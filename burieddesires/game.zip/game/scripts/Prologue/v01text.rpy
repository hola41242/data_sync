default v01isNoraKnock = False
default v01AmyPhone = False
default v01AmyisIknow = False
default v01isWifeTold = False
default v01AmyBeTheMan = False
label prologue:
    $persistent.gal1 = False
    $persistent.gal2 = False
    $persistent.gal3 = False
    $persistent.gal4 = False
    $persistent.gal5 = False
    $persistent.gal6 = False
    $persistent.gal7 = False
    $persistent.gal8 = False
    $persistent.gal9 = False
    $persistent.gal10 = False
    $persistent.gal11 = False
    $persistent.gal12 = False
    $persistent.gal13 = False
    $persistent.gal14 = False
    $persistent.gal15 = False
    $persistent.gal16 = False

    $persistent.gal17 = False
    stop music fadeout 3.0
    scene dtrapol2 with fade
    play music "audio/therapy.mp3"
    tp "At the school where you were teaching, there was a student who fell in love with you. But because of your morals, you tried to persuade her otherwise. correct?"
    tp "You tried to adhere to your code of ethics. You trusted in what society called wrong... yet it didn't change that girl's fate."
    tp "Then after she committed suicide, you talked to [pD0] to get over the sudden trauma, said you needed to clear your head, hit the road, and get away from it all."
    tp "When you started to feel normal again, you went back to [pD0]"
    tp "When you arrived back home, you found an important letter waiting for you."
    tp "The letter was from the most prestigious college in the country offering you a job."
    tp "This was the perfect opportunity to put your past behind you and start a new life."
    tp "The question you need to be asking yourself is, are you ready to become a teacher again?"
    scene dtrapol1 with dissolve
    menu:
        "I don't know":
            scene dtrapol5 with dissolve
            mc "I don't know.."
            mc "I know it wasn't my fault but... I still can't shake the feeling that I could have prevented all of this from happening."
            scene dtrapol4 with dissolve
            tp "[mc] you just need to remind yourself, there was nothing you could have done."
            tp "You cannot blame yourself for something she chose to do."
            tp "Or else we would all be held accountable for everyone's mistakes or choices."
            tp "Sometimes we have to accept the cycle of life."
            mc "I know... you're right.."
        "I'm ready":
            scene dtrapol5 with dissolve
            mc "Yes, I'm ready."
            mc "But I still think about it more often than I would like."
            mc "When I feel happy, I suddenly think of what happened and... I just forget about my happiness."
            mc "As if I don't deserve it."
            scene dtrapol3 with dissolve
            tp "When you're happy, your brain suddenly convinces you that you are in a state of grief."
            tp "It's extremely normal for people who have been through traumatic events."
            tp "When positive emotion appears, your brain begins to suppress it because that's our moral structure."
            tp "Suppressing certain emotions while grieving is nothing more than being human."
            mc "Huh.."
            mc "I suppose so.."
        "You know the answer":
            scene dtrapol5 with dissolve
            mc "Well, actually, that's why I'm here."
            mc "I wanted to hear your opinion if you think I am ready."
            scene dtrapol3 with dissolve
            tp "Of course, I understand this but, my question was actually, how are you feeling right now?"
            mc "Oh...well...to be honest, I don't know."
            mc "There is just so much weight on my shoulders, I need it lifted."
    scene dtrapol4 with dissolve
    tp "[mc], you don't have a problem."
    tp "On the contrary, you're quite trouble-free."
    mc "What makes you say that?"
    tp "I now know the answer that will end our session successfully."
    tp "You know you have done nothing wrong, and I am confident you will find a solution."
    tp "On paper, you're the perfect teacher."
    scene dtrapol5 with dissolve
    mc "But..."
    scene dtrapol2 with dissolve
    tp "But... as a teacher, you follow the same morals as everyone else."
    tp "Have you ever wondered why you feel guilty when there was nothing you can do to save that girl?"
    tp "Because you didn't try to ignore the code of ethics that the whole world sees as an immutable law."
    tp "Even if it causes someone's death."
    scene dtrapol5 with dissolve
    mc "But.."
    scene dtrapol4 with dissolve
    tp "No but, when she told you she loved you, what was the first thing that came to mind?"
    scene dtrapol1 with dissolve
    mc "A student's relationship with the teacher is prohibited."
    tp "And who imposed this ban?"
    mc "Laws."
    tp "In other words, rulers."
    tp "Now let's think about it, the rulers have told us that students cannot have relationships with their teachers."
    scene dtrapol5 with dissolve
    mc "Okay, and how was I supposed to know she would commit suicide?"
    scene dtrapol1 with dissolve
    tp "Be honest, [mc], the second thing that comes to mind after your student says she's in love with you is that it's impossible. Were you afraid that she couldn't handle the truth?"
    mc "I'm...."
    mc "Yes.."
    scene dtrapol2 with dissolve
    tp "But it was highly unlikely that she would go so far as to commit suicide. If it had been another student, maybe she would have been upset for a few months and come to her senses."
    tp "But how logical do you think it is that she killed herself because she couldn't reciprocate her love?"
    mc "What do you mean?"
    scene dtrapol3 with dissolve
    tp "Love is the most powerful emotion, it's a fact, but it's also a feeling you'll fight for the most."
    tp "I think the psychology of the girl who fell in love with you was already in a very bad situation."
    tp "Even if she got what she wanted, there was no guarantee that she wouldn't have committed suicide anyway."
    tp "As a result, the only reason you're still facing this trauma is that you think there's something you could have done and you didn't."
    tp "I'm not blaming you, I'm just explaining the real reason for the trauma."
    mc "Huh.."
    tp "I understand your feelings, but now you know what caused your trauma."
    tp "I know it's not going to make you feel better, but you must know what the problem is."
    tp "And unfortunately the only cure is time, and perhaps one... unethical suggestion."
    tp "Don't let others decide what's right or not on your behalf."
    tp "What you may see as freedom, another person may see it as oppression."
    tp "Do it in a way that no one would notice, you're a very smart man, so I'm sure it won't be a problem for you."
    scene dtrapol5 with dissolve
    mc "Yea... I'm sure murderers and rapists would agree."
    tp "Maybe, or maybe we are taught that going against the rules is a social taboo, which makes us criminals to morality."
    scene dtrapol3 with dissolve
    tp "You need to rethink your ideas on what is right and wrong. Once you cross that border, you shouldn't feel like a criminal."
    scene dtrapol1 with dissolve
    mc "If I'm honest, When I first got here, I half expected to tell you my story, wait for some cliche predictable answers, then just go back to my same miserable life."
    tp "Well, you do look much better now than you did when I first saw you."
    mc "Look maybe, but still the same inside."
    tp "Well, when you go home and put your head on the pillow, you'll start to think about everything I have told you in greater detail. "
    scene dtrapol2 with dissolve
    tp "We have a little more time before the end of our session, if you like, we can discuss some routine issues?"
    tp "Like your [pD0], for example"
    mc "Sure, why not?"
    $v01a0 = False
    $v01a1 = False
    $v01a2 = False
    $v01a3 = False
    menu v01aD:
        "[pD1]" if not v01a0:
            if persistent.patch_installed==True:
                jump pJanet
            elif persistent.patch_installed ==False:
                scene dtrapol1 with dissolve
                mc "She is a great person"
                mc "If im honest I could spend my life with her."
                mc "I love her, and I will always be there for her."
                $v01a0 = True
                jump v01aD
        "Claire" if not v01a1:
            scene dtrapol1 with dissolve
            mc "Claire"
            mc "My youngest [pD2]"
            mc "She is honestly so adorable.."
            scene dtrapol3 with dissolve
            tp "Even though I only know her by name, she must be such a sweetheart.."
            tp "Just by telling it to me, I could see it light up your eyes, you must love her."
            mc "You're quite a positive person, I envy that about you."
            tp "Please...continue"
            scene dtrapol1 with dissolve
            mc "Claire is a very rare girl as if she came from a different universe."
            mc "As horrible as the world we live in is, she treats it like her own little paradise where everything is perfect."
            mc "She lives her life to the fullest, like..."
            mc "She thinks that no one is judging her, she is constantly happy, excited, energetic."
            mc "If she was locked in the most boring, empty room on the planet, she would somehow make it the most exciting place on earth."
            scene dtrapol2 with dissolve
            tp "I can tell you have a special place in your heart for her.."
            tp "Go on."
            mc "She adores me, sometimes I feel like I'm more than just a [pD4] to her "
            mc "Her love feels so different, I am sure nobody in the world will ever love me as much as she does."
            scene dtrapol3 with dissolve
            tp "So how intense are your feelings for her in return? Compared to say your other [pD5]?"
            mc "I wish I could answer that..."
            tp "I understand."
            scene dtrapol2 with dissolve
            tp "Maybe during our next session we can go into more detail if you like."
            mc "No harm in that I suppose.."
            $v01a1 = True
            jump v01aD
        "Nora" if not v01a2:
            scene dtrapol1 with dissolve
            mc "My other [pD2], Nora."
            mc "I'm sure you get many patients that talk very little but..."
            mc "No one has spoken less than Nora and said much."
            mc "She's incredibly smart, far too mature for her age."
            mc "Sometimes I think she's more mature than I am."
            mc "The problem is, people who don't know her don't give her a chance. They think she's just a soulless creature."
            mc "You're probably thinking she is the complete opposite from Claire..."
            mc "But I don't think so, I believe she has very deep feelings that she just doesn't share."
            mc "She is most likely just very bad at expressing herself."
            mc "But, I'm certain that she loves me, she just doesn't know how to express it."
            scene dtrapol3 with dissolve
            tp "Hmmm, I think discussing Nora could be a whole session on its own"
            tp "I would like you to try giving me as much detail as you can on Nora."
            scene dtrapol5 with dissolve
            mc "Should I be worried?"
            tp "No, no, don't worry."
            tp "I would just like some more details on her next time, helps me understand her better."
            mc "Sure thing."
            $v01a2 = True
            jump v01aD
        "Emma" if not v01a3:
            scene dtrapol1 with dissolve
            mc "Emma, the oldest of my [pD6]"
            mc "I could honestly sum her up in two words."
            mc "Tempered and rebellious."
            mc "She has to be the most popular person in every room she enters."
            mc "I don't like it personally but, it's not like I can stop her."
            scene dtrapol4 with dissolve
            tp "She's quite the rule breaker, isn't she?"
            scene dtrapol1 with dissolve
            mc "Absolutely."
            mc "It looked like the more rules she's given, the more rebellious she gets."
            mc "At first, I didn't impose any rules, yet somehow she still rebelled."
            mc "So when I started making rules, she once again became more rebellious. It was almost as if she was doing it just to spite me."
            mc "Like I am one big game or something."
            mc "But when we aren't fighting, she's perfectly normal."
            mc "Yet she's always talking to me, always trying to strike up a conversation."
            mc "If I say one thing, she argues it's another as if we have nothing in common."
            mc "But I suppose it can be fun in its way, makes me think more."
            mc "I feel smarter when we argue, wakes something up inside of me that nobody else can."
            scene dtrapol3 with dissolve
            tp "Can you give an example?"
            scene dtrapol1 with dissolve
            mc "Sometimes I think of something in my head, then imagine what her counter argument would be. "
            mc "Usually crazy things that don't make any sense."
            mc "After I imagine the counter argument, I think of a way to counter the argument I just made against myself."
            mc "She knows I do this without having ever told her, I think she does the same thing."
            mc "I'm playing along with her game even without telling her I am."
            tp "You only do this with Emma, yes? Not Claire or Nora?"
            mc "Yeah, just Emma."
            scene dtrapol2 with dissolve
            tp "It seems like a lot of fun in some strange way."
            tp "That being said, I think you should tell her what you're doing someday."
            mc "I don't think so, she will laugh and call me weird or just be angry at me."
            tp "Don't ever assume."
            scene dtrapol4 with dissolve
            tp "Emma might see herself as competing against you."
            tp "Perhaps she is trying to prove herself to you in her own strange way."
            scene dtrapol5 with dissolve
            mc "Emma? Seriously?"
            mc "No, you don't know her."
            tp "In time, I'm sure I will."
            mc "Well, then I guess we'll have yet another separate session, this time for Emma."
            scene dtrapol3 with dissolve
            tp "A separate session for all of them isn't such a bad idea."
            mc "Well, you are the doctor here."
            $v01a3 = True
            jump v01aD
    scene dtrapol2 with dissolve
    tp "Before we finish, let's talk about your [pD7] briefly."
    tp "Last time you said your [pD7] got divorced, correct?"
    mc "Yeah."
    tp "How is she doing? Have you spoken to her since our last session?"
    scene dtrapol1 with dissolve
    mc "I did, she told me how she weirdly enjoys being a single mother."
    mc "She's happy, and has fewer problems alone."
    mc "But if I'm honest, I don't think she's telling the truth."
    tp "What makes you think that?"
    mc "Well, my [pD7] and I have always been competitive, ever since we were kids, we would always try to be better than one another. "
    mc "So far, the score is 1000 to my sister, 0 to me. She beats me at everything we do."
    mc "In all that time, she never once showed any signs of weakness."
    mc "Even when something was wrong, she would hide it, there is no doubt in my mind being a single mother is killing her"
    mc "Mentally and physically, she must be exhausted..."
    scene dtrapol3 with dissolve
    tp "Interesting...however, I'm afraid our time is up for this session."
    mc "Wait, Already?"
    tp "I'm afraid so but, don't worry. I have written down everything we should discuss next week."
    scene dtrapol8 with dissolve
    tp "So, I hope things go well for you, and I will see you next time."
    mc "Thank you for this, until next time."
    stop music fadeout 3.0
    menu:
        "See you":
            mc "See you."
    play music "audio/car-ride-at-dawn.mp3"
    scene nightcar
    "Well...today's session went pretty well I guess, she is a pretty good therapist."
    "She's smart.. very, smart... and professional but... I do feel awkward sometimes."
    "Kinda freaks me out when she convinces me of something."
    "Well...it is her job."
    "Maybe I will go to that interview after all."
    "Yeah...it's time to move on."
    stop music
    play music "audio/bensound-tenderness.mp3" fadein 3.0
    scene dmchomenght1 with fade
    mc "Ahh....home at last."
    scene dmchomenght2 with dissolve
    "Sounds like everyone is asleep."
    menu:
        "Check the girls":
            scene dmchomenght2
            "I can't sleep without seeing my Angels"
            $v01a4 = False
            $v01a5 = False
            menu v01aD1:
                "Check Claire and Nora" if not v01a4:
                    $persistent.gal1 = True
                    scene proldaugh5 with dissolve
                    pause
                    scene proldaugh1 with dissolve
                    "Sound asleep..."
                    menu:
                        "Check the girls":
                            scene proldaugh2 with dissolve
                            "I swear, a marching band wouldn't even be able to wake these heavy sleepers."
                            $v01M1 = False
                            $v01M2 = False
                            menu v01D0:
                                "Check Claire" if not v01M1:
                                    scene proldaugh4 with dissolve
                                    pause
                                    $v01M1 = True
                                    jump v01D0
                                "Check Nora" if not v01M2:
                                    scene proldaugh3 with dissolve
                                    pause
                                    $v01M2 = True
                                    jump v01D0
                            scene proldaugh2 with dissolve
                            "..."
                            $v01a4 = True
                            jump v01aD1
                        "Go to sleep":
                            jump d01gosleep
                "Check Emma" if not v01a5:
                    scene dmchomenght3 with dissolve
                    mc "Locked..."
                    $v01a5 = True
                    jump v01aD1
        "Go straight to sleep":
            jump d01gosleep
label d01gosleep:
    mc "I should probably get to sleep, it's pretty late."
    scene dnightwfe1 with fade
    mc "Man...she really is a work of art, but I should let her sleep."
    scene dnightwfe2 with dissolve
    pause
    scene black
    "The Next Morning"
    scene mcwake1
    "Rise and shine... time to start my new life."
    "Got an interview to nail, such a weird feeling."
    "God... I feel like a little kid again, waking up on the day of a field trip."
    "Hmmm, it's pretty early, got some time to kill... maybe I should just watch some TV."
    $v01a6 = False
    $v01a7 = False
    menu v01d2:
        "Go to the hall":
            jump gotoHall
        "Check Nora and Claire" if not v01a6:
            scene kncknora1 with fade
            menu:
                "Knock":
                    play sound "audio/knock.mp3"
                    pause
                    d1 "Come in"
                    scene prolvisitknck1 with dissolve
                    mc "Good Morning, girls."
                    d1 "Morning [pD8]"
                    d2 "Morning."
                    mc "Just thought I would come to check on you both."
                    d1 "Aaaw, we're doing just fine!"
                    mc "That's good to hear, I'll see you both in a bit. Bye, you two."
                    scene prolvisitknck2 with dissolve
                    d2 "What do you mean 'bye'?"
                    d2 "You're not leaving us again, are you?"
                    scene prolvisitknck3 with dissolve
                    d1 "W...what!"
                    d1 "[pD8]!"
                    mc "Don't be silly, sweetheart, I'm not going anywhere."
                    scene prolvisitknck4 with dissolve
                    d1 "Oh...ok...phew, you scared me!"
                    scene prolvisitknck2 with dissolve
                    mc "Nora."
                    d2 "Yes [pD8]"
                    mc "Please don't scare Claire like that."
                    scene prolvisitknck3 with dissolve
                    d1 "So you're not leaving, right?"
                    d1 "You will stay with us forever and ever, right?"
                    scene prolvisitknck1 with dissolve
                    mc "Of course, sweetheart, As I said, I'm not going anywhere."
                    d2 "Ha, alright [pD8], I love you!"
                    mc "Love you too, baby girl, see you when you're ready."
                    scene prolvisitknck5 with dissolve
                    $v01a6 = True
                    jump v01d2
        "Check Emma" if not v01a7:
            scene kncknemm with fade
            menu:
                "Knock":
                    play sound "audio/knock.mp3"
                    pause
                    "Huh... guess she's still sleeping."
                    $v01a7 = True
                    jump v01d2
label gotoHall:
    scene eponemcempty with fade
    "Pretty quiet around here."
    "...Claire... she's definitely up to something."
    "Probably try and sneak up on me again...try and scare me."
    "Game on Claire...game on..."
    scene prolhme1 with dissolve
    pause
    scene epone4 with dissolve
    "Right on time..."
    "Haha, she's so bad at this, it's adorable."
    menu:
        "Catch":
            play sound "audio/notify.mp3"
            show screen dominancePoint
            d1 "I'll catch you off guard this time!"
            scene epone6 with dissolve
            d1 "quietly.."
            scene epone8 with dissolve
            d1 "almost there.."
            scene prolhme2 with dissolve
            d1 "target identified"
            scene prolhme3 with dissolve
            d1 "I'm the sneakiest ninja."
            scene epone11 with vpunch
            d1 "Booh!"
            mc "Seriously, honey, sneaking up is not what you best at."
            scene epone13 with dissolve
            d1 "Oh c’mon!"
            d1 "Would it kill you to pretend you didn't see me coming, [pD8]?"
            mc "Take it as a life lesson, sweety."
            mc "In real life, no one will pretend to make you happy."
            scene epone13sad with dissolve
            d1 "For me, this is real life!"
            mc "Sweety.."
            mc "All right, come again, I won't notice this time."
            scene epone13sadwalk with dissolve
            d1 "It's not the same!"
            "I can't stand her being upset, but she needs to learn about life..."
            $claire_d_points += 1
        "Pretend":
            play sound "audio/notify.mp3"
            show screen lovePoint
            scene prolhme1 with dissolve
            "Look at her Sweetness!"
            scene epone4 with dissolve
            d1 "I'll catch you off guard this time!"
            scene epone6 with dissolve
            d1 "quietly.."
            scene epone8 with dissolve
            d1 "almost there.."
            scene prolhme2 with dissolve
            d1 "target insight"
            scene prolhme3 with dissolve
            d1 "I'm the sneakiest ninja."
            scene epone11 with vpunch
            d1 "Booh!"
            mc "Oh my god!"
            mc "U scared me!"
            scene epone13happy with dissolve
            mc "Ahahah, how did you sneak in?"
            d1 "Yaaaaaaay!"
            d1 "I did it!"
            mc "Yes, you did, honey."
            d1 "I came like a silent and deadly ninja!"
            d1 "Never even noticed me [pD13]!"
            mc "Nope, you're the perfect ninja, baby."
            d1 "Yaay!"
            scene epone13happywalk with dissolve
            d1 "[pD10]"
            d1 "I'm the perfect ninja."
            wf "Of course you are, honey."
            d1 "You should have seen how scared [pD13] was. I suddenly existed out of nothing, and baam!"
            d1 "I scared him with my deadly boo technique!"
            " Aah, my sweet baby girl.."
            $claire_l_points += 1
    scene eponemcempty with dissolve
    mc "Okay, now Claire's event is over, I can watch TV in peace."
    scene epone16 with dissolve
    "Oh, Nora also woke up, my quiet and docile girl.."
    scene epone17 with dissolve:
        yalign 1.0
        linear 5.0 yalign 0.0
    pause
    scene epone16
    d2 "Morning [pD8]"
    mc "Morning baby."
    scene epone18 with fade
    menu:
        "Watch tv":
            "Nothing good is ever on this early"
        "Talk to her":
            $persistent.gal2 = True
            mc "So how are you?"
            scene epone20 with dissolve
            d2 "Good."
            mc "I'm good too, thanks for asking.."
            d2 "Uh huh."
            mc "Anything you want to talk about?"
            d2 "No."
            mc "How did you sleep?"
            d2 "Good."
            mc "Good good.."
            "I'm not getting anywhere with this..."
    scene epone21 with fade
    d3 "Yawn."
    d3 "Morning, dudes."
    scene epone24 with dissolve:
        yalign 1.0
        linear 5.0 yalign 0.0
    pause
    scene epone21 with dissolve
    mc "Manners!"
    scene epone22 with dissolve
    d3 "What we talked about yesterday is still okay, right?"
    d2 "Uh huh."
    d3 "Cool"
    d3 "Get dressed, I wanna leave early."
    scene epone23 with dissolve
    d2 "You sure you need me for this?"
    d3 "Wouldn't have asked you if I didn't."
    d2 "Eh fine"
    d3 "C’mon Nora chop chop."
    d2 "Fine."
    scene epone26 with dissolve
    scene epone27 with vpunch
    play sound "audio/Slap1.mp3"
    pause
    scene epone30 with dissolve
    d2 "Ouch!"
    d2 "Please don't do that!"
    d3 "Oh shut up, I know you liked it."
    d2 "No, I don't."
    d3 "Uh huh, whatever you say, sis."
    scene epone32 with fade
    d3 "Ugh, this is so boring."
    menu:
        "Everything is boring for you":
            mc "Wow, what a surprise."
            mc "Sweety, everything is boring for you."
            scene prolhme7 with dissolve
            d3 "Excuse me!"
            mc "Calm down, just kidding."
            d3 "A comedy genius.."
            mc "Oh yeah, let's see you try."
            scene prolhme8 with dissolve
            d3 "Why waste time on this?"
            mc "Do you have a better option?"
            scene prolhme5 with dissolve
            d3 "Fine."
            d3 "What’s the best thing about Switzerland?"
            mc "What?"
            d3 "I don't know, but the flag is a big plus."
            scene prolhme9 with dissolve
            menu:
                "Laugh":
                    play sound "audio/notify.mp3"
                    show screen lovePoint
                    mc "Ahahah, okay, that is a good one."
                    show prolhme10
                    d3 "See, I told you."
                    mc "Yep, you beat me, sweety."
                    $emma_l_points +=1
                "Don't":
                    play sound "audio/notify.mp3"
                    show screen dominancePoint
                    mc "And?"
                    d3 "So that's it."
                    mc "Oh, I see, nice."
                    show prolhme11
                    d3 "I hate you so much."
                    mc "Hahaha, that was good."
                    d3 "Agghh!"
                    $emma_d_points +=1
                    "Hehehe"
        "What do you want to watch?":
            mc "Alright then, why don't you pick what we watch?."
            mc "TV is all yours."
            d3 "Meh, don't feel like it."
            d3 "About to leave anyways."
    jump EA

label EA:
    scene epone33 with dissolve:
        yalign 1.0
        linear 5.0 yalign 0.0
    pause
    scene epone34 with dissolve
    d2 "I’m ready."
    d3 "Nice, let's go."
    mc "Wait, why aren't you in uniform, Emma?"
    d3 "I left my uniform at Lilly's, and I'll stop by and get dressed before I go to school."
    mc "Seems shady."
    scene epone35 with fade
    d3 "C'mon were gonna be late."
    mc "But you're leaving early...how will you be late?"
    d3 "See you, [pD8]!"
    d2 "Bye."
    "She's up to something, but what.."
    "Anyways...got the house to myself now."
    "I can now relax a bit."
    "Or.."
    scene eponemcempty with fade
    menu:
        "Go to your [pD9]":
            play sound "audio/wakitchen1sound.mp3"
            scene wakitchen1 with fade
            mc "Ah...my beautiful [pD9]"
            menu:
                "Grab her":
                    mc "Hey sexy."
                    scene wakitchen2 with dissolve
                    wf "Well, well if it ain't mister charming himself."
                    mc "Oh yeah, Think mister charming would do this?"
                    scene wakitchen3 with vpunch
                    wf "[mc]!"
                    wf "The.. they will hear!"
                    mc "Nah..got the house to ourselves"
                    wf "Oh, okay then."
                    wf "I think I can guess, but...what do you want for breakfast?"
                    mc "Shh...just...keep cooking."
                    wf "Oho? Kinky..."
                    menu:
                        "Ask her why she's dressed like that.":
                            $v01isWifeTold = True
                            mc "By the way, why are you dressed like this in the morning?"
                            scene wakitchen7 with dissolve
                            wf "Ugh seriously?"
                            mc "What, this is unusual, and I was wondering"
                            wf "I'm going shopping with your [pD7], I told you that."
                            scene wakitchen36 with dissolve
                            mc "Okay, how is she, by the way?"
                            wf "She's not well, she's been having a hard time since her divorce."
                            mc "Why didn't she tell me?"
                            wf "Actually, I shouldn't have said it either, but we need to do something about it."
                            mc "What's the problem, financially or psychologically?"
                            wf "Both."
                            mc "Great, [pD7]'s in a terrible state, and I'm just learning about it."
                            mc "And you're not telling me! Bravo Janet."
                            scene wakitchen37 with dissolve
                            wf "It's not my fault, she made me promise."
                            mc "I guess... but still."
                            mc "How about we offer to take them in here? How does that sound?"
                            scene wakitchen38 with dissolve
                            wf "Actually, I had that exact thought, Amy can't work and also keep up with her girls."
                            wf "We can take care of her and her girls, at least until she's back on her feet."
                            mc "Wow, ok, phew, for a second, I thought you would hate the idea."
                            wf "Are you kidding, Amy's my best friend."
                            mc "God..you do make me feel like the luckiest man in the world."
                            scene wakitchen40 with dissolve
                            wf "Awww."
                            mc "Anyway, I really should get going."
                            mc "Say hi to Amy for me."
                            scene wakitchen41 with dissolve
                            wf " Will do honey."
                            jump v01leavehome
                        "Make a move":
                            scene black
                            play sound "audio/undressed.mp3"
                            pause
                            scene wakitchen4 with dissolve
                            wf "[mc]...what...what are...mmh!"
                            mc "Shhh...just accept it"
                            wf "I...oh god..."
                            mc "You're mine, baby...always remember that."

                            wf "To..ngh...to the bedroom?"
                            mc "No."
                            mc "You're mine, and I can have you anywhere I like."
                            wf "That's so...ngh...god."
                            mc "Shush."
                            mc "No talking until I say."
                            mc "Understand me?"
                            wf "Mmmgh...y...yes."
                            mc "Good girl."
                            mc "Go on then...tell me how much you love it."
                            wf "I..oooh."
                            mc "Say it, baby, like the little slut you are."
                            wf "I..nggh...I love it so much, daddy..."
                            scene wakitchen8 with fade
                            wf "God... I need this"
                            scene wakitchen9 with dissolve
                            mc "Go on then...make daddy happy."
                            scene wfv011remqe125es_1
                            pause
                            scene wakitchen10 with dissolve
                            pause
                            scene wakitchen11 with dissolve
                            pause
                            scene wakitchen12 with dissolve
                            pause
                            scene wakitchen9 with dissolve
                            wf "Is my daddy happy?"
                            mc "Fuck...go on...keep...going."
                            scene wfv011remqe125es_1
                            wf "Oh my.."
                            wf "God, I love when you talk dirty to me."
                            mc "You were such an innocent girl when we first met."
                            mc "Now look at you, a cock hungry little fucktoy."
                            wf "MHmm!"
                            mc "Fuckkkk...yes baby."
                            wf "Mhmm."
                            mc "Remember when you sucked me for the first time?"
                            wf "Mmmhm."
                            mc "Instantly fell in love with my cock didn't you?"
                            wf "Uhhm."
                            mc "Keep...going ngh..."
                            mc "Alright...ngh...time to be a proper slut"
                            scene wfv011remakeprol2_1_1
                            wf "Mhm hmm."
                            mc "Yessss..."
                            mc "God, I will always love your mouth..."
                            mc "Warm...wet..."
                            mc "Take it, baby..."
                            wf "Mhmmhmm."
                            scene wakitchen13
                            mc "Ughh."
                            scene wakitchen14
                            mc "Ohh."
                            mc "Igh!"
                            mc "Suck it, baby..."
                            "God, I'm.."
                            "Getting..."
                            "So..."
                            "Cloooose!"
                            menu:
                                "Cum in her throat":
                                    scene wakitchen19 with dissolve
                                    pause
                                    scene wakitchen20 with dissolve
                                    mc "hnnng!"
                                    scene wakitchen24 with vpunch
                                    wf "Hngghhh!"
                                    mc "Fuck!!"
                                    mc "Oooh god!"
                                    mc "I...god...that...oh my god."
                                    mc "I..."
                                    mc "Don't..swallow I..wanna see."
                                    scene wakitchen25 with dissolve
                                    mc "Fuck... best [pD9] ever."
                                    mc "Go on, my little whore...you can swallow now."
                                    scene wakitchen26 with dissolve
                                    play sound "audio/SWFSwallow1.wav"
                                    pause
                                "Cum on her face":
                                    mc "Babe, I'm coming!"
                                    mc "Get ready!"
                                    scene wakitchen28 with vpunch
                                    mc "Iggggh!"
                                    mc "Fuck me..."

                            show wakitchen31 with dissolve
                            wf "Heh...where did that come from?"
                            wf "Fucking wild babe."
                            mc "Heh..sorry."
                            mc "Guess something just...made me hornier."
                            wf "Haha, it's fine love, I swear I could have cum without even touching myself."
                            wf "Guess I just love when my inner slut comes out."
                            mc "Too bad you didn't let it out when you were younger!"
                            wf "Hey, we're still young!"
                            wf "I have all those years of being an innocent girl to make up for."
                            wf "So...trust me...I want to try everything you with."
                            mc "Like everything!?"
                            wf "Yeah, everything.."
                            mc "Does that include anal?.."
                            wf "Anal? Really? Childs play"
                            mc "Oh fuck...so...how about?"
                            wf "haha, easy there, cowboy, you can fuck my ass another day...now..help me get up."
                            mc "fiiiine fine."
                            scene wakitchen32 with dissolve
                            mc "Come on, baby."
                            scene wakitchen33 with dissolve
                            wf "Hehe...forget mister charming, more like king charming over here."
                            mc "You know it."
                            scene wakitchen34 with dissolve
                            mc "Wowowow..."
                            wf "Huh?"
                            mc "You got some...cum on your face?"
                            scene wakitchen35 with dissolve
                            wf "Oh ahaha what? Don't love me enough to kiss me after fucking my face?"
                            mc "Ha, I love you but...not that much."
                            mc "Anyway."
                            mc "Ok...that was great, but I have to get ready for this interview."
                            mc "Wish me luck and...thank you, baby."
                            wf "Good luck...daddy..hehe."
                            scene wakitchen41 with fade
                            mc "Love you, honey."
                            wf "Love you more."
                            jump v01leavehome
                "Leave":
                    scene wakitchen41 with fade
                    mc "Hey, love, I'm heading out."
                    wf "Alright, sweetie! Good luck!"
                    jump v01leavehome
        "Leave":
            scene wakitchen41 with fade
            mc "Hey, love, I'm heading out."
            wf "Alright, sweetie! Good luck!"
            jump v01leavehome
label v01leavehome:
    stop music fadeout 3.0
    scene black
    "You're out of the house, in your car."
    play music "audio/car-ride-at-dawn.mp3"
    scene mccar1 with fade
    pause
    scene mccar2 with dissolve
    pause
    scene mccar3 with dissolve
    play sound ("audio/phonevibration.mp3")
    mc "Who's that now?"
    scene mccar4 with dissolve
    menu:
        "Answer it":
            stop sound
            scene mccar5 with dissolve
            mc "Hey [pD7]"
    ss "Hey [mc], how are you?"
    mc "Not too bad, heading for my interview."
    ss "Is that the one you got the letter from?"
    mc "That's the one, pretty confident, honestly."
    ss "As you should be, you didn't even apply, so they want you."
    ss "Gonna be hanging out with all those spoiled rich kids, haha!"
    mc "You know me, I'll be nice until I throw one out the window."
    ss "Damn right, I would hire you."
    mc "Who wouldn't?"
    mc "Anyways, so what's up? Do you need something?"
    scene mccar5 with vpunch
    ss "No, just checking up seeing how you are."
    ss "Been a while since I've seen you."
    mc "Yeah, I was just thinking that this morning."
    ss "Yeah, we should meet up, I'm seeing Janet today."
    if v01isWifeTold:
        menu:
            "I know":
                play sound "audio/notify.mp3"
                $v01AmyisIknow = True
                $renpy.notify("Amy will remember this")
                mc "Yeah she told me"
                ss "Oh.."
                ss "Alright..."
                scene mccar5 with vpunch
                "Wait...shit, I wasn't supposed to tell her that"
                "Fuck... I'm a dead man."
            "Really?":
                mc "Yeah? She didn't say anything about that."
                ss "Oh, I told her not to tell you."
                mc "Uh...why?"
                scene mccar5 with vpunch
                ss "I don't know... we'll talk about it when I see you."
                mc "If you say so."
    $v01x0 = False
    $v01x1 = False
    menu v01Dx0:
        "Ask about the girls" if not v01x0:
            mc "How are the girls?"
            ss "They're alright, girls being girls."
            ss "Full of energy but, nothing I can't handle."
            mc "Yeah, sounds like nothing's changed."
            ss "Oh, they have mentioned that they missed you."
            scene mccar5 with vpunch
            mc "Tell them I miss em too, and I will give them a big hug next time I see them."
            ss "Will do."
            $v01x0 = True
            jump v01Dx0
        "Ask about the divorce" if not v01x1:
            mc "You probably don't want to talk about it, but I gotta ask."
            mc "Since you're alone now...and the girls."
            mc "Do you think you can handle it?"
            ss "Pfft, you forget who I am already?"
            ss "I'm the strong one in the [pD12], remember?"
            ss "There is nothing I can't handle, only losing to you, which will never happen."
            mc "Yaya, but still, I worry sometimes."
            mc "Maybe...you should move in with us?."
            $v01AmyPhone = True
            scene mccar5 with vpunch
            mc "Your girls will get along great with mine."
            ss "Thanks for the offer, but I can handle it."
            menu:
                "Insist":
                    mc "Listen, I know you're the strong one of the [pD12]."
                    mc "But that doesn't mean you need to be Wonder Woman, it's my job to make sure you're safe."
                    ss "Trust me, I can handle it on my own."
                    ss "I appreciate the offer, but the answer is no, and I'm sticking to it."
                    menu:
                        "Be the man":
                            play sound "audio/notify.mp3"
                            show screen dominancePoint
                            $amy_d_points+=1
                            mc "Fuck sake Amy. "
                            mc "This isn't a fucking joke, you're moving in with me and that final understand?"
                            ss "Well, well, well, look who's balls finally dropped."
                            mc "This isn't a joke Amy..."
                            ss "Look, you're only doing this because I'm your [pD7]."
                            mc "Does it matter?"
                            scene mccar5 with vpunch
                            mc "You're moving in with us, end of story."
                            ss "And if I keep saying no?"
                            mc "Then I will drag your ass to my house."
                            ss "Ugh..."
                            ss "...Fine"
                            mc "*sigh* Okay..good, thank you for letting me help you."
                            mc "But listen, I'm here, so I have to go. We will talk about it more when I see you in person."
                            ss "Alright...good luck and..."
                            ss "Thanks..."
                            mc "Talk to you soon, ok?"
                            ss "Alright.."
                            ss "...listen."
                            mc "Hm?"
                            ss "When I said thanks...I mean it."
                            mc "We are [pD12], we look out for each other."
                            ss "You're right...thank you again, I'll...see you soon."
                            mc "Bye."
                            $v01AmyBeTheMan = True
                        "Don't insist":
                                mc "Hmm, okay then [pD7].."
                                mc "But don't forget that our door is always open to you."
                                ss "Thank you again [mc], you are the best."
                                mc "Anyway, I'm about to get to school, let's meet, then we'll talk in more detail."
                                ss "Okay then [mc], good luck with your first day."
                                ss "Don't pee in your pants."
                                mc "Ha ha, so funny."
                                scene mccar5 with vpunch
                                mc "Anyway, see you later."
                                ss "See you."
                "Don't":
                        mc "Hmm, okay then [pD7].."
                        mc "But don't forget that our door is always open to you."
                        ss "Thank you again [mc], you are the best."
                        scene mccar5 with vpunch
                        mc "Anyway, I'm about to get to school, let's meet, then we'll talk in more detail."
                        ss "Okay then [mc], good luck with your first day."
                        ss "Don't pee in your pants."
                        mc "Ha ha, so funny."
                        mc "Anyway, see you later."
                        ss "See you"
            $v01x1 = True
            jump v01Dx0
        "End call":
                mc "Hmm okay then [pD7].."
                mc "Anyway, I'm about to get to school, let's meet, then we'll talk in more detail."
                ss "Okay then [mc], good luck with your first day."
                ss "Don't pee in your pants."
                scene mccar5 with vpunch
                mc "Ha ha, so funny."
                mc "Anyway, see you later."
                ss "See you."
    scene mccar6 with fade
    stop music
    play music "audio/bensound-tenderness.mp3" fadein 3.0
    menu:
        "Enter":
            scene okhol1 with fade
            "Seems pretty normal so far."
            scene prolschol2 with fade
            "Wonder what she's staring at."
            menu:
                "Say hi":
                    $persistent.gal4 = True
                    scene prolschol3 with dissolve
                    mc "Hey."
                    mc "You alright?"
                    "Shy little thing.."
                    mc "Well...ok...guess I'll see you around."
                "Keep Walking":
                    mc "Maybe I should leave her alone."
            scene prolschol5 with dissolve
            menu:
                "Say hi":
                    scene prolschol6 with dissolve
                    "Holy shit, she's cute."
                    mc "Good Morning."
                    m1 "Oh sorry, I'm in a rush."
                "Keep Walking":
                    scene prolschol6 with dissolve
                    "Holy shit, she's cute..."
            scene prolschol7 with dissolve
            mc "Huh... she is pretty... pretty weird.. more like."
            scene prolschol4 with dissolve
            menu:
                "Go to the second floor":
                    scene prolschol9 with fade
            mc "Oh neat, twins."
            scene prolschol10 with dissolve
            menu:
                "Say hi":
                    mc "Morning girls."
                    tw1 "Hi!"
                    tw2 "..."
                    mc "Wow, aren't you two just adorable."
                    tw1 "Awww heh, thanks!"
                    scene prolschol11 with dissolve
                    tw2 "Do you need something?"
                    mc "Just passing by."
                    tw2 "Uh huh ya...so are you here for a reason or just to perv on little girls?"
                    mc "I'm here for an interview."
                    tw2 "Cool, finally someone to mop the floors properly."
                    mc "harr harr, very funny, young lady."
                    tw1 "Gasp! He spoke like a teacher!"
                    tw2 "Great... just what we need... another crappy teacher."
                    mc "Anyway, I should really get going."
                    tw1 "Oki! Can't wait to see you in my class!"
                    mc "Hold on now, they have to hire me first."
                    tw1 "Oh right, then good luck, nearly teacher!"
                    mc "How adorable."
                "Go on":
                    jump v01principal
            jump v01principal
        "Go straight to the principal's office":
            jump v01principal
label v01principal:
    scene black
    "In front of the principal's door."
    scene metprol1 with fade
    menu:
        "Knock on the door":
            play sound("audio/knock.mp3")
    sm "Enter!"
    stop sound
    scene metprol2 with dissolve
    mc "Good Morning."
    scene metprol3 with dissolve
    sm "Oooh, so you must be the superstar."
    mc "...huh?"
    scene metprol4 with dissolve
    sm "Well, don't just stand there, have a seat."
    mc "um..sure."
    scene metprol5 with dissolve
    sm "I gotta say, when I first heard about you, I half expected a bald...fat..ugly middle aged pervert but, this is...quite a surprise."
    mc "Oh...well I'm...flattered but... who told you about me?"
    sm "Hush hush, no need to be so nervous."
    sm "My assistant gave me everything I need to know."
    mc "Alright...Ms.."
    scene metprol6 with dissolve
    sm "Gaby."
    sm "Charlotte Gaby."
    mc "Nice to meet you, Miss Gaby, but who tol..."
    sm "shh...please.. call me Charlotte."
    scene metprol7 with dissolve
    sm "So let us get right to the point."
    sm "So why does an ordinary teacher such as yourself got a job offer from the country's most luxurious school?"
    sm "Is that what you want to know?"
    mc "I...yeah, I suppose so."
    "This is weird."
    "Miss Gaby... I think you're trying to seduce me..."
    sm "As I said, your experience in teaching makes you the perfect choice for our school."
    sm "If you did some research which...no doubt you have, you would know what kind of standard we require from our teachers."
    sm "Yet... somehow our overall success rate remains significantly below average"
    sm "For a while now we've had to do a lot of work to hide this gem of a school from the public"
    scene metprol5 with dissolve
    menu:
        "What kind of work?":
            scene metprol6 with dissolve
            sm "Let just say, a necessary kind of work."
            mc "Alright..."
        "So you bribed?":
            play sound "audio/notify.mp3"
            show screen dominancePoint
            $gaby_d_points +=1
            mc "So it starts with 'B' and ends with 'ribed' right?"
            sm "Our methods should be an irrelevance to you."
    scene metprol7 with dissolve
    sm "But recently, the school's low success rate has become too noticeable."
    sm "So we turned to some more...unorthodox methods, to ensure our school remains hidden."
    sm "Our current faculty members are highly qualified, but...they lack something."
    mc "Discipline?"
    sm "Hmmm, you are a smart boy."
    mc "Well, one of the key points of being a teacher is authority."
    sm "True, but...I was thinking more... fear."
    mc "Fear?"
    sm "You walked through these halls, seen these students. They are all spoiled rich brats, parents of wealth and power."
    mc "That would explain why your standards are far beyond all the other schools."
    mc "In this case, teachers are forced to give low grades even though they fear the consequences."
    mc "But it's hard to bring fear when all the teachers are giving out low grades, can't fire all of them."
    sm "You just keep impressing me more and more, you know that?..."
    sm "But I'm sure you have figured out where you fit in with all of this, you have a talented blend of both authority and education."
    sm "We would like to bring you on, as an example of what kind of teachers we are looking for here."
    scene metprol5 with dissolve
    sm "Of course you know this won't be easy, you have to not only succeed but...all eyes will be on you."
    sm "Give us what we need, and you will get what you want in return."
    mc "Perhaps, this may be an offer I simply can not refuse."
    mc "I could find some cushy dead end job working in a Public school."
    mc "But...perhaps the extra effort required here is exactly what I need in life."
    mc "But...will the workload be worth it?"
    scene metprol6 with dissolve
    sm "Worth it?... I don't think you understand what we offer here..."
    "Oh...she doesn't seem too happy about that...uh oh.."
    sm "You want a good paying job? We will give you more money than you know what to do with. [mc]"
    sm "You'll have power...status."
    sm "You can play nice with me all you want."
    sm "It's not me you need to convince."
    sm "Those little shits in the halls? Turn then into dream students."
    sm "Corrupt their minds with outsider thoughts, something their parents have no knowledge of."
    sm "Imagine it, rich students, that understand real world problems."
    sm "Ten Thousand poor students would never achieve what one of these rich students can."
    "I have to say, this interview is bonkers."
    "It sure is different, rather exciting..."
    "But... Do I want this kind of responsibility?"
    scene metprol7 with dissolve
    mc "You're right, but...."
    mc "I don't know..."
    sm "Let's be honest, [mc], you and I both know an opportunity like this will never happen again."
    sm "This is what will happen..."
    sm "The [mc] that makes the wrong decision will say no, he will walk out that door and take up a job at some nobody public school."
    sm "That [mc] will never have anything exciting happen to him ever again."
    sm "He will wake up, drive to work and teach 100 students that will also achieve nothing, drive home. Sleep, and do the same thing every day for the rest of his life."
    sm "He never made any wealth, power, or received any form of recognition. Never seized any opportunities that presented themselves to him."
    sm "He learned, to play it safe..."
    scene metprol5 with dissolve
    sm "And he never got noticed by anyone..."
    mc "..."
    "Fuck..."
    "She's good.."
    "But...do I want this...I know my [pD1] does and... so do my [pD5] would too."
    "...this is beyond anything I expected."
    "But...what about."
    "My [pD7]..."
    "Single mother...broke.."
    "I could buy us a mansion, have her move in, and we could all live together."
    "I think..."
    "Okay...fuck it."
    "let's do it!"
    scene metprol6 with dissolve
    mc "Perhaps..."
    sm "hmm?"
    mc "It's time I seized the opportunity then."
    scene metprol7 with dissolve
    sm "Excellent!"
    sm "So it is agreed then."
    sm "As I said, your students are rich and egotistical...even for their young age."
    sm "Establishing authority over them is not going to be an easy task."
    sm "Violence is not an option...."
    sm "Unless...you have to."
    mc "What about the students' attitude towards me?"
    sm "They will try and end your career, cry to mommy and daddy but, leave that to us."
    sm "It works, but unfortunately, many teachers have quit over that simple threat, being unable to handle them."
    mc "Problem is if these students wanted to..."
    mc "They could ruin not just my career, but my entire life."
    sm "Of course, it's happened before."
    sm "But that is why you are here, we just need your ability to turn them into little angels."
    sm "Do what you think is necessary, and we won't have any problems."
    sm "If you fail then, good luck being fucked for life, but if you succeed, you will have the world at your feet."
    mc "Right..."
    mc "Ok.."
    mc "I think I am up to the challenge."
    sm "I'll give you one tip, though."
    sm "As you have noticed, a majority of the students are female."
    sm "And, the majority of these girls have...shall we say...daddy issues."
    sm "If none of your methods work, then you can train these girls in... your own ways."
    sm "Just...make sure the door is locked when you do."
    scene metprol4v5 with dissolve
    sm "So...you have a year to prove yourself."
    scene metprol8 with dissolve
    sm "I took the liberty of collecting a list of our most troubling girls."
    scene metprol9 with dissolve
    sm "If you can turn half of these girls, then you have succeeded."
    sm "Everything you need to know is on this list."
    sm "Discover who they are, their secrets, and the things they hide from everyone."
    sm "As long as you keep it quiet, you may do as you wish to convert them."
    sm "All I care about is that you help get this school back on track."
    scene metprol5 with dissolve
    "Does she want me to..."
    "Do...that to them?"
    "This school is so fucking weird."
    "Ah, who am I kidding, I took the job, I might as well at least try."
    "Honestly... my morals are my morals and that's not going to change."
    "And I should do my best to make sure they don't."
    "What's the worst that can happen? I can teach some rich brats some proper morals."
    "Yeah...I think I'm ready for this."
    "I'll try to save the students that can be saved."
    "I'll treat those who are born bad as they deserve."
    sm "Due to privacy, you will be given a new bank account, your first deposit should already be waiting for you."
    sm "Once you start to show us that you are capable of this job, you will see your bank account begin to fill up."
    sm "So...congratulations, you are officially employed. "
    sm "You will start tomorrow, be here bright and early."
    sm "Now... get out of my office."
    "Did I just sign a contract with the devil?"
    "Oh well..."
    "What now.."
    menu:
        "Go back to your car":
            scene mccar6 with fade
            pause
    scene metprol10 with dissolve
    mc "Well...here's to my new life."
    scene end1
    play sound "audio/walking-in-high-heels.mp3"
    pause
    stop sound
    $persistent.gal9 = True
    scene endprlg2
    pause
    scene endprlg3
    pause
    jump v011Start
