image wfBlow0 = Movie(play="animation/v01blow0.mpg")
image wfBlow1 = Movie(play = "animation/v01blow1.mpg")
image wfBlow2 = Movie(play = "animation/v01blow2.mpg")
image wfBlow3 = Movie(play = "animation/v01blow3.mpg")
image wfBlow4:
    "wakitchenre1" with dissolve
    1
    "wakitchenre2" with dissolve
    1
    repeat
#v011
image wfv011roomkissing = Movie(play="animation/v011/roomkissing.webm")
image wfv011feetjob1 = Movie(play="animation/v011/feetjob1.webm")
image wfv011fj2= Movie(play="animation/v011/fj2.webm")
image wfv011hj1 = Movie(play="animation/v011/hj1.webm")
image wfv011hj2 = Movie(play="animation/v011/hj2.webm")
image wfv011kitchenkiss = Movie(play="animation/v011/kitchenkiss.webm")
image wfv011reversecg1 = Movie(play="animation/v011/reversecg1.webm")
image wfv011pgjiggle = Movie(play="animation/v011/pgjiggle.webm")
image wfv011remakeprol2_1_1 = Movie(play="animation/v011/remakeprol2_1_1.webm")
image wfv011remqe125es_1 = Movie(play="animation/v011/remqe125es_1.webm")
image wfv011revrsejigle = Movie(play="animation/v011/revrsejigle.webm")
image wfv011revrsejigle2 = Movie(play="animation/v011/revrsejigle2.webm")
image wfv011tcrhndlck = Movie(play="animation/v011/tcrhndlck.webm")
image wfv011t1intro = Movie(play="animation/v011/t1intro.webm")
image wfv011Lunaending = Movie(play="animation/v011/Lunaending.webm", loop = False)
image wfv011rubyintro = Movie(play="animation/v011/rubyintro.webm", loop=False)

#v02
image analhrdc = Movie(play="animation/v02/analhrdc.webm")
image anlclose = Movie(play="animation/v02/anlclose.webm")
image bjeye = Movie(play="animation/v02/bjeye.webm")
image analhrdc = Movie(play="animation/v02/analhrdc.webm")
image bjsdeone = Movie(play="animation/v02/bjsdeone.webm")
image deeppntr = Movie(play="animation/v02/deeppntr.webm")
image fetj = Movie(play="animation/v02/fetj.webm")
image hjahea = Movie(play="animation/v02/hjahea.webm")
image hjhk = Movie(play="animation/v02/hjhk.webm")
image rversecg = Movie(play="animation/v02/rversecg.webm")
image rvrseclose = Movie(play="animation/v02/rvrseclose.webm")
image sidehj = Movie(play="animation/v02/sidehj.webm")
image talksni = Movie(play="animation/v02/talksni.webm")
image rubydoor = Movie(play="animation/v002/rubydoor.webm")
image amymcgjbthrm = Movie(play="animation/v002/amymcgjbthrm.webm")

#v03
image hmmmmmm = Movie(play="animation/v03/hmmmmmm.webm")
image hmmmmmm_1 = Movie(play="animation/v03/hmmmmmm_1.webm")
image hmmmmmm_2 = Movie(play="animation/v03/hmmmmmm_2.webm")
image hmmmmmm_3 = Movie(play="animation/v03/hmmmmmm_3.webm")
image hmmmmmm_4 = Movie(play="animation/v03/hmmmmmm_4.webm")
image hmmmmmm_5 = Movie(play="animation/v03/hmmmmmm_5.webm")
image wfeee = Movie(play="animation/v03/wfeee.webm")

#v04
image rubydance = Movie(play="animation/v04/rubydance.webm")
#v05
image anrcpgac1 = Movie(play="animation/v05/anrcpgac1.webm")
image anrcpgac2 = Movie(play="animation/v05/anrcpgac2.webm")
image lekmescn1a = Movie(play="animation/v05/lekmescn1a.webm")
image lekmescn2a = Movie(play="animation/v05/lekmescn2a.webm")
image lekmescn3a = Movie(play="animation/v05/lekmescn3a.webm")
image lekmescn4a = Movie(play="animation/v05/lekmescn4a.webm")
image lekmescn5a = Movie(play="animation/v05/lekmescn5a.webm")
image lekmescn6a = Movie(play="animation/v05/lekmescn6a.webm")
image lekmescn3v2 = Movie(play="animation/v05/lekmescn3v2.webm")
image rbmgrlgrdn1a = Movie(play="animation/v05/rbmgrlgrdn1a.webm")
image rbmgrlgrdn2a = Movie(play="animation/v05/rbmgrlgrdn2a.webm")
image rbmgrlgrdn3a = Movie(play="animation/v05/rbmgrlgrdn3a.webm")
image rbmgrlgrdn4a = Movie(play="animation/v05/rbmgrlgrdn4a.webm")
