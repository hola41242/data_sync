default v04McWentRuby = False
default v04McWentZoey = False
label v04_a:
    $config.allow_skipping = True
    scene black with Fade(1.0, 2.0, 1.0)
    "Next day in livingroom"
    pause 0.5
    scene rbygnm1 with fade
    pause
    scene rbygnm2 with dissolve
    pause
    rb "Hey [pD14]!"
    mc "Hey Ruby."
    rb "I'm a little shy about to say this, but you know, we talked about cosplay?"
    rb "If you're serious, there's a fun event we can attend together."
    rb "But if you have free time of course."
    mc "How long will it last?"
    rb "..."
    mc "Ruby?"
    rb "Few days..."
    mc "Few days?"
    mc "What kind of event is that?"
    rb "Uhmmm...."
    rb "It's called Cosplay with [pD83]."
    rb "There is a hotel for such events."
    rb "My friend went to that party last year. She praised it so much that I always wanted to go too."
    rb "I know it's so selfish of me to want something like that..."
    rb "but I wanna go so much, please don't hate me [pD14]..."
    mc "Don't be silly."
    mc "You know what? I'm in."
    mc "You want it so much, and who knows? Maybe I like it."
    rb "I've always wanted to participate, maybe now we can participate together if you want, of course."
    mc "I said I'm in honey."
    rb "Well actually, it's not that necessary, we don't necessarily need to participate in this event..."
    rb "we can do it by ourselves at home in the garden or something like that..."
    rb "that would be very nice too."
    mc "Ruby!"
    rb "What [pD14]?"
    mc "I said I'm in. Let's do this."
    rb "Seriously?"
    mc "Yes honey seriously."
    rb "YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    scene rbygnm1 with dissolve
    pause
    mc "This is going to take some time."
    rb "AAAAAAAAAAAAAAAAAAAAAAY"
    mc "Silly thing..."
    mc "Hmm"
    mc "Cosplay with [pD83]."
    mc "A small trip..."
    mc "probably cute cosplay girls..."
    mc "Holy shit!"
    mc "This is like a lottery!"
    mc "I hope this doesn't cost too much..."
    scene rbygnm2 with dissolve
    pause
    mc "You calm now?"
    rb "Yes yes!"
    mc "When can you get ready?"
    rb "Ready already!"
    mc "Not shocking."
    mc "Okay, then I'll come to your house, have you talked to your [pD80]?"
    rb "Yeah of course."
    mc "Okay sweety, I'll be there soon."
    mc "But please don't start yaying again!"
    rb "Just a little bit?"
    mc "No!"
    "....."
    mc "Okay just a little..."
    "YAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    mc "Nope, I can't."
    mc "Heh no text this time."
    scene black with fade
    "At Ruby's house"
    scene lbyvent1 with dissolve
    pause
    rb "YAAAAAAAAAAAAAAAAAAAAAAAAAAAAA....."
    scene lbyvent2 with dissolve
    pause
    rb "AAAY"
    mc "(What is that dress Ruby...)"
    scene lbyvent3 with dissolve
    pause
    mc "You're happy, aren't you?"
    rb "Of course [pD14] I completed my yaay"
    rb "It's pretty important."
    mc "I'm sure it is."
    scene lbyvent4 with dissolve
    pause
    mc "Hey there cutie."
    rb "Who me!"
    mc "I don't see any other cuties around."
    scene lbyvent5 with dissolve
    pause
    rb "[pD14] stop, you make me red again"
    rb "You know my [pD80] said I'm all red because of you."
    mc "Wait..."
    rb "Every time you make me happy, I blush"
    mc "Oh... yeah because of that."
    mc "Makes sense."
    mc "I like red."
    rb "Eheheh"
    scene lbyvent6 with dissolve
    play sound "audio/cardoor.mp3"
    rb "I can't believe we're doing this!"
    mc "We are going to the cosplay contest which is so much miles far from here."
    mc "Hmmm"
    mc "It is kinda weird."
    scene lbyvent7 with dissolve
    pause
    rb "You are not gonna bail on me, right [pD14]?"
    rb "You don't want me to see in a bad mood right..."
    rb "[pD14]..."
    scene lbyvent8 with dissolve
    play music "audio/car-ride-at-dawn.mp3" fadein 1.0
    pause
    mc "Ahmm..."
    mc "(This is new)"
    mc "(She's using her female things on me)"
    mc "(Which is pretty weird. It's too soon...)"
    mc "(Is it?)"
    mc "(I wonder if I caused this)"
    mc "(She was so innocent...)"
    mc "(Well still is, but I feel that something is going to change.)"
    mc "(I can't ignore it, I need to get on top of it and understand it clearly.)"
    mc "Honey why are you talking like that?"
    mc "I'm asking because this is new."
    scene lbyvent9 with dissolve
    pause
    rb "I'm talking like what?"
    rb "I feel so many things at the same time and I can't act normal when this happens."
    mc "This?"
    rb "Yes, tons of emotions trapped in my body are being released right now."
    mc "What caused this?"
    rb "I have no idea..."
    mc "(This one makes me excited I don't know why...)"
    mc "You have no idea huh"
    rb "Yup I have no idea what this is, but I know that you are the source of this"
    mc "Okay this is a..."
    mc "pretty good answer"
    rb "What kind of answer you want to hear [pD14]?"
    rb "I can lie for you"
    rb "If you really want, I can make you believe my lies."
    mc "(She believes she's completely in control of the conversation)"
    mc "(Now I'm sure she found one of Luna's magazines.)"
    mc "(But this is so fun. I'm gonna let her)"
    mc "Uhm..."
    mc "Thanks, but I don't think I need lies right now."
    mc "Also what kind of lies you're talking about?"
    rb "Anything you wanna hear."
    mc "Why?"
    rb "Because I want to pay you back somehow."
    rb "I don't have money or talent or anything you like"
    rb "I have to show my gratitude."
    mc "With lies?"
    scene lbyvent10 with dissolve
    pause
    rb "I..."
    rb "I don't know..."
    rb "I just..."
    rb "Actually, you are right [pD14]."
    rb "Lying for gratitude is not a good idea."
    rb "I'm so happy that I can't think straight."
    rb "When you came to pick me up, everything suddenly became so serious."
    rb "My feelings exploded and then..."
    mc "Ruby"
    mc "I get it honey just calm down."
    rb "Yup"
    scene lbyvent11 with dissolve
    pause
    rb "Sorry about that..."
    mc "It's cute"
    scene lbyvent10 with dissolve
    pause
    rb "Hmh?"
    mc "Everything about you"
    rb "Really..."
    rb "I know you've been saying these things to me a lot..."
    rb "and every time I hear it, it makes the same effect as the first time I heard it"
    rb "But..."
    mc "No honey"
    scene lbyvent13 with dissolve
    pause
    mc "There is no but"
    mc "You amaze me in every possible way"
    mc "I won't stop saying it every time you amaze me"
    mc "I don't want to hear that stupid question you're about to ask me"
    mc "Everything I say is words that come straight from my heart."
    scene lbyvent16 with dissolve
    pause
    mc "Yeah I know, I'm boring."
    scene lbyvent15 with dissolve
    pause
    mc "Of course, fall asleep while I'm saying something good."
    scene lbyvent16 with dissolve
    pause
    mc "You're really sleeping huh?"
    mc "Wait..."
    mc "Why am I just noticing that her dress is open..."
    mc "I have a gorgeous breast in front of my eyes but I didn't notice for a while..."
    mc "I feel like losing the control..."
    mc "Why..."
    mc "Also what should I do about that fugitive?"
    mc "Should I fix the dress?"
    mc "Or should I wake and warn her?"
    scene lbyvent16 with dissolve
    pause
    mc "Or...."
    mc "I can look at it sometimes to boost my energy."
    mc "the trip can be much more enjoyable."
    scene lbyvent18 with dissolve
    pause
    rb "Mhhmm"
    rb "Ice cream..."
    scene lbyvent19v1 with dissolve
    pause
    scene lbyvent19 with dissolve
    pause
    rb "Oh..."
    mc "What's that honey?"
    scene lbyvent20 with dissolve
    pause
    rb "Nothing!"
    rb "I'm just soo sleepy"
    rb "Gonna sleep a little."
    scene lbyvent21 with dissolve
    pause
    mc "Hey careful!"
    rb "Sorry [pD14]."
    mc "Honey what are you doing?"
    scene lbyvent24 with dissolve
    pause
    rb "Oh no..."
    rb "I'm stuck [pD14]..."
    scene lbyvent22 with dissolve
    pause
    mc "No you're not"
    scene lbyvent23 with dissolve
    pause
    rb "How do you know?"
    scene lbyvent22 with dissolve
    pause
    mc "(I remember this scene from somewhere.)"
    mc "Maybe I can see you're not stuck?"
    scene lbyvent23 with dissolve
    pause
    rb "You wouldn't know that without being in my place [pD14]..."
    scene lbyvent22 with dissolve
    pause
    mc "If you're not stuck, when I step on the gas a little, you'll stick right in the back seat"
    mc "You want to try?"
    scene lbyvent25 with dissolve
    pause
    rb "But [pD14] you wouldn't do that to me, right?"
    scene lbyvent26 with dissolve
    pause
    rb "[pD14]?"
    rb "You wouldn't do that, right?"
    menu:
        "Step on the gas!":
            $ruby_d_points +=1
            show screen dominancePoint
            play sound "audio/notify.mp3"
            scene lbyvent21 with dissolve
            pause
            mc "Honey of course I wouldn't do such a thing"
            scene lbyvent25 with dissolve
            pause
            rb "Ehehe I knew I..."
            scene lbyvent27 with dissolve
            pause
            play sound "audio/car-engine-sound-effect.mp3"
            scene lbyvent28 with dissolve
            pause
            scene lbyvent29 with dissolve
            pause
            rb "[pD14]..."
            scene lbyvent30 with vpunch
            play sound "audio/falling-sound-effect-bgm-and-sound-effect.mp3"
            pause
            scene lbyvent31 with dissolve
            pause
            scene lbyvent32 with vpunch
            pause
            mc "Ahahahaha you need to see yourself right now!"
            rb "Pfffff"
            mc "C'mon it's a joke, also, you wanted this."
            scene lbyvent33 with dissolve
            pause
            rb "Yeah it's true..."
        "Of course I wouldn't honey":
            $ruby_l_points +=1
            play sound "audio/notify.mp3"
            show screen lovePoint
            scene lbyvent22 with dissolve
            pause
            mc "Honey of course I wouldn't do such a thing"
            scene lbyvent23 with dissolve
            pause
            rb "Ehehe I knew it!"
    scene lbyvent34 with dissolve
    pause
    rb "[pD14]"
    mc "Yes honey"
    scene lbyvent35 with dissolve
    pause
    rb "In all the excitement I forgot to ask"
    rb "What costume did you bring for cosplay?"
    scene lbyvent34 with dissolve
    pause
    mc "It's a secret my dear."
    scene lbyvent36 with dissolve
    pause
    rb "Oh it's exciting!"
    rb "Can I guess?"
    scene lbyvent37 with dissolve
    pause
    mc "Well..."
    mc "Let it be a surprise, okay?"
    rb "Oh, okay I'm cool with that."
    mc "Good."
    rb "Yeah."
    mc "Mhm hm."
    rb "..."
    scene lbyvent38 with dissolve
    pause
    rb "Is it a pirate costume???"
    mc "Seriously?"
    scene lbyvent39 with dissolve
    pause
    rb "Can you say rrr for me?"
    mc "Why?"
    scene lbyvent40 with dissolve
    pause
    rb "if you can say RRR like a pirate, maybe you've figured out how to become a pirate?"
    mc "I don't catch the logic in there"
    rb "So you've been working to say rrr if you brought a pirate costume."
    mc "Oh so this is your trick."
    mc "What if I'm a natural at being a pirate?"
    mc "For example, what happens if I say it perfectly, even if I didn't choose the pirate theme"
    rb "It's even cooler, it means you've been a pirate before"
    mc "Hm"
    mc "Might be"
    scene lbyvent41 with dissolve
    pause
    rb "So rrr?"
    mc "Sure why not."
    mc "Rrrrr"
    scene lbyvent40 with dissolve
    pause
    rb "Yeah you are a terrible pirate"
    mc "Oh yeah let's hear your rrrr then!"
    rb "I'm a girl, a cute one! Have you ever heard a cute girl pirate before?"
    mc "What about girls who are not cute?"
    mc "Can they be pirate?"
    rb "No they're girls. It is a boy thing."
    mc "Then why you added cute?"
    rb "Because I am."
    mc "But..."
    mc "Nevermind."
    mc "The answer is no, not a pirate."
    rb "Oh, okay."
    scene lbyvent42 with dissolve
    pause
    scene lbyvent43 with dissolve
    pause
    rb "A ninja!"
    mc "What's that?"
    rb "You chose Ninja, didn't you?"
    mc "You want to keep asking that huh?"
    scene lbyvent44 with dissolve
    pause
    rb "Can't help it! I wanna know!"
    scene lbyvent45 with dissolve
    pause
    mc "Yeah but you can't."
    mc "So honey I have a question."
    scene lbyvent44 with dissolve
    pause
    rb "What's that [pD14]?"
    scene lbyvent45 with dissolve
    pause
    mc "What is actually cosplay with [pD83]?"
    mc "My first guess is that you are dressing up and there is a competition about who is better."
    mc "Or...?"
    scene lbyvent46 with dissolve
    pause
    rb "Oh no, there is no competition [pD14]."
    rb "It's like this role-playing activity."
    mc "Huh?"
    rb "We will dress and socialize as whoever we want to be."
    scene lbyvent45 with dissolve
    pause
    mc "(Well this actually not surprising.)"
    mc "(She is just looking for a place where she can comfortably do her favorite hobby without embarrassment.)"
    mc "Oooh..."
    mc "I see now."
    mc "That's even better."
    scene lbyvent42 with dissolve
    pause
    scene lbyvent43 with dissolve
    pause
    rb "Is it?"
    mc "Yeah, in fact, I am excited that we will do this activity together."
    scene lbyvent44 with dissolve
    pause
    rb "Oh good, I was afraid that you would bail on me."
    mc "There is no chance honey."
    scene lbyvent47 with dissolve
    pause
    rb "Ehehe happy"
    mc "You're making happy noises"
    rb "Thank you for noticing"
    mc "It's hard to not."
    mc "I think we're about to arrive."
    rb "Yaay!"
    scene cphlt1 with Fade(1.0, 2.0, 1.0)
    play music "audio/the-way-to-you.mp3"
    pause
    mc "Damn!"
    mc "Looks too bright..."
    rb "..."
    scene cphlt2 with dissolve
    pause
    mc "So, we're here honey."
    mc "How do you feel?"
    rb "..."
    mc "Ruby?"
    rb "It's so amazing, I'm definitely not going crazy, and everything is normal!"
    rb "I mean, everything is great, as I've always wanted!"
    scene cphlt3 with dissolve
    pause
    scene cphlt4 with dissolve
    pause
    mc "Is everything okay, honey?"
    scene cphlt5 with dissolve
    pause
    scene cphlt6 with dissolve
    pause
    rb "..."
    scene cphlt7 with dissolve
    pause
    rb "I'm scared [pD14]..."
    mc "Huh why?"
    rb "I can't get dressed up and walk around people."
    mc "But this was your idea?"
    rb "I thought I could do it, but I'm so scared right now."
    rb "Please let's go back home [pD14]."
    mc "(Well I was expecting something like this.)"
    mc "(I have to take control for her sake.)"
    scene cphlt10 with dissolve
    pause
    mc "Honey, this is totally normal."
    mc "I knew something like this was going to happen."
    mc "It's okay. You're having a little shock right now."
    mc "No one will laugh at you."
    mc "In fact, you know what? You will be the most glamorous cosplayer in this hotel."
    mc "People will look at you, yes, but they will admire what they are looking at."
    mc "This is me talking."
    mc "No lies."
    scene cphlt8 with dissolve
    pause
    rb "No shenanigans..."
    mc "Exactly."
    scene cphlt9 with dissolve
    pause
    rb "You're right [pD14]."
    rb "Thanks for that."
    rb "I feel much better."
    mc "Good."
    mc "Let's pick a room."
    scene cphlt11 with dissolve
    pause
    scene cphlt12 with dissolve
    pause
    rcp "Thank you for reporting this, you can be sure that we will solve the problem as soon as possible."
    rcp "Have a nice day!"
    scene cphlt13 with dissolve
    pause
    rcp "Sorry to keep you waiting."
    scene cphlt14 with dissolve
    pause
    rcp "Welcome to our hotel."
    rcp "How can I help you?"
    mc "Hey."
    rcp "Hey."
    mc "..."
    mc "Hey."
    rcp "Hey."
    mc "Is everything all right?"
    rcp "Of course sir."
    rcp "It's our policy, we answer everything."
    mc "Why?"
    rcp "Because our customers deserve all the answers."
    mc "What if I'm here to ask for an address?"
    scene cphlt15 with dissolve
    pause
    rcp "...."
    mc "Hey?"
    scene cphlt16 with dissolve
    pause
    rcp "What?"
    mc "Ugh..."
    scene cphlt14 with dissolve
    pause
    mc "I'm here for a vacation."
    rcp "Oh how amazing, thank you sir for choosing us!"
    mc "Oh how kind you are."
    rcp "This is your kindness sir."
    mc "......"
    rcp "....."
    mc "How did you do that!"
    rcp "What exactly sir?"
    scene cphlt17 with dissolve
    pause
    rb "[pD14]..."
    mc "Oh right..."
    scene cphlt13 with dissolve
    pause
    mc "We need a room."
    scene cphlt14 with dissolve
    pause
    rcp "Of course, we have a lot of rooms."
    rcp "What kind of room do you want?"
    mc "Regular."
    rcp "I know exactly what you're looking for, sir."
    mc "Yeah, I just said."
    rcp "Of course, sir."
    mc "So..."
    rcp "Yes sir?"
    mc "What exactly is this cosplay thing?"
    rcp "We have an extremely free dress code, you can do any cosplay you want within the hotel's boundaries."
    rcp "In addition, you can benefit from cosplay events designed by the hotel management."
    rcp "We treat you as whoever you want to be here."
    mc "How so?"
    rcp "Let's say you decided to become a pirate, we treat you like a pirate."
    scene cphlt18 with dissolve
    pause
    rb "Hah, she chose a pirate too!"
    rb "A very good choice, [pD14], you see?"
    mc "Yeah yeah I get it."
    scene cphlt13 with dissolve
    pause
    mc "What do you mean, we're treating you like you're a pirate?"
    rcp "Like if I see you in a pirate costume I'll say ahoy instead of hey."
    mc "Huh what if I dress like a king?"
    rcp "Then I call you my king."
    mc "What if I dress like a dictator?"
    scene cphlt17 with dissolve
    pause
    rb "[pD14]!"
    mc "Yeah honey sorry."
    mc "Just give me the keys."
    scene cphlt20 with dissolve
    pause
    rcp "Of course sir, thank you for choosing us."
    scene cphlt21 with dissolve
    pause
    scene cphlt22 with dissolve
    pause
    rb "Oh my..."
    rb "This room is awesome!"
    mc "(That bitch)"
    mc "(When she said 'I know exactly what you're looking for', I thought she'd found us a twin room.)"
    mc "(This is for couples)"
    mc "(Well...)"
    mc "(I should give her a good tip actually.)"
    scene cphlt23 with dissolve
    pause
    scene cphlt24 with dissolve
    pause
    rb "Right [pD14]?"
    mc "Sure honey."
    scene cphlt25 with dissolve
    pause
    mc "I'm just going to take a nap."
    scene cphlt26 with dissolve
    pause
    rb "Aww tired already?"
    mc "I'm old."
    scene cphlt27 with dissolve
    pause
    rb "Hah silly [pD14] you are not that old."
    mc "That?"
    rb "Okay then I'm gonna do something about..."
    rb "I'll probably wait until you wake up..."
    mc "No, you're going to explore the hotel while I'm sleeping."
    rb "But [pD14]...."
    scene cphlt28 with dissolve
    pause
    mc "I said explore the hotel! Go go go!"
    rb "Ay!"
    rb "Yes [pD14]!"
    scene cphlt29 with dissolve
    pause
    mc "Good girl."
    play sound "audio/doorStorming.mp3"
    scene cphlt30 with dissolve
    pause
    mc "Ruby?"
    mc "Hm no response."
    scene rbhl1 with dissolve
    pause
    mc "Just as I thought!"
    mc "I have to do something to increase her courage."
    scene rbhl2 with dissolve
    pause
    mc "Hmm"
    scene rbhl3 with dissolve
    pause
    mc "But first let's show the consequences of lying."
    scene rbhl4 with dissolve
    pause
    play sound "audio/Slap1.mp3"
    scene rbhl5 with vpunch
    pause
    scene rbhl6 with dissolve
    pause
    rb "Oh my!"
    rb "[pD14]!"
    mc "What are you doing?"
    scene rbhl7 with dissolve
    pause
    rb "Uhmm..."
    rb "Can you give me a few minutes?"
    mc "Why? So you can find a lie?"
    rb "Yeah I can't lie because I'm focusing on my ass right now."
    scene rbhl8 with dissolve
    pause
    mc "C'mon it's not that hard."
    mc "If I spanked Luna this soft, she wouldn't even feel it."
    scene rbhl9 with dissolve
    pause
    rb "Wow really?"
    rb "How hard you hit her bum?"
    mc "Well actually, something that requires delicacy can vary depending on the situation and according to the person."
    rb "How exactly [pD14]?"
    mc "Hmm"
    mc "Wait!"
    mc "What are you doing here?"
    scene rbhl10 with dissolve
    pause
    rb "Aww..."
    rb "Not worked"
    mc "Ruby..."
    scene rbhl11 with dissolve
    pause
    rb "I'm afraid to do what you say, [pD14]."
    mc "You've decided to hide here until I wake up."
    scene rbhl12 with dissolve
    pause
    rb "More or less, yeah"
    mc "Ugh"
    mc "Let's go to the room."
    scene rbhl13 with dissolve
    pause
    rb "Why, are you gonna teach me a lesson!?"
    mc "Kind of"
    rb "Oh no..."
    rb "But I deserved that"
    scene rbhl14 with dissolve
    pause
    rb "Please go easy on me sir!"
    mc "Come"
    rb "Yes sir!"
    scene rbhl15 with dissolve
    pause
    mc "Okay, now put on your costume."
    rb "Hm?"
    mc "Do it!"
    rb "Yes sir!"
    scene rbhl16 with fade
    pause
    mc "(I thought I could finish this trip without doing this)"
    mc "(I have to do it for Ruby's self-confidence)"
    mc "Are you dressed Ruby?"
    rb "Almost, [pD14]."
    rb "I don't understand why all of a sudden you want to see me cosplay."
    rb "But that's what I wanted anyway, I am much more comfortable that there is no one else but us."
    rb "That's why I'm wearing the costume I chose specially for you!"
    rb "I'm so excited!"
    mc "Good, same."
    mc "You ready?"
    scene rbhl17 with dissolve
    pause
    rb "I am, but most importantly are you ready for this [pD14]?"
    mc "(Hah she has no idea)"
    mc "I think you'll have to be ready."
    rb "Trust me [pD14]."
    mc "I'm going to..."
    rb "I'm going to..."
    mc "Surprise you!"
    rb "Surprise you!"
    scene rubydance
    pause
    scene rbhl18 with dissolve
    pause
    rb "[pD14]!"
    mc "Ruby!"
    scene rbhl19 with dissolve
    pause
    rb "I can't believe you did that!"
    mc "......."
    "My eyes are not ready for this"
    "She is a real angel!"
    "I think this is falling in love..."
    mc "Yeah..."
    scene rbhl20 with dissolve
    pause
    rb "You are the best. Oh my god I love you so much!"
    "I think my heart got a boner right now..."
    "If she had lived centuries ago, she could have started a war with her beauty."
    scene rbhl21 with dissolve
    pause
    rb "[pD14]!"
    rb "Are you there?"
    mc "Yeah yeah"
    scene rbhl22 with dissolve
    pause
    rb "How do I look?"
    rb "I chose this for you."
    rb "I hope you like it."
    mc "(Like?)"
    mc "(You gotta be joking Ruby)"
    mc "(I've never felt this way before.)"
    mc "(And I can't describe it correctly...)"
    mc "(I love it.)"
    scene rbhl23 with dissolve
    pause
    rb "Yaay!"
    rb "So happy!"
    scene rbhl25 with dissolve
    pause
    rb "But [pD14], you..."
    rb "You look so good!"
    scene rbhl28 with dissolve
    pause
    rb "You finally got rid of that suit for a while."
    scene rbhl26 with dissolve
    pause
    rb "Oh my god, I'm having so much fun right now!"
    rb "My heart is about to explode!"
    scene rbhl29 with dissolve
    pause
    rb "And you know..."
    scene rbhl30 with dissolve
    pause
    rb "Oh my [pD14]..."
    scene rbhl31 with dissolve
    pause
    rb "Ahah you scared me"
    scene rbhl32 with dissolve
    pause
    rb "I'm definitely not complaining about this situation, but what do I owe this honor?"
    scene rbhl33 with dissolve
    pause
    mc "..."
    rb "[pD14]?"
    scene rbhl34 with dissolve
    pause
    rb "Okay then, I stop questioning and surrender myself to this moment."
    scene rbhl35 with dissolve
    pause
    rb "Wow."
    rb "Your eyes are amazing!"
    scene rbhl36 with dissolve
    pause
    rb "....."
    mc "(Her breath...)"
    mc "(So warm, soft...)"
    mc "(It's like a warm wind is massaging my face...)"
    mc "(Smells like strawberries...)"
    mc "(She really smells like strawberries, I think she ate something with strawberries.)"
    mc "(Maybe it's natural, she's so perfect.)"
    mc "(I wouldn't mind if I died right now.)"
    scene rbhl37 with dissolve
    pause
    rb "[pD14] I..."
    mc "(Sush honey)"
    mc "(Let your [pD14] taste heaven...)"
    mc "(Everything is perfect right now. Everything is as it should be.)"
    mc "(I'm gonna do it!)"
    scene rbhl38 with dissolve
    pause
    play sound "audio/a-cute-sneeze.mp3"
    scene rbhl39 with dissolve
    pause
    scene rbhl40 with dissolve
    pause
    rb "Aah..."
    scene rbhl41 with dissolve
    pause
    rb "Wow that was super relief!"
    rb "Eheheh"
    scene rbhl42 with dissolve
    pause
    rb "Oh [pD14]!"
    scene rbhl43 with dissolve
    pause
    rb "Sorry, I've been waiting for this sneeze all day. For a moment I forgot I was hugging you, my body just took control."
    rb "Oh your face..."
    mc "(Aah...)"
    mc "It's okay Ruby."
    mc "I'll wash my face and then we'll tour the hotel for a while."
    scene rbhl44 with dissolve
    pause
    rb "Oh sure [pD14] take your tim...{w} What!"
    scene rbhl45 with dissolve
    pause
    rb "No way [pD14] I definitely can't leave the room like this!"
    rb "Nu uh forget it..."
    scene rbhl46 with dissolve
    pause
    mc "Oh kitty got claws, since when have you been defying me, Ruby?"
    rb "But [pD14]..."
    mc "There is no but!"
    scene rbhl47 with dissolve
    pause
    rb "Yes sir..."
    mc "Huh! What was that? Did you say yaaay?"
    rb "Kind of"
    mc "What was that!"
    scene rbhl48 with dissolve
    pause
    rb "Yaaaay!"
    mc "That's what I wanna hear!"
    scene rbhl49 with fade
    pause
    mc "So"
    mc "How do you feel right now?"
    scene rbhl50 with dissolve
    pause
    rb "Okay, you were right, it had nothing to do with what I was afraid of..."
    rb "But still I don't think I can do it without you."
    scene rbhl52 with dissolve
    pause
    rb "Agh!"
    rb "For some reason, I'm starting to hate admitting that I'm wrong!"
    mc "Hah! you became a woman then."
    scene rbhl51 with dissolve
    pause
    rb "[pD14]"
    mc "Yeah honey?"
    rb "Thank you."
    rb "It may seem like a very insignificant thing, but I really thank you very much for what you have done for me."
    rb "Neither Luna nor my [pD80] could have forced me to do this."
    rb "I'm not saying I'm a bad girl. They wouldn't force me to do it, because when I said I didn't want it, they would get upset and stop trying."
    rb "So I guess that's why I'm like this."
    scene rbhl53 with dissolve
    pause
    mc "No honey, because you grew up without a father."
    mc "Girls who have experienced this misfortune usually have two options."
    mc "Maybe if you had an older brother who is 2-3 years older than you, that could have worked too. But growing up without a father is an incomplete start to life for a girl."
    mc "If you grew up with a good father, you would learn how to choose the right person. Because your mother, who had already chosen a good father, would teach you how to do this."
    scene rbhl54 with dissolve
    pause
    rb "Is this what happens to all girls who grow up without a father [pD14]?"
    mc "A large majority yes."
    scene rbhl51 with dissolve
    pause
    rb "There is a 3rd option..."
    mc "Hmph?"
    rb "Remember you said that girls growing up without a father have 2 options"
    rb "There is another."
    mc "Oh yeah, what is it?"
    scene rbhl55 with dissolve
    pause
    rb "It's you."
    "..."
    rb "Go sleep [pD14] I'm going to change my clothes and walk in the park."
    rb "And don't worry about me, it's almost like half of everything comes from you."
    rb "And that makes me strong."
    scene cphlt30 with dissolve
    pause
    mc "Damn I slept too much."
    mc "Where is Ruby..."
    mc "Ruby, are you here?"
    mc "No I guess."
    mc "Let's find her."
    scene cphlt31 with dissolve
    pause
    mc "(Still too bright...)"
    scene cphlt32 with dissolve
    pause
    mc "Hey"
    rcp "Hey"
    scene cphlt33 with dissolve
    pause
    rcp "Did you like our hotel, sir?"
    mc "I just woke up."
    rcp "So you used our bed, didn't you?"
    mc "Yes."
    rcp "Did you enjoy our beds sir?"
    mc "...."
    mc "Yes I enjoyed."
    rcp "Amazing!"
    mc "Yeah yeah it is."
    mc "Have you seen my [pD21] lately?"
    rcp "Which one is your [pD21] sir?"
    mc "Ginger one."
    rcp "Oh yeah I know her."
    mc "So?"
    rcp "Isn't she super cute?"
    mc "Yeah she is, but what about my question?"
    rcp "What was your question?"
    mc "Did you see her?"
    rcp "Oh yes I saw her."
    mc "Where is she..."
    rcp "I just saw her sir."
    mc "Where and when?"
    rcp "20 minutes ago, here."
    mc "Where did she go?"
    rcp "Can't remember, she could have gone anywhere."
    rcp "Because there is a different activity all over our hotel, if you are interested, I will give you our catalog."
    mc ".........."
    mc "Have a good day."
    rcp "You too sir."
    mc "....."
    mc "(Weirdo)"
    scene cphlt34 with dissolve
    pause
    mc "I have to ask someone else."
    mc "Like the kimono girl."
    mc "She was there when I got there."
    scene cphlt35 with dissolve
    pause
    mc "Hey."
    mc "If I'm not going to bother, can I ask you a question?"
    scene cphlt36 with dissolve
    pause
    mc "(Sure take your time.)"
    mc "(They are becoming more and more disrespectful these days...)"
    mc "(The problem of this generation is less spanking...)"
    scene cphlt38 with dissolve
    pause
    mc "(Huh too fancy for a brat.)"
    mc "(But...)"
    mc "(Nice.)"
    scene cphlt37 with dissolve
    pause
    gth1 "Did you like what you see?"
    mc "Uhmm..."
    mc "(Shit that was too obvious!)"
    menu:
        "Yes":
            scene cphlt39 with dissolve
            pause
            mc "Honestly, I'm expecting cuter but that suits you too, so the answer to your question is yes, I like what I see."
            gth1 "Oh thanks."
            gth1 "What do you want?"
            mc "Have you seen a red head girl lately?"
            gth1 "Wig or real red head?"
            mc "Uhmm real."
            gth1 "Nope I didn't see any."
            mc "What about wig did you see red head wig?"
            gth1 "Also no."
            mc "Then why did you ask wig or real? You could say you didn't see her directly."
            gth1 "....."
            scene cphlt37 with dissolve
            pause
            gth1 "Did you see my dad?"
            mc "What? How should I know your dad?"
            scene cphlt39 with dissolve
            pause
            gth1 "How should I know your red head?"
            mc "I just literally said red head, just like you're saying right now!"
            gth1 "Yeah whatever."
            mc "(Fucking brat...)"
        "No":
            scene cphlt35 with dissolve
            pause
            mc "Honestly, no."
            mc "I'm expecting cuter undies."
            mc "This doesn't suit you."
            if persistent.patch_installed == True:
                jump v04_b
        "Act like don't know what she's talking about":
            scene cphlt39 with dissolve
            pause
            mc "Huh?"
            mc "I don't understand."
            gth1 "...."
            mc "Did you see a red head girl lately?"
            gth1 "Nope."
            mc "Okay..."
            mc "Thanks."
            mc "(Such a little brat...)"
label v04_c:
    scene cphlt55 with dissolve
    pause
    mc "(Oh this girl should know.)"
    scene cphlt56 with dissolve
    pause
    mc "Hi, I was looking for my..."
    scene cphlt57 with dissolve
    pause
    gth2 "She was walking by the pool with someone twenty minutes ago."
    mc "Oh thanks."
    mc "Wait someone?"
    gth2 "Yeah I saw her with a dude."
    mc "What, a dude!?"
    scene cphlt56 with dissolve
    pause
    gth2 "Mhm hm"
    gth2 "Anything else?"
    mc "(Nope, thanks.)"
    mc "(What the fuck!)"
    scene cphlt59 with Fade(1.0, 2.0, 1.0)
    pause
    mc "(There she is.)"
    scene cphlt60 with dissolve
    pause
    mc "(And hello cutie.)"
    mc "(Damn I love this hotel so far!)"
    mc "(Oh, Ruby!)"
    scene cphlt61 with dissolve
    pause
    mc "Ruby!"
    scene cphlt62 with dissolve
    pause
    rb "Oh [pD14] you are awake."
    mc "Yeah."
    mc "I found out that you came to the pool with someone."
    mc "Who is your new friend?"
    scene cphlt63 with dissolve
    pause
    rb "Oh he..."
    rb "He is awesome [pD14]!"
    mc "Awesome how?"
    scene cphlt64 with dissolve
    pause
    mc "Also why are you still wearing this dress?"
    scene cphlt65 with dissolve
    pause
    rb "Why? You said you liked the dress..."
    mc "Yes, I love it, but that doesn't mean you can wear this dress in front of other people."
    mc "I'm sure I said that."
    scene cphlt66 with dissolve
    pause
    rb "Oh..."
    rb "But I thought that this is a normal thing."
    mc "It's not, only around me."
    rb "Okay [pD14], I'm sorry."
    rb "..."
    mc "Anyway, go on."
    scene cphlt63 with dissolve
    pause
    rb "I was exploring the area and..."
    mc "Really just like that?"
    scene cphlt67 with dissolve
    pause
    rb "...."
    scene cphlt68 with dissolve
    pause
    rb "Well almost."
    rb "As I was walking towards the garden, I met someone"
    rb "He asked me why I wasn't dressed."
    rb "I told him that I couldn't do it without you"
    rb "Then I said I was going to the garden but..."
    rb "he told me that the garden is boring right now, the pool is fun."
    rb "I still wanted to go to the garden, but he insisted, so I'm here."
    mc "(Seems weird)"
    scene cphlt63 with dissolve
    pause
    mc "What else?"
    rb "And we didn't do anything else."
    scene cphlt69 with dissolve
    pause
    rst "Hey Ruby did you see it?"
    rst "I was so fast please say you saw."
    scene cphlt70 with dissolve
    pause
    rb "Yes I saw it. You were so good."
    scene cphlt71 with dissolve
    pause
    rst "Well this is me, right?"
    rst "Water is good why don't you come in?"
    scene cphlt72 with dissolve
    pause
    rst "Huh?"
    rst "Who is this?"
    mc "Who are you?"
    rst "I asked first."
    mc "I'm her..."
    scene cphlt73 with dissolve
    pause
    rb "Friend!"
    scene cphlt74 with dissolve
    pause
    rb "This is my friend..."
    scene cphlt75 with dissolve
    pause
    mc "(Why did Ruby introduce me as her friend...)"
    mc "(Damn, she's looking at me with those eyes again.)"
    mc "(I don't like the way it's going, but I'll keep up.)"
    mc "Yeah her friend, a friend to whom her responsibility belongs."
    scene cphlt76 with dissolve
    pause
    rst "Oh okay man, nice to meet you."
    rst "I'm Josh and I'm the savior of shy cosplayers."
    mc "(I wanna punch him so hard right now...)"
    mc "A truly tremendous vision..."
    mc "I'm sure your parents are very proud of you."
    rst "Yeah..."
    rst "Ahahah anyway, I have to go now."
    rst "I have to get ready for the night."
    mc "Uh huh, nice to meet you cosplay Jesus."
    rst "ahah...."
    scene cphlt77 with dissolve
    pause
    rb "Uhmmmmmm....."
    mc "What?"
    rb "So..."
    mc "Just say it..."
    rb "Can we go?"
    mc "Mhm?"
    rb "A place like, like a nightclub, bright but also dark."
    scene cphlt78 with dissolve
    pause
    rb "Isn't that right, Josh?"
    rb "He told me it's so beautiful. I want to see, shall we go please..."
    rst "As long as you want Ruby."
    rst "Your friend doesn't have to come, you can come with me."
    scene cphlt79 with dissolve
    pause
    mc "Dude, you didn't quite get it."
    mc "I just spoke softly because I didn't want to make Ruby nervous."
    mc "Obviously, you don't understand much about implicit threats, so I'm telling you openly..."
    mc "I don't want to see you near this girl."
    scene cphlt81 with dissolve
    pause
    rb "[pD14], what's going on?"
    mc "It's a cosplay"
    rb "Oh it is..."
    rb "Okay."
    mc "Right, buddy?"
    rst "Yeah..."
    mc "(You are so done if I see you around her.)"
    scene cphlt80 with dissolve
    pause
    rst "Okay, then I'll find my girl, but I'll see you guys anyway."
    rb "But I want to meet with her..."
    scene cphlt82 with dissolve
    pause
    rst "You can meet with her in the night club."
    rb "Yaay"
    mc "(Hmmm my girl...)"
    mc "(Is she his daughter or her date or like me?)"
    mc "(I wonder about her...)"
    scene cphlt83 with dissolve
    pause
    rb "So what we gonna do [pD14]?"
    mc "Everything you want, as long as you're in front of my eyes."
    scene cphlt86 with dissolve
    pause
    mc "The last time I remember, I was your [pD14], not your 'friend'."
    rb "[pD14] I'm not a little kid anymore..."
    mc "So?"
    rb "Well..."
    rb "I'm sorry, I'm just ashamed"
    mc "Of me?"
    rb "Yeah I was silly"
    mc "It's okay, just be careful."
    mc "So what you wanna do?"
    scene cphlt84 with dissolve
    pause
    rb "I wanna swim!"
    mc "Then go swim."
    rb "Yay!"
    scene cphlt85 with dissolve
    pause
    rb "Oh..."
    rb "I changed my mind!"
    scene cphlt87 with dissolve
    pause
    mc "Oh I see"
    mc "So many people here huh"
    rb "Mhm hm..."
    mc "It's okay honey i'm here with you."
    mc "Or we can do something else."
    mc "Let's go to the room and change, maybe you'll have the courage to go into the pool."
    scene cphlt780 with dissolve
    pause
    rb "Oh I..."
    mc "C'mon, no one gonna disturb you while I'm here honey."
    scene cphlt88 with dissolve
    pause
    rb "I forget to bring swimsuit anyway let's do something else."
    mc "How could you have forgotten? You came with a big suitcase."
    mc "Oh I see..."
    mc "You didn't bring a swimsuit from the beginning because you were afraid to swim, right?"
    rb "No I just forgot..."
    mc "Ugh"
    mc "I got this, but I don't want to leave you alone."
    rb "Why?"
    scene cphlt89 with dissolve
    pause
    mc "(I can't say that such men are dangerous, she may start thinking that I look like such men...)"
    mc "(I need to figure this out soon.)"
    mc "(She is so naive that makes her easy target.)"
    mc "(I mean look at her, she's like a black friday for weirdos!)"
    scene cphlt90 with dissolve
    pause
    mc "(Hey, this is my lovely [pD21]...)"
    mc "(But it's fucking true...)"
    rb "..."
    scene cphlt91 with dissolve
    pause
    mc "(Hey, it's like I know this girl from somewhere.)"
    mc "(She looks a lot like someone I know.)"
    scene cphlt92 with dissolve
    pause
    scene cphlt93 with dissolve
    pause
    mc "Hey do I know you?"
    scene cphlt94 with dissolve
    pause
    sy "Oh my god mr. [mc]!"
    mc "Huh"
    sy "I'm so embarrassed, I never thought you'd see me like this!"
    scene cphlt95 with dissolve
    pause
    mc "Zoey?"
    sy "Hi, mr. [mc]..."
    mc "What are you doing here?"
    mc "Cosplay and vacation. Yeah that was a stupid question."
    scene cphlt98 with dissolve
    pause
    sy "Please don't tell them please!"
    sy "They'll make fun of me until I graduate."
    mc "(At least she has the goal of graduating.)"
    mc "Of course I won't tell anyone Zoey."
    scene cphlt99 with dissolve
    pause
    sy "Oh thank god I was so scared..."
    scene cphlt100 with dissolve
    pause
    scene cphlt101 with dissolve
    pause
    sy "I'm sorry, I act weird when I get scared."
    mc "It's okay, I liked it."
    sy "Oh..."
    mc "(I like it?)"
    mc "(Why I said that...)"
    scene cphlt102 with dissolve
    pause
    mc "Scared of what?"
    mc "Do you really think I'm going to gossip with students behind your back?"
    sy "Yeah I don't know, I'm just scared..."
    mc "No need, in fact it's great that I ran into you here."
    sy "Oh why?"
    mc "I need your help Zoey"
    sy "My help?"
    scene cphlt103 with dissolve
    pause
    mc "Could you look after her sometimes"
    mc "When I'm busy with something else..."
    sy "Oh of course I always get along with cute girls."
    mc "(I wonder why?)"
    mc "Amazing, you are a lifesaver!"
    scene cphlt104 with dissolve
    pause
    sy "Me?"
    mc "Yeah I just portrayed my gratitude in a different way."
    sy "Usually people don't say such things to me..."
    mc "(Poor thing)"
    mc "(I'm kinda sad for her...)"
    mc "So we deal?"
    sy "Yes! I'll take care of her!"
    scene cphlt105 with dissolve
    pause
    sy "Uhmmm"
    sy "From what by the way?"
    mc "Oh yeah I almost forget."
    mc "From men."
    scene cphlt106 with dissolve
    pause
    sy "Oh I see."
    sy "I can do that!"
    sy "Should I kill them if they cross the line?"
    mc "Ahah nice one."
    scene cphlt105 with dissolve
    pause
    mc "Especially there is a guy..."
    mc "Josh."
    mc "Be careful about that guy a lot, if you see him just take Ruby and find me okay?"
    sy "Sure whatever you say mr. [mc]!"
    mc "(Nice)"
    mc "So what did you want from me in return?"
    sy "I don't understand..."
    mc "For your favor?"
    scene cphlt107 with dissolve
    pause
    sy "Oh I know what I want!"
    mc "Except for grade or similar things."
    scene cphlt108 with dissolve
    pause
    sy "Awww"
    scene cphlt105 with dissolve
    pause
    sy "Hmmm let me think first."
    mc "Sure."
    mc "Thank you again."
    mc "Come let me introduce you."
    scene cphlt109 with dissolve
    pause
    mc "Hey Ruby, look, this is one of my students, Zoey."
    mc "You seem to have a lot in common."
    scene cphlt110 with dissolve
    pause
    rb "Oh how nice!"
    rb "Do you like cosplay too?"
    scene cphlt111 with dissolve
    pause
    sy "Yeah..."
    sy "Sometimes..."
    rb "Oh I see you are exactly like me!"
    rb "This is perfect I'm not alone anymore!"
    mc "You never were honey"
    scene cphlt109 with dissolve
    pause
    rb "Yeah but she is shy like me."
    mc "Oh yeah that's right."
    mc "Huh it's actually pretty accurate."
    scene cphlt112 with dissolve
    pause
    mc "(Am I lucky or what!)"
    scene cphlt113 with dissolve
    pause
    mc "Well honey when I'm not around you will stick with Zoey alright?"
    rb "Yes sir!"
    sy "Yes sir!"
    scene cphlt114 with dissolve
    pause
    mc "(Damn that feels awesome.)"
    scene cphlt113 with dissolve
    pause
    mc "Oh by the way, Ruby wants to swim so bad but she didn't bring any swimsuit."
    mc "Can you help her?"
    mc "(I'm pretty sure Ruby won't swim in this pool. Even if there's no one around, the fear that someone might come at any moment will keep her away from it.)"
    mc "(But I'm still waiting for a little miracle, maybe she'll start to throw off her shyness gradually)"
    sy "Of course mr. [mc] there is everything here"
    mc "Good, by the way, buy me a shorts too, is $100 enough?"
    scene cphlt114 with dissolve
    pause
    sy "Oh yeah thank you so much mr. [mc] but I'm kind of rich you know, so it is unnecessary."
    sy "You are just a teacher after all. I should buy her swimsuit too..."
    "Is this coming from her naiveness or she's just arrogant as the others..."
    mc "Sure Zoey. Whatever you like."
    sy "Okay, then we're going mr. [mc]!"
    mc "Okay, Ruby, don't forget anything I said."
    mc "Okay... What now?"
    scene cphlt116 with dissolve
    pause
    mc "Hey"
    "Oh hey, how can i help you?"
    menu:
        "Night club":
            scene cphlt116 with dissolve
            pause
            mc "I need information about the nightclub."
            rcp "It's a nightclub."
            mc "You are really weird."
            rcp "I'm sorry I don't understand."
            mc "Ugh... Where is this club?"
            rcp "Which club?"
            mc "Not which club, it's nightclub."
            rcp "..."
            mc "Oh c'mon that was funny."
            mc "...."
            mc "Nightclub"
            scene cphlt117 with dissolve
            pause
            rcp "follow that way."
            mc "Very specific."
            rcp "Is there anything else?"
            mc "No."
        "Cosplay event":
            scene cphlt116 with dissolve
            pause
            mc "What do you know about the cosplay event?"
            rcp "People dress up like the characters they like."
            mc "No no not like that..."
            mc "I'm talking about the event at the hotel."
            rcp "Oh right."
            rcp "People dress up as their favorite characters."
            mc "What is wrong with you girl..."
            rcp "Excuse me I don't understand you?"
            mc "Nothing. Have a nice day."
            rcp "You too."
        "Try to flirt with her":
            scene cphlt116 with dissolve
            pause
            mc "I'm wondering about something."
            mc "Why employees are not included in the cosplay concept?"
            rcp "Such a nice question!"
            mc "..."
            mc "What about an answer. I'm sure it will be nice too?"
            rcp "Oh right."
            rcp "I don't know."
            rcp "My superiors didn't require me to cosplay."
            mc "I see."
            mc "You're looking pretty good with this outfit by the way."
            rcp "Oh thanks."
            mc "Yeah..."
            mc "Would you like to have a drink with me sometime?"
            rcp "Thanks for asking. My answer is no."
            rcp "Is there anything else you want me to help with?"
            mc "No thanks."

    mc "(I will never ask that receptionist anything else.)"
    mc "(She scares me a little.)"
    mc "(Well it's early, girls are shopping. I  saw a nice bar earlier , let's roll few beer till night.)"
    scene cphlt118 with Fade(1.0, 2.0, 1.0)
    pause
    rb "Thank you for taking care of me."
    rb "Without my [pD14], I would be so alone."
    scene cphlt119 with dissolve
    pause
    sy "The truth is, I was lonely too, I didn't expect to meet someone on the same frequency with me."
    rb "Ehehe"
    scene cphlt120 with dissolve
    pause
    sy "So Ruby is your name huh?"
    sy "Sorry that was so awkward."
    scene cphlt121 with dissolve
    pause
    rb "Not to me..."
    scene cphlt122 with dissolve
    pause
    rb "Thank you so much by the way."
    rb "Your name is amazing as well, Zoey. What does it mean?"
    sy "I don't know, I never wondered."
    sy "Yours?"
    scene cphlt123 with dissolve
    pause
    rb "Same page club ehehe"
    rb "I just learned this, it's fun to say."
    sy "Yes, and it is perfect for you."
    rb "Aww thank you."
    sy "Well, has your [pD14] ever mentioned me?"
    scene cphlt124 with dissolve
    pause
    rb "Yes"
    sy "Really!"
    rb "Yup"
    sy "What did he say about me?"
    scene cphlt125 with dissolve
    pause
    rb "Oh..."
    rb "I thought I could lie, but when a question came about this lie, I was stunned."
    rb "No, he never mentioned you, I'm sorry..."
    scene cphlt123 with dissolve
    pause
    sy "Then why said yes?"
    rb "I felt like you need it, so... I'm sorry this is much worse."
    sy "Aahaha you're silly, Ruby."
    sy "Well of course it's kinda sad. But not a big deal, I have tons of time for that."
    rb "Oh okay."
    rb "So what are we doing then Zoey?"
    sy "We're getting in shape honey."
    sy "Oh sorry I said honey."
    scene cphlt125 with dissolve
    pause
    rb "Oh no I liked it!"
    sy "Hehe"
    rb "So shape me up because I don't know anything about shaping..."
    sy "Well I'm not an expert either. But the routine conversation of my classmates is usually about fashion, well, I learned the basics by listening to them."
    sy "Sorry I talked too much..."
    scene cphlt121 with dissolve
    pause
    rb "Why are you apologizing? You can talk much longer."
    rb "Even I dare you to talk as much as you can. I have no limit!"
    rb "I can listen you all day long!"
    sy "Oh my god you're so cute!"
    scene cphlt120 with dissolve
    pause
    sy "My teacher is really lucky to have a cute one like you."
    sy "Which brings to my mind the question, why is mr. [mc] always walking around with a cold face?"
    scene cphlt123 with dissolve
    pause
    rb "Ahaha yes he has such a bad temper"
    sy "And for some reason I feel like I'm around a wild animal that will attack me every time I see him"
    sy "Waow that was so weird sorry..."
    scene cphlt125 with dissolve
    pause
    rb "No no I guess you're right. He might look scary from the outside."
    rb "But actually he's a very perfect person."
    rb "He has been my hero for as long as I can remember."
    rb "..."
    rb "So what are we doing?"
    sy "We choose something for you."
    scene cphlt118 with dissolve
    pause
    rb "Yuppi I'm all yours."
    scene cphlt119 with dissolve
    pause
    sy "Oh really?"
    rb "Yup my [pD14] entrusted me to you, technically you are my [pD14] now."
    sy "Oh my I'm becoming an [pD14] for the first time in my life. It's a very strange feeling ahahah"
    sy "Well, then, if i'm the authority, you'll do everything I say, okay?"
    rb "Aye aye [pD14]!"
    sy "Wow that was fast, but I like it."
    sy "Follow me sweet [pD21], let's get you in some shape."
    scene cphlt126 with dissolve
    pause
    sy "Okay, I have some options for you, some of them are crazy, but I really want to see the results."
    rb "Crazy?"
    rb "How crazy actually?"
    sy "We will see."
    rb "Uhm..."
    scene cphlt127 with dissolve
    pause
    rb "Maybe we should just try normal things. I don't seem to have much of a mod for crazy things."
    sy "Did you just disobey your [pD14]?"
    scene cphlt128 with dissolve
    pause
    rb "Oh no how dare I!"
    sy "Good, let's try those!"
    scene cphlt126 with dissolve
    pause
    rb "You really love this role."
    sy "When you have a [pD21] like that, you love her whether you like it or not."
    rb "Ehehe, yes [pD14]!"
    scene cphlt129 with dissolve
    pause
    sy "Alright then, go in there."
    rb "How polite are you."
    sy "I'm really good at acting..."
    scene cphlt130 with dissolve
    pause
    sy "Is everything alright Ruby?"
    rb "Yeah..."
    sy "Then come out I'm so excited!"
    rb "Is there anyone out there?"
    sy "No just me. You can come out."
    scene cphlt131 with dissolve
    pause
    rb "Still not ready..."
    scene cphlt132 with dissolve
    pause
    rb "...."
    sy "I have an idea."
    scene cphlt133 with dissolve
    pause
    sy "Hi there."
    rb "Wait. What?"
    scene cphlt134 with dissolve
    pause
    rb "Uhmmm..."
    sy "....."
    scene cphlt135 with dissolve
    pause
    rb "So..."
    scene cphlt136 with dissolve
    pause
    sy "I don't know why I go inside."
    sy "I think I got caught up in my role."
    sy "Wow your skin is so pretty..."
    scene cphlt137 with dissolve
    pause
    rb "Oh it is?"
    sy "Well yeah a lot of girls at school are waiting ready to hate you just for this skin."
    rb "Why..."
    sy "Well..."
    sy "I don't know exactly either."
    sy "But this suits you perfectly."
    scene cphlt138 with dissolve
    pause
    rb "Okay then I'll pick this one!"
    sy "Oh no! We will try others too!"
    rb "Well if you say so [pD14]."
    rb "...."
    sy "....."
    sy "You know what? This is perfect. No need to try other options."
    rb "Oh yeah I totally agree!"
    rb "What about you? Aren't you going to buy something?"
    sy "No I have everything."
    sy "Let's pick a shorts for mr. [mc], and go shall we?"
    rb "Yeah..."
    scene cphlt139 with dissolve
    pause
    mc "Hmm more cosplayers"
    scene cphlt140 with dissolve
    pause
    csp1 "After last year's event, I thought we wouldn't go through anything like this again!"
    scene cphlt141 with dissolve
    pause
    csp1 "We should always be in the top 3!"
    scene cphlt142 with dissolve
    pause
    csp1 "We barely achieved this balance last year, and yet you went and chose a stupid cosplay again!"
    csp1 "Why do you hate me so much Jade? What did I do to you?"
    scene cphlt143 with dissolve
    pause
    csp4 "I'm just not okay with showing my skin a lot Iris!"
    scene cphlt144 with dissolve
    pause
    csp1 "You fucking idiot!"
    csp1 "I can't believe how stupid you can be!"
    csp1 "It's not even the slutty nun!"
    scene cphlt145 with dissolve
    pause
    csp4 "Please don't insult me when people are around..."
    scene cphlt141 with dissolve
    pause
    csp1 "Shut up!"
    csp1 "If we want to be in the top 3, we have to be the sexiest cosplayers possible. That's the only way!"
    scene cphlt143 with dissolve
    pause
    csp4 "The number of participants never exceeds 10. Does it really matter that we are in the top 3 in such a competition?"
    scene cphlt145 with dissolve
    pause
    csp4 "Besides, I'm not having fun anymore..."
    scene cphlt141 with dissolve
    pause
    csp1 "Because last year you stopped following my system you dumb slut!"
    csp1 "And I need to win this every year. You know what it means to me!"
    csp4 "Stop insulting me please..."
    scene cphlt142 with dissolve
    pause
    csp1 "Are you fucking crossing me?"
    csp1 "Be careful how you answer this or..."
    scene cphlt146 with dissolve
    pause
    mc "Or what?"
    mc "Are you gonna kill her? Beat her? Humiliate her?"
    scene cphlt147 with dissolve
    pause
    csp1 "Who the fuck are you? Fbi?"
    scene cphlt148 with dissolve
    pause
    mc "See? She can't do such things to you."
    mc "Her weapon is her mouth. If you stop listen, she will be defeated by you."
    csp1 "Excuse me!"
    mc "But yeah those kind of stand up things took time, but you should consider to begin."
    mc "Don't let her crush you anymore."
    scene cphlt149 with dissolve
    pause
    csp1 "I don't know who you are but congrats! You just get in my blacklist."
    mc "You mean your empty imaginary threat list?"
    mc "What did you do to your worst enemy in that list? I would like to hear?"
    scene cphlt150 with dissolve
    pause
    csp1 "Huh?"
    mc "You said you added me to your blacklist, I accept this list as your payback/revenge list."
    mc "What I was wondering is; have you been able to get revenge on anyone on this list? And if so, how?"
    scene cphlt151 with dissolve
    pause
    csp1 "I don't have to explain to you old garbage. Get the fuck out of my side!"
    scene cphlt152 with dissolve
    pause
    mc "See she can't answer because there is no blacklist or such things."
    mc "This is her weapon. It's like a robbery with a toy gun."
    mc "Am I right honey?"
    scene cphlt149 with dissolve
    pause
    csp1 "You have no idea how fucked you are!"
    scene cphlt153 with dissolve
    pause
    csp2 "Okay, stop answer to him Iris."
    scene cphlt154 with dissolve
    pause
    csp1 "Why, I don't wanna!"
    csp2 "Yes, you want."
    scene cphlt155 with dissolve
    pause
    csp2 "And you sir, you should be more careful."
    csp2 "You can make assumptions for people you don't know, but are you 100 percent sure that this list is a lie?"
    mc "(Who is this girl? Her voice is weird, made me little uncomfortable.)"
    mc "(And the fact that she speaks so calmly makes her look much more mature.)"
    mc "(I can't suppress my desire to take her seriously despite the age difference between us...)"
    mc "(I kinda like her.)"
    mc "What a weird group you have?"
    mc "Do whatever you like. But be careful, she seems like naive but this is how serial killers are born."
    scene cphlt156 with dissolve
    pause
    csp1 "You're not going to turn into a serial killer and hunt me down, are you?"
    scene cphlt157 with dissolve
    pause
    csp4 "What?! Of course no."
    scene cphlt158 with dissolve
    pause
    csp1 "Oh wait!"
    scene cphlt159 with dissolve
    pause
    csp1 "Who the fuck is this guy anyway? I didn't see him before."
    csp1 "Who is your cosplay partner asshole?"
    mc "Heh you will learn soon."
    scene cphlt160 with dissolve
    pause
    csp1 "*whispers*"
    mc "(Okay [mc] what the fuck was that!?)"
    mc "(I lost control and acted like a child...)"
    mc "(Maybe I became too much younger after all...)"
    mc "(Also I didn't know about the competition. Why Ruby lied to me about this?)"
    mc "(They must still be shopping. I can go to my room, there's nothing to do around here.)"
    scene cphlt161 with dissolve
    pause
    csp3 "Who was that guy? He was so cute."
    csp1 "No he was not!"

    scene cphlt161v2 with fade
    pause
    play sound "audio/knock.mp3"
    mc "Ahh just give me a break..."
    scene cphlt162 with dissolve
    pause
    csp2 "..."
    mc "(Hmm)"
    mc "(Probably assassination...)"
    mc "Hey you are..."
    mc "What was your name?"
    mc "Can you hear me?"
    mc "I don't know this character. Is she deaf or something?"
    mc "If so, you would also be silent when you were by the pool."
    mc "What do you want?"
    scene cphlt163 with dissolve
    pause
    mc "Alright freak I'll keep up with."
    scene cphlt167 with dissolve
    pause
    scene cphlt168 with dissolve
    pause
    scene cphlt169 with dissolve
    pause
    mc "I like where this goes."
    scene cphlt170 with dissolve
    pause
    mc "You little dirty whore... no panties huh?"
    scene cphlt171 with dissolve
    pause
    mc "Oh you like the way I talk?"
    mc "Keep going."
    scene cphlt172 with dissolve
    pause
    scene cphlt173 with dissolve
    pause
    mc "Oh yes honey crawl to me."
    mc "Looking tough must be at odds with your personality."
    scene cphlt174 with dissolve
    pause
    mc "What happened earlier must have excited you."
    mc "Just a little girl acting tough, but actually an obedient slut."
    mc "My favorite."
    scene cphlt175 with dissolve
    pause
    mc "Okay, enough teasing."
    mc "Time for action."
    scene cphlt176 with dissolve
    pause
    scene cphlt177 with dissolve
    pause
    mc "Hm?"
    mc "What is this..."
    scene cphlt178 with dissolve
    pause
    mc "Is this the farthest you can go or?"
    mc "You can't give me blue balls and go!"
    mc "(Wait wait wait...)"
    mc "(I think this blacklist nonsense is real.)"
    mc "(This is fishing [mc]...)"
    mc "(Fucking smart brats...)"
    mc "Actually, you can go."
    mc "I just realized my dick isn't that hard."
    scene cphlt179 with dissolve
    pause
    mc "By the way, I will see you in competition."
    mc "Number 2 was it?"
    mc "Was fun kiddo."
    mc "See you later"
    scene cphlt180 with dissolve
    pause
    mc "Okay...."
    mc "I have blue balls and my dick is still hard... Fucking amazing!"
    mc "I don't wanna fap alone. It's not my thing..."
    mc "Well I should rest a bit now."
    mc "I'm sure Zoey's taking care of Ruby."
    play sound "audio/ringtone-sound-effect.mp3"
    pause
    mc "Yes"
    stop sound
    scene tlph1 with dissolve
    pause
    d3 "Hey [pD8]."
    mc "This is surprising."
    d3 "We were curious about you. They chose me as the messenger."
    d3 "Don't get cocky."
    mc "Mhm hm"
    mc "What are you guys doing without the man of the house?"
    scene tlph2 with dissolve
    pause
    d3 "We're doing pretty good, duh."
    mc "Seems suspicious..."
    d3 "Turn your [pD13] sense off [pD8], everything's okay."
    scene tlph3 with dissolve
    pause
    d1 "[pD28]!!!!"
    d2 "I have fully control on everything. Jealous?"
    d1 "[pD28]...."
    scene tlph4 with dissolve
    pause
    d1 "[pD28]!!!"
    d3 "[pD8] wait I'm going to my room."
    d3 "Nora can you help please?"
    d2 "There's only one person who needs help, and he's not here."
    mc "Haah good one Nora."
    d1 "I want to speak with [pD28]!!"
    d3 "Hold on."
    mc "Huh"
    scene tlph5 with dissolve
    pause
    d3 "Okay, I'm in a safe place."
    d3 "Now we can talk."
    mc "I realized that I miss you already."
    scene tlph6 with dissolve
    pause
    d3 "..."
    d3 "*whisper* Then come earlier...."
    mc "What was that honey?"
    scene tlph7 with dissolve
    pause
    d3 "Nothing I'm out."
    mc "(Heh she became the cutest thing ever)"
    mc "(That actually makes me more horny...)"
    mc "(Maybe I should...)"
    mc "Wait"
    scene tlph8 with dissolve
    pause
    menu:
        "Try to [pD84] while talking":
            if persistent.patch_installed == True:
                jump v04_d
        "Hang up and rest":
            scene cphlt180 with dissolve
            pause
            mc "Nah, I should get some rest..."
            scene gsgr01 with dissolve
            pause
            mc "Damn, I slept until morning..."
            scene gsgr02 with dissolve
            pause
            mc "Oh Ruby"
            mc "Yeah..."
            scene gsgr03 with dissolve
            pause
            mc "For a moment I forgot there was only one bed."
            mc "Thank God she didn't decide to sleep on the couch."
            scene gsgr02 with dissolve
            pause
            mc "Not that shy anymore huh?"
            mc "Look at you."
            mc "And your cute little nipples"
            mc "The best way to wake."
            mc "Damn you're amazing when you're sleeping."
            scene gsgr04 with dissolve
            pause
            mc "All right..."
            jump v04_e
label v04_e:
    play sound "audio/knock.mp3"
    scene gsgr01 with dissolve
    pause
    mc "Hm"
    scene gsgr02 with dissolve
    pause
    mc "No need for housekeeping."
    gth1 "Hey, can you open it for a second?"
    mc "(And my angel is here.)"
    mc "(Damn it feels amazing.)"
    mc "(Waking up in the same bed with her.)"
    mc "(She is wearing cute pajamas.)"
    mc "(And i'm naked...)"
    mc "(Oh fuck!)"
    mc "(What the fuck?!)"
    scene gsgr04 with dissolve
    pause
    mc "(Did I sleep like this?!)"
    mc "(I remember passing out after the phone call.)"
    mc "(But she slept next to me, did she see my dick...)"
    mc "(But she's lying here, so she came and slept without noticing?)"
    mc "(Lucky me I guess.)"
    mc "(Or unlucky?)"
    mc "(Wait someone was at the door.)"
    scene gsgr03 with dissolve
    pause
    mc "Are you still there?"
    gth1 "Yes!"
    mc "Coming."
    scene gsgr1 with dissolve
    pause
    mc "Is everything okay?"
    gth1 "Yeah I just..."
    mc "What?"
    gth1 "Can I hate my dad a little here too?"
    mc "Huh?"
    mc "I don't get it."
    scene gsgr2 with dissolve
    pause
    gth1 "..."
    gth1 "I feel terrible and I think I can put up with your presence for a while..."
    mc "Well first one was better."
    scene gsgr4 with dissolve
    pause
    gth1 "Oh oh look!"
    gth1 "I found the redhead you were talking about yesterday!"
    mc "Oh wow really?"
    gth1 "It was a funny joke..."
    mc "Meh"
    scene gsgr5 with dissolve
    pause
    gth1 "She is cute and pretty."
    gth1 "Who is she?"
    scene gsgr6 with dissolve
    pause
    mc "My cosplay partner."
    scene gsgr7 with dissolve
    pause
    gth1 "Cool."
    gth1 "Well that's a relief."
    mc "What do you mean?"
    scene gsgr8 with dissolve
    pause
    gth1 "Wanna spend time with me or not?"
    mc "Umm sure, what you wanna do?"
    if persistent.patch_installed == True:
        jump v04_f
    else:
        jump v04_g
label v04_g:
    mc "Are you hungry?"
    gth1 "Yeah I guess so."
    mc "Cool let's go."
    gth1 "Oh okay, but I want to go to my room first."
    gth1 "I'll meet you there."
    scene ltepd1 with dissolve
    pause
    mc "(Oh Zoey is here.)"
    scene ltepd2 with dissolve
    pause
    mc "(With a much bolder...Cosplay?)"
    mc "(Nah must be normal outift)"
    mc "(But still)"
    mc "(This one is so much better.)"
    mc "(Girls should be cute, hot and sexy, it's so wrong for them to try to act cool...)"
    mc "(Let's approach her.)"
    scene ltepd3 with dissolve
    pause
    mc "(But hello...)"
    mc "(Nice ass)"
    mc "(I wanna spank that ass so hard!)"
    scene ltepd4 with dissolve
    pause
    sy "Oh mr. [mc]!"
    sy "What a coincidence!"
    mc "Yeah we met again in a restricted area."
    sy "Ahaha you're funny"
    scene ltepd5 with dissolve
    pause
    sy "Won't you join me?"
    mc "Sure."
    mc "(She still hasn't come, I think she was embarrassed and gave up.)"
    mc "(Well... understandable.)"
    scene ltepd6 with dissolve
    pause
    mc "What you doing here, sleeping?"
    sy "No, I just think better with closed eyes."
    scene ltepd7 with dissolve
    pause
    mc "Hm"
    sy "But it is so good that I ran into you."
    mc "Why is that?"
    scene ltepd8 with dissolve
    pause
    sy "I have some problems..."
    mc "What are they?"
    sy "I talked to my dad a short time ago."
    scene ltepd9 with dissolve
    pause
    sy "I won't go into details and bore you, in a nutshell, this is my last adventure."
    sy "I think we're really getting poorer."
    mc "(Maybe one day i'll buy your swimsuit"
    mc "(Good one [mc].)"
    mc "This must be terrible."
    mc "What about school?"
    mc "Are you going to leave school too?"
    sy "No, I'm entrusted to you until I graduate."
    scene ltepd10 with dissolve
    pause
    sy "Anyway..."
    sy "This is my last cosplay contest, and I want to win."
    mc "Well that's the spirit."
    sy "Yeah but it's pretty impossible."
    mc "Why?"
    sy "I have a very good idea to win, but unfortunately I don't have a partner."
    mc "(I know where it goes...)"
    mc "Hmm"
    mc "Well this is a really bad situation for me."
    mc "I need to do this with Ruby."
    scene ltepd11 with dissolve
    pause
    sy "Of course mr. [mc] she is your [pD29]."
    sy "I'm sure she can win this thing not just once, but every year."
    sy "Because you are that kind of man."
    sy "I just wanted to try my luck."
    scene ltepd12 with dissolve
    pause
    mc "(Oh c'mon!)"
    menu:
        "Go with Zoey":
            $v04McWentZoey = True
            scene ltepd12 with dissolve
            pause
            mc "Is there no one else? Am I really your only choice for the theme you have chosen?"
            scene ltepd13 with dissolve
            pause
            sy "Yeah..."
            sy "When I first saw you here, I was so happy that..."
            scene ltepd14 with dissolve
            pause
            sy "I felt like you sensed that I needed help and came for me.)"
            mc "(Ruby is a good girl. She will understand this, but still...)"
            mc "(Deep down, my choice would always be Ruby)"
            mc "(But this will be like taking the first serious step for my students.)"
            mc "(After all, that was my latest ultimate goal.)"
            mc "(Fuck!)"
            mc "Okay Zoey I'm in."
            scene ltepd15 with dissolve
            pause
            sy "No way really?"
            mc "Yeah really."
            sy "Are you really choosing me over your [pD29]?"
            mc "(Dude...)"
            mc "Yeah..."
            scene ltepd16 with dissolve
            pause
            sy "Oh my god thank you mr. [mc]. Thank you! Thank you!"
            mc "You're welcome Zoey."
            mc "What we gonna do?"
            sy "Meet me in my room tonight I'm gonna buy your costume first."
            mc "Without me?"
            scene ltepd17 with dissolve
            pause
            sy "I know your size mr. [mc], go spend time with Ruby."
            mc "(What is your deal Zoey...)"
        "Go with Ruby":
            $v04McWentRuby = True
            scene ltepd6 with dissolve
            pause
            mc "I really wanna help Zoey but..."
            scene ltepd8 with dissolve
            pause
            sy "Yeah I get it. She is family."
            mc "Not just that, I believe she needs me much more than you."
            scene ltepd9 with dissolve
            pause
            sy "Oh, you think so?"
            mc "Yeah."
            scene ltepd10 with dissolve
            pause
            sy "Lucky girl..."
            mc "Sorry."
            scene ltepd13 with dissolve
            pause
            sy "Well thanks anyway."
            sy "See you around mr. [mc]."
            mc "Yeah, you too."
            mc "(That went bad...)"
    #$config.allow_skipping = False
    #"End of v0.4. Don't forget to save the game."
    #"Thanks for playing!"
    if v04McWentRuby == True:
        jump v05a
    elif v04McWentZoey == True:
        jump v05b
    #end of the update
