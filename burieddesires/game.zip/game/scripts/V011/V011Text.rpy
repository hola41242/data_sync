default v011mcLiedAmy = False
default v011mcLiedJanet = False
default v011mcKnowsEmmaGrades = False
default v011mcTookEmmaPass = False
default v011mcCheckedEmmaPhone = False
default v011mcWentChristian = False
default v011mcKnowsChloesDream = False
default v011mcOkayWithThis = False
default v011mcNotOkayWithThis = False
default v011mcInterfereEmma = False
default v011mcGabyNotNow = False
default v011mcGabyPolitely = False
default v011mcGabyMeet = False
label v011Start:
    scene otoex1 with fade
    mc "I'm not even sure how I feel right now."
    scene otoex2 with dissolve
    menu:
        "I am afraid":
            mc "Am I taking on too much responsibility{w}, this is scary.."
            mc "I have no doubt that what the therapist says still makes sense."
            mc "But it's still going to bother me to cross that border."
            mc "How much can I trust someone who tells me to do this?"
            mc "Charlotte...{w}, as much as she needs me, she can sell me out without hesitation."
            mc "I should have a card up my sleeve"
            mc "Otherwise, it's too risky."
            mc "Maybe I'm overreacting, maybe this is normal?.."
            mc "Ah..{w} Fuck.."
        "I'm not afraid.":
            mc "Who am I kidding? My past is an insult to my true personality"
            mc "I've always deserved so much better,{w} but I've always condemned myself to the least"
            mc "Being afraid doesn't suit me, I'm qualified to protect both my family and myself."
            mc "Charlotte...{w}, as much as she needs me, she can sell me out without hesitation."
            mc "I should have a card up my sleeve"
            mc "Otherwise, it's too risky."
    mc "I can't wait to go home and tell everyone the good news"
    mc "After a short celebration, I will carefully examine this list"
    scene otoex3 with dissolve
    mc "Huh..."
    mc "I'd know that look anywhere."
    mc "Is he Charlotte's man?.."
    mc "You're not scaring anyone, asshole."
    menu:
        "rear-view mirror":
            scene otoex4 with dissolve
            mc "Pfft seriously.."
            mc "This is so cliche"
            mc "Uuuugh I'm so scared.."
            mc "Child's play"
    scene otoex5 with dissolve
    scene otoex6 with dissolve
    "...."
    "Hey, why are you standing in the middle of the road{w}, shouldn't you be waiting in the car?"
    "I'm sorry, ma'am, something caught my attention."
    "Oh, something that'll get even your attention, huh?"
    "No... {w}Just a feeling"
    "Whatever"
    "Let's go. I can't miss my meeting."
    "Yes ma'am"
    scene hmeback1 with fade
    mc "Home sweet"
    mc "ALABAMAAA" with vpunch
    mc "Hehe.."
    mc "I'm in a good mood"
    scene hmeback2 with dissolve
    pause
    scene hmeback3 with dissolve
    mc "Oh [pD7]{w} you came"
    scene hmeback4 with dissolve
    ss "Thank you for making me feel welcome."
    ss "Don't you have a hug for your little [pD7]?"
    menu:
        "Hug":
            scene hmeback5 with dissolve
            $amy_l_points +=1
            play sound "audio/notify.mp3"
            show screen lovePoint
            mc "Come over here!"
            ss "Oh is this a fatality huh!"
            mc "Shut up nerd"
            ss "I've really missed you a lot [mc].."
            mc "Me too [pD7].."
        "Tease":
            $amy_d_points +=1
            show screen dominancePoint
            play sound "audio/notify.mp3"
            scene hmeback4 with dissolve
            mc "Little??"
            scene hmeback7  with dissolve
            ss "Don't you dare!"
            mc "Or what"
            ss "Or what huh.."
            ss "Are you sure you want me to remind you again?"
            scene hmeback6 with dissolve
            ss "Because the last time, things didn't go well for you."
            mc "Weak..."
            mc "So weak [pD7], you were better than this."
            mc "Or were you just good at my memories?"
            ss "Oh it's on!"
            mc "Yeah it's on"
            mc "Remember our first footrace?"
            ss "That doesn't count!"
            mc "Oh yeah, you were 3 seconds behind me!"
            ss "Laaame , you cheated."
            mc "Uh huh, I broke the rules by moving my legs faster, you're right."
            ss "Oh shut up!"
            ss "Let me remind you that I've never lost to you in wrestling."
            mc "Oh about that.."
            mc "I've always let you win."
            ss "Oh c'mon, why would you do something like this"
            mc "I just wanted you to know how it feels when you win."
            ss "Lieeee! Because you can't beat meeee!"
            mc "No!"
            scene hmeback8 with dissolve
            d1 "HEY!"
            scene hmeback9 with dissolve
            d1 "Do I hear a fight in the house, or do my ears mislead me?!"
            ss "Shit..."
            mc "No, honey, we're just joking."
            d1 "Good"
            scene hmeback10 with dissolve
            ss "She still hates negative energy huh"
            mc "You have no idea.."
            mc "The other day, we were watching a show on TV, and there was a guy screaming all the time."
            mc "Claire hurried to her room."
            mc "She found the name of that screaming man and e-mailed him."
            ss "No way, What e-mail did she write?"
            mc "Being so nervous can hurt you and those around you"
            mc "Please laugh instead of shout."
            ss "Oh man that's nuts!"
            mc "Yeah, but she's not doing it to be funny."
            ss "That's why she's unique."
            mc "Exactly.."
    mc "I passed the final boss, now where's my reward!"
    scene hmeback11 with dissolve
    ss "Haa haa so funny"
    scene hmeback12 with dissolve
    ss "Ruby, come and say hello to your [pD14]."
    scene rubyintro020
    $ renpy.movie_cutscene("animation/v011/rubyintro.webm")
    pause
    scene hmeback13 with dissolve
    rb "[pD14]!"
    scene hmeback14 with dissolve
    pause
    scene hmeback15 with dissolve
    mc "Hey there my little angel"
    scene hmeback16 with dissolve
    rb "I've missed you very much!"
    mc "Yeah I can feel that"
    rb "You haven't changed.."
    mc "Should I be happy or sad about it?"
    rb "Of course you should be happy,{w} you are the best!"
    mc "That's me"
    scene hmeback17 with dissolve
    mc "So where is the troublemaker?"
    scene hmeback18 with dissolve
    d3 "Oh get off my back [pD8]"
    mc "I'm not talking about you, honey."
    scene hmeback19 with dissolve
    d3 "You better not be!"
    mc "Manners!"
    scene hmeback20 with dissolve
    mc "So...{w} Luna?"
    ss "Uhmm.."
    ss "Luna couldn't come"
    mc "Is everything okay?"
    scene hmeback21 with dissolve
    ss "Yeah, you know Luna, she does what she wants to do, I couldn't convince her to come."
    mc "I guess she didn't miss me very much."
    ss "It's not that"
    ss "She's so reckless these days."
    mc "I guess she couldn't handle the divorce."
    ss "I don't think so, after all, she hated him."
    ss "I don't really know what to do with this girl"
    ss "I just hope she'll settle down one day"
    mc "C'mon [pD7] she has a strong [pD32] like you"
    mc "She doesn't stand a chance"
    mc "You just have to understand her."
    scene hmeback22 with dissolve
    ss "Did something like this happen to you? "
    scene hmeback23 with dissolve
    mc "Nope, all my [pD5] are like angels. They're not causing any trouble..."
    ss "She's looking at you right now, isn't she?.."
    mc "Sshh be cool.."
    scene hmeback21 with dissolve
    ss "You're not really bringing work home [mc].."
    mc "Huh?"
    ss "I mean, you're a teacher, you have absolute discipline at work"
    ss "and you fail so much at home."
    mc "Wow thank you for saying so clearly [pD7] I almost didn't understand.."
    mc "But you're right, when it comes to my [pD5], that part of me disappears"
    ss "Yeah, but don't spoil them too much. They'll eat you alive!"
    ss "Especially Emma."
    mc "I wonder why"
    ss "Dunno"
    mc "Seriously?"
    ss "What"
    mc "She's the spitting image of you"
    ss "What? Emma?"
    mc "Yes, ambitious, combative and rebellious, just like you."
    mc "Hates to lose."
    mc "Even though she keeps losing"
    mc "See, a carbon copy"
    scene hmeback25 with dissolve
    ss "Aahaaa, I see now"
    ss "You made a mini-me to beat"
    ss "This is so pathetic"
    mc "Seriously [pD7]"
    mc "This is just sad..."
    ss "You know what? Let's do it!"
    mc "Lets do what?"
    ss "We'll wrestle."
    mc "Whaat"
    ss "Are you scared?"
    ss "If you can beat me in wrestling, I'll accept your superiority."
    mc "We're not kids anymore [pD7]"
    ss "Haa haa, coward"
    mc "Not gonna work"
    ss "Then accept it"
    mc "No"
    ss "You are the worst"
    scene hmeback24 with dissolve
    mc "By the way, about Luna.."
    mc "Don't worry, [pD17], I'll take care of it."
    mc "You no longer have to worry"
    ss "I can take care of myself"
    mc "I know, and I respect that"
    mc "I'm your [pD15]. Let me"
    mc "You deserve a real man."
    ss "A real man huh"
    ss "...."
    ss "We'll talk about this later."
    mc "Sure baby [pD7]"
    scene hmeback25 with dissolve
    ss "Gee..,{w} don't call me that it's embarrassing."
    mc "Ehehe"
    mc "Awww this took me back to the good old days."
    mc "The days when you were too cute"
    ss "Ahaha what days are those?"
    mc "When you hadn't learned to speak yet"
    mc "You were so cute back then."
    ss "Oh you!"
    mc "Just kidding [pD7]"
    stop music fadeout 3.0
    scene hmeback25 with dissolve
    mc "Let's eat now, I'm really hungry"
    scene hmeback26 with dissolve
    mc "Ruby, call the girls, honey."
    rb "Aye aye [pD14]!"
    scene hmeback27 with fade
    play music "audio/dinner.mp3"
    mc "Look at this, like a big family!"
    mc "I feel like a king today"
    scene hmeback28 with dissolve
    wf "You've always been the king of this house, darling."
    scene hmeback29 with dissolve
    ss "Awwww"
    ss "This is so gross."
    d3 "Haa haa"
    wf "Oh shut up"
    scene hmeback27 with dissolve
    $v011cS0_0 = False
    $v011cS0_1 = False
    $v011cS0_2 = False
    $v011cS0_3 = False
    $v011cS0_4 = False
    $v011cS0_5 = False
    menu v011cS0:
        "Janet" if not v011cS0_0:
            scene hmeback28 with dissolve
            mc "So, what did you do today?"
            wf "Nothing special, coffee, shopping, gossip"
            mc "Thanks to god for creating man to bring joy to the world!"
            scene hmeback30 with dissolve
            ss "Said the man who don't even have one male friend."
            wf "This is actually a good point"
            wf "Honey why don't you have any male friends?"
            scene hmeback28 with dissolve
            mc "I don't have any female friends either."
            mc "I have colleagues"
            ss "Uh huh, they don't count."
            mc "....."
            wf "Even in college, he was a lone wolf.."
            scene hmeback34 with dissolve
            d3 "Haahaa [pD16] is a weirdo"
            scene hmeback28 with dissolve
            mc "Who needs friends?{w} I have you"
            scene hmeback29 with dissolve
            ss "Aww this is so gross too, you're on fire today [pD11]"
            scene hmeback30 with dissolve
            ss "But seriously, I don't remember him having any friends either."
            scene hmeback34 with dissolve
            d3 "Told you he is a weirdo"
            mc "Sweety if you keep talking like that, you'll have no friends too."
            scene hmeback40 with dissolve
            d3 "Whatever"
            wf "So honey, everyone is wondering the same thing"
            d3 "I already told [pD10]"
            mc "Shut Up, Emma, you're the weird one, not me!"
            d3 "Sure buddy"
            scene hmeback32 with dissolve
            d1 "Hey!"
            d1 "Don't push [pD16]"
            d1 "Obviously, because of his love for me, he can't devote time to anyone else."
            scene hmeback33 with dissolve
            d2 "This is very illogical."
            d2 "He was like this before you were born."
            scene hmeback32 with dissolve
            d1 "Because he felt I was going to be born!"
            d2 "Damn! This is so wise"
            d1 "Thank you Nora"
            scene hmeback28 with dissolve
            mc "People!"
            mc "Can we talk about something else?"
            ss "Yes please."
            wf "Fine by me, too"
            mc "Huh this was easy.."
            $v011cS0_0 = True
            jump v011cS0
        "Amy" if not v011cS0_1:
            scene hmeback28 with dissolve
            mc "So, are you staying?"
            scene hmeback30 with dissolve
            ss "Nope"
            if v01AmyPhone:
                mc "Have you thought about moving?"
                if v01AmyisIknow:
                    ss "Ehh.. You were so bossy on the phone so I didn't even think about it."
                else:
                    scene hmeback31 with dissolve
                    ss "Janet and I talked about it a little bit,"
                    ss "but still I'm not too sure. I don't want to bother you."
            else:
                mc "Why don't you move in with us?"

            scene hmeback32 with dissolve
            d1 "Please stay with us [pD17] please pleasee!"
            scene hmeback33 with dissolve
            d2 "Yeah that would be good"
            scene hmeback34 with dissolve
            d3 "Why not, I think it is a good idea."
            scene hmeback30 with dissolve
            wf "See, everybody wants it."
            ss "You guys are the best, but still I need to talk to Luna first..."
            mc "I can convince her."
            ss "Huh good luck with that"
            scene hmeback31 with dissolve
            mc "I know it's a big decision, but you have no choice."
            ss "Actually I do have one choice."
            mc "No, I know what you're thinking, and I certainly don't approve of it."
            wf "What's that?"
            scene hmeback28 with dissolve
            mc "You're thinking about moving back in with [pD18] parents, right?"
            wf "Why don't you approve of it?"
            wf "I know I don't know them as well as you do. But I don't think they're bad people"
            mc "They're not bad,{w} just different"
            ss "Yeah..."
            mc "They don't believe in the concept of family."
            mc "I don't think they even like [pD33] very much."
            wf "Then why did they want to have children?"
            ss "Can we not talk about this?"
            menu:
                "Talk":
                    scene hmeback31sd with dissolve
                    play sound "audio/notify.mp3"
                    show screen dominancePoint
                    $amy_d_points +=1
                    if persistent.patch_installed==True:
                        jump pAmy
                    else:
                        mc "Have you forgotten, Amy? We're friends, and friends don't keep secrets."
                        ss "I know, but..."
                        mc "Do you remember what your parents did for a living?"
                        wf "I think they were working for a company?"
                        mc "It was their company."
                        d3 "No way!"
                        d3 "Then why aren't we rich?"
                        mc "Because, young lady, we don't want any more than we need."
                        d3 "Oh fuck.."
                        mc "Anyway, [pD20] family was too obsessed with money and power."
                        ss "They still are..."
                        mc "They got married at a very young age and established a company"
                        mc "They don't trust anyone but themselves"
                        mc "That's why they decided to have children."
                        mc "They wanted a son to take over the company."
                        mc "So Amy's birth was not useful for them."
                        mc "They started educating her for business when she was little."
                        mc "In the early years they taught maths, english, etc.,"
                        mc "but at the end, they began to teach the ugly side of the business world."
                        mc "I won't talk this openly because I don't want Claire having nightmares tonight."
                        mc "Amy couldn't stand it of course, who teaches a child such things?"
                        ss "Enough!"
                        menu:
                            "Stop":
                                scene hmeback31sd with dissolve
                                mc "Anyway, as a result, her family is not like other families"
                                mc "It would be the worst thing that could happen if Amy moved in with them."
                                wf "Yes.."
                            "Don't stop":
                                scene hmeback31sd with dissolve
                                play sound "audio/notify.mp3"
                                show screen dominancePoint
                                $amy_d_points +=1
                                $amy_r_points -=1
                                $renpy.notify("You made Amy so upset.")
                                mc "I hated them because they corrupted her mind as a kid"
                                mc "Then as her best friend they offered me something.."
                                ss "I've never dared to ask you before, what did they want from you?"
                                menu:
                                    "Not now":
                                        mc "this is not the time nor the place"
                                    "Don't tell it":
                                        mc "Believe me, you don't want to know about it."
                                mc "They couldn't handle the fact that Amy failed"
                                mc "They began to see her as failed projects, and after that, she was raised by nannies.."
                                wf "Is that why you both wanted to get married at a young age?"
                                ss "Yeah, but [mc] was lucky, he fell in love with the right woman"
                                ss "But I have two perfect [pD34]!"
                                wf "I'm sorry.."
                                ss "Don't be"
                "Don't talk":
                    scene hmeback28 with dissolve
                    play sound "audio/notify.mp3"
                    show screen lovePoint
                    $amy_l_points +=1
                    mc "Well, if you don't want.."
                    mc "Maybe we'll talk about it later."
                    wf "Okay, sorry for asking"
                    mc "It's ok honey"
            $v011cS0_1 = True
            jump v011cS0
        "Ruby" if not v011cS0_2:
            scene hmeback35 with dissolve
            mc "Ruby, how's school?"
            rb "Boring.."
            mc "Because you don't have a cool teacher like me"
            scene hmeback36 with dissolve
            d3 "Hah! Dream on [pD8]"
            d1 "I wish you were at my school...."
            rb "Our teachers are very strict. They don't care about us.."
            rb "They're not friendly at all."
            d3 "Girlfriend, you're not missing anything."
            d1 "Emma! Stop that.."
            d3 "Okay okay gee..."
            mc "How are things with Luna?"
            scene hmeback35 with dissolve
            rb "Not so good, we used to hang out all the time."
            rb "I don't see her around here anymore."
            rb "She's got new friends, and I guess she's ashamed of me."
            mc "Don't be ridiculous, of course, she's not ashamed of you,"
            mc "in fact, Luna's reaction is perfectly normal"
            mc "It's a phase she has to go through,"
            mc "if you think it's always gonna be like this from now on, you're wrong."
            rb "Thank you [pD14].."
            rb "You always find a way to make me happy"
            mc "Anything for my beautiful [pD21]"
            mc "You had a very close friend, how are things with her?"
            scene hmebackruby1 with dissolve
            rb "Good.. We're having fun"
            mc "Hmm, she doesn't pay as much attention to you as she used to?"
            rb "how did you know?"
            mc "C'mon Ruby, did you think you could lie to me?"
            rb "As if everyone changes suddenly, I can't keep up"
            rb "After all, I'm always alone"
            mc "You have me"
            rb "That's hard to believe that...."
            mc "Oh.."
            mc "I'll prove it to you. I promise."
            rb "You're gonna have to spend a lot of time with me. So be prepared."
            mc "Sush, don't let them hear, or the girls will be jealous.."
            rb "I love you [pD14]"
            mc "I love you too honey"
            rb "..."
            menu:
                "Give your hand":
                    scene hmebackruby2 with dissolve
                    $ruby_r_points +=1
                    rb "I'm very special to you, aren't I?"
                    mc "Of course honey"
                    rb "I'm so happy right now"
                    rb "And I'm not sure I can hide it"
                    rb "Can I hug you [pD14]?"
                    mc "I'll give a big and tight hug later, deal?"
                    rb "Yeey!"
                    rb "Your hands are so strong, so reassuring, it feels great..."
                    mc "Baby, girls will hear.."
                    rb "Oh yeah you're right."
                "Don't":
                    pause
            $v011cS0_2 = True
            jump v011cS0
        "Claire" if not v011cS0_3:
            scene hmeback37 with dissolve
            mc "So Claire how was your day?"
            d1 "Uhmmm nothing unusual [pD13].."
            mc "Uh huh..."
            scene hmeback42 with dissolve
            wf "Is everything okay sweety?"
            d1 "Yeah yeah, dinner's a little hot..."
            wf "You still burn your tongue with food, Claire."
            $v011cS0_3 = True
            jump v011cS0
        "Emma" if not v011cS0_4:
            scene hmeback40 with dissolve
            mc "Aren't you and Luna close, Emma?"
            mc "At least she could come to see you."
            d3 "Yeah she is bussy"
            mc "With what?"
            d3 "With stuff, you know"
            mc "No I don't"
            d3 "Yeah exaclty"
            mc "One day I will spank you in front of everyone!"
            d1 "Hey! I hate the negative energy! Please stop"
            $v011cS0_4 = True
            jump v011cS0
        "Nora" if not v011cS0_5:
            scene hmeback39 with dissolve
            mc "Nora, what did you and Emma do yesterday? Is it done?"
            d3 "Yes [pD8]"
            mc "I asked Nora."
            d3 "And I answered for Nora."
            mc "That was exactly my point."
            d3 "We're good then?"
            mc "Yeah"
            mc "Wait no!"
            wf "Not again, stop fighting and eat!"
            $v011cS0_5 = True
            jump v011cS0
    scene hmeback41 with dissolve
    mc "Anyway, I have good news."
    mc "I got the job"
    wf "Oh honey this is amazing"
    d1 "That's my [pD13]!"
    d2 "Good, we won't starve"
    ss "Congratulations [pD11]"
    rb "Yaay [pD14]!"
    d3 "Pity. I feel sorry for those at school..."
    mc "Yeah thank you all"
    mc "They offered me good money."
    mc "We can move to a new house soon!"
    mc "To a bigger house"
    ss "...."
    scene hmeback42 with dissolve
    d1 "But I love this house.."
    scene hmeback39 with dissolve
    d2 "What you love is the memories you've collected in this house, Claire."
    d2 "You can continue to do this in the new house."
    scene hmeback40 with dissolve
    d3 "Nora's right, and we'll finally live in a better house..."
    scene hmeback41 with dissolve
    mc "Girls, go to your rooms, the elders will talk about important issues"
    stop music
    play music "audio/bensound-tenderness.mp3" fadein 3.0
    scene hmeback43 with dissolve
    d3 "It's like you're literally begging me to stay here."
    menu:
        "Now Emma!":
            $emma_d_points +=1
            play sound "audio/notify.mp3"
            show screen dominancePoint
            mc "Now Emma!"
            mc "I'm serious, go go go"
            d3 "Ugh whatever old man"
            mc "I'm not old!"
            d2 "Actually..."
            mc "I said I'm not!"
            d1 "Of course [pD13], love you"
        "It's your funeral.":
            mc "Oh okay then, please join us and talk about real estate and financial things for hours."
            d3 "Oh hell no"
            mc "Hehe"
            ss "Nice one"
    scene hmeback44 with dissolve
    wf "We could talk in front of the girls, everything is okay, right?"
    menu:
        "partial truth":
            $mc_good_points += 1
            scene hmeback45 with dissolve
            mc "Nope.."
            ss "How so?"
            mc "Girls, I've been offered a great deal of money"
            wf "How much?"
            mc "So much that we can move to a mansion near the Academy"
            ss "Damn [pD22]..."
            ss "But how?"
            wf "Exactly! How?"
            mc "The students of this school are from very strong families."
            mc "And for some reason, they need a teacher like me."
            ss "What reason?"
            mc "Let just say a successful teacher"
            mc "That's how they promote me to do my job perfectly."
            wf "So, is this salary legal or?"
            mc "Of course it is!?"
            ss "So it's like a big luck, then"
            mc "Yeah we can say that"
            wf "I don't believe it's pure luck. You're good at teaching."
            mc "We can say that too"
        "lie":
            $v011mcLiedAmy = True
            $v011mcLiedJanet = True
            $mc_bad_points += 1
            mc "My salary is a little higher than usual,"
            mc "but I'll make much more money from private lessons with rich students."
            wf "Aren't you going to be tired of school and extra lessons, honey?"
            mc "I love my job, and also we can move into a big house near this college"
            ss "Is it that big?"
            mc "Yup, maybe more.."
            ss "Wow..."
            wf "I have a bad feeling about this..."
            mc "Why"
            wf "I can't say.."
            mc "Honey please, everything will be fine"
            wf "I hope you're right on this one."
            mc "I know I am."
            ss "Damn"
            wf "But.."
            wf "How do you know they're gonna ask you for private lessons every month?"
            wf "It's like gambling.."
            mc "I know. Just trust me"
            wf "Okay.."
            "Hmm, I think I could have told a better lie"
            "Well..,{w} damage is done.."
    scene hmeback45 with dissolve
    ss "So..."
    mc "So [pD7], you're moving in with us."
    scene hmeback46 with dissolve
    ss "Janet, I know you're a really great person, but you still have to be sure of this decision."
    ss "Is that really not a problem for you?"
    wf "Please! Don't be silly"
    scene hmeback47 with dissolve
    ss "Let me finish"
    ss "It's your opinion that matters, not [mc] and girls., let's not make a decision until you're really sure"
    ss "Okay?"
    ss "Believe me, no matter what decision you make, nothing will change between us"
    ss "We'll always be best friends."
    wf "I don't need to think, you're family."
    mc "That means?"
    wf "That means, Amy and I will start looking for a new house as soon as possible"
    mc "I'll leave you this then"
    wf "Anyway, I'll clean up the kitchen."
    ss "Let me help you"
    wf "Nope, you're a guest now, enjoy it, because it's your last time"
    ss "Okay then"
    $v011cS1_0 = False
    $v011cS1_1 = False
    menu v011cS1:
        "About divorce" if not v011cS1_0:
            scene hmebacksire1 with dissolve
            mc "Did that asshole call you?"
            ss "He tried to call a few times, but I'm not picking up."
            mc "Good"
            mc "What have you decided about [pD35]"
            ss "[pD36]"
            mc "Alimony?"
            ss "Not too much."
            ss "Don't worry, I'll start looking for a new job."
            mc "Actually, it's not necessary, I think it would be better if you stayed home with Janet"
            ss "Pfft hell no, I live to work"
            if v011mcLiedAmy == True:
                ss "I find it a little strange that you can make so much money suddenly"
                ss "Is there something you're not telling me?"
                menu:
                    "Tell the truth":
                        $mc_good_points += 1
                        mc "The students of this school are from very strong families."
                        mc "And for some reason, they need a teacher like me."
                        ss "What reason?"
                        mc "Let just say a successful teacher"
                        mc "That's how they promote me to do my job perfectly."
                        ss "So, is this salary legal or?"
                        mc "Of course it is!?"
                        ss "So it's like a big luck, then"
                        mc "Yeah we can say that"
                        ss "You're hiding something big from your wife, it's bad."
                        mc "Nah, she will understand."
                        ss "Okay then, just don't do anything to get you in trouble."
                        mc "Don't tell anyone about this [pD7]."
                        ss "Okay.."
                        $v011mcLiedAmy = False
                    "Lie":
                        mc "Don't worry, everything's fine, if there were any problems, I wouldn't take the job."
                        mc "And I'm really good at my job."
                        mc "It is not surprising that such an offer came."
                        ss "I think you're right.."
            $v011cS1_0 = True
            jump v011cS1
        "Luna" if not v011cS1_1:
            scene hmebacksire2 with dissolve
            mc "Is Luna okay? I'm sorry she didn't come."
            ss "I told you, she's with her friend."
            mc "[pD23].."
            ss "I don't really know, [pD22], she's out of control."
            ss "I don't know what Luna's doing these days."
            mc "Don't worry, just leave it to me."
            ss "Good luck with that.."
            $v011cS1_1 = True
            jump v011cS1
    ss "Anyway, we gotta get going"
    mc "I'll get Ruby."
    scene hmeback48 with fade
    mc "Hey girls Ruby's not here?"
    scene hmeback49 with dissolve
    d1 "She's with Emma"
    mc "Okie dokie"
    scene emmdr with fade
    rb "What do you think?"
    d3 "Oh c'mon your body is beautiful"
    rb "It's emberassing.."
    mc "What the hell.."
    $v011cS2_0 = False
    menu v011cS2:
        "Peek" if not v011cS2_0:
            scene hmeback50 with dissolve
            "I think they're comparing their bodies.."
            scene hmeback51 with dissolve
            "Ruby.."
            "She got her body from [pD37]"
            $v011cS2_0 = True
            jump v011cS2
        "Knock":
            scene hmeback52 with dissolve
            d3 "Wait!"
            d3 "Okay"
            mc "What are you doing girls?"
            d3 "Just girly stuff."
            mc "Uh huh.."
            mc "Anyway, Ruby, [pD38] calling"
    scene hmeback53 with fade
    ss "Janet, call me."
    scene hmeback54 with dissolve
    mc "I'll talk to Luna as soon as I can."
    ss "Don't forget to bring a helmet."
    mc "In the trunk I have Emma survival kit, don't worry."
    mc "Drive carefully"
    rb "Goodbye [pD14]"
    mc "See you, baby."
    scene hmeback55 with dissolve
    wf "So..."
    wf "Things are changing huh"
    mc "Change is good."
    wf "I think I'm a little excited"
    mc "A little?"
    mc "Our whole life is about to change, you should freak out!"
    scene hmeback56 with dissolve
    wf "I hope you made the right decision.."
    mc "I feel so tired"
    mc "I think I'll go to bed early"
    wf "Tomorrow is a big day for you. You should rest well"
    mc "For all of us."
    scene hmeback57 with fade
    if v011mcLiedJanet:
        if v011mcLiedAmy:
            #"Mc lied to both"
            mc "My conscience is not clear at all."
            mc "I lied to Amy and Janet."
            mc "I hope this doesn't end badly..."
        else:
            #"Mc lied only Janet"
            mc "I wish I could tell Janet the truth."
            mc "At least Amy knows..If something bad happens, I can talk to her."
            mc "I hope everything goes well."
    scene black
    "Next day"
    scene clmorn1 with vpunch
    d1 "Booooh"
    d1 "Irresponsible [pD4] booh"
    mc "Huh what?!"
    d1 "Wakey, wakey!"
    mc "What?! Am I late? Did I fall asleep?!"
    scene clmorn2 with dissolve
    d1 "Huh.. No, just wanted to see you [pD13]"
    mc "You scared the hell out of me Claire!.."
    scene clmorn with dissolve
    d1 "That's what ninjas are for..."
    mc "My perfect little ninja"
    scene clmorn3 with dissolve
    d1 "Liar.."
    mc "Come here babygirl"
    scene clmorn4 with dissolve
    d1 "Nu uh"
    scene clmorn5 with dissolve
    mc "If you come, I'll buy you ice cream."
    scene clmorn6 with dissolve
    pause
    menu:
        "I said come here!":
            $claire_d_points += 1
            play sound "audio/notify.mp3"
            show screen dominancePoint
            scene clmorn7 with dissolve
            mc "Hmm, I think you've forgotten who's boss in this house, young lady"
            mc "you'll do as I said"
            d1 "Oh yeah? Make me!"
            mc "Oh it's on!"
            scene clmorn8 with dissolve
            d1 "Eeeek!"
            scene clmorn9 with dissolve
            mc "Ahaha she really ran away"
            mc "So I can sleep a little more, nice"
            scene black
            "a while later"
        "Pretend to sleep.":
            mc "Huh okay then, you won."
            scene clmorn10 with dissolve
            d1 "Hey!"
            scene clmorn11 with dissolve
            d1 "Don't ignore me!"
            scene clmorn12 with dissolve
            d1 "[pD8]!"
            d1 "[pD13]!!"
            scene clmorn13 with dissolve
            d1 "I'm here!"
            scene clmorn14 with dissolve
            mc "Hehehe"
            d1 "Bad [pD13].."
            mc "So?"
            d1 "Oh thats it, I just wanted to see you"
            mc "And?"
            d1 "And i saw you"
            scene clmorn23 with dissolve
            pause
            mc "You little minx"
        "Make her go away":
            scene clmorn14 with dissolve
            mc "You woke me up, then you'll suffer the consequences"
            scene clmorn16 with dissolve
            d1 "Hmmm what are those [pD13]"
            mc "I'll tell you about politicians for hours."
            d1 "Oh no!"
            scene clmorn9 with dissolve
            mc "Hah!, Always works"
        "Ask about the school":
            scene clmorn14 with dissolve
            mc "So, tell me how school is going."
            scene clmorn15 with dissolve
            d1 "As always"
            mc "Don't you think that's the kind of answer Nora would give?"
            d1 "Ahaha yeah, but seriously, there's nothing worth telling."
            menu:
                "What important is sharing":
                    $claire_l_points += 1
                    play sound "audio/notify.mp3"
                    show screen lovePoint
                    scene clmorn14 with dissolve
                    mc "Honey, it's not the content that matters, it's who tells it"
                    d1 "Awww [pD13]..."
                    d1 "Anyway, I'll go to [pD10]."
                    scene clmorn23 with dissolve
                    pause
                "Push her":
                    $v011mcKnowsEmmaGrades = True
                    scene clmorn17 with dissolve
                    mc "Huh, I'll talk to your teacher today then."
                    d1 "No..."
                    mc "Then answer the question."
                    d1 "Yes [pD8].."
                    mc "Yes, I'm waiting"
                    scene clmorn15 with dissolve
                    d1 "Uhmm.."
                    mc "That's what I thought. You're failing your classes, aren't you?"
                    d1 "Not exactly."
                    mc "Not exactly huh?"
                    mc "They will tell you the same at your graduation day Claire!"
                    mc "Not exactly!"
                    d1 "......."
                    scene clmorn17 with dissolve
                    d1 "But [pD8]!"
                    mc "No but young lady"
                    mc "If I don't get the answers I want the next time, then you're in trouble young lady."
                    scene clmorn16 with dissolve
                    d1 "Oh no.."
                    mc "Yes.."
                    scene clmorn17 with dissolve
                    d1 "What about Emma?"
                    d1 "Her grades are also very bad"
                    scene clmorn16 with dissolve
                    d1 "Oh no..."
                    d1 "Please don't tell her you heard it from me [pD13].."
                    mc "Don't worry."
                    scene clmorn15 with dissolve
                    mc "How many classes she failed?"
                    d1 "...."
                    mc "Claire!"
                    scene clmorn16 with dissolve
                    d1 "I don't know exactly, I heard her on the phone."
                    menu:
                        "That's enough":
                            scene clmorn15 with dissolve
                            mc "Thank you for being honest, baby."
                            d1 "Don't let her know I said it [pD8]"
                            mc "Don't worry"
                            scene clmorn14 with dissolve
                            d1 "Yay! anyway, I'll go to [pD10]."
                            scene clmorn23 with dissolve
                            pause
                        "Push more":
                            scene clmorn16 with dissolve
                            mc "Tell me all you've heard."
                            d1 "But [pD8].."
                            mc "But this is for Emma's sake."
                            d1 "Emma's gonna kill me..."
                            mc "Don't be silly, of course she won't kill you."
                            mc "Just a little beat-up..."
                            scene clmorn15 with dissolve
                            d1 "She said she hadn't been to school in a while."
                            mc "Do you know how long?"
                            d1 "No, I don't"
                            mc "Do you know who did she talk to?"
                            d1 "No.."
                            mc "Does Emma have a boyfriend?"
                            scene clmorn17 with dissolve
                            d1 "Jealous?.."
                            mc "No"
                            mc "But if she's seeing a punk who's going to influence her negatively, I have to know."
                            d1 "You're jealous..."
                            menu:
                                "Tease":
                                    scene clmorn17 with dissolve
                                    mc "Of course I'm jealous, she's my [pD2], no man can even go near her"
                                    scene clmorn18 with dissolve
                                    d1 "Oh yeah, then big news [pD13], I have a boyfriend too"
                                    d1 "And he's extremely punk and handsome and all that.!"
                                    mc "Really, what's this jerk's name?"
                                    scene clmorn19 with dissolve
                                    d1 "Uhmm, it's Martin.. He is very nice"
                                    mc "I thought he was a punk, not nice"
                                    scene clmorn18 with dissolve
                                    d1 "Oh shut up!"
                                    mc "You're a terrible liar."
                                    scene clmorn19 with dissolve
                                    d1 "Yeah..."
                                    d1 "I'm not good at lying.."
                                    mc "You'll have a hard time in your career."
                                    scene clmorn16 with dissolve
                                    d1 "But isn't lying bad?"
                                    d1 "I've always been taught that."
                                    mc "Oh honey, you have so much to learn about the real world."
                                    scene clmorn21 with dissolve
                                    d1 "La la la la la!, I don't want to learn!"
                                    scene clmorn9 with dissolve
                                    d1 "My world is much better"
                                "Sensible":
                                    $persistent.gal11 = True
                                    scene clmorn20 with dissolve
                                    mc "Honey, as a [pD4] I have to protect you"
                                    mc "And I know who's a threat, you can trust my instincts"
                                    d1 "You're our hero!"
                                    mc "True"
                                    scene clmorn22 with dissolve
                                    d1 "And when you left us, didn't your instincts tell you not to go?"
                                    mc "Honey.."
                                    d1 "What if something had happened to one of us while you were gone?"
                                    mc "We agreed not to talk about it."
                                    d1 "Sorry."
                                    mc "No I'm sorry"
                                    scene clmorn23 with dissolve
                                    d1 "You should be."
                                    d1 "Anyway, I'll go to [pD10]."
                                    scene clmorn23 with dissolve
                                    "Fuck me, she is right"
                                    "She's still mad at me"
                                    "I have to make it up to them.."
                                    "Or maybe we can continue to pretend that something like this never happened.."
    mc "Should take a shower now"
    scene nagh1 with fade
    mc "Huh, locked."
    menu:
        "Knock":
            play sound "audio/knock.mp3"
            scene nagh4 with dissolve
            d3 "I'm taking a shower. Go away!"
            mc "Okay.."
    menu:
        "Go to Nora's room":
            scene nrabok1 with dissolve
            mc "Hey babe, what are you doing?"
            d2 "I'm reading a book"
            mc "How nice"
            mc "...."
            mc "All right, then I'll leave you alone."
        "Go to Emma's room":
            $v011mcTookEmmaPass = True
            scene emrompas1 with dissolve
            scene emrompas2 with dissolve
            mc "Hmmm what's this.."
            scene emrompas3 with dissolve
            mc "Looks like a password"
            mc "But password of what?.."
            mc "Anyway"
    scene nagh5 with fade
    stop music fadeout 3.0
    mc "You finally got out of the shower."
    d3 "Sorry for taking a shower!?"
    mc "So are we gonna wait like this?"
    d3 "Huh?"
    mc "I gotta get in the shower, honey."
    d3 "Oh yeah"
    scene nagh6 with dissolve
    play music "audio/showerSound.mp3" fadein 1.0
    pause
    scene nagh17 with dissolve
    "Huh this is weird.."
    menu:
        "Get dressed and go to the hall":
            stop music
            play music "audio/bensound-tenderness.mp3" fadein 5.0
            scene mout2 with dissolve
            mc "Guys, I'm leaving"
            wf "Good luck [mc]"
            d2 "Give them hell [pD8]"
            mc "Calm down Nora, I'm a teacher, not a boxer."
    scene mout3 with fade
    "This is Emma's phone.."
    "Should I check her messages?.."
    menu:
        "Do":
            mc "Fuck it, this chance will never come again."
            mc "Also, I do this for a good reason."
            mc "She could be hanging out with bad people."
            mc "Dangerous times.."
            mc "Since I justified myself, I can check the phone."
            scene mout4  with dissolve
            mc "Of course, there is a password.."
            if v011mcTookEmmaPass:
                mc "Let's try this.."
                scene mout5 with dissolve
                mc "It works! Nice!"
                mc "Now show me what you got honey."
                mc "A guy named Christian sent an address.."
                mc "Fuck!"
                mc "Does she have a boyfriend?"
                mc "I should go there!"
                mc "Let's see what you're up to, Emma!"
                mc "I'm not ready to share her."
                mc "She is mine!"
                mc "Oh, another message from Christian."
                mc "15:30, huh."
                mc "That's good."
                mc "Nurse, time of death 15:30!"
                $v011mcCheckedEmmaPhone = True
                jump v011mcCheckedEmmaPhone_S0
            else:
                mc "Fuck! I don't know the password!"
                mc "I guess I missed a once in a lifetime chance!"
                jump v011mcCheckedEmmaPhone_S1
        "Don't":
            mc "It's her personal life."
            mc "I trust her."
            jump v011mcCheckedEmmaPhone_S1
label v011mcCheckedEmmaPhone_S0:
    scene mout1 with dissolve
    mc "I started the day badly."
    scene mylnw1 with fade
    mc "I can't stop thinking about those messages.."
    mc "I don't know who you are,"
    mc "what you look like, Christian."
    mc "but today, you are my worst enemy."
    mc "If I hurry after the class, I can make it."
    mc "I need to talk to Charlotte first."
    scene otoex1 with fade
    pause
    jump v011mcChloe_0

label v011mcCheckedEmmaPhone_S1:
    stop music fadeout 3.0
    scene mout1 with dissolve
    mc "Big day ahead!"
    scene mylnw1 with fade
    play music "audio/car-ride-at-dawn.mp3"
    mc "Emma's up to something. If I could check her phone, maybe I could find out."
    mc "Or maybe I could find something about Luna."
    mc "Whatever.."
    mc "I should focus on today."
    scene otoex1 with fade
    pause
    jump v011mcChloe_0

label v011mcChloe_0:
    play music "audio/bensound-tenderness.mp3" fadein 3.0
    menu:
        "Charlotte":
            scene gbofast1 with dissolve
            "Oh, man...Who is this hottie?"
            scene gbofast2 with dissolve
            "Nice.."
            scene gbofast3 with fade
            mc "Hey, where's Charlotte?"
            att "Ms. Gaby's not here yet."
            att "You're the new teacher."
            menu:
                "Yes":
                    scene gbofast3 with dissolve
                    mc "Yes, I am."
                    mc "And you are?"
                    att "I'm Ms. Gaby's assistant, Chloe."
                    mc "When does she come?"
                    scene gbofast4 with dissolve
                    att "Probably in the afternoon, She is in a meeting right now."
                    mc "Cool."
                    scene gbofast3 with dissolve
                    att "Uhmm, can I ask you something?"
                    menu:
                        "I'm in a hurry":
                            scene gbofast7 with dissolve
                            mc "Actually, I'm in a hurry."
                            mc "And tell Gaby I might leave early today."
                            att "Sure..."
                            scene gbofast8 with dissolve
                            menu:
                                "Spank":
                                    scene gbofast9 with vpunch
                                    play sound "audio/Slap1.mp3"
                                    scene gbofast10 with dissolve
                                    att "Ouch!"
                                    att "Hey!"
                                    menu:
                                        "Sorry":
                                            scene gbofast11 with dissolve
                                            mc "Sorry, I was trying to be sincere."
                                            att "Oh... Please don't do it again. That is not appropriate."
                                            mc "Okay, it won't happen again."
                                            scene gbofast13 with dissolve
                                            att "..."
                                            mc "Okay...See you .."
                                            mc "Um.."
                                            att "Chloe.."
                                            jump v011mcTwins_0
                                        "What?!":
                                            $chloe_r_points -= 1
                                            scene gbofast11 with dissolve
                                            mc "I couldn't resist that perfect ass."
                                            scene gbofast12 with dissolve
                                            att "This is sexual harassment."
                                            mc "You have a great ass. I had to spank it."
                                            scene gbofast14 with dissolve
                                            att "........"
                                            mc "Anyway, See you later."
                                            jump v011mcTwins_0
                                "Don't":
                                    scene gbofast7 with dissolve
                                    mc "See you .."
                                    mc "Um.."
                                    att "Chloe.."
                                    jump v011mcTwins_0
                        "Sure":
                            scene gbofast15 with dissolve
                            mc "I'm listening"
                            att "I've looked at your CV a little bit, and it's obvious that you're an excellent teacher."
                            att "Wouldn't it be better if you used your skills not at the richest college in the country, but the most successful college?"
                            att "Why did you choose Diamond College?"
                            menu:
                                "For money":
                                    mc "The answer is always the same, sweety, money."
                                    scene gbofast16 with dissolve
                                    att "Oh.."
                                    att "I hope you achieve what you want with the money.."
                                    mc "What I want, huh.."
                                    mc "I guess I don't know, exactly, what I want."
                                    att "How so?"
                                    mc "I guess the money alone was enough to make that decision.."
                                    mc "I never thought about where to use the money."
                                    att "I can understand that. Money can be useful for everything."
                                    mc "Yeah.."
                                    menu:
                                        "What would you do?":
                                            $v011mcKnowsChloesDream = True
                                            mc "What would you do if you had a lot of money?"
                                            att "Hmmm.."
                                            mc "Don't think, just say what comes to mind first."
                                            scene gbofast17 with dissolve
                                            att "I think I took a vacation."
                                            att "But not those cheap vacation packages."
                                            att "A very luxurious vacation. I want to feel special..."
                                            mc "Good idea.."
                                            att "How about you?"
                                            mc "Um..."
                                            scene gbofast15 with dissolve
                                            att "Don't think, say what comes to mind first."
                                            mc "Hmm..."
                                            att "?"
                                            mc "I don't know.."
                                            att "Really?.."
                                            mc "I think I'd buy a new car, maybe I'd buy a bigger house."
                                            mc "Well, I'll buy a bigger house soon.."
                                            mc "Damn.."
                                            scene gbofast16 with dissolve
                                            att "Don't worry, Mr. [mc],"
                                            att "so what you have right now is enough for you, which is a good thing."
                                            att "everyone wants to have money and power."
                                            mc "There must be a lot of people who think money is not what they want when they have it."
                                            att "They use their money for good things like science, charity."
                                            att "Maybe you can be one of those people."
                                            mc "You're too naive to be Gaby's assistant..."
                                            scene gbofast17 with dissolve
                                            att "Everyone has things to do. That is life."
                                            att "Besides, miss Gaby's not that scary, okay she's not a saint, but she's not a bad person."
                                            mc "How do you know?"
                                            att "Trust me."
                                            menu:
                                                "Ask":
                                                    mc "C'mon, tell me."
                                                    scene gbofast18 with dissolve
                                                    att "Mr. [mc] this is not ethical."
                                                    mc "Oh, come on!"
                                                    att "I'm sorry.."
                                                    menu:
                                                        "Insist":
                                                            mc "I promise it's between us."
                                                            scene gbofast19 with dissolve
                                                            att "I'm so sorry, but every time I say no to you, I'm more embarrassed."
                                                            mc "Okay, okay, I'm sorry..."
                                                            att "I have to go back to work."
                                                            scene gbofast7 with dissolve
                                                            pause
                                                            jump v011mcTwins_0
                                                        "Don't insist":
                                                            mc "Okay, then I should get going."
                                                            att "See you Mr. [mc]"
                                                            jump v011mcTwins_0

                                                "Don't ask":
                                                    mc "Well, I hope I meet the real Gaby sooner."
                                                    scene gbofast16 with dissolve
                                                    att "If you're lucky."
                                                    mc "Okay, then I should get going."
                                                    att "See you Mr. [mc]"
                                                    jump v011mcTwins_0
                                        "Do you love your job?":
                                            scene gbofast16 with dissolve
                                            mc "Have you ever been in a situation like this? I mean, did you get a huge opportunity?"
                                            att "Well.. this job was like that."
                                            mc "Being Gaby's assistant?"
                                            att "Yes, they pay me good money, and it's cushy.."
                                            mc "Your standards are really, low..."
                                            scene gbofast18 with dissolve
                                            att "Said the man who doesn't even have a dream."
                                            mc "Hey, hey, that's rude..."
                                            scene gbofast20 with dissolve
                                            att "Oh, I'm sorry..."
                                            mc "Just kidding, but I have to admit, I misjudged you."
                                            att "How so?"
                                            mc "At first, I thought you were weak and naive, but you're so much more than that, aren't you?"
                                            mc "Gaby's not the kind of person to pick a coward, your a tough cookie, aren't you?"
                                            scene gbofast17 with dissolve
                                            att "Don't be silly, I'm just doing my job.."
                                            mc "Whatever you say.."
                                            mc "Anyway, I should get going."
                                            jump v011mcTwins_0
                                "I don't think you can understand.":
                                    scene gbofast17 with dissolve
                                    mc "I don't wanna be rude but,"
                                    mc "I don't think you can understand my motivation."
                                    scene gbofast19 with dissolve
                                    att "If you say so..."
                                    mc "And thank you."
                                    att "For what?"
                                    scene gbofast20 with dissolve
                                    mc "For complimenting me on my profession."
                                    att "Sure.."
                                    att "Is there anything you want me to help you with?"
                                    menu:
                                        "Are you single?":
                                            scene gbofast15 with dissolve
                                            mc "Actually there is one thing."
                                            att "What?"
                                            mc "Are you single?"
                                            scene gbofast19 with dissolve
                                            att "Uhmm, yes, why?"
                                            mc "Just out of curiosity."
                                            menu:
                                                "Make a move":
                                                    mc "Actually, it's not just curiosity. You are very, pretty."
                                                    att "Uhm... I thought you were married."
                                                    mc "So?"
                                                    att "So, this is not appropriate.."
                                                    mc "So if I wasn't married, something could have happened between us."
                                                    scene gbofast20 with dissolve
                                                    att "I didn't say such a thing."
                                                    mc "But you did not say no."
                                                    att "Because I didn't expect that"
                                                    scene gbofast22 with dissolve
                                                    mc "Sure, anyway, see you later."
                                                    att "Oh.."
                                                    att "Okay.."
                                                    jump v011mcTwins_0
                                                "Don't":
                                                    scene gbofast7 with dissolve
                                                    mc "See you .."
                                                    mc "Um.."
                                                    att "Chloe.."
                                                    jump v011mcTwins_0
                                        "Ask her past":
                                            scene gbofast15 with dissolve
                                            mc "How long have you been doing this job?"
                                            scene gbofast16 with dissolve
                                            att "Few years."
                                            mc "Do you like it?"
                                            scene gbofast17 with dissolve
                                            att "Of course."
                                            mc "Because they pay you well?"
                                            scene gbofast18 with dissolve
                                            att "No, that's not the case."
                                            mc "Then this is the ideal profession for you."
                                            scene gbofast19 with dissolve
                                            att "Actually, I've always wanted to study medicine... But life brought me here."
                                            menu:
                                                "tease":
                                                    $chloe_d_points += 1
                                                    play sound "audio/notify.mp3"
                                                    show screen dominancePoint
                                                    scene gbofast19 with dissolve
                                                    mc "everyone wants to be a doctor or an engineer."
                                                    scene gbofast12 with dissolve
                                                    mc "But very few people are equipped to do these things."
                                                    mc "World needs good secretaries too."
                                                    att "Uhm.."
                                                    att "..."
                                                    mc "That's what I thought"
                                                    scene gbofast21 with dissolve
                                                    pause
                                                    scene gbofast7 with dissolve
                                                    "Oh fuck, why on earth did I do that.."
                                                    jump v011mcTwins_0
                                                "don't":
                                                    $chloe_l_points += 1
                                                    play sound "audio/notify.mp3"
                                                    show screen lovePoint
                                                    mc "Maybe you're not doing a sacred job that saves lives, but"
                                                    mc "In a way, you're raising students who will do it. I think that's enough"
                                                    mc "Anyway, I should get going now, Ms..?"
                                                    att "Chloe."
                                                    mc "Ms. Chloe."
                                                    jump v011mcTwins_0
                                        "No":
                                            scene gbofast22 with dissolve
                                            mc "Nope, that's all, have a nice day Ms..?"
                                            att "Chloe.."
                                            mc "Good day Ms. Chloe"
                                            jump v011mcTwins_0
label v011mcTwins_0:
    play music "audio/school-hallway.mp3" fadein 3.0
    scene frstgn1 with dissolve
    mc "Huh, the twins are here."
    scene frstgn2 with dissolve
    mc "Hey girls."
    scene frstgn3 with dissolve
    tw2 "Hello Mr.[mc]"
    mc "Class is about to start. Why are you here?"
    tw2 "We still have time. And I haven't decided if we're going to class yet."
    mc "What does that mean, young lady?"
    tw2 "I usually go to classes when I want to Mr.[mc]"
    tw2 "Just so you know, Mr. [mc]. I want no trouble."
    mc "That was when I wasn't your teacher, young lady. From now on, you'll be in all your classes."
    scene frstgn4 with dissolve
    tw2 "Ahaha, I'd like to see you try."
    menu:
        "You won't like":
            $persistent.gal10 = True
            $olivia_d_points += 1
            play sound "audio/notify.mp3"
            show screen dominancePoint
            mc "Oh, don't worry, you will.."
            mc "Now there will be discipline in this school."
            mc "Just so you know, Olivia. I want no trouble."
            scene frstgn3 with dissolve
            tw2 "Game on."
            mc "I'll show you this isn't a game, young lady."
            scene frstgn8 with dissolve
            tw1 "I think a war is starting and I'll be a part of it. How exciting!"
            scene frstgn4 with dissolve
            tw2 "Shut up, sis!"
        "Tease":
            scene frstgn4 with dissolve
            mc "I'm not someone who tries. I'm someone who does."
            tw2 "Game on."
            mc "I'll show you this isn't a game, young lady."
            scene frstgn2 with dissolve
            tw1 "I think a war is starting and I'll be a part of it. How exciting!"
            scene frstgn4 with dissolve
            tw2 "Shut up, sis!"
    scene frstgn5 with dissolve
    mc "Hey, why the long face?"
    tw1 "Huh, no, I'm just distracted."
    mc "Honey, trust me, I know when something's wrong."
    scene frstgn3 with dissolve
    tw2 "Don't call her honey."
    scene frstgn5 with dissolve
    mc "C'mon, you can tell me."
    tw1 "Everything is fine.."
    mc "Okay.."
    scene frstgn6 with dissolve
    tw1 "So, you're our teacher now."
    mc "Yup."
    scene frstgn4 with dissolve
    tw2 "Ugh, what kinda teacher says yup.."
    mc "A cool kind!"
    scene frstgn8 with dissolve
    tw1 "Ahaha yeah, he is cool."
    tw2 "No, he is not"
    scene frstgn5 with dissolve
    tw1 "Yeah, you're right.."
    mc "Anyway, I'll see you in class, girls."
    scene frstgn8 with dissolve
    tw1 "Yes, teacher!"
    scene frstgn5 with dissolve
    tw2 "Don't shout."
    tw1 "Sorry.."
    "Gee, what's wrong with her.."
    scene frstgn7 with dissolve
    menu:
        "Go to class":
            scene clsbgn1 with dissolve
            mc "Good Morning, class."
            mc "May I have your attention, please?"
            mc "Put your phones down, stop talking to each other, and listen to me."
            scene clsbgn2 with dissolve
            stop music fadeout 2.0
            mc "Good."
            mc "I'm your new teacher. My name is Mr.[mc]"
            mc "I'll teach you philosophy."
            mc "I am also assigned as your school counselor. So,"
            mc "I'll help all of you develop the academic and social skills needed to succeed in school, as well as later in life."
            mc "I'll lay my cards on the table."
            mc "I do not doubt that you are all smart."
            mc "But it's obvious you're lazy. Your grades are not good enough."
            mc "Most of you are spoiled. Some of you are cocky and stubborn."
            mc "And it's normal for you to be like this."
            mc "Because you never had a good teacher to guide you on the right path."
            mc "I'm confident about that."
            mc "I've touched many of my old students' lives. I have put them on the right path."
            mc "And I'm proud of them all right now. Having all become very good citizens."
            mc "When I am done with you, you'll be one of these people I'm proud of."
            mc "And you all are a little more special."
            mc "You are the students who will shape the future of this country the most."
            mc "You will take over and run your family businesses."
            mc "These companies are the most important and powerful companies in this country."
            mc "That's why you are so important."
            tw2 "Duh.."
            mc "Now introduce yourself one by one."
            scene clsbgn3 with dissolve
            tw2 "Hi, I'm Olivia. I'm as smart as I am spoiled. And I'm special because I'm going to run a strong company in the future."
            tw2 "It was an incredibly inspiring speech, teacher, I was extremely impressed."
            tw2 "I'm sure you'll educate us perfectly. I have full faith in you!"
            mc "You're making fun of me right now, young lady, but I'm going to turn you into incredible individuals."
            mc "And then you will shout those words with all your heart."
            tw2 "Sure man, dream on.."
            mc ".."
            mc "Next."
            scene clsbgn4 with dissolve
            tw1 "Hello teacher, my name is Ava, and I.."
            scene clsbgn4v2 with dissolve
            tw2 "That's enough Ava. shut up."
            scene clsbgn4v3 with dissolve
            tw1 "Yes, sis."
            mc "Next."
            scene clsbgn4v4 with dissolve
            tw2 "Wait, are you just going to accept it?"
            tw2 "Aren't you going to tell me not to interfere??"
            mc "Next."
            tw2 "Wait, wha.."
            mc "I said next!"
            scene clsbgn5 with dissolve
            ky "Hi, my name is Kayla, and I don't give a shit about your discipline."
            mc "Nice to meet you, Kayla."
            mc "Next."
            scene clsbgn2 with dissolve
            mc "Missed your turn."
            scene clsbgn6 with dissolve
            m1 "Don't mind me, I just like to watch."
            scene clsbgn5v4 with dissolve
            mc "Okay then, next"
            scene clsbgn7 with dissolve
            pg "Hey, wanna see my tongue?"
            mc "Already saw it when I entered the class."
            pg "Oooh kinky."
            mc "Do you have anything else to say?"
            pg "My name is xxslut69xx, I like everything that hurts me, physically."
            mc "Creative!"
            mc "next"
            scene clsbgn8 with dissolve
            sy "Hey..."
            sy "I'm Zoey.."
            mc "I guess that's all you have to say."
            mc "Okay, and the last one."
            scene clsbgn5v2 with dissolve
            ag "Oh hey, I'm not a student of this class. I go to other classes sometimes."
            mc "Cool.."
            scene clsbgn2 with dissolve
            mc "Okay.."
            mc "This wasn't the worst first lesson I've ever seen."
            mc "But it wasn't good either."
            ag "Will yo.."
            mc "No questions."
            mc "Class Dismissed."
            tw2 "Is he serious?"
            tw1 "He seems serious.."
            mc "See you next time."
            scene clsbgn5v3 with dissolve
            m1 "Wait."
            mc "Hmm, this was unexpected."
            m1 "Will all lessons be like this??"
            mc "I don't know, we'll see. I like to watch too."
            scene clsbgn5v4 with dissolve
            m1 "Hmh."
            if v011mcCheckedEmmaPhone:
                jump v011EndSchool_S0
            else:
                jump v011EndSchool_S1
label v011EndSchool_S0:
    play music "audio/school-hallway.mp3"
    menu:
        "Get out of school":
            scene bgbsmet1 with dissolve
            mc "Finally. I'm coming for you Christian!"
            scene bgbsmet2 with dissolve
            sm "Oh hey [mc], there's someone I want you to meet."
            menu:
                "not now":
                    $gaby_r_points -= 1
                    scene bgbsmet3 with dissolve
                    $v011mcGabyNotNow = True
                    mc "Sorry Gaby, but I'm in a hurry"
                    sm "You can't be serious!"
                    mc "See you."
                    mc "I have to go early and bust them together."
                    jump v011BustEmma
                "decline politely":
                    scene bgbsmet4 with dissolve
                    $v011mcGabyPolitely = True
                    mc "Hey, I'm so sorry, but I have to go right now. My [pD2] could be in trouble."
                    mc "it would be great if we could postpone this"
                    sm "Oh, okay. It's all right, [mc], we'll do it later."
                    mc "Thank you"
                    jump v011BustEmma
                "meet":
                    jump v011EndSchool_Meet

label v011BustEmma:
    stop music fadeout 3.0
    play music "audio/bensound-tenderness.mp3" fadein 5.0
    menu:
        "Go to Christian":
            $v011mcWentChristian = True
            scene mylnw1blr with fade
            pause 0.7
            scene chasngem1 with dissolve
            mc "Huh, it looks like a religious neighborhood.."
            mc "which scares me more.."
            mc "Should I ask one of the neighbors who lives at this address?"
            mc "Nu uh, that would be stupid."
            mc "I just have to wait"
            mc "There are no people around..."
            scene chasngem2 with dissolve
            pause 0.2
            scene chasngem3 with dissolve
            play sound "audio/knockWindow.mp3"
            menu:
                "open window":
                    scene chasngem4 with dissolve
                    st1 "Uhm hello sir, did you get lost?"
                    mc "Huh?{w} No why?"
                    st1 "You've been waiting here a long time."
                    mc "Oh, I was just resting."
                    scene chasngem5 with dissolve
                    st1 "Oh my, if you are tired and need help, come and rest in our house."
                    mc "No thanks."
                    st1 "I insist."
                    mc "I said no, but thank you."
                    mc "And what's on your face?"
                    scene chasngem6 with dissolve
                    st1 "This is my make-up, do you like it?"
                    mc "Cute."
                    scene chasngem7 with dissolve
                    st1 "Really?"
                    mc "Sure."
                    scene chasngem6 with dissolve
                    st1 "Yaaay!"
                    mc "Uh huh."
                    scene chasngem8 with dissolve
                    st1 "Oh, okay."
                    st1 "So."
                    mc "What now?"
                    st1 "Can I stay with you?"
                    mc "Why?"
                    st1 "Because I'm bored."
                    mc "You can get bored somewhere else."
                    scene chasngem9 with dissolve
                    st1 "I see, you're trying to get rid of me."
                    st1 "Then you'll do something dangerous."
                    mc "What? No.."
                    st1 "Are you going to kidnap children?"
                    mc "What!?"
                    st1 "Are you going to rob a house?"
                    mc "God damn girl, no!"
                    mc "I'm not a criminal, I'm just waiting."
                    scene chasngem8 with dissolve
                    st1 "You said you were resting."
                    mc "I'm resting while I wait."
                    st1 "Wait for what? Maybe I know."
                    scene chasngem5 with dissolve
                    menu:
                        "answer":
                            mc "A boy named Christian."
                            scene chasngem8 with dissolve
                            st1 "Oh.. good luck with that.."
                            mc "Why?"
                            st1 "I don't know if you've noticed, but this is a religious neighborhood."
                            st1 "Boys in most families are named Christian.."
                            mc "Amazing.."
                            scene chasngem9 with dissolve
                            st1 "Why are you waiting for this child?"
                            st1 "Are you going to kill him?"
                            mc "Ugh, your parents should forbid you to watch TV."
                            st1 "Ugh, you are boring!"
                            mc "Yes, I'm, can you leave me alone now?"
                            scene chasngem10 with dissolve
                            scene chasngem9v4 with dissolve
                            st1 "You are a bad person. I hate you!"
                            scene chasngem11 with dissolve
                            scene chasngem9v5 with dissolve
                            scene chasngem9v6 with dissolve
                            mc "What.."
                            mc "What did I say?.."
                            mc "Anyway, at least she's gone."
                        "get rid of her":
                            scene chasngem4 with dissolve
                            mc "What do I have to do to make you leave me alone?"
                            st1 "Hmmm..."
                            scene chasngem5 with dissolve
                            st1 "1 Million dollars."
                            mc "I can give you 20 bucks."
                            st1 "Hmmmm."
                            mc "You're a bad negotiator."
                            scene chasngem9v2 with dissolve
                            st1 "Money is money!"
                            mc "By the way, I'm not giving you any money."
                            scene chasngem9v5 with dissolve
                            st1 "Fine! I'm not taking your money either!"
                            mc "I'm not giving it anyway!"
                            scene chasngem9v2 with dissolve
                            st1 "Bad man!"
                            mc "Yes, I'm bad, and you should stay away from me."
                            mc "But don't call the cops."
                            scene chasngem9v3 with dissolve
                            st1 "You're breaking my heart.."
                            menu:
                                "I don't care":
                                    mc "Oh, do I care?"
                                    mc "Nope."
                                    st1 "I thought you were a good guy.."
                                    mc "You thought wrong honey, now get lost."
                                    scene chasngem9v4 with dissolve
                                    st1 "A word and hole!"
                                    mc "What?"
                                    st1 "I'm not allowed to swear, so I censored myself!"
                                    scene chasngem9v6 with dissolve
                                    "Ugh, such a brat.."
                                    "But she was cute..."
                                "I'm sorry":
                                    $st1_l_points += 1
                                    play sound "audio/notify.mp3"
                                    show screen lovePoint
                                    scene chasngem9v3 with dissolve
                                    mc "Okay, okay, I'm sorry."
                                    mc "But I have to focus on something else right now."
                                    mc "How about this, next time I come here, we'll eat ice cream together?"
                                    st1 "Promise?"
                                    mc "Promise."
                                    scene chasngem5 with dissolve
                                    st1 "Yaaay, and how about my 1 million dollars?"
                                    mc "I'll buy you a million dollars worth of ice cream."
                                    mc "But every time I come, I'll just buy you one ice cream, so you don't get sick."
                                    mc "Deal?"
                                    st1 "Yes!"
                                    scene chasngem7 with dissolve
                                    st1 "Don't trick me."
                                    st1 "Please..."
                    scene black
                    "a while later."
                    scene chasngem1 with dissolve
                    mc "It's time, now where is Emma?"
                    scene chasngem10 with dissolve
                    mc "There she is..."
                    mc "I can't believe you, Emma!"
                    mc "You're really gonna do this, huh.."
                    mc "Wait? Why is she dressed like this.."
                    mc "it's not Emma."
                    mc "Very strange."
                    scene chasngem11 with dissolve
                    scene chasngem12 with dissolve
                    mc "Huh, they left the door open."
                    scene chasngem13 with dissolve
                    mc "Jesus..."
                    mc "Now where are they.."
                    scene chasngem14 with fade
                    og "Have you been a good girl this week?"
                    d3 "Ahaha, you're not seriously asking, Are you?"
                    mc "That is Emma!"
                    og "I am."
                    d3 "Did the world turn upside down?"
                    og "You're so bad."
                    d3 "And you like it."
                    mc "What the hell.."
                    mc "Where is Christian.."
                    mc "Who is this girl?"
                    mc "What parent names their daughter Christian?.."
                    mc "Come on, [mc], the girl's name doesn't matter, there's a bigger problem right now."
                    mc "Is Emma with this girl?.."
                    mc "I didn't expect this."
                    mc "But still.."
                    menu:
                        "I'm okay with this":
                            $persistent.gal6 = True
                            $v011mcOkayWithThis = True
                            mc "Well, this is okay."
                            mc "It's not a boy after all."
                            mc "There's nothing to be angry about, It's very [pD24].."
                            menu:
                                "Go back home":
                                    mc "Anyway, there's nothing to be afraid of, I have to get out of here."
                                    mc "I can't imagine what would happen if someone caught me here right now."
                                    mc "It's time to go home."
                                    mc "Have fun, girls."
                                    jump v011JanetLScene
                                "Stay and keep listening":
                                    mc "I know it's too risky, but I have to know."
                                    scene chasngem15 with dissolve
                                    og "Can I ask you a question?"
                                    d3 "Babe, you can even ask me the meaning of life."
                                    scene chasngem16 with dissolve
                                    og "Hmm, then tell me what is the meaning of life?"
                                    d3 "42, of course."
                                    og "Ahahaha you're so silly."
                                    mc "Hehehe silly indeed."
                                    og "Bad girl.."
                                    d3 "Oh, I'm the bad girl, huh?"
                                    d3 "What about you, you little sinner."
                                    d3 "A little, innocent girl of a faithful family is in love with another girl, how pure is that!"
                                    og "Oh c'mon.."
                                    d3 "Hey, I'm just kidding."
                                    og "I know, sweety."
                                    d3 "Let's watch something."
                                    mc "Hmm, fun time is over.."
                                    mc "It's time to go home."
                                    mc "Have fun, girls."
                                    jump v011JanetLScene
                        "I'm not okay with this":
                            $v011mcNotOkayWithThis = True
                            scene chasngem14 with dissolve
                            mc "Boy or girl doesn't change anything."
                            mc "I'm not going to share Emma with anyone."
                            mc "She belongs to her [pD13]!"
                            mc "Just like everyone else in my house."
                            menu:
                                "Leave":
                                    mc "I can't interfere right now, I'm already in someone else's House."
                                    mc "I can't imagine what would happen if someone caught me here right now."
                                    mc "I'll talk to Emma at home."
                                    jump v011JanetLScene
                                "Interfere":
                                    $v011mcInterfereEmma = True
                                    scene chasngem17 with dissolve
                                    mc "Emma!"
                                    d3 "Holy shit!"
                                    scene chasngem18v2 with dissolve
                                    d3 "[pD8] what are you doing here? How did you get in the house!?."
                                    d3 "Did you follow me?"
                                    mc "What is going on here?"
                                    d3 "Nothing, we were just chatting."
                                    mc "What I just heard didn't sound like a normal conversation."
                                    d3 "It was TV!"
                                    mc "Oh shut up!"
                                    mc "We're going home, Emma!"
                                    d3 "[pD8], it's not what it looks like."
                                    mc "Right now!!"
                                    d3 "Yes.. yes [pD13] I will.."
                                    scene chasngem19 with dissolve
                                    d3 "[pD8].."
                                    d3 "I'm sorry.."
                                    mc "...."
                                    stop music fadeout 3.0
                                    scene chasngem18 with dissolve
                                    play music "audio/car-ride-at-dawn.mp3"
                                    d3 "It was just out of curiosity, and we didn't go too far.."
                                    mc "..."
                                    d3 "We didn't do anything dangerous..."
                                    mc "..."
                                    d3 "Can you talk to me, please?"
                                    mc "No."
                                    d3 "What are you going to do."
                                    mc "I don't know."
                                    scene chasngem19 with dissolve
                                    d3 "You hate me, don't you!"
                                    mc "..."
                                    d3 "Are you going to tell the people at home?"
                                    mc "I don't know."
                                    d3 "I didn't do anything wrong.."
                                    scene chasngem20 with dissolve
                                    d3 "[pD13]!"
                                    mc "What!"
                                    d3 "I love you.."
                                    d3 "I know I'm always mean to you, but that doesn't mean I hate you."
                                    scene chasngem23 with dissolve
                                    d3 "And I know you love me."
                                    mc "Wow, you're so desperate, huh."
                                    scene chasngem19 with dissolve
                                    d3 "Please don't leave us again!"
                                    mc "What?"
                                    scene chasngem21 with dissolve
                                    pause
                                    scene chasngem22 with dissolve
                                    d3 "I know why you left home before.."
                                    scene chasngem24 with dissolve
                                    d3 "Because of me.."
                                    d3 "You thought I hated you, so you left."
                                    scene chasngem25 with dissolve
                                    d3 "Now it'll be the same again, right?"
                                    d3 "It was all a lie, a game."
                                    d3 "[pD8], even Claire doesn't love you as much as I do!" with vpunch
                                    scene chasngem26 with dissolve
                                    d3 "Please don't leave me again!"
                                    scene chasngem27 with dissolve
                                    d3 "I can change, I promise!"
                                    scene chasngem28 with dissolve
                                    d3 "No one matters to me but you! Not a girl! Not a boy!"
                                    scene chasngem29 with dissolve
                                    d3 "Just please don't leave me again!"
                                    mc "Emma.."
                                    scene chasngem28 with dissolve
                                    mc "I didn't leave home because of you or anyone else.."
                                    mc "The reason I left home was completely personal."
                                    mc "You have nothing to do with."
                                    mc "Leaving you was the worst mistake I've ever made."
                                    mc "You're making me so sad right now."
                                    d3 "I said I'd do everything your way. What more can I do?"
                                    mc "Not that"
                                    d3 "Then what?!"
                                    mc "To see you cry."
                                    scene chasngem29 with dissolve
                                    d3 "[pD8]..."
                                    mc "Okay, now we're going home, and we're not telling anyone about what happened today. it's gonna be our little secret."
                                    mc "As if it never happened.."
                                    scene chasngem30 with dissolve
                                    d3 "Yes [pD13]"
                                    mc "Huh, what?"
                                    scene chasngem31 with dissolve
                                    d3 "Oh yeah.."
                                    d3 "Pftt sure old man whatever."
                                    mc "That's my girl.."
                                    mc "But I can't help but ask, how long have you felt like this?"
                                    scene chasngem32 with dissolve
                                    d3 "I don't know..."
                                    d3 "I just feel that way."
                                    d3 "Is this wrong?"
                                    menu:
                                        "Yes":
                                            mc "Sadly yes, it's wrong.."
                                            d3 "Oh..."
                                            mc "But I don't know, Emma, I don't want to think about it right now."
                                            d3 "Okay [pD8]"
                                        "No":
                                            mc "Of course not, but still.."
                                            mc "At least you can have my opinion on your choices."
                                            d3 "How so?"
                                            mc "No matter who you want to be with, I have to approve of her first."
                                            mc "We'll have rules, of course."
                                            d3 "Like what?"
                                            mc "The first and most important rule is that, no boys!"
                                            d3 "Huh, jealous."
                                            mc "Rule number two, no activity will take place without my knowledge."
                                            d3 "Come to every date with me. Let's do everything side by side, huh [pD8]? "
                                            mc "Yeah, why not."
                                            d3 "Very, funny, a comedy genius!"
                                            mc "Yes, I am."
                                    d3 "So..."
                                    d3 "Are you ready [pD8]"
                                    mc "All set."
                                    scene chasngem31 with dissolve
                                    d3 "Good boii."
                                    mc "Oh C'mon..."
                                    d3 "You drive like an old man."
                                    d3 "Oh wait... You're old.."
                                    mc "I thought this was a good idea.."
                                    d3 "I think you should be happy about it, you can still think."
                                    mc "..."
                                    d3 "..."
                                    scene chasngem32 with dissolve
                                    d3 "[pD8].."
                                    mc "Yes, princess."
                                    scene chasngem33 with dissolve
                                    d3 "Can you hold my hand?"
                                    menu:
                                        "I can hold your hand forever":
                                            $persistent.gal3 = True
                                            $emma_r_points += 1
                                            mc "I can hold your hand forever.."
                                            scene chasngem34 with dissolve
                                            d3 "...."
                                            d3 "I love you [pD13]"
                                            mc "I love you too, honey..."
                                            jump v011JanetLScene
                                        "don't":
                                            $emma_r_points -= 1
                                            pause
                                            jump v011JanetLScene
label v011EndSchool_S1:
    play music "audio/school-hallway.mp3"
    menu:
        "Get out of school":
            scene bgbsmet1 with dissolve
            mc "Finally, the day is over."
            mc "..."
            scene bgbsmet2 with dissolve
            sm "Oh hey [mc], there's someone I want you to meet."
            menu:
                "meet":
                    jump v011EndSchool_Meet
label v011EndSchool_Meet:
    $v011mcGabyMeet = True
    scene bgbsmet4 with dissolve
    mc "Hey"
    sm "This is [mc]. Our new super star"
    gm "Nice to meet you [mc] "
    mc "And you are.."
    gm "You can call me Big Boss."
    menu:
        "Tease":
            mc "I'm sure I won't."
            gm "Hahah! A fearless man."
            sm "Or a man who has no idea who you are.."
            mc "It's not too hard to guess. He's probably, very, rich."
        "Don't":
            mc "Okay, Big Boss."
            gm "I like you already."
    gm "The name is Bill."
    mc "Nice to meet you, Bill."
    mc "If there's no other subject to talk about, may I excuse myself? "
    sm "It would be better if you joined us for coffee, huh [mc]?"
    mc "Hmm, actually, I don't like coffee, but I don't want to refuse my boss."
    gm "Do you think I'm cruel enough to force someone who doesn't like coffee to drink coffee, [mc]?"
    mc "Are you?"
    gm "We can discuss that while drinking our coffees."
    mc ".."
    gm "So, you're the teacher who will raise the grades."
    scene black
    "a while later.."
    scene bgbsmet5 with dissolve
    gm "This was a good meeting."
    gm "On my next visit, we'll talk about what's changed, what's stayed the same."
    sm "Yes, boss."
    gm "I'm sure you'll give me good news next time."
    menu:
        "Is that necessary?":
            mc "Will you constantly evaluate our performance?"
            gm "Yeah, is that a problem?"
            mc "Now that you ask like that, it's not"
            sm "[mc] a very witty man, boss."
            gm "I can see that.."
        "Sure":
            mc "Of course, sir."
            scene bgbsmet6 with dissolve
            sm "Actually, Bill comes to school once, maybe twice a year."
            scene bgbsmet7 with dissolve
            if chloe_r_points >=0:
                menu:
                    "Wink at Chloe":
                        scene bgbsmet8 with dissolve
                        play sound "audio/notify.mp3"
                        show screen lovePoint
                        $chloe_l_points += 1
                    "dont":
                        pause
            scene bgbsmet6 with dissolve
            sm "I think you're the reason for this surprise visit, [mc]."
            mc "I'm honored."
            gm "I hope you meet my expectations [mc]."
            mc "I will."
    scene bgbsmet9 with dissolve
    gm "Anyway, I'm relieved now. You may leave [mc]."
    mc "Thank you."
    sm "Visit me tomorrow before you go to class [mc]."
    mc "Sure, Charlotte."
    sm "Fine.."
    if v011mcCheckedEmmaPhone:
        mc "Well.."
        mc "I'm late... Emma's probably home already."
        mc "fuck.."
    jump v011JanetLScene
label v011JanetLScene:
    scene mchmbck with fade
    stop music fadeout 1.0
    #This part should be revisited.
    if v011mcWentChristian:
        if v011mcInterfereEmma:
            mc "God, what a day."
            mc "I'm so relieved that this Christian problem is over."
    mc "I'm really tired."
    mc "I feel like I don't have time for anything. Heading to bed early will be probably be the best choice tonight.."
    menu:
        "Go to your room":
            scene romcm1 with dissolve
            mc "Holy shit!"
    mc "That's what I call a great welcome!"
    scene romcm2 with dissolve
    wf "Welcome home handsome.."
    wf "Or should I call you.."
    $fabName = renpy.input("What would she call you?")
    wf "[fabName]"
    mc "Oh baby.. behave.."
    wf "Nope, I'm a naughty girl.."
    mc "I thought I was exhausted but, this... I'm fully charged now."
    mc "I want to make love with you for hours."
    wf "I need more than that to me."
    mc "Damn!"
    wf "So..."
    wf "What are you going to do to me first.."
    menu v011cS3:
        "Kissing with hand job":
            scene black
            scene wfv011roomkissing with fade
            mc "I can't get enough of you."
            wf "Mmmh!"
            mc "Come to me."
            wf "Here?"
            mc "Uh huh, it wasn't enough in the kitchen."
            wf "Yes [fabName]"
            mc "That's my girl!"
            jump v011cS3
        "Reverse ride":
            scene reverseani19 with dissolve
            mc "I like it when you're in control."
            wf "Oh... this is..."
            mc "Oh baby... Your ass is.. amazing.."
            wf "Anything for my [fabName]"
            menu:
                "Let her be dominant":
                    scene reverseani19 with dissolve
                    mc "I think I want to try being submissive."
                    wf "Oh.. okay, sure.."
                    wf "Uhm, honey, I don't know how to be dom.."
                    wf "What should I do or say.."
                    mc "Just talk bossy, I don't know.."
                    wf "..."
                    wf "Okay.."
                    scene black
                    scene wfv011revrsejigle with fade
                    wf "Tell me, how do you like my ass?"
                    mc "It's amazing!"
                    wf "Oh yeah, do you want it?"
                    mc "Yes!"
                    wf "Pathetic man..."
                    wf "Do you think you deserve this ass, huh?"
                    scene black
                    scene reverseani19 with dissolve
                    menu:
                        "Yes":
                            mc "Yes!"
                            wf "You make me sick!"
                        "No":
                            mc "No... I don't deserve that perfect ass mistress."
                            wf "You make me sick!"
                    wf "You want to put your pathetic dick inside my pussy don't you?"
                    mc "Yes, I want this so much!"
                    scene black
                    scene wfv011revrsejigle2 with fade
                    wf "How about my ass? Do you want to fuck my ass too?"
                    mc "Oh honey, you have no idea."
                    wf "Know your place, slave!"
                    mc "Yes.. my wife.."
                    wf "I'm your mistress!"
                    mc "I.."
                    mc "I don't think that's working."
                    wf "Oh, I'm so sorry, my love, I got carried away for a moment..."
                    mc "No... That is my fault."
                    wf "Wanna continue?"
                    mc "Yes, of course."
                    jump v011cS3
                "Regular":
                    scene reverseani19 with dissolve
                    mc "Let's do it normally."
                    wf "Whatever you want, my love."
                    wf "Are you ready?"
                    mc "You bet I am."
                    wf "I'll blow your mind!"
                    scene black
                    scene wfv011revrsejigle with fade
                    mc "Fuck, this is soo good!"
                    mc "Keep going, don't stop!"
                    scene black
                    scene wfv011revrsejigle2 with fade
                    wf "Ummmm!"
                    wf "I can ride you mmhh... all night.."
                    mc "You are the best... babe.."
                    wf "Ahmmm.."
                    wf "Do you...Uhmmmm... love me..?"
                    mc "Yes, I love you!"
                    mc "Fuck, I'm about the came"
                    menu:
                        "inside":
                            scene romcmv1 with vpunch
                            pause
                            scene romcmv2 with dissolve
                            mc "Phew, that was intense.."
                            wf "You were amazing.."
                            mc "Nothing new, huh."
                            wf "I'm amazing too!"
                            mc "Of course you are, honey."
                        "outside":
                            scene romcm14 with vpunch
                            pause
                            scene romcm15 with dissolve
                            mc "Phew, that was intense.."
                            wf "You were amazing.."
                            mc "Nothing new, huh."
                            wf "I'm amazing too!"
                            mc "Of course you are, honey."
                "Be dominant":
                    scene wfv011reversecg1 with fade
                    mc "Excuse me?"
                    mc "How dare you to ask me this!"
                    wf "What.."
                    mc "Shut up and shake that ass bitch!"
                    wf "Oh.. yes! Right now"
                    wf "So do you like it [fabName]"
                    mc "Shut up, you little slut!"
                    wf "Yes [fabName]!"
                    mc "Do you like my dick, you little bitch!"
                    wf "Oh... Uhmm... yes..."
                    mc "Don't you dare to talk back to me again!"
                    wf "Yes! Sorry! my [fabName]!"
                    mc "Who is my little bitch"
                    wf "I am!"
                    wf "I'm your little bitch"
                    wf "Can I put it in, please?"
                    mc "Sure, whatever.."
                    wf "Oh my!"
                    mc "Fuck, it's amazing!"
                    menu:
                        "cum":
                            menu:
                                "inside":
                                    scene romcmv1 with vpunch
                                    pause
                                    scene romcmv2 with dissolve
                                    pause
                                    mc "Phew, that was intense.."
                                    wf "You were amazing.."
                                    mc "Nothing new, huh."
                                    wf "I'm amazing too!"
                                    mc "Of course you are, honey."
                                "outside":
                                    scene romcm14 with vpunch
                                    pause
                                    scene romcm15 with dissolve
                                    pause
                                    mc "Phew, that was intense.."
                                    wf "You were amazing.."
                                    mc "Nothing new, huh."
                                    wf "I'm amazing too!"
                                    mc "Of course you are, honey."
                    scene romcm2 with dissolve
                    wf "Phew, that was amazing.."
                    wf "So ready to go again or enough?"
                    menu:
                        "sleep":
                            mc "We should better be sleeping."
                            wf "Oh... Okay.."
                            wf "I'm gonna shower then, wanna join?"
                            mc "Nah, too tired for a shower."
                            scene romcm19 with dissolve
                            pause
                        "continue":
                            jump v011cS3
        "Handjob":
            scene black
            scene wfv011hj1 with fade
            wf "You love this, don't you?"
            mc "Yes, baby, you drive me crazy."
            wf "Ummmm.."
            mc "Just keep doing this for now."
            wf "As your wish [fabName]"
            mc "Ugh, this is nice.."
            mc "Your hand is amazing babe."
            mc "So soft, firm, warm.."
            wf "Mhmmm mhmm"
            wf "Want me to change position [fabName]"
            scene wfv011hj2 with fade
            mc "It's getting more exciting every day..."
            wf "Yeah... It's like we just met, right?"
            mc "That was exactly what I thought!"
            menu:
                "cum":
                    scene romcm8 with dissolve
                    wf "Are you ready, my love."
                    menu:
                        "Aheago":
                            mc "Can you make an aheago face, honey?"
                            wf "Oh my..."
                            wf "I'm too old for this, my love.."
                            mc "Nonsense!"
                            wf "Okay, then I can try.."
                            scene romcm11 with dissolve
                            mc "Ahaha, worst aheago ever."
                            scene romcm12 with dissolve
                            wf "Ahahaha, stop making me laugh, baby, we are doing serious things right now!"
                            wf "But I'm not gonna fail you, here look at this!"
                            scene romcm13 with dissolve
                            mc "Holy shit!"
                            mc "You are surprisingly good at this, babe!"
                    scene romcm9 with vpunch
                    pause
                    scene romcm10 with dissolve
                    mc "Phew, that was intense.."
                    wf "You were amazing.."
                    mc "Nothing new, huh."
                    wf "I'm amazing too!"
                    mc "Of course you are, honey."
                    wf "Phew, that was amazing.."
                    wf "So ready to go again or enough?"
                    menu:
                        "sleep":
                            mc "We should better be sleeping."
                            wf "Oh... Okay.."
                            scene romcm19 with dissolve
                            pause
                        "continue":
                            jump v011cS3

                "don't":
                    jump v011cS3
        "Footjob":
            scene black
            scene wfv011feetjob1 with fade
            wf "Do you like this [fabName]"
            mc "I can't describe how you make me feel right now..."
            wf "Awww, you're so sweet!"
            mc "Your feet are sweet."
            mc "Now work those cute feet for me."
            wf "As your wish my [fabName]!"
            wf "do I do it well?"
            mc "You are a natural.. keep going."
            mc "Amazing..."
            wf "Wanna try another position [fabName]?"
            mc "Yeah, I want to see your beautiful face."
            wf "As your wish [fabName]"
            scene black
            scene wfv011fj2 with fade
            mc "You are so beautiful.."
            wf "You forgot something."
            menu:
                "cute":
                    mc "And so cute, of course!"
                "nasty":
                    mc "And nasty!"
            wf "As your wish, my love."
            mc "I'm close!"
            wf "Cum for me my [fabName], cum on my little feet!"
            mc "Fuck!"
            menu:
                "cum":
                    scene romcm17 with vpunch
                    pause
                    scene romcm18 with dissolve
                    pause
                    mc "Phew, that was intense.."
                    wf "You were amazing.."
                    mc "Nothing new, huh."
                    wf "I'm amazing too!"
                    mc "Of course you are, honey."
                    wf "Phew, that was amazing.."
                    wf "So ready to go again or enough?"
                    menu:
                        "sleep":
                            mc "We should better be sleeping."
                            wf "Oh... Okay.."
                            scene romcm19 with dissolve
                            pause
                        "continue":
                            jump v011cS3

                "don't":
                    jump v011cS3
            wf "Yeah... It's like we just met, right?"
            mc "That was, exactly what I thought!"
    scene mcwake1  with dissolve
    mc "Shit, I'm late."
    scene emptrom with dissolve
    mc "Everybody's out."
    mc "Nobody woke me up!"
    scene mout1 with dissolve
    pause
    scene mylnw1blr with fade
    pause
    scene bkwrmmi1 with fade
    pause
    scene bkwrmmi2 with dissolve
    play music "audio/bensound-tenderness.mp3" fadein 3.0
    mc "Huh, Where is everyone?"
    scene bkwrmmi3 with dissolve
    m1 "They left when you didn't show up."
    mc "Of course."
    mc "Why didn't you?"
    scene bkwrmmi4 with dissolve
    m1 "A quiet environment, very suitable for reading my book. Why should I leave?"
    menu:
        "What are you reading?":
            mc "What are you reading?"
            scene bkwrmmi5 with dissolve
            m1 "Maestro Fed."
            scene bkwrmmi6 with dissolve
            menu:
                "History":
                    scene bkwrmmi8 with dissolve
                    mc "He was a historian, wasn't he?"
                    m1 "No."
                    mc "Oh my bad."
                "Art":
                    scene bkwrmmi6 with dissolve
                    mc "I think it's a book about art."
                    m1 "It's the opposite."
                    mc "Oh, economics."
                    scene bkwrmmi7 with dissolve
                    m1 "Huh, not bad."
                "Economics":
                    scene bkwrmmi6 with dissolve
                    mc "Oh, I know him, economics book huh?"
                    m1 "Yes."
                    mc "Isn't it a little complex for you?"
                    m1 "I'll take that as an insult."
                    menu:
                        "Save it":
                            mc "No, you get me wrong."
                            mc "I wanted to say it is a 'little' complex."
                            mc "You should be reading more complex books."
                            scene bkwrmmi7 with dissolve
                            m1 "Nice save."
                        "Tease":
                            scene bkwrmmi8 with dissolve
                            mc "It must be too complex for a teen like you."
                            m1 "What do you know about me?"
                            m1 "Did you think this was the first book I ever read?"
                            menu:
                                "Compromise":
                                    mc "Yeah, you're right, my bad"
                                    m1 "Yes it is."
                                "Don't":
                                    mc "I thought a student your age should read more useful things."
                                    m1 "Uh huh, like what?"
                                    mc "Art, history, etc."
                                    scene bkwrmmi7 with dissolve
                                    m1 "Cute."
        "Class":
            scene bkwrmmi3 with dissolve
            mc "Well, let's start the lesson."
            m1 "What?"
            mc "Aren't you a student?"
            scene bkwrmmi5 with dissolve
            m1 "Yeah, right."
            mc "Then let's begin."
            scene bkwrmmi4 with dissolve
            mc "Today's lecture is ab.."
            m1 "Excuse me, can you speak more quietly? I'm trying to read my book."
            mc "Look, Mia."
            m1 "Miss Mia."
            menu:
                "get mad":
                    scene bkwrmmi3 with dissolve
                    mc "Look, Mia!"
                    m1 "Huh, man, it's easy to provoke you."
                    m1 "You have to be calmer in situations like this. You lose the people faster when you yell like this"
                "okay":
                    scene bkwrmmi10 with dissolve
                    mc "Fine, Miss Mia."
                    scene bkwrmmi11 with dissolve
                    mc "Did you feel that?"
                    m1 "Feel what?"
                    mc "Your ego just got a little bigger."
                    mc "And you know what that gets you?"
                    mc "A huge nothing."
                    scene bkwrmmi12 with dissolve
                    m1 "..."
    #wtf
    $v011cS4_0 = False
    $v011cS4_1 = False
    menu v011cS4:
        "go to principal" if not v011cS4_0:
            jump v011Principal
        "go to teachers' room" if not v011cS4_1:
            jump v011TeachersRoom
    jump v011McRoom
label v011Principal:
    scene mdrbir2 with fade
    mc "Hey"
    scene mdrbir5 with dissolve
    if v011mcGabyNotNow:
        sm "Any idea what you did yesterday?"
        mc "No, I don't, enlighten me."
        sm "That guy next to me was the big boss of the school, so he's your boss's boss."
        sm "You didn't even bother to meet him."
        mc "So."
        sm "So?"
        sm "You're playing with fire."
        menu:
            "get mad":
                $gaby_d_points += 1
                play sound "audio/notify.mp3"
                show screen dominancePoint
                scene mdrbir5 with dissolve
                mc "What're you getting at?"
                mc "It was off-hours."
                mc "I had a private issue."
                mc "I was in a hurry!"
                sm "I was going to introduce you."
                sm "And you left without any explanation, which was rude!"
                sm "Do you know how bad you make me look?"
            "I'm sorry":
                $gaby_r_points += 1
                mc "I'm very sorry."
                mc "I had a very urgent private issue, so I couldn't stay."
                scene mdrbir6 with dissolve
                sm "Fine, I'll tolerate it this time, but make sure it doesn't happen again."
                mc "Of course, Ms. Gaby."
    mc "why did you call me over today?"
    scene mdrbir3 with dissolve
    sm "Actually, nothing important, I called because I was wondering how it went."
    mc "Okay, for now, everything is fine, I had to start with one of my methods for extremely troubled students."
    mc "Honestly, I didn't think I'd resort to this method so soon."
    scene mdrbir4 with dissolve
    sm "Hmm."
    sm "What kind of method is this?"
    menu:
        "answer":
            mc "A technique based on reverse psychology, there are methods similar to this method,"
            mc "but I changed it to suit students.."
            sm "So you came up with this method yourself."
            mc "Yeah, we can say that"
            sm "Nice."
        "don't answer":
            mc "Too long to explain."
            mc "Just trust me on this."
            sm "Okay.."
    scene mdrbir6 with dissolve
    sm "All right, you may leave."
    mc "Before I go."
    menu:
        "Are you single?":
            mc "Ever since I came to the interview, I've been wondering something."
            scene mdrbir7 with dissolve
            sm "What?"
            mc "Is there anyone in your life?"
            scene mdrbir8 with dissolve
            sm "[mc] aren't you married?"
            mc "Are married people forbidden to ask this question?"
            sm "This is none of your business."
            menu:
                "Push":
                    scene mdrbir9 with dissolve
                    mc "Look, you have lots of burden on your shoulders. I can see it."
                    mc "Even the most powerful people become weaker from loneliness."
                    scene mdrbir11 with dissolve
                    sm "So what, Am I going to share my loneliness with you?"
                    mc "I was thinking more about a massage."
                    sm "Huh?"
                    mc "A good massage can take the stress of a tiring day."
                    sm "What's your motivation for that?"
                    mc "It's good for me to massage an attractive woman, so it's a mutual situation."
                    sm "Ahah, how cute, no thanks, I have a separate masseur for all the discovered massages in the world."
                    sm "I don't need the crappy massage you learned online."
                    mc "All the women I've massaged so far have been extremely pleased. If you know what I mean?"
                    scene mdrbir12 with dissolve
                    sm "..."
                    sm "No thanks.."
                    mc "As your wish, but these fingers are ready to serve you whenever you want."

                "Don't":
                    mc "Okay then."
        "How old are you?":
            mc "You look so young, but how many years have you worked for to get so much experience, power and success?"
            scene mdrbir13 with dissolve
            sm "That must be the most original way to ask a woman her age."
            sm "How old do I look?"
            mc "25."
            sm "How charming."
            mc "Seriously, how old are you?"
            sm "None of your business."
            mc "40?"
            scene mdrbir10 with dissolve
            sm "Get out!"
            mc "Hmm, 36?"
            sm "I'm serious, get out!"
            mc "I've already got the answer from your reactions."
            sm "..."
            mc "See you."
            sm "Asshole.."
        "Your past":
            mc "How did you get to this point?"
            scene mdrbir12 with dissolve
            sm "What do you mean?"
            mc "To get where you are, you must have done things you're not proud of."
            sm "....."
            mc "Who is Charlotte Gaby? Inside?"
            scene mdrbir11 with dissolve
            sm "What is this? Where are you going with this?"
            mc "It's like you have a face you don't show anyone."
            sm "You are insulting me right now."
            mc "I'm just curious about the real Gaby."
            scene mdrbir12 with dissolve
            sm "Trust me [mc], the real Gaby is a lot more dangerous than the current Gaby, so I hope she never gets out."
            mc "That has made me even more curious."
            sm "Don't you have a class to take care of?"
            mc "Yeah, you're right, thanks for the chat. That was fun."
            sm "Get out."
    $v011cS4_0 = True
    jump v011cS4
label v011TeachersRoom:
    scene tcrsom1
    pause
    scene bgsda12
    $ renpy.movie_cutscene("animation/v011/t1intro.webm")
    pause
    scene tcrsom2 with dissolve
    mc "Oh hey, we haven't met before. I'm [mc]"
    menu:
        "peek":
            scene tcrsom3 with dissolve
            pause
        "don't":
            pause
    tc1 "Hey, nice to meet you, I'm Clara."
    scene tcrsom4 with dissolve
    pause
    scene tcrsom5 with dissolve
    pause
    scene tcrsom6 with dissolve
    tc1 "You've just started, haven't you?"
    mc "Yeah, it's my second day."
    tc1 "How nice, I think you're already thinking about quitting."
    mc "What? No, why?"
    tc1 "Well, they are all little monsters."
    menu:
        "Do you love monsters":
            mc "And why didn't you quit, do you like monsters?"
            scene tcrsom12 with dissolve
            tc1 "Ahaha yeah.."
            tc1 "I need this job.."
            mc "Maybe I do, too."
            tc1 "I think everyone would endure this torture for this salary."
        "I like monsters":
            mc "I've seen worse."
            mc "I'm not afraid of them."
            scene tcrsom7 with dissolve
            tc1 "It's their families you should be afraid of."
            mc "I know about that."
            mc "We'll see."
            tc1 "Good luck with that."
            scene tcrsom6 with dissolve
    tc1 "There's a rumor about you, is it true?"
    mc "Depends on what it's about."
    scene tcrsom10 with dissolve
    tc1 "Oh, Mr. [mc] behave.."
    tc1 "About how good you are at your job, of course."
    mc "Oh... I'm alright."
    scene tcrsom12 with dissolve
    tc1 "I wonder how successful you'll be"
    tc1 "Can I ask you something [mc]"
    mc "Sure."
    scene tcrsom14 with dissolve
    tc1 "Are you married?"
    menu:
        "Yes":
            mc "Yes, I'm married."
            scene tcrsom11 with dissolve
            tc1 "Oh.."
            tc1 "Of course you're married.. it would be unreal if such a man wasn't taken."
            menu:
                "Cold response":
                    $clara_r_points -= 1
                    mc "Yeah."
                    tc1 "..."
                "Warm response":
                    $clara_r_points += 1
                    mc "I think an attractive woman, who says such beautiful things, must also be taken."
                    scene tcrsom10 with dissolve
                    tc1 "Ahaha, it seems that the marriage did not take your silver tongue from you."
                    mc "Marriage didn't take anything from me, Clara."
                    scene tcrsom12 with dissolve
                    tc1 "How nice.."
                    mc "And?"
                    tc1 "Oh, I forgot to answer, right."
                    tc1 "I'm married too."
                    mc "How nice."
                    scene tcrsom11 with dissolve
                    tc1 "Not exactly, we live an extremely boring married life. We've been like roommates lately."
                    mc "Oh, that sucks.."
                    tc1 "How's your marriage going?"
                    menu:
                        "boring":
                            $mc_bad_points += 1
                            mc "I think it's monotonous, boring, like yours."
                            scene tcrsom12 with dissolve
                            tc1 "Oh, that sucks.."
                            mc "That was my line, Clara."
                            scene tcrsom10 with dissolve
                            tc1 "Ahaha yeah right, how can a fun, fit, and handsome man like you have a monotonous married life?"
                            tc1 "I wonder, if your wife is boring.."
                            scene tcrsom12 with dissolve
                            menu:
                                "get mad":
                                    $clara_r_points -= 1
                                    mc "Excuse me, but you're talking about my wife, please know your place."
                                    tc1 "Sorry.."
                                    mc "Anyway, I'll go to class."
                                    scene tcrsom13 with dissolve
                                    #EndClara
                                "yes she is":
                                    $persistent.gal8 = True
                                    $clara_r_points += 1
                                    $mc_bad_points += 1
                                    scene tcrsom9 with dissolve
                                    "I hate doing this, but my gut tells me to do it..."
                                    mc "Yeah, she is kinda boring.."
                                    "She's not. She is so funny and crazy."
                                    mc "But she's the [pD26] of my [pD27]."
                                    scene tcrsom14 with dissolve
                                    tc1 "Aww, you have [pD27], too?"
                                    mc "Yup 3 girls."
                                    tc1 "Oh my, how adorable!"
                                    mc "You?"
                                    tc1 "I have a [pD2] too"
                                    mc "She must be so lucky to have a [pD10] like you."
                                    tc1 "Silver tongue is on the attack again, huh."
                                    mc "You have no idea what this silver language can do."
                                    scene tcrsom15 with dissolve
                                    tc1 "Hmm.."
                                    tc1 "So..."
                                    tc1 "How about adding a little excitement to our monotonous lives, [mc]"
                                    menu:
                                        "I'm in":
                                            $clara_r_points += 1
                                            mc "Hmm, what's in your head?"
                                            scene tcrsom17 with dissolve
                                            tc1 "You have to find out, and I wonder how you're gonna do it."
                                            mc "I have my methods.."
                                            tc1 "Oh yeah, like what?"
                                            scene tcrsom18 with dissolve
                                            mc "Do you trust me?"
                                            tc1 "No.."
                                            mc "Good, it's much more exciting this way."
                                            scene tcrsom19 with dissolve
                                            tc1 "Oh my..."
                                            tc1 "What are you gonna do to me.."
                                            mc "I'll learn what's going on in your head."
                                            tc1 "So how are you gonna do that?"
                                            mc "Like this.."
                                            scene wfv011tcrhndlck with fade
                                            pause
                                            scene tcrsom21 with dissolve
                                            tc1 "Did you learn?"
                                            mc "Yes."
                                            tc1 "Was it beautiful?"
                                            mc "Oh yes, baby."
                                            tc1 "You wanna know more?"
                                            mc "You know I do."
                                            tc1 "Right now, right here?"
                                            mc "Whenever, wherever.."
                                            scene black
                                            scene tcrsom22 with dissolve
                                            att "Oh hey guys."
                                            tc1 "Hey Clara."
                                            mc "Anyways, I have to go."
                                            if chloe_r_points >=0:
                                                att "Is everything okay, Mr. [mc]?"
                                                mc "Sure, I'm just in a hurry."
                                                att "Of course, have a good day."
                                                mc "You too."
                                        "No thanks":
                                            $clara_r_points -= 2
                                            scene tcrsom17 with dissolve
                                            mc "That sounds perfect, but there's enough excitement in my life right now..."
                                            scene tcrsom12 with dissolve
                                            tc1 "Oh, I thought..."
                                            menu:
                                                "give her hope":
                                                    $clara_r_points += 1
                                                    mc "No no, I'm just not ready for some things right now..."
                                                    scene tcrsom10 with dissolve
                                                    tc1 "Oh, okay then, I hope I feel ready when you're ready."
                                                    "Huh, tough cookie."
                                                "don't":
                                                    $clara_r_points -=1
                                                    scene tcrsom12 with dissolve
                                                    mc "Yeah, that was my bad.., I love flirting, but the thought of actually cheating on my [pD9] made me a little uncomfortable."
                                                    mc "Please don't get me wrong Clara, you are a very beautiful, and attractive woman, but.."
                                                    scene tcrsom11 with dissolve
                                                    tc1 "It's ok [mc], your [pD9] is a very lucky woman..."
                        "tell the truth":
                            $mc_good_points += 1
                            scene tcrsom6 with dissolve
                            mc "I can't say boring or monotonous, it's more exciting lately."
                            tc1 "Like?"
                            mc "We decided to spice up our sex life. So far we've always lived ordinary lives, our sexuality included, but recently we've both started to try different fetishes."
                            scene tcrsom15 with dissolve
                            tc1 "How nice.."
                            mc "Oh sorry, even though we just met, I started talking about my sex life."
                            tc1 "No, it's okay. I think it's more interesting than other conversations."
                            menu:
                                "Ask about her sex life":
                                    mc "If it's more interesting, then I'll ask about your sex life if it's not inappropriate."
                                    tc1 "Well.."
                                    scene tcrsom11 with dissolve
                                    tc1 "Our sex life is not as interesting as yours.."
                                    mc "Something wrong?"
                                    tc1 "Well, my husband and I haven't been together for a long time, so there's not much sex life to tell."
                                    mc "Huh, that sucks..."
                                    tc1 "Tell me about it."
                                    menu:
                                        "Make a move":
                                            $persistent.gal7 = True
                                            $clara_r_points += 1
                                            mc "I'm sure you'll meet someone who can solve this problem, Miss Clara."
                                            scene tcrsom14 with dissolve
                                            tc1 "You mean a sex therapist or something like that?"
                                            mc "Yeah, it could be, or it could be someone else..."
                                            scene tcrsom17 with dissolve
                                            tc1 "Uh huh, like a colleague?"
                                            tc1 "You'll join us or something?"
                                            mc "I never share. Just you and me."
                                            tc1 "Mhmm hmm.."
                                            tc1 "Well, I'm getting wet.."
                                            mc  "Let me feel it.."
                                            tc1 "Hmm, is that so..."
                                            scene tcrsom22 with fade
                                            att "Oh hey guys."
                                            tc1 "Hey Clara."
                                            mc "Anyway, I have to go."
                                        "Don't":
                                            scene tcrsom22 with fade
                                            att "Oh hey guys."
                                            tc1 "Hey Clara."
                                            mc "Anyway, I have to go."
                                            if chloe_r_points >=0:
                                                att "Is everything okay, Mr. [mc]?"
                                                mc "Sure, I'm just in a hurry."
                                                att "Of course, have a good day."
                                                mc "You too."


                                "Don't":
                                    scene tcrsom22 with dissolve
                                    mc "Anyway, I'm very pleased to meet you."
                                    tc1 "Me too, Mr. [mc]"
                                    mc "Well... See you around."
                                    tc1 "You will..."
        "No":
            $clara_r_points -= 1
            $mc_bad_points += 1
            mc "Umm no, I'm not married."
            scene tcrsom20 with dissolve
            tc1 "Oh... Is that so."
            mc "Yup."
            tc1 "And you're not too."
            mc "What?"
            tc1 "I can see the ring.."
            mc "Oh that... that ring is..."
            scene tcrsom16 with dissolve
            tc1 "No need to explain Mr. [mc]"
            "Fuck me.."
        "Why?":
            $clara_r_points -= 1
            scene tcrsom12 with dissolve
            mc "Why do you ask?"
            scene tcrsom11 with dissolve
            tc1 "No reason."
            mc "Huh, weird."
            tc1 "Okay.."
            scene tcrsom14 with dissolve
            mc "Anyway, I'd like to ask you about some students when you have time."
            tc1 "Oh sure, we'll have coffee somewhere."
            mc "I think we can do this at school."
            tc1 "Yeah right, silly me.."
            mc "Uh huh."
            mc "Anyway, I'll go to my office."
            tc1 "Did they give you an office?"
            mc "Yeah, is that weird?"
            tc1 "We thought you were a teacher like us."
            mc "Maybe I'm a little more."
            mc "I don't give students high grades because I'm afraid of them."
            tc1 "....."
            mc "Have a good day, miss..."
            tc1 "Clara, I told you before.."
            scene tcrsom13 with dissolve
            mc "Right Clara."
    $v011cS4_1 = True
    jump v011cS4
label v011McRoom:
    scene ofcphne1 with dissolve
    mc "Supposedly the richest college in the country."
    mc "Look at the room they gave me!"
    mc "I'm probably drunk on power, for the first time, I have my own room, and I don't like it."
    mc "Anyway, time to work."
    play sound "audio/knock.mp3"
    pause
    mc "Come in."
    play sound "audio/door-open.mp3"
    scene colgrl1 with dissolve
    pg "Hey, teacher."
    menu:
        "xxslut69xx":
            mc "Hey, xxslut69xx."
            scene colgrl2 with dissolve
            pg "Damn, you kept it in your memory?"
            pg "Respect."
            mc "I guess that's not your real nickname."
            pg "Pfft of course not, my real nickname is much sexier."
            pg "But, aren't you supposed to keep more important things in your memory?"
            menu:
                "Tease":
                    scene colgrl3 with dissolve
                    mc "Cool, I don't need to search for this nickname on onlyfans sites."
                    pg "Look at what this old man knows."
                    scene colgrl4 with dissolve
                    pg "If you're wondering about my page, I can email you, along with a few encouraging images."
                    mc "Cute."
                "I'm smart":
                    scene colgrl3 with dissolve
                    mc "Don't worry, my memory capacity is too big to be filled with garbage."
                    scene colgrl6 with dissolve
                    pg "Huh, kitty got claws, I like that"
                    mc "And you're not allowed to sit at my desk."
                    scene colgrl7 with dissolve
                    pg "Where does it say it's forbidden?"
                    mc "I'm saying it."
                    mc "My room, my rules."
                    scene colgrl8 with dissolve
                    pg "Ugh fine.."

        "Yes":
            mc "Hey, whatever your name is"
            scene colgrl3 with dissolve
            pg "How rude, I told you my name in class."
    mc "So,"
    mc "What do you want?"
    scene colgrl4 with dissolve
    pg "Isn't it inappropriate to talk to a student like that dear teacher?"
    mc "I don't think you care."
    scene colgrl5 with dissolve
    pg "True."
    mc "Yes, I'm listening to you."
    scene colgrl8 with dissolve
    pg "Hmmm."
    pg "I have a question."
    mc "What is it?"
    pg "A math question."
    mc "Okay, show me."
    scene colgrl9 with dissolve
    pg "Let me write it on your computer."
    mc "You can write it on paper."
    scene wfv011pgjiggle
    pg "I hate this ancient stuff."
    mc "A perfect generation is growing up."
    pg "Shut up, old man."
    pg "So.. what do you think."
    if persistent.patch_installed==True:
        jump v011PgScene
    else:
        menu:
            "Tease":
                mc "I thought you were smart."
                mc "You couldn't solve this question??"
            "Let me see":
                mc "I can't see the question. You're blocking me."
        scene colgrl12 with dissolve
        mc "I think I should show you how to solve this question when I have more time. You don't even know the subject."
        mc "And you're sitting at my desk again..."
        pg "Ahaha yeah."
        mc "Did you have fun?"
        scene colgrl13 with dissolve
        pg "Yes."
        mc "Yeah, I guess you're less boring than I thought."
        pg "I like you, old man."
        mc "Teacher."
        pg "Sure, I can call you whatever you want."
        pg "But 'teacher' is.. not that charming."
        pg "What about [pD28]?"
        mc "Please don't say that"
        pg "Why?"
        mc "Just call me teacher."
        mc "Because I'm your teacher."
        mc "If you have no other question, I want to get back to work."
        scene colgrl14 with dissolve
        pg "Nope, that was it"
        pg "Oh, one thing."
        scene colgrl15 with dissolve
        pg "See you soon [pD28].."
        "She is weird... But cute"
        "Ugh, I feel tired.."
        "I've been through a lot the last two days."
        "It's time to visit my therapist."
    menu:
        "Call your therapist":
            scene ofcphne1 with dissolve
            pause
            jump v011Therapist
label v011Therapist:
    scene ofcphne1 with dissolve
    pause
    scene ofcphne with dissolve
    play sound "audio/dial-sound-effect.mp3"
    pause
    mc "Hey."
    stop sound
    scene ofcphne2 with dissolve
    tp "Hey [mc], everything okay?"
    mc "Yeah, {w}no.."
    mc "Can I see you today?"
    tp "Hmm, as you know, I have an appointment system, [mc]..."
    menu:
        "get mad":
            $persistent.gal5 = True
            scene ofcphne with dissolve
            mc "Are you busy right now?! Do you have a patient?"
            tp "No, I don't have a patient, but as I said, this is not professional?"
            mc "Isn't that ironic, after the advice you gave me?"
            tp "..."
            tp "You're right, then we can meet today."
            mc "Cool, on my way."
        "I know":
            scene ofcphne2 with dissolve
            mc "Yeah, I'm aware of that, but I've been through a lot since our last meeting, and I need this session right now."
            tp "Hmm.."
            tp "Sure, today we can have a session, can you come now?"
            mc "Thanks, on my way."
    scene ofcphne1 with dissolve
    menu:
        "Go to your car":
            scene sclotfrv1 with fade
    scene sclotfrv2 with dissolve
    mc "What the hell?"
    scene sclotfrv4 with dissolve
    mc "What do you want?"
    scene sclotfrv3 with dissolve
    "Just want to talk."
    mc "I think you're lost, this isn't a pub."
    "Perhaps I wasn't clear."
    mc "I'm in a hurry, I can't deal with this shit right now."
    mc "Go and tell Gaby that [mc] is so tired of this nonsense."
    "Wrong guess, I'm not working for Gaby."
    mc "I don't care who you work for, get out of my way."
    "Or what?"
    menu:
        "Threaten him":
            mc "Or I will kick your ass."
            "A teacher will kick my ass, huh?"
            mc "You would be surprised."
            mc "Now back off."
            scene sclotfrv3 with dissolve
            "Okay okay, I want no trouble too."
            "But there's something important I want to talk to you about."
            mc "Cool, whatever it is, it can wait."
            "As your wish."
        "Negotiate with him":
            scene sclotfrv4 with dissolve
            mc "Are you sure you want to do this?"
            mc "I'm guessing you're here to intimidate me right now."
            mc "But the parking lot is full of cameras. I'm sure your boss won't be too happy about this stupidity you've done."
            mc "So just back off."
            scene sclotfrv3 with dissolve
            "[mc] I just want to talk to you."
            mc "How do you know my name?"
            "That's not important, what is important is.."
            mc "Look, I'm in a hurry right now, whatever you want to talk about, we can talk about it later."
            "As your wish.."
    scene rbecr1 with dissolve
    mc "Fuck is wrong with this school.."
    scene trptw1 with fade
    pause
    scene trptw2 with dissolve
    stop music fadeout 3.0
    pause
    scene trptw3 with dissolve
    play music "audio/therapy.mp3" fadein 3.0
    tp "Welcome [mc], please take a seat"
    mc "Thank you for accepting me today."
    mc "I took the job."
    scene trptw4 with dissolve
    tp "That's great."
    scene trptw5 with dissolve
    tp "You're finally moving on."
    mc "Yeah, I got a lot to talk to you about."
    tp "Yes, of course."
    scene trptw16 with dissolve
    play sound "audio/ringtone-sound-effect.mp3"
    mc "Oh sorry... May I?"
    tp "No problem."
    scene trptw17 with dissolve
    stop sound
    mc "Hello?"
    "Hey, is this [mc]?"
    mc "Yes, this is him"
    "Uhmm, I need your help."
    mc "Who are you?"
    "I was told to contact you."
    mc "By whom?"
    "I can't say it."
    mc "Uh huh, call me again when you feel like you can say it."
    "Wait, wait, don't hang up, it's urgent."
    mc "Look I am a very busy man, I don't have time for this kind of shit."
    "It's about your [pD21] okay."
    scene trptw18 with dissolve
    mc "What happened!"
    "It's complicated, you have to come here."
    mc "Okay okay, I will, send me the address."
    "Hurry up."
    mc "If this is a prank, I'll find you."
    scene trptw19 with dissolve
    mc "I'm sorry, I have to go."
    scene rbecr1 with dissolve
    mc "I didn't ask which [pD21] she was talking about..."
    mc "It's probably Luna. But it could be Ruby too, fuck I'm so stupid."
    mc "I should call Amy."
    scene rbecr2 with dissolve
    mc "Fuck fuck fuck, her phone is switched off!"
    mc "Ruby.."
    scene rbecr2 with dissolve
    mc "Hers too? I have to hurry!"
    scene rbe1 with dissolve
    pause
    scene rbe2 with dissolve
    play sound "audio/knock.mp3"
    scene rbe3 with dissolve
    rb "Yaay [pD14] you came!"
    scene rbe4 with dissolve
    mc "Is everything okay, honey?"
    rb "Yes, why?.."
    mc "Uhmm, nothing sweety.."
    mc "Where is [pD39]?"
    scene rbe6 with dissolve
    rb "At work."
    mc "Why are your phones turned off?"
    rb "I don't know, maybe no charge?"
    mc "I see."
    scene rbe5 with dissolve
    rb "Come in, Why are we talking here?"
    mc "I'm sorry, honey, but I have to go."
    scene rbe6 with dissolve
    rb "Oh.."
    mc "Baby, did Luna's phone number change?"
    rb "I guess..."
    "Fuck.. What now.."
    mc "Do you know where she was last?"
    rb "[pD14] is everything okay?"
    rb "Did something happen to Luna?.."
    mc "What of course no.."
    mc "I found a great job for Luna, so I need to talk to her right now."
    scene rbe4 with dissolve
    rb "Oooh, okay."
    rb "Luna's probably with her friends."
    rb "They usually meet in the park behind Northside College."
    mc "Thank you so much, honey, see you soon."
    scene rbe7 with dissolve
    rb "See you soon, [pD14]!"
    mc "Hmm... Same address."
    scene black
    scene lnev1 with dissolve
    stop music fadeout 3.0
    mc "I think this is it"
    scene lnev2 with dissolve
    mc "Hey."
    mc "I'm looking for a girl named Luna. Do you know her?"
    "There's no Luna here. You should leave"
    mc "I don't think you'll help."
    "....."
    mc "Another way to say yes."
    mc "Okay then."
    scene lnev3 with dissolve
    mc "Hey."
    "Yes?"
    mc "I'm looking for a girl named Luna, and I've been informed that she's here."
    mc "You know her?"
    "Luna, huh?"
    mc "Yes."
    "Pretty name, isn't it."
    mc "Yes, you know her?"
    "You should leave."
    mc "Ugh.."
    mc "Look, this girl could be in danger, if you know something, tell me."
    "..."
    mc "Hey!"
    mc "Fucking brat."
    scene lnev4 with dissolve
    mc "Look I don't have time, I'm looking for a girl named Luna!"
    "You should go back."
    mc "Excuse me?"
    " I said get out."
    mc "Or?"
    scene lnev5 with dissolve
    "..."
    "She's up there."
    mc "That wasn't so hard, huh.."
    scene lnev7 with dissolve
    "What kinda place is this.."
    scene lnev8 with dissolve
    "What did you do, Luna?.."
    scene lnev9 with dissolve
    pause
    scene lnev12 with dissolve
    "Well, where is she?"
    scene lnev13 with dissolve
    pause 0.2
    scene lnev14 with vpunch
    play sound "audio/hitonhead.mp3"
    pause
    scene lnev15 with dissolve
    $persistent.gal12 = True
    pause
    scene lnev11 with dissolve
    pause
    scene reeeqr35
    $ renpy.movie_cutscene("animation/v011/Lunaending.webm")
    pause
    scene eprlg1 with dissolve
    pause
    scene eprlg2 with dissolve
    mc "What the.."
    ln "Sushh"
    ln "You're gonna hate me when I say this but"
    $config.allow_skipping = False
    ln "This is the end [pD14].."
    ln "End of v0.1"
    scene black
    pause 2.0
    jump v02begin
