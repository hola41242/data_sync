image CLcimd = Movie(play = "animation/v035/CLcimd.webm")
image Luarkhz = Movie(play = "animation/v035/Luarkhz.webm")
image Luarkyav = Movie(play = "animation/v035/Luarkyav.webm")
image Luonhz = Movie(play = "animation/v035/Luonhz.webm")
image Luonyav = Movie(play = "animation/v035/Luonyav.webm")
image Nocls = Movie(play = "animation/v035/Nocls.webm", loop = False)
image Notpe = Movie(play = "animation/v035/Notpe.webm")
image Rudrt = Movie(play = "animation/v035/Rudrt.webm")

image a_rqby143:
    "rqby143" with Dissolve(0.1, alpha=True)
    0.8
    "rqby144" with Dissolve(0.1, alpha=True)
    0.8
    repeat

label v035:
    $config.allow_skipping = True
    scene clnrem1 with Fade(1.5, 1.0, 0.5)
    d1 "I'm listening!"
    scene clnrem3v2 with dissolve
    d2 "Claire.."
    d2 "I just woke up.."
    d2 "What exactly are you listening to?"
    scene clnrem2 with dissolve
    d1 "Something you promised before"
    scene clnrem3 with dissolve
    d2 "Hmm what could it be?"
    scene clnrem4 with dissolve
    d1 "How many promises do you make every day Nora"
    scene clnrem6 with dissolve

    d2 "You'd be surprised.."
    scene clnrem7 with dissolve

    d1 "C'mon [pD77], {w}the kitchen, remember?"
    scene clnrem9 with dissolve

    d1 "When we watched [pD8] and [pD10] together"
    scene clnrem10 with dissolve

    d1 "I'm ready!"
    d2 "Oh yeah, that.."
    scene clnrem7v2 with dissolve

    d1 "Now teach me. Use me as an object, an empty object."
    scene clnrem8 with dissolve

    d1 "Fill me with your knowledge [pD77]!"
    scene clnrem11 with dissolve

    d2 "Wow"
    d2 "It is very ironic that all these sentences come from someone who is really innocent."
    scene clnrem12 with dissolve

    d1 "I don't understand anything at all!"
    scene clnrem15 with dissolve

    d2 "Well, the sentences you choose are used ironically to refer to something else."
    scene clnrem13 with dissolve

    d1 "Refer to what!"
    d2 "Let's begin with the basics, okay?"
    scene clnrem14 with dissolve

    d1 "Yay! Basics!"
    scene clnrem16 with dissolve

    d2 "Uh huh{w}, yay indeed."
    d2 "Let me ask you a few questions about this, to see how much you know."
    d1 "Shoot!"
    d1 "I am ready to give all my answers!"
    scene clnrem15 with dissolve

    d2 "How amazing.."
    d2 "Question one: "
    scene clnrem14 with dissolve

    d2 "How well do you know the differences between men and women?"
    scene clnrem13 with dissolve

    d1 "Oh it's just male and female! That will be so easy!"
    scene clnrem15 with dissolve

    d1 "And I thought we were going to talk about all genders."
    scene clnrem16 with dissolve

    d1 "It's great if we're only going to talk about 2 of them!"
    d2 "These are already all genders."
    d1 "No way, there were hundreds of them when I looked on the Internet, [pD77]"
    scene clnrem11 with dissolve

    d2 "Oh boy.."
    scene clnrem17 with dissolve

    d2 "Those genders are not..."
    d1 "Are not what?"
    scene clnrem18 with dissolve

    d2 "Hmmm"
    d2 "Let's just talk about 2 genders, and I'll choose 2 genders completely randomly, okay?"
    scene clnrem19 with dissolve

    d1 "Yes!"
    scene clnrem17 with dissolve

    d2 "Hmm let's just say... male and female, I chose completely at random, what a surprise, right huh?"
    scene clnrem19 with dissolve

    d1 "Yes I'm so shocked, let's go!"
    scene clnrem22 with dissolve

    d2 "What is the main difference between male and female?"
    d1 "Hah easy one"
    d1 "Male is [pD13], female is [pD10]"
    scene clnrem21 with dissolve

    d2 "Your answer is right and wrong at the same time."
    d2 "No I mean.."
    d2 "What are the differences that you see in a man and a woman?"
    scene clnrem15 with dissolve

    d1 "Hmm, the men are big, strong, and they almost always dress the same."
    d1 "More precisely, they dress much less conspicuously than women. Isn't that weird Nora?"
    d2 "It is actually.."
    d2 "Huh that's a pretty good answer, Claire"
    scene clnrem13 with dissolve

    d1 "Yaaay"
    scene clnrem15 with dissolve

    d2 "But.."
    d1 "It's not the kind of answer you want"
    d2 "Exactly"
    scene clnrem17 with dissolve

    d1 "Hmmm, oh oh oh I found!"
    scene clnrem12 with dissolve

    d1 "Tataaaaaaaas"
    d2 "Huh?"
    scene clnrem20 with dissolve

    d1 "I meant these."
    scene clnrem22 with dissolve

    d2 "You mean the breasts?"
    d2 "Yes breasts."
    scene clnrem17 with dissolve

    d1 "We have these but boys don't."
    d2 "Yes, the body composition of men and women is different"
    scene clnrem23 with dissolve

    d1 "Booooh"
    d2 "What?"
    scene clnrem25 with dissolve

    d1 "Do not use such complex words [pD77]"
    d1 "Make it simple!"
    d2 "Some things should not be kept simple, Claire"
    d1 "Like what?"
    scene clnrem24 with dissolve

    d2 "We can not simplify the meaning of some words"
    d2 "Because of the prevalence"
    scene clnrem26 with dissolve

    d2 "If you want to be a well-equipped and complicated woman in the future"
    d2 "Claire..."
    scene clnrem27 with dissolve

    d1 "Huh? What?"
    scene clnrem28 with dissolve

    d2 "Stop sleeping when I'm trying to teach you something.."
    scene clnrem30 with dissolve

    d1 "But it is so boooooooooooring."
    d2 "Yeah it is..."
    scene clnrem29 with dissolve

    d1 "Also"
    d1 "I can also teach you without using these complicated words."
    d2 "True"
    d2 "But some professional groups need these words."
    d1 "Name one?"
    d2 "Politicians"
    d2 "They can make the lies they tell look like a positive and right decision for the future."
    d2 "They literally make sentences that cannot be doubted, so the majority of people think that everything is fine, because what is described is shown as a positive thing."
    d1 "But why do people perceive words that they don't understand as if it's a good thing?"
    d2 "Because they desperately want to connect to something."
    d2 "Instead of understanding, they rely on the judgment of the person in charge."
    d2 "It's easier for them that way. To always believe in a power superior to their own, and not to question it."
    d1 "That's stupid.."
    d2 "With a single statement of opinion, you can become both a sinner and a traitor."
    d1 "What!"
    d2 "This is how governments and religions work"
    scene clnrem30 with dissolve

    d1 "Nora please just tell me what you promised to tell.."
    d1 "Everything you tell me about real life is dragging me into the dark..."
    d2 "Ok then let's get back to our topic."
    d2 "Have you ever wondered why women have them and men don't?"
    scene clnrem31 with dissolve

    d1 "Never!"
    scene clnrem31v2 with dissolve

    d1 "Wait, I'm so tired of these clothes I'll change"
    d2 "All of a sudden?"
    scene clnrem32 with dissolve

    d1 "Yeah"
    d2 "But why, are you sweating?"
    scene clnrem33 with dissolve

    d1 "No, I'm just bored Nora"
    d2 "You're just bored huh.."
    scene clnrem34 with fade

    d1 "Tadaaa"
    scene clnrem35 with dissolve

    d1 "How do I look?"
    scene clnrem36 with dissolve

    d2 "Huh, you don't usually dress like this"
    d2 "Plain and black..."
    scene clnrem37 with dissolve

    d2 "What is going on, Claire?"
    scene clnrem38 with dissolve

    d1 "Nothing!"
    d2 "Claire.."
    d1 "Well.."
    d1 "I've been enjoying dressing up like this lately."
    d2 "Why is that?"
    scene clnrem39 with dissolve

    d1 "I don't know."
    scene clnrem40 with dissolve

    d2 "Hmmm"
    scene clnrem41 with dissolve

    d2 "I have a theory, but I need to observe it a little to make sure."
    d1 "So how do I look Nora?"
    scene clnrem42 with dissolve

    d2 "Cute and pretty."
    scene clnrem44 with dissolve

    d1 "Oh my god, 2 compliments at the same time!"
    d2 "Yes."
    scene clnrem43 with dissolve

    d2 "Can we continue?"
    d1 "Yes please."
    d2 "Breasts are basically the dining table for children."
    scene clnrem46 with dissolve

    d1 "Yum!"
    d2 "Yeah yum."
    d2 "Because women are fertile, their bodies have evolved accordingly."
    d2 "Breasts really have a lot of functions, but the most common and well-known function is breastfeeding."
    d2 "If a woman becomes pregnant, she begins to produce milk."
    scene clnrem45 with dissolve

    d1 "Is that why they're big?"
    d2 "That depends."
    d1 "Depends on what?"
    d2 "You want me to say tons of complicated words?"
    scene clnrem47 with dissolve

    d1 "No!"
    d2 "That's what I thought."
    d1 "Oh I think I know"
    d1 "The more milk there is, the bigger they become, right"
    d2 "Not exact..."
    scene clnrem48 with dissolve

    d1 "And this means that I am far from having a baby..."
    scene clnrem44 with dissolve

    d1 "Also means you have a children!"
    d1 "Probably more than one!"
    d2 "No I don't"
    scene clnrem45 with dissolve

    d1 "Liar!"
    scene clnrem55 with dissolve

    d1 "Look at yours and look at mine..."
    scene clnrem49 with dissolve

    d2 "It's actually.."
    d2 "You know what yeah you're right."
    scene clnrem44 with dissolve

    d1 "Yes!"
    scene clnrem56 with dissolve

    d1 "By the way can I taste your milk?"
    d2 "What?"
    d1 "My whole way of perception has changed Nora"
    d1 "Now when I see the breast, I'll just think about what the milk tastes like.."
    scene clnrem49 with dissolve

    d2 "Oh no.."
    d2 "What have I done.."
    scene clnrem45 with dissolve

    d1 "C'mon let me taste it!"
    d2 "You can't"
    scene clnrem45 with dissolve

    d1 "Why!"
    d2 "Because there is no milk."
    scene clnrem47 with dissolve

    d1 "But you said I was right..."
    d2 "Hmmm"
    d1 "What are you thinking of?"
    scene clnrem43 with dissolve

    d2 "I'm torn between two options."
    d2 "Either I will tell you about it in detail, which is a tedious option"
    d2 "or you'll try and see that I don't have any milk, so you'll let it go."
    scene clnrem44 with dissolve
    pause
    scene clnrem51 with dissolve

    d1 "Do the second one! Do the second the one!"
    scene clnrem43 with dissolve

    d2 "Let's finish this conversation first."
    d2 "Like I said before, female gives birth."
    d2 "But she can't get pregnant on her own."
    d2 "Reproduction occurs when the male and female have sexual intercourse."
    d1 "How?"







    scene clnrem53 with dissolve

    d2 "Just like [pD57] yesterday"
    d1 "They were making a baby then..."
    d2 "Yes"
    scene clnrem39 with dissolve

    d1 "I don't understand exactly."
    d2 "I haven't finished it yet."
    scene clnrem40 with dissolve

    d2 "All it takes for a man and a woman to have children is for the man to fertilize the woman."
    d1 "What is that?"
    scene clnrem53 with dissolve

    d2 "Sperm is the male reproductive cell and the egg is the female reproductive cell"
    d2 "The man delivers his sperm to the woman's egg, and the woman becomes pregnant."
    d1 "Hmmm"
    scene clnrem40 with dissolve

    d1 "Still not get it!"
    d1 "How?"
    d2 "The male inserts his penis into the female's vagina"
    scene clnrem51 with dissolve

    d1 "Like stabbing?"
    d2 "......"
    d2 "Yeah it's like stabbing huh.."
    scene clnrem52 with dissolve

    d1 "Ooooh I see now. But there is one thing"
    d1 "Why did [pD73] fertilize [pD53] from her mouth then?"
    d1 "Do sperms reach the egg more easily through the mouth?"
    scene clnrem53 with dissolve

    d2 "Oh boy..."
    scene clnrem54 with dissolve

    d2 "You know what? I'll tell you that if we catch them again"
    d2 "Deal?"
    d1 "Yes!"
    scene clnrem53 with dissolve

    "(I had no other choice to stop her..)"
    "(I guess it is impossible for us to catch them again, most likely they were trying different things to color their monotonous sex life.)"
    "(I don't think we'll see [pD58] and [pD73] doing it in the living room again.)"
    "(I'm sure [pD73] already figured out that we were spying on them when he came to the kitchen.)"
    "(After that, they won't take such a risk again, so I got rid of telling Claire about blowjob)"
    "(Nice.)"
    scene clnrem57 with dissolve

    d2 "Why do you look like that.."
    scene clnrem58 with dissolve

    d2 "Claire..."
    scene clnrem59 with dissolve
    pause
    scene clnrem60 with dissolve

    d1 "It's time [pD77]"
    scene clnrem61 with dissolve

    d2 "What time.."
    d1 "It's time for you to prove.."
    scene clnrem62 with dissolve

    d2 "Prove what?"
    scene clnrem63 with dissolve

    d2 "Oh.."
    d2 "That was just.."
    d2 "...."
    d2 "Actually, I found an easy way to explain this."
    scene clnrem64 with dissolve

    d1 "No!"
    d1 "Come here!"
    d2 "Claire no!"
    scene clnrem65 with dissolve

    d1 "Gimme milk!"
    d2 "Okay okay.."
    scene clnrem66 with dissolve

    d2 "Just be carefull..."
    scene clnrem68 with dissolve
    pause
    scene clnrem69 with dissolve

    d1 "Oh boy I'm so excited!"
    scene clnrem67 with dissolve

    d2 "Like I said just be car.."
    scene clnrem70 with dissolve

    "(Can't believe this...)"
    scene clnrem71 with dissolve

    "(This has to stop..)"
    "(......)"
    scene clnrem71v2 with dissolve

    "(Ugh what the hell..)"
    scene CLcimd
    d2 "Ighh..."
    d2 "Claire..."
    d2 "(Oh... I never thought this could give me so much pleasure.)"
    d2 "(My nipples are already hard.)"
    d2 "(Claire is gently pinching my nipple. God this feels so good...)"
    scene clnrem72 with dissolve

    d1 "Nora!"
    scene clnrem73 with dissolve

    d2 "What"
    scene clnrem72 with dissolve

    d1 "Stop holding yourself.."
    d2 "Huh?"
    d1 "You're holding your milk on purpose, aren't you?"
    d2 "...."
    scene clnrem73 with dissolve

    d2 "Just keep going"
    scene clnrem74 with dissolve
    d1 "Oh is this how it works?.."
    d2 "Yeah sure.."
    scene clnrem75 with dissolve
    d2 "Mmmmm"
    show Nocls
    d2 "(Claire greedily began sucking my boob)"
    d2 "(Her cute little lips wrapped around my soft areola.)"
    "(No one can blame me for this..)"
    "(I'm a human after all..)"
    scene clnrem76 with dissolve
    d2 "Ahhhh"
    scene Notpe
    d2 "Mmmmmm"

    scene clnrem77 with dissolve

    d2 "Okay stop!"
    d1 "What.."
    scene clnrem78 with dissolve

    d2 "It's.."
    scene clnrem79 with dissolve

    d2 "I.."
    scene clnrem80 with dissolve

    d2 "I'm out of milk, that's why it's not coming"
    scene clnrem81 with dissolve

    d1 "Whaaat?"
    d1 "Who drank it?!"
    d1 "Who is that greedy!"
    scene clnrem82 with dissolve

    "(There's only one person Claire can't call him to account.)"
    scene clnrem83 with dissolve

    d2 "[pD76]"
    scene clnrem84 with dissolve

    d1 "...."
    scene clnrem85 with dissolve

    d1 "Okay then"
    d2 "That's it "
    scene clnrem86 with dissolve

    d1 "Yup"
    d2 "But don't you want to drink my milk?"
    scene clnrem87 with dissolve

    d2 "Look at them Claire. Are you going to give up?"
    "(Why the hell am I doing this...)"
    d1 "Mhmmmm...."
    d1 "No!"
    scene clnrem90 with dissolve

    "(Okay, one more time, but this is the last one Nora)"
    scene clnrem89 with dissolve

    d2 "Are you sure?"
    scene clnrem91 with dissolve
    pause
    scene clnrem92 with dissolve

    d1 "Yes!"
    scene clnrem94 with dissolve

    d1 "[pD76] must have loved your milk so much that he drank all of it, Nora. I can't steal this from him."
    d1 "I'm a good girl!"
    d2 "You trully are.."
    scene clnrem93 with dissolve

    "(But I'm not I guess)"
    "(Man! Sucks..)"
    scene clnrem92 with dissolve

    d2 "Wait"
    d2 "Aren't you mad at all?"
    d1 "No!"
    d2 "Why?"
    scene clnrem86 with dissolve

    d1 "Because, if [pD73] drank all your milk, he must have a good reason"
    d2 "Yeah.."
    scene clnrem92 with dissolve

    d1 "Wait.."
    d1 "If [pD73] drank all your milk, why did you tell me to keep sucking it?"
    d2 "Cuz I forgot"
    scene clnrem93 with dissolve

    "(Weak nora so weak..)"
    scene clnrem86 with dissolve

    d1 "Oh okay then"
    d1 "Thank you so much [pD77]!"
    scene clnrem93 with dissolve

    "(I feel terrible now..)"
    scene emnr1 with Fade(1.5,1.0,0.5)

    d2 "You sleep too much, it's not a good thing."
    scene emnr4 with dissolve

    d3 "Yeey, my favorite alarm is here..."
    scene emnr2 with dissolve

    d2 "You know why I'm here Em."
    scene emnr3 with dissolve

    d2 "C'mon get your sweet ass out of bed."
    scene emnr5 with dissolve

    d3 "Make me."
    scene emnr6 with dissolve

    d2 "C'mon Ems."
    scene emnr7 with dissolve
    pause
    scene emnr8 with dissolve

    d3 "Yawn"
    scene emnr9 with dissolve

    d3 "Oh about that"
    scene emnr10 with dissolve

    d3 "No need your help anymore."
    d2 "Ouch.."
    d3 "Not like that."
    d3 "Ugh it's a long story, I'll tell you later."
    scene emnr11 with dissolve
    pause
    scene emnr12 with dissolve

    d3 "What are you doing Nora?"
    scene emnr13 with dissolve

    d2 "It was a routine I've been doing regularly for a while."
    d2 "I was used to doing this. What do I do now?"
    d3 "Maybe you should a read book."
    d2 "No, I've already filled out my reading quota for this week."
    d3 "Dudeee, it's not unhealthy to read too much."
    d2 "Really?"
    d2 "I have an answer to this question that will take about 23 minutes."
    d3 "Pls don't.."
    d2 "Oh.."
    d3 "Nora?"
    d2 "Yes"
    d3 "You blackout again."
    d2 "Before I go to sleep, I plan what I'm going to do the next day and I spend the whole day as planned, you know that."
    d3 "Ugh..."
    d3 "Fine, I'll fill the remaining time."
    d2 "Huh?"
    d3 "Go get dressed, we're going out"
    d2 "It's better than standing aimlessly."
    d3 "That's ma gir!"
    d3 "Let's go."
    d2 "What're you up to, this time?"
    d3 "Nothing."
    d3 "Just wanted to thank you"
    d2 "Actually, you're technically thanking me right now."
    d3 "Nope"
    d3 "I'll thank you by showing you around."
    d2 "Hmm"
    d3 "Get ready, you're going on a date with crazy Emma"
    d2 "Spectacular.."
    scene rqby1 with Fade(1.5,1.0,0.5)
    pause
    scene rqby2 with dissolve
    pause
    scene rqby3 with dissolve

    rb "[pD43]!"
    mc "Ruby!"
    scene rqby4 with dissolve

    rb "What are you doing here?"
    mc "I..."
    mc "Don't know, Ruby."
    mc "I don't know what I am doing."
    scene rqby5 with dissolve

    rb "Oh.."
    rb "That sounds sad [pD78].."
    mc "It is, Ruby."
    scene rqby6 with dissolve

    rb "I go to my favorite garden every time I feel sad."
    rb "I just stare at it for a while, then I go home."
    mc "Wait."
    mc "Is that the park Amy was talking about?"
    mc "The park you go to every day"
    scene rqby7 with dissolve

    rb "Oh.."
    rb "Yeah"
    rb "But I don't go there just because I'm sad, sometimes I just like there."
    mc "Wow"
    rb "What's wrong, [pD78]?"
    mc "You lied to my face."
    scene rqby8 with dissolve

    rb "Oh no!"
    rb "I definitely wouldn't do that."
    mc "Are you sure.."
    rb "......."
    rb "You know what? Let's go."
    mc "Where?"
    rb "To there."
    mc "I..."
    rb "C'mon [pD78], trust me."
    mc "Sure. Why the hell not?"
    scene rqby9 with Fade(1.5, 1.0, 0.5)
    pause
    scene rqby10 with dissolve

    rb "So what you think?"
    rb "Isn't it perfect!"
    mc "Yeah it is."
    "No it's not.."
    scene rqby11 with dissolve

    rb "Actually, it's not a very special place."
    rb "Maybe if I looked around a little, I could even find a nicer place than here."
    rb "But for me, this is the right place"
    rb "Maybe I just want this place to be special."
    rb "Who knows?"
    scene rqby12 with dissolve

    mc "It does not matter."
    mc "If you feel good here.."
    rb "Yeah.."
    mc "Is everything okay Ruby?"
    rb "Uh-uh"
    rb "We are here for you [pD78]."
    rb "Not for me."
    rb "We'll sit down and listen to ourselves."
    rb "We won't worry!"
    mc "Well, you are the boss."
    scene rqby13 with dissolve

    rb "Oh my, how would I dare [pD78].."
    scene rqby14 with dissolve

    rb "I've never seen anyone as bossy as you in my life."
    rb "Don't ever say that you're the boss."
    mc "Cute"
    scene rqby15 with dissolve

    rb "Am I.."
    mc "Of course"
    mc "You're the cutest thing I've ever seen."
    rb "What about Claire?"
    mc "Well.."
    rb "Nora?"
    rb "Emma??"
    mc "You"
    mc "You are the most precious thing."
    mc "Satisfied?"
    rb "Ehehehe"
    rb "Yep"
    mc "You are so happy right now huh?"
    scene rqby14 with dissolve

    rb "I just found out that I'm the sweetest thing in the world, don't you think?"
    mc "I didn't say 'in the world', I said 'for me' you're the cutest thing."
    rb "Yes I know"
    scene rqby15 with dissolve

    rb "But for me you are the whole world."
    mc "....."
    mc "I think that was the nicest thing I've ever been told."
    rb "..."
    mc "..."
    scene rqby16 with dissolve

    rb "Is everything okay [pD78]?"
    mc "That was my line..."
    rb "[pD14].."
    scene rqby17 with dissolve

    mc "No, Ruby"
    mc "Everything is not okay."
    mc "But it's not too bad."
    mc "I actually have no idea how bad it is."
    mc "Things are not going well with Janet."
    mc "Maybe all this is actually very good for me. I am just afraid of change?"
    mc "Since the begining."
    scene rqby16 with dissolve

    rb "Since the beginning of what?"
    mc "Nothing honey."
    rb "Hmph.."
    scene rqby18 with dissolve

    mc "Why are you dressed like this?"
    scene rqby19 with dissolve

    rb "I forgot."
    mc "Who forgets to change?"
    rb "Surely someone who always wears the same suit will not forget."
    mc "Ouch"
    scene rqby20 with dissolve

    rb "I'm kidding [pD78], I love your suit."
    mc "I like the way you dress, too."
    rb "Awww"
    mc "Ehehe.."
    scene rqby14 with dissolve

    rb "[pD14].."
    mc "Yes honey?"
    rb "Do you have a schedule today?"
    mc "I always do."
    rb "Yeah..."
    scene rqby15 with dissolve

    rb "Wanna hangout today?"
    mc "Hmm?"
    scene rqby16 with dissolve

    rb "C'mon [pD78].."
    rb "I don't even remember the last time we spent time together"
    mc "What's on your mind?"
    scene rqby20 with dissolve

    rb "Let's watch a movie together!"
    mc "Sure, let's do that."
    scene rqby21 with Fade(1.5, 1.0, 0.5)

    rb "We're home!"
    mc "Where are they?"
    scene rqby22 with dissolve

    rb "They're outside."
    mc "Such a perfect answer.."
    scene rqby23 with dissolve

    rb "[pD14]?"
    "Why did she suddenly have such an expression on her face.."
    mc "Yes honey"
    rb "I don't know exactly why you're unhappy, but I know how to make it better."
    mc "How so?"
    scene rqby22 with dissolve

    rb "By serving you as you deserve."
    mc "Honey, you don't have to."
    rb "But you said I was the boss..."
    mc "Oh okay.."
    scene rqby24 with dissolve

    rb "Okay now wait, I'll be right back."
    scene rqby25 with dissolve

    "(Don't think [mc])"
    "(Don't think about anything.)"
    "(Just feel the moment.)"
    "(Your lovely [pD21] wants to make you comfortable.)"
    mc "Huh?"
    scene rqby26 with dissolve

    mc "Ruby?"
    rb "[pD14], close your eyes!"
    mc "Where are you?"
    rb "Somewhere you can't see me."
    mc "You're in the hallway?"
    rb "...."
    rb "Yes, now can you close your eyes?"
    mc "Why?"
    rb "Just do it!"
    scene black
    mc "Fine."
    rb "Okay, open now."
    mc "Are you sure?"
    rb "[pD14] open your eyes!"
    mc "I don't know Ruby"
    mc "I don't feel like it"
    rb "THE BOSS SAYS OPEN YOUR EYES!"
    mc "Calm down, boss."
    scene rqby27 with vpunch

    rb "Tadaaa"

    mc "Ruby what is this?"
    rb "Wait wait, I learned a pose."
    scene rqby28 with dissolve

    rb "This is for you!"
    scene rqby29 with dissolve

    rb "When you do your hands like this, it's like a heart."
    rb "How do I look?"
    rb "Do I look silly [pD78]?"
    mc "Yes Ruby, very silly"
    mc "But incredibly cute one.."
    scene rqby30 with dissolve

    rb "Kyaaaa!"
    scene rqby31 with dissolve

    mc "But Ruby what is this.."
    scene rqby32 with dissolve

    rb "This is the best maid you'll ever see!"
    mc "But why.."
    scene rqby33 with dissolve

    rb "Why?"
    rb "Because I want you to be happy."
    scene rqby34 with dissolve

    rb "I can serve you like a real maid and distract you from everything that bothers you."
    mc "....."
    mc "Look honey.."
    scene rqby35 with dissolve

    rb "[pD14]"
    rb "This is happening."
    rb "All you have to do is relax."
    rb "Trust me."
    mc "Okay"
    mc "I'm in."
    mc "But this outfit of yours.."
    scene rqby36 with dissolve

    rb "Isn't it super cute!"
    mc "Yeah it is.."
    scene rqby37 with dissolve

    mc "Where did you find it anyway?"
    rb "Oh it's a gift."
    mc "Who bought you such a gift, Ruby?"
    rb "[pD79]"
    mc "What.."
    rb "She thought it would look great on me."
    rb "My [pD80] is the best!"
    mc "Yeah she is.."
    scene rqby38 with dissolve

    "(Who gives her [pD81] a sexy maid costume as a gift..)"
    "(Well..)"
    "(It looks so good on you that I can't believe my eyes.)"
    "(She is hot as hell..)"
    "(You've always been very special to me, so I've tried to ignore some of my feelings)"
    "(But now you're showing up like this, Ruby..)"
    "(Not fair..)"
    "(But I don't believe Amy bought this.)"
    "(I should push her more.)"
    mc "Honey"
    scene rqby37 with dissolve

    rb "Yes [pD78]"
    mc "Are you sure your [pD80] bought this?"
    scene rqby45 with dissolve

    rb "Mhmmmm..."
    mc "Ruby.."
    scene rqby42 with dissolve

    rb "Okay okay"
    rb "I bought..."
    mc "Why did you lie?"
    rb "They asked me a lot of questions while trying to get this. I bought it by lying. That's why I thought you'd be angry..."
    rb "It's just a dress. Why do people act as if this is something forbidden?"
    "(Too obvious actually..)"
    mc "But why honey?"
    rb "Well.."
    rb "I actually have a hobby.."
    "(Oh no..)"
    "(What kind of hobby needs a sexy maid dress..)"
    mc "What hobby?"
    rb "It's.."
    mc "Just say it."
    scene rqby40 with dissolve

    rb "Cosplay.."
    mc "Huh?"
    rb "Cosplay [pD78]. I love it, okay.."
    mc "Of course okay but, but why are you so afraid to tell me that."
    rb "It's.."
    rb "I don't know [pD78] I just feel shy about it."
    mc "Does anyone know about this hobby of yours?"
    rb "Only a few of my friends know..."
    mc "Just friends?"
    rb "Mhm hm"
    mc "Luna or Amy?"
    rb "Nope"
    mc "Hmm"
    mc "It's actually nothing to be ashamed of, honey."
    rb "You really think so?"
    mc "Yes, this is a really nice hobby."
    scene rqby43 with dissolve

    rb "Yuppiii!"
    rb "I'm so relieved"
    mc "You silly."
    scene rqby40 with dissolve

    rb "ehehe"
    mc "How long have you been interested in this hobby?"
    scene rqby42 with dissolve

    rb "Uhmmm"
    rb "I don't remember, but it's been a long time."
    scene rqby44 with dissolve

    mc "Then you've done a lot of cosplay?"
    scene rqby45 with dissolve

    rb "......."
    mc "Don't tell me this is the first time.."
    rb "......"
    mc "But why?"
    mc "If you like this hobby, why don't you do it?"
    scene rqby42 with dissolve

    rb "Yes, but I never had the courage. I always admired the cosplays I saw on the internet."
    rb "But last week, someone convinced me of that."
    mc "Who?"
    rb "Just a friend."
    mc "How adorable?"
    mc "But why maid?"
    scene rqby46 with dissolve

    rb "Oh that.."
    rb "I did a little research, this is one of the cosplays that men like the most, especially recently."
    rb "That's why I chose it."
    "(Fucking pervs..)"
    "(Hehehe)"
    mc "Well I'm glad you've got the courage to start doing the things you're interested in."
    scene rqby40 with dissolve

    rb "But I'm not sure I'll ever be able to go and buy a costume again."
    scene rqby42 with dissolve

    rb "It was very difficult to even get it, I already stole money from my [pD80]'s wall..."
    mc "Ruby..."
    rb "But.."
    rb "These things are expensive [pD78].."
    mc "Of course they are."
    mc "Let's make a deal?"
    mc "I'll be your sponsor from now on."
    scene rqby48 with dissolve

    rb "How so?"
    mc "I'll give you money to buy the clothes you want."
    scene rqby49 with dissolve

    rb "No way really!"
    mc "Yes really"
    scene rqby43 with dissolve

    rb "I'm so happy!"
    mc "Yep I can see that."
    mc "Okay then we can talk this later. Let's watch the movie."
    rb "Yaay!"
    scene rqby39 with dissolve

    mc "But"
    rb "Huh?"
    mc "Let's keep this hobby a secret between us."
    rb "Whatever you want [pD78]."
    #############################################################################################################
    scene rqby41 with dissolve

    mc "Okay then."
    mc "I have a maid."
    rb "Hmph!"
    mc "I have an amazingly cute maid!"
    rb "Hmmmmmm"
    mc "I have an amazingly cute and pretty and..."
    scene rqby42 with dissolve

    rb "Lovely"
    mc "Yeah and lovely maid."
    scene rqby43 with dissolve

    rb "Yes yes yes that's me!"
    mc "Yes that's you."
    mc "So, what are my privileges?"
    scene rqby44 with dissolve

    rb "I'm your amazingly cute and pretty and lovely maid [pD78], whatever you want!"
    scene rqby45 with dissolve

    "(Don't poke the dragon Ruby)"
    "(I'm already hard like rock...)"
    "(I'm afraid I won't be able to control myself when Ruby says such things in this outfit...)"
    mc "Hmmmm"
    scene rqby46 with dissolve

    rb "Let me give you a hint!"
    "(Oh boy!)"
    rb "Maybe you can choose what I will call you?"
    "(Oh c'mon...)"
    "(Wait..)"
    "(This is amazing opportunity!)"
    mc "Well this is a good hint."
    rb "So what should I call you [pD78]?"
    $cPName = renpy.input ("What should she call you?")
    scene rqby47 with dissolve

    rb "As you wish [cPName]"
    "(Holy moly!)"
    "(Calm [mc]..)"
    mc "Okay.."
    scene rqby48 with dissolve

    rb "What?"
    mc "Nothing."
    rb "Hmh hmh.."
    mc "Okay then, what's next?"
    rb "Whatever you want [cPName]."
    "(Oh honey you would be shocked..)"
    mc "Whatever I want huh.."
    rb "Yes [cPName] whatever you want."
    "(Very naive and very sexy ideas come to my mind at the same time...)"
    menu:
        "I want you":
            mc "I want you."
            scene rqby49 with dissolve

            rb "How so?"
            mc "I just want you."
            scene rqby50 with dissolve

            rb "Okay [cPName]. I'm yours!"
            mc "Ruby, do you know what this means?"
            scene rqby51 with dissolve

            rb "Ummmmm..."
            scene rqby52 with dissolve

            rb "Wait a second, I almost forgot!"
            rb "I'm a maid. Not Ruby!"
            mc "Okay, do you know what this means miss maid?"
            rb "Nope!"
            scene rqby53 with dissolve

            rb "But it doesn't matter [cPName]."
            rb "It will be whatever you want."
            mc "..."
            scene rqby54 with dissolve

            rb "How you want me [cPName]?"
            "(In your knees maybe...)"
            "(Or maybe I'll start to control myself)"
            "(What is going on me today..)"
            mc "I want you to..."
            scene rqby55 with dissolve

            rb "Yes [cPName]?"
            "(Calm [mc]..)"
            "(Not yet)"
            "(Not yet?..)"
            "(Huh, is that really how I feel?..)"
            mc "Where is my drink miss maid?"
            scene rqby56 with dissolve

            rb "Oh no!"
            rb "I'm so sorry [cPName]!"
            rb "Luna drank it all again..."
            mc "Well not suprising.. "
        "I want a beverage":
            mc "So you are my maid, yes?"
            rb "Yes [cPName]"
            mc "Then why isn't my drink in front of me?"
            rb "Oh no!"
            rb "I'm so sorry [cPName]!"
            rb "Luna drank it all again..."
            mc "Well not suprising.. "
    scene rqby57 with dissolve

    mc "Okay honey, you've been standing up for a long time, so sit down."
    rb "But I'm your maid.."
    mc "So.."
    scene rqby58 with dissolve

    rb "If I'm serving you, I should be tired."
    mc "Why?"
    rb "Isn't that usually the case?"
    mc "I don't know, I've never had a maid before."
    rb "Hmmm"
    scene rqby59 with dissolve

    rb "So what do I do?"
    mc "...."
    rb "...."
    mc "Follow my orders."
    rb "Which means"
    mc "Sit"
    rb "Of course [cPName]."
    mc "Will you be comfortable with that dress?"
    scene rqby60 with dissolve

    rb "Of course"
    mc "It doesn't seem very comfortable."
    rb "But you like it"
    mc "Of course I like it."
    rb "Then I keep wearing it."
    mc "..."
    mc "What kinda maid are you?"
    scene rqby61 with dissolve

    rb "Oh no what did I wrong [pD78]!"
    rb "I mean [cPName]."
    mc "You're always disobeying my orders."
    scene rqby62 with dissolve

    rb "Oh..."
    rb "Sorry [cPName]."
    scene rqby63 with Fade(1.5, 1.0, 0.5)

    rb "Here"
    "(Holy molly!)"
    scene rqby64 with dissolve

    "(This is the sweetest and sexiest thing I've ever seen..)"
    mc "Ruby.."
    scene rqby66 with dissolve

    rb "Ahem!"
    mc "Miss maid."
    mc "I didn't say take it off here."
    "(Shut the fuck up you're fucking with me!)"
    scene rqby67 with dissolve

    rb "But you asked me to take it off."
    mc "Yes, but that's not very convenient."
    mc "Oh I see."
    mc "I have to take off my underwear, right?"
    "(Yes!)"
    mc "No."
    "(Fuck me)"
    mc "You know what? Just wear the dress."
    mc "I think the annoying part is the apron."
    rb "Yup it is."
    mc "Good then dress up."
    scene rqby68 with dissolve

    rb "Yes [cPName]"
    mc "And I'll turn off the lights."
    scene rqby69 with Fade(1.5,1.0,0.5)

    mc "Now we're ready."
    rb "[cPName]"
    mc "Yes miss maid"
    scene rqby70 with dissolve

    rb "Can I take my socks off too?"
    mc "Of course, you don't need to ask."
    scene rqby71 with dissolve

    rb "These things are not comfortable at all, why are they being produced..."
    mc "Because it looks very nice on girls."
    rb "Yup, that's why I wore it, but wouldn't it be much better if they made it more comfortable anyway?"
    mc "Well.."
    mc "I don't think it's a problem because it's not worn for a long time."
    scene rqby72 with dissolve

    rb "I mean, why shouldn't it be worn for a long time?"
    "(Oh boy..)"
    mc "We'll talk about this another time."
    scene rqby73 with dissolve

    rb "You can talk to me about anything."
    mc "You know what? You are right."
    rb "Ehehe"
    scene rqby74 with dissolve

    rb "Uhmmm..."
    mc "What?"
    rb "this also starting to feel uncomfortable.."
    rb "I didn't even manage to become a maid..."
    mc "Don't be silly."
    mc "You're the best maid I've ever seen."
    scene rqby75 with dissolve

    rb "You mean it?"
    mc "Of course!"
    rb "Yay!"
    rb "All right, then I'll take my clothes off."
    mc "Or should you choose something comfortable?"
    "(Luna or Amy could be here any minute. I can't risk it...)"
    scene rqby76 with Fade(1.5, 1.0, 0.5)

    rb "Here I am"
    mc "Yes you are."
    scene rqby77 with dissolve

    rb "Okay then [cPName]."
    mc "Have you decided what you want to watch?"
    rb "How dare I [cPName]!"
    rb "You choose."
    mc "Well, there's nothing I particularly want, so let's open something randomly."
    scene rqby78 with dissolve

    rb "Whatever you say [cPName]."
    mc "This one would do."
    rb "Hmmm"
    scene rqby80 with dissolve

    rb "I've never seen that one."
    mc "Really?"
    rb "Yeah seems little old."
    scene rqby79 with dissolve

    mc "Well, I'm little old too."
    rb "Yeah this is you."
    mc "What does this mean."
    rb "I don't know [cPName]"
    scene rqby81 with dissolve

    rb "All I know is that I love you so much, every part of you."
    mc "Then you will also like this movie very much."
    rb "Why, are you in this movie?"
    scene rqby82 with dissolve

    mc "Wish"
    mc "Because I love this movie so much."
    rb "Oh makes sense!"
    rb "Guess what [cPName]?"
    mc "What?"
    rb "I love this movie!"
    mc "That's more like it."
    rb "Ehehe"
    rb "What is this movie about?"
    mc "It's The Mummy."
    rb "Ooooh right."
    scene rqby83 with dissolve

    "(Okaay...)"
    "(Don't get hard, [mc])"
    "(Just focus the movie.)"
    "(Not the chick [mc]..)"
    scene rqby84 with dissolve

    "(Think something else..)"
    "(Hah it's working.)"
    scene rqby85 with dissolve

    rb "[cPName]"
    "(Fuck!)"
    "(How can a word make me have an erection?..)"
    "(Well not hard as a wood, but Ruby's about to feel it.)"
    mc "Yes honey"
    scene rqby86 with dissolve

    rb "Do you think she is pretty?"
    mc "Yeah she is.."
    rb "Oh.."
    scene rqby87 with dissolve

    "(No more mister hard guy.)"
    "(This conversation is good for me.)"
    scene rqby85 with dissolve

    rb "[cPName]"
    "(Is she doing it on purpose..)"
    mc "Yes honey"
    scene rqby88 with dissolve

    rb "Did you find her beautiful because she's dressed like that, or because of her face and body?"
    mc "Hmm, hard question"
    rb "Why is that?"
    mc "I guess both."
    rb "Okay then"
    mc "Let's just focus on the movie shall we?"
    rb "Whatever you want [cPName]."
    scene rqby89 with dissolve

    "(Fuck...)"
    scene rqby90 with dissolve

    mc "Phew"
    mc "Man I miss this movie."
    mc "I think the last time I watched it was about 5 years ago."
    mc "So did you like?"
    scene rqby91 with dissolve

    mc "Ruby?"
    scene rqby89 with dissolve

    mc "She is asleep."
    mc "Like an angel.."
    mc "How could you do such a perfect creature [pD82]..."
    mc "Look at you."
    mc "I can watch you forever."
    mc "If I can behave myself, of course"
    mc "I'm hard again.."
    scene rqby92 with dissolve

    mc "Well at least she can't feel it."
    mc "..."
    mc "But I can.."
    mc "Maybe I can start with something innocent."
    scene rqby93 with dissolve

    mc "Look at that. So soft, so warm"
    mc "So fragile.."
    scene rqby94 with dissolve

    mc "Okay."
    mc "This is enough for now."
    mc "But I don't want to wake her up either."
    mc "I can stand like this forever..."
    mc "But I have to go home too."
    mc "That was good but it's time to awake her."
    mc "Ruby"
    mc "Hmm nothing"
    scene rqby95 with dissolve

    mc "Come on, wake up now"
    mc "Maybe little touch in her face could awake her."
    scene rqby96 with dissolve

    mc "Hey there angel.."
    mc "Nothing.."
    mc "Damn you are heavy sleeper.."
    scene rqby97 with dissolve

    mc "Maybe if I gently touch her lips, I will wake her up without scaring"
    mc "Okay"
    mc "This woke up something else.."
    mc "Hmm, maybe the pressure on the back of her head will wake her up. ehehe"
    scene Rudrt
    pause
    scene rqby94 with dissolve

    mc "Nope nothing.."
    mc "I should go back to the finger stuff"
    mc "And going deeper."
    mc "Sorry but you asked for it"
    scene rqby98 with dissolve

    mc "Holy fuck!"
    mc "Calm [mc]. Don't..."
    mc "I don't want to ruin my suit..."
    scene rqby99 with dissolve

    mc "That was close.."
    mc "So close.."
    mc "She is still sleeping"
    mc "Maybe I need to try a little harder."
    mc "What I'm doing right now is very virtuous."
    mc "I'm trying to wake up my beloved [pD21] without scaring her"
    mc "I'm sorry, my angel, but I have to make some sacrifices to wake you up."
    scene rqby100 with dissolve

    mc "Like this"
    mc "......"
    mc "this feeling..."
    mc "You're untouched and perfect."
    mc "There is no turnback from this.."
    scene rqby101 with dissolve

    rb "Mhm..."
    mc "Damn.."
    scene rqby102 with dissolve

    mc "This sound.."
    mc "Maybe I'll ease my tension a little bit."
    mc "This is totally normal.."
    scene rqby103 with dissolve
    pause
    scene rqby104 with dissolve
    pause
    scene rqby105 with dissolve
    pause
    scene rqby106 with dissolve
    pause
    scene rqby107 with vpunch

    ln "Booh!"
    mc "What the!"
    scene rqby108 with fade

    ln "Haa haaa I got you"
    mc "Fuck!"
    scene rqby109 with dissolve

    ln "Oh no!"
    ln "Are you having a heart attack [pD78]!"
    ln "You know cuz you are old."
    mc "What is this hair?"
    ln "New style, I get bored easily, you know that."
    ln "Did you like?"
    menu:
        "Good":
            scene rqby109 with dissolve

            mc "Good, I like it."
            ln "Awww, it may be the most superficial compliment I've ever heard in my life."
            mc "Take it or leave it"
        "Bad":
            scene rqby110 with dissolve

            mc "I wasn't a big fan of your previous style but"
            ln "You can keep the rest to yourself."
    scene rqby109 with dissolve

    ln "Are you sure you didn't have a heart attack?"
    mc "Luna, do you like being alive?"
    ln "Hard question."
    ln "It depends on the moment"
    ln "Most of the time I feel like an empty soul, but sometimes I feel amazing."
    mc "Because you're getting high."
    ln "That's ma [pD78]!"
    scene rqby112 with dissolve

    mc "How can she still be sleeping.."
    ln "Fuck me if I know"
    "(Careful what you wish for)"
    scene rqby113 with dissolve

    ln "By the way you've never seen a movie with me."
    ln "Should I be jealous?"
    mc "You should."
    ln "haa haaa"
    ln "I'm not"
    mc "Anyway, since you're here, I can go home."
    scene rqby114 with dissolve

    ln "Or you can join me in the kitchen."
    scene rqby115 with dissolve
    pause
    scene rqby116 with dissolve

    mc "Sure, I have time."
    ln "That's rare."
    mc "Be quick though. Janet and the girls are waiting for me at home."
    scene rqby118 with dissolve

    ln "Of course they do."
    ln "It's nothing actually."
    mc "What is the real reason for this new style?"
    scene rqby120 with dissolve

    ln "Cuz of [pD80]."
    mc "Let me guess, you got into a fight, and that's how you get revenge."
    ln "Hah, I've become a cliche..."
    mc "Yup"
    scene rqby119 with dissolve

    ln "At least it's not every day I spend all day in a black suit."
    mc "Why does everyone hate my suit?"
    ln "Cuz it fits on you."
    mc "So what? Because they're jel on me?"
    ln "Pretty much."
    mc "Good to know, jel."
    ln "Yeah."
    scene rqby120 with dissolve

    ln "So.."
    ln "What was that Ruby date, [pD78]?"
    mc "What do you mean?"
    scene rqby121 with dissolve

    ln "Don't know, it's just odd."
    mc "Is it because you saw us watching a movie?"
    ln "Yeah I don't know."
    mc "What is going on, Luna?"
    scene rqby122 with dissolve

    ln "Nothing.."
    ln "What do you really think about my new style?"
    ln "No lies"
    mc "Well, it's too colory for me."
    mc "You know me Luna I'm old school."
    ln "And you like old school girls huh?"
    "More like school girls.."
    mc "Of course, but no matter what you do, I always like you."
    ln "Yeah sure."
    mc "What was that?"
    ln "Nothing [pD78], have a good night."
    mc "You too."
    "(What is wrong with this girl?)"
    scene rqby123 with dissolve

    ln "Don't go."
    scene rqby124 with dissolve

    mc "Luna, what's going on?"
    ln "Nothing, just let me do my thing."
    mc "What is your thing?"
    scene rqby125 with dissolve

    ln "This.."
    mc "Luna, stop.."
    ln "Try me."
    mc "Ruby or your [pD80] could be here any minute."
    scene rqby126 with dissolve

    ln "And this is stopping you?"
    ln "Not cuz I'm your [pD29].."
    "(What should I do?)"
    "(I don't want to stop her.)"
    "(Should I let myself go with the flow..)"
    "(Who am I kidding? I was about the do the same thing to Ruby.)"
    "(Fuck that.)"
    mc "Okay then, do your thing and let's get over this."
    scene rqby127 with dissolve

    ln "Huh"
    mc "What?"
    scene rqby128 with dissolve

    ln "You're so easily convinced, I suddenly lost my enthusiasm."
    menu:
        "Show her who's boss":
            mc "You love to be in control, don't you?"
            scene rqby129 with dissolve

            ln "Well.."
            mc "This was a hypothetical question"
            ln ".."
            scene rqby130 with dissolve

            ln "I seriously don't want to play."
            mc "Why, you are really good at this."
            scene rqby131 with dissolve

            ln "I'm also good at baseball."
            scene rqby132 with dissolve

            ln "Oh right you already know that, huh [pD78]?"
            mc "Funny"
            ln "Anyway [pD78], I'm so tired, and you're late for home."
            mc "Why did you suddenly get so serious"
            ln "I didn't.."
            scene rqby133 with dissolve

            mc "Mhmm"
            scene rqby134 with dissolve

            ln "Oh.."
            ln "And why did you suddenly become so tactile.."
            ln "It's not real you.."
            mc "You think you know the real me huh?"
            scene rqby135 with dissolve

            ln "[pD78].."
            mc "What?"
            ln "Your phone is poking my back."
            mc "It's not the phone"
            mc "But it can vibrate like a phone."
            ln "What are you doing.."
            mc "What you've wanted for a long time."
            ln "What makes you think I want this?"
            mc "Because you're still here."
            scene rqby136 with dissolve

            ln "Because you're holding me."
            mc "Not so strong, you can get away with it if you try."
            ln "Why would I do something like that, you have to let me go."
            mc "No, I won't."
            ln "Why?"
            mc "If you use force and get rid of me, you will contradict yourself."
            mc "Your ego won't let you do that, will it?"
            mc "I have to let you go just because you want to. you can't accept anything else."
            ln "You're getting silly."
            mc "Okay then prove me wrong."
            mc "Try to get rid of"
            ln "[pD78] it's getting weird, just let me.."
            mc "No"
            ln "....."
            ln "Stop it"
            mc "Make me"
            ln "........"
            scene rqby137 with dissolve

            ln "Fine don't let me go."
            mc "And?"
            ln "Then we wait like this."
            mc "Isn't everything black and white for you?"
            ln "Yup"
            mc "Fine I can play this game."
            ln "Cool"
            mc "Yeah very cool"
            scene rqby136 with dissolve

            ln "[pD78].."
            mc "..."
            ln "I feel weird, at least don't do this."
            mc "Do what?"
            ln "Stop rubbing.."
            mc "Why, don't you like it?"
            ln "....."
            scene rqby135 with dissolve

            ln "Okay I give up, let me go."
            mc "Okay try it."
            scene rqby137 with dissolve

            ln "I can't, you're holding me so tight."
            mc "Well, what will we do about this?"
            ln "......"
            ln "Let me go."
            mc "Or?"
            ln "I'll scream."
            mc "Go ahead."
            ln "......"
            scene rqby132 with dissolve

            ln "Fine, do it."
            ln "Anyway, you'll soon cum and lose interest."
            ln "You can rub it for another 5 minutes at most."
            ln "I can feel the itching [pD78].."
            mc "Hmmm"
            mc "Then let me make you feel more."
            scene rqby136 with dissolve

            ln "[pD78].."
            scene rqby134 with dissolve

            mc "Stop playing the victim"
            mc "Your body can't lie."
            ln "Mhm.."
            scene rqby137 with dissolve

            ln "Why are you like this all of a sudden?.."
            mc "Have you forgotten how long you've been teasing me?"
            ln "Yeah but why now.."
            "(Maybe because of Ruby)"
            "(I really don't know.)"
            mc "Because I'm a man"
            mc "I want it"
            ln "That's it?"
            mc "Yes."
            ln "What if I don't want?"
            mc "Sorry honey, you poke the bear."
            ln "...."
            ln "I'm starting to lose all respect for you..."
            mc "Oh yeah?"
            ln "Yeah.."
            mc "Then I don't have to hold back."
            scene rqby138 with dissolve

            ln "Whaa..."
            scene rqby139 with dissolve

            ln "NGhhhnnn"
            mc "Look at that, I found the spot."
            ln "Thank god I'm wearing quality underwear."
            ln "No matter how hard you try, it won't tear."
            mc "Yeah, but it can stretch a little."
            scene rqby140 with dissolve

            ln "[pD78].."
            ln "It's poking my asshole..."
            scene rqby141 with dissolve

            mc "Unlucky"
            mc "For you"
            ln "Nghnn..."

            scene a_rqby143
            ln "Mhmmmm..."
            ln "[pD78]..."
            scene rqby145 with fade

            rb "I was sleepy, [pD78].."
            scene rqby146 with dissolve
            pause
            scene rqby147 with dissolve

            rb "Oh Luna!"
            rb "Guess what we did with [pD78]!"
            scene rqby148 with dissolve

            ln "Oh Ruby!"
            ln "Watching the Mummy?"
            scene rqby149 with dissolve

            rb "No way, how did you know!"
            rb "You guessed right"
            ln "Yes Ruby."
            scene rqby150 with dissolve

            rb "What are you guys doing?"
            mc "Yeah Luna what are we doing?"
            ln "We're hugging, Ruby."
            ln "We've missed each other so much."
            rb "Oh okay."
            scene rqby151 with dissolve

            rb "Can I join?"
            mc "Sure"
            scene rqby152 with dissolve

            ln "No!"
            ln "Don't come any closer!"
            scene rqby153 with dissolve

            rb "Why.."
            scene rqby154 with dissolve

            ln "Cuz..."
            scene rqby155 with dissolve

            ln" Mhmmm"
            rb "Huh?"
            ln "I don't know just don't"
            scene rqby156 with dissolve

            rb "But [pD78] said sure!"
            ln "You know what? Go to your room."
            rb "Why?"
            scene rqby157 with dissolve

            ln "Cuz i said so!"
            rb "Okay then"
            scene rqby158 with dissolve

            mc "Ruby"
            rb "Yes [pD78]."
            mc "Did I tell you you could go?"
            scene rqby159 with dissolve

            rb "No.."
            ln "Please don't do that.."
            rb "Don't do what?"
            mc "Hugging so hard"
            scene rqby160 with dissolve

            rb "I want to join!"
            ln "No!"
            scene rqby154 with dissolve

            ln "You.."
            ln "Can join us from there."
            rb "Why.."
            ln "It's a game."
            rb "Okay!"
            scene rqby161 with dissolve

            rb "What should I do?"
            ln "Just stand there and..."
            rb "And?"
            scene rqby162 with dissolve

            mc "Watch us hugging."
            rb "Oh okay!"
            mc "How do you feel Luna?"
            ln "Good.."
            rb "I feel good too!"
            mc "Of course you do."
            ln "Mhmmm.."
            scene rqby163 with dissolve

            rb "Are you okay Luna?"
            scene rqby157 with dissolve

            mc "Yes Luna, are you okay?"
            scene rqby164 with dissolve

            ln "Yeah yeah I'm fine.."
            ln "Just keep hugging.."
            mc "{size=-10}You little perv{size=-10}"
            mc "{size=-10}It turned you on that Ruby was watching us..{size=-10}"
            ln "......"
            ln "{size=-10}Don't be ridiculous.{size=-10}"
            ln "{size=-10}You're humping me with your huge penis.{size=-10}"
            ln "{size=-10}She is nothing do with it.{size=-10}"
            mc "{size=-10}Sure.{size=-10}"
            scene rqby165 with dissolve

            rb "Oh c'mon."
            rb "I'm standing far away and you're whispering.."
            rb "I'm going to my room!"
            scene rqby166 with dissolve

            ln "We're done!"
            mc "C'mon I was about the ..."
            scene rqby167 with dissolve

            ln "[pD78]"
            ln "I'm not ready for this."
            ln "I tought I was but.."
            ln "This is too much."
            mc "Really?"
            ln "I don't know, find the answer yourself.."
            "(She is doing it again..)"
            scene rqby168 with dissolve

            menu:
                "No turning back":
                    mc "I'm gonna say no."
                    scene rqby169 with dissolve

                    ln "What?.."
                    mc "Get ready."
                    ln "For what [pD78]?"
                    mc "For this!"
                    scene rqby170 with dissolve

                    ln "Aaahhh!!!"
                    scene rqby171 with dissolve

                    ln "[pD78]! What the fuck!"
                    ln "{size=-10}Finally..{size=-10}"
                    mc "What did you say?"
                    ln "Nothing"
                    scene rqby172 with dissolve

                    ln "Are you really going to do this?"
                    mc "You asked for this!"
                    ln "No I.."
                    scene rqby173 with dissolve

                    ln "Oh my god.."
                    ln "You are serious.."
                    mc "It's your problem that you don't understand the seriousness of this until you lose your panties."
                    ln "But..."
                    mc "Yeah but, hiding behind a thin piece of cloth, you did what you wanted"
                    mc "Here I come Luna!"
                    ln "......"
                    scene rqby174 with dissolve

                    ln "Inngghhh!"
                    mc "Holy shit!"
                    mc "How tight are you Luna?"
                    scene rqby175 with dissolve

                    ln "Holly!"
                    ln "You really did it."
                    mc "The tip has already gone inside you still can't believe this is happening."
                    ln "Only the tip?!"
                    mc "Yeah, still have a long way to go!"
                    ln "......"
                    mc "But still it's not so late Luna"
                    mc "I can stop if you want?"
                    ln "...."
                    mc "Silence always means 'yes I want but I'm so shy to admit it'"
                    mc "Fucking classic!"
                    scene rqby176 with dissolve

                    ln "[pD78]!"
                    ln "Stop please!"
                    mc "Hah you're still playing this game."
                    mc "Damn Luna your ego is massive."
                    ln "...."
                    mc "Fine I can play this game too"
                    mc "You can't stop me anymore."
                    mc "And you can't do shit about it!"
                    scene rqby177 with dissolve

                    ln "Oh my god!"
                    ln "What is this feeling!"
                    ln "It hurts like hell!"
                    mc "Good!"
                    mc "I'm fed up with your slutty look and bitchy behaviours."
                    mc "You get what you fuckin deserve!"
                    scene Luonyav
                    pause
                    scene Luonhz
                    ln "Mhmmm"
                    ln "..."
                    ln "Fuck!"
                    mc "Shut up you little bitch!"
                    ln "Yes!"
                    ln "You're right!"
                    ln "But I'm sorry, please forgive me!"
                    scene Luarkyav
                    pause
                    scene Luarkhz
                    mc "No"
                    ln "Oh my god!"
                    mc "Want me to stop?"
                    ln "......."
                    mc "fucking answer!"
                    ln "NO!"
                    ln "Please don't stop!"
                    mc "This is how you win!"
                    mc "I'm not just fucking you, I'm fucking your ego."
                    mc "Right?"
                    ln "..."
                    mc "Answer!"
                    ln "Yes [pD78] yes!"
                    mc "Good"
                    ln "IGgggggh"
                    mc "Are you sure you want to moan that loud?"
                    mc "Ruby can hear it and come."
                    ln "No!"
                    mc "Maybe she should come."
                    mc "I wish she could see you like this."
                    scene rqby177 with dissolve

                    ln "[pD78]!"
                    scene rqby178 with dissolve

                    mc "Shut up!"
                    scene rqby179 with dissolve
                    pause
                    scene rqby180 with dissolve

                    ln "I..."
                    scene rqby181 with dissolve

                    rb "Are they still there?"
                    scene rqby182 with dissolve

                    rb "Oh no.."
                    scene rqby183 with dissolve

                    rb "[pD78] must be so angry with Luna..."
                    scene rqby184 with dissolve

                    rb "What should I do!"
                    scene rqby185 with dissolve

                    rb "I love my sister but he is my [pD78].."
                    scene rqby186 with dissolve

                    rb "Should I stop him.."
                    scene rqby187 with dissolve
                    pause
                    scene rqby188 with dissolve

                    rb "No no no!"
                    rb "Hell no!.."
                    scene rqby189 with dissolve
                    pause
                    scene rqby190 with dissolve

                    ln "Aaggggh!!!"
                    mc "Igggh!!!!"
                    ln "[pD78]!!"
                    scene rqby191 with dissolve

                    "(I did it..)"
                    "(Fuck...)"
                    "(Or not?)"
                    "(Hmm..)"

                "Go home":
                    scene rqby123 with dissolve

                    mc "See you later Luna, I'm going home."
                    ln "Wha..."
                    mc "Have a good night."
                    ln "...."
        "Go home":
            scene rqby123 with dissolve

            mc "Are you fucking kidding me?"
            scene rqby128 with dissolve

            ln "I don't know.."
            mc "I'm going home"
            ln "Say hi to everybody."
            mc "Shut up."
            scene rqby116 with dissolve

            "(What the fuck was that?)"
            "(Is she up to something again?..)"
            "(That's nonsense)"
            "(Weird girl...)"
    $config.allow_skipping = False
    "End of v04, don't forget to save!"
    "Thank you for playing!"
    jump v04_a
