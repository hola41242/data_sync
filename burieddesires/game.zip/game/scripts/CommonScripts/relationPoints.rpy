


default mc_bad_points = 0
default mc_good_points = 0
default janet_r_points = 0
default janet_l_points = 0
default janet_d_points = 0
default amy_r_points = 0
default amy_l_points = 0
default amy_d_points = 0
default claire_r_points = 0
default claire_l_points = 0
default claire_d_points = 0
default nora_r_points = 0
default nora_l_points = 0
default nora_d_points = 0
default emma_r_points = 0
default emma_l_points = 0
default emma_d_points = 0
default ruby_r_points = 0
default ruby_l_points = 0
default ruby_d_points = 0
default luna_r_points = 0
default luna_l_points = 0
default luna_d_points = 0
default gaby_r_points = 0
default gaby_l_points = 0
default gaby_d_points = 0
default chloe_r_points = 0
default chloe_l_points = 0
default chloe_d_points = 0
default olivia_r_points = 0
default olivia_l_points = 0
default olivia_d_points = 0
default st1_r_points = 0
default st1_l_points = 0
default st1_d_points = 0
default clara_r_points = 0
default clara_l_points = 0
default clara_d_points = 0
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
