init -1:
    $ persistent.unlock_gallery = False

init python:
    class Gallery_image():
        def __init__(self, image, condition = True):
            self.image = image
            self.condition = condition
            gallery_images.append(self)


default gallery_images = []

default g1 = Gallery_image(image='gallery/glry1.jpg', condition='persistent.gal1')
default g2 = Gallery_image(image='gallery/glry2.jpg', condition='persistent.gal2')
default g3 = Gallery_image(image='gallery/glry3.jpg', condition='persistent.gal3')
default g4 = Gallery_image(image='gallery/glry4.jpg', condition='persistent.gal4')
default g5 = Gallery_image(image='gallery/glry5.jpg', condition='persistent.gal5')
default g6 = Gallery_image(image='gallery/glry6.jpg', condition='persistent.gal6')
default g7 = Gallery_image(image='gallery/glry7.jpg', condition='persistent.gal7')
default g8 = Gallery_image(image='gallery/glry8.jpg', condition='persistent.gal8')
default g9 = Gallery_image(image='gallery/glry9.jpg', condition='persistent.gal9')
default g10 = Gallery_image(image='gallery/glry10.jpg', condition='persistent.gal10')
default g11 = Gallery_image(image='gallery/glry11.jpg', condition='persistent.gal11')
default g12 = Gallery_image(image='gallery/glry12.jpg', condition='persistent.gal12')
default g13 = Gallery_image(image='gallery/glry13.jpg', condition='persistent.gal13')
default g14 = Gallery_image(image='gallery/glry14.jpg', condition='persistent.gal14')
default g15 = Gallery_image(image='gallery/glry15.jpg', condition='persistent.gal15')
default g16 = Gallery_image(image='gallery/glry16.jpg', condition='persistent.gal16')
default g17 = Gallery_image(image='gallery/glry17.jpg', condition='persistent.gal17')


default g18 = Gallery_image(image='gallery/glry18.jpg', condition='persistent.gal18')
default g19 = Gallery_image(image='gallery/glry19.jpg', condition='persistent.gal19')
default g20 = Gallery_image(image='gallery/glry20.jpg', condition='persistent.gal20')
default g21 = Gallery_image(image='gallery/glry21.jpg', condition='persistent.gal21')
default g22 = Gallery_image(image='gallery/glry22.jpg', condition='persistent.gal22')
default g23 = Gallery_image(image='gallery/glry23.jpg', condition='persistent.gal23')
default g24 = Gallery_image(image='gallery/glry24.jpg', condition='persistent.gal24')
default g25 = Gallery_image(image='gallery/glry25.jpg', condition='persistent.gal25')
default g26 = Gallery_image(image='gallery/glry26.jpg', condition='persistent.gal26')
style gal_header is text:
    font "Austie Bost You Wear Flowers Solid.ttf"
    antialias True
    color "#bbb"
    xalign 0.5
    ypos 0.02


screen gallery_screen():
    default o = 0
    $ page_items = 12
    $ bw = 340
    $ bh = 200
    # Ensure this replaces the main menu.
    tag menu

    add gui.main_menu_background
    add '#000000d5'
    frame padding(0,0) ysize 1.0 xfill True background None:
        text "Image Gallery" style "gal_header" size 50
        vpgrid cols 4:
            ypos 0.15
            spacing 40
            xalign 0.5
            # Create buttons for each image
            for g in gallery_images[o:o + page_items]:
                button padding(10,10):
                    if eval(g.condition) or persistent.unlock_gallery:
                        idle_background im.Scale("/gui/gallery/gal_idle.png", bw, bh)
                        hover_background im.Scale("/gui/gallery/gal_hover.png", bw, bh)
                        add im.Scale(g.image, bw-20, bh-20)
                        action Show("fullpic", pic=g.image)
                    else:
                        background im.Scale("/gui/gallery/gal_locked.png", bw, bh)
                        action NullAction()

        # Navigation bar
        hbox xalign 0.5 ypos 0.9 spacing 20:
            # Only enable "Previous" if we're not on the first page, to avoid negative offsets
            textbutton _("Previous") action [SensitiveIf(o > 0), SetScreenVariable("o", o - page_items)]

            for page in range(1, (len(gallery_images) / (page_items +1)) + 2):
                textbutton "[page]" action SetScreenVariable("o", (page-1) * page_items)

            # Only enable "Next" if we're not on the last page, to avoid list out-of-bounds
            textbutton _("Next") action [SensitiveIf(len(gallery_images) - o > page_items), SetScreenVariable("o", o + page_items)]
        textbutton _("Return"):
            xpos 0.9
            ypos 0.9
            action Return()

screen fullpic(pic=False):
    modal True zorder 30
    add pic
    button background None action Hide('fullpic')
