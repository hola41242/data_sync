init python:
    config.developer = True

default twinsSideStory0 = False
default SidestoryChloe0 = False

style ss_text is text:
    xalign 0.5
    yalign 0.5
    color "#9a2471"
    size 40

screen sideStories():
    default preview_img = None
    add gui.main_menu_background
    add '#000000d0'
    add "/gui/sidestories/ss_header.png"

    hbox xsize 1.0 yfill True:
        ypos 0.15
        vbox:
            xpos 0.2
            spacing 20
            button xysize(514,95):
                text "Ava & Olivia" style "ss_text"
                idle_background "/gui/sidestories/ss_idle.png"
                hover_background "/gui/sidestories/ss_hover.png"
                hovered SetScreenVariable("preview_img","images/SideStories/covers/twins_cover.png")
                unhovered SetScreenVariable("preview_img",None)
                action [SetVariable("twinsSideStory0", True),Start()]

            button xysize(514,95):
                text "Nightmare" style "ss_text"
                idle_background "/gui/sidestories/ss_idle.png"
                hover_background "/gui/sidestories/ss_hover.png"
                hovered SetScreenVariable("preview_img","images/SideStories/covers/nightmare_cover.jpg")
                unhovered SetScreenVariable("preview_img",None)
                action [SetVariable("SidestoryNightmare", True),Start()]
            button xysize(514,95):
                text "Chloe" style "ss_text"
                idle_background "/gui/sidestories/ss_idle.png"
                hover_background "/gui/sidestories/ss_hover.png"
                hovered SetScreenVariable("preview_img","images/SideStories/covers/chl1.jpg")
                unhovered SetScreenVariable("preview_img",None)
                action [SetVariable("SidestoryChloe0", True),Start()]
            button xysize(514,95):
                text "Coming soon..." style "ss_text"
                insensitive_background "/gui/sidestories/ss_insensitive.png"
                sensitive False
                action NullAction ()

        vbox:
            xfill True
            xpos 0.25
            button padding(10,10):
                idle_background "/gui/sidestories/ss_preview_box.png"
                hover_background "/gui/sidestories/ss_preview_box.png"
                add preview_img
                action NullAction()

    textbutton _("Return"):
        xpos 0.9
        ypos 0.9
        action Hide("sideStories")
