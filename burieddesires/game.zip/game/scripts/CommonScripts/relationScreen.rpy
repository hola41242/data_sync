screen lovePoint():
    add "lovePoint.png" xalign 0.95 yalign 0.05
    text "+1 Love" size 20 xalign 0.925 yalign 0.1
    timer 2.0 action Hide("lovePoint")
screen dominancePoint():
    add "dominancePoint.png" xalign 0.95 yalign 0.05
    text "+1 Dominance" size 20 xalign 0.94 yalign 0.1
    timer 2.0 action Hide("dominancePoint")
