default v03parknexttoher = False
default v03daisyforced = False
default v03mclovesjanet = False
default v03mcdaisycleaning = False
label v03:
    $config.allow_skipping = True
    scene rbys1 with fade
    pause
    mc "......."
    mc "Why did Janet say such a thing?"
    mc "Did someone say something to her"
    mc "Is that necessary, though? everything I've done so far has been extremely suspicious."
    mc "No extra factors are needed for a woman to suspect this"
    mc "What should I do about this.."
    mc "What are my feelings about this?"
    mc "[pD65]"
    mc "But is this enough for me.."
    scene rbys1v2 with fade
    menu:
        "I love her but..":
            $persistent.gal18 = True
            mc "But..."
            mc "I like other women too."
            mc "I have cheated on her many times but I still don't want to give up on her"
            mc "It's very selfish I know, but.."
            mc "Fuck.."
        "Maybe I should talk to her about it":
            mc "I have to tell her who I really am and that I still love her"
            mc "But will she accept it?"
            mc "Will she accept it unconditionally even if she does"
            mc "The most appropriate thing for this situation would be an open relationship"
            mc "But I can't share my woman with anyone"
            mc "It comes down to the fact that I am selfish."
            mc "The question is, do I deserve these selfish requests?"
            mc "..."
            mc "Obviously, yes, but still this does not prevent me from feeling bad"
        "[pD66]":
            mc "It's not just about Janet, it's going to affect [pD67] no matter what decision I make"
            mc "In the worst case, I could even lose [pD67]"
            mc "I don't want to break up with Janet, but if I have to make a choice"
            mc "I'll tell Janet I want to break up with her without telling her I cheated on her [pD68]"
            mc "But this time I'll upset the girls."
            mc "I can't take [pD69] away from them all of a sudden"
            mc "Agggh!"
            mc "Fuck!"
    mc "I think I have no choice, I will again, as always, let myself go with the flow and try to solve the problems I face"
    mc "Like I always do"
    mc "Anyway, I have a bigger problem, my class"
    menu:
        "Mia":
            $persistent.gal23 = True
            mc "I think Mia is whom I should pay the most attention to, Gabby did not warn in vain"
            mc "I have a feeling that the more I leave Mia alone, the more problems she will cause me."
            mc "I have to observe Mia for a while and make my own plans."
            mc "This should be my top priority"
        "Zoey":
            mc "The easiest target is Zoe"
            mc "It will be very easy to raise her grades and discipline her, so I can put it at the back as a priority order"
            mc "Or maybe I can get close to Zoe first and make her my secret snitch"
            mc "That way I can find out what's going on when I'm not around them"
            mc "Although it is a risky method, its return will be fast and efficient"
        "Twins":
            $persistent.gal25 = True
            mc "I think this is the most difficult problem I will have"
            mc "And on top of that, forced marriage nonsense"
            mc "Maybe I should give priority to the twins"
            mc "At least I can quickly find a solution to this ridiculous marriage problem"
            mc "But this can change a lot of things"
            mc "In fact, everything could be solved much easier if Olivia left Ava alone for a while"
            mc "In a few minutes, I can manipulate Ava and earn her loyalty"
            mc "Huh, at least I have a solid plan for the twins"
            mc "But I still don't know who to give priority to anyway"
    mc "Anyway, time for school"
    scene rbys2 with fade
    pause
    menu:
        "Park next to her":
            $v03parknexttoher = True
            scene rbys3 with fade
            pause
            mc "Huh, this is the first time I've seen this girl"
            mc "I already know what she's like"
            mc "I also know the reaction she will give when I park next to her"
            mc "I will do it"
            mc "Hehe"
            scene rbys4 with fade
            play sound "audio/carhonk.mp3"
            mc "Ehehehe"
            dai "What the.."
            scene rbys5 with fade
            pause
            dai "What the fuck man!"
            dai "The parking lot is almost completely empty, and you're trying to get in here asshole!"
            scene rbys6 with fade
            pause
            dai "Hey!"
            scene rbys7 with fade
            pause
            mc "What did you say, young lady?"
            scene rbys8 with fade
            pause
            dai "Young lady?"
            dai "Who do you think you are?"
            mc "I am a Teacher."
            scene rbys9 with fade
            pause
            dai "So?"
            mc "So, you need to be careful what you say."
            scene rbys10 with fade
            pause
            dai "You mean the asshole one?"
            mc "Yup exactly"
            dai "Okay then, asshole"
            mc "I'll warn you for the last time"
            dai "I don't think they told you about this school"
            mc "Sushh"
            scene rbys11 with fade
            pause
            dai "What did you say to me!?"
            mc "Be in my room 10 minutes before classes start"
            dai "Huh?"
            mc "You heard me"
            mc "Now close this door"
            mc "You're blocking the parking lot"
            scene rbys12 with fade
            pause
            dai "There is plenty spot in there"
            mc "Do it."
            scene rbys13 with fade
            pause
            dai "You are so done!"
            mc "I'm not gonna warn you again."
            scene rbys10 with fade
            pause
            dai "Fine, wait until you talk to my dad then you'll understand what kind of shit you're getting yourself into"
            mc "Sure missy, don't forget to go to Gabby's room and tell her about this situation before you call your dad"
            dai "Gabby.."
            dai "Who the hell are you man?"
            scene rbys11 with fade
            pause
            mc "In my room in 10"
            dai "......"
            scene rbys13 with fade
            pause
            mc "Now move!"
            dai "Asshole.."
            scene rbys14 with fade
            pause
        "Park somewhere else":
            scene rbys2 with fade
            pause
            mc "She looks like trouble, I've already had enough trouble"
            mc "Okay time to win the day"
    scene rbys15 with fade
    pause
    mc "Wait, that girl again"
    mc "Again no school uniform, does this girl live in the parking lot or what.."
    menu:
        "Say hi":
            $persistent.gal19 = True
            scene rbys16 with fade
            pause
            mc "Hey"
            scene rbys17 with fade
            pause
            prg "Yo"
            mc "Are you a student of this school?"
            scene rbys18 with fade
            pause
            prg "Nope"
            mc "So why are you always here, that is, in the parking lot?"
            prg "I love it here, it has a different aura"
            mc "Mhm hm"
            mc "How does security let you in"
            scene rbys19 with fade
            pause
            prg "Like this"
            scene rbys21 with fade
            pause
            mc "Okay, that makes sense"
            scene rbys22 with fade
            pause
            prg "Yeah"
            mc "Does this always work?"
            prg "Yup"
            mc "Like?"
            scene rbys23 with fade
            pause
            prg "Like almost everything"
            prg "Food, coffee, ride, beer, weed and other stuff"
            scene rbys24 with fade
            pause
            mc "Damn"
            mc "Are you not afraid at all?"
            scene rbys22 with fade
            pause
            prg "From what?"
            mc "I don't know, maybe harassment, rape, or public pressure"
            scene rbys23 with fade
            pause
            prg "Nope"
            mc "You're weird"
            scene rbys22 with fade
            pause
            prg "Sure, I don't have a problem with this"
            mc "Huh"
            mc "Is there anything you want to ask me?"
            scene rbys24 with fade
            pause
            prg "Uhmmm"
            scene rbys23 with fade
            pause
            prg "No, I guess nothing"
            scene rbys22 with fade
            pause
            mc "Cool"
            mc "One last thing"
            mc "You show me your boobs"
            mc "But I'm not going to give you anything for this"
            scene rbys25 with fade
            pause
            prg "Wanna give me some money?"
            mc "No"
            scene rbys22 with fade
            pause
            prg "Okay"
            mc "Do you want money from me?"
            scene rbys23 with fade
            pause
            prg "Yeah, who wouldn't?"
            mc "So how will you feel if I don't?"
            prg "Nothing I already have enough money."
            mc "Wait"
            mc "You have enough money, why do you use your body to get something"
            scene rbys26 with fade
            pause
            prg "Give money, get the change, it's very difficult"
            prg "All I have to do is slip the T-shirt up"
            mc "What the?"
            mc "Every answer you give is so logical, yet so illogical."
            prg "welcome to the 21st century"
            mc "Huh.."
            scene rbys27 with fade
            pause
            mc "Okay then see you later"
            prg "Cya"
            menu:
                "Ask one more time":
                    scene rbys22 with fade
                    pause
                    mc "You know what? I want to see them again."
                    scene rbys24 with fade
                    pause
                    prg "My boobs?"
                    mc "Yeah"
                    scene rbys28 with fade
                    pause
                    prg "Sure"
                    mc "Nice"
                    prg "Have a good day."
                "Don't":
                    scene rbys27 with fade
                    pause
                    mc "Time to go to school"
        "Go to school":
            pass
    scene rbys30 with fade
    pause
    mc "God damn I miss this"
    mc "Wait do i.."
    mc "Anyway, let's say hi to the girls"
    scene rbys31 with fade
    pause
    mc "Morning girls."
    scene rbys32 with fade
    pause
    tw2 "Oh you.. Amazing.."
    tw1 "Hey mister teacher"
    ky "Hm?"
    scene rbys33 with fade
    pause
    ky "Excuse me, but I'm in the middle of something."
    mc "With Kayla?"
    ky "Congratulations, you can remember a name."
    mc "Yeah"
    mc "I think I'll hate you the most"
    ky "Oh no"
    ky "What should I do now.."
    mc "Olivia"
    scene rbys34 with fade
    pause
    tw2 "Yes?"
    mc "After class, come to my room with Ava, I want to talk to you"
    tw2 "No need"
    tw1 "I can come"
    tw2 "No you can't either"
    mc "This is not a request"
    tw2 "Ugh"
    scene rbys35 with fade
    pause
    ky "Hey"
    scene rbys36 with fade
    pause
    mc "Don't hey people"
    mc "Especially your teacher"
    scene rbys37 with fade
    pause
    ky "I'll say this in the most civilized way possible"
    scene rbys35 with fade
    pause
    ky "You're interrupting our conversation right now"
    ky "I promise you, I'll make an effort to look like I'm accepting your authority in the classroom"
    mc "Does this arrogance come from wealth, or is it an innate disease?"
    mc "I have never really met a person as repulsive as you, not even in the movies"
    scene rbys38 with fade
    pause
    ky "That's what you think, because you've never met a person like me before"
    ky "But trust me, in time you will understand very well what I mean"
    ky "Can't wait"
    scene rbys39 with fade
    pause
    mc "You like this, don't you?"
    mc "You want someone to challenge you all the time"
    mc "I know your type"
    mc "Spoiler alert, you are not special.."
    scene rbys37 with fade
    pause
    ky "Yeah yeah, keep talking"
    ky "In fact"
    scene rbys40 with fade
    pause
    ky "You should talk when I leave"
    ky "Because it's the same thing if I'm here or I'm not here"
    ky "It has no effect"
    scene rbys41 with fade
    pause
    tw2 "I think it has Mr Teacher, I like your talking"
    scene rbys42 with fade
    pause
    tw2 "No you don't"
    scene rbys43 with fade
    pause
    tw2 "Thank you for getting rid of her."
    mc "I guess I didn't have an effect, she wanted to leave and she left"
    tw2 "Yes, that's exactly what happened"
    tw2 "But you still helped me get rid of her early"
    mc "And?"
    tw2 "That's it"
    mc "No thank you?"
    tw2 "Nope"
    mc "Better than nothing"
    tw1 "Thank you so much Mr. Teacher"
    tw1 "Kayla was angry at me, Olivia was defending me"
    mc "What have you done to her?"
    scene rbys45 with fade
    pause
    tw2 "Doesn't matter, no one can be mad at Ava except me"
    tw2 "I don't know what it looks like from the outside, but whoever is under my wing"
    tw2 "can only get scolded by me."
    scene rbys46 with fade
    pause
    "Is Ava impersonating Olivia.."
    scene rbys47 with fade
    pause
    tw2 "And also let this be a warning to you"
    tw2 "You can be a teacher, but I'm responsible for all of Ava's actions"
    scene rbys48 with fade
    pause
    "I shouldn't laugh..."
    tw2 "I want you to talk to me when there's a problem with Ava"
    tw2 "...."
    scene rbys49 with fade
    pause
    tw2 "Are you laughing?"
    mc "Ahm ahm, no"
    tw2 "......."
    scene rbys50 with fade
    pause
    scene rbys51 with fade
    pause
    tw2 "Ava.."
    scene rbys52 with fade
    pause
    scene rbys53 with fade
    pause
    tw1 "What's the matter, sister?"
    tw2 "Seriously?"
    tw2 "In front of him.."
    tw1 "I have no idea what u're talking about sis"
    scene rbys54 with fade
    pause
    tw2 "We will talk about this later"
    tw1 "Mhm hmm"
    scene rbys55 with fade
    pause
    tw1 "Good bye Mr. Teacher, thank you for punching that asshole"
    scene rbys56 with fade
    pause
    tw2 "Just come!"
    tw1 "I can't wait to see you again, Mr Teacher"
    tw2 "Ava!"
    scene rbys57 with fade
    pause
    "Aah I fucking love them so much.."
    "Wait.."
    "Do I?"
    "When.."
    "I think I'm getting used to girls"
    scene rbys57 with fade
    pause
    scene rbys58 with fade
    pause
    mc "Huh?"
    mc "Oh, Zoey"
    scene rbys59 with fade
    pause
    sy "Hi.."
    mc "Hi, I haven't had a chance to talk to you much"
    sy "Yes"
    mc "Is everything all right?"
    scene rbys60 with fade
    pause
    sy "Mhm hm"
    mc "Amazing"
    mc "What was it you wanted to say?"
    sy ".."
    mc "You just poked me. You want to say something"
    scene rbys61 with fade
    pause
    sy "I just wanna say"
    sy "Thank you"
    mc "For what?"
    scene rbys60 with fade
    pause
    sy "For being mean to those cruel girls"
    mc "Honey, I don't treat them badly"
    mc "I'm just following the right path"
    sy "Doesn't matter, thank you for causing them pain and suffering"
    "What the hell.."
    mc "What?"
    sy "I can't wait for the lesson"
    mc "Okay..."
    "This is weird.."
    "Anyway, let's see"
    $v03m0_s0 = False
    $v03m0_s1 = False
    if v03parknexttoher == True:
        jump v03gabyroom
    else:
        menu v03m0:
            "Teachers' room" if not v03m0_s0:
                $v03m0_s0 = True
                jump v03teachersRoom
            "My room" if not v03m0_s1:
                $v03m0_s1 = True
                jump v03mcroom
    jump v03teachersRoomMls
label v03teachersRoom:
    scene rbys63 with fade
    pause
    mc "Hello"
    mc "Huh.."
    mc "Mia and Clara"
    mc "It seems like a boss who scolds his employee"
    menu:
        "Interrupt":
            scene rbys64 with fade
            pause
            scene rbys65 with fade
            pause
            mc "What is going on there?"
            scene rbys66 with fade
            pause
            m1 "Uhmm, you're interrupting us.?"
            mc "Why are you sitting in that chair and why is Miss Clara standing in front of you"
            scene rbys67 with fade
            pause
            m1 "Ugh, here we go again.."
            m1 "You and your questions.."
            m1 "Both are unnecessary.."
            mc "Hey!"
            mc "You can't talk to me like that"
            scene rbys68 with fade
            pause
            m1 "I can and I will"
            m1 "But chill, I'm done already"
            mc "You're done?"
            mc "What does this mean"
            m1 "Something, something I wouldn't even bother to tell you"
            mc "Excuse me?"
            m1 "Nope I can't"
            mc "Wait, this is my thing!"
            m1 "Not anymore."
            scene rbys69 with fade
            pause
            m1 "...."
            scene rbys70 with fade
            pause
            mc "What was that?"
            tc1 "Something you will understand soon."
            mc "Yeah, don't think so"
            tc1 "I have to go"
            scene rbys70 with fade
            pause
        "Don't":
            pass
    jump v03m0
label v03gabyroom:
    mc "I have a little more time before the lesson starts, what should I do"
    mc "Let's visit that bitch"
    scene rbys74 with fade
    pause
    mc "She seems tired like always"
    scene rbys75 with fade
    pause
    mc "Hey Gab"
    scene rbys76 with fade
    pause
    sm "Gab ?"
    sm "You can't call me a nickname, [mc]"
    mc "Why, I think we've been intimate enough"
    sm "Ugh, what do you want?"
    mc "Nothing, I thought I'd stop by before class"
    scene rbys78 with fade
    pause
    sm "..."
    scene rbys79 with fade
    pause
    sm "You don't need to do that"
    mc "I know"
    mc "But I want to"
    scene rbys78 with fade
    pause
    sm "Whatever"
    scene rbys77 with fade
    pause
    sm "You've met Miss Daisy"
    mc "Yep"
    sm "She came to complain about you."
    mc "Yeah"
    sm "This is not good"
    mc "How so"
    sm "If you could establish enough authority, they wouldn't come to complain."
    mc "It's okay, this is just the beginning"
    sm "I hope so"
    mc "Chill Gaby, I got this"
    scene rbys79 with fade
    pause
    sm "Stop calling me that"
    mc "Anyway, I'm going to class"
    mc "Is there anything you want to say?"
    sm "Hmm"
    scene rbys77 with fade
    pause
    sm "Oh I almost forgot"
    sm "Bill said he wanted to talk to you at dinner"
    mc "Bill ?"
    sm "The big boss who came the other day"
    mc "Oh that ugly fat asshole"
    sm "Yeah that's him"
    mc "Why ?"
    sm "He probably wants to get to know you a little more"
    mc "He's not exactly my type.."
    scene rbys78 with fade
    pause
    sm "Funny"
    scene rbys77 with fade
    pause
    sm "He won't be alone, he wants you there while he's having dinner with his family"
    mc "That's weird"
    mc "Wait,does this mean I have to bring my family too"
    sm "No, but bring them if you want"
    mc "No thanks"
    mc "Are you gonna be there?"
    sm "Nope"
    mc "How about Chloe ?"
    sm "No, that fat asshole can harass Chloe more because I'm not there"
    mc "When he's with his family?"
    sm "Yeah, the advantages of being strong"
    sm "He can do what he wants"
    mc "Must be nice"
    sm "It is.."
    mc "Anyway, we'll talk, I'm going to class"
    sm "Good luck"
    jump v03m0
label v03mcroom:
    scene rbys72 with fade
    pause
    mc "Aaah silence"
    mc "Nice"
    scene rbys73 with fade
    pause
    if v03parknexttoher == True:
        scene rbys80 with fade
        pause
        mc "Come"
        scene rbys81 with fade
        pause
        scene rbys82 with fade
        pause
        dai "Okay I'm here, now what?"
        mc "Good question"
        mc "That's for you to decide"
        dai "Ugh, get to the point"
        scene rbys83 with fade
        pause
        mc "Sit"
        scene rbys84 with fade
        pause
        dai "..."
        dai "Ugh.."
        scene rbys85 with fade
        pause
        dai "Yes, I'm listening to you"
        mc "Did you go and see Gabby?"
        dai "...."
        dai "Yes."
        mc "What did she say?"
        scene rbys86 with fade
        pause
        dai "Respect your authority"
        mc "Mhmm hmmm"
        mc "That's why you're here"
        dai "Yes"
        mc "Now I'm asking"
        mc "Can you understand your situation?"
        dai "No"
        scene rbys88 with fade
        pause
        mc "Look, it makes no difference who you are"
        mc "Very rich, very powerful, very intelligent etc."
        mc "No matter who you are, there must be someone above you"
        mc "Before you meet them, you think the whole world revolves around you"
        mc "There is no person in the world who can be the strongest in every room"
        scene rbys87 with fade
        pause
        dai "Yeah yeah cool, I got it"
        dai "As I said before, I will respect your authority within the school boundaries"
        dai "Can I go now?"
        mc "No"
        scene rbys90 with fade
        pause
        dai "Why?"
        mc "Because you're only saying all this to get away"
        dai "Duh"
        scene rbys89 with fade
        pause
        mc "I'm sorry, but to ensure my authority, you need to understand that such behavior will not go unpunished"
        dai "You can't be serious"
        mc "Unfortunately"
        scene rbys90 with fade
        pause
        dai "C'mon man, it's just.."
        scene rbys89 with fade
        pause
        dai "Sir."
        mc "Better"
        dai "..."
        scene rbys90 with fade
        pause
        dai "Fine, what should I do?"
        menu:
            "For 1 Week you will come and clean this room before me":
                $v03mcdaisycleaning = True
                mc "It doesn't get dirty much, but it still holds dust"
                mc "Every day the dust of this room will be removed properly"
                mc "And of course I will check"
                dai "I've never cleaned up once in my life."
                mc "Great, then you'll do it for the first time because of me"
                dai "..."
                dai "I can't believe it..."
                mc "Most of them can't"
                mc "That's all"
                mc "You can go"
            "The assignment I will give you will be delivered within 1 week":
                mc "And believe me, this assignment will be a really difficult one"
                mc "Also, if I don't like the assignment you've done, I'll give you a more difficult assignment"
                mc "If you fail again, your punishment will turn into something that involves humiliation instead of homework"
                dai "Huh?"
                mc "It's like waiting in the hallway on one leg"
                dai "You can't do that"
                mc "Try me"
                dai "...."
                mc "That's all"
                mc "you can go"
            "It's up to you":
                scene rbys90 with fade
                pause
                dai "What do you mean when you say it's up to me?"
                mc "I want you to determine the punishment yourself"
                scene rbys87 with fade
                pause
                dai "Hah easy!"
                mc "But"
                scene rbys86 with fade
                pause
                dai "Of course.."
                mc "If I don't like this punishment, I'll give you a heavier punishment than usual, and you won't have a choice"
                scene rbys89 with fade
                pause
                dai "...."
                dai "What are you after?"
                mc "..."
                dai "Sir.."
                mc "No idea what are you talking about"
                mc "So, did you choose?"
                scene rbys90 with fade
                pause
                dai "...."
                dai "Just tell me what should I do?"
                mc "No, you are going to tell me"
                dai "I know what you're thinking.."
                mc "Like I say, no idea what you're talking about."
                dai "Well I have to admit this is pretty smart"
                dai ".."
                scene rbys89 with fade
                pause
                dai "Okay then, I'll show you my boobs, that should be enough"
                menu:
                    "Get angry":
                        scene rbys101 with fade
                        pause
                        mc "What!"
                        mc "This is an extremely inappropriate offer!"
                        mc "You're in trouble"
                        scene rbys92 with fade
                        pause
                        dai "Wait.."
                        scene rbys93 with fade
                        pause
                        dai "Weren't you trying to abuse me without getting stuck in legal boundaries?"
                        mc "Ugh fucking millennium.."
                        scene rbys94 with fade
                        pause
                        dai "Okay then sorry for this, I misunderstood"
                        mc "Nah, I can't ignore it"
                        mc "I need to talk to the disciplinary committee first, and then to your family"
                        scene rbys103 with fade
                        pause
                        dai "No!"
                        dai "Please I can do anything"
                        mc "Like?"
                        dai "Like I have so much money"
                        mc "Everyone has a lot of money"
                        dai "What do you want?"
                        mc "More than boobs"
                        scene rbys104 with fade
                        pause
                        dai "what the..."
                        dai "You tricky asshole.."
                        dai "I can't believe I fell for that"
                        dai "Sick bastard!"
                        mc "Excuse me?"
                        dai "...."
                        mc "Sit."
                        dai "...."
                        scene rbys98 with fade
                        pause
                        dai "Fine, I'll also show my pussy"
                        mc "Oh honey.."
                        mc "No, not good enough.."
                        scene rbys99 with fade
                        pause
                        dai "What you want dude, do you wanna fuck me right here!"
                        mc "Well.."
                        scene rbys100 with fade
                        pause
                        dai "No way!"
                        mc "How about a bj?"
                        dai "No!"
                        mc "Okay then give me a handjob, I won't go any lower than this"
                        mc "Take it or leave it"
                        scene rbys102 with fade
                        pause
                        dai "......"
                        dai "Can't believe this !"
                        scene rbys87 with fade
                        pause
                        dai "Wait"
                        dai "What I said that it would not matter"
                        dai "Who would they believe if I report you?"
                        dai "You can't prove that I said all this"
                        scene rbys105 with fade
                        pause
                        mc "Yeah I can"
                        mc "My phone is recording it"
                        scene rbys106 with fade
                        pause
                        dai "So what, it also recorded what you said"
                        mc "Have you heard of the stop recording button before?"
                        scene rbys107 with fade
                        pause
                        dai "..."
                        scene rbys108 with fade
                        pause
                        dai "Fuck you!"
                        mc "HEY!"
                        dai "..."
                        scene rbys107 with fade
                        pause
                        dai "Fine but only one time"
                        mc "Shut up"
                        mc "You'll do as I say"
                        scene rbys108 with fade
                        pause
                        dai "But this is not legal"
                        mc "Shut up and grab my dick"
                        dai "..."
                        scene rbys109 with fade
                        pause
                        mc "What do you think?"
                        scene rbys110 with fade
                        pause
                        dai ".."
                        mc "Aww is this your first time?"
                        scene rbys111 with fade
                        pause
                        dai "No I have a boyfriend.."
                        scene hmmmmmm_3
                        mc "Is he bigger than me?"
                        dai "..."
                        mc "Answer!"
                        scene rbys112 with fade
                        pause
                        dai "No.."
                        mc "Nice"
                        mc "Okay then, be quick, I have a class"
                        scene hmmmmmm_4
                        pause
                        scene rbys113 with fade
                        pause
                        scene rbys114 with fade
                        pause
                        dai "Eww..."
                        dai "It's all over my leg!"
                        dai "How am I gonna clean this up?.."
                        mc "I'm sure you can find a solution"
                        dai "But.."
                        mc "Yeah whatever, now get lost."
                        scene rbys115 with fade
                        pause
                        dai "Fucking hate you"
                        mc "Sure."
                        "This is not good.."
                        "But I can't control myself."
                        "She was already bad, there's no need to sympathize with her."
                        "Heh I bet Hitler thought like this.."
                        "I'm not Hitler.."
                        "Or am I.."
                        "Nah I'm just a teacher at a school where there are spoiled rich and bad girls"
                        "Yep, I'm still a good guy."
                    "Push more":
                        $v03daisyforced = True
                        scene rbys91 with fade
                        pause
                        mc "Just boobs?"
                        mc "Why would this satisfy me?"
                        mc "I want more"
                        scene rbys96 with fade
                        pause
                        dai "No, boobs or nothing"
                        mc "Nah, this is not a sufficient punishment."
                        scene rbys100 with fade
                        pause
                        dai "You can't touch me or anything"
                        mc "Okay then I'll fap without touching you"
                        scene rbys98 with fade
                        pause
                        dai "Eww no"
                        mc "Then I'll give you really hard task for punishment"
                        scene rbys102 with fade
                        pause
                        dai "..."
                        dai "Fuck"
                        scene rbys94 with fade
                        pause
                        dai "Fine"
                        dai "Make it quick, if it's possible."
                        mc "Well you can make it quick.."
                        scene rbys97 with fade
                        pause
                        dai "No!"
                        scene rbys98 with fade
                        pause
                        dai "I'm just going to stay here and wait"
                        mc "Take off your clothes"
                        scene rbys116 with fade
                        pause
                        dai "There's no other option anyway"
                        mc "How so?"
                        dai "This is a one-piece uniform, I need to take it off completely"
                        scene rbys117 with fade
                        pause
                        dai "Panties became a bonus for you"
                        mc "Lucky me"
                        dai "Yeah.."
                        mc "Turn around, it will be a surprise to you too"
                        dai "Your dick is out right"
                        mc "You spoiled the whole surprise"
                        dai "Ha ha so funny"
                        scene rbys118 with fade
                        pause
                        scene rbys119 with fade
                        pause
                        mc "What are you waiting for?"
                        dai "Mentally getting ready"
                        mc "We're not gonna fuck, girl.."
                        dai "Yeah but still.."
                        mc "Turn now"
                        dai "..."
                        scene rbys120 with fade
                        pause
                        mc "Nice.."
                        dai "Really.."
                        mc "Kind of, you're still hiding most of it"
                        scene rbys121 with fade
                        pause
                        mc "Damn.."
                        dai "What.."
                        mc "Your tits"
                        dai "What about them?"
                        mc "They're perfect.."
                        dai "You mean it?"
                        mc "Yeah, you care?"
                        scene rbys122 with fade
                        pause
                        dai "No.."
                        mc "You sure?"
                        scene rbys123 with fade
                        pause
                        dai "Yes.."
                        mc "Yeah sure, okay it's your turn"
                        mc "Look at my dick"
                        scene rbys124 with fade
                        pause
                        dai "......"
                        scene rbys125 with fade
                        pause
                        mc "C'mon just look.."
                        mc "How is it?"
                        scene rbys126 with fade
                        pause
                        dai "...."
                        scene rbys127 with fade
                        pause
                        dai "Disgusting."
                        mc "Aww, is this the first time you see a penis?"
                        scene rbys128 with fade
                        pause
                        dai "No, I have a boyfriend"
                        scene rbys125 with fade
                        pause
                        mc "Uh huh"
                        mc "Is he bigger than me?"
                        scene rbys126 with fade
                        pause
                        dai "..."
                        scene rbys127 with fade
                        pause
                        dai "No.."
                        scene rbys125 with fade
                        pause
                        mc "Then this is your first real penis, darling"
                        dai "..."
                        scene rbys127 with fade
                        pause
                        dai "Can you be faster, please?"
                        scene rbys125 with fade
                        pause
                        mc "With only boobs? Nope.."
                        scene rbys121 with fade
                        pause
                        mc "Hey"
                        dai "What?"
                        scene rbys125 with fade
                        pause
                        mc "don't look away, look at me"
                        dai "Why.."
                        mc "This will make it end faster"
                        dai "Fine.."
                        scene rbys126 with fade
                        pause
                        mc "I want you to look into my eyes and then at my penis"
                        dai "Ugh.."
                        mc "You like this, don't you ?"
                        scene rbys127 with fade
                        pause
                        dai "No.."
                        mc "Hah you like it"
                        mc "If you don't help me, we'll both miss class"
                        scene rbys130 with fade
                        pause
                        dai "I told you, you can't touch me!"
                        mc "No need, just be sexy"
                        scene rbys124 with fade
                        pause
                        dai "..."
                        scene rbys131 with fade
                        pause
                        dai "Fine"
                        scene rbys132 with fade
                        pause
                        dai "Like this?"
                        mc "Ugh you're not taking a photo.."
                        mc "You know what? Let's do like this"
                        menu:
                            "Cute":
                                scene rbys131 with fade
                                pause
                                mc "Be as cute as possible"
                                dai "Oh you like cute things huh?"
                                dai "I can be cute"
                                scene rbys133 with fade
                                pause
                                dai "Look"
                                mc "Another"
                                scene rbys134 with fade
                                pause
                                dai "Fine..."
                                mc "Amazing"
                                mc "One more"
                                scene rbys135 with fade
                                pause
                                dai "..."
                                scene rbys136 with fade
                                pause
                                scene rbys137 with fade
                                pause
                                dai "Stop smiling.."
                                mc "Can't help it, you are so cute"
                                dai "...."
                                dai "Shut up.."
                                mc "Perfect"
                            "Sexy":
                                scene rbys131 with fade
                                pause
                                mc "Try to be sexy as hell"
                                dai "So I should be myself"
                                mc "Aww that's so cute"
                                scene rbys138 with fade
                                pause
                                dai "No it's hot, not cute.."
                                mc "This means that you need to prove how sexy you can be."
                                scene rbys139 with fade
                                pause
                                dai "Isn't that enough?"
                                mc "Would we be having this conversation if it were enough?"
                                scene rbys140 with fade
                                pause
                                dai "Hate you.."
                                mc "C'mon you can do it"
                                scene rbys141 with fade
                                pause
                                dai "Here"
                                scene rbys142 with fade
                                pause
                                mc "Not bad, but you can do better"
                                scene rbys143 with fade
                                pause
                                dai "What about this"
                                scene rbys144 with fade
                                pause
                                mc "You are getting good"
                                mc "Try again"
                                dai "No one can resist this"
                                mc "C'mon do your best"
                                scene rbys145 with fade
                                pause
                                mc "Perfect"
                            "Shy":
                                scene rbys131 with fade
                                pause
                                mc "I want you to be shy"
                                dai "...."
                                scene rbys146 with fade
                                pause
                                dai "Like that?"
                                mc "Hah"
                                dai "What.."
                                mc "You are really cute"
                                scene rbys147 with fade
                                pause
                                dai "Shut up.."
                                mc "But not shy enough"
                                scene rbys148 with fade
                                pause
                                dai "What should I do?"
                                scene rbys149 with fade
                                pause
                                mc "Try something else"
                                scene rbys150 with fade
                                pause
                                dai "Like this?"
                                mc "Not bad at all"
                                dai "You are hard to please.."
                                mc "Nope, I'm pleased already.."
                        mc "Yeah that's much better"
                        mc "Turn around and bend over"
                        scene rbys151 with fade
                        pause
                        dai "NO!"
                        mc "Calm, I'm not gonna touch you, just wanna see your ass"
                        scene rbys152 with fade
                        pause
                        dai "Ok, but I won't take my panties down"
                        mc "Just bend over!"
                        scene rbys154 with fade
                        pause
                        dai "Here.."
                        mc "Nice.."
                        mc "Okay I'm about to cum"
                        scene rbys153 with fade
                        pause
                        dai "Finally"
                        scene rbys155 with fade
                        pause
                        mc "Igghh.."
                        scene rbys156 with fade
                        pause
                        mc "Fuck it was good, but not that good"
                        mc "Just good"
                        scene rbys157 with fade
                        pause
                        dai "Should I be sad."
                        scene rbys158 with fade
                        pause
                        mc "Nah you should be proud"
                        mc "You just managed to make me cum with just boobs"
                        mc "This is, in a way, a success"
                        mc "Hey you can proud of yourself"
                        scene rbys159 with fade
                        pause
                        dai "Whatever"
                        dai "Can I go?"
                        mc "Sure, after cleaning my room"
                        scene rbys160 with fade
                        pause
                        dai "Hah nice one"
                        mc "..."
                        dai "You are kidding, right?"
                        mc "Nope"
                        scene rbys161 with fade
                        pause
                        dai "What!"
                        scene rbys162 with fade
                        pause
                        mc "Yeah this is the second part of your punishment"
                        mc "You just stood there, it's not a punishment"
                        mc "I'll check later, if you do it sloppy, I will punish you again"
                        dai "..."
                    "Accept":
                        scene rbys85 with fade
                        pause
                        mc "Hmm, sure why not?"
                        scene rbys87 with fade
                        pause
                        dai "Huh?"
                        mc "What?"
                        scene rbys90 with fade
                        pause
                        dai "I didn't think it would be so easy."
                        dai "Is this a psychological game you're doing?"
                        scene rbys91 with fade
                        pause
                        mc "No it's not. But I'm not gonna push it"
                        mc "You are not that pretty"
                        scene rbys92 with fade
                        pause
                        dai "What.."
                        mc "Yeah, now go to your class"
                        mc "And don't forget, I'm watching you."
                        scene rbys98 with fade
                        pause
                        dai "Asshole.."
                        mc "What?"
                        scene rbys99 with fade
                        pause
                        dai "I'm pretty!"
                        mc "..."
                        mc "Sorry.."
                        mc "It just.."
                        scene rbys104 with fade
                        pause
                        dai "I hate you!"
                        scene rbys115 with fade
                        pause
                        "Waow that was.."
                        "Fuck me.."
                    "Punish her appropriately":
                        scene rbys91 with fade
                        pause
                        mc "I'll ignore what you're saying."
                        mc "I decide your punishment"
                        mc "You will clean my room after school for 1 Week"
                        mc "If I'm not satisfied with the result, your sentence will be extended"
                        mc "Is that understood?"
                        dai "..."
                        scene rbys107 with fade
                        pause
                        dai "I offered you my boobs.."
                        mc "That's why you're already getting such a heavy punishment"
                        scene rbys108 with fade
                        pause
                        dai "I'm sorry ?"
                        mc "No you are not"
                        dai "I thought you might want to see.."
                        mc "You thought wrong"
                        scene rbys99 with fade
                        pause
                        dai "Why, am I not pretty enough.."
                        scene rbys101 with fade
                        pause
                        mc "This has nothing to do with beauty"
                        mc "Discipline."
                        mc "But I think you're pretty beautiful."
                        scene rbys86 with fade
                        pause
                        dai "..."
                        dai "Heh I don't care what you think about me"
                        mc "Sure, see you"
                        mc "And don't forget I'm watching you."
                        scene rbys115 with fade
                        pause
                        dai "..."
    $v03m0_1 = True
    jump v03m0
label v03teachersRoomMls:
    scene rbys163 with fade
    pause
    mc "Hmm"
    mc "There's nobody"
    scene rbys164 with fade
    pause
    mc "I'll get a coffee and go to class, there's already someone.."
    scene rbys165 with fade
    pause
    mls "Hey"
    mc "Hey"
    mls "Do I know you ?"
    mc "Now that you've asked, no"
    scene rbys166 with fade
    pause
    mls "Are you a parent?"
    mc "Nope, I'm the new teacher"
    mc "You ?"
    scene rbys167 with fade
    pause
    mls "I am a teacher."
    mls "Have you just started?"
    mc "Kinda"
    scene rbys168 with fade
    pause
    mls "This is my first day at school"
    mc "Where were you before?"
    scene rbys170 with fade
    pause
    menu:
        "Peek closer":
            $persistent.gal21 = True
            scene rbys171 with fade
            pause
            "God damn she is hot.."
    mls "I was at another affiliate of this school"
    mc "Why are you assigned here?"
    scene rbys172 with fade
    pause
    mls "Because I've completed my mission there"
    mc "Mission?"
    scene rbys173 with fade
    pause
    mls "I go to affiliates with a low GPA and make things right"
    "Gaby hadn't told me about it, I thought I was the first and only one.."
    scene rbys174 with fade
    pause
    mc "Hah"
    mc "I'm here precisely for this reason"
    scene rbys175 with fade
    pause
    mls "Hmmm"
    mls "Which affiliate were you in before?"
    mc "I have been in public schools before, this is my first in college"
    scene rbys176 with fade
    pause
    mls "Oh, is that so.."
    mc "How many times have you been doing this?"
    mls "This is my 6th"
    mc "That's impressive"
    mls "That's why I'm here"
    scene rbys177 with fade
    pause
    "They think I couldn't handle it myself huh.."
    menu:
        "Peek":
            $persistent.gal22 = True
            scene rbys179 with fade
            pause
            scene rbys180 with fade
            pause
    scene rbys178 with fade
    pause
    mls "So"
    mls "Did you like it?"
    mc "What ?"
    mls "You are checking me again"
    mls "And I'm asking because I'm wondering if you like it?"
    mc "I.."
    mc "Yeah, I like it"
    mls "This answer was not a certain answer"
    scene rbys179 with fade
    pause
    scene rbys180 with fade
    pause
    scene rbys181 with fade
    pause
    mls "Here take a better look"
    scene rbys182 with fade
    pause
    mc "Nice.."
    scene rbys183 with fade
    pause
    scene rbys184 with fade
    pause
    mc "But, I can't quite see the ribbon blocking the image"
    scene rbys182 with fade
    pause
    mls "There is another fabric on the back of this ribbon, so why bother with the ribbon?"
    mc "I.."
    mc "Huh"
    mls "Exactly"
    scene rbys181 with fade
    pause
    mls "You can also look at it from another angle"
    mc "Yeah"
    mc "Anyway"
    mc "Okay then, I'm going to my class"
    mc "And nice to meet you"
    mls "Me too"
    mls "But we should talk more about this"
    mc "About the ribbon?"
    mls "That too"
    mc "Agreed"
    scene rbys185 with fade
    pause
    mls "See you soon"
    mc "[mc]"
    mls "Melissa"
    "God damn she is smoking hot.."
label v03class:
    scene rbys186 with fade
    pause
    mc "Morning class"
    mc "Yeah well, that's what I thought."
    scene rbys187 with fade
    pause
    mc "Now I will ask you a question"
    mc "Then I would like you to make a summary on blank papers"
    mc "There are no right or wrong answers."
    mc "There is only one rule"
    mc "The answer should be at least half the page"
    scene rbys188 with fade
    pause
    mc "Before I finish my sentence, I can see that many of you are thinking about why I should do this."
    mc "Trust me, the papers you will give me this day will have a great impact on my attitude towards you in the coming days"
    mc "In short, don't make me angry"
    mc "My question"
    mc "What do you see when you look in the mirror"
    mc "Stop grumbling"
    mc "You can Start"
    mc "No questions"
    scene rbys190 with fade
    pause
    mc "Come"
    att "I'm sorry to interrupt, but Miss Gaby wants to see you."
    mc "She couldn't wait till the break ? "
    att "Unfortunately"
    mc "Fine"
    scene rbys191 with fade
    pause
    att "Is there anything else you want me to help you with, Ms Gaby"
    sm "No, thanks, you can leave"
    scene rbys192 with fade
    pause
    mc "Is everything all right ?"
    scene rbys193 with fade
    pause
    sm "Yes, Ms I called you to meet Melissa as early as possible and coordinate"
    mc "Hmm"
    sm "Have a seat"
    scene rbys194 with fade
    pause
    sm "I understand that you have already met"
    scene rbys195 with fade
    pause
    mc "Yeah.."
    mls "Yes, briefly"
    scene rbys196 with fade
    pause
    sm "Good, this is the first time you're attending this meeting right now, [mc]"
    sm "I haven't given you a lot of details so far, but from this day on, you will learn more details"
    sm "As you can see, Miss Melissa was assigned to a different affiliate many years ago in the same position that you were brought in for"
    sm "So far, our big bosses are satisfied enough with Miss Melissa"
    mc "But ?"
    sm "Yep there is always a but"
    scene rbys197 with fade
    pause
    sm "Miss Melissa not only has all the alpha traits, but also has a very strong aura as a first impression"
    sm "But still this does not change the fact that she is not a man"
    sm "Yes, so far she is doing quite successfully"
    sm "But it can't get to the level we want"
    sm "On the other hand, you"
    sm "You also have many of the features that Melissa has, although the difference in experience is huge"
    sm "The wisest move to make in this case is"
    scene rbys196 with fade
    pause
    mc "We will become better by working under my command"
    mc "In short, we will become a deadly team"
    scene rbys197 with fade
    pause
    sm "Not exactly"
    sm "Yes, you have everything we are looking for, but this does not cover your inexperience"
    sm "Miss Melissa will be your mentor"
    mc "I don't think that's really a good idea."
    sm "Yes, it is"
    sm "You are the best for this job, but you are too slow"
    sm "And she won't boss you around"
    scene rbys197 with fade
    pause
    sm "Right Melissa?"
    scene rbys198 with fade
    pause
    mls "Sure..."
    scene rbys199 with fade
    pause
    mc "I know that look"
    mc "She is loving it right now"
    scene rbys196 with fade
    pause
    sm "Look, guys, this partnership is perfect in every way, the only obstacle in front of you is yourself"
    sm "It won't be good for me if you get into a war of authority among yourselves and start making the big bosses uneasy."
    sm "If it's not good for me, it's not good for you, I assume you understand the hierarchy here"
    sm "While we are gathered, I would like to talk about a few details that may be considered important"
    sm "First there will be a change to the course system"
    sm "Melissa has been trying a method for a while"
    sm "As far as I understand, the method worked, so she wants to adapt this method to this school"
    sm "Can you tell us about this method, Melissa?"
    scene rbys200 with fade
    pause
    mls "To dictate authority to these types of students, we first need to pretend to be on their side."
    mc "Nothing new"
    scene rbys201 with fade
    pause
    mls "But"
    mls "Do this not verbally, but by identifying the things they want most in their school life and doing something about it."
    mls "I empathized while thinking about how to go about this method."
    mls "And I realized I could bend the class times & dress code"
    mls "Going to the students and saying that I am actually on their side has lost its credibility."
    mls "If we want to get their attention, we have to do it with things that really benefit them."
    mc "How so?"
    mls "I removed the dress code in the previous school, anyone can dress as they want."
    mls "I also rearranged the lesson hours by observing the students' situation, at the same time I changed the class size."
    mls "Some students are much quicker than others to understand what is being taught, I asked these students to come to class only 2 days a week"
    mls "I split the class into 3; smarts, normals and retards"
    mc "Wasn't the retards a little heavy ?"
    mls "No, they are retarded, that is the truth"
    mc "Still.."
    mls "I continued with different students on different days of the week with a special program for them."
    mc "Like a private course"
    mls "Yes, and it worked"
    mc "Dress code?"
    mls "It's simple"
    mls "I told the students in my class that they could come in any outfit they wanted."
    mc "Has there been a noticeable change after changing the dress code?"
    mls "Maybe"
    mls "Doesn't sound effective enough when you say it that way?"
    mls "Think about it this way"
    mls "Although they are the heirs of the most powerful people in the world, they live their education by following this dress code."
    mls "And a teacher suddenly removes this rule, says you can dress however you want"
    mls "Even the dumbest student recognizes the authority of the person who removed this rule."
    scene rbys202 with fade
    pause
    mc "It makes sense when you think like this, yes"
    mc "You can be sure that I will try what you offer me"
    mc "But"
    mc "I am still in charge of my class, no matter what happens, I will always have the last word no matter what happens"
    mc "If we agree on this, I can work with you"
    scene rbys195 with fade
    pause
    mls "Of course"
    mls "This is your kingdom"
    mc "Thanks"
    scene rbys203 with fade
    pause
    sm "I think you have an agreement"
    sm "Great, now you can go back to your classes"
    scene rbys205 with fade
    pause
    mls "Copy that, boss"
    mc "......."
    menu:
        "Yes boss":
            scene rbys203 with fade
            pause
            mc "Sure boss whatever you say"
            scene rbys206 with fade
            pause
            sm "Did you call me boss?"
            mc "Yeah, I think you like it now that Melissa calls you that"
            sm "No, I don't, but I didn't hate it either"
        "Uh huh":
            scene rbys203 with fade
            pause
            mc "Mhmh hm"
            sm "Very specific [mc]"
            mc "Sure Gab"
            scene rbys204 with fade
            pause
            sm "Don't call me that"
    scene rbys199 with fade
    pause
    sm "For now, I'm ending this meeting here"
    sm "From this day on, you are together, try to get along well"
    mls "Can't wait"
    scene rbys207 with fade
    pause
    mc "Same"
    scene rbys208 with fade
    pause
    mc "I wonder why I'm not surprised"
    scene rbys209 with fade
    pause
    sy "They all left right after you left"
    mc "I'm not surprised at that either"
    sy "Do you want me to go and let them know"
    mc "Nah, thanks anyway"
    scene rbys210 with fade
    pause
    sy "Phew, I was so afraid that you would say yes right now"
    sy "I'm so scared of all of them except Ava"
    mc "Why"
    scene rbys211 with fade
    pause
    sy "You know why"
    mc "Yeah, I have to stop asking questions I know the answers to"
    mc "Have you done the homework I gave you?"
    scene rbys210 with fade
    pause
    sy "Still I couldn't finish it"
    mc "Anyway, you can give it along with the others"
    sy "Thank you"
    mc "You can leave too"
    scene rbys211 with fade
    pause
    sy "Okay"
    mc "Wait"
    sy "Huh ?"
    mc "Come to my room"
    scene rbys212 with fade
    pause
    sy "Why am I in trouble ?"
    mc "Depends."
    sy "Depends of what ?"
    mc "I'll be waiting for you"
label v03mcroomMls:
    scene rbys213 with fade
    pause
    mc "Finally, come"
    mc "Oh it's you"
    scene rbys214 with fade
    pause
    mls "Yup"
    mc "Yes, I'm listening to you"
    scene rbys215 with fade
    pause
    mls "I think we can leave the formality aside"
    scene rbys216 with fade
    pause
    mc "Fine by me"
    mls "Okay then"
    scene rbys217 with fade
    pause
    mls "Dude, what's with the 'I'll have the last word' crap?"
    mc "Hah I'm finally talking to the real Melissa"
    mc "Let's rock then"
    mc "I stated that I would have the last word in front of Gaby because I felt that something like this would happen"
    mc "You can't turn the game around here, honey"
    scene rbys218 with fade
    pause
    mls "..."
    mc "I've never liked this look..."
    scene rbys219 with fade
    pause
    mls "Because when you just finished the sentence, you realized something"
    mls "By stating this, you have accepted Gaby as an authority [mc]"
    mls "Anyway, this will be easier than I thought"
    mls "On my way here, I thought you had a layered plan for this"
    scene rbys220 with fade
    pause
    mls "It seems that it will be extremely easy for me to replace you right now"
    mls "But still try a little, it gets very boring like this"
    mc "Wait"
    scene rbys221 with fade
    pause
    mc "You've done it before"
    mls "Yeah, do you think you're an exception or someone special"
    mls "Do you know how many people I buried who were considered alphas like you and put on this mission"
    mc "......."
    mls "Like I said"
    mls "Try a little, at least you'll taste some competition before you go home"
    scene rbys222 with fade
    pause
    "That bitch..."
    "But still she impressed me excessively"
    "Could she have fooled me by drawing a quiet calm image on our first meeting..."
    "Nah, even if it wasn't so, I would have made the same mistake again"
    "She referenced this when she said it would be easier than I thought"
    "She realized that what she did at the first meeting was superfluous"
    "So how did I get defeated in such a simple way.."
    "I haven't been defeated yet"
    "It's even better this way"
    "She sees me as a low-level threat right now"
    "So it will be easier for her to make a mistake"
    "If I focus completely, I can win"
    "......"
    "I feel very excited.."
    "She must have meant it when she said enjoy the competition"
    scene rbys223 with fade
    pause
    sy "Uhmm.."
    mc "What.."
    mc "When did you come?"
    sy "I came in while Miss Melissa was going out, I called out to you many times you didn't hear"
    mc "Oh.. Sorry for this"
    scene rbys224 with fade
    pause
    sy "So.."
    sy "What is my punishment"
    mc "Not now"
    scene rbys225 with fade
    pause
    sy "Oh, thank god"
    sy "I was ready to get spanked."
    mc "Yeah I'll see you later you can leav..."
    mc "Wait what?"
    sy "Huh ?"
    mc "What did you just say ?"
    scene rbys226 with fade
    pause
    sy "I said huh"
    mc "..."
    mc "Before that"
    sy "I was ready to get spanked?"
    mc "Why would you say something like that?"
    sy "That's how I'm usually punished"
    mc "By Who ? Gaby ?"
    sy "No, not miss Gaby"
    mc "Then who ?"
    scene rbys227 with fade
    pause
    sy "uhmmm"
    scene rbys228 with fade
    pause
    sy "No one, I have to go"
    "The fuck..."
    "Anyway, I need to focus on Melissa for now"
    "Time to go home"
label v03bbg:
    scene rbys229 with fade
    pause
    mc "What is going on there.."
    scene rbys230 with fade
    pause
    mc "Hey"
    mc "Oh it's you again"
    prg "Hey"
    mc "Is he bothering you ?"
    scene rbys231 with fade
    pause
    bdg "Excuse me ?"
    prg "Why ?"
    scene rbys233 with fade
    pause
    prg "Are you gonna kick his ass if he bothers me ?"
    mc "Yeah"
    bdg "Yeah ?"
    mc "Yep"
    scene rbys232 with fade
    pause
    bdg "I like to see you try"
    mc "Gladly"
    scene rbys233 with fade
    pause
    prg "By the way he is not"
    mc "Good then"
    scene rbys232 with fade
    pause
    bdg "So, you still here"
    mc "Why are you surprised"
    bdg "You'll see"
    mc "Sure"
    scene rbys234 with fade
    pause
    bdg "Have a nice day"
    mc "You to"
    scene rbys235 with fade
    pause
    prg "How was your day?"
    mc "Weird but not bad"
    prg "Cool"
    mc "How was your day?"
    prg "Same"
    mc "Cool"
    prg "Yeah"
    mc "Do you want me to drive you home?"
    prg "Hmmm"
    prg "No"
    mc "Okay then, see you later"
    prg "Sure"
    menu:
        "Flirt with her":
            mc "Wait"
            prg "I'm not moving"
            mc "Did you flash your boobs today ?"
            prg "Yeah"
            mc "To who ?"
            prg "To you"
            mc "Except me"
            prg "Then no"
            mc "Nice"
            prg "Why?, I'm not your girlfriend or something"
            mc "I know, but still"
            mc "Your tits are so cute by the way"
            prg "Oh thanks"
            mc "Can I see them again ?"
            prg "Sure"
            scene rbys236 with fade
            pause
            mc "Can you make a pose for me ?"
            prg "Sure"
            scene rbys237 with fade
            pause
            mc "Nice.."
            scene rbys238 with fade
            pause
            prg "Wanna touch ?"
            mc "Yes"
            prg "Then touch 'em"
            scene rbys239 with fade
            pause
            mc "Damn.."
            mc "They're really perky"
            scene rbys240 with fade
            pause
            prg "Yeah"
            prg "Your hands are strong by the way"
            mc "Yes they are"
            mc "What about your pussy"
            prg "What about it ?"
            mc "Can I see it"
            prg "Hmm"
            prg "Aren't you afraid of getting caught by someone?"
            mc "Nope"
            prg "Why"
            mc "It's easy, I think most people who come to this school know you"
            prg "Yeah kind of"
            mc "Which means they also know that you're not a normal person"
            prg "Not a normal person ?"
            mc "It doesn't matter, I just have to say that I'm interfering with public nudity"
            prg "Hmm"
            prg "I see"
            prg "Okay"
            scene rbys241 with fade
            pause
            scene rbys242 with fade
            pause
            prg "Here"
            scene rbys243 with fade
            pause
            mc "Mhmm seems tasty"
            prg "Is it ?"
            mc "Seems like yeah"
            prg "Huh, now I'm curious"
            mc "I can taste it and prove it if you want"
            scene rbys244 with fade
            pause
            prg "You'd do that for me ?"
            mc "Oh yeah, absolutely for you"
            prg "Okay do it"
            mc "Okay then turn around"
            scene rbys245 with fade
            pause
            prg "Is it good ?"
            mc "Hell yes"
            scene rbys246 with fade
            pause
            prg "Mhmm"
            prg "So what do you think?"
            mc "Give a min, I have to be sure"
            prg "Okay.."
            scene rbys247 with fade
            pause
            prg "Ugghhh"
            scene hmmmmmm_1
            pause
            scene rbys245 with fade
            pause
            mc "Want me to stop"
            prg "No keep going"
            scene rbys248 with fade
            pause
            prg "Fuck !"
            prg "Damn that was good"
            mc "Yeah, it's fucking tasty"
            prg "Cool"
            mc "Did you like it"
            prg "Yes, you were really good"
            mc "You bet"
            mc "Anyway let me go before I get caught by someone"
            scene rbys249 with fade
            pause
            prg "Okay"
            scene rbys250 with fade
            pause
            mc "By the way, I can trust you, right ?"
            prg "About what ?"
            mc "You know what"
            scene rbys251 with fade
            pause
            prg "Yeah don't worry"
            prg "I know so many secrets that this one may not even be worth remembering"
            mc "Ouch.."
            prg "It's not because of the performance."
            prg "I want to say.."
            mc "I know I'm just kidding"
            prg "Oh ok then"
            prg "You were so good by the way"
            mc "Thanks"
            mc "Careful"
            prg "You too"
        "Go home":
            jump v03home
label v03home:
    scene rbys252 with fade
    pause
    mc "Girls!"
    mc "No one ?"
    menu:
        "Take off the suit":
            pass
    scene rbys253 with fade
    pause
    mc "Aaah that's more like it"
    mc "Let's see what's on"
    scene rbys254 with fade
    pause
    mc "Oh she is there"
    mc "Hey Janet"
    wf "Oh, did you come in, I didn't hear"
    mc "Yeah"
    scene rbys255 with fade
    pause
    mc "Do you want to talk about this ridiculous topic"
    wf "What ridiculous topic"
    mc "I'm cheating on you"
    scene rbys256 with fade
    pause
    wf "Oh, that"
    wf "Forget about it, it wasn't anything serious"
    mc "It seemed quite serious to me"
    scene rbys257 with fade
    pause
    wf "Then you need to relax a little"
    mc "Babe we have to talk about this.."
    scene rbys258 with fade
    pause
    wf "Nope, I feel so fucking horny"
    wf "I want you so much right now"
    scene rbys259 with fade
    pause
    wf "Don't you want me.."
    mc "....."
    mc "Okay then.."
    mc "Let's go to the bedroom"
    wf "No"
    wf "I want it here"
    mc "But the girls.."
    scene rbys260 with fade
    pause
    wf "I want it right now !"
    mc "Fuck that!"
    scene rbys261 with fade
    pause
    wf "Yes exactly like this !"
    mc "You don't need to say any more, you asked for it"
    wf "Yes I did"
    scene rbys262 with fade
    pause
    wf "Now punish me !"
    mc "Is the house empty?"
    wf "Pfft who cares, just fuck my throat already"
    mc "....."
    mc "Get down on your knees, hold your hands behind your back"
    scene rbys263 with fade
    pause
    wf "Mhmm, what else"
    mc "Open your mouth and keep your eyes closed"
    wf "Oh no..."
    wf "What are you going to do to me with my eyes closed and my mouth open.."
    mc "Whatever I want"
    wf "How mean..."
    scene rbys265 with fade
    pause
    wf "Is this good for you daddy ?"
    mc "Yes."
    scene rbys264 with fade
    pause
    wf "But my mouth doesn't open any more than that, daddy, are you sure that's enough.."
    mc "Don't worry, I'll handle the rest"
    scene rbys266 with fade
    pause
    wf "Oh my.."
    wf "What are you doing right now.."
    mc "You have to open your eyes to see this"
    wf "Can I ?"
    scene rbys267 with fade
    pause
    mc "No"
    wf "Mhmmm mean."
    scene rbys268 with fade
    pause
    wf "Oh.."
    wf "Is that ..."
    mc "Yeah how does this feel"
    scene rbys269 with fade
    pause
    wf "So hot, it's almost burning my face"
    scene wfeee
    mc "I will also burn your throat"
    scene rbys270 with fade
    pause
    wf "Mhmmmmm"
    mc "Here we go!"
    if persistent.patch_installed == True:
        jump chapter3Claire1
    else:
        jump v03home2
label v03home2:
    scene rbys283 with fade
    pause
    wf "Can you be harder please"
    mc "Sure babe"
    scene hmmmmmm_5
    pause
    scene rbys284 with fade
    pause
    wf "....."
    mc "What"
    wf "Nothing"
    mc "Just say it !"
    scene rbys285 with fade
    pause
    wf "........"
    wf "I'm not exciting you anymore, am I"
    mc "Don't be silly, baby."
    scene rbys286 with fade
    pause
    wf "Stop that"
    mc "Stop what ?"
    wf "Stop lying [mc]"
    wf "We've been married for so long that I can notice a slight change."
    mc "Babe, you're talking nonsense right now"
    wf "Please stop that and be honest please.."
    mc "......"
    wf "Now answer my question honestly."
    wf "[mc] am I the only woman in your life"
    menu:
        "Yes":
            mc "Of course you are"
            scene rbys287 with fade
            pause
            mc "The reason I've been changing lately is because the new job is so stressful"
            mc "I didn't know you felt that way, but I promise I'll be a lot more careful from now on"
            wf "..."
            wf "Okay I trust you"
        "No":
            mc "No you are not"
            scene rbys288 with fade
            pause
            wf "..."
            mc "I need to keep my mental health stable, because I love you and girls very much"
            mc "It's the best I can do, but you're always the most important to me"
            mc "[pD71] and I trust you more than anyone"
            scene rbys290 with fade
            pause
            wf "So I'm just a side chick huh.."
            mc "Didn't you listen to what I said, you're the main chick"
            wf "I see"
            mc "You'll leave me.."
            wf "No, you are [pD72]"
            wf "If you're seeing other women, I can't say you're the only one to blame"
            wf "So I haven't been a good wife"
            mc "No, don't say that babe..."
            wf "It's ok [mc] I already knew this would happen."
            wf "Just don't leave the house again"
            mc "So what, are you going to accept this and move on with your life?"
            wf "Do I have another option ?"
            mc "....."
            menu:
                "I love you":
                    $v03mclovesjanet = True
                    mc "I love you"
                    scene rbys291 with fade
                    pause
                    wf "....."
                    wf "Me to.."
                "Stay silence":
                    $persistent.gal24 = True
                    pass
        "It's complicated":
            scene rbys289 with fade
            pause
            mc "I'm not in my best mental condition.."
            mc "I can't use the words 'yes' or 'no' as an answer"
            mc "This is a new job, and the interesting events I've been going through lately are starting to change me"
            wf "...."
            mc "I can't give you an answer because I'm not sure of anything"
            mc "But I can tell you a truth"
            menu:
                "I love you":
                    $persistent.gal26 = True
                    $v03mclovesjanet = True
                    scene rbys291 with fade
                    pause
                    mc "The fact that I love you"
                    mc "No matter what happens, this fact will not change"
                    wf "..."
                    wf "Thank you."
                "I love my [pD66]":
                    scene rbys290 with fade
                    pause
                    mc "The fact that I love [pD66]"
                    mc "No matter what happens, this fact will not change"
                    wf "..."
    scene rbys289 with dissolve
    mc "So.."
    wf "Everything will go on as before, nothing has changed"
    mc "Okay then.."
    mc "We can finish what we started in our bedroom if you want"
    mc "The girls are about to come"
    wf "No need"
    wf "You are hardly hard anyway"
    mc "It's not because of you"
    mc "I feel so exhausted"
    wf "Sure..."
    mc "..."
    "Fuck..."
    $persistent.gal20 = True
    "I feel terrible"
    if persistent.patch_installed == True:
        jump chapter3Claire2
    else:
        jump v03home3
label v03home3:
    if persistent.patch_installed == True:
        jump chapter3Emma1
    else:
        $config.allow_skipping = False
        scene black
        #"End of v0.3"
        jump xmasstart
