label xmasstart:
    scene black
    "Christmas"
    pause
    $config.allow_skipping = True
    play music "audio/xmasmusic.mp3"
    scene clrxms1 with Fade(1.5, 1.0, 0.5)
    pause
    scene clrxms2 with fade
    pause
    scene clrxms3 with fade
    pause
    scene clrxms4 with fade
    pause
    scene clrxms5 with fade
    pause
    scene clrxms6 with fade
    pause
    d1 "Good morning Claire!"
    d1 "Good morning Claire!"
    d1 "And good morning to you"
    dr "Morning"
    d1 "Do you know what time it is?"
    dr "Time is something that doesn't work for me."
    dr "So I don't care."
    d1 "It's christmas!"
    dr "Oooh that thing"
    d1 "I can feel it, today will be my best day!"
    dr "Oh no.."
    scene clrxms7 with fade
    pause
    "Yawn"
    scene clrxms8 with fade
    pause
    d1 "Big day"
    d1 "What should I wear?"
    dr "Something proper for your age maybe?"
    d1 "Naah"
    d1 "You know what I decided."
    dr "You should stop that"
    d1 "Why?.."
    dr "It's not right?"
    d1 "I'm Claire, everything is right for me!"
    dr "No it isn't, that's why I exist remember?"
    d1 "Boomer"
    d1 "Not gonna listen to you!"
    dr "Oh wow I'm shocked"
    scene clrxms11 with fade
    pause
    d1 "I feel so cute today!"
    dr "Well that's true"
    d1 "Yaaaaay"
    d1 "Let's get dress!"
    d1 "Hmmmmmm"
    d1 "Can't choose, help me a little"
    dr "Aren't some of these Emma's?"
    d1 "Yup"
    dr "You are getting more reckless every day...."
    scene clrxms17 with Fade(2.0, 1.5, 1.0)
    pause
    d1 "How do I look!"
    dr "It doesn't seem like you"
    d1 "I think it turned out perfect!"
    dr "Yeah it's perfect"
    d1 "Let's try another!"
    dr "heh I knew"
    scene clrxms14 with fade
    pause
    d1 "Tadaaa"
    dr "Hmmm"
    scene clrxms15 with fade
    pause
    d1 "Damn Emma know how to dress.."
    dr "I can't argue with that"
    scene clrxms16 with fade
    pause
    dr "Did you decide?"
    d1 "I think this is perfect."
    scene clrxms18 with fade
    pause
    d1 "Before we start the day, we need to decide on our plan."
    dr "What plan?"
    d1 "Let's sit first."
    scene clrxms19 with fade
    pause
    d1 "Are you comfortable there?"
    dr "Claire..."
    d1 "Yeah yeah I know"
    scene clrxms20 with fade
    pause
    dr "I think we should talk about the milk thing first."
    scene clrxms21 with fade
    pause
    d1 "There's nothing to talk about."
    dr "Look, Claire, what you're doing is actually..."
    scene clrxms27 with fade
    pause
    d1 "Stop!"
    scene clrxms20 with fade
    pause
    dr "......."
    dr "........"
    scene clrxms22 with fade
    pause
    d1 "First we must decorate the house, the spirit of christmas must live in the hall"
    dr "Don't do that again! Don't ignore me again."
    dr "Every time you do this I feel like I'm dying.."
    d1 "Then don't say things that will upset me!"
    dr "I try..."
    scene clrxms23 with fade
    pause
    d1 "Okay then"
    d1 "Ideas?"
    dr "About?"
    d1 "Decoration"
    scene clrxms24 with fade
    pause
    dr "Hmmm"
    dr "We need a credit card, a vehicle and, of course, a driver."
    scene clrxms22 with fade
    pause
    d1 "Easy peasy lemon squeezy!"
    dr "How?"
    scene clrxms25 with fade
    pause
    d1 "Emma!"
    dr "What makes you think Emma's gonna help you?"
    scene clrxms26 with fade
    pause
    d1 "Cuz we're [pD6].."
    scene clrxms28 with fade
    pause
    dr "Well..Good luck.."
    d1 "Why.."
    dr "You know her.."
    d1 "Yeah but this is special"
    d1 "And we are [pD6].."
    d1 "What is your suggestion?"
    dr "Lie."
    d1 "Never"
    dr "Okay then"
    dr "Now what?"
    d1 "It's time to start the day!"
    scene clrxms29 with fade
    pause
    scene clrxms30 with fade
    pause
    d1 "[pD23]!"
    scene clrxms31 with fade
    pause
    d3 "Morning Claire"
    d1 "Good morning, the best [pD7] in the world!"
    scene clrxms32 with fade
    pause
    d3 "Wait.."
    d3 "are you wearing my clothes?"
    d1 "Oh this.."
    dr "Say 'I think my mom got it mixed up.'"
    d1 "I think my mom got it mixed up."
    scene clrxms33 with fade
    pause
    d3 "Oh.."
    d3 "Okay then."
    d3 "What do u want.."
    d1 "do you know what this day is?"
    d3 "Yeah it's christmas"
    d1 "Exactly!"
    scene clrxms34 with fade
    pause
    d3 "Oh no.."
    d1 "Oh yes!"
    scene clrxms35 with fade
    pause
    d3 "I don't know what you're going to want, but I know the answer I'm going to give."
    d1 "Then get ready, we're leaving!"
    d3 "You know what?"
    d3 "I'm in."
    scene clrxms36 with fade
    pause
    d1 "Really?"
    d3 "Yup, no matter how ridiculous your plan is, I'm in"
    dr "That's weird.."
    d1 "Seems shady..."
    scene clrxms39 with fade
    pause
    d3 "Let's make a deal"
    d3 "I'm really bored these days so I decided this could be fun"
    d3 "Deal is"
    d3 "Don't tell me the plan, just tell me what to do at the moment"
    d1 "It's your funeral"
    d3 "Hopefully."
    d3 "So tell me boss, what should I do first?"
    scene clrxms37 with fade
    pause
    d1 "Me? Boss?"
    scene clrxms38 with fade
    pause
    d1 "This day has already exceeded my expectations, I'm so happy!"
    d3 "If your celebration is over, let's start"
    d1 "Okay then employee!"
    scene clrxms36 with fade
    pause
    d1 "Your first task is to steal the key to [pD8]'s car!"
    d3 "Wow"
    d3 "I didn't expect that."
    d3 "I thought we were going to play house or something."
    scene clrxms37 with fade
    pause
    d1 "Oh..."
    scene clrxms40 with fade
    pause
    d1 "So called badass Emma can't even steal the car keys or..."
    scene clrxms33 with fade
    pause
    d3 "Oh it's on.."
    dr "You're getting good at this."
    scene clrxms41 with fade
    pause
    d1 "We have to get in the car no later than 2 hours, so get ready, Emma"
    d3 "Hah cute."
    scene clrxms42 with fade
    pause
    d3 "Tadaa!"
    scene clrxms43 with fade
    pause
    scene clrxms44 with fade
    pause
    d1 "You already stole it?"
    scene clrxms45 with fade
    pause
    d3 "Nah, these are the spare keys."
    d3 "I stole it from [pD10]'s purse a while ago."
    scene clrxms46 with fade
    pause
    dr "I really like this girl."
    d1 "But didn't [pD10] tell [pD8]?"
    d3 "I'll tell you later."
    scene clrxms47 with fade
    pause
    d3 "Go get dressed, and then we're going!"
    scene clrxms48 with fade
    pause
    d1 "But I'm already dressed.."
    scene clrxms46 with fade
    pause
    d3 "It's winter, dude..."
    d1 "Oooh right.."
    d1 "Wait.. I forgot something"
    d3 "What?"
    d1 "Money..."
    d3 "Oh that's okay too"
    d1 "Hmm?"
    d3 "I also stole [pD10]'s credit card."
    scene clrxms48 with fade
    pause
    d1 "Stealing is bad.."
    scene clrxms46 with fade
    pause
    d3 "This is not actually stealing, because she still doesn't know"
    d3 "[pD10] does her shopping on Sunday every week and she doesn't use any cards other than that."
    d3 "I just put the card in her wallet on Sundays"
    dr "God damn..."
    d1 "Okay then"
    scene clrxms50 with fade
    pause
    d3 "Are you ready?"
    d1 "Yeah.."
    d3 "What's wrong?"
    d1 "I was excited to go out in your clothes.."
    scene clrxms51 with fade
    pause
    d3 "Ugh calm dude, this is much more better."
    scene clrxms52 with fade
    pause
    d1 "Do you really think so?"
    d3 "Yup"
    scene clrxms53 with fade
    pause
    d1 "Yay!"
    d3 "Let's rock then"
    scene clrxms55 with fade
    pause
    d1 "Aren't we super cute [pD7]!"
    scene clrxms56 with fade
    pause
    d3 "Yes Claire, we are super cute."
    d3 "But you have to stop grabbing my boob..."
    d1 "Why? Are you afraid that your milk will leak?"
    d3 "What?"
    d1 "Milk?"
    d3 "Whatever, let's go."
    d1 "Yaaaay"
    scene clrxms57 with fade
    pause
    scene clrxms58 with fade
    pause
    d1 "Oh boy!"
    d1 "So exciting!"
    scene clrxms60 with fade
    pause
    d3 "Hey cutie!"
    scene clrxms61 with fade
    pause
    d1 "Yes officer, is there a problem?"
    d3 "No you just too cute to walk, wanna join me?"
    scene clrxms62 with fade
    pause
    d1 "Ummmm but Ma'am [pD16] told me not to do that."
    d3 "C'mon little girl it will be super fun"
    d1 "Hmmmmm"
    d1 "But you don't offer me a candy or something?"
    d3 "Oh yeah, I have tons of candy."
    scene clrxms63 with fade
    pause
    d1 "Yaay I'm in!"
    dr "Hah funny"
    scene clrxms64 with fade
    pause
    d3 "That was fun"
    d1 "You can really drive, right?"
    scene clrxms65 with fade
    pause
    d3 "This is not my first time dude.."
    d1 "Oki doki"
    d3 "So where are we going?"
    d1 "Somewhere we can buy christmas!"
    d3 "Right"
    scene clrxms66v2 with fade
    pause
    d1 "Oh my god!"
    d1 "I love snow so much!"
    d3 "Well, I don't hate it either"
    d1 "Saying it like this instead of saying I love it too..."
    d1 "Emma is being Emma again.."
    d3 "I need to do something about your joy-filled black hole."
    d3 "Otherwise, all of humanity would be sucked by it."
    d1 "That means the world is still alive because of both of us!"
    d3 "Yeah I guess so"
    d1 "Yaaay"
    d3 "Silly.."
    scene clrxms67 with fade
    pause
    d3 "Here we are."
    d1 "[pD23] I feel like a criminal!"
    d3 "Why?"
    scene clrxms68 with fade
    pause
    d1 "We stole [pD13]'s car, [pD10]'s card. It is very exciting that we will also shop without permission!"
    d3 "Silly"
    scene clrxms69 with fade
    pause
    d1 "Let's rob someone!"
    scene clrxms71 with fade
    pause
    d3 "Calm down Wonder Woman"
    d1 "Eheheh"
    scene clrxms70 with fade
    pause
    d1 "Oh oh oh! That one! That one!"
    d3 "Cool let's go."
    scene clrxms72 with fade
    pause
    d1 "Wait"
    d3 "What?"
    d1 "Look at this girl."
    d3 "What about her?"
    d1 "Don't you really see it?"
    d3 "See what?"
    d1 "She is unhappy.."
    d3 "Welcome to the real world [pD7]"
    d3 "Claire!"
    scene clrxms73 with fade
    pause
    d1 "Hey!"
    scene clrxms74 with fade
    pause
    sg ".."
    sg "Hi"
    scene clrxms75 with fade
    pause
    d1 "Why you're not happy?!"
    sg "I.."
    sg "Uhmm"
    d1 "Sorry I asked rudely."
    d1 "Are you okay?"
    sg "No"
    d1 "What happened?.."
    sg "I lost my family.."
    d1 "Oh no.."
    d1 "How did they die.."
    sg "What! They are not dead!"
    d1 "But you lost your family"
    d3 "She's lost Claire..."
    d1 "Oooh right.."
    scene clrxms76 with fade
    pause
    d1 "..."
    d3 "No!"
    scene clrxms77 with fade
    pause
    d3 "Claire no!"
    d3 "Not gonna happen!"
    scene clrxms78 with fade
    pause
    scene clrxms79 with fade
    pause
    scene clrxms80 with fade
    pause
    d3 "I can't believe this.."
    scene clrxms81 with fade
    pause
    d3 "It's like seeing a puppy on the side of the road and picking it up.. for fuck's sake"
    d1 "C'mon [pD23].."
    d3 "Fine whatever, she is your responsibility."
    d3 "Not mine"
    scene clrxms82 with fade
    pause
    d1 "Yaaay"
    sg "Wuhuuu"
    d1 "Yaaaaaaay"
    sg "WUUHUUUUUUUUUUU"
    d3 "STOP"
    d3 "Now the're two of them.."
    d1 "I loved your stickers by the way!"
    sg "Omg really?"
    d1 "Yeah!"
    sg "Thank you so much!"
    d3 "What's the deal with these stickers?"
    sg "They didn't forbid it, so I never take it off"
    d3 "Hmm"
    d3 "So in a conservative family you cling tightly to your own freedom"
    sg "But I love them!"
    d3 "Cool"
    scene clrxms83 with fade
    pause
    scene clrxms84 with fade
    pause
    d3 "Never gonna make you boss again.."
    d1 "Haah, admit it, you liked my leadership"
    d3 "Sure"
    d1 "She loves it"
    dr "I agree"
    sg "....."
    scene clrxms85 with fade
    pause
    d1 "Okaaay"
    d1 "This is our home."
    scene clrxms86 with fade
    pause
    d1 "How did you find it?"
    scene clrxms87 with fade
    pause
    sg "So beautiful"
    d1 "Yaay"
    scene clrxms88 with fade
    pause
    d1 "Tadaaa"
    d1 "This is my room."
    scene clrxms89 with fade
    pause
    sg "It's so pretty!"
    scene clrxms90 with fade
    pause
    d1 "It will be much more beautiful."
    d1 "Let's start!"
    d1 "Wait, let me give you some comfortable clothes first."
    sg "That would be nice thank you Claire"
    scene clrxms91 with fade
    pause
    d1 "Aren't we super cute!"
    sg "You sure are.."
    d1 "We are!"
    scene clrxms92 with fade
    pause
    sg "Are you and Emma sharing this room?"
    d1 "Nope, with my other [pD7]"
    sg "So you're 3 [pD6]"
    d1 "Yup!"
    d1 "Don't have a sister?"
    scene clrxms93 with fade
    pause
    sg "..."
    scene clrxms94 with fade
    pause
    sg "I don't."
    d1 "Oh.."
    dr "She's obviously upset about this. I think you should drop it."
    scene clrxms95 with fade
    pause
    scene clrxms96 with fade
    pause
    d1 "So what do you think?"
    sg "Woow..."
    d1 "I know right!"
    dr "Well It is pretty cool"
    sg "I'm so happy right now!"
    scene clrxms97 with fade
    pause
    mc "Girls I'm home."
    scene clrxms98 with fade
    pause
    d1 "[pD74]!"
    mc "My little angel."
    scene clrxms99 with fade
    pause
    d1 "Look at this [pD8]!"
    d1 "Do you like it?"
    mc "Damn.."
    mc "Pretty good."
    mc "I had no idea"
    d1 "Emma and I did it together."
    mc "Emma?"
    d1 "Yeah it seems weird but yeah!"
    mc "I'll be damn.."
    scene clrxms100 with fade
    pause
    mc "Oh you brought your friend"
    if v011mcWentChristian:
        scene clrxms101 with fade
        pause
        sg "Hi mister...."
        mc "What the..."
        d1 "What's going on?"
        mc "..."
        mc "Nothing honey, I just remembered something."
        scene clrxms102 with fade
        pause
        d1 "Oh ok then."
        d1 "I'll be in Emma's room."
        mc "Sure honey"
        scene clrxms103 with fade
        pause
        mc "So"
        mc "Do you remember me?"
        sg "Yes, from your suit."
        sg "Are you sleeping in that suit?"
        mc "Hah fun"
        sg "How did you remember me?"
        sg "You can't forget my face because I'm too sweet, can you?"
        scene clrxms104 with fade
        pause
        sg "Don't say stickers!"
        scene clrxms105 with fade
        pause
        mc "I was going to say that I remembered because you were too sweet"
        scene clrxms103 with fade
        pause
    else:
        scene clrxms102 with fade
        pause
        d1 "I'll be in Emma's room."
        mc "Sure honey"
        scene clrxms103 with fade
        pause
        mc "Hey there."
        sg "Hi mister."
    mc "Are you a friend of Emma?"
    sg "Nope"
    mc "Claire?"
    sg "Nope"
    mc "Hmm"
    sg "I got lost in the mall, they found me and brought me here."
    mc "Classic Claire"
    sg "By the way, your [pD75] drives very well."
    mc "Yeah she's good at everything.."
    mc "Wait"
    mc "What?!"
    scene clrxms105 with fade
    pause
    sg "Oh.."
    mc "EMMAAA!"
    scene clrxms106 with fade
    pause
    d3 "What happened [pD8]?"
    scene clrxms107 with fade
    pause
    d3 "Oh..."
    d3 "That.."
    scene clrxms108 with fade
    pause
    mc "I can't believe you!"
    mc "What if something happened to you?"
    scene clrxms109 with fade
    pause
    mc "And you took your [pD7] with you"
    mc "And this girl"
    mc "I can't believe you!"
    scene clrxms110 with fade
    pause
    d3 "[pD76].."
    mc "Shut up!"
    scene clrxms111 with fade
    pause
    d3 "I'm sorry.."
    mc "Go to your room now!"
    mc "When your [pD10] comes, go give her the key and tell her what you did"
    scene clrxms110 with fade
    pause
    d3 "But [pD8]!"
    mc "Excuse me!"
    scene clrxms111 with fade
    pause
    d3 "Yes daddy.."
    mc "Tell Claire she is grounded too."
    scene clrxms110 with fade
    pause
    d3 "Yes [pD13]"
    sg "I'm sorry Emma.."
    scene clrxms112 with fade
    pause
    mc "Anyway, I'll give you a ride home, your parents must be worried sick."
    scene clrxms113 with fade
    pause
    sg "I don't think so"
    mc "What do you mean? Aren't you lost in the mall?"
    sg "I lied"
    mc "Why?"
    sg "Because I wanted to see santa."
    mc "So your family doesn't know you were at the mall."
    sg "Na ah they think I'm playing outside"
    scene clrxms112 with fade
    pause
    mc "Oh my..."
    mc "Anyway, let me take you home."
    scene clrxms114 with fade
    pause
    mc "Wha ?"
    sg "Can I stay a little longer"
    scene clrxms115 with fade
    pause
    sg "Please.."
    mc "Why?"
    sg "I wanna spend more time with them and you.."
    mc "Is everything okay in your house?"
    mc "Are your parents hurting you?"
    sg "What? no!"
    sg "Not like that.."
    mc "Like what?"
    sg "It's a very boring restrictive family."
    sg "Your family is very nice."
    sg "So I want to stay a little longer."
    sg "And we've worked so hard."
    sg "I also contributed to the decoration."
    mc "Well I can't argue with that."
    sg "So can I stay ?"
    mc "Sure, but I'll give you a ride home before night"
    scene clrxms116 with fade
    pause
    sg "Good enough!"
    sg "Thank you mister!"
    sg "Can I join to your [pD5]?"
    menu:
        "Sure":
            scene clrxms116 with fade
            pause
            mc "Just don't let those two be in the same room"
            sg "Oki doki!"
            mc "Have fun"
            mc "But no stealing cars this time"
            sg "Yes sir!"
            scene clrxms117 with fade
            pause
            sg "Heyoooo"
            scene clrxms118 with fade
            pause
            d1 "Oh hey!"
            scene clrxms119 with fade
            pause
            d1 "I think my [pD13] has forgiven me?"
            sg "Oh no"
            sg "He is pissed.."
            scene clrxms120 with fade
            pause
            d1 "Yeah.."
            dr "Wonder why.."
            scene clrxms121 with fade
            pause
            sg "He said I can spend time with you."
            sg "But on the condition that I see you two separately"
            d1 "Aww.."
            sg "It's okay we're friends now, so I'll see you all the time, right?"
            d1 "Of course!"
            scene clrxms122 with fade
            pause
            d1 "Since we are friend.."
            dr "Don't..."
            d1 "Ehehehe..."
            scene clrxms123 with fade
            pause
            d3 "Oh you're still here"
            d3 "I thought [pD8] would take you right away."
            sg "He let me spend some time with you."
            scene clrxms124 with fade
            pause
            d3 "How generous [pD8].."
            sg "He is awesome.."
            sg "I wish my [pD8] was like that."
            d3 "Nope"
            sg "?"
            scene clrxms125 with fade
            pause
            d3 "I'm not interested in your family stories."
            sg "Oh ok.."
            scene clrxms126 with fade
            pause
            d3 "Hey"
            d3 "Sorry"
            d3 "I'm sure you have a hard life"
            scene clrxms128 with fade
            pause
            d3 "But that's my personality, don't take it personally"
            scene clrxms127 with fade
            pause
            sg "It's okay"
            sg "I can understand"
            sg "You're jealous about your [pD13]"
            scene clrxms129 with fade
            pause
            d3 "What pfft no.."
            sg "Whatever you say.."
            scene clrxms130 with fade
            pause
            d3 "So"
            d3 "Do you like to have fun?"
            sg "Yes!"
            scene clrxms131 with fade
            pause
            d3 "Have you ever had fun with another girl before?"
            sg "Uh huh"
            d3 "Oh yeah"
            d3 "How?"
            sg "Uhmmm"
            sg "You know games and other things.."
            d3 "Like what.."
            sg "Chatting..."
            d3 "What else?"
            sg "Playing with dolls"
            d3 "Mhmm"
            scene clrxms133 with fade
            pause
            d3 "I can play with dolls too"
            sg "Amazing!"
            sg "Do you have any ?"
            scene clrxms134 with fade
            pause
            d3 "I have now..."
            scene clrxms136 with fade
            pause
            sg "......"
            scene clrxms137 with fade
            pause
            sg "What do you mean..."
            scene clrxms138 with fade
            pause
            d3 "Come here"
            sg "...."
            scene clrxms139 with fade
            pause
            d3 "That was fun"
            sg "Yeah..."
            sg "I think it's time to go..."
            scene clrxmsend with fade
            pause
            wf "You did all this [mc]?"
            mc "Nope"
            wf "Hmmm.."
            wf "I love you so much guys"
            d2 "Same"
            d1 "You're the same! {w} as Emma!"
            d3 "When we can go to our rooms?"
            mc "Oh you want to stay in there more?"
            d3 "..."
            d1 "..."
            wf "What's going on"
            mc "Nothing babe."
            mc "Happy new year guys!"
        "No":
            mc "I'm sorry but they are grounded..."
            scene clrxms113 with fade
            pause
            sg "Yeah I know.."
            sg "I just wanted to try my luck."
            mc "It's okay, I can accompany you"
            scene clrxms116 with fade
            pause
            sg "Really!?"
            mc "Of course"
            sg "Thank you mister!"
            mc "These lights hurt my eyes"
            mc "I'm going to my bedroom"
            mc "Come there if you want. Or you can watch the tree here"
            mc "It's your choice"
            sg "Coming!"
            scene scnfg1 with fade
            pause
            sg "So what should we do?"
            mc "You tell me."
            mc "We have to play or chat or anything you want"
            scene scnfg2 with fade
            pause
            sg "I don't think you are a good player that's why I wanna chat !"
            scene scnfg3 with fade
            pause
            mc "Ouch, but keep going"
            menu:
                "Peek":
                    scene scnfg4 with fade
                    pause
                "Dont":
                    pass
            scene scnfg5 with fade
            pause
            sg "Where is your [pD9]?"
            mc "She is at my [pD7]'s house."
            scene scnfg6 with fade
            pause
            sg "Why aren't you there?"
            mc "I'm surrounded by women, sometimes it's good for my health to stay away from them"
            sg "But I'm here"
            mc "Yup"
            mc "But you don't talk that much"
            scene scnfg7 with fade
            pause
            sg "I guess that's a good thing"
            mc "for me, yeah"
            sg "Do you love your [pD9]?"
            mc "Of course"
            sg "Do you love your [pD7]?"
            mc "I love everyone who is related to me."
            scene scnfg8 with fade
            pause
            sg "Oh.."
            sg "All my questions have been answered now.."
            mc "Noice"
            scene scnfg5 with fade
            pause
            sg "What do you think about Santa?"
            mc "I think he is a good guy"
            scene scnfg2 with fade
            pause
            sg "I know right!"
            sg "I've always wanted to meet him"
            sg "I even secretly left cookies and milk on the doorstep every Christmas."
            scene scnfg7 with fade
            pause
            sg "But not just for him to visit me"
            sg "Because maybe he's hungry"
            sg "I've never been mad at him because he never came"
            sg "But..."
            mc "Maybe Santa didn't notice your cookie gesture because he was visiting houses from the chimney"
            sg "I wasn't born yesterday I know somethings.."
            mc "Oh, I thought.."
            scene scnfg5 with fade
            pause
            sg "Santa must be too fat to fit through the chimney so he must be entering through the door"
            mc "Oh yeah.."
            mc "But santa is not fat"
            mc "He is fit"
            sg "How the hell could you know?"
            mc "Cuz we're friends"
            sg "No way!"
            mc "Yup"
            sg "I don't believe you!"
            scene scnfg9 with fade
            pause
            mc "Oh yeah"
            mc "Stay here, I'll call him for you"
            sg "Will you do that for me!"
            mc "Of course"
            sg "....."
            sg "Thank you..."
            mc "Just wait"
            sg "Please be fast I'm so excited!"
            scene scnfg10 with Fade(1.5, 1.0, 0.5)
            pause
            mc "What the hell was that fat bastard saying?.."
            mc "Hah I remember"
            scene scnfg11 with fade
            pause
            mc "Hoo Hooo hooo"
            scene scnfg12 with fade
            pause
            sg "OH MY GOD!"
            scene scnfg13 with fade
            pause
            sg "It's you Santa! Oh my god! Oh my god! Oh my god!"
            mc "Yes my dear"
            sg "Thank you for coming!"
            scene scnfg14 with fade
            pause
            mc "My beloved friend told me about you"
            scene scnfg15 with fade
            pause
            sg "Where is he?"
            mc "He.."
            mc "is busy at the moment"
            sg "Wow it's really you!"
            sg "I don't know what should I do now!"
            sg "Oh oh oh I know!"
            sg "I've always wanted to sit on your lap!"
            "Jackpot!"
            mc "Sure my dear"
            scene scnfg16 with fade
            pause
            mc "How do you feel?"
            sg "Amazing!"
            menu:
                "Just chat with her":
                    scene scnfg16 with fade
                    pause
                    mc "So tell me my dear"
                    mc "What do you want from Santa this year?"
                    scene scnfg17 with fade
                    pause
                    sg "You already gave my present Santa."
                    mc "That's cute.."
                    sg "I can stay here forever"
                    mc "That might be a problem for me.."
                    sg "Yeah you have to visit other houses too.."
                    mc "Wish.."
                    sg "Huh?"
                    mc "Nothing"
                    mc "So I guess I have to go now"
                    scene scnfg19 with fade
                    pause
                    sg "..."
                    sg "Thank you so much Santa.."
                    mc "Be a good girl and I might visit you again."
                    sg "Next year.."
                    mc "Maybe sooner.."
                    scene scnfg18 with fade
                    pause
                    sg "Seriously!!!"
                    mc "You bet"
                    sg "Yaay.."
                    mc "..."
                    scene clrxmsend with Fade(1.5, 1.0, 0.5)
                    pause
                    wf "You did all this [mc]?"
                    mc "Nope"
                    wf "Hmmm.."
                    wf "I love you so much guys"
                    d2 "Same"
                    d1 "You're the same! {w} as Emma!"
                    d3 "When we can go to our rooms?"
                    mc "Oh you want to stay in there more?"
                    d3 "..."
                    d1 "..."
                    wf "What's going on"
                    mc "Nothing babe."
                    mc "Happy new year guys!"
                    $config.allow_skipping = True
    jump v035
