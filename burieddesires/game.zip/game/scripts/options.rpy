













define config.name = _("Buried Desires")





define gui.show_name = False




define config.version = "0.5"





define gui.about = _p("""
""")






define build.name = "BuriedDesires"







define config.has_sound = True
define config.has_music = True
define config.has_voice = True













define config.main_menu_music = "audio/bensound-hey.mp3"
define config.default_music_volume = 0.3
define config.default_sfx_volume = 0.3








define config.enter_transition = dissolve
define config.exit_transition = dissolve




define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)







default preferences.text_cps = 0





default preferences.afm_time = 15
















define config.save_directory = "BuriedDesires-1608813468"






define config.window_icon = "gui/window_icon.png"






init python:




















    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)








    build.archive("v0.5patch", "all")
    build.classify('game/lwdptch/**.**', 'v0.5patch')

    build.classify('game/images/**.png', 'archive')
    build.classify('game/images/**.jpg', 'archive')
    build.classify('game/animation/**.mpg', 'archive')
    build.classify('game/animation/**.webm', 'archive')
    build.classify('game/scripts/**.rpy', 'archive')
    build.classify('game/scripts/**.rpyc', 'archive')



    build.documentation('*.html')
    build.documentation('*.txt')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
