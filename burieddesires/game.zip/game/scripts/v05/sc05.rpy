label v05a:
    play music "audio/phoenix.mp3"
    scene rcpgacbgn1 with dissolve
    "Man... I feel bad for Zoey now."
    "It's still the best decision, but..."
    "She suddenly left, the look on her face made me very uncomfortable."
    "Is she okay?"
    menu:
        "Go after Zoey":
            mc "I'm not sure how much this will affect her..."
            mc "After all, I don't know her deeply. In fact, the longest conversation I had with her was this..."
            mc "She may be a much different person than she looks"
            mc "Maybe she was affected enough to hurt herself."
            mc "I feel like I shouldn't risk it even if it's a very small possibility."
            scene rcpgac1 with dissolve
            mc "Hey"
            rcr "What you need, sir?"
            mc "Did you see...."
            scene rcpgac2 with dissolve
            rcr "Dude really?"
            mc "Huh?"
            rcr "You keep asking me 'have you seen her, where has she gone...' bla bla bla"
            rcr "What is your deal?"
            mc "What is my deal? {w} What is your deal miss!"
            mc "Acting like a robot and suddenly acting like... this"
            mc "Are you like this to everyone, or do you have a special grudge against me?"
            scene rcpgac3 with dissolve
            rcr "I'm just tired, sorry"
            rcr "Please don't report me."
            mc "(She changed her attitude again)"
            mc "I'm confused."
            rcr "I was pretending to protect my mental health"
            mc "What kind of role is this?"
            rcr "I'm answering questions like crazy so that they can get away from here as fast as they can."
            mc "Oh right, I always want to get out of here as soon as possible."
            mc "Hah, so your method is working, nice."
            mc "Well it would be more accurate to say that it was working. Why did you break the role?"
            mc "I wonder if I'm a very difficult man..."
            rcr "Actually, I thought I was reaching my limit in general, but maybe you've brought me to the point where I can't stand it."
            mc "Is it good or not?"
            rcr "Depends on what you're going to do."
            mc "I won't get you fired, don't worry."
            scene rcpgac5 with dissolve
            rcr "Phew..."
            rcr "Thank you so much."
            rcr "I'm really sorry about my outburst."
            scene rcpgac6 with dissolve
            mc "Sush"
            mc "It's okay, I get it."
            mc "You must be suffocating in stress."
            rcr "You can't imagine..."
            mc "No need to, I'm going through the same thing, this is not a vacation for me either."
            rcr "She's your responsibility, isn't she?"
            mc "You need to relax."
            mc "I don't mind. But if it was one of the snobs when you were having this outburst, it wouldn't be too surprising that you'd be fired"
            rcr "You're right, I should be more careful"
            scene rcpgac6 with dissolve
            menu:
                "Use this chance":
                    mc "(Hmm, maybe I can take her stress out, she's vulnerable right now, I can use that.)"
                    mc "Do you think that temporarily relaxing with outbursts of anger is the definitive solution?"
                    scene rcpgac8 with dissolve
                    rcr "Okay, you're right, but what can I do..."
                    rcr "I can't ask for a day-off right now."
                    mc "What will change if you ask for that, you will have delayed the inevitable end a little."
                    rcr "So what, should I resign because I'm going to be fired anyway!"
                    rcr "Sorry... That was not nice. I'm under a lot of pressure."
                    mc "Yeah and I have a solution for that."
                    rcr "Really?"
                    mc "Maybe we can be a little naughty."
                    scene rcpgac4 with dissolve
                    rcr "Oh..."
                    rcr "Actually, it's not a bad idea, but I still feel like you're trying to take advantage of my situation."
                    mc "Well I'm just giving you a choice, and yes, it's a useful option for myself, because I'm stressed too, it's a mutual situation"
                    scene rcpgac7 with dissolve
                    rcr "And if I used this idea with someone else, how would you feel then?"
                    scene rcpgac6 with dissolve
                    mc "(Well of course, I would be very uncomfortable with this situation, after all, it doesn't sound nice for her to have sex with someone else when there is a possibility of me fucking her.)"
                    mc "(Since we're playing dirty...)"
                    mc "Frankly, I don't really care, after all, I don't have any feelings for you, you're a stranger."
                    mc "But if I have a chance to blow off some steam with sex, I won't miss it"
                    rcr "So the important thing is my decision."
                    mc "(Oh you bitch)"
                    mc "(Now it's time to plant the bomb)"
                    mc "Mhm hm, but if I was a selfish and bad person, you wouldn't choose someone else because I have the power to get you fired."
                    mc "Am I wrong?"
                    scene rcpgac7 with dissolve
                    rcr "Touche..."
                    rcr "So.."
                    rcr "What are you thinking of?"
                    mc "Your mouth..."
                    rcr "Hmph?"
                    rcr "Oh..."
                    rcr "I see now..."
                    rcr "Was funny"
                    mc "I know"
                    mc "Anyway let's go to my room."
                    scene rcpgac8 with dissolve
                    rcr "It's too risky, I can't leave here, and it won't be good for me if I'm seen entering or leaving a client's room."
                    mc "That makes sense."
                    mc "You can't come to my room and you can't leave your place."
                    mc "This limits our options quite a lot."
                    rcr "Yeah..."
                    rcr "I guess that wasn't a good idea."
                    mc "The exact opposite."
                    mc "Can I come there?"
                    rcr "Uhmm sure. But why?"
                    mc "You will see."
                    scene rcpgac9 with dissolve
                    rcr "So you're going to help by reducing my workload?"
                    mc "Hell no."
                    mc "Will you get down on your knees, please?"
                    rcr "Why? Did you drop something?"
                    rcr "Oh..."
                    rcr "No!"
                    rcr "It's too risky..."
                    rcr "How are we supposed to do it here? It seems impos...{w} Oh you want a blow job!"
                    mc "Clever girl."
                    rcr "But what's in it for me? Aren't you a little selfish?"
                    mc "It's much easier and safer than licking pussy, don't you think?"
                    mc "Besides, I'm not the only one who's going to enjoy it. You're going to love it and you're going to get wet it's in your DNA."
                    rcr "Well... Can't argue with that."
                    rcr "I'm in!"
                    mc "But is it really okay to do it here?"
                    rcr "Well, if someone comes, we'll tell them that I dropped something on the floor and you helped me find it."
                    scene rcpgac10 with dissolve
                    rcr "Oh you are hard already..."
                    mc "(I was sure this would happen, my body just kept up with my brain.)"
                    mc "You can look at my dick, you don't have to be ashamed girl."
                    rcr "I'm not, I'm just making sure there's no one around."
                    mc "It's okay, there is no one."
                    rcr "I'm going to be fired so hard..."
                    mc "Well, if you get fired, you'll have done it in a legendary way."
                    rcr "Yeah."
                    rcr "By the way, damn this is the biggest dick I've ever touched."
                    mc "If you turn your head, it will also be the biggest dick you've ever seen."
                    scene rcpgac11 with dissolve
                    mc "What?"
                    mc "What is that look?"
                    scene rcpgac12 with dissolve
                    mc "Hm?"
                    mc "(I think she's too afraid of getting caught.)"
                    mc "(She accepted it with an instant decision and now regrets it)"
                    mc "(Should I stop?)"
                    menu:
                        "Stop":
                            mc "Let's just stop."
                            mc "I felt like I was abusing you."
                            scene rcpgac13 with dissolve
                            rcr "No!"
                            rcr "I like it. Really really like it."
                            mc "I can't tell much from your face..."
                            scene rcpgac10 with dissolve
                            rcr "No it's because..."
                            rcr "I just came... That's why..."
                            mc "No way."
                            rcr "Yeah, I had the same reaction."
                            rcr "At first I thought I was like this because I was so embarrassed, but it turns out I'm cumming..."
                            mc "(Hah look at that, she is an exhibitionist!)"
                            mc "(And she just discovered this)"
                            mc "Okay this is good."
                            rcr "Not for me."
                            rcr "Yes, it feels great, but this excitement was scary..."
                            mc "(Some people use drugs to feel like this...)"
                            rcr "And it's just handjob, I have no idea how I would react if we had sex."
                            mc "You'd probably scream."
                            mc "Or you wouldn't. Maybe you like the thrill of being caught, who knows?"
                            mc "So we keep going?"
                            scene rcpgac13 with dissolve
                            rcr "Yes, it's your turn."
                            mc "Oh yeah. I made you cum without penetrating or licking."
                            mc "You totally owe me."
                        "Comfort her":
                            scene rcpgac11 with dissolve
                            mc "Hey, calm down, it's gonna be okay."
                            mc "Remember what we planned?"
                            mc "We won't get caught by anyone, I swear to you."
                            scene rcpgac12 with dissolve
                            rcr "Mhmmm hm"
                            mc "Is that a yes?"
                            rcr "Mhm hmm"
                            mc "Well I guess so"
                            mc "(She already came or what?)"
                            mc "(Nah it's impossible, she didn't even touch herself)"
                            mc "(Most likely she was embarrassed or afraid.)"
                            mc "(No need to overthink, just enjoy the moment [mc])"
                    scene anrcpgac1
                    pause
                    scene anrcpgac2
                    pause
                    scene rcpgac13 with dissolve
                    rcr "How is it so far?"
                    mc "Good good"
                    rcr "Doesn't seem like though..."
                    mc "I think you need to change your strategy."
                    rcr "What're you getting at?"
                    mc "It's time to wet my dick."
                    rcr "I thought you'd cum before that...."
                    mc "Oh honey I'm not a teenager."
                    mc "(Neither are you, and that's the real answer to this question)"
                    scene rcpgac14 with dissolve
                    mskg "Hey"
                    scene rcpgac15 with dissolve
                    mskg "I need help, but who are you?"
                    mc "How may I help you?"
                    scene rcpgac16 with dissolve
                    mskg "Huh?"
                    mskg "That's weird."
                    mskg "Where is that lady?"
                    mc "She is... busy."
                    scene rcpgac17 with dissolve
                    mskg "Anyway, my room smells strange again."
                    mc "Then take a shower."
                    mskg "You're terrible at this."
                    mc "Oh yeah"
                    scene rcpgac18 with dissolve
                    mc "...."
                    mc "(What is wrong with her eyes...)"
                    mc "You are right."
                    scene rcpgac17 with dissolve
                    mskg "So..."
                    mskg "The smell?"
                    mc "Hmm"
                    mc "Pretty good, I like it."
                    mskg "What?"
                    mc "Your smell"
                    scene rcpgac19 with dissolve
                    mskg "Oh.."
                    mskg "Ahahah"
                    mskg "Thank you"
                    mc "You're welcome missy."
                    mskg "Okay, I'm changing my mind, you're good."
                    mc "Well I changed my mind too..."
                    mc "The first time I saw you, I thought you must be a freak"
                    mc "But you're normal."
                    mc "Why do you even wear a mask?"
                    scene rcpgac17 with dissolve
                    mskg "Actually I'm a weirdo."
                    mskg "I have Tourette syndrome."
                    mc "So you swear?"
                    mskg "Wish..."
                    mskg "I do things with my mouth."
                    mc "It's called talking."
                    mc "(Aw man I could have said something sexier...)"
                    mc "(I always come up with the best ideas when it's too late.)"
                    mskg "Haa haa"
                    mskg "Not that, like throwing kisses."
                    mskg "Also I stick my tongue out and do things."
                    mskg "In short..."
                    mc "You make dicks hard in public."
                    mc "(Okay...)"
                    mc "(And sometimes I go a bit far...)"
                    mc "(Well let's see where it goes)"
                    mskg "Wow..."
                    mskg "But yeah..."
                    mskg "Some people find it creepy, and others..."
                    mskg "Like you said..."
                    mc "(Maybe I should always go a little too far)"
                    mc "I wanna see"
                    mskg "......."
                    scene rcpgac19 with dissolve
                    mskg "It's embarrassing..."
                    mc "Now I wanna see more"
                    mskg "Oh well, you're being nice to me anyway"
                    scene rcpgac20 with dissolve
                    pause
                    scene rcpgac21 with dissolve
                    mskg "Hey"
                    mc "(Damn she's prettier than I thought)"
                    scene rcpgac22 with dissolve
                    rcr "(his dick is getting hard...)"
                    rcr "(Is he really into....)"
                    mc "Wow you're quite beautiful."
                    scene rcpgac23 with dissolve
                    mskg "Oh shut up..."
                    mc "...."
                    mskg "You really shut up..."
                    scene rcpgac24 with dissolve
                    mskg "Am I really?"
                    mskg "Oh c'mon don't shut up."
                    mc "Yes honey you are really."
                    scene rcpgac25 with dissolve
                    mskg "You are pretty handsome, you know."
                    mc "Yes I know"
                    mskg "Confident, like it"
                    mc "Yeah by the way, I fucking love your syndrome."
                    mskg "No way, why?"
                    mc "I don't need a reason to like this."
                    mc "I just like what I see."
                    scene rcpgac26 with dissolve
                    mskg "I wish you were always around..."
                    mc "(Oh no she's sad, I have to try to avoid sadness my dick is almost ready for her)"
                    mc "Surround yourself with people who will accept you as you are, then you won't need to wear a mask"
                    mc "For now, I can fill this gap."
                    mc "I am really good at it..."
                    mskg "Oh are you..."
                    mc "You have no idea girl."
                    mskg "Maybe you'll teach me a lesson before you go"
                    mc "Maybe I will"
                    scene rcpgac27 with dissolve
                    mc "(can't get any harder than this, it's time)"
                    mskg "You should stay at the reception more."
                    mc "Why? Isn't she good enough?"
                    mskg "I don't know..."
                    mskg "She's just weird, you know."
                    mskg "Like a..."
                    mc "Robot, yes."
                    mc "To be honest, people who work as receptionists should be fun."
                    mc "Like you."
                    rcr "(Asshole...)"
                    scene rcpgac28 with dissolve
                    mskg "Such a nice way to compliment."
                    mskg "Do you really like talking to me that much?"
                    rcr "(Okay he is hard like a rock, I think it's time to suck him.)"
                    rcr "(So exciting!)"
                    scene rcpgac29 with dissolve
                    mc "Hmph?"
                    mskg "I'm starting to feel like you're going to jump on me suddenly"
                    mc "(Because someone is sucking my dick)"
                    scene rcpgac30 with dissolve
                    mc "You have no idea..."
                    mskg "Oh my, no hesitation..."
                    mskg "Maybe I will let you, who knows..."
                    mc "I know because I don't need you to let me..."
                    mc "(I'm about the cum!)"
                    scene rcpgac31 with dissolve
                    mc "Show me that mouth again!"
                    mskg "This is not a trick to show people..."
                    mc "Trick, syndrome, weirdness... I don't care what it is. Just show me!"
                    mskg "Oh my..."
                    mskg "Okay..."
                    scene rcpgac32 with dissolve
                    mc "Ugh not this one!"
                    mskg "I'm not doing it on purpose, I don't have a choice..."
                    mskg "..."
                    scene rcpgac33 with dissolve
                    mc "There, perfect!"
                    mc "Your mouth is fucking amazing!"
                    mskg "......"
                    mskg "I..."
                    mskg "Really..."
                    scene rcpgac34 with dissolve
                    pause
                    scene rcpgac35 with dissolve
                    mc "(phew... that was weirdly hot.)"
                    scene rcpgac23 with dissolve
                    mskg "Uhm..."
                    mc "I'll call the receptionist to take care of your problem."
                    scene rcpgac26 with dissolve
                    "Oh yeah that, thank you."
                    scene rcpgac24 with dissolve
                    mc "(she wants to continue flirting but unfortunately we don't really care about flirting after ejaculating and I'm tired of standing.)"
                    mskg "See you later then..."
                    scene rcpgac23 with dissolve
                    mc "Who knows..."
                    mc "(There she goes, her weirdness was really hot. I liked it, it's good to try new things.)"
                    scene rcpgac9 with dissolve
                    rcr "You are a mad man..."
                    rcr "But it was super exciting!"
                    rcr "I've never felt like this before."
                    mc "You're welcome."
                    rcr "So when we do this again?"
                    mc "Oh, I never thought about it."
                    rcr "What?"
                    mc "We have to get back after this cosplay contest is over, ugh a class full of problems are waiting for me..."
                    scene rcpgac8 with dissolve
                    rcr "Oh..."
                    rcr "I see..."
                    mc "(I think she's become obsessed with me, I don't blame her.)"
                    mc "(What was her name... Can't remember, well no need to, she is the freaky masked girl for me.)"
                    mc "Oh by the way, the contest is today, isn't it?"
                    rcr "Yeah"
                    mc "Gonna watch?"
                    rcr "I'll probably be busy."
                    mc "Okay, I'm going."
                    mc "That was fun."
                    rcr "Yeah was super fun, see you later."
                "I can help you":
                    scene rcpgac3 with dissolve
                    rcr "I would be very glad, but how will you help?"
                    mc "We can simply talk."
                    scene rcpgac4 with dissolve
                    rcr "What's the use of talking, anyway?"
                    mc "I don't know, how are you feeling right now?"
                    rcr "Well... much more better than before."
                    mc "You know why?"
                    rcr "Because my nervous breakdown is over."
                    scene rcpgac6 with dissolve
                    mc "Yes but mostly because we are talking."
                    mc "You are not talking to me with a command given to you, but completely of your own free will."
                    mc "If two people who hate each other could come face-to-face and talk for a while without physical fighting, the problem between them would be solved"
                    rcr "Even if one of those people kills someone the other person loves?"
                    mc "Yeah that was stupid, but what I said before is true."
                    mc "C'mon check your tension. You are better than before, am I wrong?"
                    scene rcpgac4 with dissolve
                    rcr "Yeah I guess so..."
                    rcr "Okay I can do it!"
                    mc "You're already doing it honey!"
                    mc "Sorry for a moment I addressed you like one of my students."
                    rcr "Oh no, it's okay."
                    scene rcpgac7 with dissolve
                    rcr "Thank you, for saying nice things..."
                    mc "Okay, then if I have time, I'll come talk to you every once in a while and compliment you"
                    rcr "What? Ahahah"
                    rcr "You're crazy..."
                    scene rcpgac6 with dissolve
                    mc "(Ugh so cliche...)"
                    mc "Flirting is becoming more unbearable every year...)"
                    mc "If you feel good enough, I'm running away."
                    rcr "Yes I am, thank you so much [mc], I can't wait for your next visit."
                    mc "Good girl."

        "She will be fine":
            scene rcpgacbgn1 with dissolve
            mc "(After this cosplay thing is over, I'll pull her aside and talk to her properly.)"
            mc "(I hope she doesn't have a selfish and vindictive character that she's hiding.)"
            mc "(After all, the easiest student I can reach in the class is Zoey.)"
            mc "(Losing her from the very beginning would cause a very difficult process for me.)"
    jump v05c
label v05b:
    play music "audio/phoenix.mp3"
    scene rcpgacbgn1 with dissolve
    pause
    scene mnglr1 with dissolve
    csp1 "You're pretty popular with the girls, aren't you?"
    mc "Oh hey."
    mc "You again."
    csp1 "Usually people are happy to see me."
    mc "Mhm hm"
    mc "Are you washing those clothes?"
    csp1 "I have 5 backups."
    csp1 "What about you?"
    mc "Same."
    mc "What do you want?"
    csp1 "......."
    csp1 "I had you investigated"
    mc "Okay..."
    mc "Is this legal?"
    csp1 "I don't know probably."
    mc "You really need to get out of your golden cage and learn about the real world."
    scene mnglr2 with dissolve
    csp1 "And you need to get out of your cave!"
    scene mnglr3 with dissolve
    mc "You're the one sitting at my table without permission, and you've also threatened me before."
    mc "I think I'm free to say what I want, if you don't like it, you can leave."
    csp1 "........"
    scene mnglr4 with dissolve
    csp1 "I came here to talk to you about something important."
    mc "I will not withdraw from the competition."
    csp1 "It's not about that."
    mc "Oh okay then, what do you want?"
    scene mnglr5 with dissolve
    csp1 "A little manners for a start."
    mc "Nope you get what you deserve."
    csp1 "....."
    "How did you manage to become a teacher in such a school?"
    mc "(Huh she really learned about me, I think she's not someone who pretends to be a princess with a small fortune.)"
    menu:
        "You should ask this to my students":
            mc "After all, I am educating students of the most prestigious school in the country."
            scene mnglr6 with dissolve
            csp1 "What about the schools you worked at before? The public ones?"
            csp1 "I know you're newbie in this school."
            csp1 "I doubt they'll even remember your name in such a short time."
            scene mnglr3 with dissolve
            mc "(Agh I deserved that...)"
            mc "(Wait, why am I acting like I've lost? I am very successful at teaching.)"
            mc "Yeah it may be a public school, but even with those limited opportunities, my students' average success was very high."
            scene mnglr7 with dissolve
            csp1 "Oh yeah, sure sure..."
            csp1 "Does this include suicide average too?"
            scene mnglr8 with dissolve
            mc "I'm gonna pretend I didn't hear that.."
            csp1 "Okay that was low I'm sorry."
            mc "..."
        "Lie":
            scene mnglr6 with dissolve
            mc "Because I'm one of the owners of the school and I'm tired of being idle."
            csp1 "Ahahaha nice one."
            csp1 "Seriously why?"
            mc "(Of course, she did not believe such a lie, but at least I tried)"
            mc "I'm not gonna answer this question."
            scene mnglr7 with dissolve
            csp1 "I'm wondering why. Is there something you're hiding?"
            mc "I'm sure there's nothing that will work for you."
        "Don't answer":
            mc "Why should I answer this question?"
            scene mnglr6 with dissolve
            csp1 "Because I'm asking."
            mc "This does not provide the necessary motivation for me to answer."
            csp1 "..."
    scene mnglr4 with dissolve
    csp1 "Okay I'll cut to the chase."
    csp1 "How much do you want to recommend me to the school?"
    mc "How much you got?"
    scene mnglr5 with dissolve
    csp1 "Uhmm I never counted...."
    mc "Then how do you know how rich you are?"
    scene mnglr9 with dissolve
    csp1 "I have everything, even the things I don't want"
    mc "Why are there things you don't want, are you crazy?"
    scene mnglr10 with dissolve
    csp1 "No, figure of speech, and you're crazy not me!"
    mc "Wow, an unexpected reaction from a supplicant."
    csp1 "Oh yeah sorry, sometimes I do that..."
    mc "Bitching out?"
    scene mnglr11 with dissolve
    csp1 "...."
    mc "I asked a question."
    csp1 "Yes."
    mc "Yes, what?"
    csp1 "Are you really going to do this?"
    mc "Yes."
    scene mnglr12 with dissolve
    csp1 "A bitch, sometimes I act like a selfish spoiled reckless bitch."
    mc "Wow calm down a bit, you're talking about yourself."
    scene mnglr13 with dissolve
    csp1 "............."
    csp1 "Asshole"
    mc "What was that?"
    scene mnglr14 with dissolve
    csp1 "Can you help me please!"
    mc "No."
    scene mnglr15 with dissolve
    csp1 "Why? It should be very easy for you!"
    mc "It is."
    scene mnglr16 with dissolve
    csp1 "Then why!"
    csp1 "Don't you want money?"
    csp1 "If so, we can complete what we left unfinished."
    mc "The fight by the pool?"
    scene mnglr17 with dissolve
    csp1 "..."
    csp1 "Yeah!"
    mc "Why would I want such a thing?"
    scene mnglr18 with dissolve
    csp1 "How about my girls, if there's someone you like, you know..."
    scene mnglr19 with dissolve
    mc "You're cute, have a nice day..."
    mc "What was your name again?"
    scene mnglr20 with dissolve
    csp1 "It's Annie."
    mc "There is no Annie in my class."
    csp1 "Did you mean you were going to help me!?"
    csp1 "I can be the best Annie ever for you!"
    mc "Wow! Calm down walking desperation."
    mc "I just realized that there is no one in my class with the same name as you."
    mc "Cya!"
    "Asshole!"
    scene rcpgac37 with dissolve
    mc "(Hah look at this! Ugly fat boss and sexy secretary cosplay.)"
    scene rcpgac38 with dissolve
    pause
    scene rcpgac39 with dissolve
    pause
    scene rcpgac37 with dissolve
    mc "(The sexier the woman, the uglier and more repulsive the man, heh perfect balance.)"
    mc "(But damn she is really hot.)"
    scene rcpgac40 with dissolve
    mc "(Oh... Look at that, she likes to tease.)"
    mc "(C'mon give me more.)"
    scene rcpgac41 with dissolve
    mc "(Looks like we have a mind reader, nice butt)"
    scene rcpgac42 with dissolve
    mc "(No panties...)"
    scene rcpgac43 with dissolve
    pause
    scene rcpgac44 with dissolve
    pause
    scene rcpgac45 with dissolve
    pause
    scene rcpgac46 with dissolve
    pause
    scene rcpgac47 with dissolve
    pause
    scene rcpgac48 with dissolve
    pause
    scene rcpgac49 with dissolve
    pause
    scene rcpgac50 with dissolve
    pause
    scene rcpgac51 with dissolve
    pause
    scene rcpgac52 with vpunch
    rcr "I'm so sick and tired of damn questions!"
    rcr "I'm not a fucking search engine!"
    smbs "Who the fuck do you think I am? You worthless bitch!"
    smbs "Isn't that your job!"
    smbs "I'm gonna fire you!"
    mc "(Oh c'mon! That was the best part...)"
    mc "(Wait what's going on there?)"
    smbs "You are done! You hear me? Done!"
    mc "(Wow... I think this guy doesn't do cosplay, the receptionist found out about it in a bad way...)"
    mc "(Must be suck, she was weird but I hope she won't get fired)"
    smbt "Sir please calm down. I handle this, you go sit down."
    scene rcpgac53 with dissolve
    pause
    smbs "Can you believe that bitch, the problem with this country is that the working class doesn't know its place, she has no idea what I'm going to do to her"
    smbs "I'm not just going to get her fired, it's natural selection for her."
    scene rcpgac54 with dissolve
    pause
    mc "Maybe she's just having a bad day, she doesn't deserve to be targeted for a momentary outburst of anger."
    smbs "..."
    smbs "The people around me usually approve of what I say, and so they can continue to live normally, it!s a good tip for you."
    smbs "Okay sir, we can move."
    smbs "I like you anyway, your aura. This is what I look for in my managers."
    smbs "What do you do for a living?"
    mc "I'm shaping young minds"
    smbs "Heh shaping minds huh, keep it up."
    scene rcpgac55 with dissolve
    pause
    scene rcpgac56 with dissolve
    smbt "We should move sir, we don't have so much time."
    smbs "Sure sure, let's go."
    scene rcpgac57 with dissolve
    pause
    mc "Nice suit by the way."
    mc "But it doesn't suit you, I'm afraid."
    smbs "Funny guy, keep it up."
    menu:
        "Let him go":
            scene rcpgac56 with dissolve
            mc "...."
            mc "(Nope I'm not gonna do it.)"
        "Annoy him":
            scene rcpgac58 with dissolve
            mc "I was fantasizing about your secretary a few minutes ago, and man, you should have seen what a freak fantasy this is, well actually you did."
            smbs "What the fuck is wrong with this guy?"
            smbs "And what is wrong with you?"
            mc "(He's kinda right...)"
            smbt "We should move sir..."
    scene rcpgac59b with dissolve
    mc "(I can easily destroy him just by talking, but I don't want any more potential enemies.)"
    scene rcpgac59 with dissolve
    mc "(She seems so upset... I have to check on her.)"
    scene rcpgac60 with dissolve
    mc "Hey"
    mc "First of all, I'm not going to ask for a direction, so hold your fire, I just want to ask, are you okay?"
    rcr "I'm fucked, how can I be?"
    rcr "I'll probably be fired soon."
    mc "Well... Yeah probably."
    mc "Such types do not hesitate to destroy the people they see below themselves in order to satisfy their ego."
    mc "I've met one of them."
    rcr "Fuck them! Fuck everyone."
    mc "Including me?"
    rcr "Just leave me alone please."
    mc "Okay"
    mc "But before I go..."
    mc "Maybe getting fired from this job will cause a much better change in your life, don't devestated, just start planning what you're going to do next"
    "...."
    mc "Okay then I'm going."
    scene rcpgac59b with dissolve
    play sound "audio/notify.mp3"
    "{i} Zoey: I've arranged your costumes, let's meet in my room as soon as possible! \n ps: the door is open{/i}"
    mc "(I hope you will prepare for the assignments I will give you with this speed and enthusiasm.)"
    scene rcpgac61 with dissolve
    mc "So what are we doing?"
    scene rcpgac62 with dissolve
    mc "Zoey?"
    scene rcpgac63 with dissolve
    sy "Meowwww!"
    mc "Wow, a cat."
    scene rcpgac64 with dissolve
    sy "Purrr!"
    mc "You're in the character. So what? Am I going to be a dog now?"
    sy "What? No, it's catwoman."
    mc "Turn around."
    scene rcpgac65 with dissolve
    mc "(Nice ass Zoey.)"
    mc "Oh batman and catwoman I see it now. All the pieces finally clicked into place."
    mc "Okay this is a good idea."
    mc "That means..."
    scene rcpgac66 with dissolve
    mc "I am vengeance, I am the night, I am Batman!"
    scene rcpgac67 with dissolve
    sy "Oh my god yes!"
    sy "You are so awesome! Yes yes!"
    mc "Batman is my generation hero Zoey of course I know him"
    scene rcpgac68 with dissolve
    sy "Perfect, now dress up!"
    mc "It's a little early, isn't it?"
    mc "I don't wanna walk around with costume..."
    sy "Yeah but rehearsal?"
    mc "Oh right, sometimes I forget that this competition is something important to you."
    mc "Allright let's suit up."
    sy "You really doing it..."
    mc "Well yeah whole operation was your idea."
    scene rcpgac69 with dissolve
    sy "I..."
    sy "Even after accepting this, I was wondering when you would give up."
    sy "But you're really being a partner with me instead of your own [pD21]."
    sy "You don't secretly hate her, do you?"
    mc "What, of course no."
    mc "She is my sunshine."
    sy "Then why?"
    mc "I have a reason for that."
    sy "Teacher thing?"
    mc "Yeah."
    sy "...."
    sy "I can't do this to you [mc]."
    sy "And to her."
    sy "I just really want to see what you're going to do."
    sy "It was selfish I know, but I'm like this."
    mc "Don't you want me to be your partner?"
    scene rcpgac70 with dissolve
    sy "Of course I do."
    sy "But it's not right, honestly this is enough for me."
    mc "But what about the contest?"
    scene rcpgac69 with dissolve
    sy "I lied a little bit about it..."
    mc "So if you don't win, nothing will happen?"
    sy "Yeah..."
    sy "So sorry. Please don't hate me, I'm just... you know..."
    mc "Yeah I get that."
    scene rcpgac71 with dissolve
    sy "Are you mad at me?"
    menu:
        "Yes":
            mc "I hate being lied to, Zoey."
            sy "You're right, I'm willing to accept your punishment."
            sy "I'm serious, I did cross the line."
            sy "You can pick any punishment you want, not gonna argue, just accept it."
            mc "Really?"
            scene rcpgac70 with dissolve
            sy "Yes, I deserved that sir."
            mc "Kind of yeah."
            scene rcpgac71 with dissolve
            sy "So what will my punishment be..."
            scene rcpgac72 with dissolve
            mc "Come here and lie down on my knees."
            sy "Uhm I don't get it."
            mc "Spank, my dear student, it's old but gold."
            sy "Oh my..."
            sy "You're serious..."
            mc "Now!"
            sy "Y... Yes sir!"
            sy "Uhm..."
            scene rcpgac73 with dissolve
            sy "This is really embarrassing, mr. [mc]."
            scene rcpgac74 with dissolve
            mc "Don't worry, the pain will take away the shame."
            sy "Oh... I"
            sy "I deserved this."
            scene rcpgac75 with dissolve
            sy "Is caressing part of spanking mr.[mc]?"
            mc "Yes, i'm getting your ass ready for a slap."
            sy "Oh my..."
            scene rcpgac76 with dissolve
            sy "Okay"
            play sound "audio/Slap1.mp3"
            scene rcpgac77 with vpunch
            sy "I'm read..."
            scene rcpgac78 with dissolve
            sy "Aww!"
            mc "Are you sorry for your behavior!"
            scene rcpgac79 with dissolve
            sy "Yes yes, I'm so sorry mr.[mc]!"
            sy "Ouch..."
            menu:
                "Stop":
                    scene rcpgac74 with dissolve
                    mc "Okay then, that's all I wanted to hear."
                    sy "Oh..."
                    sy "Thanks..."
                    mc "I have to go to Ruby."
                    sy "Of course."
                    mc "See you in contest."
                    sy "Can't wait."
                "Harder":
                    scene rcpgac80 with dissolve
                    mc "Is it so?"
                    mc "You didn't just lie to me..."
                    mc "You tried to test me!"
                    play sound "audio/Slap1.mp3"
                    scene rcpgac81 with vpunch
                    sy "Ahhh!"
                    sy "Yes mr.[mc]! I did that!"
                    sy "I'm a bad bad girl! I deserve this punishment!"
                    mc "(What the fuck Zoey? Are you trying to make me hard...)"
                    menu:
                        "Harder!":
                            scene rcpgac80 with dissolve
                            pause
                            play sound "audio/Slap1.mp3"
                            scene rcpgac81 with vpunch
                            sy "Ouch!!"
                            scene rcpgac80 with dissolve
                            pause
                            play sound "audio/Slap1.mp3"
                            scene rcpgac81 with vpunch
                            sy "Awww!!!!"
                            mc "(I'm getting out of control, she said she likes the pain, but I still feel strange...)"
                            mc "You little arrogant selfish girl!"
                            scene rcpgac82 with dissolve
                            sy "Oh my god yes!!!!!!!"
                            mc "Huh?"
                            scene rcpgac83 with dissolve
                            sy "Oh I mean, oh my god! It hurts!!"
                            mc "(Does she like it...)"
                            sy "I..."
                            sy "I think this is enough sir..."
                            mc "Oh, I'm sorry. I forgot who is in charge."
                            mc "I'll decide when it's enough!"
                            scene rcpgac84 with dissolve
                            sy "Inngggh!!"
                            sy "Hurts so fucking much!!"
                            mc "One more for the swear!"
                            scene rcpgac85 with dissolve
                            sy "Just let me take a breathe, please..."
                            play sound "audio/Slap1.mp3"
                            scene rcpgac86 with vpunch
                            sy "Mr.[mc] it's getting really sore..."
                            mc "Yeah, if I keep doing this, my hand will get red, good catch Zoey"
                            scene rcpgac87 with dissolve
                            sy "Actually, I was talking about myself..."
                            sy "Your belt is poking my belly every time you spank mr.[mc]..."
                            sy "And I feel so tired..."
                            mc "Have you learned your lesson, Zoey?"
                            sy "Yes mr.[mc]."
                            mc "Good, this was a little trailer for your future and your classmate's future."
                            mc "Right, Zoey?"
                            mc "Oh she fell asleep..."
                            mc "Weird, seems really relaxed."
                            scene rcpgac88 with dissolve
                            mc "Now it's time to go Ruby, I was thinking about how to tell her the bad news."
                            mc "But everything went well."
                        "Don't cross the line":
                            scene rcpgac88 with dissolve
                            mc "I think it's time to stop."
                            sy "Oh..."
                            sy "Thanks mr.[mc]..."
                            mc "I have to go to Ruby."
                            sy "Of course."
                            mc "See you in contest."
                            sy "Can't wait."

        "No":
            scene rcpgac71 with dissolve
            mc "Well I assume you have reasons, but I still haven't figured out exactly what you're thinking"
            mc "But we have a long time ahead of us to understand this."
            mc "I'm that kind of a teacher."
            scene rcpgac68 with dissolve
            sy "Lucky me and of course lucky them"
            sy "I can't wait to see the class obey you in the future mr.[mc]."
            mc "Obeying is a absurd choice of words for this, but yes, for me"
            mc "I have to go to Ruby."
            sy "Of course."
            mc "See you in contest."
            sy "Can't wait."
    jump v05c

label v05c:
    scene rbmgrlgrdn1 with dissolve
    mc "There she is..."
    scene rbmgrlgrdn2 with dissolve
    mc "With a company..."
    mc "Let me guess, she's trying to use Ruby to get close to me."
    mc "I wonder what kind of plan she has."
    scene rbmgrlgrdn3 with dissolve
    csp1 "I think this is an opportunity that you won't get, and be sure this is a first for us too."
    csp1 "For the first time we are including someone from outside in the team."
    csp1 "I knew the first moment I saw you, you need a group of friends to support you."
    scene rbmgrlgrdn4 with dissolve
    rb "But I've already got what I want."
    rb "Besides, I have a partner."
    scene rbmgrlgrdn5 with dissolve
    csp1 "Oh I see..."
    csp1 "I thought we had a new friend that we would meet regularly after this competition."
    rb "Friends..."
    rb "More than one..."
    rb "How many of you were there?"
    csp1 "4"
    rb "Wow..."
    rb "So many friends."
    scene rbmgrlgrdn6 with dissolve
    csp1 "Yeah, more friends, more fun!"
    rb "Oh wow..."
    csp1 "Yeah yeah, you in?"
    scene rbmgrlgrdn8 with dissolve
    pause
    scene rbmgrlgrdn6 with dissolve
    rb "Uhmm, no."
    csp1 "Huh!?"
    scene rbmgrlgrdn4 with dissolve
    rb "My partner is better than four friends."
    scene rbmgrlgrdn9 with dissolve
    csp3 "Ouch"
    csp1 "...."
    scene rbmgrlgrdn10 with dissolve
    csp1 "The worst day ever."
    csp1 "Why have I become like this? Instead of walking around and insulting people, I'm constantly begging someone for something."
    csp1 "I hate you dad!"
    csp1 "You know what? I give up."
    csp1 "I don't care, I'm fine like this. I'm just okay without that fucking school."
    scene rbmgrlgrdn11 with dissolve
    rb "Uhmmm"
    csp1 "What?"
    scene rbmgrlgrdn12 with dissolve
    rb "I can see your panties..."
    csp1 "Oh"
    csp1 "Did you like it?"
    rb "What! No..."
    rb "I mean I don't know..."
    csp1 "No one around, it's cool."
    rb "Uhmm okay..."
    csp1 "Your partner is a dick, by the way."
    scene rbmgrlgrdn13 with dissolve
    rb "He certainly isn't!"
    csp1 "Well maybe not to you."
    scene rbmgrlgrdn14 with dissolve
    rb "Oh..."
    rb "I can't say anything about that."
    scene rbmgrlgrdn13 with dissolve
    rb "But you're still talking bad about someone I love."
    rb "I can't accept this!"
    csp1 "What if he's a serial killer?"
    scene rbmgrlgrdn15 with dissolve
    rb "Then he would be the most perfect serial killer in the world."
    csp1 "You have no idea what we're talking about, do you?"
    scene rbmgrlgrdn14 with dissolve
    rb "I'm not stupid, I know what a serial killer is."
    rb "But still he is my..."
    rb "Everything."
    rb "I probably would have let him kill me."
    scene rbmgrlgrdn16 with dissolve
    csp1 "Damn"
    csp1 "It's sick."
    csp1 "Or love, I don't know the difference."
    csp1 "But I know this, it would be interesting to live in your head."
    scene rbmgrlgrdn15 with dissolve
    rb "A sick love!"
    csp1 "Heh we can say that."
    csp1 "You are so pretty. Did you know that?"
    scene rbmgrlgrdn17 with dissolve
    rb "Awww thank you!"
    rb "Yes, I'm aware of that, my [pD14] always reminds me of it."
    scene rbmgrlgrdn13 with dissolve
    rb "Only to me."
    rb "Not to anyone else! To me!"
    csp1 "Allright Juliet we get it."
    scene rbmgrlgrdn14 with dissolve
    rb "By the way you are so pretty too."
    scene rbmgrlgrdn16 with dissolve
    csp1 "Hah is that so?"
    scene rbmgrlgrdn15 with dissolve
    rb "Yes, you look so gorgeous."
    rb "To be honest, I was excited when you sat next to me."
    scene rbmgrlgrdn17 with dissolve
    csp1 "Why?"
    rb "Because you are a very beautiful person."
    csp1 "Just because of that?"
    rb "Yup"
    scene rbmgrlgrdn12 with dissolve
    csp1 "We're not much different from animals, and that bothers me."
    csp1 "..."
    csp1 "Why is no one asking anything about what I just said!"
    rb "Oh I..."
    rb "I basically have no idea what you're talking about, so..."
    csp1 "What about you? You are one of my sidekicks!"
    scene rbmgrlgrdn10 with dissolve
    csp3 "Oh I..."
    csp3 "I simply don't care what you're talking about, that's why."
    csp1 "Just ask."
    csp1 "Oh okay, why?"
    csp1 "Because...."
    scene rbmgrlgrdn18 with dissolve
    csp1 "You know what? Forget it, let's go."
    csp1 "See you later."
    csp1 "Bye bye"
    rb "Bye bye!"
    scene rbmgrlgrdn18 with dissolve
    pause
    scene rbmgrlgrdn19 with dissolve
    pause
    scene rbmgrlgrdn20 with dissolve
    mc "Well well..."
    scene rbmgrlgrdn21 with dissolve
    csp1 "Ugh are you stalking me dude?"
    mc "I think you should stop trying."
    csp1 "I don't know what you're talking about."
    scene rbmgrlgrdn22 with dissolve
    mc "Pfft you know."
    mc "Just leave me alone, you wanted it, but you didn't get it."
    mc "Stop bothering other people to get what you want."
    mc "This is the only information I will give you as a teacher."
    csp1 "Meh"
    mc "Hmm, something is weird."
    mc "You don't speak in a hateful tone anymore."
    mc "Why is that?"
    scene rbmgrlgrdn23 with dissolve
    csp1 "I kinda like her."
    csp1 "She likes you a lot."
    csp1 "I guess I can't go above that."
    csp1 "Also..."
    csp1 "I'm already one step ahead of you."
    csp1 "But at least answer this question."
    csp1 "Could you have gotten me into that school somehow?"
    mc "Yeah, I think I have that power."
    scene rbmgrlgrdn24 with dissolve
    csp1 "Ah, I did not expect that."
    csp1 "It didn't feel good to know that."
    scene rbmgrlgrdn22 with dissolve
    mc "Well, this is life."
    mc "You want to go to that school just to make your family happy, don't you?"
    csp1 "Bingo."
    mc "I understand that you are happy where you are."
    mc "If you really wanted this, you would have looked for another way instead of giving up at the first difficulty you faced."
    scene rbmgrlgrdn25 with dissolve
    csp1 "Like, for example, going to my target and telling him I've given up and making him let his guard down?"
    mc "Yes, yes, I know this paradox."
    mc "Also I know one more thing."
    mc "Reading people. Thanks to my profession, I can do this very easily."
    mc "You don't want anything from me anymore, I can see that."
    scene rbmgrlgrdn26 with dissolve
    csp1 "'This is the only information I will give you as a teacher' my ass"
    csp1 "You just lectured me again!"
    csp3 "Oh my god. Yes he did!"
    mc "No I didn't..."
    mc "Have you ever been educated before?"
    mc "Do you have any idea what it is like?"
    csp1 "Oh shut up mr.Tough Guy, you buried your axe too."
    csp1 "Wow it feels good."
    mc "What makes you feel good?"
    scene rbmgrlgrdn27 with dissolve
    csp1 "This."
    csp1 "I meant us."
    csp1 "First you hated me, when I stopped hating you, you stopped too."
    csp1 "Yeah yeah, you're not going to help me, I get it, but still"
    scene rbmgrlgrdn28 with dissolve
    csp1 "If you had given me a chance, I could have changed your mind."
    mc "Seriously, the new generation flirts very well."
    mc "One quick blink and you're already on my chest."
    scene rbmgrlgrdn29 with dissolve
    csp1 "No faster than your hands, I didn't even notice when you grab me."
    csp1 "Also, since you think like that, I think I've impressed you."
    scene rbmgrlgrdn30 with dissolve
    csp1 "But damn, you are a big man."
    csp1 "How small I am compared to you."
    csp1 "So exciting and scary..."
    csp1 "But I'm impressed, your hands know how to react quickly."
    scene rbmgrlgrdn31 with dissolve
    csp1 "Thats a strong grab..."
    csp1 "But perfectly precise, pleasure and pain are in harmony, just as I like."
    mc "(Oh you know how to talk, you little bitch.)"
    scene rbmgrlgrdn32 with dissolve
    mc "You never give up, do you?"
    scene rbmgrlgrdn33 with dissolve
    mc "The woman who gets what she wants one way or another."
    mc "This is what you will turn into."
    mc "That's what's best for a woman."
    csp1 "Imhh hh"
    csp1 "Does this bother you?"
    csp1 "To come face to face with such a woman?"
    scene rbmgrlgrdn34 with dissolve
    csp1 "Mhmm such a strong hands and fingers."
    csp1 "I bet no one has ever kissed your finger before."
    scene rbmgrlgrdn35 with dissolve
    mc "You have no idea how many girls have this finger in their mouth, don't worry about it"
    scene rbmgrlgrdn36 with dissolve
    mc "But the answer to your question is yes, no one has done this before, I like it."
    scene rbmgrlgrdn35 with dissolve
    csp1 "I have to taste it."
    csp1 "Don't look at me like that, you want this."
    scene rbmgrlgrdn36 with dissolve
    mc "(But I didn't? I think she's on autopilot...)"
    scene rbmgrlgrdn35 with dissolve
    csp1 "Touching my lips like this nu uh"
    csp1 "You have to touch the inside of my mouth..."
    csp1 "And I have to taste you..."
    scene rbmgrlgrdn36 with dissolve
    mc "(Hot so hot, this crazy bitch knows what to do.)"
    scene rbmgrlgrdn37 with dissolve
    mc "(Wait! I'm losing control!)"
    scene rbmgrlgrdn38 with dissolve
    mc "(Oh fuck it, let her try a little.)"
    scene rbmgrlgrdn36 with dissolve
    mc "(I can't let my guard down because of finger sucking...)"
    scene rbmgrlgrdn38 with dissolve
    mc "(Can I?)"
    scene rbmgrlgrdn35 with dissolve
    mc "(Let's wait and see, show me what you got princess)"
    scene rbmgrlgrdn37 with dissolve
    mc "I can feel your throat pressing on my finger, I couldn't wait to feel the same with my dick."
    scene rbmgrlgrdn38 with dissolve
    pause
    scene rbmgrlgrdn39 with dissolve
    csp1 "Imh..."
    csp1 "Wow, that was intense."
    csp1 "Do you like it?"
    mc "You know I do."
    scene rbmgrlgrdn30 with dissolve
    csp1 "How exactly do I know..."
    mc "I'm sure you're feeling the pressure."
    csp1 "Oh my, that means I woke up the monster huh?"
    mc "Yes honey, you did."
    scene rbmgrlgrdn31 with dissolve
    csp1 "I brought you to this point just by licking your finger, if I tried a little more, maybe I could get what I want..."
    mc "Aww honey, you're definitely not ready for this."
    mc "I'm like an endgame to you."
    mc "It would be devastating for you, like going up against the endgame monster in the first level"
    csp1 "How devastating it can be..."
    mc "When you're trying to get what you want the most, I take from you something that you didn't know I wanted yet."
    csp1 "Although the result for me is a definite loss, I will have gained a huge experience."
    mc "Jackpot."
    scene rbmgrlgrdn40 with dissolve
    csp3 "Oh my good it's like a sex theatre!"
    csp3 "Please keep going!"
    scene rbmgrlgrdn30 with dissolve
    csp1 "Hmmm, I'm not sure if we should continue."
    mc "Bitch you already know my answer."
    csp1 "That was the right answer."
    scene rbmgrlgrdn42 with dissolve
    csp1 "Will I be your student?"
    mc "Like I said before bitch, you already know my answer."
    scene rbmgrlgrdn43 with dissolve
    csp1 "Well, don't blame me for trying."
    csp1 "Yes, maybe I didn't get what I wanted, but you were very kind to me"
    csp1 "So I decided to reward you."
    mc "Nice!"
    csp1 "Let me finish."
    scene rbmgrlgrdn29 with dissolve
    csp1 "You found him cute before wanna make him cum?"
    scene rbmgrlgrdn44 with dissolve
    csp3 "(Do I!)"
    mc "(I think that's what I like the most in the new generation.)"
    menu:
        "Do it":
            mc"Why the hell not?"
            csp3 "Yay"
            scene rbmgrlgrdn45 with dissolve
            csp1 "Cool, have fun guys."
            mc "(She is very unstable, but it's kinda hot.)"
            scene rbmgrlgrdn46 with dissolve
            csp3 "Hey"
            scene rbmgrlgrdn47 with dissolve
            mc "I feel so tired."
            mc "You can go if you want, I'm gonna sit here and enjoy the view."
            csp3 "Can I join you?"
            mc "Sure."
            scene rbmgrlgrdn48 with dissolve
            csp3 "What view are we going to enjoy?"
            mc "For me the sky, but I suggest you to sun, you are as pale as vampire, missy"
            csp3 "Oh yeah I am."
            scene rbmgrlgrdn49 with dissolve
            csp3 "So what you want me to do?"
            mc "I don't know, just don't make me move."
            mc "I feel so lazy."
            csp3 "Oh I know what to do."
            scene rbmgrlgrdn1a
            csp3 "Do you like it sir?"
            mc "Sure."
            scene rbmgrlgrdn2a
            csp3 "Your penis is so beatiful."
            mc "This is the first time I've received such a compliment."
            csp3 "She is so cute, I want to put on makeup and kiss so bad!"
            mc "Please don't."
            mc "Just make me cum. I have to go to the contest."
            csp3 "Oh yeah the contest, we have to hurry."
            scene rbmgrlgrdn3a
            mc "I don't think we have to hurry that much."
            mc "Oh fuck it go faster!"
            csp3 "Yes sir!"
            scene rbmgrlgrdn4a
            pause
            scene rbmgrlgrdn50 with dissolve
            mc "Innghh..."
            mc "Ugh that was a bad idea."
            mc "Rushing orgasm is the worst. I hope I never have to cum like this again."
            scene rbmgrlgrdn51 with dissolve
            mc "Nice catch."
            mc "I did not expect that."
            mc "Good job"
            mc "But don't drop it on my suit, please."
            scene rbmgrlgrdn52 with dissolve
            mc "Look at you, such a good girl."
            mc "Allright now swallow it."
            scene rbmgrlgrdn53 with dissolve
            mc "Nice."
            mc "Lets check it, open your mouth."
            scene rbmgrlgrdn54 with dissolve
            mc "Nice nice"
            scene rbmgrlgrdn55 with dissolve
            mc "You deserved this pat."
            scene rbmgrlgrdn56 with dissolve
            mc "I think you like it."
            scene rbmgrlgrdn57 with dissolve
            mc "Oh you really like it huh?"
            mc "Well..."
            scene rbmgrlgrdn58 with dissolve
            mc "You're like a pet, you know that?"
            csp3 "Mhm hm"
            scene rbmgrlgrdn59 with dissolve
            mc "(She is cute...)"
            mc "Allright take your time."
        "Don't":
            scene rbmgrlgrdn29 with dissolve
            mc "Nah, I'm gonna pass on this."
            mc "Don't get me wrong, she is hot and completely fuckable."
            mc "But not like this."
            mc "And thanks, you're cute too."
            csp3 "Aww..."
    scene ctnyrsma1 with dissolve
    mc "Allright let's get over this."
    mc "I think I came early."
    scene ctnyrsma2 with dissolve
    mc "Hey"
    scene ctnyrsma3 with dissolve
    "What can I get you?"
    mc "I'm fine thanks, when will this start?"
    "My shift has just started, I don't know."
    "You should ask the dj"
    mc "Thanks."
    scene ctnyrsma4 with dissolve
    mc "(Nice view.)"
    scene ctnyrsma5 with dissolve
    mc "Do you need help?"
    scene ctnyrsma6 with dissolve
    djg "Oh, thanks, but no need"
    scene ctnyrsma7 with dissolve
    djg "Hi"
    mc "Can you please get down the stage, I really don't like people to look down on me."
    scene ctnyrsma8 with dissolve
    djg "Oh about that, can't do it."
    mc "Why?"
    djg "Because floor is lava"
    mc "How am I stepping then?"
    djg "I don't know, man, maybe you have lava-proof shoes or something."
    mc "I see."
    scene ctnyrsma9 with dissolve
    djg "How about this?"
    mc "Well better than before."
    djg "Awesome, what you need?"
    mc "Nothing actually."
    mc "Are you competing too?"
    djg "Nah, I'm the dj."
    mc "Cool."
    djg "What about you?"
    mc "My nephew is one of the contestants."
    djg "Which one?"
    mc "Most gorgeous one obviously."
    scene ctnyrsma10 with dissolve
    djg "Ah a loving parent, I thought you were a legend."
    mc "We are real, thanks."
    djg "She must be so lucky."
    djg "Most parents do not take this hobby seriously, they do not even see such activities at the amusement park level"
    mc "Yeah that's true."
    mc "So what is your deal?"
    mc "Are you a student trying to make money, or do you hang out in places like this because you like cosplay?"
    scene ctnyrsma11 with dissolve
    djg "When you look at me, do you only see these 2 options?"
    mc "Considering the position we're in right now, yeah, don't you think it makes sense?"
    djg "Actually, it is, second option by the way."
    djg "I love cosplay."
    mc "You've wasted my time so unnecessarily..."
    djg "Hah, I'm so young that I could lose tons of time, but unfortunately, the same does not apply to you..."
    mc "Ugh okay, I get it, I'm a little old, every fucking one..."
    mc "Find a new opening line for flirting."
    djg "Oh you want me to flirt with you."
    mc "I don't want it, you're already doing it."
    djg "Maybe I do, who knows..."
    mc "Me, just said it."
    djg "yeah yeah you got my point."
    djg "Literally couldn't impress you geeez..."
    mc "Yeah my balls are kinda empty, if we had met a few hours later, I would have stayed on the right side of you."
    scene ctnyrsma12 with dissolve
    djg "Wow strict to the point, you nasty old man."
    mc "But, right now my priority is Ruby."
    mc "By the way, do you know how the competition will be?"
    scene ctnyrsma13 with dissolve
    djg "Oh it's not a big thing, they will take turns on the stage, the jury will look and give notes, and then they will announce the winner in the final."
    mc "And?"
    djg "That's pretty much."
    mc "I was expecting more entertainment."
    djg "Ugh you're in the nerd paradise dude, don't disrespect their dreams."
    djg "You're living their dream, be grateful."
    mc "Oh I am so far from that."
    mc "And I hope for more."
    djg "It's starting, good luck to your [pD21]."
    mc "Thanks, but she doesn't need."
    djg "Haha cool [pD14]!"
    mc "That's what they call me."
    mc "Hah I didn't notice, but it's getting crowded in here."
    scene ctnyrsma14 with dissolve
    mc "Man every time I see a sweet bum, I get hypnotized."
    mc "Allright it's time to find a place to sit now."
    scene ctnyrsma15 with dissolve
    mc "Ruby should be backstage, I shouldn't visit her like a crazy parent"
    mc "I was barely able to restore her self-confidence. If I go to her now and others make fun of her, she may withdraw from the competition."
    mc "When they see how great her cosplay is, they will want to eliminate the biggest threat."
    mc "Damn she was gorgeous in that costume!"
    scene ctnyrsma16 with dissolve
    mskg "Hey [mc], can I sit with you?"
    mc "Of course, I need a companion anyway."
    mskg "Lucky then!"
    mc "Me or you?"
    mskg "Uhmm both?"
    mc "Sure why the hell not?"
    scene ctnyrsma17 with dissolve
    mc "Aren't you participating in the competition?"
    scene ctnyrsma18 with dissolve
    mskg "No I just like to watch."
    mc "Sometimes me too."
    mc "Aren't you going to take off the mask?"
    mskg "Well... You know my condition."
    mc "Yeah, that's why I'm asking."
    mc "You can be comfortable around me."
    mskg "......"
    mc "Do it."
    mskg "Yes sir..."
    scene ctnyrsma19 with dissolve
    mc "Much better."
    mskg "Well if you say so."
    scene ctnyrsma20 with dissolve
    pause
    mc "And here it is."
    mskg "Oh stop..."
    mc "What? I like it."
    mskg "You are serious huh."
    scene ctnyrsma21 with dissolve
    pause
    mc "Okay think like that, everyone uses no more than 4-5 expressions in their daily life."
    mc "Doesn't that make people boring?"
    mskg "So that means I'm not boring?"
    mc "Better, you are interesting."
    scene ctnyrsma22 with dissolve
    pause
    mskg "Ehehe thanks."
    mc "So who's your favorite?"
    mskg "Ooh the redhead girl, she was stunning in that costume!"
    mc "I know right!"
    mskg "How about yours?"
    mc "Same stunning girl!"
    mskg "Oh! Shall we make a bet on whose favorite will win?"
    mc "..."
    mc "We picked the same girl..."
    scene ctnyrsma23 with dissolve
    pause
    mskg "Ooh right..."
    mskg "Sorry I'm not so bright sometimes."
    play music "audio/phoenix.mp3"
    scene ctnyrsma24 with dissolve
    pause
    scene ctnyrsma25 with dissolve
    pause
    scene ctnyrsma26 with dissolve
    djg "Allright people get ready for the contestants."
    mc "Hm it's beginning."
    djg "We invite our first contestant to the stage."
    scene ctnyrsma27 with dissolve
    pause
    scene ctnyrsma28 with dissolve
    mc "This is the only girl who responds to me like a normal person."
    mskg "I've never seen her talking to anyone before, she was constantly playing with her phone."
    djg "Next we have another bunny costume"
    scene ctnyrsma30 with dissolve
    pause
    scene ctnyrsma31 with dissolve
    mc "Hah, she changed her costume, good for her, that nun costume was boring"
    scene ctnyrsma31v3 with dissolve
    csp2 "Hi, can I sit here, you're the only person I know so..."
    scene ctnyrsma31v2 with dissolve
    mc "Of course there is plenty of room."
    csp2 "Thanks."
    scene ctnyrsma31v4 with dissolve
    csp2 "What do you think about my costume?..."
    mc "Tell her what I just said."
    mskg "Hah, she changed her costume, good for her, that nun costume was boring"
    mc "Damn you are pretty bright sometimes."
    csp2 "..."
    mskg "Eheh I have a good memory"
    "..."
    scene ctnyrsma29 with dissolve
    pause
    scene ctnyrsma31v5 with dissolve
    csp4 "So did you pick this place to sit huh?"
    mc "You can walk or crawl it's your decision."
    csp4 "Sure why not?"
    mc "(Huh even though I teased, she didn't answer, it's strange)"
    scene ctnyrsma32 with dissolve
    pause
    scene ctnyrsma33 with dissolve
    pause
    scene ctnyrsma31v6 with dissolve
    csp3 "Hey guys, are we sitting here huh?"
    mc "Sure sure you are welcome too."
    scene ctnyrsma31v7 with dissolve
    mc "Wow, there are a lot more cosplayers than before."
    mskg "Most of them only attend the competition day."
    mc "Cool."
    scene ctnyrsma34 with dissolve
    mc "Woah, who is her?"
    mskg "This is the first time I've seen her."
    mskg "She is too young, but fucking killing it."
    scene ctnyrsma35 with dissolve
    pause
    mc "Absolutely..."
    mc "(Damn I wish I'd met you at the hotel she is so gorgeous.)"
    mc "Does anyone know who she is?"
    mskg "Nope."
    csp3 "Same."
    scene ctnyrsma36 with dissolve
    pause
    scene ctnyrsma39 with dissolve
    mc "And here she is."
    scene ctnyrsma31v8 with dissolve
    csp1 "Did you like the show."
    mc "So far yeah."
    mc "Take a seat."
    csp1 "Nah we have a shit to do, let's go girls our job is done."
    mc "Don't you want to see the rest of the cosplayers?"
    csp1 "Nope."
    csp1 "Cya."
    mc "(Man I want her to see Ruby...)"
    scene ctnyrsma31v9 with dissolve
    mc "Why are you giggling?"
    mskg "Nothing."
    scene ctnyrsma37 with dissolve
    mc "Is that..."
    scene ctnyrsma38 with dissolve
    mc "Holy shit this is Zoe."
    mc "She changed her costume."
    mc "But every time I see her, she gets sexier."
    scene ctnyrsma31v10 with dissolve
    sy "Hi mr.[mc], can I sit with you?"
    mc "Of course."
    scene ctnyrsma31v11 with dissolve
    sy "Who is she?"
    mc "A friend."
    sy "Of course."
    sy "How was I."
    mc "Very good."
    scene ctnyrsma31v12 with dissolve
    sy "Ehehe thanks mr.[mc]."
    mc "You should dress more like this."
    sy "Oh..."
    sy "Maybe I will"
    mc "Can't wait to see more."
    scene ctnyrsma40 with dissolve
    mc "She's here!"
    scene ctnyrsma31v13 with dissolve
    mc "So fucking gorgeous..."
    scene ctnyrsma41 with dissolve
    mc "Oh no..."
    mskg "What's wrong with her?"
    scene ctnyrsma31v14 with dissolve
    mc "She petrified."
    scene ctnyrsma31v15 with dissolve
    mc "C'mon Ruby...."
    scene ctnyrsma31v16 with dissolve
    stop music
    pause
    scene black
    "few years ago..."
    pause
    scene flbqrbft1 with dissolve
    pause
    scene flbqrbft2 with dissolve
    rbf "I still can't believe I'm wasting my time on something like this."
    rbf "This is so boring..."
    scene flbqrbft4 with dissolve
    ss "Could you please stop that?"
    scene flbqrbft3 with dissolve
    rbf "Don't grumble when the girls are around, don't grumble when the girls aren't around, why should I just shut up all the time and silently approve of this nonsense?"
    scene flbqrbft4 with dissolve
    ss "The other day you got drunk with your stupid friends and spent hours arguing about where the floating pontoons were connected."
    ss "This is one of your daughter's most important days and it's only going to take a few hours, I can't believe I'm explaining this to you."
    scene flbqrbft3 with dissolve
    rbf "Not this again, how they ram those fucking pontoons into the seabed is really a mystery, of course we'll be arguing about it for hours."
    rbf "Ugh sometimes I forget how stupid you are Amy."
    ss "......."
    scene flbqrbft4 with dissolve
    ss "Just be patient."
    rbf "Oh yeah for what? what will this bring me?"
    ss "You'll be a father, you stupid bastard!"
    scene flbqrbft3 with dissolve
    rbf "Pfft big fucking deal, my girls are tough, they don't need a father."
    rbf "Me and my sister didn't need."
    ss "Oh yeah best results ever, one idiot pothead and what was Cindy doing these days?"
    rbf "Mind your own fucking business, she is doing good."
    ss "She is a fucking whore!"
    rbf "Don't talk shit about my sister, bitc. She is doing her best."
    ss "I'm sure her customers are very satisfied about that."
    rbf "I swear to god..."
    scene flbqrbft4 with dissolve
    ss "What? You gonna hit me?"
    scene flbqrbft3 with dissolve
    rbf "...."
    rbf "Just shut the fuck up."
    scene flbqrbft5 with dissolve
    "Excuse me, but you're fighting very loudly, could you be quieter please?"
    ss "I'm so sorry miss."
    rbf "I'm not, even fuck you."
    rbf "Hah look at her man, she's afraid of getting beaten up, she's ignoring me."
    rbf "Such a puss"
    scene flbqrbft4 with dissolve
    ss "It's beginning sush!"
    scene flbqrbft3 with dissolve
    rbf "Big fucking deal."
    rbf "They're just half brained little animals."
    scene flbqrbft4 with dissolve
    ss "One of them is your daughter!"
    rbf "Ahaha yeah I know."
    ss "Asshole..."
    scene flbqrbft3 with dissolve
    rbf "I hope she doesn't embarrass me, I'm telling you Amy if she fucks it up I'll get out of here."
    ss "Shut the fuck up it's started!"
    scene flbqrbft7 with dissolve
    pause
    scene flbqrbft8 with dissolve
    girl1 "Oh witch, cruel witch, please don't take me away from xmast I..."
    girl1 "I want to stay here, there's only an hour left, please witch please"
    scene flbqrbft9 with dissolve
    girl2 "Hah beg as much as you want I won't let you into christmas."
    rbf "Oh my god...."
    ss "Shut the fuck up!"
    scene flbqrbft8 with dissolve
    girl1 "Oh how cruel witch you are, is there no one to help me, to stop this wicked witch?"
    girl1 "I said is there no one to help me!"
    scene flbqrbft10 with dissolve
    rb "......"
    ss "Oh my good she is here!"
    ss "She looks so cute. Honey I love you so much!"
    scene flbqrbft11 with dissolve
    rb "I... I..."
    rb "I'm here to stop you!"
    ss "You are going good honey! Keep going!"
    scene flbqrbft13 with dissolve
    girl1 "How lucky I am, here is a savior!"
    girl1 "Save me from this cruel bitch."
    girl1 "Witch! I mean witch!"
    rbf "Ahaha allright you got me there."
    ss "Ugh..."
    girl2 "You can't stop me xmas protector, I am way ahead of you!"
    girl2 "Now get out of my way or I'll pinch you!"
    rb "I..."
    rbf "C'mon Ruby, don't embarrass me, just say it and get off the stage."
    rb "I..."
    scene flbqrbft12 with dissolve
    rb "I..."
    ss "You can do it honey!"
    rb "I....."
    scene flbqrbft14 with dissolve
    rbf "Fuck it I'm done, can't watch this no more."
    rbf "Good luck with her, I'm going to smoke some weed to forget this disappointment."
    scene flbqrbft15 with dissolve
    rb "Dad...."
    girl1 "Dad?"
    girl2 "Ahahahha"
    girl1 "She said dad aahaha"
    scene flbqrbft16 with dissolve
    rb "DAD"
    scene flbqrbft17 with dissolve
    pause
    play music "audio/phoenix.mp3"
    scene ctnyrsma31v16 with dissolve
    pause
    scene ctnyrsma31v18 with dissolve
    mc "Ruby!"
    mc "I'm here honey it's okay!"
    mc "(C'mon baby we've been through this c'mon you can do it!)"
    mc "(Maybe I should go get dressed... What am I talking about, I don't have time!)"
    mc "(Please don't black out...)"
    mc "(C'mon look at me)"
    mc "(C'mon c'mon I should do something..."
    mc "You are not alone! I'm here for you!"
    scene ctnyrsma31v17 with dissolve
    csp1 "......"
    scene ctnyrsma31v19 with dissolve
    csp1 "The fuck you are!"
    mc "huh?"
    csp1 "I mean let's make it two, if I'm going to lose this, I'm going to lose to someone who deserves to win."
    csp1 "That's why I'm here with you, for her."
    scene ctnyrsma31v20 with dissolve
    csp1 "Ruby! You are gorgeous!"
    csp1 "Wohoooooooo!"
    csp1 "Give us a show!"
    scene ctnyrsma31v21 with dissolve
    csp2 "Uhm you don't sound like you are supporting her, more like you're angry with her."
    csp1 "Shut up and cheer!"
    scene ctnyrsma31v22 with dissolve
    csp3 "Oh my good what a stunning babe!"
    scene ctnyrsma31v23 with dissolve
    csp2 "You are amazing girl!"
    mc "....."
    mc "Damn I did not expect that...."
    scene ctnyrsma41 with dissolve
    rb "[pD14]..."
    rb "He's looking at me..."
    rb "But not with pitying eyes, he is proud of me!"
    rb "And those girls..."
    scene ctnyrsma42 with dissolve
    rb "Snap out of it Ruby!"
    rb "I thought I didn't care about winning this, but I can't fail when you look at me like that."
    rb "Even if I fail this time, at least I'll try!"
    scene ctnyrsma31v24 with dissolve
    rb "Fuck it!"
    rb "I'm going to win this shit!"
    mc "Ahahaha you said it out loud."
    mc "But yeah princess fuck it and win this shit!"
    play music "audio/biohazard.mp3"
    scene ctnyrsma31v25 with dissolve
    pause
    scene ctnyrsma31v26 with dissolve
    pause
    scene ctnyrsma31v27 with dissolve
    pause
    scene ctnyrsma31v28 with dissolve
    pause
    scene ctnyrsma31v29 with dissolve
    pause
    scene ctnyrsma31v30 with dissolve
    pause
    scene ctnyrsma31v31 with dissolve
    pause
    scene ctnyrsma31v33 with dissolve
    pause
    scene ctnyrsma31v32 with dissolve
    pause
    scene ctnyrsma43 with dissolve
    rb "*breathes"
    scene ctnyrsma45 with dissolve
    rb "Oh my god, I did it!"
    scene ctnyrsma46 with dissolve
    rb "I'm so embarrassed, but I don't care. i did a good job, [pD14]. that's the only thing that matters to me!"
    scene ctnyrsma47 with dissolve
    mc "That's my girl."
    csp1 "Ha, we had no chance from the beginning..."
    csp3 "You are such a tsundere."
    csp1 "Shut up!"
    scene ctnyrsma49 with dissolve
    pause
    scene ctnyrsma26 with dissolve
    djg "Wow that was..."
    djg "Awkward."
    djg "But pretty awesome!"
    djg "All right people, this was the last contestant."
    djg "We're taking a short break now. I'll take the results from the jury and announce the winner in a moment."
    scene ctnyrsma48 with dissolve
    rb "[pD14]!"
    rb "I was so scared until I saw you."
    rb "I'm so tired..."
    scene ctnyrsma466 with dissolve
    mc "I'm not surprised, what have you done?"
    scene ctnyrsma48 with dissolve
    rb "I've worked for this. but I didn't even think I'd do it on stage."
    rb "You encouraged me last time and then..."
    rb "...."
    scene ctnyrsma50 with dissolve
    rb "I was so scared..."
    rb "But then I saw you and and..."
    scene ctnyrsma51 with dissolve
    mc "Sush princess"
    mc "You made me so proud."
    rb "I..."
    scene ctnyrsma52 with dissolve
    mc "I love you so much Ruby."
    scene ctnyrsma53 with dissolve
    rb "*Mumbling"
    mc "I know princess I know."
    scene ctnyrsma44 with dissolve
    mc "Hm?"
    scene ctnyrsma54 with dissolve
    csp1 "I'm bored, let's go."
    scene ctnyrsma55 with dissolve
    csp2 "But they still haven't announced who won."
    scene ctnyrsma54 with dissolve
    csp1 "Ugh isn't that obvious..."
    scene ctnyrsma56 with dissolve
    pause
    scene ctnyrsma57 with dissolve
    mc "Hey."
    mc "You did good."
    mc "In every way."
    mc "Good job."
    csp1 "..."
    mc "Maybe we could have a little chat with you, you know..."
    scene ctnyrsma58 with dissolve
    mc "(Well hello titties)"
    csp1 "Save it dude, I don't want it anymore."
    csp1 "I got what I wanted, and that was the only thing that mattered to me."
    scene ctnyrsma59 with dissolve
    csp1 "I still got it."
    scene ctnyrsma60 with dissolve
    csp2 "Oh my god, what are you doing!"
    csp3 "He likes it"
    csp2 "This is very inappropriate."
    scene ctnyrsma61 with dissolve
    csp3 "Oh yeah"
    csp2 "Oh my!"
    scene ctnyrsma62 with dissolve
    csp1 "Silence girls, I'm trying to talk here."
    csp2 "But she!"
    csp1 "Silence!"
    scene ctnyrsma63 with dissolve
    csp3 "Hehe"
    csp3 "She said silence let's scream!"
    csp2 "You're so bad!"
    scene ctnyrsma64 with dissolve
    mc "(Such a nice show.)"
    scene ctnyrsma65 with dissolve
    csp1 "Stop fooling around, we're going."
    scene ctnyrsma66 with dissolve
    rb "Hey"
    scene ctnyrsma67 with dissolve
    rb "Oh my... what are they doing..."
    scene ctnyrsma68 with dissolve
    csp1 "Huh they're playing, what do you want?"
    scene ctnyrsma69 with dissolve
    rb "I just wanna thank you"
    csp1 "I don't accept thanks from strangers."
    scene ctnyrsma70 with dissolve
    rb "Oh..."
    rb "I thought we were friends..."
    csp1 "You thought wrong."
    scene ctnyrsma69 with dissolve
    rb "Well"
    rb "Thank you stranger."
    rb "I will never forget you."
    csp1 "We are going!"
    scene ctnyrsma26 with dissolve
    djg "It's time to announce the winner."
    djg "And the winner is!"
    stop music
    play music "audio/phoenix.mp3"
    scene evbtysnd1 with dissolve
    mc "Such a fun trip huh?"
    mc "I definitely needed something like this, thank you Ruby."
    mc "But it's time for us to go."
    mc "We're leaving early tomorrow, you pack your suitcase and I'll check out of the hotel."
    mc "Don't leave the room and don't let anyone in but me."
    rb "Yes [pD14]."
    mc "Good girl."
    rb "Yeah I'm a good girl..."
    if persistent.patch_installed == True:
        jump v05d
    else:
        jump v05e
label v05e:
    menu:
        "Visit Annie":
            scene lekmescn1 with dissolve
            csp2 "Oh it's you."
            csp2 "I'm sorry about your partner..."
            csp2 "She deserved to win."
            mc "Thanks, but what happened happened."
            mc "Can I come?"
            csp2 "Sure."
            scene lekmescn2 with dissolve
            mc "So you girls are staying together huh?"
            csp2 "Duh, we're like family."
            scene lekmescn3 with dissolve
            mc "Oh hey."
            csp3 "Why are you here?"
            mc "We're leaving tomorrow, I wanted to say goodbye to you."
            csp3 "How thoughtful."
            csp3 "Do you want me to come with you?"
            scene lekmescn4 with dissolve
            mc "That would be lovely."
            mc "Maybe some other time."
            scene lekmescn3 with dissolve
            csp3 "Maybe."
            mc "But I came for..."
            csp3 "Yeah yeah I know, she is on the balcony"
            menu:
                "Slap that ass!":
                    scene lekmescn4 with dissolve
                    pause
                    scene lekmescn5 with dissolve
                    pause
                    play sound "audio/Slap1.mp3"
                    scene lekmescn7 with vpunch
                    pause
                    scene lekmescn8 with dissolve
                    pause
                    scene lekmescn9 with dissolve
                    pause
                "Don't slap that ass!":
                    mc "(I want to do it, but somehow I'm not doing it.)"
            mc "Thanks."
            scene lekmescn10 with dissolve
            mc "Wow, this is the first time I've seen you without a costume."
            scene lekmescn11 with dissolve
            csp1 "So did you like it?"
            mc "Yes"
            scene lekmescn12 with dissolve
            csp1 "Why are you here?"
            mc "To say goodbye, and thank you."
            scene lekmescn13 with dissolve
            csp1 "You just said that, you even said the thank you part more than once."
            mc "Yeah, because you deserved it."
            csp1 "How noble you are."
            mc "So..."
            csp1 "..."
            mc "Okay, then I'm going."
            scene lekmescn12 with dissolve
            csp1 "You can stay a little longer if you want."
            mc "Then I will."
            mc "I have time, but not much."
            csp1 "I guessed that."
            scene lekmescn14 with dissolve
            mc "Yeah"
            mc "So are you okay?"
            scene lekmescn15 with dissolve
            csp1 "I don't know, I think I am."
            csp1 "I..."
            csp1 "I just don't like people like you."
            mc "Handsome, sexy, old but not that old, kinda sexy old?"
            scene lekmescn16 with dissolve
            csp1 "Yeah,the first time I saw you, I realized that I was going to like you too much, so I tried to make you hate me as much as possible."
            csp1 "However..."
            mc "I'm here and I care."
            mc "And I'm sexy old."
            csp1 "...."
            csp1 "Exactly."
            scene lekmescn17 with dissolve
            csp1 "Hate you."
            csp1 "You are the worst."
            scene lekmescn18 with dissolve
            csp1 "Why are you giving me these feelings before you leave, is this your move?"
            csp1 "Do you like to torture girls like me..."
            scene lekmescn19 with dissolve
            mc "Of course no."
            mc "But"
            mc "Well I don't know what to say."
            mc "You might be right."
            scene lekmescn20 with dissolve
            csp1 "Wow, I thought you'd say something to get me out of this shitty situation."
            mc "Hmmm"
            mc "I have an idea actually."
            mc "Hey, come closer."
            scene lekmescn21 with dissolve
            csp1 "Stop doing that!"
            scene lekmescn20 with dissolve
            csp1 "Don't give me orders."
            csp1 "....."
            csp1 "What is it?"
            menu:
                "Be a bad man":
                    scene lekmescn19 with dissolve
                    csp1 "Huh?"
                    mc "I'm gonna use you before I go."
                    scene lekmescn20 with dissolve
                    csp1 "What!"
                    mc "Yeah the best way to get rid of emotions."
                    mc "Gonna fuck you without feelings, just gonna use you."
                    scene lekmescn19 with dissolve
                    csp1 "You don't care about my feelings, you just want to use me like a sex doll!"
                    mc "Exactly."
                    csp1 "Pff I'm not stupid."
                    csp1 "Just snap out of it."
                    mc "Oh you think so?"
                    mc "Let me be more clear then."
                    scene lekmescn22 with dissolve
                    csp1 "....."
                    mc "No foreplay, no kissing, I won't even try to satisfy you, I'll just fuck your mouth."
                    mc "So, are you in fuck doll?"
                    scene lekmescn23 with dissolve
                    csp1 "I can't believe this is happening..."
                    mc "(I'm on the right track, she hates me. I have to push a little more.)"
                    mc "See my dick is already hard, just nod your head and I'll destroy you with this."
                    csp1 "...."
                    scene lekmescn23 with dissolve
                    csp1 "You know what? You are right, fucking cave man."
                    csp1 "Do whatever you want, if you really do what you say, I'm sure I'll hate you one hundred percent until I die!"
                    scene lekmescn23v2 with dissolve
                    mc "Don't mind if I do!"
                    scene lekmescn23v3 with dissolve
                    pause
                    scene lekmescn23v2 with dissolve
                    csp1 "Hey!"
                    csp1 "I didn't mean that!"
                    mc "What did you expect?"
                    mc "You said do whatever you want."
                    mc "And I want this, so?"
                    csp1 "..."
                    csp1 "I didn't expect this to happen."
                    mc "So what did you expect? Romance?"
                    csp1 "...."
                    csp1 "Fine do it!"
                    mc "Let's rock!"
                    scene lekmescn1a
                    mc "God damn!"
                    mc "You're taking really good."
                    mc "I thought you wouldn't even take half of me."
                    mc "Just relax."
                    mc "Almost done..."
                    mc "(I have to finish it soon I don't want to break her...)"
                    mc "Almost over get ready!"
                    scene lekmescn90 with dissolve
                    mc "Aggh!"
                    csp1 "Igh..."
                    scene lekmescn91 with dissolve
                    csp1 "It's awful I think I'm going to be sick."
                    scene lekmescn92 with dissolve
                    mc "Damn, that was nice."
                    mc "I just injected hate medicine in your throat."
                    mc "That should fix the problem."
                    csp1 "..."
                    csp1 "If you're done, you can leave."
                    mc "Thanks for the head."
                    mc "(Am I the best Romeo or what.)"
                    mc "(Don't feel bad [mc], you did it for a good cause)"
                "Take her":
                    scene lekmescn19 with dissolve
                    mc "You know what I think?"
                    csp1 "What?"
                    mc "I don't believe these feelings are real."
                    mc "I think you're acting, maybe you don't even realize what you're doing."
                    scene lekmescn20 with dissolve
                    csp1 "What is wrong with you..."
                    mc "That was my line."
                    mc "What is wrong with you?"
                    mc "No one can become like this in such a short time."
                    mc "The reason for what you're doing right now is a mixture of multiple negative emotions."
                    mc "Jealousy, ego, selfishness..."
                    mc "Well, considering that your opponent is Ruby, you're making the worst possible move by accepting to lose right away."
                    mc "Emotional exploitation."
                    scene lekmescn21 with dissolve
                    csp1 "Why are you saying this?"
                    mc "Because you don't keep people around to tell you the truth."
                    mc "I thought I'd fill that gap."
                    mc "Believe me, this is not love at all."
                    mc "You just want a piece of me."
                    mc "If I gave you a positive answer, you'd probably get bored with me after a few sex."
                    scene lekmescn22 with dissolve
                    mc "Let's speed up this progress, and you'll see that I'm right."
                    scene lekmescn23 with dissolve
                    csp1 "Really? Just like that?"
                    mc "Yup, just like that."
                    scene lekmescn24 with dissolve
                    csp1 "I don't think you are right."
                    mc "Of course you think that way, I just explained why you think that way?"
                    scene lekmescn25 with dissolve
                    csp1 "I'm..."
                    scene lekmescn26 with dissolve
                    pause
                    scene lekmescn27 with dissolve
                    csp1 "I'm special."
                    scene lekmescn28 with dissolve
                    mc "Aren't we all?"
                    scene lekmescn29 with dissolve
                    mc "You can't have everything you want."
                    csp1 "It's strange to hear this from someone who can get whatever he wants."
                    scene lekmescn30 with dissolve
                    mc "Well I have my ways for that."
                    mc "For example, I don't live in a world where I believe my own lies."
                    mc "When I want something, I really try to get it."
                    csp1 "Like me?"
                    scene lekmescn31 with dissolve
                    mc "Bingo."
                    csp1 "Why should I give you what you want, even though you've explained all this?"
                    scene lekmescn32 with dissolve
                    mc "Like I said, I have my ways."
                    scene lekmescn33 with dissolve
                    mc "Sometimes I have to make very detailed plans, sometimes plans that take too long."
                    scene lekmescn34 with dissolve
                    mc "Sometimes I have to act very bravely."
                    scene lekmescn35 with dissolve
                    csp1 "So which one are you using on me?"
                    mc "You should be feeling the pressure in your ass right now."
                    scene lekmescn39 with dissolve
                    csp1 "Hah, did you think I'd just let you?"
                    scene lekmescn40 with dissolve
                    csp1 "Why should I give myself up to you?"
                    csp1 "We're both trying to get what we want."
                    csp1 "Why would I give you something without taking something from you?"
                    scene lekmescn41 with dissolve
                    csp1 "Stop poking with your dick..."
                    mc "Make me."
                    mc "Oh right you can't, look at the difference between us, if I don't let you, you can't leave here."
                    csp1 "......"
                    scene lekmescn42 with dissolve
                    mc "But I'm letting you, do you know why?"
                    mc "Because I can."
                    scene lekmescn43 with dissolve
                    csp1 "You made your point."
                    csp1 "What's next?"
                    scene lekmescn44 with dissolve
                    mc "You'll obey me."
                    mc "Not just because I'm huge and you're small."
                    mc "You're gonna obey my words."
                    scene lekmescn45 with dissolve
                    csp1 "I..."
                    csp1 "I will obey."
                    scene lekmescn46 with dissolve
                    mc "See, simple as that."
                    mc "At least you're rational."
                    scene lekmescn47 with dissolve
                    mc "I don't like that look."
                    scene lekmescn48 with dissolve
                    csp1 "It's hard for me to accept this."
                    scene lekmescn49 with dissolve
                    csp1 "But yeah I can't win against you."
                    scene lekmescn50 with dissolve
                    mc "I know."
                    mc "Your eyes already know it."
                    scene lekmescn51 with dissolve
                    pause
                    scene lekmescn52 with dissolve
                    mc "Well I didn't have to command you, you just grabbed it."
                    mc "Like breathing."
                    mc "Do what you have to do."
                    mc "Well if your handshake is over, you can get to work."
                    scene lekmescn2a
                    pause
                    scene lekmescn53 with dissolve
                    mc "My dick is very dry, don't you think?"
                    scene lekmescn54 with dissolve
                    mc "Yeah nice and easy."
                    scene lekmescn55 with dissolve
                    csp1 "It looks big."
                    mc "It is."
                    scene lekmescn56 with dissolve
                    csp1 "Are you going to grab my head or not?"
                    mc "Not yet, you grab it and..."
                    mc "Well do your thing, I wanna see first."
                    scene lekmescn57 with dissolve
                    mc "Hah better than I expected"
                    mc "Keep going, i still can't decide when to take control."
                    scene lekmescn58 with dissolve
                    pause
                    scene lekmescn59 with dissolve
                    mc "Come on, your breath can't wet my dick, it's still dry, do something about it."
                    scene lekmescn60 with dissolve
                    mc "Finally, a progress, keep going."
                    scene lekmescn61 with dissolve
                    pause
                    scene lekmescn62 with dissolve
                    mc "Don't forget to lick the tip."
                    scene lekmescn63 with dissolve
                    pause
                    scene lekmescn3a
                    mc "Good good, you're taking really good."
                    scene lekmesc3v2
                    mc "Good girl"
                    mc "Okay it's time to take control"
                    scene lekmescn4a
                    pause
                    scene lekmescn64 with dissolve
                    mc "Okay, that's enough, need a little cooldown."
                    mc "Look at that face, this is the 'I did a good job' face."
                    mc "Okay, it's time for real action."
                    scene lekmescn65 with dissolve
                    mc "That's what I'm talking about."
                    mc "Keep going."
                    scene lekmescn66 with dissolve
                    csp1 "I'm ready for you."
                    csp1 "Sir."
                    scene lekmescn67 with dissolve
                    pause
                    scene lekmescn68 with dissolve
                    csp1 "Is this okay sir?"
                    scene lekmescn69 with dissolve
                    mc "Sir huh?"
                    mc "I usually prefer daddy, but sir is good too."
                    scene lekmescn70 with dissolve
                    csp1 "I'm ready for you daddy."
                    mc "Such a good girl."
                    scene lekmescn71 with dissolve
                    pause
                    scene lekmescn72 with dissolve
                    mc "Let's get rid of these."
                    scene lekmescn73 with dissolve
                    pause
                    scene lekmescn74 with dissolve
                    pause
                    scene lekmescn75 with dissolve
                    mc "Nice bum."
                    scene lekmescn76 with dissolve
                    mc "Let's see"
                    scene lekmescn77 with dissolve
                    mc "Oh, so wet."
                    mc "Seems like you are enjoying too much so far."
                    scene lekmescn78 with dissolve
                    csp1 "Yes daddy."
                    scene lekmescn79 with dissolve
                    mc "Tight"
                    mc "Nice"
                    scene lekmescn80 with dissolve
                    mc "Do you like to be teased?"
                    scene lekmescn81 with dissolve
                    csp1 "Yes daddy."
                    scene lekmescn82 with dissolve
                    mc "Of course you do."
                    scene lekmescn83 with dissolve
                    mc "How are you feeling now?"
                    csp1 "Excited and scared."
                    mc "Good"
                    mc "These are the best combination for the moment."
                    mc "Do you know when I will penetrate you?"
                    scene lekmescn81 with dissolve
                    csp1 "No I don't know, when?"
                    mc "Not so soon."
                    csp1 "Oh okay daddy, I can wait."
                    scene lekmescn84 with dissolve
                    mc "I lied!"
                    scene lekmescn85 with dissolve
                    csp1 "Aggh!"
                    mc "So tight!"
                    mc "It's awesome!"
                    scene lekmescn5a
                    mc "Still hurts?"
                    csp1 "No..."
                    csp1 "Not that much..."
                    scene lekmescn6a
                    mc "I didn't expect you to be this tight."
                    mc "I'm about to cum."
                    csp1 "Mhm hmm..."
                    mc "Almost!"
                    scene lekmescn85 with dissolve
                    mc "Yess!!"
                    csp1 "Aaah!!"
                    scene lekmescn86 with dissolve
                    mc "Damn"
                    mc "Phew"
                    mc "That was pretty intense."
                    mc "Hey are you okay?"
                    csp1 "Yeah"
                    csp1 "I guess so."
                    scene lekmescn87 with dissolve
                    csp1 "I have no idea how it got here..."
                    mc "You actually do, but give it time."
                    csp1 "I feel very tired and my throat and pussy are a little sore..."
                    mc "Yeah shits happen."
                    scene lekmescn88 with dissolve
                    csp1 "Thank god, girls are sleeping."
                    mc "Uh huh"
                    scene lekmescn89 with dissolve
                    csp1 "So, you took what you wanted..."
                    csp1 "I also got what I wanted, albeit indirectly."
                    csp1 "..."
                    mc "Yes, it's time to get back to our lives."
                    mc "Well, that was really fun, maybe one day our paths will cross and we'll do it again who knows."
                    csp1 "Yeah maybe."
                    csp1 "Well, goodbye then."
                    mc "Bye."
                "Just leave":
                    scene lekmescn14 with dissolve
                    mc "I think i should leave"
                    csp1 "Yeah me too"
                    mc "Have nice day and thank you again"
                    csp1 "You really like to thank huh."
                    mc "And here is the bitch again"


    scene evbtysnd2 with dissolve
    mc "I'm back princess"
    mc "Ruby?"
    rb "Welcome, [pD14]."
    mc "What is this attitude?"
    scene evbtysnd3 with dissolve
    rb "Nothing."
    rb "I've packed everything."
    rb "*Hick"
    scene evbtysnd4 with dissolve
    mc "Did you drink that champagne?"
    rb "I don't know what you're talking about, [pD14]."
    mc "....."
    mc "Oh no you really didn't..."
    mc "Well it's not a big deal anyway."
    mc "Sooner or later this was going to happen anyway."
    mc "You could have experienced it at a ridiculous stupid teen party..."
    scene evbtysnd5 with dissolve
    mc "Ruby?"
    mc "Why are you sad, honey, we had a really fun trip together, isn't that what you wanted?"
    rb "Of course I'm so happy."
    mc "I accept every lie you tell as if it were the truth without question, but that doesn't include the lie that you're happy when you're unhappy."
    mc "I just can't accept this."
    scene evbtysnd6 with dissolve
    rb "....."
    mc "Look, I know you wanted to win the contest, but life is not fair sometimes."
    mc "For me, you are the winner, of course, that's the main thing, isn't it?"
    scene evbtysnd7 with dissolve
    rb "I saw your face when she came on the stage, [pD14]."
    rb "You are lying."
    scene evbtysnd5 with dissolve
    mc "I..."
    mc "It's not like that."
    mc "Yes i reacted to her but not because i..."
    mc "Fuck how can I explain this..."
    scene evbtysnd8 with dissolve
    rb "No need, [pD14], you didn't do anything wrong, I'm not mad at you just because you're attracted to that girl."
    rb "I'm just mad at myself."
    mc "Are you angry with yourself, but why?"
    rb "Because I don't know what I'm supposed to do."
    rb "No matter how much I think about it, I can't understand why you're looking at her like that."
    rb "I need to understand because I want to do the same thing and I want you to look at me like that."
    rb "I..."
    rb "I've never felt so helpless before."
    scene evbtysnd5 with dissolve
    mc "Stop it."
    mc "You're better than her in every way because I love you, not her."
    mc "I just looked at her because it's a man thing."
    mc "I mean..."
    mc "Fuck I don't know how to explain this!"
    rb "You said the f word twice."
    mc "Yes I did and I'll say it again FUCK!"
    mc "I fucking love you Ruby."
    mc "I can die for you, I can kill for you."
    mc "You are my precious thing and she, she..."
    mc "She's just..."
    if persistent.patch_installed == True:
        jump v05f
    else:
        jump v05g
label v05g:
    scene black
    $config.allow_skipping = False
    "End of v0.5. Don't forget to save the game."
    "Thanks for playing!"
    #end of the update
    return
