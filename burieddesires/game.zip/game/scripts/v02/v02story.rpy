default v02McNotToday = False
default v02McLiedAmy = False
default v02McRubyYou = False
define config.load_failed_label = "v02begin"
label v02begin:
    if persistent.patch_installed == False:
        $pD8 = str(mcName)
        $pD11 = str(mcName)
        $pD13 = str(mcName)
        $pD14 = str(mcName)
        $pD16 = str(mcName)
        $pD22 = str(mcName)
        $pD43 = str(mcName)
    else:
        jump v02beginpatched
    $config.allow_skipping = True
    scene lnw1 with fade
    pause
    mc "What.."
    scene lnw2 with fade
    pause
    mc "Nora!"
    scene lnw3 with fade
    pause
    ln "[pD14] are you okay?"
    mc "Huh what the hell is going on?"
    scene lnw4 with fade
    pause
    ln "I'm so sorry [pD14] I hit you and you passed out."
    scene lnw5 with fade
    pause
    mc "Yeah I know that{w}, how I got back here?"
    ln "You've never left here, you've been unconscious for a few hours."
    mc "...."
    mc "Fuck"
    scene lnw6 with fade
    pause
    ln "Haa haa you said fuck"
    menu:
        "Shut up Luna!":
            scene lnw10 with fade
            pause
            mc "Ugh just shut up.. my fucking head!"
            ln "Mean."
            mc "Look who's talking."
            ln "Sorry about that"
        "How long have I been out?":
            scene lnw8 with fade
            pause
            ln "Hmmm, I think 4 hours"
            mc "Can't believe this..."
            scene lnw9 with fade
            pause
            ln "What can't you believe?"
            mc "Nothing."
    scene lnw19 with fade
    pause
    mc "Why did you hit me!"
    ln "You're not gonna believe why."
    scene lnw20 with fade
    pause
    mc "I don't believe it already, yes"
    scene lnw21 with fade
    pause
    ln "Then I don't need to tell you."
    mc "Tell now"
    scene lnw22 with fade
    pause
    ln "It's a long story"
    menu:
        "Not this again!":
            scene lnw16 with fade
            pause
            mc "Tell me right now!"
            ln "Gee [pD14] what is wrong with you..."
            scene lnw18 with fade
            pause
            mc "What is wrong with me?"
            mc "You hit me with a baseball bat as hard as you could. "
            mc "in the head!"
            scene lnw19 with fade
            pause
            ln "I'm so sorry about that"
            mc "You will be."
            scene lnw20 with fade
            pause
            ln "What does this mean?"
            mc "You'll understand when I take you home"
            scene lnw22 with fade
            pause
            ln "Come on, listen first."
            mc "Speak"
            mc "Now!"
        "Just tell me what is going on":
            scene lnw16 with fade
            pause
            mc "I don't care what the reason is,{w} just tell the truth"
            mc "Why did you do that Luna?"
            scene lnw19 with fade
            pause
            ln "First you have to promise not to tell [pD41]."
            mc "Sure promise"
    scene lnw23 with fade
    pause
    ln "I have a stalker"
    mc "What stalker means?"
    scene lnw24 with fade
    pause
    ln "Someone's obsessed with me, he's always after me."
    mc "Is he trying to hurt you?"
    scene lnw25 with fade
    pause
    ln "No, he just thinks he's in love with me."
    scene lnw26 with fade
    pause
    ln "Anyway, I thought you were him."
    mc "How..."
    scene lnw27 with fade
    pause
    ln "He kinda dress like you.."
    mc "At least he had taste."
    scene lnw28 with fade
    pause
    ln "More like the taste of the last century"
    mc "What was that?"
    scene lnw27 with fade
    pause
    ln "Nothing"
    mc "So he looks like me?"
    ln "Yeah pretty much"
    scene lnw28 with fade
    pause
    mc "Is he harassing you?"
    ln "Well..{w} kinda"
    mc "Okay"
    ln "Okay what?"
    mc "Gonna find him and beat him"
    mc "Until I'm sure he'll stay away from you"
    ln "You don't need to do that"
    mc "Why?"
    ln "Well.. we knocked you out ourselves."
    mc "Oh yeah, I remember those girls now."
    mc "Are they ur crew?"
    ln "Crew?"
    mc "Yeah like a gang"
    scene lnw20 with fade
    pause
    ln "No..."
    ln "We're just close friends"
    mc "Okay that's good"
    scene lnw19 with fade
    pause
    ln "They thought you were that idiot because he looked so much like you, you were standing with your back turned, and I shot you."
    mc "Hmmm"
    scene lnw26 with fade
    pause
    mc "Okay, I believe you."
    ln "Thanks.. I guess"
    mc "Let's find this fucker"
    scene lnw9 with fade
    pause
    ln "Haaa haa you said fucker again"
    scene lnw11 with fade
    pause
    pg3 "Oh, he's awake."
    mc "Yeah.. no thanks to you"
    scene lnw12 with fade
    pause
    pg3 "Pffft, I told Luna"
    pg3 "He can sleep a little on my lap."
    scene lnw13 with fade
    pause
    pg3 "She didn't accept."
    mc "That's cute"
    scene lnw15 with fade
    pause
    ln "Ummm, I feel guilty.."
    pg3 "Yes, of course.{w} Just because of guilt"
    mc "Huh?"
    ln "Nothing"
    ln "How is your head?"
    mc "I'm fine."
    scene lnw14 with fade
    pause
    pg3 "You look really fine"
    scene lnw15 with fade
    pause
    ln "Dude just leave us."
    ln "Also where are they?"
    scene lnw30 with fade
    pause
    pg3 "They left a few minutes ago."
    ln "Withouth even telling?"
    scene lnw31 with fade
    pause
    pg3 "You fell asleep, and they didn't want to bother You."
    ln "Cool"
    scene lnw32 with fade
    pause
    pg3 "Okay then I'm going home too"
    mc "Wait, I'll give you a ride."
    scene lnw33 with fade
    pause
    pg3 "Nah man I'm cool, this truck is mine"
    mc "Do you have a driver's license?"
    scene lnw34 with fade
    pause
    pg3 "What's that?"
    pg3 "Kidding, no, but that's not a problem so far."
    mc "Teenagers..."
    scene lnw36 with fade
    pause
    pg3 "Old mans..."
    ln "Hah she got you"
    mc "Nope"
    scene lnw35 with fade
    pause
    mc "Time got me, she just stated that"
    mc "Huge difference"
    scene lnw36 with fade
    pause
    pg3 "Wise and old, nice"
    scene lnw35 with fade
    pause
    ln "Okay she got you now"
    mc "Yeah she did"
    scene lnw36 with fade
    pause
    pg3 "Okay then see you soon"
    pg3 "I hope..."
    scene lnw37 with fade
    pause
    ln "So"
    ln "Are you gonna tell [pD42]?"
    scene lnw38 with fade
    pause
    menu:
        "Should I tell?":
            $persistent.gal13 = True
            mc "[pD40] is a lot more reasonable than you think."
            mc "He could have solved such a problem very easily without embarrassing you"
            ln "How?"
            mc "By asking for my help"
            ln "Has she asked you for help before?"
            menu:
                "Lie":
                    mc "Nope."
                    scene lnw46 with fade
                    pause
                    ln "I think that's a lie"
                    mc "Then don't think."
                    ln "This doesn't make any sense"
                    mc "Cuz you hit me with a baseball!"
                    scene lnw41 with fade
                    pause
                    ln "I'm so sorry about that [pD14]"
                    ln "I promise I'll make it up"
                    scene lnw44 with fade
                    pause
                    mc "You don't look sorry"
                    mc "And how?"
                    scene lnw42 with fade
                    pause
                    ln "I can kiss your head"
                    mc "And how will that help me?"
                    scene lnw41 with fade
                    pause
                    ln "I have magic lips"
                    mc "Okay..."
                    scene lnw44 with fade
                    pause
                    ln "I'll do whatever you want to make up for it"
                    mc "Hmm"
                    mc "I'll think about that."
                    ln "Should I be afraid?"
                    mc "You just promised the guy you hit with the baseball bat, should you?"
                    ln "Well, fuck"
                    mc "Nope, you are not allowed to swear in front of me"
                    scene lnw45 with fade
                    pause
                    ln "Oh c'mon! still?"
                    mc "Yeah still!"
                    scene lnw40 with fade
                    pause
                    ln "Sorry"
                    $v02McLiedAmy = True
                "Truth":
                    $persistent.gal14 = True
                    mc "Yeah, she asked me before."
                    scene lnw46 with fade
                    pause
                    ln "When?"
                    mc "We had dinner the other day, the one you didn't come to."
                    scene lnw40 with fade
                    pause
                    ln "Oh yeah I was so busy that day"
                    mc "Oh yeah, what were you doing?"
                    ln "Hiding from stalker?"
                    mc "Seriously?"
                    scene lnw44 with fade
                    pause
                    ln "I just..."
                    ln "I didn't want to come."
                    mc "Why?"
                    ln "Dunno"
                    ln "Anyway, what did [pD42] want from you?"
                    mc "She said that you always came home late, that you were always out, and that she is uncomfortable with it"
                    scene lnw46 with fade
                    pause
                    ln "Damn [pD42].."
                    mc "Hey!"
                    ln "Sorry sorry, she is your [pD7] after all "
    play sound "audio/ringtone-sound-effect.mp3"
    scene lnw47 with fade
    pause
    mc "Wait, the phone's ringing."
    scene lnw48 with fade
    pause
    ln "You didn't have to say Wait [pD14]"
    scene lnw49 with fade
    pause
    mc "Hey"
    mc "Sorry honey, something came up."
    mc "I'll tell you when I get home"
    mc "Nothing serious. Everything's fine."
    mc "I'll be home soon"
    mc "Kiss the girls for me"
    scene lnw50 with fade
    pause
    mc "Let's go, Luna."
    ln "Aye aye [pD14]"
    # A while later
    scene lnw51 with fade
    pause
    ln "My favorite pile of concrete yaay"
    mc "You're right."
    scene lnw52 with fade
    pause
    ln "Let's go then"
    scene lnw53 with fade
    pause
    ln "Aggh I ache all over my body"
    mc "I'm not surprised"
    play sound "audio/knock.mp3"
    scene lnw54 with fade
    pause
    ln "Liftoff will start in t minus 3 seconds"
    mc "What?"
    ln "3"
    mc "What are you doing, Luna?"
    ln "2"
    ln "Just wait"
    $ renpy.movie_cutscene("animation/v002/rubydoor.webm")
    scene lnw55 with fade
    pause
    ln "1"
    ln "Bam!"
    scene lnw57 with fade
    pause
    rb "[pD43]!"
    scene lnw58 with fade
    pause
    ln "Eagle has landed"
    scene lnw59 with fade
    pause
    ln "Ugh grow up Ruby"
    scene lnw60 with fade
    pause
    rb "No I'm not gonna!"
    scene lnw61 with fade
    pause
    rb "Right [pD14]?"
    menu:
        "Tease":
            scene lnw60 with fade
            pause
            mc "I agree, because the older you get, the heavier you get."
            mc "Maybe when you grow up, you'll stop jumping on me..."
            scene lnw62 with fade
            pause
            rb "Huh no chance!"
            mc "Yeah well, that's what I thought..."
        "Direct":
            mc "Well, growing up is part of life"
            mc "Because"
            scene lnw63 with fade
            pause
            rb "No no no!"
            mc "What?"
            scene lnw64 with fade
            pause
            rb "This grow up talk{w}, I don't want it"
            mc "Yeah, she'll probably never grow up."
            rb "So right!"
    rb "Oh by the way"
    scene lnw65 with fade
    pause
    rb "Luna, I miss you so much!"
    scene lnw66 with fade
    pause
    ln "Hah, I haven't missed you."
    scene lnw67 with fade
    pause
    rb "Liar, buuuuuuuuuuuuuuh"
    scene lnw66 with fade
    pause
    ln "Ugh kids.."
    mc "......"
    scene lnw68 with fade
    pause
    ln "Say it"
    mc "Nope"
    scene lnw69 with fade
    pause
    mc "Ruby"
    scene lnw60 with fade
    pause
    rb "Yes [pD14]"
    mc "Where is [pD44]"
    scene lnw71 with fade
    pause
    rb "You mean [pD41]."
    mc "Yes."
    scene lnw70 with fade
    pause
    rb "I think she's in the shower"
    scene lnw72 with fade
    pause
    ln "Later weirdos I'm going to my room"
    mc "You're welcome"
    ln "Hah sure"
    scene lnw75 with fade
    pause
    rb "Actually, she loves you very much."
    mc "Yeah, I knew it."
    scene lnw73 with fade
    pause
    rb "......"
    mc "What?"
    scene lnw74 with fade
    pause
    rb "I love you more"
    mc "Also know it"
    scene lnw76 with fade
    pause
    rb "How about you?"
    mc "Of course I love you to honey"
    rb "More than luna?"
    mc "Yeah of course"
    scene lnw78 with fade
    pause
    rb "What about [pD41]"
    mc "Yes honey you're my favorite in this house."
    rb "But outside this house?"
    mc "Still you are the one honey"
    scene lnw76 with fade
    pause
    rb "Hmmm"
    mc "This isn't over right..."
    rb "Ehehe"
    mc "Oh boy.."
    scene lnw78 with fade
    pause
    rb "How about Janet"
    mc "Still you are the one baby"
    scene lnw75 with fade
    pause
    rb "And [pD45]?"
    menu:
        "You":
            scene lnw78 with fade
            pause
            mc "Nope still you"
            mc "Now you believe me?"
            scene lnw79 with fade
            pause
            rb "No"
            mc "Okay, what do I have to do to make you believe?"
            rb "Kiss me"
            mc "Uhm..."
            rb "In my forehead"
            mc "Sure"
            scene lnw77 with fade
            pause
            rb "[pD46] [pD14].."
            mc "....."
            scene lnw78 with fade
            pause
            rb "Ehehe"
            $v02McRubyYou = True
        "I love you equally":
            scene lnw73 with fade
            pause
            mc "Don't be angry about it, but how can I love one of you more than the other?.."
            scene lnw74 with fade
            pause
            rb "You love me more than [pD41] and [pD47], but"
            mc "Yeah but.."
            rb "But what?"
            mc "You know what?{w} I agree with you, you shouldn't grow up."
            mc "As you grew older, you started pushing me"
            scene lnw75 with fade
            pause
            rb "Hmmm, now I feel like growing up"
            mc "Hah I wonder why I'm not surprised."
    mc "Anyway, I'll check on [pD40]."
    scene lnw80 with fade
    pause
    rb "Haahaa"
    mc "Smartass"
    scene lnw81 with fade
    menu:
        "Peek Luna":
            scene lnw82 with fade
            pause
            "Hmm"
            scene lnw83 with fade
            pause
            "Such a pain in the ass.."
            "A cute one.."
            scene lnw84 with fade
            pause
            scene lnw85 with fade
            pause
            scene lnw86 with fade
            pause
            scene lnw87 with fade
            pause
            scene lnw88 with fade
            pause
            ss "Boh"
            scene lnw89 with fade
            pause
            mc "Very scary [pD23]"
            ss "What are you doing?"
            scene lnw90 with fade
            pause
            menu:
                "What do I look like doing??":
                    mc "You tell me"
                    ss "Do you want me to be honest?"
                    mc "Nope"
                    ss "Hah, funny"
                "Checking Luna":
                    scene lnw91 with fade
                    pause
                    ss "Uh huh.."
                    ss "A long check, I think"
                    mc "Yeah, even now, I'm not sure about her safety, she's so dangerous"
                    scene lnw92 with fade
                    pause
                    ss "Ahah yeah [pD22] so true.."
                    scene lnw93 with fade
                    pause
                    ss "What do we do with her.."
                    mc "Well, the answer to your question is simple."
                    mc "We'll always protect her, do we have a choice?"
        "Go to Amy":
            $persistent.gal16 = True
            scene lnw214 with fade
            pause
            mc "Amy?"
            mc "Are you there? "
            mc "I guess she doesn't hear."
            scene lnw215 with fade
            menu:
                "Peek":
                    mc "Hello [pD48]..."
                    scene lnw216 with fade
                    pause
                    mc "Damn"
                    scene lnw217 with fade
                    pause
                    mc "She's still amazing.."
                    scene lnw218 with fade
                    pause
                    scene lnw219 with fade
                    pause
                    ss "Are you enjoying [pD11]"
                    mc "How long have you known?"
                    scene lnw220 with fade
                    pause
                    ss "from the moment you say 'Are you there'"
                    mc "Heh"
                    scene lnw221 with fade
                    pause
                    ss "So, how was your day?"
                    mc "We can talk about it in a more appropriate.."
                    ss "Uh huh"
                    ss "So..."
                    ss "Wanna join me?"
                    mc "Want me to join you [pD23]?"
                    ss "I don't know, do I?"
                    menu:
                        "Don't":
                            mc "Nah, it's been a hard day, I'll wait for you in the kitchen."
                            scene lnw222 with fade
                            pause
                            ss "Downer.."
                            mc "Sure [pD23]"
                            jump v02AmyKitchen
                        "Join":
                            scene lnw220 with fade
                            pause
                            mc "Why the hell not"
                            scene lnw230 with fade
                            pause
                            ss "That's the spirit"
                            ss "But no funny business"
                            menu:
                                "Agree":
                                    mc "Sure whatever you say"
                                    ss "..."
                                    mc "So.."
                                    ss "So.."
                                    scene lnw231 with fade
                                    pause
                                    mc "Just like old times huh?"
                                    ss "Like very old times"
                                    scene lnw232 with fade
                                    pause
                                    ss "How old were we the last time we did this?"
                                    mc "Can't remember.."
                                    ss "Oh fuck off"
                                    mc "What?"
                                    ss "You had to engrave every form of this body in your mind."
                                    mc "I already had."
                                    ss "Liar.."
                                    mc "This feels good"
                                    ss "Which, water or my skin?"
                                    mc "Both"
                                    ss "I know right"
                                    menu:
                                        "Make a move":
                                            scene lnw233 with fade
                                            pause
                                            ss "Behave.."
                                            mc "I'm.."
                                            ss "[mc]..."
                                            mc "Okay okay.."
                                            scene lnw234 with fade
                                            pause
                                            ss "So how is Janet?"
                                            mc "You're not gonna believe this"
                                            mc "Janet's starting to change."
                                            ss "How?"
                                            mc "In bedroom"
                                            scene lnw236 with fade
                                            pause
                                            ss "Awww old timers don't wanna sex anymore ahaha"
                                            mc "The exact opposite"
                                            mc "She became a little freaky"
                                            ss "Oh it's exciting, tell me more"
                                            mc "We've been having casual sex [pD49], and I think she's tired of it."
                                            ss "No way, tell me more!"
                                            mc "She wants to try everything, but step by step"
                                            ss "What you tried so far?"
                                            mc "Footjob"
                                            scene lnw238 with fade
                                            pause
                                            ss "Waow.."
                                            scene lnw234 with fade
                                            pause
                                            ss "Could you have chosen this because my feet are touching your skin right now?"
                                            mc "Hmmm, nice catch"
                                            ss "How was she by the way?"
                                            mc "Surprisingly good, no doubt she learned it from the internet."
                                            scene lnw237 with fade
                                            pause
                                            ss "I hope she learned it from internet.."
                                            mc "[pD23]..."
                                            ss "Kiddin.."
                                            ss "Did you like it?"
                                            mc "Yeah really liked it.."
                                            ss "Mhmmm"
                                            ss "Let's compare then.."
                                            scene lnw235 with fade
                                            pause
                                            mc "Finally.."
                                            ss "Asshole, you've manipulated me."
                                            mc "Did I..."
                                            scene lnw236 with fade
                                            pause
                                            ss "Tell me [mc], whose feet are softer, me or your wife?"
                                            scene amymcgjbthrm
                                            menu:
                                                "Your":
                                                    mc "Definitely yours"
                                                    ss "That's more like it"
                                                "Janet's":
                                                    mc "Hmmm"
                                                    scene lnw237 with fade
                                                    pause
                                                    ss "I don't like it so far.."
                                                    mc "Sorry [pD23] but Janet's feet are much more softer then yours.."
                                                    ss "Oh how nice, then go to her"
                                                    mc "Oh c'mon!"
                                            scene lnw235 with fade
                                            pause
                                            mc "I have to ask, does it give you pleasure to do this?"
                                            ss "Physically very little, but seeing the pleasure I give the man.."
                                            mc "Hmmm I didn't get it at all."
                                            ss "That because you're a man."
                                            mc "Doesn't matter right now"
                                            ss "Yeah I can feel it"
                                            mc "I think.."
                                            ss "I know"
                                            scene lnw239 with fade
                                            pause
                                            mc "Igghhh fuck.."
                                            ss "How was it?"
                                            mc "Fucking amazing"
                                            ss "Well you deserve this"
                                            mc "I think I deserve more"
                                            scene lnw240 with fade
                                            pause
                                            ss "Don't be so greedy [pD22]"
                                            mc "Yeah."
                                            scene lnw241 with fade
                                            pause
                                            ss "I'll put some clothes on."
                                            scene lnw242 with fade
                                            pause
                                            ss "We'll keep talking while we have a drink in the kitchen."
                                            mc "All right, I'll wait in the kitchen."
                                        "Don't":
                                            mc "Okay then that's refreshing. Thanks for inviting me [pD23]"
                                            ss "It's okay, and thank you for being good."
                                            mc "If I wasn't exhausted.."
                                            ss "I know."
                                            jump v02AmyKitchen
                                "Don't agree":
                                    scene lnw242 with fade
                                    pause
                                    ss "Aww how sad"
                                    ss "Anyway, wait in the kitchen, and I'll put some clothes on."
                                    mc "Sure."
                                    jump v02AmyKitchen
                        "Don't join but stay":
                            mc "I have something else in mind"
                            scene lnw223 with fade
                            pause
                            ss "Behave..."
                            mc "Can't after see that, I mean those.. I mean you..."
                            ss "Well.."
                            ss "What the hell, you fucking deserve this"
                            mc "What exactly I deserve"
                            scene lnw224 with fade
                            pause
                            ss "This hands.."
                            mc "Fine by me"
                            ss "Hah you want me to give you head right"
                            mc "Yeah"
                            scene lnw225 with fade
                            pause
                            ss "So bold, yet so naive..."
                            mc "Oh fuck off."
                            ss "Just give that cock before I change my mind [pD22]"
                            ss "Damn I miss this.."
                            mc "I'm sure you miss the taste."
                            ss "Nope"
                            mc "This is an insult!"
                            ss "No it's not"
                            ss "So how is that feel"
                            mc "Fucking amazing"
                            ss "You are so easy to please [pD22]..."
                            mc "...."
                            scene lnw226 with fade
                            pause
                            ss "Stop holding you back man..."
                            mc "Can you blame me?"
                            ss "I know what you're trying to do"
                            mc "What am I trying to do?"
                            ss "You're trying to delay ejaculation and get me to give you a blowjob"
                            mc "And do I succeed?"
                            ss "Nope."
                            mc "Well I had to try"
                            mc "Anyway here I come"
                            ss "Cum whenever you want, I'm already in tub"
                            mc "Finally some good fucking news"
                            scene lnw227 with fade
                            pause
                            mc "Iggghhh take it [pD23]!"
                            ss "Oh.."
                            scene lnw228 with fade
                            pause
                            ss "I miss that feeling"
                            scene lnw229 with fade
                            pause
                            ss "So warm in my face.."
                            mc "I wish you'd said that before I cum..."
                            ss "Hah you're right"
                            mc "Well next time.."
                            ss "Ahaha sure [pD22]"
                "Go wait in kitchen":
                    $v02McNotToday = True
                    jump v02AmyKitchen
    scene lnw94 with fade
    pause
    ss "Thank you so much."
    scene lnw95 with fade
    pause
    mc "For what?"
    scene lnw96 with fade
    pause
    ss "For this"
    scene lnw97 with fade
    pause
    mc "She is [pD50]"
    scene lnw98 with fade
    pause
    ss "You are amazing."
    mc "Am I?"
    scene lnw99 with fade
    pause
    ss "Yeah absolutely"
    scene lnw100 with fade
    pause
    mc "You're the amazing one."
    mc "Being Luna's [pD32] could be the hardest job in the world"
    mc "especially as a [pD51]."
    scene lnw101 with fade
    pause
    ss "Said Emma's [pD4]"
    mc "Ahah yeah.."
    ss "Will you stay today?"
    menu:
        "No":
            scene lnw102 with fade
            pause
            mc "I'm sure they're worried about me, I feel like I haven't been home in a very long time"
            ss "Spending a few hours with Luna can make you feel that."
            mc "Tell me about it "
        "Maybe":
            scene lnw103 with fade
            pause
            ss "Hmm, I wonder what's keeping you in suspense?"
            mc "Who knows.."
            ss "I do, and you do too, clearly"
            mc "But"
            ss "There is always a but"
            mc "Yeah."
    scene lnw101 with fade
    pause
    ss "Do you want a drink or do we continue our conversation here?"
    menu:
        "Here is good":
            scene lnw102 with fade
            pause
            ss "I bet"
            scene lnw103 with fade
            pause
            ss "You like places with a nice view."
            mc ".."
            ss "It reminds me of the past"
            ss "When you were little, you liked to hang out on the door sills."
            ss "You'd even like some certain door sills better"
            mc "And every time you saw me, you loved to accompany me."
            ss "These are the only good memories from there"
            mc "Same"
            ss "Tell me [pD22], do you feel the past?"
            menu:
                "Not today":
                    scene lnw100 with fade
                    pause
                    mc "I had a weird nightmare.."
                    mc "So.."
                    scene lnw99 with fade
                    pause
                    ss "I get it [pD22] it's ok"
                    mc "Thanks [pD23]"
                    ss "So wanna grab a drink or you'll leave?"
                    mc "I should get going"
                    mc "There are 4 girls at home ready to tear me apart"
                    ss "Lucky them."
                    mc "Hah"
                    ss "Talk to Ruby before you go."
                    ss "She refused to eat because you left without telling her last time"
                    mc "God damn she's so cute"
                    ss "After all, she's my [pD55]."
                    $v02McNotToday = True
                    jump v02RubyL
        "Let's talk in kitchen":
            $v02McNotToday = True
            jump v02AmyKitchen
label v02AmyKitchen:
    scene lnw90 with fade
    pause
    mc "I want to drink something."
    ss "Yup"
    ss "Go to the kitchen and I'll get some clothes."
    mc "Sure [pD23]"
    ss "Don't be naughty in the kitchen by the way"
    mc "Oh c'mon.."
    mc "It was just a one time thing"
    ss "Uh huh.."
    scene lnw150 with fade
    pause
    scene lnw151 with fade
    pause
    mc "Here you are"
    ss "Did you wait long?"
    mc "Nah, I'm used to"
    ss "What a gentleman"
    mc "Why did you dress like a child by the way"
    ss "Ha ha"
    ss "Coffee, beer or juice?"
    menu:
        "Beer":
            $persistent.gal17 = True
            mc "You know what I want"
            ss "I know..."
            scene lnw152 with fade
            pause
            ss "An ice-cold beer is coming."
            scene lnw153 with fade
            pause
            scene lnw154 with fade
            pause
            ss "Here's a beer from the sexy waitress"
            mc "Haha, you have to work in a job like this"
            mc "Even with just tips, you can earn more than me"
            ss "Wish."

        "Coffee please":
            scene lnw151 with fade
            pause
            ss "Right away [pD22]"
            scene lnw153 with fade
            pause
            scene lnw155 with fade
            pause
            ss "Hot and tasty coffee"
            ss "Like me.."
            mc "Indeed it is.."
        "What Juice do you have?":
            scene lnw151 with fade
            pause
            ss "Oh, sorry [pD22]"
            ss "I think Ruby drank it all."
            ss "Do you want coffee instead?"
            mc "Yup"
            scene lnw153 with fade
            pause
            scene lnw155 with fade
            pause
    scene lnw156 with fade
    pause
    ss "So"
    ss "About Luna"
    mc "She is fine"
    mc "No dangerous or illegal problems"
    ss "Okay, what's dangerous or not illegal?"
    menu:
        "Lie":
            scene lnw160 with fade
            pause
            mc "Luna and her friends are just hanging out in an alley"
            mc "That's all."
            ss "That's it?"
            mc "Yeah"
            scene lnw161 with fade
            pause
            ss "Hah, good"
            mc "Yup"
            ss "Are you sure it's just that?"
            mc "Like I said before, yup"
            ss "Thank god, I'm relieved"
        "Truth":
            mc "It's little complicated"
            scene lnw158 with fade
            pause
            ss "Complicated how?"
            mc "Looks like Luna has a stalker."
            scene lnw162 with fade
            pause
            ss "What?!"
            mc "Yeah"
            scene lnw163 with fade
            pause
            ss "Soo.."
            mc "I found Luna."
            mc "We talked a little, and then we came home."
            ss "Are you sure you've told me everything?"
            menu:
                "Actually, there is a detail":
                    scene lnw163 with fade
                    pause
                    mc "This stalker started dressing like me, found out Luna admired me"
                    ss "And then?"
                    mc "Because Luna's friends saw me for the first time, they thought I was him"
                    mc "Luna hit me in the head with a baseball bat because she couldn't see my face"
                    scene lnw162 with fade
                    pause
                    ss "What.."
                    mc "It's ok"
                    ss "Damn.."
                    mc "Yeah but it's all okay [pD23]"
                    scene lnw163 with fade
                    pause
                    ss "So what we gonna do about this stalker?"
                    mc "You're not gonna do anything."
                    mc "I'll handle it"
                    scene lnw161 with fade
                    pause
                    ss "Uuuh gonna beat that asshole?"
                    mc "Well.."
                    mc "Probably"
                    ss "Nice!"
                    mc "Weirdo"
                    ss "You're weird too [pD22]"
                    mc "Anyway this is the story"
                    scene lnw157 with fade
                    pause
                    ss "I see"
                    ss "Really thank you very much [pD22]"
                    ss "It's hard being a [pD51]"
                    ss "If you weren't here, I wouldn't have known about it, maybe he'd be obsessed with Luna and hurt her."
                    mc "I don't think he can hurt Luna."
                    mc "Her friends are protecting her"
                "Nope this is it":
                    scene lnw158 with fade
                    pause
                    ss "Seems shady"
                    scene lnw163 with fade
                    pause
                    ss "But I trust you more than anything [pD22]"
                    ss "If you think that's what I need to know, it's the right thing to do"
                    mc "Wow.."
                    ss "What?"
                    mc "You're acting weird."
                    ss "Nah, I'm being reasonable"
                    mc "I loved reasonable Amy"
                    scene lnw165 with fade
                    pause
                    ss "Oh this is nothing [pD22]"
                    ss "You're gonna love this Amy much more"
                    mc "Can't wait"
            if amy_d_points >=2:
                scene lnw164 with fade
                pause
                ss "[mc]"
                mc "Yeah ?"
                scene lnw166 with fade
                pause
                ss "Remember when we were at dinner at your house talking about [pD62] family?"
                mc "Yes"
                scene lnw167 with fade
                pause
                ss "At that moment, I asked you to stop there, and you stopped."
                ss "But deep down, I felt like I needed to hear it..."
                mc "Oh.."
                mc "I stopped not to disturb you"
                ss "I know"
                ss "Anyway let's call it a day"
                scene lnw168 with fade
                pause
                mc "Yeah."
            else:
                scene lnw166 with fade
                pause
                ss "You didn't answer the question I asked at the table."
                mc "........"
                ss "What did [pD62] family want from you?"
                mc "Forget It, Amy."
                ss "Is it that bad?"
                mc "...."
                ss "Did they ask you to get rid of me?"
                mc "What, no?"
                ss "So what?"
                mc "Sorry."
                ss "I see"
                ss "I'm sure you have a good excuse."
                ss "But sooner or later, you have to answer me that question [mc]"
                mc "Yeah I know, but not now"
                ss "Then I believe you [pD22]"
                scene lnw168 with fade
                pause
                mc "Anyway let's call it a day"
    jump v02RubyL
label v02RubyL:
    if v02McNotToday == False:
        scene lnw180 with fade
        pause
        scene lnw179 with fade
        pause
        mc "Ruby"
        mc "Hah, she slept."
        scene lnw183 with fade
        pause
        ss "Yeah I'm not surprised."
        mc "So cute.."
        ss "I know"
        mc "Do you want me to carry her to her room??"
        ss "Naah, I can handle it"
        mc "Are you sure she gets heavier every day"
        scene lnw184 with fade
        pause
        ss "Never ever say this to a woman [pD22]"
        mc "Noted"
        scene lnw181 with fade
        pause
        scene lnw182 with fade
        pause
        mc "See you soon my emerald angel"
        ss "That's cute"
        ss "Drive carefully [pD22]"
        mc "Always [pD23]"
    else:
        scene lnw169 with fade
        pause
        scene lnw170 with fade
        pause
        mc "Where is my emerald angel!"
        scene lnw171 with fade
        pause
        rb "HERE HERE!"
        rb "I miss you so much [pD14]!"
        mc "How much?"
        scene lnw172 with fade
        pause
        rb "Thiiiiiiiiiis much"
        scene lnw173 with fade
        pause
        mc "You may be the sweetest thing I've ever seen Ruby"
        scene lnw174 with fade
        pause
        rb "Kyaaaaaaaaaaaa stop it, I'm so embarrassed!"
        mc "Okay kiddo"
        rb "Ehehe"
        mc "..."
        scene lnw175 with fade
        pause
        rb "Oh.."
        rb "You're going.."
        mc "I have to my angel.."
        scene lnw176 with fade
        pause
        rb "Come back as soon as you can, please."
        mc "I promise baby"
        scene lnw177 with fade
        pause
        rb "I believe [pD14]"
        scene lnw178 with fade
        pause
        mc "Okay then, I'm a goner"
        ss "Be careful [pD22]"
        rb "I love you [pD14]"
        mc "Me too honey"
    scene lnw243 with fade
    pause
    mc "Damn what a day.."
    mc "Again.."
    mc "I miss my girls"
    mc "I feel like I haven't been home for a long time."
    mc "Can't wait to see them"
    mc "And I have a lot of pain in my ass at school."
    mc "And now Luna's impostor stalker too."
    mc "I'd like to live a quiet life with my [pD5]"
    mc "But maybe this life is not that bad"
    mc "Anyway today is over, I hope Janet is not so horny."
    mc "I feel really exhausted"
    scene lnq0 with fade
    pause
    mc "Finally"
    mc "Now it's time for a good sleep"
    scene lnq6 with fade
    pause
    mc "Hello my hot wife"
    mc "Heh she's a heavy sleeper too."
    scene lnq7 with fade
    pause
    mc "After dealing with 3 monsters all day alone, it's normal."
    scene lnq8 with fade
    pause
    mc "Wait, this dress is new."
    mc "And looks like teen dresses"
    mc "Huh weird"
    mc "But it's hot.."
    mc "Anyway, there's no time to be horny. I have to sleep."
    mc "My fucking head still hurts anyway"
    mc "Huh?"
    d2 "[pD63]"
    scene lnq10 with fade
    pause
    mc "Nora?"
    d2 "Can I speak to you"
    mc "Of course honey"
    mc "Bad dream?"
    scene lnq13 with fade
    pause
    d2 "What makes a dream bad?"
    mc "......"
    mc "What's wrong honey"
    d2 "Exactly, what's wrong?"
    mc "I didn't understand."
    d2 "You're acting weird again."
    "Huh, that sounds familiar..."
    mc "How exactly?"
    d2 "[pD63]"
    d2 "Is everything ok?"
    mc "Yes babe why?"
    d2 "You can be honest"
    d2 "I'm sure [pD58] can't listen to us right now."
    d2 "She's a heavy sleeper."
    d2 "[mc]"
    d2 "Are you allright?"
    mc "Yes honey I'm"
    d2 "...."
    scene lnq14 with fade
    pause
    d2 "I love you so much [pD63]"
    mc "I love you too honey"
    d2 "I know"
    mc "But?"
    d2 "But I'm afraid you'll leave again"
    mc "Babe"
    d2 "I promise I'm never gonna do that again"
    mc "...."
    mc "Uhmm"
    d2 "It's really easy too see [pD63], not a big deal"
    mc "Yeah but still"
    d2 "It's scary"
    mc "Stop that"
    scene lnq15 with fade
    pause
    d2 "Sorry"
    d2 "Can't help it"
    mc "So"
    d2 "Am I here to talk about this?"
    d2 "Yes"
    d2 "I just want to feel good"
    mc "So, do you feel good??"
    d2 "Yeah"
    d2 "I am"
    mc "Nora"
    mc "You can trust me"
    d2 "I am."
    mc "And stop scaring people"
    mc "It's not just a privilege to be smarter than everyone else"
    mc "You have to keep this up without offending other people."
    mc "Although it pushes the threshold of tolerance"
    d2 "You are smart too [pD63]"
    mc "Of course I am"
    mc "Why do you think you're smart?"
    mc "Thanks to me"
    d2 "Do as I say, not as I do"
    mc "Huh?"
    scene lnq13 with fade
    pause
    d2 "I've just shortened the long dialogue."
    mc "You're fast."
    scene lnq18 with fade
    pause
    d2 "I know"
    mc "And"
    d2 "And handsome?"
    mc "What no.."
    mc "Wait am I?"
    d2 "Uhmm yeah.."
    mc "Huh thanks"
    scene lnq20 with fade
    pause
    d2 "So smart and so dumb at the same time.."
    mc "Hey!"
    d2 "Ahaha a joke"
    mc "I love you so much Nora"
    d2 "..."
    d2 "Good night [pD13]"
    mc "Can't wait"
    scene lnq23 with fade
    pause
    d2 "Why"
    mc "Nothing.."
    d2 "Okay"
    mc "Good night honey"
    mc "Wait [pD13]!?"
    scene lnq25 with fade
    pause
    "She said [pD13].."
    "Damn I miss that!"
    scene lnq27 with fade
    pause
    "My life is getting better"
    "I think I'm so happy."
    "Yeah I am.."
    scene lnq26 with fade
    pause
    mc "Morning [mc]"
    mc "It's time to start the day"
    mc "Janet's already up, as usual."
    mc "Ugh my head.."
    mc "I think it's gonna hurt like this for a few days."
    scene lnh1 with fade
    pause
    mc "Huh, I haven't seen three of them ready at the same time in a long time"
    mc "Damn Janet you're getting good at this"
    scene lnh2 with fade
    pause
    mc "Morning girls"
    scene lnh7 with fade
    pause
    d1 "......"
    d2 "......"
    scene lnh3 with fade
    pause
    d1 "Morning [pD13]"
    scene lnh4 with fade
    pause
    d1 "I'm sorry I can't attack you today"
    d1 "I'm still very sleepy.."
    mc "Hah lucky day"
    scene lnh5 with fade
    pause
    d1 "Hey!"
    scene lnh6 with fade
    pause
    mc "Nora meditates"
    mc "Emma's almost meditating."
    scene lnh8 with fade
    pause
    d3 "Shut up [pD8], I'm in the middle of something."
    mc "I bet"
    scene lnh9 with fade
    pause
    $persistent.gal15 = True
    d1 "Don't talk to [pD13] like that Emma!"
    scene lnh10 with fade
    pause
    d3 "Oh yeah what u gonna do about it?"
    scene lnq28 with fade
    pause
    d1 "I'm going to bite you!"
    scene lnh10 with fade
    pause
    d3 "Heh I like to see you try"
    scene lnq29 with fade
    pause
    d1 "That's it come over here!"
    d3 "Hey!"
    d3 "[pD64]"
    d3 "Claire gonna bite me again!"
    scene lnq30 with fade
    pause
    mc "Okaay What is this sentence? this is how to make a roam a couch for myself"
    scene lnq31 with fade
    pause
    d2 "That was nice [pD8]"
    mc "Damn"
    mc "Compliments from the most intelligent person in the universe"
    mc "This day could not have started better"
    scene lnq32 with fade
    pause
    d2 "I'm happy for you [pD8]"
    scene lnq33 with fade
    pause
    d2 "Anyway i'm goner too"
    mc "Be..."
    d2 "I will [pD8]"
    mc "Love you honey"
    scene lnq34 with fade
    pause
    d1 "[pD13] we're going to school"
    mc "Okay girls be careful"
    d2 "C'mon let's go"
    scene lnq35 with fade
    pause
    mc "Let's see what's going on in the world"
    scene lnq36 with fade
    pause
    wf "Hey"
    wf "Do you have time?"
    mc "Yeah I still have time"
    mc "What happened"
    wf "Yesterday happened"
    mc "What?"
    wf "[mc]"
    mc "Yes?"
    wf "Are you cheating on me?"
    mc "What?{w} no..{w} why"
    scene lnq38 with fade
    pause
    wf "Okay I believe you"
    mc "What.."
    scene lnq39 with fade
    pause
    wf "Breakfast is ready in the kitchen"
    mc "Wait"
    mc "What's going on, Janet?"
    scene lnq40 with fade
    pause
    wf "Nothing"
    scene lnq41 with fade
    pause
    wf "I'm going to the grocery store, do you want anything??"
    mc "Baby, you're scaring me."
    wf "It was just a question honey everything is ok"
    scene lnq42 with fade
    pause
    mc "But.."
    wf "I'm out see you after school, good luck"
    scene lnq43 with fade
    pause
    mc "What the fuck..."
    mc "I just said that the day started very well"
    mc "Another day another problem.."
    mc "Fucking amazing"
    $config.allow_skipping = False
    jump v03
#End of v0.2.5
