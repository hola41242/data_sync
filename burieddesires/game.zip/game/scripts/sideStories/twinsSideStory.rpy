define av = Character("Ava")
define ol = Character("Olivia")
define tm = Character("Susan")
define dr1 = Character("Driver")
define ml = Character("Lucas")
define tf = Character("Jack")
default OliviaCalledMc = False
default OliviaCalledLucas = False
label twSideStory0:
    $save_name = "Side story: Twins"
    stop music
    $mcName = renpy.input("What is your name?")
    scene twstbg1 with dissolve
    pause
    scene twstbg2 with dissolve
    pause
    scene twstbg3 with dissolve
    pause
    scene twstbg4 with dissolve
    pause
    scene twstbg5 with dissolve
    ol "Hey."
    scene twstbg6 with dissolve
    ol "Wake up!{w} rise and shine!"
    scene twstbg7 with dissolve
    av "Oh,{w} morning, sis."
    ol "Sure, whatever."
    av "Did you sleep well?"
    scene twstbg4 with dissolve
    ol "Not exactly."
    scene twstbg8 with dissolve
    pause
    scene twstbg9 with fade
    av "Oh, how come? Did you have a bad dream?"
    scene twstbg10 with dissolve
    ol "I was running away from the dragon-riding zombies."
    av "Again...?"
    ol "Yeah."
    av "Did they get you this time?"
    ol "No, I showed my boobs, and they fell out of the sky."
    scene twstbg11 with dissolve
    ol "I mean, look at these bad boys!"
    scene twstbg12 with dissolve
    scene twstbg13 with vpunch
    play sound "audio/Slap1.mp3"
    pause
    ol "And this!"
    scene twstbg14 with dissolve
    av "Ahaha!"
    av "Silly..."
    ol "You're silly, not me."
    scene twstbg15 with dissolve
    av "You're so right."
    scene twstbg16 with dissolve
    av "So, what are we doing today?"
    scene twstbg17 with dissolve
    ol "Ugh.. we have to go to the company again..."
    scene twstbg14 with dissolve
    av "Yay!"
    scene twstbg17 with dissolve
    ol "Don't yay!"
    ol "We hate this, remember?"
    scene twstbg15 with dissolve
    av "Oh yeah, we do..."
    scene twstbg18 with dissolve
    av "If you hate it so much, I can go alone..."
    scene twstbg17 with dissolve
    ol "Hell no, You can't do anything without me!"
    av "Also true."
    scene twstbg19 with fade
    av "What will I wear?"
    ol "Doesn't matter."
    ol "just put something on."
    scene twstbg21 with fade
    av "Okay sis."
    ol "Ready?"
    scene twstbg20 with dissolve
    av "Yes."
    scene twstbg23 with dissolve:
        yalign 1.0
        linear 5.0 yalign 0.0
    pause
    ol "How do I look?"
    av "Amazing, like always!"
    ol "Tell me something I don't know."
    av "Let me think..."
    ol "Ugh..."
    ol "Figure of speech."
    ol "Anyway, let's go."
    scene black
    "In living room"
    scene twstbg25 with fade
    av "Wow... You're taller than I am."
    scene twstbg26 with dissolve
    ol "We're the same height, Ava. I'm wearing high heels."
    av "Oh yeah... Right..."
    scene twstbg27 with dissolve
    tm "Morning, girls."
    av "Morning, Mom."
    scene twstbg28 with dissolve
    tm "You're already ready."
    scene twstbg29 with dissolve
    ol "Yeah, dad's waiting for us."
    scene twstbg30 with dissolve
    tm "Charming like always..."
    scene twstbg31 with dissolve
    tm "But I have to admit, it's admirable that you took up on all this responsibility at such a young age..."
    ol "Oh, mother, you have no idea what a good example you set for me...."
    ol "All thanks to you..."
    scene twstbg32 with dissolve
    av "Awww this is so sweet sis..."
    scene twstbg33 with dissolve
    tm "Olivia, these words make me very happy..."
    ol "Wait, let me finish."
    scene twstbg34 with dissolve
    ol "You've set a very good example for me, because"
    ol "you've shown me how pathetic it is to sit at home all day."
    ol "Waiting for your husband to come home from work."
    ol "It may sound like sarcasm, but you've really helped me."
    scene twstbg35 with dissolve
    av "Sis, this is so cruel..."
    tm "It's okay, Ava..."
    scene twstbg36 with dissolve
    ol "You heard her, now move."
    scene twstbg37 with dissolve
    pause
    scene twstbg38 with fade
    pause
    scene twstbg39 with dissolve
    av "So, sis."
    ol "Huh, what?"
    av "What do you think of the new teacher?"
    ol "He's playing the tough guy, but it's not something I can't handle."
    av "I didn't exactly ask that, but.."
    av "But still, he mocked you in class."
    ol "Ava..."
    av "But he did..."
    ol "Shut up, I got caught off guard!"
    scene twstbg40 with dissolve
    ol "Wassup, servant."
    dr1 "Thank you, ma'am."
    scene twstbg41 with fade
    pause
    scene twstbg42 with dissolve
    av "Uhmm, sis, can you move over a little bit?"
    scene twstbg43 with dissolve
    ol "Why? Can't you just sit there?"
    av "I can't sit. You need to get your feet out of there."
    ol "It's pointy."
    av "So?"
    ol "Ahaha, nothing."
    scene twstbg44 with fade
    ol "What do you think?"
    scene twstbg45 with dissolve
    av "I think if we paint all the roads colorful, there will be no unhappy people."
    scene twstbg46 with dissolve
    ol "Ugh...Not that.."
    ol "About the teacher.."
    scene twstbg47 with dissolve
    av "Oh right, I think he is cute."
    scene twstbg48 with dissolve
    ol "No! He is not!"
    scene twstbg49 with dissolve
    av "I don't know... I like him."
    scene twstbg48 with dissolve
    ol "Don't."
    av "But.."
    ol "No but."
    scene twstbg49 with dissolve
    av "Do you think he can do what he says?"
    scene twstbg50 with dissolve
    ol "He can't do it to me."
    ol "And he can't do it to you because of me."
    scene twstbg51 with dissolve
    ol "If he makes Mia angry, we won't have to worry."
    av "Mia is so horrible..."
    scene twstbg54 with dissolve
    ol "She is strong..."
    av "Are you afraid of Mia?"
    scene twstbg51 with dissolve
    ol "No."
    scene twstbg55 with dissolve
    av "That's my sister!"
    scene twstbg56 with dissolve
    av "But I'm too scared..."
    scene twstbg53 with dissolve
    ol "Don't worry, even Mia can't touch you as long as I exist."
    scene twstbg54 with dissolve
    av "I know sis."
    av "But I like him..."
    ol "Who?"
    scene twstbg55 with dissolve
    av "The teacher."
    scene twstbg48 with dissolve
    ol "Ugh not that again.."
    scene twstbg55 with dissolve
    av "Why..?"
    av "He is handsome, cute and.."
    scene twstbg48 with dissolve
    ol "And bossy, that's why you like him."
    scene twstbg46 with dissolve
    av "What? No!"
    av "Why would you say something like that.."
    ol "Are you falling in love with this guy?"
    scene twstbg53 with dissolve
    av "No, I'm not! You're falling in love!"
    scene twstbg54 with dissolve
    av "I just feel safe with him around."
    scene twstbg48 with dissolve
    ol "You feel safe when I'm around!"
    scene twstbg56 with dissolve
    av "Okay.."
    scene twstbg54 with dissolve
    av "Uhm..."
    ol "What now?"
    scene twstbg49 with dissolve
    av "Maybe he is right."
    ol "About what?"
    av "About being successful students."
    scene twstbg57 with dissolve
    ol "Maybe you're right, from now on, instead of learning important things about the company...Let's give up the family fortune."
    ol "let's strive for an education system in which we will compete with low and middle-class students."
    ol "Maybe if we're lucky, we can work 8 hours a day on a monthly minimum wage and devote weekends to ourselves"
    ol "It's perfect just imagining it, isn't it?"
    scene twstbg56 with dissolve
    av "You're just focusing on the bad..."
    scene twstbg51 with dissolve
    ol "Oh honey.."
    ol "I didn't even say the bad ones. Real-life sucks more than you ever imagined, trust me."
    scene twstbg48 with dissolve
    av "But if we focus on our education, we won't suddenly lose all our money."
    ol "That's what I mean, there's no point in doing it, so why would we do that?"
    av "I think you're right."
    ol "Yes, I am, like always..."
    scene twstbg55 with dissolve
    av "But you didn't answer my question..."
    ol "Huh?"
    av "The teacher?"
    av "You talked about the dialogue between you, but you didn't say what you thought of him."
    scene twstbg51 with dissolve
    ol "Huh, you're right.., nice catch, sometimes I forget you're not that stupid."
    scene twstbg57 with dissolve
    dr1 "Poor girl..."
    scene twstbg58 with dissolve
    ol "Excuse me!"
    scene twstbg59 with dissolve
    dr1 "Is there something wrong ma'am?"
    ol "You tell me!"
    dr1 "...."
    dr1 "I'm sorry, ma'am."
    ol "It's okay."
    scene twstbg60 with dissolve
    pause
    scene twstbg61 with dissolve
    ol "Hi, Daddy."
    ol "Uh-huh.. we're on our way, we're almost there."
    ol "Yeah, but I have something to say."
    scene twstbg62 with dissolve
    ol "The driver molested me."
    dr1 "Ma'am!"
    scene twstbg63 with dissolve
    ol "I'm on the phone!"
    scene twstbg62 with dissolve
    ol "Yeah, Daddy, still verbally harassing.."
    ol "No, he just said something, he didn't touch me, but I still don't feel safe."
    ol "Will do daddy."
    scene twstbg64 with dissolve
    av "Sis...."
    ol "Shut up."
    scene twstbg65 with dissolve
    dr1 "Ma'am... Why did you do such a thing?"
    ol "Stop talking to me."
    dr1 "But I need this job!"
    ol "If you keep talking to me, I'll say you tried to rape me this time."
    ol "Ava witnessed all of it."
    ol "Right?"
    av "......."
    av "Yes, sis.."
    scene black
    "At company"
    scene twstbg66 with fade
    av "It was terrible what you did."
    scene twstbg67 with dissolve
    ol "He deserved it, every time we get in the car, he keeps looking at us in the rearview mirror."
    av "So what, that's not a bad thing.."
    ol "Trust me, Ava, these harmless-looking peeks can become much more dangerous over time."
    av "If you say so.."
    scene twstbg68 with fade
    pause
    scene twstbg69 with dissolve
    ml "Trust me, girl, with this body, you deserve to work in much better places."
    ml "Like my office ahahah."
    scene twstbg70 with dissolve
    ml "Well, well, well, look who it is..."
    av "Hey, Lucas."
    scene twstbg71 with dissolve
    ml "Hey, gorgeous."
    scene twstbg73 with dissolve
    ol "What do you want?"
    scene twstbg72 with dissolve
    ml "You god damn know what I want."
    scene twstbg74 with dissolve
    ol "Ava, go sit there. Dad will call us soon."
    scene twstbg75 with dissolve
    ol "Last time I told you not to talk to me. Yet, you still insist."
    ml "What can I say? I can't stay away from such a magnificent girl."
    scene twstbg76 with dissolve
    ol "You're playing with fire Lucas. You don't want to see my bad side."
    scene twstbg75 with dissolve
    ml "Oh c'mon, you shouldn't talk to your future business partner like that."
    scene twstbg76 with dissolve
    ol "Exactly, business partner, not a friend. The dialogue between us will go no further than work."
    scene twstbg77 with dissolve
    ol "Now get out of the way."
    scene twstbg78 with dissolve
    ml "Then what I'm going to say now may surprise you."
    ml "Actually, you were going to get this piece of news from your father. But after our conversation today, I want you to hear it from me."
    scene twstbg79 with dissolve
    ol "What the fuck are you talking about, Lucas?"
    scene twstbg80 with dissolve
    ml "We're getting married."
    scene twstbg81 with dissolve
    ol "Don't ever put your stupid dreams into words again, you don't know how pathetic you look right now."
    ml "Ahaha, this is serious, babe."
    ml "Our fathers already agreed. You weren't my first choice though, Ava was."
    ml "I prefer a loyal puppy that I can easily dominate to a wild tiger."
    scene twstbg86 with dissolve
    ml "Ahaha look at her, so silly."
    scene twstbg87 with dissolve
    ml "I think she's trying to stick her tongue up her nose."
    scene twstbg92 with dissolve
    ml "Anyway."
    ml "But unfortunately, since you're the one with the best management skills, you're the one who has the chance to marry me."
    scene twstbg82 with dissolve
    ol "Is this a joke?"
    ml "Nope, this is real."
    scene twstbg91 with dissolve
    ol "None of what you said matters. But you can be sure that this nonsense will not happen."
    scene twstbg92 with dissolve
    ml "And you can be sure that I will enjoy turning you into a good submissive housewife."
    scene twstbg93 with dissolve
    ol "Do you realize what you're doing right now?"
    ml "Yeah, I'm showing the truth to a spoiled girl who sounds too loud."
    scene twstbg83 with dissolve
    ol "No, you're throwing away the future of your poor company right now."
    ol "Because I will not accept this marriage nonsense in any way, sooner or later you will be banned from all our business."
    ol "When I'm head of the company, I'll wipe you out of the market, and I assure you, Lucas, I won't stop until I see you take the bus from home to work."
    scene twstbg84 with dissolve
    ml "Damn... you really know how to scare someone, I was almost impressed."
    scene twstbg81 with dissolve
    ml "But there's one important detail you missed."
    ol "What's that detail?"
    ml "it's already signed."
    ol "It doesn't change anything, we're in a liberal country, and no one, including my father, can make me do something I don't want to do."
    ol "You've pushed your luck."
    scene twstbg85 with dissolve
    ml "Yeah, and one more little detail."
    ml "If you don't agree to this marriage, I'll just marry Ava instead of you."
    scene twstbg88 with dissolve
    ml "Actually, I see you as a challenge. If I can marry you and turn you into a loyal dog, I can satisfy my ego. Ava is just too easy."
    ml "But, from another angle, I can mentally destroy you by constantly sharing with you what I did to Ava..."
    ml "Huh, I think it's a win-win situation for me."
    scene twstbg89 with dissolve
    ol "Do you think I care what happens to Ava?"
    scene twstbg94 with dissolve
    ol "Did you really come up with such a pathetic plan to attack me...?"
    scene twstbg91 with dissolve
    ol "But, she is mine, it's not that I care about her too much."
    ol "She's loyal, and I can't find an employee like her. So I won't give her away either."
    ol "With one word, Ava won't marry you. You can be sure of that."
    scene twstbg92 with dissolve
    ml "I'd love to see your face after you talked to your father..."
    ml "Anyway."
    ml "I suggest you make your choice now, you or Ava?"
    ml "See you soon, my future wife/sister-in-law."
    scene twstbg95 with dissolve
    ol "........."
    ol "Ava!"
    scene twstbg96 with dissolve
    av "Yes sis, is everything okay?"
    ol "Yes, let's go."
    av "But dad hasn't called us yet."
    ol "This company is mine, and I go when I want."
    play sound("audio/doorStorming.mp3")
    scene twstbg97 with vpunch
    ol "Dad!"
    tf "Olivia! That is not appropriate!"
    av "Hi dad."
    scene twstbg98 with dissolve
    ol "Oh sorry, is it appropriate to sell your daughters like in the Middle Ages?!"
    ol "What the hell, dad!"
    scene twstbg99 with dissolve
    tf "I don't like your tone."
    scene twstbg100 with dissolve
    ol "Fuck the tone!"
    av "Oh my!"
    tf "Excuse me!?"
    scene twstbg99 with dissolve
    ol "Is it true? What Lucas said?"
    tf "That little bastard!"
    tf "You weren't supposed to know that yet."
    scene twstbg101 with dissolve
    ol "Dad..."
    tf "Look, Olivia, you're smart. You have to understand."
    scene twstbg102 with dissolve
    ol "Oh my god....."
    scene twstbg103 with dissolve
    tf "Our company is not in a bad situation, but it is also not in a good situation."
    tf "We need to take the right steps, or we won't be able to keep up in this race."
    scene twstbg104 with dissolve
    ol " So what you call the right step is to sell your daughters for the company?!"
    scene twstbg105 with dissolve
    ol "What if you didn't have a daughter?"
    scene twstbg106 with dissolve
    ol "Then how were you going to save the company? Are you sacrificing us because of your mismanagement skills and being left behind in the race for profit..?"
    scene twstbg107 with dissolve
    tf "If I had a son, we wouldn't be in this situation."
    scene twstbg108 with dissolve
    ol "What..?"
    tf "It's no secret that one of you will be in charge of the company in the future, and the entire lobby knows it, so we can't get forward-looking investment."
    ol "What why? I've proven myself in every field! This stupid Lucas is nothing compared to me."
    tf "It's because you're not men."
    tf "I know it's not fair, but we live in a world like this."
    scene twstbg109 with dissolve
    ol "I can't believe this! The company is going bankrupt because the future boss of the company is not a man?"
    ol "We live in 2021. How is that simply possible..."
    tf "I can't do anything about it, Olivia. If you don't marry Lucas, the company's vote of confidence will drop all the time."
    tf "And by the time one of you becomes head of the company, the vote of confidence will have already fallen substantially"
    tf "You know that those companies always end up in bankruptcy, even if you try, even if you take the right steps, this fact will not change..."
    tf "I'm sorry, but if you don't want to live a middle-class life in the future, you have to marry Lucas."
    scene twstbg110 with Fade (0.2, 0, 0.2)
    scene twstbg110 with vpunch
    pause
    scene twstbg111 with dissolve
    pause
    scene twstbg112 with dissolve
    pause
    scene twstbg113 with dissolve
    pause
    scene twstbg114 with dissolve
    av "Don't touch her."
    tf "Ava..."
    scene twstbg115 with dissolve
    av "I'm sorry..."
    av "But dad, my sister hates Lucas, and it may sound impossible, but even I hate him, does it have to be Lucas?"
    tf "I'm afraid it has to be him. That little bastard and his father have already started spreading rumors in our lobby that he's planning to marry one of you."
    tf "If you don't marry Lucas, we won't find anyone else in the same position."
    av "Why..."
    tf "Because."
    scene twstbg116 with dissolve
    ol "I get it, no need to answer."
    scene twstbg117 with dissolve
    tf "I'll leave it to you to decide who gets married. I can't feel any worse than I feel right now.."
    scene twstbg118 with dissolve
    ol "Anyway, let's go."
    scene twstbg119 with dissolve
    av "Sis.."
    scene twstbg120 with dissolve
    ol "What?"
    av "I think it's fate. Everything that happened today, everything that we talked about, seems to be preparing us for what is happening now."
    scene twstbg121 with dissolve
    av "I can't believe I'm saying this, but FUCK LUCAS!"
    av "And fuck this company!"
    ol "Wha.."
    scene twstbg122 with dissolve
    av "Let's do what the teacher says, get educated, and live like normal people!"
    av "Let us have friends who will accept us for who we are, who will love us. To hell with fake conversations for the benefit of companies!"
    av "Let's fall in love with someone who comes across completely by chance, save money to buy something we want, and take the bus!"
    av "Olivia."
    av "Let's live like normal people!"
    av "C'mon sis, you know I'm right.."
    av "Hey, get ready! we have a future to plan!"
    ol "How.."
    ol "How can you be so calm, Ava?"
    ol "We just found out how worthless our lives are..."
    ol "After all those things I've said to our mother, this happened to me.."
    av "Yeah, you should be nicer to our mother."
    ol "What are we going to do?"
    ol "I want to go home.."
    av "No..{w} not like this."
    ol "What?"
    av "Sis, you look terrible. If you leave the company like this, the entire image you've created so far will shatter."
    av "Especially because that Lucas bastard should still be here, he might be waiting for you."
    av "You don't want to give him that pleasure, do you?"
    ol "Yeah, you are right.."
    ol "......."
    av "Everything will be fine, sis. It's just a day we have to get through."
    av "There'll be a lot of days like this in life. We can't break down every time. We have to do something about it."
    ol "Our whole life is a joke."
    av "No, it's not."
    ol "How can you be sure of that?"
    av "Because I have you."
    ol "When did we change roles, sis?"
    av "Never. I'm just paying my debt to my guardian angel."
    ol "That's gay."
    av "Ahaha yeah, sis, that's pretty gay!"
    ol "Yeah, it is.."
    av "Uh-huh.."
    ol "Anyway, I think I'm ready to leave."
    scene twstbg123 with dissolve
    ol "How do I look?"
    av "Scary like always, that's my sis!"
    ol "Nice, let's go, we have a company to burn."
    scene twstbg124 with dissolve
    av "THAT'S MORE LIKE IT YES!!"
    scene twstbg125 with dissolve
    ol "Calm your tits, Ava."
    av "Oh yeah, I got excited..."
    scene twstbg126 with dissolve
    av "Oh wait!"
    av "You got the driver fired! How do we get home?"
    av "oh, oh, can I drive ??"
    ol "What?! No, I don't want to die yet."
    av "You can't drive either.."
    av "What about father's driver?"
    ol "No, I don't wanna talk with dad."
    av "Cab?"
    av "Oooh! A bus!"
    ol "What.."
    av "Yeah! Let's try the bus, sis. it'll be fun.!"
    ol "Yeah..{w} not that ready.."
    av "C'mon sis, let's try it, please please pleasee!"
    ol "Ugh geez, fine! Just shut up."
    av "Yaaaaay!"
    ol "Don't yaaaaay."
    av "..."
    av "Yay!"
    ol "Hey!"
    scene twstbg127 with fade
    ml "Hey girls, I've been waiting for you."
    ml "So which one of you will be my sex slave? Have you decided?"
    ol "You f...."
    scene twstbg128 with Fade (0.2, 0, 0.2)
    scene twstbg128 with vpunch
    play sound "audio/kick.mp3"
    pause
    scene twstbg129 with dissolve
    av "It's just the beginning, bitch!"
    scene twstbg130 with dissolve
    ol "Oh!"
    ol "My!"
    ol "God!"
    scene twstbg131 with dissolve
    av "Sis, I feel amazing!"
    av "It feels so good!"
    av "I WANT TO HIT EVERYONE!"
    ol "Ahaha, nice kick, Ava!"
    scene twstbg132 with dissolve
    ol "Let's let's get out of here."
    ml "Fucking maniacs!"
    ml "You'll be very sorry!"
    ml "Do you hear me? You'll regret it."
    ml "I'm fucking Lucas Shurly, and you will pay for this!"
    av "Did his desperate screams give you pleasure too? Or am I a weirdo?"
    ol "You have no idea how satisfied I am right now, Ava."
    av "Yaaaaay!"
    ol "Stop yaaying!"
    av "Oh yeah, of course, sis."
    scene black
    pause
    scene twstbg133 with dissolve
    ol "So..."
    scene twstbg134 with dissolve
    av "So..."
    scene twstbg135 with dissolve
    ol "This is a bus stop..."
    scene twstbg136 with dissolve
    av "Uh-huh, I've always seen it in movies, in TV series, it's so exciting, isn't it!"
    ol "I guess."
    av "It's a magical place, sis, people fall in love here, meet new people!"
    ol "It's a space for short-term socialization."
    av "Exactly!"
    ol "Not bad, I suppose."
    ol "About earlier.."
    ol "Maybe we should.."
    av "No."
    av "Don't do that."
    ol "Yeah, right.."
    ol "Wait, Don't you need a special card or something for this bus thing?"
    av "How so?"
    ol "I mean, I think we have to pay for using the bus."
    av "Huh.."
    av "I don't know, sis."
    ol "Well, we'll think about it then."
    av "Yay!"
    scene twstbg137 with fade
    pause
    scene twstbg138 with dissolve
    ol "What..."
    av "What?"
    scene twstbg139 with dissolve
    ml "Did you miss me, bitch?!"
    scene twstbg140 with dissolve
    av "Oh no.."
    av "He's here for revenge, sister."
    av "Protect me!"
    scene twstbg141 with dissolve
    ol "Shut up, Ava."
    ol "What the fuck are you doing here."
    ml "Are you practicing your future life?"
    ol "None of your business, get lost!"
    scene twstbg142 with dissolve
    ml "I do whatever I want!"
    scene twstbg143 with dissolve
    ml "And I expect you to apologize properly. In fact, you need to kneel."
    scene twstbg144 with dissolve
    ol "Get out of my sight, or you'll get a kick from me too."
    ml "How dare you!"
    ml "I'll make you feel sorry, especially you, Ava!"
    ol "Don't you dare, I'll fucking kill you!"
    ml "So you care about her... You're not such a heartless monster."
    ol "Oh, trust me, I am."
    ml "No one can treat me like this. I won't rest until I teach you a lesson."
    ml "And you have to get used to it."
    scene twstbg145 with fade
    pause
    scene twstbg146 with dissolve
    pause
    scene twstbg147 with dissolve
    mc "Girls, what are you doing here?"
    av "A hero!"
    ol "What the.."
    scene twstbg148 with dissolve
    ml "Who the fuck are you, old man?"
    mc "Is everything okay, girls?"
    ol "Sure, we just want to try the bus."
    mc "What, is this your first time?"
    av "Yes!"
    mc "Huh, weird."
    ol "You're weird."
    mc "You're in a mood again, Olivia."
    ol "You know me."
    av "He knows me too, right?"
    mc "Of course, Ava."
    av "Yaay!"
    scene twstbg149 with dissolve
    ml "Hey!"
    ml "Who are you to ignore me?"
    scene twstbg150 with dissolve
    ml "Look at me, boomer!"
    ml "I have to kick these bitches' ass, so take your cheap car and get out o..."
    play sound "audio/punch.mp3"
    scene twstbg151 with vpunch
    pause
    scene twstbg152 with dissolve
    av "Oh my god!"
    ol "....."
    scene twstbg153 with dissolve
    ml "What the f.."
    ml "Do you punch trees before you go to sleep?"
    ml "Fuck, it hurts so much!"
    ml "How dare you?!"
    scene twstbg154 with dissolve
    mc "Look, I don't know who you are, but if I ever hear you talk like that to my students again,"
    ml "What?"
    mc "I'll punch you twice. I don't think a weak little man like you can handle more than two."
    ml "I..."
    scene twstbg155 with fade
    ml "You are a dead man!"
    scene twstbg156 with dissolve
    mc "Such a weirdo."
    av "You saved us, yay!"
    scene twstbg157 with dissolve
    ol "It was extremely unnecessary. No one asked you to do that for us."
    mc "Hmmm."
    mc "I get it, come on, I'll take you home."
    scene twstbg158 with dissolve
    mc "I can't leave you here."
    av "But I wanted to take the bus..."
    ol "Don't talk like you agreed!"
    mc "Olivia."
    ol "What?"
    scene twstbg159 with dissolve
    mc "Shut up and get in."
    scene twstbg157 with dissolve
    ol "How dare you!"
    av "C'mon sis.."
    ol "Ugh, whatever."
    scene twstbg161 with fade
    mc "So where are we going?"
    scene twstbg160 with dissolve
    av "Let's go to the funfair!"
    scene twstbg162 with dissolve
    ol "No."
    scene twstbg161 with dissolve
    ol "We ran into each other in this whole city... Small world..."
    scene twstbg163 with dissolve
    ol "Yes! Ahaha."
    av "how lucky! Phew!"
    scene twstbg164 with dissolve
    ol "Is everything okay, Ava?"
    av "Yes, of course! Why wouldn't everything be okay? Geez sis, calm down."
    scene twstbg165 with dissolve
    ol "Oh my god!"
    ol "Did you call [mcName]??"
    scene twstbg166 with dissolve
    mc "Uhmm, Mr. [mcName]?"
    scene twstbg167 with dissolve
    av "Okay, I have to stop you right there."
    av "You're delusional."
    mc "Girls.."
    ol "Ava!"
    mc "I really feel like I'm getting ignored right now."
    scene twstbg168 with dissolve
    av "Yes I called him.."
    mc "Ahaha, that was fast."
    scene twstbg166 with dissolve
    ol "Shut up!"
    mc "Thank god it's not working hours right now."
    scene twstbg169 with dissolve
    ol "How dare you do something like that without telling me, Ava!"
    mc "Seriously!"
    mc "Oh whatever, I'm just gonna stop talking."
    av "Please don't get mad sis, I saw Lucas look at us with hatred when we left the company..."
    av "And because you got our driver fired, my brain suddenly started working..."
    av "I thought Lucas would probably follow us."
    ol "And you chose to call [mcName] instead of going with father's driver."
    ol "But you insisted on getting on the bus? How did [mcName] get to the bus stop?"
    scene twstbg170 with dissolve
    av "I still want to go on the bus a lot, but I gave him the address of the bus stop so you wouldn't understand."
    scene twstbg172 with dissolve
    ol "How do you know the address of this bus stop?"
    av "......."
    ol "Ava?"
    av "I know the whole city like the back of my hand."
    ol "How?"
    av "I'm on map applications all day!"
    scene twstbg175 with dissolve
    mc "Huh, I think I can educate you, Ava."
    av "Yaay!"
    ol "What does that have to do with education?"
    mc "Look at her. She memorized the whole city. She's a smart lady."
    scene twstbg176 with dissolve
    ol "I wouldn't be so sure about that."
    av "HEY!"
    av "I'm right here.. You talk like I'm an idiot."
    mc "Ahaha yeah.."
    scene twstbg177 with dissolve
    ol "Hey! Don't insult my sister!"
    av "Yaay, go sis!"
    ol "Shut up, Ava."
    av "Yaay, I will!"
    scene twstbg173 with dissolve
    mc "I don't know what this is about, but I don't want to leave you until I'm sure of your safety."
    mc "Who was that idiot?"
    av "He is.."
    ol "Shut up, Ava."
    ol "It's none of your business."
    mc "Actually it is. You're my students."
    mc "No matter how much you don't want to be.."
    mc "Now, tell me what's wrong?"
    ol "As I said before, none of your bus.."
    scene twstbg174 with dissolve
    mc "Now!"
    ol "....."
    ol "It's a long story."
    scene black
    "a while later"
    scene twstbg175 with dissolve
    mc "Ha, it is like a ridiculous soap opera."
    av "I know, right!"
    mc "Yeah, it sucks.."
    scene twstbg177 with dissolve
    ol "Yeah it does."
    scene twstbg175 with dissolve
    mc "So, I can't allow that."
    ol "What exactly can't you allow?"
    scene twstbg174 with dissolve
    mc "This marriage."
    scene twstbg176 with dissolve
    ol "Ahaha thank you, my hero!"
    scene twstbg177 with dissolve
    ol "Seriously, what can you do?"
    mc "Hmmm, that's a good question,"
    mc "but that question doesn't matter at all."
    mc "Because I decided not to allow it."
    ol "Yeah, we understand that, but how?"
    mc "I don't know."
    ol "You're overconfident."
    mc "I know, right? One of the most important requirements of being a teacher is to have confidence"
    ol "you don't even understand sarcasm.."
    scene twstbg178 with dissolve
    av "So...funfair?"
    mc "I think we're here."
    av "Funfair?!"
    scene twstbg179 with dissolve
    ol "Great, now you know our house."
    av "Oh right.."
    scene twstbg180 with fade
    ol "Go inside, I'll be right back."
    av "Hmph!"
    scene twstbg181 with fade
    ol "Thank you."
    mc "For what?"
    scene twstbg182 with dissolve
    ol "You know."
    scene twstbg183 with dissolve
    ol "What you did today may have a lot of meaning in your life."
    ol "But in my world, it can't go beyond a simple protective activity."
    ol "It wasn't your job, though. so I'll give you what you deserve."
    mc "If you're talking about giving me money, don't try anything like that."
    ol "But you earned it."
    mc "Ahahah, fuck you."
    ol "Excuse me!"
    mc "No, I don't think I will."
    mc "I don't need your money, and it's not even your money."
    mc "Keep it."
    mc "I helped you today because I'm your teacher, and some things can be done unconditionally in life."
    mc "But don't worry, everyone in the class will learn this, including you."
    ol "Pftt, you could just say no."
    ol "Oh, before I forget,"
    ol "fuck you too."
    mc "Amazing, see you in class."
    mc "Hey, before you go."
    scene twstbg184 with dissolve
    mc "This is my number, if you get in trouble, don't hesitate to call"
    ol "Huh, In your dreams!"
    mc "Just take this, maybe one day you'll need it."
    scene twstbg185 with dissolve
    ol "Sure, whatever."
    scene twstbg186 with dissolve
    mc "Hey, Olivia."
    ol "What?"
    mc "Is everything really okay?"
    scene twstbg187 with dissolve
    ol "Pfft what kind of question is that?"
    mc "Olivia!"
    mc "When I first spoke to you, I thought you were like a typical brat who wanted to look tough."
    scene twstbg188 with dissolve
    mc "But maybe I was wrong, huh?"
    mc "Maybe I was prejudiced against you."
    mc "But now that I'm looking at you, I see a completely different Olivia."
    mc "An Olivia in so much pain that she needs to make herself look tough."
    scene twstbg189 with dissolve
    ol "Ugh, my stomach!"
    mc "Everything okay?"
    ol "No.."
    scene twstbg190 with dissolve
    ol "I think I'm sick of your speech."
    mc "Okay, that was funny."
    scene twstbg191 with dissolve
    ol "It was?"
    mc "Yeah, I enjoyed it."
    ol "But I humiliated you."
    scene twstbg192 with dissolve
    mc "Yup, and you did it quite successfully."
    ol "..."
    scene twstbg193 with dissolve
    ol "Man what is wrong with you?"
    mc "Nothing, the question is what's wrong with you?"
    scene twstbg194 with dissolve
    ol "Look, if you're hitting on me, you're wasting your time. Yes, this stubbornness can be effective on most people."
    ol "But I don't care, and I hate you, remember?"
    mc "I'm sure everything will be better, Olivia."
    scene twstbg193 with dissolve
    ol "You're completely out of dialogue right now, talking to yourself."
    mc "See you in class."
    ol "Weirdo."
    scene twstbg195 with fade
    ol "Huh?"
    scene twstbg196 with dissolve
    ol "Hey."
    av "............"
    scene twstbg197 with dissolve
    ol "You closed your eyes before I came in, didn't you?"
    scene twstbg198 with dissolve
    av ".."
    scene twstbg199 with dissolve
    ol "I can see you!"
    scene twstbg200 with dissolve
    av "How did you know when I closed my eyes?"
    ol "Right now, your face is facing the entrance, and I'm staying to your right."
    av "My right or your right?"
    ol "My right."
    av "Then you should have said I'm staying to your left."
    ol "Are we really going to discuss this right now?"
    scene twstbg201 with dissolve
    av "I have time?"
    ol "But I don't."
    scene twstbg202 with dissolve
    ol "Also."
    ol "I can still see you. You're not invisible when you close your eyes..."
    scene twstbg200 with dissolve
    av "Are you sure..?"
    ol "You eavesdropped on us, didn't you?"
    av "What? no..."
    scene twstbg203 with dissolve
    ol "Ugh, just go change!"
    av "Aye, sir!"
    scene twstbg204 with fade
    pause
    scene twstbg205 with dissolve
    pause
    scene twstbg206 with dissolve
    ol "Asshole!"
    scene twstbg207 with dissolve
    ol "I'm sure everything will be fine, Olivia, he said,"
    ol "Wait, it's not like that, let me do it with his smart-ass expression."
    scene twstbg208 with dissolve
    ol "I'm sure everything will be fine, Olivia."
    scene twstbg209 with dissolve
    ol "Perfect.."
    scene twstbg210 with dissolve
    ol "......."
    ol "You know what!"
    ol "No, it won't! "
    ol "Everything will be much worse!"
    ol "I don't feel good when you come to me and tell me that you can help me. Even you can't save me, asshole!"
    ol "On the contrary, it makes me feel more sorry for myself.."
    ol "If you really think you can save me, you have to do it without letting me know.."
    ol "As if he could do something like that.."
    ol "Everything will be much worse..."
    scene twstbg211 with dissolve
    ol "This is my hell."
    scene twstbg213 with dissolve
    ol "This is my life."
    scene twstbg212 with dissolve
    pause
    scene twstbg214 with Fade(1.0,0, 1.0)
    pause
    scene twstbg215 with dissolve
    pause
    scene twstbg216 with dissolve
    pause
    scene twstbg217 with dissolve
    tm "Is everything okay, Olivia?"
    scene twstbg218 with dissolve
    ol "Why does everyone ask that..?"
    tm "Honey.."
    scene twstbg219 with dissolve
    ol "No, it's not."
    ol "Maybe you can help me."
    tm "Of course, honey, what is it?"
    ol "Dad's gonna marry me to Lucas."
    tm "And?"
    scene twstbg220 with dissolve
    ol "And??"
    ol "Mom, it's Lucas, the asshole one!"
    tm "It would be more accurate to say 'heir to our partner'"
    ol "Mom, I don't want to marry him."
    tm "Why not?"
    scene twstbg221 with dissolve
    ol "Because I don't love him?"
    scene twstbg222 with dissolve
    tm "Honey.."
    tm "Love is complicated.."
    tm "There are things that have to happen. We can't give them up for stupid things."
    tm "And trust me, even the person you hate most becomes bearable over time."
    scene twstbg223 with dissolve
    ol "What the fuck are you talking about?"
    tm "Olivia!"
    ol "Don't Olivia me!"
    scene twstbg224 with dissolve
    ol "I'm not property, I have feelings!!"
    scene twstbg225 with dissolve
    tm "I doubt that."
    ol "What's that supposed to mean?"
    scene twstbg226 with dissolve
    tm "Okay, honey, calm down. You don't have to do it."
    scene twstbg227 with dissolve
    tm "We'll get Ava married."
    scene twstbg228 with dissolve
    ol "Oh my god.."
    ol "We are your daughters!"
    tm "Don't make this a big deal, Olivia."
    tm "Ava will do it without any problems, and you know that."
    ol "You're a monster!"
    scene black
    pause
    "A while later"
    scene twstbg229 with dissolve
    pause
    scene twstbg230 with dissolve
    pause
    scene twstbg231 with dissolve
    pause
    scene twstbg232 with dissolve
    pause
    scene twstbg233 with dissolve
    ol "Hey"
    scene twstbg234 with dissolve
    pause
    scene twstbg235 with dissolve
    pause
    scene twstbg236 with dissolve
    ol "...."
    menu:
        "[mcName]":
            $OliviaCalledMc = True
            scene twstbg238 with dissolve
            ol "Hey."
            ol "Huh, who are you?"
            scene twstbg239 with dissolve
            ol "What the hell are you talking about bitch!"
            ol "Ugh, you're annoying. Did I call [mcName]?"
            scene twstbg240 with dissolve
            ol "What the fuck is your problem bitch."
            scene twstbg241 with dissolve
            ol "I'm the last person you want to annoy, so be careful."
            ol "Just answer me, does this number belong to [mcName] or not?"
            scene twstbg242 with dissolve
            ol "What the fuck is this? I don't have time for a game."
            scene twstbg241 with dissolve
            ol "Sure, whatever, I just want to talk with him."
            ol "What? Of course not!"
            ol "Uh-huh, then why does a cheap bitch answer his phone?"
            ol "Okay, that was too unnecessary."
            ol "Why would I do such a thing?"
            ol "I'm about to make an important decision for my future."
            ol "And that scares me."
            ol "Yes, but as bad as the first option.."
            ol "Yeah..."
            ol "Huh, that was pretty wise."
            ol "Thank you, mysterious bitch."
            ol "Okay, then I'm out."
            ol "Nu-uh, this can work."
            ol "If possible, don't let him know we talked."
            "phone hangs up"
            ol "Huh..."
            ol "Time to take the third option then."
        "Lucas":
            $OliviaCalledLucas = True
            scene twstbg239 with dissolve
            ol "Hey."
            ml "Guess who regretted it and called like a dog!"
            scene twstbg240 with dissolve
            ol "Ugh, shut the fuck up!"
            ml "Are you fucking kidding me!"
            ml "Instead of apologizing, are you insulting me?"
            ol "Shut up!"
            ol "I made my decision, I will marry you."
            ml "Hmmm, I don't know, I still haven't made my choice."
            ol "What the fuck are you talking about?"
            ml "Oh honey, you've lost the right to choose. Because of you, I was assaulted by someone I don't know."
            ml "You made fun of me, and you insulted me."
            ml "After all this, did you think I'd give you a choice?"
            ml "Funny..."
            scene twstbg241 with dissolve
            ol "You're pushing your luck too hard. It's either me or it's over."
            ml "Damn, do you love her enough to sacrifice yourself for your sister? Is the world turning upside down or something?"
            ol "It's a very strategic choice, and if Ava marries you, you can easily take over my company."
            ml "Hmm, so why are you telling me this, isn't that the most ridiculous move to make?"
            ml "After hearing all this, of course, I will choose Ava. Not you."
            ml "You bitch!"
            ml "I knew you didn't care about Ava. You were going to manipulate me and make me choose Ava!"
            ml "You know what, I'm not that stupid, Olivia, I pick you!"
            ml "You will be my slave!"
            ml "Yes, you heard right! A slave!"
            ol "Fuck..."
            ol "Hanging up."
            ml "Hahaaa hang up, did you think you could manipulate me with your little brain?..."
            ml "I can't wait to destroy you!"
    $save_name = None
    return
