default SidestoryNightmare = False
label Sidestorynightmare:
    $save_name = "Side story: Nightmare"
    stop music
    $mcName = renpy.input("What is your name?")
    if persistent.patch_installed == False:
        $pD8 = str(mcName)
        $pD11 = str(mcName)
        $pD13 = str(mcName)
        $pD14 = str(mcName)
        $pD16 = str(mcName)
        $pD22 = str(mcName)
    $config.allow_skipping = True
    scene lntwo1 with dissolve
    pause
    scene lntwo2 with dissolve
    pause
    scene lntwo3 with dissolve
    mc "Huh.."
    scene lntwo5 with dissolve
    mc "Luna?"
    ln "Good morning, [pD14]."
    scene lntwo4 with dissolve
    ln "[pD14], I'm so sorry I hit you.."
    ln "I thought you were somebody else.."
    mc "Ugh, my head!"
    mc "You thought I was somebody else?"
    mc "How long have you been hitting people with a baseball bat, Luna?!"
    mc "And who did something bad enough that they deserved to be hit like that?"
    mc "Tell me everything right now, how you got yourself into trouble?"
    scene lntwo7 with dissolve
    pg3 "Daamn girls, Luna is being scolded right now."
    pg2 "No way!"
    pg1 "I have to see this."
    scene lntwo8 with dissolve
    ln "Hey girls, is everything okay?"
    pg1 "Uhm yes, boss why?"
    ln "Not for long.."
    scene lntwo6 with dissolve
    ln "Where were we?"
    scene lntwo9 with dissolve
    mc "What is this!"
    mc "Are you a gang leader or something?"
    scene lntwo10 with dissolve
    mc "Look at this place, you look like street punks."
    mc "Do [pD39] and Ruby know about this?"
    scene lntwo11 with dissolve
    ln "[pD14], calm down."
    mc "Don't talk back to me, young lady!"
    pg2 "What did he say? I can't hear."
    pg3 "He said, young lady."
    pg2 "No way!"
    ln "One moment, [pD14]."
    scene lntwo12 with dissolve
    ln "Girls get the fuck out now!"
    pg3 "Yes, boss!"
    scene lntwo13 with dissolve
    mc "I can't believe it!"
    mc "What is this, huh?"
    mc "Birds of prey?"
    scene lntwo14 with dissolve
    ln "Birds of what?"
    mc "You know, the movie about female supervillains. They're supposed to be bad, but for some reason, they're fighting the bad guys."
    scene lntwo15 with dissolve
    ln "That sounds lame."
    mc "It is, it really is.."
    mc "Anyways, what the hell Luna!"
    scene lntwo16 with dissolve
    ln "Okay, I'm going to tell you everything but first, we have to go another place."
    mc "Good, let's go home, I don't want you to stay in this dump anymore."
    scene lntwo17 with dissolve
    ln "Firstly we can't go home."
    ln "Secondly, this is my hideout! It is not a dump!"
    menu:
        "Don't push me":
            $luna_d_points +=1
            play sound "audio/notify.mp3"
            show screen dominancePoint
            scene lntwo17 with dissolve
            mc "Don't push me, Luna!"
            ln "But [pD14].."
            mc "No, but!"
            ln "Fine.. you're the boss."
            mc "Damn right I am."
        "A hideout?":
            scene lntwo17 with dissolve
            mc "What? A hideout?"
            mc "Seriously.."
            scene lntwo18 with dissolve
            ln "Yeah it's cool, look we even have a badass truck here"
            mc "This is a shitty truck, Luna.."
            ln "Yeah... But."
            ln "Doesn't it look cool when you lift the hood?"
            mc "Huh, actually it does.."
            mc "But that's irrelevant."
            mc "Who are you hiding from?"
            mc "Did you commit a crime?"
            ln "Which one?"
            scene lntwo14 with dissolve
            mc "Luna!"
            ln "Sorry, [pD14] just teasing you."
            ln "But seriously, we really should go somewhere else."
            mc "Fine, but they are not coming."
    scene lntwo19 with dissolve
    mc "So where are we going?"
    scene lntwo20 with dissolve
    ln "Are you hungry?"
    mc "Yes, believe it or not, getting hit with a baseball bat makes you hungry."
    ln "Yeah, I've been there."
    mc "What?"
    ln "Nothing, let's go."
    scene lntwo21 with dissolve
    ln "Girls!"
    pg3 "Yes, Luna?"
    ln "I'm going to breakfast with my [pD14], Amelia, you're in charge."
    pg3 "Yes, boss!"
    mc "Ugh.."
    scene lntwo23 with dissolve
    "Another crazy day..."
    "Am I surprised? "
    "Hell no.."
    "But I'm relieved that Luna is okay.."
    "She's a little taller."
    "Huh, who would believe that Luna is only a year older than Emma?.."
    scene lntwo24 with dissolve
    ln "I don't think it's safe.."
    mc "Huh?"
    ln "You're looking at me, you have to look at the road."
    mc "How do you know I'm looking at you?"
    ln "Because I have telekinetic powers."
    menu:
        "No, you don't":
            scene lntwo25 with dissolve
            mc "Nope, that's not true."
            mc "Because telekinetic powers don't give you better vision."
            ln "Let me try again then?"
            mc "Go ahead."
            ln "Because I saw your reflection through the window."
            mc "Fine, you got me."
        "Thank god you're okay":
            $luna_l_points +=1
            play sound "audio/notify.mp3"
            show screen lovePoint
            scene lntwo25 with dissolve
            mc "I haven't seen you in a long time, I think I've missed you..."
            ln "Hah gaay."
            mc "Funny."
            ln "Ugh, man.."
            ln "It's really hard to annoy someone now."
            mc "Not exactly."
            mc "The worst insult right now is calling someone 'straight.'"
            ln "So true.."
    mc "You've been so quiet since we got in the car, it doesn't suit you."
    ln "Yeah.."
    ln "I don't know [pD14].."
    ln "The presence of an adult next to me affects my personality."
    ln "I guess I like being important in my own little world."
    mc "So you're ready to talk about it?"
    ln "Not yet, I'm still hungry, let's eat first."
    mc "Whatever you say."
    scene lntwo26 with dissolve
    mc "We can eat there."
    ln "Sure."
    scene lntwo27 with dissolve
    pause
    scene lntwo28 with dissolve
    pause
    scene lntwo29 with dissolve
    mc "Okay, you can go, I'll get gas first."
    scene lntwo30 with dissolve
    ln "Okay [pD14], do you want me to order for you?"
    menu:
        "Sure":
            mc "Sure."
            ln "What do you want to eat?"
            mc "Hmm, anything with meat in it."
            ln "Aye, sir!"
        "Nah":
            mc "I don't want to order without seeing the menu."
            ln "Okay then, don't be late."
            mc "Okay, honey."
    scene lntwo31 with dissolve
    pause
    scene lntwo32 with dissolve
    pause
    scene lntwo33 with dissolve
    mc "Is everything okay, ma'am?"
    smg "Sure.."
    mc "Because you're staring at me."
    scene lntwo34 with dissolve
    smg "Is that a problem?"
    mc "No, is it a problem for me to ask that?"
    smg "No."
    mc "Good."
    scene lntwo35 with dissolve
    smg "I have to say,"
    smg "You have a really hot girlfriend,"
    smg "Maybe a little young for you, though."
    smg "But hey, good for you."
    menu:
        "She is my [pD29]":
            mc "Thanks, but she is my [pD29]."
            smg "That is better."
            mc "No, we're just.."
            mc "Nevermind."
        "That means you have a chance too":
            mc "You guys can be friends,"
            mc "After all, there's not much of an age difference between you."
            smg "That was pretty smooth."
            mc "Like your skin."
            smg "Hold your horse's cowboy, you're too fast."
            mc "Not always."
            smg "Hah.."
    scene lntwo43 with dissolve
    smg "Wanna play a game?"
    mc "Depends."
    smg "I'll make guesses and try to guess who you are."
    mc "Seems fun, will there be a reward or a punishment?"
    scene lntwo44 with dissolve
    pause
    scene lntwo45 with dissolve
    pause
    scene lntwo46 with dissolve
    smg "......."
    mc "What?"
    smg "Nothing."
    smg "Yes, there will be a punishment and reward."
    smg "Without that, this game wouldn't mean anything."
    mc "Good, is there a limit?"
    smg "Nope."
    mc "Are you sure? You may regret that decision."
    smg "Do you realize that you gave me a lot of clues before making a single guess?"
    mc "Or I'm playing mind games..."
    smg "Not gonna work on me."
    mc "How do you know?"
    mc "After all, your only condition for winning is that I'm an honest person."
    mc "Even if you know everything right, I can say you're wrong."
    mc "Everyone does the same thing because there is no limit."
    smg "Can we start now?"
    mc "Sure."
    smg "You're doing a job where you can order people."
    menu:
        "True":
            mc "It is not difficult to predict."
        "False":
            mc "Nope, you got off to a really bad start."
    smg "You don't have any close friends, you're a lone wolf."
    menu:
        "True":
            mc "How did you figure that out, I wonder?"
            smg "I'm the one asking the questions right now, I don't have to give you any answers."
            mc "Cool, correct."
        "False":
            mc "Hah, dream on, I have a lot of friends, and many of them are close friends."
            mc "Wrong."
    smg "You're married with kids."
    menu:
        "True":
            mc "It's not a surprise for someone my age."
        "False":
            mc "Just because I'm middle-aged doesn't mean I have to be married with kids."
    smg "You're selfish and addicted to control."
    menu:
        "True":
            mc "I'd say it's partly true."
        "False":
            mc "Oh honey, you have no idea who I am.."
    smg "Last guess."
    mc "Shoot."
    smg "You don't know who you are. You don't even have a clue."
    mc "This is..."
    mc "Stupid."
    smg "How so?"
    mc "My turn."
    scene lntwo47 with dissolve
    smg "But I didn't finish yet."
    mc "Yeah, but I did."
    $v02a0 = False
    $v02a1 = False
    $v02a2 = False
    $v02a3 = False
    $v02a4 = False
    menu v02aD:
        "You're old" if not v02a0:
            mc "You're older than you look, but you look so young because you've had aesthetics."
            smg "Wrong."
            $v02a0 = True
            jump v02aD
        "You're a slacker" if not v02a1:
            mc "You don't have any profession, you do things that you don't really want, but you have to do to live the life you want."
            smg "Wrong."
            $v02a1 = True
            jump v02aD
        "You're a show pony" if not v02a2:
            mc "You don't smoke regularly, you only smoke at specific moments because you think smoking makes you look sexier."
            smg "Wrong."
            $v02a2 = True
            jump v02aD
        "You're a slave" if not v02a3:
            mc "You like to be controlled, but you want the person who controls you to deserve it."
            smg "Wrong."
            $v02a3 = True
            jump v02aD
        "You're jealous" if not v02a4:
            mc "You're jealous, full of hatred, you hate everyone younger and prettier than you."
            smg "Wrong."
            $v02a4 = True
            jump v02aD
    smg "......."
    scene lntwo38 with dissolve
    smg "You know what, I made a mistake, I don't want to play anymore."
    mc "Shut up."
    scene lntwo49 with dissolve
    smg "Excuse me.."
    scene lntwo50 with dissolve
    mc "Go to the bathroom and wait for me."
    scene lntwo51 with dissolve
    smg "What makes you think I'll do that..?"
    mc "Because we both want it."
    scene lntwo48 with dissolve
    smg "I.. Can't deny that.."
    mc "Good, now move your ass."
    scene lntwo36 with dissolve
    pause
    scene lntwo37 with dissolve
    pause
    scene lntwo38 with dissolve
    pause
    scene lntwo39 with dissolve
    "Well.."
    "Can't help myself."
    "I'm a man after all..."
    "Let's rock."
    #black screen
    scene lntwo40 with dissolve
    "Fuck..."
    "Luna must have seen us."
    "Hmmm.."
    menu:
        "Fuck it, Luna's the last person that would rat me out to Janet.":
            "I hope she won't stare."
            scene lntwo41 with dissolve
            pause
            scene lntwo42 with dissolve
            pause
            "Time to smash"
            scene lntwo42v1 with dissolve
            "Hmmm"
            scene lntwo42v2 with dissolve
            smg "Yes, sir."
            mc "Let's be quiet."
            smg "Why?"
            mc "Don't ask questions, just obey me."
            scene lntwo42v3 with dissolve
            smg "Yes, sir."
            menu v02ss0:
                "Handjob":
                    scene sidehj
                    pause
                    jump v02ss0
                "blowjob":
                    scene bjsdeone
                    pause
                    jump v02ss0
                "fuck":
                    scene rversecg
                    pause
                    menu:
                        "close look":
                            scene rvrseclose
                            pause
                            menu:
                                "cum":
                                    scene lntwo42v4 with vpunch
                                    pause
                                "continue":
                                    jump v02ss0
            scene lntwo42v1 with dissolve
            mc "That was good."
            smg "Yeah, it was."
            mc "Well, have a good day."
            smg "....."








##########################################
    scene lntwo52 with dissolve
    "There she is.."
    "She's still in the same place."
    "Or she went all over the store and came back here."
    "Or she was following me...."
    "Fuck.."
    "But..."
    menu:
        "Spank!":
            scene lntwo53 with dissolve
            pause
            scene lntwo54ps with dissolve
            mc "Wha.."
            mc "How"
            ln "Haha, nice try, [pD14]!"
            mc "Wow, you really have powers."
            scene lntwo55 with dissolve
            ln "You bet!"
            mc "Or, you saw it from the reflection."
            ln "There's only one logical explanation here, and that's the fact that I have powers."
            mc "Sure, sure."
            ln "But damn, [pD14].."
            ln "Were you really going to spank me?"
            menu:
                "No":
                    mc "Pfft of course not."
                    mc "I wanted to test your special powers."
                    ln "Uh-huh, very convincing.."
                "Yes":
                    play sound "audio/notify.mp3"
                    show screen dominancePoint
                    $luna_d_points +=1
                    mc "Yeah, is that a problem?"
                    ln "Nope."
                    mc "Cool, then I'll try again later."
                    ln "Good luck with that."

    mc "So, did you look for something to eat?"
    scene lntwo56 with dissolve
    ln "Yeah."
    mc "And?"
    ln "There is nothing good here, let's go somewhere else."
    mc "Luna..."
    scene lntwo57 with dissolve
    ln "C'mon let's go."
    mc "Sweety, we need to talk about this, you can't make me forget it by constantly changing decisions."
    scene lntwo58 with dissolve
    ln "Geez [pD14], we'll talk, but first, let's eat."
    scene lntwo59 with dissolve
    ln "If my memory doesn't mislead me, you were picky about food."
    ln "Just like in other matters.."
    #black screen
    scene lntwo63 with dissolve
    mc "We've been driving for half an hour, and you still haven't decided where to eat."
    mc "You know what! That's it!"
    mc "You hit me in the head with a baseball bat, Luna."
    mc "Fuck the meal. We are going to talk right now!"
    scene lntwo64 with dissolve
    ln "No way!"
    ln "We have to find a good place to eat and talk."
    mc "Luna, is everything okay?"
    mc "Why are you always trying to avoid this conversation?"
    ln "....."
    mc "Luna?"
    ln "No, it's not that.."
    ln "Because after we talk, you'll take me home and disappear again.."
    mc "Honey, we live in the same city now... We can see each other whenever we want."
    ln "Maybe we live in the same city, but we're not in the same timeline.."
    mc "What do you mean?"
    ln "We live in the same city, and we have a very deep bond."
    ln "But you're never there for me, you exist, but you don't actually exist."
    mc "How charming, I'll ask you something before I answer."
    mc "Have you talked to [pD40] lately?"
    ln "Nope."
    mc "Then I'll give you my answer after I drive you home."
    ln "Whatever.."
    #BLACK SCREEN
    scene lntwo82 with dissolve
    mc "Luna."
    mc "Hey."
    mc "Wake up."
    #A while later
    scene lntwo71 with dissolve
    ln "Oh, I fell asleep."
    mc "Yeah."
    scene lntwo79 with dissolve
    ln "How sweet did I look while I slept, [pD14]?"
    mc "So you want me to admit that you're cute and rate it."
    ln "Exactly."
    mc "Hah, cute."
    ln "Yeah, I know, but how much cute?"
    menu:
        "Why don't you try the power of 'telekinesis' and find out for yourself?":
            ln "Oh c'mon.."
            mc "Yeah, how does it feel?"
            ln "No, not that"
            scene lntwo81 with dissolve
            ln "I read your mind.."
            mc "....."
            ln "I got you."
            ln "Again."
            mc "So?"
            ln "9/10."
            mc "When did I cut that 1 point?"
            ln "Nope, I don't fall for such easy tricks, [pD14]."
            mc "Damn it!"
        "Why would I rate you like that?":
            scene lntwo78 with dissolve
            ln "Oh.."
            ln "Well, I thought we'd have fun or something..."
            scene lntwo75 with dissolve
            mc "Nonsense."
            mc "After you hit me in the head with a baseball bat, I'm taking you to dinner."
            mc "Don't you think it's an insult to ask me to rate how cute you are or how much I care about you?"
            ln "I.."
            mc "Stop playing stupid games, Luna."
            mc "After all this, especially."
            scene lntwo76 with dissolve
            ln "Just.."
            ln "All right, forget it.."
    scene lntwo70 with dissolve
    "She seems to be immersed in deep thoughts."
    "No matter what I do, she won't answer my questions."
    "At least until she wants to."
    "She doesn't want me to push her."
    "I think she set a few conditions in her head."
    "She's playing one of her games again."
    "Well, bad luck, honey, because I've had enough experience with Emma."
    "I can play that game too."
    mc "Long time no see, huh, Luna?"
    scene lntwo71 with dissolve
    ln "......."
    ln "Yes, [pD14]."
    mc "[pD40] and Ruby came to visit recently."
    mc "Why didn't you come?"
    scene lntwo73 with dissolve
    ln "I was busy.."
    mc "I bet."
    mc "I wonder what's important enough to keep you from visiting?"
    scene lntwo72 with dissolve
    ln "Hmmm."
    ln "I have a better question."
    "Fuck...."
    scene lntwo73 with dissolve
    ln "What's important enough to keep you from me?"
    mc "I don't understand.."
    scene lntwo77 with dissolve
    ln "Of course you don't."
    ln "Trust me.. If you knew.."
    mc "Knew what?"
    ln "Nothing, [pD14]."
    ln "Just take me home."
    scene lntwo75 with dissolve
    mc "Nope."
    mc "First, we will talk about this."
    mc "And, I promised [pD40]."
    scene lntwo76 with dissolve
    ln "Hah.."
    ln "Uh! Stupid me! How could I not guess!"
    ln "You're here because your [pD7] wants you to."
    ln "And I thought.."
    scene lntwo73 with dissolve
    ln "You know what? Let's stop talking."
    mc "Luna.."
    scene lntwo74 with dissolve
    ln "Just shut up!"
    ln "Shut up, shut up, shut up!"
    mc "What the hell?"
    scene lntwo72 with dissolve
    ln "I was so happy you found me."
    ln "But I was still angry."
    ln "But my dear [pD14] found me at [pD41]'s request!"
    ln "Fucking amazing!"
    scene lntwo71 with dissolve
    ln "Oh, yeah, I almost forgot, how did you find me?"
    menu:
        "Ruby told me":
            $v02RubyTold = True
            scene lntwo73 with dissolve
            ln "Fucking little asshole!"
            mc "Hey!"
            ln "Yeah, perfect little Ruby!. No one can say anything to her."
            mc "I didn't mean.."
            ln "Save it, I understand."
        "I have my ways":
            scene lntwo77 with dissolve
            ln "Pfft you're just a teacher."
            mc "I was thinking like that, until a short while ago."
            ln "Oh yeah, what changed?"
            ln "Did you join the Special Forces or something?"
            mc "Maybe."
            ln "You wish.."
            ln "But I'm mad at you, so I can do what I want!"
            mc "For example, you can hit me in the head with a baseball bat."
            mc "Oh right... You already did that."
            ln "....."
    scene lntwo76 with dissolve
    mc "I'm not here just because of [pD40]'s request."
    ln "Ugh, just stop, you're gonna say I'm worried about you or something.."
    scene lntwo78 with dissolve
    mc "You know what? You're right."
    mc "I didn't worry about you, because you're not someone I have to worry about."
    mc "I don't know how you do it, but you can put yourself in extremely dangerous situations and get away with it."
    mc "You're like that, Luna."
    mc "You have survival skills."
    mc "And you don't need anyone."
    mc "So stop playing the helpless fragile girl."
    mc "The biggest reason we couldn't see each other is that you didn't come to me."
    mc "There's only one person here who has the right to be angry, and it's me."
    mc "So sulk all you want, I don't feel any emotional responsibility for you."
    scene lntwo80 with dissolve
    ln "Okay.. you're right."
    mc "Yea, I am."
    ln "But still, fuck you."
    scene lntwo75 with dissolve
    mc "Fuck you too honey."
    mc "'You exist, but you don't actually exist' huh?"
    ln "Hey."
    ln "Don't embarrass me. I may have been touched at that moment and made such a sentence."
    mc "I wonder how Amy and Ruby will react when they hear this."
    ln "Don't you dare!"
    mc "Oh, I dare."
    ln "I'll hit you with a baseball bat again."
    mc "Aahaha, of course, kiddo."
    ln "Asshole."
    menu:
        "Enough with the insults!":
            play sound "audio/notify.mp3"
            show screen dominancePoint
            $luna_d_points +=1
            mc "I'm going to stop you right there."
            mc "You're out of line now, young lady!"
            mc "It's getting annoying."
            ln "Oh c'mon, I'm just messing with you, [pD14]."
            mc "Don't, or I'll start messing with you."
            ln "It just words, you know."
            mc "Hmmm, let's see what words can do."
            ln "Okay [pD14], come at me with everything."
            mc "And now I'm going to use my telekinesis ability to put what's inside your head into words."
            mc "Even though you're the least bright girl in the house, the fire of freedom that you think is burning inside you makes you different from everyone else."
            mc "The reason you don't go to school is because of the real fear you have at home. There's a lot of people, and you realize you're no better than any of them."
            mc "You've put yourself in an important place in your head. So you're trying to escape the truth and live with your own truth."
            mc "The phrase no one understands me actually means that no one should understand me, or they will understand how ordinary I am."
            mc "And trust me, your fucking pretentious wild attitude only makes you important in the eyes of the simps."
            mc "Is that really what you want?"
            mc "If being important to degenerate nerdy simps who don't leave the house really satisfies you..."
            mc "I wish you were a little like Ruby."
            ln "I want to get out."
            mc "Of course you do, but you can't."
            mc "You can get out if I want you to. So far, you've been sitting in the side seat and talking to me with an intonation like you're superior to me."
            mc "But the truth is, you're not in charge here."
            mc "If you really want to get out, you can open the door and jump."
            mc "Get it?"
            ln "I don't wanna talk anymore."
            mc "Yes, of course, because you knew you couldn't win by talking. And you choose the easiest way, not to talk."
            mc "You need to grow up, Luna."
        "Don't do that again":
            mc "Honey, I know it's your personality and your style."
            mc "But it's starting to bother me that you're always insulting me."
            mc "I love you so much, so I'm asking you to be more careful."
            ln "C'mon [pD14], it's just words.."
            mc "No, it's not."
            ln "....."
            mc "We're cool?"
            ln "I am, that's for sure."
            menu:
                "Don't push her":
                    mc "Well, better than nothing."
                    ln "Yeah, it is."
                "Push her":
                    play sound "audio/notify.mp3"
                    show screen dominancePoint
                    $luna_d_points +=1
                    mc "I'm asking one more time, Luna."
                    mc "We're cool, right?"
                    scene lntwo71 with dissolve
                    ln "What happens if I say no"
                    mc "You'll find out after you say no."
                    mc "And believe me, anything can happen, if you really want to know, be my guest."
                    scene lntwo70 with dissolve
                    ln "........."
                    ln "We're cool."
                    mc "Nope, try again."
                    ln "We're cool [pD14]."
                    mc "See, not that hard."
    mc "So Luna, are you ready to tell me?"
    ln "......."
    mc "Why did you hit me, Luna?"
    ln "I.."
    ln "I was high, I thought you were a stalker chasing me."
    mc "That's it?"
    ln "Yeah."
    mc "I don't believe this."
    ln "Well, I can't force you to believe it, you asked me for an answer, and I gave you an answer."
    mc "Luna, please."
    ln "I'm telling the truth, [pD14]."
    mc "Then I pretend to believe it."
    ln "Thanks."
    scene lntwo70 with dissolve
    ln "Have you decided? what are we going to do?"
    mc "Why don't you want to go home?"
    ln "I don't know, I just don't want to."
    mc "Okay."
    scene lntwo75 with dissolve
    ln "You'll still take me home, won't you?"
    mc "Of course I won't do that."
    mc "If you don't want to go home, I can give you a ride to a friend you trust."
    ln "Nah, I don't want to see anybody."
    mc "Then I'll take you to a hotel."
    ln "I don't want to be alone."
    mc "It's really annoying, you know."
    scene lntwo70 with dissolve
    ln "I want to stay with you today."
    mc "Sure, the girls missed you, too."
    ln "Not there.."
    ln "Let's stay in a hotel together.."
    mc "Why?"
    ln "I want to spend time with you in a cheap hotel room."
    mc "That's weird.."
    ln "Please."
    mc "Honey, have you forgotten that I have a family?"
    ln "Pfft, what could happen?"
    ln "Janet will divorce you if you say you can't come home one day?"
    mc "It's not just that, I've started a new job, and it's exhausting."
    ln "I didn't say we should run a marathon together."
    mc ".........."
    scene lntwo79 with dissolve
    ln "C'mon, [pD14].."
    mc "Okay, but it's a one-time thing."
    scene lntwo81 with dissolve
    ln "Yes!"
    mc "But promise me, no funny business?"
    ln "Aye, sir!"
    scene black with dissolve
    scene lntwo69 with dissolve
    ln "Oh, a motel."
    mc "Yeah, seems good."
    scene lntwo84 with dissolve
    ln "Not a lot of people, quiet, this place is perfect!"
    scene lntwo83 with dissolve
    pause
    scene lntwo85 with dissolve
    mc "I wonder if there's food here."
    scene lntwo86 with dissolve
    ln "Let's talk to the manager."
    scene lntwo87 with dissolve
    mc "Hey."
    hm "Welcome."
    mc "We need a room for two."
    scene lntwo88 with dissolve
    hm "I'm afraid they're all full."
    scene lntwo87 with dissolve
    mc "How can there be no rooms available when there is so few cars parked?"
    hm "Most of our rooms are being renovated."
    mc "Okay."
    ln "Let's just take whichever is available then."
    hm "Sure thing."
    scene black with dissolve
    scene lntwo89 with dissolve
    ln "Not bad at all huh, [pD14]?"
    mc "Yeah, I guess."
    mc "Wait for me here, I'll go get something."
    ln "What are you gonna get?"
    mc "A few cleaning stuff."
    mc "And food if I can find any, but you can order whatever you want right now. Don't wait for me."
    ln "Okay."
    ln "Hey.."
    mc "What?"
    ln "You'll be back, won't you?"
    mc "Did you think I'd leave you alone in a place like this??"
    ln "You left me in a lot worse places than here."
    mc "No, I didn't."
    ln "Oh yeah, that was someone else."
    mc "Who?"
    ln "Ahaha, just kidding, [pD14]."
    mc "Funny."
    scene lntwo90 with dissolve
    ln "Ugh, my feet are killing me."
    mc "Then why are you wearing those big boots?"
    ln "Because I like to look like this."
    mc "It's weird."
    ln "What's weird?"
    mc "This thought."
    scene lntwo91 with dissolve
    ln "Uh-huh, how about you?"
    mc "Me?"
    ln "Yeah, you're wearing a suit."
    mc "So what, I'm dressed for my job."
    ln "I'm also dressed for my job."
    mc "And what job is that?"
    ln "Living."
    mc "Hmm..."
    ln "Exactly."
    mc "You make me miss Emma."
    ln "Damn, I missed her!"
    ln "How is she?"
    mc "As always."
    ln "I bet."
    scene lntwo93 with dissolve
    ln "Something's changed."
    mc "What do you mean?"
    ln "Something in your eyes."
    mc "Well, I like my eyes."
    ln "Seriously?"
    mc "Yeah, why?"
    ln "Because it's a very ordinary color."
    mc "Yes, that is why I like them."
    scene lntwo94 with dissolve
    ln "You're really boring [pD14].."
    scene black with dissolve
    scene lntwo95 with dissolve
    mc "Don't leave the room until I get here, don't open the door if someone knocks, understand?"
    ln "Ahaha [pD14] trust me, I'm too used to these situations."
    mc "Ugh.."
    scene black with dissolve
    pause
    "A while later"
    scene lntwo96 with dissolve
    menu:
        "What is that noise?":
            scene lntwo97 with dissolve
            "I'm sure Luna's fine, I still have time, I'll check on that voice."
            menu:
                "Knock":
                    scene lntwo98 with dissolve
                    "knock-knock."
                    "Hmmm, nothing."
                    "What should I do?"
                    menu:
                        "Try to enter":
                            "It's unlocked."
                            scene lntwo99 with dissolve
                            pause
                            scene lntwo100 with dissolve
                            jq "Yo what the fuck?"
                            mc "Hey, sorry I heard strange noises, and I wanted to check to see if everything was okay."
                            jq "Without knocking?"
                            mc "I knocked."
                            scene lntwo101 with dissolve
                            jq "Bullshit!"
                            mc "Buddy, you don't have a gun..."
                            jq "Fuck off!"
                            jq "Don't mess with my mind asshole, can't you see the glock in my hand?"
                            mc "That's what I'm saying, I don't see it."
                            scene lntwo102 with dissolve
                            jq "Fuck really.."
                            jq "Damn man, I'm so fucking high.."
                            scene lntwo103 with dissolve
                            mc "Yeah, I can see that."
                            jq "My gun?"
                            scene lntwo104 with dissolve
                            mc "No, I meant.."
                            mc "Nevermind."
                            mc "Are you watching the wall?"
                            jq "Huh? no, watching TV."
                            mc "Hmmm."
                            jq "Lick and mortgage on."
                            mc "No, it's not, and what the fuck is Lick, and oh fuck whatever."
                            mc "Tv's standing to my right and you're watching the wall."
                            jq "Jesus fucking christ, are you fucking insane?"
                            mc "Yeah, I'm the insane one."
                            jq "Aahahah tickle lick..."
                            jq "This dude is fucking crazy."
                            "Why did I enter this room? Why did I sit next to this maniac?..."
                            "I guess things don't find me. I'm looking for them."
                            mc "You are the weirdest guy I've ever met."
                            jq "What?"
                            mc "Nothing."
                            mc "...."
                            scene lntwo105 with dissolve
                            mc "Is she okay?"
                            jq "Pfft, how should I know ehehe."
                            mc "Huh?"
                            jq "She's just chilling, man."
                            scene lntwo106 with dissolve
                            mc "This is more than chilling."
                            jq "For weak motherfuckers maybe, but not for us."
                            scene lntwo107 with dissolve
                            mc "Is she your girlfriend or something?"
                            jq "Nah, she was here when I came."
                            mc "And you didn't have a problem with that?"
                            jq "Look at her, would you have a problem with that?"
                            scene lntwo108 with dissolve
                            mc "...."
                            scene lntwo109 with dissolve
                            pause
                            scene lntwo110 with dissolve
                            #m animation
                            hk "Mmmmhmmm."
                            scene lntwo111 with dissolve
                            mc "What was that?"
                            jq "What was what?"
                            mc "She's just moaning."
                            jq "Yeah, she does that all the time."
                            mc "....."
                            mc "All the time?"
                            jq "Yeah, dude, it's kind of annoying."
                            scene lntwo112 with dissolve
                            mc "A hot smoking girl is moaning, and that's annoying for you?"
                            jq "Yes, I can't focus on click and sorty."
                            scene lntwo114 with dissolve
                            mc "Click and sorty huh?"
                            scene lntwo113 with dissolve
                            jq "Yeah, best show ever."
                            mc "So what's this show about?"
                            scene lntwo115 with dissolve
                            jq "There is a guy."
                            scene lntwo116 with dissolve
                            mc "And?"
                            jq "And what?"
                            mc "You were talking about Click and Sorty."
                            scene lntwo117 with dissolve
                            jq "Click and what?"
                            jq "Dude, what the fuck are you talking about?"
                            jq "There is no such series."
                            mc "......"
                            scene lntwo118 with dissolve
                            jq "So anyway, this guy's like a genius, he's time-traveling with his grandson, and his grandson's name is sorty."
                            jq "That's why the name of the show is Click and Sorty."
                            scene lntwo115 with dissolve
                            mc "You're doing that on purpose, right?"
                            jq "Doing what on purpose?"
                            mc "The show name."
                            jq "Which show?"
                            "I'm about to punch this asshole.."
                            mc "Are you sure she is okay?"
                            jq "Her brain has turned into mashed potatoes, but she is hot as hell, free fuck doll ey mate ahahah."
                            mc "I don't think she's aware of what's going on around her."
                            jq "Who cares?"
                            menu:
                                "I do":
                                    scene lntwo114 with dissolve
                                    mc "I care."
                                    jq "Why?"
                                    mc "Because it's a felony."
                                    jq "Yeah, you're right, call the police."
                                    jq "Just kidding, dude, don't do that."
                                    jq "Also, chill a little, will you? She is happy, look at her face."
                                    mc "Cuz she's on drugs."
                                    jq "So what?"
                                    mc "Yeah, I think you're right."
                                    jq "Damn right I am."
                                "I don't":
                                    scene lntwo115 with dissolve
                                    mc "Looks like you don't really care."
                                    jq "Because I don't."
                                    mc "Lucky you."
                                    jq "Why?"
                                    mc "...."
                                    jq "Fuck you, asshole."
                                    mc "What?"
                                    jq "I know what you mean."
                                    mc "Huh?"
                                    jq "Now you're surprised I understand that."
                                    mc "I get it. You're not a dumbass."
                                    jq "Heh fuck you, dude."
                            scene lntwo115 with dissolve
                            mc "So, what was that noise?"
                            jq "She sometimes starts moaning, and then she stops, I don't know what she used, but it gives her orgasms, I guess."
                            mc "Did you fuck her?"
                            jq "Wish."
                            mc "huh?"
                            jq "I took so much shit, my ding dong isn't working.."
                            mc "Heh, you must hate your dick right now."
                            jq "Not really, I really don't care about sex right now."
                            mc "What kind of drugs did you take.."
                            jq "I know right, it's fucking crazy."
                            jq "There is a hot smoking body in front of me, and she wants to be fucked, but I don't care."
                            jq "Weird, huh?"
                            mc "Whatever, I'm going to my room, try to be quiet, I have to work on something, and I need silence."
                            jq "What are you going to work on in a place like this?"
                            mc "It's none of your business."
                            jq "I've told you my whole story."
                            mc "And?"
                            jq "You should do the same."
                            jq "Also, it will be good for you cuz probably I'm not even gonna remember you when I'm silver."
                            mc "Yeah, thanks, but no, have fun."
                            scene lntwo112 with dissolve
                            jq "Yo suit guy."
                            mc "What?"
                            jq "Wanna fuck this slut?"
                            mc "Huh?"
                            jq "I'm sick of watching tv."
                            mc "You are not watching god damn tv, dude, it's fucking wall!"
                            jq "Pfft whatever, do you want her or not?"
                            scene lntwo113 with dissolve
                            jq "Yeah, she is hot, I bet her pussy smells like water."
                            mc "Water?"
                            mc "Dude, water doesn't smell."
                            jq "FUCK OFF REALLY?!"
                            mc "Calm down, everybody knows that, why are you so surprised?"
                            jq "I feel cheated..."
                            mc "Because of this?"
                            jq "Yeah..."
                            scene lntwo114 with dissolve
                            mc "Can you understand what I'm saying?"
                            hk "......"
                            scene lntwo113 with dissolve
                            mc "If you want me to take you somewhere safe, give me a sign."
                            mc "You can trust me. I'm a teacher..."
                            hk "......"
                            jq "Fuck you too."
                            mc "Shut up, dude."
                            mc "Okay, let's try like this."
                            mc "If you want me to take you somewhere safe, blink two times."
                            hk "....."
                            mc "Blink if you understand me."
                            mc "Blink once for yes, twice for no"
                            hk "...."
                            mc "You know what, I think you're faking it."
                            mc "Look, I'm in a very strange situation right now."
                            mc "Part of me wants me to fuck you so hard..."
                            mc "The other one wants me to help you."
                            mc "And I really don't know what to do right now."
    scene lntwo114 with dissolve
    mc "Well.. I tried. My conscience is clear."
    scene lntwo133 with dissolve
    mc "I hope nothing happens to you, you're so young and beautiful, this is so sad.."
    mc "Good luck."
    hk "Wait.."
    scene lntwo134 with dissolve
    "Always works"
    scene lntwo135 with dissolve
    mc "You've finally decided to talk."
    scene lntwo137 with dissolve
    mc "What is your name?"
    hk "......"
    mc "That's a good name, I'm [mcName], nice to meet you."
    mc "Will you answer the questions I just asked?"
    hk "....."
    mc "Are you in danger?"
    scene lntwo136 with dissolve
    hk "No."
    mc "Cool, is there anything you want from me?"
    scene lntwo137 with dissolve
    hk "....."
    mc "Ugh, fuck it. "
    mc "I'm outa here."
    scene lntwo139 with dissolve
    hk "Don't go."
    mc "Then answer my questions."
    scene lntwo140 with dissolve
    hk "Okay.. I will."
    mc "But first, stop lying like concubines in the Ottoman harem."
    scene lntwo141 with dissolve
    hk "How do you know that?"
    mc "I'm a teacher."
    scene lntwo142 with dissolve
    hk "Huh, weird.."
    mc "Why is that?"
    scene lntwo143 with dissolve
    hk "I thought of you as a powerful businessman or a mafia."
    mc "Because I'm wearing a black suit, right?"
    hk "That too, but the real deal is your eyes."
    "That's the second time today.."
    mc "You're hitting on me?"
    scene lntwo147 with dissolve
    hk "Maybe.."
    mc "......"
    mc "Anyway."
    scene lntwo144 with dissolve
    mc "Why are you here with this guy, do you know him?"
    hk "No, I don't."
    mc "I asked two questions. You only answered one."
    scene lntwo145 with dissolve
    hk "I'm..."
    hk "Running.."
    hk "can you sit in front of me?"
    mc "It's weird but, why not."
    scene lntwo126 with dissolve
    mc "Happy?"
    scene lntwo127 with dissolve
    hk "Yeah."
    mc "So you are running?"
    mc "From the law?"
    hk "Kind of.."
    scene lntwo128 with dissolve
    hk "It's my family."
    scene lntwo129 with dissolve
    mc "I don't have to sit here anymore."
    scene lntwo130 with dissolve
    hk "No, stay.."
    mc "Fine."
    scene lntwo132 with dissolve
    mc "Why are you running away from your family?"
    hk "....."
    mc "Don't be afraid, I can help you."
    scene lntwo131 with dissolve
    hk "They want to catch me."
    mc "To hurt you?"
    hk "No.."
    mc "We're not getting anywhere like this."
    mc "I'm bored on the floor."
    scene lntwo141 with dissolve
    mc "Go on."
    scene lntwo142 with dissolve
    hk "I don't trust him.."
    mc "Who?"
    scene lntwo145 with dissolve
    hk "The man here."
    mc "Don't worry, I'm pretty good at fighting. I can protect you."
    scene lntwo146 with dissolve
    hk "....."
    scene lntwo145 with dissolve
    mc "Come with me, stay with us tonight."
    scene lntwo147 with dissolve
    hk "Us?"
    mc "I'll spend the night with my [pD29] here. You can stay with us."
    scene lntwo141 with dissolve
    hk "Why are you spending the night at a motel like this with your [pD29]?..."
    mc "It's complicated."
    scene lntwo147 with dissolve
    hk "Uh-huh I'm sure..."
    hk "But that won't gonna work..."
    mc "Why?"
    scene lntwo142 with dissolve
    hk "I think this guy's a spy my dad sent."
    mc "Yeah... I don't think so."
    mc "His brain has turned into mashed potatoes. He thinks the wall is a tv."
    hk "Yeah, isn't that weird?"
    mc "Hmmm?"
    mc "It doesn't matter, I can protect you."
    scene lntwo148 with dissolve
    mc "Come let's go."
    hk "That's it?"
    hk "I've told you that I'm in a very unusual and dangerous situation, and you're going to protect me in the same room as your [pD29]."
    hk "What if I'm the danger?"
    scene lntwo149 with dissolve
    mc "Ahahaha, of course you are, kiddo."
    mc "Honey, your brain is a mashed potato too."
    hk "Asshole.."
    mc "Yeah, I'm the asshole."
    mc "Anyway, let's go."
    scene lntwo151 with dissolve
    hk "Wait."
    mc "What?"
    scene lntwo148 with dissolve
    mc "He's literally 1 meter away, I'm sure he heard everything we said."
    hk "Pfft, I know that."
    hk "But also, I know which drugs he took."
    mc "But you said you don't know?"
    hk "That was before I trusted you."
    mc "So now you trust me?"
    hk "Yeah, you want to take me to the same place as your [pD29]."
    mc "What if I'm lying?"
    hk "For what purpose? fucking me?"
    mc "Maybe more."
    hk "Nope, I trust myself in such situations."
    mc "So what did this guy get?"
    hk "A hallucinative drug, but the kind that affects the ears instead of the eyes."
    mc "And you know this how?"
    hk "Because I gave it to him."
    mc "What.."
    mc "Is he completely deaf?"
    hk "No, how can I explain?"
    hk "He can hear the moment you go near him and make him feel that you are talking to him."
    mc "What a strange drug."
    hk "Yeah, the raw material of this drug is used in interrogations."
    mc "And how do you know that, and why did you give this guy this drug?"
    hk "Forget about it for now."
    scene lntwo152 with dissolve
    hk "I have a plan."
    mc "Listening?"
    scene lntwo153 with dissolve
    hk "Fuck me."
    mc "Excuse me?"
    hk "Hmm, I think I'm losing my touch."
    hk "Okay, let's try it differently."
    scene lntwo154 with dissolve
    hk "Fuck me, daddy! "
    mc "Holy shit! "
    hk "Yeah dude, fuck me, remember what he said before?"
    mc "Yeah, I remember but, I can't do it with that guy here..."
    hk "Why not?"
    mc "I don't know.."
    hk "Awww, are you jealous?"
    mc "Pfft why should I be?"
    hk "Cuz he is gonna see my naked body."
    mc "No..."
    mc "I have an idea."
    scene lntwo155 with dissolve
    mc "Yo."
    jq "Huh, what?"
    mc "Dude, you are sitting on the toilet..."
    jq "Huh?"
    mc "I have to piss man, go inside."
    jq "Oh yeah, sorry, I think I'm distracted."
    scene lntwo156 with dissolve
    mc "Good boy.."
    scene lntwo157 with dissolve
    hk "Ahaha, that was fun."
    mc "He is so fucked up..."
    scene lntwo158 with dissolve
    hk "Anyway."
    hk "Now listen carefully."
    hk "After you cum."
    hk "Tell the man:"
    hk "Man, this slut is something else so hot and perky, I can't get enough of her, I'll take her to my room and fuck her sweet ass until morning."
    mc "You flattered yourself a little too much."
    hk "Maybe, but that's the truth."
    mc "Wait, if that's the plan, then we can do it without sex?"
    hk "Can you fuck me in front of your [pD29]?"
 ###   mc "Why Sex is so much in the plan"
    mc "How will it give us an advantage?"
    hk "Uhm, I'm horny and want to be fucked, and you are a dude."
    mc "So?"
    mc "Do you think we think about sex every minute?"
    hk "......"
    mc "Yeah, you're right... All right, I admit that even this sentence has affected me greatly.."
    hk "Cool."
    mc "So is there any limit?"
    hk "What limit?"
    mc "You know hardcore sex, anal sex, deepthroat, and other kinky stuff.."
    hk "Oh about that, I don't care, I'm super fucked up right now."
    hk "You can fuck anywhere in my body as hard as you want."
    mc "...."
    mc "I almost jizzed in my pants.."
    hk "I'm not that freaky actually but, the shit I took earlier was so strong and made me super horny.."
    mc "So you're a homegirl?"
    hk "No, but I'm not that freaky."
    mc "Well, I'm just a lucky guy then."
    hk "More like lucky man, because you're a little old."
   ## mc "I decided to fuck your throat so hard."
    hk "Good luck with that, old man."
    mc "Ugh.."
    hk "I'm really wondering how you're gonna perfo.."
    scene lntwo159ps with dissolve
    pause
    scene lntwo160 with dissolve
    mc "Let's begin, shall we."
    hk "Yes, daddy..."
    #scene  with dissolve
    #handjob
    mc "Let's get these little hands working."
    scene hjhbahego00 with dissolve
    mc "Good girl."
    scene hjhk
    menu:
        "Aheago":
            scene hjahea
        "no":
            pause
    mc "Very good, you're a fucking natural at this"
    hk " Mhmm."
    mc "Okay, that's enough, now wet my dick with your mouth bitch."
    scene mindisvan00 with dissolve
    mc "Oh nice..."
    mc "Your mouth is really amazing.."
    mc "So warm and wet.."
    mc "Now, I'm gonna fuck your throat!"
    scene mainthroatfc00 with dissolve
    mc "Fuck, this is amazing!"
    scene deeppntr
    mc "God damn girl, you take it like a champ..."
    mc "Fuck, I'm about to cum!"
    hk "Hold it, dude, it's so soon.."
    jq "What's that?"
    mc "Huh?"
    jq "I heard a girl's voice."
    mc "It's probably from the tv."
    jq "Oh yeah, right.."
    scene fetjb00 with dissolve
    mc "Okay, it's time for your feet"
    hk "Weirdo."
    scene fetj
    mc "Shut up."
    hk "So you admit you're a creep."
    mc "Fuck you bitch, I'm not a creep."
    hk "Pretty creepy to me."
    mc "Oh bitch.."
    mc "You have no idea what that feels like."
    hk "Does it really feel so good?"
    mc "Yeah."
    hk "Hand job or foot job?"
    mc "Is this the place for this kind of conversation?"
    hk "I was just curious."
    mc "They're both different and beautiful in their own ways."
    hk "If you had to choose one of the two, which one would you choose?"
    menu:
        "Hand job":
            mc "Handjob, because it has more usable space than feet."
            hk "Well, this is the right answer, you're not that creepy."
            mc "........."
        "Foot job":
            mc "Foot job, because I really like this feeling."
            hk "More than hands?"
            mc "Maybe, I don't know exactly, I just wanted to choose this."
            hk "Yup, you're a weirdo."
            mc "Fuck you."
            hk "Yeah, I'm waiting for you to fuck me."
    scene hrdcore11 with dissolve
    mc "Damn..."
    scene analhrdc
    menu:
        "close":
            scene anlclose
    mc "You are extremely tight.."
    hk "Ugh..."
    hk "You are so big... fuck, it hurts.."
    mc "Oh.."
    menu:
        "I can stop if you want":
            mc "If it really hurts, I can stop."
            hk "Well, it hurts yes, but it also gives me pleasure."
            hk "But it still fucking hurts..."
            mc "Okay then, I'm moving on to your pussy."
            hk "Classie.."
        "Good, scream bitch!":
            hk "Fuck!"
            hk "You're getting bigger."
            mc "Yup, you are tight and in pain. It's kinda hot."
            hk "Fucking creep!"
            mc "Want me to stop?"
            hk "If I say yes, will you?"
            mc "Nope, but I let you express yourself!"
            hk "Fuck!"
            hk "I don't want to admit it, but this feels so good.."
            mc "God damn, you're still tight.."
            hk "Yeah, because it hurts!"
            mc "That's good."
            hk "......"
            mc "Okay, I'm about to cum."
            hk "Okay... mmphhmmm."
            hk " I think ugh!"
            hk "That's.. enough.. aaah!"
            hk "We.. fuck.. it hurts..."
            hk "We can stop!"
            hk "Just cum already!"
            mc "That was fucking amazing."
            hk "My ass is burning..."
            mc "Oh yeah, it's burning alright."
            hk "Asshole.."
    scene sdecum1 with vpunch
    pause
    scene lntwo162 with dissolve
    hk "That was."
    mc "Amazing."
    hk "Exactly.."
    hk "Okay, he is coming."
    scene lntwo163 with dissolve
    jq "Damn, that was refreshing."
    scene lntwo164 with dissolve
    mc "Eww."
    mc "Did you wash your hands?"
    jq "What hands?"
    mc "Nothing.."
    scene lntwo166 with dissolve
    mc "So I decided to fuck her."
    scene lntwo167 with dissolve
    jq "Ma man!"
    jq "Okay, go for it, dude!"
    scene lntwo165 with dissolve
    mc "But not here."
    jq "Why is that?"
    mc "Is that a problem for you?"
    jq "Nah."
    mc "Cool."
    jq "Enjoy it."
    mc "Oh, I will."
    #a while later
    mc "Okay, I'm ready, get dressed up we're going"
    scene lntwo168 with dissolve
    hk "What're you looking at?"
    scene lntwo169 with dissolve
    mc "I don't know, reflex."
    hk "That's hot."
    mc "You're so young, everything is hot for you."
    hk "So true.."
    #a while later
    scene lntwo170 with dissolve
    pause
    scene lntwo171 with dissolve
    hk "Are you sure about that?"
    mc "About what?"
    hk "You don't know who I am..."
    hk "Well, you're right. Anyone would keep such a sexy chick close."
    mc "Hmm, I pick that one."
    mc "I want to keep this sexy chick close."
    mc "Is that okay for you?"
    hk "Hell yeah."
    mc "Cool, let's go."

#Out side
    scene lntwo172 with dissolve
    hk "You didn't say what we agreed."
    mc "Oh yeah, I forgot."
#    mc "Did you really need to hear that?"
    hk "Don't know..."
    mc "Is everything okay?"
    hk "Yeah, just.."
    mc "What?"
    hk "I pity the guy.."
    scene lntwo173 with dissolve
    menu:
        "He looks happy right now":
            hk "Right now, yes, but I wonder how his mood will be when he sobers up."
            mc "Why are you so worried, do you have feelings for him?"
            hk "As a person, yes, I'm really curious about his story."
            mc "You seemed sure he was your father's man."
            hk "What if he's not, what if he's someone who lives like this?"
            scene lntwo174 with dissolve
            mc "Believe me, there are countless people who are much worse off than this guy."
            mc "The only reason you're feeling bad right now is because you met one of them."
            mc "It's only when you meet one of them that you get that feeling. Even though you know they've always existed."
            mc "That's why we're so simple creatures."
            mc "Do you believe that charities set up for poor countries around the world take their work seriously??"
            mc "They can't realize how important their job is without living like them. I'm sure the bosses of big charities don't even know what the areas they're helping look like right now."
            hk "At least they help, even if they don't know."
            scene lntwo175 with dissolve
            mc "Ahaha, that's cute."
            mc "Do I need to remind you of the fact that most of the money raised goes to taxes, expenses?"
            hk "God damn, this world is so cruel..."
            mc "It always was, Mia..."
            hk "Who?"
            mc "Nothing, let's go."
        "Don't":
            scene lntwo174 with dissolve
            mc "This is the life he chose."
            mc "Don't feel sorry for someone who's trying to get back on drugs instead of getting his life back on track as soon as he wakes up."
            mc "Same goes with the people who make the same mistake over and over and learn nothing."
            mc "And you were sure that this guy was spying on you, where did this empathy come from?"
            hk "I don't know, I guess because I'm human."
            mc "So young and naive."
            mc "I feel like you're no stranger to such environments, how did you not lose your mind or even survive with this purity?"
            hk "That's a long story.."
            "Something tells me I have to reach this girl,"
            "but the important thing is Luna."
            "I've wasted a lot of time fucking."
            "Although it wasn't so wasted, she was fucking amazing in bed.."
            mc "Anway, let's go."
    scene lntwo176 with dissolve
    mc "What happened again?"
    scene lntwo177 with dissolve
    hk "I have to go.."
    scene lntwo178 with dissolve
    mc "To that junkie?"
    hk "No."
    hk "Somewhere else."
    mc "Sure, do you want me to take you where you want to go?"
    hk "No thanks."
    mc "Are you afraid of me?"
    hk "No."
    mc "Okay then."
    hk "You're not gonna stop me, are you?"
    scene lntwo179 with dissolve
    mc "Nope, I've had enough of these ridiculous games in high school."
    scene lntwo180 with dissolve
    mc "As you said before, I'm an old man."
    mc "And I'm too tired to run after young girls."
    scene lntwo181 with dissolve
    "It's an obvious lie, I'll never stop chasing young girls.."
    hk "It's not like that."
    scene lntwo182 with dissolve
    mc "Fine then, let me ask you one last question."
    mc "What's wrong... with you."
    hk "Wow, that's a really caring voice."
    hk "You must be very good at what you do."
    mc "..."
    hk "I..."
    hk "Can we sit first?"
    mc "Sure."
    scene lntwo183 with dissolve
    hk "Just like that huh."
    mc "Yup, just like that."
    scene lntwo184 with dissolve
    hk "I was in love."
    "Fuck..."
    scene lntwo185 with dissolve
    mc "Don't get me wrong,"
    mc "but it doesn't feel right to hear the girl I just fucked love another man."
    scene lntwo186 with dissolve
    hk "She was a girl."
    mc "Okay I'm fine with that."
    hk "......"
    mc "Just kidding, please go on."
    hk "You were not, I'm not stupid, but it's ok."
    hk "I can understand you."
    hk "Anyway."
    scene talksni
    hk "When I was a teenager,"
    mc "You mean last year?"
    hk "Seriously.."
    mc "I'm sorry, sometimes I can't help myself.."
    hk "In my family's eyes, I was like a project that had to be raised, according to their rules."
    hk "Every day was planned for me."
    hk "At first, I didn't mind so much, I even believed that this life was such a normal thing."
    hk "But over time, I got a feeling.."
    mc "A feeling of freedom."
    hk "Yes..."
    hk "Although this feeling was very strong, it was not stronger than the authority I accepted.."
    hk "So I started using the internet to at least suppress this feeling a little bit."
    hk "Ridiculous dating sites etc."
    hk "Then I met someone, it was a fake profile.."
    hk "Someone who spends her time making fun of people.."
    hk "I asked her questions because I was interested in this, why, how, etc."
    hk "I didn't expect her to take me seriously and respond, but she did."
    mc "I don't think anyone has ever deigned to ask these simple questions."
    hk "Exactly."
    hk "All of a sudden, she started answering these questions with enthusiasm, like she was waiting for someone to come and ask them."
    hk "And I didn't interfere in any way, I just read what she wrote."
    hk "After a while, she stopped writing."
    hk "As if she realized that she had made a big mistake."
    hk "Everything was too natural. A cautious person's momentary error and panic after realizing.."
    hk "I know it sounds ordinary, but at that moment I felt like I was communicating with a real person."
    hk "I was relieved that someone even told me about something I wasn't very interested in."
    hk "She wrote again a few days later."
    hk "She asked a question about me, I lied."
    hk "But not because I had to, I wanted to lie."
    hk "I wanted to experience the effects of it."
    hk "And I told her about it, and I think she started taking care of me after that."
    hk "We talked for months, sometimes 2-3 hours a day."
    hk "Of course, during this time, I was extra careful not to let my family know about the situation."
    hk "I could have lost the internet if they knew I was talking to someone outside the house like that."
    hk "And I felt.."
    hk "Fear, excitement, responsibility."
    hk "I realized that as a person, I had improved more than ever."
    hk "even so little dialogue would be enough for me."
    hk "But I started to want more."
    hk "I told her I wanted to see her."
    hk "She asked me why, and I said I wanted to see the real you."
    hk "She agreed and gave me an address."
    hk "She said we had to make a plan to run away from home together because I had told her before what kind of family life I had."
    hk "We made a plan by having fun together, and in a very strange way, everything went so well...."
    hk "I suddenly found myself waiting at the bus station."
    hk "I can't tell you my excitement, when the time came, when I got on the bus and sat down for the first time, suddenly everything started to feel more real."
    hk "Excitement and happiness had been replaced by anxiety and fear."
    hk "I began to think about what I would go through when I got home, thinking the worst-case scenario and the odds that the worst-case scenario would happen."
    hk "I did it for so long that when the bus came to the last stop, I felt like I had teleported there."
    hk "And when I got off the bus, all that fear and anxiety was gone, and that day I learned to live in the moment for the first time."
    hk "I learned true freedom from a wind that caressed my face like a silk fabric."
    hk "And I started walking towards the exact address, and every time I took a step, I felt like a hill was forming."
    hk "But it wasn't downhill or uphill, it was purgatory, neither difficult nor easy..."
    hk "I finally got to the exact address, and I realized I'd arrived a little earlier than we agreed."
    hk "I started waiting, but time didn't pass."
    hk "I finally saw someone, a very beautiful girl with long blonde hair."
    hk "That's when I found out She was a girl for the first time."
    hk "It didn't disappoint me, I wouldn't be happier if they were a man."
    hk "I came here just because it was her, and my excitement was rising every step she took towards me."
    hk "Every time she approached me, I felt like I was getting a little smaller."
    hk "She continued and stopped until half a meter remained between us."
    hk "I began to look involuntarily into her eyes, and I realized that this feeling could be nothing but love."
    hk "And I said those words without even gathering the courage to wait for her to make a single sentence."
    hk "I love you.."
    hk "I was so excited, I was thinking about a million things at once."
    hk "I found myself desperately waiting for an answer.."
    scene lntwo186 with dissolve
    hk "..........."
    mc "What happened next.."
    hk "........."
    hk "I..."
    hk "Have to go."
    scene lntwo187 with dissolve
    hk "Sorry.."
    mc "What.."
    mc "Hey.."
    scene lntwo189 with dissolve
    "That was so fucking weird..."
    "And then what happened, how did you get here?..."
    "Fuck, I want to know so bad.."
    "But can't go back.."
    "Luna..."
    "Fuck! I forget her"
    mc "I'm back."
    scene lntwo190 with dissolve
    mc "Luna!"
    mc "Where are you!"
    "I think she's in the bathroom"
    scene lntwo191 with dissolve
    pause
    scene lntwo192 with dissolve
    pause
    scene lntwo194 with dissolve
    pause
    scene black with dissolve
    scene lntwo195 with dissolve
    mc "I thought something had happened...."
    ln "Geez calm down, [pD14], I just took a shower."
    mc "Yeah, sorry.."
    ln "I'm out."
    ln "To be honest, I like it when you worry like that."
 ##   mc "Luna, be serious, I'm living like hell right now."
    ln "....."
    mc "And maybe get dressed?"
    ln "That's not what your eyes say."
    mc "Huh?"
    scene lntwo196 with dissolve
    ln "Nothing.."
    scene lntwo197 with dissolve
    ln "Tada, how do I look?"
    mc "Like when you hit me in the head with a baseball bat."
    ln "Hah, lame."
    #black screen
    scene lntwo198 with dissolve
    ln "You've been gone too long, and for a moment, I thought you'd left me."
    menu:
        "I fucked a junkie in a motel.":
            scene lntwo198 with dissolve
            ln "..."
            scene lntwo200 with dissolve
            ln "Ahahahaha."
            ln "Damn, [pD14].."
            ln "I didn't know you had such a sense of humor."
            mc "Aahaha yeah..."
        "The line was too long.":
            scene lntwo199 with dissolve
            ln "What a line, it took hours."
            mc "Yeah, weird."
            ln "Uh-huh.."
    scene lntwo201 with dissolve
    mc "Okay, now we are ready, we can begin."
    ln "Did you call my [pD31]?"
    mc "Yes, in the car."
    ln "How did she take it?"
    mc "Perfectly normal."
    ln "Cool."
    scene lntwo202 with dissolve
    ln "Uhmm.."
    mc "What now?"
    ln "You're going to be so angry with me, but.."
    mc "What did you do!"
    ln "I smoked weed while you were shopping."
    mc "What!"
    ln "I was over-stressed, I needed to relax..."
    ln "And you came so late, and I was bored."
    mc "Are you fucking kidding me, Luna!"
    mc "How can we talk like this."
    ln "No idea.."
    mc "I can barely stop myself right now."
    scene lntwo203 with dissolve
    ln "You want to beat me up, don't you?"
    scene lntwo204 with dissolve
    mc "No..."
    mc "I would never do such a thing.."
    scene lntwo205 with dissolve
    ln "Lies."
    scene lntwo206 with dissolve
    ln "Fucking lie.., isn't that what you want most right now?"
    mc "Don't be funny.."
    scene lntwo207 with dissolve
    ln "You have a respectable personality, you're good at what you do."
    ln "Everyone respects you."
    ln "When everything is going well, a [pD29] who comes out of nowhere puts you in this situation."
    scene lntwo208 with dissolve
    ln "Struck a blow on the head, and"
    ln "and on top of that, she's forcing you to stay in a shitty motel that's a home for whores and junkies."
    ln "Ugh... If I were you, I'd punch me until I passed out."
    scene lntwo211 with dissolve
    ln "C'mon hit me."
    mc "I'm not even gonna take you seriously and answer right now, Luna."
    ln "Don't be afraid."
    ln "And we'll be even, and I really want it."
    mc "How much weed did you smoke?"
    scene lntwo214 with dissolve
    ln "Ahaha, [pD14] you are so pure.."
    ln "It's not alcohol, some weeds knock you out in one breath, some don't knock you out even if you smoke a few ounces."
    scene lntwo210 with dissolve
    mc "Pfft, stop being a smart ass, you know what I mean."
    scene lntwo212 with dissolve
    ln "Yes, but you don't understand what I really mean."
    ln "I really want you to hit me."
    mc "Why?"
    scene lntwo213 with dissolve
    ln "Ugh, do you need a reason?"
    ln "Then."
    scene lntwo216 with dissolve
    ln "It's so hot."
    mc "What have you become?"
    scene lntwo215 with dissolve
    ln "Are you really gonna judge me?"
    ln "You fuck everything that walks, especially the young ones..."
    ln "Hey [pD14], how many younger than me have you fucked before?"
    mc "Luna!"
    ln "You freaky bastard."
    ln "Don't get me wrong, this is so hot for me."
    ln "You can be yourself, not gonna judge."
    ln "In fact, tell me about your freaky memories, and I'll touch myself in the meantime."
    scene lntwo210 with dissolve
    mc "Christ! Snap out of it! "
    scene lntwo209 with dissolve
    ln "Then hit me!"
    mc "No!"
    ln "Pussy!"
    scene lntwo222 with dissolve
    mc "Please don't."
    scene lntwo217 with dissolve
    ln "FUCKING PUSSY! "
    mc "STOP IT RIGHT NOW!"
    scene lntwo218 with dissolve
    ln "NO, I'M NOT GONNA STOP!"
    scene lntwo219 with dissolve
    ln "There is only one way to stop me!"
    scene lntwo220 with dissolve
    ln "C'mon, do it!"
    ln "Trust me, it will make you so hard, I can see the monster in your eyes!"
    ln "I don't know how you do it, but holding that monster captive is a big success."
    ln "Let him out!"
    scene lntwo221 with dissolve
    mc "Stop messing with my brain!"
    ln "Oh, we're getting somewhere."
    ln "You feel humiliated, Don't you?"
    scene lntwo223 with dissolve
    ln "A very young girl knocks you out in one shot."
    ln "It must be so embarrassing, how can you still call yourself a man?"
    ln "You know what I see when I look at you?"
    scene lntwo224 with dissolve
    mc "Stop."
    ln "A fucking coward."
    mc "Stop.."
    scene lntwo225 with dissolve
    ln "I bet I can kick your ass."
    mc "Stop....."
    ln "Still... oh my god, how much of a coward are you!"
    mc "STOP!"
    ln "Fuck you pussy!"
    scene lntwo226ps2 with vpunch
    play sound "audio/punch1.mp3"
    pause
    scene lntwo227 with dissolve
    pause
    scene lntwo228 with dissolve
    mc ".........."
    scene lntwo229 with dissolve
    mc "I can't believe you made me do this..."
    scene lntwo232 with dissolve
    ln "Finally.."
    scene lntwo233 with dissolve
    mc "Why did you do that!?"
    ln "Trust me, this is necessary."
    ln "You will understand me one day."
    scene lntwo237 with dissolve
    mc "I hit you.."
    mc "I fucking hit you.."
    scene lntwo234 with dissolve
    ln "Yeah and that was pretty good, you are really strong, [pD14]."
    scene lntwo235 with dissolve
    mc "Don't talk to me."
    mc "Luna, why did you do that?"
    scene lntwo238 with dissolve
    ln "Maybe I'm too high."
    ln "Maybe I'm a lunatic."
    scene lntwo239 with dissolve
    ln "Maybe because of a reason, the kind I can't tell you."
    mc "I'm risking everything for you, and look at the result?"
    ln "Honestly, I don't care, I really don't care what you're risking."
    ln "I think you should leave right now."
    mc "Huh?"
    scene lntwo240 with dissolve
    ln "Fuck the junkie in the downstairs room again and fuck Janet with the dick you didn't clean."
    ln "You can even fuck me before you go, it's like a threesome."
    mc "Please stop..."
    scene lntwo241 with dissolve
    ln "Pfft boring.."
    scene lntwo242 with dissolve
    ln "I was in an emotional void when I was in the car, and I think I said things that would have ridiculous meanings."
    ln "I know right now that what I said was not my true feelings."
    ln "Seriously, I don't want you anymore, you can go, we're cool."
    scene lntwo243 with dissolve
    mc "Seriously."
    ln "Yup."
    mc "Wait."
    mc "Is this your best acting?"
    scene lntwo244 with dissolve
    ln "What are you talking about?"
    mc "Do you think I don't understand what you're trying to do?"
    mc "Luna, I'm not stupid."
    scene lntwo245 with dissolve
    ln "Press x for doubt."
    mc "Be mature for once!"
    mc "I know what you're trying to do, stop it."
    mc "I can't believe I lost control and hit you."
    ln "...."
    ln "Fuck."
    scene lntwo246 with dissolve
    ln "I guess you won't leave."
    scene lntwo247 with dissolve
    ln "But I saw the monster inside you."
    mc "Everyone lives with a monster inside Luna."
    mc "There are specific circumstances that bring out that monster."
    ln "And I fucking find it."
    ln "But it was really hard."
    ln "Your self-control is something else."
    mc "Damn it, Luna, you made me hit you.."
    mc "Look at your face.."
    ln "Isn't that hot.."
    mc "Ugh, not again.."
    ln "....."
    mc "Do you have more?"
    ln "What?"
    mc "Weed."
    ln "Nope, I smoked my last joint while you were out."
    #####################################################################
    ln "Wait, Did you want to try it?.."
    mc "Of course not, I'm a teacher, remember?"
    ln "Oh yeah, I remember."
    mc "And I don't want to make this day to get any weirder."
    mc "This was enough for me."
    ln "Well, better than nothing."
    mc "I'm going to the bathroom."
    scene lntwo248 with dissolve
    "God damn, this place smells amazing.."
    "I wonder if she carries a perfumed shampoo with her..."
    scene lntwo249 with dissolve
    mc "Hey."
    mc "Who are they, Luna?"
    scene lntwo250 with dissolve
    ln "[pD14] calm down, it's all right, please don't do anything unnecessary."
    mc "Who are they?"
    scene lntwo251 with dissolve
    ln "Friends, there's something important about me."
    mc "What the fuck? have you forgotten why we're here?!"
    ln "Of course not.."
    scene lntwo252 with dissolve
    ln "Guys, this is my [pD14], and were kinda.. lovers."
    mc "Wha.."
    scene lntwo253 with dissolve
    ln "Don't worry my love, these people are reliable, I'm sure they won't reveal our secret."
    ln "Anyway, I'll take care of this for a while, and I'll see you again as soon as I'm done."
    ln "I have to go now, I hope you won't be mad at me, my love.."
    menu:
        "Don't let her go":
            mc "Wait."
            ln "What now?"
            mc "I'll come with you.."
            ln "Uhm, this is kind of a personal thing.."
            mc "No!"
            scene lntwo254 with dissolve
            tg1 "Don't be jealous old man, we need her brain, not her body."
            ln "Yeah, he is so jealous ahaha."
            mc "No, I'm not letting her go, she is mine."
            scene lntwo258 with dissolve
            tg1 "Luna, we're in a hurry."
            tg1 "Do you want me to handle him?"
            scene lntwo259 with dissolve
            pause
            scene lntwo260 with dissolve
            ln "If anything happens to him, our business could be at a dead end...."
            scene lntwo261 with dissolve
            tg1 "Did you just threaten me?"
            scene lntwo262 with dissolve
            ln "Let's call it more of a warning, I believe in our hieratic order, but within certain limits."
            scene lntwo263 with dissolve
            tg1 "Fine.."
            tg1 "Okay, let's go."
            scene lntwo264 with dissolve
            tg1 "Stay here until we get in the car. I don't trust this guy."
            tg2 "Sure thing."
            scene lntwo265 with dissolve
            mc "Fuck it!"
            mc "Give me back, Luna!"
            scene lntwo266 with dissolve
            ln "NOOOOOOOOOOOOOOOOOOOOO!!!!!{p=0.5}{nw}"
            scene black with vpunch
            play sound "audio/gunshot.mp3"
            tg1 "Fuck!"
            scene lntwo274 with Dissolve (3.0)
            tg2 "The fuck is wrong with you, sis!"
            scene lntwo275 with dissolve
            tg2 "Fuck fuck fuck!"
            tg2 "He said no blood!"
            tg1 "He was going to attack me."
            tg1 "Did you knock Luna out?"
            tg2 "No, she's in shock."
            tg2 "Fuck! find the casing and let's go."
            tg1 "What about him?"
            tg2 "He'll probably die, and if he survives, he'll know we have his girlfriend."
            tg1 "The best option is to kill him then."
            tg2 "I think he's already dead."
            tg1 "No."
            tg2 "He's gonna bleed to death. They can't get him to the hospital."
            tg1 "I can kill him with a pillow."
            tg2 "Just leave it, bro."
            tg1 "Yeah."
            scene lntwo274v2 with dissolve
            "So that's why she didn't want to go home."
            "She's really involved in dangerous things."
            "I think it all started when she hit me in the head, so she lied to me about why she hit me..."
            "Luna... What kind of trouble did you get yourself into?.."
            "Oh.. I see now."
            "Why are you trying to make me hit you.."
            "She knew I couldn't give up on her no matter what she did."
            "So she tried to make me hate herself as much as possible."
            "So when they found her, I would let her go."
            "That's pretty smart."
            "Damn, Luna... Even though you made a plan, considering that you will be found..."
            "I'm sorry, but I couldn't hate you."
            "So I proudly accept my end.."
            "I think this is the end for me."
            "I need a miracle."
            "Man this sucks..."
            "I wonder what my [pD5] are doing right now."
            "Although it's not hard to guess"
            "Emma's testing Janet's patience."
            "Nora's trying to put up with Claire's extreme positivity."
            "Ehehe..."
            "Live a good life, I love you so much."
            "Although I can't tell you these things right now, I'm sure you can feel them."
            "Goodbye...."

        "Let her go":
            scene lntwo253 with dissolve
            "Luna's making the right move right now."
            "I have to keep up with her."
            mc "Oh, okay then.."
            ln "I'm so sorry my love, but I promise I'll make it up to you."
            mc "Sure baby, it's your life."
            scene lntwo254 with dissolve
            tg1 "Seriously Luna."
            ln "What?"
            tg1 "I couldn't imagine you being such a love bug."
            scene lntwo253 with dissolve
            mc "Before you go, do you want me to come with you?"
            ln "Nah, I have my friend, they can protect me."
            "Stop [mcName]..."
            "Just follow her plan, she is smart."
            scene lntwo250 with dissolve
            mc "Are you sure?"
            "Fuck is wrong with me!"
            scene lntwo251 with dissolve
            tg1 "Yes she is, dude."
            "It's time to stop [mcName]"
            mc "..."
            mc "I'm not asking you."
            ln "......."
            tg1 "Luna..."
            scene lntwo252 with dissolve
            ln "I'm sorry, he is really protective."
            ln "It's okay, babe..."
            "This is my last chance I have to keep my mouth close."
            mc "You know what, I changed my mind."
            ln "Fuck..."
            tg1 "Huh?"
            scene lntwo255 with dissolve
            pause
            scene lntwo257 with dissolve
            mc "Luna, come here, you're not going anywhere."
            ln "Why..."
            mc "Because I.."
            scene lntwo258 with dissolve
            tg1 "I suggest we do it the easy way."
            scene lntwo259 with dissolve
            mc "Shut the fuck up, and give back my girl."
            scene lntwo260 with dissolve
            mc "Now."
            ln "Please don't hurt him, he really loves me, please."
            scene lntwo261 with dissolve
            tg1 "If you say one more word, second place will be yours."
            scene lntwo262 with dissolve
            ln "No..."
            ln "If you do that.."
            scene lntwo261 with dissolve
            tg1 "Shut the fuck up!"
            scene lntwo263 with dissolve
            tg1 "Okay show is over, time to go."
            scene lntwo264 with dissolve
            tg2 "......"
            scene lntwo265 with dissolve
            mc "Do you think you're powerful?"
            mc "Neither you nor that stupid son of a bitch standing behind you is my equal."
            mc "This is my last warning, let Luna go and get the fuck out of here."
            mc "Or I'll rip your little head off with my ha..."
            scene black with vpunch
            play sound "audio/gunshot.mp3"
            pause 1.0
            scene lntwo266 with Dissolve (3.0)
            tg1 "Back off!"
            scene lntwo267 with dissolve
            ln "No..."
            ln "No!"
            tg1 "Knock her out, we need her."
            ##########
            scene lntwo268 with dissolve
            pause
            scene lntwo269 with dissolve
            tg1 "Hah, you ain't so tough."
            tg1 "You were talking too big."
            tg1 "Fucking garbage."
            scene lntwo270 with dissolve
            mc "I."
            scene lntwo271 with dissolve
            tg1 "Oh, look at that!"
            tg1 "Fucking impressive."
            tg1 "He can still talk."
            tg1 "I what?"
            mc "Will"
            mc "Find you."
            mc "And murder you."
            tg1 "Do you really believe that?"
            tg1 "Or are you trying to look as tough as you can before you die?"
            tg1 "As if the second one makes more sense, doesn't it?"
            mc "Eheh."
            scene lntwo272 with dissolve
            tg1 "What's so funny asshole?"
            mc "It feels weird."
            tg1 "What feels weird."
            mc "For the first time in my life, I'm talking to a walking corpse."
            tg1 ".........."
            scene lntwo273 with dissolve
            tg1 "You know what, I'm not gonna kill you that fast."
            tg1 "I'll leave you like this."
            tg1 "I'd love to watch you die in pain, but watching garbage die slowly is a complete waste of time for me."
            tg1 "But don't worry, sometimes I'll think about you, how much you suffered."
            tg1 "So long garbage."
            tg1 "Oh, by the way, don't worry, I won't kill Luna, she is much more important to us than you can imagine."
            tg1 "But the punishment will be severe."
            tg1 "She'll probably be too traumatized to ever experience anything sexual again after the punishment she'll be given."
            tg1 "I wish I had the time to do it in front of you."
            tg1 "But as I said, my time is too valuable to deal with garbage like you."
            tg1 "Have fun."
            scene lntwo274v2 with dissolve
            "So that's why she didn't want to go home."
            "She's really involved in dangerous things."
            "I think it all started when she hit me in the head, so she lied to me about why she hit me..."
            "Luna... What kind of trouble did you get yourself into?.."
            "Oh.. I see now."
            "Why are you trying to make me hit you.."
            "She knew I couldn't give up on her no matter what she did."
            "So she tried to make me hate herself as much as possible."
            "So when they found her, I would let her go."
            "That's pretty smart."
            "Damn, Luna... Even though you made a plan, considering that you will be found..."
            "I'm sorry, but I couldn't hate you."
            "So I proudly accept my end.."
            "I think this is the end for me."
            "I need a miracle."
            "Man this sucks..."
            "I wonder what my [pD5] are doing right now."
            "Although it's not hard to guess"
            "Emma's testing Janet's patience."
            "Nora's trying to put up with Claire's extreme positivity."
            "Ehehe..."
            "Live a good life, I love you so much."
            "Although I can't tell you these things right now, I'm sure you can feel them."
            "Goodbye...."
    #s####♥
menu:
    "Emma":
        scene lntwo305 with dissolve
        mc "Oh, I didn't see you."
        scene lntwo306 with dissolve
        d3 "Stop acting [pD8]."
        d3 "I have an aura as bright as the sun, it's impossible that you didn't see me."
        mc "Of course, my bad sunshine, please forgive this helpless servant!"
        scene lntwo307 with dissolve
        d3 "Hmmm, I need to think about it."
        scene lntwo308 with dissolve
        d3 "Okay, I forgive you."
        d3 "But this is the last time!"
        mc "As your wish, my queen."
        scene lntwo309 with dissolve
        d3 "Hehe."
        mc "What was that?"
        scene lntwo306 with dissolve
        d3 "What was what?"
        mc "You laughed"
        d3 "No, I didn't."
        mc "Yes, you did."
        scene lntwo310 with dissolve
        d3 "I will burn you!"
        mc "Please don't burn me!"
        scene lntwo306 with dissolve
        d3 "I won't because I'm busy."
        mc "Thank you, your highness."
        mc "By the way, what are you doing at the computer?"
        d3 "Just admiring it."
        mc "Yeah, it's a great technology."
        d3 "Computers are a really great thing."
##         mc "Like?"
        d3 "I can see my beautiful reflection when I shut it"
        mc "Ahahaha "
        d3 "What's so funny about this!"
        mc "Nothing. I thought of a joke."
        d3 "Please don't tell me, your jokes are excessively repulsive..."
        mc "But this one is good."
        d3 "....."
        mc "C'mon, I know you're wondering."
        d3 "Okay, spit it out."
        mc "What’s Forrest Gump’s password?"
        d3 "Oh no...."
        mc "1forrest1"
        scene lntwo311 with dissolve
        d3 "I knew it!"
        d3 "Get out!"
        scene lntwo274v2 with dissolve
        "Ahaha, I remember this day very well. She pretended she didn't like it, but she loved my dad jokes.."
        "Yeah, she absolutely loved it..."
        #black screen
        scene lntwo312 with dissolve
        pause
        scene lntwo313 with dissolve
        d3 "Dad?"
        mc "What is it, sweetie."
        d3 "How's outside?"
        mc "Hmmm, that is a hard question."
        d3 "How so?"
        mc "I can't answer that question without going out."
        d3 "Ugh."
        scene lntwo314 with dissolve
        mc "Hey, be careful."
        scene lntwo315 with dissolve
        d3 "What should I be careful of, what could be the worst?"
        mc "Aliens."
        scene lntwo316 with dissolve
        d3 "Huh?"
        mc "They are everywhere. you know."
        scene lntwo317 with dissolve
        d3 "Pfft."
        mc "I'm serious."
        scene lntwo318 with dissolve
        d3 "Wait, really?"
        mc "Of course, we live on a tiny planet in an infinite void, what do you think are the chances that there will only be life on this planet/"
        scene lntwo319 with dissolve
        d3 "....."
        d3 "[pD8]..."
        mc "Yeah, in fact, I think they're probably already among us."
        d3 "Whaat???"
        mc "Of course, imagine an infinite civilization with more advanced technology than our current technology."
        mc "At least one of them may have sent an army to live among us to explore the world."
        d3 "Like who?"
        mc "Can be anyone."
        mc "Your Favorite Band, actor, classmate, or..."
        d3 "Or?..."
        mc "Or me.."
        d3 "....."
        mc "Ahahahah."
        scene lntwo320 with dissolve
        d3 "I HATE YOU!"
        d3 "I'm out!"
        mc "Watch out for aliens!"
        scene lntwo314 with dissolve
        d3 ".........."
        #black screen
        scene lntwo321 with dissolve
        mc "You're home early."
        scene lntwo322 with dissolve
        d3 "It's a sunny day. There's no wind, and the temperature is great."
        mc "Then why are you so sad?"
        scene lntwo323 with dissolve
        d3 "Because I couldn't find anything to whine about."
        mc "Ahaha, same old Emma."
        d3 "You're the old one."
        mc "Might be, but I'm happier than you."
        scene lntwo324 with dissolve
        d3 "Ignorance is bliss, [pD8]."
        mc "Eehheheh."
        "Ouch..."
        #Black screen
        scene lntwo325 with dissolve
        pause
        scene lntwo326 with dissolve
        pause
        scene lntwo327 with dissolve
        mc "Emma."
        d3 "What?"
        mc "Is there cheese in the fridge?"
        scene lntwo328 with dissolve
        d3 "Let me look."
        scene lntwo329 with dissolve
        "Yup, I'm not surprised he'll eat all the cheese left.."
        ###
        scene lntwo330 with dissolve
        d3 "No, we don't."
        mc "Oh good, cause that cheese was out of date, and I was gonna ask you to throw it away."
        scene lntwo331 with dissolve
        d3 "Wait, whaat?"
        mc "Ahaha kidding, babe."
        scene lntwo332 with dissolve
        d3 "I hate you!"
        scene lntwo274v2 with dissolve
        "I wish I was home right now, and you were making life difficult for me."
        "Fuck...."
        #black screen
        scene lntwo333 with dissolve
        pause
        scene lntwo334 with dissolve
        mc "Emma."
        d3 "What?"
        mc "Didn't you forget something?"
        scene lntwo336 with dissolve
        d3 "I don't forget anything."
        mc "You forgot my birthday..."
        scene lntwo337 with dissolve
        d3 "I didn't forget."
        d3 "I just didn't care."
        mc "Okay, that was cold!"
        scene lntwo338 with dissolve
        d3 "Hah, like I care."
        d3 "Leave me alone I have some shit to do!"
        scene lntwo337 with dissolve
        d3 "And don't look in the second drawer in your room."
        mc "Why?"
        d3 "No reason, I just like to impose bans on you."
        mc "Heh, fine."
        scene lntwo274v2 with dissolve
        "I remember this day. When I opened the drawer I saw a carefully packed birthday present."
        "I think it was the best birthday present I ever got..."
        #black screen
        scene lntwo339 with dissolve
        d3 "I hate it!"
        scene lntwo340 with dissolve
        d3 "I hate it, I hate it!"
        mc "Uh-huh.."
        mc "Honey."
        scene lntwo341 with dissolve
        d3 "What?"
        mc "I'm watching tv, and you're standing right in front of me."
        scene lntwo343 with dissolve
        d3 "....."
        mc "You know what? My bad."
        mc "Is everything all right?"
        scene lntwo342 with dissolve
        d3 "Today is Monday. A whole week starts on Monday. I hate Mondays. I wish there was never a day called Monday in the week..."
        mc "You know what, I can grant that wish."
        mc "...."
        mc "Done."
        scene lntwo344 with dissolve
        d3 "So?"
        d3 "No, Monday?"
        mc "Yup, exactly."
        scene lntwo345 with dissolve
        d3 "Cool..."
        scene lntwo346 with dissolve
        mc "Amazing."
        d3 "I hate it!"
        scene lntwo347 with dissolve
        mc "What now!"
        scene lntwo348 with dissolve
        d3 "Now the week starts with Tuesday."
        d3 "I hate Tuesday."
        mc "Oh great..."
        scene lntwo349 with dissolve
        d3 "I hate this stupid Tuesday!"
        "I have to destroy the concept of time to satisfy her..."
        scene lntwo274v2 with dissolve
        "Hahaha she always hated Mondays"
        "Nora used to be a lot more talkative."
        "I wonder why she's been quiet lately.."
        "Huh, I can't remember..."
        scene lntwo350 with dissolve
        pause
        scene lntwo351 with dissolve
        mc "Nora"
        scene lntwo352 with dissolve
        d2 "Yeah, [pD8]?"
        mc "Janet told me you've been eating too much lately."
        scene lntwo353 with dissolve
        d2 "And?"
        mc "And, that's not healthy"
        scene lntwo354 with dissolve
        d2 "[pD8], I've read a lot of books about human food culture."
        d2 "The amount of food I eat doesn't seem to be too much in any of them."
        d2 "And, yes, I considered my age in this statement. You puckered your lips like 'but at this age'."
        "Damn it"
        mc "...."
        mc "I forbid you to eat so much."
        d2 "Oh c'mon!"
        mc "Shush!"
        mc "I'm the [pD8], not you!"
        scene lntwo355 with dissolve
        d2 "Yes, [pD8]."
        scene lntwo356 with dissolve
        mc "Ehehe."
        scene lntwo357 with dissolve
        mc "Where Are you going? We were chatting."
        d2 "I'm hungry."
        mc "Seriously?"
        d2 "Yup."
        scene lntwo358 with dissolve
        mc "Nora."
        scene lntwo359 with dissolve
        mc "I can't believe you!"
        d2 "What?"
        mc "That jar was full."
        d2 "Define full."
        mc "Nora!"
        mc "Don't eat that!"
        d2 "Why, I've already eaten a big jar."
        mc "If you eat that, you'll die."
        scene lntwo360 with dissolve
        mc "........"
        scene lntwo361 with dissolve
        d2 "Ehehe."
        scene lntwo362 with dissolve
        d2 "I'm not dead."
        mc "Ugh..."
        scene lntwo274v2 with dissolve
        "She was always so smart, so talkative, a very happy, positive person..."
        "What happened, she suddenly turned into a quiet, emotionless person.."
        "How can I not remember something like that as a [pD4]?..."
        scene lntwo274v2 with dissolve
        "NO!"
        "I can't die this way!"
        "At least I can't die without remembering why Nora became like this."
        "I've given light to so many people up to this day."
        "But my [pD5] have always been my first priority."
        "I'm strong enough to remember what I need to remember most when I close my eyes to eternity.."
        "Remember"
        "Remember..."
        "REMEMBER!"
        scene black with dissolve
        scene lntwo363 with dissolve
        pause
        scene lntwo364 with dissolve
        pause
        scene lntwo365 with dissolve
        d2 "Woaw"
        "Fuck..."
        scene lntwo366 with dissolve
        d2 "I thought about all the possibilities, but I didn't think you'd really do it."
        mc "Nora, why are you up at this hour?"
        scene lntwo367 with dissolve
        d2 "I wouldn't be so surprised if a divine force descended on the earth right now and told me that religions are real."
        mc "Baby, are you okay?"
        d2 "I don't want to believe you're so weak."
        d2 "Even if the answer is right in front of me."
        scene lntwo368 with dissolve
        mc "Baby."
        d2 "Don't call me that."
        scene lntwo369 with dissolve
        d2 "After that girl's suicide, you didn't show it to anyone, you acted perfectly."
        d2 "You made me believe it for a moment."
        mc "Nora."
        scene lntwo370 with dissolve
        d2 "I knew you could think of that."
        d2 "But I really didn't think you'd do it."
        d2 "How naive I was."
        d2 "I've overestimated everything."
        d2 "Will, maturity, logic."
        d2 "And a [pD4]'s love for his [pD5]."
        mc "Don't say that."
        scene lntwo371 with dissolve
        d2 "Thank you, [pD8], you taught me the most important thing I need to learn."
        d2 "Maybe I knew it, but my heart wouldn't allow it."
        d2 "I understand much better now."
        mc "I'm sorry."
        scene lntwo372 with dissolve
        d2 "Hah, you already understand my current feelings, right?"
        mc "I always knew you were special."
        scene lntwo373 with dissolve
        d2 "Not that special, I guess."
        d2 "It hurts..."
        scene lntwo375 with dissolve
        mc "Do you think I don't know that?"
        mc "Can you imagine how much it hurts me?"
        mc "No matter how hard I tried, I couldn't."
        mc "I can't look you or your [pD6] in the face."
        scene lntwo374 with dissolve
        d2 "I'm not gonna tell you it wasn't your fault and try to talk you out of it.."
        d2 "Because it would be a lie."
        mc ".........."
        scene lntwo376 with dissolve
        d2 "You were weak, even though you knew what you had to do, you didn't do it."
        d2 "[pD8]."
        d2 "You're guilty."
        d2 "And yet."
        d2 "if I asked you to endure a little more pain and stay with us, what would you say?"
        mc "...."
        mc "I'm sorry."
        scene lntwo368 with dissolve
        d2 "Yes, you are, I can see that."
        mc "If I had another chance, at everything.."
        d2 "Why did you suddenly decide to lie?"
        d2 "So far, you've been honest."
        d2 "No, if you had another chance, it would be the same thing."
        d2 "[pD8]."
        d2 "You're weak."
        d2 "And to get stronger, you have to experience these losses."
        d2 "That's exactly why I hate you."
        d2 "For being weak."
        mc "I'm.."
        scene lntwo377 with dissolve
        d2 "sorry."
        scene lntwo378 with dissolve
        d2 "You're not as big as the mistakes you made."
        d2 "But you're not as small as the lies you tell, [pD8]..."
        scene lntwo379 with dissolve
        d2 "One day you'll come back, but some things won't be the same."
        d2 "Maybe it's supposed to be that way."
        d2 "But knowing that still doesn't help."
        scene lntwo377 with dissolve
        d2 "I..."
        mc "Goodbye."
        scene lntwo274v2 with dissolve
        "Now I remember why I can't remember."
        "Because I didn't want to remember.."
        "She was happier than Claire, more ill-tempered than Emma."
        "I'm the one who did this to her."
        "I'm a terrible [pD4]...."
        "I think I'm ready now.."
        "Goodbye for the last time, my [pD5].."
        "All three of you are very strong people.."
        "Always look out for each other."
        "Face all challenges together.."
        "Don't be weak like your [pD4].."
        "I love you..."
        #####
        scene lntwo276 with dissolve
        pause
        scene lntwo277 with dissolve
        hk "Oh no..."
        scene lntwo278 with dissolve
        pause
        scene lntwo279 with dissolve
        hk "Fuck, fuck, fuck!"
        hk "What should I do..."
        scene lntwo280 with dissolve
        hk "Hey! hey! "
        hk "I know you are still alive!"
        scene lntwo281 with dissolve
        hk "C'mon man, don't give up!"
        hk "I may not know you well enough, but I know you won't die that easily!"
        "Is she.."
        "What was her name.."
        "I'm a terrible person, I don't even know her name..."
        "Just let me die.."
        "I had my last reckoning with myself.."
        "Why are you giving me hope?"
        "I'm not gonna make it.. I know.."
        "But still.."
        "I want to see them again.."
        "Why are you causing this?"
        "Let me die in pain..."
        scene lntwo282 with dissolve
        hk "C'mon! "
        hk "Fuck! CPR seemed so easy in the movies!"
        "Huh, I wish I could talk, I could tell you I don't need CPR...."
        scene lntwo283 with dissolve
        hk "Open your eyes!"
        "Fine, I can do that.."
        scene lntwo284 with dissolve
        hk "Oh thank god!"
        hk "Good, you are still alive!"
        "Heh barely.."
        scene lntwo285 with dissolve
        hk "Look at my eyes!"
        hk "I'm not gonna let you die, okay?"
        "Why..."
        "I took advantage of you.."
        "Why are you trying so hard for me?..."
        scene lntwo281 with dissolve
        hk "Fuck what now.."
        hk "Oh, the blood!"
        hk "I have to apply pressure."
        hk "Stupid Felicia!"
        hk "I should have noticed that earlier!"
        "Hah, I know her name now."
        "It's a nice name, I liked it."
        "Nice to meet you, Felicia."
        $hk = Character("Felicia")
        scene lntwo286 with dissolve
        hk "Don't worry, I already called 911!"
        hk "I'm going to save you!"
        scene lntwo287 with dissolve
        hk "I promise."
        "Why.."
        "Why are you trying so hard."
        scene lntwo288 with dissolve
        hk "You've listened to me more carefully than anyone has."
        hk "You're a good person, you don't deserve to die like this."
        "Huh, as if she heard my question."
        "Funny, but I'm not a good person, sorry.."
        hk "Try to talk. You must be conscious. I guess it worked."
        hk "I don't know, man, that's what happened in the Movies, C'mon try it!"
        hk "I know you can hear me and understand me!"
        "I don't think I can, but still, I'll try."
        mc "Hehe."
        "Oh, I can still talk."
        scene lntwo286 with dissolve
        hk "Oh, thank god, thank god!"
        hk "You will be okay."
        mc "[mcName]."
        scene lntwo287 with dissolve
        hk "Nice to meet you, [mcName]..."
        mc "You.."
        mc "Sho..."
        mc "Should.."
        mc "stay away.."
        mc "..."
        mc "From me.."
        scene lntwo284 with dissolve
        hk "Fuck no!"
        mc "You stubborn bi.."
        mc "Bitch!"
        scene lntwo286 with dissolve
        hk "Ahaha, yeah, that's me..."
        hk "Fuck! You're bleeding.."
        scene lntwo281 with dissolve
        hk "What should I do.."
        hk "Should I burn the bleeding area? I saw that in a movie."
        "NO DON'T!"
        mc "Please.."
        mc "Don't!"
        hk "Okay, okay..."
        scene lntwo282 with dissolve
        hk "At least I need to keep you conscious, right?"
        hk "Okay, let's talk."
        hk "Until the ambulance arrives."
        hk "Ask me anything I will answer it, promise!"
        hk "No lies."
        mc "What happened?"
        hk "huh?"
        mc "What happened, afterward."
        hk "After what?"
        scene lntwo284 with dissolve
        hk "Oh right, I didn't complete my story"
        hk "All right, I'll tell you, but you have to listen, okay, don't close your eyes."
        scene lntwo287 with dissolve
        hk "I wonder if I should show you my tits, maybe it'll keep you from sleeping."
        "Yes, please!"
        scene lntwo284 with dissolve
        hk "Nah, it's stupid."
        "Oh c'mon!"
        scene lntwo287 with dissolve
        hk "Okay, here is what happened after that."
        hk "I was walking towards her."
        scene lntwo289 with dissolve
        pause
        scene lntwo290 with dissolve
        pause
        scene lntwo291 with dissolve
        pause
        scene lntwo292 with dissolve
        ffn "Huh, you really came."
        scene lntwo293 with dissolve
        hk "Yeah.."
        scene lntwo294 with dissolve
        hk "You look amazing.."
        scene lntwo295 with dissolve
        ffn "Thanks."
        scene lntwo296 with dissolve
        hk "Oh, are we going to take a selfie?"
        scene lntwo297 with dissolve
        ffn "Mm-hmm."
        scene lntwo298 with dissolve
        ffn "Hello Mr.Relish."
        ffn "She is in front of me right now."
        scene lntwo281 with dissolve
        hk "After that, she handed me the phone."
        scene lntwo300 with dissolve
        pause
        scene lntwo301 with dissolve
        hk "Yes.."
        ff "Now, do you understand?"
        ff "I control your whole world, you can't run away from me, you can't go beyond my wishes."
        ff "Let this be a lesson to you. Now, the girl in front of you will escort you home."
        ff "Don't try to play any more games."
        scene lntwo299 with dissolve
        hk "But.."
        hk "I thought.."
        ffn "Miss Relish, please don't overreact. I've been ordered to escort you home."
        hk "What about what we talked about?.."
        ffn "I'm sorry, Miss Relish, I was just doing as I'm told."
        hk "But...."
        scene lntwo298 with dissolve
        ffn "Oh, I think the phone's still on."
        ffn "Yes?"
        ffn "Sure."
        scene lntwo302 with dissolve
        ffn "This is for you Ms.Relish."
        scene lntwo303 with dissolve
        opr "You have reached your mobile phone spending limit.."
        $config.allow_skipping = False
        scene lntwo304 with dissolve
        opr "You also reached the end of this update."
        opr "Have a good day."
        #end of the v0.2
