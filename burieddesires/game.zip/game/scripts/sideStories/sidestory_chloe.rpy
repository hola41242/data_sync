
label Sidestorychloe:
    $save_name = "Side story: Chloe's Dream"
    stop music
    $mcName = renpy.input("What is your name?")
    $config.allow_skipping = True
    scene chl1 with fade
    pause
    scene chl2 with fade
    pause
    scene chl3 with fade
    pause
    att "Mhhm"
    att "Yes Ms. Gaby"
    scene chl4 with fade
    pause
    att "Yes, right away."
    att "Let me tidy myself up."
    scene chl5 with fade
    pause
    att "What the..."
    att "What are these"
    att "Who made me wear these?.."
    scene chl6 with fade
    pause
    att "Ms. Gaby?"
    att "Anyone?"
    scene chl7 with fade
    pause
    att "The hell is going on here.."
    att "there is no one around"
    att "Is that a prank?"
    att "Who did this?.."
    att "Olivia if you did this..."
    scene chl8 with fade
    pause
    att "Oh.."
    att "I feel sleepy.."
    att "But there's no time, I have to figure this out first"
    scene black
    scene chl9 with fade
    pause
    att "Hmmm still no one.."
    att "Don't be afraid, Chloe."
    att "Is it..."
    scene chl10 with fade
    pause
    att "Oh that's [mc]!"
    scene chl11 with fade
    pause
    att "Hey, I'm sorry you see me like this, but I have no idea what's going on."
    att "I think one of the girls made a prank on me and dressed me up like this."
    att "I woke up like this in Ms. Gaby's room"
    att "Do you have any idea what it is [mc]?"
    scene chl12 with fade
    pause
    att "Uhmmm"
    att "Are you mad at me?"
    att "Why are you ignoring me Mr.[mc]..."
    scene chl13 with fade
    pause
    att "Agh!"
    att "You're hurting me"
    att "[mc].."
    scene chl17 with fade
    pause
    att "Ms. Gaby!"
    scene chl15 with fade
    pause
    att "Ms. Gaby..."
    scene chl16 with fade
    pause
    att "Why are you dressed like that?.."
    scene chl14 with fade
    pause
    att "Did they make this joke on you too?"
    scene chl18 with fade
    pause
    att "I.."
    att "Don't understand"
    scene chl19 with fade
    pause
    att "I am scared..."
    scene chl20 with fade
    pause
    att "But I trust you with my heart."
    scene chl21 with fade
    pause
    att "..."
    scene chl22 with fade
    pause
    scene chl23 with fade
    pause
    sm "How are you feeling Chloe."
    att "Isn't it obvious, Miss Gaby?"
    att "I'm confused, feeling scared and.."
    sm "And?"
    att "..."
    att "Weird.."
    att "...."
    scene chl24 with fade
    pause
    att "Miss Gaby, Is everything okay?"
    sm "Just answer the question!"
    att "I'm sorry!"
    att "Uhmm.."
    att "I feel like.."
    sm "like an endless orgasm.."
    att "........"
    att "What's going on Miss Gaby.."
    scene chl25 with fade
    pause
    sm "Your skin is so soft.."
    att "Miss Gaby..."
    att "Please.."
    scene chl26 with fade
    pause
    sm "Can you feel my fingers on your skin, Chloe.."
    att "Yes.."
    sm "What does it feel like"
    att "...."
    scene chl27 with fade
    pause
    sm "Answer!"
    att "I feel amazing!"
    sm "Good"
    scene chl28 with fade
    pause
    sm "Do you want to feel better?"
    att "...."
    att "Yes Ms. Gaby.."
    scene chl29 with fade
    pause
    sm "So let's get rid of these."
    att "..."
    sm "Can you feel the eyes on you?"
    att "Yes.."
    sm "And do you feel what the owner of those eyes is doing?.."
    att "Yes Ms Gaby.."
    att "But I'm scared.."
    scene hmmmmmm_2

    sm "Don't"

    sm "Just let yourself go"
    att ".."
    att "I.."

    att "I can't."
    sm "You can, you have to.."
    att "But.."
    sm "Shut up"

    att "NO!"
    att "I will close my eyes and wake up"
    scene chl35 with fade
    pause
    scene chl36 with fade
    pause
    att "Phew.."
    scene chl37 with fade
    pause
    att "That was scary"
    att "And super realistic.."
    scene chl38 with fade
    pause
    att "Okay then let's work"
    att "..."
    scene chl39 with fade
    pause
    att "What I was working on.."
    att "What day was it today?.."
    att "Or year.."
    att "I can't remember anyhting.."
    scene chl40  with fade
    pause
    att "Oh fuck!"
    att "Am I still dreaming..."
    mc "You bet"
    att "Oh my"
    scene chl41 with fade
    pause
    att "You scared me [mc].."
    mc "You don't need to call me [mc], it's your dream"
    mc "You can call me whatever you want"
    scene chl42 with fade
    pause
    att "Yeah I know but still"
    att "That makes me different..."
    scene chl43 with fade
    pause
    mc "Don't you want to be someone else?"
    att "....."
    mc "Why are you afraid?"
    scene chl44 with fade
    pause
    att "I'm not afraid of anything, I'm just okay with who I am"
    mc "You're okay?"
    scene chl45 with fade
    pause
    att "Yes I am"
    mc "You are okay, but you don't love"
    att "What makes you think that?"
    mc "You said it. You're just okay with it, not loving it."
    att "Don't you think you're pushing your luck a little too much?"
    scene chl46 with fade
    pause
    mc "Don't know, ask yourself"
    mc "It's your subconscious that makes me ask these questions."
    att "Stop messing with my head"
    att "If you're my subconscious then tell me how to wake up"
    scene chl47 with fade
    pause
    mc "I think you know it"
    att "Ugh yeah I know cuz u are me.."
    mc "Not exactly"
    scene chl48 with fade
    pause
    att "What are you trying to say? Or do I have an extra consciousness?"
    att "Does this mean I've lost control?.."
    att "I can't believe this.."
    att "Now you're going to dramatically and slowly explain to me that you're taking control of my body, and in your last sentence, isn't my voice and vision gradually disappearing as I fall into a dark hole?..."
    scene chl49 with fade
    pause
    mc "Wow..."
    scene chl50 with fade
    pause
    att "I'm ready, do your thing."
    scene chl51 with fade
    pause
    mc "What is this?"
    att "This is my pose of accepting"
    scene chl52 with fade
    pause
    mc "Damn you are weird"
    mc "Calm down, I am here for help"
    mc "Yes I'm you, but different"
    att "How.."
    mc "Well you're looking at mc right now because you modeled him very well both in looks and personality"
    mc "That means you think too much of [mc]"
    scene chl53 with fade
    pause
    att "No!"
    att "I don't think of [mc] that often shut up!"
    mc "Uh huh"
    scene chl43 with fade
    pause
    mc "Anyway, As a result, you not only created me, you also added my personality."
    mc "Right now you're seeing the [mc] you really know"
    att "So, what now?"
    att "I slept, I thought I was awake but I'm still asleep and I modeled [mc] and made him talk"
    scene chl55 with fade
    pause
    att "Apparently I forgot to model shoes for myself."
    scene chl56 with fade
    pause
    mc "Hm What did you model instead?.."
    att "No idea"
    mc "I have some"
    att "..."
    scene chl57 with fade
    pause
    att "So how do I wake up?"
    scene chl58 with fade
    pause
    mc "This will sound cliché but"
    mc "Overcoming your fears."
    att "Seriously?"
    mc "Yeah.."
    scene chl59 with fade
    pause
    att "I don't have a fear"
    scene chl60 with fade
    pause
    mc "Being fucked?"
    scene chl61 with fade
    pause
    att "Jesus christ!"
    att "Language!"
    mc "Well this is your deepest desire. Your buried desire."
    scene chl62 with fade
    pause
    att "No shut up!"
    scene chl64 with fade
    pause
    att "What kind of madness is this?"
    att "I don't need anything from you"
    att "And obviously I don't need to deal with this bullshit to wake up"
    att "You know that I'm a very tidy person"
    att "If I'm sleeping, I've definitely set at least 3 alarms."
    att "I'll wake up with an alarm it's that simple"
    att "All I have to do is wait"
    mc "Hm"
    mc "Maybe I should be the one controlling the body.."
    att "Huh?"
    mc "We are in your brain cell"
    att "So?"
    mc "So there is no time"
    scene chl63 with fade
    pause
    att "It doesn't matter, I'm a patient person, I can wait no matter how long it takes"
    mc "There is no time literally.."
    mc "You can't wake up until you overcome your fear"
    scene chl65 with fade
    pause
    att "But this is a crime..."
    mc "If your brain is trying to get you to this point, something really isn't right."
    mc "Or it could just be an ordinary dream."
    mc "Maybe while I'm talking, your eyes will suddenly open and you'll wake up."
    scene chl66 with fade
    pause
    att "I'm confused..."
    mc "Well?"
    scene chl67 with fade
    pause
    att "Okey I'll do it"
    scene chl68 with fade
    pause
    att "What should I do tell... me?"
    mc "..."
    scene chl69 with fade
    pause
    att "I'm asking a question"
    att "Hey"
    scene chl70 with fade
    pause
    att "Hey voice in my head I'm asking you"
    mc "..."
    scene chl71 with fade
    pause
    att "Stop scaring me [mc]"
    scene chl72 with fade
    pause
    mc "You called me here, Chloe"
    mc "yes I am listening to you"
    scene chl73 with fade
    pause
    att "What are you talking about?"
    scene chl74 with fade
    pause
    mc "You called me to Gaby's room so I came"
    att "What the..."
    mc "Is everything okay Chloe?"
    att "You were just someone else"
    mc "I'm sure I'm me"
    att "..."
    mc "So?"
    scene chl75 with fade
    pause
    att "I think I got it"
    mc "Got what?"
    scene chl76 with fade
    pause
    att "Fuck it"
    att "I want you to.."
    mc "You want me to what?"
    scene chl77 with fade
    pause
    att "You know.."
    mc "No I don't"
    att "I want the thing"
    mc "Okay what is that thing?"
    att "The thing that you carry all the time.."
    mc "My wallet?"
    att "No.."
    att "It's your.."
    att "You know"
    scene chl78 with fade
    pause
    mc "I have no idea what r u talking about Chloe, I think you should come to me when you're sure"
    scene chl79 with fade
    pause
    att "Wait"
    scene chl80 with fade
    pause
    att "I wan't you to..."
    att "Fuck me.."
    scene chl81 with fade
    pause
    mc "Oh"
    mc "Sure"
    att "That's it?"
    mc "Yeah u are cute and hot"
    att "Oh okay.."
    "Wish Ms. Gaby was here so she could help me..."
    scene chl82 with fade
    pause
    sm "As your wish.."
    att "Of course.."
    scene chl83 with fade
    pause
    sm "Hey guys"
    att "..."
    scene chl84 with fade
    pause
    mc "Hey"
    sm "What're u guys doing in my office?"
    att "It's.."
    scene chl85 with fade
    pause
    mc "I'm about the fuck Chloe"
    att "No! It's complicated.."
    scene chl86 with fade
    pause
    sm "Oh how nice, I wish I had popcorn."
    scene chl87 with fade
    pause
    att "Okay..."
    att "Sometimes I forgot this is a dream.."
    mc "Okay then get undress"
    att "Oh.."
    att "Ms Gaby will watch?.."
    scene chl88 with fade
    pause
    sm "I can do more than watch."
    mc "It's not a bad idea, come here"
    mc "Her first time, I'm sure she needs a mentor"
    sm "This looks like a job for me"
    scene chl89 with fade
    pause
    att "I..."
    att "I'm so scared!"
    sm "That's good"
    att "How.."
    scene chl90 with fade
    pause
    sm "Fear is our most basic instinct, you can't imagine the pleasure you will get when you turn it into pleasure.."
    att "Oh my.."
    att "What will happen to me now.."
    scene chl91 with fade
    pause
    sm "Whatever the alpha wants.."
    scene chl92 with fade
    pause
    att "Oh my, oh my.."
    att "Mr. [mc] please be gentle I'm so scared.."
    sm "How cute.."
    sm "She is ready to go [mc]"
    sm "Do your thing"
    scene chl93 with fade
    pause
    att "......"
    scene chl94 with fade
    pause
    scene chl95 with fade
    pause
    att "OH MY GOD!"
    att "Oh my god!"
    scene chl96 with fade
    pause
    att "What is this feeling..."
    sm "Do you like it?"
    scene chl97 with fade
    pause
    scene hmmmmmm
    att "Yes yes yes!"
    sm "You little slut.."
    scene chl98 with fade
    pause
    att "..."
    #Animation
    sm "You act naive and pure but there's a dirty slut deep inside of you."
    sm "Look at you"
    sm "I bet you want more right"
    att "Mhhmmmm"
    sm "You can't even talk"
    sm "Good girl"
    sm "You deserve this.."
    sm "You work so hard, you gave up your pleasures from constantly trying to be productive"
    sm "Chloe"
    scene chl99 with fade
    pause
    att "..."
    sm "I'm proud of you"
    sm "I've never had an employee as good as you."
    scene chl100 with fade
    pause
    sm "And friend.."
    att "........."
    sm "You can wake up now"
    att "What..."
    sm "U did it"
    att "No.."
    att "I want to stay more please.."
    scene chl101 with fade
    pause
    scene chl102 with fade
    pause
    sm "Geez Chloe..."
    scene chl103 with fade
    pause
    scene chl104 with fade
    pause
    att "Ms Gaby!"
    scene chl105 with fade
    pause
    sm "Yes this is me"
    att "But you are dressed"
    scene chl106 with fade
    pause
    sm "Huh?"
    att "Uhm.."
    att "What happened.."
    sm "You slept while working"
    att "Oh.."
    att "Yeah..."
    att "I mean I'm so sorry!"
    att "I promise it won't happen again"
    sm "You are so cute"
    att "..."
    scene chl107 with fade
    pause
    sm "Just rest today, you seem so tired"
    att "Ahaha yeah a little.."
    scene chl108 with fade
    pause
    att "Aaah.."
    att "Such an amazing dream..."
    att "What am i saying.."
    att "Anyway, get to work"
    scene chl109 with fade
    pause
    sm "What did I tell you a minute ago!"
    scene chl110 with fade
    pause
    att "Yes Ms. Gaby sorry!"
    scene chl111 with fade
    pause
    #end of chloe act



















    return
