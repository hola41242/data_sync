﻿# The script of the game goes in this file.
init -3 python:
    persistent.patch_installed = False
# Declare characters used by this game. The color argument colorizes the
# name of the character.
define tp = Character ("therapist")
define mc = Character ("[mcName]")
define d1 = Character ("Claire")
define d2 = Character ("Nora")
define d3 = Character ("Emma")
define wf = Character ("Janet")
define ss = Character ("Amy")
define m1 = Character ("Mia")
define tw1 = Character ("Ava")
define tw2 = Character ("Olivia")
define sm = Character("Gaby")
define rb = Character("Ruby")
define att = Character("Chloe")
define ky = Character("Kayla")
define pg = Character("Tina")
define sy = Character("Zoey")
define ag = Character("Nora")
define st1 = Character(" ")
define sg = Character ("Sticker Girl")
define og = Character("Christian")
define tc1 = Character("Clara")
define gm = Character("Bill")
define ln = Character("Luna")
define pg3 = Character("girl 3")
define pg2 = Character("girl 2")
define pg1 = Character("girl 1")
define smg = Character("girl")
define hk = Character("girl")
define ffn = Character("girl")
define ff = Character("Felicia's father")
define opr = Character("Operator")
define hm = Character("girl")
define jq = Character("man")
define tg1 = Character("girl")
define tg2 = Character("man")
define dai = Character("Daisy")
define prg = Character("Portisha")
define mls = Character("Melissa")
define bdg = Character("Unknown")
define dr = Character("?")
define rcp = Character("Receptionist")
define gth1 = Character("Kimono Girl")
define gth2 = Character("?",color="#A020F0")
define rst = Character("Josh")
define csp1 = Character("Annie",color="#A020F0")
define csp4 = Character("?",color="#000000")
define csp3 = Character("?",color="#FF0000")
define csp2 = Character("?",color="#FFFFFF")
define rcr = Character("Reception",color="#FFFFFF")
define mskg = Character("Mask girl",color="#FFFFFF")
define smbs = Character("?",color="#FFFFFF")
define smbt = Character("?",color="#FFFFFF")
define smbg = Character("Smol",color="#FFFFFF")
define djg = Character("Dj",color="#FFFFFF")
define rbf = Character("Jerry",color="#FFFFFF")
define girl1 = Character("Girl",color="#FFFFFF")
define girl2 = Character("Girl",color="#FFFFFF")

$ slidedown = CropMove(1.0, "slidedown")
init:
    $ flash = Fade(.25, 0, .75, color="#fff")
# The game starts here.
label start:
    if twinsSideStory0:
        jump twSideStory0
    if SidestoryNightmare:
        jump Sidestorynightmare
    if SidestoryChloe0:
        jump Sidestorychloe
    else:
        $mcName = renpy.input("What is your name?")
        "All characters in this game are over 18 years old.\nThis game contains sexual content. You must be over eighteen years of age to play."
        if persistent.patch_installed == False:
            $pD8 = str(mcName)
            $pD11 = str(mcName)
            $pD13 = str(mcName)
            $pD14 = str(mcName)
            $pD16 = str(mcName)
            $pD22 = str(mcName)
            $pD43 = str(mcName)
        menu:
            "I'm over 18":
                "Great!"
                "Enjoy the game!"
            "I'm not over 18":
                $renpy.quit()

        # Show a background. This uses a placeholder by default, but you can
        # add a file (named either "bg room.png" or "bg room.jpg") to the
        # images directory to show it.
        play music "audio/bensound-tenderness.mp3"
        #jump v03
        jump prologue

        # This shows a character sprite. A placeholder is used, but you can
        # replace it by adding a file named "eileen happy.png" to the images
        # directory.


        # These display lines of dialogue.

        # This ends the game.

    return
