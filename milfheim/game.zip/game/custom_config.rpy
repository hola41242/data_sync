



define imfelldwpica_font = "fonts/IMFellDWPica/IMFellDWPica-Regular.ttf"
define noto_font = "fonts/noto/noto_regular.ttf"
define notok_font = "fonts/noto/notok_regular.ttf"









define gui.interface_text_font = noto_font

define gui.accent_color = "#ffffff"

define gui.text_font = noto_font

define gui.text_color = "#ffffff"

style textbutton_choice_text is button_text


style button_text font noto_font
style button_text idle_color "#ffffff"
style button_text hover_color "#ee4037"
style button_text selected_color "#ee4037"

style chapter_selected_text_style is button_text:
    size 26
    color "#ee4037"
    bold True

style chapter_unselected_text_style is button_text:
    size 22
    color "#FFFFFF"
    hover_color "#ee4037"


style pagination_number_style is default:
    font noto_font
    bold True
    size 26
    idle_color "#FFFFFF"
    hover_color "#ee4037"
    selected_color "#FFFFFF"


style say_window xalign 0.5
style say_window xsize 1500
style say_window ysize 250
style say_label color "#ffffff" outlines [ (5, "#ffff", 0, 0), (4, "#111", 0, 0) ]
style say_label font imfelldwpica_font
style say_label size 45
style say_label text_align 0.0
style namebox padding (0, 0, 0, 0)
style say_dialogue size 35
style say_dialogue adjust_spacing True

define gui.name_xpos = 0.0
define gui.name_ypos = 0.05
define gui.dialogue_xpos = 0.0
define gui.dialogue_ypos = 0.25
define gui.namebox_borders = Borders(3, 0, 3, 17, 10, 0, 10, 0)
define gui.namebox_tile = True
define gui.namebox_height = 55


image ctc:
    "gui/ctc.png"
    zoom 1.0
    offset (10, 10)
    easein 1.0 offset (10, 15)
    easein 1.0 offset (10, 10)
    repeat


style nvl_label size 35
style nvl_label yalign 0.0
style nvl_dialogue size 27
style nvl_dialogue adjust_spacing True
style nvl_dialogue yoffset 30
style nvl_button_text size 27

define gui.nvl_height = None
define gui.nvl_spacing = 30
define gui.nvl_borders = Borders(75, 75, 75, 75, 0, 0, 0, 0)
define gui.nvl_name_xpos = 0.3
define gui.nvl_name_xalign = 0.0
define gui.nvl_text_xpos = 0.3
define gui.nvl_text_width = 720
define gui.nvl_thought_xpos = 0.3
define gui.nvl_thought_width = 720
define gui.nvl_button_xpos = 0.3


style quick_button_text:
    idle_color "#ffffff"
    hover_color "#ee4037"
    selected_color "#ee4037"
    insensitive_color "#4b4b4b"

define gui.quick_button_text_font = noto_font
define gui.quick_button_text_size = 25

style quick_button_text:
    variant "small"
    size 40


define gui.frame_borders = Borders(43, 43, 43, 43, 20, 20, 20, 20)


style confirm_button ysize 25
style confirm_prompt_text color "#ffffff"
define gui.confirm_frame_borders = Borders(43, 43, 43, 43, 50, 30, 50, 30)

style choice_button_text:
    yalign 0.5

define gui.choice_button_text_font = noto_font
define gui.choice_button_height = 70
define gui.choice_button_text_idle_color = "#bdbdbd"
define gui.choice_button_text_hover_color = "#ee4037"

style nvl_button:
    ysize 30
    padding (0, 0)
    hover_background "#dedede"


style notify_frame padding (30, 10, 60, 10)
style notify_text font noto_font
style notify_text color "#ffffff"

define gui.notify_frame_borders = Borders(0, 7, 65, 7)


style skip_frame padding (30, 10, 60, 10)
style skip_triangle line_spacing 0
style skip_triangle line_leading 0
style skip_text color "#ffffff"

define gui.skip_frame_borders = Borders(0, 7, 65, 7)




style navigation_button size_group None
define gui.navigation_spacing = 10

style navigation_button_text:
    idle_color "#ffffff"
    hover_color "#ee4037"
    font noto_font
    size 40


style game_menu_navigation_frame:
    xsize 0
    background "gui/sub_menu_background.png"
    yoffset -30

style game_menu_label_text:
    font noto_font
    size 65

style game_menu_label:
    xalign 0.435
    xsize 1300
    yalign 0.05
    xanchor 0.0
    ysize 90
    top_padding 40
    bottom_padding 10
    left_padding 20
    right_padding 20


style vscrollbar:
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", Borders(10, 10, 10, 10, 0, 0, 0, 0))
    thumb "gui/scrollbar/vertical_[prefix_]thumb.png"
    thumb_offset 13
    top_gutter 10
    bottom_gutter 10
    xsize 38

style scrollbar:
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", Borders(10, 10, 10, 10, 0, 0, 0, 0))
    thumb "gui/scrollbar/horizontal_[prefix_]thumb.png"
    thumb_offset 13
    left_gutter 10
    right_gutter 10
    ysize 38


define gui.bar_borders = Borders(15, 15, 15, 15)
define gui.vbar_borders = Borders(15, 15, 15, 15)

style bar ysize 31


style game_menu_content_frame:

    left_margin 0
    xfill True

style game_menu_side:
    xpos 350

    ysize 700


style radio_button_text:
    selected_color "#ffffff"
    line_leading -10

style radio_button left_padding 40

style check_button_text:
    selected_color "#ffffff"
    line_leading -10

style check_button left_padding 40


style page_label yalign -0.05
style slot_button_text:
    insensitive_color "#dedede"
    idle_color "#ffffff"

style slot_grid:
    yspacing -20
    yoffset -10


style help_text:
    color "#ffffff"


style about_text color "#ffffff"


style history_text color "#ffffff"
style history_text size 30
style history_name xsize 180
style history_name_text text_align 0.5
style history_name_text minwidth 180
style history_name_text size 30
style history_name_text left_padding 20
style history_window xfill False
style history_window ysize None
style history_window ymargin 20

define gui.history_height = None


style return_button idle_background "gui/back_idle_button.png"
style return_button hover_background "gui/back_hover_button.png"
style return_button left_padding 50
style return_button top_padding 0
style return_button xalign 0.1
style return_button yalign 0.14
style return_button xsize 190
style return_button_text yalign 0.5
style return_button_text line_leading -15


style slider:
    thumb_offset 13
    left_gutter 10
    right_gutter 10
    right_bar "gui/slider/horizontal_reveal_bar.png"

style vslider:
    thumb_offset 13
    top_gutter 10
    bottom_gutter 10

define gui.slider_tile = True
define gui.slider_size = 38

style narration_text_style is say_dialogue:
    font imfelldwpica_font
    size 30
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
