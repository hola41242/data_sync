default selected_location = "boarding_house"

define character_data = {

    "helen": {
        "name": "h_name",
        "age": "4?",
        "job": "Photographer",
        "icon": "images/character_bio/helen_icon.png",
        "bio_image": "images/character_bio/helen_bio.jpg",

        "info": [
            {
                "text": "This is [h_name]. She is a woman who manages tenants and also works.She is divorced from her husband, and her children have all become independent.",
                "condition": None,
            },
            {
                "text": "She struggles with alcoholism. In her free time, she enjoys relaxing on a chair in the backyard while listening to music.",
                "condition": "ch02_started",
            },
            {
                "text": "She went through major incidents and struggled, but recently returned to a normal life. Letting [d_name] into her home is a sign that she is ready to take care of someone again.",
                "condition": "ch03_started",
            },
            {
                "text": "She runs a photography studio. It appears she used to shoot photos bordering on pornography in the past, and she certainly has no hesitation when it comes to wearing revealing outfits.",
                "condition": "ch04_started",
            },
            {
                "text": "Ivy introduced her to a man, but she ended up getting so drunk that she made a fool of herself and passed out. She also caused a drunken scene in front of her tenant, [d_name]. She hasn't forgotten what happened. In her mind, it's almost like a debt.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_helen",
        "love": "love_helen",
        "sus": "sus_helen",
    },

    "sophia": {
        "name": "Sophia",
        "age": "5?",
        "job": "Professor",
        "icon": "images/character_bio/sophia_icon.png",
        "bio_image": "images/character_bio/sophia_bio.jpg",

        "info": [
            {
                "text": "She is a psychology professor. And she has another side job for her own satisfaction.She has narcissistic traits and is obsessed with maintaining her figure.",
                "condition": None,
            },
            {
                "text": "She strictly manages her physique. The reason is that she has another job besides being a professor.",
                "condition": "ch03_started",
            },
            {
                "text": "Her side hustle is lingerie modeling, and she has worked with [h_name] for a long time. This gig serves as an outlet to satisfy her own narcissistic desires.",
                "condition": "ch04_started",
            },
            {
                "text": "She did a nude photoshoot with [d_name]. The highly explicit shoot with her own student left her utterly exhausted. She was also deeply impressed by [d_name]'s manhood, and the impression has stayed with her ever since.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_sophia",
        "love": "love_sophia",
        "sus": "sus_sophia",
    },

    "amanda": {
        "name": "Amanda",
        "age": "5?",
        "job": "Housewife",
        "icon": "images/character_bio/amanda_icon.png",
        "bio_image": "images/character_bio/amanda_bio.jpg",

        "info": [
            {
                "text": "She always tries to take care of [d_name].She is cheerful and enjoys making quirky and sexual jokes.",
                "condition": None,
            },
            {
                "text": "She reunited with [d_name] after a long time, and once again realized that he has grown into a well-built man.",
                "condition": "ch03_started",
            },
            {
                "text": "The tension between her and Frank is reaching a breaking point. It is taking a serious toll not only on her daily life, but on her sex life as well.",
                "condition": "ch04_started",
            },
            {
                "text": "She became sexually aroused by [d_name]'s massage.",
                "condition": "ch05_started",
            },
            {
                "text": "For the first time, she has seen the house where [d_name] lives.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_amanda",
        "love": "love_amanda",
        "sus": "sus_amanda",
    },

    "mary": {
        "name": "Mary",
        "age": "5?",
        "job": "Youth Center Director",
        "icon": "images/character_bio/mary_icon.png",
        "bio_image": "images/character_bio/mary_bio.jpg",

        "info": [
            {
                "text": "She was [d_name]'s youth center teacher, a beautiful middle-aged woman both inside and out.",
                "condition": None,
            },
            {
                "text": "She feels that her marriage with her husband is gradually falling apart—especially their sex life.",
                "condition": "ch02_started",
            },
            {
                "text": "She is in shock after seeing the explicit photo that [d_name] sent via text. Since then, she has been looking at the photo every day.",
                "condition": "ch03_started",
            },
            {
                "text": "She gave [d_name] a blowjob, which completely shifted the dynamic of their relationship. This is just the beginning for the two of them.",
                "condition": "ch04_started",
            },
            {
                "text": "She sent [d_name] a nude photo of herself. Their relationship has entered a new phase, and [d_name] will become even bolder from here on.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_mary",
        "love": "love_mary",
        "sus": "sus_mary",
    },

    "celine": {
        "name": "Celine",
        "age": "2?",
        "job": "Youth Center worker",
        "icon": "images/character_bio/celine_icon.png",
        "bio_image": "images/character_bio/celine_bio.jpg",

        "info": [
            {
                "text": "She is a staff member at the Milfheim Youth Center, and a childhood friend of [d_name].",
                "condition": None,
            },
            {
                "text": "She witnessed [d_name] and Mary engaging in more physical intimacy than necessary and began to suspect something.",
                "condition": "ch02_started",
            },
            {
                "text": "She accidentally discovered an explicit photo of [d_name] on Mary's computer. She is now certain that Mary and [d_name] are having a sexual relationship.",
                "condition": "ch04_started",
            },
            {
                "text": "While spending time with [d_name] at a bar, she ended up seeing his penis. Now she sees him in a completely different light. She's also begun to feel a strange sense of rivalry toward Mary.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_celine",
        "love": "love_celine",
        "sus": "sus_celine",
    },

    "beth": {
        "name": "Beth",
        "age": "3?",
        "job": "A housekeeper in Helen's neighborhood.",
        "icon": "images/character_bio/beth_icon.png",
        "bio_image": "images/character_bio/beth_bio.jpg",

        "info": [
            {
                "text": "She works as a housekeeper for the local area, including Helen's house.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_beth",
        "love": "love_beth",
        "sus": "sus_beth",
    },

    "emma": {
        "name": "Emma",
        "age": "5?",
        "job": "Masseuse",
        "icon": "images/character_bio/emma_icon.png",
        "bio_image": "images/character_bio/emma.jpg",

        "info": [
            {
                "text": "She runs a small massage shop with one employee. Frank is a regular at her massage parlor.",
                "condition": None,
            },
            {
                "text": "She despises Frank, but since he regularly spends money at her massage parlor, she has little choice but to maintain ties with him.",
                "condition": "ch06_started",
            },
            
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_emma",
        "love": "love_emma",
        "sus": "sus_emma",
    },

    "olivia": {
        "name": "Olivia",
        "age": "4?",
        "job": "Restaurant Owner",
        "icon": "images/character_bio/olivia_icon.png",
        "bio_image": "images/character_bio/olivia_bio.jpg",

        "info": [
            {
                "text": "She is Amanda’s younger sister and runs an Italian restaurant named after herself.",
                "condition": None,
            },
            {
                "text": "She reunited with [d_name] after a long time. She has been making advances toward him as an adult, becoming increasingly direct with her flirting.",
                "condition": "ch03_started",
            },
            {
                "text": "She is currently going through a divorce and is staying at a cabin she acquired from her husband. Her newfound freedom is gradually loosening her moral restraints.",
                "condition": "ch04_started",
            },
            {
                "text": "At the mountain cabin, she kissed [d_name] while wrapped in his arms. She also gave him a handjob for the first time.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_olivia",
        "love": "love_olivia",
        "sus": "sus_olivia",
    },

    "lena": {
        "name": "Lena",
        "age": "4?",
        "job": "Graphic Designer & Writer",
        "icon": "images/character_bio/lena_icon.png",
        "bio_image": "images/character_bio/lena_bio.jpg",

        "info": [
            {
                "text": "She has been [h_name]’s friend for a long time. However, a certain turn of events led her into a physical relationship with [h_name], and now they are also tied together through their work.",
                "condition": None,
            },
            {
                "text": "She met [d_name] at [h_name]’s house. By chance, she saw him exposed and was struck with shock and excitement.",
                "condition": "ch03_started",
            },
            {
                "text": "She got a taste of [d_name]'s cock. A mouthful, in fact. And she doesn't feel the slightest bit guilty toward [h_name], who is both her friend and lover.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_lena",
        "love": "love_lena",
        "sus": "sus_lena",
    },

    "diana": {
        "name": "Diana",
        "age": "4?",
        "job": "Violent Crimes Detective",
        "icon": "images/character_bio/diana_icon.png",
        "bio_image": "images/character_bio/diana_bio.jpg",

        "info": [
            {
                "text": "She is a Violent Crimes detective driven by a strong sense of justice. After earning the rank of team leader, she was assigned to the Milfheim Hills Police Station.",
                "condition": None,
            },
            {
                "text": "She has reunited with Owen, her former subordinate on the force. With this, she opens the second chapter of her career in law enforcement right here in Milfheim Hills.",
                "condition": "ch04_started",
            },
            {
                "text": "She has begun her duties as the head of the Violent Crimes Unit at the Milfheim Police Department. However, she's already encountered an unexpected obstacle: an authoritarian police chief who has tried to touch her inappropriately. She's also opened a mysterious case file bearing [d_name]'s name.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_diana",
        "love": "love_diana",
        "sus": "sus_diana",
    },

    "rose": {
        "name": "Rose",
        "age": "5?",
        "job": "Marketing Agency CEO",
        "icon": "images/character_bio/rose_icon.png",
        "bio_image": "images/character_bio/rose_bio.jpg",

        "info": [
            {
                "text": "She is the CEO of a marketing agency. She’s a woman with incredible charisma.She is best friends with Mary.",
                "condition": None,
            },
            {
                "text": "After the interview, she decided to hire [d_name].",
                "condition": "ch05_started",
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_rose",
        "love": "love_rose",
        "sus": "sus_rose",
    },

    "alessia": {
        "name": "Alessia",
        "age": "2?",
        "job": "Office Worker",
        "icon": "images/character_bio/alessia_icon.png",
        "bio_image": "images/character_bio/alessia_bio.jpg",

        "info": [
            {
                "text": "She works for Rose's advertising company. She and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_alessia",
        "love": "love_alessia",
        "sus": "sus_alessia",
    },

    "anna": {
        "name": "Anna",
        "age": "4?",
        "job": "?",
        "icon": "images/character_bio/anna_icon.png",
        "bio_image": "images/character_bio/anna_bio.jpg",

        "info": [
            {
                "text": "She is an unknown figure.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_anna",
        "love": "love_anna",
        "sus": "sus_anna",
    },

    "chloe": {
        "name": "Chloe",
        "age": "2?",
        "job": "Office Worker",
        "icon": "images/character_bio/chloe_icon.png",
        "bio_image": "images/character_bio/chloe_bio.jpg",

        "info": [
            {
                "text": "She works for Rose's advertising company. She and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_chloe",
        "love": "love_chloe",
        "sus": "sus_chloe",
    },

    "ethan": {
        "name": "Ethan",
        "age": "3?",
        "job": "Detective",
        "icon": "images/character_bio/ethan_icon.png",
        "bio_image": "images/character_bio/ethan_bio.jpg",

        "info": [
            {
                "text": "He is a detective with the Milfheim Police Department. He works out at the gym run by Ivy almost every day.",
                "condition": None,
            },
            {
                "text": "He has just started working under his new boss, Diana. He seems wary of her, but at the same time, he also seems to like her.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_ethan",
        "respect": "respect_ethan",
        "rivalry": "rivalry_ethan",
    },

    "evan": {
        "name": "Evan",
        "age": "2?",
        "job": "Police Officer",
        "icon": "images/character_bio/evan_icon.png",
        "bio_image": "images/character_bio/evan_bio.jpg",

        "info": [
            {
                "text": "He is a police officer with the Milfheim Police Department. He is a rookie cop.",
                "condition": None,
            },
            {
                "text": "He has just started working under his new boss, Diana. The moment he laid eyes on her, he began entertaining the far-fetched dream of falling in love with her.",
                "condition": "ch06_started",
            },
            
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_evan",
        "respect": "respect_evan",
        "rivalry": "rivalry_evan",
    },

    "evelyn": {
        "name": "Evelyn",
        "age": "2?",
        "job": "Youth Center worker",
        "icon": "images/character_bio/evelyn_icon.png",
        "bio_image": "images/character_bio/evelyn_bio.jpg",

        "info": [
            {
                "text": "She works at Mary's Youth Center. She started working there fairly recently, so she and [d_name] don't know each other.",
                "condition": None,
            },
            {
                "text": "She caught [d_name] sneaking into the youth center. Since then, she's become wary of him.",
                "condition": "ch06_started",
            },
            
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_evelyn",
        "love": "love_evelyn",
        "sus": "sus_evelyn",
    },
    "frank": {
        "name": "Frank",
        "age": "6?",
        "job": "Salesman",
        "icon": "images/character_bio/frank_icon.png",
        "bio_image": "images/character_bio/frank_bio.jpg",

        "info": [
            {
                "text": "He is Amanda's husband. They met as children and have been together ever since. He enjoys going out drinking and hitting the local nightlife. He has no idea where his marriage to Amanda is heading. He also dislikes [d_name] for no particular reason.",
                "condition": None,
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_frank",
        "respect": "respect_frank",
        "rivalry": "rivalry_frank",
    },

    "harold": {
        "name": "Harold",
        "age": "6?",
        "job": "Police Chief",
        "icon": "images/character_bio/harold_icon.png",
        "bio_image": "images/character_bio/harold_bio.jpg",

        "info": [
            {
                "text": "He is the Chief of the Milfheim Police Department. He is a former military man who served in operations in the Middle East and South America. He later transitioned into law enforcement and built an exceptional career with years of experience. He became Chief of the Milfheim Police Department at a relatively young age.",
                "condition": None,
            },
            {
                "text": "He seems to have taken a special interest in Diana. Almost as if he's looking to add another trophy to his display case.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_harold",
        "respect": "respect_harold",
        "rivalry": "rivalry_harold",
    },

    "isabella": {
        "name": "Isabella",
        "age": "4?",
        "job": "Diner Owner",
        "icon": "images/character_bio/isabella_icon.png",
        "bio_image": "images/character_bio/isabella_bio.jpg",

        "info": [
            {
                "text": "She runs a diner on the outskirts of Milfheim.",
                "condition": None,
            },
            {
                "text": "She's in a relationship with Detective Owen. However, he seems to regard her as little more than a sex partner. She's beginning to grow dissatisfied with his attitude toward her.",
                "condition": "ch06_started",
            },
            
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_isabella",
        "love": "love_isabella",
        "sus": "sus_isabella",
    },

    "jason": {
        "name": "Jason",
        "age": "1?",
        "job": "College Student",
        "icon": "images/character_bio/jason_icon.png",
        "bio_image": "images/character_bio/jason_bio.jpg",

        "info": [
            {
                "text": "He is [d_name]'s college classmate. They share a dorm room and have become best friends. He has a fun-loving personality and shares many of the same interests as [d_name]. Like most young men, he has a huge interest in sex. He especially has a thing for female professors like Sophia.",
                "condition": None,
            },
            {
                "text": "He discovered that Professor Sophia works as a model on the side, including nude modeling. The discovery has left him overwhelmed with excitement.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_jason",
        "respect": "respect_jason",
        "rivalry": "rivalry_jason",
    },

    "kevin": {
        "name": "Kevin",
        "age": "2?",
        "job": "Office Worker",
        "icon": "images/character_bio/kevin_icon.png",
        "bio_image": "images/character_bio/kevin_bio.jpg",

        "info": [
            {
                "text": "He works for Rose's advertising company. He and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_kevin",
        "respect": "respect_kevin",
        "rivalry": "rivalry_kevin",
    },

    "leila": {
        "name": "Leila",
        "age": "2?",
        "job": "Waitress",
        "icon": "images/character_bio/leila_icon.png",
        "bio_image": "images/character_bio/leila_bio.jpg",

        "info": [
            {
                "text": "She works at the rooftop bar. She and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_leila",
        "love": "love_leila",
        "sus": "sus_leila",
    },

    "marcus": {
        "name": "Marcus",
        "age": "2?",
        "job": "Office Worker",
        "icon": "images/character_bio/marcus_icon.png",
        "bio_image": "images/character_bio/marcus_bio.jpg",

        "info": [
            {
                "text": "He works for Rose's advertising company. He and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_marcus",
        "respect": "respect_marcus",
        "rivalry": "rivalry_marcus",
    },

    "michael": {
        "name": "Michael",
        "age": "4?",
        "job": "?",
        "icon": "images/character_bio/michael_icon.png",
        "bio_image": "images/character_bio/michael_bio.jpg",

        "info": [
            {
                "text": "He is a mysterious figure. He appears to be close to [h_name].",
                "condition": None,
            },
            {
                "text": "He is a former special forces soldier.",
                "condition": "ch05_started",
            },
            {
                "text": "He is helping [h_name] with her work. He also appears to be working for an unknown organization.",
                "condition": "ch06_started",
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_michael",
        "respect": "respect_michael",
        "rivalry": "rivalry_michael",
    },

    "monica": {
        "name": "Monica",
        "age": "5?",
        "job": "Rooftop Bar Owner",
        "icon": "images/character_bio/monica_icon.png",
        "bio_image": "images/character_bio/monica_bio.jpg",

        "info": [
            {
                "text": "She runs a rooftop bar in downtown Milfheim. She has a cheerful personality.",
                "condition": None,
            },
            {
                "text": "She overheard most of the conversation between [d_name] and Celine at the rooftop bar she runs.",
                "condition": "ch06_started",
            },
            
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_monica",
        "love": "love_monica",
        "sus": "sus_monica",
    },

    "rebecca": {
        "name": "Rebecca",
        "age": "4?",
        "job": "University Professor",
        "icon": "images/character_bio/rebecca_icon.png",
        "bio_image": "images/character_bio/rebecca_bio.jpg",

        "info": [
            {
                "text": "She holds degrees in psychology and philosophy. She teaches sexology at the university [d_name] attends. She is close with Sophia.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_rebecca",
        "love": "love_rebecca",
        "sus": "sus_rebecca",
    },

    "shakira": {
        "name": "Shakira",
        "age": "3?",
        "job": "Office Worker",
        "icon": "images/character_bio/shakira_icon.png",
        "bio_image": "images/character_bio/shakira_bio.jpg",

        "info": [
            {
                "text": "She works for Rose's advertising company. She and [d_name] have only seen each other around.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_shakira",
        "love": "love_shakira",
        "sus": "sus_shakira",
    },

    "vivian": {
        "name": "Vivian",
        "age": "3?",
        "job": "Office Worker",
        "icon": "images/character_bio/vivian_icon.png",
        "bio_image": "images/character_bio/vivian_bio.jpg",

        "info": [
            {
                "text": "She works for Rose's advertising company. She was in contact with [d_name] regarding his interview.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_vivian",
        "love": "love_vivian",
        "sus": "sus_vivian",
    },

    "owen": {
        "name": "Owen",
        "age": "3?",
        "job": "Police Officer",
        "icon": "images/character_bio/owen_icon.png",
        "bio_image": "images/character_bio/owen_bio.jpg",

        "info": [
            {
                "text": "He is a police officer with the Milfheim Police Department. He previously worked with Diana in the Major Crimes Unit in the state capital. For reasons unknown, he was transferred to the Milfheim Police Department and now works in the Vice Unit. He and Diana were once romantically involved.",
                "condition": None,
            },
        ],

        "status_type": "male",
        "continuation": "*His information will continue to be added.",
        "friendship": "friendship_owen",
        "respect": "respect_owen",
        "rivalry": "rivalry_owen",
    },

    "veronica": {
        "name": "Veronica",
        "age": "5?",
        "job": "Urologist.",
        "icon": "images/character_bio/veronica_icon.png",
        "bio_image": "images/character_bio/veronica_bio.jpg",

        "info": [
            {
                "text": "She is a mysterious woman. She seduced Mary and [d_name] at the park. She seems to enjoy a sexually liberated lifestyle.",
                "condition": None,
            },
        ],

        "status_type": "female",
        "continuation": "*Her information will continue to be added.",
        "lust": "lust_veronica",
        "love": "love_veronica",
        "sus": "sus_veronica",
    },
    
    "ivy": {
    "name": "Ivy",
    "age": "4?",
    "job": "Gym Owner",
    "icon": "images/character_bio/ivy_icon.png",
    "bio_image": "images/character_bio/ivy_bio.jpg",

    "info": [
        {
            "text": "She runs a gym in downtown. She is a friend of [h_name]. She is very interested in maintaining her own body as well as helping others maintain theirs.",
            "condition": None,
        },
        {
                "text": "She introduced [h_name] to a man. She also exposed her bare breasts to [h_name], seemingly on purpose.",
                "condition": "ch06_started",
        },
    ],

    "status_type": "female",
    "continuation": "*Her information will continue to be added.",
    "lust": "lust_ivy",
    "love": "love_ivy",
    "sus": "sus_ivy",
    },
    "stella": {
            "name": "Stella",
            "age": "2?",
            "job": "Restaurant Server",
            "icon": "images/character_bio/stella_icon.png",
            "bio_image": "images/character_bio/stella_bio.jpg",

            "info": [
                {
                    "text": "She works as a server at Olivia's restaurant.",
                    "condition": None,
                },
            ],

            "status_type": "female",
            "continuation": "*Her information will continue to be added.",
            "lust": "lust_stella",
            "love": "love_stella",
            "sus": "sus_stella",
        },
}
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
