default ch05_started = False

label ch05_cabin01:
    $ ch05_started = True
    if not in_replay:
        $ persistent.unlock_ch05_cabin01 = True
    $ friendship_jason += 50
    $ respect_jason += 50
    $ rivalry_michael += 20
    $ rivalry_frank += 50
    show screen top_ui_buttons
    scene chapter05_start with Dissolve(2.0)
    pause
    if not in_replay:
        $ bio_alessia = True
        $ bio_anna = True
        $ bio_chloe = True
        $ bio_evelyn = True
        $ bio_frank = True
        $ bio_harold = True
        $ bio_isabella = True
        $ bio_jason = True
        $ bio_kevin = True
        $ bio_marcus = True
        $ bio_michael = True
        $ bio_owen = True
        $ bio_rebecca = True
        $ bio_shakira = True
        $ bio_veronica = True
        $ bio_vivian = True
        $ bio_ivy = True
        $ bio_stella = True
    scene chapter05_start02 with Dissolve(2.0)
    pause
    scene ch04_cabin02_22 at hand_camera with Dissolve(1.2)
    n "그녀는 허공에 희미하게 울리는 발자국 소리에 고개를 돌렸다."
    scene ch04_cabin02_22-02 at hand_camera with Dissolve(1.2)
    o "........."
    scene ch04_cabin02_23 at hand_camera with Dissolve(1.2)
    d "......."
    o "........."
    scene ch04_cabin02_24 at hand_camera with Dissolve(1.2)
    o "왜 안자고 나왔어?"
    o ".........."
    scene ch04_cabin02_25 at hand_camera with Dissolve(1.2)
    o "너도 잠이 안오니?"
    d "네 ㅎㅎ 그냥...."
    d "마음이 좀 싱숭생숭 해서요.."
    o "........."
    o "마음이 싱숭생숭하다라....."
    scene ch05_cabin01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_01-02 at hand_camera with Dissolve(0.8)
    o "........."
    o "흐음....."
    scene ch05_cabin01_01-03 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_cabin01_02 at hand_camera with Dissolve(1.2)
    pause
    n "둘 사이에 어색한 기류가 흘렀다."
    pause
    n "올리비아는 몇시간 전보다 맑은 정신이었다."
    n "그녀는 술기운은 사라졌고 거의 맨정신이었다."
    n "하지만 그녀의 머릿속에 떠나지 않고 남아있는것은 그의 튼실한 성기였다."
    scene ch05_cabin01_03 at hand_camera with Dissolve(0.8)
    d "........."
    o "......."
    o "이 영화 본적 있니?"
    d "이 영화요??"
    d "음....."
    d "아뇨. 본 기억이 없어요."
    o "아쉽군."
    o "내가 제일 좋아하는 영화야."
    o "야한 영화는 아니니까 기대하지 말고."
    d "ㅎㅎ"
    scene ch05_cabin01_04 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_cabin01_04-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_cabin01_05 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_cabin01_06 at hand_camera with Dissolve(0.8)
    d "........"
    o "......."
    o "왜 무슨 말이 하고싶은데?"
    scene ch05_cabin01_07 at hand_camera with Dissolve(0.8)
    d "아뇨 그냥...."
    d "올리를 바라본거에요...."
    d "그냥....."
    d "올리가 무슨 생각하는지 궁금해서요 ㅎㅎ.."
    o "뭐라고?"
    o "그렇게 날 쳐다보면 내가 무슨 생각하는지 알아내져?"
    o "......."
    o "멍청이."
    scene ch05_cabin01_08 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
    o "이리로와 멍청아."
    scene ch05_cabin01_09 at hand_camera with Dissolve(0.8)
    d "ㅎㅎㅎ"
    scene ch05_cabin01_10 at hand_camera with Dissolve(1.2)
    d "........."
    o "......."
    scene ch05_cabin01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_12 at hand_camera with Dissolve(0.8)
    o "......."
    o "너...."
    scene ch05_cabin01_13 at hand_camera with Dissolve(0.8)
    o "너 나 사랑하니?"
    scene ch05_cabin01_14 at hand_camera with Dissolve(0.8)
    d "그럼요."
    pause
    d "전 올리를 사랑해요."
    d "우리가 그런걸 확인할 사이인가요? ㅎㅎ"
    scene ch05_cabin01_15 at hand_camera with Dissolve(0.8)
    o "......."
    scene ch05_cabin01_16 at hand_camera with Dissolve(0.8)
    o "그럼 아만다는?"
    d "네?"
    scene ch05_cabin01_17 at hand_camera with Dissolve(0.8)
    d "아....당연히 아만다도 사랑하죠."
    d "왜 그런 질문을...."
    scene ch05_cabin01_14 at hand_camera with Dissolve(0.8)
    o "싱겁기는..."
    d "싱겁다니요 ㅎㅎ."
    d "아만다와 올리는 저에게 특별한 사람들이라구요."
    d "우리 셋은 평생 같이 할 사람들이잖아요."
    o "........"
    scene ch05_cabin01_15-02 at hand_camera with Dissolve(0.8)
    o "흐음......."
    o "특별한 사람이라서 그렇게 아만다와 나에게 고추를 들이민거야?"
    scene ch05_cabin01_18 at hand_camera with Dissolve(0.8)
    d "**(젠장....)**"
    d "그...그건....ㅎㅎ"
    d "뭐랄까....."
    o "....."
    d "술은 마시지 않았지만 술에 취했었다고 할까 하하."
    scene ch05_cabin01_19 at hand_camera with Dissolve(0.8)
    o "........"
    o "뜬금 없는 질문하나 할까?"
    d "네."
    o "....."
    o "만약에 우리가 연인이라면 지금 뭘하고 싶니?"
    scene ch05_cabin01_20 at hand_camera with Dissolve(0.8)
    d "네?"
    d "그게 무슨 말이에요?"
    o "들었잖아."
    o "우리가 연인이라면 지금 당장 뭘하고싶냐고."
    scene ch05_cabin01_21 at hand_camera with Dissolve(0.8)
    d "음......글쎄요...."
    d "..........."
    pause
    d "모르겠어요 ㅎㅎ."
    pause
    d "아마 우리가 연인이라면 올리가 원하는 것을 하고 있겠죠? 하하."
    scene ch05_cabin01_22 at hand_camera with Dissolve(0.8)
    o "그래?"
    o "........"
    o "내가 원하는 것이라....."
    scene ch05_cabin01_23 at hand_camera with Dissolve(0.8)
    pause
    o "난 섹스를 원해."
    o "지금 당장."
    d "!!!!!!"
    play sound "audio/ambi/fabric02.mp3"
    scene ch05_cabin01_24 at hand_camera with Dissolve(0.8)
    d "............"
    scene ch05_cabin01_25 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_26 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    o "하................."
    pause
    o "이 서늘한 산속의 공기와 바람...."
    o "............."
    o "이 적당한 취기(술에 의한)..."
    scene ch05_cabin01_27 at hand_camera with Dissolve(0.8)
    o "........."
    o "그리고 내 옆에는 우람한 자지가 있어..."
    d "오...올리..."
    scene ch05_cabin01_27-02 at hand_camera with Dissolve(0.8)
    o "............."
    o "이보다 더 떡치기 완벽한 상황이 있을까?"
    o "안그래?"
    play voice_f "audio/sex/milfmoanshort05.mp3"
    o "이런 상황에서 떡치면 난 보통 오르가즘을 느낀다고..."
    scene ch05_cabin01_28 at hand_camera with Dissolve(0.8)
    d ".........."
    d "오..오르가즘이요?..."
    o "그래."
    o "내가 얘기 했잖아 꼬맹아."
    o "중요한건 분위기라고."
    scene ch05_cabin01_29 at hand_camera with Dissolve(0.8)
    o "........."
    o "근데 지금 난......"
    pause
    n "[d_name]은 그 어느때보다 올리비아의 말에 집중했다."
    n "그 순간에 그는 간절히 원했다."
    pause
    n "올리비아의 입에서 자신의 생각과 같은 말이 나오길..."
    d ".........."
    o "근데 지금 난......"
    scene ch05_cabin01_30 at hand_camera with Dissolve(0.8)
    o "섹스보다 위로를 원해...."
    d "**(뭐요???)**"
    d "**(섹스보다 위로요??....)**"
    d "**(............)**"
    d "위..위로요??.."
    d "**(대화의 방향이 또 무거워지잖아 이거.......)**"
    d "**(어떻게 해야 하지.....)**"
    menu:
        n "What should I do?"
        "분위기를 이어가기 위해 그녀의 몸을 만진다.":
            scene ch05_cabin01_30-02 at hand_camera with Dissolve(0.8)
            n "[d_name]은 성적인 긴장감을 유지하기 위해 그녀의 음부 가까이 손을 가져갔다."
            n "올리비아는 단번에 그의 의도를 알아차렸다."
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            o "젠장. 니가 만지는것만으로 닭살이 돋아."
            o "............."
            d "**(............)**"
            d "그..그래요?.."
            d "저도 지금 발기가....."
    scene ch05_cabin01_31 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    o "하아........."
    o "........."
    o "난 지금 내 주변의 모든 일에 지쳤어....."
    play music "audio/bgm/night02.mp3"
    scene ch05_cabin01_32 at hand_camera with Dissolve(0.8)
    d "............."
    o "남편과 이혼 소송....."
    pause
    o "레스토랑 운영....."
    o "이런 저런 스트레스거리들.."
    o "........"
    o "난 번아웃이 온거 같아."
    scene ch05_cabin01_33 at hand_camera with Dissolve(0.8)
    o "휴........."
    d "오..올리.."
    d "괜찮아요?"
    n "그의 손은 올리비아의 음부로 더 가까이 다가갔다."
    n "마치 지금 그녀가 하는 말은 자기가 원하는 말이 아니니 다시 생각해보라는듯이 말이다."
    n "자신의 손의 움직임에 올리가 반응하길 원했다."
    scene ch05_cabin01_34 at hand_camera with Dissolve(0.8)
    o "......"
    o "날 좀 안아줘 허니.."
    scene ch05_cabin01_25 at hand_camera with Dissolve(0.8)
    d "!!!"
    pause
    d "아...알겠어요."
    scene ch05_cabin01_34 at hand_camera with Dissolve(0.8)
    o "살과 살을 맞대고..."
    d "!!!!"
    o "난 남자와 살을 맞대면 안도감을 느껴."
    o "어린 아이 처럼 말이야..."
    o "........"
    scene ch05_cabin01_28 at hand_camera with Dissolve(0.8)
    d ".........."
    d "아....알겠어요."
    d "그렇게 하고 말고요."
    d "내일 아침까지라도 안고 있을 수 있어요.."
    scene ch05_cabin01_35 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_cabin01_35-02 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_cabin01_35-03 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_cabin01_36 at hand_camera with Dissolve(1.3)
    play music "audio/bgm/erotic12.mp3"
    d "**(젠장...)**"
    d "**(가슴이 두근거려서 터질거 같아....)**"
    scene ch05_cabin01_37 at hand_camera with Dissolve(0.8)
    d "**(왜 여자를 안으면 심장이 이렇게 빨리 뛰는거지?)**"
    d "**(........)**"
    d "**(아니야........)**"
    d "**(뭔가 내 상황이 금기를 깨는 그런거라 더 그런건가......)**"
    scene ch05_cabin01_38 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
        $ add_point("lust_olivia", 1, "lust_olivia")
    o "........"
    scene ch05_cabin01_39 at hand_camera with Dissolve(0.8)
    d "괜찮아요 올리?"
    d "자세가 불편하진 않아요?"
    scene ch05_cabin01_40 at hand_camera with Dissolve(0.8)
    o "아냐 괜찮아."
    o "너무 좋아....."
    pause
    o "편해....."
    o "..........."
    o "사람의 체온이 그리웠어...."
    scene ch05_cabin01_41 at hand_camera with Dissolve(0.8)
    d "그..그랬군요..."
    pause
    o "왜 남자 품에 안기면 맘이 편해지는걸까..."
    d "그...그래요?..."
    o "........."
    o "내가 요물인가?"
    d "아뇨..그럴리가요..."
    d "저도 안정이 돼요.."
    d "**(젠장 사실은 올리와의 다양한 체위만 생각하는 중이에요!!!!)**"
    scene ch05_cabin01_40 at hand_camera with Dissolve(0.8)
    o "ㅎㅎ"
    o "너와 내가 이러고 있게 될 줄이야...."
    o "아만다가 보면 날 죽이려들겠군."
    d ".........."
    o "상관없어."
    o "아만다가 분명 나에게 마음껏 널 유혹해 보라고 했으니까.."
    d "ㅎㅎ 그랬었나요?..."
    scene ch05_cabin01_42 at hand_camera with Dissolve(0.8)
    o "하......."
    pause
    o "아만다와 나, 자매가 나란히 결혼 생활에 실패했다니....."
    o "......"
    scene ch05_cabin01_43 at hand_camera with Dissolve(0.8)
    d "........"
    d "미안해요 올리......"
    scene ch05_cabin01_44 at hand_camera with Dissolve(0.8)
    o "......"
    o "그거 아니?"
    d "어떤거요?........"
    o "......"
    pause
    o "아만다는 힘겹게 견디고 있어..."
    scene ch05_cabin01_43 at hand_camera with Dissolve(0.8)
    d "........"
    o "너도 알겠지만..."
    o "프랭크가 점점 더 망나나짓을 하고다니는거 같아."
    o "......."
    o "얼마전엔 아만다를 때린다고 위협도 했던거 같아."
    scene ch05_cabin01_44 at hand_camera with Dissolve(0.8)
    o "그리고....."
    o "난 가정을 잃을 처지야.."
    o "............"
    o "혼자 살면 자유롭다는거?"
    o "다 개소리야."
    scene ch05_cabin01_45 at hand_camera with Dissolve(0.8)
    d "........"
    o "그것도 내가 젊고 건강할 때 뿐이라고..."
    o "모든 사람들의 관심을 받을 때 뿐이야.."
    scene ch05_cabin01_43 at hand_camera with Dissolve(0.8)
    d "........"
    d "그...그렇겠죠 아무래도.."
    scene ch05_cabin01_46 at hand_camera with Dissolve(0.8)
    o "그래..."
    o "넌 눈치가 빠르니까 내말이 이해 될거야.."
    scene ch05_cabin01_47 at hand_camera with Dissolve(0.8)
    d "........"
    d "**(젠장......)**"
    d "**(왜 심각한 얘길 하면서 거길 만지는거지?...)**"
    scene ch05_cabin01_48 at hand_camera with Dissolve(0.8)
    o "젠장 너랑 섹스하고 싶다."
    d "!!!!!!!"
    o ".........."
    d "저...저기..."
    o "아니...그냥 남자가 필요한건가?..."
    o "튼실한 자지에 박히고 싶다고."
    o "제대로 서있을수도 없을때까지 말이야."
    scene ch05_cabin01_49 at hand_camera with Dissolve(0.8)
    d "제대로 서있을 수 없을때 까지요?....."
    d "........."
    scene ch05_cabin01_48 at hand_camera with Dissolve(0.8)
    o ".........."
    o "근데 너와 그 짓을 하게되면 난 내 언니까지 잃게 될거야."
    o "......"
    o "이 망할 작은 동네에서 매장 당할거라고....."
    d "........"
    o "이 망할 남일에 관심 많은 놈들만 사는 동네...."
    scene ch05_cabin01_50 at hand_camera with Dissolve(0.8)
    o "이 세상에 영원한 비밀은 없거든."
    d "........."
    d "**(뭐라 말하고 싶은데 도저히 뭐라 말해야 할지 모르겠다.........)**"
    d "............."
    d "**(하....그냥 세상만사 다 잊고 떡이나 치자고 하고싶은데..)**"
    d "**(라고 하면 쓰레기 새끼지.)**"
    d "**(왜 이 순간에도 떠오르는건 섹스뿐이지????)**"
    d "............."
    d "**(여자를 안고 있으니 당연한건지...아님 내가 섹스에 미친건가??..)**"
    d "**(진짜 병원에 가봐야 하나...)**"
    scene ch05_cabin01_51 at hand_camera with Dissolve(0.8)
    d ".........."
    d "제가 영원히 올리비아 옆에 있을게요..."
    pause
    d "전 영원히 올리비아와 함께 할거에요."
    play voice_f "audio/voices/flaugh06.mp3"
    o "하하. 정말?"
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
    d "그럼요!"
    d "전 이런 농담은 안해요."
    scene ch05_cabin01_51-02 at hand_camera with Dissolve(0.8)
    o ".........."
    o "빈말이라도 고마워."
    o "근래들어 들어본 말 중에 가장 스윗한 말이었어."
    o "아니 내 남편이 프로포즈 할 때 했던 말 같은데? ㅎㅎㅎ"
    scene ch05_cabin01_51-03 at hand_camera with Dissolve(0.8)
    d ".........."
    d "제가 아만다와 올리비아의 옆에 있을거에요."
    d "결혼도 안할거고 그냥 셋이 같이 살아요."
    scene ch05_cabin01_52 at hand_camera with Dissolve(0.8)
    o ".........."
    o "같잖게 달콤하네 ㅎㅎ."
    o ".........."
    o "뭐 여자 생기면 당연히 거기로 달려가겠지."
    scene ch05_cabin01_46 at hand_camera with Dissolve(0.8)
    o ".........."
    o "하지만 빈말이라도 고마워...."
    o "......."
    pause
    o "너..."
    d "네?"
    o "......."
    o "너..."
    o "나에게서 여자의 매력을 느끼니?"
    scene ch05_cabin01_43 at hand_camera with Dissolve(0.8)
    d "........"
    d "여..여자로서의 매력이요??"
    o "으흥."
    scene ch05_cabin01_51-03 at hand_camera with Dissolve(0.8)
    d "그..그럼요."
    menu:
        n "What should I do?"
        "올리는 매력적인 여자에요....":
            scene ch05_cabin01_51-03 at hand_camera with Dissolve(0.8)
            d "올리는 매력적인 여자에요...."
            if not in_replay:
                $ add_point("love_olivia", 1, "love_olivia")
            o "....."
            o "매력있는 여자라....."
        "올리는 이 세상에서 제일 섹시해요.":

            scene ch05_cabin01_51-03 at hand_camera with Dissolve(0.8)
            d "올리는 이 세상에서 제일 섹시해요."
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            o "....."
            play voice_f "audio/voices/flaugh06.mp3"
            o "하하. 이건 예상 못한 대답이네."
    scene ch05_cabin01_53 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort01.mp3"
    n "쪽!(키스하는 의성어)"
    d "**(!!!!!)**"
    n "그녀는 [d_name]의 젖꼭지에 부드럽게 키스했다."
    n "그녀의 입술이 몸에 닿자 그는 기분좋은 소름을 느꼈다."
    d "**(쉣.......)**"
    play voice_f "audio/sex/kissshort02.mp3"
    scene ch05_cabin01_54 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic05.mp3"
    pause
    scene ch05_cabin01_54-02 at hand_camera with Dissolve(0.8)
    d "아..올리....."
    d "거...거기는..."
    d "너..너무 좋아요..."
    play voice_f "audio/sex/kisslong01.mp3" loop
    scene ch05_cabin01_55 at hand_camera with Dissolve(0.8)
    o ".........."
    n "쪽쪽(키스하는 의성어)"
    scene ch05_cabin01_56 at hand_camera with Dissolve(0.8)
    d "**(마이갓......)**"
    d "오..올리......"
    o ".........."
    d "**(여자의 입은 왜 이렇게 느낌이 좋은걸까....)**"
    scene ch05_cabin01_57 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!"
    d "으..........."
    scene ch05_cabin01_58 at hand_camera with Dissolve(0.8)
    d "아......."
    scene ch05_cabin01_59 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_60 at hand_camera with Dissolve(0.8)
    d "하...올리...."
    o "**(.......)**"
    d "너무 좋아요....."
    d "맙소사....."
    stop voice_f
    scene ch05_cabin01_61 at hand_camera with Dissolve(0.8)
    o "..........."
    n "그녀는 자신을 보살피려는 의지를 보인 남자에게 자신의 여성성을 보여주었다."
    n "그리고 그것은 그녀가 그 남자와 섹스로 가는 여러 루트중에 가장 확실한 루트중 하나였다."
    pause
    n "하지만 그녀는 [d_name]과의 애무는 넘어선 안 될 선이라고 되새겼다."
    o "**(나 지금 [d_name]에게 뭐하는거지?)**"
    o "**(...........)**"
    o "**(이 어린애랑 뭐하는거야...)**"
    scene ch05_cabin01_61-02 at hand_camera with Dissolve(0.8)
    d "....."
    d "올리....."
    pause
    d "사랑해요 올리."
    d "전 참을 수 없어요.."
    o "뭐?"
    d "올리를 가지고 싶어요..."
    o "날 가지고 싶다고??..."
    scene ch05_cabin01_62 at hand_camera with Dissolve(0.8)
    pause
    n "그는 애무를 멈추고 갈등하는 올리비아의 뒷머리를 잡았다."
    n "그리고 그녀의 머리를 자신 쪽으로 당겨왔다."
    menu:
        n "What should I do?"
        "그녀에게 키스를 한다.":
            scene ch05_cabin01_63 at hand_camera with Dissolve(0.8)
            o "!!!!"
            pause
    scene ch05_cabin01_64 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort02.mp3"
    pause
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    scene ch05_cabin01_65 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_65-02 at hand_camera with Dissolve(0.8)
    n "흥분 상태의 그는 자신의 행동이 그녀와의 관계를 망친걸까 고민했다."
    pause
    play voice_f "audio/sex/kisslong01.mp3" loop
    n "하지만 올리비아의 혀가 그의 혀와 섞여가자 안도했다."
    scene ch05_cabin01_66 at hand_camera with Dissolve(0.8)
    n "그들은 그들의 인생에서 가장 깊은 키스를 했다."
    pause
    n "마치 입으로 서로의 존재를 빨아들이려는 듯이.."
    scene ch05_cabin01_67 at hand_camera with Dissolve(0.8)
    n "올리비아는 [d_name]과의 키스로 여러 금기를 깼다."
    pause
    n "이토록 나이차이가 많이 나는 남성과의 키스는 그녀에게 전혀 새로운 성적인 경험이었다."
    scene ch05_cabin01_68 at hand_camera with Dissolve(0.8)
    pause
    image ch05_cabin01_kiss01:
        "ch05_cabin01_67" with dissolve
        0.7
        "ch05_cabin01_68" with dissolve
        0.7
        repeat
    scene ch05_cabin01_kiss01 at hand_camera with Dissolve(0.8)
    n "그녀에게 흥분과 부끄러움이 동시에 찾아왔다."
    pause
    n "그녀는 마치 [d_name]과의 키스로 고등학교 시절로 돌아간 듯한 기분을 느꼈다."
    scene ch05_cabin01_69 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_70 at hand_camera with Dissolve(0.8)
    pause
    image ch05_cabin01_kiss02:
        "ch05_cabin01_69" with dissolve
        0.7
        "ch05_cabin01_70" with dissolve
        0.7
        repeat
    scene ch05_cabin01_kiss02 at hand_camera with Dissolve(0.8)
    n "그들은 시간이 멈춘듯이 키스를 했다."
    pause
    n "그리고 [d_name]은 다음 단계로 나아가야 한다는 것을 느꼈다."
    scene ch05_cabin01_kiss01 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_72-02 at hand_camera with Dissolve(0.8)
    o "!!!!!"
    scene ch05_cabin01_72 at hand_camera with Dissolve(0.8)
    pause
    stop voice_f
    scene ch05_cabin01_71 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_73 at hand_camera with Dissolve(0.8)
    o "ㅎㅎ"
    d "........"
    play music "audio/bgm/normal11.mp3"
    scene ch05_cabin01_73-02 at hand_camera with Dissolve(0.8)
    d "왜..왜그래요.."
    d "제가 뭐 잘못했어요?"
    scene ch05_cabin01_74 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_75 at hand_camera with Dissolve(0.8)
    o "흐응......"
    scene ch05_cabin01_76 at hand_camera with Dissolve(0.8)
    o "퓨.........."
    o "**(장하다 올리비아....장해...)**"
    o "**(부끄럽다 정말....)**"
    scene ch05_cabin01_77 at hand_camera with Dissolve(0.8)
    d "미...미안해요...."
    d "제가 너무 가..갑작스럽게..."
    scene ch05_cabin01_77-02 at hand_camera with Dissolve(0.8)
    o "아니야 괜찮아."
    o "정말 좋았어."
    o "........"
    o "넌 잘못한거 없어."
    scene ch05_cabin01_78 at hand_camera with Dissolve(1.2)
    d "그..근데 왜 갑자기..."
    d "........"
    d "또 드..들어가려고요?"
    scene ch05_cabin01_79 at hand_camera with Dissolve(0.8)
    d "........"
    d "절 여기다 두고 또 들어가는거에요?..."
    o "........"
    scene ch05_cabin01_80 at hand_camera with Dissolve(0.8)
    o "미안해 허니."
    o "........"
    o "그냥...."
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_cabin01_80-02 at hand_camera with Dissolve(0.8)
    o "난 이런 기분일 줄은 몰랐어....."
    o "......"
    o "그리고 너와 나, 아만다와의 관계..."
    pause
    o "어서 들어가서 자."
    o "나중에 얘기하자."
    scene ch05_cabin01_81 at hand_camera with Dissolve(0.8)
    d "**(젠장....)**"
    pause
    d "**(내가 너무 푸시했나...)**"
    d "**(.......)**"
    d "**(아니 가슴을 만질게 아니라 자지를 꺼냈어야 했나?)**"
    scene ch05_cabin01_82 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_83 at hand_camera with Dissolve(0.8)
    n "집으로 들어가려던 올리비아는 걸음을 멈췄다."
    n "그리고 잠시 멈춰서 침묵 속에서 무언가 생각했다."
    scene ch05_cabin01_83-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_84 at hand_camera with Dissolve(1.2)
    d "????"
    scene ch05_cabin01_84-02 at hand_camera with Dissolve(1.2)
    n "그리고 잠시 [d_name]의 얼굴을 바라보았다."
    pause
    n "그리고 이내 입을 열었다."
    scene ch05_cabin01_85 at hand_camera with Dissolve(1.2)
    o "일어서."
    scene ch05_cabin01_86 at hand_camera with Dissolve(0.8)
    d "네?"
    scene ch05_cabin01_85 at hand_camera with Dissolve(0.8)
    o "들었잖아."
    o "일어서라고."
    play sound "audio/ambi/fabric03.mp3"
    scene ch05_cabin01_86-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_87 at hand_camera with Dissolve(0.8)
    d "???"
    scene ch05_cabin01_88 at hand_camera with Dissolve(0.8)
    d "??"
    d "뭐하는거에요?"
    d "........"
    play sound "audio/ambi/fabric02.mp3"
    scene ch05_cabin01_89 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_90 at hand_camera with Dissolve(0.8)
    d "뭐..뭐하는거에요??"
    d "오..올리..."
    scene ch05_cabin01_91 at hand_camera with Dissolve(0.8)
    o "ㅎㅎ"
    o "널 놓고 들어가려는게 아니야..."
    o "무슨 말인지 아니?"
    o "......."
    scene ch05_cabin01_92 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort02.mp3"
    n "쪽(키스하는 의성어)"
    scene ch05_cabin01_93 at hand_camera with Dissolve(0.8)
    d "맙소사 올리......"
    d "지금 저 놀리는거죠?......"
    d "이러다 갑자기 또 멈출려고 그러죠? 맞죠?"
    pause
    d "........."
    d "이럴거면 소파로 가는게..."
    play sound "audio/ambi/fabric02.mp3"
    scene ch05_cabin01_94 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!"
    n "그의 사타구니에 시원한 산 바람이 스쳐왔다."
    pause
    n "그리고 흥분감과 해방감, 올리비아에 대한 성욕이 뒤섞여 밀려왔다."
    scene ch05_cabin01_95 at hand_camera with Dissolve(1.2)
    play music "audio/bgm/erotic04.mp3"
    pause
    scene ch05_cabin01_94 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_96 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    d "쉣....올리..."
    scene ch05_cabin01_96-02 at hand_camera with Dissolve(0.8)
    o "내가 그냥 들어갈까봐 아쉬우셨어요 왕자님?"
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    scene ch05_cabin01_97 at hand_camera with Dissolve(0.8)
    o "젠장....."
    pause
    o "이 세상에 어떤 여자가 이런 자지를 보고도 잠에 들 수 있을까?"
    o "......"
    scene ch05_cabin01_98 at hand_camera with Dissolve(0.8)
    o "이걸 아만다의 항문에 그대로 밀어넣으려 했다고?"
    d "아...아니 그건...."
    scene ch05_cabin01_99 at hand_camera with Dissolve(0.8)
    o "이 무식한 녀석!"
    scene ch05_cabin01_100 at hand_camera with Dissolve(0.8)
    pause
    image ch05_cabin01_hj01:
        "ch05_cabin01_98" with dissolve
        0.5
        "ch05_cabin01_99" with dissolve
        0.5
        "ch05_cabin01_100" with dissolve
        0.5
        repeat
    scene ch05_cabin01_hj01 at hand_camera with Dissolve(0.8)
    d "아 올리......"
    d "젠장.."
    scene ch05_cabin01_101 at hand_camera with Dissolve(0.8)
    o "그래 꼬맹아."
    o "내 보지에 넣고 싶어서 미치겠지?"
    d "네?...."
    o "날 너의 트로피 캐비넷에 추가 하고 싶은거지??"
    d "........"
    scene ch05_cabin01_102 at hand_camera with Dissolve(0.8)
    o "아니야?"
    d "마....맞아요."
    scene ch05_cabin01_103 at hand_camera with Dissolve(0.8)
    o "뭐라고?"
    o "뭐라고 했는지 안들려."
    scene ch05_cabin01_104 at hand_camera with Dissolve(0.8)
    d "올리의 보..보지에 넣고 싶어요."
    scene ch05_cabin01_105 at hand_camera with Dissolve(0.8)
    o "젠장."
    o "너 때문에 나 지금 젖었잖아.."
    o "내 남편이 지금 이 장면을 봤어야 하는데..."
    o "아마 바로 샷건을 들고 올걸?"
    d "네??!!"
    o "하........."
    image ch05_cabin01_hj02:
        "ch05_cabin01_102" with dissolve
        0.5
        "ch05_cabin01_103" with dissolve
        0.5
        "ch05_cabin01_104" with dissolve
        0.5
        "ch05_cabin01_105" with dissolve
        0.5
        repeat
    play sound "audio/sex/penet_long_interval.mp3" loop volume 0.5
    scene ch05_cabin01_hj02 at hand_camera with Dissolve(0.8)
    d "쉣!!!!"
    o "그래 허니...."
    o "너의 물건 정말 훌륭해..."
    o "......."
    o "내 손으로 전해져...."
    scene ch05_cabin01_106 at hand_camera with Dissolve(0.8)
    d "**(쉣.....)**"
    d "**(어떻게 내가 딱 좋아하는 압력으로 쥐고 있는거지??)**"
    d "**(이게 밀프의 능력이야...아....)**"
    scene ch05_cabin01_hj02 at hand_camera with Dissolve(0.8)
    o "......"
    o "맙소사......"
    o "니가 우리집에 첨 들어왔을때 이렇게 될 줄 누가알았을까.."
    d "아....."
    o "움찔움찔 하네?"
    d "네....."
    scene ch05_cabin01_107 at hand_camera with Dissolve(0.8)
    o "맙소사..."
    o "자지가 완전 돌덩이네 돌덩이..."
    scene ch05_cabin01_108 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_cabin01_109 at hand_camera with Dissolve(0.8)
    d "!!"
    stop sound fadeout 0.5
    scene ch05_cabin01_109-02 at hand_camera with Dissolve(0.8)
    o "내 남편은 여기 만져주는거 좋아했었는데..."
    o "내가 입안에 사탕 처럼 넣고 굴려주면 좋아했었어 ㅎㅎ."
    d "젠장 올리...."
    image ch05_cabin01_hj03:
        "ch05_cabin01_109-02" with dissolve
        0.8
        "ch05_cabin01_109-03" with dissolve
        0.8
        repeat
    scene ch05_cabin01_hj03 at hand_camera with Dissolve(0.8)
    d "아.....올리...."
    d "........"
    d "올리와 섹스하고 싶어요...."
    o "............"
    image ch05_cabin01_hj02:
        "ch05_cabin01_102" with dissolve
        0.2
        "ch05_cabin01_103" with dissolve
        0.2
        "ch05_cabin01_104" with dissolve
        0.2
        "ch05_cabin01_105" with dissolve
        0.2
        "ch05_cabin01_104" with dissolve
        0.2
        "ch05_cabin01_103" with dissolve
        0.2
        repeat
    play sound "audio/sex/penet_long_interval.mp3" loop volume 0.5
    scene ch05_cabin01_hj02 at hand_camera with Dissolve(0.8)
    d "아..........."
    o "나랑 섹스하고 싶니?"
    d "네......"
    image ch05_cabin01_hj04:
        "ch05_cabin01_110" with dissolve
        0.2
        "ch05_cabin01_111" with dissolve
        0.2
        "ch05_cabin01_112" with dissolve
        0.2
        "ch05_cabin01_113" with dissolve
        0.2
        "ch05_cabin01_112" with dissolve
        0.2
        "ch05_cabin01_111" with dissolve
        0.2
        repeat
    scene ch05_cabin01_hj04 at hand_camera with Dissolve(0.8)
    d "아..........."
    o "아만다랑 영원히 안볼수 있어?"
    d "........"
    o "왜 대답을 못해?"
    d "그...그건..."
    o "아무런 대가 없이 날 먹고 싶은거야?"
    d ".........."
    o "아만다도 따먹고 나도 따먹고 싶은거야? 허?"
    d ".........."
    o "자매를 모두 따먹을려고??!!"
    o "니가 무슨 왕이니?"
    image ch05_cabin01_hj05:
        "ch05_cabin01_113-02" with dissolve
        0.2
        "ch05_cabin01_113-03" with dissolve
        0.2
        "ch05_cabin01_113-04" with dissolve
        0.2
        "ch05_cabin01_113-05" with dissolve
        0.2
        "ch05_cabin01_113-04" with dissolve
        0.2
        "ch05_cabin01_113-03" with dissolve
        0.2
        repeat
    image ch05_cabin01_hj02-fast:
        "ch05_cabin01_102" with dissolve
        0.07
        "ch05_cabin01_103" with dissolve
        0.07
        "ch05_cabin01_104" with dissolve
        0.07
        "ch05_cabin01_105" with dissolve
        0.07
        "ch05_cabin01_104" with dissolve
        0.07
        "ch05_cabin01_103" with dissolve
        0.07
        repeat
    play sound "audio/sex/penet_short_interval.mp3" loop volume 0.5
    scene ch05_cabin01_hj02-fast at hand_camera with Dissolve(0.8)
    d "젠장......"
    pause
    image ch05_cabin01_hj04-fast:
        "ch05_cabin01_110" with dissolve
        0.07
        "ch05_cabin01_111" with dissolve
        0.07
        "ch05_cabin01_112" with dissolve
        0.07
        "ch05_cabin01_113" with dissolve
        0.07
        "ch05_cabin01_112" with dissolve
        0.07
        "ch05_cabin01_111" with dissolve
        0.07
        repeat
    scene ch05_cabin01_hj04-fast at hand_camera with Dissolve(0.8)
    d "아..........."
    d "젠장......"
    o "그래....."
    o "하아......."
    o "아마도 아만다와 날 둘다 따먹을 수 있을거야...."
    d "아......"
    o "니가 하기에 달렸어.."
    pause
    o "니가 하고싶다고 여자들이 허락하는건 아니거든."
    o "......"
    o "젠장....."
    play sound "audio/sex/penet_mid_interval.mp3" loop volume 0.5
    scene ch05_cabin01_hj05 at hand_camera with Dissolve(0.8)
    o "젠장 팔아파...."
    o "!!!!"
    o "사정할거 같지??"
    d "아..........."
    image ch05_cabin01_hj05-fast:
        "ch05_cabin01_113-02" with dissolve
        0.07
        "ch05_cabin01_113-03" with dissolve
        0.07
        "ch05_cabin01_113-04" with dissolve
        0.07
        "ch05_cabin01_113-05" with dissolve
        0.07
        "ch05_cabin01_113-04" with dissolve
        0.07
        "ch05_cabin01_113-03" with dissolve
        0.07
        repeat
    play sound "audio/sex/penet_short_interval.mp3" loop volume 0.5
    scene ch05_cabin01_hj05-fast at hand_camera with Dissolve(0.8)
    d "아..........."
    d "쌀거 같아요!!"
    o "그래!!!"
    o "사랑하는 날 위해 싸줘!!!"
    d "아....젠장!!!!!"
    scene ch05_cabin01_114 at hand_camera with Dissolve(0.2)
    stop sound
    d "악!!!"
    play sound "audio/sex/cum01.mp3"
    scene ch05_cabin01_115 at hand_camera with Dissolve(0.8)
    $ renpy.pause(2.0, hard=True)
    scene ch05_cabin01_116 at hand_camera with Dissolve(0.8)
    o "와우...."
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    o "미치겠다 정말....."
    o "엄청 많이 나왔네.."
    scene ch05_cabin01_117 at hand_camera with Dissolve(0.8)
    d "아....올리...."
    d "하........."
    scene ch05_cabin01_118 at hand_camera with Dissolve(0.8)
    o "좋았니?"
    d "네......"
    o "......"
    o "엄청 아쉬운 말투네 ㅎㅎ"
    o "내가 어떻게 해주길 바랬는데 멍청아."
    d "..........."
    scene ch05_cabin01_119 at hand_camera with Dissolve(1.2)
    o "어서 들어가서 자...."
    o "아만다 방으로 가지말고 알겠니?"
    d "네 알겠어요...."
    o "............"
    scene ch05_cabin01_120 at hand_camera with Dissolve(0.8)
    d "........."
    d "잘자요 올리..."
    scene ch05_cabin01_121 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_cabin01_122 at hand_camera with Dissolve(1.2)
    d "........."
    d "쉣....."
    d "뭐지...."
    d "내가 애처로워 보여서 해준건지 아니면...."
    d "일종의 올리비아의 쇼케이스였나...."
    d "......"
    d "도무지 종잡을수가 없어...."
    jump ch05_acar02

label ch05_acar02:
    if not in_replay:
        $ persistent.unlock_ch05_acar02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"


if not in_replay:
    $ send_phone_message("System", "", "celine_dm", message_kind=5, do_pause=False)
    $ send_phone_message("Celin", "What are you doing?.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What are you doing up this late?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "I couldn't sleep.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Me neither. I'm just lying here.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Is it really okay for a married woman to be texting a man this late at night?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Mention the married woman thing one more time and I'll eat you alive.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hahahaha.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Let's grab dinner tomorrow or the day after. What do you think?", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I'm always down.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Okay, good.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "I'll pick a time and give you a call.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Sounds good.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Go to sleep.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "And quit thinking dirty thoughts.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Yeah, yeah, I got it.", "celine_dm", do_pause=False)

    $ send_phone_message("System", "", "helen_dm", message_kind=5, do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I finished my interview and took a day trip with Amanda.", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I think we'll be heading home tomorrow.", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "Okay. Thanks for texting me.", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "No problem. Haha.", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "Have a good time, and I'll see you tomorrow.❤️", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Okay, see you tomorrow.", "helen_dm", do_pause=False)

    $ send_phone_message("System", "", "jason_dm", message_kind=5, do_pause=False)
    $ send_phone_message("Jason", "Yo, check this out, dude.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "images/phone/media/V05_jason01.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What the hell is this?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Look at the picture.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "????????", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "That's Professor Sophia, isn't it? Holy shit….", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Dude, the picture you sent me was Professor Sophia too!!", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Oh my God!!!!! How the hell did I not realize that?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Don't tell me you're pretending you didn't know.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "No, dude. I seriously had no idea.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "You were too busy staring at her tits to even look at her face, weren't you?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Fuck……", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "So, what was she like?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What do you mean, what was she like?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "You know, dude. Was she into it? That kind of thing.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "?? You dead???", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I guess she was pretty normal. Not too forward, not too reserved.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "She was cool with getting touchy with a younger guy like you?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Yeah, I guess so.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Holy shit…. That's some serious intel.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Fuck!! I'm gonna go jerk off. I'll call you later.", "jason_dm", do_pause=False)

    $ send_phone_message("System", "", "mary_dm", message_kind=5, do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What are you doing??", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Hey, Sweetie. I just got to the office.", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Why? Is something wrong?", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "No, haha.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I just missed you.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Mary??", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Why do you miss me? Haha.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Do I really need a reason to miss you? Haha.", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "I’m about to get started with work, so let’s talk later.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Oh, actually…", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Yeah?", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Could you send me a picture of yourself?", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "A picture of me?", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Yeah. A picture of you.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "A sexy one. Haha.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "??", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "You’re such a troublemaker. You know that?", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "images/phone/media/V05_mary01.jpg", "mary_dm", 2, summary_alt="mary Photo", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Wow, Mary……", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Haha.", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "This is so damn embarrassing 😂", "mary_dm", do_pause=False)
    $ send_phone_message("Mary", "Text me later, honey.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Wait Mary.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Mary??", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Just one more picture, please.", "mary_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "If you don't reply, I'll show up with roses and confess my love to you!!!", "mary_dm", do_pause=False)


    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/28_thumb.jpg",
            "phone": "images/phone/shots/28.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/29_thumb.jpg",
            "phone": "images/phone/shots/29.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/30_thumb.jpg",
            "phone": "images/phone/shots/30.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/31_thumb.jpg",
            "phone": "images/phone/shots/31.jpg",
        })

        $ gallery_notif = True

    scene ch05_acar02_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_04 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_05 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_05-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_05-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_05-04 at hand_camera with Dissolve(1.2)
    d ".........."
    o "........"
    scene ch05_acar02_06 at hand_camera with Dissolve(1.5)
    a "아우 머리가 깨질거 같아..."
    d "괜찮아요?"
    a "내가 왠 술을 그렇게..."
    play sound "audio/ambi/cardooropen.mp3"
    scene ch05_acar02_07 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/carstart01.mp3"
    pause
    scene ch05_acar02_07-02 at hand_camera with Dissolve(1.5)
    a "쟤도 어제 많이 마셨니?"
    a "얼굴이 맛이 갔는데?"
    d "그...그런거 같아요..."
    d "........"
    play sound "audio/ambi/carpass02.mp3"
    scene ch05_acar02_07-03 at hand_camera with Dissolve(1.5)
    a "어휴 저 미친년."
    a "앞섶이라도 좀 잠그지 뭐야 저게."
    a "저년은 이 산에 사는 마녀야."
    a "이 산에 사는 마녀라고."
    d "크흠....."
    d ".........."
    scene ch05_acar02_08 at hand_camera with Dissolve(0.8)
    o "..........."
    o "둘이 뭐라고 얘기하는거야?"
    o "..........."
    o "니들의 속셈을 다 안다고...."
    o "음흉한 사람들 같으니..."
    scene ch05_acar02_08-02 at hand_camera with Dissolve(0.8)
    o "라랄랄라~~~"
    o "......."
    play sound "audio/ambi/carpass.mp3"
    scene ch05_acar02_08-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_09 at hand_camera with Dissolve(0.8)
    a "하....나도 이제 늙었나봐."
    a "그 술 조금 마셨다고 완전히 뻗었었네."
    a "........."
    a "나 어제 혹시 헛소리 안했지?"
    scene ch05_acar02_10 at hand_camera with Dissolve(0.8)
    d "하하 네 별거 없었어요."
    d "그냥 뭐랄까...."
    d "그냥 단지 귀여웠어요 하하하하."
    scene ch05_acar02_11 at hand_camera with Dissolve(0.8)
    a "뭐야 그 말은?"
    a "........"
    a "내가 어제 뭔짓 했다는 거잖아?"
    scene ch05_acar02_10 at hand_camera with Dissolve(0.8)
    d "아니에요."
    d "그냥 술마시다가 피곤하다고 들어갔어요."
    d "올리비아와 좀 많이 마시긴 했죠. 둘다.."
    scene ch05_acar02_12 at hand_camera with Dissolve(0.8)
    a "............"
    a "흐음....."
    scene ch05_acar02_13 at hand_camera with Dissolve(0.8)
    d "왜요?"
    d "제가 거짓말 하는거 같아요?"
    scene ch05_acar02_14 at hand_camera with Dissolve(0.8)
    a "하하 아니야."
    a "신경쓰지마."
    scene ch05_acar02_15 at hand_camera with Dissolve(0.8)
    d "......"
    scene ch05_acar02_16 at hand_camera with Dissolve(0.8)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch05_acar02_17 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/cararrival.mp3"
    scene ch05_acar02_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_19 at hand_camera with Dissolve(0.8)
    stop sound fadeout 0.5
    a "오 이 집이야?"
    d "네. ㅎㅎ"
    a "집 좋네."
    a "밀프하임에 이런 동네가 있었구나."
    scene ch05_acar02_20 at hand_camera with Dissolve(0.8)
    d "다운타운하고 좀 멀긴한데 조용해서 좋아요."
    d "저 처럼 애늙은이가 살기 좋아요 하하하."
    scene ch05_acar02_20-02 at hand_camera with Dissolve(0.8)
    a "하루종일 방구석에서 게임만 하는건 아니지?"
    d "하하 안그래요."
    d "은근히 이거저거 할거 많아요 저."
    scene ch05_acar02_20-03 at hand_camera with Dissolve(0.8)
    a "그래 알겠어 ㅎㅎ."
    a "............."
    scene ch05_acar02_20-04 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_20-05 at hand_camera with Dissolve(0.8)
    a "........."
    d "........"
    scene ch05_acar02_20-06 at hand_camera with Dissolve(0.8)
    a "........."
    a "왜?"
    a "왜 그렇게 느끼하게 쳐다봐?"
    a "뭐 할 말 있어?"
    a "용돈 필요하니?"
    scene ch05_acar02_20-07 at hand_camera with Dissolve(0.8)
    d "어....."
    d "아..아무것도 아니에요."
    scene ch05_acar02_20-06 at hand_camera with Dissolve(0.8)
    a "........."
    scene ch05_acar02_21 at hand_camera with Dissolve(1.2)
    play voice_f "audio/sex/kissshort01.mp3"
    n "아만다와 [d_name]은 누가 먼저랄것 없이 서로에게 키스했다."
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
        $ add_point("love_amanda", 1, "love_amanda")
    n "분명 둘 모두 서로의 관계는 보호자와 피보호자라는 것을 인식하고 있었지만,"
    n "해변에서의 일을 겪고나서 그 들은 서로의 몸을 탐하는것에 조금 더 관대하고 솔직해졌다."
    scene ch05_acar02_21-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort02.mp3"
    pause
    scene ch05_acar02_21-03 at hand_camera with Dissolve(0.8)
    a "장난치지 말고 어서 들어가세요 아저씨."
    a "우리가 무슨 연인이니? ㅎㅎ"
    d "아...알겠어요..."
    scene ch05_acar02_22 at hand_camera with Dissolve(1.2)
    d "저랑 같이 집에 들어갈래요?"
    scene ch05_acar02_23 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh07.mp3"
    a "뭐? 하하하."
    scene ch05_acar02_23-02 at hand_camera with Dissolve(0.8)
    d "왜요 하하. 안될거 뭐 있어요?"
    d "제 방에서 잠시 쉬다가 가요."
    d "두통도 심할거 아니에요 지금?"
    d "제가 마사지 해줄게요."
    scene ch05_acar02_23-03 at hand_camera with Dissolve(0.8)
    a "니 방에서 쉬다 가라고?"
    a "........."
    pause
    a "안돼."
    a "나중에 너의 랜드레이디와 통화하고 서로 좀 알면 그때는 모르겠다."
    a "그리고 니가 말하는 마사지가 뭔지 뻔하거든?"
    a "내가 니 여자친구니?"
    scene ch05_acar02_22 at hand_camera with Dissolve(0.8)
    d "ㅎㅎ 알겠어요."
    d "........."
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch05_acar02_23-04 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_24 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/carleaving.mp3"
    scene ch05_acar02_25 at hand_camera with Dissolve(0.8)
    d ".........."
    scene ch05_acar02_25-02 at hand_camera with Dissolve(0.8)
    d "....."
    d "왜 갑자기 아만다를 보면 걱정이 되지??...."
    pause
    d "무슨 일이라도 생길거 처럼 기분이 이상해."
    scene ch05_acar02_26 at hand_camera with Dissolve(1.2)
    d "젠장.."
    d "불안장애라도 생기려고 하나.."
    d "잘못한것도 없는데 괜히 불안해...."
    pause
    d "아니 자매 모두에게 자지를 보여준거 자체가 미친짓이지 헤헤헤......"
    d "그녀들 속으론 날 변태라고 생각할수도 있어....."
    d "어색해지기 싫어서 티를 안내는거 뿐일 수 있다고..."
    jump ch05_hhouse00

label ch05_hhouse00:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse00 = True
    scene ch05_acar02_27 at hand_camera with Dissolve(1.2)
    play music "audio/bgm/normal10.mp3"
    d "!!!!"
    scene ch05_acar02_28 at hand_camera with Dissolve(0.8)
    b "!!!!"
    scene ch05_acar02_29 at hand_camera with Dissolve(0.8)
    d "아...."
    d "안녕하세요 베스."
    scene ch05_acar02_30 at hand_camera with Dissolve(0.8)
    b "아..안녕 [d_name]."
    if not in_replay:
        $ add_point("lust_beth", 1, "lust_beth")
    b "......"
    b "외출했다 들어오나봐요?"
    scene ch05_acar02_31 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch05_acar02_31-02 at hand_camera with Dissolve(0.8)
    b ".........."
    scene ch05_acar02_32 at hand_camera with Dissolve(0.8)
    d "아 네....."
    d "보호자와 짧은 여행을 다녀왔습니다..."
    scene ch05_acar02_33 at hand_camera with Dissolve(0.8)
    b "그랬군요..."
    b "재미있었겠네요 ㅎㅎ"
    b "....."
    b "아 너의 옷들은 방에 정리 해놨어요."
    scene ch05_acar02_34 at hand_camera with Dissolve(0.8)
    d "아 감사합니다."
    d "정리는 제가 해도 되는데...."
    b "괜찮아요. 내 일인걸요."
    scene ch05_acar02_35 at hand_camera with Dissolve(0.8)
    d "깁스 풀었네요??"
    d "......"
    b "아 네 맞아요.."
    scene ch05_acar02_36 at hand_camera with Dissolve(0.8)
    b "답답하다고 의사를 닥달했더니 허락해줬어요 하하."
    b "진짜 다시 태어난 느낌이에요."
    d "하하 너무 무리하진 마세요."
    play voice_f "audio/voices/flaugh04.mp3"
    b "절대 깁스할 일 만들지 말아요 알았죠? 하하."
    d "네 알겠습니다 하하."
    scene ch05_acar02_37 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/whiskey02.mp3"
    b "그럼....."
    b "필요한거 있으면 문자 보내요."
    d "네 ㅎㅎ 알겠습니다."
    scene ch05_acar02_38 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch05_acar02_39 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_40 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/whiskey02.mp3"
    pause
    scene ch05_acar02_41 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_42 at hand_camera with Dissolve(0.8)
    d "!!!!!!"
    scene ch05_acar02_43 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_44 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_44-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_45 at hand_camera with Dissolve(0.8)
    h "아...[d_name]군 왔어요?"
    scene ch05_acar02_42 at hand_camera with Dissolve(0.4)
    d "네......."
    d "자..잘 다녀왔습니다."
    scene ch05_acar02_45-02 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch05_acar02_45-03 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    pause
    scene ch05_acar02_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_47 at hand_camera with Dissolve(0.8)
    d "**(마이갓....)**"
    d "**(그녀 행동이 좀 이상한데...)**"
    scene ch05_acar02_48 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_48-02 at hand_camera with Dissolve(0.8)
    b "......."
    play voice_f "audio/voices/flaugh02.mp3"
    scene ch05_acar02_49 at hand_camera with Dissolve(0.8)
    h "하하하."
    h "이건 가슴을 가린걸까요 아닌걸까요?"
    scene ch05_acar02_50 at hand_camera with Dissolve(0.8)
    d "네??"
    d "아...미..미안합니다."
    scene ch05_acar02_48 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_52 at hand_camera with Dissolve(0.8)
    d "!!!"
    h "미안해요 하하."
    h "내 집에선 편하게 있을게요."
    h "내가 무슨 소녀도 아니고 참 이게 뭔지...."
    scene ch05_acar02_52-02 at hand_camera with Dissolve(0.8)
    b "..........."
    n "베스는 [h_name]의 행동에 다소 놀랐다."
    pause
    n "[h_name]의 성격을 잘 알고 있었지만 그에게 그녀의 맨 가슴을 오픈하는 것은 놀라웠다."
    scene ch05_acar02_53 at hand_camera with Dissolve(0.8)
    d "네??"
    d "아...그..그렇죠."
    d "제가 괜히 여기로 와서 방해한거 같습니다."
    d "편하게 쉬세요. 전 올라갈게요."
    scene ch05_acar02_54 at hand_camera with Dissolve(0.8)
    d "......."
    scene ch05_acar02_55 at hand_camera with Dissolve(0.8)
    h "저기 [d_name]!!"
    scene ch05_acar02_56 at hand_camera with Dissolve(0.8)
    d "네??"
    scene ch05_acar02_57 at hand_camera with Dissolve(0.8)
    d "!!!!"
    scene ch05_acar02_58 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    h "여기 자리도 많은데 같이 시간 보낼래요?"
    scene ch05_acar02_58-02 at hand_camera with Dissolve(0.8)
    d "네??!!"
    d "....."
    scene ch05_acar02_58 at hand_camera with Dissolve(0.8)
    h "베스와 나는 신경쓰지말고 자유롭게 여기서 시간보내요."
    h "아무도 뭐라 할 사람 없으니 편하게 입어도 돼요."
    h "나야 뭐 엄마 같은 나이고 베스도 이모뻘인데 너무 긴장하는거 같아서 좀 미안해서 그래요."
    h "집에서 불편하게 지내면 안되잖아요."
    scene ch05_acar02_58-02 at hand_camera with Dissolve(0.8)
    d "....."
    scene ch05_acar02_59 at hand_camera with Dissolve(0.8)
    d "아..전..."
    d "어제 잠을 못잤더니 피곤해서 침대에 좀 누워있으려구요..."
    d "다음에 여기서 편하게 쉴게요 하하."
    scene ch05_acar02_60 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ 그래요 그럼."
    h "그럼 난 이따 운동가니까 저녁 먹을 때 봐요."
    scene ch05_acar02_59 at hand_camera with Dissolve(0.8)
    d "아 네 알겠습니다."
    d "......."
    d "잘 다녀 오세요."
    scene ch05_acar02_61 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_acar02_62 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/whiskey02.mp3"
    scene ch05_acar02_63 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_acar02_64 at hand_camera with Dissolve(0.8)
    h "아......."
    h "이 위스키가 남자라면 내 온몸을 내 줄수 있어....."
    h "내 모든 구멍을 내 줄 수 있다고.."
    scene ch05_acar02_65 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh03.mp3"
    b "하하하하 맙소사 [h_name]...."
    b "갑자기 왠 구멍이야기를!!"
    b "언니는 병원가봐야 해요."
    b "진지하게 진짜로요."
    scene ch05_acar02_66 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    h "셧업 하하하."
    h "너무 경박스러운 말이었나??"
    h "나 요새 욕구불만인지 어쩌냐 정말.."
    stop voice_f fadeout 0.5
    jump ch05_gym01

label ch05_gym01:
    if not in_replay:
        $ persistent.unlock_ch05_gym01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A few hours later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal07.mp3"
    scene ch05_gym01_01 at hand_camera with Dissolve(1.2)
    play sound "audio/ambi/cardoorclose.mp3"
    h "후...."
    h "건강해지려고 왔는데 왜이렇게 마음이 무겁지?"
    h "운동 한걸로 하고 다시 집에 갈까..."
    scene ch05_gym01_01-02 at hand_camera with Dissolve(0.5)
    h "!!!!!!"
    scene ch05_gym01_02 at hand_camera with Dissolve(0.8)
    h "!!"
    play sound "audio/ambi/cardooropen.mp3"
    scene ch05_gym01_02-02 at hand_camera with Dissolve(1.0)
    pause
    scene ch05_gym01_02-03 at hand_camera with Dissolve(0.8)
    unknownm "으아...."
    h "........."
    unknownm "운동은 역시 좋아."
    unknownm "헥토르와 싸워도 이걸거같군!!"
    unknownm "내 조상은 분명 아킬레우스야."
    unknownm "이 야수같은 몸덩이는 분명 아킬레우스로부터 온거라고."
    scene ch05_gym01_03 at hand_camera with Dissolve(0.8)
    h "........"
    play sound "audio/ambi/cardoorclose.mp3"
    h "뭐야 저 남자.."
    h "어떻게 자신에게 저런 말을..."
    scene ch05_gym01_03-02 at hand_camera with Dissolve(1.2)
    h "........"
    h "[d_name]에게 좀 미안하네..."
    h "왜 날 너무 어렵게 대할까....."
    h "흐음....."
    h "찐하게 키스라도 해줘야 하나."
    scene ch05_gym01_04 at hand_camera with Dissolve(1.2)
    h "**(오늘은 어떤 운동이지?....)**"
    h "**(지난번에 하체 했으니까 오늘 상체인가?..)**"
    scene ch05_gym01_05 at hand_camera with Dissolve(0.8)
    h "**(그냥 아이비에게 쪼임 운동이나 하자고 할까?....)**"
    h "**(..........)**"
    h "**(그런 농담이 재밌니 [h_name]...)**"
    scene ch05_gym01_06 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_gym01_07 at hand_camera with Dissolve(0.8)
    h "!!!!"
    scene ch05_gym01_08 at hand_camera with Dissolve(0.8)
    h "**(와우......)**"
    scene ch05_gym01_09 at hand_camera with Dissolve(0.8)
    h "**(살은 많이 안쪘는데 가슴이 저렇게 크네...)**"
    h "**(저 여자 어깨 진짜 아프겠다.)**"
    scene ch05_gym01_10 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_gym01_11 at hand_camera with Dissolve(0.8)
    pause
    i "아니야!"
    i "자세가 틀렸잖아!"
    scene ch05_gym01_11-02 at hand_camera with Dissolve(0.8)
    h "..........."
    scene ch05_gym01_12 at hand_camera with Dissolve(0.8)
    i "하체 신경쓰고 자세 잡아!!"
    i "하체가 흔들리면 운동 효과가 없어진다고!!"
    scene ch05_gym01_13 at hand_camera with Dissolve(0.8)
    i "너희들이 지금 소모하는 칼로리도 곧 너희 재산이야."
    i "정석적인 자세로 움직여야 칼로리를 온전히 근육으로 바꿀 수 있어."
    i "명심해."
    i "운동은 누가 더 효율적으로 하냐가 제일 중요해."
    scene ch05_gym01_14 at hand_camera with Dissolve(0.8)
    unknownm "아...알겠습니다!!"
    scene ch05_gym01_15 at hand_camera with Dissolve(0.8)
    unknownm "..........."
    unknownm "**(젠장 저 몸을 봐...)**"
    unknownm "**(그녀에게 침대 위에서 깔리고 싶다.)**"
    scene ch05_gym01_16 at hand_camera with Dissolve(0.8)
    unknownm "**(젠장....)**"
    unknownm "**(그녀라면 나 같은 상남자도 복종의 즐거움을 느끼게 할 수 있을거 같아..)**"
    unknownm "**(내 자지가 뽑혀나갈수도 있을거 같아!!)**"
    scene ch05_gym01_17 at hand_camera with Dissolve(0.8)
    i "........"
    scene ch05_gym01_17-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_gym01_18 at hand_camera with Dissolve(1.2)
    i "안녕 [h_name]~"
    scene ch05_gym01_19 at hand_camera with Dissolve(0.8)
    i "매일 오진 않았지만 지난번 보다는 텀이 빨라졌네 하하."
    i "좋은 현상이야."
    scene ch05_gym01_20 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh02.mp3"
    h "하하."
    h "너의 잔소리 환청이 들려서 나왔어."
    scene ch05_gym01_21 at hand_camera with Dissolve(0.8)
    i "좋아. 훌륭해."
    i "원래 누군가 잔소리를 해야 운동이 되는거야."
    scene ch05_gym01_22 at hand_camera with Dissolve(0.8)
    h "누가 아니래."
    h "잔소리는 싫지만 그래도 너에게 감사해. 하하."
    h "다시 운동 시작하니까 확실히 삶에 에너지가 생기는거 같아."
    i "당연하지!"
    scene ch05_gym01_23 at hand_camera with Dissolve(0.8)
    i "자 오늘은 팔과 복근이야."
    i "원래는 한 부위씩 해야 하지만 니가 또 언제 올지 모르니 같이 할거야."
    scene ch05_gym01_24 at hand_camera with Dissolve(0.8)
    h "그럴줄 알았지."
    h "아.... 그래도 하체보다 상체 운동이 낫다."
    h "하체 운동은 너무 고통스러워..."
    scene ch05_gym01_25 at hand_camera with Dissolve(0.8)
    i "내 엉덩이가 부럽지 않은거야?"
    i "사실대로 말해. 오늘 하체 운동 하고 싶지?"
    h "닥쳐."
    h "운동 시작하실까요 선생님?"
    play voice_f "audio/voices/milflaugh12.mp3"
    i "하하하."
    scene ch05_gym01_26 at hand_camera with Dissolve(1.2)
    play music "audio/bgm/normal09.mp3"
    pause
    scene ch05_gym01_26-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_gym01_27 at hand_camera with Dissolve(1.2)
    i "하나 둘 하나 둘!!"
    i "허리 숙이지마!!"
    i "야 그러다 덤벨 놓친다 힘줘 손에!!"
    h "아..알겠어 하아..."
    scene ch05_gym01_28 at hand_camera with Dissolve(0.8)
    i "좋아 [h_name]!!"
    i "튕기듯이 들지말고 동작을 하나하나 느끼는거야!"
    h "알겠어."
    i "그래 그렇게!"
    scene ch05_gym01_29 at hand_camera with Dissolve(0.8)
    i "허리에 힘주고!!"
    i "어깨 돌아가게 하지마!!"
    i "팔뚝 힘으로만 드는거야."
    i "좋아 [h_name]!!"
    i "한 세트 더!"
    scene ch05_gym01_30 at hand_camera with Dissolve(0.8)
    h "나 주...죽을거 같아 아이비..."
    h "하아......."
    h "이게 다 뭔가 싶어...."
    i ".........."
    scene ch05_gym01_30-02 at hand_camera with Dissolve(0.8)
    h "하아 하아...."
    h "와 오늘 진짜 빡세게 했다..."
    i "자 이제 복근 한다."
    h "fuck...."
    scene ch05_gym01_31 at hand_camera with Dissolve(0.8)
    i "좋아 [h_name]."
    i "지난번 보다 더 집중하고 있어."
    i "동기부여가 더 된거 같은데 맞아?"
    scene ch05_gym01_32 at hand_camera with Dissolve(0.8)
    h "하아하아..."
    h "그래보이나?"
    h "식구가 하나 생겨서 그런가??"
    i "식구??"
    i "뭐야 집에 남자 들인거야?"
    scene ch05_gym01_33 at hand_camera with Dissolve(0.8)
    i "뭐야 집에 남자 들인거야???????"
    h "아니야."
    i "뭐야 그럼?"
    i "..........."
    i "임신한거야?"
    scene ch05_gym01_34 at hand_camera with Dissolve(0.8)
    h "응 맞아."
    h "임신했어."
    i "하하하. 축하해 [h_name]."
    h "고마워."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch05_gym01_35 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/heavybreath01.mp3" volume 2.0
    h "하아하아......"
    h "드디어 끝난건가?....."
    scene ch05_gym01_36 at hand_camera with Dissolve(0.8)
    i "끝나서 아쉬워?"
    play voice_f "audio/voices/milflaugh12.mp3"
    i "계속 할까? 하하하."
    scene ch05_gym01_37 at hand_camera with Dissolve(0.8)
    h "내 지금까지 들은 농담 중 가장 영양가 없는 농담이야 아이비."
    i "하하하."
    i "농담 아닌데?"
    h "너의 농담 타이밍을 도저히 모르겠다...."
    scene ch05_gym01_38 at hand_camera with Dissolve(0.8)
    i "아 그리고 [h_name]."
    i "중요한 말 할게 있거든?"
    i "샤워하고 가기전에 잠시 내 사무실에서 봐."
    i "대단한건 아니고 잠깐 할 말이 있어."
    h "왜 무슨 말인데?"
    h "그냥 여기서 하면 안돼?"
    i "중요한 말 이라니까."
    scene ch05_gym01_39 at hand_camera with Dissolve(0.8)
    h "그래 알겠어."
    h "이따 봐."
    scene ch05_gym01_40 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh03.wav"
    h "퓨........"
    scene ch05_gym01_41 at hand_camera with Dissolve(1.2)
    h "[d_name]이 와서 나좀 업고가줬으면 좋겠네."
    h "그럼 마구 이뻐해줄텐데."
    h "찐하게 키스도 해줄 수 있다고."
    play sound "audio/ambi/shower02.mp3" loop
    scene ch05_gym01_42 at hand_camera with Dissolve(2.0)
    pause
    scene ch05_gym01_43 at hand_camera with Dissolve(1.5)
    h "**(무슨 중요한 말이길래 사무실까지 오래..)"
    pause
    h "**(괜히 긴장되네.)**"
    scene ch05_gym01_43-02 at hand_camera with Dissolve(1.5)
    pause
    jump ch05_gym02

label ch05_gym02:
    if not in_replay:
        $ persistent.unlock_ch05_gym02 = True
    stop sound fadeout 0.5
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch05_gym01_44 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_gym01_45 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_gym01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_gym01_47 at hand_camera with Dissolve(0.8)
    h "!!"
    scene ch05_gym01_48 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/sus07.mp3"
    h "앗 미안."
    h "이따가 올까?"
    scene ch05_gym01_49 at hand_camera with Dissolve(0.8)
    i "아냐 괜찮아 ㅎㅎ."
    i "잠깐 땀 식히고 있었어. 어서 들어와."
    h "그래.."
    scene ch05_gym01_50 at hand_camera with Dissolve(1.5)
    h "우...팔아파.."
    play voice_f "audio/voices/milflaugh12.mp3"
    i "하하."
    i "단백질 잘 챙겨먹으라고."
    scene ch05_gym01_51 at hand_camera with Dissolve(0.8)
    h "이따 마트 들려서 닭고기 사갈려고."
    h "밥하기 귀찮을땐 닭요리가 최고지."
    h "근데 할말이 뭐야?"
    h "설마 나에게 사랑 고백하는건 아니지?"
    scene ch05_gym01_52 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh11.mp3"
    i "하하하하."
    i "어떻게 알았어?"
    i "난 사실 널 처음 본 순간부터 너와 사랑에 빠졌다고."
    scene ch05_gym01_53 at hand_camera with Dissolve(0.8)
    h "푸...."
    h "나랑 사귀려면 줄서야해."
    h "지금 한 10명은 대기하고 있어."
    h "소년 부터 할배까지 말이야."
    scene ch05_gym01_54 at hand_camera with Dissolve(0.8)
    i ".........."
    i "음....할 말이 뭐냐면 말이야..."
    scene ch05_gym01_55 at hand_camera with Dissolve(0.8)
    i "내가 지난번에 샤워하면서 말했던 그 남자 기억나지?"
    pause
    i "여기 가끔 와서 운동하는 아저씨."
    scene ch05_gym01_56 at hand_camera with Dissolve(0.8)
    h "..........."
    h "기억나지."
    pause
    h "근데 그 아저씨가 왜?"
    scene ch05_gym01_57 at hand_camera with Dissolve(0.8)
    i ".........."
    scene ch05_gym01_58 at hand_camera with Dissolve(0.8)
    i "그 아저씨에게 널 소개시켜 주려고."
    pause
    i "그 아저씨는 승락했어."
    scene ch05_gym01_59 at hand_camera with Dissolve(0.8)
    h "뭐?!!!"
    h "지...진짜로??"
    h "..........."
    h "내가 생각해본다고 했잖아."
    h "왜 갑자기 니 맘대로 그렇게 하는거야??"
    scene ch05_gym01_60 at hand_camera with Dissolve(0.8)
    i "워워 진정해 진정해."
    i "그냥 서로 연락이라도 해보라는거야."
    i "누가 지금 결혼하래?"
    scene ch05_gym01_61 at hand_camera with Dissolve(0.8)
    h "아니 그건 아니지만...."
    pause
    h "좀....갑작스러워서."
    scene ch05_gym01_60 at hand_camera with Dissolve(0.8)
    i "괜찮아."
    i "날 못 믿는거야?"
    i "심심해 보일 정도로 성실한 사람같아."
    i "이상한 놈이면 내가 당연히 얘기조차 안꺼냈겠지."
    h ".........."
    h "그야 그렇지.."
    scene ch05_gym01_62 at hand_camera with Dissolve(0.8)
    i "정말 괜찮은 사람이야."
    i "여유 있고 매너 좋고.."
    i "부족하지도 넘치지도 않는 사람이야."
    h "..............."
    scene ch05_gym01_63 at hand_camera with Dissolve(0.8)
    i "또 고민하는 척 하는거야??...."
    i "제발 [h_name]...."
    i "..........."
    i "자기야(여성들 끼리 애칭으로 부르는 단어)..."
    scene ch05_gym01_64 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_gym01_65 at hand_camera with Dissolve(0.8)
    i "너 혼자 산지 꽤 됐잖아?"
    h "........."
    i "혼자 사는 삶에 익숙해지면 안된다고."
    i "이제 좋은 사람 만나서 다시 시작해야지."
    i "그렇게 시간 보내다가 금방 50대 되고 폭삭 늙는다고."
    h ".........."
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_gym01_66 at hand_camera with Dissolve(0.8)
    h "!!!!!!!!!!!"
    n "그녀들이 얘기를 나누고 있을때 노크 없이 사무실의 문이 열렸다."
    scene ch05_gym01_67 at hand_camera with Dissolve(0.8)
    n "그리고 다소 성깔있어 보이는 중년의 남성이 걸어들어왔다."
    scene ch05_gym01_68 at hand_camera with Dissolve(0.8)
    h "..........."
    scene ch05_gym01_69 at hand_camera with Dissolve(0.8)
    unknownm "아 방해해서 미안해요."
    unknownm "........."
    unknownm "방문자가 있는지 몰랐습니다."
    scene ch05_gym01_70 at hand_camera with Dissolve(0.8)
    h "**(호..혹시..)**"
    h "**(저 사람인가?!!)**"
    h "**(오우 쉣....)**"
    h "**(가정폭력범 처럼 생겼는데???)**"
    scene ch05_gym01_71 at hand_camera with Dissolve(0.8)
    h "!!!!!"
    scene ch05_gym01_72 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort01.mp3"
    n "쪽(키스 의성어)"
    scene ch05_gym01_73 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort02.mp3"
    pause
    scene ch05_gym01_74 at hand_camera with Dissolve(0.8)
    unknownm "미안 합니다."
    unknownm "이거 제가 초면에 실례했습니다."
    scene ch05_gym01_75 at hand_camera with Dissolve(0.8)
    unknownm "나이가 드니 부끄러운것도 없네요 하하."
    unknownm "이상한 사람아니니 안심하세요."
    h "아 네...."
    scene ch05_gym01_76 at hand_camera with Dissolve(0.8)
    unknownm "운동하고 있을게."
    unknownm "이따가 봐요."
    scene ch05_gym01_77 at hand_camera with Dissolve(0.8)
    i "이따가 봐요 테디 베어 ㅎㅎ"
    scene ch05_gym01_78 at hand_camera with Dissolve(0.8)
    h "............."
    h "**(테디 베어....)**"
    scene ch05_gym01_79 at hand_camera with Dissolve(0.8)
    h "......."
    scene ch05_gym01_80 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh12.mp3"
    i "뭐? 하하하."
    i "불편하게 해서 미안해."
    scene ch05_gym01_81 at hand_camera with Dissolve(0.8)
    h "아...아니야."
    h "뭘 그런거 가지고 사과를....."
    scene ch05_gym01_82 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal03.mp3"
    i "이봐 [h_name]."
    i "너 지금까지 정말 열심히 살았잖아."
    i "난 그걸 가까이 서 그동안 지켜봐온 사람중에 하나야."
    h "......."
    scene ch05_gym01_83 at hand_camera with Dissolve(0.8)
    i "난 정말 니가 이젠 제대로 된 남자를 만났으면 좋겠어."
    i "..........."
    i "무슨 말인지 알지?"
    scene ch05_gym01_84 at hand_camera with Dissolve(0.8)
    i "여유 있고, 포용력 있고.."
    i "평범하게 돈 버는 그런 사람말이야."
    i "어느정도 자기 관리도 좀 하고.."
    i "인생의 후반을 같이 할 사람말이야."
    scene ch05_gym01_85 at hand_camera with Dissolve(0.8)
    h "..........."
    scene ch05_gym01_82 at hand_camera with Dissolve(0.8)
    i "니가 이 남자 저 남자 만나면서 즐기고 살겠다면야 할말 없지만....."
    i "..........."
    i "지금 그런것도 아니잖아?.."
    i "지금 우리 나이에 소녀 처럼 안절부절하면서 고민할거야?"
    scene ch05_gym01_81 at hand_camera with Dissolve(0.8)
    h "..........."
    scene ch05_gym01_86 at hand_camera with Dissolve(0.8)
    h "......"
    i "어떻게 생각해?"
    scene ch05_gym01_87 at hand_camera with Dissolve(0.8)
    h "알겠어."
    h "........"
    h "만나볼게."
    scene ch05_gym01_88 at hand_camera with Dissolve(0.8)
    i "잘 생각했어."
    i "그냥 가볍게 일단 만나서 어떤 사람인지 탐색해봐."
    i "맘에 든다고 그 사람 집에 졸졸 따라가지 말고 하하하."
    scene ch05_gym01_88-02 at hand_camera with Dissolve(0.8)
    h "........"
    i "아저씨들은 분위기 좋은거 같으면 자지 부터 꺼내려고 하니까 조심하라고 하하하."
    i "분위기 좋다고 덮썩 잡지 말라고."
    scene ch05_gym01_89 at hand_camera with Dissolve(0.8)
    h "어우...."
    h "그런 일은 절대 안일어나."
    scene ch05_gym01_90 at hand_camera with Dissolve(0.8)
    i "그럼 너의 연락처 그 남자에게 전해줄게."
    i "이따 문자 갈거야."
    scene ch05_gym01_91 at hand_camera with Dissolve(0.8)
    h "그래 알겠어."
    h "생각해줘서 고마워 아이비."
    scene ch05_gym01_91-02 at hand_camera with Dissolve(0.8)
    i "천만에."
    i "잘 되길 바래."
    i "잘 되면 나중에 저녁이나 쏴 하하."
    h "알겠어 ㅎㅎ"
    i "스킬들이 녹슬지 않았나 점검도 좀 하고."
    i "옷장에서 야한 속옷도 좀 꺼내고."
    h "셧업."
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_gym01_92 at hand_camera with Dissolve(0.8)
    h "나중에 봐."
    i "그래 운동은 이틀이상 거르면 안되는거 알지?"
    h "ㅎㅎ 알겠어."
    scene ch05_gym01_93 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_gym01_94 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/camera.mp3"
    pause
    scene ch05_gym01_95 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_gym01_96 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하........"
    pause
    h "모르겠다........"
    h "뭐 동네에서 친구하나 생기면 좋은거지 뭐.."
    h "큰일이라도 나겠어?"
    jump ch05_hhouse01

label ch05_hhouse01:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "That Evening" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal08.mp3"
    scene ch05_hhouse01_01 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/keyboard.mp3" volume 2.0 loop
    scene ch05_hhouse01_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_03 at hand_camera with Dissolve(0.8)
    d "젠장.."
    stop sound
    d "..........."
    d "교과서좀 읽고 했어야 했는데 벌써 가물가물하네."
    scene ch05_hhouse01_02 at hand_camera with Dissolve(0.8)
    d "흐음......"
    d "[d_name]이 만난 사람."
    d "로즈..."
    scene ch05_hhouse01_04 at hand_camera with Dissolve(0.8)
    d "상황은 마케팅 회사 인턴 면접..."
    d "제목은......"
    d "첫인상의 형성과 대인 인식에 관한 심리학적 분석."
    d "......."
    d "크....지린다..."
    d "박사 논문 제목 같은걸?"
    scene ch05_hhouse01_05 at hand_camera with Dissolve(0.8)
    h "[d_name]~~"
    h "잠깐만 나와줄래요?"
    scene ch05_hhouse01_02 at hand_camera with Dissolve(0.8)
    d "아..잠시만요!!"
    pause
    h "뭐라고요??"
    scene ch05_hhouse01_04 at hand_camera with Dissolve(0.8)
    d "그러니까 여기선 이 내용이 들어가면 되겠군..."
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_hhouse01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_07 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!"
    d "....."
    scene ch05_hhouse01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_09 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_09-02 at hand_camera with Dissolve(0.8)
    n "[d_name]의 방문이 열리고 [h_name]이 수줍게 웃으며 들어왔다."
    n "그녀는 메이크업도 하고 한껏 치장한 모습이었다."
    scene ch05_hhouse01_10 at hand_camera with Dissolve(0.8)
    d "아........"
    pause
    d "제가 학교 과제를 하느라 정신이...."
    scene ch05_hhouse01_11 at hand_camera with Dissolve(0.8)
    h "아 그랬군요."
    h "혹시 제가 방해한건 아니죠?"
    scene ch05_hhouse01_10 at hand_camera with Dissolve(0.8)
    d "아 아닙니다. 괜찮습니다."
    scene ch05_hhouse01_11 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ"
    h "나 어때 보여요?"
    scene ch05_hhouse01_10 at hand_camera with Dissolve(0.8)
    d "......."
    scene ch05_hhouse01_12 at hand_camera with Dissolve(0.8)
    h "그 반응은 뭐에요?....."
    h "......"
    h "이상해요?"
    scene ch05_hhouse01_12-02 at hand_camera with Dissolve(0.8)
    d "아...아니에요."
    d "너무 아름다워요 랜드레이디....."
    menu:
        n "What should I do?"
        "한 명의 여신 같아요.":
            d "한 명의 여...여신같아요....."
            h "뭐라고요??"
            scene ch05_hhouse01_13 at hand_camera with Dissolve(0.8)
            play voice_f "audio/voices/milflaugh10.mp3"
            h "여신이라고요? 하하."
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
            h "그 정도 칭찬을 바란건 아닌데.."
            h "너무 반응이 비현실적인데요?"
            scene ch05_hhouse01_14 at hand_camera with Dissolve(0.8)
            h "흐음..."
            h "내 이름이 그리스 신화의 여신급 여인 이름이긴하죠 하하."
        "제가 지금껏 본 가장 아름다운 여자에요.":

            d "제가 본 여자들 중에 제일 아... 아름다워요..."
            h "뭐라고요??"
            scene ch05_hhouse01_13 at hand_camera with Dissolve(0.8)
            play voice_f "audio/voices/milflaugh10.mp3"
            h "정말 그렇게 생각해요??"
            if not in_replay:
                $ add_point("love_helen", 1, "love_helen")
            h "그 정도 칭찬을 바란건 아닌데.."
            h "너무 반응이 비현실적인데요?"

    scene ch05_hhouse01_15 at hand_camera with Dissolve(0.8)
    d "아...그..그렇죠."
    d "........"
    d "근데 왜 이 시간에 이렇게 옷을 입었어요?"
    scene ch05_hhouse01_16 at hand_camera with Dissolve(0.8)
    h "나 약속이 있어서 막 나거려던 참이었어요."
    h ".........."
    h "남자의 의견이 필요해서 [d_name]에게 잠깐 물어봤어요 헤헤."
    scene ch05_hhouse01_17 at hand_camera with Dissolve(0.8)
    d "나...남자의 의견이요??"
    d "**(남자의 의견???)**"
    scene ch05_hhouse01_18 at hand_camera with Dissolve(0.8)
    h "솔찍히 말하면...."
    pause
    h "소개팅 받아서 남자 만나러 나가요."
    scene ch05_hhouse01_19 at hand_camera with Dissolve(0.8)
    d "네?!!!!!!!!"
    d "남자를 만난다구요?!!!"
    d "아니 왜...남자를..."
    scene ch05_hhouse01_20 at hand_camera with Dissolve(0.8)
    h "........"
    h "왜 그렇게 놀라요??"
    scene ch05_hhouse01_21 at hand_camera with Dissolve(0.8)
    h "남자 만나면 안돼요??"
    scene ch05_hhouse01_22 at hand_camera with Dissolve(0.8)
    d "아...하하하."
    d "......."
    d "제가 너무 말을 오버해서 했습니다."
    d "죄송합니다."
    scene ch05_hhouse01_23 at hand_camera with Dissolve(0.8)
    h "하하 아니에요."
    h "내가 너무 뜬금없이 얘기해서 그런걸거에요."
    scene ch05_hhouse01_24 at hand_camera with Dissolve(0.8)
    h "주방에 음식 차려놨으니 저녁 먹어요."
    h "알겠죠? 거르면 안돼요."
    scene ch05_hhouse01_25 at hand_camera with Dissolve(0.8)
    d "네 아...알겠습니다."
    d "감사합니다."
    scene ch05_hhouse01_26 at hand_camera with Dissolve(0.8)
    h "하하하."
    h "그렇게 졸졸 따라올거에요?"
    d "아..ㅎㅎ"
    scene ch05_hhouse01_27 at hand_camera with Dissolve(0.8)
    h "어서 들어가요."
    h "이러면 내가 무슨 해외여행 가는거 같잖아요 하하."
    d "네 ㅎㅎ 들어갈게요."
    d "잠시 신선한 공기를 마시러..."
    scene ch05_hhouse01_28 at hand_camera with Dissolve(0.4)
    d "!!!"
    scene ch05_hhouse01_29 at hand_camera with Dissolve(0.8)
    n "그가 도로 쪽을 봤을 때 한 중년의 남성이 어정쩡하게 서있었다."
    n "[d_name]은 본능적으로 그 남성에게 경계심을 느꼈다."
    scene ch05_hhouse01_30 at hand_camera with Dissolve(0.8)
    n "[h_name]이 그 남자에게 가까이 갈수록 [d_name]의 경계심은 긴장과 화로 바뀌었다."
    scene ch05_hhouse01_31 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_32 at hand_camera with Dissolve(1.3)
    pause
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch05_hhouse01_32-02 at hand_camera with Dissolve(1.3)
    pause
    play sound "audio/ambi/carleaving02.mp3"
    scene ch05_hhouse01_33 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_hhouse01_34 at hand_camera with Dissolve(1.3)
    d "..........."
    d "**(젠장.....)**"
    d "**(이건 그녀의 삶인데....)**"
    d "..........."
    d "**(왜 내 기분이 별로지?....)**"
    stop sound fadeout 0.5
    d "**(내가 [h_name]에게 뭐라도 되는것도 아니잖아..)**"
    play music "audio/bgm/night05.mp3"
    scene ch05_hhouse01_35 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_36 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_37 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_38 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_39 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_40 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse01_41 at hand_camera with Dissolve(1.5)
    d "젠장...."
    d "....."
    d "왜 랜드레이디에게 버림 받은 기분이 들지......."
    d "........."
    d "난 성인이 됐는데도 여전히 애 같은 놈이구나..."
    d "그녀가 내 엄마도 아닌데...."
    jump ch05_hhouse02

label ch05_hhouse02:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A few hours later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch05_hhouse01_41-02 at hand_camera with Dissolve(0.8)
    d "........."
    d "시간이 얼마나 흘렀지?....."
    d "......"
    d "세 시간??"
    pause
    d "네 시간??"
    scene ch05_hhouse01_41-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/cararrival.mp3"
    n "자동차 엔진 소리"
    d "!!"
    scene ch05_hhouse01_42 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_43 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_44 at hand_camera with Dissolve(0.8)
    d "**(어???!!!!!)**"
    d "[h_name]!!"
    scene ch05_hhouse01_45 at hand_camera with Dissolve(0.8)
    unknownm "아..안녕하세요."
    scene ch05_hhouse01_46 at hand_camera with Dissolve(0.8)
    d "젠장.."
    d "그녀에게 무슨 짓을 한거에요??!!"
    scene ch05_hhouse01_47 at hand_camera with Dissolve(0.8)
    unknownm "아니 제가 무슨 짓을 한건 아니에요."
    unknownm "그..그녀가 술을 좀.."
    d "제가 부축할게요."
    unknownm "조..조심해요."
    d "젠장 [h_name].."
    scene ch05_hhouse01_48 at hand_camera with Dissolve(0.8)
    unknownm "니가 그녀의 아들이겠군요."
    unknownm "이렇게 돼서 정말 미안해요."
    unknownm "하지만 내가 그녀에게 술을 먹인게 아니에요."
    unknownm "정말 입니다."
    scene ch05_hhouse01_49 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_50 at hand_camera with Dissolve(0.8)
    unknownm "........."
    unknownm "그녀가 마음에 쌓인게 많은가봐요."
    unknownm "아마 내가 잘못된 시기에 연락한거 같습니다."
    h "흐음....."
    scene ch05_hhouse01_51 at hand_camera with Dissolve(0.8)
    d ".........."
    scene ch05_hhouse01_52 at hand_camera with Dissolve(0.8)
    d "데려다 주셔서 감사합니다."
    d "그녀는 제가 챙길테니 이만 가보세요."
    d "감사합니다."
    play sound "audio/ambi/dooropen02.mp3"
    scene ch05_hhouse01_53 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_54 at hand_camera with Dissolve(0.8)
    unknownm "........."
    unknownm "젠장..."
    unknownm "........."
    unknownm "그녀와 다시 만나기는 글렀겠지?......"
    unknownm "......."
    unknownm "하....맘에 드는데..."
    scene ch05_hhouse01_55 at hand_camera with Dissolve(0.8)
    h "이거놔 이놈아.."
    d "괜찮아요 [h_name]?"
    h "날 모텔로 끌고 온거야?"
    d "집에 들어왔어요. 이제 괜찮아요."
    scene ch05_hhouse01_56 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/doorclose.mp3"
    h "집 엿먹으라고해."
    d "네?!!"
    h "여긴 내 집이 아니라 은행 집이라고!!"
    d "아...그..그렇군요."
    play voice_f "audio/voices/fhurt07.mp3"
    scene ch05_hhouse01_57 at hand_camera with Dissolve(0.8)
    h "아얏!!!"
    scene ch05_hhouse01_58 at hand_camera with Dissolve(0.8)
    d "쉣!!"
    d "[h_name]!!!!!"
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_hhouse01_59 at hand_camera with Dissolve(0.8)
    pause
    d "홀리....."
    d "......"
    scene ch05_hhouse01_60 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/erotic03.mp3"
    scene ch05_hhouse01_61 at hand_camera with Dissolve(0.8)
    n "그녀가 다리가 꼬여 넘어지며 소파에 엎어졌다."
    n "그녀의 자세는 그녀를 만나는 거의 모든 사람이 그녀로 부터 보기 원하는 자세였다."
    d "**(젠장.......)**"
    play voice_f "audio/voices/fsigh06.mp3"
    h "퓨........."
    h "팬티 벗겨줘."
    d "네??!!!!!!"
    scene ch05_hhouse01_62 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh16.mp3"
    h "나 이 자세 좋아해 헤헤헤."
    d "젠장!!"
    scene ch05_hhouse01_62-02 at hand_camera with Dissolve(0.8)
    n "[d_name]은 자신의 팬티를 벗겨달라는 말을 듣고 머릿속이 하얗게 변했다."
    n "그는 잠시 어떤 제대로 된 생각 조차 할 수 없었다."
    scene ch05_hhouse01_62-03 at hand_camera with Dissolve(0.8)
    n "그리고 엉덩이를 치켜들고 있는 [h_name]위 뒤에서 멍하니 서있을 뿐이었다."
    scene ch05_hhouse01_62-04 at hand_camera with Dissolve(0.8)
    n "그는 랜드레이디의 엉덩이 굴곡을 한 참 관찰했다."
    pause
    n "그리고 자신의 양심을 뒤로 하고 그녀의 요청을 들어주기로 결정했다."
    scene ch05_hhouse01_62-05 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_62-04 at hand_camera with Dissolve(0.8)
    d "아...알겠어요.."
    d "팬티를 벗겨드릴게요...."
    scene ch05_hhouse01_62-05 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "그녀의 치마를 들춘다.":
            play sound "audio/ambi/fabric03.mp3"
            scene ch05_hhouse01_62-06 at hand_camera with Dissolve(0.8)
            pause
    scene ch05_hhouse01_62-07 at hand_camera with Dissolve(0.8)
    h "흐응....."
    scene ch05_hhouse01_62-08 at hand_camera with Dissolve(0.8)
    n "그는 랜드레이디 드레스의 밑단을 들춰올렸다."
    pause
    n "그의 심장은 밖으로 튀어나올듯이 쿵쾅거렸다."
    menu:
        n "What should I do?"
        "그녀의 팬티를 벗긴다.":
            scene ch05_hhouse01_62-09 at hand_camera with Dissolve(0.8)
            pause
    scene ch05_hhouse01_62-10 at hand_camera with Dissolve(0.8)
    h "흐음........"
    scene ch05_hhouse01_62-11 at hand_camera with Dissolve(0.8)
    h "그건...."
    d "네??!!!"
    play voice_f "audio/voices/fsigh06.mp3"
    h "후우......"
    h "그건..... 벗기는게..... 아니잖아.."
    d "아 그...그렇죠.."
    play sound "audio/ambi/fabric03.mp3"
    scene ch05_hhouse01_62-12 at hand_camera with Dissolve(1.0)
    pause
    scene ch05_hhouse01_62-13 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag02.wav"
    h "욱!!"
    h "토 할거 같아."
    scene ch05_hhouse01_62-08 at hand_camera with Dissolve(0.4)
    d "!!!!!!!!"
    d "토할거 같다구요?!!"
    h "응 토할거 같아."
    scene ch05_hhouse01_63 at hand_camera with Dissolve(0.8)
    d "젠장 [h_name]."
    d "소파에 토하면 안돼요!!"
    d "괜찮아요??"
    d "제가 부축할게요."
    scene ch05_hhouse01_63-02 at hand_camera with Dissolve(0.8)
    h "그래 거칠게 박아줘."
    d "홀리...[h_name]..."
    d "바..방으로 부축할게요."
    play sound "audio/ambi/fabric03.mp3"
    scene ch05_hhouse01_64 at hand_camera with Dissolve(0.8)
    h "여기도....괜찮은데...."
    h "우욱......"
    d "젠장!! 괜찮아요??"
    h "난 괜찮아.. 난 괜찮아..."
    scene ch05_hhouse01_65 at hand_camera with Dissolve(0.8)
    d "악!!"
    scene ch05_hhouse01_65-02 at hand_camera with Dissolve(0.8)
    d "악!!"
    play sound "audio/ambi/drop01.wav"
    scene ch05_hhouse01_66 at hand_camera with Dissolve(0.3)
    d "악 내 엉덩이!!"
    scene ch05_hhouse01_67 at hand_camera with Dissolve(0.8)
    h "끄응....."
    h "아저씨는 이 자세를 좋아하는군요...."
    h "박력 있네요 아저씨.."
    d "젠장!!"
    d "정신 차려요 [h_name]!!"
    scene ch05_hhouse01_68 at hand_camera with Dissolve(0.8)
    h "끄응....."
    scene ch05_hhouse01_69 at hand_camera with Dissolve(0.8)
    h "뭐......해?......"
    d "네?!!"
    d "아 제..제가 넘어지는 바람에..."
    h "나 기다리고 있잖아..."
    d "네?????!!"
    scene ch05_hhouse01_70 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    d "미안해요 [h_name]."
    d "제가 일으켜 드릴게요!!"
    scene ch05_hhouse01_71 at hand_camera with Dissolve(0.8)
    d "**(젠장!!)**"
    d "**(왜 술취한 사람은 항상 무거운거야??!!)**"
    d "**(젠장 일어서질 못하겠어.)**"
    d "**(아만다가 이래서 나보고 운동하라고 한거구나!!)**"
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_hhouse01_72 at hand_camera with Dissolve(0.8)
    d "후아후아...."
    d "보..보기보다 무겁네요 [h_name].."
    h "..........."
    scene ch05_hhouse01_72-02 at hand_camera with Dissolve(0.8)
    d "쉣!!"
    h "이....자세도.....괜찮네...."
    d "그...그런거 아니에요!!"
    scene ch05_hhouse01_73 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    d "Fuck!!!"
    play sound "audio/ambi/drop01.wav"
    scene ch05_hhouse01_74 at hand_camera with Dissolve(0.8)
    h "예스........."
    h "퍽미....."
    scene ch05_hhouse01_75 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_76 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    d "이건 좋지 않아!!"
    scene ch05_hhouse01_77 at hand_camera with Dissolve(0.8)
    h "그래..이건.......좋지않아...."
    h "내가.......일어날게.."
    pause
    h "일어날수 있다고....내가...."
    scene ch05_hhouse01_78 at hand_camera with Dissolve(0.8)
    d "[h_name] 괜찮아요?"
    d "다리에 힘좀 줘봐요!!"
    d "**(젠장 그녀를 업어야 하냐?)**"
    scene ch05_hhouse01_79 at hand_camera with Dissolve(0.8)
    h "나 발아파."
    h "나 발아퍼 달링~~"
    scene ch05_hhouse01_80 at hand_camera with Dissolve(0.8)
    h "구두 벗을거야."
    h "벗으면 덜 섹시하지만...."
    scene ch05_hhouse01_81 at hand_camera with Dissolve(0.8)
    d "아...[h_name]!"
    scene ch05_hhouse01_81-02 at hand_camera with Dissolve(0.8)
    d "퍽!!!"
    d "다리를 다 들면 안돼요!!!!"
    d "아..이러다 또 넘어져요!!!"
    stop music fadeout 0.5
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_hhouse01_82 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_83 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_84 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fshock01.mp3"
    l "!!!!!!!"
    scene ch05_hhouse01_85 at hand_camera with Dissolve(0.8)
    d "............"
    d "**(누구지 이시간에??)**"
    d "**(젠장!!!!!)**"
    scene ch05_hhouse01_86 at hand_camera with Dissolve(0.8)
    d "누..누구세요?!!"
    d "젠장...."
    scene ch05_hhouse01_86-02 at hand_camera with Dissolve(0.8)
    l "..........."
    l "웟.."
    l "웟 더.."
    l "웟 더 퍽.."
    scene ch05_hhouse01_86-03 at hand_camera with Dissolve(0.8)
    l "......"
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
        $ add_point("sus_lena", 1, "sus_lena")
    l "뭐하고 있는거야???....."
    l "홀리......"
    l "너 이 꼬마녀석!!"
    l "드디어 본색을 드러내는구나!!"
    scene ch05_hhouse01_87 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse01_88 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/camera.mp3"
    n "찰칵!!"
    scene ch05_hhouse01_88-02 at hand_camera with Dissolve(0.8)
    d "............"
    d "레...레나...."
    d "아...안녕하세요."
    h "이 분위기 어쩔거야......"
    d "네?!!"
    scene ch05_hhouse01_89 at hand_camera with Dissolve(0.8)
    d "부..분위기요?"
    h "난 쓰리섬은 안해봤어."
    d "............"
    jump ch05_hhouse03

label ch05_hhouse03:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse03 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "That Night" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch05_hhouse02_01 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse02_02 at hand_camera with Dissolve(1.5)
    n "레나는 술에 취해 인사불성이 된 [h_name]을 침대에 눕혔다."
    n "그리고 그녀가 편하게 자게하기 위해 그녀의 옷을 모두 벗겼다."
    scene ch05_hhouse02_03 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse02_04 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_hhouse02_05 at hand_camera with Dissolve(1.5)
    l "........."
    scene ch05_hhouse02_05-02 at hand_camera with Dissolve(1.5)
    l "........."
    l "넌 정말 아름다워 [h_name]..."
    scene ch05_hhouse02_06 at hand_camera with Dissolve(0.8)
    l "넌 꼬마일 때 부터 가장 아름다웠어."
    pause
    l "그 아름다움이 나이가 들어도 사라지질 않는구나."
    scene ch05_hhouse02_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_08 at hand_camera with Dissolve(0.8)
    n "레나는 [h_name]의 젖꼭지를 입에 넣었다."
    pause
    n "그리고 얼마간 [h_name]의 젖꼭지를 음미했다."
    scene ch05_hhouse02_08-02 at hand_camera with Dissolve(0.8)
    l "네가 술에 취해 잠들줄은 꿈에도 몰랐네."
    l "전화라도 하고 올걸 그랬네.."
    l "......."
    l "잘 쉬고 있어 베이비."
    scene ch05_hhouse02_08-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_09 at hand_camera with Dissolve(0.8)
    n "거실에선 [d_name]이 초조한 모습으로 앉아있었다."
    scene ch05_hhouse02_10 at hand_camera with Dissolve(0.8)
    d "!!"
    scene ch05_hhouse02_10-02 at hand_camera with Dissolve(1.28)
    pause
    scene ch05_hhouse02_11 at hand_camera with Dissolve(0.8)
    d "**(젠장.....)**"
    d "**(그녀 기분이 별로 안좋아 보이는데...)**"
    scene ch05_hhouse02_12 at hand_camera with Dissolve(0.8)
    pause
    n "그들은 잠시 말 없이 앉아있었다."
    pause
    n "[d_name]은 세입자의 입장에서 긴장하고 있었지만,"
    n "레나는 즐거움에 지어지는 미소를 억지로 참고 있었다."
    scene ch05_hhouse02_13 at hand_camera with Dissolve(0.8)
    d ".........."
    scene ch05_hhouse02_14 at hand_camera with Dissolve(0.8)
    l "......"
    d "크흠......"
    d "그....저기..."
    scene ch05_hhouse02_16 at hand_camera with Dissolve(0.8)
    l "......"
    scene ch05_hhouse02_17 at hand_camera with Dissolve(0.8)
    d "그건 우연이었어요....."
    d ".........."
    d "레나가 생각하는 그런게 아니에요.."
    scene ch05_hhouse02_16 at hand_camera with Dissolve(0.8)
    l "......"
    scene ch05_hhouse02_17 at hand_camera with Dissolve(0.8)
    d "제가 흑심이 있어서 랜드레이디의 옷을 벗겼거나....."
    d ".........."
    scene ch05_hhouse02_17-02 at hand_camera with Dissolve(0.8)
    d "제 자지...아니 제 물건을 그렇게 꺼내놓은게 아니에요....."
    scene ch05_hhouse02_17-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_18 at hand_camera with Dissolve(0.8)
    d "**(젠장 깜짝이야..)**"
    scene ch05_hhouse02_19 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_20 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_hhouse02_21 at hand_camera with Dissolve(0.8)
    d "**(...........)**"
    d "**(젠장 아무말도 없으니까 더 불안하잖아.)**"
    d "**(내 말을 믿는건지 아닌지 모르겠네.)**"
    scene ch05_hhouse02_22 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_22-02 at hand_camera with Dissolve(1.2)
    l "너......"
    scene ch05_hhouse02_22-03 at hand_camera with Dissolve(0.8)
    l "[h_name]에게 무슨 짓을 하려던거야?"
    l "이 변태 녀석아."
    scene ch05_hhouse02_23 at hand_camera with Dissolve(0.8)
    d "그...그게 아니라요.."
    l "뭐가 아니야??!!"
    l "이 무식한 놈."
    l "술에 취한 여자를 그렇게 들어안고 흉하게 말이야!!"
    scene ch05_hhouse02_22-03 at hand_camera with Dissolve(0.8)
    l "너 이럴려고 이 집에 들어온거지??"
    d "네?!!"
    l ".........."
    l "여자 혼자 사는 집인거 알고 들어온거지??!!"
    scene ch05_hhouse02_24 at hand_camera with Dissolve(0.8)
    d "아 아니에요!!"
    d "절대 그런거 아니에요."
    d "그...저기..."
    scene ch05_hhouse02_24-02 at hand_camera with Dissolve(0.8)
    d ".............."
    d "[h_name]은 나에게 랜드레이디지 여자가 아니에요."
    d "제가 어떻게 그녀를 여자로 생각을...."
    scene ch05_hhouse02_25 at hand_camera with Dissolve(0.4)
    l "뭐?"
    l "........."
    l "그게 무슨 뜻이야?"
    pause
    l "[h_name]이 여자로서 매력이 없다는거야?!!"
    l "그녀와 내가 나이든 아줌마라는거야??!!!"
    scene ch05_hhouse02_26 at hand_camera with Dissolve(0.8)
    d "네??!!"
    d "........"
    d "아...그게 아니라..."
    d "그녀는 물론 정말 섹시한 여자입니다."
    d "그..그녀는 정말 섹시한 여자에요."
    scene ch05_hhouse02_26-02 at hand_camera with Dissolve(0.8)
    l "뭐? 섹시??!!!"
    d "아...아니 그게아니라요.."
    l "뭐가 아니야?"
    l "여태 [h_name]을 그런 생각으로 관찰하고 이었지???!!"
    l "드디어 너의 본색을 드러내는구나 이 음흉한 놈!!"
    scene ch05_hhouse02_26 at hand_camera with Dissolve(0.8)
    d "네??!!"
    scene ch05_hhouse02_27 at hand_camera with Dissolve(0.8)
    d "하......"
    l ".........."
    d "......"
    pause
    l "나는 어때?"
    l ".........."
    d "......"
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_hhouse02_27-02 at hand_camera with Dissolve(0.8)
    l "나도 섹시하냐고 묻잖아."
    scene ch05_hhouse02_28 at hand_camera with Dissolve(0.8)
    d "......."
    d "..........."
    d "네.....맞아요.."
    d "레나도 섹시해요..."
    scene ch05_hhouse02_29 at hand_camera with Dissolve(0.8)
    d "........."
    d "엄청 섹시해요.."
    scene ch05_hhouse02_30 at hand_camera with Dissolve(0.8)
    l "........"
    l "너..."
    l "....."
    l "너 지금 나랑 섹스하는 생각하지?"
    d "네????!!!!"
    scene ch05_hhouse02_30-02 at hand_camera with Dissolve(0.8)
    d "........"
    l "솔찍하게 말해."
    scene ch05_hhouse02_31 at hand_camera with Dissolve(0.8)
    d "......."
    pause
    d "네 맞아요..."
    pause
    d "레나와 섹스하는 상상했어요...."
    scene ch05_hhouse02_32 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
    l "이놈 시키."
    l "이 어린노무 자식이 지 엄마 같은 여자한테 한다는 소리가..."
    l "........"
    pause
    l "[h_name]과도 떡치고 싶지?"
    scene ch05_hhouse02_31 at hand_camera with Dissolve(0.8)
    d "......."
    d "....."
    scene ch05_hhouse02_33 at hand_camera with Dissolve(0.8)
    l "사실대로 말해."
    l "내가 안나타났으면 오늘 [h_name]을 따먹으려고 했었잖아..."
    l "아님 최소 그녀 입이라도 느끼고 싶었잖아 그치??"
    scene ch05_hhouse02_34 at hand_camera with Dissolve(0.8)
    d "......"
    l "아니야?"
    d ".........."
    l "........."
    l "아니야??????"
    pause
    d "네 맞아요."
    scene ch05_hhouse02_34-02 at hand_camera with Dissolve(0.8)
    l "........"
    l "음흉한 놈."
    l "니 엄마 나이인 여자들에게 감히 성욕을 느껴??!!"
    scene ch05_hhouse02_35 at hand_camera with Dissolve(0.8)
    d "죄송합니다..."
    l "........"
    l "일어서."
    scene ch05_hhouse02_36 at hand_camera with Dissolve(0.8)
    d "네??"
    l "일어서보라고."
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_hhouse02_36-02 at hand_camera with Dissolve(0.8)
    d "......"
    d "왜...왜요?..."
    l "아잉 그냥 일어서봐 허니."
    d "......"
    scene ch05_hhouse02_37 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_hhouse02_38 at hand_camera with Dissolve(0.8)
    l "증명해봐."
    scene ch05_hhouse02_39 at hand_camera with Dissolve(0.8)
    d "네??"
    scene ch05_hhouse02_40 at hand_camera with Dissolve(0.8)
    l "못알아들은척 하지마."
    l "증명해 보라고."
    d "증명이요??"
    d "......"
    d "뭘 증명하라는 건지...."
    scene ch05_hhouse02_39 at hand_camera with Dissolve(0.8)
    l "니가 [h_name]과 나를 따먹을 자격이 되는지 보여보라고."
    d "!!!!!!"
    l "어서."
    d "........"
    pause
    d "네....아..알겠어요.."
    play sound "audio/ambi/fabric03.mp3"
    scene ch05_hhouse02_41 at hand_camera with Dissolve(0.8)
    n "[d_name]은 바지와 함께 팬티를 내렸다."
    n "그는 자신의 성기를 여성에게 노출하는데 점점 익숙해지고 있었다."
    pause
    n "그리고 여성에게 자신의 성기를 노출하는데 오는 흥분에 젖어들고 있었다."
    play music "audio/bgm/erotic10.mp3"
    scene ch05_hhouse02_42 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
    scene ch05_hhouse02_43 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_44 at hand_camera with Dissolve(0.8)
    l "마이갓......"
    pause
    l "이런..."
    l "홀리......"
    scene ch05_hhouse02_45 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_45-02 at hand_camera with Dissolve(0.8)
    l "**(하.....)**"
    l "**(또 보는것만으로 내 보지가 움찔거리네...)**"
    l "......."
    l "만져 줄까?"
    scene ch05_hhouse02_39 at hand_camera with Dissolve(0.8)
    d "......"
    scene ch05_hhouse02_43 at hand_camera with Dissolve(0.8)
    d "네......"
    l "하하 네?"
    d "......"
    scene ch05_hhouse02_46 at hand_camera with Dissolve(0.8)
    l "이 음흉한 꼬마녀석....."
    l "요즘 놈들은 다 너 처럼 부끄런운줄도 모르니?...."
    scene ch05_hhouse02_47 at hand_camera with Dissolve(0.8)
    d "!!!"
    scene ch05_hhouse02_48 at hand_camera with Dissolve(0.8)
    d "**(쉣.....)**"
    scene ch05_hhouse02_49 at hand_camera with Dissolve(0.8)
    l "**(이 정도면 야동배우 해야 하는거 아냐??....)**"
    l "**(......)**"
    scene ch05_hhouse02_50 at hand_camera with Dissolve(0.8)
    l "**(맙소사....)**"
    l "**(만지는것 만으로 그의 힘이 느껴져....)**"
    l "**(젠장....)**"
    l "**(이걸로 쑤셔지고 싶다..)**"
    scene ch05_hhouse02_51 at hand_camera with Dissolve(0.8)
    l "너........"
    l "나이 많은 아줌마와 섹스한적 있니?"
    l "그러니까...."
    l "중년 여성과 섹스하는건 어떻게 생각해?"
    scene ch05_hhouse02_52 at hand_camera with Dissolve(0.8)
    d "아........"
    d "아니 사실...."
    pause
    d "잘 모르겠어요.."
    l "잘 모르겠어요는 또 뭐야.."
    scene ch05_hhouse02_52-02 at hand_camera with Dissolve(0.8)
    l "**(보지가 또 움찔거려....)**"
    l "**(.....)**"
    l "**(이거에 쑤셔지면 며칠은 섹스 생각 안날거 같아...)**"
    scene ch05_hhouse02_53 at hand_camera with Dissolve(0.8)
    n "그녀는 조용히 사진의 얼굴을 그의 성기 가까이 가져갔다."
    scene ch05_hhouse02_54 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    scene ch05_hhouse02_55 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_56 at hand_camera with Dissolve(0.8)
    d "**(이 일이 일어나는건가?!!)**"
    d "**(레나가 빨아주는건가???)**"
    scene ch05_hhouse02_57 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_55 at hand_camera with Dissolve(0.8)
    l "................."
    scene ch05_hhouse02_59 at hand_camera with Dissolve(0.8)
    d "!!"
    scene ch05_hhouse02_60 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_61 at hand_camera with Dissolve(0.8)
    l "난 [h_name]에게 아무것도 숨기지 않아."
    d "네?!!"
    scene ch05_hhouse02_62 at hand_camera with Dissolve(0.8)
    d "........"
    d "수..숨기지 않다는게 무슨 말이에요?"
    scene ch05_hhouse02_63 at hand_camera with Dissolve(0.8)
    n "그녀는 [d_name]의 귀두를 입에 넣으려다 말고 돌연 일어섰다."
    n "그리고 그의 손을 잡고 [h_name]이 자고 있는 방으로 이끌었다."
    l "따라와."
    scene ch05_hhouse02_64 at hand_camera with Dissolve(0.8)
    d "웟?!!"
    d "레나 지금 뭐하는거에요??"
    d "이 방엔 래...랜드레이디가 있잖아요??!!"
    scene ch05_hhouse02_65 at hand_camera with Dissolve(0.8)
    l "그냥 날 따라와."
    scene ch05_hhouse02_66 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse02_67 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/dooropen02.mp3"
    scene ch05_hhouse02_67-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_68 at hand_camera with Dissolve(0.8)
    d "**(!!!!!!!!!!!!!!!!)**"
    play music "audio/bgm/night04.mp3"
    scene ch05_hhouse02_68-02 at hand_camera with Dissolve(0.8)
    d "**(!!!!!!!!!!!!!!!!)**"
    scene ch05_hhouse02_69 at hand_camera with Dissolve(0.8)
    n "[d_name]은 자신의 눈앞에 펼쳐진 광경을 믿을 수 없었다."
    scene ch05_hhouse02_70 at hand_camera with Dissolve(0.8)
    n "자신의 눈앞엔 나체의 랜드레이디가 누워있었다."
    scene ch05_hhouse02_71 at hand_camera with Dissolve(0.8)
    d "**(맙소사......[h_name]....)**"
    pause
    d "**(그녀가 지금 무슨 짓을 하려는 거지??!!)**"
    d "**(서...설마...)**"
    pause
    d "**(레...랜드레이디와 내가 뭔가 하게되는건가???!!!!)**"
    scene ch05_hhouse02_71-02 at hand_camera with Dissolve(0.8)
    d "**(홀리쉣.......)**"
    d "**(그녀를 봐......)**"
    d "**(당장 그녀 위에 올라타고 싶다....)**"
    d "**(하........)**"
    d "**(그녀와 껴앉고 자는것만으로 사정할수도 있을거같아.......)**"
    scene ch05_hhouse02_71-02-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_71-03 at hand_camera with Dissolve(0.8)
    d "**(맙소사.....)**"
    scene ch05_hhouse02_71-04 at hand_camera with Dissolve(0.8)
    d "여...여긴 왜 들어온거에요?....."
    d "......."
    d "래..랜드레이디와 뭔가 하려는거에요?"
    scene ch05_hhouse02_05 at hand_camera with Dissolve(0.8)
    l "............"
    scene ch05_hhouse02_71-04 at hand_camera with Dissolve(0.8)
    d ".........."
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_hhouse02_72 at hand_camera with Dissolve(0.8)
    d "아......"
    scene ch05_hhouse02_72-02 at hand_camera with Dissolve(0.8)
    d "으흥..........."
    n "그의 성기에 최근 느꼈던 익숙한 감촉이 느껴졌다."
    pause
    n "귀두부터 따뜻하고 촉촉하게 감싸오는 여성의 입안....."
    n "그안에서 레나의 혀가 부드럽게 움직이기 시작했다."
    scene ch05_hhouse02_73 at hand_camera with Dissolve(0.8)
    n "[d_name]은 최근 여성에게 블로우잡을 받으며 경험이 쌓이기 시작했다."
    n "그는 여성의 입의 감촉으로 그 여성이 능숙한지 아닌지 판단할 수 있게 되었다."
    scene ch05_hhouse02_74 at hand_camera with Dissolve(0.8)
    n "그의 성기로부터 알 수 있는 것은 레나는 블로우잡에 능숙한 여성이었다."
    scene ch05_hhouse02_75 at hand_camera with Dissolve(0.8)
    d "아으........"
    scene ch05_hhouse02_75-02 at hand_camera with Dissolve(0.8)
    n "레나는 조금씩 조금씩 자신의 입안으로 [d_name]의 성기를 넣어갔다."
    scene ch05_hhouse02_76 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    l "꺼억...."
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
    scene ch05_hhouse02_77 at hand_camera with Dissolve(0.8)
    l "**(젠장!!)**"
    l "**(입에 넣었을 뿐인데 숨쉬기가 힘들어..)**"
    scene ch05_hhouse02_78 at hand_camera with Dissolve(0.8)
    d "아....레나...."
    d "느낌이....너무 좋아요....."
    image ch05_hhouse02_bj01:
        "ch05_hhouse02_79" with dissolve
        0.1
        "ch05_hhouse02_80" with dissolve
        0.1
        "ch05_hhouse02_81" with dissolve
        0.1
        "ch05_hhouse02_82" with dissolve
        0.1
        "ch05_hhouse02_83" with dissolve
        0.1
        "ch05_hhouse02_84" with dissolve
        0.1
        "ch05_hhouse02_83" with dissolve
        0.1
        "ch05_hhouse02_82" with dissolve
        0.1
        "ch05_hhouse02_81" with dissolve
        0.1
        "ch05_hhouse02_80" with dissolve
        0.1
        repeat
    scene ch05_hhouse02_bj01 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop
    d "으......."
    d "**(맙소사.....)**"
    d "**(이건 진짜 느낌이 좋아...아....)**"
    scene ch05_hhouse02_85 at hand_camera with Dissolve(0.8)
    d "흐응........."
    image ch05_hhouse02_bj02:
        "ch05_hhouse02_86" with dissolve
        0.1
        "ch05_hhouse02_87" with dissolve
        0.1
        "ch05_hhouse02_88" with dissolve
        0.1
        "ch05_hhouse02_89" with dissolve
        0.1
        "ch05_hhouse02_90" with dissolve
        0.1
        "ch05_hhouse02_91" with dissolve
        0.1
        "ch05_hhouse02_90" with dissolve
        0.1
        "ch05_hhouse02_89" with dissolve
        0.1
        "ch05_hhouse02_88" with dissolve
        0.1
        "ch05_hhouse02_87" with dissolve
        0.1
        repeat
    scene ch05_hhouse02_bj02 at hand_camera with Dissolve(0.8)
    d "으......."
    d "**(젠장.......)**"
    l "커헉......."
    l "**(벌써 입이 아파.....)**"
    l "**(이래가지곤 5분도 못빨거 같은데...)**"
    scene ch05_hhouse02_76 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    l "꺼억...."
    l "**(하아..하아....)**"
    l "**(이 꼬마 녀석 대단하네..)**"
    l "**(내 여태 만나본 남자들 중 탑3에 들겠어.)**"
    image ch05_hhouse02_bj02-02:
        "ch05_hhouse02_91-02" with dissolve
        0.1
        "ch05_hhouse02_91-03" with dissolve
        0.1
        "ch05_hhouse02_91-04" with dissolve
        0.1
        "ch05_hhouse02_91-05" with dissolve
        0.1
        "ch05_hhouse02_91-06" with dissolve
        0.1
        "ch05_hhouse02_91-07" with dissolve
        0.1
        "ch05_hhouse02_91-06" with dissolve
        0.1
        "ch05_hhouse02_91-05" with dissolve
        0.1
        "ch05_hhouse02_91-04" with dissolve
        0.1
        "ch05_hhouse02_91-03" with dissolve
        0.1
        repeat
    scene ch05_hhouse02_bj02-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop
    d "으......."
    d "하아......"
    scene ch05_hhouse02_92 at hand_camera with Dissolve(0.8)
    d "아 레나......"
    l "커헉....커헉...."
    scene ch05_hhouse02_bj02 at hand_camera with Dissolve(0.8)
    d "으......."
    d "**(따뜻하다.....)**"
    scene ch05_hhouse02_bj02-02 at hand_camera with Dissolve(0.8)
    d "**(아 젠장.......)**"
    pause
    d "**(그녀는 레즈비언아니었나......)**"
    d "**(이건 뭐지 대체.......)**"
    d "**(대체 랜드레이디와 그녀는 무슨 사이지?.....)**"
    d "**(그게 지금 무슨 상관이야...)**"
    d "**(젠장 너무 좋다.....아....)**"
    scene ch05_hhouse02_93 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort03.mp3"
    d "**(쉣...)**"
    d "**(이건 미쳤어....)**"
    scene ch05_hhouse02_94 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort02.mp3"
    pause
    scene ch05_hhouse02_95 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fsigh.mp3"
    l "하아...."
    l "하아...하아...."
    scene ch05_hhouse02_96 at hand_camera with Dissolve(0.8)
    d "레나......"
    d "최...최고에요..."
    scene ch05_hhouse02_97 at hand_camera with Dissolve(0.8)
    l "좋지?"
    play voice_f "audio/voices/flaugh03.wav"
    l "아줌마가 빨아주니까 좋지? 허? ㅎㅎ"
    l "어린 여자들하고는 다르지??"
    scene ch05_hhouse02_97-02 at hand_camera with Dissolve(0.8)
    d "네......."
    d "너무 좋아요 레나....."
    scene ch05_hhouse02_97 at hand_camera with Dissolve(0.8)
    l "ㅎㅎ"
    l "넌 귀엽구나.."
    l "솔직해서 좋네."
    pause
    l "좋아 그럼 이제..."
    scene ch05_hhouse02_98 at hand_camera with Dissolve(1.3)
    l "날 사용해."
    scene ch05_hhouse02_98-02 at hand_camera with Dissolve(0.8)
    l "네??"
    scene ch05_hhouse02_98-03 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic01.mp3"
    l "내 머릴 잡고 사용하라고."
    l "내 입이 보지라고 생각하고 쑤셔줘...."
    d "!!!!!!!!"
    d "네??"
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    d "........."
    d "입이 보지라고 생각하고....."
    pause
    d "**(뭐지 그게???)**"
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    l "해본적 없어?"
    d "잘 이해가 안돼서...."
    scene ch05_hhouse02_98-03 at hand_camera with Dissolve(0.8)
    l "어려울거 없어."
    l "내 머릴 잡고 섹스하듯이 내 입에 쑤시면 돼."
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    d "........."
    pause
    d "아...알겠어요..."
    d "해볼게요..."
    scene ch05_hhouse02_100 at hand_camera with Dissolve(0.8)
    l "그래 그렇게 베이비...."
    l "날 창녀 처럼 생각하고 입에 쑤셔줘."
    l "너 하고 싶은대로 해."
    d "젠장...레나...."
    scene ch05_hhouse02_101 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    l "커헉..."
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    d "**(젠장....)**"
    d "**(이런건 해본적 없는데....)**"
    scene ch05_hhouse02_101 at hand_camera with Dissolve(0.8)
    l "커억...."
    scene ch05_hhouse02_106 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag01.mp3"
    l "컥!!!!"
    scene ch05_hhouse02_106-01 at hand_camera with Dissolve(0.8)
    l "우헉....."
    image ch05_hhouse02_bj03:
        "ch05_hhouse02_101" with dissolve
        0.1
        "ch05_hhouse02_102" with dissolve
        0.1
        "ch05_hhouse02_103" with dissolve
        0.1
        "ch05_hhouse02_104" with dissolve
        0.1
        "ch05_hhouse02_105" with dissolve
        0.1
        "ch05_hhouse02_106" with dissolve
        0.1
        "ch05_hhouse02_105" with dissolve
        0.1
        "ch05_hhouse02_104" with dissolve
        0.1
        "ch05_hhouse02_103" with dissolve
        0.1
        "ch05_hhouse02_102" with dissolve
        0.1
        repeat
    scene ch05_hhouse02_bj03 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop
    d "크윽........"
    pause
    d "**(제...젠장...)**"
    l "**(예스.....)**"
    scene ch05_hhouse02_106-02 at hand_camera with Dissolve(1.3)
    d "**(좋...좋아....)**"
    l "커헉...."
    scene ch05_hhouse02_107 at hand_camera with Dissolve(1.3)
    l "커헉...커헉....."
    scene ch05_hhouse02_108 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_109 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse02_110 at hand_camera with Dissolve(0.8)
    h "............"
    image ch05_hhouse02_bj05:
        "ch05_hhouse02_111-02" with dissolve
        0.1
        "ch05_hhouse02_111-03" with dissolve
        0.1
        "ch05_hhouse02_111-04" with dissolve
        0.1
        "ch05_hhouse02_111-05" with dissolve
        0.1
        "ch05_hhouse02_111-06" with dissolve
        0.1
        "ch05_hhouse02_111-07" with dissolve
        0.1
        "ch05_hhouse02_111-06" with dissolve
        0.1
        "ch05_hhouse02_111-05" with dissolve
        0.1
        "ch05_hhouse02_111-04" with dissolve
        0.1
        "ch05_hhouse02_111-03" with dissolve
        0.1
        repeat
    scene ch05_hhouse02_bj05 at hand_camera with Dissolve(0.8)
    l "어억...."
    l "커헉.........."
    scene ch05_hhouse02_111 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/breath02.mp3"
    l "꺼억......"
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    d "........."
    d "괘..괜찮아요?"
    scene ch05_hhouse02_111-01 at hand_camera with Dissolve(0.8)
    l "헉...헉..."
    l "...."
    l "더 쑤셔줘 베이비."
    l "더 강하게 쑤셔줘.."
    scene ch05_hhouse02_99 at hand_camera with Dissolve(0.8)
    d "........."
    image ch05_hhouse02_bj05-fast:
        "ch05_hhouse02_111-02" with dissolve
        0.05
        "ch05_hhouse02_111-03" with dissolve
        0.05
        "ch05_hhouse02_111-04" with dissolve
        0.05
        "ch05_hhouse02_111-05" with dissolve
        0.05
        "ch05_hhouse02_111-06" with dissolve
        0.05
        "ch05_hhouse02_111-07" with dissolve
        0.05
        "ch05_hhouse02_111-06" with dissolve
        0.05
        "ch05_hhouse02_111-05" with dissolve
        0.05
        "ch05_hhouse02_111-04" with dissolve
        0.05
        "ch05_hhouse02_111-03" with dissolve
        0.05
        repeat
    scene ch05_hhouse02_bj05-fast at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop
    l "어억...."
    l "커헉......."
    scene ch05_hhouse02_107 at hand_camera with Dissolve(0.8)
    l "커헉...커헉....."
    d "아악 레나!!!!!"
    scene ch05_hhouse02_112 at hand_camera with Dissolve(0.8)
    d "아아......."
    image ch05_hhouse02_bj06:
        "ch05_hhouse02_112-02" with dissolve
        0.05
        "ch05_hhouse02_112-03" with dissolve
        0.05
        "ch05_hhouse02_112-04" with dissolve
        0.05
        "ch05_hhouse02_112-05" with dissolve
        0.05
        "ch05_hhouse02_112-06" with dissolve
        0.05
        "ch05_hhouse02_112-07" with dissolve
        0.05
        "ch05_hhouse02_112-06" with dissolve
        0.05
        "ch05_hhouse02_112-05" with dissolve
        0.05
        "ch05_hhouse02_112-04" with dissolve
        0.05
        "ch05_hhouse02_112-03" with dissolve
        0.05
        repeat
    scene ch05_hhouse02_bj06 at hand_camera with Dissolve(0.8)
    l "허억....."
    d "**(젠장!!!!)**"
    d "**(보지와는 또 다른 좋은 느낌이야...)**"
    l "커헉......커헉....."
    scene ch05_hhouse02_111 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    l "꺼억......"
    l "허억....."
    play voice_f "audio/sex/gag01.mp3"
    scene ch05_hhouse02_112-08 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/heavybreath01.mp3" volume 2.0
    l "하아...하아..."
    l "잠깐만 숨좀 쉬자...."
    jump ch05_hhouse03_branch

label ch05_hhouse03_branch:
    if lust_helen >= 37:
        jump ch05_hhouse03_02
    else:
        jump ch05_hhouse03_03

label ch05_hhouse03_02:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse03_02 = True
    scene ch05_hhouse02_112-09 at hand_camera with Dissolve(0.8)
    d "아...네..."
    d "......."
    n "숨을 돌리고 있는 레나를 옆에두고 그에 눈에 다른 한 여성이 들어왔다."
    pause
    stop voice_f fadeout 0.5
    n "그녀는 잠자는 숨속의 공주 처럼 무방비 상태였다."
    n "[d_name]은 [h_name]에게 다가갔다."
    scene ch05_hhouse02_112-09-02 at hand_camera with Dissolve(0.8)
    l "하아....하아...."
    scene ch05_hhouse02_112-09-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_112-09-04 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "당신의 성기를 [h_name]의 입에 넣는다.":
            scene ch05_hhouse02_112-09-05 at hand_camera with Dissolve(0.8)
            l "하아...하아...."
    play voice_f  "audio/sex/liquid01.mp3"        
    scene ch05_hhouse02_112-09-06 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_112-09-07 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_112-09-08 at hand_camera with Dissolve(0.8)
    pause
    jump ch05_hhouse03_03

label ch05_hhouse03_03:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse03_03 = True
    scene ch05_hhouse02_112-09 at hand_camera with Dissolve(0.8)
    d "미...미안해요.."
    d "......."
    scene ch05_hhouse02_112-10 at hand_camera with Dissolve(0.8)
    l "하아...하아...."
    scene ch05_hhouse02_112-11 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "당신의 성기를 레나의 입에 넣는다.":
            scene ch05_hhouse02_112-12 at hand_camera with Dissolve(0.8)
            l "잠깐만...."
            l "조금만 더 쉬자.."
            l "턱이 빠질거 같아."
            scene ch05_hhouse02_112-13 at hand_camera with Dissolve(0.8)
            l "자...잠깐만.."
            scene ch05_hhouse02_112-14 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/gag02.wav"
            l "끄헉!!"
            if not in_replay:
                $ add_point("lust_lena", 1, "lust_lena")

    image ch05_hhouse02_bj07:
        "ch05_hhouse02_112-15" with dissolve
        0.05
        "ch05_hhouse02_112-16" with dissolve
        0.05
        "ch05_hhouse02_112-17" with dissolve
        0.05
        "ch05_hhouse02_112-18" with dissolve
        0.05
        "ch05_hhouse02_112-19" with dissolve
        0.05
        "ch05_hhouse02_112-20" with dissolve
        0.05
        "ch05_hhouse02_112-19" with dissolve
        0.05
        "ch05_hhouse02_112-18" with dissolve
        0.05
        "ch05_hhouse02_112-17" with dissolve
        0.05
        "ch05_hhouse02_112-16" with dissolve
        0.05
        repeat
    scene ch05_hhouse02_bj07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop
    l "허억....."
    d "아윽..."
    l "커억.....커억....."
    l "**(그...그가 점점 과감해지고 있어....)**"
    l "**(이...어린 놈이 감히 나에게...)**"
    l "**(........)**"
    scene ch05_hhouse02_113 at hand_camera with Dissolve(0.8)
    n "그는 서서히 레나의 입을 사용하는 즐거움을 알아갔다."
    pause
    n "서로간의 쾌락을 위한 행위가 아닌.."
    n "그는 오로지 사정을 하기 위해 달려갔다."
    pause
    n "그는 레나의 입을 도구로 사용하고 있었다."
    image ch05_hhouse02_bj08:
        "ch05_hhouse02_112-21"
        0.05
        "ch05_hhouse02_112-22"
        0.05
        "ch05_hhouse02_112-23"
        0.05
        "ch05_hhouse02_112-24"
        0.05
        "ch05_hhouse02_112-25"
        0.05
        "ch05_hhouse02_112-26"
        0.05
        "ch05_hhouse02_112-25"
        0.05
        "ch05_hhouse02_112-24"
        0.05
        "ch05_hhouse02_112-23"
        0.05
        "ch05_hhouse02_112-22"
        0.05
        repeat
    scene ch05_hhouse02_bj08 at hand_camera with Dissolve(0.8)
    l "허억....."
    l "커억...커억....."
    l "**(아 어린 놈에게 이렇게 다뤄지니 흥분돼서 미칠거 같아!!!!)**"
    l "**(크아......)**"
    image ch05_hhouse02_bj04:
        "ch05_hhouse02_112-27"
        0.05
        "ch05_hhouse02_112-28"
        0.05
        "ch05_hhouse02_112-29"
        0.05
        "ch05_hhouse02_112-30"
        0.05
        "ch05_hhouse02_112-31"
        0.05
        "ch05_hhouse02_112-32"
        0.05
        "ch05_hhouse02_112-31"
        0.05
        "ch05_hhouse02_112-30"
        0.05
        "ch05_hhouse02_112-29"
        0.05
        "ch05_hhouse02_112-28"
        0.05
        repeat
    scene ch05_hhouse02_bj04 at hand_camera with Dissolve(0.8)
    l "허억....."
    l "커헉.....커억....."
    image ch05_hhouse02_bj07-fast:
        "ch05_hhouse02_112-15" with dissolve
        0.035
        "ch05_hhouse02_112-16" with dissolve
        0.035
        "ch05_hhouse02_112-17" with dissolve
        0.035
        "ch05_hhouse02_112-18" with dissolve
        0.035
        "ch05_hhouse02_112-19" with dissolve
        0.035
        "ch05_hhouse02_112-20" with dissolve
        0.035
        "ch05_hhouse02_112-19" with dissolve
        0.035
        "ch05_hhouse02_112-18" with dissolve
        0.035
        "ch05_hhouse02_112-17" with dissolve
        0.035
        "ch05_hhouse02_112-16" with dissolve
        0.035
        repeat
    scene ch05_hhouse02_bj07-fast at hand_camera with Dissolve(0.8)
    l "허억....."
    l "끄윽.....끄윽....."
    d "으아!!!!!!"
    stop music fadeout 0.5
    scene ch05_hhouse02_113-02 at hand_camera with Dissolve(0.2)
    d "**(으윽...싼다......)**"
    scene ch05_hhouse02_114 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/cum01.mp3"
    d "아........"
    play voice_f  "audio/sex/cum01.mp3"
    scene ch05_hhouse02_115 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_116 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/gag03.wav"
    l "꺽억..."
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
    scene ch05_hhouse02_117 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/gag02.wav"
    l "커억....."
    d "**(으아...........)**"
    d "**(악!!!!!!!!!)**"
    scene ch05_hhouse02_119 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/liquid02.mp3"
    pause
    scene ch05_hhouse02_117 at hand_camera with Dissolve(0.8)
    pause
    play voice_f  "audio/sex/liquid02.mp3"
    scene ch05_hhouse02_119 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_117 at hand_camera with Dissolve(0.8)
    pause
    play voice_f  "audio/sex/liquid02.mp3"
    scene ch05_hhouse02_119 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_120 at hand_camera with Dissolve(1.2)
    d "하......."
    d "마...맙소사....."
    scene ch05_hhouse02_121 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/heavybreath01.mp3" volume 2.0
    l "하아....하아....하아....."
    scene ch05_hhouse02_121-02 at hand_camera with Dissolve(0.8)
    d "**(맙소사.....)**"
    d "**(내가 무슨 짓을 저지른거지??....)**"
    d "**(그녀는 랜드레이디의 연인이잖아....)**"
    scene ch05_hhouse02_121-03 at hand_camera with Dissolve(0.8)
    stop voice_f fadeout 0.5
    l "후......"
    d "괜찮아요 레나?..."
    l "하아...하아....."
    l "맙소사..."
    l "진짜 많이 사정했어 너.."
    l "후........"
    scene ch05_hhouse02_121-02 at hand_camera with Dissolve(0.8)
    d "괜찮아요 레나?..."
    pause
    d "미..미안합니다."
    d "제가 너무 흥분한나머지...."
    scene ch05_hhouse02_123 at hand_camera with Dissolve(0.8)
    l "아니야."
    l "....."
    l "어서 나가."
    l "가서 쉬어."
    scene ch05_hhouse02_124 at hand_camera with Dissolve(1.2)
    l "넌 소질이 있구나."
    d "......"
    l "어서 나가."
    l "나도 샤워하고 잘거야."
    d "네.....그럴게요.."
    scene ch05_hhouse02_125 at hand_camera with Dissolve(0.8)
    d "**(젠장.....)**"
    d "**(이 방에 들어오는게 아니었어.....)**"
    d "**(내가 무슨 짓을 한거지...)**"
    scene ch05_hhouse02_126 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse02_127 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse02_128 at hand_camera with Dissolve(0.8)
    l "사랑해 베이비."
    scene ch05_hhouse02_129 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch05_hhouse02_130 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/liquid01.mp3"  
    scene ch05_hhouse02_131 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse02_132 at hand_camera with Dissolve(1.2)
    pause
    jump ch05_police01

label ch05_police01:
    if not in_replay:
        $ persistent.unlock_ch05_police01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch05_police01_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_02-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_03 at hand_camera with Dissolve(1.2)
    tv "다음 뉴스입니다."
    tv "최근 밀프하임 지역에서 정체불명의 조직 범죄가 잇따르면서 시민들의 불안이 커지고 있습니다."
    tv "지난 몇 주 동안 여러 지역에서 유사한 수법의 강력 범죄가 연이어 발생했으며,"
    scene ch05_police01_04 at hand_camera with Dissolve(0.8)
    tv "경찰은 사건들 사이에 조직적인 연관성이 있을 가능성을 두고 수사를 확대하고 있습니다."
    tv "현재까지 해당 범죄를 주도하는 조직의 실체나 규모는 확인되지 않았습니다."
    tv "경찰은 범행 수법과 관련자들의 움직임을 토대로 배후 세력을 추적하고 있습니다."
    scene ch05_police01_05 at hand_camera with Dissolve(0.8)
    tv "밀프하임 경찰서장은 오늘 오전 전화 인터뷰에서 이번 사건에 대응하기 위해,"
    tv "인근 지역을 포함한 외부 기관으로부터 추가 인력을 지원받았다고 밝혔습니다."
    tv "경찰서장은 모든 가용 인력을 수사에 투입하고 있으며,"
    tv "사건의 실체를 밝히기 위해 총력을 다하겠다고 강조했습니다."
    tv "하지만 경찰의 노력에도 범죄율은 떨어지지 않아 주민들은 우려하고 있습니다."
    scene ch05_police01_06 at hand_camera with Dissolve(0.8)
    di "............"
    tv "경찰은 시민들에게 수상한 행동이나 범죄와 관련된 정보를 발견할 경우 즉시 신고해 줄 것을 당부했습니다."
    tv "이어서 다음 소식입니다."
    scene ch05_police01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_08 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_police01_09 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_10 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_11 at hand_camera with Dissolve(1.28)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch05_police01_14 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_15 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_16 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_17 at hand_camera with Dissolve(0.8)
    di "좋은 아침입니다."
    unknownm "좋은 아침입니다."
    scene ch05_police01_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_19 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_ethan = True
    unknownm "............"
    unknownm "좋은 아침입니다."
    scene ch05_police01_20 at hand_camera with Dissolve(0.8)
    di "좋은 아침이에요."
    di "신임 팀장입니다. 잘 부탁해요."
    scene ch05_police01_20-02 at hand_camera with Dissolve(0.8)
    unknownm "반갑습니다."
    unknownm "잘 부탁 드립니다."
    play sound "audio/ambi/dooropen02.mp3"
    scene ch05_police01_21 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_22 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_22-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_23 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_evan = True
    play sound "audio/ambi/knock.mp3"
    n "그녀가 서류를 정리하고 있을 때 한 경찰이 다가와 노크했다."
    unknownm "저..팀장님?"
    scene ch05_police01_24 at hand_camera with Dissolve(0.8)
    di "네?"
    di "무슨 일 있나요?"
    scene ch05_police01_25 at hand_camera with Dissolve(0.8)
    unknownm "저..."
    unknownm "서장님이 직접 업무 브리핑을 한다고 합니다."
    unknownm "외근 인원 제외하고 부서별로 한 명 이상 모이라는 지시입니다."
    di "아 그래요?"
    unknownm "네 제가 안내해 드릴게요. 같이 브리핑룸으로 가시죠."
    scene ch05_police01_26 at hand_camera with Dissolve(0.8)
    di "아 그렇군요."
    di "고마워요."
    scene ch05_police01_26-02 at hand_camera with Dissolve(0.8)
    unknownm "ㅎㅎ 천만에요."
    scene ch05_police01_26-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_police01_27 at hand_camera with Dissolve(1.5)
    pause
    scene ch05_police01_28 at hand_camera with Dissolve(2.0)
    pause
    play music "audio/bgm/erotic10.mp3"
    scene ch05_police01_29 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_29-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_30 at hand_camera with Dissolve(0.8)
    di "............."
    di "**(흐음......)**"
    scene ch05_police01_30-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_31 at hand_camera with Dissolve(0.8)
    chi "좋은 아침이군."
    chi "모두 주목해."
    scene ch05_police01_32 at hand_camera with Dissolve(0.8)
    chi "............"
    chi "지난 몇 달 동안 밀프하임힐스의 조직 범죄는 우리가 예상했던 수준을 훨씬 넘어섰다."
    chi "불법 마약 유통, 총기 밀매, 갈취, 자금 세탁까지."
    chi "도시 곳곳에서 범죄 조직의 영향력이 빠르게 확대되고 있다."
    chi "모두들 알듯이 문제는 이것만이 아니다."
    scene ch05_police01_33 at hand_camera with Dissolve(0.8)
    chi "우리는 아직도 해결하지 못한 연쇄 살인 사건을 안고 있고,"
    chi "최근 발생한 총격 사건들 역시 범인 검거에 이르지 못했다."
    chi "시민들의 신뢰는 흔들리고 있으며, 언론과 시청도 결과를 요구하고 있다."
    chi "..........."
    chi "우리가 해야 할 일을 제대로 하고 있지 못하단 말이야."
    scene ch05_police01_34 at hand_camera with Dissolve(0.8)
    chi "따라서 우리 경찰서도 인원 충원들이 있었다."
    chi "그리고 오늘부터 이 조직 범죄에 대해 다른 각도로 접근할 것이다."
    chi "오늘부로 이 사건들은 더 이상 개별 사건이 아니다."
    chi "모두 하나의 거대한 조직이 뒤에서 움직이고 있을 가능성을 전제로 수사한다."
    scene ch05_police01_35 at hand_camera with Dissolve(0.8)
    di "........."
    chi "연방 수사국과의 공조도 적극적으로 진행한다."
    chi "자존심은 넣어두고 오로지 사건의 해결만을 위해서 일해라."
    chi "필요한 정보는 공유하고, 필요한 지원은 모두 요청해라."
    scene ch05_police01_36 at hand_camera with Dissolve(0.8)
    chi "그리고 이젠 우리 서 전체가 하나로 움직여야 한다."
    chi "그말은.."
    chi "바이스부, 강력부, 지능범죄부 이제 그런 구분은 없다."
    chi "살인,강도,절도,마약,금융,사이버,실종 등 이제 모든 범죄를 모두가 공유한다."
    scene ch05_police01_37 at hand_camera with Dissolve(0.8)
    chi "그 말은 지금 밀프하임에서 일어나는 강력범죄들은 다 연결되어 있다는 말이야."
    chi "따라서 우리도 오늘부터는 전원이 하나의 태스크포스로 움직인다."
    chi "모든 인력과 모든 자원을 총동원해서 이 사건들을 사주한 정점의 세력을 찾아내라."
    scene ch05_police01_38 at hand_camera with Dissolve(0.8)
    chi "............"
    chi "하지만 절대로 잊지 마라."
    chi "가장 중요한 것은 증거다."
    scene ch05_police01_39 at hand_camera with Dissolve(0.8)
    chi "추측도, 감도, 소문도 법정에서는 아무 의미가 없다."
    chi "우리가 체포하는 순간, 그들을 끝까지 유죄로 만들 수 있는 것은 오직 증거뿐이다."
    scene ch05_police01_40 at hand_camera with Dissolve(0.8)
    chi "불법 자금의 흐름, 통신 기록, CCTV, 목격자 진술, 디지털 포렌식. 무엇이든 확보해라."
    chi "주민들의 증언 한마디도 때론 결정적 단서가 될 수 있음을 모두들 알것이다."
    chi "흘려듣지 말고 취합해서 모두에게 공유한다."
    scene ch05_police01_41 at hand_camera with Dissolve(0.8)
    chi "이번 작전은 범죄자 몇 명을 체포하는 것이 목표가 아니다."
    chi "밀프하임힐스를 뒤에서 조종하는 조직의 머리를 잘라내는 것."
    chi ".........."
    chi "우린 이 조직의 성격을 전혀 유추 할 수가 없어."
    chi "지금까지 우리가 알던 조직들과는 다르다는 것을 명심해."
    scene ch05_police01_42 at hand_camera with Dissolve(0.8)
    chi "이번 작전은 범죄자 몇 명을 체포하는 것이 목표가 아니다."
    chi "대신 내가 책임지고 유무형의 파격적인 지원을 해줄것이다."
    chi "그 만큼 우리는 지금 사활을 걸어야 한다는 말이야."
    chi "질문 있나?"
    scene ch05_police01_43 at hand_camera with Dissolve(0.8)
    n "서장의 말이 끝나고 브리핑룸에 정적이 흘렀다."
    pause
    n "그들의 정체된 분위기는 지역민들의 불평을 듣고있는 밀프하임 경찰서 그 자체였다."
    scene ch05_police01_43-02 at hand_camera with Dissolve(0.8)
    n "그들은 의기소침해져 이었다."
    n "그곳은 마치 선장을 잃고 바다에서 표류하는 배와 같았다."
    scene ch05_police01_44 at hand_camera with Dissolve(0.8)
    n "그들에게 그 어느때보다 분위기를 바꿀 수 있는 한 방이 필요했다."
    n "그들의 삶과 수사 모두 불을 당길 수 있는 번개가 필요했다."
    di "........"
    scene ch05_police01_45 at hand_camera with Dissolve(0.8)
    chi "좋아."
    chi "다들 일 시작하자."
    scene ch05_police01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_46-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_47 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_48 at hand_camera with Dissolve(0.8)
    chi "다이아나 형사."
    chi "잠깐 얘기좀 하지."
    scene ch05_police01_48-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_49 at hand_camera with Dissolve(0.8)
    di "네 알겠습니다."
    scene ch05_police01_50 at hand_camera with Dissolve(0.8)
    chi "얼굴 보니 좋구만."
    scene ch05_police01_50-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_50-03 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal05.mp3"
    di "안녕하세요 서장님."
    di "사건에 관련 된 얘기인가요?"
    scene ch05_police01_51 at hand_camera with Dissolve(0.8)
    di "**(..........)**"
    pause
    di "**(젠장 이젠 숨기지도 않는군.)**"
    di "**(설마 일부러 드러내는건 아니겠지??)**"
    di "**(..........)**"
    di "**(자신에게 이 정도 권력이 있다는걸 알려주는건가?...)**"
    scene ch05_police01_52 at hand_camera with Dissolve(0.8)
    di "**(이곳 경찰들이 내 가슴을 볼때마다 돈을 받으면 이 동네에 집도 사겠어.)**"
    di "**(하....또 발가벗은 느낌이네.)**"
    scene ch05_police01_53 at hand_camera with Dissolve(0.8)
    chi "동료들과 인사는 했나?"
    scene ch05_police01_54 at hand_camera with Dissolve(0.8)
    di "몇 몇과는 인사했습니다."
    di "오늘 업무 종료 후 간단히 다 같이 식사를 하려고 합니다."
    scene ch05_police01_55 at hand_camera with Dissolve(0.8)
    chi "그렇군."
    chi "좋은 생각이네."
    chi "그들을 업무적으로만 대하지 말게."
    chi "네가 여기서 일하는 동안 그들은 너의 전우야."
    scene ch05_police01_56 at hand_camera with Dissolve(0.8)
    chi "경찰에서 산전수전 다 겪었으니 알겠지만 혼자 만드는 성과라는건 없어."
    di "네 명심하겠습니다."
    scene ch05_police01_57 at hand_camera with Dissolve(0.8)
    chi "팀원들 실력들은 좋아."
    chi "단지...."
    pause
    chi "문제는 그들이 너무 오래 이 사건에 매달려 있었다는거야."
    chi "그말은 다들 매너리즘에 빠져있다는 말이지."
    chi "그건 나도 마찬가지고..."
    scene ch05_police01_58 at hand_camera with Dissolve(0.8)
    chi "그 결과 다들 사기가 떨어져 있어. 의욕도 점차 사라지고."
    chi "잡아오면 풀어주고...잡아오면 풀어주고..."
    chi "병신 같은 판사 놈들."
    chi "......."
    chi "누군가 이끌어주고 페이스를 끌어올려줘야해."
    chi "모두가 처자식 굶기기 싫으면 말이지."
    chi "이대로 가면 내 목아지도 날아갈 판이야."
    scene ch05_police01_59 at hand_camera with Dissolve(0.8)
    di "제 역할을 반드시 해내겠습니다."
    chi "그래."
    scene ch05_police01_60 at hand_camera with Dissolve(0.8)
    chi "이 조직 범죄는 이제 MPD만의 사건이 아니야."
    chi "정치권에서도 주목하고 있어."
    chi "전 국가적 이슈가 되고 있다는 말이야."
    scene ch05_police01_61 at hand_camera with Dissolve(0.8)
    chi "그리고 알아서 잘 하겠지만,"
    chi "자네 자신의 페이스를 무너뜨리진 말게."
    chi "......."
    chi "무슨 말인지 알지?"
    chi "우리가 하는 일은 삶과 일중에 하나가 무너지면 다른 하나도 따라서 무너지는 일이지."
    chi "내 말을 믿게."
    chi "삶과 일 중에 하나가 무너지고 멀쩡한 사람을 못봤네."
    scene ch05_police01_56 at hand_camera with Dissolve(0.8)
    di "네 잘 알아서 하겠습니다."
    chi "그래. 자넬 믿겠네."
    scene ch05_police01_62 at hand_camera with Dissolve(0.8)
    chi "........."
    chi "그리고 일주일 뒤에 기자회견이 있을거야."
    scene ch05_police01_63 at hand_camera with Dissolve(0.8)
    di ".........."
    chi "아마 그냥 기자회견이 아니라 우리를 압박하는 청문회 처럼 흘러갈거야."
    chi "내가 아는 기자가 귀띔해주더군."
    scene ch05_police01_63-02 at hand_camera with Dissolve(0.8)
    chi "그들에게 무언가 씹을 거리를 던져줘야해."
    chi "무슨 말인지 알겠나?"
    scene ch05_police01_63 at hand_camera with Dissolve(0.8)
    di "네 무슨 말인지 압니다."
    chi "좋아."
    scene ch05_police01_64 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_65 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_66 at hand_camera with Dissolve(0.8)
    n "서장은 자연스럽게 그녀에게 다가가 그녀의 허리에 손을 올렸다."
    chi "그건 그렇고 이사한 곳은 괜찮나?"
    di "네. 지낼만 한거 같습니다."
    chi "주변에 아무것도 없어서 썰렁하지?"
    scene ch05_police01_67 at hand_camera with Dissolve(0.8)
    di "전 조용한걸 좋아해서 오히려 좋습니다."
    di "주변에 조깅 코스도 잘 돼 있어서 너무 좋습니다."
    scene ch05_police01_67-02 at hand_camera with Dissolve(0.8)
    chi "다행이군."
    chi "이런 소도시에선 집과 이 경찰서만 왔다갔다 하다가 자칫 지치기 십상이거든."
    chi "스트레스와 압박감을 잊을 자네만의 무언가 필요하다네."
    di "네 맞습니다."
    scene ch05_police01_68 at hand_camera with Dissolve(0.8)
    chi "자네도 알겠지만 자네 정도의 계급은 서장인 나와 몇 몇 상위 서열들과 연결 돼 있어."
    chi "자네의 성과가 곧 나의 성과가 된다고."
    chi "그말은 자네와 내가 뗄수 없는 관계로 묶여 있다는거야."
    di "......."
    chi "따라서 자네와 내가 때론 친구 처럼, 때론 부부 처럼 긴밀하게 모든걸 공유해야 한다는거야."
    di "..............."
    di "**(부부 처럼이라니....맙소사....)**"
    scene ch05_police01_67-02 at hand_camera with Dissolve(0.8)
    chi "혹시라도 어떤 문제가 있거나 상의하고 싶은게 있다면 언제든 말하게."
    chi "일에 대해서든 사적인것이든."
    scene ch05_police01_69 at hand_camera with Dissolve(0.8)
    di "....."
    di "네 그렇게 하겠습니다."
    chi "어쨌든 내가 자네보다 인생과 경찰 생활 모두 선배이니까,"
    chi "조금이라도 이 곳에서 자네의 생활에 도움이 될걸세."
    scene ch05_police01_69-02 at hand_camera with Dissolve(0.8)
    chi "나중에 기회가 된다면 내가 부임 초기시절 자주 가던 나만 알고 있는 경치 좋은 곳을 알려주겠네."
    chi "혼자서 자연에서 쉬고 오기 그만인 곳이야."
    scene ch05_police01_69-02-02 at hand_camera with Dissolve(0.8)
    chi "산속에 호수가 있는 기막힌 곳이지."
    chi "하루종일 다 벗고 수영해도 사람 하나 볼 수 없는 한적한 곳이야."
    scene ch05_police01_69-03 at hand_camera with Dissolve(0.8)
    di "네 알겠습니다."
    di "어떤 곳인지 정말 궁금하네요 ㅎㅎ."
    di "신경써주셔서 감사합니다."
    scene ch05_police01_70 at hand_camera with Dissolve(0.8)
    chi "그래. 이제 공식 업무 시작이니 고생하게."
    chi "이슈가 있으면 언제든 찾아오거나 전화하게."
    scene ch05_police01_70-02 at hand_camera with Dissolve(0.8)
    chi "내가 서장이라고 너무 어려워 하지말고 알겠나?"
    di "네....네 알겠습니다."
    scene ch05_police01_71 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_72 at hand_camera with Dissolve(0.8)
    di "........."
    di "**(퓨.......)**"
    di "**(이렇게 이르게 사람을 판단하고 싶진 않지만.....)**"
    di "**(끈적하다 끈적해....)**"
    di "**(쉽지않겠어 정말....)**"
    scene ch05_police01_72-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_72-03 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/sus09.mp3"
    scene ch05_police01_73 at hand_camera with Dissolve(1.5)
    n "그녀는 그녀의 사무실에 돌아와 책상에 앉았다."
    pause
    n "하지만 그녀의 머릿속엔 지난번에 찾은 서류파일로 가득차 있었다."
    play sound "audio/ambi/drawer.mp3" volume 2.0
    scene ch05_police01_74 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_police01_75 at hand_camera with Dissolve(1.3)
    n "그녀는 다시 서류를 꺼내 펼쳤다."
    n "그리고 자신을 가장 신경쓰이게 하는 작은 쪽지를 집어들었다."
    scene ch05_police01_76 at hand_camera with Dissolve(0.8)
    di ".........."
    di "에드워드 형사....."
    di "흠......"
    scene ch05_police01_77 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_77-02 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_police01_78 at hand_camera with Dissolve(0.8)
    n "저희 가족은 신변의 위협을 받고 있습니다."
    n "저의 아들마저 위험 합니다."
    n "저희 부부는 그를 고아원에 맡기고 떠납니다."
    n "그게 그 아이의 안전을 위한 유일한 길입니다."
    n "이 도시는 당신의 상상 이상으로 위험합니다."
    n "부디 밀프하임에 있는 동안이라도 그를 지켜봐 주세요."
    n "무리한 부탁드려서 정말 미안합니다. 그의 이름은 [d_name]입니다."
    scene ch05_police01_79 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_police01_80 at hand_camera with Dissolve(0.8)
    di "흐음........."
    di "도대체 이렇게 오래 전에 무슨 일이 있었던거야..."
    di "왜 에드워드 형사는 이 서류들을 남겨놓은 거지?"
    di "끝난 케이스인거야 아님 시작조차 안 된 케이스인거야.."
    pause
    di "왜 지금까지 아무도 이 서류를 발견하지 못한거야?...."
    di "............"
    scene ch05_police01_81 at hand_camera with Dissolve(0.8)
    di "고아원?......"
    di "........"
    di "[d_name].."
    di "도대체 뭔지 감도안오네...."
    scene ch05_police01_82 at hand_camera with Dissolve(0.8)
    stop music fadeout 1.0
    di "아우씨!!"
    di "아직도 누가 내 엉덩이를 만지고 있는거 같아."
    di "젠장........"
    di "이러다 서장이 내 집에 갑자기 들이닥치는거아냐?..."
    di "........."
    di "이 곳 생활이 내 생각만큼 수월하지 않겠군....."
    jump ch05_diner01

label ch05_diner01:
    if not in_replay:
        $ persistent.unlock_ch05_diner01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Meanwhile, at the diner..." at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/erotic10.mp3"
    scene ch05_diner01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_diner01_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_diner01_03 at hand_camera with Dissolve(0.8)
    do "아 젠장!!!"
    scene ch05_diner01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_diner01_05 at hand_camera with Dissolve(0.8)
    unknown "아흑..!!"
    unknown "예스 예스!!"
    scene ch05_diner01_06 at hand_camera with Dissolve(0.8)
    unknown "아흥..."
    scene ch05_diner01_07 at hand_camera with Dissolve(0.8)
    do "아......"
    do "이사벨라!!"
    do "당신의 후장은 정말 최고에요."
    scene ch05_diner01_08 at hand_camera with Dissolve(0.8)
    isa "그런말은 부끄러워...."
    isa "아흥....."

    image ch05_diner01_sex01:
        "ch05_diner01_09" with dissolve
        0.1
        "ch05_diner01_10" with dissolve
        0.1
        "ch05_diner01_11" with dissolve
        0.1
        "ch05_diner01_12" with dissolve
        0.1
        "ch05_diner01_13" with dissolve
        0.1
        "ch05_diner01_14" with dissolve
        0.1
        "ch05_diner01_12" with dissolve
        0.1
        "ch05_diner01_11" with dissolve
        0.1
        "ch05_diner01_10" with dissolve
        0.1
        repeat
    play sound "audio/sex/penet_mid_interval.mp3" loop
    scene ch05_diner01_sex01 at hand_camera with Dissolve(0.8)
    do "마이갓....."
    do "내가 당신의 후장 때문에 당신을 못떠나요"
    do "하루 종일 생각난다구요."
    do "이 세상 최고의 후장이에요."
    isa "..........."
    image ch05_diner01_sex02:
        "ch05_diner01_14-02" with dissolve
        0.1
        "ch05_diner01_14-03" with dissolve
        0.1
        "ch05_diner01_14-04" with dissolve
        0.1
        "ch05_diner01_14-05" with dissolve
        0.1
        "ch05_diner01_14-06" with dissolve
        0.1
        "ch05_diner01_14-07" with dissolve
        0.1
        "ch05_diner01_14-05" with dissolve
        0.1
        "ch05_diner01_14-04" with dissolve
        0.1
        "ch05_diner01_14-03" with dissolve
        0.1
        repeat
    scene ch05_diner01_sex02 at hand_camera with Dissolve(0.8)
    do "좋아요 이사벨?"
    isa "아........."
    isa "좋...좋아요."
    do "여기에 다른 놈 자지를 넣게 해줄거에요?"
    isa ".........."
    isa "아..아니에요. 그렇지 않아요."
    do "확신이 없네요?"
    isa "내 후..후장은 오로지 오웬거에요."
    do "보지는요?"
    isa "내 보지도 오웬거에요. 하아...."
    image ch05_diner01_sex03:
        "ch05_diner01_16" with dissolve
        0.1
        "ch05_diner01_17" with dissolve
        0.1
        "ch05_diner01_18" with dissolve
        0.1
        "ch05_diner01_19" with dissolve
        0.1
        "ch05_diner01_20" with dissolve
        0.1
        "ch05_diner01_21" with dissolve
        0.1
        "ch05_diner01_19" with dissolve
        0.1
        "ch05_diner01_18" with dissolve
        0.1
        "ch05_diner01_17" with dissolve
        0.1
        repeat
    scene ch05_diner01_sex03 at hand_camera with Dissolve(0.8)
    do "아........"
    image ch05_diner01_sex03-fast:
        "ch05_diner01_16" with dissolve
        0.05
        "ch05_diner01_17" with dissolve
        0.05
        "ch05_diner01_18" with dissolve
        0.05
        "ch05_diner01_19" with dissolve
        0.05
        "ch05_diner01_20" with dissolve
        0.05
        "ch05_diner01_21" with dissolve
        0.05
        "ch05_diner01_19" with dissolve
        0.05
        "ch05_diner01_18" with dissolve
        0.05
        "ch05_diner01_17" with dissolve
        0.05
        repeat
    play sound "audio/sex/penet_short_interval.mp3" loop
    scene ch05_diner01_sex03-fast at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/fmoanlong02.mp3" loop
    isa "아!!!!!!!!!!!!!!!"
    isa "오웬!!!!!"
    do "아........"
    do "당신의 얼굴을 보면서 하고싶어."
    stop sound fadeout 0.5
    scene ch05_diner01_21-02 at hand_camera with Dissolve(0.8)
    stop voice_f fadeout 0.5
    do "컴온 이사벨라."
    scene ch05_diner01_21-03 at hand_camera with Dissolve(0.8)
    isa "하아....하아....."
    isa "빨리 사정해야 해."
    isa "카운터를 너무 오래 비우면 안돼."
    scene ch05_diner01_21-04 at hand_camera with Dissolve(0.8)
    do "그래 알겠어."
    do "금방 끝낼게."
    do "돌아누워봐요."
    scene ch05_diner01_21-05 at hand_camera with Dissolve(0.8)
    do "젠장 이사벨...."
    do "당신은 정말 야한 몸둥이를 가지고 있군요."
    scene ch05_diner01_21-06 at hand_camera with Dissolve(0.8)
    isa "흐응....."
    do "젠장....."
    do "아니. 당신의 보지에다 할래"
    scene ch05_diner01_21-07 at hand_camera with Dissolve(0.8)
    pause
    play voice_f  "audio/sex/liquid01.mp3"     
    scene ch05_diner01_21-08 at hand_camera with Dissolve(0.8)
    isa "아흥....."
    image ch05_diner01_sex04:
        "ch05_diner01_22" with dissolve
        0.1
        "ch05_diner01_23" with dissolve
        0.1
        "ch05_diner01_24" with dissolve
        0.1
        "ch05_diner01_25" with dissolve
        0.1
        "ch05_diner01_26" with dissolve
        0.1
        "ch05_diner01_27" with dissolve
        0.1
        "ch05_diner01_26" with dissolve
        0.1
        "ch05_diner01_25" with dissolve
        0.1
        "ch05_diner01_24" with dissolve
        0.1
        "ch05_diner01_23" with dissolve
        0.1
        repeat
    play sound "audio/sex/penet_mid_interval.mp3" loop
    scene ch05_diner01_sex04 at hand_camera with Dissolve(0.8)
    do "아........"
    isa "아흥....."
    do "당신은 정말 맛있어요..."
    do "내 자지도 맛있어요?"
    isa "하아...하아...."
    isa "오웬의 자지 정말 맛있어요..."
    scene ch05_diner01_21-09 at hand_camera with Dissolve(0.8)
    isa "아흥............."
    do "아 이사벨라...."
    image ch05_diner01_sex05:
        "ch05_diner01_29" with dissolve
        0.05
        "ch05_diner01_30" with dissolve
        0.05
        "ch05_diner01_31" with dissolve
        0.05
        "ch05_diner01_32" with dissolve
        0.05
        "ch05_diner01_33" with dissolve
        0.05
        "ch05_diner01_34" with dissolve
        0.05
        "ch05_diner01_33" with dissolve
        0.05
        "ch05_diner01_32" with dissolve
        0.05
        "ch05_diner01_31" with dissolve
        0.05
        "ch05_diner01_30" with dissolve
        0.05
        repeat
    play sound "audio/sex/penet_short_interval.mp3" loop
    scene ch05_diner01_sex05 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/fmoanlong02.mp3" loop
    do "아......"
    isa "아 오웬........"
    image ch05_diner01_sex04-fast:
        "ch05_diner01_22" with dissolve
        0.05
        "ch05_diner01_23" with dissolve
        0.05
        "ch05_diner01_24" with dissolve
        0.05
        "ch05_diner01_25" with dissolve
        0.05
        "ch05_diner01_26" with dissolve
        0.05
        "ch05_diner01_27" with dissolve
        0.05
        "ch05_diner01_26" with dissolve
        0.05
        "ch05_diner01_25" with dissolve
        0.05
        "ch05_diner01_24" with dissolve
        0.05
        "ch05_diner01_23" with dissolve
        0.05
        repeat
    scene ch05_diner01_sex04-fast at hand_camera with Dissolve(0.8)
    isa "아 불끈불끈 하는게 느껴져.."
    do "쌀거 같아..."
    isa "아흥....."
    isa "내 안에다 싸줘!!"
    stop sound
    scene ch05_diner01_36 at hand_camera with Dissolve(0.8)
    do "윽......."
    scene ch05_diner01_37 at hand_camera with Dissolve(0.8)
    do "아!!!!!!!!!"
    isa "하아...하아...."
    play sound "audio/sex/liquid02.mp3" 
    scene ch05_diner01_38 at hand_camera with Dissolve(0.8)
    isa "아흥......"
    scene ch05_diner01_37 at hand_camera with Dissolve(0.8)
    pause
    play soun "audio/sex/liquid02.mp3" 
    scene ch05_diner01_38 at hand_camera with Dissolve(0.8)
    pause
    stop voice_f  fadeout 0.5
    scene ch05_diner01_39 at hand_camera with Dissolve(0.8)
    do "아...이사벨라...."
    isa ".........."
    play sound "audio/sex/liquid01.mp3" 
    scene ch05_diner01_40 at hand_camera with Dissolve(0.8)
    isa "하........"
    scene ch05_diner01_40-02 at hand_camera with Dissolve(0.8)
    isa "평소보다 많이 싼거같아.."
    do "쉣....."
    do "너의 보지는 정말 언제나 최고야...."
    play sound "audio/ambi/fabric01.mp3"
    scene ch05_diner01_40-03 at hand_camera with Dissolve(0.8)
    do "나 이제 가봐야 해."
    isa "........."
    do "미안한데 시간이 별로 없네."
    scene ch05_diner01_41 at hand_camera with Dissolve(0.8)
    do "이제 한동안 바빠질거 같아."
    do "서장이 무슨 바람이 불었는지 한 동안 경찰들을 달달 볶을거 같아."
    do "지금도 간신히 빠져나온거거든."
    scene ch05_diner01_42 at hand_camera with Dissolve(0.8)
    isa ".........."
    play sound "audio/ambi/zipper.mp3"
    scene ch05_diner01_43 at hand_camera with Dissolve(0.8)
    do "...."
    do "왜?"
    do "무슨 할 말 있어?"
    scene ch05_diner01_43-02 at hand_camera with Dissolve(0.8)
    isa ".........."
    isa "아냐.."
    isa "바쁜데 어쩔수 없지."
    scene ch05_diner01_44 at hand_camera with Dissolve(1.2)
    do "연락할게."
    do "사랑해."
    play sound "audio/ambi/dooropen03.mp3"
    scene ch05_diner01_45 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene ch05_diner01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_diner01_47 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_diner01_48 at hand_camera with Dissolve(0.8)
    isa "........."
    isa "......."
    isa "난 그에게 뭐지?..."
    isa "성욕 해소 도구인가...."
    scene ch05_diner01_49 at hand_camera with Dissolve(1.2)
    pause
    jump ch05_hhouse04

label ch05_hhouse04:
    if not in_replay:
        $ persistent.unlock_ch05_hhouse04 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "That evening" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/title02.mp3" loop
    scene ch05_hhouse01_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse03_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse03_03 at hand_camera with Dissolve(0.8)
    d "**(어제 그 일은 일어나선 안 될 일이었다.....)"
    d "**(하........)**"
    scene ch05_hhouse03_04 at hand_camera with Dissolve(0.8)
    d "**(맙소사....)**"
    d "**(그 장면은 정말이지...)**"
    d "**(하......)**"
    d "**(그녀의 엉덩이에 얼굴을 파묻고 싶었어.....)**"
    scene ch05_hhouse03_05 at hand_camera with Dissolve(0.8)
    d "**(그리곤 레나가 일을 벌였어.....)**"
    d "**(날 갈굴때만 해도 혼날 줄 알았는데....)**"
    d "**(그녀는.......)**"
    d "**(하.....)**"
    d "**(그건 정말 태어나서 처음 경험해본 수준의 것이었어....)**"
    d "**(중년 여성의 과감함 이랄까.....)**"
    d "**(그 행위를 또 할 기회가 있을까?)**"
    d "**(그녀가 또 하게 해줄까?.....)**"
    scene ch05_hhouse03_06 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_hhouse03_06-02 at hand_camera with Dissolve(1.2)
    d "**(랜드레이디는 다음 날 잘 일어 났을까?)**"
    d "**(그녀들과 같이 한 침대에서 자고 싶었는데..)**"
    d "**(서로의 체온을 느끼면서 말이야..)**"
    scene ch05_hhouse03_06-03 at hand_camera with Dissolve(1.2)
    d "**(젠장......)**"
    d "**(밀프들의 매력에서 빠져나올수가 없다.....)**"
    d "**(..........)**"
    d "**(아니 그냥 나는 여자를 좋아하는건가?...)**"
    scene ch05_hhouse03_07 at hand_camera with Dissolve(1.2)
    d "**(그래......)**"
    pause
    d "**([h_name]이 멀쩡할 수 가 없지...)**"
    d "**(..........)**"
    d "**(그녀도 나의 마사지를 받으면 좋겠는데...)**"
    scene ch05_hhouse03_08 at hand_camera with Dissolve(0.8)
    d "**(근데 레나는 정말이지.....)**"
    d "**(내가 지금것 본 여자중에 제일 신비한 여자야....)**"
    scene ch05_hhouse03_09 at hand_camera with Dissolve(1.2)
    d "**(뭐랄까.....)**"
    d "**(아직까지 동심에 빠져 있는 어른이라고 할까...)**"
    d "**(본능에만 충실한 동물같은 여자라고 할까...)**"
    d "**(하지만 스마트한 느낌을 주기도해...)**"
    scene ch05_hhouse03_10 at hand_camera with Dissolve(1.2)
    d "**(랜드레이디는 무슨 일이 일어났는지 절대 모를거야..)**"
    d "**(한동안 숙취로 고생하겠지..)**"
    scene ch05_hhouse03_11 at hand_camera with Dissolve(0.8)
    d "**(근데 레나는 그 와중에....)**"
    d "**(그 와중에 그런 장난을 하다니 하하하..)**"
    d "**(근데 난 레나처럼 야한 여자가 좋아....젠장...)**"
    scene ch05_hhouse03_12 at hand_camera with Dissolve(0.8)
    d "**(난 당신을 사랑한다고요!!!)**"
    d "**(알아요 레나??)**"
    d "**(젠장......)**"
    scene ch05_hhouse03_12-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse03_13 at hand_camera with Dissolve(0.8)
    d "**(어찌됐건 지금 나는 셀린과의 약속으로 저녁 외출을 한다....)**"
    d "**(........)**"
    d "**(그녀와 둘이서 식사를 하는건 오랜만이군..)**"
    scene ch05_hhouse03_14 at hand_camera with Dissolve(0.8)
    d "**(근데.....)**"
    d "**(셀린이 요즘 좀 이상해..)**"
    d "**(뭔가 숨기는거 같기도 하고 말이지...)**"
    d "**(날 보는 표정이 좀 어색하단 말이야....)**"
    d "**(.........)**"
    play sound "audio/ambi/dooropen03.mp3"
    scene ch05_hhouse03_15 at hand_camera with Dissolve(0.8)
    d "뭐 만나보면 알겠지."
    scene ch05_hhouse03_16 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_hhouse03_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_hhouse03_17-02 at hand_camera with Dissolve(1.3)
    d "..........."
    scene ch05_hhouse03_18 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    scene ch05_hhouse03_19 at hand_camera with Dissolve(1.3)
    pause
    scene ch05_hhouse03_20 at hand_camera with Dissolve(0.8)
    d "앵??!!!!"
    d "와우 셀린....."
    d "뭔가 많이 바뀐거 같은데?"
    scene ch05_hhouse03_21 at hand_camera with Dissolve(0.8)
    c "귀신이라도 본 표정이네."
    c "빨리 가자 배고프다."
    scene ch05_hhouse03_22 at hand_camera with Dissolve(0.8)
    c "뭘 그렇게 꾸물대는거야."
    c "어서 타."
    scene ch05_hhouse03_23 at hand_camera with Dissolve(0.8)
    d "알겠습니다 여왕님."
    c "셧업."
    jump ch05_bar01

label ch05_bar01:
    if not in_replay:
        $ persistent.unlock_ch05_bar01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Two hours later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal11.mp3" volume 1.7
    scene ch05_bar01_01 at hand_camera with Dissolve(0.8)
    d "아 저녁 너무 많이 먹었나."
    d "배부르구만."
    scene ch05_bar01_02 at hand_camera with Dissolve(0.8)
    c "그러게 오늘 너 좀 의외네."
    c "넌 항상 남자치고 적게 먹었잖아."
    d "음식이 맛있어서 간만에 많이 먹었어."
    d "아만다가 많이 좀 먹으라고 볼때마다 그러는데 그게 참 안되네."
    scene ch05_bar01_03 at hand_camera with Dissolve(0.8)
    c "아만다 아주머니는 잘 지내셔?"
    c "언제 한 번 뵈야 하는데 안부전화도 안해서 죄송하네."
    d "괜찮아."
    d "아주 건강하게 잘 지내셔."
    d "너 보고 싶다고 하더라."
    d "내가 대신 안부 전할게."
    scene ch05_bar01_04 at hand_camera with Dissolve(0.8)
    c "나 어렸을땐 어른이 되면 아만다 처럼 되고 싶었는데...."
    d "뭐라고? ㅎㅎㅎ"
    c "남자는 절대 모르는 여자만의 시선이 있다고."
    c "아만다는 정말 매력있는 여자야."
    d "음......."
    scene ch05_bar01_05 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_06 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch05_bar01_07 at hand_camera with Dissolve(0.8)
    d "그래서 결혼 생활은 어때?"
    d "벌써 몇개월 됐지?"
    scene ch05_bar01_08 at hand_camera with Dissolve(0.8)
    c "........"
    n "그녀는 [d_name]의 결혼에 대한 질문에 잠시 말을 멈췄다."
    pause
    n "말 없이 한 참을 침묵하다 다시 말을 이어갔다."
    scene ch05_bar01_09 at hand_camera with Dissolve(0.8)
    c "어때 보이는데?"
    d "나한테 묻는거야?"
    d "흠......."
    d "나야 뭐....특별히 느껴지는건 없는데?"
    scene ch05_bar01_10 at hand_camera with Dissolve(0.8)
    c "괜찮아."
    c "그냥 무지성으로 말해도 돼."
    d "음....."
    d "행복해 보이는데?"
    d "저녁에 남자인 친구를 만나게 해준다는건 이해심이 많은 남자인가?"
    scene ch05_bar01_09 at hand_camera with Dissolve(0.8)
    c "아 쫌!!"
    c "결혼했다고 집에만 있는게 아니라니까!!"
    c "부부가 종일 껴안고 있는 줄 아냐?"
    scene ch05_bar01_10 at hand_camera with Dissolve(0.8)
    d "음....."
    d "...."
    d "근데 요즘 좀 생각이 많아 보이기도 하고?..."
    c "생각이 많아보인다고?"
    d "응."
    d "뭔가 답답한게 있어보여."
    scene ch05_bar01_11 at hand_camera with Dissolve(0.8)
    c "........"
    if not in_replay:
        $ add_point("love_celine", 1, "love_celine")
    d "......"
    scene ch05_bar01_12 at hand_camera with Dissolve(0.8)
    c "니가 내 남편보다 날 더 정확하게 보는구나...."
    d "뭐?"
    d "하하하."
    d "니가 날 띄엄띄엄 봤구나."
    d "나 이래뵈도 심리학 전공이라고."
    d "난 나름 예리한 분석력을 가지고 있다고."
    c "오~~"
    c "그러시군요 아저씨."
    scene ch05_bar01_13 at hand_camera with Dissolve(0.8)
    d "야 우리가 같이 한게 몇 년인데 내가 널 모르겠냐?"
    d "우리는 남매같은 사이잖아."
    d "척하면 척이라고."
    d "애기 때부터 거의 20년 가까이 알고 지냈는데 섭하게 무슨 말이야 그게."
    scene ch05_bar01_14 at hand_camera with Dissolve(0.8)
    c "........"
    c "그렇긴 하지.."
    c "볼거 못볼거 다 보고 자랐으니까...."
    scene ch05_bar01_15 at hand_camera with Dissolve(0.8)
    c "후우......."
    d "왜그러는데?"
    d "무슨 일인데 그래?"
    c "........"
    pause
    c "신혼이라고 매일이 핑크빛일 줄 알았는데....."
    c "........."
    c "현실은 그렇지 않더라."
    scene ch05_bar01_13 at hand_camera with Dissolve(0.8)
    d "......"
    d "왜 무슨 문제라도 있는거야?"
    scene ch05_bar01_16 at hand_camera with Dissolve(0.8)
    c "......."
    c "아니 딱히 문제는 없는데...."
    c "..."
    c "뭐랄까...."
    d ".........."
    c "내가 기대했던 것과 좀 다르다고 해야하나..."
    c "아니 기대했다기보다 내가 생각했던 결혼 생활과 달라.."
    scene ch05_bar01_17 at hand_camera with Dissolve(0.8)
    c "...근데 사실 나는 핑크빛이고 뭐고, 그냥 좋았어."
    c "........."
    c "누가 날 기다려준다는 거."
    c "집에 가면 누가 있다는 거."
    scene ch05_bar01_18 at hand_camera with Dissolve(0.8)
    d "......"
    scene ch05_bar01_19 at hand_camera with Dissolve(0.8)
    c "너도 알잖아."
    c "우리 그렇게 자랐잖아."
    c "........."
    c "보육원 방 불 끄고 누우면..."
    c "남들은 다 어딘가로 돌아가는데 우리들만 남는 기분."
    scene ch05_bar01_20 at hand_camera with Dissolve(0.8)
    d "........"
    c "난 그게 진짜 싫었어."
    c "외로운 거."
    c "엄마의 품이 아니라 인형을 끌어안고 잠들어야 하는거.."
    scene ch05_bar01_19 at hand_camera with Dissolve(0.8)
    d "난 인형이 없었........"
    c "입양 갔던 집도......"
    c "너도 알잖아. 내 양아버지도 프랭크 못지 않은거......"
    d "알지......"
    c ".........."
    c "그래서 난 어떻게든 빨리 가정을 만들고 싶었나봐.."
    scene ch05_bar01_20 at hand_camera with Dissolve(0.8)
    c "그래서 결혼한다고 했을 때 사람들이 왜 그렇게 서두르냐고....."
    c "나이 차이도 있는데 괜찮겠냐고 걱정했는데...."
    scene ch05_bar01_21 at hand_camera with Dissolve(0.8)
    c "나한테는 그게 중요한 게 아니었어. "
    d "........"
    c "그 사람이 '이제 넌 혼자가 아니야'라고 말해준 게 중요했지."
    c "그게 그 사람의 프로포즈였거든..."
    scene ch05_bar01_22 at hand_camera with Dissolve(0.8)
    c "후훗....."
    scene ch05_bar01_23 at hand_camera with Dissolve(0.8)
    d "......"
    scene ch05_bar01_24 at hand_camera with Dissolve(0.8)
    c "왜 날 그렇게 봐 하하."
    c "예상 못한 얘기 였나?"
    c "신혼인데 이런 얘기 하니까 놀랐지?"
    scene ch05_bar01_25 at hand_camera with Dissolve(0.8)
    d "아니..."
    d "그냥...."
    d "경청하고 있었어."
    d "니가 그런 생각을 하는지 정말 몰랐네.."
    scene ch05_bar01_26 at hand_camera with Dissolve(0.8)
    c "......"
    c "소꿉친구에게도 처음 하는 얘기는 있는 법이지.."
    c "후.........."
    c "......"
    scene ch05_bar01_27 at hand_camera with Dissolve(0.8)
    c "아 그런데 좋은 사람이야. 그이는..."
    c "정말 좋은 사람이라고."
    d "나 아무말도 안했거든?"
    scene ch05_bar01_28 at hand_camera with Dissolve(0.8)
    d "흐음...."
    d "셀린이 날 포기하고 선택한 남자인데 당연히 좋은 사람이겠지."
    c "여보세요 아저씨."
    c "넌 단 한번도 나에게 남자인적 없거든?"
    c "꼬맹이 주제에..."
    d "후훗..."
    n "그들은 오랜만에 둘만의 시간을 가지며 즐거운 대화를 이어갔다."
    n "마치 친자매 처럼 격식 없이, 꾸밈 없이..."
    n "[d_name]과 셀린 모두 오로지 서로에게만 할 수 있는 이야기들을 하며 스트레스를 풀었다."
    n "그리고 그들의 만남은 생각보다 길어져갔다....."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal08.mp3" volume 2.0
    scene ch05_bar01_30 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh04.mp3"
    c "하하하."
    c "맞아 그런일이 있었지."
    scene ch05_bar01_31 at hand_camera with Dissolve(0.8)
    c "난 그때 처음 봤어."
    c "그렇게 선생님들이 화낸 모습은 처음이었다고."
    c "메리가 그렇게 무서운 선생님인지 처음 알았다니까."
    scene ch05_bar01_32 at hand_camera with Dissolve(0.8)
    d "그런건 누가 봐도 화냈을거야."
    d "꼬맹이들이 방이 춥다고 보육원에 불을 지르려고 했으니까 하하하."
    play voice_f "audio/voices/flaugh04.mp3"
    c "하하하하하."
    c "대체 넌 어렸을때 그런 생각을 어떻게 한거야?"
    c "넌 방화범이야. 방화범이라고."
    scene ch05_bar01_32-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_33 at hand_camera with Dissolve(0.8)
    c "하하하하. 생각났다."
    c "너 그때 빨개벗기고 벌 받았잖아."
    d "!!!!!!!"
    scene ch05_bar01_34 at hand_camera with Dissolve(0.8)
    d "그랬었다고?"
    d "흠........"
    d "그땐 그런 체벌이 가능했었나?"
    scene ch05_bar01_35 at hand_camera with Dissolve(0.8)
    c "........"
    c "그땐 진짜 꼬맹이었는데...."
    c "지금은..."
    c "넌 대학생이고 난 유부녀라니...."
    scene ch05_bar01_36 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_37 at hand_camera with Dissolve(0.8)
    c "크흠...."
    c "나이들고...."
    c "몸도 커졌고...."
    scene ch05_bar01_38 at hand_camera with Dissolve(0.8)
    d "그래..."
    d "시간이 정말 빠르게 흘러."
    d "나도 곧 취업하느라 난리겠지."
    scene ch05_bar01_39 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_40 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_monica = True
        $ bio_leila = True
    mo "두 분 잘어울리네요. ㅎㅎ"
    mo "커플이세요?"
    scene ch05_bar01_41 at hand_camera with Dissolve(0.8)
    d "커..커플이요??"
    c "네?!!!!"
    c "아니에요!!"
    scene ch05_bar01_43 at hand_camera with Dissolve(0.8)
    c "우리는 소꿉친구에요 ㅎㅎ."
    scene ch05_bar01_44 at hand_camera with Dissolve(0.8)
    mo "아 정말 미안해요."
    mo "제가 정말 큰 실례를 했습니다."
    scene ch05_bar01_45 at hand_camera with Dissolve(0.8)
    c "아 괜찮아요 ㅎㅎ"
    c "그럴수도 있죠."
    scene ch05_bar01_46 at hand_camera with Dissolve(0.8)
    c "사실 얘랑 같이 있으면 별소리 다들어요."
    c "남매냐, 커플이냐, 부부냐, 친구 사이냐 등등."
    scene ch05_bar01_47 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh09.mp3"
    mo "아 하하."
    mo "그럼 전 최악은 아니네요."
    mo "제가 잘 맞추는 편인데 이번은 확실하게 틀렸네요 하하."
    scene ch05_bar01_48 at hand_camera with Dissolve(0.8)
    mo "필요한거 있으면 얘기해요."
    mo "실수한 보상으로 그냥 드릴게요."
    c "네 고맙습니다 ㅎㅎ."
    d "**(지금 필요한건.....)**"
    d "**(아줌마의 엉덩이입니다.....)**"
    d "..........."
    scene ch05_bar01_49 at hand_camera with Dissolve(0.8)
    d "ㅋㅋㅋㅋ"
    d "너랑 내가 커플이라는 상상만 해도 토나올거 같아."
    d "아잉 사랑해요~베이비~"
    d "오늘 밤 당신은 내거에요~"
    scene ch05_bar01_50 at hand_camera with Dissolve(0.8)
    c "죽고싶냐?!!"
    d "하하하하."
    scene ch05_bar01_51 at hand_camera with Dissolve(1.5)
    d "난 사실...."
    d "니가 이제 유부녀라는게 아직도 안믿겨."
    d "결혼식을 못봐서 그런가 그냥 바뀐게 없는거 같아..."
    scene ch05_bar01_52 at hand_camera with Dissolve(0.8)
    c "............."
    scene ch05_bar01_53 at hand_camera with Dissolve(0.8)
    d "어렸을 땐 말이야.."
    d "난 당연히 너랑 결혼할거라 생각했어."
    d "이 세상에 여자는 너 한명이라 생각했거든.."
    scene ch05_bar01_54 at hand_camera with Dissolve(0.8)
    c "개소리하지 이 망할 위선자 놈아."
    scene ch05_bar01_55 at hand_camera with Dissolve(0.4)
    d "뭐?"
    d "무슨 말이야?"
    d "내가 왜 위선자야?"
    scene ch05_bar01_56 at hand_camera with Dissolve(0.8)
    c "어떻게 니가 나한테 그럴수 있어?"
    c "이 변태 새끼야."
    scene ch05_bar01_57 at hand_camera with Dissolve(0.8)
    d "뭐야 갑자기 뜬금없이 뭔 소리하는거야?"
    d "취했냐?"
    d "내가 변태라니..."
    d "난 그냥 여기서 오렌지 쥬스 마시고 있었다고."
    scene ch05_bar01_58 at hand_camera with Dissolve(0.8)
    c "............."
    c "대체 남자들은 왜 하나같이 다들 그모양인지.."
    d "뭔 말이야 그게 대체?"
    d "스무고개 하지말고 그냥 말해 좀."
    scene ch05_bar01_59 at hand_camera with Dissolve(0.8)
    c "............."
    c "난 봤다."
    d "뭐?"
    scene ch05_bar01_60 at hand_camera with Dissolve(0.8)
    d "........"
    d "다 봤다니 무슨말이야 그게?"
    scene ch05_bar01_61 at hand_camera with Dissolve(0.8)
    c "..........."
    c "**(젠장..)**"
    c "**(이거 좋은 선택인거 맞나 셀린?)**"
    c "**(그냥 모른체 덮는게 맞는거 아닌가?.....)**"
    scene ch05_bar01_62 at hand_camera with Dissolve(0.8)
    n "그녀는 폰을 집어들고 잠시 생각했다."
    pause
    n "그리고 이내 결심한 듯 그녀의 폰을 테이블 위에 올려놓았다."
    scene ch05_bar01_63 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/erotic09.mp3"
    scene ch05_bar01_64 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!"
    scene ch05_bar01_65 at hand_camera with Dissolve(0.8)
    d "아니 이게 어떻게........"
    pause
    d "맙소사......"
    scene ch05_bar01_66 at hand_camera with Dissolve(0.8)
    n "[d_name]의 심장이 마치 밖으로 튀어나오려는 듯이 쿵쾅거렸다."
    n "자신의 발기한 모습을 셀린이 보았다는데서 오는 흥분은 전혀 없었고,"
    n "마치 현장에서 검거된 범인 처럼 절망에 휩쌓였다."
    scene ch05_bar01_67 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_68 at hand_camera with Dissolve(0.8)
    c "너........"
    scene ch05_bar01_69 at hand_camera with Dissolve(0.8)
    d "........"
    scene ch05_bar01_70 at hand_camera with Dissolve(0.8)
    c "지난번 비 오던 날 메리 사무실에 있었을 때...."
    c "그때도 메리 옆에서 그거 꺼내놓고 있었지?"
    scene ch05_bar01_69 at hand_camera with Dissolve(0.8)
    d "뭐?..........."
    pause
    d "아...아니...."
    d "그...그게 무슨 말이야?"
    d "**(셀린이 그걸 어..어떻게 알았지?)**"
    d "**(혹시 그 내가 한 짓을 다 본거 아냐??!!)**"
    d "**(아 젠장....)**"
    d "**(빗소리에 문이 열리는 소리를 못들어나???)**"
    scene ch05_bar01_72 at hand_camera with Dissolve(0.8)
    c "............"
    c "미친새끼...."
    c "......"
    c "너 메리에게 무슨 짓을 한거야?"
    c ".........."
    c "너 메리하고 잔거야?"
    scene ch05_bar01_74 at hand_camera with Dissolve(0.8)
    d "뭐??!!"
    d "절대 아냐!! 내가 어떻게 메리와 그런 짓을..."
    d "너야 말로 미친소리 하지마 셀린."
    d "메리가 나에게 어떤 존재인데 내가 메리와 그런 짓을..."
    scene ch05_bar01_75 at hand_camera with Dissolve(0.8)
    c "........"
    c "이런 미친놈이 내 친구였다니..."
    scene ch05_bar01_76 at hand_camera with Dissolve(0.8)
    d "뭐..뭐야..."
    scene ch05_bar01_77 at hand_camera with Dissolve(0.8)
    c "그 큰 고추로 메리를 꼬신거야?"
    d "뭐?!!!!!!"
    scene ch05_bar01_78 at hand_camera with Dissolve(1.2)
    d "**(젠장 제대로 걸려들은거 같은데......)**"
    d "**(아 썅.......)**"
    d "**(무섭네....)**"
    scene ch05_bar01_79 at hand_camera with Dissolve(0.8)
    c "그 큰 고추로 메리에게 깊은 인상을 준거냐고?"
    c "메리가 뭐래?"
    c "그녀의 몸안에 꽉 차는 느낌이래?"
    scene ch05_bar01_80 at hand_camera with Dissolve(0.8)
    d "........"
    d "미...미안한데 저리 좀....가..가 줄래?"
    d "너 지금 좀 무서워...."
    d "꽉차긴 뭐가 꽉차...."
    d "그런거 아니야."
    scene ch05_bar01_81 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_82 at hand_camera with Dissolve(0.8)
    c "변태 새끼."
    c "대체 몇 살 차이야..."
    d "그런거 아니라니까..."
    c "............."
    c "넌 언제나 가장 얌전해 보이지만 가장 큰 사고를 치고다니는 놈이었어."
    c "어릴땐 그냥 바보 같은게 귀여웠는데..."
    c "......"
    c "지금은 넌 역겨워."
    scene ch05_bar01_84 at hand_camera with Dissolve(0.8)
    d "니가 생각하는 그런거 아니야."
    d "........."
    d "넌 완전히 잘못 짚었어."
    scene ch05_bar01_85 at hand_camera with Dissolve(0.8)
    c "더 이상 말하지마."
    c "한 마디만 더 하면 너랑 인연을 완전히 끊을거야."
    scene ch05_bar01_86 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_bar01_87 at hand_camera with Dissolve(1.1)
    pause
    scene ch05_bar01_87-02 at hand_camera with Dissolve(0.8)
    c "............"
    stop music fadeout 1.0
    c "보여줘."
    scene ch05_bar01_87-03 at hand_camera with Dissolve(0.8)
    d "........"
    d "보...보여 달라니 뭘?"
    scene ch05_bar01_87-04 at hand_camera with Dissolve(0.8)
    c "순진한척 하지마."
    c "뭐긴 뭐야 니 고추지."
    d "!!!!!!!!!!!!!!!"
    scene ch05_bar01_87-05 at hand_camera with Dissolve(0.8)
    d "........"
    pause
    d "지...지금??"
    pause
    d "여...여기서?"
    scene ch05_bar01_87-06 at hand_camera with Dissolve(0.8)
    c "그래."
    c "니가 합성해서 메리에게 사기친건지 확인해야겠어."
    c "니가 메리를 가지고 노는건지 확인할거라고!!"
    scene ch05_bar01_87-07 at hand_camera with Dissolve(0.8)
    d "........"
    pause
    d "사...사기는 아니야.."
    d "합성 아니라고."
    d "......."
    d "내 거 맞아.."
    c "하!! 걸려들었어."
    c "이 미친놈!!"
    scene ch05_bar01_88 at hand_camera with Dissolve(0.8)
    d "젠장....."
    scene ch05_bar01_88-02 at hand_camera with Dissolve(0.8)
    n "그는 멍한 상태로 지퍼로 손을 가져갔다."
    pause
    play sound "audio/ambi/zipper.mp3"
    n "그리고 지퍼를 열고 이미 발기한 성기를 꺼냈다."
    scene ch05_bar01_88-03 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic03.mp3"
    c "!!!!!!!!!!!"
    c "웟더퍽!!!!!!!!!!"
    scene ch05_bar01_88-04 at hand_camera with Dissolve(0.8)
    c "맙소사 [d_name]!!!!!!"
    if not in_replay:
        $ add_point("lust_celine", 1, "lust_celine")
    pause
    c "지...진짜로 꺼내면 어떡해 바보야!!!!!"
    d "니가 지금 꺼내라며??"
    c "너 미쳤어??!!!"
    c "아니 이 무슨..."
    scene ch05_bar01_88-03 at hand_camera with Dissolve(0.8)
    c "맙소사........"
    c "........."
    scene ch05_bar01_88-05 at hand_camera with Dissolve(0.8)
    d "............"
    c "......."
    n "[d_name]의 물건을 본 셀린은 충격에 빠졌다."
    n "그것은 그녀에게 실로 엄청난 경험이었다."
    n "소꿉친구 였던 [d_name]의 성기를 보는 것은 친구로서 감당하기 힘든 충격이었다."
    scene ch05_bar01_88-06 at hand_camera with Dissolve(0.4)
    d "쉣....."
    c "홀리......"
    play sound "audio/ambi/phonering02.mp3" volume 0.7
    n "전화가 울린다."
    scene ch05_bar01_89 at hand_camera with Dissolve(0.8)
    c "**(젠장...)**"
    stop sound
    scene ch05_bar01_90 at hand_camera with Dissolve(0.8)
    c "Hey, honey."
    c "........"
    c "응 지금 친구와 바에 있어."
    pause
    c "맞아. 루프탑바."
    scene ch05_bar01_90-02 at hand_camera with Dissolve(0.8)
    c "........"
    c "응 알겠어."
    c "이따 봐 허니."
    c "사랑해."
    scene ch05_bar01_91 at hand_camera with Dissolve(0.8)
    d "........."
    d "너의 남편이야?"
    scene ch05_bar01_92 at hand_camera with Dissolve(0.8)
    c "......."
    c "맞아."
    c "날 데리러 온데."
    scene ch05_bar01_93 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch05_bar01_94 at hand_camera with Dissolve(0.8)
    c "맙소사....."
    if not in_replay:
        $ add_point("lust_celine", 1, "lust_celine")
    c "이제 좀 집어넣어라 좀!!!"
    c "뭐하는거야 이 멍청이야."
    scene ch05_bar01_94-02 at hand_camera with Dissolve(0.8)
    c ".........."
    c "어렸을 땐 귀여웠는데....."
    c "이건 마치......"
    pause
    c "너에게 배신당한 느낌이야...."
    d "....."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal11.mp3"
    scene ch05_bar01_95 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_96 at hand_camera with Dissolve(0.8)
    unknownm "셀린!"
    scene ch05_bar01_97 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_bar01_98 at hand_camera with Dissolve(0.8)
    d "!!"
    scene ch05_bar01_99 at hand_camera with Dissolve(0.8)
    c "안녕 허니."
    scene ch05_bar01_100 at hand_camera with Dissolve(0.8)
    c "넌 나와 메리의 관계를 영원히 바꿔 놓았어."
    d "뭐?!!"
    c "이제 메리를 보면 니 고추 사진이 항상 생각날거야."
    d "......."
    scene ch05_bar01_101 at hand_camera with Dissolve(0.8)
    c "나중에 봐."
    c "아줌마들에게 흘리고 다니면 나중에 큰일 난다."
    c "정신 차려라 이놈아."
    c "아무리 섹스가 좋아도 이 좁은 동네에서 그녀들의 남편들과 원수가 되려고 그래?"
    c "문제될거 없는 또래를 찾으라고 또래를."
    scene ch05_bar01_102 at hand_camera with Dissolve(0.8)
    d "!!"
    scene ch05_bar01_104 at hand_camera with Dissolve(1.3)
    unknownm "좀 시간이 늦어졌네용 우리 이쁜이(느끼한 어투)."
    c "미안해요. 미리 연락을 못했어요."
    d "**(우리 이쁜이.....)**"
    scene ch05_bar01_105 at hand_camera with Dissolve(1.3)
    unknownm "안녕하세요."
    unknownm "셀린 남편 래리입니다."
    d "아..안녕하세요."
    d "전 [d_name]입니다."
    d "그녀와 같은 보육원에서 지냈던 친구입니다."
    la "아 알고있습니다."
    la "그녀에게 얘기 들었습니다."
    la "기회가 되면 나중에 같이 식사 한 번 하시죠."
    d "아...네 좋습니다."
    la "그럼 저희 먼저 가보겠습니다."
    scene ch05_bar01_106 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_bar01_106-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_bar01_107 at hand_camera with Dissolve(0.8)
    d "........."
    pause
    d "**(셀린이 뭔가 하고 싶은 말을 안한거 같은데.....)**"
    d "흐음.........."
    scene ch05_bar01_108 at hand_camera with Dissolve(1.3)
    d "맙소사....."
    d "정신이 하나도 없네...."
    scene ch05_bar01_109 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_bar01_110 at hand_camera with Dissolve(1.2)
    mo "**(후훗.......)**"
    mo "**(......)**"
    scene ch05_bar01_111 at hand_camera with Dissolve(1.2)
    pause
    jump ch05_orph01

label ch05_orph01:
    if not in_replay:
        $ persistent.unlock_ch05_orph01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch05_orph01_01 at hand_camera with Dissolve(1.2)
    play sound "audio/ambi/park01.mp3" loop
    pause
    scene ch05_orph01_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_04 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_05 at hand_camera with Dissolve(1.2)
    pause
    stop sound fadeout 0.5
    scene ch05_orph01_06 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_09 at hand_camera with Dissolve(0.8)
    d "!!!!!!"
    scene ch05_orph01_10 at hand_camera with Dissolve(0.8)
    h "**(쉣.....)**"
    scene ch05_orph01_11 at hand_camera with Dissolve(0.8)
    d "조....좋은 아침이에요 [h_name]."
    scene ch05_orph01_12 at hand_camera with Dissolve(0.8)
    h "굿모닝 [d_name]."
    h "........."
    h "우리 한참만에 보는거 같네요 하하."
    scene ch05_orph01_13 at hand_camera with Dissolve(0.8)
    d "네 그러게요 ㅎㅎ."
    d "......"
    d "몸 상태는 좀 괜찮으세요?"
    scene ch05_orph01_14 at hand_camera with Dissolve(0.8)
    h "네 괜찮아요."
    h "레나가 같이 있어줘서 덕분에...."
    scene ch05_orph01_15 at hand_camera with Dissolve(0.8)
    d "아 레나...."
    d "......"
    d "다행입니다 괜찮아 지셔서."
    scene ch05_orph01_16 at hand_camera with Dissolve(0.8)
    h "하........"
    h "부끄럽네요..."
    h "그런 모습을 보여서...."
    h "이 나이먹고 왠 술을 그렇게 마셨는지....."
    scene ch05_orph01_17 at hand_camera with Dissolve(0.8)
    d "하하 부끄럽긴요."
    d "살다보면 그런 날도 있는거죠."
    d "너무 신경쓰지 마세요."
    scene ch05_orph01_18 at hand_camera with Dissolve(0.8)
    h "그래요...."
    h "아 혹시..."
    h "물어볼게 있는데.."
    scene ch05_orph01_17 at hand_camera with Dissolve(0.8)
    d "네?"
    d "어떤거요?"
    scene ch05_orph01_20 at hand_camera with Dissolve(0.8)
    h "........"
    h "혹시......"
    scene ch05_orph01_21 at hand_camera with Dissolve(0.8)
    h "내가 술마시고 온 날.."
    d "..........."
    h "혹시......"
    h "나 혹시 [d_name]의 방에 들어갔었어요??"
    scene ch05_orph01_22 at hand_camera with Dissolve(0.8)
    d "네??!!"
    d "........"
    d "랜드레이디가 제 방에 왔었냐구요?!!"
    d "..........."
    scene ch05_orph01_23 at hand_camera with Dissolve(0.8)
    h "하..........."
    h "내가 그날 기억이 가물가물해서....."
    h "........"
    h "내가 침대로 어떻게 갔는지도 모르겠고....."
    h "레나는 또 언제 온건지..."
    scene ch05_orph01_24 at hand_camera with Dissolve(0.8)
    h "..........."
    h "내가 뭔가를....."
    h "......"
    h "내가 [d_name]군과 뭔가를 했던거 같기도 하고...."
    scene ch05_orph01_22 at hand_camera with Dissolve(0.8)
    d "........."
    d "**(젠장...)**"
    d "**(그녀가 뭔가 본거 같은데 그 날??!!)**"
    d "**(지금 애둘러 말하는건가?)**"
    d "**(혹시 내가 레나에게 그 짓거리 한걸 다 본거 아냐??)**"
    scene ch05_orph01_25 at hand_camera with Dissolve(0.8)
    h "나 혹시....."
    h "그날 밤에 [d_name]군에게 무슨 짓을 한건아니죠?"
    scene ch05_orph01_25-02 at hand_camera with Dissolve(0.8)
    d "네?"
    d "그..그게 무슨 말이에요?"
    d "........"
    d "[h_name]이 저에게 무슨 짓을 했냐니요?..."
    scene ch05_orph01_24 at hand_camera with Dissolve(0.8)
    h "**(젠장....)**"
    h "**(아니라고 안하는거 보니까 진짜 무슨 일이 있어나보네 하........)**"
    h "**(그냥 말 안하는게 낫나?.....)**"
    h "**(그냥 꿈이었나?)**"
    h "**(궁금해서 미치겠네....)**"
    scene ch05_orph01_27 at hand_camera with Dissolve(0.8)
    h "내가 혹시 그날 [d_name]군에게 블로우잡을 해줬어요?"
    scene ch05_orph01_28 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!!!!!!!!"
    d "뭐라고요????!!!"
    d "........"
    d "브..블로우 잡이요??"
    scene ch05_orph01_30 at hand_camera with Dissolve(0.8)
    h "........."
    h "아니죠?...."
    h "그쵸?"
    h "...."
    h "너무 기억이 생생해서......"
    h "네가 내 머리를 잡고 거칠게........"
    scene ch05_orph01_31 at hand_camera with Dissolve(0.8)
    d ".........."
    d "아...아뇨...그건..."
    d "그건 [h_name]이 아니라 레..!!!"
    d "아 아뇨 그런 일은 없었어요."
    scene ch05_orph01_30 at hand_camera with Dissolve(0.8)
    h "화...확실해요?"
    scene ch05_orph01_31 at hand_camera with Dissolve(0.8)
    d ".........."
    d "그...그런 일이 있었다면..."
    menu:
        n "What should I do?"
        "제가 지금 [h_name]을 끌어안고 키스를 하고있지않을까요?":
            d "그...그런 일이 있었다면..."
            d "제가 지금 [h_name]을 끌어안고 키스를 하고있지않을까요?"
            d "**(젠장 지금 멘트 멋졌다.)**"
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
        "아.....그런 일은 없었어요.":

            d "그...그런 일이 있었다면..."
            d "아.....그런 일은 없었어요."
            d "......."
    scene ch05_orph01_32 at hand_camera with Dissolve(0.8)
    h "휴......"
    h "그럼 다행이네요...."
    h "다 제 꿈이었나봐요."
    scene ch05_orph01_33 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh02.mp3"
    h "하하하."
    h "이 나이먹고 주책이네요."
    h "그런 꿈을 꾸다니..."
    h "아침부터 흉악한 소릴 해서 미안해요 하하."
    h "블로우잡이라니 맙소사..."
    h "그냥 내가 개소리한거라 생각하고 잊어요 알겠죠?"
    scene ch05_orph01_34 at hand_camera with Dissolve(0.8)
    d "아 네......"
    d "그렇게 하겠습니다."
    scene ch05_orph01_34-02 at hand_camera with Dissolve(0.8)
    h "혹시 우리 신나게 섹스한건아니죠??"
    d "네?!!!!!!!"
    d "시...신나게 섹스요??!!!"
    h "혹시 내가 창피할까봐 거짓말하는건 아니죠??"
    scene ch05_orph01_34-03 at hand_camera with Dissolve(0.8)
    h "아 미안해요."
    h "아줌마가 주책없는 소리를 했네요."
    h "그냥 못들은걸로 해요."
    scene ch05_orph01_35 at hand_camera with Dissolve(0.8)
    h "오늘 회사 첫 출근하는거에요?"
    scene ch05_orph01_36 at hand_camera with Dissolve(0.8)
    d "아 아뇨 ㅎㅎ"
    d "출근은 내일부터구요 지금은 잠시 메리 선생님좀 보고 오려구요."
    scene ch05_orph01_36-02 at hand_camera with Dissolve(0.8)
    h "아 그렇군요."
    h "내가 데려다 줄까요?"
    scene ch05_orph01_36 at hand_camera with Dissolve(0.8)
    d "아 괜찮습니다."
    d "운동도 할겸 전 자전거 타고 가면 됩니다."
    scene ch05_orph01_36-03 at hand_camera with Dissolve(0.8)
    d "남자는 하체가 중요하잖아요 하하하."
    h "**(뭐야 저 행동은...)**"
    h "**(아 진짜 무슨 일 있었던거 아냐??!!)**"
    scene ch05_orph01_37 at hand_camera with Dissolve(0.8)
    h "그래요 그럼."
    h "편한대로 해요."
    h "저녁에 봐요."
    d "넵 알겠습니다."
    d "다녀올게요."
    play sound "audio/ambi/dooropen02.mp3"
    scene ch05_orph01_38 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene ch05_orph01_39 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_40 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_41 at hand_camera with Dissolve(1.2)
    h "[d_name]과 레나가 분명 나에게 뭔가 숨기고 있는거 같은데...."
    h "하........"
    scene ch05_orph01_42 at hand_camera with Dissolve(1.2)
    h "............."
    h "하...이 미친년...."
    h "대체 어떻게 이런 일이...."
    h "이게 대체 무슨 행위야......"
    h "........"
    h "뭐지이게?...섹스하려고 했나?..."
    h "근데 팬티는 또 입고 있잖아....."
    h "하......."
    h "레나는 또 이 사진을 어떻게 찍은거야....하..."
    scene ch05_orph01_43 at hand_camera with Dissolve(0.8)
    h ".........."
    h "미치겠다 진짜..."
    h "레나와 [d_name]모두 날 위해서 말 안하고 있나??"
    h "하...........진짜...."
    h "술이 왠수다...술이 왠수야...."
    h "아이비에게 미안해서 어떻게 얼굴을 보지...."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene ch05_orph01_43-02 at hand_camera with Dissolve(0.8)
    n "[d_name]은 메리를 보기 위해 보육원에 왔다."
    n "하지만 그는 어제 셀린과의 대화 이후로 메리를 만나는데 어려움을 겪기 시작했다."
    n "메리와의 평범한 만남도 이젠 셀린의 시선을 피해야 했다."
    scene ch05_orph01_43-03 at hand_camera with Dissolve(0.8)
    d "........"
    d "**(셀린이 없을리가 없지.....)**"
    scene ch05_orph01_43-04 at hand_camera with Dissolve(0.8)
    d "**(웟더퍽 셀린..)**"
    d "**(여기가 무슨 클럽인줄 아나?)**"
    d "**(어제부터 왜 저래 갑자기..)**"
    scene ch05_orph01_44 at hand_camera with Dissolve(0.8)
    d "**(마이갓.....)**"
    d "**(엉덩이가 다 보이잖아.)**"
    d "**(메리가 보면 극대노 할거 같은데?)**"
    d "**(저 정도면 메리가 쫓아낼 정도야..)**"
    scene ch05_orph01_44-02 at hand_camera with Dissolve(0.8)
    d "**(홀리쉣!!)**"
    d "**(........)**"
    scene ch05_orph01_45 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_46 at hand_camera with Dissolve(0.8)
    pause
    ev "뭐야 저 사람?"
    ev "......"
    scene ch05_orph01_47 at hand_camera with Dissolve(0.8)
    ev "왜 저러고 있지?"
    ev "셀린을 훔쳐보는 건가?"
    ev "......"
    ev "저거 꽃 아냐?"
    ev "헐......"
    ev "설마 저 남자 셀린에게 고백하려고 저러고 있는거야??!!!"
    scene ch05_orph01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_48 at hand_camera with Dissolve(0.8)
    ev "........"
    ev "도둑인가?"
    scene ch05_orph01_49 at hand_camera with Dissolve(0.8)
    ev "........"
    scene ch05_orph01_49-02 at hand_camera with Dissolve(0.8)
    ev "!!!!!!!!!!!!!"
    scene ch05_orph01_49-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_50 at hand_camera with Dissolve(1.2)
    ev "오마이갓!!"
    ev "어떡하지?"
    ev "경찰에 신고해야 하나??!!"
    ev "저기 문이 있는건 어떻게 알았지??"
    scene ch05_orph01_51 at hand_camera with Dissolve(1.3)
    d "젠장"
    d "내 집과 마찬가진 곳에 숨어들다니...."
    d "조상중에 도둑이 있는게 분명해..."
    d "하....이제 여기 올때마다 셀린 눈치를 살펴야 하나.."
    scene ch05_orph01_51-02 at hand_camera with Dissolve(1.3)
    d "젠장.."
    d "메리가 어디있지?"
    scene ch05_orph01_51-03 at hand_camera with Dissolve(0.8)
    d "불이 켜 있는거 보면 출근 한거 같은데...."
    scene ch05_orph01_52 at hand_camera with Dissolve(0.8)
    d "아 씨 셀린에게 들킬까봐 괜히 심장 두근거리네.."
    scene ch05_orph01_53 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!"
    scene ch05_orph01_54 at hand_camera with Dissolve(0.8)
    d "**(쉣!!)**"
    play sound "audio/ambi/dooropen02.mp3"
    scene ch05_orph01_55 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_56 at hand_camera with Dissolve(0.8)
    d "**(좆될뻔했다....)**"
    d "콜록!!"
    scene ch05_orph01_57 at hand_camera with Dissolve(0.4)
    m "!!!!!!!!"
    m "**(뭐야 왠 남자목소리지??)**"
    scene ch05_orph01_58 at hand_camera with Dissolve(1.2)
    pause
    scene ch05_orph01_59 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!"
    m "**(뭐야 이 사람?!!!!)**"
    m "**(변태인가???)**"
    scene ch05_orph01_60 at hand_camera with Dissolve(0.8)
    d "쉣!!!"
    d "저 여자 뭐야 여기 직원인가?!!"
    d "엄청 돌아다니네 진짜!!!"
    scene ch05_orph01_61 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_61-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_61-03 at hand_camera with Dissolve(0.8)
    n "[d_name]은 위기를 모면하기 위해 열려 있는 화장실 문을 열었다."
    scene ch05_orph01_61-04 at hand_camera with Dissolve(0.8)
    n "하지만 그 칸엔 한 여인이 있었고 순간 자신은 좆됐음을 인지했다."
    play music "audio/bgm/erotic09.mp3"
    scene ch05_orph01_61-05 at hand_camera with Dissolve(0.8)
    n "하지만 이내 여성의 실루엣과 헤어를 보고 그것이 메리임을 알아차렸다."
    scene ch05_orph01_62 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    m "[d_name]!!!!!!"
    m "너.....지금..."
    play sound "audio/ambi/dooropen.mp3"
    scene ch05_orph01_63 at hand_camera with Dissolve(0.8)
    ev "무슨 소리를 들은거 같은데..."
    pause
    ev "아닌가...."
    scene ch05_orph01_64 at hand_camera with Dissolve(0.8)
    m "..............."
    d "........"
    n "그 둘은 서로에게 하고 싶은 말이 있었지만 아무 말도 할 수 없었다."
    pause
    n "그저 서로의 얼굴을 바라볼 뿐이었다."
    scene ch05_orph01_65 at hand_camera with Dissolve(0.8)
    d "............"
    m ".........."
    scene ch05_orph01_66 at hand_camera with Dissolve(0.8)
    m "너 지금 뭐.."
    scene ch05_orph01_66-02 at hand_camera with Dissolve(0.8)
    d ".........."
    d "**(사랑해요 메리.)**"
    scene ch05_orph01_66-03 at hand_camera with Dissolve(0.8)
    m "**(!!!!)**"
    m "**(이거 왠 장미야.....)**"
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
        $ add_point("love_mary", 1, "love_mary")
    m "**(얘 지금 뭐하는 거지????)**"
    d "**(사랑한다구요 메리.....)**"
    d "**(메리의 꽃잎은 아직 떨어지지 않았어요.)**"
    d "**(메리는 한 송이의 장미 같은 여자에요.)**"
    scene ch05_orph01_66-05 at hand_camera with Dissolve(0.8)
    n "메리는 지금 상황에 제대로 대응 할 수 없었다."
    n "너무나 혼란스러운 나머지 자신이 아래 옷을 다 벗었다는 것을 잊었다."
    menu:
        n "What should I do?"
        "그녀에게 키스한다.":
            scene ch05_orph01_67 at hand_camera with Dissolve(0.8)
            m "읍!!!!!!!"
    scene ch05_orph01_68 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
    scene ch05_orph01_69 at hand_camera with Dissolve(0.8)
    n "그들은 이내 서로의 혀를 교환 했다."
    n "그리고 가능한 소리를 내지않고 서로의 혀를 교환했다."
    pause
    n "메리는 더 이상 그의 혀를 거부하지 않았다."
    scene ch05_orph01_70 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_71 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_72 at hand_camera with Dissolve(0.8)
    ev "으흐흥....."
    ev "살이 좀 쪘나?...."
    scene ch05_orph01_72-02 at hand_camera with Dissolve(0.8)
    ev ".........."
    ev "흐음......"
    ev "가슴이 좀 커졌나??"
    scene ch05_orph01_73 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    m "헤이!!"
    scene ch05_orph01_75 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    scene ch05_orph01_76 at hand_camera with Dissolve(1.2)
    play voice_f "audio/sex/gag03.wav"
    m "욱!!!!!!"
    scene ch05_orph01_76-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_77 at hand_camera with Dissolve(0.8)
    m "**(!!!!!!!!!!!)**"
    play voice_f  "audio/sex/liquid01.mp3"  
    scene ch05_orph01_79 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
    pause
    play voice_f "audio/sex/gag01.mp3"
    scene ch05_orph01_80 at hand_camera with Dissolve(0.8)
    m "꺼헉...."
    scene ch05_orph01_81 at hand_camera with Dissolve(0.8)
    ev "응?"
    play voice_f "audio/sex/gag03.wav" volume 2.0
    m "꺼헉......."
    ev "!!!!!!"
    scene ch05_orph01_81-02 at hand_camera with Dissolve(0.8)
    ev "누구에요? 괜찮아요?..."
    ev "......."
    play voice_f "audio/sex/gag03.wav" volume 2.0
    m "꺼헉......."
    ev "토하는 거에요??"
    pause
    ev "혹시 문제있어요?"
    pause
    ev "........."
    scene ch05_orph01_81-03 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/gag01.mp3"
    ev "!!!"
    scene ch05_orph01_82 at hand_camera with Dissolve(0.8)
    pause
    scene ch05_orph01_83 at hand_camera with Dissolve(0.8)
    ev "!!!!!!"
    pause
    hide screen top_ui_buttons
    jump ch06_orph01
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
