default ch04_started = False

label ch04_hstudio01:
    $ ch04_started = True
    if not in_replay:
        $ persistent.unlock_ch04_hstudio01 = True
    show screen top_ui_buttons
    scene chapter04_start with Dissolve(2.0)
    pause    
    play music "audio/bgm/erotic09.mp3"
    scene ch03_hstudio03_84-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    x "**(하아 하아....)**"
    n "소피아의 코에 [d_name]의 체취가 훅 풍겨져 왔다."
    n "그녀의 남편 외에 다른 남성의 체취를 느끼자 그녀는 혼란스러워졌다."
    scene ch03_hstudio03_85 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    h "그렇게 반만 내린 상태로 잠시 멈출게요. 좋아요."
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "**(하... 너무 더워서 안되겠다.)**"
    scene ch03_hstudio03_85-02 at hand_camera with Dissolve(0.8)
    h "두 사람 모두 잠깐만요."
    h "촬영을 멈춰서 미안해요."
    scene ch03_hstudio03_85-04 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_hstudio03_85-05 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_hstudio03_85-08 at hand_camera with Dissolve(1.2)
    pause
    scene ch03_hstudio03_85-09 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh01.mp3"
    pause
    scene ch03_hstudio03_85-10 at hand_camera with Dissolve(0.8)
    h "하... 이제 좀 살만하네요."
    h "제 맘대로 촬영을 끊어서 미안해요."
    scene ch03_hstudio03_85-10-02 at hand_camera with Dissolve(0.8)
    x "............."
    h "오늘 진짜 끈적거리네요."
    scene ch03_hstudio03_85-11 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    h "맘 같아선 다 벗고 싶지만..."
    play voice_f "audio/voices/flaugh02.mp3"
    h "전 모델이 아니기에 하하하."
    h "자 그럼 다시 시작할게요."
    scene ch04_hstudio01_00 at hand_camera with Dissolve(1.3)
    h "이제 완전히 내려주세요 마담!"
    scene ch04_hstudio01_01 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    scene ch04_hstudio01_01-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/skin06.mp3"
    scene ch04_hstudio01_01-03 at hand_camera with Dissolve(0.2)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    x "욱!!"
    n "찰칵!"
    scene ch04_hstudio01_02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "소피아가 그의 팬티를 완전히 내리자 거대한 그의 성기가 튀어오르며 그녀의 얼굴을 때렸다."
    n "그것은 평소 그녀가 알던 [d_name]의 이미지에 매치되지 않는 것이었다."
    scene ch04_hstudio01_02-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    x "**(..............)**"
    x "**(맙소사 [d_name]!!!!!)**"
    pause
    n "그녀의 제자였던 [d_name]의 성기를 보자 그에 대한 그녀의 모든 관념은 산산히 깨어졌다."
    x "**(이게 진짜 니가 맞는거니?...)**"
    x "**(..............)**"
    x "**(니 얼굴과 너무나도 매치가 안되잖아..)**"
    n "[d_name]은 그녀에게 더이상 제이슨과 말장난을 하던 소년이 아니었다."
    scene ch04_hstudio01_03 at hand_camera with Dissolve(0.8)
    h "**(맙소사....)**"
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch04_hstudio01_04 at hand_camera with Dissolve(0.8)
    x "**(이 녀석은 부끄럽지도 않은건가?)**"
    x "**(인지 부조화, 스키마 불일치..., 기대 위반....)**"
    x "**(......)**"
    scene ch04_hstudio01_04-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "조....좋아요!"
    h "지금 분위기 정말 뜨겁네요."
    h "지금 분위기를 가지고 계속 진행 해볼게요!"
    h "남자친구의 발기를 본 여자친구의 눈빛으로 바라보세요!!"
    scene ch04_hstudio01_05 at hand_camera with Dissolve(0.8)
    h "좋아요! 지금 표정 정말 좋아요."
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    x "..............."
    x "**(지금 내 표정이 어떻지?)**"
    x "**(.........)**"
    x "**(남성의 성기를 이렇게 가까이서 보는게 얼마만이지?....)**"
    stop sound
    scene ch04_hstudio01_06 at hand_camera with Dissolve(0.8)
    h "크흠..."
    h "마담."
    h "이제 그의 성기를 잡아 주세요."
    d "**(!!!!!)**"
    scene ch04_hstudio01_07 at hand_camera with Dissolve(0.8)
    h "어 그러니까...."
    h "블로우잡을 표현할거니까 그의 성기 아래 쪽을 잡아주세요."
    scene ch04_hstudio01_07-02 at hand_camera with Dissolve(0.8)
    x "**(..............)**"
    scene ch04_hstudio01_07-03 at hand_camera with Dissolve(0.8)
    x "**(........)**"
    scene ch04_hstudio01_08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    d "읏......."
    scene ch04_hstudio01_09 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(젠장....)**"
    d "**(그녀의 손이 너무 기분좋아....)**"
    d "**(부드럽다...)**"
    stop sound
    scene ch04_hstudio01_10 at hand_camera with Dissolve(0.8)
    h "좋아요 마담."
    h "이제 둘이 연인이라 생각하고 그의 성기를 만지다가 오랄섹스를 하는 과정을 흉내내는거에요."
    h "다시 말할게요."
    h "마담과 [d_name]은 서로의 몸을 탐하는 연인이에요."
    h "지금 여기엔 마담과 [d_name]만 있는거에요!"
    scene ch04_hstudio01_11 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch04_hstudio01_12 at hand_camera with Dissolve(0.8)
    x "**(..........)**"
    scene ch04_hstudio01_13 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch04_hstudio01_14 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch04_hstudio01_15 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    d "**(젠장!!)**"
    d "**(그녀의 입김이 다 느껴져....하...)**"
    scene ch04_hstudio01_16 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter02.mp3" volume 0.4 loop
    n "[d_name]의 고추로 그녀의 입김이 전해졌다."
    n "그는 자신의 고추로 그녀의 호흡을 그대로 느낄 수 있었다."
    n "그낌은 메리의 입안을 떠올리게해 그는 참을 수 없는 흥분에 휩쌓였다."
    scene ch04_hstudio01_17 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    scene ch04_hstudio01_18 at hand_camera with Dissolve(0.8)
    h "좋아요."
    h "[d_name]이 마담의 머리를 잡아주세요."
    scene ch04_hstudio01_19 at hand_camera with Dissolve(0.8)
    h "좋아요."
    n "찰칵!"
    scene ch04_hstudio01_20 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_21 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "이 촬영은 연기였지만 소피아에겐 일종의 자기 만족이었다."
    n "그것은 그녀의 나르시즘이 견고해지는 결과를 낳았다."
    n "그 이유는 그녀는 [d_name]의 단단한 발기의 원인이 그녀 자신이라는데 일종의 기쁨을 느꼈다."
    d "**(이건 고문이야.....)**"
    d "**(남자에게 이건 고문이라고...)**"
    scene ch04_hstudio01_22 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "때문에 그녀의 열정적인 오랄섹스 연기는,"
    n "자신에게 발기한 젊은 남성의 성기에 대한 일종의 보상이었다."
    scene ch04_hstudio01_23 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(혼란스럽다....혼란스러워...)**"
    x "**(여기서 뭐하고 있는거니 소피아?)**"
    x "**(............)**"
    x "**(대체 이렇게 음란한 연기를 하고 있는 이유가 뭐니?.....)**"
    scene ch04_hstudio01_24 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋습니다."
    stop sound
    scene ch04_hstudio01_25 at hand_camera with Dissolve(0.8)
    h "저 마담."
    h "그의 성기를 치켜 세우고 그 고....."
    h ".........."
    h "그의 고환을 핥는 연기를 해주세요."
    scene ch04_hstudio01_26 at hand_camera with Dissolve(0.8)
    d "**(쉣.....)**"
    x "..............."
    x "**(진짜?)**"
    x "**(와우 [h_name]....)**"
    x "**(이런 것들 기획하는데 능숙하네요...)**"
    scene ch04_hstudio01_27 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    scene ch04_hstudio01_28 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(흐응...)**"
    scene ch04_hstudio01_29 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_30 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "............."
    x "**(맙소사..)**"
    x "**(그의 체취가 다 느껴져.....)**"
    scene ch04_hstudio01_31 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_32 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_33 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(그래요 마담!!)**"
    d "**(하.......)**"
    d "**(조금만 실제로 해주세요......)**"
    h "좋아요."
    scene ch04_hstudio01_33-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_34 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(아!!!!!)**"
    d "윽....."
    scene ch04_hstudio01_35 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_36 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    x "**(혀가 닿아 버렸다..)**"
    scene ch04_hstudio01_37 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(바로 그거에요 마담!!)**"
    pause
    d "**(간지러워!!)**"
    scene ch04_hstudio01_34 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    scene ch04_hstudio01_38 at hand_camera with Dissolve(0.8)
    h "괜찮아요 [d_name]?"
    h "자세가 불편하거나 그러진 않아요?"
    scene ch04_hstudio01_39 at hand_camera with Dissolve(0.8)
    d "넵 괜찮습니다!"
    d "아주 좋습니다!"
    scene ch04_hstudio01_40 at hand_camera with Dissolve(0.8)
    h "좋아요."
    h "이제 둘다 일어서서 서로 바라보세요."
    h "오랄섹스를 마치고 일어서서 서로를 바라보는 장면이에요."
    scene ch04_hstudio01_41 at hand_camera with Dissolve(1.5)
    h "마담이 [d_name]의 젖꼭지를 입으로 애무하는 모션을 해주세요."
    h "너무 연기가 많으면 전체적으로 어색해져서요...이해 부탁할게요."
    h "이제 상체는 두 사람이 괜찮으면 약한 수준으로 진짜 애무해주세요."
    h "거부감이 들면 두 사람 모두 손으로 표시하면 상대는 멈춰주세요."
    h "이제 저도 가급적이면 말을 안할게요."
    d "넵 알겠습니다!"
    scene ch04_hstudio01_41-02 at hand_camera with Dissolve(0.8)
    x "**(뭐라고?)**"
    x "**(방금 [h_name]이 뭐라고 했지?)**"
    x "**(.........)**"
    x "**([d_name]의 젖꼭지를 빨으라고 했나?)**"
    x "**(.........)**"
    x "**(아닌가? 흉내만 내라고 했나?)**"
    scene ch04_hstudio01_42 at hand_camera with Dissolve(0.8)
    h "좋아요."
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    scene ch04_hstudio01_43 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_44 at hand_camera with Dissolve(0.8)
    d "읏..."
    n "찰칵!"
    scene ch04_hstudio01_45 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(후......)**"
    x "**(좋아........)**"
    x "**(별거아냐. 그냥 단지 연기일 뿐이야.)**"
    x "**(여교수가 그의 제자의 젖꼭지를 빠는게 아니라고.)**"
    x "**(그냥 단지 연기일 뿐이야..........)**"
    scene ch04_hstudio01_46 at hand_camera with Dissolve(0.8)
    n "쪽"
    d "**(쉣!!)**"
    d "**(마담............)**"
    scene ch04_hstudio01_46-02 at hand_camera with Dissolve(0.8)
    d "**(아윽....)**"
    image ch04_hstudio01_nipple01:
        "ch04_hstudio01_46" with dissolve
        0.8
        "ch04_hstudio01_46-02" with dissolve
        0.8
        repeat
    scene ch04_hstudio01_nipple01 at hand_camera
    pause
    scene ch04_hstudio01_47 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(아 마담............)**"
    scene ch04_hstudio01_48 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_48-01 at hand_camera with Dissolve(0.8)
    d "**(젠장......)**"
    d "**(촬영이고 나발이고 그녀랑 섹스하고 싶다!!!!)**"
    d "**(..........)**"
    d "**(이대로 가면 할 수 있지 않을까?)**"
    n "찰칵!"
    scene ch04_hstudio01_48-02 at hand_camera with Dissolve(0.8)
    d "**(젠장......)**"
    x "**(!!!!!!!!!!!!)**"
    n "찰칵!"
    scene ch04_hstudio01_48-04 at hand_camera with Dissolve(0.8)
    x "**(아흥...)**"
    n "찰칵!"
    scene ch04_hstudio01_48-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_48-05-02 at hand_camera with Dissolve(0.8)
    d "**(젠장 넣고 싶다!!!!)**"
    n "찰칵!"
    x "**(흐응...)**"
    scene ch04_hstudio01_48-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_48-07 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(맙소사.....)**"
    x "**(그의 고추가 뜨거워...)**"
    x "**(...........)**"
    x "**(나의 몸 때문에 이렇게 뜨거워진거니?)**"
    scene ch04_hstudio01_48-08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_48-09 at hand_camera with Dissolve(0.8)
    d "**(당신을 먹고 싶어요 마담!!)**"
    d "**(같이 하지 않을래요?....)**"
    n "찰칵!"
    d "**(이런 분위기면 [h_name]도 이해하지 않을까요?)**"
    scene ch04_hstudio01_48-10 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(하........)**"
    d "**(진짜 넣고 싶다....)**"
    scene ch04_hstudio01_48-11 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(아......)**"
    scene ch04_hstudio01_49 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_50 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(그녀도 했으니까 나도 해도 되겠지??)**"
    menu:
        n "What should I do?"
        "그녀의 젖꼭지를 입에 넣는다.":
            scene ch04_hstudio01_51 at hand_camera with Dissolve(0.8)
            x "**(아!!!!!!)**"
            d "**(당신을 먹어치워 줄게요!!)**"
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    n "찰칵!"
    scene ch04_hstudio01_52 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "흐응.."
    x ".........."
    x "**(아!!)**"
    x "**(이 녀석아! 입속에서 혀를 그렇게 움직이지마!!)**"
    x "아흥...."
    image ch04_hstudio01_nipple02:
        "ch04_hstudio01_51" with dissolve
        0.65
        "ch04_hstudio01_52" with dissolve
        0.65
        repeat
    scene ch04_hstudio01_nipple02 at hand_camera
    pause
    scene ch04_hstudio01_53 at hand_camera with Dissolve(0.8)
    x "하..아흥..."
    h "**(마이갓.....)**"
    n "찰칵!"
    scene ch04_hstudio01_nipple02 at hand_camera
    pause
    scene ch04_hstudio01_54 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(이건 뭔가 잘못된거 같아!!)**"
    if not in_replay:
        $ add_point("sus_sophia", 1, "sus_sophia")
    x "**(이건 더 이상 연기가 아닌거 같아.)**"
    x "**(이건 이 녀석과 진짜 하는거 잖아!!)**"
    scene ch04_hstudio01_54-02 at hand_camera with Dissolve(0.8)
    x "아흥......"
    n "찰칵!"
    stop sound
    h "아.. [d_name]..그건 약간 너무 간거 같아요."
    scene ch04_hstudio01_55 at hand_camera with Dissolve(0.8)
    x "**(그만!!!)**"
    d "**(쉣!)**"
    scene ch04_hstudio01_56 at hand_camera with Dissolve(1.3)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    d "아.... 미안합니다."
    h "두 사람 모두 좋았어요!!"
    h "잠시만요."
    scene ch04_hstudio01_58 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    h "퓨........."
    h "..........."
    h "에.....다음은......"
    scene ch04_hstudio01_59 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_60 at hand_camera with Dissolve(0.8)
    x "**(이 못된 녀석 같으니!!)**"
    x "**(.............)**"
    x "**(이 녀석 날 알아보고도 지금 모른체 하는걸까?...)**"
    x "**(........)**"
    x "**(그 순진한 얼굴속에 음흉한 모습을 감추고 있었구나.)**"
    scene ch04_hstudio01_60-02 at hand_camera with Dissolve(0.8)
    x "**(.............)**"
    x "**(젠장......)**"
    scene ch04_hstudio01_61 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_61-02 at hand_camera with Dissolve(0.8)
    h "아....이제 마지막 파트에요."
    h "............."
    scene ch04_hstudio01_62 at hand_camera with Dissolve(0.8)
    h "자 이제 소파에서 좀 편하게 찍을게요 헤헤."
    h "더운데 두 사람 모두 고생이 많네요."
    h "미안하지만 잠시 소파좀 같이 옮길까요?"
    jump ch04_hstudio02

label ch04_hstudio02:
    if not in_replay:
        $ persistent.unlock_ch04_hstudio02 = True
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hstudio03_00 with Dissolve(2.0)
    pause
    stop sound
    scene ch04_hstudio01_63-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_63-03 at hand_camera with Dissolve(1.1)
    x "**(......)**"
    x "**(어떻게 계속 저렇게 발기해 있는거지??)**"
    scene ch04_hstudio01_63-04 at hand_camera with Dissolve(1.1)
    pause
    scene ch04_hstudio01_63-05 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    h "............."
    scene ch04_hstudio01_63-06 at hand_camera with Dissolve(0.8)
    h "이런 것 까지 시켜서 미안해요."
    h "갑작스럽게 하게 돼서 준비가 안돼있어요.."
    d "하하 괜찮습니다."
    scene ch04_hstudio01_63-07 at hand_camera with Dissolve(0.8)
    h "전엔 완벽하게 모든 물품들이 다 준비 돼 있었는데..."
    h "하하.. 없으니까 아쉽네요."
    d "아 그랬었어요??"
    h "네 ㅎㅎ 뭐 자랑은 아니지만.."
    scene ch04_hstudio01_63-08 at hand_camera with Dissolve(0.8)
    h "일도 이렇게 됐으니...."
    h "한 가지 비밀을 알려주자면..."
    h "............"
    h "저의 스튜디오는 성인을 위한 스튜디오였답니다 하하."
    h "살색과 교성이 난무하는......"
    d ".............."
    scene ch04_hstudio01_63-09 at hand_camera with Dissolve(0.8)
    h "누군가 알면 안되는 조금 더 은밀하고 적극적인 성인들을 위한 공간이랄까......"
    h "남녀의 살결이 부딪히고, 신음소리와 카메라 셔터음이 시끄럽게 뒤섞이던 장소였어요...."
    h "옷을 입고 있는게 부자연스러운 장소."
    d "**(젠장....)**"
    scene ch04_hstudio01_63-10 at hand_camera with Dissolve(0.8)
    h "남자들은 성기를 덜렁 거리며 돌아다니고..."
    h "여자들은 자신의 은밀한 곳을 활짝 열어 보여주던......"
    d "**(맙소사.....)**"
    d "**(그녀는 무슨 일을 했던거지??)**"
    d "**(여기서 야동이라도 찍었던건가??)**"
    x "**(하하하 [h_name]...)**"
    x "**(어린 애를 그렇게 놀리면 어떡해요 하하하.)**"
    scene ch04_hstudio01_63-11 at hand_camera with Dissolve(0.8)
    h "자 얼추 레퍼런스와 비슷하게 세팅 됐네요."
    h "흠......"
    scene ch04_hstudio01_63-12 at hand_camera with Dissolve(0.8)
    h "자 이제 마지막 하이라이트 씬 촬영할게요."
    h "앞서 애무 부분을 완료 했으니 이젠 섹스씬이에요."
    h "[d_name]은 소파에 앉고 마담은 옆에 서서 포즈를 취해주세요."
    scene ch04_hstudio01_64 at hand_camera with Dissolve(0.8)
    d "넵 알겠습니다!"
    scene ch04_hstudio01_64-01 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/normal08.mp3" volume 1.5
    scene ch04_hstudio01_64-02 at hand_camera with Dissolve(2.0)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    h "네 지금 구도 좋아요."
    scene ch04_hstudio01_64-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_64-04 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "마담은 일어서고 [d_name]이 마담을 팔로 안아주세요."
    scene ch04_hstudio01_64-05 at hand_camera with Dissolve(1.2)
    n "찰칵!"
    scene ch04_hstudio01_64-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "네 좋아요."
    h "이렇게나 둘이 잘 어울린다니 놀랍네요!"
    h "역시 나이차이는 숫자에 불과하네요!"
    d "**(맞아요 [h_name]!!)**"
    d "**(그러니 이 마담과 섹스하게 해주세요!!!)**"
    d "**(제발.....)**"
    h "마담이 뒤돌아 볼래요?"
    scene ch04_hstudio01_64-07 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "네 좋아요."
    scene ch04_hstudio01_64-08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋아요. 이제 그녀의 팬티를 벗겨 주세요."
    h "팬티를 한번에 벗기지 말고 단계별로 동작을 끊어주세요."
    scene ch04_hstudio01_64-09 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(후.......)**"
    n "그가 소피아의 팬티를 잡았을 때 그녀는 묘한 흥분을 느꼈다."
    n "대학교수와 그녀의 제자라는 관계에서 지위가 역전 될 가능성은 제로에 가까웠지만,"
    n "촬영이라는 행위에서, 제3자에게 통제되어 그녀의 제자에게 자신을 알몸을 보여주며,"
    n "그리고 자신의 속옷이 벗겨지는 행위를 당하며 그녀는 표현하기 힘든 굴욕과 쾌감을 느꼈다."
    scene ch04_hstudio01_64-10 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    n "그것은 마치 팬티와 함께 그녀의 윤리적 부담감이 벗겨지는 느낌이었다."
    x "**(하아.......)**"
    x "**([h_name]만이 보고 있을 뿐인데 왜 이렇게 흥분되고 부끄러운거지?)**"
    n "찰칵!"
    stop sound
    h "네 이제 마담이 그의 무릎에 앉아주세요."
    scene ch04_hstudio01_65 at hand_camera with Dissolve(1.2)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    scene ch04_hstudio01_65-01 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_65-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(젠장..)**"
    scene ch04_hstudio01_65-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "노파심에 말하지만 절대 진짜로 삽입하지 마세요 하하하."
    x "**(..........)**"
    h "................"
    h "미안해요. 하면 안되는 농담이었어요."
    d "**(노노노!!)**"
    d "**(삽입해도 됩니다!!!)**"
    scene ch04_hstudio01_65-04 at hand_camera with Dissolve(0.8)
    x "**(.........)**"
    n "찰칵!"
    scene ch04_hstudio01_66 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(후..........)**"
    x "**(그의 고추는 왜 계속 움직이는거지.......)**"
    scene ch04_hstudio01_68 at hand_camera with Dissolve(0.8)
    stop sound
    h "좋아요."
    h "마담은 그에게 몸을 완전히 맡기세요."
    h "그리고 [d_name]은 너의 성기를 그녀의 엉덩이 앞으로 위치해주세요."
    scene ch04_hstudio01_69 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch04_hstudio01_70 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "좋아요."
    h "마담 고개를 돌려서 카메라를 바라보세요."
    scene ch04_hstudio01_71 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    h "좋아요."
    h "이건 정말 야하네요."
    h "아름다운 커플이에요."
    stop sound
    h "자 이제 [d_name]은 편하게 누워요."
    h "그리고 마담은 그에게 안겨서 엉덩이를 좀 들어볼래요?"
    scene ch04_hstudio01_71-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    scene ch04_hstudio01_71-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_71-03-02 at hand_camera with Dissolve(0.8)
    h "**(마이갓......)**"
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    pause
    h "**(이 장면 진짜 야하네.....)**"
    scene ch04_hstudio01_71-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    h "**(저게 마담에게 들어가면 어떨까........)**"
    h "**(.......)**"
    h "**(............)**"
    h "**(어떤 느낌일까....)**"
    scene ch04_hstudio01_71-04 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    h "이제 자연스럽게 삽입 직전까지의 과정을 연기해주세요."
    h "말 그대로 넣기 직전까지의 과정이에요."
    h "........."
    scene ch04_hstudio01_71-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(하.......)**"
    x "**(소피아 이 한심한 여자야...)**"
    x "**(이렇게 추한 동작을 하면서 뭐하는거야...)**"
    x "**(하........)**"
    x "**(방학중에 이 녀석과 이러고 있을 줄 누가 예상이나 했을까..)**"
    scene ch04_hstudio01_71-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(흐응....)**"
    x "**(.....)**"
    x "**(이 녀석 품에 안기는게 왜 이렇게 흥분되지......)**"
    x "**(이 녀석이 나 때문에 이렇게 발기한거야?)**"
    x "**(.....)**"
    x "**(이 꼬마녀석이 자기 보다 30살은 많은 날 보고 발기한거라고.)**"
    scene ch04_hstudio01_71-07 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_71-08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(아흥.....)**"
    scene ch04_hstudio01_71-09 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(이건 일어나선 안되는 일이었어.....)**"
    x "**(어떻게 나의 제자인 니 놈이 감히 내게 이런 짓을..)**"
    x "**(이 한심한 녀석 같으니!!)**"
    scene ch04_hstudio01_71-10 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(젠장 넣고싶다!!)**"
    d "**(.....)**"
    d "**(은근슬쩍 귀두만 넣어볼까???)**"
    d "**(.....)**"
    menu:
        n "What should I do?"
        "그녀의 질에 귀두를 삽입한다.":
            scene ch04_hstudio01_71-11 at hand_camera with Dissolve(0.8)
            x "**(!!!!!!!!!!!!!!!!!!!!!!!!!!!!)**"
            if not in_replay:
                $ add_point("lust_sophia", 1, "lust_sophia")
            n "찰칵!"
    stop sound
    h "아...[d_name]."
    h "그......."
    h "거기가 한계에요 알았죠?"
    h "조금만 조심해주세요."
    h "절대 더 밀면 안돼요!!"
    d "아 알겠습니다!"
    image ch04_hstudio01_grind01:
        "ch04_hstudio01_71-10" with dissolve
        0.8
        "ch04_hstudio01_71-11" with dissolve
        0.8
        repeat
    scene ch04_hstudio01_grind01 at hand_camera
    pause
    scene ch04_hstudio01_72 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    x "**(하.......)**"
    x "**(우리 모두 무슨 일을 하고 있는 거지?.....)**"
    x "**(.............)**"
    x "**(난 왜 그에게 맞춰서 엉덩이를 추잡스럽게 움직이고 있는거지?)**"
    scene ch04_hstudio01_grind01 at hand_camera
    d "**(쉣....)**"
    d "**(그녀도 나에게 맞춰서 움직이고 있어...)**"
    scene ch04_hstudio01_72-01 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_72-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(......)**"
    d "**(마이갓......)**"
    d "**(하.....넣고 싶다..넣고 싶다...)**"
    d "**(딱 한 번만 넣었다 빼도 되냐고 물어볼까?)**"
    d "**(그 정도는 이 여자들이 허락하지 않을까?)**"
    stop sound
    h "환상적이에요!!"
    h "두 사람 모두 잠깐만요!!"
    scene ch04_hstudio01_72-03 at hand_camera with Dissolve(0.8)
    h "자 이제 마지막 씬이에요."
    h "............."
    h "음......."
    h "소피아가 소파에 눕고 [d_name]은 서서 그녀의 발목을 잡으세요."
    d "**(쉣........)**"
    d "아..알겠습니다!"
    scene ch04_hstudio01_72-04 at hand_camera with Dissolve(1.3)
    x "퓨......"
    scene ch04_hstudio01_73 at hand_camera with Dissolve(2.0)
    x ".............."
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    scene ch04_hstudio01_74 at hand_camera with Dissolve(0.8)
    d "**(아 젠장....차라리 자위를 하고싶다...)**"
    d "**(이건 고문이다 고문!!)**"
    d "**(.............)**"
    d "**(그녀를 봐...)**"
    d "**(그녀도 내가 넣기를 바라는 자세잖아.)**"
    d "**(.............)**"
    d "**(그녀의 나이라면 이미 촬영하면서 섹스한 경험이 많지 않을까?)**"
    scene ch04_hstudio01_75 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(이런 일을 하는 여자라면 혹시 성인 영화 배우도 하지 않을까?)**"
    d "**(.............)**"
    d "**(하...어떻게 설득하지??)**"
    d "**(..........)**"
    d "**(그냥 넣어버릴까?)**"
    scene ch04_hstudio01_76 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**([h_name]이 허락할까?)**"
    h "이제 그녀의 다리를 벌려주세요."
    scene ch04_hstudio01_78 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "하응.........."
    d "**(이것봐....)**"
    d "**(아무리 연출이라지만 그녀는 너무 무방비잖아....)**"
    d "**(.............)**"
    d "**(그녀도 실제 하고 싶은거야.)**"
    scene ch04_hstudio01_78-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(호...혹시 [h_name]도 내가 그냥 실제로 하길 바라는거 아닐까?)**"
    d "**(............)**"
    d "**(그럼 혹시 못이기듯 이해해주지 않을까???)**"
    d "**(하.....젠장!!!!)**"
    d "**(마지막 섹스가 언제였지?)**"
    scene ch04_hstudio01_79 at hand_camera with Dissolve(0.8)
    x "하응.........."
    x "**(나의 자세를 봐.....)**"
    pause
    x "**(누가 날 대학교 교수라고 생각할까..)**"
    n "찰칵!"
    scene ch04_hstudio01_80 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(하..........)**"
    x "**(마지막 섹스가 언제였지?.....)**"
    x "**(............)**"
    x "**(맙소사 소피아.....)**"
    x "**(나 섹스리스로 살았던건가....)**"
    scene ch04_hstudio01_80-02 at hand_camera with Dissolve(0.8)
    d "**(맙소사....)**"
    d "**(그녀는 느끼고 있어..)**"
    n "찰칵!"
    scene ch04_hstudio01_80-03 at hand_camera with Dissolve(0.8)
    d "**(그냥 이러고 있는 것 만으로 찌릿찌릿하네....)**"
    d "**(하........)**"
    d "**(넣고싶다!! 넣고싶다!! 넣고싶다!!)**"
    d "**(.............)**"
    d "**(좋아 실수인척 넣는 거야.)**"
    d "**(뒤는 나중에 생각하는거야!!)**"
    scene ch04_hstudio01_81 at hand_camera with Dissolve(0.8)
    stop sound
    h "이제 [d_name]은 그녀에게 더 가까이 가주세요."
    h "그리고 삽입을 하 듯 [d_name]의 허리를 앞뒤로 움직여 주세요."
    scene ch04_hstudio01_82 at hand_camera with Dissolve(0.8)
    d "아..알겠어요."
    scene ch04_hstudio01_83 at hand_camera with Dissolve(1.2)
    x "하......."
    play sound "audio/ambi/shutter01.mp3" volume 0.5 loop
    n "찰칵!"
    d "**(아 시발 아닌가?)**"
    d "**(그건 대형사고 인가??)**"
    d "**(내 맘대로 넣었다가 체포되는거 아냐??)**"
    scene ch04_hstudio01_84 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "!!!!!!!!!"
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    n "시작은 연기였지만 그녀의 머리속은 이미 [d_name]에 의해 휘져어졌다."
    scene ch04_hstudio01_85 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "[h_name]에 의해 통제된 환경에서 그녀는 [d_name]의 어떤 행동에도 반응하지 못했다."
    x "**(맙소사 [h_name]!!)**"
    x "**(난 촬영이 이정도 수위인지 몰랐다고....)**"
    x "**(오 [h_name]......)**"
    scene ch04_hstudio01_86 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "**(느껴진다!! 그껴진다고.....)**"
    d "**(미끌미끌해....)**"
    d "**(쉣!!)**"
    scene ch04_hstudio01_86-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(맙소사 [d_name].....)**"
    x "**(오 디어.....)**"
    x "**(너 느끼고 있는거야?)**"
    if not in_replay:
        $ add_point("love_sophia", 1, "love_sophia")
    x "**(너의 교수님에게 비비면서 느끼는거냐고!!)**"
    x "**(불과 얼마전에 난 널 가르치고 있었어 이 녀석아..)**"
    scene ch04_hstudio01_87 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_86 at hand_camera with Dissolve(0.8)
    d "**(아 미치겠다.......)**"
    d "**(이건 시발 나에겐 고문이야.....)**"
    menu:
        n "What should I do?"
        "그녀의 보지에 귀두를 비빈다.":
            scene ch04_hstudio01_91 at hand_camera with Dissolve(0.8)
            n "찰칵!"
            x "!!!!!!!!!"
    scene ch04_hstudio01_91 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch04_hstudio01_92 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "흐응...."
    scene ch04_hstudio01_93 at hand_camera with Dissolve(0.8)
    x "아........"
    h "!!!!!!!!!!!!!!!!"
    scene ch04_hstudio01_94 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    scene ch04_hstudio01_95 at hand_camera with Dissolve(0.8)
    h ".........."
    x "**(맙소사 [h_name]....)**"
    x "**(이렇게 해도 말리지 않는거야??)**"
    x "**(너 뭐하고 있어?!!)**"
    image ch04_hstudio01_grind02:
        "ch04_hstudio01_91" with dissolve
        0.5
        "ch04_hstudio01_92" with dissolve
        0.5
        "ch04_hstudio01_93" with dissolve
        1.0
        "ch04_hstudio01_94" with dissolve
        1.3
        repeat
    scene ch04_hstudio01_grind02 at hand_camera
    pause
    scene ch04_hstudio01_101 at hand_camera with Dissolve(0.8)
    d "**(아.............)**"
    scene ch04_hstudio01_95 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "**(카메라가 왜 이러지?)**"
    image ch04_hstudio01_grind02-02:
        "ch04_hstudio01_91" with dissolve
        0.3
        "ch04_hstudio01_92" with dissolve
        0.3
        "ch04_hstudio01_93" with dissolve
        0.7
        "ch04_hstudio01_94" with dissolve
        0.7
        repeat
    scene ch04_hstudio01_grind02-02 at hand_camera
    n "그는 마지막 이성의 끈을 붙잡고 갈등했다."
    pause
    n "그녀의 입구에 연신 성기를 비비면서 눈치를 살폈다."
    scene ch04_hstudio01_95 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter03.mp3"
    h "**(또 SD카드가 말썽인가?)**"
    n "그녀 자신의 제자에게 성기가 비벼지면서 그녀의 굴욕감은 절정에 올랐다."
    scene ch04_hstudio01_104 at hand_camera with Dissolve(0.8)
    x "**(하........)**"
    x "**(뭐가 뭔지 모르겠어.......)**"
    x "**(최면에 걸린건가......)**"
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    image ch04_hstudio01_grind03:
        "ch04_hstudio01_102" with dissolve
        0.5
        "ch04_hstudio01_103" with dissolve
        0.5
        "ch04_hstudio01_104" with dissolve
        0.5
        "ch04_hstudio01_103" with dissolve
        0.5
        "ch04_hstudio01_102" with dissolve
        0.5
        repeat
    scene ch04_hstudio01_grind03 at hand_camera with Dissolve(0.8)
    n "그것은 그녀 인생에서 최초의 경험이었다."
    scene ch04_hstudio01_103 at hand_camera with Dissolve(0.8)
    x "**(하........)**"
    x "**(맙소사 [d_name].....)**"
    x "**(지금 뭘하려는거니...)**"
    n "그녀의 인생에서 몇 몇의 남성과 섹스를 했지만,"
    n "그녀의 아들 보다도 어린 남성과 서로의 성기를 비비는 행위는 처음이었다."
    scene ch04_hstudio01_grind03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_108 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "조..좋았어요 [d_name]."
    h "........"
    h "아 두 사람 잠깐만요."
    scene ch04_hstudio01_108-02 at hand_camera with Dissolve(0.8)
    h "..........."
    h "카메라가 좀 이상한데 잠깐 쉬고 있을래요?"
    h "미안해요..."
    scene ch04_hstudio01_109 at hand_camera with Dissolve(0.8)
    n "소피아와 [d_name]모두 방금 [h_name]이 한 말을 들었다."
    n "하지만 [d_name]은 그녀의 말에 따를 수 없을만큼 흥분돼 있었다."
    d "하아....."
    x "흐응...."
    scene ch04_hstudio01_109-02 at hand_camera with Dissolve(0.8)
    menu:
        n "What should I do?"
        "그녀의 보지에 삽입한다.":
            scene ch04_hstudio01_110 at hand_camera with Dissolve(0.8)
            x "**(.........)**"
            x "**(뭐야? 점점 밀고들어오는데?....)**"
            pause
            x "**(뭐?!!!!!!!)**"
    scene ch04_hstudio01_111 at hand_camera with Dissolve(0.8)
    x "**(이 녀석 지금 진짜 넣으려하나??!!!!!)**"
    x "**(맞네!! 점점 밀고 들어오잖아!!!)**"
    scene ch04_hstudio01_110 at hand_camera with Dissolve(0.8)
    pause   
    play sound "audio/sex/liquid01.mp3"
    scene ch04_hstudio01_112 at hand_camera with Dissolve(0.8)
    x "!!!!!!!!!!"
    scene ch04_hstudio01_112-02 at hand_camera with Dissolve(0.8)
    x "앗 잠깐만!!!!!"
    scene ch04_hstudio01_112 at hand_camera with Dissolve(0.8)
    x "!!!!!!!!!!"
    d "아 젠장 들어간다!!!"
    x "뭐?!!!"
    play sound "audio/sex/liquid02.mp3"
    scene ch04_hstudio01_113 at hand_camera with Dissolve(0.8)
    x "헤이!!!"
    x "뭐하는거야?!!!!!"
    scene ch04_hstudio01_114 at hand_camera with Dissolve(0.4)
    d "아!!!!!!!!"
    scene ch04_hstudio01_112-03 at hand_camera with Dissolve(0.8)
    h "허?"
    play sound "audio/sex/cum01.mp3"
    scene ch04_hstudio01_116 at hand_camera with Dissolve(0.8)
    d "아!!!!!!!!!!"
    scene ch04_hstudio01_117 at hand_camera with Dissolve(0.8)
    h "!!!!!!!!!!!!!!!!!"
    scene ch04_hstudio01_114 at hand_camera with Dissolve(0.8)
    d "아.................."
    d "**(좆)**"
    d "**(좆됐)**"
    d "**(좆됐다........)**"
    play sound "audio/sex/cum01.mp3"
    scene ch04_hstudio01_118 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hstudio01_118-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_119 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_120 at hand_camera with Dissolve(1.3)
    pause
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
        $ add_point("sus_sophia", 1, "sus_sophia")
    scene ch04_hstudio01_121 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_122 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/voices/fgrunt01.wav"
    scene ch04_hstudio01_124 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_125 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hstudio01_126 at hand_camera with Dissolve(0.8)
    d "**(젠장...........)**"
    d "**(........)**"
    d "**(대체 난 무슨 짓을 저지른거냐....)**"
    scene ch04_hstudio01_127 at hand_camera with Dissolve(0.8)
    h "......."
    scene ch04_hstudio01_128 at hand_camera with Dissolve(0.8)
    d "미안합니다...."
    scene ch04_hstudio01_129 at hand_camera with Dissolve(0.8)
    h "아니에요."
    h "괜찮아요....."
    scene ch04_hstudio01_130 at hand_camera with Dissolve(0.8)
    h "미안해요 마담.."
    h "괜찮아요?"
    scene ch04_hstudio01_131 at hand_camera with Dissolve(0.8)
    x "난 괜찮아요."
    scene ch04_hstudio01_132 at hand_camera with Dissolve(0.8)
    x "너의 남자 친구나 챙겨주세요 하하하."
    scene ch04_hstudio01_133 at hand_camera with Dissolve(0.8)
    d "......................."
    d "미안합니다 마담....."
    d "미안해요 [h_name].."
    scene ch04_hstudio01_134 at hand_camera with Dissolve(0.8)
    h "괜찮아요."
    h "촬영 잘 마쳤으니 걱정하지 마요."
    scene ch04_hstudio01_135 at hand_camera with Dissolve(0.8)
    h "....................."
    scene ch04_hstudio01_136 at hand_camera with Dissolve(0.8)
    h "........"
    scene ch04_hstudio01_137 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!"
    scene ch04_hstudio01_138 at hand_camera with Dissolve(0.8)
    d "제가 닦을게요!!"
    h "앗 깜짝이야..."
    h "아..알겠어요."
    scene ch04_hstudio01_139 at hand_camera with Dissolve(0.8)
    x ".............."
    scene ch04_hstudio01_140 at hand_camera with Dissolve(1.2)
    x "**(마이갓......)**"
    x "**(왜 아직도 녀석의 고추가 서있는 거지?.......)**"
    h "**(.....................)**"
    h "**(맙소사 [d_name]....)**"
    scene ch04_hstudio01_141 at hand_camera with Dissolve(1.2)
    x "**(......................)**"
    h "**(.............)**"
    jump ch04_hcar01

label ch04_hcar01:
    if not in_replay:
        $ persistent.unlock_ch04_hcar01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal07.mp3" volume 1.5
    play sound "audio/ambi/city03.mp3" volume 1.2 loop
    scene ch04_hcar01 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hcar02 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hcar03 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hcar04 at hand_camera with Dissolve(1.2)
    n "[h_name]은 소피아와 전화를 하고 있었다."
    n "그녀는 소피아와의 은밀한 대화를 위하여 차의 핸즈프리를 이용하지 않았다."
    scene ch04_hcar05 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh02.mp3"
    h "하하하. 알겠어요 마담."
    h "그렇게 할게요. 아무튼 오늘 정말 고생 많았어요."
    h "......."
    h "................"
    h "제 남자친구에게도 그렇게 말 전해줄게요."
    scene ch04_hcar03 at hand_camera with Dissolve(0.8)
    d "**(남자친구??)**"
    d "**(.......)**"
    d "**(그녀가 남자친구가 있었나??)**"
    scene ch04_hcar06 at hand_camera with Dissolve(0.8)
    h "그래요."
    h "그럼 다음 주 주말에 내 집에서 저녁 같이 먹을까요?"
    h "............."
    h "하하 좋아요. 그럼 다음 주말에 봐요."
    h "또 통화해요."
    h "연락할게요."
    scene ch04_hcar03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hcar07 at hand_camera with Dissolve(1.3)
    d "그 저......."
    d "마담은 저 때문에 화나지 않았어요?"
    d "......."
    scene ch04_hcar08 at hand_camera with Dissolve(0.8)
    h "..............."
    h "그녀는 화나지 않았어요."
    h "다만 좀 놀랐을 뿐이에요."
    pause
    h "그녀는 나와 오랜기간 같이 일해온 프로 모델이라서 산전수전 다 겪었어요."
    h "아까 일은 전혀 개의치 않고 있어요."
    scene ch04_hcar08-02 at hand_camera with Dissolve(0.8)
    d "다행이네요..."
    d "퓨......."
    d "......."
    d "어떻게 그런 짓을 해버렸는지..."
    d "..........."
    d "전 구제불능인가봐요."
    scene ch04_hcar09 at hand_camera with Dissolve(0.8)
    h "................."
    scene ch04_hcar10 at hand_camera with Dissolve(0.8)
    h "오히려 내가 [d_name]과 마담에게 미안하네요.."
    h "................"
    h "애초에 내가 [d_name]군에게 무리한 부탁을 했던거에요....."
    h "맙소사 내가 무슨 짓을 벌인걸까요..."
    scene ch04_hcar07 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_hcar11 at hand_camera with Dissolve(0.8)
    h "내가 촬영하면서 컨트롤을 했어야 했는데....."
    h "나도 모르게 상황에 몰입돼서........."
    h "정신을 놓고 카메라 버튼만 누르고 있었네요..."
    scene ch04_hcar11-02 at hand_camera with Dissolve(0.8)
    d "............"
    d "아닙니다.."
    d "저는 바보였어요..."
    scene ch04_hcar12 at hand_camera with Dissolve(0.8)
    d ".............."
    d "그 순간에 사정을 하다니.......하....."
    d "그리고........"
    menu:
        "무슨 일이 있었는지 실토한다.":
            scene ch04_hcar08-02 at hand_camera with Dissolve(0.8)
            d "........."
            d "저 사실..."
            d "....."
            d "마담에게 삽입하려고 헀었어요......."
            scene ch04_hcar09 at hand_camera with Dissolve(0.8)
            h "................."
            scene ch04_hcar08-02 at hand_camera with Dissolve(0.8)
            d "있잖아요..."
            d "........"
            d "그녀의 성기에 비비면서 너무 흥분해서 그만....."
            d "............."
            d "잘못하면 그녀의 몸안에 사정할 뻔 했어요....."
            scene ch04_hcar10 at hand_camera with Dissolve(0.8)
            h ".................."
        "아무말도 하지 않는다.":

            d "......................"
    scene ch04_hcar13 at hand_camera with Dissolve(0.8)
    d "저......."
    d "병원을 가봐야 할까요?"
    scene ch04_hcar14 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fwhat01.mp3"
    h "뭐라고?!!"
    scene ch04_hcar15 at hand_camera with Dissolve(0.8)
    h "하하하. 병원이라니 당치도 않은 소리에요."
    h "왜 그런 말을 해요..."
    h "........"
    h "남자가 사정하는건 자연스러운건데 괜한 걱정하지 말아요."
    scene ch04_hcar16 at hand_camera with Dissolve(0.8)
    d "그럴까요?......"
    d "..........."
    d "아니.....그래도 사...삽입도 안했는데 어떻게 사정을......."
    h "..........."
    scene ch04_hcar17 at hand_camera with Dissolve(0.8)
    h "음......."
    h "그건..."
    h "꼭 삽입하지 않아도 사정은 할 수......"
    scene ch04_hcar17-02 at hand_camera with Dissolve(0.8)
    h "걱정하지 말아요."
    h "아마 심리적으로 긴장해서 그랬을거에요."
    scene ch04_hcar17-03 at hand_camera with Dissolve(0.8)
    h "그리고 그......."
    h "............."
    h "보통 남자는 어릴 땐 사정 조절이 잘 되지 않을 수 있다고 들었어요."
    h "그 왜...."
    h "어릴 땐 모든 감각들이 신선하다고 할까......"
    h "............."
    h "신경쓰지 말아요.."
    scene ch04_hcar17-04 at hand_camera with Dissolve(0.8)
    d "..................."
    d "실은 제 여자친구와 첫 경험 때도 그랬었거든요......."
    d "하........"
    d "랜드레이디는 모를거에요 이게 얼마나 남자에게 자괴감이 드는건지...."
    scene ch04_hcar18 at hand_camera with Dissolve(0.8)
    h "..............."
    h "너는 좋은 조건을 갖췄으니 걱정 안해도 돼요."
    scene ch04_hcar19 at hand_camera with Dissolve(0.8)
    d ".........."
    d "좋은 조건이요??"
    scene ch04_hcar17 at hand_camera with Dissolve(0.8)
    h "아...그러니까...."
    h "그 말은..."
    h "**(흐음.......)**"
    h "**(정말 몰라서 묻는건가?.....)**"
    scene ch04_hcar21 at hand_camera with Dissolve(2.0)
    h "충분히 건강하니까 경험만 쌓이면 최고의 남자가 될 수 있을거에요 헤헤."
    h "아....그게 그러니까 억지로 경험을 쌓으라는건 아니고요."
    scene ch04_hcar22 at hand_camera with Dissolve(0.8)
    h "................"
    h "무슨 말인지 알죠?"
    h "내 말은 자괴감 들 필욘 없다는 거에요."
    scene ch04_hcar23 at hand_camera with Dissolve(0.8)
    d "그렇게 얘기해줘서 감사합니다."
    d "...................."
    d "사실 전....."
    scene ch04_hcar24 at hand_camera with Dissolve(0.8)
    d "그다지 경험이 많지 않습니다..."
    d "..............."
    d "지난번에 식사하면서 얘기 했었지만...."
    scene ch04_hcar25 at hand_camera with Dissolve(0.8)
    d "전 일반적이지 않은 성적인 취향이 있어요."
    scene ch04_hcar22 at hand_camera with Dissolve(0.8)
    h "일반적이지 않다는게 무슨 말이에요?"
    h "......"
    scene ch04_hcar25 at hand_camera with Dissolve(0.8)
    d "......."
    d "전 저보다 나이가 많은 여자가 좋습니다.."
    scene ch04_hcar26 at hand_camera with Dissolve(0.8)
    h "................"
    menu:
        "[h_name]의 나이대 여성이 좋아요.....":
            d "[h_name]의 나이대 여성이 좋아요....."
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
                $ add_point("love_helen", 1, "love_helen")
            pause    
        "중년의 여성이 좋아요.":
            d "중년의 여성이 좋아요."
    scene ch04_hcar27 at hand_camera with Dissolve(2.0)
    h "..............."
    d "그래서 대학교 생활 내내 제 또래 여성들과는 잘 지내지 못했어요..."
    d "뭐랄까..."
    d "어린애들 같다고 해야하나..."
    d "시끄럽게 깔깔거리고 몰려다니고 장난치고..."
    scene ch04_hcar26 at hand_camera with Dissolve(0.8)
    d "반면에 3,40대의 여교수들에게 눈길이 더 갔어요.."
    d "........"
    d "뭐 50대도 있었고요.."
    d "그러네요...."
    d "오늘 같이 촬영했던 마담과 같은 여자들이요..."
    d "저를 있는 그대로 받아들일 수 있을것 같은 느낌이 드는 여성들..."
    d "........"
    d "유치하지 않고 성숙한 여성들..."
    scene ch04_hcar27-02 at hand_camera with Dissolve(1.2)
    d "아니 정확히 말하면 제 또래 여성들도 좋긴 하지만...."
    d "뭐랄까......."
    d "아 모르겠습니다......"
    d "이거 뭐 여자면 다 좋다는 소리네요 하하하."
    d "표현을 잘 못하겠네요...."
    scene ch04_hcar28 at hand_camera with Dissolve(0.8)
    h "그랬군요...."
    h "당연히 그럴 수 있는데 왜 그렇게 시무룩해요? 하하."
    h "이제 대학교 1학년인데 너무 심각하게 걱정하진 말아요."
    scene ch04_hcar29 at hand_camera with Dissolve(0.8)
    h ".........."
    h "이 세상에 여자는 많아요."
    h "두루두루 만나다보면 [d_name]의 진짜 여자 취향을 알 수 있을거에요.."
    scene ch04_hcar30 at hand_camera with Dissolve(0.8)
    h "무분별하게 만나라는게 아니라 그러니까..."
    h "음....."
    scene ch04_hcar31 at hand_camera with Dissolve(0.8)
    h "앞으로 여자 만날 날들은 많이 남았으니 차차 자신을 알아가면 돼요 헤헤."
    scene ch04_hcar32 at hand_camera with Dissolve(0.8)
    d "......"
    d "그렇겠죠...."
    scene ch04_hcar33 at hand_camera with Dissolve(0.8)
    h "여기 있다간 피곤해서 잠들거 같네요."
    h "어서 집으로 가요."
    play sound "audio/ambi/carmoving01.mp3"
    scene ch04_hcar34 at hand_camera with Dissolve(2.0)
    pause
    jump ch04_hhouse01

label ch04_hhouse01:
    if not in_replay:
        $ persistent.unlock_ch04_hhouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    scene ch04_hhouse01 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/dooropen.mp3"
    scene ch04_hhouse02 at hand_camera with Dissolve(1.2)
    h "아 역시 집이 제일 좋아...."
    h "뭐 아직 절반은 은행 집이지만."
    scene ch04_hhouse03 at hand_camera with Dissolve(0.8)
    h "집에 백만년만에 돌아온거 같네요 하하."
    scene ch04_hhouse04 at hand_camera with Dissolve(2.0)
    play voice_f "audio/voices/fsigh01.mp3"
    h "아 편하다........."
    h "..........."
    h "저기 [d_name]....."
    d "네?"
    h "내 옷 좀 벗겨줄래요? 하하하."
    d "네??!!!"
    scene ch04_hhouse05 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "........."
    scene ch04_hhouse05-02 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch04_hhouse05-03 at hand_camera with Dissolve(2.0)
    h "너도 피곤할텐데 앉아요."
    scene ch04_hhouse05-04 at hand_camera with Dissolve(0.8)
    d "아 네.."
    scene ch04_hhouse05-05 at hand_camera with Dissolve(1.0)
    h "그렇게 서서 내 몸매를 감상하는거에요?"
    d "아 잠시 딴 생각좀하느라..."
    scene ch04_hhouse05-02 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch04_hhouse06 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse07 at hand_camera with Dissolve(0.8)
    n "둘 사이에 어색한 정적이 흘렀다."
    scene ch04_hhouse07-02 at hand_camera with Dissolve(0.8)
    n "확실히 그 둘은 어제 보다 더 가까워졌다."
    n "조금더 친근해 졌다."
    n "하지만 둘 사이의 어색함은 오히려 둘이 처음 만났던 날 보다 커졌다."
    scene ch04_hhouse08 at hand_camera with Dissolve(0.8)
    d "물 드릴까요?"
    scene ch04_hhouse08-02 at hand_camera with Dissolve(0.8)
    h "고마워요 헤헤."
    scene ch04_hhouse09 at hand_camera with Dissolve(1.5)
    n "그 이유는.."
    n "[h_name]이 그의 남성성을 느끼기 시작했기 때문이다."
    scene ch04_hhouse10 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse11 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse12 at hand_camera with Dissolve(1.1)
    n "그리고 처음으로 [d_name]에게 정서적으로 의지하기 시작했기 때문이다."
    scene ch04_hhouse13 at hand_camera with Dissolve(0.8)
    d "여기 물 마셔요."
    scene ch04_hhouse14 at hand_camera with Dissolve(1.2)
    if not in_replay:
        $ add_point("love_helen", 1, "love_helen")
    h "고마워요 헤헤."
    scene ch04_hhouse15 at hand_camera with Dissolve(0.8)
    d "피곤하실 텐데 편히 쉬세요."
    d "전 올라가서 쉴게요."
    scene ch04_hhouse16 at hand_camera with Dissolve(0.8)
    h "그럴래요?"
    h "그럼 편하게 쉬어요."
    scene ch04_hhouse17 at hand_camera with Dissolve(1.3)
    h "아 저 [d_name]."
    scene ch04_hhouse18 at hand_camera with Dissolve(0.5)
    d "네??"
    d "......."
    d "뭐 필요한거 있어요?"
    scene ch04_hhouse19 at hand_camera with Dissolve(0.8)
    h "..........."
    d "........"
    scene ch04_hhouse20 at hand_camera with Dissolve(0.8)
    h "저녁 식사는 [d_name]이 만들래요?"
    scene ch04_hhouse21 at hand_camera with Dissolve(0.8)
    d "네?"
    d "저녁 식사요??"
    h "네."
    h "[d_name]이 만든 음식을 먹고 싶은걸요? 헤헤."
    scene ch04_hhouse22 at hand_camera with Dissolve(0.8)
    d "하하하 그럴까요?"
    d "대신 우리 둘 사이가 영원히 멀어져도 전 모릅니다."
    scene ch04_hhouse23 at hand_camera with Dissolve(0.8)
    h "하하하하. 알겠어요."
    h "그럼 이따 같이 만들어요."
    scene ch04_hhouse23-02 at hand_camera with Dissolve(0.8)
    d "네 알겠습니다 하하하."
    d "제가 확실하게 방해해 드릴게요."
    scene ch04_hhouse24 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse25 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_hhouse26 at hand_camera with Dissolve(1.2)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3" volume 1.3
    scene ch04_hhouse27 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse28 at hand_camera with Dissolve(1.3)
    n "둘은 1층 주방에서 같이 저녁을 만들었다."
    pause
    n "그녀는 자신도 모르는 사이에 1층에서 머무는 시간이 길어졌다."
    scene ch04_hhouse28-02 at hand_camera with Dissolve(1.3)
    n "그녀가 홀로 살았을 땐 남편이 주로 머물렀던 1층에 거의 머물지 않았지만,"
    n "[d_name]이 온 뒤로 이 집안에서 그녀의 활동 반경도 넓어졌다."
    scene ch04_hhouse29 at hand_camera with Dissolve(0.8)
    d "**(그녀는 또 편하게 입었군....)**"
    d "**(맙소사..)**"
    d "**(......)**"
    scene ch04_hhouse30 at hand_camera with Dissolve(0.8)
    d "**([h_name]을 내 여자로 만들고싶다...)**"
    d "..........."
    d "**(여우 같은 여자다 그녀는....)**"
    d "......"
    d "**(누나 같기도 하고 친구 같기도 하고 엄마 같기도 하고...)**"
    scene ch04_hhouse31 at hand_camera with Dissolve(1.5)
    d "**(하........)**"
    d "**(그녀를 안고 싶다..)**"
    d "**(............)**"
    d "**(그녀를 내것으로 만들고 싶다..)**"
    scene ch04_hhouse31-02 at hand_camera with Dissolve(1.5)
    d "**(그녀에게 사랑받는 남자가 되고 싶다.....)**"
    d "**(........)**"
    d "**(그녀에게 인정받는 남자가 되고 싶다....)**"
    scene ch04_hhouse29 at hand_camera with Dissolve(0.8)
    d "**(그녀와 결혼한다면 이런 모습일까?.....)"
    d "......."
    d "**(날 반겨주고, 매일 음식을 만들어주고....)"
    d "**(매일 집안 여기저기서 섹스하고...)"
    scene ch04_hhouse28-02 at hand_camera with Dissolve(1.3)
    d "**(.......)**"
    d "**(그녀는 지금 나를 어떻게 보고있을까...)**"
    pause
    d "**(그녀는 나를 꼬맹이로 보고있을까?)**"
    d "**(...........)**"
    d "**(나를 남자라고 보는 생각이 조금이라도 있을까?......)**"
    scene ch04_hhouse31-03 at hand_camera with Dissolve(0.8)
    h "후후후.."
    h "거의 다 됐네요."
    h "자 이제 신나게 먹어볼까요?"
    scene ch04_hhouse31-04 at hand_camera with Dissolve(0.8)
    h "낮에 나름 거사를 치뤘더니 배고프네요 하하하."
    h "[d_name]도 배고프죠?"
    scene ch04_hhouse31-05 at hand_camera with Dissolve(0.8)
    d "네 배고파 미칠거 같아요 하하."
    d "어서 먹어요."
    scene ch04_hhouse32 at hand_camera with Dissolve(0.8)
    h "[d_name]에게 음식을 만들어주다보니 잊고 살았던 나의 여성성이 다시 튀어나오나봐요 하하하."
    d "하하하. 그래요?"
    scene ch04_hhouse32-02 at hand_camera with Dissolve(0.8)
    h "남편과 애들과 같이 지낼 땐 그렇게 음식 만들기 싫었는데..."
    h "이젠 다시 만드는 재미를 느끼네요."
    scene ch04_hhouse33 at hand_camera with Dissolve(1.3)
    d "잘 먹겠습니다."
    h "하하 맛있게 먹겠습니다."
    scene ch04_hhouse33-02 at hand_camera with Dissolve(0.8)
    h "맛있게 먹어요..."
    h "오늘 너무 고생 시켜서 미안했어요."
    d "하하 아닙니다."
    scene ch04_hhouse34 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_hhouse35 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_hhouse36 at hand_camera with Dissolve(0.8)
    d "저 근데...."
    d "이제 그 사진들은 어떻게 되는거에요??"
    scene ch04_hhouse37 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse38 at hand_camera with Dissolve(0.8)
    h "음...이제 그 사진들은 일단 내가 먼저 보고 추릴거에요."
    h "너무 우스꽝스러운 표정들과 동작들은 빼고, 흔들린 사진들도 빼고요.."
    h "그 후에 파트 별로 폴더링해서 고객회사에 전달해요."
    scene ch04_hhouse39 at hand_camera with Dissolve(0.8)
    h "그러면 그 쪽에서 최종 상품화해서 잡지와 웹페이지에 공개하는거에요."
    scene ch04_hhouse40 at hand_camera with Dissolve(0.8)
    d "아 그렇군요..."
    d "그럼 돈은 어떻게 계산되는거에요?"
    d "아 돈이 당장 필요한건 아니구요 그냥 호기심에 물어보는거에요."
    scene ch04_hhouse38 at hand_camera with Dissolve(0.8)
    h "몇 가지 플랫폼에 공개되느냐에 따라 다른데,"
    h "이번 촬영은 온라인과 잡지에 다 공개돼서 모델들에게 페이가 괜찮은 편이에요."
    scene ch04_hhouse40 at hand_camera with Dissolve(0.8)
    d "그럼 오늘 그 마담의 과거 사진들도 온라인 페이지에 있는거에요??"
    scene ch04_hhouse41 at hand_camera with Dissolve(0.8)
    h "네 맞아요."
    scene ch04_hhouse40 at hand_camera with Dissolve(0.8)
    d ".........."
    d "저....그러면..."
    d "마담이 실제로 세...섹스도 하는 배우인거에요??"
    scene ch04_hhouse41 at hand_camera with Dissolve(0.8)
    h "하하하 마담은 팬클럽도 있을정도로 꽤 인기있는 모델이에요."
    h "그런 일은 하지 않고요 누드도 이번이 처음이었어요."
    h "그녀와 같이 촬영하겠다는 남자 모델들도 정말 많아요."
    h "너는 데뷔하자마자 인기스타와 같이 촬영한거에요 하하."
    scene ch04_hhouse42 at hand_camera with Dissolve(0.8)
    d "하하하 이거 영광이네요."
    d "나중에 개인적으로도 친해지고 싶네요."
    scene ch04_hhouse41 at hand_camera with Dissolve(0.8)
    h "다음 주말에 집으로 초대 했으니 같이 저녁 먹고 시간보내요."
    h "이제 같이 촬영할 일은 없겠지만 그래도 인연이니."
    scene ch04_hhouse42 at hand_camera with Dissolve(0.8)
    d "기대 됩니다 하하."
    d "**(계속 같이 촬영하고 싶은데......)**"
    scene ch04_hhouse43 at hand_camera with Dissolve(0.8)
    d "아 참!"
    d "전 내일 마케팅 회사에 면접 보러갑니다."
    d "메리 선생님의 도움으로 면접 기회를 얻었어요."
    scene ch04_hhouse33 at hand_camera with Dissolve(0.8)
    h "아 그거 잘 됐네요."
    h "긴장 되겠어요 하하."
    h "너무 긴장하지 말고 면접 잘 해요."
    scene ch04_hhouse45 at hand_camera with Dissolve(0.8)
    d "감사합니다 하하."
    d "부디 합격해서 제 스스로 돈을 벌어 보고 싶습니다."
    d "그래서 [h_name]과 같이 사는데 보탬이 되고 싶습니다."
    d "..........."
    scene ch04_hhouse43 at hand_camera with Dissolve(0.8)
    d "에 그러니까.."
    d "이 집안의 남자로 인정 받는다랄까 하하."
    d "어쨌든 제가 지금은 이 집의 유일한 남자 잖아요 하하하."
    scene ch04_hhouse45-02 at hand_camera with Dissolve(0.8)
    h "........."
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
        $ add_point("love_helen", 1, "love_helen")
    pause            
    scene ch04_hhouse38 at hand_camera with Dissolve(0.8)
    h "잘 될거에요.."
    h "음 그럼....."
    scene ch04_hhouse47 at hand_camera with Dissolve(0.8)
    h "내일 비 올지도 모르고...."
    h "잘 하라는 의미에서..."
    scene ch04_hhouse48 at hand_camera with Dissolve(0.8)
    h "내일 내가 회사 까지 데려다 줄게요."
    h "더운데 셔츠입고 땀 뻘뻘 흐리면서 다니면 보기에도 안좋아요 하하."
    scene ch04_hhouse49 at hand_camera with Dissolve(0.8)
    d "그렇게 안해주셔도 되는데....."
    d "정말 감사합니다...."
    scene ch04_hhouse50 at hand_camera with Dissolve(0.8)
    h ".........."
    h "별거 아니에요 헤헤."
    h "어서 마저 먹어요."
    scene ch04_hhouse51 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse51-02 at hand_camera with Dissolve(1.2)
    pause
    jump ch04_hhouse02

label ch04_hhouse02:
    if not in_replay:
        $ persistent.unlock_ch04_hhouse02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal11.mp3"
    scene ch04_hhouse52 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse53 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse54 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse55 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse55-02 at hand_camera with Dissolve(1.2)
    d "오늘도 대단한 하루였군......"
    scene ch04_hhouse56 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse57 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse58 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse59 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse55 at hand_camera with Dissolve(1.2)
    d "하........."
    d "눈만 뜨면 섹스 생각 뿐이구나.."
    d "........"
    d "교수님이 내준 과제는 대체 언제 할거냐.."
    scene ch04_hhouse60 at hand_camera with Dissolve(1.5)
    d "젠장...."
    scene ch04_hhouse60-02 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_hhouse61 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse62 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh01.mp3"
    h "퓨.........."
    h "피곤하다....."
    h "....."
    h "나이 먹으니까 반나절만 촬영해도 다리가 아프네."
    h "20대엔 밤새서 촬영도 했었는데..."
    scene ch04_hhouse62-02 at hand_camera with Dissolve(1.5)
    h "............"
    h "마담에게 삽입하려고 했었다니....."
    h "진짜인가?..."
    h "............"
    h "내가 옆에 있었는데 어떻게 그런 생각을 했지?"
    h "........"
    h "둘이 뭔가 서로 신호를 주고 받았나?..."
    h "에이 설마..."
    play sound "audio/ambi/bath01.mp3"
    scene ch04_hhouse62-03 at hand_camera with Dissolve(2.0)
    h "............."
    h "근데 정말이지 몇몇 장면들은 엄청 야했어....."
    h "......."
    h "............."
    h "내가 섹스할 때도 그렇게 야한 모습일까?"
    h "........."
    h "나도 마담 처럼 흠뻑 젖었을까?......."
    h "....."
    play voice_f "audio/voices/fsigh01.mp3"
    h "하............"
    h "....."
    h "나 언제 마지막으로 섹스 했지?..."
    scene ch04_hhouse63 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_hhouse64 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_hhouse65 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse66 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh06.mp3"
    h "퓨.........."
    scene ch04_hhouse67 at hand_camera with Dissolve(1.3)
    h "........."
    h "그는 정말 건강해..."
    h "......"
    h "어떻게 사정하고나서도 그렇게 계속 발기해 있는건지...."
    scene ch04_hhouse68 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하......."
    h "오늘 땡기는 날인가...."
    scene ch04_hhouse69 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse70 at hand_camera with Dissolve(0.8)
    d "으흑..."
    scene ch04_hhouse71 at hand_camera with Dissolve(0.8)
    d "아 [h_name]...."
    d "당신이 해주는거 진짜 기분 좋아요...."
    scene ch04_hhouse72 at hand_camera with Dissolve(0.8)
    d "아 [h_name]........"
    d "우걱우걱 먹어주세요!!"
    scene ch04_hhouse73 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse74 at hand_camera with Dissolve(0.8)
    d "아........"
    d "[h_name]!!!"
    d "일어서서 이리와요!!"
    scene ch04_hhouse75 at hand_camera with Dissolve(0.8)
    d "처음 보자마자 랜드레이디와 하고싶었다구요!!"
    scene ch04_hhouse76 at hand_camera with Dissolve(0.8)
    d "그 녹색 드레스를 벗기고 떡치고 싶었다구요!!"
    scene ch04_hhouse77 at hand_camera with Dissolve(0.8)
    d "랜드레이디도 날 처음 본 날 나와 떡치고 싶었다는거 알아요!!"
    d "그래서 집을 구경시켜준다는 빌미로 이리저리 날 데리고 다녔던거죠!!!"
    play sound "audio/ambi/doorclose.mp3"
    scene ch04_hhouse78 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse79 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric02.mp3"
    scene ch04_hhouse79-02 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse80 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_hhouse81 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하......"
    h "오늘 따라 엄청 하고 싶네....."
    h ".............."
    h "거칠게 당하고 싶어...."
    scene ch04_hhouse82 at hand_camera with Dissolve(0.8)
    h ".............."
    h "퓨............"
    h "......."
    h "생리할 때가 됐나 보다..."
    scene ch04_hhouse83 at hand_camera with Dissolve(0.8)
    h "[d_name]의 발기한 모습이 잊혀지질 않아..."
    h ".............."
    h "참 한심하다 [h_name]......."
    h "어린 남자애의 몸을 상상하고 있다니...."
    h ".............."
    h "이 지저분한 년아..."
    scene ch04_hhouse_a01 at hand_camera with Dissolve(0.8)
    d "거실에서도, 제 방에서도, 뒷마당에서도 하고싶었던거죠?"
    scene ch04_hhouse_a02 at hand_camera with Dissolve(0.8)
    d "내가 덮쳐주길 기다렸던거죠?!!"
    scene ch04_hhouse_a03 at hand_camera with Dissolve(0.8)
    d "주방에서도 내가 따먹어주길 기다렸죠?!!"
    scene ch04_hhouse_a04 at hand_camera with Dissolve(0.8)
    d "오늘 마담과 같이 따먹어주길 바랬던거죠?!!!"
    image ch04_hhouse01_sex01:
        "ch04_hhouse_a01" with dissolve
        0.4
        "ch04_hhouse_a02" with dissolve
        0.4
        "ch04_hhouse_a03" with dissolve
        0.4
        "ch04_hhouse_a04" with dissolve
        0.4
        repeat
    scene ch04_hhouse01_sex01 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse87 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse88 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_hhouse89 at hand_camera with Dissolve(1.2)
    h "........."
    scene ch04_hhouse88 at hand_camera with Dissolve(0.8)
    h "[d_name]것이 이 정도 크기였나?"
    h "........."
    h "아냐 약간 더 굵었던거 같아."
    play voice_f "audio/voices/fsigh01.mp3"
    h "하........"
    h "이러고 레나에게 나무랐던거야?..."
    h "레나의 웃는 소리가 여기까지 들리는거 같네...."
    scene ch04_hhouse90 at hand_camera with Dissolve(1.2)
    play sound "audio/sex/fmoanshort.mp3"
    h "흐음...."
    scene ch04_hhouse91 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_hhouse01_sex01 at hand_camera with Dissolve(0.8)
    pause
    image ch04_hhouse01_sex02:
        "ch04_hhouse_a01" with dissolve
        0.2
        "ch04_hhouse_a02" with dissolve
        0.2
        "ch04_hhouse_a03" with dissolve
        0.2
        "ch04_hhouse_a04" with dissolve
        0.2
        repeat
    scene ch04_hhouse01_sex02 at hand_camera with Dissolve(0.8)
    d "아 [h_name]!!!"
    d "이제 당신은 내거에요 알아요?!!"
    d "이제 당신은 내 여자라구요!!"
    image ch04_hhouse01_sex03:
        "ch04_hhouse_a01" with dissolve
        0.1
        "ch04_hhouse_a02" with dissolve
        0.1
        "ch04_hhouse_a03" with dissolve
        0.1
        "ch04_hhouse_a04" with dissolve
        0.1
        repeat
    scene ch04_hhouse01_sex03 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    scene ch04_hhouse92 at hand_camera with Dissolve(0.8)
    d "아 [h_name]!!!!!"
    d "아악......"
    scene ch04_hhouse93 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse94 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_hhouse70 at hand_camera with Dissolve(1.5)
    d "아흑....."
    jump ch04_company01

label ch04_company01:
    if not in_replay:
        $ persistent.unlock_ch04_company01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch04_company01 at hand_camera with Dissolve(1.3)
    pause


if not in_replay:
    $ create_phone_channel("beth_dm", "Beth",
        ["Beth", phone_config["phone_player_name"]],
        "phone/icons/beth.png")

if not in_replay:
    $ send_phone_message("System", "", "amanda_dm", message_kind=5, do_pause=False)
    $ send_phone_message("Amanda", "Frank is getting worse.", "amanda_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Damn...", "amanda_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What happened?", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "I don't even know.", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "He claims he saw me with another guy or something.", "amanda_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "No way, that's ridiculous.", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "Exactly.", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "I can't stand the sight of him right now, seriously.", "amanda_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hang in there, Amanda.", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "Anyway, let's go out and get some fresh air together soon.", "amanda_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "eah, I'd love to ❤️", "amanda_dm", do_pause=False)
    $ send_phone_message("Amanda", "Sounds good. I'll call you, honey.", "amanda_dm", do_pause=False)

    $ send_phone_message("System", "", "jason_dm", message_kind=5, do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What's up?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Not much.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Campus is so dead since everyone left.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Must be pretty quiet though, haha.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Yeah lol.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Feels like I rented out the whole school.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hey, got any more of those pics?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "You shameless bastard.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "I hooked you up with those gifts last time, what're you doing for me?", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Thought you said you'd be my bitch for life?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Chill, just wait.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Your boy is about to make his debut as a model soon.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Wait, a model? You? Lmao.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "images/phone/media/ch04_helen01.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
    $ send_phone_message("Jason", "images/phone/media/ch04_helen02.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
    $ send_phone_message("Jason", "What the hell is this?? Is that you?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Yup, that's me.", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "HOLY SHIT!!", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Yo, send me all the pics right now. Fast.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "It's gonna be on the internet soon, so I'll let you know haha.", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "This is the difference in our class, bro..", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Dude, this lady looks just like Professor Sophia?", "jason_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What??", "jason_dm", do_pause=False)
    $ send_phone_message("Jason", "Yo, call me right now.", "jason_dm", do_pause=False)

    $ send_phone_message("System", "", "helen_dm", message_kind=5, do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hey Helen, are you asleep by any chance?", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "Still awake. Do you need something?", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Sorry for the late text.", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Could you maybe send me one or two pictures from the photoshoot?", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "Sure, hold on a sec.", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "But you can't post them anywhere, okay? Promise?", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Got it!!", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "images/phone/media/ch04_helen01.jpg", "helen_dm", 2, summary_alt="helen Photo", do_pause=False)
    $ send_phone_message("Helen", "images/phone/media/ch04_helen02.jpg", "helen_dm", 2, summary_alt="helen Photo", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Thank you so much!!", "helen_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Have a good night.", "helen_dm", do_pause=False)
    $ send_phone_message("Helen", "Haha good night.❤️", "helen_dm", do_pause=False)

    $ send_phone_message("System", "", "celine_dm", message_kind=5, do_pause=False)
    $ send_phone_message("Celin", "Hey.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What's up?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "I know what you did last summer.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What?? What the hell are u talking about?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Got a guilty conscience or something?", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What do you mean?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Just kidding, hahaha.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hmmm...", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "What are your plans for the weekend?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Wanna grab a drink?", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "I'm down.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "If Celine asks to meet up, I gotta make time even if I don't have any, haha.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Are you flirting with a married woman now?", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Hey, I'm just a naturally nice guy.", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Creep lol", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What?", "celine_dm", do_pause=False)
    $ send_phone_message("Celin", "Anyway, I'll hit you up on Friday.", "celine_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Cool, sounds good.", "celine_dm", do_pause=False)

    $ send_phone_message("System", "", "beth_dm", message_kind=5, do_pause=False)
    $ send_phone_message("Beth", "Hi there. Is this [d_name]?", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Yes, that's me. Who's this?", "beth_dm", do_pause=False)
    $ send_phone_message("Beth", "Oh, it's Beth.", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Oh, hi!", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "What's up?", "beth_dm", do_pause=False)
    $ send_phone_message("Beth", "Could you check if there’s a red USB drive inside your desk drawer, [d_name]?", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Sure, hold on a second.", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "Ah, found it.", "beth_dm", do_pause=False)
    $ send_phone_message("Beth", "Oh, thank you so much!!", "beth_dm", do_pause=False)
    $ send_phone_message(phone_config["phone_player_name"], "No problem haha.", "beth_dm", do_pause=False)
    $ send_phone_message("Celin", "See you tomorrow :)", "beth_dm", do_pause=False)


    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/24_thumb.jpg",
            "phone": "images/phone/shots/24.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/25_thumb.jpg",
            "phone": "images/phone/shots/25.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/26_thumb.jpg",
            "phone": "images/phone/shots/26.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/27_thumb.jpg",
            "phone": "images/phone/shots/27.jpg",
        })

        $ gallery_notif = True

    scene ch04_company02 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_company03 at hand_camera with Dissolve(1.3)
    n "맑게 개인 다음날 아침 그녀는 거실에서 그를 기다리고 있었다."
    scene ch04_company04 at hand_camera with Dissolve(0.8)
    n "그것은 그녀의 익숙했던 지난 날들을 떠올리게 했다."
    pause
    n "오로지 달라진 것은 그 방에서 나올 남자 뿐이었다."
    scene ch04_company05 at hand_camera with Dissolve(0.8)
    h "[d_name]!!"
    h "그러다 늦겠어요. 어서 나와요."
    h "내 잔소리가 필요한거에요?"
    d "네 지금 나갑니다!!"
    play sound "audio/ambi/dooropen.mp3"
    scene ch04_company06 at hand_camera with Dissolve(0.8)
    d "제가 너무 꾸물거렸어요 하하."
    d "나갑니다 나갑니다."
    play sound "audio/ambi/doorclose.mp3"
    scene ch04_company07 at hand_camera with Dissolve(0.8)
    d "이렇게 입는건 거의 처음이라 좀 오래걸렸어요."
    scene ch04_company07-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company08 at hand_camera with Dissolve(0.8)
    h "와우 [d_name]."
    h "그렇게 입으니까 회사원 같네요 헤헤."
    h "내 아들 옷이 딱 맞다니 다행이네요."
    h "신사 같네요 하하."
    scene ch04_company09 at hand_camera with Dissolve(0.8)
    d "전 언제나 신사였는걸요?!!"
    d "잊으셨어요? 하하하."
    scene ch04_company10 at hand_camera with Dissolve(0.8)
    h "어서 따라와요."
    h "다행히 비가 멈춰서 날씨가 좋네요."
    scene ch04_company10-02 at hand_camera with Dissolve(0.8)
    h "하지만 내가 면접 보러 가는거 처럼 긴장 되네요 하하하."
    d "하하 그런가요?"
    play sound "audio/ambi/cardooropen.mp3"
    scene ch04_company10-03 at hand_camera with Dissolve(2.0)
    h "아우....."
    h "어제 카메라좀 들고 있었다고 어깨가 결리네요."
    h "봤죠? 이게 중년 여성이라고요.."
    play voice_f "audio/voices/flaugh02.mp3"
    h "파릇파릇한 20대 여성과는 다르다고요 하하하."
    scene ch04_company10-04 at hand_camera with Dissolve(0.8)
    d "............."
    play sound "audio/ambi/carmoving01.mp3"
    scene ch04_company10-05 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_company10-06 at hand_camera with Dissolve(2.0)
    play sound "audio/ambi/carpass.mp3" volume 0.5
    pause
    scene ch04_company10-07 at hand_camera with Dissolve(2.0)
    play sound "audio/ambi/carpass.mp3" volume 0.5
    pause
    scene ch04_company10-08 at hand_camera with Dissolve(2.0)
    play sound "audio/ambi/city03.mp3" volume 1.2 loop
    pause
    scene ch04_company10-09 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_company10-10 at hand_camera with Dissolve(0.8)
    d "태워 주셔서 감사합니다."
    d "면접 잘 볼게요 헤헤."
    scene ch04_company10-11 at hand_camera with Dissolve(0.8)
    h "그래요."
    h "긴장하지 말고 면접 잘 봐요."
    h "혹시 무슨 일 있으면 전화해요. 알겠죠?"
    scene ch04_company10-12 at hand_camera with Dissolve(0.8)
    d "네 알겠습니다."
    d "감사합니다."
    d "[h_name]을 위해서 면접 잘 하겠습니다!!"
    h "하하하 알겠어요."
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch04_company10-13 at hand_camera with Dissolve(1.5)
    d "[h_name]이 나의 아내고 이렇게 매일 출근한다면 행복하겠군......"
    d "저녁엔 야한 속옷을 입고 날 기다리고....."
    pause
    d "젠장 면접이나 신경쓰자.."
    d "집중하자 [d_name]!!"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    play music "audio/bgm/normal05.mp3"
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch04_company11 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_company12 at hand_camera with Dissolve(0.8)
    n "타닥타닥타닥(키보드 두드리는 소리)"
    play sound "audio/ambi/dooropen02.mp3" volume 0.7
    scene ch04_company13 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company14 at hand_camera with Dissolve(0.8)
    d "아 안녕하세요..."
    d "저.. 면접보러왔습니다."
    d "............"
    scene ch04_company15 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_alessia = True
        $ bio_chloe = True
        $ bio_kevin = True
        $ bio_marcus = True
        $ bio_shakira = True
        $ bio_vivian = True

    unknownf "안녕하세요."
    unknownf "[d_name] 맞나요?"
    scene ch04_company16 at hand_camera with Dissolve(0.8)
    d "네 맞습니다."
    d "오늘 면접이 있어서 왔습니다."
    d "전 [d_name]이라고 합니다."
    scene ch04_company16-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company17 at hand_camera with Dissolve(0.8)
    unknownf "네 반가워요."
    unknownf "이쪽으로 따라오세요."
    d "감사합니다."
    play sound "audio/ambi/walkheels01.mp3" volume 0.7
    scene ch04_company18 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company18-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch04_company18-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company19 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company20 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company21 at hand_camera with Dissolve(0.8)
    unknownf "여기에서 잠시 기다려주세요."
    unknownf "곧 대표님이 오실거에요."
    unknownf "뭐 마실거 드릴까요?"
    scene ch04_company22 at hand_camera with Dissolve(0.8)
    d "아닙니다. 전괜찮습니다."
    d "감사합니다."
    scene ch04_company23 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_company24 at hand_camera with Dissolve(2.0)
    d "흠......."
    d "**(그렇게 큰 회사는 아닌거 같은데..)**"
    d "**(하긴 이런 소도시가 다 그렇지 뭐..)**"
    scene ch04_company25 at hand_camera with Dissolve(2.0)
    n "그는 그 스스로 생각 보다 많이 긴장하지 않았다는 사실에 짐짓 감탄하고 있었다."
    n "사실 회사 생활이란게 별거 아닌걸까 생각하기 시작했다."
    scene ch04_company26 at hand_camera with Dissolve(2.0)
    d "............"
    d "**(메리의 친구라니 어떤 사람인지 엄청 궁금하네.....)**"
    d "**(흠......)**"
    d "**(......)**"
    d "**(섹시한 밀프일까 푸짐한 아줌마 스타일일까..)**"
    d "**(헤헤헤.)**"
    play sound "audio/ambi/walkheels01.mp3" volume 0.7
    scene ch04_company27 at hand_camera with Dissolve(0.8)
    d "!!"
    stop sound
    if not in_replay:
        $ bio_rose = True
    scene ch04_company27-02 at hand_camera with Dissolve(1.7)
    play music "audio/bgm/erotic06.mp3" volume 0.6
    r "오래 기다렸나요?"
    scene ch04_company28 at hand_camera with Dissolve(0.8)
    d "예?!!"
    d "아..아닙니다. 괜찮습니다."
    d "면접에 대해 생각하고 있었습니다."
    n "그가 고개를 들었을 때 그의 상상과 전혀 다른 여성이 나타났다."
    n "그녀의 움직임으로 인한 약한 바람과 함께 진한 향수 냄새가 훅 풍겨져왔다."
    n "그의 머릿속에 있던 면접에 대한 모든 생각이 깨끗이 사라졌다."
    d "......................"
    scene ch04_company29 at hand_camera with Dissolve(0.8)
    pause
    r "........."
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_company30 at hand_camera with Dissolve(0.8)
    r "음........"
    n "그녀는 그 존재만으로 [d_name]을 압도했다."
    r "........."
    scene ch04_company28 at hand_camera with Dissolve(0.8)
    n "그녀가 아무 말도 하지 않은 그 몇초 사이 그는 자신의 숨소리도 낼 수 없었다."
    scene ch04_company31 at hand_camera with Dissolve(0.8)
    r "우선....."
    r "이게 좀 개인적으로 궁금하네요."
    r "아니 그전에 내가 말하다보면 직설적으로 말 할때가 있는데,"
    r "나의 나쁜 버릇이니 이상하게 생각하진 말았으면 해요."
    r "알겠죠?"
    d "네...네 알겠습니다."
    scene ch04_company32 at hand_camera with Dissolve(0.8)
    r "메리와는 무슨 사이에요?"
    r "..........."
    r "두 사람이 어떻게 알게 된거죠?"
    scene ch04_company33 at hand_camera with Dissolve(0.8)
    d "아 그..그건..."
    d "......."
    d "네 전 원래 이곳 출신입니다."
    d "어렸을적 버려져서 보육원에 맡겨 졌었습니다."
    d "물론 그것도 메리 선생님에게 들어서 알게 된 것이지만요."
    r "..........."
    scene ch04_company34 at hand_camera with Dissolve(0.8)
    d "그 보육원에서 절 보살펴주신 분이 메리 선생님이었습니다."
    d "10대 때 의탁 가정에 보내졌지만 그 후로도 메리와 보호자이자 친구처럼 지내고 있습니다."
    scene ch04_company35 at hand_camera with Dissolve(0.8)
    r "........."
    r "그랬군요."
    r "꽤 어려운 어린 시절을 보냈을거 같군요."
    r "........."
    scene ch04_company36 at hand_camera with Dissolve(0.8)
    r "사실 어제도 메리에게 전화가 왔었어요."
    d "아...그런가요?.."
    r "[d_name]군이 좋은 학생이라고 일 할 기회를 줬으면 한다고 하더군요."
    r "평생 저에게 이런 부탁은 한 적 없던 친구인데 참 의외라고 생각 했었죠."
    scene ch04_company37 at hand_camera with Dissolve(0.8)
    d "아 그랬었군요."
    d ".........."
    d "저는 그녀에게 평생의 빚을 지고 살고 있습니다."
    scene ch04_company37-01 at hand_camera with Dissolve(0.8)
    r "평생의 빚이요?"
    d "네 그렇습니다."
    d "그녀는 절 가족처럼 잘 보살펴 줍니다."
    d "........."
    scene ch04_company37-02 at hand_camera with Dissolve(0.8)
    d "그리고 그녀는 정말 아름다운 여성이에요."
    d "........."
    d "죄송합니다 제가 엉뚱한 얘기를 했습니다."
    scene ch04_company38 at hand_camera with Dissolve(0.8)
    r "............"
    r "그건 맞아요."
    r "여자인 내가 봐도 가지고 싶은 여자죠 메리는 하하하."
    r "내 친구지만 어린 소녀 같으면서도 엄마 같은 때가 있어요."
    scene ch04_company39 at hand_camera with Dissolve(2.0)
    n "그녀는 잠시 말을 마치고 심각한 표정으로 모니트를 들여다 봤다."
    d "**(제....젠장....)**"
    d "**(압박감이 엄청나......)**"
    scene ch04_company40 at hand_camera with Dissolve(0.8)
    r "대학교에서 심리학을 공부하고 있다고 들었다."
    r "오래는 아니었겠지만 1년간 공부해본 느낌은 어땠어요?"
    scene ch04_company41 at hand_camera with Dissolve(0.8)
    d "1년간 정말 재미있게 공부했습니다."
    d "제가 무언가의 원초적인 원리를 탐구하는 것을 좋아합니다."
    d "때문에 사람의 내면의 근저에 깔려있는 무의식을 탐구하는 것이 정말 흥미로웠습니다."
    d "무엇보다 사람 자체를 연구하는 학문이라는게 맘에 듭니다."
    scene ch04_company39-02 at hand_camera with Dissolve(0.8)
    r "그렇군요."
    r "그럼 1년간 배운것들이 마케팅 회사에 쓸모가 있을거 같나요?"
    scene ch04_company41 at hand_camera with Dissolve(0.8)
    d "**(다행이다...)**"
    d "**(어제 밤에 답변을 준비했던 거야 하하하.)**"
    d "네 그렇습니다."
    d "마케팅이란 필연적으로 인간에 대한 분석이 우선되어야 하는 분야입니다."
    d "떄문에 인간의 본성을 탐구하는 학문인 심리학 만큼 마케팅에 필요한 학문은 없다고 생각합니다."
    scene ch04_company42 at hand_camera with Dissolve(0.8)
    d "..............."
    d "전 마케팅 분야에서 사람의 마음이 어떻게 움직이는지,"
    d "그리고 그 움직임이 어떻게 소비로 연결되는지 현장에서 배우고 싶습니다."
    scene ch04_company43 at hand_camera with Dissolve(0.8)
    r "**(..............)**"
    r "**(너무 뻔한 대답이라 실소가 나올 지경이군...)**"
    r "**(AI에게 물어본건가?..)**"
    r "소비라...."
    r "[d_name]군이 아직은 어리고 내 자식 같으니 편하게 말할게요."
    scene ch04_company44 at hand_camera with Dissolve(1.3)
    r "결국 마케팅은 상대를 유혹하는 기술이야."
    r "내가 가진 것을 상대가 갈구하게 만드는 것."
    r "자네는 심리학도니까 알겠지?"
    r "인간의 가장 깊은 곳에 있는 욕망을 건드리는 법 말이야."
    scene ch04_company45 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_company46 at hand_camera with Dissolve(0.8)
    d "맞습니다."
    d "결핍을 찾아내고, 그것을 채워줄 수 있다는 확신을 주는 것이 핵심이라고 생각합니다."
    scene ch04_company46-02 at hand_camera with Dissolve(0.8)
    r "................."
    scene ch04_company47 at hand_camera with Dissolve(0.8)
    r "난 어떤 사람 같지?"
    r "................."
    r "심리학도의 눈으로 날 한번 분석해봐."
    scene ch04_company48 at hand_camera with Dissolve(0.8)
    d "대표님을 분석하라고요?..."
    scene ch04_company49 at hand_camera with Dissolve(0.8)
    r "편하게 얘기해, 여기서 오고가는 대화는 우리만의 비밀이니까."
    r "의도가 있는거 아니고 면접 때 마다 항상 물어보는 질문이야."
    scene ch04_company46 at hand_camera with Dissolve(0.8)
    d "아....네.."
    scene ch04_company50 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_company49 at hand_camera with Dissolve(0.8)
    r "지금 보이는 나에 대한 어떤 것이든 분석해봐."
    scene ch04_company51 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh07.mp3"
    r "니가 뚫어져라 보고있는 나의 큰 젖에 대해 얘기해도 괜찮아 하하하."
    if not in_replay:
        $ add_point("lust_rose", 1, "lust_rose")
    d "네?!!!!"
    d "**(제..젠장...)**"
    d "**(쥐구멍에라도 들어가고 싶어진다......)**"
    scene ch04_company52 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company51-02 at hand_camera with Dissolve(0.8)
    unknownf "........"
    scene ch04_company53 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_company36 at hand_camera with Dissolve(0.8)
    r "그런데 진짜 내 젖을 언급하면 여기서 일하는 것은 꿈도 꾸지 말아요."
    d "콜록 콜록."
    d "네...네 알겠습니다."
    d "**(젠장 하마터면 말할 뻔 했다..)**"
    scene ch04_company36-02 at hand_camera with Dissolve(0.8)
    r "..............."
    scene ch04_company54 at hand_camera with Dissolve(0.8)
    r "그럼 나에 대해 읽은것들을 말해봐요."
    r "난 맘에 담아두는 성격은 아니니 가능한 솔직하게 말해요."
    scene ch04_company54-02 at hand_camera with Dissolve(0.8)
    r "너 같은 꼬맹이가 날 어떻게 분석하는지 궁금하네요."
    n "[d_name]은 그녀의 놀리는 듯한 태도에 불편함을 느꼈다."
    n "순간 그녀에게 자신의 취업을 부탁하는 메리의 모습을 상상했다."
    n "그런 상상은 그가 로즈를 적대시 하기에 충분했다."
    scene ch04_company54-03 at hand_camera with Dissolve(0.8)
    n "그리고 로즈와 같이 자신의 어머니 나이의 여성에게 무시를 받는 것은 그를 화나게 했다."
    n "생모에게 버림 받은 기억이 그가 연상의 여인에게 집착하게 된 큰 원인이되었다."
    n "지금 로즈의 모습은 그런 그를 불편하고 화나게 하기 충분했다."
    n "그리고 그는 자신의 화를 그녀를 묘사하는데 풀기로 결심했다."
    scene ch04_company55 at hand_camera with Dissolve(0.8)
    d "대표님은 지금 완벽하게 무장하고 계세요."
    d "............."
    d "흑발과 대비되는 진한 메이크업, 빈틈없는 착장, 그리고 상대를 압도하는 당당한 태도까지."
    d "정기적으로 샵에서 헤어스타일링 까지 하시는거 같습니다."
    d "아 물론 왁싱까지 깨끗이 하실것으로 보입니다."
    r ".........."
    d "이건 마케팅 회사 대표로서 반드시 필요한 부분으로 일종의 갑옷이겠죠."
    d "그리고 물론 대표님 개인적인 만족을 위한 것이기도 하겠죠."
    d "회사와 대표님 자신을 완벽히 관리하고자 하는 욕망."
    d "하지만......."
    scene ch04_company55-02 at hand_camera with Dissolve(0.8)
    r "**(...........)**"
    r "하지만?"
    scene ch04_company56 at hand_camera with Dissolve(0.8)
    d "입술 옆의 그 점.."
    d "그 점은 메이크업으로 그리신걸로 보입니다."
    r ".........."
    d "대표님은 누군가 자신을 두려워하는 것보다,"
    d "그 갑옷을 뚫고 들어와 자신을 여자로 봐주길 갈구하고 계신 것 아닌가요?"
    d "그러니까 자신안엔 갑주를 입은 회사의 대표가 아니라,"
    d "매력적인 여성도 있다고 어필하기 원하는거 같습니다."
    r "....................."
    d "아니 더 정확히 말하자면 매력적인 여성성도 회사를 운영하는데 일종의 도구로서 활용하고 있는거 같습니다.."
    d "한 마디로 자신 스스로를 상품화 하신거죠."
    scene ch04_company57 at hand_camera with Dissolve(0.8)
    r "계속해봐요."
    scene ch04_company58 at hand_camera with Dissolve(0.8)
    d "마케팅이 유혹의 기술이라면, 대표님은 가장 완벽한 피사체죠."
    d "하지만 모두가 대표님의 지위와 겉모습에 압도당해 진짜 로즈라는 여자가 가진 결핍에는 다가가지 못해요."
    d "성공한 중년의 여성이라는 가면 뒤에 숨겨진, 본능적이고 날것의 시선에 굶주려 있는... "
    d "그런 모습이 보입니다."
    scene ch04_company59 at hand_camera with Dissolve(0.8)
    d "모두가 성공한 여성이라는 타이틀에 압도 돼 자신에게 사탕발림만 하는 사람들만 보셨을테니 자신을 편하게,"
    d "아니 오히려 무례하게 구는 사람을 보면 자극을 느끼시는거 같습니다."
    d "......................"
    d "한마디로 대표님 자신이 마케팅 실험체인 셈 입니다."
    scene ch04_company60 at hand_camera with Dissolve(0.8)
    r "............."
    r "내가 마케팅 실험체라..."
    r "내 결핍을 안다는 듯이 지껄인 남자는 네가 처음이 아니야, 데미안."
    r "대부분은 그 알량한 분석 뒤에 얄팍한 수작이 깔려 있어서 지루하기 짝이 없었지."
    r "그렇게 생각하지 않니?"
    scene ch04_company60-02 at hand_camera with Dissolve(0.8)
    d "그 사람들과 저의 차이는 간단합니다."
    d "저는 대표님이 듣고 싶어 하는 이야기에 관심이 없습니다."
    d "그런 말을 할 지식도 경험도 미천하고요."
    d "대신 대표님이 숨기고 있는 이야기에 관심이 있죠."
    scene ch04_company61 at hand_camera with Dissolve(0.8)
    d "솔직히 말씀드리면 이런 분석은 위험합니다."
    d "상대가 싫어하면 무례한 젊은 놈으로 끝나니까요."
    d "그런데 대표님은 화를 내기는커녕 점점 제 얘기에 흥미를 보이시는거 같습니다."
    d "아마 제 분석 자체보다도 누군가가 자신을 그렇게 들여다봤다는 사실이 재미있으셨겠죠."
    d "그래서 저는 계속 말했습니다."
    r "............."
    scene ch04_company62 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh07.mp3"
    r "하하하하하."
    r "세상에!"
    r "메리가 물건을 보냈네."
    r "대학교 1학년 학생 입에서 이런 소리가 나올 줄이야."
    scene ch04_company63 at hand_camera with Dissolve(0.8)
    d "무례했다면 사과 드립니다...."
    d "하지만 대표님이 솔직함을 원하셔서 제 느낌 그대로 두서 없이 말씀드렸습니다."
    scene ch04_company38 at hand_camera with Dissolve(0.8)
    r "하하하. 아니에요."
    r "솔직하지만 믿을 수 없을 정도로 유치한 말들이었어요.."
    d "**(젠장.)**"
    d "**(괜히 오바했다.)**"
    r "정말 3류 소설의 대사를 드는 줄 알았다 하하하."
    scene ch04_company37 at hand_camera with Dissolve(0.8)
    d "죄송합니다.."
    scene ch04_company65 at hand_camera with Dissolve(0.8)
    r "아니야 괜찮아."
    r "하지만 이렇게 신선한 분석은 처음이야 하하하."
    r "이게 내가 진짜 원했던 허를 찌르는 발상이었다고 하하."
    scene ch04_company46-02 at hand_camera with Dissolve(0.8)
    r "유치하긴 했지만 틀에박힌 대답이 아니어서 안심했어요."
    r "학교에서 배우는 것과 현장에서의 실무는 천지 차이지만.."
    r "[d_name]군은 타고난 분석력이 있어 보이네요."
    r "............"
    scene ch04_company63 at hand_camera with Dissolve(0.8)
    d "가..감사합니다."
    d "하지만 제가 좀 무례했습니다..."
    scene ch04_company66 at hand_camera with Dissolve(1.3)
    d "**(.............)**"
    r "맞아요."
    r "엄한 분위기의 회사 였다면 바로 집에 가란 소리를 들었겠죠."
    play sound "audio/ambi/walkheels01.mp3" volume 0.7
    scene ch04_company66-02 at hand_camera with Dissolve(0.8)
    d "!!!!"
    stop sound
    scene ch04_company66-03 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_company67 at hand_camera with Dissolve(2.0)
    r "괜찮아."
    r "내 기준엔 전혀 무례하지 않았어."
    scene ch04_company68 at hand_camera with Dissolve(0.8)
    r "오히려 재미있었어."
    r "..............."
    r "너 처럼 어린 녀석에겐 꾀 가혹하게 드릴수 있겠지만,"
    r "너도 역시 밑바닥에 깔려있는 너의 열등감을 건드리니 바로 너의 본심을 드러냈어."
    r "......."
    r "그게 이상하다는건 아니지만 내가 보기엔 넌 뭔가 단단한 껍질에 갇혀있는 걸로 보인단다."
    scene ch04_company69 at hand_camera with Dissolve(0.8)
    d "**(.............)**"
    d "꺼...껍질이요?"
    r "그래 껍질."
    scene ch04_company68 at hand_camera with Dissolve(0.8)
    r "뭐랄까 껍질에 갇힌 새 처럼 무언가 널 억누르고 있다고."
    r "..............."
    scene ch04_company69 at hand_camera with Dissolve(0.8)
    d "........"
    scene ch04_company70 at hand_camera with Dissolve(0.8)
    r "좋아, 꼬맹아."
    r "네 분석이 맞는지 틀린지는 앞으로 네가 몸소 체험하며 확인해 봐."
    r "..............."
    scene ch04_company71 at hand_camera with Dissolve(0.8)
    r "아니, 니가 순진한 얼굴에 예리함을 숨기고 있는거 같으니 사실을 말 해 줄게."
    r "너의 어린시절 배경은 이미 들어 알고있었어."
    r "이 부분을 숨긴건 사과할게."
    scene ch04_company72 at hand_camera with Dissolve(0.8)
    r "그리고 사실 메리와 통화 했을 때 이미 인턴으로 채용하기로 결정했었어."
    r "대학교 1학년의 신선한 사고회로가 필요했었어."
    r "들어오면서 봤을테지만 여기 직원들이 너 처럼 어리진 않거든."
    r "또 내 베프인 메리와 가족 같은 사이라니 당연히 채용이었지."
    r "게다가 이런 작은 도시의 회사가 너 처럼 학생 인턴을 채용하면 주에서 임금 지원도 해주거든."
    scene ch04_company73 at hand_camera with Dissolve(0.8)
    r "................."
    r "근데 그런 조건들이 없었어도 널 채용했을거 같아."
    r "왜 그렇게 결정했는지 알겠니?"
    scene ch04_company74 at hand_camera with Dissolve(0.8)
    d "아니요. 모르겠습니다."
    scene ch04_company70 at hand_camera with Dissolve(0.8)
    r "좋아, [d_name]."
    r "마케팅에서 가장 중요한건 바로 솔직함이야."
    r "있는 그대로의 모습."
    r "니가 방금 나에게 보여준 그 모습 말이야."
    r "심리학도 결국 똑같지 않니?"
    scene ch04_company75 at hand_camera with Dissolve(0.8)
    r "사람의 마음을 이해하려면, 가장 먼저 그 사람을 있는 그대로 봐야 하지."
    r "억지로 꾸며내거나, 듣기 좋은 말만 덧칠하면… 잠깐은 속일 수 있을지 몰라도 결국 본질은 드러나."
    r "사람은 생각보다 훨씬 예민하거든."
    r "진짜와 가짜, 진심과 포장지를 본능적으로 구분해."
    scene ch04_company74 at hand_camera with Dissolve(0.8)
    r "그리고 그건 비즈니스도 마찬가지야."
    r "대부분 사람들은 마케팅이라고 하면 없는 가치를 만들어내고, 평범한 걸 과장해서 반짝이게 꾸미는 기술이라고 생각해"
    r "틀린 말은 아니지."
    r "하지만 그런 방식은 오래 못 가."
    scene ch04_company76 at hand_camera with Dissolve(0.8)
    r "왜냐하면 실체 없는 포장은 결국 벗겨지니까."
    r "과장된 약속, 부풀려진 이미지, 억지로 만들어낸 환상…"
    r "처음엔 사람들의 시선을 끌 수 있어도, 결국 실망만 남겨."
    r "그리고 실망은 신뢰를 갉아먹지."
    r "그러한 역효과는 마케팅을 하기 전보다 더 브랜드의 신뢰를 추락시키지."
    scene ch04_company77 at hand_camera with Dissolve(0.8)
    r "한 번 무너진 신뢰는 돈으로도 쉽게 복구되지 않아."
    r "그래서 진짜 마케팅은 없는 것을 만드는 게 아니야."
    r "이미 존재하는 가치,"
    r "이미 그 브랜드가 가진 진짜 의미를…"
    scene ch04_company78 at hand_camera with Dissolve(0.8)
    r "가장 선명하고, 가장 정확하고, 가장 매력적으로 보여주는 방법을 찾는 것."
    r "그게 시작이야."
    r "쉽게 말해서..가짜를 추가하는 기술이 아니라,진짜를 전달하는 기술이지."
    scene ch04_company79 at hand_camera with Dissolve(0.8)
    r "그래야 사람의 마음을 건드릴 수 있어."
    r "결국 사람을 움직이는 건 허상이 아니라 공감이야."
    scene ch04_company75 at hand_camera with Dissolve(0.8)
    r "사람이 무언가에 돈을 지불하고 구매할 때,"
    r "A와 B사이에서 비지니스가 성사 될 때,"
    scene ch04_company80 at hand_camera with Dissolve(0.8)
    r "............"
    r "여자가 옷을 벗고 남자에게 자신의 다리를 벌릴 때,"
    scene ch04_company77 at hand_camera with Dissolve(0.8)
    r "무조건 선행 되는 조건이 뭔지 아니?"
    scene ch04_company81 at hand_camera with Dissolve(0.8)
    d "모...모릅니다."
    scene ch04_company82 at hand_camera with Dissolve(0.8)
    r "..............."
    r "이미 알고 있을텐데?"
    scene ch04_company83 at hand_camera with Dissolve(0.8)
    r "바로 확신이지."
    r "이 물건을 사도 되겠다,"
    r "이 사람과 같이 거래를 해도 되겠다,"
    r "이 사람에게 내 다리를 벌려도 되겠다....."
    scene ch04_company84 at hand_camera with Dissolve(0.8)
    r "사람의 모든 움직임과 선택은 바로 이 확신에서 비롯되는거야."
    r "그리고 그 확신은 바로 니가 나에게 보여줬던 솔직함에서 시작되는 거고.."
    scene ch04_company84-02 at hand_camera with Dissolve(0.8)
    d "그... 그렇군요.."
    scene ch04_company85 at hand_camera with Dissolve(0.8)
    r "조심스럽게 비위를 맞추지도 않았고,있지도 않은 말을 지어내지도 않았고,"
    r "그저 네가 본 그대로를 말했지."
    r "무례할 수도 있었지만 동시에 가장 강력했지..."
    r "마케팅이란 바로 그런 진솔함을 추구하는 산업이야."
    scene ch04_company86 at hand_camera with Dissolve(0.8)
    pause
    r "나도 답례로 3류 소설 같은 대사를 쳐 줄게."
    d ".............."
    r "기대할게."
    r "네가 분석한 내 결핍을 어떻게 채워줄지 말이야……"
    r "오해하지마."
    r "내 결핍이 아니라 이 회사의 결핍 말하는거야."
    scene ch04_company88 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_company89 at hand_camera with Dissolve(0.8)
    r "그리고 말이야.."
    scene ch04_company90 at hand_camera with Dissolve(0.8)
    r "이 점은 진짜라고"
    r "메이크업이 아니라고!"
    r "난 그렇게 유치한 짓 안한다 하하."
    scene ch04_company88 at hand_camera with Dissolve(0.8)
    d "........."
    d "그..그렇군요."
    d "**(이 여자는 진짜 종잡을 수가 없다...)***"
    d "**(어떻게 이렇게 사람을 들었다 놨다 하는거지?...)***"
    scene ch04_company38 at hand_camera with Dissolve(0.8)
    r "좋아 그럼..."
    r "오늘, 내일은 개인적인 시간을 갖고 이틀 뒤 부터 출근할래?"
    scene ch04_company41 at hand_camera with Dissolve(0.8)
    d "네 그렇게 하겠습니다!"
    scene ch04_company49 at hand_camera with Dissolve(0.8)
    r "그래 수고했어."
    r "너의 자리와 물품들은 준비 해 놓을게."
    r "메리에게도 전화 해주고."
    d "네 알겠습니다!"
    scene ch04_company90-02 at hand_camera with Dissolve(1.3)
    pause
    play sound "audio/ambi/dooropen.mp3" volume 0.7
    scene ch04_company91 at hand_camera with Dissolve(1.3)
    d "**(맙소사....)**"
    d "**(저렇게 종잡을 수 없는 사람은 처음이네.)**"
    d "**(.........)**"
    d "**(나이들면 자연스럽게 생기는 능력인가?)**"
    play sound "audio/ambi/walkheels01.mp3" volume 0.7
    scene ch04_company92 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_company59 at hand_camera with Dissolve(1.5)
    pause
    stop sound
    play music "audio/bgm/normal04.mp3"
    scene ch04_company94 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/city02.mp3" loop
    pause
    scene ch04_company95 at hand_camera with Dissolve(1.5)
    d "퓨........."
    d "그녀의 카리스마가 대단하네..."
    d "그래서 이런 회사를 운영할 수 있는건가보다.."
    scene ch04_company96 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/phonering02.mp3" volume 0.7
    n "전화가 울린다."
    stop sound
    scene ch04_company97 at hand_camera with Dissolve(0.8)
    d "아만다!!"
    d "잘 지냈어요?"
    scene ch04_company98 at hand_camera with Dissolve(1.3)
    a "잘 지냈지? 넌 어때?"
    d "잘 지냈어요!!"
    d "전 방금 회사 면접을 마치고 나왔어요!"
    a "회사 면접??"
    d "네!"
    d "메리가 연결해줘서 이틀 뒤 부터 출근하게 됐어요."
    scene ch04_company99 at hand_camera with Dissolve(1.3)
    a "오 정말 잘 됐다."
    a "마침 내가 전화를 잘 했네."
    a "그럼 취업 축하겸 해변으로 여행 다녀올까?"
    a "어때?"
    d "지금 바로요?"
    a "응 지금 바로."
    scene ch04_company100 at hand_camera with Dissolve(1.0)
    d "네 좋아요!!"
    d "근데 저 옷 지금 없는데 어떻게 하죠?"
    scene ch04_company101 at hand_camera with Dissolve(1.0)
    play voice_f "audio/voices/milflaugh08.mp3"
    a "옷은 필요 없을거야 하하하."
    a "서점에서 책이라도 읽고 있어."
    a "금방 갈게. 알았지?"
    scene ch04_company102 at hand_camera with Dissolve(2.0)
    f ".............."
    scene ch04_company103 at hand_camera with Dissolve(1.0)
    f "당신 [d_name] 만나러 나가는거야?"
    f "..............."
    f "그 옷차림은 또 뭐야??"
    f "설마 그렇게 입고 밖에 나갈건 아니지??"
    f "당신이 무슨 창녀야?!!"
    f "내가 동네 창피해서 어딜 가지 못하겠다고!!"
    scene ch04_company104 at hand_camera with Dissolve(1.0)
    a "............."
    a "신경꺼."
    a "저녁 준비 해놓을테니까 알아서 챙겨 먹어."
    a "오늘 늦을수도 있어."
    a "당신이 좋아하는 그 마사지샵이라도 가던가 해."
    scene ch04_company105 at hand_camera with Dissolve(0.8)
    f ".............."
    f "그...그건...."
    scene ch04_company104 at hand_camera with Dissolve(1.0)
    a "설마 내가 모른다고 생각했던거야?"
    pause
    a "오 프랭크....."
    f ".............."
    scene ch04_company105 at hand_camera with Dissolve(0.8)
    a "당신은 날 실망시켰어...."
    a "........"
    a "또 다시.."
    f ".............."
    scene ch04_company106 at hand_camera with Dissolve(1.3)
    pause
    jump ch04_acar01

label ch04_acar01:
    if not in_replay:
        $ persistent.unlock_ch04_acar01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal06.mp3"
    scene ch04_acar01 at hand_camera with Dissolve(1.3)
    play sound "audio/ambi/carpass.mp3" volume 0.3
    pause
    scene ch04_acar02 at hand_camera with Dissolve(1.3)
    pause
    stop sound
    scene ch04_acar03 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/milflaugh08.mp3"
    a "하하하."
    a "그런 면접을 봤다니 정신이 없었겠네."
    d "네 어찌나 정신이 없던지 하하하."
    d "......."
    d "그래도 좋은 경험을 한거 같아요."
    scene ch04_acar04 at hand_camera with Dissolve(0.8)
    a "식은 땀이 줄줄 흐르지 않았어? 하하."
    a "불알 사이에도 땀 찼을걸? 하하하."
    scene ch04_acar05 at hand_camera with Dissolve(0.8)
    d "맙소사 아만다!!"
    d "거기 까진 땀 안났어요."
    scene ch04_acar06 at hand_camera with Dissolve(0.8)
    a "확인 해볼까? 하하하."
    scene ch04_acar07 at hand_camera with Dissolve(0.8)
    d "오 그래요?"
    d "저의 아나콘다를 꺼낼까요 그럼?"
    scene ch04_acar08 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh08.mp3"
    a "하하하."
    a "그 별명이 맘에 들었구나?"
    a "니가 그 별명을 좋아할 줄 알았어."
    d "하! 전혀 맘에 안들어요."
    a "지금 말고."
    a "이따가 꺼내야 할 걸?"
    scene ch04_acar09 at hand_camera with Dissolve(0.8)
    d "네?"
    d "이따 제 아나콘다를 꺼낸다구요?"
    d "바다에서 그랬다간 풍기문란으로 잡혀간다구요."
    scene ch04_acar10 at hand_camera with Dissolve(0.8)
    d "프랭크는 어때요?"
    d "그날 저 떠나고 바로 프랭크가 왔어요?"
    scene ch04_acar11 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh03.wav"
    a "하 말도 마....."
    a "그 날 아침에 와서 별소리를 다 하더라."
    scene ch04_acar12 at hand_camera with Dissolve(0.8)
    a "왜 아침부터 샤워했냐, 어제 밤에 혹시 집에 남자 불러들였냐,"
    a "여기저기 킁킁 거리면서 냄새 맡고 다니더라."
    d "헐 진짜요?!!"
    a "드디어 저 사람이 미쳤구나 싶었지 뭐야."
    d "맙소사."
    d "프랭크는 언제나 한결 같네요."
    a ".............."
    a "나이가 드니까 점점 더 고약해지는거 같기도하고.."
    scene ch04_acar13 at hand_camera with Dissolve(0.8)
    a "그 있잖아.."
    a "우리가 얘기 했던 그 계획 이제 실행할 때가 온거 같아."
    scene ch04_acar14 at hand_camera with Dissolve(0.8)
    d "하하하하하."
    d "제가 깜빡했네요."
    scene ch04_acar15 at hand_camera with Dissolve(0.8)
    a "그나저나 보육원에 갔었니?"
    a "메리는 잘 지내지?"
    a "하...언제 메리와 만나서 커피라도 마셔야 하는데.."
    scene ch04_acar16 at hand_camera with Dissolve(0.8)
    d "네 마..만났었죠."
    d ".........."
    d "보육원 사람들 모두 잘 지내고 있어요."
    d "셀린도 잘 지내고..."
    a "아 셀린.."
    a "셀린도 보고싶다."
    scene ch04_acar17 at hand_camera with Dissolve(0.8)
    d ".................."
    scene ch04_acar18 at hand_camera with Dissolve(1.3)
    d "메리와 좋은 시간을 보내고 왔어요..."
    a ".........."
    scene ch04_acar19 at hand_camera with Dissolve(1.3)
    d "보육원에 가면 메리는 항상 절 환영해줘요."
    a "그치..."
    a "메리는 정말 좋은 사람이야."
    a "내가 시장이라면 메리에게 지역사회 공로상이라도 하나 주고 싶다 정말 하하하."
    scene ch04_acar20 at hand_camera with Dissolve(1.3)
    d "그..그렇죠...."
    d "........."
    scene ch04_acar21 at hand_camera with Dissolve(1.3)
    d "이제 자주가려구요.."
    d "........."
    d "메리도 그러길 바랄거 같아요..."
    scene ch04_acar22 at hand_camera with Dissolve(0.8)
    a "그랬구나.."
    a "좋았겠다."
    a "............."
    scene ch04_acar22-02 at hand_camera with Dissolve(0.8)
    a "넌 행복한 줄 알아야 돼!"
    a "무슨 말인지 아니?"
    a "널 그렇게 챙기는 여성들이 대체 주변에 몇 명이니? 하하하."
    play voice_f "audio/voices/milflaugh07.mp3"
    scene ch04_acar23 at hand_camera with Dissolve(0.8)
    d "하하하. 그럼요."
    d "전 행복한 남자인거 같아요 하하."
    scene ch04_acar24 at hand_camera with Dissolve(0.8)
    a "그래. 감사하고 살아야지."
    a "아무튼 메리랑만 좋은 시간만 보내지 말고 나랑도 좀 보내자고!"
    d "그...그래야죠 헤헤.."
    scene ch04_acar25 at hand_camera with Dissolve(0.8)
    a "여자가 질투하면 무슨 일이 벌어지는지 알지?"
    a "이 시골 동네에 재앙이 찾아온다고 하하하."
    scene ch04_acar23 at hand_camera with Dissolve(0.8)
    d "하하하. 저에겐 아만다 뿐이에요."
    d "늘 아만다와 좋은 시간을 보내는 상상을 한다구요 헤헤.."
    scene ch04_acar26 at hand_camera with Dissolve(2.0)
    a "..............."
    play sound "audio/ambi/carpass.mp3" volume 0.5
    scene ch04_acar27 at hand_camera with Dissolve(2.0)
    a "바다랑 가까워 진다!!!"
    d "예~~~"
    a "유후~~~"
    jump ch04_beach01

label ch04_beach01:
    if not in_replay:
        $ persistent.unlock_ch04_beach01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene ch04_beach01 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_beach02 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_beach03 at hand_camera with Dissolve(1.3)
    d "제가 뭐 들어야 할 건 없어요?"
    a "이 돗자리만 메고 가."
    a "나머진 내가 들게."
    scene ch04_beach03-02 at hand_camera with Dissolve(1.1)
    a "하 이 바다가 얼마만이야."
    a "좋아 좋아 헤헤."
    scene ch04_beach04 at hand_camera with Dissolve(2.0)
    pause
    play ambient "audio/ambi/beach01.mp3" volume 2.8 fadein 1.0
    scene ch04_beach04-02 at hand_camera with Dissolve(1.5)
    a "하하!!"
    a "다행히 이 자리에 사람이 아무도 없군."
    scene ch04_beach04-03 at hand_camera with Dissolve(0.8)
    a "여기가 풀들에 가려져 있어서 편하게 쉬기 좋아."
    d "네 자리 좋네요 하하."
    a "그치? 헤헤."
    scene ch04_beach05 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_beach06 at hand_camera with Dissolve(0.8)
    a "아 여기 예전에 왔을 때랑 좀 달라졌을걸?"
    scene ch04_beach07 at hand_camera with Dissolve(0.8)
    d "달라졌다니 뭐가요?"
    d "똑같은거 같은데요?"
    scene ch04_beach08 at hand_camera with Dissolve(0.8)
    a "하하하."
    a "쉽게 알아차리지 못할걸?"
    a "저길 봐봐."
    scene ch04_beach09 at hand_camera with Dissolve(0.8)
    d "네? 표지판이요?"
    scene ch04_beach10 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!"
    n "그가 아만다가 가르키는 곳을 봤을 때 알림판 하나가 서있었다."
    n "그것은 이 둘이 있는 지역은 누드가 허용된 구역임을 알리고 있었다."
    d "아니 대체 언제부터 이렇게 된거에요??"
    scene ch04_beach11 at hand_camera with Dissolve(0.8)
    d "헐......."
    d "표지판 넘어서 부터에요?"
    d "아닌가? 우리가 있는 쪽 말하는건가?"
    scene ch04_beach12 at hand_camera with Dissolve(0.8)
    a "나도 몰라."
    a "그게 뭐가 중요해."
    a "규칙은 따르면 되는거야 하하하."
    a "또 촌스럽게 눈 동그래져서 두리번거리지 말라고 알려주는거야."
    scene ch04_beach13 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "걱정하지 말아요."
    d "저 쿨한척 잘해요."
    play voice_f "audio/voices/milflaugh07.mp3"
    a "하하하 나도 알아."
    scene ch04_beach14 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_beach15 at hand_camera with Dissolve(0.8)
    a "그런데 말이야.."
    a "그 지난번에 말한 그건 어떻게 되가니?"
    a "기억하고 있어?"
    scene ch04_beach16 at hand_camera with Dissolve(0.8)
    d "그거라니 뭐 말하는거에요?"
    scene ch04_beach17 at hand_camera with Dissolve(0.8)
    a "운동하라고 얘기 했잖아."
    a "그새 잊어버린거야?"
    a "특히 하체 운동."
    d "아 기억하고 있어요..."
    a "잘 먹는 것도 중요한데 운동도 그만큼 중요하단다."
    a "관리 안하면 프랭크 몸매 될수도 있어."
    scene ch04_beach18 at hand_camera with Dissolve(0.8)
    d "아 아직 시작은 안했어요."
    d "지금은 하숙집 마당에서 수영만하고 있어요."
    d "랜드레이디도 운동하던데 같이 할까봐요."
    scene ch04_beach18-02 at hand_camera with Dissolve(0.8)
    a "좋은 생각이야."
    a "운동은 평생 해야해."
    a "기억하지?"
    d "............."
    a "다양한 체위를 하려면 몸이 탄탄해야 한다고 하하하하."
    scene ch04_beach19 at hand_camera with Dissolve(0.8)
    d "........."
    d "네..."
    scene ch04_beach19-02 at hand_camera with Dissolve(0.8)
    show ch04_beach19-03 at hand_camera with Dissolve(0.8)
    d "............."
    d "물론 기억하고 있어요 헤헤."
    d "매일매일 되새기고 있어요."
    hide ch04_beach19-03 with Dissolve(0.8)
    scene ch04_beach15 at hand_camera with Dissolve(0.8)
    a "랜드레이디는 어떠니?"
    a "같이 좀 지내보니까 어때?"
    scene ch04_beach16 at hand_camera with Dissolve(0.8)
    d "좋은 사람이에요."
    d "절 그냥 렌트비만 받아먹을 사람으로만 보면 어쩌나 걱정했는데,"
    d "인간 대 인간으로 잘 대우해주고 챙겨줘요."
    d "때때로 요리도 해주구요."
    d "사람 자체가 쿨해요."
    scene ch04_beach17 at hand_camera with Dissolve(0.8)
    a "다행이구나."
    a "요즘엔 정말 이상한 사람들이 많아서 잘 봐야 해."
    a "결정적인 순간에 돌변하는 싸이코패스들도 있어."
    a "또 젋은 남자들 후리고 싶어서 안달난 여자들도 있다고."
    scene ch04_beach18 at hand_camera with Dissolve(0.8)
    d "네 무슨 말인지 알아요."
    d "아만다에게 귀에 못이 박히도록 들었잖아요 하하하."
    d "위험한 사람을 멀리하고 위험한 자리는 애초에 피하되,"
    d "만약 발을 들였다면 한시라도 빨리 그곳을 빠져나오는 것만이 너를 지키는 유일한 방법이다."
    d "네가 가는 곳과 네가 만나는 사람이 결국 네 인생의 방향을 정한다."
    scene ch04_beach18-02 at hand_camera with Dissolve(0.8)
    a "좋아."
    a "잘 기억하고 있군."
    a "잔소리한 보람이 있어. 훌륭해."
    a "........"
    a "하지만 거기에 하나를 더 추가해."
    scene ch04_beach19 at hand_camera with Dissolve(0.8)
    d "진심이에요?"
    d "지금 이것만으로도 벅찬데 어떤걸 추가할까요?"
    scene ch04_beach20 at hand_camera with Dissolve(0.8)
    a "남자는 하체가 튼실해야 한다."
    d "하하하. 알겠어요."
    a "............"
    scene ch04_beach19 at hand_camera with Dissolve(0.8)
    d "홀리쉣..."
    scene ch04_beach21 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_beach21-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach22 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_beach23 at hand_camera with Dissolve(0.8)
    unknownm "이런 이런...."
    scene ch04_beach23-02 at hand_camera with Dissolve(0.8)
    unknownm "어이 거기!"
    unknownm "여긴 누드 구역인데 왜 옷을 입고 그래요?"
    unknownm "하하하하하."
    unknownm "여기선 옷을 입는게 오히려 위화감 조성하는거 몰라요?"
    scene ch04_beach24 at hand_camera with Dissolve(0.8)
    unknownf "어이 아줌마!"
    unknownf "어색해보이는데 그러지말고 그냥 다 벗는게 어때요?"
    unknownf "뭐 이미 다 벗은거 같은데 그런 촌스러운 천쪼가리는 왜 걸치고 있는거에요?"
    unknownm "하하하하."
    unknownf "그런 꼬마 노예를 데리고 왔는데 막상 부끄러운거에요? 하하하."
    scene ch04_beach25 at hand_camera with Dissolve(0.8)
    unknownm "하하하하."
    scene ch04_beach26 at hand_camera with Dissolve(0.8)
    a "하........"
    a "그런거 아니니까 갈길들 가세요."
    a "얌전히 있는 사람들이게 시비걸지 마세요."
    scene ch04_beach23-02 at hand_camera with Dissolve(0.8)
    unknownm "벗을거 아니면 우리에게 자리 양보하세요."
    unknownm "누드존에서 옷 입고 자리만 차지하고 있으면 비매너라구요."
    unknownm "거긴 우리가 맡아놓은 자리라구요."
    scene ch04_beach26-02 at hand_camera with Dissolve(0.8)
    a "하......."
    scene ch04_beach24 at hand_camera with Dissolve(0.8)
    unknownf "볼품 사나운 아줌마 몸매 때문이면 저 밑에 해변으로가세요."
    unknownf "거긴 아줌마 같은 노인들 많아서 좋을거에요."
    unknownf "왜 여기 있는거에요? 하하하."
    scene ch04_beach26-03 at hand_camera with Dissolve(0.8)
    d "헤이!!"
    d "주둥이 닥치고 저리 꺼져."
    scene ch04_beach27 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach27-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach28 at hand_camera with Dissolve(0.8)
    a "내가 벗으면 이 동네 남자들이 다 넋이 나가거든."
    a "그래서 이 구석에 숨어서 너희들에게 자비를 베풀고 있던거야."
    scene ch04_beach29 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach29-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach29-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach30 at hand_camera with Dissolve(0.8)
    unknownf "아줌마가 주책이야!!"
    unknownf "추하다 추해!!"
    a "하하하."
    a "그럴줄 알았다."
    scene ch04_beach30-02 at hand_camera with Dissolve(0.8)
    unknownf ".............."
    scene ch04_beach31 at hand_camera with Dissolve(0.8)
    a "그래 애기들은 저리가서 놀아라."
    a "그래그래 어서들 꺼져."
    d "쉣.....아만다."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    scene ch04_beach32 at hand_camera with Dissolve(1.2)
    n "한적한 해변에서 아만다와 [d_name]은 따사로운 햇살을 만끽하고 있었다."
    n "그 둘은 나체의 몸으로 나란히 누워있었다."
    scene ch04_beach33 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_beach34 at hand_camera with Dissolve(1.2)
    a "허니."
    d "네?"
    a "나 선크림 좀 발라줘."
    scene ch04_beach35 at hand_camera with Dissolve(1.1)
    d "네 알겠어요."
    scene ch04_beach36 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach37 at hand_camera with Dissolve(0.8)
    d "전신 다 발라요?"
    a "당연하지."
    scene ch04_beach38 at hand_camera with Dissolve(0.8)
    a "구석구석 발라줘.."
    d "구석구석이요?........."
    a "으흥 구석구석."
    a "다 벗었다고 부끄러운건 아니지?"
    scene ch04_beach39 at hand_camera with Dissolve(0.8)
    d "하하하 부끄러울리가요."
    d "이미 우리는 볼거 못볼거 다 본 사이잖아요."
    scene ch04_beach38 at hand_camera with Dissolve(0.8)
    a "뭐야 그말은."
    a "그냥 슬쩍 본거지 뭐."
    scene ch04_beach39 at hand_camera with Dissolve(0.8)
    d "하하 그런가요?"
    d "아무튼 꼼꼼히 발라줄게요."
    a "하하 그래."
    scene ch04_beach39-01 at hand_camera with Dissolve(1.5)
    d "**(젠장......)**"
    d "**(아무리 나랑 있다지만 그녀는 너무 무방비한거 아냐?)**"
    d "**(.......)**"
    scene ch04_beach39-02 at hand_camera with Dissolve(1.5)
    pause
    $ massage_arm_back = False
    $ massage_leg_back = False
    $ massage_waist_back = False
    $ massage_done = False

    while not massage_done:

        if massage_arm_back and massage_leg_back and massage_waist_back:
            $ massage_done = True
        if not massage_done:

            menu:
                "팔에 썬크림을 바른다." if not massage_arm_back:
                    $ massage_arm_back = True
                    scene ch04_beach40 at hand_camera with Dissolve(0.8)
                    d "그거 알아요?"
                    a "응? 어떤거?"
                    d "아만다는 피부가 참 부드러워요."
                    if not in_replay:
                        $ add_point("love_amanda", 1, "love_amanda")
                    a "........"
                    d "만지면 제 기분도 좋아져요 헤헤헤."
                    scene ch04_beach41 at hand_camera with Dissolve(0.8)
                    a "하하하."
                    a "뭘 새삼스럽게 그런 말을 해."
                    d "........."
                    d "그냥 그렇다는거에요 헤헤헤."
                    a "내 나이가 몇살인데 피부가 부드럽다는거야."
                    d "진짜라니까요."
                    scene ch04_beach42 at hand_camera with Dissolve(0.8)
                    a "그럼 마음것 만지세요 아저씨."
                    d "네 알겠습니다 숙녀분."
                    play voice_f "audio/voices/milflaugh08.mp3"
                    a "하하하. 하지마 느끼해!!"
                    d "하하하."
                    scene ch04_beach41 at hand_camera with Dissolve(0.8)
                    d "........."
                    a "..........."
                    n "[d_name]의 그녀의 팔을 부드럽게 훑었다."
                    n "그녀는 가만히 그의 손의 감촉을 느꼈다."
                    n "그의 손의 감촉은 부드러움과 동시에 남자다운 힘이 느껴졌다."
                    scene ch04_beach43 at hand_camera with Dissolve(0.8)
                    n "그의 손길은 아만다에게 성적인 흥분을 불러 일으켰다."
                    play voice_f "audio/sex/milfsigh01.mp3"
                    a "으흥....좋다.."
                    a "........"
                    a "프랭크가 너 처럼 스윗했으면 얼마나 좋았을까."
                    scene ch04_beach44 at hand_camera with Dissolve(0.8)
                    a "........"
                    pause
                    a "망할 프랭크........"
                    d "......"
                    image ch04_beach_sun01:
                        "ch04_beach41" with dissolve
                        0.8
                        "ch04_beach42" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun01 at hand_camera with Dissolve(0.8)
                    pause
                    d "............"
                    image ch04_beach_sun02:
                        "ch04_beach43" with dissolve
                        0.8
                        "ch04_beach41" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun02 at hand_camera with Dissolve(0.8)
                    a "......."
                    scene ch04_beach_sun01 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach_sun02 at hand_camera with Dissolve(0.8)
                    a "......."
                    scene ch04_beach44-02 at hand_camera with Dissolve(0.8)
                    d "미안해요 아만다."
                    a "응 뭐가?"
                    d "......."
                    d "프랭크 아저씨요."
                    a "........."
                    a "니가 미안할게 뭐있어."
                    d "그냥 뭐....그런 생각이 드네요."
                    d ".........."
                    d "아만다는 더 좋은 대우를 받아야 해요."
                    a ".........."
                    a "괜찮아. 때가 되면 죽여버릴거야."
                    d "하하하."
                "다리에 썬크림을 바른다." if not massage_leg_back:
                    $ massage_leg_back = True
                    scene ch04_beach45 at hand_camera with Dissolve(2.0)
                    d "다리 바를게요."
                    a "으흥."
                    scene ch04_beach46 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach47 at hand_camera with Dissolve(0.8)
                    d "젠장...."
                    play voice_f "audio/voices/mwhat01.mp3"
                    a "뭐라고?"
                    d "**(젠장 말해버렸다.)**"
                    d "아 아무것도 아니에요."
                    a ".........."
                    scene ch04_beach48 at hand_camera with Dissolve(0.8)
                    a "왜 무슨 말이 하고싶은데?"
                    scene ch04_beach48-02 at hand_camera with Dissolve(0.8)
                    d "네?"
                    d "아 잠시 딴생각 했었어요."
                    a "뭐야 무슨 중요한 일인데 선크림 바르다말고 딴 생각을해."
                    a "싱겁기는.."
                    scene ch04_beach49 at hand_camera with Dissolve(0.8)
                    a "왜 하고싶은 말 있음 편하게 해."
                    a "우리 둘 사이에 못할 말이 뭐가 있니. 안그래?"
                    d ".........."
                    d "근데......."
                    d "아만다는 지금 저에게 이렇게 다 보여주고 있으면 안부끄러워요?"
                    scene ch04_beach49-02 at hand_camera with Dissolve(0.8)
                    a "뭐?"
                    a "그게 무슨 말이야?"
                    a "내가 뭘 다 보여주고 있다는건데?"
                    d "아니.....그게."
                    d "............"
                    d "아만다의 그.... 그곳들이 너무나 적나라하게 보이는데요?"
                    a "뭘 말하는거야?"
                    a "내 보지?"
                    d "네?!"
                    play voice_f "audio/voices/milflaugh07.mp3"
                    a "하하하."
                    scene ch04_beach49-03 at hand_camera with Dissolve(0.8)
                    d "맙소사 아만다..."
                    a "뭐야 영어 말하는법 잊어버렸어?"
                    a "왜 확실하게 표현할 수 있는 말을 두고 빙빙 돌려서 말하는거야."
                    a "............"
                    a "그리고 나도 네걸 봤는데 너도 볼수 있는거 잖아."
                    a "누드비치에서 왜 벗었냐고 말하고 싶은거야? 하하하."
                    scene ch04_beach49 at hand_camera with Dissolve(0.8)
                    d "아 그게 아니라..."
                    d "그러니까 제 말은..."
                    a "오케이 허니. 나랑 하나 약속하자."
                    a "이 시간 이후로 답답하게 어물어물 하지말고 그냥 하고 싶은 말 해 알겠지?"
                    a "조심하는것도 좋지만 그렇게 말하는게 버릇되면 여자들 다 도망간다."
                    n "아만다의 그 말을 들었을 때 그는 오전의 로즈의 말을 떠올렸다."
                    n "그가 껍질에 갇힌 새 처럼 무언가 억눌려 있다는 로즈의 말과,"
                    n "답답하게 어물어물 한다는 아만다의 말이 같은 맥락이라고 생각했다."
                    d "............."
                    n "그리고 아만다의 질책은 다시 그의 자존심을 건들였다."
                    d "알겠어요 아만다."
                    menu:
                        "여기서 보는 풍경이 죽이네요.":
                            d "여기서 보는 풍경이 죽이네요."
                            scene ch04_beach49-04 at hand_camera with Dissolve(0.8)
                            a "........."
                        "아만다 보지 이쁘네요.":
                            d "아만다 보지 이쁘네요."
                            if not in_replay:
                                $ add_point("lust_amanda", 1, "lust_amanda")
                            scene ch04_beach49-04 at hand_camera with Dissolve(0.8)
                            a "맙소사...."
                            d "네..하고싶은 말 하라해서 말했어요."
                            a "......"
                    image ch04_beach_sun03:
                        "ch04_beach49" with dissolve
                        0.8
                        "ch04_beach49-02" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun03 at hand_camera with Dissolve(0.8)
                    pause
                    image ch04_beach_sun04:
                        "ch04_beach49-03" with dissolve
                        0.8
                        "ch04_beach49-02" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun04 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach_sun03 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach_sun04 at hand_camera with Dissolve(0.8)
                    pause
                "허리와 등에 썬크림을 바른다." if not massage_waist_back:
                    $ massage_waist_back = True
                    scene ch04_beach49-05 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach49-06 at hand_camera with Dissolve(0.8)
                    a "헤이!"
                    a "재미 하나도 없거든?"
                    d "하하하."
                    scene ch04_beach49-07 at hand_camera with Dissolve(0.8)
                    d "거기가 선크림 올려놓을 최적의 장소였어요."
                    d "아만다 엉덩이골이 딱 올려놓기 좋게 생겼어요."
                    a "감히 장난의 여신에게 도발을 하다니."
                    a "오늘이 가기전에 갚아 줄게 기대해."
                    scene ch04_beach50 at hand_camera with Dissolve(0.8)
                    d "..........."
                    d "근데 아만다...."
                    a "응 허니."
                    d ".........."
                    d "그날 샤워 할 때 말이에요....."
                    a "......."
                    a "집에 왔던 날?"
                    d "네 같이 샤워 했을때..."
                    scene ch04_beach51 at hand_camera with Dissolve(0.8)
                    a "응 근데?"
                    d ".........."
                    d "저 그......."
                    a "그냥 말 해."
                    a "대신 상스럽지만 않게 말하면 돼."
                    d "하.....알겠어요!!"
                    scene ch04_beach52 at hand_camera with Dissolve(0.8)
                    d "그날 제 고추를 봤었잖아요."
                    d "........"
                    d "아주 가까이서요."
                    a ".........."
                    d "그때 무슨 생각이 들었어요?"
                    d ".........."
                    scene ch04_beach52-02 at hand_camera with Dissolve(0.8)
                    a ".........."
                    a "음.....오만 생각이 다 들었지."
                    a "혼란스러움.."
                    a "부끄러움.."
                    a "충격.."
                    a "자랑스러움? 뭐 그런것들?"
                    d "........"
                    scene ch04_beach52-03 at hand_camera with Dissolve(0.8)
                    d "흥분되진 않았어요?"
                    play voice_f "audio/voices/mwhat01.mp3"
                    a "뭐?"
                    d "그 있잖아요..."
                    d "제가 아만다 앞에서 발기했었잖아요.."
                    d "그것도 아주 발딱....."
                    a ".........."
                    d "전 그때 엄청 부끄럽기도 했지만..."
                    d "..........."
                    scene ch04_beach52-02 at hand_camera with Dissolve(0.8)
                    a "부끄럽기도 했지만 뭐?"
                    d "사실 좀 흥분되기도 했었어요..."
                    if not in_replay:
                        $ add_point("lust_amanda", 1, "lust_amanda")
                    a ".........."
                    d "우리가 뭐 서스럼 없이 지내긴 했지만,"
                    d "그렇게 다 벗고, 거기다 내가 발기까지 했던적은 처음이었잖아요.."
                    d "..........."
                    d "그것도 아만다 얼굴 앞에서..."
                    scene ch04_beach53 at hand_camera with Dissolve(1.3)
                    d "그리고 순간 야한 생각을 했던거 같아요...."
                    d "........"
                    d "미안해요 아만다.."
                    d "숨기고 싶지 않았어요.."
                    d "....."
                    d "요즘.. 아니 하루 종일 섹스생각만 하는거 같아요."
                    scene ch04_beach52-04 at hand_camera with Dissolve(0.8)
                    a ".........."
                    d "미안해요..."
                    scene ch04_beach52-02 at hand_camera with Dissolve(0.8)
                    a "...."
                    a "그래...."
                    image ch04_beach_sun05:
                        "ch04_beach50" with dissolve
                        0.8
                        "ch04_beach51" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun05 at hand_camera with Dissolve(0.8)
                    pause
                    image ch04_beach_sun06:
                        "ch04_beach52" with dissolve
                        0.8
                        "ch04_beach53" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun06 at hand_camera with Dissolve(0.8)
                    a "........."
                    scene ch04_beach_sun05 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach_sun06 at hand_camera with Dissolve(0.8)
                    pause
    menu:
        "엉덩이에 썬크림을 바른다." if massage_arm_back and massage_leg_back and massage_waist_back:
            scene ch04_beach53-02 at hand_camera with Dissolve(2.0)
            pause
            scene ch04_beach55 at hand_camera with Dissolve(1.3)
            pause
            scene ch04_beach56 at hand_camera with Dissolve(0.8)
            d "**(젠장....)**"
            d "**(............)**"
            d "**(그녀는 이 자세가 부끄럽지 않은건가?)**"
            d "**(......)**"
            d "**(이 정도면 일부러 나에게 보여주는거 아닌가?)**"
            d "**(아니 그게 그러니까..)**"
            d "**(...........)**"
            d "**(이렇게 자신의 몸을 보여주면서 욕구를 해소하는게 아닐까?....)**"
            d "**(젠장...........)**"
            d "**(자꾸 나에게 하체 운동하라고 말하는게....)**"
            d "**(혹시 다른 목적이 있는거 아냐?.....)**"
            scene ch04_beach57 at hand_camera with Dissolve(0.8)
            a "다 발랐니?"
            a "돌아 누울까?"
            scene ch04_beach57-02 at hand_camera with Dissolve(0.8)
            d "아 잠깐만요."
            d "엉덩이 남았어요."
            scene ch04_beach58 at hand_camera with Dissolve(0.8)
            a "우....."
            a "역시 꼼꼼하네 꼼꼼해 헤헤."
            d "네 엉덩이를 안바르면 섭하죠."
            d "........."
            scene ch04_beach59 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfsigh01.mp3"
            a "흐응.........."
            a "기분 좋다.."
            image ch04_beach_sun07:
                "ch04_beach58" with dissolve
                0.8
                "ch04_beach59" with dissolve
                0.8
                repeat
            scene ch04_beach_sun07 at hand_camera
            pause
            scene ch04_beach60 at hand_camera with Dissolve(0.8)
            d "**(젠장......)**"
            d "**(저기에 얼굴을 파묻고 싶다..)**"
            d "**(아만다의 몸을 빨고 싶다..)**"
            scene ch04_beach61 at hand_camera with Dissolve(0.8)
            d "**(아만다가 허락하지 않을까?..)**"
            d "**(.........)**"
            d "**(지금 무슨 생각하는거냐 이 미친놈아..)**"
            image ch04_beach_sun08:
                "ch04_beach60" with dissolve
                0.8
                "ch04_beach61" with dissolve
                0.8
                repeat
            scene ch04_beach_sun08 at hand_camera
            pause
            scene ch04_beach57-02 at hand_camera with Dissolve(0.8)
            d "............"
            d "엉덩이에 더 바를까요?"
            a "으흥."
            a "좋을대로 하세요 아저씨."
            scene ch04_beach62 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach63 at hand_camera with Dissolve(0.8)
            pause
            image ch04_beach_sun09:
                "ch04_beach62" with dissolve
                0.8
                "ch04_beach63" with dissolve
                0.8
                repeat
            scene ch04_beach_sun09 at hand_camera
            pause
            n "그는 아만다의 엉덩이에 계속해서 선크림을 발라나갔다."
            pause
            n "그리고 그의 엄지손가락은 점점 그녀의 항문에 가까워졌다."
            scene ch04_beach64 at hand_camera with Dissolve(0.8)
            d "**(젠장 젠장 젠장!!)**"
            d "**(그냥 시도해볼까?)**"
            d "**(......)**"
            d "**(아만다가 화내면 실수였다고 하면 되잖아?)**"
            d "**(손이 미끄러져서 얼굴이 거기에 닿았다고.)**"
            scene ch04_beach65 at hand_camera with Dissolve(0.8)
            n "그는 아만다의 항문의 주변을 만지기 시작했다."
            n "그는 아만다의 레드라인을 확인하고 싶었다."
            n "그리고 아만다의 은밀한 곳의 경계를 만지기 시작했다."
            scene ch04_beach66 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach67 at hand_camera with Dissolve(0.8)
            d "**(쉣....)**"
            d "**(아만다의 보지가 젖었어.)**"
            d "**(내가 만져줘서 아만다가 젖었어....)**"
            scene ch04_beach68 at hand_camera with Dissolve(0.8)
            d "**(............)**"
            d "**(그녀도 지금 내가 뭔가 해주길 바라는거야..)**"
            image ch04_beach_sun10:
                "ch04_beach67" with dissolve
                0.8
                "ch04_beach68" with dissolve
                0.8
                repeat
            scene ch04_beach_sun10 at hand_camera
            a "........."
            a "**(얘 뭐하는거지?)**"
            a "**(이건 선크림 바르는게 아니잖아..)**"
            scene ch04_beach69 at hand_camera with Dissolve(0.8)
            a "..........."
            a "허니....."
            d "네?"
            a "뭐하는거니?"
            a "그건 선크림 바라는게 아니잖아?"
            a ".........."
            a "그렇게 만지고 싶으면 막 만져도 되는거야?"
            scene ch04_beach70 at hand_camera with Dissolve(0.8)
            d "아 미안해요 아만다."
            d "........"
            d "아 전 그냥..."
            d "꼼꼼히 바르려다 보니 그랬네요."
            scene ch04_beach71 at hand_camera with Dissolve(0.8)
            play voice_f "audio/voices/milflaugh07.mp3"
            a "하하하하하."
            a "농담이야."
            d "네??"
            a "너 하고싶은대로 해."
            a "뭐 만지면 닳는것도 아니고 안될게 뭐가 있겠니."
            scene ch04_beach70 at hand_camera with Dissolve(0.8)
            d "**(나 하고싶은대로 하라고??)**"
            d "**(...........)**"
            d "**(문자 그대로 하고싶은대로 하라는건가?)**"
            d "**(.......)**"
            d "**(좋아 그럼....)**"
            scene ch04_beach71 at hand_camera with Dissolve(0.8)
            menu:
                n "What should I do?"
                "그녀의 똥구멍을 활짝 벌린다.":
                    scene ch04_beach72 at hand_camera with Dissolve(0.8)
                    pause 0.5
                    scene ch04_beach73 at hand_camera with Dissolve(0.8)
                    a "너 지금 뭐하는거야? 허?"
                    if not in_replay:
                        $ add_point("lust_amanda", 1, "lust_amanda")
                    d "아니...."
                    d "아만다가 저 하고싶은대로 하라고 해서..."

    scene ch04_beach74 at hand_camera with Dissolve(1.2)
    a "**(............)**"
    a "**(얘 뭐야...)**"
    a "**(후.....)**"
    scene ch04_beach75 at hand_camera with Dissolve(0.8)
    a "고마워 허니."
    a "수고했어."
    scene ch04_beach76 at hand_camera with Dissolve(1.5)
    a "자 이제 앞에도 발라줘야지 헤헤."
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/mhuh05.mp3"
    a "허?"
    scene ch04_beach76-03 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
    a "....."
    n "그녀가 돌아누웠을 때 그녀 앞엔 또다시 발기한 [d_name]이 서 있었다."
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    n "그리고 그녀는 지난번보다 더 집중하여 그의 성기를 바라보았다."
    a "**(맙소사 [d_name].....)"
    a "............"
    a "야 넌....."
    scene ch04_beach76-03 at hand_camera with Dissolve(0.8)
    a "너무 시도 때도 없이 발기 하는거 아냐?"
    d "뭐 어쩌겠어요..."
    d "발기하는걸 막을 수도 없고 말이에요."
    d "......"
    d "아만다가 너무 섹시해서 그런거에요 하하하."
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    a "............."
    a "아무리 그래도 그렇지....."
    scene ch04_beach76-04 at hand_camera with Dissolve(0.8)
    d "오해하지 말아요."
    d "아까 아만다가 말한대로 그냥 숨김없이 얘기하는거에요."
    d "사실 아만다 생각하고 발기한적 많아요."
    scene ch04_beach76-05 at hand_camera with Dissolve(0.8)
    a "뭐?"
    a "날 생각하고 발기했었다고?"
    d "네."
    d "충격 받었어요? 하하하."
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    a "........."
    d "사실 아만다랑 섹스하는 생각도 했었어요."
    a "!!!!!!!!!!!"
    scene ch04_beach76-06 at hand_camera with Dissolve(0.8)
    a "나하고 섹스하는 생각도 했었다고?!!!!!!"
    a "맙소사 [d_name].."
    a ".............."
    a "아니 대체 어떻게 그런 생각을......"
    scene ch04_beach76-04 at hand_camera with Dissolve(0.8)
    d "아 심각하게 받아들이진 말아요.."
    d "그 뭐랄까....."
    d "뭐 그냥 자위 할때 이런저런 쓰레기 같은 생각 많이 하거든요 남자들은 하하하."
    scene ch04_beach76-08 at hand_camera with Dissolve(0.8)
    d "충격 받았다면 미안해요 아만다......"
    d "너무 솔찍하게 얘기했나요? 하하하."
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    a "나..나랑 섹스하는 생각을한다고??"
    a "............"
    d "**(젠장 괜한소리 했나....)**"
    d "**(분위기 갑자기 이상해진거 같은데...)**"
    scene ch04_beach76-02 at hand_camera with Dissolve(0.8)
    a "너......."
    a "날 생각하면서 자위 한다고?"
    a "어떻게 나 한테 그런 말을........."
    d "젠장...."
    d "미안해요 아만다...."
    scene ch04_beach76-07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh07.mp3"
    a "하하하하하하하하하."
    a "장난이야 장난."
    a "또 당하냐 그걸? 하하하하."
    a "뭐 젊은 남자가 당연히 그럴수도 있는거 아냐?"
    a "그런 상상하는건 니 자유인데 누가 뭐라고해."
    a "옆집 아줌마는 아들이 자기 팬티 냄새 맡고 자위했단다 하하."
    a "다 겪는 과정이야."
    scene ch04_beach76-09 at hand_camera with Dissolve(0.8)
    d "아만다는 그럼 저랑 섹스하는 생각 해본적 있어요?"
    a "뭐?"
    d "그러니까..."
    d "제 자지 생각?"
    a "맙소사 허니...."
    a "뭔 미친소리야 그게."
    d "생각해본적 있어요?"
    scene ch04_beach76-10 at hand_camera with Dissolve(0.8)
    a ".........."
    a "..............."
    pause
    a "그렇지 뭐..."
    a "아니 그러니까 내 말은...."
    a ".........."
    a "나도 너랑 섹스하는 생각 해본적 있어."
    a ".........."
    a "그게 그러니까 그냥 망상처럼.."
    scene ch04_beach76-11 at hand_camera with Dissolve(0.4)
    a "!!!!!!!"
    play voice_f "audio/voices/fgrunt03.mp3"
    scene ch04_beach76-12 at hand_camera with Dissolve(0.8)
    a "뭐하는거야?!!!"
    a "........"
    scene ch04_beach76-13 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
        $ add_point("sus_amanda", 1, "sus_amanda")
    d "그냥 잠시 이러고 있을까요? 헤헤."
    d "아.........."
    d "아만다를 안으면 너무 기분이 좋아요.."
    a "........"
    scene ch04_beach76-14 at hand_camera with Dissolve(0.8)
    a "넌 또라이야 그거아니?"
    d "하하하."
    a "이 미친놈."
    a "**(하........)**"
    a "**(이게 내가 필요했던 거야.....)**"
    a "**(...........)**"
    a "**(아만다 이 음흉햔 년아...정신 차려라..)**"
    unknownm "헤이 거기!!"
    scene ch04_beach76-15 at hand_camera with Dissolve(0.8)
    d "허?"
    scene ch04_beach76-16 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach76-17 at hand_camera with Dissolve(0.8)
    unknownm "이런 이런.."
    unknownm "꼬맹이 잖아."
    scene ch04_beach76-18 at hand_camera with Dissolve(0.8)
    unknownm "아~~~ 베이비~~~"
    unknownm "내 자지맛이 어때?"
    unknownm "야외에서 떡치니까 색다르지?"
    unknownf "하하하하. 하지마!!"
    scene ch04_beach76-19 at hand_camera with Dissolve(0.8)
    unknownm "방해해서 미안해."
    unknownm "행운을 빌어."
    unknownf "하하하."
    scene ch04_beach76-20 at hand_camera with Dissolve(0.8)
    a "덥다. 나에게서 떨어져 ㅎㅎ"
    scene ch04_beach76-21 at hand_camera with Dissolve(0.8)
    a "**(흐응..)**"
    scene ch04_beach77 at hand_camera with Dissolve(1.5)
    a "ㅎㅎ 쿨럭..."
    a "마져 발라주시겠어요 변태 아저씨?"
    d "네 여기 변태가 갑니다."
    a "하하하."
    a "아씨 그렇게 말하니까 갑자기 엄청 신경쓰이잖아!!"
    scene ch04_beach78 at hand_camera with Dissolve(0.8)
    pause
    $ massage_arm_front = False
    $ massage_leg_front = False
    $ massage_done = False

    while not massage_done:
        if massage_arm_front and massage_leg_front:
            $ massage_done = True
        if not massage_done:

            menu:
                "팔에 썬크림을 바른다." if not massage_arm_front:
                    $ massage_arm_front = True
                    scene ch04_beach78-02 at hand_camera with Dissolve(0.8)
                    d "그...."
                    d "음모 왁싱 했어요?"
                    a "..........."
                    a "네 맞습니다 아저씨."
                    a "비키니 입으려고 왁싱 했습니다."
                    d "그..그렇군요."
                    scene ch04_beach79 at hand_camera with Dissolve(0.8)
                    a "왜 물어봐?"
                    d "전 털이 무성한게 좋습니다 하하하."
                    a "그래?"
                    d "왠지 더 야하게 느껴지잖아요."
                    d "그렇게 적나라하게 털이 나있으면 하하하."
                    d "원초적인 모습?"
                    a ".........."
                    a "그런 취향이었군."
                    scene ch04_beach80 at hand_camera with Dissolve(0.8)
                    d "저......."
                    a ".........."
                    a "허니..그냥 말해."
                    a "한 번 더 망설이면 아나콘다에서 소심남이라고 니 별명 바꿀거야."
                    d "하하하하 알겠어요."
                    d "소심남이 되면 안되죠 하하하."
                    scene ch04_beach81 at hand_camera with Dissolve(0.8)
                    d "아만다는 마지막 섹스가 언제에요?"
                    a ".........."
                    a "와우."
                    a "이제 보니까 소심남이 아니라 급발진남으로 별명을 바꿔야 겠네."
                    d "아니 그냥 말하라면서요."
                    a "맞아 맞아. 그냥 이렇게 말하는게 훨 낫네."
                    a ".........."
                    a "내 마지막 섹스라....."
                    scene ch04_beach82 at hand_camera with Dissolve(0.8)
                    a "이런....."
                    a "기억이 안나는데?"
                    d "에이 거짓말 하지 말아요."
                    d "어떻게 그게 기억이 안날 수 있어요."
                    a "...................."
                    a "아냐 진짜야."
                    a ".........."
                    a "너도 알지 않나?"
                    a "나랑 프랭크 섹스 안한지 엄청 오래됐어."
                    d "................"
                    scene ch04_beach79 at hand_camera with Dissolve(0.8)
                    d "그..그렇군요."
                    d "......."
                    d "............"
                    a "왜 무슨 말이 하고 싶은데?"
                    d "그러니까...."
                    d "아만다도 그럼 섹스가 하고 싶겠네요?"
                    a ".........."
                    a "지금 그걸 질문이라고 하니?"
                    a "섹스가 땡기는 날도 있고 아닌 날도 있는거지."
                    scene ch04_beach80 at hand_camera with Dissolve(0.8)
                    d "저......."
                    a ".........."
                    d "아만다는 프랭크 몰래 만나는 남자 없어요?"
                    a ".........."
                    a "워워....왜 그런걸 물어보는거야?"
                    a "뭔가 저의가 느껴지는데?"
                    scene ch04_beach81 at hand_camera with Dissolve(0.8)
                    d "................"
                    d "그냥.....뭐랄까..."
                    a ".........."
                    d "전 결혼을 해본적이 없으니 모르겠지만 아만다와 프랭크는 부부잖아요.."
                    d "부부관계에서 성생활이 꽤 큰 부분을 차지한다고 들었어요."
                    d "부부라는 관계를 유지하는데도 중요하지만 뭐랄가..."
                    a ".........."
                    d "성욕은 인간의 본성 중에 하나잖아요."
                    scene ch04_beach82 at hand_camera with Dissolve(0.8)
                    d "근데 그게 만족이 안되면 정말 비극일거 같아요."
                    a ".........."
                    a "그게 내가 몰래 만나는 남자가 있는지 물어본 이유가 되는거니?"
                    d "아니 그러니까.."
                    d "제 말은...."
                    d "아만다도 사람이잖아요."
                    d "그러니까 당연히 성적인 만족감을 느끼고 싶을거 아니에요."
                    a ".........."
                    d "보통 그런 경우에 다른 방법들을 찾곤 하니까 물어본거에요......"
                    scene ch04_beach78-02 at hand_camera with Dissolve(0.8)
                    a ".........."
                    a "그런 깊은 뜻이 있었군요 아저씨."
                    d "하하하. 그렇습니다 부인."
                    scene ch04_beach83 at hand_camera with Dissolve(0.8)
                    a ".........."
                    a "**(어머나!)**"
                    a "**(얘는 이걸 못느끼고 있었나 왜 얘길 안하지?)**"
                    scene ch04_beach84 at hand_camera with Dissolve(0.8)
                    a "**(맙소사....)**"
                    a "**(..........)**"
                    a "**(진짜 단단하다...)**"
                    a "**(..........)**"
                    a "**(꽤 무거운걸....)**"
                    image ch04_beach_sun11:
                        "ch04_beach83" with dissolve
                        0.8
                        "ch04_beach84" with dissolve
                        0.8
                        repeat
                    scene ch04_beach_sun11 at hand_camera
                    pause
                    scene ch04_beach84-02 at hand_camera with Dissolve(0.8)
                    a "아 미안 하하."
                    a "손이 닿고 있는 지 몰랐어."
                    d "아 괘 괜찮아요......"
                    a "뭐가 괜찮아 이 녀석아."
                    d "뭐 좀 만진다고 닳는거 아니잖아요."
                    scene ch04_beach84-03 at hand_camera with Dissolve(0.8)
                    a ".........."
                    a "만진다고 닳는게 아니지.."
                    if massage_arm_front and massage_leg_front and massage_belly_front:
                        $ massage_done = True
                "다리에 썬크림을 바른다." if not massage_leg_front:
                    $ massage_leg_front = True
                    scene ch04_beach85 at hand_camera with Dissolve(2.0)
                    d "그.........."
                    d "좋았어요?"
                    a "응 니가 선크림 발라주니까 좋네 헤헤."
                    d "........"
                    d "아니 그게 아니라...."
                    d "........"
                    d "저랑 섹스하는 상상 해본적 있다고 했잖아요."
                    d "........"
                    d "그렇게 상상했을때....좋았어요?"
                    scene ch04_beach86 at hand_camera with Dissolve(0.8)
                    a "좋았냐는게 무슨 말이야?"
                    a ".........."
                    a "그냥 상상일 뿐이었는데 좋고 나쁘고가 어디있어....."
                    d "........"
                    d "그건 그렇죠......."
                    scene ch04_beach87 at hand_camera with Dissolve(0.8)
                    d "........"
                    d "그럼 나랑 섹스하는 생각하면서 자위 했어요?"
                    a ".........."
                    a "맙소사 [d_name].."
                    if not in_replay:
                        $ add_point("lust_amanda", 1, "lust_amanda")
                    d "........"
                    d "그냥 물어보는거에요."
                    a ".........."
                    a "........"
                    a "맞아."
                    pause
                    a "자위 했었어."
                    scene ch04_beach88 at hand_camera with Dissolve(0.8)
                    d "........"
                    d "솔찍하게 얘기 해줘서 고마워요 아만다."
                    d "......"
                    d "저도 자위하면서 아만다 생각하곤 해요."
                    a "맙소사 허니..."
                    a "날 생각하면서 자위했다고?"
                    d "......"
                    a "왜 많고 많은 여자들 중에 내 생각을 하는거야 하하하."
                    d "........"
                    d "아 물론 다른 여자들 상상도 하죠 하하하."
                    a "........."
                    scene ch04_beach85 at hand_camera with Dissolve(1.5)
                    a "주로 누굴 상상하는데?"
                    d "........"
                    d "솔찍하게 말할테니 이상한 놈이라 생각하면 안돼요 알았죠?"
                    play voice_f "audio/voices/milflaugh07.mp3"
                    a "그래 약속할게 하하하."
                    a "그렇게 말하니까 더 수상하잖아."
                    d "아니 뭐 그렇게 수상한 얘기는 아니구요.."
                    scene ch04_beach86 at hand_camera with Dissolve(0.8)
                    d "랜드레이디 생각하고요,"
                    a ".........."
                    d "대학교 교수님 생각도 하고요,"
                    d ".........."
                    d "메리 생각도 하고요....."
                    a "메리도?!!!"
                    d "네......"
                    a "와우..."
                    scene ch04_beach87 at hand_camera with Dissolve(0.8)
                    d "........"
                    d "올리비아 상상도 해요..."
                    a "그래 그럴 줄 알았다."
                    d "........"
                    d "옆집 케이티 아줌마 생각도 해요."
                    a "오마이갓...."
                    a "와우 [d_name]."
                    d "........"
                    d "프랭크 생각도 하고요."
                    a "퍽유!"
                    a "죽고싶냐?"
                    d "하하하하하하."
                    scene ch04_beach89 at hand_camera with Dissolve(0.8)
                    d "**(젠장..)**"
                    d "**(그녀 보지가 계속 움찔움찔해...)**"
                    scene ch04_beach90 at hand_camera with Dissolve(0.8)
                    n "아만다의 성기엔 애액이 흘러내렸다."
                    n "[d_name]의 손길과 그의 음란한 말들이 그녀를 흥분시키고 있었다."
                    d "..........."
                    d "아....아만다 그거 알아요?"
                    a "응? 뭐 말하는거야?"
                    d "직설적으로 말해도 돼요?"
                    a "그래 확실하게 표현해."
                    d "..........."
                    d "아만다 보지 지금 젖었어요."
                    a ".............."
                    d "제 것도 쉽게 들어가겠는데요?"
                    play voice_f "audio/voices/mhuh02.mp3"
                    a "허? 뭐라고 했지?"
                    d "제 것도 쉽게..........."
                    d "아 아니에요 잊어버려요."
                    a "...."
                    scene ch04_beach91 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach92 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch04_beach94 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/milfsigh01.mp3"
                    a "하........."
                    a "모든 스트레스가 다 날아가는거 같아."
                    a "........."
                    a "파도소리와 시원한 바람.."
                    a "그리고 사랑하는 [d_name]의 손길..."
                    a "니 손 느낌이 너무 좋다 허니...."
                    d "..........."
                    d "**(내 자지는 느낌이 더 좋을걸요..)**"

    menu:
        n "What should I do?"
        "배에 썬크림을 바른다.":
            scene ch04_beach95 at hand_camera with Dissolve(0.8)
            d "위로 올라갈게요."
            a "뭐?"
            scene ch04_beach96 at hand_camera with Dissolve(1.5)
            a "........"
            a "봤지?"
            d "뭐가요?"
            a "넌 너무 가벼워 허니..."
            a "지금 보다 두배 더 무거워져도 된다고."
            d "하하하."
            d "아만다를 쉽게 들고 섹스할 수 있을정도로 말하는거죠?"
            a "..........."
            a "미치겠다 정말..."
            a "조금전까지 어물어물 말하던 [d_name]맞니?"
            a "내 원래 [d_name]을 돌려주시겠어요 아저씨?"
            d "하하하하하."
            scene ch04_beach97 at hand_camera with Dissolve(0.8)
            a "그래....."
            a "날 쉽게 들고 떡칠 수 있으면 합격이야."
            a "......"
            a "그게 날 가질 수 있는 남자의 기준이라고...."
            scene ch04_beach98 at hand_camera with Dissolve(0.8)
            a "흐응......."
            d "..........."
            d "기분 좋아요?"
            a "......."
            a "그래."
            a "사랑하는 [d_name]이 날 만져주니까 기분이 좋아."
            d "더 기분좋게 해줄까요?"
            a "......."
            a "그게 무슨 말이야?"
            scene ch04_beach99 at hand_camera with Dissolve(0.8)
            d "..........."
            d "그러니까...."
            d "........."
            a "아저씨.."
            a "그냥 편하게 말씀하시라니까요?"
            d "........."
            n "[d_name]은 잠시 망설였다."
            n "그는 지금 이 상황을 유리하게 이용하고 싶었다."
            n "지금 자신 앞에 있는 것은 그의 보호자가 아니라 자신에게 몸을 맡긴 한명의 여성이었다."
            d "아 퍽!! 알겠어요."
            scene ch04_beach100 at hand_camera with Dissolve(0.8)
            d "성감 마사지 해줄까요?"
            a "성감 마사지?"
            a "......."
            a "지금 하고 있는게 성감 마사지 아냐?"
            d "아니 그러니까..."
            d "지금은 아만다의 성감대는 안만지고 있잖아요.."
            d ".........."
            d "내가 만져줄까요?"
            scene ch04_beach101 at hand_camera with Dissolve(0.8)
            a ".........."
            play voice_f "audio/voices/milflaugh08.mp3"
            a "하하하."
            a "어디서 줏어 들은건 있어가지고.."
            a ".........."
            a "너 마사지 하는 방법은 아니?"
            d "........"
            a "그래 해보세요 아저씨.."
            a "선은 넘지말고요."
            a "이상한 짓 하면 호적에서 파버린다."
            d "하하하하."
            scene ch04_beach100 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach102 at hand_camera with Dissolve(0.8)
            pause
            image ch04_beach_sun12:
                "ch04_beach100" with dissolve
                0.8
                "ch04_beach102" with dissolve
                0.8
                repeat
            scene ch04_beach_sun12 at hand_camera
            pause
            a ".........."
            a "이게 성감대 마사지야?"
            a "실망인데...."
            scene ch04_beach_sun12 at hand_camera
            pause
            scene ch04_beach103 at hand_camera with Dissolve(0.8)
            d ".........."
            scene ch04_beach104 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach105 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfmoanshort03.mp3" volume 0.7
            a "흐응......."
            image ch04_beach_sun13:
                "ch04_beach104" with dissolve
                0.8
                "ch04_beach105" with dissolve
                0.8
                repeat
            scene ch04_beach_sun13 at hand_camera
            a "흐응......."
            image ch04_beach_sun14:
                "ch04_beach104" with dissolve
                0.6
                "ch04_beach105" with dissolve
                0.6
                repeat
            scene ch04_beach_sun14 at hand_camera
            pause
            a "젠장........"
            scene ch04_beach106 at hand_camera with Dissolve(0.8)
            d "**(나야 말로 젠장이에요 아만다!!)**"
            d "**(젠장 어제 그 마담 사건에 이어서 지금 또 이렇게 됐네..)**"
            d "**(..............)**"
            d "**(살짝 넣어볼까?)**"
            d "**(아만다는 받아주지 않을까?)**"
            scene ch04_beach107 at hand_camera with Dissolve(0.8)
            d "**(그녀는 지금 젖었잖아...)**"
            d "**(.........)**"
            d "**(아만다도 지금 엄청 하고 싶을거 같은데?)**"
            d "**(......)**"
            d "**(............)**"
            image ch04_beach_sun15:
                "ch04_beach106" with dissolve
                0.8
                "ch04_beach107" with dissolve
                0.8
                repeat
            scene ch04_beach_sun15 at hand_camera
            pause
            a "!!!!!!!!!!"
            a "**(맙소사....)**"
            a "**(얘 지금 넣으려고 하는건가?.....)**"
            a "**(이렇게 닿고 있는걸 못느끼나...)**"
            a ".........."
            a "**(퓨..........)**"
            scene ch04_beach108 at hand_camera with Dissolve(0.8)
            a "허니?"
            d "네?"
            scene ch04_beach109 at hand_camera with Dissolve(0.8)
            a "너 지금 뭐하니?"
            a "..........."
            a "맙소사....."
            a "니 고추가 지금 어디에 있는지 알아?"
            scene ch04_beach110 at hand_camera with Dissolve(0.8)
            d "허?"
            scene ch04_beach111 at hand_camera with Dissolve(0.8)
            d "아......."
            d "미안해요."
            d ".........."
            d "이게 이렇게 돼 있는 줄 몰랐어요 헤헤."
            scene ch04_beach112 at hand_camera with Dissolve(0.8)
            a "................"
            d "........"
            n "그는 아만다의 말이 귀에 들어오지 않았다."
            n "지금 그의 눈에 들어온건 서로 닿아있는 남녀의 성기였다."
            pause
            n "그리고 둘 중 누구도 자세를 바꾸지 않았다."
            n "그리고 그는 자신의 성기를 조금씩 전진시켰다."
            scene ch04_beach113 at hand_camera with Dissolve(0.8)
            a "헤이!!"
            scene ch04_beach114 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfmoanshort06.mp3"
            pause
            image ch04_beach_sun16:
                "ch04_beach113" with dissolve
                0.8
                "ch04_beach114" with dissolve
                0.8
                repeat
            scene ch04_beach_sun16 at hand_camera
            a "**(맙소사....)**"
            a "**(얘 지금 뭐하는거지?)**"
            image ch04_beach_sun17:
                "ch04_beach112" with dissolve
                0.5
                "ch04_beach113" with dissolve
                0.5
                "ch04_beach114" with dissolve
                0.5
                "ch04_beach113" with dissolve
                0.5
                repeat
            scene ch04_beach_sun17 at hand_camera
            pause
            play sound "audio/sex/liquid01.mp3"
            scene ch04_beach115 at hand_camera with Dissolve(0.8)
            a "흐응.."
            scene ch04_beach116 at hand_camera with Dissolve(0.8)
            a "......."
            d "하.......아만다...."
            scene ch04_beach117 at hand_camera with Dissolve(0.8)
            a "맙소사 [d_name]..."
            play voice_f "audio/voices/flaugh08.mp3"
            a "뭐 하는거야 하하하."
            scene ch04_beach118 at hand_camera with Dissolve(0.8)
            a "너 미쳤어??"
            a "........."
            a "지금 나에게 삽입하려고 하는거잖아??!!"
            a "맙소사 허니......"
            a "나랑 섹스하려는거야?!!"
            a "......."
            scene ch04_beach116 at hand_camera with Dissolve(0.8)
            a "세상에..."
            a "수고했어 허니.."
            a "이제 좀 쉬자."

    scene ch04_beach119 at hand_camera with Dissolve(0.8)
    d "아직 안끝났는데요?"
    a "허?"
    menu:
        n "What should I do?"
        "성기 주변에 썬크림을 바른다.":
            scene ch04_beach120 at hand_camera with Dissolve(2.0)
            a "!!"
            play music "audio/bgm/erotic03.mp3"
            scene ch04_beach120-02 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach122 at hand_camera with Dissolve(0.8)
            pause
            scene ch04_beach121 at hand_camera with Dissolve(0.8)
            a "........."
            a "뭐하려고?...."
            scene ch04_beach122 at hand_camera with Dissolve(0.8)
            d "........"
            scene ch04_beach123 at hand_camera with Dissolve(0.8)
            pause
            image ch04_beach_sun18:
                "ch04_beach122" with dissolve
                0.7
                "ch04_beach123" with dissolve
                0.7
                repeat
            scene ch04_beach_sun18 at hand_camera
            pause
            play voice_f "audio/sex/milfmoanshort08.mp3"
            a "흐응......."
            d "기분 좋아요?"
            d "이젠 좀 성감 마사지 같아요?"
            a "......"
            scene ch04_beach120 at hand_camera with Dissolve(0.8)
            d "아만다는 자위할 때 어떤 상상해요?"
            a "......"
            a "뭘 그럴걸 물어..."
            d "궁금해요..."
            d "자위할 때 어떤 상상을 하는지....."
            a "......"
            d "그걸 알면 내가 아만다의 부족한 것을 채워줄 수도 있잖아요."
            play voice_f "audio/voices/mwhat09.mp3"
            a "뭐?!!!"
            scene ch04_beach125 at hand_camera with Dissolve(0.8)
            d "그런 상상을 할 때면 자신의 숨겨진 욕구를 반영하기도 하잖아요..."
            a "......"
            a "맙소사 [d_name]."
            a "심리학 공부를 하더니 굉장한 질문들을 하네."
            a "퓨......."
            d "전 단지...."
            d "아만다를 더 알고 싶을 뿐이에요."
            n "[d_name]의 말이 어떤걸 의미하는지 아만다는 알 수 있었다."
            pause
            n "하지만 그녀는 가만히 그의 손길을 느낄 뿐 그의 말을 제지하지 않았다."
            n "그녀는 이 모든 일들과 대화가 부적절하다는 것을 느끼고 있었지만,"
            n "확인 하고 싶었다."
            pause
            n "[d_name]에게 자신이 가지는 의미를.."
            scene ch04_beach126 at hand_camera with Dissolve(0.8)
            d "아만다는 어떤 체위가 좋은지..."
            d "얼마나 오래 하는게 좋은지...."
            a "맙소사..."
            d "........."
            d "근데......"
            d "그동안 한 대화 속에서 제가 알아차린건 있어요."
            a "........."
            a "알아차린게 뭔데?"
            scene ch04_beach127 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfmoanshort05.mp3"
            a "흐응......"
            d "........."
            d "아만다는 남자가 아만다를 완전히 지배해서 삽입하는게 좋은거죠?"
            d "남자에게 완전히 통제당한 상태에서 섹스하고 싶은거죠?"
            a "..........."
            d "예를 들면 아만다를 번쩍 들어안고 박는거 말이에요."
            scene ch04_beach128 at hand_camera with Dissolve(0.8)
            a "맙소사 허니....."
            a "........"
            a "내가 지금까지 너에게 괜한 말들을 했구나."
            a "그만해 이제."
            scene ch04_beach129 at hand_camera with Dissolve(0.8)
            d "괜한 말들이라뇨.."
            d "내가 그걸 알아차렸다 한들 뭐가 달라지겠어요."
            d "내가 뭐 진짜 아만다와 섹스할 일이 있겠어요?.."
            a "........"
            d "그냥 아만다를 조금 더 알았다는거 그거 뿐이에요."
            scene ch04_beach129-02 at hand_camera with Dissolve(0.8)
            d "............"
            d "단지 아만다를 더 알고 싶을 뿐이에요....."
            d "........"
            d "단지 아만다를 더 기분좋게 해주는 법을 알고 싶을 뿐이에요."
            d "...."
            d "아만다는 그럴 자격이 있는 여자니까요."
            scene ch04_beach130 at hand_camera with Dissolve(0.8)
            d ".........."
            d "아만다 지금 엄청 젖었네요...."
            a "........"
            a "맙소사....지금 우리 무슨 짓을 하는거야..."
            a "다 끝난거 같은데 좀 같이 쉬자 이제."
            menu:
                n "What should I do?"
                "그녀의 질 입구를 벌린다.":
                    play sound "audio/sex/liquid01.mp3"
                    scene ch04_beach131 at hand_camera with Dissolve(0.8)
                    a "!!!!!!!!!!"
            scene ch04_beach132 at hand_camera with Dissolve(0.8)
            a ".........."
            a "맙소사 [d_name]..."
            a "너 왜이래?"
            a "나 정색하고 화낸다?"
            n "아만다가 고개를 들고 자신에게 말하자,"
            n "아만다의 성기와 그 주변에 힘이 들어가는 것이 그의 손에 느껴졌다."
            scene ch04_beach133 at hand_camera with Dissolve(0.8)
            n "그는 그녀의 말에 아랑곳 하지 않고 애무를 이어나갔다."
            a ".........."
            play sound "audio/sex/liquid01.mp3"
            scene ch04_beach134 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfmoanshort09.mp3"
            a "흐응...."
            image ch04_beach_sun19:
                "ch04_beach133" with dissolve
                0.7
                "ch04_beach134" with dissolve
                0.7
                repeat
            play sound "audio/sex/liquid01.mp3" loop    
            scene ch04_beach_sun19 at hand_camera
            pause
            scene ch04_beach135 at hand_camera with Dissolve(0.8)
            d "말했잖아요.."
            d "성감대 마사지 해준다고요..."
            a ".........."
            stop sound
            scene ch04_beach136 at hand_camera with Dissolve(0.8)
            d "............."
            menu:
                "아만다와 하고 싶어요.":
                    d "아만다와 하고 싶어요...."
                    play voice_f "audio/voices/mhuh04.mp3"
                    a "허?? 뭐라고 했지?"
                    scene ch04_beach131 at hand_camera with Dissolve(0.8)
                    d "........."
                    d "넣어도 돼요?"
                    a "**(뭐??!!)**"
                    a "**(넣어도 돼냐고??)**"
                    a "**(..........)**"
                    a "**(얘가 미쳤나..)**"
                    scene ch04_beach137 at hand_camera with Dissolve(0.8)
                    pause
                    play sound "audio/sex/liquid01.mp3"
                    scene ch04_beach138 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/voices/fgrunt03.mp3"
                    a "흐윽..."
                    image ch04_beach_sun20:
                        "ch04_beach137" with dissolve
                        0.7
                        "ch04_beach138" with dissolve
                        0.7
                        repeat
                    scene ch04_beach_sun20 at hand_camera
                    pause
                    scene ch04_beach139 at hand_camera with Dissolve(0.8)
                    a "하.....허니.."
                    a "이제 충분히 발라줬어."
                    a "맙소사 [d_name]."
                    scene ch04_beach140 at hand_camera with Dissolve(1.3)
                    play voice_f "audio/voices/fsigh06.mp3"
                    a "퓨..........."
                    scene ch04_beach141 at hand_camera with Dissolve(1.3)
                    a "**(맙소사 아만다.....)**"
                    a "**(너 진짜 많이 젖었다....)**"
                    a "**(..........)**"
    scene ch04_beach142 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_beach142-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_beach143 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_beach144 at hand_camera with Dissolve(1.2)
    if not in_replay:
        $ bio_anna = True
    unknownf "내 저럴 줄 알았다. 저럴줄 알았어."
    unknownf "요망한 아줌마가 소년 노예를 하나 가지고 있네."
    unknownf "대체 몇 살 차이야 허?"
    unknownf "대체 몇 살 차이냐고."
    scene ch04_beach144-02 at hand_camera with Dissolve(0.8)
    unknownf "역겨운 년."
    unknownf ".........."
    unknownf "저것봐라 저것봐."
    scene ch04_beach142 at hand_camera with Dissolve(0.8)
    unknownf "얼마나 요망한지 삽입도 안했는데 제대로 앉지도 못하네."
    unknownf "음흉한 년 같으니."
    scene ch04_beach145 at hand_camera with Dissolve(0.8)
    unknownf "오 저 불쌍한 꼬마녀석."
    unknownf "저 훌륭한 물건을 넣을데가 없네."
    unknownf "그냥 저 마녀 보지에 넣어서 혼줄을 내주면 되는데."
    unknownf "얼마나 노예 처럼 부려 먹었으면 멈추라니까 바보 처럼 멈추고 있냐."
    scene ch04_beach142-02 at hand_camera with Dissolve(0.8)
    unknownf "..........."
    scene ch04_beach148 at hand_camera with Dissolve(0.8)
    a "이제 내가 발라줄까?"
    scene ch04_beach149 at hand_camera with Dissolve(0.8)
    d "아..아니에요 괜찮아요."
    d "난 그늘에서 음료수 마시고 쉴거에요."
    scene ch04_beach148 at hand_camera with Dissolve(0.8)
    a "그래 그럼..."
    a "난 30 분만 잘게 너도 쉬어."
    a "..........."
    jump ch04_beach_branch

label ch04_beach_branch:
    if lust_amanda >= 28:
        jump ch04_beach01_02
    else:
        jump ch04_beach02

label ch04_beach01_02:
    if not in_replay:
        $ persistent.unlock_ch04_beach01_02 = True
    $ saw_amanda_sleep_scene = True
    scene ch04_beach150 at hand_camera with Dissolve(2.0)
    a ".............."
    d "..........."
    n "그녀는 돌아누웠다."
    n "그리고 무방비 상태로 돌아누운 그녀의 하체가 그의 눈에 들어왔다."
    scene ch04_beach150-02 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "내 옆에서 나체로 잔다니 두렵지 않은거게요?"
    d "난 음흉한 남자라구요. 알잖아요 하하하."
    scene ch04_beach151 at hand_camera with Dissolve(0.8)
    n "그리고는 자신의 성기를 그녀의 성기에 가져갔다."
    n "무언가 자신의 성기에 가까이 온것을 아만다도 느끼고 이었다."
    play voice_f "audio/voices/milflaugh08.mp3"
    a "하하하."
    a "너 가끔 진짜 이상한 소리 잘하는거 알지?"
    a "방해하지 말고 저리가."
    d "음......"
    d "그냥 그렇다는거에요 하하."
    scene ch04_beach152 at hand_camera with Dissolve(0.8)
    d "**(음......)**"
    a "나 좀 잘게 허니."
    a "너도 좀 쉬어."
    d "**(젠장.......)**"
    d "**(넣고 싶다.....넣고 싶다고....)**"
    d "**(하.............)**"
    scene ch04_beach152-02 at hand_camera with Dissolve(0.8)
    d "**(그녀의 보지를 벌려도 뭐라하지 않았는데....)**"
    d "**(약간 조금 더 뭔가 해도 그녀가 받아주지 않을까?...)**"
    d "**(...............)**"
    d "**(그냥....)**"
    d "**(이것도 서로 장난하는거잖아.. 그렇지?)**"
    scene ch04_beach152-03 at hand_camera with Dissolve(0.8)
    unknownf "........"
    scene ch04_beach152-02 at hand_camera with Dissolve(0.8)
    menu:
        "그녀의 항문에 삽입한다.":
            scene ch04_beach153 at hand_camera with Dissolve(0.8)
            a "?????"
            n "[d_name]은 그의 귀두를 아만다의 항문에 가져다 댔다."
            n "그녀의 질은 가려져 있었고,"
            n "자신의 애무로 그녀의 항문이 충분히 이완됐을거라 생각했다."
    scene ch04_beach153-02 at hand_camera with Dissolve(0.8)
    a "**(웟......)**"
    a "**(웟.....더.....)**"
    a "**(웟.....더.....퍽......)**"
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
        $ add_point("sus_amanda", 1, "sus_amanda")
    a "**(.............)**"
    a "**(대체 이게 무슨....)**"
    scene ch04_beach153 at hand_camera with Dissolve(0.8)
    pause
    menu:
        "고추를 조금 더 전진시킨다.":
            scene ch04_beach154 at hand_camera with Dissolve(0.8)
            pause
    scene ch04_beach153-02 at hand_camera with Dissolve(0.2)
    pause
    scene ch04_beach154 at hand_camera with Dissolve(0.8)
    menu:
        "고추를 조금 더 전진시킨다.":
            scene ch04_beach154-02 at hand_camera with Dissolve(0.8)
            pause
    n "그의 성기가 아만다의 항문을 압박하자 그녀는 형용할 수 없는 기분을 느꼈다."
    n "그 순간 그녀의 모든 감각은 그녀의 항문에 집중 되었다."
    image ch04_beach_sun21:
        "ch04_beach153" with dissolve
        0.7
        "ch04_beach154" with dissolve
        0.7
        "ch04_beach154-02" with dissolve
        0.7
        repeat
    scene ch04_beach_sun21 at hand_camera
    d "**(아 젠장....)**"
    d "**(그녀도 원하고 있어.)**"
    d "**(......)**"
    d "**(이것봐. 지금 그녀는 가만히 있잖아.)**"
    scene ch04_beach156 at hand_camera with Dissolve(0.8)
    a "야 뭐해 지금?"
    d "..........."
    scene ch04_beach156-02 at hand_camera with Dissolve(0.8)
    d "그 저....."
    d "그러니까...."
    scene ch04_beach156-03 at hand_camera with Dissolve(0.8)
    d ".........."
    d "아만다를 기분좋게 해주고 싶었어요.."
    d "그......서...성감 마시지의 연장이랄까?.."
    a "..........."
    scene ch04_beach156-02 at hand_camera with Dissolve(0.8)
    a "..........."
    a "야 그렇게 해서 그렇게 굵은게 들어가겠니?"
    d "네?"
    a "..........."
    scene ch04_beach156 at hand_camera with Dissolve(0.8)
    a "맙소사....."
    a "..........."
    a "손가락을 넣던가 아님 플러그로 좀 넓혀야지."
    a "그렇게 억지로 밀어넣으면 당연히 안들어가지 이 아저씨야."
    scene ch04_beach156-03 at hand_camera with Dissolve(0.8)
    d "아........."
    d "그 그럼...."
    d "손가락을 먼저 넣을까요?"
    a "하.........[d_name].."
    scene ch04_beach156-04 at hand_camera with Dissolve(0.8)
    a "미안하지만 나 좀 잘게 저리 가줄래?"
    d ".........."
    d "네 알겠어요.. 미안해요."
    scene ch04_beach156-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach156-05 at hand_camera with Dissolve(0.8)
    a "나 화낸다?"
    d "아 미안해요 미안해요.."
    scene ch04_beach157 at hand_camera with Dissolve(0.8)
    d "제가 잠시 정신이 나갔었나봐요..."
    a "맞아."
    a "너 지금 미친놈 같아. 알아?"
    scene ch04_beach158 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach156 at hand_camera with Dissolve(1.5)
    a "맙소사....."
    a "....."
    a "**(내가 무슨 섹스인형인줄 아나?)**"
    scene ch04_beach153-02 at hand_camera with Dissolve(1.5)
    a "....."
    a "**(애널 섹스가 해보고 싶었나?)**"
    a "**(아니 그래도 그렇지 어떻게 나에게...)**"
    a "**(.........)**"
    a "**(쟤가 미쳤나..)**"
    scene ch04_beach144-02 at hand_camera with Dissolve(1.5)
    pause
    jump ch04_beach02

label ch04_beach02:
    if not in_replay:
        $ persistent.unlock_ch04_beach02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch04_beach02_01 at hand_camera with Dissolve(1.5)
    pause
    play music "audio/bgm/erotic05.mp3"
    scene ch04_beach02_02 at hand_camera with Dissolve(1.5)
    pause 
    scene ch04_beach02_03 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach02_04 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_beach02_05 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_06 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach02_07 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_beach02_07-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_08 at hand_camera with Dissolve(0.8)
    d "**(뭐지 이 여자는?...)**"
    d "**(.......)**"
    scene ch04_beach02_09 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_10 at hand_camera with Dissolve(0.8)
    unknownf "안녕."
    scene ch04_beach02_11 at hand_camera with Dissolve(0.8)
    d "아.. 안녕..."
    d "**(왜 이리 낯이 익지?..)**"
    scene ch04_beach02_12 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_11 at hand_camera with Dissolve(0.8)
    d "허?"
    scene ch04_beach02_13 at hand_camera with Dissolve(0.8)
    d "**(젠장..)**"
    scene ch04_beach02_14 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_15 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh05.mp3"
    unknownf "후훗."
    unknownf "귀엽네."
    scene ch04_beach02_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_19 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_beach02_19-02 at hand_camera with Dissolve(0.8)
    d "뭐 하세요?"
    scene ch04_beach02_20 at hand_camera with Dissolve(0.8)
    unknownf "쉿.."
    unknownf "작게 얘기해."
    scene ch04_beach02_19-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_22 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_23 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_24 at hand_camera with Dissolve(0.8)
    unknownf "내가 선크림 발라줄게요."
    d "네?"
    scene ch04_beach02_25 at hand_camera with Dissolve(0.8)
    unknownf "그냥 가만히 있으면 돼."
    scene ch04_beach02_24 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_beach02_26 at hand_camera with Dissolve(0.8)
    unknownf "옳지."
    unknownf "그래 그렇게....."
    play music "audio/bgm/erotic06.mp3"
    image ch04_beach02_sun01:
        "ch04_beach02_24" with dissolve
        0.8
        "ch04_beach02_26" with dissolve
        0.8
        repeat
    scene ch04_beach02_sun01 at hand_camera
    d "다..당신은 누구세요?"
    d "이래도 괜찮은거에요??"
    scene ch04_beach02_26-02 at hand_camera with Dissolve(0.8)
    unknownf ".............."
    play voice_f "audio/voices/flaugh05.mp3"
    unknownf "상관 없어 헤헤."
    unknownf "니가 응당 받아야할 대우를 해주려 하는거야."
    scene ch04_beach02_27 at hand_camera with Dissolve(0.8)
    d ".........."
    d "제...제가 받아야 할 대우요??"
    unknownf "쉿!"
    scene ch04_beach02_28 at hand_camera with Dissolve(0.8)
    unknownf "그냥 가만히 있어."
    image ch04_beach02_sun02:
        "ch04_beach02_27" with dissolve
        0.8
        "ch04_beach02_28" with dissolve
        0.8
        repeat
    scene ch04_beach02_sun02 at hand_camera
    pause
    scene ch04_beach02_29 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_29-02 at hand_camera with Dissolve(0.8)
    pause
    image ch04_beach02_sun03:
        "ch04_beach02_29" with dissolve
        0.8
        "ch04_beach02_29-02" with dissolve
        0.8
        repeat
    scene ch04_beach02_sun03 at hand_camera
    pause
    unknownf "후훗"
    unknownf "마음것 만져도 돼."
    d "!!!!!"
    d "지..진짜요??"
    unknownf "그래 날 만져줘 베이비."
    menu:
        "그녀의 성기를 만진다.":
            scene ch04_beach02_30 at hand_camera with Dissolve(0.8)
            pause
    scene ch04_beach02_31 at hand_camera with Dissolve(0.8)
    unknownf "예스 베이비.."
    unknownf "그래 그렇게..."
    scene ch04_beach02_32 at hand_camera with Dissolve(0.8)
    unknownf "벌써 젖기 시작하잖아.."
    d "........"
    unknownf "확인 해봐 달링."
    d "네?!!"
    unknownf "손가락을 넣어봐."
    d "!!!!!"
    scene ch04_beach02_30 at hand_camera with Dissolve(0.8)
    menu:
        "그녀의 성기에 손가락을 넣는다.":
            play sound "audio/sex/liquid01.mp3"
            scene ch04_beach02_33 at hand_camera with Dissolve(0.8)
            n "그가 그녀의 질에 손가락을 넣자 질퍽한 소리와 오돌토돌한 촉감이 느껴졌다."
            unknownf "더 넣어봐."
            d "........"
    play sound "audio/sex/liquid01.mp3"
    scene ch04_beach02_34 at hand_camera with Dissolve(0.8)
    unknownf "예스........."
    n "그의 손가락에 그녀의 질이 움질꺼리는게 고스란히 느껴졌다."
    unknownf "더 깊게..."
    play sound "audio/sex/liquid01.mp3" volume 1.3
    scene ch04_beach02_35 at hand_camera with Dissolve(0.8)
    unknownf "아흥....."
    image ch04_beach02_sun04:
        "ch04_beach02_33" with dissolve
        0.5
        "ch04_beach02_34" with dissolve
        0.5
        "ch04_beach02_35" with dissolve
        0.5
        "ch04_beach02_34" with dissolve
        0.5
        repeat
    scene ch04_beach02_sun04 at hand_camera
    unknownf "아흥....."
    unknownf "그거 알아?"
    d "네?"
    unknownf "선크림 엿먹으라 그래."
    d "뭐라고요??"
    scene ch04_beach02_36 at hand_camera with Dissolve(0.8)
    d "!!!!!!!"
    n "그녀는 썬크림 바르는 것을 멈추고 다리를 벌려 그의 몸 위로 올라갔다."
    scene ch04_beach02_36-02 at hand_camera with Dissolve(0.8)
    d "**(마이갓!!)**"
    n "그리고 한치의 망설임도 없이 [d_name]의 성기를 붙잡았다."
    d "**(이 여자는 미쳤어..)**"
    scene ch04_beach02_37 at hand_camera with Dissolve(0.8)
    n "그리고 그녀의 음모가 그의 입을 간지럽혔다."
    n "그리고 이내 따뜻하고 촉촉한 무엇인가 자신의 성기를 감싸는 것이 느껴졌다."
    scene ch04_beach02_38 at hand_camera with Dissolve(0.8)
    d "**(............)**"
    scene ch04_beach02_39 at hand_camera with Dissolve(0.8)
    n "츄릅.."
    scene ch04_beach02_40 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort01.mp3"
    unknownf "흐응....."
    d "**(으흑.......)**"
    scene ch04_beach02_41 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag01.mp3"
    unknownf "커억....."
    d "**(젠장......)**"
    scene ch04_beach02_38 at hand_camera with Dissolve(0.8)
    d "**(이거 꿈인가?....)**"
    scene ch04_beach02_42 at hand_camera with Dissolve(0.8)
    unknownf "챱챱..."
    d "**(아..좋은 향기가 나...)**"
    d "**(그녀는 여기에도 뭔가 뿌리는건가??)**"
    scene ch04_beach02_42-02 at hand_camera with Dissolve(0.8)
    d "**(.................)**"
    scene ch04_beach02_48 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid02.mp3"
    scene ch04_beach02_47 at hand_camera with Dissolve(0.8)
    scene ch04_beach02_46 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid02.mp3"
    scene ch04_beach02_45 at hand_camera with Dissolve(0.8)
    d "읏......"
    scene ch04_beach02_44 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_43 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/gag01.mp3"
    unknownf "커억....."
    d "**(크.......)**"
    d "**(그녀의 목에 닿았어...)**"
    image ch04_beach02_bj01:
        "ch04_beach02_44"
        0.5
        "ch04_beach02_45"
        0.6
        "ch04_beach02_46"
        0.5
        "ch04_beach02_47"
        0.5
        "ch04_beach02_48"
        0.6
        "ch04_beach02_45"
        0.5
        repeat
    scene ch04_beach02_bj01 at hand_camera
    pause
    play voice_f "audio/sex/oral03.mp3" volume 1.6 loop 
    d "**(흐윽.......)**"
    scene ch04_beach02_50 at hand_camera with Dissolve(0.8)
    d "**(아 젠장.....)**"
    d "**(그녀의 입속으로 빨려들어갈거 같아!!)**"
    scene ch04_beach02_bj01 at hand_camera
    d "**(흐윽.......)**"
    image ch04_beach02_bj02:
        "ch04_beach02_43" with dissolve
        0.6
        "ch04_beach02_44" with dissolve
        0.6
        repeat
    scene ch04_beach02_bj02 at hand_camera
    pause
    d "**(쉣!!!!!)**"
    unknownf "커억....."
    d "**(아.......)**"
    d "**(이게 능숙한 여자의 테크닉이구나....)**"
    d "**(...........)**"
    d "**(메리와는 차원이 달라..)**"
    image ch04_beach02_bj03:
        "ch04_beach02_45" with dissolve
        0.6
        "ch04_beach02_46" with dissolve
        0.6
        repeat
    scene ch04_beach02_bj03 at hand_camera
    pause
    d "**(흐응......)**"
    d "**(그녀는 너무나 능숙해.....)**"
    image ch04_beach02_bj04:
        "ch04_beach02_45" with dissolve
        0.6
        "ch04_beach02_46" with dissolve
        0.6
        "ch04_beach02_45" with dissolve
        0.6
        "ch04_beach02_46" with dissolve
        0.6
        "ch04_beach02_43" with dissolve
        0.6
        "ch04_beach02_44" with dissolve
        0.6
        "ch04_beach02_43" with dissolve
        0.6
        "ch04_beach02_44" with dissolve
        0.6
        repeat
    scene ch04_beach02_bj04 at hand_camera
    play voice_f "audio/sex/oral04.wav" volume 2.0 loop 
    pause
    d "**(아..........)**"
    image ch04_beach02_bj01:
        "ch04_beach02_44" with dissolve
        0.3
        "ch04_beach02_45" with dissolve
        0.4
        "ch04_beach02_46" with dissolve
        0.3
        "ch04_beach02_47" with dissolve
        0.3
        "ch04_beach02_48" with dissolve
        0.4
        "ch04_beach02_45" with dissolve
        0.3
        "ch04_beach02_44" with dissolve
        0.3
        repeat
    scene ch04_beach02_bj01 at hand_camera
    pause
    scene ch04_beach02_50-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/milfmoanshort05.mp3"
    unknownf "아흑....."
    unknownf "예스 베이비 예스!!"
    scene ch04_beach02_50-03 at hand_camera with Dissolve(0.8)
    unknownf "날 먹어치워줘 달링."
    n "챱챱"
    n "쪽쪽"
    scene ch04_beach02_50-04 at hand_camera with Dissolve(1.3)
    pause
    n "한산한 시골의 해변에서.."
    n "[d_name]은 아만다의 옆에서 낯선 여자에게 구강성교를 받고 있었다."
    n "아만다가 깨어날지도 모르는 불안함은 성기로 부터 전해지는 쾌감에 잊혀져 갔다."
    image ch04_beach02_bj04-02:
        "ch04_beach02_48-02"
        0.2
        "ch04_beach02_48-03"
        0.2
        "ch04_beach02_48-04"
        0.2
        "ch04_beach02_48-05"
        0.2
        "ch04_beach02_48-06"
        0.2
        "ch04_beach02_48-03"
        0.2
        "ch04_beach02_48-02" with dissolve
        0.4
        "ch04_beach02_48-01" with dissolve
        0.4
        "ch04_beach02_48-02" with dissolve
        0.4
        "ch04_beach02_48-01" with dissolve
        0.4
        repeat
    scene ch04_beach02_bj04-02 at hand_camera
    play voice_f "audio/sex/oral03.mp3" volume 2.0 loop 
    pause
    d "**(아 젠장.....)**"
    d "**(이렇게 빨리는건 처..처음이야....)**"
    d "**(.........)**"
    d "**(빨려들어가는거 같아.....하....)**"
    scene ch04_beach02_50-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_50-05 at hand_camera with Dissolve(0.8)
    d "푸하......."
    unknownf "흐응........"
    stop voice_f
    scene ch04_beach02_51 at hand_camera with Dissolve(1.3)
    d "........"
    d "..........."
    d "**(끝난건가?.......)"
    d "....."
    d "**(더 해주지 좀 아쉬운데...)**"
    scene ch04_beach02_52 at hand_camera with Dissolve(0.8)
    d "**(!!!)"
    n "그가 아쉬워 하던 사이 그의 성기에 무언가 감싸지는 감촉을 느꼈다."
    scene ch04_beach02_53 at hand_camera with Dissolve(0.8)
    unknownf "............."
    d ".........."
    scene ch04_beach02_53-02 at hand_camera with Dissolve(0.8)
    n "그가 고개를 들었을 때 그녀는 그의 성기에 콘돔을 씌우고 있었다."
    unknownf "**(젠장 이 콘돔 작은 사이즈였잖아....)**"
    unknownf "**(급하게 사느라 확인을 못했네.)**"
    unknownf "**(뭐 상관 없어..)**"
    scene ch04_beach02_54 at hand_camera with Dissolve(0.8)
    n "그리고 그녀는 그의 성기를 잡고 삽입하기 시작했다."
    d "홀리 쉣!!"
    unknownf "쉬~~~"
    unknownf "그냥 가만히 즐겨 헤헤."
    scene ch04_beach02_52 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_54 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_54-02 at hand_camera with Dissolve(0.8)
    unknownf "맙소사...."
    unknownf "너 진짜 두껍다."
    scene ch04_beach02_55 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_56 at hand_camera with Dissolve(0.8)
    unknownf "흐응......"
    d "**(아....들어간다..)**"
    scene ch04_beach02_55 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    unknownf "예스...."
    play sound "audio/sex/liquid02.mp3"
    scene ch04_beach02_57 at hand_camera with Dissolve(0.8)
    d "**(아...........)**"
    play music "audio/bgm/erotic01.mp3"
    image ch04_beach02_bj05:
        "ch04_beach02_55" with dissolve
        0.7
        "ch04_beach02_57" with dissolve
        0.7
        "ch04_beach02_55" with dissolve
        0.7
        "ch04_beach02_57" with dissolve
        0.7
        "ch04_beach02_58" with dissolve
    scene ch04_beach02_bj05 at hand_camera
    pause
    play sound "audio/sex/liquid02.mp3"
    scene ch04_beach02_58 at hand_camera with Dissolve(0.8)
    unknownf "아흥....."
    scene ch04_beach02_59 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_60 at hand_camera with Dissolve(0.8)
    unknownf "**(예스 예스 예스......)**"
    unknownf "**(생각보다 훨씬 훌륭해..)**"
    scene ch04_beach02_61 at hand_camera with Dissolve(0.8)
    unknownf "**(아......)**"
    scene ch04_beach02_62 at hand_camera with Dissolve(0.8)
    unknownf "**(맙소사.....)**"
    unknownf "**(이거 진짜 좋아.....)**"
    scene ch04_beach02_63 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/sex/liquid01.mp3"
    scene ch04_beach02_63-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/sex/liquid01.mp3"
    scene ch04_beach02_63-03 at hand_camera with Dissolve(0.8)
    pause
    image ch04_beach02_sex01:
        "ch04_beach02_64-01"
        0.2
        "ch04_beach02_64-02"
        0.35
        "ch04_beach02_64-03"
        0.2
        "ch04_beach02_64-04" with dissolve
        0.35
        "ch04_beach02_64-05"
        0.2
        "ch04_beach02_64-06"
        0.2
        "ch04_beach02_64-07" with dissolve
        0.2
        repeat
    scene ch04_beach02_sex01 at hand_camera
    play sound "audio/sex/penet_long_interval.mp3" loop
    unknownf "**(예스 베이비!!)**"
    unknownf "**(날 쑤셔줘!!!)**"
    d "**(으흑....)**"
    d "**(........)**"
    d "**(아흑.......)**"
    scene ch04_beach02_65 at hand_camera with Dissolve(0.8)
    unknownf "흐응......."
    d "**(으흑....)**"
    unknownf "허윽...."
    scene ch04_beach02_sex01 at hand_camera
    pause
    image ch04_beach02_sex01-02:
        "ch04_beach02_64-01"
        0.1
        "ch04_beach02_64-02"
        0.25
        "ch04_beach02_64-03"
        0.1
        "ch04_beach02_64-04" with dissolve
        0.25
        "ch04_beach02_64-05"
        0.1
        "ch04_beach02_64-06"
        0.1
        "ch04_beach02_64-07" with dissolve
        0.1
        repeat
    scene ch04_beach02_sex01-02 at hand_camera
    play sound "audio/sex/penet_mid_interval.mp3" loop
    unknownf "**(오마이갓!!!!)**"
    unknownf "**(예스 베이비!! 예스!!)**"
    unknownf "**(날 따먹어줘!!!!!!!)**"
    image ch04_beach02_sex02:
        "ch04_beach02_64-08"
        0.1
        "ch04_beach02_64-09"
        0.1
        "ch04_beach02_64-10"
        0.1
        "ch04_beach02_64-11"
        0.1
        "ch04_beach02_64-12"
        0.1
        "ch04_beach02_64-13"
        0.1
        "ch04_beach02_64-14"
        repeat
    scene ch04_beach02_sex02 at hand_camera
    play sound "audio/sex/penet_short_interval02.mp3" loop
    unknownf "**(예스!! 예스!! 예스!!)**"
    d "**(아......)**"
    d "**(미쳤다 진짜...)**"
    d "**(..........)**"
    d "**(아........)**"
    unknownf "**(오마이갓!!!!)**"
    unknownf "**(예스 베이비!! 예스!!)**"
    image ch04_beach02_sex02-02:
        "ch04_beach02_64-01"
        0.05
        "ch04_beach02_64-02"
        0.08
        "ch04_beach02_64-03"
        0.05
        "ch04_beach02_64-04" with dissolve
        0.08
        "ch04_beach02_64-05"
        0.05
        "ch04_beach02_64-06"
        0.05
        "ch04_beach02_64-07" with dissolve
        0.05
        repeat
    scene ch04_beach02_sex02-02 at hand_camera
    play sound "audio/sex/penet_short_interval03.mp3" loop
    unknownf "**(!!!!)**"
    unknownf "**(아..........)**"
    d "**(젠장! 자지가 벌써 느낌이 오는거 같은데..)**"
    d "**(.........)**"
    d "**(젠장...)**"
    image ch04_beach02_sex02-03:
        "ch04_beach02_66"
        0.23
        "ch04_beach02_66-02"
        0.23
        repeat
    scene ch04_beach02_sex02-03 at hand_camera
    d "**(젠장...)**"
    d "**(그녀는 마치 기계 같아....)**"
    d "**(섹스기계...)**"
    pause
    image ch04_beach02_sex02-03-02:
        "ch04_beach02_66-03" with dissolve
        0.3
        "ch04_beach02_66-04" with dissolve
        0.3
        repeat
    scene ch04_beach02_sex02-03-02 at hand_camera
    d "**(쉣...)**"
    d "**(대체 이 여자는 누구지...)**"
    n "그녀의 방아찍기를 보던 그는 그녀에게 참을 수 없는 매력을 느꼈다."
    n "그는 그의 주변 모든 여성들이 이 여성과 같이 단계를 건너뛴 섹스를 했으면 좋겠다 생각했다."
    n "그녀와 계속 만나면서 섹스에 대해 가르침을 받고 싶어졌다."
    scene ch04_beach02_sex02-02 at hand_camera
    d "**(젠장 이러다 쌀거같은데?)**"
    unknownf "**(마이갓....)**"
    image ch04_beach02_sex02-01:
        "ch04_beach02_64-08"
        0.06
        "ch04_beach02_64-09"
        0.09
        "ch04_beach02_64-10"
        0.06
        "ch04_beach02_64-11"
        0.09
        "ch04_beach02_64-12"
        0.06
        "ch04_beach02_64-13"
        0.06
        "ch04_beach02_64-14"
        repeat
    scene ch04_beach02_sex02-01 at hand_camera
    play sound "audio/sex/penet_short_interval03.mp3" loop
    unknownf "**(예스!! 예스!! 예스!!)**"
    image ch04_beach02_sex02-04:
        "ch04_beach02_67" with dissolve
        0.23
        "ch04_beach02_67-02" with dissolve
        0.23
        repeat
    scene ch04_beach02_sex02-04 at hand_camera
    d "**(젠장...)**"
    unknownf "**(예스!!)**"
    unknownf "**(예스!! 예스!!)**"
    unknownf "**(예스!! 예스!! 예스!!)**"
    scene ch04_beach02_sex02-02 at hand_camera
    unknownf "**(퍽!!!!)**"
    unknownf "**(..........)**"
    scene ch04_beach02_sex02-04 at hand_camera
    d "**(으........)**"
    unknownf "**(흐윽!!!!!!!!!!!!!)**"
    stop sound
    scene ch04_beach02_67 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_67-02 at hand_camera with Dissolve(0.8)
    unknownf "**(..........)**"
    scene ch04_beach02_67-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_68 at hand_camera with Dissolve(1.5)
    unknownf "**(하아하아.....)**"
    unknownf "**(맙소사......)**"
    unknownf "**(이렇게 빨리 간적이 있었나?...)**"
    unknownf "..........."
    unknownf "너 대단하구나...."
    unknownf "........"
    unknownf "나 사랑하니?"
    d "네 사랑해요..."
    d "....."
    unknownf "나도 사랑해 달링."
    scene ch04_beach02_68-02 at hand_camera with Dissolve(0.8)
    unknownf "내 보지를 쑤셔줘....."
    unknownf "어서 내 보지를 쑤셔줘.."
    d "아..알겠어요..."
    image ch04_beach02_sex02-05:
        "ch04_beach02_69" with dissolve
        0.35
        "ch04_beach02_70" with dissolve
        0.35
        repeat
    scene ch04_beach02_sex02-05 at hand_camera
    play sound "audio/sex/penet_short_interval.mp3" loop
    unknownf "예스 베이비..."
    unknownf "예스 베이비......."
    unknownf "내 보지가 좋다고 말해줘."
    d "너의 보지는 최고에요...."
    unknownf "아흥...."
    image ch04_beach02_sex02-06:
        "ch04_beach02_70-02" with dissolve
        0.35
        "ch04_beach02_70-03" with dissolve
        0.35
        repeat
    scene ch04_beach02_sex02-06 at hand_camera
    unknownf "으흥......"
    image ch04_beach02_sex03:
        "ch04_beach02_70-04" with dissolve
        0.15
        "ch04_beach02_70-05"
        0.1
        "ch04_beach02_70-06"
        0.1
        "ch04_beach02_70-07"
        0.1
        "ch04_beach02_70-08" with dissolve
        0.15
        "ch04_beach02_70-09"
        0.1
        "ch04_beach02_70-10"
        0.1
        repeat
    scene ch04_beach02_sex03 at hand_camera
    play sound "audio/sex/penet_mid_interval.mp3" loop
    unknownf "으흥........."
    d "**(으.......)**"
    image ch04_beach02_sex03-02:
        "ch04_beach02_71" with dissolve
        0.3
        "ch04_beach02_72" with dissolve
        0.3
        repeat
    scene ch04_beach02_sex03-02 at hand_camera
    play sound "audio/sex/penet_short_interval.mp3" loop
    unknownf "아흑........"
    unknownf "**(이 놈 자지는 마술봉인가....)**"
    unknownf "**(또 갈거 같아......아......)**"
    stop sound
    play sound "audio/ambi/pop01.mp3"
    scene ch04_beach02_73
    n "탁!!"
    image ch04_beach02_sex03-03:
        "ch04_beach02_73" with dissolve
        0.3
        "ch04_beach02_74" with dissolve
        0.3
        repeat
    play sound "audio/sex/penet_short_interval.mp3" loop
    scene ch04_beach02_sex03-03 at hand_camera
    d "**(아.....뭔가 느낌이 더 좋아진거 같아.....)**"
    d "**(아 따뜻해...)**"
    image ch04_beach02_sex04:
        "ch04_beach02_70-11"
        0.1
        "ch04_beach02_70-12" with dissolve
        0.25
        "ch04_beach02_70-13"
        0.1
        "ch04_beach02_70-14" with dissolve
        0.25
        "ch04_beach02_70-15"
        0.1
        "ch04_beach02_70-16"
        0.1
        "ch04_beach02_70-17"
        0.1
        repeat
    scene ch04_beach02_sex04 at hand_camera
    play sound "audio/sex/penet_mid_interval.mp3" loop
    unknownf "**(아흑.....)**"
    unknownf "**(아...간다...또 간다....)**"
    image ch04_beach02_sex04-02:
        "ch04_beach02_70-11"
        0.05
        "ch04_beach02_70-12" with dissolve
        0.1
        "ch04_beach02_70-13"
        0.05
        "ch04_beach02_70-14" with dissolve
        0.1
        "ch04_beach02_70-15"
        0.05
        "ch04_beach02_70-16"
        0.05
        "ch04_beach02_70-17"
        0.05
        repeat
    scene ch04_beach02_sex04-02 at hand_camera
    play sound "audio/sex/penet_short_interval03.mp3" loop
    unknownf "**(으힉!!!!!!!)**"
    unknownf "**(예스~~~~~~!!!!!!)**"
    unknownf "**(...........)**"
    unknownf "**(아...............)**"
    scene ch04_beach02_75 at hand_camera with Dissolve(0.4)
    stop sound
    d "아..."
    d "쌀거 같아요.."
    scene ch04_beach02_76 at hand_camera with Dissolve(0.8)
    unknownf "가득 싸줘......"
    scene ch04_beach02_75 at hand_camera with Dissolve(0.8)
    d "아흑.."
    image ch04_beach02_sex05:
        "ch04_beach02_77"
        0.4
        "ch04_beach02_77-02"
        0.4
        repeat
    scene ch04_beach02_sex05 at hand_camera
    pause
    image ch04_beach02_sex06:
        "ch04_beach02_77"
        0.6
        "ch04_beach02_77-02"
        0.6
        repeat
    scene ch04_beach02_sex06 at hand_camera
    play sound "audio/sex/liquid02.mp3" loop
    n "그는 몸을 휘감아 오는 쾌감과 함께 가득 사정했다."
    n "그녀의 질 속이 그의 성기를 쥐어짜듯 압박했다."
    stop sound
    scene ch04_beach02_77 at hand_camera with Dissolve(0.8)
    n "그는 남김 없이 그녀의 질 속에 정액을 주입했다."
    play sound "audio/sex/liquid01.mp3"
    scene ch04_beach02_77-02 at hand_camera with Dissolve(0.8)
    d "아............"
    d "**(진공 청소기로 빨려들어가는 느낌이야..)**"
    scene ch04_beach02_78 at hand_camera with Dissolve(0.8)
    unknownf "허??!!"
    scene ch04_beach02_79 at hand_camera with Dissolve(0.8)
    unknownf "젠장!"
    scene ch04_beach02_80 at hand_camera with Dissolve(2.0)
    unknownf "**(맙소사.....)**"
    unknownf "**(.........)**"
    unknownf "**(아니 이게 언제 이렇게....)**"
    scene ch04_beach02_80-01 at hand_camera with Dissolve(0.8)
    unknownf "**(.........)**"
    unknownf "**(좀 위험한 시기인거 같은데..)**"
    unknownf "**(하........)**"
    unknownf "**(콘돔 살때 약도 샀어야 했는데 하....)**"
    unknownf "**(젠장 급하게 갔다오느라..)**"
    scene ch04_beach02_80-02 at hand_camera with Dissolve(0.8)
    d "아....미안해요.."
    scene ch04_beach02_81 at hand_camera with Dissolve(0.8)
    d "저도 그게 그렇게 된지 몰랐어요........"
    d "어..어쩌죠?"
    d "........."
    scene ch04_beach02_82 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh05.mp3"
    unknownf "헤헤 괜찮아. 괜찮아."
    unknownf "이미 벌어진 일인데 어쩔수 없지."
    scene ch04_beach02_82-02 at hand_camera with Dissolve(0.8)
    unknownf "임신하면 낳지 뭐 하하."
    d "뭐라고요?!!!"
    scene ch04_beach02_82-03 at hand_camera with Dissolve(0.8)
    unknownf "으음...."
    scene ch04_beach02_83 at hand_camera with Dissolve(0.8)
    unknownf "맙소사 너 방금 사정한거 맞니?"
    unknownf "대단하구나.."
    play sound "audio/sex/liquid01.mp3"
    scene ch04_beach02_84 at hand_camera with Dissolve(0.8)
    pause
    image ch04_beach02_sex08:
        "ch04_beach02_83" with dissolve
        0.6
        "ch04_beach02_84" with dissolve
        0.6
        repeat
    scene ch04_beach02_sex08 at hand_camera
    unknownf "아흥......"
    d "**(으........)**"
    play sound "audio/sex/liquid02.mp3"
    scene ch04_beach02_85 at hand_camera with Dissolve(0.8)
    d "!!!"
    unknownf "아......"
    unknownf "시발..."
    image ch04_beach02_sex09:
        "ch04_beach02_85" with dissolve
        0.6
        "ch04_beach02_84-02" with dissolve
        0.6
        repeat
    scene ch04_beach02_sex09 at hand_camera
    play sound "audio/sex/liquid02.mp3" loop
    unknownf "아흥......"
    d "**(으........)**"
    image ch04_beach02_sex10:
        "ch04_beach02_85" with dissolve
        0.3
        "ch04_beach02_84-02" with dissolve
        0.3
        repeat
    scene ch04_beach02_sex10 at hand_camera
    play sound "audio/sex/penet_short_interval.mp3" loop
    unknownf "예스!!!!!!!"
    d "**(으아!!!!!!!)**"
    scene ch04_beach02_85 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid02.mp3"
    unknownf "흐응..."
    scene ch04_beach02_86 at hand_camera with Dissolve(0.8)
    unknownf "..........."
    unknownf "퍽...."
    unknownf "이건 미쳤어..."
    unknownf "..........."
    play sound "audio/sex/milfmoanshort05.mp3"
    a "으음......"
    scene ch04_beach02_87 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_88 at hand_camera with Dissolve(0.8)
    unknownf "쉿.."
    scene ch04_beach02_86 at hand_camera with Dissolve(1.5)
    unknownf "일어날게."
    scene ch04_beach02_89 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach02_89-02 at hand_camera with Dissolve(0.8)
    unknownf "**(.........)**"
    unknownf "**(내가 이겼다 아줌마 하하하.)**"
    unknownf "**(날 그렇게 무안하게 하고 그냥 넘어갈 줄 알았냐?)**"
    pause
    unknownf "**(.....)**"
    unknownf "**(..........)**"
    unknownf "**(................)**"
    scene ch04_beach02_90 at hand_camera with Dissolve(0.8)
    unknownf "**(젠장.....)**"
    unknownf "**(..........)**"
    unknownf "**(복수해서 기분이 더 좋을 줄 알았는데....)**"
    unknownf "**(.........)**"
    unknownf "**(왜 기분이 더 더럽지?...)**"
    unknownf "**(.........)**"
    unknownf "**(다리가 후들거리네....)**"
    scene ch04_beach02_91 at hand_camera with Dissolve(1.5)
    d "..........."
    d "**(저 여자는 뭐지.....)**"
    d "........"
    d "**(후..........)**"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/sus07.mp3"
    scene ch04_beach02_92 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/phonering02.mp3" volume 0.7 loop
    n "전화벨이 울린다."
    scene ch04_beach02_93 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_93-02 at hand_camera with Dissolve(1.5)
    a "하 잠깐 잤더니 어지럽네....."
    scene ch04_beach02_93-03 at hand_camera with Dissolve(1.5)
    pause
    stop sound
    scene ch04_beach02_95 at hand_camera with Dissolve(1.5)
    a "안녕 나의 스윗한 여동생."
    a "무슨 일이니?"
    o "아냐 그냥 별일 없고 안부전화 한거야."
    o "오늘 [d_name]만났어?"
    a "........."
    a "어떻게 알았냐?"
    a "조짐이 보이더니 니가 드디어 마녀가 됐구나."
    o "아 뭐라는거야."
    scene ch04_beach02_95-02 at hand_camera with Dissolve(0.8)
    a "지금 해변에서 같이 쉬고 있어."
    o "아 마침 좋네."
    o "거기면 가깝지."
    scene ch04_beach02_96 at hand_camera with Dissolve(0.8)
    a "........."
    o "오늘 내 산장에서 같이 저녁 먹고 놀자."
    o "내가 몇가지 음식을 준비할거거든."
    o "간만에 자매끼리 술 한잔 하자고."
    o "어때?"
    scene ch04_beach02_97 at hand_camera with Dissolve(1.3)
    a "흠........"
    a "그래 그럼."
    a "그에게 얘기할게."
    scene ch04_beach02_96 at hand_camera with Dissolve(0.8)
    o "얘기는 무슨 얘기야."
    o "그냥 여기로 끌고와 하하하."
    o "아무튼 늦지말고 와."
    a "알겠어. 이따 봐."
    scene ch04_beach02_97 at hand_camera with Dissolve(0.8)
    a "........"
    a "뭐야 이건...."
    a "........"
    a "요즘 유행하는 자위 방법인가?"
    scene ch04_beach02_98 at hand_camera with Dissolve(0.8)
    a ".........."
    a "맙소사.."
    scene ch04_beach02_99 at hand_camera with Dissolve(1.5)
    a ".........."
    scene ch04_beach02_100 at hand_camera with Dissolve(0.8)
    a "**(대체 이게 뭐야....)**"
    a ".........."
    scene ch04_beach02_99 at hand_camera with Dissolve(0.8)
    a ".........."
    a "**(이거 콘돔이잖아.)**"
    a "**(아니 얘가 대체 이걸 왜 끼고 있어?)**"
    scene ch04_beach02_100-02 at hand_camera with Dissolve(0.8)
    a "!!"
    scene ch04_beach02_101 at hand_camera with Dissolve(0.8)
    a "**(...........)**"
    a "**(저 여자.....)**"
    a "**(어디서 본적 있었나 왜 낯이 익지?)**"
    scene ch04_beach02_100-02 at hand_camera with Dissolve(0.8)
    a "**(...........)**"
    scene ch04_beach02_102 at hand_camera with Dissolve(0.8)
    a "**(...........)**"
    n "그녀는 [d_name]의 성기를 처음으로 자세히 관찰했다."
    a "**(이거.......)**"
    a "**(발기한거야 아닌거야?.....)**"
    n "그의 성기의 크기와 색깔, 힘줄까지 가능한 자세히 관찰했다."
    a "**(...........)**"
    a "**(아님 발기하는 중인가?.....)**"
    scene ch04_beach02_103 at hand_camera with Dissolve(2.0)
    a "**(!!!!!!!!!!!!!!!)**"
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
    n "그의 성기가 그녀의 얼굴 방향으로 세워지자 요도 구멍까지 적나라하게 보여졌다."
    n "그 모습은 그녀를 성적으로 압도하기에 충분했다."
    a "**(...........)**"
    a "**(마이갓.......)**"
    a "**(이 힘줄들좀 봐..)**"
    a "**([d_name].............)**"
    scene ch04_beach02_104 at hand_camera with Dissolve(0.8)
    a "**(...........)**"
    n "그리고 이내 [d_name]이 자신에게 삽입하는 상상을 하기에 이르렀다."
    a "**(......)**"
    a "**(이걸 내 똥구멍에 쑤셔넣으려고 했었다고?!!!)**"
    a "**(......)**"
    a "**(이거 들어가기나 해?)**"
    scene ch04_beach02_105 at hand_camera with Dissolve(1.5)
    a "**(맙소사......)**"
    a "**(......)**"
    a "**(프랭크의 세 배는 되는거 같아....)**"
    scene ch04_beach02_100-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_105 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_beach02_106 at hand_camera with Dissolve(1.5)
    a "**(.....)**"
    a "**(...........)**"
    d "전화 온거 올리비야 였어요?"
    scene ch04_beach02_107 at hand_camera with Dissolve(0.2)
    play voice_f "audio/voices/fgrunt03.mp3"
    a "!!!!!!!!!!!!!!!"
    scene ch04_beach02_108 at hand_camera with Dissolve(1.5)
    d "전화 온거 올리비야 였어요?"
    a "엄.....응...."
    a "맞아."
    a "............"
    a "자기네 산장에 와서 같이 저녁먹자고 하네."
    a "같이 가자."
    d "네 좋아요."
    scene ch04_beach02_109 at hand_camera with Dissolve(1.5)
    d ".........."
    d "아만다 괜찮아요?"
    a "응 괜찮아."
    a "갑자기 일어섰더니 좀 어지러웠어."
    d "같이 옆에 좀 누울래요?"
    a "아냐 어서 자리 정리하자."
    scene ch04_beach02_111 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_beach02_112 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_beach02_113 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_beach02_114 at hand_camera with Dissolve(1.5)
    a "**(헤헤헤.)**"
    a "**(잘 가 꼬맹아.)**"
    a "**(.........)**"
    scene ch04_beach02_115 at hand_camera with Dissolve(1.5)
    a "..........."
    a "저런 음흉한 아줌마 같으니.."
    scene ch04_beach02_117 at hand_camera with Dissolve(2.0)
    pause
    play sound "audio/ambi/carleaving.mp3"
    scene ch04_beach02_118 at hand_camera with Dissolve(2.0)
    pause
    stop ambient
    jump ch04_cabin01

label ch04_cabin01:
    if not in_replay:
        $ persistent.unlock_ch04_cabin01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "An hour later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3" volume 1.5
    scene ch04_cabin01_01 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_cabin01_02 at hand_camera with Dissolve(2.0)
    pause
    play sound "audio/ambi/cararrival.mp3"
    scene ch04_cabin01_03 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/cardooropen.mp3"
    pause
    scene ch04_cabin01_04 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_04-02 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_05 at hand_camera with Dissolve(1.5)
    o "어서와."
    o "얼마전에 봤는데 한 참전에 본 느낌이네."
    scene ch04_cabin01_05-02 at hand_camera with Dissolve(1.5)
    a "뭐야?"
    a "그 옷차림은 뭐야?"
    a "아직 이혼도 안했는데 처녀로 돌아간거야?"
    a "오늘 여긴 또 어떤 남자가 왔다 갔냐?"
    scene ch04_cabin01_05-03 at hand_camera with Dissolve(0.8)
    o "쓸데없는 소리 하지마."
    o "그런거 없었어."
    o "너야 말로 지금 치마가 그게 뭐야?"
    o "길거리 창녀야?"
    a "응 맞아."
    a "신나게 매춘하다 왔어."
    d "**(맙소사....)**"
    d "**(.............)**"
    scene ch04_cabin01_06 at hand_camera with Dissolve(0.8)
    o "잘 지냈니? 헤헤."
    d "네 잘지냈어요."
    o "그 사이에 더 남자다워 졌냐?"
    d "하하 잘 모르겠어요."
    scene ch04_cabin01_07 at hand_camera with Dissolve(1.5)
    o "문자도 한 번 안보내고 뭐한거야 어?"
    o "내가 보고싶지 않았던거야?"
    d "미안해요 ㅎㅎ."
    d "이런 저런 일로 정신이 없었어요."
    scene ch04_cabin01_08 at hand_camera with Dissolve(1.5)
    d "와 맛있는 냄새가 나네요!"
    o "하하하."
    scene ch04_cabin01_09 at hand_camera with Dissolve(0.8)
    o "나 레스토랑 사장인거 잊었니?"
    o "아만다의 요리와는 차원이 다르다고 내 요리는."
    scene ch04_cabin01_10 at hand_camera with Dissolve(0.8)
    a "웃기지마."
    a "내가 안도와줬으면 넌 레스토랑 시작도 못했어."
    a "알고 떠들어라."
    scene ch04_cabin01_11 at hand_camera with Dissolve(1.5)
    a "흠......"
    a "뭔가 잘못 된 냄새가 나는걸?"
    a "........."
    a "너 제대로 요리하고 있는거 맞아?"
    scene ch04_cabin01_12 at hand_camera with Dissolve(0.8)
    o "하하하 헛소리 하지마."
    o "매일 만드는 메뉴인데 무슨 말한는거야 지금."
    o "그리고 여기 주인은 나야."
    o "참견하지 말라고."
    scene ch04_cabin01_13 at hand_camera with Dissolve(0.8)
    o "트집 잡지말고 가서 [d_name]과 쉬고 있어."
    play voice_f "audio/voices/milflaugh04.mp3"
    o "같이 그와 침대에서 껴안고 있던지 하하하."
    scene ch04_cabin01_14 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch04_cabin01_15 at hand_camera with Dissolve(1.5)
    a "운전했더니 좀 피곤하네."
    a "난 방에서 좀 쉰다."
    o "알겠어."
    o "준비 되면 부를게."
    scene ch04_cabin01_16 at hand_camera with Dissolve(1.5)
    o "이리와 허니."
    o "나 안 심심하게 옆에서 좀 떠들어."
    d "네 알겠어요 ㅎㅎ."
    scene ch04_cabin01_17 at hand_camera with Dissolve(0.8)
    o "바다는 어땠니?"
    o "오랜만에 가봤지?"
    d "네 ㅎㅎ."
    d "몇 년만에 가봤는데 진짜 많이 바뀌었더라구요."
    scene ch04_cabin01_18 at hand_camera with Dissolve(0.8)
    d "그래도 뭐 바다는 바다였어요."
    d "알잖아요 시골 동네 바다.."
    o "시골 동네 바다가 뭔데?"
    d "........."
    d "그 뭐랄까..."
    d "사람 많지 않아서 좋고 적당히 있을거 있고."
    d "개념 없는 사람들도 좀 있고 하하."
    scene ch04_cabin01_19 at hand_camera with Dissolve(0.8)
    o "하하."
    o "근데 바다는 언제가도 좋아."
    o "바다에 가면 왠지 뭔가 한 꺼풀 벗은 느낌이 들어."
    o "세상의 근심을 다 내려놓게 된다랄까..."
    d "네 맞아요."
    d "........."
    d "전 근심이랄게 딱히 없긴 하지만 하하."
    scene ch04_cabin01_20 at hand_camera with Dissolve(0.8)
    o "나도 좀 그런 느긋한 시간을 가져야 하는데.."
    o "............."
    o "레스토랑이랑 남편 문제를 동시에 해결하느라 정신이 너무 없어."
    d "아........."
    scene ch04_cabin01_21 at hand_camera with Dissolve(0.8)
    d "아저씨와는 그럼 완전히 헤어진거에요?"
    d "아니 이혼한거에요?"
    o "........"
    n "올리비아는 바로 대답하는 대신 잠시 뜸을들였다."
    pause
    n "무엇인가 생각하듯 잠시 머뭇거린 그녀는 다시 입을 열었다."
    scene ch04_cabin01_22 at hand_camera with Dissolve(0.8)
    o "아니 아직은."
    o "이혼 소송중이야."
    o "........"
    d "음......"
    d "문제가 있었던 거에요?"
    scene ch04_cabin01_22-02 at hand_camera with Dissolve(0.8)
    o "뭐 어른들의 문제랄까 하하."
    o "남편이 뭐 큰 원인 제공은 했지....."
    d "그..그렇군요..."
    o "뭐 소송은 법대로 판결이 나겠지."
    o "중요한 것은....."
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_cabin01_23 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh10.mp3"
    o "난 지금 자유롭다는거지 하하하."
    d "하하.."
    d "........."
    o "진짜 혼자 사는 삶은 천국이야."
    o "너~~~~~~무 자유로워."
    d "그..그렇겠죠 아무래도 ㅎㅎ."
    n "그녀가 [d_name]에게 팔을 올리자 그녀의 향기가 풍겨왔다."
    d "**(하.....향기롭다...)**"
    d "**(아만다와 비슷한 듯 또 다른 향기야.....)**"
    d "**(하.....)**"
    menu:
        "그녀의 허리에 손을 올린다.":
            scene ch04_cabin01_23-02 at hand_camera with Dissolve(1.5)
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
                $ add_point("love_olivia", 1, "love_olivia")
            o "........"
            n "그녀는 그가 지난번과는 사뭇 달라졌다고 생각했다."
            n "그리고 [d_name]이 그녀의 허리에 손을 올리자 올리비아는 성적인 긴장감을 느꼈다."
            o "뭐 물론 평생 혼자살긴 싫지만..."
            o "지금 당장은 그래."
            o "당분간은 자유를 즐겨야지."
            d "그렇군요..."
    menu:
        "그녀의 허리를 쓰다듬는다.":
            image ch04_cabin_01:
                "ch04_cabin01_23-03" with dissolve
                0.8
                "ch04_cabin01_23-02" with dissolve
                0.8
                repeat
    scene ch04_cabin_01 at hand_camera with Dissolve(0.8)
    d "아무튼 고생했어요 이것저것.."
    o "........"
    scene ch04_cabin01_24 at hand_camera with Dissolve(0.8)
    d "근데 갑자기 혼자 살게 돼서 외롭진 않아요?"
    d "........."
    d "특히 그 밤에 좀....."
    d "그러니까 제 말은.."
    d "여긴 좀 동네 끝이라 좀 외곽이고...."
    o "하하하."
    o "혼자 있다고 밤에 외로운거야?"
    d "네? 아니 그게.. 그러니까...."
    o "하하하. 장난이야."
    o "그러니까 여기서 같이 살자니까 나 안외롭게 헤헤."
    scene ch04_cabin01_25 at hand_camera with Dissolve(0.8)
    o "여기와서 남자 답게 날 보살펴줘."
    d "네? 하하하."
    o "!!"
    play sound "audio/ambi/hit01.mp3"
    scene ch04_cabin01_26 at hand_camera with Dissolve(0.8)
    o "웁스."
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_cabin01_27 at hand_camera with Dissolve(1.5)
    o "미안해 사과야."
    scene ch04_cabin01_28 at hand_camera with Dissolve(0.8)
    d "!!!!"
    d "**(웟 더 퍽.)**"
    scene ch04_cabin01_29 at hand_camera with Dissolve(0.8)
    o "웁스!"
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_cabin01_30 at hand_camera with Dissolve(1.1)
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    o "........"
    d "아...미안해요.."
    d "......."
    d "일부러 본건 아니었어요..."
    o "응? 하하하 괜찮아."
    scene ch04_cabin01_31 at hand_camera with Dissolve(0.8)
    d "......."
    o "내가 말했잖아."
    o "난 집에선 속옷 안입는다고."
    d "......."
    d "아...맞아요."
    d "그랬었죠.."
    d "......."
    d "전 그 말이 농담인줄 알았어요...."
    scene ch04_cabin01_30 at hand_camera with Dissolve(0.8)
    o "어떤거 같니?"
    scene ch04_cabin01_31 at hand_camera with Dissolve(0.8)
    d "네? 뭐가요?"
    scene ch04_cabin01_32 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh10.mp3"
    o "뭐긴 뭐야 니가 방금 본 거."
    d "네?!!!!!"
    o "아니다."
    o "내 보지."
    scene ch04_cabin01_32-02 at hand_camera with Dissolve(0.8)
    d "............."
    d "올리......."
    o "하하하 표현이 너무 상스럽니?"
    o "..........."
    o "너 또 그 얼빵한 표정하고 있지?"
    scene ch04_cabin01_33 at hand_camera with Dissolve(0.8)
    o "내 나이치고 소녀 처럼 이쁘지?"
    d "............."
    o "아냐? 하하하."
    o "깨끗하게 왁싱 했어야 했나 헤헤."
    scene ch04_cabin01_34 at hand_camera with Dissolve(0.8)
    d ".............."
    d "아....."
    d "제가 사실 그.... 보지를....."
    scene ch04_cabin01_35 at hand_camera with Dissolve(0.8)
    d "비교할 만큼 보..보지를 많이 보지 못해서..."
    o "뭐?"
    d "아... 근데.."
    d "올리의 보..보지는 이쁘게 생긴거 같아요.."
    scene ch04_cabin01_35-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3" volume 0.7
    o "뭐? 하하하하하."
    o "미치겠다 진짜.."
    o "넌 보면 가끔 혼란스러워."
    o "진짜 순진한건지..."
    scene ch04_cabin01_32 at hand_camera with Dissolve(0.8)
    o "아니면 고도의 목적을 가지고 순진한 척 하는건지."
    o "..........."
    o "순진한척 해서 몇 번 성공했던 경험이 있는거야?"
    scene ch04_cabin01_32-02 at hand_camera with Dissolve(0.8)
    d ".............."
    d "아니 그렇지는 않은데요......"
    scene ch04_cabin01_32 at hand_camera with Dissolve(0.8)
    o "............"
    o "야 이 바보야."
    scene ch04_cabin01_36 at hand_camera with Dissolve(0.8)
    d "저 바보 아닌데요!"
    d "자꾸 저 놀리지 마세요."
    o "바보인데 뭐 아니래."
    d "저 바보 아니라구요!!"
    o "바보 [d_name]."
    menu:
        n "What should I do?"
        "그녀를 뒤에서 껴앉는다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_36-01 at hand_camera with Dissolve(0.8)
            d "아놔 진짜!!"
            o "!!!!"
    scene ch04_cabin01_36-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
    d "저 바보 아니라구요!!"
    o ".........."
    scene ch04_cabin01_36-03 at hand_camera with Dissolve(0.8)
    o "뭐하니 꼬맹아 하하."
    d "날 바보라고 놀린거에 대한 벌이에요."
    o "훗......"
    o "벌 치고는 참 하찮네."
    scene ch04_cabin01_37 at hand_camera with Dissolve(0.8)
    o "바보 맞네 하하."
    o "[d_name]은 바보에요."
    d "아니라니까요 하하."
    scene ch04_cabin01_38 at hand_camera with Dissolve(0.8)
    o "!!"
    d "이 정도면 바보 아닌거죠?"
    d "그쵸?"
    o "......."
    scene ch04_cabin01_38-02 at hand_camera with Dissolve(0.8)
    o "..............."
    scene ch04_cabin01_38 at hand_camera with Dissolve(0.8)
    d "이래도 바보에요?"
    d "흐음...."
    menu:
        "드레스 속으로 손을 넣는다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_39 at hand_camera with Dissolve(0.8)
            o "!!!!!!!!!"
            o "야 너 뭐하는거야?"
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            d "와 올리비아도 아만다 만큼 피부가 부드럽네요."
            o "하하하 뭐라고?"
            d "제가 아직도 바보 같아요?"
            o "응 맞아."
    menu:
        "손을 더 깊히 넣는다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_40 at hand_camera with Dissolve(0.8)
            o "흐응......."
            o "........."
            o "그게 전부야 멍청아?"
            o "내 허벅지에 손이 막혔는데 뭐 어쩌라고?"
    menu:
        "손을 더 깊히 넣는다.":
            scene ch04_cabin01_41 at hand_camera with Dissolve(0.8)
            play sound "audio/voices/fhurt07.mp3"
            n "그가 손을 더 밀어넣자 그의 손가락에 까칠한 그녀의 음모가 느껴졌다."
            o "젠장!!"
            o "그만해 바보야!!"
    scene ch04_cabin01_42 at hand_camera with Dissolve(0.8)
    o "이 버릇없는 녀석 같으니."
    o "아만다 닮아가는 거냐?"
    d "바보는 멈추라는 말이 뭔지 이해를 못하겠는데요?"
    scene ch04_cabin01_43 at hand_camera with Dissolve(0.8)
    o "너 진짜 바보 맞구나."
    o "바보 변태."
    scene ch04_cabin01_44 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_45 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_46 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_46-01 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_46-02 at hand_camera with Dissolve(0.8)
    d "하하하."
    o "저리가 이제. 덥다 하하."
    scene ch04_cabin01_46-03 at hand_camera with Dissolve(0.8)
    a "다 됐니?"
    scene ch04_cabin01_47 at hand_camera with Dissolve(0.8)
    o "아 어서 앉아."
    o "마침 준비 다 됐어."
    o "[d_name]이 도와줘서 생각보다 금방 만들었네 하하."
    scene ch04_cabin01_52 at hand_camera with Dissolve(2.0)
    pause
    scene ch04_cabin01_53 at hand_camera with Dissolve(0.8)
    d "잘 먹겠습니다!"
    scene ch04_cabin01_54 at hand_camera with Dissolve(0.8)
    o "다들 맛 있게먹어."
    a "잘 먹을게."
    scene ch04_cabin01_55 at hand_camera with Dissolve(0.8)
    o "이렇게 셋이서 밥먹는게 얼마만인지 모르겠네."
    o "[d_name]이 처음 우리 패밀리에 왔을 때가 처음이자 마지막인거 같은데?"
    a "그 후로 처음이라고? 와우..."
    d "........"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch04_cabin01_56 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh10.mp3"
    o "하하하하 맙소사."
    o "그 사람들이 [d_name]보고 꼬마 노예라고 했다고? 하하하."
    scene ch04_cabin01_64 at hand_camera with Dissolve(0.8)
    d "네."
    d "다들 다 벗고 그런말을 하는게 진짜 우스워 보였어요."
    d "그 사람들도 수상해보이는건 마찬가지 였는데."
    scene ch04_cabin01_58 at hand_camera with Dissolve(0.8)
    a ".........."
    a "대체 요즘 젊은 놈들은 매너를 어디에 놓고 다니는지 참.."
    a "......."
    a "내가 그래서 활짝 열고 보여줬지."
    scene ch04_cabin01_58-02 at hand_camera with Dissolve(0.8)
    a "이거나 보고 주둥이 닥치라고."
    play voice_f "audio/voices/flaugh08.mp3"
    a "그때 그 남자놈들 표정을 니가 봤어야 해 하하하."
    a "아니다. 그때 옆에 있던 여자 얼굴을 니가 봤어야해."
    scene ch04_cabin01_59 at hand_camera with Dissolve(0.8)
    o "하하하."
    o "그렇지. 언니가 그냥 넘어갈 사람이 아니지."
    o "바로 응징을 해야지."
    o "언니의 좌우명이 눈에는 눈, 이에는 이잖아."
    scene ch04_cabin01_60 at hand_camera with Dissolve(0.8)
    o "..........."
    scene ch04_cabin01_61 at hand_camera with Dissolve(0.8)
    o "그러고 그냥 바다 구경만 하다 온거야?"
    a "아니 사건이 있었지!!"
    d "**(?????)**"
    scene ch04_cabin01_62 at hand_camera with Dissolve(0.8)
    a "그리고 [d_name]이 썬크림을 발라줬어."
    a "..........."
    a "구석구석 발라줬어."
    o "구석구석??"
    a "........"
    a "너무 구석구석 발라준게 문제였지."
    scene ch04_cabin01_63 at hand_camera with Dissolve(0.8)
    o "......."
    o "그랬구나....."
    o "**(둘다 빨개벗고 선크림을 발라줫다고? 하!)"
    pause
    o "**(아만다 아만다 아만다....)**"
    o "**(이 역겨운 쌍년!)**"
    scene ch04_cabin01_63-02 at hand_camera with Dissolve(0.8)
    a "어찌나 꼼꼼하게 발라주던지 하하하."
    a "[d_name]이 참 꼼꼼해요 그럴 때 보면..."
    a "하마터면 대사건이 일어날뻔 했다니까 하하."
    scene ch04_cabin01_63-03 at hand_camera with Dissolve(0.8)
    a "하여튼 그는 꼼지락 꼼지락 만지는거 진짜 좋아해."
    d "**(..............)**"
    a "요즘 애들은 다 그런건지 부끄러운것도 없어요."
    scene ch04_cabin01_64 at hand_camera with Dissolve(0.8)
    d "왜요? 저 부끄러움 많아요 하하."
    d "전 그냥 골고루 바르는데만 집중했을 뿐이에요."
    a "웃기지마."
    a "이 음흉한 녀석."
    scene ch04_cabin01_65 at hand_camera with Dissolve(0.8)
    o "흠........."
    o "**(그거 뿐이야?)**"
    o "**(이 둘 무슨 짓을 하고 다니는거야?)**"
    o "**(이 요망한 년.)**"
    o "**(누드 비치에 이 꼬맹이를 데리고 가?)**"
    scene ch04_cabin01_65-02 at hand_camera with Dissolve(0.8)
    o "하하."
    o "다음엔 나랑 같이 가자."
    o "알겠지?"
    scene ch04_cabin01_66 at hand_camera with Dissolve(0.8)
    d "네 ㅎㅎ......"
    jump ch04_cabin02

label ch04_cabin02:
    if not in_replay:
        $ persistent.unlock_ch04_cabin02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal11.mp3"
    scene ch04_cabin01_67 at hand_camera with Dissolve(2.0)
    n "사적인 공간에서 오랜만에 모인 그들은 즐겁게 식사를 마쳤다."
    n "아만다와 올리비아는 오랜만에 술자리를 가졌다."
    n "조금씩 취기가 올라오며 대화는 부끄러움을 모르는듯 적나라해져갔다."
    scene ch04_cabin01_68 at hand_camera with Dissolve(0.8)
    d "하....아만다..."
    d "그 얘기는 안할 수 없을까요?..."
    scene ch04_cabin01_69 at hand_camera with Dissolve(0.8)
    o "뭐?"
    o "뭐야 지금 무슨 소리 하는거야?"
    scene ch04_cabin01_71 at hand_camera with Dissolve(0.8)
    a "진짜라니까."
    a "나도 깜짝 놀랐다 정말."
    a "진짜 내 보지를 어떻게 그렇게 만져대는지.."
    a "나중엔 내 보지를 벌려보더라."
    d "하.........."
    d "제가 그럴려고 그런게 아니라..."
    scene ch04_cabin01_71-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/mwhat09.mp3"
    o "뭐??!!"
    o "[d_name]이 언니 보..보지를 벌렸다고?!!!!"
    n "올리비아는 아만다의 말을 믿을 수 없었다."
    n "아만다가 묘사하는 [d_name]의 행동은 그녀의 상상을 아득히 넘어선 것이었다."
    play sound "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_71-03 at hand_camera with Dissolve(0.8)
    a "그렇다니까."
    a "........"
    a "대체 무슨 생각인지.."
    scene ch04_cabin01_71-02 at hand_camera with Dissolve(0.8)
    o "맙소사...."
    o "둘이 지금 짜고 나 놀리는거지?"
    scene ch04_cabin01_71-03-02 at hand_camera with Dissolve(0.8)
    a "그거 뿐인 줄 아니?"
    a "선크림 바르는 척 하면서 고추를 내 보지에 들이밀더라."
    d "저기 아만다...."
    d "다...단어 선택이라도 좀 다르게 해주면 안될까요?...."
    d "그...그건 자세가 그냥 그렇게 됐을 뿐이에요."
    scene ch04_cabin01_71-02-02 at hand_camera with Dissolve(0.8)
    o ".................."
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    o "아니 왜? 어떤 상황이었는데??"
    o "........"
    o "호..혹시 둘이 같이 흥분하고 그랬던거야??"
    o "그러니까 내 말은....."
    o "둘이 지금 진도를 나가고 있는거야?"
    play sound "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_71-03 at hand_camera with Dissolve(0.8)
    a "미쳤니?"
    a "그걸 지금 질문이라고 하냐?"
    scene ch04_cabin01_71-03-02 at hand_camera with Dissolve(0.8)
    a "아 해변에 도착해서 떠날 때 까지 발기해 있더라."
    a "역시 젊은게 좋아요."
    a "한 세 시간은 됐던거 같은데."
    d "아 그런거 아니에요 제발...."
    scene ch04_cabin01_71-04 at hand_camera with Dissolve(0.8)
    d "미안해요 아만다 하......"
    d "제가 미쳤었나봐요.."
    play sound "audio/ambi/whiskey02.mp3"
    scene ch04_cabin01_71-02-03 at hand_camera with Dissolve(0.8)
    o "..................."
    o "**(이 두 사람 이미 일 저지른거아냐?)**"
    o "........"
    o "**(이미 둘이 섹스한거 아냐??)**"
    if saw_amanda_sleep_scene:
        jump ch04_cabin03
    else:
        jump ch04_cabin04

label ch04_cabin03:
    if not in_replay:
        $ persistent.unlock_ch04_cabin03 = True
    scene ch04_cabin01_71-09 at hand_camera with Dissolve(0.8)
    a "아! 그러고나서 내가 자려고 뒤돌아 누웠는데,"
    play voice_f "audio/voices/milflaugh08.mp3"
    a "하하하하."
    a "내 똥구녕에 자지를 들이밀더라."
    scene ch04_cabin01_71-10 at hand_camera with Dissolve(0.4)
    play voice_f "audio/voices/fcough04.mp3"
    o "캑캑!"
    scene ch04_cabin01_71-11 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fcough03.mp3"
    o "콜록 콜록."
    scene ch04_cabin01_71-12 at hand_camera with Dissolve(0.8)
    o "!!!!!!"
    o "뭐라고?........"
    o "......"
    n "계속되는 아만다의 말에 올리비아는 점점 현실감각을 잃어갔다."
    n "그녀역시 장난인듯 아닌듯 [d_name]에게 추파를 던지고 있었지만,"
    n "아만다와 [d_name]의 행동은 그녀에게도 큰 충격이었다."
    o "언니 하...항문에 뭘 들이밀었다고??!!"
    o "......"
    o "진짜 그런거야 [d_name]?!!"
    scene ch04_cabin01_71-04-02 at hand_camera with Dissolve(0.8)
    d "........"
    d "그..그건....."
    d "하....."
    d "........"
    d "아만다를 기분 좋게 해주려고........"
    d "그러니까......"
    d "나방이 불빛에 이끌리듯 그랬달까....."
    scene ch04_cabin01_71-12 at hand_camera with Dissolve(0.8)
    o "나방이 불빛에 이끌리듯??"
    o "........"
    o "맙소사........"
    scene ch04_cabin01_71-05 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh08.mp3"
    a "하하하."
    a "내가 어이 없어서 쳐다보는데도 기어이 넣어보려고 얼마나 노력을 하던지 하하하."
    a "내가 무슨 섹스인형이냐? 하하하하."
    scene ch04_cabin01_71-04-02 at hand_camera with Dissolve(0.8)
    d "아 그러니까 그건......"
    d "꼭 넣으려고 했다기보다는.....그러니까..."
    d "하........"
    d "제가 미쳤었나봐요......"
    d "그러니까 그건......"
    d "일종의........"
    scene ch04_cabin01_71-12 at hand_camera with Dissolve(0.8)
    o "........"
    scene ch04_cabin01_71-04-02 at hand_camera with Dissolve(0.8)
    d "일종의..."
    d "무의식에서 나온 행동이랄까..."
    scene ch04_cabin01_71-07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh08.mp3"
    a "하하하하...."
    a "허니......"
    a "다음엔 고추에 침이라고 바르고 넣으라고 알았니?"
    o "그만해 언니!"
    d "..........."
    play sound "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_71-08-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh08.mp3"
    a "보지에 넣었으면 쑥 하고 들어갔겠지 바보야 하하하하."
    o "아만다!! 너 미쳤어?!!"
    a "하...."
    a "이 녀석이 자지를 나에게 들이밀다니.."
    a "대체 이 세상이 어떻게 돌아가는거야.."
    scene ch04_cabin01_72 at hand_camera with Dissolve(2.0)
    n "잠시 세 사람에게 정적이 흘렀다."
    n "세 사람이 얼마나 취 했는지는 알 수 없지만 각자 모두의 머릿속에 은밀한 생각을 하고 있었다."
    n "세 사람은 잠시 말을 멈추고 술잔을 들이켰다."
    jump ch04_cabin04

label ch04_cabin04:
    if not in_replay:
        $ persistent.unlock_ch04_cabin04 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch04_cabin01_72-00 at hand_camera with Dissolve(1.5)
    n "아만다와 올리비아는 연거푸 술잔을 들이켰다."
    n "테이블에 빈 술잔이 늘어가며 둘의 취기도 강해졌다."
    scene ch04_cabin01_72-01 at hand_camera with Dissolve(0.8)
    n "취기가 올라온 자매는 [d_name]은 제쳐두고 둘의 이야기를 이어갔다."
    scene ch04_cabin01_72-01-02 at hand_camera with Dissolve(0.8)
    a "아 그 얘기는 대체 언제까지 할거니?"
    a "내 장례식장에서도 할거니?"
    scene ch04_cabin01_72-02 at hand_camera with Dissolve(0.8)
    o "그러니까 언니가 [d_name]의 전여친 뭐라할 자격이 없다니까!"
    o "아니 언니야말로 옛날에 내 남친 빼았아갔었잖아."
    play voice_f "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_72-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_72-04 at hand_camera with Dissolve(0.8)
    a "하....."
    a "20년도 더 된 얘기를 지금 꺼내는 거냐?"
    scene ch04_cabin01_72-05 at hand_camera with Dissolve(0.8)
    o "이 이기적인 년!"
    a "언니한테 무슨 말버릇이야 그게 이년아!"
    scene ch04_cabin01_72-06 at hand_camera with Dissolve(0.8)
    d "........."
    scene ch04_cabin01_72-07 at hand_camera with Dissolve(0.8)
    a "그리고 말은 똑바로 해라."
    a "그때 그놈이 너랑 만난다는 말은 안하고 날 속인거라니까."
    a "내가 미친년이니 여동생과 만나는 남자랑 만나게?"
    scene ch04_cabin01_73 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh10.mp3"
    o "하하하."
    o "..............."
    o "그래도 그놈 고추는 진짜 튼실했었는데."
    play sound "audio/ambi/whiskey02.mp3"
    scene ch04_cabin01_74 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_75 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh05.mp3"
    a "후........"
    a "오늘 술 잘 받는구만."
    scene ch04_cabin01_72-06 at hand_camera with Dissolve(0.8)
    d "........."
    d "**(와 아만다 술 정말 세구나....)**"
    scene ch04_cabin01_76 at hand_camera with Dissolve(0.8)
    o "고추도 튼실했고 체력도 좋았어..."
    o "뭐 운동 선수였으니 당연하겠지 하하."
    o "내가 섹스의 즐거움을 안것도 그 놈 덕이었지 헤헤."
    scene ch04_cabin01_77 at hand_camera with Dissolve(0.8)
    d "**(.............)**"
    d "**(섹스의 즐거움....)**"
    scene ch04_cabin01_78 at hand_camera with Dissolve(0.8)
    a "흐음....."
    a "그 놈이 튼실하긴 했지."
    scene ch04_cabin01_78-02 at hand_camera with Dissolve(0.8)
    a "아마 [d_name] 크기랑 비슷했던거 같은데?"
    a "아니다 굵기는 [d_name]이 더 굵어 확실히."
    scene ch04_cabin01_79 at hand_camera with Dissolve(0.8)
    o "뭐?"
    o "[d_name] 고추가 팔뚝만해? 하하하."
    o "[d_name]이 얼마나 큰지 궁금하네."
    scene ch04_cabin01_80 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    a "후후후."
    play sound "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_80-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_81 at hand_camera with Dissolve(0.8)
    a "와우 이 술 진짜 강하네!!"
    scene ch04_cabin01_82 at hand_camera with Dissolve(0.8)
    o "강하지? 하하."
    o "이거 아무때나 꺼내는 술이 아니라고."
    o "이 집에 있는 술 중에 제일 비싼 술이야."
    o "이혼 소송 이기면 마시려고 했는데.."
    scene ch04_cabin01_83 at hand_camera with Dissolve(0.8)
    o "시간 참 빠르다.."
    o "그게 벌써 20년도 더 된 일이라니...."
    scene ch04_cabin01_84 at hand_camera with Dissolve(0.8)
    a "그치?"
    a "시간 진짜 빠르다."
    scene ch04_cabin01_85 at hand_camera with Dissolve(0.8)
    a "나도 가끔 걔 생각날 때 있거든."
    a "어디서 무슨 일하며 살고 있을까.."
    scene ch04_cabin01_86 at hand_camera with Dissolve(0.8)
    o "뭐야 갑자기 감상적이 된거야?"
    scene ch04_cabin01_87 at hand_camera with Dissolve(0.8)
    a "후후.."
    a "감상적인게 아니라 워낙 기억에 남는 일들이 많았으니 그렇지."
    a "그리고 그때가 뭐 내 인생의 꽃 같은 날들이었으니.."
    scene ch04_cabin01_88 at hand_camera with Dissolve(0.8)
    a "우리 자매랑 그 남자랑 무슨 일이 있었는지 아니?"
    d "네?"
    scene ch04_cabin01_86 at hand_camera with Dissolve(0.8)
    o "뭐 또 무슨 얘기를 꺼내려고?"
    o "하여간 언니가 술만 마시면 불안해."
    scene ch04_cabin01_88 at hand_camera with Dissolve(0.8)
    a "나랑 올리가 걔를 두고 하도 싸우고 싸우다가 결국에는.."
    a "결국 그 남자랑 쓰리...."
    scene ch04_cabin01_88-02 at hand_camera with Dissolve(0.2)
    o "!!!!!"
    scene ch04_cabin01_88-03 at hand_camera with Dissolve(0.8)
    a "읍...."
    o "!!!!!"
    scene ch04_cabin01_89 at hand_camera with Dissolve(0.8)
    a "읍...."
    scene ch04_cabin01_90 at hand_camera with Dissolve(0.8)
    o "하하하 이 사람이 별 소릴 다하네."
    o "언니가 많이 취했네."
    o "왜 일어나지도 않은 소리를 하고 있어."
    o "지금 [d_name] 앞에서 무슨 말을 하는거야."
    scene ch04_cabin01_91 at hand_camera with Dissolve(0.8)
    a "꺼져 나 안취했어!!"
    a "다시 생각해보니 그 남자 남동생까지 와서 포썸을 했었나?"
    a "내 기억이 맞지?"
    o "그런 일 없었다니까 이년아!!!"
    scene ch04_cabin01_92 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    a "하........"
    play music "audio/bgm/erotic12.mp3"
    scene ch04_cabin01_92-01 at hand_camera with Dissolve(2.0)
    a "나도 한때 날리는 여자 였다고....."
    pause
    a "나한테 줄 섰던 남자들이 한트럭이었는데..."
    a "하 내가 어쩌다 프랭크 같은 놈이랑 결혼을 해서....."
    scene ch04_cabin01_92-02 at hand_camera with Dissolve(1.5)
    pause
    n "아만다의 그 말은 올리비아의 깊은 곳을 만졌다."
    n "이혼을 앞둔 그녀로서 아만다가 처한 결혼 생활이 얼마나 힘든것인지 알고 있기 때문이었다."
    scene ch04_cabin01_92-03 at hand_camera with Dissolve(0.8)
    a "망할 프행크."
    pause
    a "야 임마 [d_name]!!"
    a "............"
    a "이 정신 나간 놈아!!!"
    d "........."
    a "너 나랑 섹스하고 싶냐?"
    scene ch04_cabin01_93 at hand_camera with Dissolve(0.8)
    d "네?....."
    scene ch04_cabin01_92-03 at hand_camera with Dissolve(0.8)
    a "............"
    a "영어 모르냐?"
    a "............"
    a "나랑 신나게 떡치고 싶냐고?"
    scene ch04_cabin01_93 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_93-02 at hand_camera with Dissolve(0.8)
    d "......"
    scene ch04_cabin01_93-03 at hand_camera with Dissolve(1.1)
    pause
    scene ch04_cabin01_93-04 at hand_camera with Dissolve(0.8)
    a "........."
    a "너 지금도 내 보지에 넣고 싶냐?"
    a "........."
    a "아니 내 똥구멍에 넣고 싶은거지?"
    o "아만다..."
    scene ch04_cabin01_93 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch04_cabin01_93-05 at hand_camera with Dissolve(0.8)
    a "나랑 자고 싶지?"
    a "아냐 너 지금 올리비아랑 떡 치고 싶은거지?"
    d ".............."
    a "요즘 어린애들은 섹스가 그냥 스포츠잖아? 맞지?"
    a "섹스먼저 하고 사귈까 말까 결정한다며?"
    a ".........."
    a "여기서 같이 떡 칠까?"
    scene ch04_cabin01_93 at hand_camera with Dissolve(1.1)
    n "아만다의 말에 그는 당혹감을 감출 수 없었다."
    pause
    n "하지만 동시에 내심 그런 일들이 일어나길 바랬다."
    n "그리고 그 짧은 순간 만약 그런 일들이 실제로 일어난다면,"
    n "지금 이 자리에 있는 이 세명의 관계는 어떻게 되는것인지와 같은,"
    n "지극히 현실적이며 동시에 쓸데없는 걱정을 했다."
    scene ch04_cabin01_93-06 at hand_camera with Dissolve(0.8)
    o "맙소사...."
    scene ch04_cabin01_93-07 at hand_camera with Dissolve(0.8)
    o "너 많이 취했어 아만다."
    o "언니가 좀 피곤한가보다."
    o "들어가서 좀 쉬자."
    scene ch04_cabin01_94 at hand_camera with Dissolve(0.8)
    a "주둥아리 닥쳐 올리..."
    a "이 좆이면 환장하는 년아."
    scene ch04_cabin01_94-02 at hand_camera with Dissolve(0.8)
    o "............"
    scene ch04_cabin01_94-03 at hand_camera with Dissolve(0.8)
    o "그래?"
    o "지금 같이 떡칠까?"
    d "???!!!"
    o "어때?"
    o "우릴 방해할 내 남편이나 프랭크도 없는데 어때?"
    o "아무도 없는 이 산속에서 신나게 떡치자고."
    o "좋네. 술마시고 떡치고 술마시고 떡치고.."
    o "............"
    o "어서 벗어 아만다."
    o "그럼 나도 벗을게."
    scene ch04_cabin01_94 at hand_camera with Dissolve(0.8)
    a "......."
    a "닥쳐 미친년아."
    scene ch04_cabin01_94-04 at hand_camera with Dissolve(0.8)
    a "난 미치지 않았어."
    a "........."
    a "근데 너희 둘은 미쳤으니 오늘 밤 무슨 일이 일어나도 일어나겠네 안그래?!!"
    a "........."
    a "이 망할 세상..."
    a "대체 어디까지 타락한거야 이 세상은.."
    scene ch04_cabin01_94-05 at hand_camera with Dissolve(1.5)
    a "욱.."
    scene ch04_cabin01_94-06 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_94-07 at hand_camera with Dissolve(1.5)
    d "젠장......"
    d "....."
    d "내가 대체 아만다에게 무슨 짓을 한거지..."
    d "난 어떻게 생겨먹은 놈이냐....."
    jump ch04_cabin05

label ch04_cabin05:
    if not in_replay:
        $ persistent.unlock_ch04_cabin05 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch04_cabin01_95 at hand_camera with Dissolve(0.8)
    o "퓨........"
    o "굉장한 밤이네 하하하."
    n "잠시후에 아만다를 재우고 올리비아가 나타났다."
    n "그녀 역시 취했다는것을 [d_name]은 느끼고 있었다."
    n "그녀의 목소리는 평소보다 상기되어 있었다."
    scene ch04_cabin01_96 at hand_camera with Dissolve(1.5)
    o "괜찮니?"
    d "네......"
    d "아만다는 괜찮아요?"
    o "응 그녀는 잠들었어."
    o "아만다가 저렇게 취한건 처음보네."
    scene ch04_cabin01_97 at hand_camera with Dissolve(0.8)
    d "제가 아만다에게 상처를 준거 같아요."
    o "아냐아냐 괜찮아 그냥 취해서 그런거야."
    o "내일 아마 기억도 못할거야 하하."
    scene ch04_cabin01_98 at hand_camera with Dissolve(1.5)
    n "그들은 아무말 없이 잠시 나란히 앉아있었다."
    n "조용한 침묵속에 오늘 했던 대화들이 서로의 머릿속을 맴돌았다."
    o "뭐 프랭크와 이런 저런 다툼도 있었고 좀 그런 시기인거지.."
    o "............"
    pause
    o "맙소사 아만다."
    o "화끈하다 화끈해."
    o "......."
    scene ch04_cabin01_99 at hand_camera with Dissolve(0.8)
    o "아만다는 젊었을 때 정말 유명했다.."
    o "동네에서 아만다를 모르는 남자들이 없었어.."
    o "어찌나 남자들을 잘 홀리고 다녔는지.."
    o "......."
    d "..........."
    d "그랬을거 같아요."
    scene ch04_cabin01_100 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_101 at hand_camera with Dissolve(0.8)
    o "그래서 그 뒤로 경험은 없는거야?"
    o "..........."
    scene ch04_cabin01_102 at hand_camera with Dissolve(0.8)
    d "경험이요?"
    scene ch04_cabin01_102-01 at hand_camera with Dissolve(0.8)
    o "섹스 말이야."
    o "캠퍼스에서 여친과 하고나서 그 후론 없었냐고."
    scene ch04_cabin01_102 at hand_camera with Dissolve(0.8)
    d "아....."
    d "그..저......"
    scene ch04_cabin01_103 at hand_camera with Dissolve(0.8)
    o "........"
    o "난 마지막이 언제였더라?"
    o "흐흐.."
    scene ch04_cabin01_103-02 at hand_camera with Dissolve(0.8)
    d "사실은...."
    d "그게 저....."
    d "오늘 해변에서......했었어요..."
    scene ch04_cabin01_104 at hand_camera with Dissolve(0.8)
    o "........"
    scene ch04_cabin01_104-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/mwhat03.mp3"
    o "뭐?!!!!"
    scene ch04_cabin01_105 at hand_camera with Dissolve(0.8)
    o "아만다랑 해변에서 섹스했다고?!!!!"
    scene ch04_cabin01_105-02 at hand_camera with Dissolve(0.8)
    o "너 지금 진심이야??!!"
    o "오늘 아만다랑 해변에서 섹스했다고?!??"
    scene ch04_cabin01_106 at hand_camera with Dissolve(0.8)
    d "아니아니!!"
    d "그게 무슨 말이에요..제가 어떻게 아만다랑 섹스를 하겠어요?!!"
    play voice_f "audio/voices/milflaugh10.mp3"
    scene ch04_cabin01_108 at hand_camera with Dissolve(0.8)
    o "농담이야 농담 하하하..."
    d "네??"
    o "뭘 그렇게 놀라고 그래."
    scene ch04_cabin01_109 at hand_camera with Dissolve(0.8)
    o "........"
    o "아만다랑 섹스할 수도 있지 뭘 그래."
    o "아만다랑 섹스하면 세상이 멸망하는것도 아닌데."
    scene ch04_cabin01_109-02 at hand_camera with Dissolve(0.8)
    d "네?..."
    scene ch04_cabin01_109-03 at hand_camera with Dissolve(0.8)
    o "뭘 되묻고 그래."
    o "하하하. 아만다 똥구멍에 넣으려고 했다며?"
    o "아만다랑 섹스할수도 있고, 나랑도 할 수도 있고."
    o ".........."
    o "보육원 메리랑도 할수도 있고, 너의 대학교 교수랑도 할수도 있고."
    scene ch04_cabin01_109-02 at hand_camera with Dissolve(0.8)
    d "..............."
    scene ch04_cabin01_110 at hand_camera with Dissolve(0.8)
    o "너의 랜드레이디와도 할 수 있고,"
    o "너의 전여친 엄마랑도 할 수도 있고, 내 레스토랑 여자 직원이랑 섹스할수도 있는거 아냐?"
    scene ch04_cabin01_110-02 at hand_camera with Dissolve(0.8)
    d "맙소사...."
    d "그런건 야동에서나 일어나는 일인거 같은데요.."
    scene ch04_cabin01_110 at hand_camera with Dissolve(0.8)
    o ".........."
    o "근데 한 가지만 기억해."
    scene ch04_cabin01_111 at hand_camera with Dissolve(0.8)
    o "남자는 여자보다 더 섹스에 자유로워."
    o "신체적으로든 정신적으로든..."
    o "무슨 말인지 아니?"
    o "섹스할 여자를 찾기 힘든게 문제지만.."
    o "대신 여자는 섹스할 상대를 고를 수 있는 입장이지."
    o "남자는 선택 받아야 하는 입장이고."
    scene ch04_cabin01_112 at hand_camera with Dissolve(0.8)
    o "그러니까 여자에게 인기가 많더라도 아무하고나 떡치면 안되고,"
    o "인기가 없더라도 눈에 불을 켜고 찾아다녀도 추해진다고."
    scene ch04_cabin01_113 at hand_camera with Dissolve(0.8)
    o "알았니?"
    o "절대 추한 남자는 되지 말라는 소리야."
    o "그냥 오면 하는거야....."
    o "......."
    o "섹스할 상황이 되면 하는거라고."
    scene ch04_cabin01_114 at hand_camera with Dissolve(2.0)
    n "그녀는 말을 마치고 술잔을 들고 소파로 향했다."
    n "그녀의 걸음은 티를 내진 않았지만 술로 인해 어눌해져있었다."
    o "후........"
    o "그냥 자연스럽게 분위기가 만들어지면 하는거라고...."
    play sound "audio/ambi/whiskey01.mp3"
    scene ch04_cabin01_115 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_cabin01_115-02 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin01_115-03 at hand_camera with Dissolve(1.5)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch04_cabin01_115-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin01_115-04 at hand_camera with Dissolve(0.8)
    o "하 편하다....."
    o "......"
    d "졸려요?"
    o "......"
    o "조금 졸려."
    d "저도 좀 피곤하네요.."
    o "들어가서 이제 자야겠다.."
    o "..........."
    o "너 크기는 어떠니?"
    d "네?"
    o "발기는 오래가니?"
    scene ch04_cabin01_115-05 at hand_camera with Dissolve(0.8)
    d "...."
    d "발기요?"
    scene ch04_cabin01_115-06 at hand_camera with Dissolve(0.8)
    o "응 발기."
    o "내가 느끼기에 꽤 괜찮은 물건을 가지고 있는거 같은데."
    o "....."
    o "아만다가 너의 고추 얘기를 할땐 얼굴에 생기가 돌던데.."
    o "........"
    o "얼마나 너의 고추가 인상적이었길래..."
    o "맞아?"
    scene ch04_cabin01_115-07 at hand_camera with Dissolve(0.8)
    d "............"
    menu:
        n "What should I do?"
        "그녀에게 가까이 간다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_116 at hand_camera with Dissolve(1.3)
            pause
            scene ch04_cabin01_117 at hand_camera with Dissolve(1.3)
            o "??"
            scene ch04_cabin01_118 at hand_camera with Dissolve(1.3)
            n "그는 올리비아의 앞에 서서 바지 지퍼에 손을 올렸다."
            n "그리고 메리에게 자신의 성기를 처음 보여줬던 날을 떠올리며 형용할 수 없는 흥분을 느꼈다."
            n "그리고 지금 올리비아는 술에 취해있다는 것이 그를 더 흥분하게 했다."
            menu:
                "고추를 꺼내서 그녀에게 보여준다.":
                    scene ch04_cabin01_119 at hand_camera with Dissolve(1.3)
                    play sound "audio/ambi/zipper.mp3"
                    pause
            scene ch04_cabin01_120 at hand_camera with Dissolve(1.3)
            play sound "audio/ambi/fabric02.mp3"
            o "..........."
            scene ch04_cabin01_121 at hand_camera with Dissolve(1.3)
            n "그녀가 눈을 뜨자 그녀의 앞에 [d_name]의 발기한 성기가 있었다."
            n "잠에들었다 깼다를 반복하던 그녀에게 이것이 현실이라는 것을 인지하기 까지 약간의 시간이 필요했다."
            scene ch04_cabin01_121-02 at hand_camera with Dissolve(1.3)
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            n "[d_name]의 성기는 그녀가 상상했던 것 보다 더 튼실했다."
            n "그가 바지를 내리고 잠시후에 그의 체취가 올리비아에게 전해졌다."
            scene ch04_cabin01_122 at hand_camera with Dissolve(0.8)
            d "어때요?"
            d "이 정도면 여자들이 만족할까요?"
            scene ch04_cabin01_122-02 at hand_camera with Dissolve(0.8)
            d "..............."
            scene ch04_cabin01_123 at hand_camera with Dissolve(0.8)
            o "맙소사 [d_name]........"
            play sound "audio/voices/fsigh06.mp3"
            o "지금 뭐 하......"
            scene ch04_cabin01_125 at hand_camera with Dissolve(0.8)
            o "나 지금 그렇게 많이 취하진 않았거든?"
            o "......."
            o "후......너 진짜 바보였구나."
            scene ch04_cabin01_124 at hand_camera with Dissolve(0.8)
            d "저도 오늘 올리비아거 봤잖아요."
            d "............"
            d "뭐 비긴샘이죠."
            d "어때요?"
            d "꽤 괜찮은 물건인거 같아요?"
            d "........."
            scene ch04_cabin01_120 at hand_camera with Dissolve(0.8)
            pause
            o "괜찮은 물건 같냐고?"
            o "......."
            o ".........."
            scene ch04_cabin01_120-02 at hand_camera with Dissolve(0.8)
            n "선명한 정신의 평소 그녀 였다면 그녀는 아무말도 하지 않았을 것이다."
            pause
            n "하지만 술에 취한 그녀는 [d_name]의 성기를 잠시 관찰했다."
            n "그리고 빨라지는 호흡을 억누르고 차분히 그의 성기를 평가했다."
            scene ch04_cabin01_120 at hand_camera with Dissolve(0.8)
            o "훌륭해."
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            o "..........."
            o "훌륭해 허니...."
            o "........"
            scene ch04_cabin01_123 at hand_camera with Dissolve(0.8)
            o "하지만 어리숙해...."
            o "물건은 훌륭한데 넌 너무 어리숙하다고..."
            scene ch04_cabin01_128 at hand_camera with Dissolve(0.8)
            d "그게 무슨 말이에요?"
            o "........."
            o "좆 크기는 나중 문제야....."
            o "그 전엔 오로지 분위기라고..."
            o "어리숙해 보이는 남자에게 박히고 싶은 여자는 이 세상에 없어."
            o "그렇게 여자에게 자지만 들이민다고 다 되는게 아니라고."
            o "크기 보다는 분위기라고...."
            o "......"
            o "크기 보다는 분위기야.."
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_129 at hand_camera with Dissolve(1.5)
            play sound "audio/voices/fsigh06.mp3"
            o "휴.........."
            o "맙소사 [d_name]..."
            scene ch04_cabin01_129-02 at hand_camera with Dissolve(1.3)
            pause
            scene ch04_cabin01_129-03 at hand_camera with Dissolve(1.3)
            o "**(.........)**"
            o "**(맙소사.......)**"
            o "**(....)**"
            scene ch04_cabin01_129-04 at hand_camera with Dissolve(1.3)
            d "......."
            d "............."
            d "하하..왜 그렇게 쳐다봐요?..."
            scene ch04_cabin01_129-05 at hand_camera with Dissolve(1.3)
            pause
            scene ch04_cabin01_129-06 at hand_camera with Dissolve(1.3)
            o "아만다 방해하지 말고 다른 방에 가서 자."
            scene ch04_cabin01_130 at hand_camera with Dissolve(1.3)
            d ".........."
            scene ch04_cabin01_131 at hand_camera with Dissolve(1.3)
            pause
        "작지는 않은거 같아요 하하.":

            scene ch04_cabin01_131-02 at hand_camera with Dissolve(0.8)
            d "작지는 않은거 같아요 하하."
            if not in_replay:
                $ add_point("love_olivia", 1, "love_olivia")
            scene ch04_cabin01_132 at hand_camera with Dissolve(0.8)
            o "하하하 그래?"
            o "자신 있나보네."
            scene ch04_cabin01_133 at hand_camera with Dissolve(0.8)
            d "지금 확인 해볼래요?"
            o "........."
            d "꺼내볼까요?"
            scene ch04_cabin01_134 at hand_camera with Dissolve(0.8)
            o "............."
            o "흐음......지금은 말고..."
            play sound "audio/ambi/fabric01.mp3"
            scene ch04_cabin01_134-02 at hand_camera with Dissolve(1.5)
            o "아 졸리다....."
            scene ch04_cabin01_135 at hand_camera with Dissolve(0.8)
            o ".........."
            pause
            o "[d_name]..."
            o "[d_name]..[d_name].."
            o "[d_name]..[d_name]..[d_name].."
            scene ch04_cabin01_135-02 at hand_camera with Dissolve(1.5)
            o "나중에 볼 기회가 있겠지."
            scene ch04_cabin01_136 at hand_camera with Dissolve(1.5)
            o "아만다 방해하지 말고 다른 방에 가서 자."
            o "알겠지?"
            scene ch04_cabin01_137 at hand_camera with Dissolve(1.5)
            d "네 알겠어요."
            d "잘 자요 올리."
            scene ch04_cabin01_130 at hand_camera with Dissolve(1.1)
            d ".........."
            scene ch04_cabin01_131 at hand_camera with Dissolve(1.1)
            pause
            jump ch04_cabin06

label ch04_cabin06:
    if not in_replay:
        $ persistent.unlock_ch04_cabin06 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "At midnight" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night04.mp3"
    scene ch04_cabin02_00 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_cabin02_01 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_cabin02_01-02 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_cabin02_02 at hand_camera with Dissolve(1.3)
    pause
    scene ch04_cabin02_03 at hand_camera with Dissolve(1.3)
    d "............."
    d "젠장 지금 몇시지?"
    d "잠이 안온다 잠이 안와...."
    scene ch04_cabin02_04 at hand_camera with Dissolve(0.8)
    d "하........"
    scene ch04_cabin02_05 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_06 at hand_camera with Dissolve(1.2)
    d "이름 모를 그대여....."
    d "......."
    d "몇 살 쯤 됐을까...."
    d "30대?"
    d "40대?"
    scene ch04_cabin02_07 at hand_camera with Dissolve(1.2)
    d "......."
    d "그녀가 내 인생에서 섹스한 두번째 여자군..."
    scene ch04_cabin02_08 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_04-02 at hand_camera with Dissolve(0.8)
    d "퓨........"
    scene ch04_cabin02_09 at hand_camera with Dissolve(0.8)
    d "........"
    d "그 여자에게 연락처라도 물어봤어야 했는데..."
    d "....."
    d "아쉽군....."
    scene ch04_cabin02_10 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_13 at hand_camera with Dissolve(1.5)
    pause
    scene ch04_cabin02_14 at hand_camera with Dissolve(1.2)
    n "Hehe."
    scene ch04_cabin02_15 at hand_camera with Dissolve(0.8)
    n "그가 물을 마실때 밖에서 희미한 웃음 소리가 들려왔다."
    scene ch04_cabin02_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch04_cabin02_17 at hand_camera with Dissolve(1.2)
    n "야외의 파티오엔 올리비아가 앉아 있었다."
    scene ch04_cabin02_18 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_19 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_20 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_21 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_21-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_22 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_22-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_23 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_24 at hand_camera with Dissolve(1.2)
    pause
    scene ch04_cabin02_25 at hand_camera with Dissolve(1.2)
    pause
    hide screen top_ui_buttons
    jump ch05_cabin01
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
