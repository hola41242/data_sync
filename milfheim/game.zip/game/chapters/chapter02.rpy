init python:
    def fix_v01_save():
        
        for s in ["v01_mary_bj01_manual", "v01_mary_bj02_manual"]:
            renpy.hide_screen(s)
        
        
        store.dissolve = dissolve_nonskip
        store.fade = fade_nonskip
        config.dismiss_blocking_transitions = False
        store._dismiss_pause = False
        
        
        renpy.restart_interaction()


label after_load:
    $ fix_v01_save()
    return

default ch02_started = False

label ch02_droom01:
    $ ch02_started = True
    if not in_replay:
        $ persistent.unlock_ch02_droom01 = True

    if not in_replay:
        $ fix_v01_save()


    if not in_replay:
        $ create_phone_channel("celine_dm", "Celine",
            ["Celine", phone_config["phone_player_name"]],
            "phone/icons/celine.png")

        $ create_phone_channel("helen_dm", "Helen",
            ["Helen", phone_config["phone_player_name"]],
            "phone/icons/helen.png")

    scene chapter02_start with Dissolve(2.0)
    pause
    play music "audio/bgm/normal11.mp3"

    if not in_replay:
        $ send_phone_message("Jason", "Yo bro. How’s the boarding house?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Feels like a hotel suite, haha.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "What, got some pretty lady staff there or something?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Figures. You’re always thinking about women.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Says the hypocrite.?", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Man, I miss Professor Sophia.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Come visit this neighborhood sometime. The landlady here is really nice.You can crash in my room.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Landlady? Is she hot?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "You’d lose your mind if you saw her, lol.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Shit. Give me the address right now.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "lol, enjoy dorm life. I’ll call you.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Hey, I’m always ready, man. ", "jason_dm", do_pause=False)

        $ send_phone_message("Celin", "Hey.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Hm?", "celine_dm", do_pause=False)
        $ send_phone_message("Celin", "When you came here the other day, did something happen with Mary?", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Something? No, nothing happened.", "celine_dm", do_pause=False)
        $ send_phone_message("Celin", "Hmm…", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Why?", "celine_dm", do_pause=False)
        $ send_phone_message("Celin", "Mary just seemed a bit off, so I was wondering if something was going on.", "celine_dm", do_pause=False)
        $ send_phone_message("Celin", "Anyway, let’s grab a drink.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Of course. Just tell me when you’re free!!", "celine_dm", do_pause=False)
        $ send_phone_message("Celin", "Okay. I’ll get in touch.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Sounds good. ", "celine_dm", do_pause=False)

        $ send_phone_message("Helen", "images/phone/media/helen01.jpg", "helen_dm", 2, summary_alt="helen Photo", do_pause=False)
        $ send_phone_message("Helen", "I’ll use this photo as your profile picture, haha.", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Okay. But my expression looks kind of awkward...", "helen_dm", do_pause=False)
        $ send_phone_message("Helen", "How about trying a bigger smile next time?", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yes, I will!!", "helen_dm", do_pause=False)
        $ send_phone_message("Helen", "Alright, haha. Good night.", "helen_dm", do_pause=False)
        $ send_phone_message("Helen", "Are you at home by any chance?", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yes, I’m on the second floor!", "helen_dm", do_pause=False)
        $ send_phone_message("Helen", "I’m really sorry, but could you check if there’s an SD card on the table in my room?", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Just a moment.", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yes, it’s here.", "helen_dm", do_pause=False)
        $ send_phone_message("Helen", "Oh thank goodness… thank you!!", "helen_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "No problem!", "helen_dm", do_pause=False)


    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/16_thumb.webp",
            "phone": "images/phone/shots/16.webp",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/17_thumb.webp",
            "phone": "images/phone/shots/17.webp",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/18_thumb.webp",
            "phone": "images/phone/shots/18.webp",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/19_thumb.webp",
            "phone": "images/phone/shots/19.webp",
        })

    scene 01lecture_387 with dissolve
    show screen top_ui_buttons
    pause
    scene 01lecture_388 at hand_camera with dissolve
    pause
    scene ch02_droom_01 with dissolve
    n "[d_name]이 눈을 뜨자 침대 가장자리에 한 여성이 속옷 차림으로 앉아있었다."
    n "그는 전혀 뜻밖의 상황으로 인해 꿈과 현실의 사이에서 머물러 있었다."
    n "그리고 잠시 시간이 흐르자 이것은 현실이라는 것을 알 수 있었다."
    scene ch02_droom_02 with dissolve
    d "저기..."
    d "헬렌?"
    scene ch02_droom_03 with dissolve
    d "!!!"
    scene ch02_droom_04 at hand_camera with Dissolve(0.8)
    d "............"
    d "저기요...놀라게 해서 미안합니다."
    d "근데..."
    d "미안하지만 누구세요?"
    scene ch02_droom_05 at hand_camera with Dissolve(0.8)
    unknownf "아 미안해요."
    unknownf "제가 다리가 불편해서 어쩔수 없이 잠시 앉았어요.일어날게요."
    scene ch02_droom_04 with dissolve
    d "............"
    n "그는 지금 어떤 상황인지 어안이 벙벙했다."
    n "그리고 그는 본능적으로 여성의 신체를 스캔했다."
    n "그리고 그는 아침 발기중임을 곧바로 느낄 수 있었다."
    scene ch02_droom_06 at hand_camera with Dissolve(0.8)
    d "!!!"
    d "(젠장. 지금은 안돼!)"
    d "(어떻게 하지?!!)"
    scene ch02_droom_07 with Dissolve(2.0)
    pause
    scene ch02_droom_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_09 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch02_droom_10 at hand_camera with Dissolve(0.8)
    unknownf "(shit)"
    play sound "audio/ambi/fabric02.mp3"
    scene ch02_droom_10-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_11 at hand_camera_zoom
    unknownf "(sigh.....)"
    d "(오오옷!!)"
    scene ch02_droom_11-02 with dissolve
    play voice_f "audio/voices/fhurt01.mp3"
    unknownf "아야!"
    scene ch02_droom_12 with dissolve
    d "저기요."
    d "제가 도와드릴게요."
    scene ch02_droom_12-02 with dissolve
    pause
    scene ch02_droom_13 at hand_camera with Dissolve(0.8)
    d "................"
    n "[d_name]의 머릿속은 카오스 였다.."
    n "처음 보는 여성이 속옷 차림으로 자신의 침대에 앉아 있었고"
    n "그는 애써 태연한 척 하느라 자신이 어떤 옷차림인지 인지하지 못했다."
    scene ch02_droom_14 with dissolve
    play voice_f "audio/voices/fshock02.mp3"
    unknownf "허?!!!!!!!!!!!"
    if not in_replay:
        $ add_point("lust_beth", 2, "lust_beth")
        $ add_point("sus_beth", 2, "sus_beth")
    scene ch02_droom_15 at hand_camera with vpunch
    pause
    play voice_f "audio/voices/fscream01.mp3" volume 0.5
    scene ch02_droom_16 with dissolve
    unknownf "꺄약! 저리가!"
    d "뭐?!!"
    scene ch02_droom_17 with vpunch
    d "알았어요 알았어요!"
    d "나는 단지..."
    scene ch02_droom_18 with dissolve
    d "(!!!)"
    scene ch02_droom_19 at hand_camera with Dissolve(0.8)
    unknownf "아..."
    scene ch02_droom_20 at hand_camera with Dissolve(0.8)
    unknownf "......"
    unknownf "너 나한테 무슨 짓을 한거야."
    d "네? 아니 전 단지.."
    scene ch02_droom_21 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fmoanshort.mp3"
    unknownf "........"
    scene ch02_droom_21-01 at hand_camera with Dissolve(0.8)
    d "괜찮아요?"
    scene ch02_droom_21-02 at hand_camera with Dissolve(0.8)
    unknownf "아니 난 그냥.."
    unknownf "너무 놀라서 나도 모르게.."
    scene ch02_droom_22 at hand_camera with Dissolve(0.8)
    d "미안해요! 제가 민게 아닌데......"
    scene ch02_droom_23 at hand_camera with Dissolve(0.8)
    d "정말 미안합니다."
    d "제 손을 잡으세요."
    scene ch02_droom_24 with dissolve
    unknownf "고마워요."
    scene ch02_droom_25 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_26 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fgrunt01.wav"
    d "네 이제 됐어요."
    scene ch02_droom_27 at hand_camera with Dissolve(0.8)
    unknownf "(하....이게 무슨 망신이람.)"
    scene ch02_droom_28 at hand_camera with Dissolve(0.8)
    d "네 그렇게 천천히 일어나면 돼요."
    scene ch02_droom_29 with dissolve
    play voice_f "audio/voices/fwhat01.mp3"
    unknownf "웟 더 퍽!"
    scene ch02_droom_30 with dissolve
    d "네? 왜 그래요?"
    scene ch02_droom_31 with dissolve
    d "허??"
    d "(shit!!!!!!!)"
    if not in_replay:
        $ add_point("lust_beth", 2, "lust_beth")
        $ add_point("sus_beth", 2, "sus_beth")
    scene ch02_droom_32 at hand_camera with vpunch
    d "(shit!)"
    n "고개를 내려 아래를 바라보자 자신의 성기가 삐져나와 덜렁거리고 있었다."
    n "순간 그는 처음 느껴보는 감정의 파도를 느꼈다."
    n "그는 그 짧은 순간에 흥분, 공포, 불안, 쾌감을 동시에 느꼈다."
    scene ch02_droom_33 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_34 with dissolve
    d "젠장 이게 왜 밖으로..."
    play voice_f "audio/voices/fscream01.mp3" volume 0.5
    scene ch02_droom_35 with dissolve
    unknownf "꺄악!"
    scene ch02_droom_36 at hand_camera with Dissolve(0.8)
    d "젠장!"
    scene ch02_droom_37 with dissolve
    d "허?"
    scene ch02_droom_26 at hand_camera with Dissolve(0.8)
    d "괜찮아요?"
    scene ch02_droom_39 at hand_camera with Dissolve(0.8)
    d "정말 미안합니다. 하......"
    d "(하...... 아침부터 이게 무슨 짓거리냐.)"
    scene ch02_droom_40 at hand_camera with Dissolve(0.8)
    d "(아니 근데 대체 이 사람이 누구지?)"
    d "(누군데 이렇게 이 집에서 자유롭게 돌아다니는거지?)"
    scene ch02_droom_40-01 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fgrunt01.wav"
    d "([h_name]의 딸인가?)"
    d "(아냐 그러기엔 나이가 안맞아.)"
    d "(헬렌의 동생인가?)"
    scene ch02_droom_41 with dissolve
    play voice_f "audio/voices/fhurt02.mp3"
    unknownf "아야!"
    scene ch02_droom_42 with dissolve
    unknownf "shit!"
    play sound "audio/ambi/fabric02.mp3"
    scene ch02_droom_43 at hand_camera with Dissolve(0.8)
    d "(!!!!!!!)"
    play sound "audio/ambi/drop01.wav" volume 0.3
    scene ch02_droom_44 at hand_camera with Dissolve(0.8)
    d "(.................)"
    play music "audio/bgm/erotic03.mp3"
    scene ch02_droom_44-01 at hand_camera with Dissolve(0.8)
    unknownf "..............."
    scene ch02_droom_44-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_45 at hand_camera with Dissolve(0.8)
    d "(.................)"
    scene ch02_droom_46 at hand_camera with Dissolve(0.8)
    d "(이거 지금 무슨 일이지..)"
    d "(나 아직 자고 있나?)"
    d "(꿈인가?)"
    scene ch02_droom_47 at hand_camera with Dissolve(0.8)
    unknownf "..............."
    scene ch02_droom_48 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_49 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_50 at hand_camera with Dissolve(1.3)
    pause
    scene ch02_droom_51 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_51-02 at hand_camera with vpunch
    pause
    if not in_replay:
        $ add_point("lust_beth", 2, "lust_beth")
        $ add_point("sus_beth", 2, "sus_beth")
    scene ch02_droom_51-03 at hand_camera
    play voice_f "audio/voices/fhurt01.mp3"
    unknownf "웁!!!"
    scene ch02_droom_52 with dissolve
    unknownf "너 뭐하는 거야?!!!"
    scene ch02_droom_53 at hand_camera with Dissolve(0.8)
    unknownf "너 나한테 무슨 짓을 하는거야?......"
    play voice_f "audio/voices/fcrying01.mp3"
    unknownf "흑흑흑(우는 소리)"
    scene ch02_droom_54 at hand_camera with Dissolve(0.8)
    d "(좆됐다.)"
    scene ch02_droom_55 at hand_camera with Dissolve(0.8)
    unknownf "흑흑흑(우는 소리)"
    scene ch02_droom_56 at hand_camera with Dissolve(0.8)
    d "(하.........)"
    play music "audio/bgm/normal02.mp3"
    scene ch02_droom_57 at hand_camera with Dissolve(2.0)
    d "저기..."
    d "정말 미안합니다."
    d "일부러 그런건 절대 아니에요.."
    d "실수였습니다....."
    stop voice_f
    n "잠에서 완전히 깨어난 그에게 불안감이 엄습했다."
    n "그의 생각에 그녀는 분명 [h_name]의 여동생이었고 이 일이 [h_name]의 귀에 들어가면 정말 집에서 나가야 할지 모른다고 생각했다."
    scene ch02_droom_58 at hand_camera with Dissolve(0.8)
    d "하......"
    scene ch02_droom_59 at hand_camera with Dissolve(0.8)
    d "저기..."
    d "제 사과를 받아주세요."
    d "제발 [h_name]에게 말하지 말아주세요. 부탁합니다."
    scene ch02_droom_60 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_58 at hand_camera with Dissolve(0.8)
    d "정말 미안합니다.."
    scene ch02_droom_61 at hand_camera with Dissolve(2.0)
    unknownf "괜찮아요."
    unknownf "신경쓰지 마세요."
    pause
    unknownf "내 잘못이에요."
    scene ch02_droom_62 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/fabric01.mp3"
    unknownf "............"
    unknownf "제가 이 방에 들어오는게 아니었어요."
    unknownf "젊은 남자가 자는 침대에 속옷 차림으로 앉은 내가 제 정신이 아니었어요."
    scene ch02_droom_63 with Dissolve(2.0)
    d "............"
    scene ch02_droom_64 with dissolve
    pause
    scene ch02_droom_65 at hand_camera with Dissolve(1.5)
    d "............"
    scene ch02_droom_66 at hand_camera with Dissolve(0.8)
    d "저기..."
    d "정말 미안합니다."
    d "제가 의도했다거나 일부러 옷을 그렇게..."
    d "뭔가를 꺼내놓았다거나 그런건 절대 아닙니다. 하..."
    scene ch02_droom_67 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom_68 at hand_camera with Dissolve(0.8)
    unknownf ".............."
    scene ch02_droom_68-01 at hand_camera with Dissolve(0.8)
    d ".........."
    scene ch02_droom_69 at hand_camera with Dissolve(0.8)
    unknownf "크흠."
    scene ch02_droom_70 at hand_camera with Dissolve(0.8)
    unknownf "미안합니다."
    unknownf "마음 불편해하지 말았으면 합니다."
    unknownf "[h_name]에겐 말하지 않을게요."
    unknownf "그럴 필요도 없는 일이에요."
    unknownf "일어나지 않았던 일이라 생각하세요. 저도 잊어버리겠습니다."
    unknownf "편히 쉬세요."
    play sound "audio/ambi/dooropen.mp3"
    scene ch02_droom_71 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch02_droom_72 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_beth = True
    d "젠장.."
    d "저 사람이 [h_name]이 말한 가정부였구나...."
    d "나 대형사고 친거 같은데..."
    d "하............."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    jump ch02_living01

label ch02_living01:
    if not in_replay:
        $ persistent.unlock_ch02_living01 = True

    play music "audio/bgm/normal03.mp3"
    scene ch02_living01_01 with dissolve
    play sound "audio/ambi/doorclose.mp3"
    pause
    scene ch02_living01_02 with dissolve
    pause
    play sound "audio/ambi/vacuum02.mp3" loop
    scene ch02_living01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_04 at hand_camera with Dissolve(0.8)
    n "그의 심장은 여전히 빠르게 뛰고 있었다."
    n "그리고 여성을 제대로 돕지 못한 자신이 원망스러웠다."
    d "(젠장.)"
    d "(진짜 마음 불편하네.)"
    d "(아니 왜 그 타이밍에 그게 그녀의 입으로....)"
    scene ch02_living01_05 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_05-02 at hand_camera with Dissolve(0.8)
    pause
    n "그녀도 자신이 지금 무엇을 하고 있는지 인지하지 못할 정도로 혼란스러웠다."
    show ch02_living01_05-03 at hand_camera with Dissolve(0.8)
    n "방에서 나올 때 부터 줄곧 머릿속에 그의 고추 생각이 떠나질 않았다."
    n "생각이 계속될수록 흥분과 수치심이 동시에 그녀를 휘감았다."
    scene ch02_living01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_09 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_10 with vpunch
    play voice_f "audio/voices/fhurt01.mp3"
    unknownf "아얏!"
    scene ch02_living01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_12 at hand_camera with Dissolve(0.8)
    unknownf "젠장"
    scene ch02_living01_13 at hand_camera with Dissolve(0.8)
    d "저기요"
    scene ch02_living01_14 at hand_camera with Dissolve(0.8)
    d "괜찮아요?"
    d "그 몸으로 계속하시는건 무리같은데요."
    d "제가 도와드릴게요."
    if not in_replay:
        $ add_point("love_beth", 2, "love_beth")
    scene ch02_living01_15 at hand_camera with Dissolve(0.8)
    unknownf ".........................."
    scene ch02_living01_15-02 at hand_camera with Dissolve(0.8)
    unknownf "고맙지만 괜찮아요."
    unknownf "이건 내 일이니 신경 안써도 돼요."
    scene ch02_living01_16 at hand_camera with Dissolve(0.8)
    d "저기 아까는 저의 실수였어요."
    d "정말 미안합니다."
    play sound "audio/ambi/dooropen.mp3"
    scene ch02_living01_17 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/normal04.mp3"
    scene ch02_living01_18 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_living01_19 at hand_camera with Dissolve(0.8)
    pause
    n "방문이 열리고 [h_name]이 나타났다."
    n "그녀는 그녀의 몸매가 훤히 드러나도록 입고 있었다."
    scene ch02_living01_20 with dissolve
    h "오 두 사람 벌써 인사한거에요?"
    h "아니 베스! 왜 온거에요?"
    h "일 할 수 있는 상태에요?"
    scene ch02_living01_21 at hand_camera with Dissolve(0.8)
    b "굿모닝 [h_name]."
    b "전 많이 좋아졌어요."
    b "이제 자유롭게 움직일 수 있어요."
    scene ch02_living01_22 at hand_camera with Dissolve(0.8)
    h "정말이에요?"
    h "봐요. 지금 붕대도 풀지 못했는데 일하면 안될거 같은데요?"
    scene ch02_living01_21 at hand_camera with Dissolve(0.8)
    b "아니에요. 일 할 수 있어요."
    b "붕대를 풀 때 까지 기다리려면 너무 오래걸려요."
    scene ch02_living01_23 at hand_camera with Dissolve(0.8)
    b "아마 완전히 다 회복하려면 한달도 더 걸릴거에요."
    b "의사도 간단한 일은 해도 된다고 했어요."
    b "그리고 움직이지 않고 집에만 있으니 답답해서 너무 힘들었어요."
    scene ch02_living01_24 at hand_camera with Dissolve(0.8)
    h "지금 그게 간단한 일은 아닌거 같은데요?"
    h "그렇게 하면 제가 마음이 너무 불편해요."
    scene ch02_living01_25 at hand_camera with Dissolve(0.8)
    h "무리해서 움직이면 회복이 더 늦어질거에요."
    h "집안일은 내가 하면 되니까 집에가서 회복에 전념해요."
    scene ch02_living01_26 at hand_camera with Dissolve(0.8)
    h "아니에요 베스!"
    h "그러면 회복이 더 늦어질......."
    play sound "audio/ambi/fabric01.mp3"
    scene ch02_living01_27 with dissolve
    pause
    play sound "audio/ambi/fabric02.mp3"
    scene ch02_living01_27-02 with dissolve
    pause
    scene ch02_living01_28 at hand_camera with Dissolve(0.8)
    d "!!!"
    b ".........."
    scene ch02_living01_29 with dissolve
    h "웁스!"
    scene ch02_living01_30 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_31 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_32 at hand_camera with Dissolve(0.8)
    b "(..........)"
    scene ch02_living01_33 at hand_camera with Dissolve(0.8)
    pause
    n "이유는 아무도 모른다."
    n "그 순간 베스는 자신도 모르게 [d_name]의 사타구니로 눈길이 갔다."
    scene ch02_living01_34 with dissolve
    d "(쉣!)"
    scene ch02_living01_35 at hand_camera with Dissolve(0.8)
    h "어쨌든 베스. 어서 멈추고 집에가서 쉬어요."
    h "나 지금 강요하는 거에요."
    scene ch02_living01_35-02 at hand_camera with Dissolve(0.8)
    h "베스 맘이 편할지 몰라도 내가 너무 불편해요."
    scene ch02_living01_25 at hand_camera with Dissolve(0.8)
    h "지금 그 상태로 일하는건 절대 안돼요."
    h "알겠죠?"
    scene ch02_living01_36 at hand_camera with Dissolve(0.8)
    b "...................."
    b "알겠어요 [h_name]."
    b "그렇게 할게요."
    scene ch02_living01_23 at hand_camera with Dissolve(0.8)
    b "그럼 세탁기만 작동해놓고 갈게요."
    b "그렇게 하면 되죠?"
    scene ch02_living01_36-02 at hand_camera with Dissolve(0.8)
    h "맙소사 베스."
    h "너의 고집은 당할수 없네요. 그렇게 해요."
    scene ch02_living01_37 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_living01_38 at hand_camera with Dissolve(0.8)
    pause
    n "그녀가 1층으로 내려가고 거실엔 묘한 정적이 흘렀다."
    n "[d_name]은 재빨리 청소도구를 집어 들며 말했다."
    scene ch02_living01_39 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/vacuum02.mp3"
    d "나머지는 제가 이어서 할게요."
    scene ch02_living01_40 at hand_camera with Dissolve(0.8)
    d "힘이 남아돌아서 이렇게라도 움직여야해요."
    scene ch02_living01_41 at hand_camera with Dissolve(0.8)
    h "hehe. 그럼 말리지 않을게요."
    h "나는 뒷마당에 있을테니 혹시 필요한게 있으면 얘기해요."
    h "너무 열심히는 하지말아요. 이따가 내가 마저 하면 돼요. 알겠죠?"
    h "점심은 그럼 맛있는거 만들어줄게요."
    scene ch02_living01_42 with Dissolve(1.0)
    pause
    scene ch02_living01_43 with Dissolve(1.0)
    pause
    scene ch02_living01_44 with Dissolve(1.0)
    d "(젠장..........)"
    d "(그녀 나이에 비해 그녀의 몸매는 믿을 수 없을 만큼 훌륭해..)"
    scene ch02_living01_45 at hand_camera with Dissolve(0.8)
    d "(뎀...)"
    d "(그녀는 여전히 나에게 너무 무방비야....)"
    d "(저 동작은 뭐지? 초대장인가?)"
    d "(진짜 날 애기 취급하는건가...)"
    pause
    d "(난 남자로 보이지 않는다는 건가요?)"
    stop sound fadeout 1.0
    jump ch02_laundry01

label ch02_laundry01:
    if not in_replay:
        $ persistent.unlock_ch02_laundry01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch02_laundry01_00 with Dissolve(2.0)
    pause
    scene ch02_laundry01_01 with dissolve
    d "(여기는 페인트를 칠하다 말았네.)"
    d "(무슨 급박한 일이라도 있었나?)"
    d "(나중에 내가 칠해야겠군.)"
    n "[d_name]은 심정이 복잡했다."
    n "베스에게 제대로 된 사과를 해야 한다는 생각과"
    n "그녀가 괜찮은지 확인 하고 싶은 생각,"
    n "그리고 묘한 흥분감에 사로잡혀 그녀가 떠나기전 다시 그녀와 조우하고 싶었다."
    play sound "audio/ambi/dooropen.mp3"
    scene ch02_laundry01_02 with Dissolve(1.0)
    pause
    scene ch02_laundry01_03 with dissolve
    d "!!!!"
    scene ch02_laundry01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_laundry01_05 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_laundry01_06 at hand_camera with Dissolve(0.8)
    d "(젠장. 여기 들어온게 또 실수인거 같은데.....)"
    d "(어떡하지? 다시 돌아나가야 하나?)"
    d "(아니다. 어짜피 그녀도 내 소리 들었을거야.)"
    d "저기요..베스."
    scene ch02_laundry01_07
    b "!!!!!!!!!!!!"
    play sound "audio/ambi/hit01.mp3"
    scene ch02_laundry01_08 with vpunch
    play voice_f "audio/voices/fhurt07.mp3"
    b "아얏!"
    if not in_replay:
        $ add_point("sus_beth", 2, "sus_beth")
    scene ch02_laundry01_09
    d "우왁!"
    scene ch02_laundry01_10 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fhurt03.mp3"
    b "아......."
    scene ch02_laundry01_11 at hand_camera with Dissolve(0.8)
    b "젠장...."
    scene ch02_laundry01_12 at hand_camera with Dissolve(0.8)
    b "아니 왜 인기척을 안내고 들어와요?!"
    b "아이고 아파라.."
    scene ch02_laundry01_13 with dissolve
    d "미안합니다."
    d "괜찮아요 베스?"
    d "(하.......난 대체 왜 이러냐..)"
    scene ch02_laundry01_14 at hand_camera with Dissolve(1.5)
    play voice_f "audio/voices/fsigh03.wav"
    b "하.........."
    scene ch02_laundry01_15 at hand_camera
    b "안 괜찮아요!"
    b "이러다 목까지 부러지게 생겼다구요!"
    scene ch02_laundry01_16 at hand_camera with Dissolve(0.8)
    d "미안해요 아까 부터...."
    d "왜 이런일이 계속 생기는지 참..."
    scene ch02_laundry01_16-02 at hand_camera with Dissolve(0.8)
    n "베스는 머리의 고통이 가시면서 화가 가라 앉기 시작했다."
    n "그리고 그의 얼굴을 보자 잠시 잊고 있었던 자신의 얼굴위의 그의 물건이 떠올랐다."
    b "왜요? 뭐 부탁할거라도 있어요?"
    scene ch02_laundry01_13 at hand_camera with Dissolve(0.8)
    d "아 부탁은 아니구요.."
    d "계속 타이밍이 안맞아서 제 소개를 못했네요."
    scene ch02_laundry01_17 at hand_camera with Dissolve(0.8)
    d "전 [d_name]이라고 합니다."
    d "이 곳 출신입니다."
    d "그리고 엊그제 여기 왔습니다.. 방학 동안 이 집에서 지내게 됐습니다."
    scene ch02_laundry01_18 at hand_camera with Dissolve(0.8)
    d "반갑습니다."
    scene ch02_laundry01_19 at hand_camera with Dissolve(0.8)
    b "난 베스에요."
    b "보다싶히 [h_name]의 집 가정부에요."
    d "네. [h_name]이 얘기해서 알고는 있었는데 그게 당신일줄은 몰랐습니다."
    scene ch02_laundry01_19-02 at hand_camera with Dissolve(0.8)
    d "아 그리고.."
    d "아까 방에서 있었던 일은 절대 내가 의도한 일이 아니었습니다.."
    d "절 이상한 사람으로 보지 않았으면 합니다."
    scene ch02_laundry01_20 at hand_camera with Dissolve(0.8)
    n "베스는 그가 왜 런드리 까지 내려와서 그 얘기를 다시 꺼내는지 알 수 없었다."
    n "하지만 그녀 자신 스스로도 그가 꺼낸 이야기가 싫지 않다는 것을 느끼고 있었다."
    n "그럼에도 그런 이야기를 다시 꺼내는 저의를 의심했다."
    b "괜찮다."
    b "그건 내 실수였어."
    scene ch02_laundry01_21 at hand_camera with Dissolve(0.8)
    b "니가 자고 있던 그 방에 내가 들어가는게 아니었어."
    b "나도 모르게 루틴으로 그냥 방에 들어간거야."
    b "그 방은 [h_name]이 내가 필요할 때 쓰라고 허락했거든."
    b "거기 있는 여자 옷들은 내거야."
    scene ch02_laundry01_22 at hand_camera with Dissolve(0.8)
    b "...................."
    b "술 취한 여자도 아니고 남자 혼자 자고있는 방에 들어가다니 하...."
    b "[h_name]이 보기라도 했으면 날 엄청 책망했을거야."
    scene ch02_laundry01_20 at hand_camera with Dissolve(0.8)
    b "내 짐들은 내일 다 치울게."
    b "............"
    b "거기 내 속옷도 좀 있거든..."
    scene ch02_laundry01_23 at hand_camera with Dissolve(0.8)
    d "아니에요. 그럴 필요 없어요."
    d "나는 여기에 방학 동안만 있을거라 굳이 안그래도 돼요."
    d "그 방은 베스의 방이었으니까 내가 다 차지하지 않을게요."
    scene ch02_laundry01_23-02 at hand_camera with Dissolve(0.8)
    b "아냐 거기는 내 방이 아니라 [h_name]의 아들 방이었..."
    scene ch02_laundry01_24 at hand_camera with Dissolve(0.3)
    d "(그녀가 지금?)"
    d "(그녀가 지금 내 고추 쪽을 보고 있나?)"
    pause
    scene ch02_laundry01_25 at hand_camera with Dissolve(0.8)
    b "............."
    b "이 동네에는 어떻게 오게 된거에요?"
    b "그리고 [h_name]과는 어떻게 알게 된거에요?"
    scene ch02_laundry01_26 at hand_camera with Dissolve(0.8)
    d "아 저는 [h_name]과 아는 사이는 아닙니다."
    d "전 밀프하임 대학교의 학생인데요 방학동안에 여기서 지내기로 했습니다."
    d "여기가 제 고향이거든요."
    scene ch02_laundry01_27 at hand_camera with Dissolve(0.8)
    b "그렇군요.."
    b "이 곳 출신이라니 왠지 그리 낯설게 느껴지진 않네요."
    d "(쉣! 치마가 저렇게 올라간걸 못느끼나?)"
    d "(이 집 사람들은 다들 엉덩이에 자신감이 있나?)"
    d "(............................)"
    scene ch02_laundry01_28 at hand_camera with Dissolve(0.8)
    d "(아냐.)"
    d "(베스도 지금 내가 애로 보일수도 있는거야.)"
    d "(굳이 자신의 엉덩이를 가릴 필요도 없을 애 말이야.)"
    scene ch02_laundry01_27 at hand_camera with Dissolve(0.8)
    b "..............."
    b "근데 이곳 출신이면 가족들이 있지 않아요? 일찍 독립한거에요?"
    scene ch02_laundry01_26 at hand_camera with Dissolve(0.8)
    d "아 저는......"
    d "사실 고아입니다."
    d "어렸을 때 시설에 맡겨져서 부모님이 어디있는 몰라요."
    b "(!!)"
    scene ch02_laundry01_25 at hand_camera with Dissolve(0.8)
    b "............."
    b "아 미안해요. 그런줄도 모르고.."
    b "괜한걸 물어봤네요."
    scene ch02_laundry01_24 at hand_camera with Dissolve(0.8)
    d "괜찮습니다. 아는거라곤 서류에 있던 부모님 이름뿐이라 별 느낌도 없어요."
    d "오히려 제 배경 때문에 많은 사람들에게 넘치는 사랑을 받고 살았어요."
    scene ch02_laundry01_30 at hand_camera with Dissolve(0.8)
    b "후훗. 생각이 깊은 학생이네요."
    b "그런 상황이면 보통 부모님을 원망할수도 있는데..."
    b "보기 좋네요."
    scene ch02_laundry01_26 at hand_camera with Dissolve(0.8)
    b "[h_name]의 집엔 어떻게 오게 된거에요?"
    b "아까 물어본걸 또 물어보고 내가 정신이 없네요."
    scene ch02_laundry01_28 at hand_camera with Dissolve(0.8)
    d "아 그....."
    d "어플을 통해서 [h_name]의 세입자 구인 광고를 보고 연락했어요."
    d "제가 살았던 집과 그리 멀지않아서 좋아보였어요."
    scene ch02_laundry01_27 at hand_camera with Dissolve(0.8)
    b "아 그랬군요."
    b "근데 여기는 좀 외곽이라 심심하지 않아요?"
    b "밖에 나가봐야 산과 나무들 뿐인데."
    b "..................."
    b "혈기왕성한 젊은 남자가 살기엔 너무 정적이지 않아요?"
    scene ch02_laundry01_30 at hand_camera with Dissolve(0.8)
    d "하하 전 오히려 이 환경이 좋아요."
    d "제가 학교 전공 때문에 책을 자주 읽는데 이만한 환경이 없습니다."
    scene ch02_laundry01_29 at hand_camera with Dissolve(0.8)
    b "오. 그 부분은 [h_name]과 잘 맞겠네요."
    b "..............."
    b "그녀도 조용한 환경을 좋아해요."
    scene ch02_laundry01_25 at hand_camera with Dissolve(0.8)
    b "..........................."
    b "아까 도와주겠다고 해서 고마웠다."
    b "설령 그게 형식적인 말이었다 해도.."
    scene ch02_laundry01_28 at hand_camera with Dissolve(0.8)
    d "아니에요. 진심이었어요."
    d "지금 네가 붕대를 감은걸 보면 꽤 심각해 보인다."
    d "[h_name]의 말대로 당신은 휴식이 필요해 보입니다."
    if not in_replay:
        $ add_point("love_beth", 2, "love_beth")
    scene ch02_laundry01_30 at hand_camera with Dissolve(0.8)
    n "그녀는 비로소 아침의 충격을 뒤로 하고 일상으로 돌아온 느낌에 안도했다."
    n "그리고 그가 약간 오지랖은 있어 보여도 자신을 진심으로 걱정해주고 있다고 느꼈다."
    n "자신보다 한참 어린 남자에게 그런 위로를 들으니 그녀는 왠지 쑥스러워졌다."
    scene ch02_laundry01_31 at hand_camera with Dissolve(2.0)
    play voice_f "audio/voices/fsigh02.mp3"
    b "휴...."
    b "대강 마무리 된거 같네."
    scene ch02_laundry01_31-02 with dissolve
    b "몸은 힘들어도 오길 잘한거 같아요."
    b "이렇게라도 하니 맘이 한결 편하네요."
    scene ch02_laundry01_32 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_laundry01_32-02 at hand_camera with Dissolve(2.0)
    play music "audio/bgm/normal06.mp3"
    play voice_f "audio/voices/flaugh03.wav"
    b "후훗.."
    scene ch02_laundry01_33 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch02_laundry01_32-03 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch02_laundry01_33-02 at hand_camera with Dissolve(0.8)
    b "..........."
    b "왜 그렇게 멍하게 쳐다봐요 민망하게."
    b "..........."
    scene ch02_laundry01_33 at hand_camera with Dissolve(0.8)
    d "아.. 아닙니다. 제가 가끔 이렇게 멍할때가 있어요."
    d "좀... 안좋은 버릇입니다."
    scene ch02_laundry01_33-02 at hand_camera with Dissolve(0.5)
    b "그렇군요."
    b "안좋은 버릇이라고 할거 까진 아니에요."
    scene ch02_laundry01_33-04 at hand_camera with Dissolve(0.8)
    b "..................."
    b "저기..."
    pause
    b "아까 방에서 있던 일 때문에 온거죠?"
    if not in_replay:
        $ add_point("lust_beth", 2, "lust_beth")
        $ add_point("sus_beth", 2, "sus_beth")
    scene ch02_laundry01_24 at hand_camera with Dissolve(0.8)
    d "(!!!!!!!)"
    d "아 그건..."
    scene ch02_laundry01_33-04 at hand_camera with Dissolve(0.8)
    b "..................."
    b "맙소사......"
    b "어떻게 그런 일이 벌어질 수 있죠?"
    b "..................."
    b "누가 이 일을 믿을 수 있을까요?..."
    scene ch02_laundry01_33-11 at hand_camera with Dissolve(1.5)
    b "..........."
    b "(맙소사..)"
    b "(이 일을 사람들이 믿을까?)"
    b "(생전 처음 보는 꼬마녀석의 고추 밑에 주저앉아 입을 벌리고 있었다고?)"
    scene ch02_laundry01_33-04 at hand_camera with Dissolve(0.8)
    b ".............."
    b "괜찮아요. 말하고 싶은거 있으면 어서 얘기해요."
    b "난 이제 나가야 해요."
    scene ch02_laundry01_33-08 at hand_camera with Dissolve(0.8)
    d "아 저...."
    d "그러니까..........."
    pause
    d "저의..."
    scene ch02_laundry01_33-03 at hand_camera with Dissolve(0.8)
    b ".............."
    b "(너의 뭐? 이 꼬마녀석.)"
    b "(뭘 저렇게 뜸들이는거지?)"
    b "(너도 결국 이런 말이 하고싶은거잖아.)"
    scene ch02_laundry01_33-12 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic06.mp3"
    b "(내 자지는 어떤거 같아요?)"
    b "(이 정도면 널 만족시킬 수 있겠죠?)"
    b "(자 봐요. 와서 더 자세히 들여다봐요.)"
    pause
    b "(내 것을 봤으니 이제 당신 차례에요.)"
    scene ch02_laundry01_33-03 at hand_camera with Dissolve(0.8)
    b "(....)"
    b "(다른 남자들 처럼 어떻게든 구실을 만들어서 내 팬티를 벗기고 싶은거잖아.)"
    scene ch02_laundry01_33-08 at hand_camera with Dissolve(0.8)
    d ".............."
    d "괜찮아요 베스?"
    scene ch02_laundry01_33-04 at hand_camera with Dissolve(0.8)
    b "그거 알아?"
    d "네?"
    b "(남자는 아무리 신사다운척, 여자를 위하는척 해도 다 똑같아.)"
    b "(어리든 노인이든 원하는건 단 하나라고.)"
    scene ch02_laundry01_33-05 at hand_camera with Dissolve(0.8)
    b "(눈만 뜨면 떡칠 궁리나 하는 더러운 놈들.)"
    b "(오 그래? 너도 신나게 빨아줄까?)"
    b "(그래서 할말도 없으면서 여기까지 따라온거 아냐?)"
    b "(날 분명 쉬운 여자라고 생각하고 있겠지?)"
    scene ch02_laundry01_33-09 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/oral03.mp3"
    b "(너도 내가 빨아준 수많은 남자들과 같은 이상한 신음을 내면서 날 내려다 볼거지?)"
    b "(너의 이모뻘인 내 머리를 쓰다듬으면서 말이야.)"
    scene ch02_laundry01_33-10 at hand_camera with Dissolve(0.8)
    b "(아무런 저항없이 너의 자지를 입에 무는 날 보고싶지?)"
    b "(그게 지금 니 머릿속에 있는 생각이잖아?)"
    scene ch02_laundry01_33-13 at hand_camera with Dissolve(0.8)
    b "(너의 우람한 자지를 한껏 입에 물고 추한 표정을 짓고 있는 내 얼굴을 보고 싶지?)"
    b "(꺼억꺼억 거리며 겨우 숨을 쉬는 모습을 지켜보며,)"
    scene ch02_laundry01_33-14 at hand_camera with Dissolve(0.8)
    b "(그런 나를 아름다운 여자라며 머리를 쓰다듬을거잖아.)"
    b "(날 착한 여자라 불러줄거지?)"
    b "(.................)"
    b "(더러운 남자들.)"
    stop sound
    scene ch02_laundry01_33-08 at hand_camera with Dissolve(0.8)
    d "괜찮아요 베스?"
    scene ch02_laundry01_33-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_laundry01_33-08 at hand_camera with Dissolve(0.8)
    d "괜찮아요?"
    scene ch02_laundry01_33-03 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal05.mp3"
    b ".............."
    b "아니에요. 신경쓰지말아요."
    b "잠시 다른데 정신이 팔렸었나봐요."
    scene ch02_laundry01_33-06 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh01.mp3"
    b ".............."
    b "(젠장. 나 지금 왜 이렇게 망상을 하지?)"
    b "(하....나한테 문제가 있어.)"
    b "(저 애는 이 동네에서 보기드문 순수한 사람 같은데 하.....)"
    d "(댐......아름다운 겨드랑이야.)"
    b "(저렇게 순수한 애를 보고 지금 무슨 생각을 하는거야?)"
    d "(쉣! 핥아보고 싶다.)"
    d "([h_name]의 겨드랑이 만큼 아름다운거 같아.)"
    scene ch02_laundry01_33-07 at hand_camera with Dissolve(0.8)
    d "(저것봐...)"
    d "(그녀는 나에게 경계심이 없는거야.)"
    d "(난 그녀에게 그냥 꼬맹이일 뿐이라고.)"
    d "(잘보이고 싶은 남자라면 저렇게 자기 겨드랑이을 훤히 보여줄리가 없잖아.)"
    scene ch02_laundry01_34 at hand_camera with Dissolve(2.0)
    b "그럼 난 이만 갈게요. 나중에 봐요."
    scene ch02_laundry01_35 at hand_camera with Dissolve(0.8)
    d "아 저기..."
    n "[d_name]은 그녀와 더 이야기 하고 싶었다."
    n "그녀와 자신 사이에 형성된 애로틱한 긴장감을 더 즐기고 싶었다."
    n "그리고 아직은 낯선 이 동네에서 왠지 은밀한 것들을 공유할 수 있는 친구가 생긴거 같았다."
    n "그녀가 떠나는 것이 아쉬운나머지 본인도 이해하지 못할 말을 했다."
    d "제가 [h_name]에게 차를 빌려서 데려다 드릴게요."
    scene ch02_laundry01_36 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_beth", 2, "love_beth")
    b "뭐라고요? [h_name]의 차를 빌린다고요?!!"
    play voice_f "audio/voices/milflaugh04.mp3"
    b "그녀가 자신의 차를 너에게 빌려줄거 같아요 하하."
    scene ch02_laundry01_37 at hand_camera with Dissolve(0.8)
    b "방에서 일 때문에 신경 쓰이는 거라면 난 정말 괜찮아요."
    b "그리고 내 오토바이가 있어요. 그걸로 가면 돼요."
    scene ch02_laundry01_38 at hand_camera with Dissolve(0.8)
    b "신경써줘서 고마워요."
    b "나중에 봐요."
    scene ch02_laundry01_39 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_laundry01_40 at hand_camera with Dissolve(0.8)
    d "바보 같은 놈."
    d "난 말할 때 가끔 뇌를 안거치고 말하는거 같네."
    d "차를 빌린다니 참나..."
    d "더 애 같은 놈으로 보겠군.."
    jump ch02_pool01

label ch02_pool01:
    if not in_replay:
        $ persistent.unlock_ch02_pool01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    scene ch02_pool01_00 with dissolve
    play sound "audio/ambi/park01.mp3" loop
    pause
    scene ch02_pool01_01 with dissolve
    pause
    scene ch02_pool01_02 at hand_camera with Dissolve(0.8)
    d "(산 밑 마을은 공기가 상쾌하구나.)"
    d "(건강해 지는 느낌이야.)"
    d "(나중에 나이들면 이런 곳에 살 수 있었으면 좋겠다..)"
    scene ch02_pool01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_03-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_05 at hand_camera with Dissolve(0.8)
    d "(맙소사.)"
    d "(그녀의 가슴이 이렇게 컸었나?..)"
    scene ch02_pool01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_05 at hand_camera with Dissolve(0.8)
    n "그는 자신의 스케쥴을 [h_name]에게 알리기 위해 그녀에게 다가갔다."
    n "그리고 눈 앞에 펼쳐진 광경에 며칠 전 그녀 앞에서 발기했던 일이 떠올라 조심스러워다."
    d "................."
    d "저기요 [h_name]."
    scene ch02_pool01_08 at hand_camera with Dissolve(0.8)
    d "................."
    d "저기요 [h_name]."
    scene ch02_pool01_08-02 at hand_camera with Dissolve(0.8)
    d "(그녀는 내가 온줄도 모르는군.)"
    d "(어떡하지?? 자전거를 빌려야 하는데?)"
    menu:
        n "What should I do?"
        "Touch her body. ":
            if not in_replay:
                $ add_point("lust_helen", 2, "lust_helen")
                $ add_point("love_helen", 1, "love_helen")
            scene ch02_pool01_08-03 at hand_camera with Dissolve(0.8)
            d "(소리 쳤다가 그녀가 또 나 때문에 놀라면 어떡하지?)"
            d "(그냥 젠틀하게 만지는게 나을거 같은데?? 아닌가??)"
            scene ch02_pool01_09 at hand_camera with Dissolve(0.8)
            d "저기요 [h_name]."
            scene ch02_pool08_09-02 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_pool01_08-03 at hand_camera with Dissolve(0.8)
            d "(.....)"
            scene ch02_pool01_09-03 at hand_camera with Dissolve(0.8)
            d "[h_name]!"
            scene ch02_pool01_09-04 at hand_camera with Dissolve(0.3)
            d "[h_name]!"
        "Speak louder.":

            if not in_replay:
                $ add_point("sus_helen", 2, "sus_helen")
            scene ch02_pool01_08-02 at hand_camera with Dissolve(0.8)
            d "(If I do this, she can hear me, right?)"
            scene ch02_pool01_10 with vpunch
            d "저기요 [h_name]!!!!!!!!"

    scene ch02_pool01_11 with vpunch
    play voice_f "audio/voices/fhurt06.mp3"
    h "What?!!"
    d "(!!!)"
    scene ch02_pool01_11-02 with dissolve
    pause
    scene ch02_pool01_12 at hand_camera with Dissolve(0.8)
    h "........."
    scene ch02_pool01_12-02 at hand_camera with Dissolve(0.8)
    d "(젠장 내가 또 실수했나?)"
    scene ch02_pool01_13 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_14 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh01.mp3"
    h "아 [d_name].."
    h "진짜 깜짝 놀랐잖아요."
    scene ch02_pool01_15 at hand_camera with Dissolve(0.8)
    d "미안합니다."
    d "계속 당신을 불렀는데 당신이 듣지 못해서요."
    scene ch02_pool01_16 at hand_camera with Dissolve(0.8)
    h "아 그랬군요."
    h "근데 무슨 일이에요?"
    scene ch02_pool01_17 at hand_camera with Dissolve(0.8)
    d "아 저 베스는 방금 돌아갔어요."
    d "자신의 오토바이로 집에 간다며 나갔습니다."
    scene ch02_pool01_18 at hand_camera with Dissolve(0.8)
    h "아 그랬군요.."
    h "알려줘서 고마워요."
    scene ch02_pool01_17-02 at hand_camera with Dissolve(0.8)
    h "그녀는 때때로 너무 열심히 일하려고 하는게 문제에요."
    h "조만간 세입자를 받을거라 얘기 했더니 본인이 책임감을 느꼈는지 일부러 출근한거 같아요."
    scene ch02_pool01_18-02 at hand_camera with Dissolve(0.8)
    d ".........."
    d "아 그랬군요."
    d "제가 괜히 미안해 집니다."
    scene ch02_pool01_19 at hand_camera with Dissolve(0.8)
    h "헤헤 괜찮아요."
    h "오늘은 좀 정신이 없었는데 나중에 정식으로 소개해 줄게요."
    h "이제 몇 달간 계속 보고 지내야 하는 사람이니까 서로 알고 지내야죠."
    scene ch02_pool01_20 at hand_camera with Dissolve(0.8)
    h "(이런이런.....)"
    h "(이제 옷차림에 더 신경써야겠는걸..)"
    scene ch02_pool01_21 at hand_camera with Dissolve(0.8)
    pause
    n "그녀는 [d_name]과의 대화 도중 자세를 고쳐 앉았다."
    scene ch02_pool01_22 at hand_camera with Dissolve(0.8)
    d "(!!!!!!!)"
    scene ch02_pool01_23 at hand_camera with Dissolve(0.8)
    h "아 그리고 오늘 내 친구가 올거에요."
    h "마이클은 아니니까 걱정 안해도 돼요 하하."
    scene ch02_pool01_24 at hand_camera with Dissolve(0.8)
    h "그런데 그 친구는 너무 활발하고 긴장감이 넘치는 친구여서 감당하기 힘든 사람이에요 헤헤."
    h "그래서 미안하지만 오늘은 좀 가능하면 2층에 머물러줄래요?"
    h "귀찮게 해서 미안해요."
    scene ch02_pool01_25 at hand_camera with Dissolve(0.8)
    d "아 그랬군요."
    d "신경쓰지 않아도 됩니다. 오늘 살던 집에 다녀올거거든요."
    d "하루 자고 내일 올겁니다."
    scene ch02_pool01_23 at hand_camera with Dissolve(0.8)
    h "아하 그랬군요."
    h "좋은 시간이 되겠네요 헤헤."
    scene ch02_pool01_26-02 at hand_camera with Dissolve(2.0)
    h "영차."
    scene ch02_pool01_26-03 with dissolve
    pause
    scene ch02_pool01_26-04 at hand_camera with Dissolve(0.8)
    h "그럼 오늘은 난 친구와 집에 있을테니 잘 다녀와요."
    h "혹시 오늘 돌아오게 되면 문자 메세지 부탁해요."
    scene ch02_pool01_26-05 at hand_camera with Dissolve(0.8)
    d "네 그렇게 할게요."
    d "친구분과 좋은 시간 보내세요."
    scene ch02_pool01_28 at hand_camera with Dissolve(0.8)
    h "고마워요 헤헤."
    h "나중에 더 가까워지면 같이 선텐해요."
    scene ch02_pool01_29 at hand_camera with Dissolve(0.8)
    d "네 좋아요 하하."
    pause
    d "(저도 어서 [h_name]과 가까워 지고 싶어요..)"
    d "(지금 당장이라도...)"
    scene ch02_pool01_30 with dissolve
    pause
    scene ch02_pool01_30-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool01_31 at hand_camera with Dissolve(0.8)
    h "(안그래도 되는데 그는 너무 행동을 조심하는거 같아.)"
    h "(그때 발기했을때 내가 너무 민망하게 행동했나?)"
    h "(괜히 좀 미안해지네.)"
    scene ch02_pool01_32 with dissolve
    play voice_f "audio/voices/fwhat01.mp3"
    h "허!!!!!!!!!!"
    scene ch02_pool01_33 with vpunch
    if not in_replay:
        $ add_point("lust_helen", 2, "lust_helen")
    h "맙소사!"
    n "그녀는 그제서야 자신의 음모가 약간 삐져 나온것을 알아 챘다."
    n "그리고 순간 굴욕감과 함께 미묘한 색다른 흥분이 그녀의 몸을 감쌌다."
    scene ch02_pool01_34 at hand_camera with Dissolve(0.8)
    h "세상에! 지금까지 이러고 [d_name]과 대화 한거야?!!!"
    h "맙소사 [h_name]!"
    h "아침에 분명히 거울 봤잖아...하...."
    scene ch02_pool01_35 at hand_camera with Dissolve(0.8)
    h "아니 겨드랑이털도 아니고 음모털이라니.."
    h "칠칠치 못한 아줌마라고 생각했겠네."
    h "하...왁싱해야하나."
    scene ch02_pool01_35-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    h "하하하 너 진짜 최악이다 [h_name]."
    h "어쩜 이럴수가..."
    h "진짜 얼굴 화끈거리네."
    scene ch02_pool01_36 at hand_camera with Dissolve(0.8)
    pause
    jump ch02_town01

label ch02_town01:
    if not in_replay:
        $ persistent.unlock_ch02_town01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal06.mp3"
    scene ch02_town01_00 with Dissolve(2.0)
    play sound "audio/ambi/bicycle01.mp3"
    pause
    scene ch02_town01_01 with Dissolve(2.0)
    pause
    play sound "audio/ambi/town01.mp3" loop
    scene ch02_town01_02 with Dissolve(2.0)
    pause
    scene ch02_town01_03 with Dissolve(2.0)
    d "이 심심한 동네는 바뀐게 하나도 없네 하하."
    scene ch02_town01_03-02 at hand_camera with Dissolve(0.8)
    d "집에 왔으니 셀카 한 번 박아줘야지."
    d "제이슨에게도 보내주고 말이야."
    scene ch02_town01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_town01_05 at hand_camera with Dissolve(0.8)
    d "아 메리에게도 보내줘야지."
    scene ch02_town01_05-02 at hand_camera with Dissolve(0.8)
    d "하......"
    show ch02_town01_05-03 at hand_camera with Dissolve(0.8)
    d "내 고추 사진 보낸 뒤로 메리에게서 문자 하나 없어..."
    d "하... 이 미친놈."
    d "대체 메리에게 그런 짓을 왜 해가지고..."
    pause
    d "뭔가 분위기를 바꿔야 해.."
    scene ch02_town01_05-02 with dissolve
    d "이 멍청한 놈."
    d "하필 두 번씩이나 그 짓을 해가지고..."
    d "다시 메리 얼굴을 어떻게 보나.."
    scene ch02_town01_06 at hand_camera with Dissolve(0.8)
    d "응?!"
    scene ch02_town01_07 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/carleaving.mp3"
    pause
    scene ch02_town01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_town01_08-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/town01.mp3" loop
    scene ch02_town01_08-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_town01_09 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/sus01.mp3"
    d "(쉣!!)"
    scene ch02_town01_09-01 at hand_camera with Dissolve(0.5)
    d "(프랭크!!!!!)"
    scene ch02_town01_10 at hand_camera with Dissolve(0.8)
    d "(1년만에 집에 와서 제일 처음 만난게 프랭크라니..)"
    d "(재수 없네.)"
    d "(근데 옆엔 누구지??)"
    scene ch02_town01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_town01_12 at hand_camera with Dissolve(0.8)
    d "(그녀는 누구지? 처음 보는 사람인데?)"
    d "(프랭크가 혹시 바람피는거 아냐?!)"
    scene ch02_town01_12-02 at hand_camera with Dissolve(0.8)
    d "(혹시 모르니까 사진 찍어 둬야지.)"
    play sound "audio/ambi/camera.mp3"


    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/15_Thumb.webp",
            "phone": "images/phone/shots/15.webp",
            "description": "프랭크 사진"
        })
    scene ch02_town01_13 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/town01.mp3" loop
    d "(쉣!)"
    scene ch02_town01_14 at hand_camera with Dissolve(0.8)
    d "흠......"
    d "친구들과 낚시 여행간다고 했던거 같은데.."
    d "이번엔 또 무슨 짓을 하는거지?"
    d "흠................"
    jump ch02_ahouse01

label ch02_ahouse01:
    if not in_replay:
        $ persistent.unlock_ch02_ahouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch02_ahouse01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse01_02 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "오랜만에 집에 오니까 절로 웃음이 나오네."
    scene ch02_ahouse01_03 with dissolve
    menu:
        "Knock":
            play sound "audio/ambi/knock.mp3" 
            scene ch02_ahouse01_03 with dissolve
            scene ch02_ahouse01_04 with dissolve
            scene ch02_ahouse01_03 with dissolve
            scene ch02_ahouse01_04 with dissolve
            stop sound
            pause
    menu:
        "Knock again":
            play sound "audio/ambi/knock.mp3"
            scene ch02_ahouse01_03 with dissolve
            scene ch02_ahouse01_04 with dissolve
            scene ch02_ahouse01_03 with dissolve
            scene ch02_ahouse01_04 with dissolve
            stop sound
    play sound "audio/ambi/dooropen.mp3" 
    scene ch02_ahouse01_05 with Dissolve(1.0)
    scene ch02_ahouse01_06 with dissolve
    a "너 인줄 알았어!!"
    scene ch02_ahouse01_07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh05.mp3"
    a "나의 달링~"
    d "정말 보고싶었어요 아만다."
    scene ch02_ahouse01_08 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort02.mp3"
    a "Mwah~"
    scene ch02_ahouse01_09 at hand_camera with Dissolve(0.8)
    d "와우"
    d "당신은 더 어려진거 같아요. 하나도 안변했네요.헤헤."
    scene ch02_ahouse01_10 at hand_camera with Dissolve(0.8)
    a "헤헤 만나자마자 그러기야?"
    a "어서 들어와 허니."

    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch02_ahouse01_11 with dissolve
    play voice_f "audio/voices/milflaugh06.mp3"
    a "하하하 [d_name]."
    a "너의 엉뚱함은 대학에 가도 사라지지 않는구나."
    scene ch02_ahouse01_12 at hand_camera with Dissolve(0.8)
    a "여자 친구 사귄다고 그렇게 설레해 하더니 뭐야 그게?"
    a "그러니까 내가 술 조심하라고 했잖니 하하하."
    scene ch02_ahouse01_13 at hand_camera with Dissolve(0.8)
    d "아 그 당시엔 제이슨과 경쟁적으로 마셔서 좀 오바한거에요."
    d "물론 멍청한 행동이었던건 인정해요 하하하."
    scene ch02_ahouse01_12 at hand_camera with Dissolve(0.8)
    a "여자들을 앞에 두고 제이슨과 술 경쟁을 했다고?!!"
    a "하.....너희들은 여자를 가질 자격이 안돼있어 하하하."
    scene ch02_ahouse01_13 at hand_camera with Dissolve(0.8)
    d "아 그건 오해에요."
    d "여자들이 옆에서 부추겨서 한 짓이었어요."
    d "그러다 둘다 만취해서 여자친구도 못알아보고 잠들었었죠 하하하."
    scene ch02_ahouse01_14 at hand_camera with Dissolve(0.8)
    a "아무튼 너는 먹는것 좀 잘챙기고 다녀야 해."
    a "지금 몸의 두배는 되어야 한다고."
    a "그러다 태풍 불면 프랑스까지 날라가겠어."
    scene ch02_ahouse01_13 at hand_camera with Dissolve(0.8)
    d "제이슨이나 저나 다 먹는데 관심이 별로 없어서 좀 말랐어요."
    d "그래도 체육관에서 운동은 계속 하고 있었어요."
    scene ch02_ahouse01_14 at hand_camera with Dissolve(0.8)
    a "더 살 쪄야 한다고. 그래가지고 여자애들을 번쩍 번쩍 들겠니?"
    n "아만다의 농익은 섹드립이 터져 나왔다."
    n "그녀의 농담은 거기서 그치지 않았다."
    a "알겠니 허니? 힘이 쎄면 뭐든지 수월해진다고. 특히 하체와 허리가 중요해 하하하."
    play voice_f "audio/voices/milflaugh06.mp3"
    a "그래야 모든 체위를 자유롭게 할수 있다고."
    scene ch02_ahouse01_14-02 at hand_camera with Dissolve(0.8)
    d "뭐라고요?!!"
    d "하... 쫌 그런 말은 조심스럽게 하면 안돼요?"
    scene ch02_ahouse01_14-03 at hand_camera with Dissolve(0.8)
    d "아만다를 만났다는게 이제 현실로 와닿네요 하하하."
    scene ch02_ahouse01_14-04 at hand_camera with Dissolve(0.8)
    a "농담하는거 아냐. 너도 알잖아."
    a "성생활은 삶에서 큰 부분이야."
    a "특히 대학교에 가면 고삐가 풀려서 조절되지 않는 섹스로 인생이 망가지는 케이스가 정말 많아."
    scene ch02_ahouse01_14-02 at hand_camera with Dissolve(0.8)
    d "흠......"
    d "그건 맞는 말이긴 하지만..."
    d "그게 자유로운 체위를 하는것과 어떤 관계가 있는거죠?"
    scene ch02_ahouse01_14-05 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    a "몸이 약해서 원하는 자세가 안되면 그거만큼 자괴감 드는게 없을걸? 하하하."
    a "아무튼 넌 지금 육체적으로 더 강해져야 할거 같아."
    a "섹스 뿐만 아니라 널 스스로도 지킬만큼 강해져야해 알겠니?"
    scene ch02_ahouse01_14-02 at hand_camera with Dissolve(0.8)
    d "흠......"
    d "맞는 말이긴한데 보자마자 이런 대화는 좀..."
    scene ch02_ahouse01_14-03 at hand_camera with Dissolve(0.8)
    d "알겠어요. 더 열심히 운동할게요 헤헤."
    d "아마 지금 아만다를 들고 30분은 거뜬히 서있을수 있을걸요?"
    d "들어볼까요? 하하."
    scene ch02_ahouse01_14-06 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh09.mp3"
    a "하하."
    a "어떤 자세로 들건데?"
    a "단순히 들고만 있으면 인정 안되는거 알지?"
    scene ch02_ahouse01_14-07 at hand_camera with Dissolve(0.8)
    d "..........."
    d "(어떤 자세로? 음.........)"
    scene ch02_ahouse01_14-08 at hand_camera with Dissolve(0.8)
    d "(damn...)"
    d "(이런 자세로?)"
    d "(아만다에게 나의 남성성을 어필하기 위해?)"
    scene ch02_ahouse01_14-09 at hand_camera with Dissolve(0.8)
    d "(아니면 이런 자세로?)"
    d "(아만다와 빈틈없이 밀착되기 위해?)"
    d "(..............)"
    scene ch02_ahouse01_14-10 at hand_camera with Dissolve(0.8)
    d "(아니면 이런 자세로?)"
    d "(아만다에게 긴장감을 주기 위해?)"
    d "(................)"
    d "(또 망상하기 시작했군.)"
    d "(진짜 메리에게 말한거 처럼 눈뜨고 잘때까지 섹스생각 뿐이네.)"
    d "(이러다 진짜 사고치는거아냐?)"
    scene ch02_ahouse01_15 at hand_camera with Dissolve(0.8)
    a "오늘 점심은 내가 준비를 못해서 내 시스터네 가게에 가서 먹자."
    a "그녀도 너 엄청 기다리더라."
    scene ch02_ahouse01_13 at hand_camera with Dissolve(0.8)
    d "좋아요!"
    d "안그래도 올리비아도 보고 싶었어요."
    scene ch02_ahouse01_16 at hand_camera with Dissolve(0.8)
    a "잠깐만 기다려. 옷 입고 나올게."
    scene ch02_ahouse01_17 at hand_camera with Dissolve(0.8)
    n "이것이 [d_name]이 보고 싶었던 그녀의 모습이었다."
    n "포근하지만 야한 농담을 던지고, 선을 넘을 듯 하면서 넘지 않는 그녀."
    n "그런 그녀의 모습은 지금 [d_name]에게 다르게 다가왔다."
    n "성인이 된 그에게 아만다는 그와 짝을 이를 수 있는 한 명의 암컷이었다."
    d ".........."
    menu:
        "Follow her":
            if not in_replay:
                $ add_point("lust_amanda", 2, "lust_amanda")
                $ add_point("love_amanda", 2, "love_amanda")
            scene ch02_ahouse01_18 at hand_camera with Dissolve(0.8)
            pause
            play sound "audio/ambi/fabric01.mp3"
            scene ch02_ahouse01_19 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse01_20 at hand_camera with Dissolve(0.8)
            a "허니."
            a "먹고 싶은 메뉴 있어?"
            scene ch02_ahouse01_21 at hand_camera with Dissolve(0.8)
            d "어....."
            d "저는 이탈리안 메뉴면 돼요."
            d "어짜피 올리비아 가게는 이탈리안 레스토랑이잖아요."
            scene ch02_ahouse01_22 at hand_camera with Dissolve(0.8)
            a "하하하"
            a "언제나 단순 심플한 나의 왕자님 헤헤."
            a "나중에 너랑 결혼 할 여자는 참 편하겠어."
            scene ch02_ahouse01_23 at hand_camera with Dissolve(0.8)
            d "네 전 언제나 그렇죠 하하."
            d "근데 모르겠어요."
            d "심리학을 공부하니까 쓸데 없이 생각만 많아지는거 같아요."
            d "자꾸 뭔가 분석하려들고 그런 버릇이 생기고 있어요."
            a "아냐아냐."
            a "넌 원래 단순한 듯 하면서 까다로웠어."
            a "..............."
            a "자 이 옷 어떤가 봐바."
            scene ch02_ahouse01_23-02 at hand_camera with Dissolve(0.8)
            d "!!!!"

            show ch02_ahouse01_24 at smooth_vertical_pan with Dissolve(1.0)
            pause
            scene ch02_ahouse01_25 at hand_camera with Dissolve(0.8)
            a "나 어때 보이니?"
            play voice_f "audio/voices/milflaugh06.mp3"
            a "너무 야하게 입었나? 헤헤."
            scene ch02_ahouse01_26 at hand_camera with Dissolve(0.8)
            d "아니에요. 잘 어울려요."
            d "당신은 어떤 옷을 입어도 다 잘 어울려요."
            d "아만다가 이 세상에서 제일 아름다운 여자에요 헤헤."
            scene ch02_ahouse01_27 at hand_camera with Dissolve(0.8)
            a "이리와 허니."
            a "누가 뭐래도 넌 내게 최고의 남자야."
            scene ch02_ahouse01_28 at hand_camera with Dissolve(0.8)
            a "나 정말정말 니가 보고 싶었어."
            play voice_f "audio/sex/Kissshort02.mp3"
            a "나의 왕자님."
            scene ch02_ahouse01_29 at hand_camera with Dissolve(0.8)
            d "헤헤. 저도 보고싶었어요."
            d "사랑해요 아만다."
            scene ch02_ahouse01_30 at hand_camera with Dissolve(0.8)
            a "나도 사랑해."
            play voice_f "audio/sex/Kissshort02.mp3"
            a "Muah~"
            jump ch02_acar01

label ch02_acar01:
    if not in_replay:
        $ persistent.unlock_ch02_acar01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal10.mp3"
    scene ch02_acar01_01 with dissolve
    play sound "audio/ambi/carleaving.mp3"
    pause
    scene ch02_acar01_02 with dissolve
    pause
    scene ch02_acar01_02-02 with dissolve
    a "젠장! 선글라스를 깜빡했네."
    a "눈을 감고 운전할수도 없고 참..."
    scene ch02_acar01_03 at hand_camera with Dissolve(0.8)
    a "그래서.."
    a "대학교 수업은 어때? 잘 따라갈만해?"
    a "내가 쓸데 없는 고민이라고 그렇게 말했어도 너 수업 어려우면 어떡하지라고 엄청 걱정했었잖아."
    scene ch02_acar01_04 at hand_camera with Dissolve(0.8)
    d "네 전반적으로 괜찮아요."
    d "수업도 맘에 들고요 생각보다 어렵지 않더라고요."
    d "특히 담당 교수님이 맘에 들어요."
    d "가능한 신입생에 맞춰 쉽게 설명하려 노력하세요."
    d "심리학계에서 평가가 상당히 좋은 학자더라구요."
    scene ch02_acar01_05 at hand_camera with Dissolve(0.8)
    a "와우."
    a "까다로운 [d_name]의 학문적 갈증을 채워준 교수님이라니 대단하네."
    a "힘들게 결정한 전공이었으니 더 뿌듯하겠어."
    scene ch02_acar01_04-02 at hand_camera with Dissolve(0.8)
    d "네 만약 뭔가 내가 배우고 성장한다는 느낌이 없으면 어떨까하고 걱정했는데 다행이죠."
    d "작은 도시의 대학교에서 그런 실력있는 교수님이 있었다니 행운이에요."
    d "그리고 그 교수님은 뭐랄까...."
    scene ch02_acar01_05-02 at hand_camera with Dissolve(0.8)
    a ".............."
    a "교수님이 어떤데?"
    a "뭘 뜸들이는 거야?"
    scene ch02_acar01_06 with dissolve
    d "음......"
    scene ch02_acar01_07 with dissolve
    d "음...... 그녀가 좋은 이유는"
    scene ch02_acar01_08 with dissolve
    d "그녀는 몸매도 어메이징 하거든요 하하하."
    scene ch02_acar01_09 with dissolve
    play voice_f "audio/voices/milflaugh07.mp3"
    a "하하하하."
    a "뭐야 겨우 그 말 하려고 뜸들인거니?"
    scene ch02_acar01_09-02 at hand_camera with Dissolve(0.8)
    a "난 니가 그녀를 몰래 짝사랑하고 있다고 할 줄 알았지 하하하."
    a "아님 뭔가 더 강력한 말을 할 줄 알았는데.."
    a "흠..... 좀 싱거운걸.."
    scene ch02_acar01_10 at hand_camera with Dissolve(0.8)
    a "하지만 나 좀 질투 나는데?"
    a "어떤 여자가 몸매로 우리 [d_name]의 마음을 훔친거지?"
    scene ch02_acar01_10-02 with dissolve
    a "솔찍하게 말해봐."
    a "나와 그 교수님 둘 중에 누구 몸매가 더 좋은거 같아?"
    scene ch02_acar01_05-04 at hand_camera with Dissolve(0.8)
    d "(............)"
    d "(왜 저런걸 물어보지?)"
    d "(이거 왠지 느낌이 대답 잘해야 할 거 같은데?)"
    scene ch02_acar01_11 with dissolve
    d "하하하. 너무 당연한걸 묻는거 아니에요?"
    menu:
        "Of course, Amanda's figure is the best.":
            scene ch02_acar01_11 at hand_camera with Dissolve(0.8)
            d "당연히 아만다의 몸매가 최고에요."
            d "아만다의 몸매는 우리 지역의 보물이잖아요."
            a "뭐? 이 지역의 보물?"
            d "어떤 여자도 너의 몸매와 비교할 수 없어요."
    scene ch02_acar01_12 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh09.mp3"
    a "하하하하."
    a "이 느끼한 녀석같으니 헤헤."
    a "일단 다른 여자친구를 만날 기본 소양은 갖췄다고 인정해줄게."
    a "대학에 가기전에 내가 열심히 잔소리한 보람은 있네."
    scene ch02_acar01_13 with dissolve
    d "헤헤. 그렇죠....."
    d "아만다에게 많이 배웠어요.."
    scene ch02_acar01_14 at hand_camera with Dissolve(0.8)
    d "(젠장....)"
    d "(이 타이밍에 발기를 한다고?....하...)"
    scene ch02_acar01_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_acar01_16 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_acar01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_acar01_18 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/carpass.mp3" volume 0.5
    pause
    jump ch02_cafe01

label ch02_cafe01:
    if not in_replay:
        $ persistent.unlock_ch02_cafe01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal09.mp3" volume 1.5
    play sound "audio/ambi/carpass02.mp3"
    scene ch02_cafe01_01 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch02_cafe01_02 at hand_camera with Dissolve(0.8)
    pause   
    scene ch02_cafe01_03 with Dissolve(2.0)
    pause   
    scene ch02_cafe01_04 at hand_camera with Dissolve(0.8)
    pause
    d "(damn..)"
    d "(그녀의 옆 가슴이 내 팔뚝에 닿고 있어..)"
    d "(메리 가슴만큼 부드러워....하...)"
    d "(이런걸 멜론이라고 하는건가.)"
    d "(진짜 신입생 여자애들하고는 차원이 다르네..)"
    if not in_replay:
        $ bio_olivia = True
        $ bio_stella = True
    scene ch02_cafe01_05 at hand_camera with Dissolve(1.2)
    o "글쎄 나한테 그런말을 하더라니까!"
    o "세상에 그런 정신 나간 남자가 또 있을까 싶다."
    scene ch02_cafe01_06 with dissolve
    pause
    o "(하하 왔구나!!!)"
    scene ch02_cafe01_06-02 at hand_camera with Dissolve(1.2)
    o "(이런이런...)"
    o "(저 년 옷 입은거 봐라..)"
    o "(아주 젖이 밖으로 튀어 나오겠네.)"
    o "(아줌마가 주책이야.)"
    scene ch02_cafe01_07 with dissolve
    d "안녕하세요 올리비아!!"
    scene ch02_cafe01_08 at hand_camera with Dissolve(0.8)
    o "헤이"
    o "너희들 왔구나!"
    scene ch02_cafe01_09 at hand_camera with Dissolve(0.8)
    o "잘 왔어 언니."
    a "잘 지냈니?"
    scene ch02_cafe01_10 at hand_camera with Dissolve(0.8)
    o "헤이 [d_name]!!"
    o "너 우리를 1년 동안 그렇게 혼자 놔둬도 되는거야?!"
    scene ch02_cafe01_12 at hand_camera with Dissolve(0.8)
    o "너는 좀 혼나야돼."
    o "대학 갔다고 우리를 잊은거니?"
    o "내가 널 얼마나 예뻐했는데 말이야!"
    scene ch02_cafe01_13 with dissolve
    o "요 못된 녀석!"
    scene ch02_cafe01_14 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
        $ add_point("lust_olivia", 1, "lust_olivia")
        $ add_point("sus_olivia", 1, "sus_olivia")
    o "내가 집에 자주 오라고 몇 번을 말했니 어?"
    scene ch02_cafe01_15 at hand_camera with Dissolve(0.8)
    d "미안해요 올리비아. 너도 알잖아요."
    d "프랭크 때문에 어쩔수 없었어요. 헤헤."
    scene ch02_cafe01_15-02 at hand_camera with Dissolve(0.8)
    o "아무리 그래도 아만다는 너 아니면 누가 챙기겠니?"
    o "아만다는 매일 외로운 밤을 보내고 있다고."
    o "사람이 외로우면 수명까지 줄어들어. 그거 아니?"
    scene ch02_cafe01_16 at hand_camera with Dissolve(0.8)
    a "(지랄하네.)"
    a "(지는 매일 남자들이랑 뒹굴고 다니느라 연락 한 번 제대로 안했으면서 참나.)"
    a "(내가 모를거 같냐?)"
    scene ch02_cafe01_16-02 at hand_camera with Dissolve(0.8)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3" 
    scene ch02_cafe01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe01_18 at hand_camera with Dissolve(0.8)
    a "맛있게 먹어 허니."
    a "난 맛만 볼거야. 요즘 다이어트 하고 있거든."
    a "니가 다 먹어야 해."
    scene ch02_cafe01_19 at hand_camera with Dissolve(0.8)
    d "하하 알겠어요."
    d "아만다를 번쩍 들려면 더 열심히 먹어야 겠어요 하하하."
    scene ch02_cafe01_20 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh08.mp3"
    a "하하하하. 그래?"
    a "어떤 자세로 들건데?"
    a "말만 하지말고 좀 진짜로 해봐."
    a "나는 힘쎈 남자가 좋아요. 헤헤."
    scene ch02_cafe01_21 at hand_camera with Dissolve(0.8)
    a "그런데 허니."
    a "그때 일 이후로 여자 친구와 완전히 헤어진거야?"
    a "왜 있잖아."
    a "보통 그렇게 헤어져도 다시 메세제 주고 받고 하면서 완전 관계를 끊진 않거든."
    a "그 사이에 정도 들었을거고 시간도 어느정도 지났으니 말이야.."
    a "20대 초반엔 욱해서 헤어지기도 하니까 꼴도보기 싫어 이정도는 아니거든."
    scene ch02_cafe01_22 at hand_camera with Dissolve(0.8)
    d "..........."
    d "하....."
    d "그녀는...."
    d "그때 일 후로 일주일만에 다른 사람과 사귀기 시작했어요."
    scene ch02_cafe01_23 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fwhat01.mp3"
    a "뭐 일주일?"
    a "완전 썅년이네."
    a "그럼 널 만나면서 양다리 걸치고 있었단거야!"
    scene ch02_cafe01_23-02 at hand_camera with Dissolve(0.8)
    a "어떻게 그럴 수 있지?"
    a "그 나이땐 누구든 불장난을 한다지만 그래도 몇 달간 사귄 정이 남아있을 시기인데?"
    a "여지도 없이 그렇게 갈아탈수 있나?"
    scene ch02_cafe01_24 at hand_camera with Dissolve(0.8)
    a "아 요즘 어린 여자들 진짜 이해 불가야."
    a "그렇게 계속 하면 1년에 수십명과 섹스하고 살겠네."
    a "너무 헤픈거 아니니?"
    a "그러다 진짜 인생 망가진다고."
    scene ch02_cafe01_25 at hand_camera with Dissolve(0.8)
    d "..............."
    d "뭐 어쩌겠어요."
    d "근데 뭐 다런건 아니잖아요."
    scene ch02_cafe01_23-02 at hand_camera with Dissolve(0.8)
    a "허니..."
    a "넌 때론 너무 착해서 탈이야."
    a "그런 짓을 당했으면 너도 똑같이 돌려줬어야지."
    scene ch02_cafe01_24 at hand_camera with Dissolve(0.8)
    a "너도 보란듯이 다른 여자를 옆에 끼고 그년에게 보여줘!"
    a "이 세상에 복수처럼 달콤한게 없는 법이야."
    a "눈에눈, 이에는 이라고."
    scene ch02_cafe01_25 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "이미 지난 일이에요."
    d "더 좋은 여자가 어딘가엔 있겠죠."
    scene ch02_cafe01_26 with dissolve
    pause   
    scene ch02_cafe01_27 at hand_camera with Dissolve(0.8)
    pause   
    scene ch02_cafe01_28 at hand_camera with Dissolve(1.5)
    play voice_f "audio/voices/fahem01.mp3"
    pause   
    scene ch02_cafe01_29 at hand_camera with Dissolve(0.8)
    o "음식은 먹을만해?"
    d "네 진짜 맛있어요!!"
    o "고마워 헤헤."
    o "근데 무슨 얘기들을 그렇게 재미있게 하는거야?"
    scene ch02_cafe01_30 at hand_camera with Dissolve(0.8)
    o "나도 좀 이야기에 끼워줘."
    o "너의 연애 얘기지? 헤헤."
    jump ch02_lake01

label ch02_lake01:
    if not in_replay:
        $ persistent.unlock_ch02_lake01 = True
    stop music
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Meanwhile, a lake on the outskirts of Milfheim.." at truecenter with Dissolve(2.0)
    $ _skipping = True
    pause
    play music "audio/bgm/normal03.mp3"
    play sound "audio/ambi/park01.mp3" loop
    scene ch02_lake01_01 with Dissolve(1.5)
    pause
    scene ch02_lake01_02 with Dissolve(1.5)
    pause
    scene ch02_lake01_03 with Dissolve(1.0)
    pause
    scene ch02_lake01_04 with Dissolve(1.0)
    pause
    scene ch02_lake01_05 with Dissolve(1.5)
    pause
    scene ch02_lake01_06 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_lake01_07 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_lake01_08 with dissolve
    f "Damn it. Not a single bite today."
    f "I shouldn't have come out here just to go home empty-handed."
    f "I caught one in the morning, and it's been nothing but bad luck since."
    scene ch02_lake01_09 with dissolve
    f "Hey Emma!"
    if not in_replay:
        $ bio_emma = True
    f "Say a prayer or something to get the fish biting."
    f "Don't just lie there so comfortably, do something helpful!"
    scene ch02_lake01_10 at hand_camera with Dissolve(0.8)
    e ".........."
    e "That's not part of the arrangement, Daddy."
    e ".........."
    e "My only duty is to be your companion and satisfy you."
    scene ch02_lake01_11 with dissolve
    f "Ha! Is that so?!"
    scene ch02_lake01_08 at hand_camera with Dissolve(0.8)
    f "What has this world come to..."
    f "Everything is about the damn business."
    f "Terms! Terms! Terms!"
    e "No, Frank."
    e "This is about the promise we made. It's not just about the business."
    scene ch02_lake01_09 at hand_camera with Dissolve(0.8)
    f "Oh, really?"
    f "Fine, then I'll take what I'm owed from our deal!"
    f "The 'special service' you promised in our agreement!"
    scene ch02_lake01_10-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/zipper.mp3"
    pause
    scene ch02_lake01_10-03 at hand_camera with Dissolve(0.8)
    f "Alright Emma, start now."
    f "Show me the appreciation I've properly supported you for!!"
    scene ch02_lake01_12 at hand_camera with Dissolve(0.8)
    e "Jesus, Frank."
    e "Don't be so aggressive. I'll do my best to provide you with pleasure."
    e "I'm even willing to put up with those ridiculous positions of yours. But..."
    e "Look at your condition. You need to get yourself ready first."
    scene ch02_lake01_13 at hand_camera with Dissolve(0.8)
    f "................"
    scene ch02_lake01_13-02 at hand_camera with Dissolve(0.8)
    f "Don't you try to brush me off."
    f "Getting me in the mood is part of the agreement too!!"
    f "Dammit Emma. Just start."
    f "Once you begin, I'll be ready!!"
    scene ch02_lake01_14 at hand_camera with Dissolve(0.8)
    e "Dammit."
    e "I was crazy to agree to this..."
    scene ch02_lake01_15 at hand_camera with Dissolve(1.5)
    e ".................."
    f "Come on Emma. Hurry up."
    e "(shit.)"
    e "Aright aright."
    play voice_f "audio/sex/oral03.mp3" loop
    image ch02_lake01_BJ01:
        "ch02_lake01_16" with dissolve
        0.5
        "ch02_lake01_17" with dissolve
        0.5
        "ch02_lake01_18" with dissolve
        0.5
        "ch02_lake01_17" with dissolve
        0.5
        "ch02_lake01_16" with dissolve
        0.5
        repeat
    scene ch02_lake01_BJ01 at hand_camera
    pause
    play sound "audio/ambi/park01.mp3" loop
    scene ch02_lake01_19 with dissolve
    f "Dammit Emma. You're the best."
    scene ch02_lake01_BJ01 at hand_camera
    pause
    scene ch02_lake01_19 with dissolve
    f "Dammit!!"
    scene ch02_lake01_20 with dissolve
    stop sound
    f "Emma, lie down now!"
    scene ch02_lake01_21 with vpunch
    play voice_f "audio/voices/fhurt07.mp3"
    e "Ah!"
    play sound "audio/ambi/park01.mp3" loop
    scene ch02_lake01_22 at hand_camera with Dissolve(0.8)
    e "You son of a..."
    e "Don't treat me like that!"
    e "I'm not just some disposable object!"
    scene ch02_lake01_23 at hand_camera with Dissolve(0.8)
    e "Look at yourself, Frank."
    e "Look at your poor condition."
    scene ch02_lake01_24 with dissolve
    f "What?"
    scene ch02_lake01_25 with dissolve
    f "................"
    f "Oh, for god's sake! You ruined the mood again."
    scene ch02_lake01_23 at hand_camera with Dissolve(0.8)
    e "You think you can satisfy me with that?"
    e "Dream on, you pathetic man!"
    e "No woman would ever truly want to be with someone like you!"
    scene ch02_lake01_26 at hand_camera with Dissolve(0.8)
    f "Damm it."
    e "Let's do this, Frank."
    scene ch02_lake01_27 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/fabric01.mp3"
    f "Yeah, that's what I'm talking about!"
    f "Show me everything!!"
    scene ch02_lake01_28 at hand_camera with Dissolve(0.8)
    e "Come find me at my place when you're in better shape."
    e "And today, I'll enjoy watching you fish like that, so I'm keeping the support money."
    e "How about that, Frank?"
    scene ch02_lake01_29 at hand_camera with Dissolve(0.8)
    f "You sly woman."
    f "You're going to keep my support for nothing?"
    f "You want me to just show you my body and be satisfied?!!"
    f "Don't even think about it, you witch!"
    scene ch02_lake01_29-02 at hand_camera with Dissolve(0.8)
    e "Fine."
    e "I'll return your support, so let's go back to town right now."
    e "Of course, I'll keep a portion for the 'service' I've already provided."
    scene ch02_lake01_30 at hand_camera with Dissolve(0.8)
    f "Fine. I'll visit you at the center when I'm feeling better."
    f "Next time, be more affectionate, like a real partner."
    scene ch02_lake01_31 at hand_camera with Dissolve(0.8)
    e "Alright, Daddy."
    e "Come prepared next time."
    e "I'll give you the warmest welcome possible."
    e "And I'll show you heaven."
    scene ch02_lake01_31-02 at hand_camera with Dissolve(0.8)
    f "Heaven......."
    f "..............."
    f "Good lord....."
    scene ch02_lake01_32 with Dissolve(2.0)
    pause
    scene ch02_lake01_33 with Dissolve(2.0)
    pause
    jump ch02_cafe02

label ch02_cafe02:
    if not in_replay:
        $ persistent.unlock_ch02_cafe02_fake = True
    play music "audio/bgm/normal05.mp3"
    scene ch02_cafe01_29 with Dissolve(2.0)
    pause       
    scene ch02_cafe01_30 at hand_camera with Dissolve(0.8)
    o "무슨 얘기들을 그렇게 재미있게 하는거야? 헤헤."
    o "나도 좀 이야기에 끼워줘."
    scene ch02_cafe02_01 at hand_camera with Dissolve(0.8)
    a "있잖아 대학교 신입생과 하는 대화 뻔하지 않겠어?"
    a "이 꼬마녀석의 러브 스토리야. 클래식이지 클래식 하하."
    scene ch02_cafe02_02 at hand_camera with Dissolve(0.8)
    o "오! 그건 내 전공이잖아."
    o "사랑스러운 우리 [d_name]에게 어떤 연애 문제가 있을까?"
    scene ch02_cafe02_03 with Dissolve(1.5)
    o "설마 나에게 말하기 부끄러운 이야기 일까나? 헤헤."
    scene ch02_cafe02_04 with dissolve
    pause  
    scene ch02_cafe02_05 at hand_camera with Dissolve(0.8)
    d "(맙소사..)"
    d "(그녀 가슴이 이렇게 컸었나?)"
    d "(..............)"
    d "(아만다와 막상막하야..)"
    scene ch02_cafe02_04 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
        $ add_point("lust_olivia", 1, "lust_olivia")
        $ add_point("sus_olivia", 1, "sus_olivia")
    o "(후훗.)"
    scene ch02_cafe02_07 at hand_camera with Dissolve(0.8)
    o "([d_name]이 녀석 이제는 과감하게 쳐다 보네.)"
    o "(포커페이스도 못하고 저렇게 얼빵하게 쳐다보니 여자들이 싫어하지.)"
    o "(좋아. 이젠 너도 성인이라 이거지?)"
    n "그녀는 [d_name]을 1년 만에 봤을 때 그가 더 어른스러워 졌다고 느꼈다."
    n "그리고 그와 포옹했을 때 그의 몸이 더 단단해지고 커졌다는 것을 느꼈다."
    n "말인 즉슨, 이젠 자신의 양심의 가책을 내려놓고 더 편하게 [d_name]과 대화할 수 있다는 뜻이었다."
    scene ch02_cafe02_08 at hand_camera with Dissolve(0.8)
    o "(그럼 어른의 대화를 해야지. 뭐야 이게 간지럽게 빙빙 돌려서들 말하고 말이야.)"
    o "(아만다는 대체 언제까지 [d_name]을 애 취급할거지?)"
    o "(재미 없는 인간들 같으니.)"
    scene ch02_cafe02_08-02 at hand_camera with Dissolve(0.8)
    o "(흠.....)"
    o "(무슨 꿍꿍이니 아만다?)"
    o "(설마 그가 영원히 너만의 [d_name]으로 남길 바라는거야?)"
    o "(그가 여자를 만나서 너의 곁을 떠나는게 두려운거니?)"
    scene ch02_cafe02_09 at hand_camera with Dissolve(0.8)
    o "무슨 일인데 그래? 나한테는 얘기 안할거야?"
    scene ch02_cafe02_10 at hand_camera with Dissolve(0.8)
    a "아 별거 아냐."
    a "그는 집에 오기 얼마전에 여자친구와 헤어졌데."
    a "근데 그년이 글쎄 일주일만에 딴 남자와 사귄다지 뭐야."
    a "그래서 같이 그년 욕을 해주고 있었어."
    scene ch02_cafe02_11 at hand_camera with Dissolve(0.8)
    o "하하하 언니. 너무 [d_name]편만 드는거 아니야?"
    o "그건 여자쪽 이야기도 들어봐야 한다고."
    scene ch02_cafe02_12 at hand_camera with Dissolve(0.8)
    o "우리 왕자님이 그 여자애를 잘못 다뤘을수도 있잖아."
    o "애처롭다고 마냥 편들어주면 오히려 역효과 생긴다고."
    scene ch02_cafe02_13 at hand_camera with Dissolve(0.8)
    a "그년이 헤어지고 일주일만에 딴 놈을 만났다는데 더 말할필요도 없지."
    a "어쩌면 그럴 수 있니? 말세야 말세."
    scene ch02_cafe02_14 at hand_camera with Dissolve(0.8)
    o "맙소사 아만다."
    o "요즘 시대에 일주일이면 오히려 정숙한 여자라고."
    o "양다리 걸치는 사람들이 수두룩 한데 헤어지고 딴 놈 만난걸 어떻게 원망하겠어."
    o "안그래?"
    o "[d_name]도 이 여자 저 여자 만나고 다녀야 점점 능숙해 질거라고."
    o "전혀 나쁜게 아냐."
    scene ch02_cafe02_15 at hand_camera with Dissolve(0.8)
    a "하 그래?! 우리 둘을 부디 너의 세상에 포함하지 말아줘."
    a "우리 [d_name]은 요즘 시대에 보기 드문 순정남이라고."
    a "로미오와 줄리엣 처럼 한 여자를 만나서 역사에 남을 커플이 될거야."
    scene ch02_cafe02_16 at hand_camera with Dissolve(0.8)
    n "올리비아는 순간 아만다에게 고마웠다."
    n "자신이 비튼 대화의 방향으로 잘 따라와 줬고 자신이 결정적인 말을 날릴 수 있는 판을 깔아주었기 때문이다."
    scene ch02_cafe02_16-02 at hand_camera with Dissolve(0.8)
    o "로미오와 줄리엣? 하....지금이 무슨 중세시대니?"
    o "안타깝다 정말."
    o "니가 나와 같이 살았으면 지금 모든 여대생들을 다 따먹고 다녔을텐데 하하하."
    scene ch02_cafe02_16-04 at hand_camera with Dissolve(0.8)
    d "(......)"
    scene ch02_cafe02_16-03 at hand_camera with Dissolve(0.8)
    o "(물론 나도 따먹고 말이지.헤헤.)"
    o "(매일 매일 보지가 욱신거릴 정도로.)"
    o "(중년 여성만이 줄 수 있는 즐거움을 제대로 알려줄수 있는데..)"
    scene ch02_cafe02_17 at hand_camera with Dissolve(0.8)
    a "뭐?! 맙소사 올리비아. 지금 무슨 말을 하는거야?"
    a "대학교가 연애하러 가는 곳인줄 아니?"
    a "1년만에 [d_name]을 만났는데 할 말이 그런거 밖에 없니?"
    scene ch02_cafe02_18 at hand_camera with Dissolve(0.8)
    a "맙소사. 이러니까 내가 널 멀리하는거야."
    a "난 너 처럼 머리에 섹스만 가득찬 사람들이 제일 싫어."
    scene ch02_cafe02_19 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh04.mp3"
    o "하하하 언니. 나를 그렇게 평가 하지마."
    o "난 그저 솔찍하게 말할 뿐이야."
    o "(그리고 나못지않게 너의 머리속에도 섹스로 가득차있잖아.)"
    o "[d_name]이 더 매력적인 남자가 되길 바라는 마음에서 한 말이라고."
    o "어린 여자부터 중년 여성들까지 모두에게 사랑 받는 남자 얼마나 좋아 안그래?"
    o "(언니에게도 나쁠거 없을텐데?)"
    scene ch02_cafe02_20 at hand_camera with Dissolve(0.8)
    o "헤이 [d_name]."
    o "재미없는 아만다 말고 나랑 데이트나 하러가자."
    o "오늘만 내 귀여운 남자친구가 되주는거 어때?"
    scene ch02_cafe02_20-02 at hand_camera with Dissolve(0.8)
    n "그는 약간 혼란스러웠다."
    n "그녀를 종종 보긴 했지만 그녀가 이런 캐릭터를 가진 여성인줄 모르고 있었다."
    n "그리고 그 순간 그녀가 친 거미줄에 완전히 걸려들었다."
    scene ch02_cafe02_21 at hand_camera with Dissolve(0.8)
    a "오 그래? 데미안도 웃기만 하는거 보니까 둘이 아주 죽이 잘 맞네."
    a "그러다 신혼여행 가겠다?"
    scene ch02_cafe02_22 at hand_camera with Dissolve(0.8)
    a "잘들 해봐. 난 화장실 다녀온다."
    a "오! 그리고 2세 이름은 뭘로 할건지 정하면 알려줘."
    o "(하하. 저봐.)"
    o "(니 마음속 깊은 곳에 숨어있는 본성이 꿈틀거리기 시작하지?)"
    o "(그런걸 숨기고 사니까 늙는거라고.)"
    scene ch02_cafe02_23 at hand_camera with Dissolve(0.8)
    a "(저 쌍년 저거 버릇 어디 안가네.)"
    a "(어떻게 쟤는 나이를 먹어도 변하질 않네.)"
    a "(남자 자지라면 자다가도 벌떡벌떡 일어나는 년!)"
    a "(하! 니가 이 언니에게 도전한다 이거니?)"
    scene ch02_cafe02_24 at hand_camera with Dissolve(0.8)
    o "후후후."
    o "잘 생각해봐 [d_name]."
    o "프랭크 때문에 집에 가지도 못하는데 방학 동안 내 집에서 지내는거 어때?"
    o "프랭크 처럼 못살게 구는 사람도 없고."
    o "내 집에선 아무 규칙 없이 자유롭게 지낼 수 있어. 헤헤."
    o "늦게 자도, 밤새 게임해도 아무도 뭐라 안해."
    pause
    o "난 속옷도 안입고 다닌다고 헤헤헤."
    d "(!!!!!!!!!!!!)"
    scene ch02_cafe02_24-02 at hand_camera with Dissolve(0.8)
    o "너도 알잖아. 나 지금 남편하고 별거하고 있어."
    play voice_f "audio/voices/Fsigh01.mp3"
    o "나 요즘 너무 외로워..."
    scene ch02_cafe02_24-03 at hand_camera with Dissolve(0.8)
    o "잠깐만...."
    o "내가 사는 집 사진을 보여줄게."
    pause
    o "아 찾았다!"
    scene ch02_cafe02_24-03-02 at hand_camera with Dissolve(0.8)
    o "자 봐. 내 집은 이렇게 싱그러운 햇빛이 든다고."
    o "칙칙한 아만다네 동네 말고 방학 동안 나랑 지내자 헤헤."




    $ phone_start()
    show screen phone_ui
    $ create_phone_channel("olivia_dm", "Olivia", ["Olivia", phone_config["phone_player_name"]], "phone/icons/olivia.png")
    $ switch_channel_view("olivia_dm")

    $ send_phone_message("Olivia", "images/phone/media/ch02_olivia01.webp", "olivia_dm", 2, summary_alt="olivia Photo", do_pause=False)
    $ npc_type_and_send("Olivia", "So? Don’t you want to come over to my place right now? ❤️", "olivia_dm", typing_time=3)
    pause
    o "당장 짐싸들고 오고싶지 않아?"
    o "어떻게 생각해?"







    hide screen phone_ui
    scene ch02_cafe02_24-04 with dissolve
    pause
    scene ch02_cafe02_20-02 at hand_camera with Dissolve(0.8)
    d "이건 정말이지....."
    d "제가 본 것 중에 가장 아름다워요.."
    if not in_replay:
        $ add_point("lust_olivia", 3, "lust_olivia")
        $ add_point("sus_olivia", 1, "sus_olivia")
    scene ch02_cafe02_24-05 at hand_camera with Dissolve(0.8)
    o "뭐가 아름답다는 거야?"
    play voice_f "audio/voices/flaugh04.mp3"
    o "내 주방이? 하하하."
    o "이 꼬마 녀석 생각보다 능글 맞네."
    scene ch02_cafe02_25 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_26 at hand_camera with Dissolve(0.8)
    o ".............."
    scene ch02_cafe02_27 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_28 at hand_camera with Dissolve(0.8)
    o "아 그거 기계가 지금 좀 이상해."
    scene ch02_cafe02_29 at hand_camera with Dissolve(0.8)
    o "지금 되다 안되다 그러네."
    o "이제 금방 될거야."
    o "컵 올리고 레버를 내려봐."
    scene ch02_cafe02_30 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    d "(웟더뻑!)"
    n "순간 그의 시야에 들어온 것은.."
    scene ch02_cafe02_30-02 at hand_camera with Dissolve(0.8)
    n "그가 아침에 일어나 잠에 들 때 까지 원하는 바로 그것이었다."
    scene ch02_cafe02_31 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_cafe02_31-02 at hand_camera_zoom with vpunch
    play music "audio/bgm/erotic02.mp3"
    d "(웟 더 퍽!)"
    scene ch02_cafe02_31-03 at hand_camera with Dissolve(0.8)
    d "(맙소사 올리!!)"
    scene ch02_cafe02_31-04 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_olivia", 7, "lust_olivia")
    play voice_f "audio/voices/flaugh03.wav"
    o "(니가 지금 무슨 생각하는지 다 느껴져.)"
    o "(순진한 녀석.)"
    scene ch02_cafe02_32 at hand_camera with Dissolve(0.8)
    a "후후."
    scene ch02_cafe02_33 at hand_camera with Dissolve(0.8)
    a "그래서 [d_name]을 꼬시는데 성공한거야?"
    scene ch02_cafe02_34 at hand_camera with Dissolve(0.8)
    a "!!!!!!!!!!!!!!!!!!!!!!!!"
    scene ch02_cafe02_35 at hand_camera with Dissolve(0.8)
    a "(뭐야 저 미친년!!!!!!!)"
    a "(저 미친년 저거 일부러 저러는거야!!)"
    scene ch02_cafe02_35-02 with dissolve
    pause
    scene ch02_cafe02_36 at hand_camera with Dissolve(0.8)
    a "(이 걸레 같은 년!!)"
    a "(감히 누구에게 이 더러운 엉덩이를 들이대는거야!!!!!)"
    scene ch02_cafe02_30 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_37 with dissolve
    a "(썅년!)"
    scene ch02_cafe02_37-02 with vpunch
    play sound "audio/ambi/slap01.mp3"
    pause
    scene ch02_cafe02_38
    play voice_f "audio/voices/fhurt07.mp3"
    o "허?!!!!!!!!!!"
    n "순간 올리비아는 깜짝 놀랐다."
    n "자신의 엉덩이를 때린것이 [d_name]이라고 생각했기 때문이다."
    n "아주 짧은 순간이었지만 그녀는 설명하기 힘든 흥분을 느꼈다."
    o "(뭐야 이거?)"
    scene ch02_cafe02_39 at hand_camera with Dissolve(0.8)
    a "................."
    a "너 지금 나랑 해보자는거야?"
    scene ch02_cafe02_39-02 at hand_camera with Dissolve(0.8)
    o "(젠장!!)"
    o "(어쩐지 여자손 같더라..)"
    o "(저 바보 녀석이 이렇게 과감할리가 없지.)"
    scene ch02_cafe02_40 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal05.mp3"
    a "배부르게 먹었니 허니?"
    a "그럼 어서 집으로 가자."
    scene ch02_cafe02_41 at hand_camera with Dissolve(0.8)
    d "아야."
    d "아... 알겠어요."
    scene ch02_cafe02_42 with Dissolve(2.0)
    pause
    scene ch02_cafe02_43 at hand_camera with Dissolve(0.8)
    o "언니 가슴은 참 부드러워."
    o "[d_name]도 언니 가슴이 얼마나 부드러운지 알지?"
    o "저 녀석에게 빨리 여자의 즐거움을 알려줘. 안그럼 내가 쟤 꼬셔서 가져가버린다."
    scene ch02_cafe02_44 at hand_camera with Dissolve(0.8)
    a "너 이년아."
    a "왜 문을 활짝 열고 정글의 동굴까지 보여주지 그랬냐?"
    a "얼마든지 [d_name]을 꼬셔봐."
    a "머리에 자지만 가득찬 이 더러운 년!"
    scene ch02_cafe02_44-02 at hand_camera with Dissolve(0.8)
    o "후후후."
    o "그럼 공식적으로 너에게 허락을 받은거네? 하하하."
    o "저 녀석은 이제 죽을때 까지 내 엉덩이 생각 뿐일걸?"
    scene ch02_cafe02_44 at hand_camera with Dissolve(0.8)
    a "오 그래?"
    a "오늘이 지나면 그의 머릿속에서 너의 엉덩이 따위는 흔적도 없이 사라질거야."
    o "헤헤. 두고보면 알겠지."
    scene ch02_cafe02_45 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_46 at hand_camera with Dissolve(0.8)
    n "올리비아는 모든 힘을 다해 [d_name]과 몸을 밀착 시켰다."
    n "아까 처음 만났을때와 다르게 [d_name]도 몸을 밀착시키는 것을 보고 그도 자신을 원한다는 것을 느꼈다."
    pause
    scene ch02_cafe02_47 at hand_camera with Dissolve(0.8)
    o "허니."
    o "다음 번엔 우리 둘만 만나자 알겠지?"
    o "저 늙은 아줌마는 프랭크랑 놀라고 하고 우리끼리 데이트하자고."
    scene ch02_cafe02_48 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch02_cafe02_49 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_47 at hand_camera with Dissolve(0.8)
    o "허니."
    o "여자는 행동하는 남자를 좋아해."
    o "더 자신있게 행동하라고 언제든지."
    o "여자가 할 수 있는게 싸대기 밖에 더 있겠어?"
    scene ch02_cafe02_49-02 with dissolve
    o "..............."
    scene ch02_cafe02_49-03 with dissolve
    pause
    scene ch02_cafe02_47 with dissolve
    o "키스미"
    d "알겠어요."
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
        $ add_point("lust_olivia", 2, "lust_olivia")
    scene ch02_cafe02_49-04 at hand_camera with Dissolve(2.0)
    play voice_f "audio/sex/kissshort03.mp3"
    pause
    scene ch02_cafe02_47 with Dissolve(1.0)
    o "바보야."
    o "입벌려 봐."
    scene ch02_cafe02_49-05 with dissolve
    pause
    scene ch02_cafe02_49-02 with dissolve
    scene ch02_cafe02_49-06 with dissolve
    pause
    scene ch02_cafe02_49-07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/liquid01.mp3"
    d "!!!!!!!!!!!!!!!!!!!!!!!!!"
    scene ch02_cafe02_49-08 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/liquid01.mp3"
    pause
    scene ch02_cafe02_49-09 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_49-10 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_49-11 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_cafe02_49-02 with dissolve
    o "..............."
    scene ch02_cafe02_47 with dissolve
    pause
    scene ch02_cafe02_50 with dissolve
    o "다음에 볼땐 더 확신에 찬 진짜 남자가 돼 있길 바래. 꼬맹아."
    o "메세지 보내. 알았지?"
    scene ch02_cafe02_51 at hand_camera with Dissolve(0.8)
    a "컴온 허니."
    a "어두워 지려고 한다. 어서 가자."
    scene ch02_cafe02_52 at hand_camera with Dissolve(2.0)
    pause
    play music "audio/bgm/normal11.mp3"
    scene ch02_cafe02_53 at hand_camera with Dissolve(2.0)
    a "..........................."
    scene ch02_cafe02_54 at hand_camera with Dissolve(0.8)
    d "............."
    d "하하 왜 그렇게 쳐다봐요?"
    scene ch02_cafe02_55 at hand_camera with Dissolve(0.8)
    a "너 이 녀석."
    a "올리의 엉덩이 잘 감상 했어?"
    a "아주 넋놓고 쳐다보더만."
    a "그렇게 됐으면 니가 뭔가 조치를 했어야지!"
    scene ch02_cafe02_56 at hand_camera with Dissolve(0.8)
    d "뭐?!"
    d "아니에요. 나도 그냥 몸이 얼었던거에요."
    d "그리고 제가 그 상황에서 스커트를 내리려면 그녀의 엉덩이에 손이 닿을수 밖에 없는걸요?"
    d "잘못하면 제가 변태로 몰린다구요."
    scene ch02_cafe02_57 at hand_camera with Dissolve(0.8)
    a "하! 퍽이나!"
    a "그년은 니가 가까이 오면 오히려 엉덩이를 너에게 내밀었을걸?!!!"
    a "무슨 말인지 알아?!!"
    a "그녀의 엉덩이를 너의 자.....!!"
    a "......."
    a "아무튼 그 더러운 년!"
    a "항상 그런식이야!!"
    scene ch02_cafe02_58 at hand_camera with Dissolve(0.8)
    a "이리와 이녀석!"
    scene ch02_cafe02_59 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort03.mp3"
    a "Mwah~"
    scene ch02_cafe02_60 at hand_camera with Dissolve(0.8)
    a "나 삐졌어."
    a "니가 나보다 내 여동생을 더 좋아하는거 같아."
    a "어떻게 그럴수 있니? 그 오랜 시간을 나와 함께 했는데.."
    a "그 요망한 년에게 그렇게 금방 빠져버리다니.."
    a "나도 내 엉덩이라도 보여줘야 하는거니? 응?"
    scene ch02_cafe02_61 at hand_camera with Dissolve(0.8)
    pause  
    scene ch02_cafe02_62 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh06.mp3"
    a "하하하."
    a "어서 집에 가자 달링. 헤헤."
    scene ch02_cafe02_63 at hand_camera with Dissolve(0.8)
    a "(우리의 홈스윗홈으로 가자.)"
    jump ch02_ahouse02

label ch02_ahouse02:
    if not in_replay:
        $ persistent.unlock_ch02_ahouse02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/chill.mp3"
    scene ch02_ahouse02_01 at truecenter with Dissolve(2.0)
    pause
    play sound "audio/ambi/carpass02.mp3"
    scene ch02_ahouse02_02 at truecenter with Dissolve(1.5)
    pause
    stop sound
    scene ch02_ahouse02_03 at truecenter with Dissolve(1.5)
    pause
    scene ch02_ahouse02_04 at hand_camera with Dissolve(0.8)
    a "허니."
    a "프랭크도 없으니 오붓하게 거실에서 영화 보자. 어때?"
    scene ch02_ahouse02_05 at hand_camera with Dissolve(0.8)
    d "그냥 옛날 처럼요? 헤헤."
    scene ch02_ahouse02_04-02 at hand_camera with Dissolve(0.8)
    a "그냥 옛날 처럼.."
    a "단 영화는 내가 보고 싶은걸로. 헤헤."
    scene ch02_ahouse02_06 at hand_camera with Dissolve(0.8)
    d "좋아요!"
    d "난 영화라면 다 좋아하니까요 헤헤."
    scene ch02_ahouse02_07 at hand_camera with Dissolve(0.8)
    a "좋아 그럼 샤워하고 30분 뒤에 거실에서 만나."
    d "알겠어요."
    scene ch02_ahouse02_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_09 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/night03.mp3"
    a "(그냥 옛날 처럼..)"
    scene ch02_ahouse02_10 at hand_camera with Dissolve(0.8)
    a "(맞아. 그냥 옛날 처럼..)"
    scene ch02_ahouse02_11 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_11-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_12 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_12-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_13 at hand_camera with Dissolve(1.3)
    pause
    scene ch02_ahouse02_13-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_14 at hand_camera with Dissolve(2.0)
    play sound "audio/ambi/shower01.mp3" loop
    pause
    scene ch02_ahouse02_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_19 at hand_camera with Dissolve(0.8)
    a "..................."
    scene ch02_ahouse02_19-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_20 at hand_camera with Dissolve(0.8)
    n "그녀는 자신도 모르게 평소보다 더 신경 써서 그녀의 성기를 씻었다."
    n "그녀의 행동은 그녀의 무의식에서 비롯된 것이었다."
    n "마치 일어나지 않을 일을 대비하는 강박증에 걸린 사람처럼..."
    scene ch02_ahouse02_21 at hand_camera with Dissolve(2.0)
    stop sound
    play music "audio/bgm/night04.mp3"
    pause
    scene ch02_ahouse02_22 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/hairdryer01.mp3" loop
    pause
    scene ch02_ahouse02_22-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch02_ahouse02_23 at hand_camera with Dissolve(0.8)
    a "젠장 이 놈에 가슴 때문에 어깨가 결리네."
    scene ch02_ahouse02_24 at hand_camera with Dissolve(0.8)
    a "(가슴은 무식하게 커서 어디다 쓰려고...)"
    pause 
    scene ch02_ahouse02_25 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/milfsigh01.mp3"
    n "그녀는 자신의 큰 가슴을 들어올렸다."
    n "샤워 후의 나른함과 상쾌함에 가슴의 무게 때문에 느껴졌던 무게감이 잠시나마 사라지자.."
    n "그녀는 소소한 쾌감을 느꼈다."
    a "아......."
    a "오늘 브라를 착용했어야 했어."
    scene ch02_ahouse02_26 at hand_camera with Dissolve(0.8)
    a "괜히 멋부렸더니 어깨만 아프네."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch02_ahouse02_26-02 with dissolve
    pause
    scene ch02_ahouse02_27 with dissolve
    pause
    scene ch02_ahouse02_28 with dissolve
    d "!!!!!!!"
    scene ch02_ahouse02_29 at hand_camera with Dissolve(0.8)
    d "아 깜짝 놀랐잖아요."
    d "거기서 뭐해요 아만다?"
    scene ch02_ahouse02_30 at hand_camera with Dissolve(0.8)
    a "내가 요즘 잘 때 입는 슬립을 입었는데 좀 창피해서 하하하."
    scene ch02_ahouse02_29 at hand_camera with Dissolve(0.8)
    d "하 그것 때문에 거기 숨은 거에요?"
    d "우리 사이에 부끄러울게 뭐가 있어요 빨리 나와요."
    scene ch02_ahouse02_30-02 at hand_camera with Dissolve(0.8)
    a "좋아 그럼."
    a "놀리거나 잔소리 하기 없기다? 알았지?"
    scene ch02_ahouse02_31 at hand_camera with Dissolve(0.8)
    d "알겠어요. 약속할게요."
    d "내가 설마 아만다 잠옷 가지고 잔소리를...."
    scene ch02_ahouse02_31-02 at hand_camera with dissolve
    d "!!!!!!!!!!!!!!!!!!!"
    play music "audio/bgm/erotic06.mp3"
    show ch02_ahouse02_31-03:
        xalign 0.5
        yalign 0.0
        ease 3 yalign 0.45
    pause
    scene ch02_ahouse02_31-03-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_31-02 at hand_camera with dissolve
    pause
    scene ch02_ahouse02_31-04 at hand_camera with Dissolve(0.8)
    a "뭐? 왜그래 헤헤?"
    a "너무 과감한가?"
    a "아니야 전에 이거보다 더 야하게 입었었잖아?헤헤."
    scene ch02_ahouse02_31-05 at hand_camera with Dissolve(0.8)
    d ".............."
    d "아.. 아니에요."
    d "너무 섹시해요 아만다."
    scene ch02_ahouse02_32 at hand_camera with Dissolve(0.8)
    a "섹시? 하하하."
    a "그럼 성공이야 헤헤."
    a "(올리비아 그년보다 내가 더 섹시하지.)"
    a "(걔는 그냥 나대는거고 나 처럼 타고난 섹시함은 절대 못 따라오지.)"
    scene ch02_ahouse02_32-02 at hand_camera with Dissolve(0.8)
    a "근데 넌 왜 팬티만 입고 있니?"
    a "집에서 그러고 다니니까 프랭크가 화내는거야 하하하."
    scene ch02_ahouse02_32-03 at hand_camera with Dissolve(0.8)
    a "(하지만...)"
    a "(프랭크가 화 내는건 너 때문이야 아만다. 헤헤.)"
    scene ch02_ahouse02_32-04 at hand_camera with Dissolve(0.8)
    a "(뭐 어때? 집주인이 편하게 입겠다는데 누가 뭐라 할거야?)"
    a "(내가 빨개벗고 다니든 스트립쇼를 하든 내 자유라고 하하하.)"
    scene ch02_ahouse02_33 at hand_camera with Dissolve(0.8)
    a "기다려. 간식 가져올게."
    scene ch02_ahouse02_33-02 at hand_camera with Dissolve(0.8)
    d "아..알겠어요."
    d "(....)"
    d "(젠장, 저 엉덩이좀 봐...)"
    d "(아만다의 몸매가 저렇게 아름다웠었다니...)"
    scene ch02_ahouse02_34 with dissolve
    pause
    scene ch02_ahouse02_35 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_35-02 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_36 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_33-02 with dissolve
    d "(맙소사.....)"
    scene ch02_ahouse02_37 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_38 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_39 at hand_camera with Dissolve(0.8)
    d "(...........)"
    scene ch02_ahouse02_40 at hand_camera with Dissolve(0.8)
    n "사실 [d_name]은 아만다와 살면서 그녀의 나체를 본적이 있었다."
    n "하지만 지금은 그에게 전달 되는 공기가 달랐다."
    n "생모에게 버림 받은 기억이 그가 보호자인 아만다에게 인정 받아야 한다는 강박관념이 생기게 만들었고,"
    n "그 방법은 아만다에게 자신의 남성성을 어필하여 자신이 의지할 수 있는 수컷임을 증명하는 것이라는 뒤틀린 생각을 하기 시작했다."
    scene ch02_ahouse02_40-02 at hand_camera with Dissolve(0.8)
    n "그는 그녀가 의지할 수 있는 남자가 되고 싶었다."
    n "정신적으로 의지할 수 있는 남자."
    n "육체적으로 의지할 수 있는 그런 남자."
    n "그래서 그녀를 행복하게 해주고 싶었다."
    scene ch02_ahouse02_41 at hand_camera with Dissolve(0.8)
    a "좋아 준비 끝. 헤헤"
    a "오늘의 영화는 내가 좋아하는 로맨틱 코미디야."
    a "친구가 생각없이 보기 좋은 영화라고 추천해줬어."
    a "지금이 딱 그런 영화를 보기 좋은 타이밍이지."
    d "저도 좋아요 헤헤."
    scene ch02_ahouse02_42 at hand_camera with Dissolve(0.8)
    d "(허??)"
    d "My pen is huge?"
    scene ch02_ahouse02_43 at hand_camera with Dissolve(0.8)
    d "(이게 로맨틱 코미디 영화 제목 맞나?)"
    d "(..........)"
    scene ch02_ahouse02_44 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch02_ahouse02_45 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    a "하하하하하하."
    d "저 남자 내 저럴 줄 알았어요."
    a "다 된 밥상을 저렇게 엎어버린다고?"
    scene ch02_ahouse02_46 at hand_camera with Dissolve(0.8)
    d "하하하하하."
    a "완전 최악의 남자야 하하."
    a "저렇게 하면 여자에게 차이는거야 [d_name]."
    a "명심해. 여자는 어리든 나이가 들었든 신사다운 남자를 좋아한다고."
    a "나쁜 남자 좋아하는 여자들은 극소수야."
    scene ch02_ahouse02_47 at hand_camera with Dissolve(0.8)
    d "왜 내 얘길해요. 난 저렇게 까지 이상한 행동은 안한다구요."
    d "그리고 전 태어날 때 부터 신사다웠다구요 하하하."
    a "오 그래? 하하하."
    scene ch02_ahouse02_48 at hand_camera with Dissolve(0.8)
    d "..............."
    scene ch02_ahouse02_49 at hand_camera with Dissolve(2.0)
    d "(젠장....)"
    d "(오늘 그녀가 유난히 상기된거 같아..)"
    d "(와인 때문인가??)"
    scene ch02_ahouse02_49-02 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_50 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_51 with dissolve
    d "(음.....)"
    d "(그녀의 체온이 뜨거워..)"
    scene ch02_ahouse02_51-02 at hand_camera with Dissolve(0.8)
    d "(와인 때문인가? 그녀의 피가 펌핑 하는게 느껴지네.)"
    scene ch02_ahouse02_52 at hand_camera with Dissolve(0.8)
    a "허니."
    scene ch02_ahouse02_53 at hand_camera with Dissolve(0.8)
    d "네?"
    scene ch02_ahouse02_54 at hand_camera with Dissolve(0.8)
    a "자세를 바꾸자."
    a "내가 너에게 안길게."
    a "오래 이렇고 있었더니 허리가 아프네."
    a "이제 늠름한 남자가 됐으니 숙녀를 안아줘야지 헤헤."
    scene ch02_ahouse02_55 at hand_camera with Dissolve(0.8)
    d "아 좋아요!"
    d "신사다운 이 [d_name]에게 안기세요 하하하."
    scene ch02_ahouse02_56 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/fabric01.mp3"
    pause
    scene ch02_ahouse02_56-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_57 with Dissolve (2.0)
    n "그들은 서로의 몸을 밀착시켰다."
    n "그녀는 일말의 경계심도 없이 자신의 체중을 온전히 그에게 맡겼다."
    scene ch02_ahouse02_58 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_58-02 at hand_camera with Dissolve(0.8)
    d "(그녀의 샴푸 냄새가 싱그럽네.)"
    d "(젠장. 그녀 살결이 너무 부드러워.)"
    scene ch02_ahouse02_59 at hand_camera with Dissolve(0.8)
    a "(!!!!!!!!!!!)"
    scene ch02_ahouse02_60 at hand_camera with Dissolve(0.8)
    a "뭐하니?"
    a "손의 위치가 잘못된거 같지 않니?"
    scene ch02_ahouse02_60-02 at hand_camera with Dissolve(0.8)
    d "헤헤. 아만다의 피부가 너무 부드러워서 저도 모르게 쓰다듬게 됐어요."
    a "하하. 뭐야 방금전에 저 영화속에 남자와 다를바 없잖아."
    scene ch02_ahouse02_61 at hand_camera with Dissolve(0.8)
    d "(젠장.)"
    d "(미치겠다. 그녀의 가슴이 진짜 부드러워.)"
    d "(마치 비단결 같아.)"
    d "(어떡하지?)"
    menu:
        n "What should I do?"
        "Lower your hands further.":
            if not in_replay:
                $ add_point("lust_amanda", 2, "lust_amanda")
            scene ch02_ahouse02_58-02 at hand_camera with Dissolve(0.8)
            d "(젠장. 나도 어쩔수 없다.)"
            d "(그냥 애정 표현인거야.)"
            d "(이렇게 붙어 앉은건 아만다가 원한거 였어.)"
            scene ch02_ahouse02_62 at hand_camera with Dissolve(0.8)
            a "(!!!!!!!!!!!!!!!!!!!!!)"
            play voice_f "audio/sex/fsigh04.mp3"
            scene ch02_ahouse02_63 at hand_camera with Dissolve(0.8)
            d "(젠장..진짜 부드럽다.)"
            scene ch02_ahouse02_63-02 at hand_camera with Dissolve(0.8)
            a "(.................)"
            scene ch02_ahouse02_64 at hand_camera with Dissolve(0.8)
            pause
        "Stay still.":
            scene ch02_ahouse02_58-02 at hand_camera with Dissolve(0.8)
            d "(괜히 아만다의 기분을 잡치지 말자....)"
            d "(모처럼 만났는데 나까지 이상한 짓 하면 안돼..)"
            scene ch02_ahouse02_64 at hand_camera with Dissolve(0.8)
            pause
    scene ch02_ahouse02_64-02 at hand_camera with Dissolve(0.8)
    a "바나나 먹을거야. 너도 줄까?"
    d "전 괜찮아요."
    scene ch02_ahouse02_64-03 at hand_camera with Dissolve(0.8)
    a "알겠어."
    scene ch02_ahouse02_64-04 at hand_camera with Dissolve(0.8)
    d "(쿨럭...)"
    scene ch02_ahouse02_64-05 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse02_64-06 at hand_camera with Dissolve(0.8)
    d "(.....)"
    d "(........)"
    d "(..................)"
    d "(맙소사................)"
    scene ch02_ahouse02_64-07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh04.mp3"
    a "헤헤."
    scene ch02_ahouse02_64-08 at hand_camera with Dissolve(0.8)
    d "(쉣!!)"
    play music "audio/bgm/erotic03.mp3"
    scene ch02_ahouse02_64-09 at hand_camera with Dissolve(1.5)
    play voice_f "audio/sex/oral02.mp3" loop
    pause
    scene ch02_ahouse02_64-10 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-11 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-11-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-11-03 at hand_camera with Dissolve(0.8)
    pause
    image ch02_ahouse02_BJ01:
        "ch02_ahouse02_64-11-04" with dissolve
        0.8
        "ch02_ahouse02_64-11-05" with dissolve
        0.8
        repeat
    scene ch02_ahouse02_BJ01 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-12 at hand_camera with Dissolve(0.8)
    pause
    image ch02_ahouse02_BJ02:
        "ch02_ahouse02_64-11-06" with dissolve
        0.8
        "ch02_ahouse02_64-11-07" with dissolve
        0.8
        repeat
    scene ch02_ahouse02_BJ02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-12 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-13 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-14 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse02_64-15 at hand_camera with Dissolve(0.8)
    d "하 아만다...제발 좀...."
    stop sound
    scene ch02_ahouse02_64-16 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    a "하하하하. 알았어 알았어"
    a "장난안할게."
    a "바나나가 너무 맛있어 보여서 나도 모르게 그만 하하하."
    a "아껴먹으려고 겉부터 핥은거야."
    scene ch02_ahouse02_65 with dissolve
    n "그의 고추는 계속 발기 해 있었다."
    n "그리고 그의 고추는 아만다의 엉덩이골 사이에 정확히 끼어 있었다."
    d "(젠장... 또 시작이네.)"
    d "(자지가 터질거 같아....)"
    d "(왜 나에게 이런 장난을 하는거지?)"
    d "(내가 어떻게 나올지 걱정도 안되나?)"
    scene ch02_ahouse02_65-02 with dissolve
    d "하하하 날 지금 도발하는거에요?"
    d "모든 일엔 대가가 따른다는거 모르세요?"
    a "뭐? 대가라니?"
    a "바나나좀 먹었다고 대가를 치뤄야해?"
    menu:
        n "What should I do?"
        "Grab her breasts.":
            if not in_replay:
                $ add_point("lust_amanda", 2, "lust_amanda")
            scene ch02_ahouse02_65-02 with dissolve
            d "그럼 이건 어때요?"
            a "뭐??"
            play music "audio/bgm/erotic01.mp3"
            scene ch02_ahouse02_66 with vpunch
            a "!!!!!!!!!!!!!!!"
            scene ch02_ahouse02_67 with dissolve
            a "(..................)"
            scene ch02_ahouse02_68 with dissolve
            a "너 지금 뭐하는거야?"
            a "이 집에서 쫒겨나고 싶니?"
            d "............."
            scene ch02_ahouse02_69 with dissolve
            a "그리고 대가라는게 겨우 이거야? 실망인걸."
            a "그리고 나처럼 불쾌하지 않게 은유적인게 있어야지 이건 너무 노골적이잖아."
            a "잘 알아둬. 이런식으로 하면 여자를 다루는게 아니라 도박하는거라고."
            scene ch02_ahouse02_70 with dissolve
            d "오 그래요?"
            d "그럼 이건 어때요?"
            a "뭐?"
            menu:
                n "What should I do?"
                "Rub her nipples.":
                    if not in_replay:
                        $ add_point("lust_amanda", 3, "lust_amanda")
                    scene ch02_ahouse02_65-02 with dissolve
                    pause
                    scene ch02_ahouse02_70-02 with dissolve
                    play voice_f "audio/voices/fhurt03.mp3"
                    a "!!!!!!!!!!!"
                    scene ch02_ahouse02_70-03 with dissolve
                    a "(앗!!..)"
                    scene ch02_ahouse02_70-04 with dissolve
                    a "(아흥..)"
                    image ch02_ahouse02_nipple01:
                        "ch02_ahouse02_70-02" with dissolve
                        0.7
                        "ch02_ahouse02_70-03" with dissolve
                        0.7
                        "ch02_ahouse02_70-02" with dissolve
                        0.7
                        "ch02_ahouse02_70-03" with dissolve
                        0.7
                        "ch02_ahouse02_70-04" with dissolve
                        0.7
                        "ch02_ahouse02_70-03" with dissolve
                        0.7
                        repeat
                    scene ch02_ahouse02_nipple01 at hand_camera
                    pause
                    scene ch02_ahouse02_70-05 with dissolve
                    play voice_f "audio/sex/milfsigh01.mp3"
                    a "(아흥...)"
                    a "뭐하는거니 허니?"
                    a "이건 좀 선을 넘은거 같지 않니?"
                    scene ch02_ahouse02_71 with dissolve
                    d "당신이 먼저 나에게 장난쳤잖아요 하하하."
                    d "전 밸런스를 맞추려고 했을뿐이에요."
                    a "밸런스라니.. 하.."
                    a "이건 도를 한참은 넘어섰다고."
                    a "이 변태 녀석."
                    d "............"
                    d "사랑해요 아만다."
                    scene ch02_ahouse02_72 with dissolve
                    a "어물쩡 말돌리지마."
                    a "여자를 이렇게 놀리면 안돼."
                    a "지금이야 괜찮은 분위기지만 아슬아슬했다 이번 건."
                    a "..............."
                    scene ch02_ahouse02_73 at hand_camera with Dissolve(2.0)
                    a "(헛! 이게 성인 등급 영화였나..)"
                    a "(타이밍 한번 민망하네..)"
                    scene ch02_ahouse02_73-02 at hand_camera with Dissolve(0.8)
                    a "(뭐지 이 영화는?)"
                    a "(독립 예술 영화도 아닌데 성기 노출을 한다고?!)"
                    a "(아만다는 알고 있었나??)"
                    scene ch02_ahouse02_74 at hand_camera with Dissolve(0.8)
                    a "............."
                    a "이리와 꼬맹아."
                    a "지금 시간이 멈췄으면 좋겠다. 너무 행복해."
                    a "그치?"
                    scene ch02_ahouse02_75 at hand_camera with Dissolve(0.8)
                    play sound "audio/sex/kissshort03.mp3"
                    a "Mwah~"
                    scene ch02_ahouse02_76 at hand_camera with Dissolve(0.8)
                    play sound "audio/sex/kissshort03.mp3"
                    d "(아 젠장. 자지가 터질거 같네.)"
                    d "(그녀의 엉덩이가 누르고 있는데 이거 잡고 고추 위치를 바꿔야 할거 같은데..)"
                    d "(아 젠장! 그럴러면 손을 넣어야 하잖아.)"
                    d "(이러다 부러지는거 아냐?!!!)"
                    scene ch02_ahouse02_76-02 at hand_camera with Dissolve(0.8)
                    d "(젠장 아만다...)"
                    play sound "audio/sex/kissshort03.mp3"
                    d "(당신은 지금 날 고문하고 있어요.)"
                    scene ch02_ahouse02_77 at hand_camera with Dissolve(0.8)
                    a "왜그래 허니?"
                    a "괜찮니?"
                    d "아 네.. 괜찮아요.."
                    d "한 자세로 오래 있었더니 쥐가 났었나봐요."
                    a "아 그랬구나."
                    scene ch02_ahouse02_78 at hand_camera with Dissolve(0.8)
                    pause
                    scene black with dissolve
                    $ _skipping = False
                    $ renpy.choice_for_skipping()
                    show text "After a while" at truecenter with Dissolve(2.0)
                    $ _skipping = True
                    play music "audio/bgm/night05.mp3"
                    scene ch02_ahouse02_79 with Dissolve(2.0)
                    pause
                    scene ch02_ahouse02_80 with Dissolve(1.0)
                    a "아흥~"
                    a "살짝 알딸딸하고 나른한게 기분 좋아."
                    scene ch02_ahouse02_81 with Dissolve(1.0)
                    a "영화 볼만 했니?"
                    d "네. 재미있었어요 헤헤."
                    scene ch02_ahouse02_82 at hand_camera with Dissolve(0.8)
                    d "마지막에 좀 야해지면서 놀랐는데 제목이 제목이니 만큼 하하하."
                    a "하하."
                    a "근데 그렇게 거대하다라는 타이틀을 붙일 정도는 아닌던데? 헤헤."
                    scene ch02_ahouse02_83 at hand_camera with Dissolve(0.8)
                    a "시간이 너무 빨리가는거 같아."
                    a "벌써 잘 시간이라니."
                    a "아쉽지만 이제 굿나잇 키스를 해줘."
                    scene ch02_ahouse02_84 at hand_camera with Dissolve(0.8)
                    pause
                    n "프랭크가 없는 자유로운 집 안에서.."
                    n "그들의 스킨쉽은 더 과감해지고 있었다."
                    n "그리고 이번엔 누가 먼저랄거 없이 자석에 이끌리듯 서로의 입술이 닿았다."
                    scene ch02_ahouse02_85 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/kissshort02.mp3"
                    pause
                    scene ch02_ahouse02_86 at hand_camera with Dissolve(0.8)
                    pause
                    scene ch02_ahouse02_87 at hand_camera with Dissolve(0.8)
                    a "헤헤."
                    a "입술에 하는게 굿나잇 키스야?"
                    scene ch02_ahouse02_88 at hand_camera with Dissolve(2.0)
                    play voice_f "audio/sex/milfmoanshort02.mp3"
                    a "으음....나른하다."
                    scene ch02_ahouse02_89 at hand_camera with Dissolve(0.8)
                    a "와인을 마셨더니 졸리네."
                    a "너도 피곤할텐데 어서 올라가서 자."
                    scene ch02_ahouse02_90 at hand_camera with Dissolve(0.8)
                    a "난 침대에 쓰러지면 바로 잠들거 같아."
                    a "내일 아침에 봐용~"
                    d "잘자요 아만다."
                    jump ch02_ahouse03

label ch02_ahouse03:
    if not in_replay:
        $ persistent.unlock_ch02_ahouse03 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night.mp3"
    scene ch02_ahouse03_01 at hand_camera with Dissolve(0.8)
    pause    
    scene ch02_ahouse03_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse03_03 at hand_camera with Dissolve(0.8)
    pause     
    scene ch02_ahouse03_04 at hand_camera with Dissolve(1.5)
    d "아 편안하다...."
    d "이러니 저러니 해도 역시 내 방이 최고야."
    d "프랭크가 없으니까 천국이네."
    scene ch02_ahouse03_05 at hand_camera with Dissolve(0.8)
    n "그는 낮에 보았던 프랭크와 여성이 떠올랐다."
    n "줄곧 아만다에게 말하고 싶었지만 그녀와의 좋은 시간을 망치고싶지 않았다."
    d "하.... 프랭크가 뭔가 수상한 짓 하고있는거 같은데.."
    scene ch02_ahouse03_05-02 at hand_camera with Dissolve(0.8)
    d "아만다도 알고 있을까?"
    pause
    d "아마 그녀라면 이미 뭔가 눈치채고 있겠지."
    d "프랭크가 엄한짓을 하고 돌아다닌다는걸."
    d "하.........."
    scene ch02_ahouse03_05-03 at hand_camera with Dissolve(0.8)
    d "젠장."
    d "아만다는 정말 더 좋은 대우를 받아야 해."
    d "프랭크 같은 인간에게 헌신하며 살 여자가 아니라고."
    scene ch02_ahouse03_06 at hand_camera with Dissolve(0.8)
    d "..............."
    d "아만다가 없었으면 이 집은 애저녁에 무너졌을거야."
    scene ch02_ahouse03_05 at hand_camera with Dissolve(0.8)
    d "하.................."
    d "빌어먹을 프랭크. 이번엔 또 무슨 사고를 치려는거지?"
    d "아직도 아만다를 괴롭힐게 남았나?"
    scene ch02_ahouse03_06 at hand_camera with Dissolve(0.8)
    pause
    d "내가 해야해."
    scene ch02_ahouse03_07 at hand_camera with Dissolve(0.8)
    d "내가 아만다를 챙겨야 한다고."
    scene ch02_ahouse03_08 at hand_camera with Dissolve(0.8)
    n "그는 프랭크 대신 아만다를 챙겨야 한다는 스스로의 명분을 만들었다."
    n "하지만 아만다에게 가는 이유는 그것 뿐만이 아니었다."
    n "프랭크가 없는 지금 그는 아만다에게 자신의 남성성, 자신의 존재를 각인시키고 싶었다."
    n "그리고"
    scene ch02_ahouse03_08-02 at hand_camera with Dissolve(1.3)
    n "자신에게 안겨있던 아만다의 체온과 향기를 다시 느끼고 싶었다."
    scene ch02_ahouse03_08-03 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_ahouse03_09 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_ahouse03_09-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse03_09-03 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse03_10 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_ahouse03_11 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_ahouse03_12 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_ahouse03_10-02 at hand_camera with Dissolve(1.5)
    d "................"
    d "(I have to protect her.)"
    menu:
        n "What should I do?"
        "Climb onto her bed.":
            play music "audio/bgm/night02.mp3"
            if not in_replay:
                $ add_point("lust_amanda", 3, "lust_amanda")
                $ add_point("love_amanda", 3, "love_amanda")
            scene ch02_ahouse03_13 at hand_camera with Dissolve(1.5)
            pause
            scene ch02_ahouse03_14 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/fabric03.mp3"
            pause
            scene ch02_ahouse03_15 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse03_15-02 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse03_15-03 at hand_camera with Dissolve(2.0)
            pause
            play sound "audio/ambi/fabric03.mp3"
            scene ch02_ahouse03_16 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse03_17 at hand_camera with Dissolve(2.0)
            pause
            scene ch02_ahouse03_18 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse03_19 at hand_camera with Dissolve(0.8)
            a "!!"
            scene ch02_ahouse03_20 at hand_camera with Dissolve(0.8)
            a "뭐? 너 여기서 뭐하는거야?"
            a "와인은 내가 마신거 같은데 아저씨?"
            d "헤헤."
            d "아만다가 쓸쓸하게 혼자 자게하고 싶지 않았어요."
            scene ch02_ahouse03_20-02 at hand_camera with Dissolve(0.8)
            a "우....어디서 그런 작업 멘트를 배워온거야?"
            a "나 지금 울먹할 정도로 감동 받았어."
            d "헤헤."
            scene ch02_ahouse03_20-03 at hand_camera with Dissolve(0.8)
            a "너 왜케 몸이 차갑니?"
            d "아니에요."
            d "아만다 몸이 지금 뜨거운거 같은데요?"
            scene ch02_ahouse03_20 at hand_camera with Dissolve(0.8)
            a "나야 와인을 마셨으니 그렇지."
            d "하하. 그럼 저에게 당신의 체온을 좀 나눠주세요."
            scene ch02_ahouse03_20-02 at hand_camera with Dissolve(0.8)
            a "뭐? 그게 무슨 말이야?"
            a "체온을 어떻게 나눠준다는 거야?"
            d "어........."
            d "아 같이 꼭 껴안고 자면 우리 둘의 체온이 맞춰지지 앉을까요?"
            scene ch02_ahouse03_20-03 at hand_camera with Dissolve(0.8)
            a "헤헤. 그렇구나."
            a "더 빠른 방법이 있지 않을까?"
            scene ch02_ahouse03_20-02 at hand_camera with Dissolve(0.8)
            d "그럼 꼭 껴앉고 자는거 말고 다른 방법이 있다는 말이에요?"
            scene ch02_ahouse03_20-03 at hand_camera with Dissolve(0.8)
            a "뭐? 정말 진지하게 물어보는 거니?"
            a "하! 내가 깜빡 속을뻔했네."
            a "오호호! 심리학을 공부하더니 이제 나름 잘 받아치는걸?"
            scene ch02_ahouse03_20 at hand_camera with Dissolve(0.8)
            d "네? 난 정말 아만다가 무슨 말을 하는지 하나도 모르겠어요."
            a "알았어 알았어 그렇다고 하자 하하."
            play voice_f "audio/voices/milflaugh06.mp3"
            a "응큼한 녀석."
            scene ch02_ahouse03_20-03 at hand_camera with Dissolve(0.8)
            a "..................."
            scene ch02_ahouse03_20-04 at hand_camera with Dissolve(0.8)
            a ".........."
            a "허니...."
            pause
            d "네 저 여기 있어요."
            a ".........."
            a "넌.."
            a "대학에 가있던 1년 동안 어떻게 지냈니?"
            pause
            a ".................."
            a "외롭지 않았니?"
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            d ".........."
            d "음.. 전..."
            pause
            d "전 외롭지 않았어요. 제이슨도 있고.."
            d "알잖아요 대학교가 얼마나 시끌벅쩍 한지."
            scene ch02_ahouse03_20-04 at hand_camera with Dissolve(0.8)
            a ".........."
            a "내가 보고싶지 않았니?"
            d "당연히 보고 싶었어요."
            d "매일 잘 때 아만다 생각을 했는걸요?"
            scene ch02_ahouse03_19 at hand_camera with Dissolve(0.8)
            a ".........."
            a "정말이니?"
            d "그럼요."
            scene ch02_ahouse03_20-04 at hand_camera with Dissolve(0.8)
            a ".........."
            scene ch02_ahouse03_20-05 at hand_camera with Dissolve(0.8)
            a "훌쩍.."
            d "(!!!!)"
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            d ".........."
            d "아.. 아만다..울어요? 왜 그래요?"
            pause
            d "무슨 일 있어어요?"
            scene ch02_ahouse03_20-05 at hand_camera with Dissolve(0.8)
            a "훌쩍.."
            play voice_f "audio/voices/Fsigh01.mp3"
            a "하........"
            a "모르겠어.."
            a "요즘 갱년기가 온건지 눈물이 많아진거 같아."
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            d ".........."
            d "무슨 일 있는거죠?"
            d "그쵸?"
            d "나한테 말해봐요. 어떤 문제에요?"
            scene ch02_ahouse03_20-05 at hand_camera with Dissolve(0.8)
            a "하.........."
            a "있잖아.."
            a "...................."
            a "요즘 프랭크가 좀 이상해."
            d "(!!!)"
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            d "(젠장 내가 그럴 줄 알았다.)"
            d "(아만다 처럼 예리한 사람이 그걸 모를리가 없지.)"
            d "(아 젠장 낮에 프랭크 본거 얘기 해야하나?)"
            d "(아냐 일단 무슨 일인지 들어보자.)"
            d "이상하다는게 무슨 말이에요?"
            scene ch02_ahouse03_20-04 at hand_camera with Dissolve(0.8)
            a ".........."
            a "미안해. 내가 괜한 말을 했어."
            a "너와는 전혀 상관 없는 말인데.."
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            d "(.................)"
            pause
            d "아만다."
            a "응 허니?"
            scene ch02_ahouse03_20-07 at hand_camera with Dissolve(0.8)
            d "사랑해요."
            d "내가 이 세상에서 가장 사랑하는 사람은 아만다에요."
            d "영원히 내가 아만다 곁에 있을게요."
            d "난 아만다와 결혼해서 살거에요."
            scene ch02_ahouse03_20-08 at hand_camera with Dissolve(0.8)
            pause
            a "나와 결혼한다고? 헤헤."
            a "나 정말정말 감동 받았어 허니."
            a "......."
            a "사랑해 허니."
            scene ch02_ahouse03_20-07 at hand_camera with Dissolve(0.8)
            a "(그런데.....)"
            a "(뭐지 이건?)"
            a "(이거 그의 꼬추인가?)"
            a "(맙소사!!)"
            scene ch02_ahouse03_20-09 at hand_camera with Dissolve(0.8)
            a "(팬티를 입을걸 그랬네.)"
            play voice_f "audio/sex/fmoanshort03.mp3" volume 0.1
            a "(끄응...)"
            a "(진짜야? 영화 보는 내내 발기가 돼 있었는데 또 발기가 된다고?)"
            a "(와우. 이 녀석 여자 친구는 죽어나가겠네.)"
            a "(...........)"
            a "(맙소사.)"
            a "(이거 좀 혼란스럽네..)"
            scene ch02_ahouse03_20-10 at hand_camera with Dissolve(0.8)
            a "(하......)"
            a "(일어나서 속옷을 입을까?)"
            a "(아냐아냐..그도 이상하게 생각할거야. 더 불편하게 만들수도 있어.)"
            a "(아 그지금 나른하고 따뜻한게 너무 기분 좋아...)"
            a "(..............)"
            scene ch02_ahouse03_20-12 at hand_camera with Dissolve(0.8)
            a "(!!!!!!!!)"
            a "(놉! 이건 너무 심해.)"
            a "(이러다 쟤 이성을 잃을거 같은데? 하하하.)"
            scene ch02_ahouse03_20-11 at hand_camera with Dissolve(0.8)
            a "헤이! 뭐해?"
            a "나에게 체온을 나눠주려고 하는거야? 하하."
            a "이제 충분히 나눠줬어. 이제 더워서 조금 떨어져야 할거같아 허니."
            scene ch02_ahouse03_20-06 at hand_camera with Dissolve(0.8)
            menu:
                "Show her your love.":
                    if not in_replay:
                        $ add_point("lust_amanda", 3, "lust_amanda")
                        $ add_point("sus_amanda", 1, "sus_amanda")
                    play sound "audio/ambi/fabric03.mp3"
                    scene ch02_ahouse03_21 at hand_camera with Dissolve(2.0)
                    a "뭐하는거니?"
                    d "........"
                    d "사랑해요 아만다."
                    d "진심으로요."
                    d "언제나 내가 곁에 있을게요."
                    scene ch02_ahouse03_22 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/kissshort03.mp3"
                    pause
                    scene ch02_ahouse03_22-02 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/kissshort03.mp3"
                    pause
                    scene ch02_ahouse03_23 at hand_camera with Dissolve(2.0)
                    a "허니."
                    a "프랭크가 우릴 보면 우리 둘 다 죽여버릴거야."
                    scene ch02_ahouse03_24 at hand_camera with Dissolve(0.8)
                    d "상관 없어요."
                    d "내가 아만다를 지켜줄게요. 저도 이제 건강한 성인이에요."
                    scene ch02_ahouse03_23 at hand_camera with Dissolve(0.8)
                    a "나도 알아.헤헤."
                    a "[d_name]은 이젠 나의 늠름한 왕자님이라는걸."
                    scene ch02_ahouse03_24-02 at hand_camera with Dissolve(0.8)
                    d "그럼 아만다는 저의 여왕님이에요 헤헤."
                    scene ch02_ahouse03_20 at hand_camera with Dissolve(0.8)
                    a "그래? 그럼 여왕님이 더 감동 받도록 해줘."
                    a "원래 여왕은 쉽게 삐지는 법이야."
                    scene ch02_ahouse03_25 at hand_camera with Dissolve(0.8)
                    d "그럼 이리와요 헤헤."
                    scene ch02_ahouse03_26 at hand_camera with Dissolve(0.8)
                    a "하......"
                    pause
                    d "아..당신의 피부가 너무 부드러워요."
                    d "그리고 당신은 정말 향기로워요."
                    a "헤헤 그래?"
                    scene ch02_ahouse03_27 at hand_camera with Dissolve(0.8)
                    d "네. 마치 라일락 나무를 껴안은거 같아요."
                    a "라일락 나무?"
                    a "그런 시적인 표현은 처음 들었어 헤헤."
                    scene ch02_ahouse03_27-02 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/fsigh04.mp3"
                    a "아....."
                    a "너무 포근해."
                    scene ch02_ahouse03_27-03 at hand_camera with Dissolve(2.0)
                    pause
                    scene ch02_ahouse03_28 at hand_camera with Dissolve(2.0)
                    a "너와 영화를 보고 와인도 마시고..."
                    a "이렇게 같은 침대에서 잘 수 있다니.."
                    a "아... 매일 이럴 수 있다면 얼마나 행복할까? 헤헤."
                    scene ch02_ahouse03_29 at hand_camera with Dissolve(0.8)
                    n "그들은 잠시 말없이 서로를 바라보았다."
                    n "그녀의 눈에 [d_name]은 몰라보게 달라진 든든한 남성이었고,"
                    n "그의 눈에 아만다는 매력적인 한 여성이었다."
                    n "그리고 그들 모두는 그들의 관계에 전환점이 되는 순간이라는 것을 느끼고 있었다."
                    n "그것은 둘 모두에게 두근거림이자 두려움으로 다가왔다."
                    scene ch02_ahouse03_30 at hand_camera with Dissolve(0.8)
                    d "왜 불안하게 아무말 없이 쳐다만봐요?"
                    d "제가 또 뭐 잘못했어요?"
                    scene ch02_ahouse03_30-02 at hand_camera with Dissolve(2.0)
                    a "아냐아냐 잘못한거 없어 허니."
                    a "그냥 이 순간이 영원하길 바래서 잠시 머리가 멍해졌었어."
                    a "이런 시간이 또 언제 오려나......."
                    a "..................."
                    a "허니?"
                    d "네?"
                    a "..................."
                    a "너의 여왕님에게 굿나잇 키스를 해줘."
                    scene ch02_ahouse03_31 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/kissshort03.mp3"
                    pause
                    scene ch02_ahouse03_32 at hand_camera with Dissolve(0.8)
                    play voice_f "audio/sex/kissshort03.mp3"
                    pause
                    scene ch02_ahouse03_33 at hand_camera with Dissolve(0.8)
                    d "(젠장.)"
                    n "그의 혀가 아만다의 입술에 닿은 순간 아만다는 키스를 마쳤다."
                    n "그 타이밍이 우연인지, 그녀가 의도적으로 키스를 마친것인지는 확실치 않았다."
                    scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                    a "........."
                    a "좋은 기분을 가지고 자자."
                    scene ch02_ahouse03_34 at hand_camera with Dissolve(0.8)
                    a "naughty boy......."
                    d "하 그래요? 그럼 아만다에게도 새로운 별명을 지어줄게요."
                    a "오 그래?"
                    a "1년 동안 심리학 배운걸 활용해서 내 별명을 지어봐."
                    d "헤헤. 알겠어요."
                    d "아만다는...."
                    menu:
                        "Ass Slapper":
                            if not in_replay:
                                $ add_point("love_amanda", 2, "love_amanda")
                                $ add_point("lust_amanda", 2, "lust_amanda")
                            d "아만다는 애스 슬래퍼에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "애스 슬래퍼라니 하하하...너도 엉덩이 맞을래?"
                        "Banana Sucker":

                            if not in_replay:
                                $ add_point("love_amanda", 3, "love_amanda")
                                $ add_point("lust_amanda", 2, "lust_amanda")
                            d "아만다는 바나나써커에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "바나나써커라니 하하하..."
                        "Exhibitionist":

                            if not in_replay:
                                $ add_point("sus_amanda", 1, "sus_amanda")
                                $ add_point("lust_amanda", 1, "lust_amanda")
                            d "아만다는 노출증 걸린 여자에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "노출증 걸린 여자라니.....흠..."
                        "Sexy MILF":

                            if not in_replay:
                                $ add_point("sus_amanda", 1, "sus_amanda")
                                $ add_point("love_amanda", 1, "love_amanda")
                                $ add_point("lust_amanda", 1, "lust_amanda")
                            d "아만다는 섹시 밀프에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "섹시 밀프라니.....흠..."
                        "Naughty MILF":

                            if not in_replay:
                                $ add_point("sus_amanda", 1, "sus_amanda")
                                $ add_point("lust_amanda", 2, "lust_amanda")
                            d "아만다는 너티 밀프에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "너티 밀프라니.....흠..."
                        "Bombshell":

                            if not in_replay:
                                $ add_point("lust_amanda", 3, "lust_amanda")
                            d "아만다는 밤쉘이에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "밤쉘이라니 하하하..."
                        "Juicy Melon":

                            if not in_replay:
                                $ add_point("sus_amanda", 1, "sus_amanda")
                                $ add_point("lust_amanda", 4, "lust_amanda")
                            d "아만다는 쥬시멜론이에요."
                            scene ch02_ahouse03_28 at hand_camera with Dissolve(0.8)
                            play voice_f "audio/voices/fwhat01.mp3"
                            a "뭐?"
                            a "오마이갓 뭐? 쥬시멜론? 하하하..."
                    pause
                    a "하! 너티보이는 내 별명에 비하면 칭찬이네."
                    a "좋아 그럼 너에게 다른 별명을 지어서 문자로 보내줄게."
                    a "이제 자자......."
                    scene ch02_ahouse03_35 at hand_camera with Dissolve(1.5)
                    play sound "audio/ambi/clock01.mp3" loop volume 0.6
                    pause
                    scene ch02_ahouse03_36 at hand_camera with Dissolve(2.0)
                    pause
                    scene ch02_ahouse03_37 at hand_camera with Dissolve(2.0)
                    pause
                    scene ch02_ahouse03_38 at hand_camera with Dissolve(2.0)
                    pause
                    scene ch02_ahouse03_39 at hand_camera with Dissolve(2.0)
                    pause
                    scene ch02_ahouse03_40 at hand_camera with Dissolve(2.0)
                    pause
                    stop sound fadeout 1.0
                    jump ch02_ahouse04

label ch02_ahouse04:
    if not in_replay:
        $ persistent.unlock_ch02_ahouse04 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch02_ahouse04_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_02-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_04 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    scene ch02_ahouse04_04-02 at hand_camera with Dissolve(2.0)
    play music "audio/bgm/sus05.mp3" volume 1.5
    pause
    scene ch02_ahouse04_04-03 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_ahouse04_04-04 at hand_camera with Dissolve(0.8)
    pause
    f "이 자식이...."
    pause
    f "이 자식이 내가 없는 동안 내 자리를 차지해?!!"
    f "이 개같은 놈이. 은혜를 원수로 갚아?!!"
    f "내 인내심의 한계를 테스트해?!!"
    play sound "audio/ambi/gunload01.mp3"
    scene ch02_ahouse04_04-06 at hand_camera with Dissolve(0.8)
    f "아만다는 어디있어? !!!!!"
    scene ch02_ahouse04_04-07 at hand_camera with Dissolve(0.8)
    f "요즘 되는 일도 없는데 세상이 날 미치도록 만드네!!!"
    scene ch02_ahouse04_04-08 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/gunshot01.mp3"
    f "이 몸쓸 녀석!!"
    scene ch02_ahouse04_05 with vpunch
    d "(웟더퍽..)"
    scene ch02_ahouse04_05-02 with dissolve
    pause
    scene ch02_ahouse04_05-03 with Dissolve(2.0)
    play music "audio/bgm/normal05.mp3"
    d "(하.......)"
    d "(꿈이었군.)"
    d "(꿈 맞나?)"
    d "(...............)"
    d "(하..... 별 꿈이 다있네.)"
    d "(그래..)"
    d "(어제도 죽지않고 살아남아 이렇게 새로운 아침을 맞았군.)"
    scene ch02_ahouse04_06 with dissolve
    d "(허?)"
    scene ch02_ahouse04_07 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_09 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shower02.mp3" loop
    d "(댐...)"
    d "(화장실 커튼이 있었는데 왜 사라졌지?)"
    d "(프랭크가 떼버린건가?)"
    scene ch02_ahouse04_10 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_11 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_12 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_13 at hand_camera with Dissolve(0.8)
    d "아만다?"
    d "나 이제 가야할거 같아요."
    d "....................."
    scene ch02_ahouse04_16 at hand_camera with Dissolve(0.8)
    a "......."
    scene ch02_ahouse04_17 at hand_camera with Dissolve(0.8)
    d "............"
    scene ch02_ahouse04_13 at hand_camera with Dissolve(0.8)
    d "프랭크 올 때 되지 않았어요??"
    scene ch02_ahouse04_18 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh05.mp3"
    a "하......."
    a "어제 밤이 너무 비현실 같아서 프랭크를 잊고 있었어."
    a "시간이 왜 이렇게 빠르담?"
    scene ch02_ahouse04_19 at hand_camera with Dissolve(0.8)
    a "흑흑흑...."
    a "아쉬움에 눈물이 날거 같아."
    a "같이 사라져버릴까?"
    scene ch02_ahouse04_20 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_20-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch02_ahouse04_21 at vpunch
    a "이리와 빅보이!"
    scene ch02_ahouse04_22 at hand_camera with dissolve
    d "뭐?!!"
    scene ch02_ahouse04_23 at vpunch
    d "으악!!"
    play voice_f "audio/voices/milflaugh06.mp3"
    scene ch02_ahouse04_23-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_23-03 at hand_camera with Dissolve(0.8)
    a "하하하하하."
    a "어딜 그렇게 휙 가버리려고!!"
    scene ch02_ahouse04_24 at hand_camera with Dissolve(0.8)
    d "아 아만다!! 이제 곧 가야하는데 속옷 젖었잖아요."
    scene ch02_ahouse04_25 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    a "하하하하하."
    a "속옷이 없으면 노팬티로 돌아다니면 돼."
    scene ch02_ahouse04_26 at hand_camera with Dissolve(0.8)
    a "너도 씻어야 하잖아."
    a "프랭크 곧 오니까 같이 빨리 씻어야해!"
    scene ch02_ahouse04_27 at hand_camera with Dissolve(0.8)
    a "속옷 많이 있으니까 어서 벗어."
    d "뭐?!!"
    a "뭘 그리 놀래?"
    scene ch02_ahouse04_27-02 with dissolve
    d "안돼요 아만다!!"
    play sound "audio/ambi/fabric01.mp3"
    scene ch02_ahouse04_28 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic03.mp3"
    pause 
    scene ch02_ahouse04_28-02 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_29 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_30 at hand_camera with Dissolve(2.0)
    pause 
    scene ch02_ahouse04_31 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_32 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_33 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_34 with dissolve
    n "[d_name]의 고추를 본 그녀는 할 말을 잊었다."
    n "그리고 어제 밤 자신의 엉덩이골로 느꼈던 크기와는 완전히 다른 물건이었다."
    n "순간 그녀에게 죄책감과 낯선 부끄러움이 찾아왔다."
    a "........................"
    scene ch02_ahouse04_34-02 with dissolve
    d "미안해요 아만다."
    d "하....또 이런 일이...."
    scene ch02_ahouse04_35 with dissolve
    a "허? 또라니?"
    a "이....."
    pause
    a "이런 경우는 처음인데?......"
    image ch02_ahouse04_wiggle01:
        "ch02_ahouse04_34" with dissolve
        0.6
        "ch02_ahouse04_34-03" with dissolve
        0.6
        repeat
    scene ch02_ahouse04_wiggle01 at hand_camera with Dissolve(0.8)
    a ".............."
    a "너 지금 뭐하는거야?"
    a "왜 이게 꿈틀꿈틀.."
    pause
    scene ch02_ahouse04_36 with dissolve
    a "정말 정말 미안해 허니."
    a "내가 금방 마칠게 딱 3분만 줘. 알았지?"
    scene ch02_ahouse04_37 with dissolve
    d "뭐라고요?"
    d "이렇게 멀뚱히 기다리라는 거에요?"
    d "(.........................)"
    d "(갑자기 분위기가 확 바뀌었네.)"
    jump v02_amanda_shower_branch

label v02_amanda_shower_branch:
    if lust_amanda >= 17:
        jump ch02_ashower01
    else:
        jump ch02_ahouse05

label ch02_ashower01:
    menu:
        n "What should I do?"
        "Step into the shower booth.":
            if not in_replay:
                $ add_point("lust_amanda", 5, "lust_amanda")
                $ add_point("sus_amanda", 2, "sus_amanda")
            scene ch02_ahouse04_37 at hand_camera with Dissolve(0.8)
            d "(똑같은 패턴이야.)"
            d "(자기가 먼저 시작해놓고 내빼는거.)"
            d "(흠....)"
            scene ch02_ahouse04_37-02 at hand_camera with Dissolve(0.8)
            d "(장난의 여왕님께 되돌려 드려야죠. 이건 당신이 먼저 시작한거에요.)"
            d "(이번엔 시작은 당신이 했지만 끝내는건 나에요 하하하.)"
            d "그거 알아요?"
            a "뭐라고?"
            scene ch02_ahouse04_38 with vpunch
            play music "audio/bgm/erotic02.mp3"
            a "꺅!!!"
            play voice_f "audio/voices/fgrunt03.mp3"
            scene ch02_ahouse04_38-02 at hand_camera with Dissolve(0.8)
            a "!!!!!!!!!!!"
            scene ch02_ahouse04_38-03 at hand_camera with Dissolve(0.8)
            a "너 지금 뭐하는거야?!!"
            scene ch02_ahouse04_39 at hand_camera with Dissolve(0.8)
            d "나 엄청 금방 씻는거 알잖아요."
            d "난 물만 적시면 돼요 하하하."
            scene ch02_ahouse04_40 at hand_camera with Dissolve(0.8)
            a "[d_name]!!!!!!!!!!!"
            a "당장나가!! 이러면 안돼!!"
            a "..................."
            n "그들은 미지의 영역에 들어섰다."
            n "그들은 나체의 상태로 서로에게 밀착되었다."
            n "그녀는 [d_name]의 성기가 자신의 엉덩이골 사이로 점점 비집고 들어오는 것을 느낄 수 있었다."
            pause
            scene ch02_ahouse04_41 at hand_camera with Dissolve(0.8)
            a "제발좀.."
            a "그래 니가 이겼으니까 이제 날 좀 놔줄래?"
            a "..........................."
            n "아만다는 말로는 표현해도 저항하거나 몸으로 그를 밀어내지 않았다."
            n "오랜만에 느끼는 남성의 나체와 온기,"
            n "그리고 약간의 굴욕감이 더해져 정체모를 감정에 휩쌓였다."
            scene ch02_ahouse04_41-02 at hand_camera with Dissolve(0.8)
            n "하지만 그녀는 습기와 정체 모를 흥분에 의해 자신의 이성의 마지막 조각이 씻겨나가는 것을 견딜 수 없었다."
            n "현실의 자신의 역할이 그녀의 본능을 조정하고 있었다."
            n "아직까지는..."
            n "그녀는 그 짧은 순간에 여자와 보호자의 경계를 넘나들다 이윽고 말했다."

            scene ch02_ahouse04_42 at hand_camera with Dissolve(0.8)
            a "허니.."
            a "미안해. 내가 장난치는게 아니었는데.."
            scene ch02_ahouse04_43 at hand_camera with Dissolve(0.8)
            a "3분안에 샤워 끌낼테니까 나에게 시간 좀 줄래?"
            a "그리고 너의 그....."
            scene ch02_ahouse04_42 at hand_camera with Dissolve(0.8)
            a "암튼 미안하지만 잠깐만 기다려줘 알겠지?"
            scene ch02_ahouse04_44 at hand_camera with Dissolve(0.8)
            d "왜요? 우리 이제 이 만큼 친밀한 사이 잖아요."
            d "전 같이 씻고 싶어요."
            scene ch02_ahouse04_45 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/milfsigh01.mp3"
            a "아니 그게 아니라..."
            a "이건 너무 심해 허니."
            a "이건 우리 사이에 절대 일어나선 안되는 일이야."
            a "빨리 끝내고 나갈게 우선 나가있어줘. 알았지 허니?"
            scene ch02_ahouse04_44 at hand_camera with Dissolve(0.8)
            d "싫어요."
            d "제가 아만다 씻겨 줄게요."
            a "(!!!)"
            scene ch02_ahouse04_46 with vpunch
            a "아 좀 [d_name]!!"
            a "왜 그렇게 말을 안듣니!!!"
            scene ch02_ahouse04_48 at hand_camera with Dissolve(0.8)
            d "..................."
            d "알겠어요. 미안해요."
            scene ch02_ahouse04_47 at hand_camera with Dissolve(0.8)
            a "컴온 허니"
            a "미안해. 곧 프랭크 오니까 빨리 씻고 나갈게."
            a "............"
            scene ch02_ahouse04_49 at hand_camera with Dissolve(0.8)
            d "알겠어요. 나갈게요."
            scene ch02_ahouse04_50 at hand_camera with Dissolve(0.8)
            d "나갈게요 나갈게요."
            scene ch02_ahouse04_51 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse04_52 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_ahouse04_53 at hand_camera with Dissolve(2.0)
            play voice_f "audio/voices/fsigh03.wav"
            a "하............"
            jump ch02_ahouse05
        "Give her some time.":

            if not in_replay:
                $ add_point("love_amanda", 3, "love_amanda")
            scene ch02_ahouse04_37 with dissolve
            d "흠........."
            scene ch02_ahouse04_36 with dissolve
            a "정말 정말 미안해 허니."
            a "내가 금방 마칠게 딱 3분만 줘. 알았지?"
            jump ch02_ahouse05

label ch02_ahouse05:
    if not in_replay:
        $ persistent.unlock_ch02_ahouse05 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal.mp3"
    scene ch02_ahouse04_54 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_55 at hand_camera with Dissolve(0.8)
    a "아.....이런 시간들이 또 언제 오려나.."
    a "조금전에 만난거 같은데 시간이 너무 빠르다 정말."
    a "이게 상대성이론이라는건가?"
    d "하하."
    scene ch02_ahouse04_56 at hand_camera with Dissolve(0.8)
    a "프랭크를 죽여야 하나? 하하하."
    a "마을 뒷산으로 끌고가서 나무에 묶어놓고 올까?"
    a "아님 낚시배에서 뒤에서 밀어버릴까?"
    scene ch02_ahouse04_57 at hand_camera with Dissolve(0.8)
    d "하하하 아만다. 내가 그렇게 할까요?"
    d "그리고 모든 증거를 인멸하고 짐싸들고 여기로 올게요."
    scene ch02_ahouse04_56-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    a "하하하. 그런 끔찍한 소리는 하지마."
    a "프랭크가 사라지고 우리 둘이 산다고?"
    a "그럼 인류의 역사는 다시 쓰여져야 할걸?"
    scene ch02_ahouse04_57-02 at hand_camera with Dissolve(0.8)
    a "암튼 밖에서라도 보면 되니까 자주 보자 허니."
    a "폰은 뒀다 뭐하니. 헛소리도 좋으니까 자주 연락하자."
    d "그렇게 할게요.헤헤."
    scene ch02_ahouse04_58 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_59 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_60 at hand_camera with Dissolve(0.8)
    d "연락할게요 여왕님."
    a "하하. 알겠어요 왕자님."
    scene ch02_ahouse04_61 at hand_camera with Dissolve(0.8)
    a "청부살인은 얼마가 드는지 내가 한번 알아볼게."
    scene ch02_ahouse04_62 at hand_camera with Dissolve(0.8)
    d "하하하하. 저도 나름 알아볼게요."
    d "가능한 은밀히 진행해야 해요."
    scene ch02_ahouse04_63 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/bicycle01.mp3" 
    pause 
    scene ch02_ahouse04_64 at hand_camera with Dissolve(0.8)
    a "............."
    a "느끼한 녀석 같으니 헤헤."
    scene ch02_ahouse04_64-02 at hand_camera with Dissolve(0.8)
    a "곧 보자."
    a "빅보이."
    scene ch02_ahouse04_65 at hand_camera with Dissolve(0.8)
    a "나의 빅보이."
    stop music fadeout 1.0
    scene ch02_ahouse04_66 at hand_camera with Dissolve(1.3)
    play music "audio/bgm/sus06.mp3"
    pause 
    scene ch02_ahouse04_67 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_ahouse04_68 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_ahouse04_69 at hand_camera with Dissolve(0.8)
    pause 
    play sound "audio/ambi/camera.mp3"
    hide screen top_ui_buttons
    scene ch02_ahouse04_70 with flash
    pause
    show screen top_ui_buttons 
    scene ch02_ahouse04_71 at hand_camera with Dissolve(0.8)
    pause
    jump ch02_pool02

label ch02_pool02:
    if not in_replay:
        $ persistent.unlock_ch02_pool02 = True
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene ch02_pool02_00 with dissolve
    play sound "audio/ambi/bicycle01.mp3" 
    pause
    scene ch02_pool02_01 with dissolve
    pause  
    scene ch02_pool02_02 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_pool02_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_04 at hand_camera with Dissolve(0.8)
    d "(!!!)"
    scene ch02_pool02_05 at hand_camera with Dissolve(0.8)
    d "(뭐지 이 번호판은?)"
    d "(하하하.올리비아라도 온건가?)"
    scene ch02_pool02_06 with Dissolve (2.0)
    unknownf "하하하하하."
    scene ch02_pool02_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_09 at hand_camera with Dissolve(2.0)
    play voice_f "audio/voices/flaugh02.mp3"
    h "맙소사."
    play sound "audio/ambi/park01.mp3" loop
    h "나도 사람이라고."
    h "나도 내 나이대 평범한 여성만큼 성욕이 있어."
    h "너 처럼 굳이 밖으로 드러내지 않을 뿐이지."
    scene ch02_pool02_10 at hand_camera with Dissolve(0.8)
    h "글쎄..."
    h "아니 유치원 때부터 알았는데 아직도 날 잘 모르는거야?"
    h "근데 사람들이 날 잘 모르겠다고 하긴 하더라."
    h "내가 특별히 숨기고 사는것도 없는데."
    scene ch02_pool02_11 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_pool02_12 at hand_camera with Dissolve(0.8)
    h "(안녕 [d_name]!!)"
    scene ch02_pool02_13 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_14 at hand_camera with Dissolve(0.8)
    unknownf "(!!)"
    scene ch02_pool02_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_16 at hand_camera with Dissolve(0.8)
    d "굿 모닝 [h_name]."
    d "방금 돌아왔어요."
    scene ch02_pool02_17 at hand_camera with Dissolve(0.8)
    h "집에서 좋은 시간 보냈어요?"
    h "[d_name]이 없으니 벌써 집이 허전하더라구요."
    h "전 여기 있을테니까 필요한게 있으면 전화하거나 메세지 보내요."
    scene ch02_pool02_16 at hand_camera with Dissolve(0.8)
    d "네 알겠습니다. 고맙습니다."
    unknownf "헤이 꼬마!"
    scene ch02_pool02_18 at hand_camera with Dissolve(0.8)
    d "네?"
    scene ch02_pool02_19 at hand_camera with Dissolve(0.8)
    unknownf "왜 내 소개는 안하는거야?"
    unknownf "이거 매너가 영 아닌데?"
    scene ch02_pool02_20 at hand_camera with Dissolve(0.8)
    h "하.... 니가 왜 조용히 있나 했다."
    h "아 저기 [d_name]."
    scene ch02_pool02_21 at hand_camera with Dissolve(0.8)
    h "이 쪽은 레나라고해."
    h "어.... 그녀는 나의 베스트 프랜드야."
    if not in_replay:
        $ bio_lena = True
    scene ch02_pool02_22 at hand_camera with Dissolve(0.8)
    l "하이 꼬맹이. 나는 레나라고 해."
    l "앞으로 자주 보자."
    scene ch02_pool02_23 at hand_camera with Dissolve(0.8)
    d "안녕하세요. [d_name]이라고 합니다."
    d "전 며칠전에 이곳에 들어온 하숙생이에요."
    d "대학생인데 방학을 맞아서 이곳에 왔습니다."
    scene ch02_pool02_24 at hand_camera with Dissolve(0.8)
    d "(이 사람 어디서 본거 같은데?)"
    d "(아닌가? 내 착각인가?)"
    scene ch02_pool02_25 at hand_camera with Dissolve(0.8)
    l "(흠..... 이 꼬맹이 왜이렇게 낯익지?)"
    l "(그날 파티에 왔던 애인가?)"
    scene ch02_pool02_26 at hand_camera with Dissolve(0.8)
    d "전 올라갈게요."
    d "좋은 시간 보내세요."
    h "그래요. 주방에 간식들 있으니 먹어요."
    scene ch02_pool02_27 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_pool02_28 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh04.mp3"
    l "하하하."
    l "저 녀석에게 간식도 만들어준거야?"
    play sound "audio/ambi/park01.mp3" loop
    scene ch02_pool02_29 at hand_camera with Dissolve(0.8)
    l "저 녀석이 우리에게 좋은 시간 보내라는데? 헤헤."
    l "어떤 좋은 시간 말하는거지?"
    scene ch02_pool02_30 at hand_camera with Dissolve(0.8)
    h "컴온 레나."
    h "그는 요즘 보기 힘든 착한 학생이야."
    h "그렇게 놀리지 말라고."
    scene ch02_pool02_29-02 at hand_camera with Dissolve(0.8)
    l "하! 그러셔?"
    l "너 저 꼬마가 신경 쓰여서 나를 그냥 친구라고 소개 한거지?? 어?"
    l "저렇게 귀여운 녀석을 집에 들여놓고 니가 마음대로 가지고 놀려고 한거지?"
    l "'[d_name]이 없으니 벌써 집이 허전하더라구요.' 하하하."
    scene ch02_pool02_30-02 at hand_camera with Dissolve(0.8)
    h "지저스..레나.."
    h "그런거 아니야. 우리 사이는 굳이 [d_name]에게 말 안해도 되는 TMI라고.."
    h "하......"
    scene ch02_pool02_31 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh04.mp3"
    l "헤헤헤."
    play sound "audio/ambi/park01.mp3" loop
    l "저 꼬마 녀석 엄청 귀엽네."
    l "앞으로 더 자주 올게 자기야."
    scene ch02_pool02_32 at hand_camera with Dissolve(0.8)
    h "꿈도 꾸지마."
    h "그런 낌새라도 보이면 그날부터 넌 이 집에 출입금지야."
    scene ch02_pool02_31 at hand_camera with Dissolve(0.8)
    l "흠......."
    l "너 좀 과민반응 하는거 같은데?..."
    l "너 저 애가 맘에 드는거지? 헤헤헤"
    scene ch02_pool02_33 at hand_camera with Dissolve(0.8)
    h "................"
    scene ch02_pool02_34 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    jump ch02_hhouse01

label ch02_hhouse01:
    if not in_replay:
        $ persistent.unlock_ch02_hhouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A few hours later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3" 
    scene ch02_hhouse01_01 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_hhouse01_02 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_hhouse01_03 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_hhouse01_04 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_hhouse01_05 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_hhouse01_06 at hand_camera with Dissolve(1.5)
    d "오늘도 엄청난 하루 였군.."
    d "................"
    d "왜 계속 이런 일들이 생기는거지?"
    d "성인 드라마의 주인공이라도 된거같네..."
    scene ch02_hhouse01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_09 at hand_camera with Dissolve(0.8)
    pause 
    scene ch02_hhouse01_10 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_11-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_12 at hand_camera with Dissolve(0.8)
    d "젠장. 요즘 이상하게 난감한 상황들이 많이 생기네."
    d "1년 동안 내가 이상해진거야, 아님 이 동네가 이상해진거야?"
    d "내 꼬추에 자아가 생겨서 자꾸 밖으로 나오려고 하는건가?"
    scene ch02_hhouse01_13 at hand_camera with Dissolve(0.8)
    d "난 지금 시원한 물이 필요해."
    scene ch02_hhouse01_14 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_16 at hand_camera with Dissolve(0.8)
    n "깔깔깔깔깔"
    scene ch02_hhouse01_17 at hand_camera with Dissolve(0.8)
    d "허?"
    d "(그들은 1층에 있나보네..)"
    pause
    d "(중년 여성들의 즐거운 시간이라....)"
    d "(뭔가 로맨틱한걸.)"
    d "(영화라도 보고 있나?)"
    scene ch02_hhouse01_17-02 at hand_camera with Dissolve(0.8)
    d "(젠장 그런데 그들이 뭐하고 있는지 궁금하네.)"
    d "(이 집에 나와 여성 둘 뿐인게 뭔가 두근거리네.)"
    d "(지금도 수영복 입고 있으려나?)"
    pause
    d "(임마 지금 무슨 생각 하는거냐.)"
    menu:
        n "What should I do?"
        "Quietly head down to the first floor.":
            if not in_replay:
                $ add_point("lust_helen", 2, "lust_helen")
                $ add_point("lust_lena", 3, "lust_lena")
            scene ch02_hhouse01_17-02 at hand_camera with Dissolve(0.8)
            d "(젠장. 이젠 관음증까지 생긴거냐?)"
            play music "audio/bgm/sus01.mp3" volume 0.8
            scene ch02_hhouse01_18 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_19 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_20 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_21 at hand_camera with Dissolve(0.8)
            n "1층 거실에선 그들이 다정하게 앉아 영화를 보고 있었다."
            n "그들은 어깨를 붙이고 앉아있었고 마치 어린 소녀시절 모든것을 공유하는 절친의 감성을 이어가고 있는듯 보였다."
            scene ch02_hhouse01_22 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_23 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_24 at hand_camera with Dissolve(0.8)
            l "그래서 어쩔 계획이야 [h_name]?"
            h "응? 계획이라니?"
            l "뭐야 모르는척 하는거야?"
            l "나야 그 녀석이야?"
            scene ch02_hhouse01_25 at hand_camera with Dissolve(0.8)
            play voice_f "audio/voices/fsigh06.mp3"
            h "하... 레나.."
            h "그런거 아니라니까. 내가 미친 여자로 보이니?"
            h "나보다 20살도 더 어린 애가 남자로 보이겠어?"
            h "이런걸 굳이 설명해야 하는것도 어이가 없네."
            scene ch02_hhouse01_24 at hand_camera with Dissolve(0.8)
            l "우~~ 우리 달링이 나몰래 귀여운 남자애를 세입자로 들이셨어요?"
            l "니가 마음만 먹었으면 여자들도 들일 수 있었잖아?"
            l "이제 보니 니가 나보다 더 속물인거 같은데?"
            scene ch02_hhouse01_25-02 at hand_camera with Dissolve(0.8)
            h "마음대로 생각해."
            h "그리고 [d_name]에 대해 한 마디만 더 하면 그걸로 우리는 끝이야."
            scene ch02_hhouse01_26 at hand_camera with Dissolve(0.8)
            l "베이비.."
            scene ch02_hhouse01_27 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse01_28 at hand_camera with Dissolve(0.8)
            l "니가 괜찮으면 나도 괜찮아."
            l "니가 누굴 만나든, 누구에게 수작을 부리든 난 신경안써."
            l "너도 나의 삶의 방식을 이해 해 줬잖아. 난 그게 정말 고마웠어."
            l "하지만.."
            l "너도 느꼈지? 그 녀석 자지가 꽤 튼실한거 같던데?"
            h "뭐?!!!!"
            l "너도 이제 진짜 자지가 필요한 때가 된거야."
            l "굳이 저런 어린 남자애를 들인건 젊은 자지가 필요했던거 아냐?"
            l "너를 빈틈 없이 채워줄 그런 젊은 자지 말이야."
            l "제대로 서있지도 못할 정도로 너를 망가트려줄 그런 자지 말이야."
            scene ch02_hhouse01_29 at hand_camera with Dissolve(0.8)
            d "(...........)"
            d "(맙소사.)"
            d "(더러운 문장들의 토네이도가 몰아치는거 같아.)"
            d "(중년의 여성은 표현이 정말 강력하구나..)"
            scene ch02_hhouse01_30 at hand_camera with Dissolve(0.8)
            h "그만해!"
            h "너 정신 나갔어?"
            scene ch02_hhouse01_30-02 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/kissshort03.mp3"
            pause
            scene ch02_hhouse01_30-03 at hand_camera with Dissolve(0.8)
            l "아니 난 지금 지극히 멀쩡해."
            l "난 지금 널 위해 말하고 있는거야."
            scene ch02_hhouse01_30-04 at hand_camera with Dissolve(0.8)
            l "너도 알잖아."
            l "너에겐 지금 플라스틱 막대기 따위가 아니라 진짜 자지가 필요한 시점이라는 걸."
            l "그리고 그런 자지가 손만 뻗으면 닿을 위치에 왔는걸?"
            l "난 니가 그런 결정을 했다는게 오히려 기뻐 베이비."
            scene ch02_hhouse01_29 at hand_camera with Dissolve(0.8)
            d "(Holy....)"
            d "(그녀의 얘기가 맞을까?)"
            d "(랜드레이디가 그런 목적을 가지고 날 세입자로 들였다고????)"
            pause
            d "(에이 설마..)"
            d "(며칠 안됐지만 그런 낌새는 전혀 없었는데..)"
            scene ch02_hhouse01_31 at hand_camera with Dissolve(0.8)
            l "내가 항상 얘기 했잖아. 니가 좋은거면 난 무조건 좋아."
            l "그말은 즉슨..."
            scene ch02_hhouse01_30-04 at hand_camera with Dissolve(0.8)
            l "내가 좋으면 너도 좋아야 한다고 하하하."
            scene ch02_hhouse01_30-05 with dissolve
            d "(!!!!!!!!!!!!!!!!!!!!!!!)"
            d "(젠장 생각났다!!!)"
            scene ch02_hhouse01_32 at hand_camera with Dissolve(0.8)
            d "(버스 정류장에서 봤던 그녀였어!!)"
            scene ch02_hhouse01_32-01 at hand_camera with Dissolve(0.8)
            d "(젠장!!)"
            d "(어쩐지 낯이 익더라!!)"
            scene ch02_hhouse01_32-02 at hand_camera with Dissolve(0.8)
            h "뭐? 그게 무슨 말이야?"
            h "너 무슨 꿍꿍이냐고?"
            h "니가 어떤게 좋다는 얘기야?"
            scene ch02_hhouse01_30-03 at hand_camera with Dissolve(0.8)
            l "헤헤 그 얘긴 나중에 하자."
            l "난 지금 니가 필요하다고! 달링."
            play music "audio/bgm/erotic03.mp3"
            scene ch02_hhouse01_33 at hand_camera with Dissolve(0.8)
            pause
            play sound "audio/ambi/fabric01.mp3"
            scene ch02_hhouse01_33-02 at hand_camera with Dissolve(2.0)
            pause
            scene ch02_hhouse01_34 with vpunch
            pause
            scene ch02_hhouse01_35 at hand_camera with Dissolve(0.8)
            d "(젠장! 좆될뻔 했다.)"
            d "(나 지금 뭐하냐..)"
            scene ch02_hhouse01_36 at hand_camera with Dissolve(0.8)
            l "이리와 달링~"
            l "날 안아줘."
            scene ch02_hhouse01_37 at hand_camera with Dissolve(0.8)
            l "사랑해 [h_name]."
            play voice_f "audio/sex/kissshort03.mp3"
            pause
            l "니가 노인을 만나든 어린애를 만나든 난 다 괜찮아."
            l "왜냐하면 난 너를 사랑하기 때문이야."
            l "사랑하는 사람이 행복한 삶을 사는 모습을 보는게 나의 진정한 행복이야."
            scene ch02_hhouse01_38 at hand_camera with Dissolve(1.5)
            pause
            scene ch02_hhouse01_39 at hand_camera with Dissolve(0.8)
            d "(지저스....)"
            scene ch02_hhouse01_40 at hand_camera with Dissolve(0.8)
            d "(젠장... 저 여자 올리비아와 막상막하인듯...)"
            d "(근데 뭐랄까 올리비아가 우아한 섹시함이라면 저 여자는 더 스파이시 한 거 같아.)"
            d "(어떡하지? 젠장 궁금해 미치겠네...)"
            d "(....................)"
            d "(맞다!! 밖에 창문!!)"
            jump ch02_house02

label ch02_house02:
    menu:
        n "What should I do?"
        "Go outside and spy on them.":
            if not in_replay:
                $ add_point("lust_helen", 2, "lust_helen")
                $ add_point("lust_lena", 2, "lust_lena")
            scene ch02_hhouse02_01 at hand_camera with Dissolve(0.8)
            play music "audio/bgm/sus02.mp3"
            d "(맞다!!)"
            d "(밖에 큰 창이 있었던거 같아!)"
            scene ch02_hhouse02_02 at hand_camera with Dissolve(0.8)
            d "(젠장 [d_name]..)"
            d "(너 이거 밖에 안된는 놈이었냐?!)"
            d "(저들에게 발각되면 어쩌려고??)"
            d "(도촬하고 훔쳐보고..참나 자괴감 살벌하네..)"
            scene ch02_hhouse02_03 at hand_camera with Dissolve(0.8)
            d "(근데 궁금한건 못참겠다..)"
            scene ch02_hhouse02_04 at hand_camera with Dissolve(0.8)
            d "(젠장 두근두근하네.)"
            d "(왠지 잘못된걸 알지만 멈출수 없는 범죄자가 된 기분이랄까?)"
            n "짭짭, 쪽쪽."
            d "(젠장. 저 둘 뭐하는 걸까?..)"
            play sound "audio/ambi/cat02.mp3"
            scene ch02_hhouse02_05 with vpunch
            d "(젠장!깜짝이야!!)"
            scene ch02_hhouse02_06 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_07 at hand_camera with Dissolve(0.8)
            d "(젠장!)"
            scene ch02_hhouse02_08 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/cat01.mp3"
            d "(저 쪼그만 새끼!!)"
            scene ch02_hhouse02_08-02 at hand_camera with Dissolve(0.8)
            d "(저리가!)"
            d "(저 놈 대체 어디서 튀어나온거야?)"
            d "([h_name]이 키우는 고양이인가?)"
            scene ch02_hhouse02_09 at hand_camera with Dissolve(0.8)
            d "(심장이 터질거 같아.)"
            scene ch02_hhouse02_10 at hand_camera with Dissolve(0.8)
            d "!!!!!!!!!!!!!!!"
            scene ch02_hhouse02_11 at hand_camera with Dissolve(0.8)
            play music "audio/bgm/erotic04.mp3"
            d "([h_name].....)"
            scene ch02_hhouse02_12 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_13 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_14 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_15 at hand_camera with Dissolve(0.8)
            d ".............."
            scene ch02_hhouse02_16 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_17 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_18 at hand_camera with Dissolve(0.8)
            h "왜 그래?"
            scene ch02_hhouse02_19 at hand_camera with Dissolve(0.8)
            l "아 그냥 무슨 소리를 들은거 같아서."
            l "잠깐 확인만 할게."
            scene ch02_hhouse02_20 at hand_camera with Dissolve(0.8)
            d "(젠장!!!!!!!!!)"
            scene ch02_hhouse02_21 at hand_camera with Dissolve(0.8)
            l "허??"
            scene ch02_hhouse02_22 at hand_camera with Dissolve(0.8)
            l "헤헤. 너였구나."
            l "하루종일 어디갔다 왔니?"
            scene ch02_hhouse02_24 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_22-02 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/cat01.mp3"
            n "냐옹"
            scene ch02_hhouse02_22 at hand_camera with Dissolve(0.8)
            l "지금은 못들어와."
            l "이따가 다시 와 알았지?"
            l "미안해."
            l ".............."
            scene ch02_hhouse02_23 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/knock02.mp3"
            pause
            scene ch02_hhouse02_24 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_25 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_26 at hand_camera with Dissolve(0.8)
            d "!!!!!!!!!!!!!!!!!!!!!!"
            scene ch02_hhouse02_27 at hand_camera with Dissolve(0.8)
            play music "audio/bgm/sus01.mp3" volume 0.8
            pause
            scene ch02_hhouse02_28 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_29 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_29-02 at hand_camera with Dissolve(0.8)
            play voice_f "audio/voices/flaugh03.wav"
            pause
            scene ch02_hhouse02_29-03 at hand_camera with Dissolve(0.8)
            d "(맙소사...)"
            d "(저 여자는 부끄러움이란 없구나!!)"
            d "(젠장...난 벌써 그녀가 좋아졌어.)"
            d "(그녀는 이 세상의 모든걸 포용할 수 있는 여자 같아...하...)"
            d "(사랑해요 레나!!!!!)"
            scene ch02_hhouse02_30 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_31 at hand_camera with Dissolve(0.8)
            h "뭐해?"
            l "아 뭔가 밖에서 움직인거 같은데 고양이였어."
            scene ch02_hhouse02_32 at hand_camera with Dissolve(0.8)
            pause
            scene ch02_hhouse02_33 at hand_camera with Dissolve(0.8)
            l "(이 음흉한 녀석.)"
            l "(감히 랜드레이디의 사생활을 훔쳐봐?!)"
            scene ch02_hhouse02_34 at hand_camera with Dissolve(0.8)
            l "(이건 어때?)"
            l "(마음에 드니?)"
            l "(여기에 넣고 싶어서 미치겠지? 하하하.)"
            l "(아마 너의 자지 사이즈에 딱 맞을거 같은데?)"
            scene ch02_hhouse02_35 at hand_camera with Dissolve(0.8)
            l "(너의 자지를 빈틈없이 뜨겁게 감싸줄거 같지?)"
            l "(하..........)"
            l "(안타깝지만 오늘은 아니야.)"
            l "(그렇게 쉽게 여자를 따먹으면 안되지.)"
            l "(내 보지에 넣으려면 우선 너를 증명해야지.)"
            pause
            l "(그리고 이 집에 너의 파트너는 다른 사람인거 같은데?)"
            play sound "audio/ambi/curtain01.mp3"
            scene ch02_hhouse02_35-02 with dissolve
            pause
            d "(..............)"
            scene ch02_hhouse02_36 at hand_camera with Dissolve(2.0)
            d "(젠장.....)"
            d "(나 지금 심장이 터질거 같아....)"
            d "(..............)"
            scene ch02_hhouse02_37 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/cat01.mp3"
            d "(...............)"
            d "(사랑해요 레나.)"
            d "(사랑해요 [h_name].)"
            d "(나도 당신들의 세계에 들어가고 싶어요.)"
            d "(나도 당신들처럼 어른이라구요.)"
            jump ch02_droom02

label ch02_droom02:
    if not in_replay:
        $ persistent.unlock_ch02_droom02 = True
    scene black at hand_camera with Dissolve(0.8)
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night04.mp3"
    scene ch02_hhouse01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_hhouse01_02 at hand_camera with Dissolve(0.8)
    n "탁탁탁"
    scene ch02_droom02_01 at hand_camera with Dissolve(0.8)
    n "탁탁탁"
    scene ch02_droom02_02 at hand_camera with Dissolve(0.8)
    d "아흑"
    scene ch02_droom02_03 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    scene ch02_droom02_04 at hand_camera with Dissolve(0.8)
    d "레나!!"
    scene ch02_droom02_05 at hand_camera with Dissolve(0.8)
    d "[h_name]!! 레나!! 어서 와서 이 위에 앉아요!!"
    d "나의 자지를 사용해주세요!!"
    d "난 당신들을 만족시켜줄 수 있는 남자라구요!!!"
    n "탁탁탁"
    scene ch02_droom02_07 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_droom02_08 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh01.mp3"
    l "하... 나른하다."
    l "나도 이제 나이를 먹어가는구나."
    l "몇시간 운전했더니 밤에는 엄청피곤하네."
    scene ch02_droom02_08-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom02_09 at hand_camera with Dissolve(0.8)
    l "저 꼬마녀석....."
    l "생긴건 순진한데 하는 행동은 변태 녀석이야."
    scene ch02_droom02_10 at hand_camera with Dissolve(0.8)
    l "근데 보통 저런 순진한 얼굴을 한 녀석들이 거대한 자지를 가지고 있더라."
    l "위대한 자연의 밸런스 뭐 그런것일까?"
    scene ch02_droom02_10-02 at hand_camera with Dissolve(0.8)
    l "랜드레이디의 사생활을 훔쳐보고 말이야.."
    l ".................."
    l "중년의 여성 집주인과 젊은 남성 세입자라.."
    l "고대 그리스 시절 전부터 이어지는 인류의 클래식이지 하하하."
    scene ch02_droom02_11 at hand_camera with Dissolve(0.8)
    l "근데 항상 그런 클래식의 결말은 비극이었던거 같은데."
    l "중년의 여성과 젊은 남성이 행복하게 오래오래 살았데요 하는 이야기는 없었어."
    scene ch02_droom02_11-02 at hand_camera with Dissolve(0.8)
    l "중년의 여성은 항상 죄책감을 느껴 무너졌고"
    l "젊은 남성은 중년 여성의 시든 몸에 실망하고 자신의 성욕을 감당할 수 있는 젊은 여성에게로 돌아갔었지."
    l "여성의 남편이 등장하면 피가 난자하는 혈전도 벌어지고 말이야.."
    scene ch02_droom02_11 at hand_camera with Dissolve(0.8)
    l "......................."
    l "젠장...."
    l "그래도 나나 [h_name]이나 진짜 자지를 느껴본게 꽤 오래전 일인거 같아.."
    l "..................."
    l "남자를 만나면 안된다는 규칙이 있었던것도 아닌데 말이야.."
    l "......................."
    scene ch02_droom02_10-02 at hand_camera with Dissolve(0.8)
    l "우리 둘만으로도 충분 했지만 뭐랄까..."
    l "서로 말은 안해도 진짜 남자가 아니면 채워줄 수 없는게 있다는건 알았지..."
    l "[h_name]과 같이 자기 시작하면서 오히려 남자가 어느때보다 더 절실했었어.."
    pause
    l "하.............."
    l "저 놈이 우리 [h_name]과 같은 집에 살아도 되는 놈인지 알아봐야겠어."
    l "이런 외진 곳에서 남자가 마음만 먹으면 무슨 짓이든 할 수 있잖아.."
    scene ch02_droom02_12 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_droom02_12-01 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom02_12-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom02_13 at hand_camera with Dissolve(1.5)
    pause
    scene ch02_droom02_13-02 at hand_camera with Dissolve(0.8)
    l "(노출이 좀 과한가?)"
    l "(뭐 어때. 내가 입고 싶은 대로 입는거지.)"
    l "(어린애랑 잠시 얘기하는건데.)"
    scene ch02_droom02_14 at hand_camera with Dissolve(0.8)
    l "계신가요 아저씨?"
    scene ch02_droom02_14-02 at hand_camera with Dissolve(0.8)
    n "윽!!"
    scene ch02_droom02_15 at hand_camera with Dissolve(0.8)
    l "허??"
    l "무슨 소리야?"
    play sound "audio/ambi/dooropen02.mp3"
    scene ch02_droom02_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom02_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_droom02_18 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fgrunt03.mp3"
    l "!!!!!!!!!!!!!!!!"
    scene ch02_droom02_19 at hand_camera with Dissolve(0.8)
    l "(맙소사...)"
    scene ch02_droom02_20 at hand_camera with Dissolve(0.8)
    l "..............."
    d "아 [h_name]!!"
    l "(오 보이...)"
    d "아 레나!!"
    l "(예스! 나 여기있어!!)"
    pause
    l "(젠장 구멍 하나에 자지 두개?)"
    l "(저런 취향인가?)"
    l "(저 손 빠른것좀 봐..)"
    scene ch02_droom02_18 at hand_camera with Dissolve(0.8)
    l "(맙소사..)"
    l "(!!!!!!!!!!!)"
    l "(생각났다!!!!! 저 놈!!!)"
    scene ch02_droom02_19-02 at hand_camera with Dissolve(0.8)
    l "(저거 버스에서 그 꼬마 녀석이었어!!)"
    l "(내 사진 찍은 놈.)"
    scene ch02_droom02_18 at hand_camera with Dissolve(0.8)
    l "(이런 우연이 있을수 있나!!)"
    l "(....................)"
    scene ch02_droom02_21 at hand_camera with Dissolve(0.8)
    l "(저 힘줄좀 봐....)"
    l "(근래 본것중에 제일 난폭해 보이는 자지야.)"
    scene ch02_droom02_22 at hand_camera with Dissolve(0.8)
    l "([h_name] 이 음흉한 년...)"
    l "(운이 좋은거야 아니면 투시 능력이라도 생긴거니?)"
    l "(어떻게 저런 물건을 고른거지?)"
    l "(세입자 구할때 오디션이라도 본건가?)"
    scene ch02_droom02_23 at hand_camera with Dissolve(0.8)
    l "(아직 이 세상은 정의롭네.)"
    l "([h_name]처럼 조신하게 살면 복이 오는구나.)"
    scene ch02_droom02_24 at hand_camera with Dissolve(2.0)
    h "(그녀는 어디에 있는거지?)"
    h "(이 밤중에 어디로 간거야?)"
    scene ch02_droom02_24-02 at hand_camera with Dissolve(0.8)
    h "(허?)"
    scene ch02_droom02_22 at hand_camera with Dissolve(0.8)
    l "(저게 내가 진짜로 원하는 거야..)"
    play voice_f "audio/sex/fsigh.mp3"
    l "(한 번만 넣어도 날 완전히 굴복시킬수 있는 자지..)"
    l "(내 안의 복종 본능을 이끌어내 줄 수 있는 자지...)"
    l "(............)"
    l "하...그냥 보는것만으로도 내 보지가 움찔거리네."
    scene ch02_droom02_24-02 at hand_camera with Dissolve(0.8)
    h "(뭐?)"
    h "(보지가 움찔거린다고??)"
    scene ch02_droom02_25 at hand_camera with Dissolve(0.8)
    h "레나! 거기서 뭐해?"
    play voice_f "audio/voices/fhurt07.mp3"
    scene ch02_droom02_26 with dissolve
    l "(!!!!!!!!!!!!!!!!!!!!!!!!!!!!)"
    scene ch02_droom02_27 at hand_camera with Dissolve(0.8)
    h "[d_name] 방 문 열고 뭐해??"
    scene ch02_droom02_28 at hand_camera with Dissolve(0.8)
    d "아 레나!!!!"
    d "아 [h_name]!!!!"
    d "당신의 보지가 너무 타이트해요!!"
    scene ch02_droom02_26 at hand_camera with Dissolve(0.5)
    l "(조용히해 바보야!!!!!!!!!)"
    scene ch02_droom02_29 at hand_camera with Dissolve(2.0)
    pause
    hide screen top_ui_buttons
    jump ch03_droom01
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
