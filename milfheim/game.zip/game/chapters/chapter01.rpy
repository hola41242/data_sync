default persistent.chapter = 0
default in_replay = False

init python:
    flash = Fade(0.25, 0.0, 0.75, color="#fff")

init python:
    def play_looped_movie(movie_path, audio_path=None):
        renpy.movie_cutscene(movie_path, loop=True)
        if audio_path:
            renpy.music.play(audio_path, channel="sound", loop=True)
        renpy.pause(hard=True)

    def stop_looped_movie(audio_fadeout=0.2):
        renpy.music.stop(channel="sound", fadeout=audio_fadeout)

init python:
    def pan_top(margin=200):
        return -margin

    def pan_bottom(img_h, margin=200):
        return -(img_h - config.screen_height - margin)

transform smooth_vertical_pan(img_h=3840):
    xalign 0.5
    ypos pan_top()
    linear 6 ypos pan_bottom(img_h)
    linear 6 ypos pan_top()


transform zoom_in_center:
    xpos 0.5 ypos 0.5
    xanchor 0.5 yanchor 0.5
    zoom 1.0
    linear 2.0 zoom 1.2




define d = Character("[d_name]", color="#7289da", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)], dynamic=True)
define h = Character("[h_name]", color="#e255a1", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)], dynamic=True)

default d_name = "Damian"
default h_name = "Helen"


define a = Character("Amanda", color="#5c469c", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define an = Character("Anna", color="#DDA0DD", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define al = Character("Alessia", color="#3cd070", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define b = Character("Beth", color="#d42020", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define c = Character("Celine", color="#DDA0DD", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define ch = Character("Chloe", color="#5c469c", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define di = Character("Diana", color="#ef6fc6", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define e = Character("Emma", color="#cae34f", what_outlines=[(5, "#8c8c8c88", 0, 0), (3, "#111", 0, 0)])
define eth = Character("Ethan", color="#6C5B7B", what_outlines=[(5, "#8c8c8c88", 0, 0), (3, "#111", 0, 0)])
define ev = Character("Evan", color="#5B6E7A", what_outlines=[(5, "#8c8c8c88", 0, 0), (3, "#111", 0, 0)])
define eve = Character("Evelyn", color="#f06d1f", what_outlines=[(5, "#8c8c8c88", 0, 0), (3, "#111", 0, 0)])
define f = Character("Frank", color="#777777", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define l = Character("Lena", color="#f06d1f", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define lei = Character("Leila", color="#FF69B4", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define i = Character("Ivy", color="#3cd070", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define j = Character("Jason", color="#747474", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define k = Character("Kara", color="#e6b800", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define ke = Character("Kevin", color="#7A6855", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define r = Character("Rose", color="#ffccee", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define re = Character("Rebecca", color="#e0867e", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define mi = Character("Michael", color="#717f3d", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define mo = Character("Monica", color="#3cd070", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define o = Character("Olivia", color="#8e44ad", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define y = Character("Penny", color="#3cd070", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define m = Character("Mary", color="#e0867e", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define mar = Character("Marcus", color="#6C5B7B", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define s = Character("Sophia", color="#ff6969", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define st = Character("Stella", color="#ffccee", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define sha = Character("Shakira", color="#cae34f", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define x = Character("Madam X", color="#ff6969", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define tv = Character("TV", color="#777777", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define dj = Character("[d_name] & Jason", color="#7289da", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define isa = Character("Isabella", color="#d42020", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define chi = Character("Harold", color="#777777", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define do = Character("Detective Owen", color="#777777", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define wait = Character("Isabella", color="#d42020", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define la = Character("Larry", color="#747474", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define viv = Character("Vivian", color="#FF007F", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define ve = Character("Veronica", color="#7289da", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define unknown = Character("???", color="#f06d1f", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define unknownm = Character("???", color="#777777", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define unknownf = Character("???", color="#8e44ad", what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])



define nCenter = Character(None, window_hide=True, layout = "subtitle", show_two_window=False, what_text_align=0.5, what_xalign=0.5, window_yalign=0.5, window_xfill=False, what_size = 50, window_background=None, what_outlines=[(5, "#1118", 0, 0), (3, "#111", 0, 0)])
define n = Character(what_style="narration_text_style", 
    layout = "subtitle", 
    show_two_window=False, 
    what_text_align=0.5, 
    what_xalign=0.5, 
    window_yalign=0.95, 
    window_xfill=False, 
    what_size = 35, 
    window_background=None, 
    what_outlines=[(4, "#111", 0, 0)])


default lust_amanda = 0
default lust_alessia = 0
default lust_anna = 0
default lust_beth = 0
default lust_celine = 0
default lust_chloe = 0
default lust_diana = 0
default lust_evelyn = 0
default lust_emma = 0
default lust_lena = 0
default lust_ivy = 0
default lust_helen = 0
default lust_isabella = 0
default lust_rose = 0
default lust_olivia = 0
default lust_leila = 0
default lust_mary = 0
default lust_sophia = 0
default lust_stella = 0
default lust_monica = 0
default lust_rebecca = 0
default lust_shakira = 0
default lust_vivian = 0
default lust_veronica = 0


default sus_amanda = 0
default sus_alessia = 0
default sus_anna = 0
default sus_beth = 0
default sus_celine = 0
default sus_chloe = 0
default sus_diana = 0
default sus_evelyn = 0
default sus_emma = 0
default sus_lena = 0
default sus_ivy = 0
default sus_helen = 0
default sus_isabella = 0
default sus_rose = 0
default sus_olivia = 0
default sus_leila = 0
default sus_mary = 0
default sus_sophia = 0
default sus_stella = 0
default sus_monica = 0
default sus_rebecca = 0
default sus_shakira = 0
default sus_vivian = 0
default sus_veronica = 0


default love_amanda = 0
default love_alessia = 0
default love_anna = 0
default love_beth = 0
default love_celine = 0
default love_chloe = 0
default love_diana = 0
default love_evelyn = 0
default love_emma = 0
default love_lena = 0
default love_ivy = 0
default love_helen = 0
default love_isabella = 0
default love_rose = 0
default love_olivia = 0
default love_leila = 0
default love_mary = 0
default love_sophia = 0
default love_stella = 0
default love_monica = 0
default love_rebecca = 0
default love_shakira = 0
default love_vivian = 0
default love_veronica = 0


default friendship_jason = 0
default friendship_ethan = 0
default friendship_evan = 0
default friendship_frank = 0
default friendship_harold = 0
default friendship_kevin = 0
default friendship_marcus = 0
default friendship_michael = 0
default friendship_owen = 0


default respect_jason = 0
default respect_ethan = 0
default respect_evan = 0
default respect_frank = 0
default respect_harold = 0
default respect_kevin = 0
default respect_marcus = 0
default respect_michael = 0
default respect_owen = 0


default rivalry_jason = 0
default rivalry_ethan = 0
default rivalry_evan = 0
default rivalry_frank = 0
default rivalry_harold = 0
default rivalry_kevin = 0
default rivalry_marcus = 0
default rivalry_michael = 0
default rivalry_owen = 0


default bio_amanda = False
default bio_beth = False
default bio_celine = False
default bio_diana = False
default bio_emma = False
default bio_lena = False
default bio_ivy = False
default bio_helen = False
default bio_kara = False
default bio_rose = False
default bio_olivia = False
default bio_penny = False
default bio_mary = False
default bio_sophia = False


default persistent.sophia_info_1 = True
default show_info_button = False


label splashscreen:




    scene warning with Dissolve(1.0)
    pause
    scene warning02 with Dissolve(1.0)
    pause
    scene soundguide with Dissolve(1.0)
    pause
    scene bs with Dissolve(1.0)
    pause


    scene 18over
    menu:
        "Are you 18 years of age or older?"
        "Yes":
            pass
        "No":
            $ renpy.quit()


    return



label start:

    if not in_replay:
        $ reset_phone_data()


    jump set_woman_name

label set_woman_name:


    show expression "images/intro/heroine.jpg" at left with dissolve
    n "Here's the heroine of this story."
    n "She's a quiet, but deeply scarred middle-aged woman.\nNo one knows what dark things have happened in her past."
    n "You can name her or go with the default name."

    $ h_name = renpy.input("What is her name?", default=h_name)
    $ h_name = h_name.strip()
    if h_name == "":
        $ h_name = "Helen"

    menu:
        "Is [h_name] correct?"
        "Yes":
            pass
        "No":
            jump set_woman_name

    jump set_mc_name

label set_mc_name:

    show expression "images/intro/hero.jpg" at left with dissolve
    n "He's the hero of this story."
    n "This young man grew up in a youth center and a foster home and is now a university student. \nFor the vacation, he returned to his hometown. His past is shrouded in mystery."
    n "You can name him or go with the default name."

    $ d_name = renpy.input("What is his name?", default=d_name)
    $ d_name = d_name.strip()
    if d_name == "":
        $ d_name = "Damian"

    menu:
        "Is [d_name] correct?"
        "Yes":
            pass
        "No":
            jump set_mc_name
    $ show_info_button = True

    play music "audio/bgm/normal.mp3"
    scene black with dissolve
    nCenter "presented by Bittersweet3D" with Dissolve(2.0)

    show expression "images/intro/milfheim_logo.png" as logo at truecenter with Dissolve(2.0)
    pause
    hide logo
    jump v01_lecture01


label v01_lecture01:
    if not in_replay:
        $ persistent.unlock_v01_lecture01 = True
    scene campus01 with Dissolve(2.0)
    show screen top_ui_buttons
    n "밀프하임 대학교."
    s "좋습니다, 여러분. 벌써 이번 학기의 마지막 장이네요.."
    s "아마도 여러분 인생에 꼭 필요한 깊은 통찰을 얻을 수도 있겠지요."
    s "그러니 잘 집중해서 들어주세요."
    scene campus02 with Dissolve(1.0)
    s "정리하자면 심리학은 단순히 이론으로만 이루어진 학문이 아닙니다."
    s "궁극적으로는 우리 자신의 마음과 타인의 마음을 깊이 들여다보고 이해하려는 행위가 수반되어야 합니다."

    if not in_replay:
        $ bio_sophia = True
        $ bio_amanda = True
        $ bio_jason = True
        $ bio_frank = True
    scene 01lecture_00 with dissolve
    s "우리가 미처 깨닫지 못하는, 겉으로 잘 드러나지 않는 감정과 행동의 아주 미묘한 이면을 탐구하는 학문이죠."
    s "왜 우리는 어떤 상황에서 특정 감정을 느끼고, 왜 그렇게 행동할 수밖에 없는지... 그 근원을 찾아가는 겁니다."
    s "하지만 여기서 중요한 건, 이 모든 탐구가 타인의 마음을 억지로 파헤치거나 지배하겠다는 뜻이 아니라는 거예요."
    s "오히려 그 출발점은 바로 자기 자신의 마음을 섬세하게 분석하고 이해하기 위한 기술에서 시작됐어요."
    scene 01lecture_01 with dissolve
    s "내가 왜 지금 이런 감정을 느끼는지, 왜 과거에 그런 선택을 했는지... 자기 자신을 깊이 이해하는 데서 모든 것이 시작되는 거죠."
    s "우리는 보통 외부 상황이나 타인에게서 감정의 원인을 찾곤 하지만, 실제로는 우리 내면의 복잡한 작용에서 비롯되는 경우가 많아요."
    s "진정한 목적은 결국 더 나은 삶, 더 건강한 관계를 만드는 데 있어요."
    s "서로의 마음을 더 깊이 이해하고, 결과적으로 더 진하게 연결되기 위한 끊임없는 노력인 셈이죠."
    scene 01lecture_02 with dissolve
    s "우리가 타인과 맺는 수많은 감정의 실타래를 조금이라도 더 명확하고 투명하게 들여다보기 위한 정교한 도구랄까요."
    s "왜 우리는 누군가에게 강렬하게 끌리는지, 혹은 반대로 갑자기 마음이 식어버리는지..."
    s "사랑, 우정, 심지어는 증오와 같은 복잡한 감정들이 어떻게 생겨나고 변화하는지, 그 모든 과정을 이해하려는 거죠."
    scene 01lecture_02-01 with dissolve
    s "말로 쉽게 설명할 수 없는, 가슴을 때리는 감정의 파동이나 순간적인 느낌들 말이에요."
    s "그것조차도 사실은 우리 마음 가장 깊은 곳, 의식의 표면 아래에서 비롯된 반응들입니다."
    s "이 모든 복잡한 감정과 행동의 원천은 심리 깊은 곳, 우리가 통제하기 어려운 아주 깊은 무의식에서 시작돼요."
    scene 01lecture_02-02 with dissolve
    s "이 무의식은 단순히 어둠 속에 가려진 영역이 아니라, 우리가 아주 오래전에 겪었던 기억들, 강렬한 감정들, 그리고 우리가 미처 의식하지 못했던 무수히 많은 경험들에 의해 끊임없이 형성되고 진화하고 있어요."
    s "우리가 현재 느끼고 판단하는 모든 것의 거대한 기반이 되는 거죠."
    scene 01lecture_03 with dissolve
    s "여러분들이 그 존재를 인지하건 인지하지 못하건, 또 그것의 영향을 깨닫건 깨닫지 못하건 상관 없이 말이죠."
    s "우리의 마음속 깊은 곳, 바로 그 무의식에서는 이미 반응이 시작되었고, 우리는 단지 그 결과로 나타나는 감정이나 행동만을 느낄 뿐입니다."
    s "마치 수면 아래에서 거대한 물살이 움직이는 것처럼요."
    scene 01lecture_03 with dissolve
    s "예를 들어볼까요. 여러분이 정말 좋아하는 사람과 단둘이 있을 때, 갑자기 평소에는 잘만 나오던 말이 막히고, 심장이 걷잡을 수 없이 두근거리는 경험, 다들 한 번쯤은 해봤을 거예요."
    s "단순히 '긴장해서 그래'라고 넘겨버리기엔 무언가 설명할 수 없는 강력한 끌림이 있겠죠."
    scene 01lecture_03-01 at hand_camera with dissolve
    s "이러한 현상들은 단순히 현재의 감정적인 동요가 아니라, 우리 안에 저장된 과거의 기억이나 경험들이 얽혀서 발현되는 아주 복잡한 심리적 패턴의 일부일 수 있어요."
    s "특정 상황, 특정 사람 앞에서 무의식적으로 어떤 반응을 하게끔 프로그래밍되어 있을지도 모른다는 얘기죠."
    scene 01lecture_03-02 with dissolve
    s "때로는 우리 의식과는 별개로 무의식이 아주 냉정하고 직관적인 판단을 속삭입니다. 마치 이렇게 말하듯이요."
    s "'이 사람은 위험해 보이지만 묘하게 끌리는 뭔가가 있어', 혹은 '이 사람은 안전하고 편안하지만, 어쩐지 재미없고 지루하게 느껴진다'라고요."
    s "이러한 무의식적 메시지들이 우리의 의식적인 판단과 행동에 지대한 영향을 미칩니다."
    scene 01lecture_03-03 with dissolve
    j "…교수님, 그럼 우리가 사랑에 빠지는 것도 결국 학문적으로 설명되는 건가요?"
    j "그런 감정조차 이론이나 패턴으로 분석이 가능한가요?"
    scene 01lecture_03-04 with dissolve
    s "완전히 모든 것을 설명할 수는 없겠지만, 맞아요, 상당 부분은 충분히 설명될 수 있습니다."
    s "사랑이라는 감정, 끌림이라는 현상은 우리가 생각하는 것 이상으로 복잡한 여러 감정과 경험들의 총합체예요."
    s "하지만 그 복잡함 속에서도 일정한 흐름과 반복되는 패턴이 분명히 존재하죠. 이건 과학적인 발견이기도 합니다."
    s "그리고 그 패턴을 이해하는 것이 우리 자신과 타인을 이해하는 데 큰 도움이 될 수 있어요."
    scene 01lecture_03-05 with dissolve
    s "때로는 우리가 누군가에게 강하게 끌리는 트리거, 즉 방아쇠는 그 사람의 외적인 모습이나 명백한 조건들보다 오히려 우리 내면의 아주 깊은 무언가에서 시작되기도 합니다."
    s "예상치 못한 순간, 그 사람의 목소리 톤이나 특유의 말투, 은은한 향수 냄새, 아니면 무심코 던진 어떤 말 한마디가 마치 과거의 중요한 기억이나 감정적인 경험과 섬광처럼 맞닿아 있을 수도 있다는 거죠."
    s "이성적인 판단이 개입하기 전에 이미 우리의 무의식은 먼저 반응하고, 그 사람에게 알 수 없는 이끌림을 느끼게 만듭니다."
    s "이것이 바로 무의식의 강력한 힘입니다."
    scene 01lecture_03-06 with dissolve
    d "그 무언가가… 심리적 상처 같은 건가요?"
    d "과거에 겪은 아픔이나 외로움이 지금의 감정에 영향을 주는 걸까요?"
    scene 01lecture_03-04 with dissolve
    s "정확해요. 어릴 때 느꼈던 결핍이나 충족되지 않은 감정이 어른이 되어서도 사람을 끌어당기죠."
    scene 01lecture_03-07 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_03-08 at hand_camera with Dissolve(0.8)
    s "예를 들어, 늘 무시당했던 아이는 자신을 인정해주는 사람에게 이상하게도 더 깊이 끌리는 경향이 있어요."
    s "그걸 프로이트는 반복 강박이라고 불렀고요."
    scene 01lecture_04 with dissolve
    s "무의식 속에 남은 해결되지 못한 감정이 반복적으로 유사한 상황을 끌어당기는 거예요."
    scene 01lecture_04-01 with dissolve
    pause 
    scene 01lecture_04-02 with dissolve
    scene 01lecture_04-03 with dissolve
    pause
    scene 01lecture_04-04 with dissolve
    s "결국 우리는 치유되지 않은 감정을 통해 또 다른 관계를 만들어내곤 하죠."
    scene 01lecture_04-05 at hand_camera with Dissolve(0.8)
    s "그래서, 이번 방학에 한 가지 숙제를 드릴게요."
    s "학문적인 이론보다도 중요한 건 실제 삶에 어떻게 적용되느냐니까요."
    s "가까운 사람에게 물어보세요. '나라는 사람은 당신에게 어떤 존재인가요?' 라고요."
    scene 01lecture_04-06 at hand_camera with Dissolve(0.8)
    s "연인, 가족, 친구… 누구라도 괜찮아요."
    s "그 질문 하나가, 그 사람과 여러분의 관계를 바꿀 수도 있으니까요."
    scene 01lecture_04-07 at hand_camera with Dissolve(0.8)
    s "물론 질문을 던질 때, 상대가 불필요하게 당황하거나 불편함을 느끼지 않도록 때와 상황을 잘 맞춰야겠죠?"
    s "타인의 감정이라는 건 아주 예민하고 섬세한 거니까요. 깨지기 쉬운 도자기를 다루듯이 조심스럽게 다루는 법도 함께 배워야 해요. 무턱대고 들이대는 건 미숙한 거죠."
    scene 01lecture_03-07 at hand_camera with Dissolve(0.8)
    s "이 숙제는 관계를 배우는 동시에 여러분의 성숙도를 시험하는 기회가 될 거예요."
    scene 01lecture_05 with dissolve
    pause
    scene 01lecture_06 with dissolve
    j "맙소사"
    j "천지신명이시여"
    j "이거 몰래카메라임?"
    scene 01lecture_03-05 with dissolve
    pause
    scene 01lecture_08 with dissolve
    d "뭐가?"
    scene 01lecture_09 with dissolve
    pause
    scene 01lecture_08 with dissolve
    pause
    scene 01lecture_03-06 with dissolve
    pause
    scene 01lecture_10 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_11 at hand_camera_zoom with vpunch
    pause
    scene 01lecture_12 at hand_camera with Dissolve(0.8)
    s "잘 따라오고 있죠 여러분들?"
    scene 01lecture_13 with dissolve
    pause
    scene 01lecture_14 with dissolve
    pause 
    scene 01lecture_06 with dissolve
    j "젠장, 달려가서 쓰다듬고 싶다"
    j "그럴수만 있다면 죽을수도 있어"
    scene 01lecture_13-01 with dissolve
    d "야, 오늘 부터 방학인데 살아있어야지"
    scene 01lecture_14-01 with dissolve
    play voice_f "audio/voices/Fcough01.mp3"
    scene 01lecture_14-02 with dissolve
    s "젠장"
    scene 01lecture_14-03 at hand_camera with dissolve
    pause
    scene 01lecture_14-04 with dissolve
    pause
    scene 01lecture_14-05 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_11 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_05 at zoom_in_center with dissolve
    pause
    scene 01lecture_11-01 with dissolve
    pause
    scene 01lecture_14-07 at hand_camera
    s "(............)"
    scene 01lecture_14-08 at hand_camera_zoominout with vpunch
    pause
    scene 01lecture_10-01 with dissolve
    pause
    scene 01lecture_10-02 with dissolve
    pause
    scene 01lecture_10-03 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_10-04 with Dissolve(1.0)
    s "자, 심리학은 관계를 통제하는 수단이 아닙니다."
    s "누군가를 조종하려는 욕망이 아니라, 서로의 마음을 조심스럽게 어루만지는 기술이에요."
    s "그 마음에 상처가 있든, 기대가 있든… 그것을 이해하려는 첫걸음이죠."
    scene 01lecture_03-08 with dissolve
    s "그럼 오늘 수업은 여기까지."
    s "방학 잘 보내고, 스스로의 배움의 진척도를 메일로 공유해줘도 좋아요."
    s "여러분의 이야기를 듣는 건 언제나 제게도 큰 배움이 되거든요."
    if in_replay:
        return
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    jump v01_afterschool

label v01_afterschool:
    if not in_replay:
        $ persistent.unlock_v01_afterschool = True
    play sound "audio/ambi/crowdnoise.mp3"
    scene 01lecture_16 with dissolve
    pause
    scene 01lecture_17 with Dissolve(2.0)
    n "마침내 학기의 마지막 수업이 끝났다."
    n "소피아는 생각에 잠긴 모습으로 서류를 정리 중이다."
    scene 01lecture_18 at hand_camera with dissolve
    n "그녀는 자신의 뒤로 누군가 다가오는 인기척을 느꼈다."
    n "그녀의 치마 길이가 그녀를 약간 신경쓰게 만들었다."
    scene 01lecture_18-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_19 at hand_camera with Dissolve(0.8)
    pause
    $ renpy.music.stop(channel="sound", fadeout=1)
    scene 01lecture_19-01 with dissolve
    n "서류를 정리하는 그녀의 손이 더 빨라졌다."
    scene 01lecture_20 with dissolve
    s ".................."
    scene 01lecture_21 with dissolve
    pause
    scene 01lecture_22 at hand_camera with Dissolve(0.8)
    n "그녀는 그들이 [d_name]과 Jason임을 알아차렸지만 약간 무례하다는 느낌에 살갑게 인사하지 않았다."
    scene 01lecture_23 at hand_camera with Dissolve(0.8)
    j "교수님, 오늘 명강의 였습니다."
    j "진짜 뭔가… 심장이 두근거렸어요."
    j "말 그대로 심리학적 각성의 순간이었달까요?"
    scene 01lecture_24 with dissolve
    pause
    scene 01lecture_24-01 with dissolve
    s "제이슨, 오늘따라 유독 열정적인 찬사네요. 강의실 들어올 때만 해도 꾸벅꾸벅 졸던 학생은 누구였더라?"
    s "강의가 끝날 때쯤에만 그렇게 눈빛이 번쩍이던데... 설마 제 큰 엉덩이가 제이슨 학생의 잠을 완전히 깨워버렸나요?"
    s "수업에 집중하는 대신 다른 쪽에 더 집중했던 건 아닌지 모르겠네요."
    dj "................"
    scene 01lecture_24-02 with dissolve
    pause
    scene 01lecture_24-01 with dissolve
    s "시험 성적이 걱정되지 않는다고 하면 거짓말이겠죠?"
    s "하지만 오늘만큼은, 여러분의 솔직한 반응이 더 인상 깊네요."
    scene 01lecture_25 with dissolve
    j "아니에요 교수님"
    j "전 기숙사로 돌아가면 늘 교수님의 강의 장면을 늘 되새겨 봅니다."
    j "특히 교수님의 카리스마 넘치는 말투, 미묘한 표정 변화, 그리고 우아한 손짓까지 전부요. 정말 대단하다고 생각하고 있습니다!"
    scene 01lecture_26 with dissolve
    dj "................"
    scene 01lecture_26-01 with dissolve
    s "손짓까지... 그렇게나 자세히? 제이슨 학생, 혹시 영상을 찍어서 슬로우 모션으로 돌려보는 건 아니겠죠?"
    scene 01lecture_26-02 with dissolve
    d "아뇨, 제이슨이 하는 말이 무슨 뜻인지 알 것 같아요, 교수님."
    d "특히 오늘처럼 펜을 집으시거나, 칠판에 글을 쓰실 때의 움직임은... 그야말로 강렬했달까."
    d "제 안의 어떤 심리적 방어막을 뚫고 들어오는 충격이었습니다. 정말이지 감정의 파도가 확 밀려들었어요. 심장 박동수도 갑자기 높아지는 걸 느꼈습니다."
    scene 01lecture_26-03 with dissolve
    n "그녀는 바운더리를 미묘하게 침범하는 그들을 어떻게 대할지 순간 고민했지만 맞장구 치려는 듯 말했다."
    s "흐음... 그래요? 그런 미묘한 부분까지 알아챌 줄은 몰랐네요."
    s "그럼 굳이 '손짓'만 그렇게 열심히 되새기는 건가요? 혹시 다른 부위는... 별로였나요? 되새겨보고 싶은 마음이 안 들었나요?"
    s "더 인상 깊었던 곳은 없었나요?"
    scene 01lecture_26-04 at hand_camera with dissolve
    n "소피아의 전혀 예상치 못한 반응에 그들은 말문이 막혔다."
    dj "................"
    scene 01lecture_28 with dissolve
    s "하하 농담이에요."
    s "여러분들을 당황하게 해서 미안하네요."
    scene 01lecture_28-01 with dissolve
    s "[d_name]은 이번 방학때 뭐할거니? 계획이라도?"
    scene 01lecture_29 with dissolve
    pause
    scene 01lecture_29-01 at hand_camera with dissolve
    pause
    scene 01lecture_30 with dissolve
    d "아 저는 고향에 갔다 올거에요."
    d "만날 사람들도 있고.... 그냥 고향에 가고 싶어서요"
    scene 01lecture_31 with dissolve
    s "오, 정말 괜찮은 생각이에요! 아주 좋은데요."
    s "학기 중 쌓인 스트레스도 풀고, 재충전의 시간을 가지는 것도 중요하죠."
    s "여행도 하고, 새로운 경험도 많이 하고, 무엇보다 많은 사람들을 만나봐요."
    scene 01lecture_28 with dissolve
    s "다양한 사람들을 만나고 그들과 솔직한 대화를 나누면서, 의외로 자기 자신도 몰랐던 새로운 모습들을 발견하게 될 거예요."
    s "인간관계 속에서 우리의 마음은 더 풍성해지는 법이니까요."
    scene 01lecture_30 with dissolve
    d "네, 고향에 가면 찾고 만날 사람들이 있어요."
    d "그리고 이 녀석과 좀 떨어져 있고 싶어요 하하하"
    scene 01lecture_28 with dissolve
    s "하하하! 그 마음 충분히 이해가네요."
    s "그래요, 방학 동안 궁금한 점이 생기면 언제든 저에게 이메일을 보내세요."
    s "연애 상담도 괜찮고, 심지어 썸 타는 사람에게 어떤 질문을 던져야 할지 고민된다면 그것도 좋아요."
    scene 01lecture_28-02 with dissolve
    d "정말요? 교수님께서 제 연애사를 듣기엔 너무 버거우실 텐데요, 하하하."
    d "아마 제 복잡한 연애 이야기에 교수님도 심리학자로서의 평정심을 잃으실 수도 있을 겁니다!"
    scene 01lecture_32 with dissolve
    n "그녀는 그들이 나이에 비해 경험이 많은 남자들임을 어필하고 있다는 것을 느꼈다."
    n "그리고 그들 역시 그녀가 평생을 봐온 수많은 신입생들과 다르지 않다고 생각했다."
    scene 01lecture_32-01 with dissolve
    s "흐음... 걱정 마세요, [d_name]."
    s "저는 이 바닥에서 산전수전 공중전까지 다 겪은 사람이에요. 웬만한 이야기에 눈 하나 깜짝하지 않죠. 뭐가 버겁겠어요?"
    s "오히려 여러분의 풋풋하고 치기 어린 연애사에 조언을 해주는 건 저에게도 아주 즐거운 일이 될 겁니다. 재밌기만 할 거예요. 비밀은 엄수할 테니 안심하고 연락해요."
    scene 01lecture_33 with dissolve
    s "그래 얘들아, 또 보자."
    s "못 보는 동안 날 열심히 되새겨 봐"
    scene 01lecture_34 with dissolve
    pause
    scene 01lecture_34-01 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_34-02 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_35 with dissolve
    pause
    scene 01lecture_35-01 with Dissolve(2.0)
    n "그들은 멀어지는 소피아를 바라보며 서있을 수 밖에 없었다."
    n "그들의 눈에 소피아는 어른스럽고, 여유있으며 남자를 어떻게 상대해야 하는지 통달한 여성이었다."
    j "젠장, 역시 심리학 교수는 당해낼 수가 없어. 멘탈이 산산조각 난 것 같아."
    d "................"
    d "제이슨, 어쩌면 우리가 교수님 발톱의 때만큼도 못 미치는 풋내기일 수도 있어... 그냥 한 수 배우는 거라고 생각해."
    d "지금 이 순간도, 교수님은 우리의 무의식 속에 얼마나 깊이 침투하셨을지 감히 상상도 안 가는군."
    if in_replay:
        return
    jump v01_restroom

label v01_restroom:
    if not in_replay:
        $ persistent.unlock_v01_restroom = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    play sound "audio/ambi/walkheels02.mp3"
    scene 01lecture_36 with dissolve
    pause
    scene 01lecture_36-01 with dissolve
    pause
    scene 01lecture_36-02 with dissolve
    stop sound
    pause
    scene 01lecture_37 with Dissolve(2.0)
    s "(thank god. 드디어 학기가 끝났네.)"
    s "(그래도 신입생들이라 눈빛들이 살아있어서 나쁘진 않았어.)"
    scene 01lecture_38 with dissolve
    s "(항상 그 마지막 몇 분이 제일 피곤해.)"
    scene 01lecture_39 at hand_camera with Dissolve(2.0)
    s "(애들은 늘 진지하게 듣다가, 수업이 끝나갈 무렵엔 눈빛이 바뀐다니까.)"
    s "(부럽다.....하루종일 또렷할 수 있는 그 체력이...)"
    scene 01lecture_39-02 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_39-01 at hand_camera with Dissolve(2.0)
    s "(그 녀석들.)"
    s "(가끔은 너무 뻔해서 웃기지도 않아.)"
    s "(어찌나 티를 내는지, 숨기려는 노력조차 안 해. 내가 눈치채지 못할 거라고 생각하는 건가?)"
    scene 01lecture_40 at hand_camera with Dissolve(0.8)
    s "(감탄인지, 추파인지, 아님 그저 어린 마음에 하는 치기 어린 행동들인지...)"
    s "(참 신입생들 하나 같이들 똑같아.)"
    scene 01lecture_41 at hand_camera with Dissolve(0.8)
    s "(크크, 아직 어린노무 쉐키들이 뭘 알겠어? 이 교수님은 웬만한 남자들 심리쯤이야 꿰뚫고 있는데.)"
    scene 01lecture_41-01 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/pee.mp3"
    pause
    scene 01lecture_41-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene 01lecture_42 with dissolve
    pause
    scene 01lecture_43 at hand_camera with dissolve
    s "(그래도... 이렇게 예상 가능한 반응들이라니, 은근히 재미는 있어. 애들이 날 어떻게 보고 있는지, 무슨 생각을 하는지 너무나 투명하게 보이니까.)"
    s "(연상의 여인이라...)"
    s "(완전 고전이잖아.)"
    scene 01lecture_44 with Dissolve(2.0)
    $ renpy.music.stop(channel="sound", fadeout=1)
    pause
    scene 01lecture_40 at hand_camera with dissolve
    play sound "audio/ambi/toilet.mp3"
    pause
    scene 01lecture_39 with Dissolve(2.0)
    s "(그래도 어린 남자들이 연상을 갈망하게 되는 이유를 완벽히 안다고는 못하겠어.)"
    s "(녀석들이 나를 '여성'으로 보는 건가? 아니면 그저 내 '몸'을 보는 걸까? 아니면... 둘 다?)"
    s "(오이디푸스 콤플렉스?)"
    scene 01lecture_44-01 at hand_camera with dissolve
    s "(.................)"
    scene 01lecture_44-02 with dissolve
    pause
    scene 01lecture_45 with Dissolve(2.0)
    pause
    scene 01lecture_46 at hand_camera with dissolve
    play voice_f "audio/voices/fsigh01.mp3"
    s "(하아... 거울아 거울아, 나도 이제 예전 같지 않구나. 아무리 관리해도 세월의 흔적은 숨길 수가 없네.)"
    s "(솔직히, 너도 나이 드는 게 보인다. 소피아. 애써 외면하지 마.)"
    s "(그래도 매력이 어디 가는건 아니잖아?)"
    scene 01lecture_47 with dissolve
    pause
    scene 01lecture_48 with dissolve
    s "(제이슨 그 녀석...집에 가면 늘 교수님 강의 장면을 되새긴다고? 하하. 퍽이나.)"
    s "(그래 열심히 되새겨 봐.)"
    s "(어린 녀석이 엄마 같은 나에게 그런 끈적한 멘트나 날리고 말이야.)"
    scene 01lecture_49 at hand_camera with Dissolve(0.8)
    s "웃긴 녀석들"
    s "(감히 교수님에게 추파를 던지다니)"
    scene 01lecture_49-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_49-01-01 with Dissolve(1.0)
    n "그녀는 자신이 약간의 긴장감을 느끼고 있다는 것이 의아했다."
    scene 01lecture_49-01-02 with Dissolve(1.0)
    n "그리고 거울 앞에서 자신의 가슴을 오픈하며 약간의 해방감과 함께 긴장감이 해소되는 것을 느꼈다."
    s "(그 [d_name]란 녀석... 걔는 좀 다른거 같아.)"
    s "(유독 눈빛이 깊고... 음... 뭔가 숨기는 듯한 표정을 지을 때가 있던데.)"
    s "(뭔가 알 수 없는 녀석이랄까.)"
    s "(제이슨 보다 나는 조금 더 고상하다 뭐 이런걸 알리고 싶은건가?)"
    scene 01lecture_49-02 at hand_camera with dissolve
    s ".........."
    scene 01lecture_49-03 with dissolve
    pause
    scene 01lecture_49-04 at hand_camera with Dissolve(0.8)
    s "............."
    s "(애들이나 노인들이나 남자들이란)"
    scene 01lecture_49-05 at hand_camera with Dissolve(0.8)
    s "(다 똑같아..)"
    s "([d_name]너도 마찬가지다.)"
    s "(고상한척 하지마.)"
    if in_replay:
        return
    jump v01_lecture02

label v01_lecture02:
    play music "audio/bgm/chill.mp3"
    scene 01lecture_49-06 with Dissolve(2.0)
    pause
    if not in_replay:
        $ bio_rebecca = True
    scene 01lecture_49-07 at hand_camera with Dissolve(1.3)
    pause
    scene 01lecture_49-08 at hand_camera with Dissolve(1.3)
    pause
    scene 01lecture_49-09 at hand_camera with Dissolve(1.3)
    pause
    scene 01lecture_49-10 at hand_camera with Dissolve(1.3)
    pause
    jump v01_dormroom

label v01_dormroom:
    if not in_replay:
        $ persistent.unlock_v01_dormroom = True
    scene dorm01 with Dissolve(2.0)
    pause
    scene dorm02 with Dissolve(2.0)
    pause
    scene 01lecture_50 with Dissolve(2.0)
    pause
    scene 01lecture_50-01 with dissolve
    pause
    scene 01lecture_50-02 with dissolve
    pause
    scene 01lecture_51 at hand_camera with dissolve
    pause (2.0)
    d "아 이대로 내년까지 자고싶다."
    d "학기 끝난거 실화냐?"
    d "난 학기가 끝나면 여기저기서 떠들썩 하게 떠들고 난리 날 줄 알았어."
    scene 01lecture_52 with dissolve
    j "막상 종강 하니까 허무하지 않아?"
    j "그래도 이제부터 자유라 이거야 ㅎㅎ"
    j "하루 종일 게임하고 여행도 갔다 와야지."
    j "먹고 자고, 먹고 자고, 게임하고 자고, 게임하고 자고"
    j "앗 잠깐!"
    scene 01lecture_53 with dissolve
    j "이러면 소피아 교수님을 몇 달 동안 못 보잖아?!"
    j "젠장, 나의 소피아를 대체 얼마나 오래 못보는거야!"
    j "아직 그녀를 완벽히 상상할 수 있을 정도로 오래 감상하지 못했다고!"
    j "그녀가 칠판에 글 쓸 때마다… 그 곡선이..."
    scene 01lecture_54 with dissolve
    d "ㅋㅋㅋ 이 봐"
    d "나도 같은 생각하고 있었다고"
    d "내가 지금 까지 살면서 많은 여성들 봤지만 sophia처럼 핫한 milf는 처음이야."
    d "나를 잠깐 쳐다봐도 눈으로 나를 발가벗기는 기분이랄까?"
    scene 01lecture_54-01 with dissolve
    d "젠장, 그녀는 이 지역의 보물이자 이 학교의 보물이야"
    d "우리 시대의 참 어머니..."
    d "하지만 그녀의 몸매는 어머니가 아니라 참 누님이지."
    scene 01lecture_55 with dissolve
    j "어머니? 누님? 웃기는 소리하지마."
    j "그녀는 내게 아름다운 한 암컷이야.."
    j "나이 엿먹으라고 해."
    j "아... 나는 그녀와 결혼할거야."
    j "소피아와 아름 다운 신혼여행..... 그리고 뜨거운 첫날 밤..."
    scene 01lecture_54 with dissolve
    d "ㅋㅋㅋ 뭐라고?"
    d "아마 그녀의 자녀들이 우리 보다 몇살은 더 많을걸"
    d "그리고 우리같은 이제 막 대학교에 들어온 학생들이 남자로 보이곘냐?"
    d "아쉽지만 조금더 현실적인 여성을 찾아봐."
    d "신입생 중에도 핫한 여자들 꽤 보이더만."
    scene 01lecture_54-02 with dissolve
    j "쳇, 어린애 같은 신입생들 중에서 찾아보라고?"
    j "신경안써."
    j "사랑엔 국경도, 나이도 없는거야."
    j "벌거벗으면 결국 한 쌍의 수컷과 암컷일 뿐이라고."
    scene 01lecture_55 with dissolve
    j "그녀의 손이 니 몸을 쓰다듬는 상상을 해봤어?"
    j "그건 정말 만랩 힐러의 힐을 듬뿍 받는 성기사가 된 기분일거야 ㅋㅋㅋㅋ"
    scene 01lecture_54 with dissolve
    d "그녀의 손이 닿는 순간 레벨업이냐?"
    d "ㅋㅋㅋ 그럼 너의 경쟁자에 내 이름도 올려라"
    d "용감한 기사가 매력적인 milf를 차지하는 법이지."
    scene 01lecture_56 with dissolve
    j "지금 뭐라고 말했지?"
    j "니가 나의 번식을 방해하는 몬스터몹이라고?"
    scene 01lecture_51 with dissolve
    d "그녀를 차지하려면 나를 죽여야 할거야."
    d "그리고 너 같은 약골 따위가 날 이길순 없지!"
    scene 01lecture_57 with dissolve
    j "헤이 내가 널 죽여야 한다고?"
    j "멍청아, 그냥 너랑 내가 함께 그녀와 결혼하면 되잖아."
    j "괜찮은데? 낮에는 같이 사냥하고 밤에는 같이 뜨거운 밤을 보내는거야."
    scene 01lecture_58 with dissolve
    d "맨..."
    d "너 가끔 미친사람 같아 보이는거 알지?"
    scene 01lecture_58-01 with dissolve
    j "너는 망할 위선자야 [d_name] "
    j "너의 머릿속 상상들을 실행에 옮기면 아마 몇 번의 종신형이 나올걸? ㅋㅋㅋ"
    j "솔찍히 말해봐."
    j "우리 둘이 소피아와 결혼한다 했을때 쓰리섬 상상했잖아!"
    scene 01lecture_58 with dissolve
    d "상상은 자유야 제이슨."
    d "그리고 신께서는 인간에게 이성을 주셨지."
    d "난 이성적인 판단을 하는 사람이라고."
    scene 01lecture_59 with dissolve
    d "아 그런데 그 엉덩이는 정말이지.."
    d "다른 차원의 엉덩이야..."
    show 01lecture_60 at hand_camera with Dissolve(0.8)
    d "젠장.."
    d "완벽한 엉덩이야 ㅋㅋ"
    scene 01lecture_61 with dissolve
    j "난 밀프들만 있는 세상에서 살고 싶어"
    j "밀프하임에서"
    j "난 경험 있고, 여유 있고, 농염한 그런 여자가 좋아."
    j "젠장 그런 경험이 풍부한 여성에게 선택 받고 싶다고."
    scene 01lecture_62 with dissolve
    d "ㅋㅋ 열심히 상상의 나래를 펼치고 있어라"
    d "난 이 블랙홀과 같은 방을 떠날거야."
    scene 01lecture_63 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_64 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_64-01 with dissolve
    j "바로 고향에 갈거야?"
    j "오늘 종강 파티도 있는데 안갈꺼야?"
    scene 01lecture_64 with dissolve
    d "응, 기숙사에 하루 더 있다간 돌아버릴거 같아."
    d "고향에 가고 싶기도 하고 말이지."
    d "그리고 하숙할 집 랜드레이디에게 오늘 오후에 간다고 다 말 해놨어."
    scene 01lecture_64-02 with dissolve
    j "그래, 이 학교의 여자들은 나 하나 감당하기도 버거울거야."
    j "내가 그럼 너의 몫까지 놀아주마."
    scene 01lecture_64-03 at hand_camera with dissolve
    d "그래서 내가 빠져주는거지 ㅋㅋ"
    d "넌 집에 안가?"
    scene 01lecture_64-04 with dissolve
    j "부모님이 이번 방학은 집에 오지말고 학교에서 공부하면서 지내래."
    j "몇 달간 여행 다닌다고."
    j "이거 준비도 없이 성인 취급하는게 낯서네."
    scene 01lecture_64-02 with dissolve
    j "뭐 어차피, 혼자 있는게 익숙하긴 해."
    j "그 대신 소피아 교수님 사진이나 보며 지내야지."
    j "내가 소중히 모아온 그녀의 사진 컬렉션이 있다고!"
    scene 01lecture_65 with dissolve
    d "뭐? 소피아 사진이 있다고?"
    d "무슨 사진? 소셜 미디어?"
    d "이 자식아 얼른 공유 안하냐?"
    scene 01lecture_65-01 with dissolve
    j "하... 나 부모님 한테 버려진거냐?"
    scene 01lecture_65-02 with dissolve
    d "이 새끼 말 돌리는거 봐라 ㅋㅋㅋㅋ"
    scene 01lecture_56 with dissolve
    j "그런 사진 같은게 있겠냐? 구라지였지 임마"
    j "매일 소설미디어를 찾아보는데도 교수님 사진은 어디에도 없어."
    j "교수님과 닮은 모델을 찾긴 했는데 그 사람은 아니야."
    scene 01lecture_66 at hand_camera with dissolve
    j "하...성인도 누군가의 보살팜이 필요하다고"
    j "누가 나좀 보살펴줘!"
    scene 01lecture_66-01 with dissolve
    d "......................."
    dj "소피아 같은 여성의 보살핌!"
    scene 01lecture_67 with Dissolve(2.0)
    pause
    if in_replay:
        return

    jump v01_busdeparture


label v01_busdeparture:
    if not in_replay:
        $ persistent.unlock_v01_busdeparture = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal.mp3"
    play sound "audio/ambi/city02.mp3"
    scene 01bus_n01 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_n02 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_68 at hand_camera with Dissolve(0.8)
    d "(드디어 출발이군. 기숙사 생활도 이제 방학 동안은 안녕이다.)"
    d "(기숙사를 떠나는건 좋은데 뭐랄가.....)"
    d "(제이슨이랑 같이 못 노는게 좀 아쉬워.)"
    d "(그리고 제이슨 말대로 소피아 교수님을 못봐서 좀 안타까운걸?)"
    scene 01bus_69 with dissolve
    d "주소가 뭐였더라? 아!"
    d "412 Rosebridge Avenue, Milfheim hills"
    scene 01bus_70 with dissolve
    d "하여튼,여기가 내가 지낼 집이란 말이지."
    d "똑똑, 거긴 누가 살고 계신가요?"
    d "하숙생을 찾는 사람들이 본인들 사진도 좀 공개하면 좋을텐데 누군지 궁금하네."
    scene 01bus_70-01 with dissolve
    d "................."
    scene 01bus_70-02 at hand_camera with dissolve
    pause
    play sound "audio/ambi/walkheels01.mp3"
    scene 01bus_71 at hand_camera with Dissolve(0.8)
    n "그가 고개를 들자 반대편에서 한 여성이 빠른 걸음으로 걸어가고 있었다."
    n "그녀는 어떤한 짐도 들지 않은 모습이었다."
    scene 01bus_71-01 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene 01bus_70-01 with dissolve
    n "[d_name]은 그녀 역시 자신을 바라보는 것을 느꼈다."
    d "(음...어디서 신나게 논 옷차림 같은데.)"
    d "(얼굴이 좀 상기된거 같기도 하고..)"
    d "(밤새 어디서 파티라도 즐겼나?..)"
    d "(밤새 파티를 즐기기엔 연령이 좀 있어보이는데..)"
    scene 01bus_72 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_72-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_73 with dissolve
    d "(헤이 걸)"
    d "(오 나이는 있어보이는데 꽤나 매력적인 여자네)"
    d "(...................)"
    play sound "audio/ambi/busarrival.mp3"
    scene 01bus_74 with Dissolve (1.5)
    d "왔구나."
    scene 01bus_75 with Dissolve (1.5)
    pause
    scene 01bus_76 with Dissolve (1.5)
    pause
    scene 01bus_77 with Dissolve (1.5)
    pause
    scene 01bus_78 with Dissolve (1.5)
    n "[d_name]은 걸어가던 여자를 다시 바라보았다."
    d "(그 여자 걸어가고 있나?)"
    scene 01bus_79 at hand_camera
    d "(맙소사)"
    d "(뭐하는거야 저 여자?!)"
    scene 01bus_80 with dissolve
    play music "audio/bgm/erotic02.mp3"
    pause
    scene 01bus_81 at hand_camera_zoominout with dissolve
    pause
    scene 01bus_82 at hand_camera with Dissolve(0.8)
    n "그녀는 드레스를 벗어 자신의 젖을 훤히 드러내고 있었다."
    scene 01bus_83 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_83-01 at hand_camera with Dissolve(2.0)
    pause
    scene 01bus_79 with dissolve
    d "(오늘 지구의 종말인가?....)?"
    scene 01bus_83-02 with dissolve
    d "(holy shit)"
    play voice_f "audio/sex/milfmoanlong.mp3" loop
    scene 01bus_83-03 at hand_camera with dissolve
    pause
    scene 01bus_83-04 at hand_camera with dissolve
    pause
    scene 01bus_83-05 at hand_camera with dissolve
    n "그녀는 그녀의 젖꼭지를 잡고 들어올리며 얕은 신음을 내었다."
    scene 01bus_83-06 at hand_camera with dissolve
    pause
    scene 01bus_83-07 at hand_camera with dissolve
    d "(이거 무슨 상황이야..)"
    d "(저기 아가씨. 그러다가 경찰에 잡혀가요!)"
    scene 01bus_79 with dissolve
    stop voice_f
    n "[d_name]은 순간 얼어붙었다."
    n "순간 스쳐간 생각은 Jason에게 이 상황을 어떻게든 알려주고 싶다는 것이었다."
    d "(............)?"
    menu:
        n "What should I do?"
        "Take out the camera and film it.":
            if not in_replay:
                $ add_point("lust_lena", 1, "lust_lena")
            jump v01_buscamera
        "Just watch it and be satisfied.":

            n "[d_name]은 순간 갈등했지만 보는것으로 만족하기로 결정하였다."
            scene 01bus_79 with dissolve
            pause
            scene 01bus_79-01 with dissolve
            d "와 진짜 말세로군."
            d "ㅋㅋ 오늘 재미있는 일이 많네"
            scene 01bus_78 at hand_camera with Dissolve(0.8)
            pause
            jump v01_lenaphone

label v01_buscamera:
    scene 01bus_84 with dissolve
    d "이거 제이슨에게 알려줘야지 ㅋㅋㅋ"
    scene 01bus_85 with dissolve
    d "빨리..."
    scene 01bus_86 with dissolve
    pause
    scene 01bus_83-01 with flash
    play sound "audio/ambi/camera.mp3"
    scene 01bus_83-01
    pause


    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/03_Thumb.jpg",
            "phone": "images/phone/shots/03.jpg",
            "description": "버스 안에서 찍은 사진"
        })

    scene 01bus_87 with dissolve
    n "그녀는 [d_name]이 폰으로 자신의 모습을 찍는 것을 보고 약간 놀란 반응이었다."
    scene 01bus_88 with dissolve
    scene 01bus_89 with dissolve
    scene 01bus_88 with dissolve
    scene 01bus_89 with dissolve
    scene 01bus_88 with dissolve
    scene 01bus_89 with dissolve
    pause
    scene 01bus_89-01 at hand_camera with dissolve
    pause
    scene 01bus_89-02 with Dissolve(2.0)
    pause
    scene 01bus_90 at hand_camera with Dissolve(0.8)
    d "내가 해냈나?"
    d "제대로 찍혔을까?"
    scene 01bus_91 at hand_camera with dissolve
    d "젠장."
    d "Jason이라면 분명 깔끔하게 촬영 했을거야. 역시 나는 풋내기군.."
    scene 01bus_79-01 with dissolve
    d "Wow, what a crazy world."
    d "Haha, today’s been full of surprises."
    scene 01bus_78 at hand_camera with Dissolve(0.8)
    pause
    jump v01_lenaphone

label v01_lenaphone:
    play music "audio/bgm/normal04.mp3"
    scene 01bus_91-01 with Dissolve(2.0)
    play sound "audio/ambi/busleaving.mp3"
    pause
    scene 01bus_92 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_92-01 at hand_camera with Dissolve(0.8)
    unknown "맙소사..."
    unknown "나 방금 무슨 짓을 한거야 ㅋㅋㅋㅋㅋ"
    scene 01bus_92-02 at hand_camera with Dissolve(0.8)
    pause
    scene 01bus_92-03 at hand_camera with Dissolve(0.8)
    unknown "맙소사, 맙소사, 맙소사.."
    scene 01bus_92-04 at hand_camera with Dissolve(0.8)
    unknown "헤이"
    unknown "나 미쳤나봐 ㅋㅋ"
    unknown "나 방금 무슨 짓을 했는지 맞춰봐."
    unknown "오늘 또다른 나의 모습을 발견했어! 이건 전혀 다른 차원이야."
    scene 01bus_92-05 at hand_camera with Dissolve(0.8)
    unknown "그렇다니까 ㅋㅋ"
    unknown "그 녀석에게 보여 줬다고 ㅋㅋ"
    unknown "이건 다른 차원의 짜릿함이었어."
    scene 01bus_92-06 at hand_camera with Dissolve(0.8)
    unknown "가슴이 무슨 대수라고."
    unknown "알아. 안다고!"
    unknown "ㅋㅋ 어쩌겠어 이게 나의 본성인걸."
    unknown "노출증"
    unknown "노출증,색정증"
    unknown "노출증,색정증,양성애"
    unknown "노출증,색정증,양성애,충동적 행동"
    unknown "와우, 나 완전 신인류이지 않아? ㅋㅋ"
    scene 01bus_92-07 at hand_camera with Dissolve(0.8)
    unknown "넌 위선자야. 나는 나 자신에게 솔직한거라고."
    unknown "그리고 별로 놀랄일도 아니잖아."
    unknown "헤이.이거 그렇게 이상한 짓도 아니라고."
    scene 01bus_92-11 at hand_camera with Dissolve(0.8)
    unknown "혹시 모르잖아. 내가 그녀석의 하루를 멋지게 만들어줬을지도."
    unknown "그래, 알아 알아. 안다고!"
    unknown "하하하. 천만에. 난 그냥 인생을 즐길 뿐이라고."
    scene 01bus_92-12 at hand_camera with Dissolve(0.8)
    unknown "그냥 솔찍히 말해 자기야. 나의 삶이 부러운거지?"
    unknown "ㅎㅎㅎ 알겠어.주말에 보자."
    unknown "만나서 마저 얘기해.곧 봐 달링. 사랑해"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/chill.mp3"
    scene 01bus_92-08 with Dissolve(2.0)
    pause
    scene 01bus_92-10 with Dissolve(2.0)
    pause 
    if in_replay:
        return
    jump v01_busarrival


label v01_busarrival:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Few hours later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene 01bus_93 with Dissolve(1.5)
    pause
    scene 01bus_93-01 with Dissolve(1.5)
    pause
    scene 01bus_93-02 with Dissolve(1.5)
    pause
    play sound "audio/ambi/busarrival.mp3" loop
    scene 01bus_93-03 with Dissolve(1.5)
    pause
    scene 01bus_94 with Dissolve(1.50)
    pause
    scene 01bus_95 with Dissolve(1.5)
    pause
    scene 01bus_96 with Dissolve(1.5)
    pause 1.5
    play sound "audio/ambi/busleaving.mp3"
    scene 01bus_97 at hand_camera with dissolve
    n "그는 해질녘 마을에서 멀어지는 버스를 한동안 바라보았다."
    n "그리고 이내 익숙한 풍경들이 눈에 들어왔고 약간은 두근거리는 감정을 느꼈다."
    scene 01bus_98 with dissolve
    pause
    scene 01bus_99 at hand_camera with Dissolve(0.8)
    d "고향에 온걸 환영한다. [d_name]."
    d "1년만인가?"
    d "역시 고향의 공기를 마시니 맘이 편안해 지는거 같아."
    d "Amanda도 빨리 보고싶어."
    scene 01bus_100 with dissolve
    pause
    scene 01bus_101 with dissolve
    d "택시!"
    scene 01bus_102 with dissolve
    pause
    scene 01bus_103 with dissolve
    pause
    scene 01bus_104 with dissolve
    play sound "audio/ambi/carleaving.mp3"
    pause
    scene 01bus_105 with dissolve
    pause
    scene 01bus_106 with dissolve
    pause
    jump v01_helenhouse


label v01_helenhouse:
    if not in_replay:
        $ persistent.unlock_v01_helenhouse = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    scene 01hhouse_106-01 with Dissolve(1.0)
    pause
    scene 01hhouse_106-01-01 with Dissolve(1.0)
    play sound "audio/ambi/cararrival.mp3"
    pause
    scene 01hhouse_106-01-02 with Dissolve(1.0)
    pause
    scene 01hhouse_106-03 with Dissolve(1.0)
    stop sound
    pause
    scene 01hhouse_107 with Dissolve(1.0)
    pause
    scene 01hhouse_107-01 at hand_camera with Dissolve(0.8)
    pause 1.5
    scene 01hhouse_108 at hand_camera with Dissolve(0.8)
    n "그는 낯선 풍경을 뒤로하고 자신이 묵을 집을 찾아 두리번 거렸다."
    n "그리고 이내 자신이 어플에서 봤던 집을 찾을 수 있었다."
    scene 01hhouse_109 at hand_camera with Dissolve(0.8)
    d "이 집인가 보다."
    d "맞나?"
    d "아 사진에서 본 집 맞는거 같다."
    scene 01hhouse_110 with Dissolve(1.0)
    d "집 나이스한데?"
    d "이 동네에선 제일 세련 된 집인거 같아."
    d "내가 지낼 방은 2층일까?"
    scene 01hhouse_111 with Dissolve(1.0)
    pause
    scene 01hhouse_112 with Dissolve(1.0)
    d "(두근두근 하는걸)"
    scene 01hhouse_113 at hand_camera with Dissolve(0.8)
    n "모든 시작이 그렇듯 긴장감과 호기심이 그를 휘감았다."
    n "그리고 지금 이 발걸음이 평화로운 마을에 태풍을 몰고오게 될 것을 아무도 예상하지 못했다."
    scene 01hhouse_114 with dissolve
    pause
    scene 01hhouse_115 with dissolve
    d "좋아"
    scene 01hhouse_116 with dissolve
    play sound "audio/ambi/knock.mp3"
    scene 01hhouse_117 with dissolve
    scene 01hhouse_116 with dissolve
    scene 01hhouse_117 with dissolve
    pause
    scene 01hhouse_118 with dissolve
    pause
    scene 01hhouse_116 with dissolve
    play sound "audio/ambi/knock.mp3"
    scene 01hhouse_117 with dissolve
    scene 01hhouse_116 with dissolve
    scene 01hhouse_117 with dissolve
    play sound "audio/ambi/dooropen.mp3"
    scene 01hhouse_119 with dissolve
    pause
    scene 01hhouse_120 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_michael = True
    n "문이 열리고 한 남성이 다소 굳은 표정으로 나타났다."
    mi "..........."
    mi "무슨 일입니까"
    scene 01hhouse_121 with dissolve
    d "안녕하세요. [d_name]입니다."
    d "저는 오늘부터 여기서 지내기로 한 학생입니다."
    d "landlady [h_name]과 얘기할 수 있을까요?"
    scene 01hhouse_120 with dissolve
    n "그 남성은 잠깐 [d_name]을 바로고 입을 뗏다."
    mi "아 그게 당신이오?"
    mi "..................."
    mi "좀 일찍 도착한거 아닌가?"
    h "안녕하세요. [d_name]."
    scene 01hhouse_122 at hand_camera with Dissolve(0.8)
    h "생각보다 일찍 도착했네요."
    n "남성의 말을 끊고 여성이 나타나 말했다."
    n "[d_name]은 자신과 통화했던 여성임을 알차리고 안도감을 느꼈다."
    scene 01hhouse_122-01 at hand_camera with Dissolve(0.8)
    h "오느라 고생했어요."
    h "어서 들어와요."
    scene 01hhouse_123 with dissolve
    h "어서 가 마이클."
    h "오늘 얘기는 끝난거 아냐."
    h "나중에 마저 얘기하자."


    if not in_replay:
        $ bio_helen = True
    scene 01hhouse_124 with dissolve
    mi "잘 있어 [h_name]."
    scene 01hhouse_125 with dissolve
    h "어서 가라니까."
    scene 01hhouse_126 with dissolve
    pause
    scene 01hhouse_126-01 with dissolve
    pause
    scene 01hhouse_127 with dissolve
    pause
    scene 01hhouse_128 at hand_camera with Dissolve(0.8)
    n "[d_name]은 뒤돌아보며 멀어지는 남성을 바라보았다."
    n "그는 어딘가 모르게 위압감이 드는 남성이라 생각했다."
    scene 01hhouse_129 at hand_camera with Dissolve(0.8)
    d "..........."
    d "(Landlord는 아닌거 같은데?)"
    d "(사람 되게 시니컬 하네.)"
    play sound "audio/ambi/doorclose.mp3"
    scene 01hhouse_130 with dissolve
    pause
    scene 01hhouse_131 with Dissolve(2.0)
    pause 1.5
    scene 01hhouse_132 at hand_camera with Dissolve(0.8)
    mi ".........."
    mi "하숙생이라고 응?"
    mi "내가 지켜봐 주마 애송아."
    scene 01hhouse_131 with Dissolve(2.0)
    pause
    if in_replay:
        return
    jump v01_helenhouseinside


label v01_helenhouseinside:
    if not in_replay:
        $ persistent.unlock_v01_helenhouseinside = True
    play music "audio/bgm/chill.mp3"
    scene 01hhouse_133 with dissolve
    h "이쪽으로 올라와요 [d_name]"
    scene 01hhouse_134 with dissolve
    d "넵."
    scene 01hhouse_135 with dissolve
    pause

    show 01hhouse_136 at smooth_vertical_pan
    pause   
    n "그녀는 [d_name]을 2층으로 안내하며 계단을 올라갔다."
    n "그녀의 드레스 길이는 [d_name]의 시선을 끌기에 충분할 정도로 짧고 타이트했다."
    scene 01hhouse_137 with dissolve
    n "[d_name]은 낯선 환경과 사람들을 만난 긴장감에 자신의 눈앞에 펼쳐진 관경이 더해져 혼란스러웠다."
    scene 01hhouse_138 with dissolve
    pause
    scene 01hhouse_139 with dissolve
    n "2층에 올라선 [h_name]은 돌아서며 [d_name]에게 말했다."
    h "그래서 지금 대학생이라고요?"
    h "방학을 타지역에서 보내려 한다니 꽤 독립적인 학생인가봐요."
    scene 01hhouse_140 with dissolve
    d "네 방학이라 고향에 왔어요."
    scene 01hhouse_141 with dissolve
    h "Milfheim이 고향이에요?"
    h "왜 부모님께 안가고 여기로?...."
    scene 01hhouse_142 with dissolve
    d "오 집이 아늑한게 근사하네요"
    d "밖에서 집을 보고 상상한 것과 느낌이 달라요."
    scene 01hhouse_143 with dissolve
    d "아 전 부모님이 누군지 모릅니다."
    d "어렸을 때 보육원에 맡겨져서 그 후로 시설에서 자랐어요."
    d "중고등학교 때는 위탁 가정에서 자랐구요."
    d "사실 여기가 고향이 맞는지 100프로 확신도 없어요 ㅎㅎ"
    scene 01hhouse_144 at hand_camera with dissolve
    n "그녀는 잠시 말을 멈추고 생각했다."
    scene 01hhouse_145 with dissolve
    n "[d_name]은 순간 자신의 배경을 꾸며내어 말을 해야했었나 생각했다."
    scene 01hhouse_146 at hand_camera with dissolve
    h "아 미안해요. 그런 줄도 모르고.."
    h "쉽게 꺼낼 말이 아니었는데.."
    h "내가 초면에 괜한걸 물어봤네요."
    scene 01hhouse_145 with dissolve
    d "괜찮아요."
    d "너무 오래 된 이야기라 전 별 느낌도 없어요."
    d "사실 서류에서 본 부모님 이름 말고는 아무것도 아는게 없어요."
    scene 01hhouse_146 with dissolve
    h "........."
    h "그렇군요"
    h "그런 걸 담담하게 말할 수 있는 사람은 흔치 않죠."
    scene 01hhouse_147 with dissolve
    h "이쪽으로 오세요. 집 안내해 드릴게요"
    h "이왕 같이 지낼 거 편하게 지냈으면 좋겠어요."
    h "지금 당장은 나와 [d_name]군 둘뿐이니까."
    scene 01hhouse_148 with dissolve
    n "그녀는 돌아서서 주방으로 향했다."
    scene 01hhouse_149 with dissolve
    n "[d_name]은 잠시 그녀의 뒷모습을 바라보았다."
    n "그는 그녀가 나이에 비해 좋은 몸매를 가지고 있으니 어느정도 자기관리를 하는 여성일거라 생각했다."
    scene 01hhouse_150 at hand_camera with dissolve
    h "여기는 주방이에요."
    h "요리를 해도 되고 다른 음식도 자유롭게 먹어도 돼요."
    h "냉장고 안은 정리만 잘 해주면 아무거나 손대도 괜찮아요."
    h "1층 주방이 더 크니 거기서 요리를 해도 되지만 뒷정리는 잘 해주셔야 해요."
    h "가정부가 있는데 가능한 우리가 깔끔하게 사용하는게 좋아요."
    scene 01hhouse_151 with dissolve
    d "넵"
    d "전혀 문제없습니다."
    scene 01hhouse_152 with dissolve
    h "저기는 내 방이에요."
    h "혹시 급한 일 있을 때는 두드려도 돼요. 단, 아주 급할 때만요. 후훗"
    scene 01hhouse_153 with dissolve
    pause

    menu:
        n "How should I respond?"
        "That room probably smells nice, hehehe":
            if not in_replay:
                $ add_point("sus_helen", 1, "sus_helen")
            scene 01hhouse_151 with dissolve
            n "[d_name]은 그녀에게 좋은 첫인상을 남기고 싶다는 생각에 말했다."
            d "That room probably smells nice, hehehe"
            scene 01hhouse_154 at hand_camera with dissolve
            h "Oh, you think?"
        "The ladies' room should be located inside.":


            if not in_replay:
                $ add_point("love_helen", 1, "love_helen")
                $ add_point("lust_helen", 2, "lust_helen")
            scene 01hhouse_151 with dissolve
            d "In class, I learned that a lady's room should be inside, and a gentleman's room should be near the entrance for psychological stability."
            $ renpy.music.play("audio/voices/flaugh02.mp3", channel="sound")
            scene 01hhouse_155 at hand_camera with dissolve
            h "HeHe"
            h "Do you have a good memory?"
            h "What kind of class was it that taught you something like that?"

    scene 01hhouse_155-01 with dissolve
    pause
    scene 01hhouse_156 with dissolve
    h "여기는 보다 싶이 거실이에요."
    h "저 쪽은 화장실이에요."
    h "화장실은 1층 안방에도 있으니까 급하면 거길 사용하도록 해요."
    scene 01hhouse_156-01 with dissolve
    h "오케이"
    h "이제 [d_name]군이 지낼 방을 보여드릴게요."
    scene 01hhouse_157 with Dissolve(1.5)
    n "그녀는 방안으로 들어서며 불을 켰다."
    n "[d_name]은 그녀의 어깨 너머로 방안을 바라보며 그녀를 따라 방안으로 들어섰다."
    h ".........."
    scene 01hhouse_157-01 at hand_camera with dissolve
    h "여기가 바로.."
    jump v01_mcroom01


label v01_mcroom01:
    scene 01hhouse_158 with dissolve
    pause
    scene 01hhouse_159 with dissolve
    n "하지만 그의 눈에 들어온것은 그가 지낼 방이 아니라 그녀의 엉덩이였다."
    scene 01hhouse_160 at hand_camera with Dissolve(1.5)
    n "그는 그녀가 자신에게 너무 경계심이 없다고 생각했다."
    n "한편으로는 경계심을 보여야 할 정도로 자신을 남성으로 보지않는 것일 수도 있다고도 생각했다."
    h "여기가 방학동안 네가 지낼 방이에요."
    scene 01hhouse_161 with dissolve
    h "방이 너무 썰렁해보이죠?"
    h "[d_name]의 짐들을 자유롭게 넣어도 돼요."
    h "침구류는 새로 준비해둔 거니까 편하게 사용하세요."
    h "옷장에는 여자 옷이 있는데 주인이 있어요. 치워달라고 얘기 할게요."
    scene 01hhouse_162 with dissolve
    d "방이 안락해 보여요."
    d "친구와 둘이 살던 기숙사에 비하면 최고급 스위트룸입니다.ㅎㅎ"
    scene 01hhouse_163 with dissolve
    d "이 책상과 컴퓨터는 누구거에요?"
    scene 01hhouse_164 at hand_camera with dissolve
    h "이건 내 아들 물건들이었는데 이젠 사용하지 않을거에요."
    h "공부하는 데 불편하지 않게 그대로 두었어요. 마음대로 써도 돼요."
    h "자리가 불편하면 컴퓨터를 치우고 공간을 활용해도 돼요."
    scene 01hhouse_165 with dissolve
    h "아 1층도 소개해줄게요."
    h "어서 내려가요."
    jump v01_1stfloor

label v01_1stfloor:
    scene 01hhouse_166 with Dissolve(1.5)
    pause
    scene 01hhouse_167 with dissolve
    pause
    scene 01hhouse_168 at hand_camera with dissolve
    h "여기는 내 전 남편이 썼던 공간이야."
    h "손님들이 오면 주로 여기서 시간을 보내요."
    h "하지만 나는 1층에는 잘 안내려오게 되네요."
    h "1층이 맘에 들면 여기에서 자유 시간을 보내도록 해요."
    scene 01hhouse_169 with dissolve
    h "저 쪽엔 안방이 있어요."
    h "안방에도 화장실과 샤워실이 있으니까 거기서 씻는게 편하면 그렇게 해도 돼요."
    scene 01hhouse_169-01 with dissolve
    h "여기는 당연하지만 거실이구요. 여기서 자유롭게 티비를 사용해도 괜찮아요."
    scene 01hhouse_169-01-01 with dissolve
    h "내가 소리에 예민해서 야간에 영화나 티비를 보고 싶으면 여기서 보도록 해요."
    h "................."
    scene 01hhouse_169-03 with dissolve
    h "저 문은 2층으로 올라가는 계단이 있고 계단 밑에 세탁실로 가는 문이 있어요."
    h "[d_name]이 직접 빨래를 해도 되고 빈 바구니에 빨래를 넣어놓으면 가정부가 빨래를 할거에요."
    scene 01hhouse_169-04 with dissolve
    h "빨래를 넣을 땐 다른 사람의 옷과 섞이지 않게 해주시구요."
    h "그렇긴해도 신사라면 직접 세탁하길 바래요 ㅎㅎ"
    scene 01hhouse_170 with dissolve
    h "저 쪽은 뒷마당이야."
    h "가볼래요?"
    scene 01hhouse_171 at hand_camera with dissolve
    pause
    if in_replay:
        return
    jump v01_backyard

label v01_backyard:
    if not in_replay:
        $ persistent.unlock_v01_backyard = True
    play music "audio/bgm/normal05.mp3"
    scene 01hhouse_172 at hand_camera with Dissolve(2.0)
    pause
    scene 01hhouse_173 at hand_camera with Dissolve(2.0)
    pause

    scene 01hhouse_175 with dissolve
    n "[d_name]은 뒷마당을 보고 잠시 생각했다."
    n "대저택은 아니었지만 그녀가 공간을 꾸미기 위해 꾀 수고를 했을거란 생각과,"
    n "자신도 언젠가 이런 집을 구해 사랑하는 연인과 같이 살고 싶다는 생각이었다."
    d "와 정말 잘 구성된 공간이네요."
    d "인상적이에요."
    scene 01hhouse_176 at hand_camera with dissolve
    pause
    scene 01hhouse_177 with dissolve
    h "뒷 마당엔 수영장과 파티오가 있어."
    h "여름 밤엔 여기서 혼자 와인 마시며 책 읽는 것도 좋아요."
    scene 01hhouse_178 with dissolve
    h "ㅎㅎ"
    scene 01hhouse_179 at hand_camera with Dissolve(0.8)
    n "그녀는 다시 한 번 [d_name]을 아랑곳하지 않고 행동했다."
    h "영차..."
    scene 01hhouse_180 with Dissolve(1.5)
    h "이렇게.."
    scene 01hhouse_181 at hand_camera with Dissolve(0.8)
    pause
    scene 01hhouse_181-01 with dissolve
    pause 0.2
    scene 01hhouse_181-02 with dissolve
    pause
    scene 01hhouse_182 at hand_camera with dissolve
    pause
    play voice_f "audio/sex/fsigh.mp3"
    scene 01hhouse_183 with dissolve
    n "그녀는 의자에 누워 눈을 감으며 야릇한 신음을 내었다."
    h "아 좋다........"
    h "여기 이렇게 누우면 하루 피로가 다 풀리는 느낌이에요."
    h "나이 먹어가니까 앉는거 보다 눕는게 더 좋아지는거 있죠."
    scene 01hhouse_184 with dissolve
    h "여기는 이 집에서 내가 제일 좋아하는 공간이야."
    h "집안에서 내가 안보일때는 이곳에 있다고 생각하면 돼요 ㅎㅎ"
    h "낮에 여기 있을 땐 많이 편하게 입고 있으니까 보더라도 놀라지는 말아요 ㅎㅎ"
    scene 01hhouse_186-01 at hand_camera with dissolve
    play voice_f "audio/voices/fshock02.mp3"
    h "(!!!!!!!!)"
    scene 01hhouse_185 with Dissolve(2.0)
    n "그의 고추는 터질듯이 발기해 있었다."
    n "그가 입은 청바지 위로 적나라 하게 모양이 드러나 있었다."
    d "..............."
    scene 01hhouse_186-02 with dissolve
    h "............"
    scene 01hhouse_187 with dissolve
    h "이런 미안해요. 너무 내 생각만 했네요."
    h "처음 만났는데 제가 너무 편하게 생각했나봐요."
    scene 01hhouse_187-01 with dissolve
    h "그럼 집으로 들어갈까요?"
    h "피곤할텐데 어서 저녁먹고 쉽시다."
    scene 01hhouse_187-02 with Dissolve(1.5)
    n "그들은 이상한 분위기 속에서 집안으로 걸음을 옮겼다."
    h "................"
    scene 01hhouse_187-03 at hand_camera with dissolve
    d "(그녀가 눈치 챈거 같은데.....)"
    d "(젠장 첫날부터 이게 뭐야 이 멍청아...)"
    d "(내일 아침에 일어나면 집에서 나가달라고 하는거 아냐?)"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    jump v01_mcroom02

label v01_mcroom02:
    play music "audio/bgm/normal02.mp3"
    scene 01lecture_188 with dissolve
    h "그럼 피곤할텐데 짐 풀고 쉬어요"
    h "식사 준비 되면 같이 먹어요."
    h "요리 실력은 별로지만 오늘은 특별히 제가 만들거에요."
    scene 01lecture_189 with dissolve
    n "그는 그녀의 기분이 특별히 바뀌지 않았다 생각하며 안도했다."
    d "정말 감사합니다 랜드레이디."
    d "저의 렌트비가 정말 저렴한데 이렇게 식사도 제공해주셔도 되는지 모르겠습니다."
    d "누가 되지 않게 조용히 지내겠습니다."
    scene 01lecture_190 at hand_camera with dissolve
    pause
    scene 01lecture_189 with dissolve
    d "................."
    scene 01lecture_190 at hand_camera with dissolve
    h "그럼 식사 준비되면 부를게요."
    scene 01lecture_193 with Dissolve(1.5)
    pause
    scene 01lecture_194 with Dissolve(1.5)
    pause
    scene 01lecture_195 with Dissolve(1.5)
    pause
    scene 01lecture_196 with Dissolve(2.0)
    pause
    scene 01lecture_197 with dissolve
    d "이 정도면 대충 정리는 된거 같아."
    d "나머지는 내일 하자."
    scene 01lecture_198 with dissolve
    d "목마르군."
    d "아 아이스 커피를 마셔야 해."
    if in_replay:
        return
    jump v01_kitchen01

label v01_kitchen01:
    if not in_replay:
        $ persistent.unlock_v01_kitchen01 = True
    scene 01lecture_199 with dissolve
    pause
    scene 01lecture_200 with dissolve
    pause
    scene 01lecture_201 with dissolve
    d "저기요"
    d "[h_name]"
    scene 01lecture_202 with dissolve
    d "저기 커피머신을 좀 사용해도 될까요?"
    d "..............."
    scene 01lecture_201 with dissolve
    d ".............."
    scene 01lecture_201 with dissolve
    pause
    scene 01lecture_203 with dissolve
    d "(에라 모르겠다..)"
    d "(이런것 까지 물어볼필요 없잖아.)"
    scene 01lecture_204 with Dissolve(1.5)
    pause
    scene 01lecture_205 with dissolve
    d "(여기 있군)"
    scene 01lecture_206 at hand_camera with dissolve
    pause
    scene 01lecture_207 with dissolve
    d "(아무 컵이나 막 사용해도 되나?)"
    n "그가 컵을 막 집어들었을 때 그녀의 방에서 소리가 들려왔다."
    n "슥삭 슥삭"
    n "슥삭 슥삭"
    scene 01lecture_208 with dissolve
    d "응?"
    scene 01lecture_208-01 with dissolve
    n "그가 소리나는 곳으로 고개를 돌리자 [h_name]의 방이 보였다."
    n "그곳에는 누군가 움직이는 듯 희미한 그림자가 움직이고 있었다."
    d ".............."
    scene 01lecture_209 with dissolve
    pause
    scene 01lecture_210 with dissolve
    d "!!!!!!!!!!!!!!!!!!"
    play music "audio/bgm/erotic03.mp3"
    scene 01lecture_211 at hand_camera_zoom with vpunch
    pause
    scene 01lecture_212 at hand_camera with Dissolve(1.5)
    pause
    scene 01lecture_213 at hand_camera with Dissolve(1.5)
    pause
    scene 01lecture_213-01 at hand_camera with Dissolve(1.5)
    pause
    play voice_f "audio/voices/fshock02.mp3"
    scene 01lecture_214_alt at hand_camera with dissolve
    h "응?"
    scene 01lecture_215 at hand_camera with dissolve
    d "shit"
    scene 01lecture_216 with dissolve
    d "shit..."
    scene 01lecture_206 with dissolve
    pause 1.5
    play voice_f "audio/voices/Fcough01.mp3"
    h "크흠"
    scene 01lecture_206-01 with dissolve
    n "그는 [h_name]이 생각보다 빨리 나타나 엄청 놀랐다."
    n "그는 자신이 그녀의 방을 엿본것을 그녀가 봤을지 모른다 생각했다."
    h "혹시 뭐라고 말했나요?"
    scene 01lecture_217 with dissolve
    n "그녀는 [d_name]의 놀란 표정을 의아하게 바라보았다."
    d "아 저 그게.."
    d "커피 머신을 찾고 있었어요."
    d "커피 마셔도 될까요?"
    scene 01lecture_217-01 at hand_camera with dissolve
    h "아 미안해요. 그러고 보니 물도 안줬네요."
    h "주방에 있는 모든 기구들 자유롭게 사용 해요."
    scene 01lecture_217-02 at hand_camera with dissolve
    h "[d_name]의 렌트비에 다 포함 돼 있으니 걱정하지 말아요. ㅎㅎㅎ"
    scene 01lecture_217-03 with dissolve
    d "알겠습니다."
    if in_replay:
        return
    jump v01_dinner

label v01_dinner:
    if not in_replay:
        $ persistent.unlock_v01_dinner = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene 01lecture_218 with dissolve
    h "(음식 만드는거 진짜 오랜만이네..)"
    h "(매일 할땐 정말 지겨웠는데)"
    h "(간만에 같이 먹을 사람이 생기니까 재미있는걸.)"
    pause
    scene 01lecture_219 with dissolve
    n "그녀는 음식을 들고 식탁으로 나르기 시작했다."
    h "자 다 됐어요."
    h "배고프죠?"
    d "네 ㅎㅎ"
    d "오늘 그러고보니 아침부터 한끼도 안먹었어요."
    scene 01lecture_219-01 at hand_camera with Dissolve(0.8)
    h "한끼도 안먹었다고요?"
    h "그런데 어떻게 그렇게 서있을 수 있죠? ㅎㅎ"
    h "제 아들도 잘 안먹고 다녀서 나한테 엄청 혼났었어요."
    h "혈기왕성한 젊음이 좋지만 식사는 잘 챙겨야 해요."
    scene 01lecture_220 at hand_camera with Dissolve(0.8)
    n "그들은 서로를 마주고 앉았다."
    n "[d_name]에겐 탄산음료, 그녀 자신을 위해선 위스키를 준비했다."
    h "자 메뉴는 많지 않지만 어서 먹읍시다."
    scene 01lecture_220-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_221 with dissolve
    d "와 정말 맛있어 보여요."
    d "일렇게 정성이 담긴 음식을 얼마만에 먹어보는지 모르겠어요 ㅎㅎ."
    d "맛 없기로 유명한 제 학교 식당 밥에 비하면 특급 식당 요리입니다 ㅎㅎ"
    scene 01lecture_222 with dissolve
    h "그 정도는 아니에요 ㅎㅎ"
    h "오랜만에 실력 발휘좀 해봤어요 ㅎㅎ"
    h "평소엔 귀찮아서 대충 먹거든요. 손님이 오니까 뭔가 달라지네요."
    h "내가 음식을 차리는건 오늘이 처음이자 마지막일거에요."
    h "매일 음식을 만들어주고 청소해주는 가정부가 있어요."
    scene 01lecture_221 with dissolve
    d "아 그렇군요."
    d "가정부에게 폐를 끼치지 않게 잘해야겠네요."
    scene 01lecture_222 with dissolve
    h "ㅎㅎ 그래요"
    h "대학 기숙사에 있는 동안 부실하게 먹지 않았어요?"
    h "그러니 맛있게 먹어요."
    scene 01lecture_223 with Dissolve(1.5)
    pause
    scene 01lecture_224 with Dissolve(1.5)
    pause
    scene 01lecture_225 with dissolve
    d "그런데 landlady.."
    d "이런 질문 해도 될런지 모르겠는데요..."
    d "이 집에 혼자 살고있어요?"
    scene 01lecture_226 at hand_camera with dissolve
    n "그의 다소 예상치 못한 질문에 [h_name]은 잠시 망설였다."
    h ".........................."
    scene 01lecture_226-01 at hand_camera with dissolve
    h "응. 자식들은 다 출가 했지."
    h "이젠 조용한 게 익숙해졌어요."
    h "가끔 애들 떠드는 소리가 듣고 싶을 때가 있는거 외엔 혼자 지내는게 편한 때가 있어요."
    scene 01lecture_227 with dissolve
    h "이 집은 남편과 같이 살던 집이었는데 이혼하고 지금은 혼자 살아."
    h "전 남편이 고집스럽게 고른 집이었는데 아이러니지."
    scene 01lecture_228 with dissolve
    d "아 미안합니다."
    d "제가 괜한 질문을 했습니다."
    scene 01lecture_229 at hand_camera with dissolve
    h "아니야 괜찮아요."
    h "지나간 이야기니까. 지금은 꽤 편해요, 혼자 사는 게."
    scene 01lecture_224 with dissolve
    h "큰딸은 작년에 결혼, 작은 딸은 대학에 가 있어."
    h "이제 겨우 나한테서 벗어난 거죠. 하하"
    scene 01lecture_230 with dissolve
    d "!!"
    d "결혼?!,대학교요?"
    scene 01lecture_230-01 with dissolve
    h "으흥"
    h "큰 딸은 이 지역에서 살고 있고, 작은 애는 대학에서 영상을 전공하고 있어요."
    h "아마 작은 애는 [d_name]군과 비슷한 나이일거에요."
    scene 01lecture_230 with dissolve
    d "놀랐어요. 결혼을 할 자녀가 있을 나이로는 전혀 보이지 않거든요."
    d "랜드레이디는 기껏해야 나이가...."
    scene 01lecture_229 with dissolve
    n "그녀는 그가 어떤 말을 하려는지 알아차렸다."
    n "하지만 그가 어떤 대답을 하려는지 사뭇 궁금해졌다."
    h "응? 나이가 뭐?"
    h "내가 몇 살로 보이는데요?"
    h "솔직하게 말해도 괜찮아요 ㅎㅎㅎ"
    scene 01lecture_230 with dissolve
    d "제 생각엔......."

    menu:
        n "How should I respond?"
        "You look my age. Hehehe":
            if not in_replay:
                $ add_point("sus_helen", 1, "sus_helen")
            scene 01lecture_225 with dissolve
            d "제 또래로 보입니다. ㅎㅎㅎ"
            scene 01lecture_230-02 with dissolve
            n "그녀는 아무 대답 없이 술을 한 모금 마셨다."
            h "워 너무 나갔어요."
            h "중년 여성에게 그런 말은 실례에요."
            scene 01lecture_225 with dissolve
            n "[d_name]은 자신이 실수 했을음 깨달았다."
            d "죄송합니다.."
            d "죄송합니다..별 뜻은 없었어요.."
        "I don't know, but to me you look like you're in your 30s?":

            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
            scene 01lecture_225 at hand_camera with dissolve
            d "모르겠어요, 그냥 제 눈엔 30대 초반으로 보이는데요?"
            d "그냥 솔직하게 말씀드린거에요 ㅎㅎ"
            play voice_f "audio/voices/flaugh02.mp3"
            scene 01lecture_231 at hand_camera with dissolve
            h "하하하하"
            h "30대 초반이요?"
            h "왜 그렇게 생각을 하죠? 갑자기 수상해 보이는네요."
            h "30대 초반으로 돌아갈수만 있다면 소원이 없겠네요."
            scene 01lecture_231-01 with dissolve
            h "무슨 의미로 말 한건지는 묻지 않을게요."
            h "달변가의 기질이 보이는 학생이네요."
            h "진짜 요즘 애들 재미있다."

    scene 01lecture_226-01 with dissolve
    n "그녀는 잠시 그를 바라보다가 말했다."
    h "..............."
    h "난 아마 너의 나이에 두배가 넘을거에요."
    h "그것도 최소로."
    scene 01lecture_225 with dissolve
    d "아 실례했습니다. 난 그저 당신이 너무 젊어보여서 그걸 표현한다는게 그만"
    scene 01lecture_231-03 with dissolve
    h "괜찮아요."
    h "칭찬으로 받아드릴게요."
    h "간만에 이런 대화 하니까 좋은걸요."
    h "하지만 너무 나간 얘기는 하지 않았으면 좋겠어요."
    scene 01lecture_230-01 at hand_camera with dissolve
    h "괜찮으면 [d_name]군 얘기를 좀 해볼래요?"
    h "여기 Milfheim에 얼마나 있을거에요?"
    h "............................."
    scene 01lecture_228 at hand_camera with dissolve
    pause
    scene 01lecture_230-01 at hand_camera with dissolve
    h ".......................?"
    play voice_f "audio/voices/fshock02.mp3"
    h "(쟤 지금...)"
    h "(내 가슴을 보고 있는건가?)"
    h "(흠................)"
    scene 01lecture_229 at hand_camera with dissolve
    h "괜찮으면 [d_name]군 얘기를 좀 해볼래요?"
    h "여기 Milfheim에 얼마나 있을거에요?"
    scene 01lecture_230 with dissolve
    d "네?"
    d "아 전 일단은 방학 동안 있을 생각으로 왔어요."
    d "제 전공이 심리학인데 지도교수님이 방학 동안 가능한 많은 사람들을 만나고 나름 분석하여 에세이를 작성하라고 과제를 주셨거든요."
    scene 01lecture_230-07 with dissolve
    d "사람들을 만나면서 기회가 있으면 지역 회사에서 인턴십도 할 생각입니다."
    d "제가 위탁가정 출신이라 정부에서 저에게 지원금이 나오긴하는데 저도 사회를 위해서 뭔가 하고 싶어서요."
    d "제 고향이기도 하지만 이 지역엔 저를 길러주고 돌봐주신 분들이 있어서 더 각별해요."
    scene 01lecture_231-03 with dissolve
    h "정말 바른 생각을 가진 청년이네요."
    h "사회를 위해 일하고 싶은 Milfheim 출신의 심리학도라..."
    h "대단한 메뉴는 아니었지만 오늘 [d_name]군에게 저녁을 만들어준 보람이 바로 느껴지네요 ㅎㅎ"
    h "......................"
    scene 01lecture_229 with dissolve
    h "위탁 가정은 어땠어요? 아기때 위탁 가정으로 간거에요?"
    scene 01lecture_230-07 with dissolve
    d "아주 어렸을땐 유스센터에서 자랐어요."
    d "애기 때 그쪽에 맡겨져서 위탁가정에 가기 전까지 메리 선생님이 돌봐주셨어요."
    d "그 분은 저에게 어머니이자 선생님이에요."
    scene 01lecture_231-03 with dissolve
    h "그렇군요. 메리라면 왠지 아는 사람 같기도 한데.."
    h "저도 거기 어딘지 알아요. Milfheim Youth Center."
    h "원래는 산속에 호그와트 처럼 크게 있었잖아요."
    scene 01lecture_225 with dissolve
    d "잘 아시네요."
    d "그 후로 이 지역 인구가 줄면서 제가 위탁 가정으로 갈때 즈음에 지금 위치로 이전 했어요."
    scene 01lecture_231-03 with dissolve
    h "그렇군요."
    h "나도 지나가면서 봤는데 거기가 분교가 아니라 이전한거 였군요."
    scene 01lecture_230-08 with dissolve
    h "아 참 이거 물어보려 했었는데 잊고 있었네."
    h "근데 고향에 왔는데 왜 양부모님이 계신 곳으로 안가고 하숙집을 구했어요?"
    h "독립하게 된거에요?"
    scene 01lecture_225 with dissolve
    d "아 그건....."
    scene 01lecture_225-01 with dissolve
    n "[d_name]은 잠시 뜸들이며 말을 이어나갔다."
    d "위탁가정 분위기가 좀 ㅎㅎ"
    d "양아버지가 평소엔 자상하지만 자주 화내고 짜증내서 절 좀 못살게 굴었어요."
    d "뭐가 그렇게 못마땅 했었는지는 지금도 모르겠어요."
    d "양아버지를 떠올리면 실룩실룩 거리는 콧수염이 제일 먼저 생각나요."
    scene 01lecture_225-02 with dissolve
    d "양어머니는 정말 친어머니 처럼 자상했고요."
    d "절 정말 친자식 처럼 헌신해서 돌봐주셨어요."
    d "친구처럼 제 얘기도 다 들어주셨고요."
    d "뭐 저도 성인이 되긴 했지만 양아버지가 대학교에 가면 완전히 독립하라고 하는 바람에.."
    scene 01lecture_230-01 at hand_camera with dissolve
    h "왜요?"
    h "[d_name]군이 속을 많이 썩였어요?"
    scene 01lecture_230-07 with dissolve
    d "입양 초기엔 말썽를 많이 부렸어요."
    d "동네 불량배들과 어울리기도 했구요 ㅎㅎ"
    d "근데 양아버지가 저에게 화를 내는건 주로 다른 이유였어요."
    scene 01lecture_230-04 at hand_camera with dissolve
    h "그 이유가 뭐였는지 물어봐도 돼요?"
    h "불편하면 말하지 않아도 돼요."
    scene 01lecture_230 with dissolve
    d "첫 번째는 공부를 더 열심히 해라였고"
    d "두 번째는 제가 양어머니와 너무 가깝다는 이유였어요."
    scene 01lecture_231-10 at hand_camera with dissolve
    h "앵?"
    h "너무 가깝다는게 무슨 말이에요?"
    h "양어머니라지만 그래도 모자지간인데 가까운건 당연하잖아요?"
    scene 01lecture_221-01 with dissolve
    d "프랭크 아저씨는 저와 양어머니가 필요 이상의 스킨십을 한다고 엄청 화냈어요."
    d "둘이 옷차림이나 언행, 스킨십 이런거에 너무 조심하지 않는다면서요."
    d "저 때문에 가정의 평화가 깨졌다고 하면서요."
    d "자신의 의무는 다 했다며 대학에 가면 찾아오지 말라고 했어요. 기숙사에서 공부나 열심히 하라면서요."
    scene 01lecture_231-10 at hand_camera with dissolve
    n "그녀는 [d_name]의 말이 어떤 의미인지 잠시 생각했다."
    n "일반적인 모자지간 처럼 들리지 않았지만 특별히 신경쓰이진 않았다."
    h "저런.."
    h "필요이상의 스킨십이라니 무슨 말인지..."
    h "그 곳에서 지내면서 마음이 편치 않았겠어요."
    h "어떻게 자식에게 그렇게 모질게 대할수 있는지 모르겠네요."
    scene 01lecture_230-07 with dissolve
    d "네 약간은 그랬죠."
    d "하지만 양어머니가 절 너무 잘 돌봐주셔서 잘 지낼수 있었어요."
    d "대신 양어머니를 보러 가는건 양아버지가 없을 때 가야할 거 같아요 ㅎㅎ"
    d "내일모레 프랭크가 낚시 여행을 간다고 하니 그때 가려구요."
    scene 01lecture_231-09 at hand_camera with dissolve
    h "그래도 삐뚤어지지 않고 이렇게 어엿한 청년으로 자란게 대견하네요."
    h "뭐랄까 나이에 비해 더 어른스럽다는 생각이 들어요."
    h "짠하네요. 어린 시절이 얼마나 힘들었을지.."
    scene 01lecture_230-08 at hand_camera with dissolve
    h "[d_name]군은 나나 이 집에 대해서 궁금한거 있으면 물어봐요."
    h "어떤 것도 좋아요."
    scene 01lecture_221-01 with dissolve
    d "네 그럼.."
    d "아까 제가 도착했을때 집을 나서던 남자는 누구에요?"
    d "그 분이 Landlady의 전 남편이에요?"
    scene 01lecture_230-02 with dissolve
    n "그녀는 다시 위스키를 한 모금 들이켰다."
    h ".................."
    h "생각 못했던 질문이네요."
    scene 01lecture_231-08 with dissolve
    h "그 사람은 남편은 아니고 마이클이라고 내 친구에요."
    h "내가 하는 일과도 연관된 사람인데 가끔 와서 상의도 하고 얘기도 하고 그런 관계죠. 동업자랄까?"
    h "여기서 지내는 동안 몇 번 마주치게 될 거에요."
    scene 01lecture_226-01 at hand_camera with dissolve
    h "하지만 사교성이 좋거나 따뜻한 성격은 아니니 친해지기 힘들거에요."
    h "경계심이 많은 사람입니다."
    scene 01lecture_231-03 with dissolve
    h "근데 [d_name]군은 여자 친구가 보고싶어 하겠어요."
    h "방학이면 둘이 붙어있고 싶을텐데 이렇게 고향에 내려와버려서 어째요?"
    scene 01lecture_230-05 with dissolve
    h "응?"
    h ".........................."
    scene 01lecture_231-05 with dissolve
    play voice_f "audio/voices/fshock02.mp3"
    h "(오 보이.)"
    h "(역시 쟤 지금 내 가슴을 보고 있었어.)"
    scene 01lecture_229 with dissolve
    h "[d_name]군."
    h "................."
    scene 01lecture_228 at hand_camera with dissolve
    h "[d_name]군?"
    scene 01lecture_230 with dissolve
    d "네?"
    d "아 저 그 여자친구는...."
    d "지금은 없습니다.ㅎㅎ"
    d "학기초에 사귀었었는데 헤어졌어요."
    scene 01lecture_230-04 at hand_camera with dissolve
    h "저런... 마음이 아프겠네요."
    h "보통 첫 사랑과 헤어지면 마음을 다잡는게 정말 힘든데.."
    scene 01lecture_230-07 with dissolve
    d "처음엔 엄청 힘들었어요."
    d "룸메이트 Jason이 옆에서 여러가지 당근과 채찍을 주면서 절 도와줘서 잘 견뎠죠 ㅎㅎㅎ"
    d "그리고 여자를 한 번 만나보니 제 취향을 알겠더라구요."
    scene 01lecture_230-01 at hand_camera with dissolve
    h "오 그래요?"
    h "어떤 취향인지 궁금한걸요?"
    scene 01lecture_231-11 with dissolve
    d "전 뭐랄까..."
    d "연상의 여인 취향이더라구요."
    scene 01lecture_230-03 at hand_camera with dissolve
    h "!!"
    h "흠....."
    h "그렇군요."
    scene 01lecture_231-11 with dissolve
    d "교수님과 이것에 대해 이야기 한 적 있었는데 교수님 말론는 어린 시절 어머니의 보살핌에 대한 결핍과 그 반대인 과잉 보살핌 두 경우 모두 연상의 여인에 대한 끌림이 생길수 있다고 하더라구요."

    d "제 경우는 뭘까 많이 생각해 봤는데 아무리 생각해도 모르겠어요.ㅎㅎ"
    scene 01lecture_230-04 at hand_camera with dissolve
    h "흠..."
    h "아들을 키워본 어머니의 경험에서 말하자면 [d_name]군 나이의 남자들 상당수가 그런 과정을 겪어요."
    h "내 아들도 그랬고.. 아마 지금 연상에 대한 끌림은 일시적일 수 있어요."
    h "물론 그 교수님 이야기가 틀렸다는건 아니에요."
    scene 01lecture_231-09 with dissolve
    h "어디까지나 내 의견이니까 그냥 넘겨요 ㅎㅎ"
    h "...................."
    scene 01lecture_230-05 with dissolve
    play voice_f "audio/voices/fshock02.mp3"
    n "그녀는 [d_name]이 다시 자신의 젖을 쳐다보는걸 알아차렸다."
    h "!!!!"
    scene 01lecture_231-05 with dissolve
    h "(또?)"
    scene 01lecture_231-06 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fahem01.mp3"
    h "크흠.."
    h "[d_name]군."
    scene 01lecture_231-12 with dissolve
    d "아 죄송합니다."
    d "제가 가끔 이렇게 딴 생각을 하면 사람 말도 못듣는 경우가 가끔 있습니다."
    scene 01lecture_231-07 with dissolve
    h "괜찮아요 ㅎㅎ"
    h "맛있게 먹었어요?"
    scene 01lecture_230-07 with dissolve
    d "네 이렇게 맛있게 식사를 한건 거의 1년 만인거 같아요."
    d "잘 먹었습니다 Landlady."
    scene 01lecture_231-07 with dissolve
    h "그냥 [h_name]이라고 불러요."
    h "앞으로 몇달간 한 집에서 지낼텐데 호칭은 편해야죠."
    h "그럼 이만 일어날까요?"
    scene 01lecture_231-04 with Dissolve(2.0)
    pause
    jump v01_mcroom03

label v01_mcroom03:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    play music "audio/bgm/night.mp3"
    scene 01lecture_232 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_233 at hand_camera with Dissolve(0.8)
    d "오늘 진짜 긴 하루였다."
    d "제이슨은 파티에서 신나게 놀고있겠지?"
    d ".........."
    scene 01lecture_234 at hand_camera with Dissolve(0.8)
    d "기분이 묘하군. 편안하면서 긴장되는 이 느낌은 뭐지?"
    d "고향에 왔는데 왠지 이상한나라의 엘리스가 된 기분이야."
    d "이상한 나라의 [d_name]."
    d "Milfheim hills의 [d_name]."
    scene 01lecture_234-01 with Dissolve(1.5)
    d "젠장...."
    scene 01lecture_234-02 with Dissolve(1.5)
    d "맙소사...."
    d "대단한 날이었군."
    scene 01lecture_235 at hand_camera with Dissolve(0.8)
    n "그는 천장을 바라보며 하루를 되돌아 봤다."
    n "그리고 낯선 장소에서의 하루를 마감하며 약간은 상기된 기분을 가라앉히기 위해 눈을 감았다."
    scene 01lecture_236 with Dissolve(2.0)
    pause
    scene black with Dissolve(2.0)
    scene 01lecture_237 with Dissolve(1.5)
    pause
    scene 01lecture_238 with Dissolve(1.5)
    pause
    scene 01lecture_239 with Dissolve(1.5)
    pause
    scene 01lecture_240 with Dissolve(1.5)
    pause
    scene 01lecture_241 with Dissolve(1.5)
    pause
    scene 01lecture_242 with Dissolve(1.5)
    pause
    scene 01lecture_243 with Dissolve(1.5)
    pause
    scene 01lecture_244 with Dissolve(1.5)
    pause
    $ _dismiss_pause = False
    scene black with Dissolve(2.0)
    pause
    jump v01_mcroom04

label v01_mcroom04:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True

    play music "audio/bgm/normal03.mp3"
    scene 01lecture_244-01 with Dissolve(2.0)
    pause
    scene 01lecture_245 with dissolve
    pause
    scene 01lecture_245-01 with Dissolve(2.0)
    pause
    scene 01lecture_245 with dissolve
    pause
    scene 01lecture_246 with dissolve
    pause
    scene 01lecture_247 with Dissolve(2.0)
    n "[d_name]은 일어나 침대 끝에 걸터 앉으며 그나 아침에 일어나면 늘 하는 말을 내뱉었다."
    n "그 자신도 자신이 언제부터 아침마다 이 말을 하게 됐는지 기억하지 못했다."
    d "어제도 죽지 않고 이렇게 새로운 하루를 맞았군."
    d "흠.."
    d "오늘 어디 가기로 했었지? 보육원이었나."
    scene 01lecture_248 with dissolve
    pause
    scene 01lecture_249 with dissolve
    pause
    scene 01lecture_250 with Dissolve(2.0)
    pause
    scene 01lecture_251 with Dissolve(1.0)
    pause
    if in_replay:
        return
    jump v01_helencoffee

label v01_helencoffee:
    if not in_replay:
        $ persistent.unlock_v01_helencoffee = True
    scene 01lecture_252 with Dissolve(1.0)
    n "그는 방에서 나와서 [h_name]을 보고 잠시 멈칫했다."
    scene 01lecture_253 at hand_camera with Dissolve(1.5)
    n "[h_name]이 의자에 앉아 치마를 올리고 자신의 다리를 쓰다듬고 있었다."
    scene 01lecture_254 with dissolve
    h "(다리가 피로해..)"
    h "(이제 하이힐은 오래 못신겠어..)"
    h "(그냥 앞으로 편하게 입고 일해야 하거 같아.)"
    scene 01lecture_255 with dissolve
    pause
    scene 01lecture_256 with dissolve
    h "잘 잤어요?"
    h "오! 셔츠가 잘 어울리네요 [d_name]."
    scene 01lecture_256-01 with dissolve
    pause
    scene 01lecture_252 with dissolve
    d "좋은 아침이에요 랜드레이디."
    d "어디 갈 준비 하나봐요?"
    scene 01lecture_258 at hand_camera with dissolve
    h "으흥"
    h "일하러 가는거에요."
    h "그리고 [h_name]이라고 불러요. 나도 그게 좋아요."
    h "이 집 모기지가 아직 안 끝나서 개미 처럼 일하고 사네요 ㅎㅎ"
    scene 01lecture_259 at hand_camera with dissolve
    pause
    scene 01lecture_260 at hand_camera with dissolve
    h "원래 가정부 하시는 분이 있는데 일이 생겨서 요즘 내가 바쁘네요."
    scene 01lecture_260-01 with dissolve
    h "주방에 아침 식사 돼 있으니까 데워서 먹어요."
    scene 01lecture_261 with dissolve
    pause
    scene 01lecture_261-01 with dissolve
    pause
    scene 01lecture_262 with dissolve
    h "오늘 여기저기 돌아다닐거죠?"
    h "차고에 자전거가 있으니까 마음대로 사용해요."
    h "그리고 혹시 외박하게 되면 문자 메세지 하나 부탁해요."
    scene 01lecture_263 at hand_camera with dissolve
    pause
    scene 01lecture_264 with dissolve
    n "그녀는 [d_name]에게 손인사를 하고 계단을 내려갔다."
    scene 01lecture_264-01 with dissolve
    n "그는 내려가는 그녀의 모습을 바라보았다."
    n "어제 발기했던 자신을 보고 수상하게 생각하지 않은 것과, 그녀가 자신이 생각했던것 보다 더 친절한 사람인거 같아 안도했다."
    d "...................."
    scene 01lecture_265 with dissolve
    d "그녀는 이쁘고 친절해.."
    d "(여기서 지내는 동안 그녀와 가까워져서 친구처럼 지낼 수 있을까?)"
    pause
    d "(글쎄다....)"
    scene 01lecture_265-01 with Dissolve(2.0)
    pause
    scene 01lecture_266 with Dissolve(2.0)
    pause
    play sound "audio/ambi/garage.mp3" 
    scene 01lecture_267 with Dissolve(2.0)
    pause
    scene 01lecture_268 with dissolve
    d "오 멋진 자전거네."
    d "[h_name]이 타는건 아닌거 같은데?"
    d "음....."
    d "그럼 잘 사용하겠습니다."
    scene 01lecture_269 with Dissolve(2.0)
    pause
    play sound "audio/ambi/bicycle01.mp3" 
    scene 01lecture_270 with dissolve
    pause
    if in_replay:
        return
    jump v01_youthcenter_day


label v01_youthcenter_day:
    if not in_replay:
        $ persistent.unlock_v01_youthcenter_day = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    play music "audio/bgm/normal02.mp3"
    scene 01lecture_270-01 at hand_camera with Dissolve(0.8)
    n "그는 한 참을 자전거를 달려 그가 어린시절 보냈던 보육원에 도착했다."
    scene 01lecture_273 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_275-01 with dissolve
    n "그는 시설에 들어서면서 자신도 모르게 입가에 미소가 번졌다."
    scene 01lecture_275-02 with dissolve
    d "이런.. 진짜 집에 왔군."
    d "여기에 오니까 진짜 고향에 온게 실감난다 ㅎㅎ"
    scene 01lecture_275-03 with dissolve
    pause
    scene 01lecture_276 with dissolve
    pause
    scene 01lecture_277 with dissolve
    pause
    scene 01lecture_277-01 at hand_camera with dissolve
    pause
    scene 01lecture_278 with dissolve
    pause
    scene 01lecture_279 at hand_camera with dissolve
    c "[d_name] 돌아왔구나!!"


    if not in_replay:
        $ bio_celine = True
    scene 01lecture_280 with dissolve
    d "와 안본 사이에 더 이뻐진거 같아 Celine."
    scene 01lecture_281 at hand_camera with dissolve
    pause
    scene 01lecture_281-01 at hand_camera with dissolve
    pause
    scene 01lecture_282 with dissolve
    c "언제 돌아온거야?"
    c "문자라도 보내줬어야지 자식아. 신비주의 컨셉이야?"
    c "대학은 어때?"
    scene 01lecture_283 with dissolve
    d "내 머리론 따라가기 벅차지 ㅋㅋ"
    d "다행히 나보다 더 멍청한 친구를 만났어."
    scene 01lecture_284 with dissolve
    play voice_f "audio/voices/flaughyoung.mp3"
    c "에이 뭐야 ㅋㅋ"
    c "그 썰렁한 유머감각은 대학에 가도 안바뀌는 구나."
    scene 01lecture_284-01 with dissolve
    d "소식들었어."
    d "나를 버린거야 셀린?"
    scene 01lecture_285 at hand_camera with dissolve
    pause
    scene 01lecture_285-001 at hand_camera with dissolve
    pause
    scene 01lecture_285-01 with dissolve
    n "그녀는 자신의 손을 들어보이며 결혼 반지를 보여주었다."
    scene 01lecture_285-02 with dissolve
    d "나한테 얘기도 안해주고 너무한거 아니야?"
    d "장소를 알려줬으면 널 잡고 도망칠 수 있었는데"
    scene 01lecture_285-03 with dissolve
    c "그냥 가족들 끼리 조용히 식 올리기로 해서 대부분 연락 안했어."
    c "남편도 타지역 사람이라 하객들이 많이 못 왔을거야."
    scene 01lecture_284-01 with dissolve
    d "아 그렇구나."
    d "그래도 나한테는 얘기 해줬어야지."
    d "어린 시절을 함께한 사이인데"
    d "나에게도 기회를 줬어야 하는거 아냐? ㅎㅎ"
    scene 01lecture_285-04 with dissolve
    n "그녀는 [d_name]이 약간 변했다 생각하며 잠시 그를 바라보았다."
    n "결혼한 유부녀로서 어떤 말까지 허용해야 할지 약간 혼란스러웠지만 크게 개의치 않았다."
    c "뭐야 도시에 가더니 능글맞아 졌어 너."
    c "내가 너 보다 몇살이 더 많은데."
    c "니가 아동일 때 난 청소년이었다고."
    scene 01lecture_285-05 with dissolve
    d "ㅎㅎ 근데 벌써 유부녀라니"
    d "조만간 술 한잔 같이 하면서 얘기좀 더 들려줘"
    d "아차, 이제 결혼했으니 조심해야 하나?"
    scene 01lecture_284 with dissolve
    c "아니야 아니야"
    c "결혼 했다고 친구도 못만나고 그러는줄 아니? ㅋㅋ"
    scene 01lecture_285-02 with dissolve
    d "으흥, 그러면 시간 괜찮을 때 메세지 보내"
    scene 01lecture_285-06 with dissolve
    d "메리 선생님 계시지?"
    scene 01lecture_285-07 with dissolve
    c "선생님이라니. 이제 이 시설 원장님이야"
    c "뭐야 이거 완전 우리 동네는 신경 끄고 살았잖아."
    scene 01lecture_285-08 at hand_camera with dissolve
    d "와 원장님"
    d "내가 화성에 갔다온것도 아닌데 왜 아무것도 모르고 있었지"
    scene 01lecture_285-09 with dissolve
    c "어서 들어가봐"
    c "아마 널 보면 엄청 기뻐하실거야."
    scene 01lecture_285-10 at hand_camera with dissolve
    c "그리고 고향에 좀 자주 오라고 ㅎㅎ"
    c "신경을 끄고 사니까 메리가 원장님이 된것도 모르고 살았지."
    c "메리 선생님이 널 얼마나 보고싶어 했는데."
    c "암튼 빨리 가봐."
    if in_replay:
        return
    jump v01_youthcorridor

label v01_youthcorridor:
    if not in_replay:
        $ persistent.unlock_v01_youthcorridor = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    scene 01lecture_287 with dissolve
    pause
    scene 01lecture_288 with Dissolve(1.5)
    pause
    menu:
        "Knock":
            play sound "audio/ambi/knock.mp3" 
            scene 01lecture_289 with dissolve
            scene 01lecture_289-01 with dissolve
            scene 01lecture_289 with dissolve
            scene 01lecture_289-01 with dissolve
            stop sound
            pause
    menu:
        "Knock":
            play sound "audio/ambi/knock.mp3" 
            scene 01lecture_289 with dissolve
            scene 01lecture_289-01 with dissolve
            scene 01lecture_289 with dissolve
            scene 01lecture_289-01 with dissolve
            pause
    play sound "audio/ambi/dooropen.mp3" 
    scene 01lecture_290 with dissolve
    d "뭐야 안에 계시다면서?"
    d "응?"
    scene 01lecture_291 with vpunch
    play music "audio/bgm/erotic02.mp3"
    d "(!!!!!!!!!!!!!)"

    show 01lecture_291-01:
        subpixel True
        xalign 0.5
        yalign 0.0
        zoom 1.78
        ease 3 yalign 0.45
    pause  

    if not in_replay:
        $ bio_mary = True
    scene 01lecture_292 at hand_camera_zoom
    pause
    scene 01lecture_293 at hand_camera_zoom
    pause
    scene 01lecture_290 with dissolve
    play sound "audio/ambi/doorclose.mp3" 
    scene 01lecture_293-01 with dissolve
    d "(............)"
    scene 01lecture_293-02 with dissolve
    d "(꿀꺽...)"
    d "(방금 뭐였지?)"
    d "(뭘 본거지?)"
    d "(........)"

    menu:
        "Peeking":
            if not in_replay:
                $ add_point("lust_mary", 2, "lust_mary")
            scene 01lecture_290 with Dissolve(1.5)
            n "그는 살며시 문을 열고 안을 들여다 보았다."
            scene 01lecture_294 at hand_camera with dissolve
            m "(이게 무슨 일이야)"
            m "(나 지금 누구한테 뭘 보여준거야?)"
            m "(왜 문이 안잠겼지?)"
            scene 01lecture_295 at hand_camera with dissolve
            m "(문 잠근줄 알았는데.)"
            m "(하...메리. 왜그렇게 정신이 없니.)"
            scene 01lecture_296 at hand_camera with dissolve
            play voice_f "audio/voices/fshock02.mp3"
            m "!!........."
            m "(뭐야 쳐다보고 있는거야?)"
            m "(미친사람인가?)"
            m "(내가 스트립쇼라도 하고 있다고 생각하나.)"
            scene 01lecture_297 at hand_camera with dissolve
            pause
        "Just waiting":

            if not in_replay:
                $ add_point("love_mary", 1, "love_mary")
            scene 01lecture_293-01 with dissolve
            d "............."
            pause
            scene 01lecture_288 with dissolve
            n "그는 살며시 문을 닫고 자리에 얼어붙은 사람 처럼 문 앞에 서있었다."
            jump v01_maryoffice

label v01_maryoffice:
    scene 01lecture_299 at hand_camera with dissolve
    play music "audio/bgm/normal02.mp3"
    m "들어오세요."
    m "........."
    scene 01lecture_290 with dissolve
    pause
    scene 01lecture_301 with dissolve
    d "안녕하세요 선생님"
    play voice_f "audio/voices/fshock02.mp3"
    m "뭐??"
    scene 01lecture_302 at hand_camera with dissolve
    m "[d_name]!!"
    scene 01lecture_303 with Dissolve (2.0)
    n "그녀는 순간의 망설임도 없이 그를 끌어안았다."
    n "[d_name]도 행복감을 느끼며 그녀와 포옹했다.그리고 곧 그녀의 익숙한 향기가 느껴졌다."
    m "[d_name] 이게 얼마만이야."
    scene 01lecture_304 with dissolve
    d "보고싶었어요 선생님."
    scene 01lecture_305 with dissolve
    m "더 자주 오라고 했잖아 이 나쁜 녀석."
    scene 01lecture_306 with dissolve
    m "어서 앉아, 앉아."

    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    scene 01lecture_273 with dissolve
    pause 3.0
    m "뭐? 어쩜좋아"
    play voice_f "audio/voices/milflaugh01.mp3"
    m "[d_name]. 하하하하하."
    scene 01lecture_308 with dissolve
    m "여자 친구를 옆에 두고 술에 곯아 떨어졌다고? ㅋㅋ"
    m "엉뚱한건 여전하구나."
    scene 01lecture_309 with dissolve
    d "네. 다음 날 문자가 왔는데.."
    d "넌 나에게 모욕감을 줬어.. 이렇게 왔어요 ㅎㅎ"
    d "그렇게 차이게 된거에요."
    play voice_f "audio/voices/milflaugh02.mp3"
    scene 01lecture_310 at hand_camera with dissolve
    m "하하하. 왜그랬어."
    m "그 여자애가 별로 맘에 안들었었구나."
    scene 01lecture_311 at hand_camera with dissolve
    m "컴온 [d_name]."
    m "오랜 만에 자주 가던 공원에서 좀 걷자."
    m "나 요즘 계속 살이 쪄서 자주 걸어야해."
    jump v01_park

label v01_park:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True

    play music "audio/bgm/normal03.mp3"
    play sound "audio/ambi/park01.mp3" loop
    scene 01lecture_312 with dissolve
    pause 3.0
    scene 01lecture_313 with dissolve
    pause
    scene 01lecture_314 with Dissolve(2.0)
    pause
    scene 01lecture_315 at hand_camera with dissolve
    n "그들은 자주 가던 공원에 도착해 나란히 걸었다."
    n "공원은 평화로웠고 새들이 지저귐이 기분 좋게 들려왔다."
    m "그래서 여기 얼마나 있을거야?"
    m "왜 위탁가정에 안갔어?"
    scene 01lecture_316 at hand_camera with dissolve
    d "아시잖아요. foster father가 제가 성인이라고 오지 말래요."
    d "어제 하숙집에서 첫 날을 보냈어요."
    d "다행히 집주인도 좋은 사람인거 같아요."
    scene 01lecture_316-01 with dissolve
    m "그렇구나."
    m "그 아저씨는 여전하구나."
    m "요즘엔 이상한 사람들이 많아서 평범한 집 같아도 잘 봐야해."
    scene 01lecture_316-02 at hand_camera with dissolve
    m "컴온 [d_name]. 예전 처럼 겉자."
    n "그녀는 [d_name]의 팔을 끌어당기며 말했다."
    m "나 서운해."
    scene 01lecture_316-03 at hand_camera with dissolve
    d "ㅋㅋ. 알겠어요."
    d "그냥 예전처럼.."
    scene 01lecture_316-04 at hand_camera with dissolve
    n "그들은 그들의 몸을 밀착시키며 걷기 시작했다."
    scene 01lecture_316-05 at hand_camera with dissolve
    m "이제 [d_name]도 다 컸네"
    m "[d_name]가 원한다면 여기서 지내도 되는데."
    m "이젠 입양 알선을 주로 해서 규모가 줄긴 했어도 기숙 시설은 아직 있어."
    scene 01lecture_316-06 with dissolve
    d "하하. 그럼 아무때나 와도 돼요?"
    d "센터 직원들은 절 보는 것만으로도 피곤함을 느낄거 같은데요 ㅎㅎ"
    scene 01lecture_316-07 with dissolve
    m "하하"
    m "여기는 [d_name]의 집이잖아."
    m "언제든지 와도 돼."
    scene 01lecture_316-08 with dissolve
    n "그녀의 가슴과 허벅지가 [d_name]의 팔에 닿아있었다."
    n "그는 자신의 고추가 터질듯이 커지고 있음을 느꼈다."
    m "그럼 이제 뭐 할 계획이야?"
    scene 01lecture_316-09 with dissolve
    d "여기 있는 동안 사람들도 만나고 인턴쉽도 할거에요."
    d "교수님이 또 여러 사람들을 만나고 인간관계를 넓히라고 숙제를 내주셨거든요."
    scene 01lecture_317 with dissolve
    m "좋은 생각이야."
    m "이제 대학생이니 사회 생활에 첫 발을 딛은거잖아."
    m "마침 내 친구가 운영하는 스타트업 회사가 있는데 한번 지원해볼래?"
    scene 01lecture_318 with dissolve
    d "아 정말요? 그럼 너무 좋죠."
    scene 01lecture_318-01 with dissolve
    m "그래"
    m "내가 친구에게 얘기 해볼게."
    m "하지만 면접은 봐야 할거야."
    scene 01lecture_318-02 with dissolve
    pause
    scene 01lecture_319 at hand_camera with dissolve
    m "하..... 날씨 좋다."
    play voice_f "audio/sex/fsigh02.mp3"
    m "건강해지는 기분이야."
    if in_replay:
        return
    jump v01_park_sex

label v01_park_sex:
    if not in_replay:
        $ persistent.unlock_v01_park_sex = True
    scene 01lecture_320 at hand_camera with dissolve
    m "응?!"
    scene 01lecture_parksex-01 at hand_camera with dissolve
    pause
    scene 01lecture_parksex-02 at hand_camera with dissolve
    pause
    play music "audio/bgm/erotic02.mp3"
    scene 01lecture_320-01 at hand_camera with dissolve
    m "what?"
    image 01lecture_parksexanim01:
        "01lecture_parksex-03" with dissolve
        0.5
        "01lecture_parksex-04" with dissolve
        0.5
        "01lecture_parksex-05" with dissolve
        0.5
        "01lecture_parksex-04" with dissolve
        0.5
        "01lecture_parksex-03" with dissolve
        0.5
        repeat
    scene 01lecture_parksexanim01 at hand_camera
    pause
    play voice_f "audio/voices/fshock01.mp3"
    scene 01lecture_320-02 at hand_camera_zoom
    pause
    scene 01lecture_320-03 with dissolve
    d "응??"
    scene 01lecture_325 with dissolve
    n "[d_name]이 소리가 나는 방향을 보려고 하자 그녀는 재빨리 그의 고개를 자신을 바라보게 했다."
    m "저기 [d_name]!"
    scene 01lecture_325-01 at hand_camera with dissolve
    pause
    scene 01lecture_326 at hand_camera with dissolve
    m "이렇게 다시 봐서 정말 기쁘구나."
    m "이렇게 1년만에 오다니 넌 좀 혼나야해!"
    d "하하하"
    d "이제 그만 혼내셔도 될 나이에요."
    n "아아아아........"
    scene 01lecture_327 with dissolve
    d "무슨 소리지?"
    scene 01lecture_parksex-06 with dissolve
    pause
    scene 01lecture_parksex-07 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_328 with dissolve
    d "!!!!!!!!!!!!"
    scene 01lecture_parksex-07 at hand_camera with Dissolve(0.8)
    n "그가 소리가 나는 방향을 바라보자 나무 뒤에서 커플이 오랄섹스를 하고있었다."
    scene 01lecture_parksex-08 with Dissolve(1.5)
    pause
    scene 01lecture_parksex-09 with Dissolve(1.5)
    pause
    image 01lecture_parksexanim02:
        "01lecture_parksex-10" with dissolve
        0.6
        "01lecture_parksex-11" with dissolve
        0.6
        repeat
    scene 01lecture_parksexanim02 with dissolve
    pause
    image 01lecture_parksexanim03:
        "01lecture_parksex-12" with dissolve
        0.6
        "01lecture_parksex-13" with dissolve
        0.6
        repeat
    scene 01lecture_parksexanim03 with dissolve
    pause
    scene 01lecture_328-01 at hand_camera with dissolve
    pause
    image 01lecture_parksexanim04:
        "01lecture_parksex-14" with dissolve
        0.6
        "01lecture_parksex-15" with dissolve
        0.6
        repeat
    scene 01lecture_parksexanim04 with dissolve
    pause
    scene 01lecture_328 with dissolve
    d ".............."
    scene 01lecture_328-02 with dissolve
    n "자신의 허벅지에 무언가를 느낀 [d_name]이 고개를 내렸다."
    d ".............."
    image 01lecture_parkhand01:
        "01lecture_329" with dissolve
        0.6
        "01lecture_330" with dissolve
        0.6
        repeat
    scene 01lecture_parkhand01 with dissolve
    pause
    image 01lecture_parksexanim05:
        "01lecture_parksex-16" with dissolve
        0.2
        "01lecture_parksex-17" with dissolve
        0.2
        repeat
    scene 01lecture_parksexanim05 with dissolve
    pause
    image 01lecture_parkhand02:
        "01lecture_329-01" with dissolve
        0.6
        "01lecture_330-01" with dissolve
        0.6
        repeat
    scene 01lecture_parkhand02 with dissolve
    pause
    scene 01lecture_parksex-18 with dissolve
    pause
    scene 01lecture_parksex-19 with dissolve
    pause 1.0
    scene 01lecture_parksex-20 with dissolve
    pause
    scene 01lecture_328-02 with dissolve
    d "뭐?"
    scene 01lecture_328-03 with dissolve
    d "......."
    d "메리....."
    scene 01lecture_331 with dissolve
    m "응?"
    m "그만 돌아갈까?"
    scene 01lecture_331-01 with dissolve
    m "............"
    m "왜 그래?"
    scene 01lecture_332 at hand_camera with dissolve
    m "..............."
    scene 01lecture_329 at hand_camera with vpunch
    pause
    scene 01lecture_333 at hand_camera with vpunch
    play voice_f "audio/voices/fshock01.mp3"
    m "!!!!!!!!!!!!!!!!!!!"
    scene 01lecture_334 with dissolve
    m "앗!!"
    m "미안해 honey!"
    m "나도 모르게 그만...."
    m "난 그저 너의 허벅지에 손을 올렸을 뿐이야."
    scene 01lecture_337 at hand_camera with dissolve
    d "아니에요 괜찮아요 mary."
    pause
    if in_replay:
        return
    jump v01_park_lovers

label v01_park_lovers:
    if not in_replay:
        $ persistent.unlock_v01_park_lovers = True
    scene 01lecture_337-01 at hand_camera with dissolve
    n "인기척을 느낀 그들이 바라보자 그 커플들이 다가오고 있었다."
    scene 01lecture_337-02 at hand_camera with dissolve
    pause
    scene 01lecture_337-03 at hand_camera with dissolve
    pause
    scene 01lecture_337-04 at hand_camera with dissolve
    pause
    scene 01lecture_337-05 at hand_camera with dissolve
    pause
    play music "audio/bgm/erotic03.mp3"
    scene 01lecture_337-06 at hand_camera with dissolve
    n "그 커플은 그들 앞에 멈춰서 말을 걸어왔다."
    unknownf "거기 안녕."
    scene 01lecture_337-06-01 at hand_camera with dissolve
    m "안녕하세요."
    scene 01lecture_337-07 at hand_camera with dissolve
    unknownf "정말 아름다운 날이야. 그렇죠?"
    unknownf "너희 둘 정말 잘어울리네요."
    unknownf "우리 처럼 연상연하 커플이네요."
    unknownf "공원 데이트 하러 온거에요?"
    scene 01lecture_337-08 at hand_camera with dissolve
    m "뭐라고요? 연인이요?"
    m "그 말은 무례하네요."
    m "우리는 그저.."
    scene 01lecture_337-09 at hand_camera with dissolve
    unknownf "괜찮아요. ㅎㅎ"
    unknownf "방해할 생각은 없어요."
    unknownf "그저 보기 좋은 커플에게 인사하고 싶었을 뿐이에요."
    unknownf "엄마와 아들은 아니잖아요?"
    scene 01lecture_337-10 at hand_camera with dissolve
    m "나는..........."
    m "나는 한 때 그의 보호자이자 선생님이었어요."
    m "그리고 당신에게 왜 이걸 설명해야 하는지 모르겠네요."
    m "연인이라니 당치도 않는 소리에요."
    scene 01lecture_337-07 at hand_camera with dissolve
    unknownf "아 그런가요? 불편했다면 사과할게요."
    unknownf "그런 관계치고는 너무 밀착해서 앉은거 아니에요? 하하"
    unknownf "...................."
    unknownf "그거 알아요?"
    scene 01lecture_337-07-01 at hand_camera with dissolve
    unknownf "우릴 계속 보고 있었다는거 알아요."
    unknownf "처음 부터 끝까지 모두다요."
    scene 01lecture_337-11 at hand_camera with dissolve
    play voice_f "audio/voices/fshock01.mp3"
    n "Mary는 예상치 못한 그녀의 말에 순간 당황했다."
    m "!!!!!!!"
    m "그건..."
    scene 01lecture_337-09 at hand_camera with dissolve
    unknownf "괜찮아요. ㅎㅎ"
    unknownf "오히려 더 흥분되고 좋았는걸요."
    unknownf "누군가 보고 있다는게 이렇게 나를 흥분시키는지 처음 알았어요."
    scene 01lecture_337-07 at hand_camera with dissolve
    n "그녀는 잠시 망설이더니 다시 말을 이어갔다."
    unknownf "어땠어요?"
    unknownf "당신도 흥분 됐나요?"
    unknownf "옆의 청년과 한 몸이 되는 상상을 했어요?"
    unknownf "이 청년의 자지가 당신의 구멍을 가득 채우는 생각을 했어요?"
    scene 01lecture_337-12 at hand_camera with dissolve
    m "지금 무슨 소리를 하는거에요?!!!"
    m "저리 가세요."
    m "안그럼 당장 경찰을 부를거에요."
    scene 01lecture_337-13 at hand_camera with dissolve
    unknownm "워워"
    unknownm "진정하세요 여사님."
    scene 01lecture_337-14 at hand_camera with dissolve
    unknownm "나쁜 뜻은 없었어요."
    unknownm "우린 그저 두 사람이 잘 맺어지길 바라는거에요."
    unknownm "그렇게 가까이 앉은거 보면 이미 남녀관계인거 같은데요?"
    unknownm "나이가 많든 적든 지금 아니면 영원히 아닌거에요."
    unknownm "서로를 좋아하는데 숨기고 있다는 느낌이 들어요."
    unknownm "내가 볼땐 청년은 지금 내말에 동의할거 같은데요? 하하하"
    scene 01lecture_337-15 at hand_camera with dissolve
    n "[d_name]은 남성의 말에 난감한 표정을 지었다."
    d "............."
    scene 01lecture_337-16 at hand_camera with dissolve
    n "Mary는 그들의 말에 별다른 반응을 보이지 않는 [d_name]이 이상했다."
    m "what?"
    m "[d_name]. 왜 말이 없니?"
    m "너도 이 사람들이랑 같은 생각인거야?"
    m "나랑?"
    m "맙소사.너 정말 그렇게 생각하는거야?"
    d ".........................................."
    scene 01lecture_337-14-01 at hand_camera with dissolve
    unknownm "거봐요 하하하."
    unknownm "당신 처럼 매력있는 여성을 어떤 남자가 좋아하지 않겠어요."
    unknownm "당신을 보는 이 청년의 눈 빛만 봐도 안다구요."
    unknownm "그 매력은 큰 이점이에요."
    scene 01lecture_337-10 at hand_camera with dissolve
    m "그런 소리 하지 마세요."
    m "난 당신들 처럼 본능만 따라서 살진 않는다구요."
    m "난 그냥 평범한 가정주부에요."
    scene 01lecture_337-09 at hand_camera with dissolve
    unknownf "저도 마찬가지에요. 나도 평범한 가정 주부에요."
    unknownf "나도 당신 처럼 평생을 무언가 갈망하는 불쌍한 여인이었어요."
    unknownf "그러다 인생은 너무도 짧고 이대로 살다 늙어 죽는건 나 자신에 대한 학대라는걸 깨닫고는 마음을 바꿨어요."
    scene 01lecture_337-06 at hand_camera with dissolve
    unknownf "처음 만난 사람에게 오지랖 부린다고 생각하지 않았으면 해요."
    unknownf "예전의 나를 보는거 같아 안타까움에 얘기 한다고 생각해줬으면 해요."
    unknownf "보세요."
    scene 01lecture_337-17-01 at hand_camera with Dissolve(1.5)
    n "그 여성은 갑자기 [d_name]에게로 다가갔다."
    m "이봐요 뭐하는거에요?"
    m "물러서요!"
    scene 01lecture_337-17-02 at hand_camera with dissolve
    unknownf "이 청년의 맑은 눈 빛을 보세요."
    unknownf "때 묻지 않고 순수한 맑은 영혼이 느껴져요."
    unknownf "어떤 여성이 이런 청년과 사랑에 빠지지 않을 수 있을까요?"
    unknownf "봐요. 마음만 먹으면 정말 쉬워요."
    scene 01lecture_337-18 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kisslong02.mp3" loop
    n "그 여성은 단 한 순간의 망설임도 없이 [d_name]의 입술에 자신의 입술을 밀착시켰다."
    n "Mary는 자신의 눈 앞에서 벌어진 일을 믿을 수 없었다."
    scene 01lecture_337-19 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-20 at hand_camera with Dissolve(0.8)
    pause
    image 01lecture_parksexanim06:
        "01lecture_parksex-22" with dissolve
        1.0
        "01lecture_parksex-23" with dissolve
        1.0
        "01lecture_parksex-24" with dissolve
        1.0
        "01lecture_parksex-25" with dissolve
        1.0
        repeat
    scene 01lecture_parksexanim06 with dissolve
    pause
    scene 01lecture_337-21 at hand_camera with dissolve
    n "그 여성은 단 한 순간의 망설임도 없이 [d_name]의 입술에 자신의 입술을 밀착시켰다."
    scene 01lecture_337-22 at hand_camera with dissolve
    pause
    stop voice_f
    scene 01lecture_337-23 at hand_camera with dissolve
    pause
    scene 01lecture_337-24 at hand_camera with dissolve
    pause
    scene 01lecture_337-24-01 at hand_camera with dissolve
    unknownf "키스 잘하네. 맛있어."
    unknownf "........."
    scene 01lecture_337-25 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fshock03.mp3" 
    unknownf "와우"
    unknownf "이래서 이 아름다운 여성이 너에게 빠진거구나."
    unknownf "꽤 준수한 물건을 가지고 있네."
    unknownf "옆의 숙녀분께 보여준적 있니?"
    scene 01lecture_337-26 at hand_camera with Dissolve(0.8)
    n "그 여성은 Mary와 [d_name]앞에서 쭈구리고 앉았다."
    scene 01lecture_337-26-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-27 at hand_camera with Dissolve(0.8)
    n "그 여성은 Mary의 표정을 살피더니 말하기 시작했다."
    unknownf "어때요?"
    unknownf "우리 같이 이 소년에게 잊을수 없는 기억을 만들어 줄까요?"
    scene 01lecture_337-28 at hand_camera with dissolve
    m "......................."
    m "있을수 없는 기억이라니 그게 무슨 말이에요?"
    scene 01lecture_337-29 at hand_camera with dissolve
    n "그 여성의 오른손은 [d_name]의 고추 위에 올라가있었다."
    unknownf "녀석의 자지를 봐요."
    play voice_f "audio/voices/fshock01.mp3" 
    m "뭐라고요?!!!!!!!"
    unknownf "이런건 그냥 넘어가면 안되죠 ㅎㅎ"
    unknownf "이 청년에게도 좋지 않아요."
    scene 01lecture_337-29-01 at hand_camera with dissolve
    unknownf "지금 당신과 함께 이 청년의 젊은 자지를 빨아주고 싶어요."
    m "아니 지금 대체 무슨 말을......"
    unknownf "이 청년에게 진짜 여성의 보살핌이 뭔지 보여주고 싶지 않아요?"
    unknownf "아까 내가 섹스하는걸 보고 이 청년의 자지를 빨고 싶었죠?"
    scene 01lecture_337-30 at hand_camera with dissolve
    play voice_f "audio/voices/fshock01.mp3" 
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    m "당신 미쳤어요?"
    m "어떻게 그런말을....."
    scene 01lecture_337-30-01 at hand_camera with dissolve
    unknownf "아니요. 난 미치지 않았어요."
    unknownf "난 박사 학위까지 가지고 있다구요."
    unknownf "말했잖아요.난 그저 이 아름다운 날, 아름다운 공원에서 너희 둘 처럼 아름다운 커플이 맺어지는 걸 너무나 보고싶다구요."
    unknownf "사랑하는 사람의 성기를 애무해 주는건 지극히 정상이에요."
    unknownf "이 청년의 자지를 봐요. 지금 당신에게 들어가고 싶어 미칠 지경일거에요."
    scene 01lecture_337-30-02 at hand_camera with dissolve
    unknownf "솔찍히 말해봐요"
    unknownf "내가 섹스하는걸 보는 내내 이 청년의 자지를 생각 했잖아요."
    n "그 여성은 말을 하며 자신의 왼손을 Mary의 치마 속으로 슬그머니 넣었다."
    scene 01lecture_337-30-03 at hand_camera with dissolve
    unknownf "이 청년은 내거야."
    unknownf "이 청년은 나만 가질 수 있어."
    unknownf "지금 당장 이 청년의 자지를 빨고 싶지만 때를 기다릴 뿐이야."
    unknownf "내가 허락만 하면 이 청년은 나의 입에 그의 자지를 밀어 넣을꺼야."
    scene 01lecture_337-30-04 at hand_camera with dissolve
    pause
    scene 01lecture_337-30-05 at hand_camera with dissolve
    m "내 몸에서"
    m "당장"
    m "쏜 떼요!!"
    m "그렇지 않으면 경찰을 부르겠어요."
    scene 01lecture_337-27 at hand_camera with dissolve
    unknownf "알았어요."
    unknownf "내가 약간 서둘렀군요 하하"
    unknownf "당신에겐 시간이 필요하군요."
    unknownf "하지만 너무 시간을 낭비하지 마세요."
    unknownf "이 청년의 자지를 완전히 당신걸로 만들지 않으면 영원히 기회를 잃어버릴거에요."
    scene 01lecture_337-06 at hand_camera with dissolve
    unknownf "그럼 좋은 시간보내요."
    unknownf "인연이 되면 또 볼 일이 있겠죠."
    scene 01lecture_337-09 at hand_camera with dissolve
    unknownf "만약 다음에 또 만난다면 두 사람이 더욱 가까워져 있었으면 좋겠어요."
    unknownf "기억해요."
    unknownf "우리 인생은 고민만 하고 살기엔 너무나 짧다는거."
    scene 01lecture_337-31 at hand_camera with Dissolve(1.5)
    pause
    scene 01lecture_337-32 at hand_camera with Dissolve(1.5)
    unknownf "불편하게 할 생각은 없었어요."
    unknownf "다음에 또 볼 수 있었으면 좋겠어요."
    unknownf "인연이 된다면.."
    if in_replay:
        return
    jump v01_park_flirt

label v01_park_flirt:
    if not in_replay:
        $ persistent.unlock_v01_park_flirt = True
    play music "audio/bgm/normal03.mp3"
    scene 01lecture_337-33 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-34 at hand_camera with Dissolve(0.8)
    n "Mary와 [d_name]은 어떤 일이 일어난건지 믿을 수 없었다."
    n "그들은 그렇게 한 동안 말없이 앉아있을 뿐이었다."
    scene 01lecture_337-35 at hand_camera with dissolve
    pause
    scene 01lecture_337-36 at hand_camera with dissolve
    n "Mary는 그의 손이 자신의 엉덩이 윗부분에 닿아있음을 이제서야 느끼게 되었다."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "미안해 스위티. 괜히 공원에 오자고 해서 미친 사람들을 만나게 됐네."
    m "괜찮니?"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "............."
    d "네 괜찮아요. 저 보다 선생님이 충격 받으셨겠어요."
    scene 01lecture_337-36 at hand_camera with dissolve
    m "..............."
    n "그녀는 잠시 망설이더니 말을 이어갔다."
    m "너....."
    m "정말 내가 여자로 보이니?"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "..........."
    d "그게 무슨...."
    scene 01lecture_337-36 at hand_camera with dissolve
    m "그 남자가 했던말."
    m "너도 같은 생각이야?"
    m "나이가 많든 적든...."
    scene 01lecture_337-38 at hand_camera with dissolve
    d "..........."
    d "mary는 상냥하고 아름다워요."
    d "모두가 좋아하잖아요."
    d "저도 그렇고요."
    scene 01lecture_337-37 at hand_camera with dissolve
    n "그녀는 잠시 [d_name]을 바라보았다."
    n "그녀의 얼굴은 약간 상기 돼 있었다."
    m "아니 그런 의미가 아니라.."
    m "......................."
    scene 01lecture_337-34 at hand_camera with dissolve
    m "나에게 성적인 감정을 느꼈는지 묻는거야."
    m "정말 내가 여자로 보이는거야?"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "..........."
    d "네 맞아요."
    play voice_f "audio/voices/fshock02.mp3" 
    scene 01lecture_337-37 at hand_camera with dissolve
    m "........................"
    m "아니 어떻게.."
    m "언제부터?"
    scene 01lecture_337-34 at hand_camera with dissolve
    d "모르겠어요."
    d "왜 그런거 있잖아요."
    d "살면서 내가 아는 사람들이 아무때나 문득문득 떠오르잖아요. 잠깐씩이라도."
    d "언제부턴가 메리를 떠올리면 선생님이나 보호자가 아니라 매력있는 여성이라고 느껴졌어요."
    scene 01lecture_337-30-05 at hand_camera with dissolve
    m "........................"
    m "[d_name]......."
    scene 01lecture_337-54 at hand_camera with dissolve
    d "아마 제 착각일 수도 있어요."
    d "제가 성인이 되고 성적으로 왕성해지면서 모든 여성에게 그런 감정을 가질 수도 있잖아요."
    d "그래서 메리가 저의 머릿속에서 선생님이 아니라 여성의 카테고리로 옮겨진거 같아요."
    scene 01lecture_337-34 at hand_camera with dissolve
    d "그냥 이런 얘기를 시작하지 않았으면 제 안에서만 간직했을 감정이었는데..... "
    d "미안해요 메리."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "아니야 [d_name]."
    m "사과하지 않아도 괜찮아."
    m "솔찍하게 얘기 해줘서 고마워."
    m "나도 [d_name]이 건강하게 잘 자란 매력있는 청년이라고 생각해."
    m "방금 저들이 한 얘기는 절대 마음에 담아두지마."
    m "저들 처럼 원하는대로 살면, 특히 섹스에 있어서 난잡하게 살면 너의 정신과 몸이 반드시 상처를 받을거야."
    scene 01lecture_337-34 at hand_camera with dissolve
    m "맙소사."
    m "누가 누굴걸 빨고, 무슨 구멍으로 뭐가 들어간다니."
    m "미친 사람들. 처음 본 사람들에게 대체 무슨 말을 지껄이는건지."
    m "상상이 되니 [d_name]?"
    m "내가 너에게 블로우잡을 해준다는게?"
    scene 01lecture_337-34-01 at hand_camera with dissolve
    d "네?!!!!!"
    d "블로우잡이요?!!!"
    scene 01lecture_337-34 at hand_camera with dissolve
    m "맙소사."
    m "아니 그렇게 한다는게 아니라 가정을 물어본거잖아."
    scene 01lecture_337-38 at hand_camera with dissolve
    d "....................."
    n "무언가 말하고 싶던 [d_name]은 한 참을 고민하고 이윽고 말을 했다."
    d "상상한적 있어요."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "뭐?"
    m "상상한적 있다니."
    m "무슨 상상을 했다는 소리야?"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "..........."
    d "메리가 저의 자지를 빨아주는 상상이요."
    play voice_f "audio/voices/fshock01.mp3" 
    scene 01lecture_337-59 at hand_camera with dissolve
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    n "Mary는 방금 자신이 들은 말을 믿을 수 없었다."
    m "내가 너의 자......."
    m "와우 [d_name]."
    m "당황스러울 정도로 솔직하구나."
    m "오늘 너의 새로운 모습을 보게됐네."
    scene 01lecture_337-34 at hand_camera with dissolve
    d "기분 나빠하지 않으셨으면 해요.메리."
    d "제 또래 남자들은 일어나서 잘 때 까지 온통 섹스 생각 뿐이잖아요."
    d "사실 이런 얘기 하지 않았어도 되는거 알아요."
    d "하지만 이런 얘기가 나온이상 메리에게 만큼은 숨기지 않고 싶었어요."
    scene 01lecture_337-54 at hand_camera with dissolve
    d "그게 저와 메리 사이의 오랜 규칙이잖아요."
    d "메리에게 거짓말 하지 않기."
    scene 01lecture_337-38 at hand_camera with dissolve
    d "선생님은요?"
    d "선생님은 제 자지를 빠는 생각을 해본적 있어요?"
    play voice_f "audio/voices/fshock01.mp3" 
    scene 01lecture_337-34-02 at hand_camera with dissolve
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    m "워워 저기 아저씨. 너 지금 그게 무슨 말이야?"
    scene 01lecture_337-16 at hand_camera with dissolve
    d "그냥 물어본거에요."
    d "오늘 뭔가 미친 날인거 같지 않아요?"
    d "선생님의 벗은 몸도 보고.."
    d "이런 대화도 하고 있잖아요."
    d "저도 선생님이 저에게 거짓말 하지 않았으면 해요."
    d "......................."
    d "화났으면 미안해요..."
    scene 01lecture_337-34 at hand_camera with dissolve
    m "미안해 허니. 화낸건 아니야."
    m "사실은...."
    scene 01lecture_337-55 at hand_camera with dissolve
    n "그들은 서로의 다리가 닿아있는 것도 느끼지 못하고 있었다."
    n "아니면 그들 모두 서로의 피부의 감촉을 즐기고 있는 것인지도 모른다."
    n "그들이 느끼던 안정감은 지금 약간의 성적 흥분으로 바뀌고 있었다."
    m "................................."
    m "나도 상상해본적 있어."
    m "................................."
    m "있잖아. 너의....."
    scene 01lecture_337-60 at hand_camera with dissolve
    m "너의 자....."
    m "너의 그 물건을...."
    m "내 입에 넣는 상상을 말이야..."
    m "............."
    scene 01lecture_337-30-05 at hand_camera with dissolve
    m "맙소사..."
    m "이거 마치 고해성사 하는 기분이네."
    m "................"
    m "네가 방금 한 말 때문에 거기에 맞춰주려고 하는 얘기는 아냐."
    m "나도 너와 비슷해 [d_name]."
    scene 01lecture_337-56 at hand_camera with dissolve
    m "정말 그렇게 하고싶다기보다 어짜피 일어날 일이 아니기에 머릿속으로 일탈을 하는거야."
    m "다들 겉으론 고상한 척 해도 결국 속으론 온갖 더러운 생각을 하는게 사람이야."
    m "미안해 허니."
    scene 01lecture_337-30-04 at hand_camera with dissolve
    d "아니에요 메리. 전혀 더럽지 않아요."
    d "지금 이 공원에 있는 모든 사람들..."
    d "운동도 하고, 즐겁게 얘기하고, 걷고....."
    scene 01lecture_337-54 at hand_camera with dissolve
    d "다들 괜찮은 사람들일지 모르지만 무슨 생각을 하는지 아무도 몰라요."
    d "모두들 그렇게 자신의 상상속에선 완전한 자유를 얻는거에요."
    d "메리가 어떤 생각을 하든, 저에게 무슨 말을 하든 메리는 저에게 최고의 선생님이에요."
    scene 01lecture_337-44 at hand_camera with Dissolve(1.5)
    m "와우 [d_name]."
    m "정말 이제 어른이 다 됐구나."
    m "이제 내가 [d_name]에게 배워야겠어."
    m "고마워 허니."
    m "오늘 [d_name]이 나에게 멋진 남자로 보이네."
    n "그녀는 자신의 충격 적인 고백을 자연스럽게 흘려보내준 [d_name]이 고마웠다."
    scene 01lecture_337-38 at hand_camera with dissolve
    d "그러니까 자신이 어떤 생각을 한다해도 스스로 평가하지 말아요."
    d "생각은 우리가 통제할 수 없는거에요."
    scene 01lecture_337-44 at hand_camera with dissolve
    m "그래. [d_name]"
    m "그럼 우리 또 하나 약속을 만들까?"
    m "서로 거짓말 하지 않기로 약속 한것 처럼."
    scene 01lecture_337-44-01 at hand_camera with dissolve
    d "좋아요 메리. ㅎㅎ"
    d "어떤 약속을 할까요?"
    scene 01lecture_337-44 at hand_camera with dissolve
    m "어떤 생각을 하는지 물어보면 알려주기."
    m "어때?ㅎㅎ"
    scene 01lecture_337-44-01 at hand_camera with dissolve
    d "알겠어요. 약속 해요."
    d "와우 이거 거짓말 하지 않기와 결합 되니까 엄청 강력한 약속인데요?"
    d "무슨 생각하는지 물어보면 무조건 진실을 말해주기가 되네요."
    scene 01lecture_337-44 at hand_camera with dissolve
    m "어머. 정말 그렇게 되네 ㅎㅎ"
    m "그럼 지금 당장 서로 물어볼까?"
    m "지금 무슨 생각하니 [d_name]?"
    scene 01lecture_337-38 at hand_camera with dissolve
    n "Mary의 질문은 그다지 좋은 타이밍이 아니었다."
    n "아니면 그녀의 질문엔 어떤 의도가 있는 것으로 느껴질 수 있었다."
    d "앗..............."
    d "그게 저....."
    scene 01lecture_337-44 at hand_camera with dissolve
    m "뭐야 방금 약속했는데 처음부터 약속을 어길거야?"
    m "우리 사이에 못할 말이 어디있니?"
    m "말해봐. 오늘 우리 많은 선을 넘었잖아 ㅎㅎ"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "(Is she leading me on, knowing what I’m about to say?)"
    d "................."
    scene 01lecture_337-54 at hand_camera with dissolve
    d "메리와 키스하는 생각이요."
    scene 01lecture_337-44 at hand_camera with dissolve
    m "그래? 귀엽네."
    d "아니...................."
    d "선생님이 생각하는 그런 키스가 아니라요...."
    scene 01lecture_337-16 at hand_camera with dissolve
    d "연인 사이에 하는 키스....."
    d "혀로요......."
    play voice_f "audio/voices/fshock02.mp3" 
    scene 01lecture_337-34 at hand_camera with dissolve
    m "!!!"
    m "그렇구나.."
    m "그래 뭐 그런 생각 충분히 할 수 있지."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "................................."
    m "또 다른 생각은?"
    scene 01lecture_337-38 at hand_camera with dissolve
    d "................."
    d "(This feels risky to say... even in this mood, she might get angry.)"
    pause
    d "아까 센터에서 봤던...."
    d "메리의 몸이요..."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "!!!!!!!"
    m "그렇구나.."
    scene 01lecture_337-30-04 at hand_camera with dissolve
    d "메리는요?"
    d "지금 무슨 생각하고 있어요?"
    scene 01lecture_337-30-05 at hand_camera with Dissolve(1.5)
    m ".............."
    m "나.....나는...."
    scene 01lecture_337-30-04 at hand_camera with dissolve
    m "어서 센터로 돌아가서 남은 일을 마저 해야 한다는 생각하고 있었어."
    scene 01lecture_337-34 at hand_camera with dissolve
    d "............"
    d "정말이에요?"
    scene 01lecture_337-37 at hand_camera with dissolve
    m ".............."
    scene 01lecture_337-30-04 at hand_camera with dissolve
    m ".............."
    m "사실은......"
    scene 01lecture_337-34-01 at hand_camera with Dissolve(1.5)
    m "사실은 나도 너의 몸을 생각했어."
    m "너의 그......자...."
    m "자지......."
    m "를 내 입으로......"
    m "내 얼굴과 입 안에 가득 너의"
    scene 01lecture_337-34-01 at hand_camera with dissolve
    d "!!!!!!!!!!"
    n "Mary의 대답에 [d_name]은 자신의 귀를 의심했다."
    n "자신이 지금까지 살아오면서 들은 가장 충격적이며 야한 말이었다."
    play voice_f "audio/voices/fshock01.mp3" 
    scene 01lecture_337-45 at hand_camera with dissolve
    m "어머 나 지금 뭐래니?"
    m "미안해 [d_name]!"
    m "거짓말이야."
    m "아니 거짓말한거 아니야."
    scene 01lecture_337-46 at hand_camera with dissolve
    m "하.................."
    m "미안해 [d_name]"
    m "1년만에 만났는데 이게 무슨 일이지?"
    m "너는 나에게 아들이나 다름 없는데.."
    scene 01lecture_337-47 at hand_camera with dissolve
    d "괜찮아요 메리."
    d "저도 아까 말했잖아요."
    d "................"
    d "사실 메리만 생각하는거 아니에요."
    scene 01lecture_337-48 at hand_camera with dissolve
    m "............."
    m "나만 생각하는게 아니라는게 무슨 말이야?"
    scene 01lecture_337-47 at hand_camera with dissolve
    d "사실...."
    d "제가 아는 거의 모든 여자들의 몸을 상상하곤 해요."
    scene 01lecture_337-48 at hand_camera with dissolve
    m "오케이 [d_name]."
    m "나 별로 안놀랐어. 네 또래 남자들, 아니 세상 모든 남자들이 하루종일 여자 생각한다는거잖아."
    scene 01lecture_337-47 at hand_camera with dissolve
    d ".........................."
    d "Amanda도 포함이에요."
    play voice_f "audio/voices/fshock02.mp3" 
    scene 01lecture_337-49 at hand_camera with dissolve
    m "!!!!!!!!!!!!!!!!!!!"
    m "아....."
    m "아만다?"
    m "너의 양어머니?"
    scene 01lecture_337-48 at hand_camera with dissolve
    d "네..............."
    scene 01lecture_337-49 at hand_camera with dissolve
    n "그녀는 애써 충격받은 내색을 하지 않으며 말을 꺼냈다."
    m "무슨 생각을 했는데?...."
    scene 01lecture_337-50 at hand_camera with dissolve
    d "뭐 있잖아요."
    d "지금까지 우리가 대화한 비슷한 성격의 것들이요...."
    d "아만다가 내 자지를 어루만져주고 입으로 해주고... 그런것들이요..."
    scene 01lecture_337-49 at hand_camera with dissolve
    m "..................."
    m "아만다도 여자로 보인다는 말이니?"
    scene 01lecture_337-48 at hand_camera with dissolve
    d "아뇨 그건 좀 달라요."
    d "뭐랄까....."
    scene 01lecture_337-54 at hand_camera with dissolve
    d "그렇기도 하고 아니기도 한데....."
    scene 01lecture_337-47 at hand_camera with dissolve
    d "아 모르겠요."
    d "그냥 언제부턴가 그렇게 됐어요."
    d "......................."
    scene 01lecture_337-51 at hand_camera with dissolve
    m "............................"
    d "메리, 괜찮아요?"
    show 01lecture_337-51-01 at hand_camera with Dissolve(0.8)
    n "그녀는 [d_name]의 말을 바탕으로 상상하기 시작했다."
    show 01lecture_337-51-02 at hand_camera with Dissolve(0.8)
    n "[d_name]이 그의 양어머니와 성관계를 가지는 상상을 한다는 것이 충격적이었다."
    scene 01lecture_337-52 at hand_camera with dissolve
    d "메리?"
    scene 01lecture_337-53 at hand_camera with dissolve
    d "메리? 왜 그래요?"
    d "뭐라 말좀 해봐요."
    scene 01lecture_337-56 at hand_camera with dissolve
    m ".............."
    m "미안해."
    m "잠시 무슨 생각좀 하느라."
    scene 01lecture_337-37 at hand_camera with dissolve
    m "오늘 내 컨디션이 좀 안좋은거 같아."
    m "오늘 유난히 더운거 같지 않니?"
    scene 01lecture_337-36 at hand_camera with dissolve
    d "네."
    d "저도 평소보다 더운거 같아요."
    m "..............."
    scene 01lecture_337-39 at hand_camera with Dissolve(1.5)
    n "그들은 자연스럽게 밀착해 앉았다."
    n "그리고는 서로의 눈과 입술을 번갈아 가며 바라보았다."
    scene 01lecture_337-40 at hand_camera with Dissolve(0.8)
    n "그리고는 누가 먼저랄 것도 없이 입술을 벌리기 시작했다."
    scene 01lecture_337-41 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-42 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-57 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_337-58 at hand_camera with Dissolve(0.8)
    m "..............."
    m "우리 지금 뭐하는 거지?"
    m "그 커플 때문에 우리 둘다 정신이 흐려진거 같아."
    scene 01lecture_337-43 at hand_camera with dissolve
    pause
    scene 01lecture_338 with dissolve
    m "그럼 이제 그만 돌아갈까?"
    scene 01lecture_339 with dissolve
    d "네 돌아가요 이제..."
    if in_replay:
        return
    jump v01_youthcenter_evening

label v01_youthcenter_evening:
    if not in_replay:
        $ persistent.unlock_v01_youthcenter_evening = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene 01lecture_340 with Dissolve(1.5)
    n "그들은 자리에서 일어나 걷기 시작했다."
    scene 01lecture_341 with Dissolve(1.5)
    n "그들은 한동안 말없이 걷기만 했다."
    n "그들 스스로 생각할 시간이 필요했고.."
    n "아쉬움과 동시에 실수를 하지 않았다는 안도감이 동시에 느껴졌다."
    scene 01lecture_342 with Dissolve(1.5)
    pause
    scene 01lecture_343 with Dissolve(1.5)
    pause


    scene 01lecture_344 with Dissolve(1.5)
    m "그럼 얘야, 금방 다시 와야해? 알았지?"
    scene 01lecture_345 with Dissolve(1.5)
    d "그럼요. 선생님 보러 매일 올게요 ㅎㅎ"
    m "그리고 오늘 있었던 일들은 그냥 잊어버려."
    m "그냥 살면서 경험한 이상했던 하루라고 생각해."
    scene 01lecture_346 at hand_camera with dissolve
    d "알겠어요.메리."
    scene 01lecture_346-01 at hand_camera with dissolve
    d "내가 선생님 사랑하는거 알죠?"
    m "당연하지 [d_name]. 내가 널 얼마나 아끼고 사랑하는데."
    scene 01lecture_346-02 at hand_camera with dissolve
    m "몸도 정신도 이렇게 어엿한 청년이 됐구나 [d_name]."
    m "(....................................)"
    n "[d_name]은 가능한 가까이 그의 몸을 그녀에게 밀착시켰다."
    scene 01lecture_346-03 at hand_camera with dissolve
    play voice_f "audio/voices/fshock03.mp3" 
    m "(Oh boy..his penis keeps poking my belly. )"
    d "(Ha...................)"
    d "(Mary's scent... I feel like I might go crazy... )"
    menu:
        "Lowers the hand.":
            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            scene 01lecture_347 at hand_camera with Dissolve(1.5)
            n "그의 손이 Mary의 엉덩이 윗부분에 아슬아슬하게 내려왔다."
            n "엉덩이의 윗 부분임에도 그는 그녀의 엉덩이골을 느낄수 있었다."
            scene 01lecture_348 at hand_camera with Dissolve(1.5)
            pause
            play voice_f "audio/voices/fshock02.mp3" 
            scene 01lecture_349 at hand_camera with Dissolve(1.5)
            m "........."
            m "(He still seems excited from our earlier conversation.)"
            m "(He’s gotten way too bold. )"
            scene 01lecture_349-01 at hand_camera with Dissolve(1.5)
            pause


            scene 01lecture_346-03 with Dissolve(1.5)
            menu:
                "Lowers the hand further.":
                    if not in_replay:
                        $ add_point("lust_mary", 1, "lust_mary")
                    scene 01lecture_349-02 at hand_camera with Dissolve(1.5)
                    d "..............."
                    n "그의 손이 Mary의 엉덩이 중앙 부분을 완전히 감싸 쥐었다."
                    n "그리고 그의 손가락 끝이 그녀의 엉덩이골을 벌리려는듯 힘이 들어가기 시작했다."
                    m "(What?)"
                    scene 01lecture_349-03 at hand_camera with dissolve
                    pause
                    scene 01lecture_349-04 at hand_camera with Dissolve(1.5)
                    play voice_f "audio/voices/fshock01.mp3" 
                    m "!!!!"
                    m "[d_name]. 손이 너무 내려간거 같아."
                "Stop.":

                    scene 01lecture_347 with dissolve
                    pause   
        "Does not lower the hand.":

            if not in_replay:
                $ add_point("love_mary", 2, "love_mary")
            scene 01lecture_349-01 with dissolve
            pause
            scene 01lecture_346 with dissolve
            pause
    play voice_f "audio/sex/kissshort01.mp3" 
    scene 01lecture_345-01 with dissolve
    m "[d_name]을 봐서 너무 기뻐."
    m "곧 또 와야해 알았지?"
    scene 01lecture_345-02 at hand_camera with dissolve
    d "저도 오늘 좋았어요."
    d "자주 올게요."
    d "(Damn.)"
    d "(I really love Mary’s scent.)"

    menu:
        "Turn your face.":
            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            play voice_f "audio/sex/kissshort01.mp3" 
            scene 01lecture_345-03 with dissolve
            d "(I really love Mary’s scent.)"
            play voice_f "audio/sex/kissshort02.mp3" 
            scene 01lecture_345-04 at hand_camera with dissolve
            pause
            play voice_f "audio/sex/kissshort01.mp3" 
            scene 01lecture_345-05 at hand_camera with dissolve
            m "읍!!"
            m "(내가 실수 한건가?)"
            m "([d_name]이 고개를 돌린건가?)"
            scene 01lecture_345-08 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort02.mp3" 
            m "(!!!!!!!!!!!!!!!!!!!)"
            m "(이 녀석 지금 혀를 움직이는거 같은데?)"
            scene 01lecture_345-09 at hand_camera with dissolve
            m "(오마이갓)"
            m "(밀쳐내야 하나?)"
            m "(이 녀석이 상처 받으면 어떡하지?)"
            scene 01lecture_345-10 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort02.mp3" 
            m "(읍..!!)"
            scene 01lecture_345-11 at hand_camera with dissolve
            n "망설이던 그녀는 [d_name]의 혀가 입안으로 들어오자 고개를 돌렸다."
            scene 01lecture_345-06 at hand_camera with dissolve
            m "미안해 [d_name]."
            m "내가 조준을 잘못했네 ㅎㅎ."
            scene 01lecture_345-12 at hand_camera with dissolve
            d "미안해요 메리"
            d "메리의 향기가 너무 좋아서 저도 모르게그만..."
            scene 01lecture_345-13 at hand_camera with dissolve
            n "그녀는 순간 혼란스러웠다."
            n "버릇없이 행동하는 그를 나무라고 싶었지만 왠지 모르게 그의 장단에 어느정도 맞춰주고 싶었다."
            m "아냐 아냐. 괜찮아."
            m "나도 니가 좋아 스위티."
            m "하지만 사랑의 키스는 미래의 여자친구를 위해 아껴둬."
            m "난 너의 여자가 아니라 선생님이자 보호자야. 알겠지?"
            scene 01lecture_345-14
            d "................."
            d "제 여자가 아니더라도 서로 좋아면 키스할수 있잖아요?"
            scene 01lecture_345-13 at hand_camera with dissolve
            m "뭐?"
            m "ㅎㅎ 허니. 서로 호감이 있다는건 이성으로서 만나는 관계에서라는 얘기야."
            m "나는 너의 선생님이야 [d_name]."
            m "너와 내가 더 가까워진다고 연인이 될 수는 없잖니."
            scene 01lecture_345-12 at hand_camera with dissolve
            d "하지만....."
            d "메리도 아까 얘기 했잖아요...."
            d "제걸 입으로 애무해준는 상상을 한다고 했잖아요."
            scene 01lecture_345-15 at hand_camera with dissolve
            m "!!!!!!!!!"
            m "그건....."
            m "하.......[d_name]."
            m "그건 나의 상상이었을 뿐이야. 그렇다고 우리가 키스해도 된다는건 아니잖아."
            scene 01lecture_345-12 at hand_camera with dissolve
            d "하지만....."
            d ".........."
            d "그럼 제 입술에 키스해줄래요?"
            scene 01lecture_345-15 at hand_camera with dissolve
            m "..............."
            m "알았어. 그럼 이제 집으로 돌아가 허니."
            scene 01lecture_345-13 at hand_camera with dissolve
            m "이제 어두워지는데 그럼 내가 걱정될거야."
            scene 01lecture_345-16 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort01.mp3" 
            n "그녀는 [d_name]의 입술 끝 부분에 키스했다."
            n "순간 그녀의 깊은 곳에서 무엇인가 꿈틀거리는 것을 느꼈다."
            scene 01lecture_345-13 at hand_camera with dissolve
            m "................."
            scene 01lecture_345-14
            d "너무 짧았어요. 한번만 더요."
            scene 01lecture_345-15 at hand_camera with dissolve
            m "..............."
            scene 01lecture_345-17 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort01.mp3" 
            pause 0.5
            scene 01lecture_345-16 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort01.mp3" 
            pause 0.5
            scene 01lecture_345-17 at hand_camera with dissolve
            play voice_f "audio/sex/kissshort01.mp3" 
            pause 0.5
            scene 01lecture_345-18 at hand_camera with dissolve
            m "!!!!"
            n "그녀는 [d_name]의 입술 가장자리에 키스했다."
            n "그리고 그들은 또다시 누가 먼저랄거 없이 서로의 입을 벌렸다."
            scene 01lecture_345-15 at hand_camera with dissolve
            m "허니..."
            m "이제 빨리 집으로 돌아가. 금방 어두워질거야."
            m "........................"
            m "그리고 내 엉덩이좀 놔 줄래?"
            scene 01lecture_345-07 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_345-07-01 at hand_camera with Dissolve(1.3)
            pause
            scene 01lecture_345-07-03 at hand_camera with Dissolve(0.8)
            n "그녀는 그의 손이 자신의 엉덩이를 위로 쓸어올리듯 올라오는것을 느꼈다."
            scene 01lecture_345-07-02 at hand_camera with Dissolve(1.3)
            pause
            scene 01lecture_345-07-04 at hand_camera with dissolve
            n "그리고 그의 손이 자신의 엉덩이에 머물자 그녀는 손을 뻗어 그를 제지했다."


    scene 01lecture_349-05 with Dissolve(2.0)
    c "..........."
    c "저 둘 뭐하는거지?"
    c "너무 스킨십이 진하네."
    c "원래 저정도 했었나?........"
    scene 01lecture_349-06 at hand_camera with dissolve
    m "자 [d_name]."
    m "곧 다시 와야해. 알았지?"
    scene 01lecture_349-07 at hand_camera with dissolve
    c "흠......."
    c "분위기가 좀 그런데."
    c "..........................."
    scene 01lecture_349-08 with Dissolve(2.0)
    pause
    scene 01lecture_349-09 with Dissolve(2.0)
    pause
    if in_replay:
        return
    jump v01_helendrunk

label v01_helendrunk:
    if not in_replay:
        $ persistent.unlock_v01_helendrunk = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night.mp3"
    play sound "audio/ambi/bicycle01.mp3" 
    scene 01lecture_350 with Dissolve(2.0)
    pause
    scene 01lecture_351 with Dissolve(2.0)
    pause
    scene 01lecture_352 with Dissolve(2.0)
    pause
    scene 01lecture_353 with Dissolve(2.0)
    d "응?"
    scene 01lecture_354 with Dissolve(1.0)
    pause
    scene 01lecture_354-01 with Dissolve(1.0)
    n "그가 도착했을때 [h_name]은 거실의 식탁에서 엎드려 있었다."
    n "그녀는 핑크색 운동복 차림이었다."
    scene 01lecture_355 at hand_camera with Dissolve(2.0)
    pause
    d "............"
    scene 01lecture_355-01 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_355-02 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_356 with dissolve
    d "그녀는 취한건가?"
    scene 01lecture_356 with dissolve
    pause
    scene 01lecture_357 with dissolve
    d "맙소사...."
    scene 01lecture_358 with dissolve
    d ".............."
    d "세상 모르고 자는군.."
    scene 01lecture_357 with dissolve
    scene 01lecture_359 with Dissolve(2.0)
    pause
    play voice_f "audio/sex/fsigh03.mp3" 
    scene 01lecture_359-01 with dissolve
    h "응?"
    h "마이클이야?"
    h "아 미안해요 [d_name]."
    scene 01lecture_359-02 with dissolve
    d "괜찬아요 [h_name]?"
    d "많이 피곤해 보여요."
    scene 01lecture_359-03 with Dissolve(2.0)
    h "괜찮아요."
    h "위스키를 조금 마신거 뿐이에요."
    play voice_f "audio/sex/fsigh04.mp3" 
    scene 01lecture_359-04 at hand_camera with dissolve
    d "앗...."
    scene 01lecture_359-05 at hand_camera with dissolve
    d "괜찮아요?"
    d "제가 방까지 부축해 드릴게요."
    scene 01lecture_359-06 at hand_camera with dissolve
    h "아니에요. 내가 혼자 갈 수 있어요."
    h "고마워요 [d_name]."
    scene 01lecture_360 with dissolve
    h "난 들어갈게요."
    h "잘자요"
    scene 01lecture_361 with dissolve
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene 01lecture_362 with dissolve
    pause
    scene 01lecture_363 with Dissolve(1.5)
    d "...................."
    scene black with dissolve
    if lust_helen >= 3:
        scene 01lecture_363-01 with Dissolve(2.0)
        pause
        scene 01lecture_363-02 at hand_camera with Dissolve(2.0)
        pause
        scene 01lecture_363-03 at hand_camera with Dissolve(2.0)
        pause
        if in_replay:
            return
        jump v01_mcshower

label v01_mcshower:
    if not in_replay:
        $ persistent.unlock_v01_mcshower = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    play sound "audio/ambi/shower01.mp3" loop
    scene 01lecture_364 with Dissolve(2.0)
    pause
    scene 01lecture_365 at hand_camera with dissolve
    pause
    scene 01lecture_366 at hand_camera with dissolve
    pause
    scene 01lecture_367 at hand_camera with dissolve
    pause
    scene 01lecture_367-01 with dissolve
    pause
    scene 01lecture_367-02 with dissolve
    pause
    scene 01lecture_367-03 with dissolve
    pause
    scene 01lecture_375 with dissolve
    pause 
    scene 01lecture_367-04 with dissolve
    pause  
    scene 01lecture_367 with dissolve
    d "젠장"
    image 01lecture_bethmaster01:
        "01lecture_368" with dissolve
        0.6
        "01lecture_369" with dissolve
        0.6
        repeat
    scene 01lecture_bethmaster01 at hand_camera
    pause
    scene 01lecture_369-01 with dissolve
    d "아 메리....."
    image 01lecture_bethmaster02:
        "01lecture_367-05" with dissolve
        0.6
        "01lecture_367-06" with dissolve
        0.6
        repeat
    scene 01lecture_bethmaster02 at hand_camera
    pause
    scene 01lecture_369-02 at hand_camera with dissolve
    pause
    play sound "audio/sex/cum01.mp3"
    scene 01lecture_367-07 at hand_camera with dissolve
    pause
    scene 01lecture_367-08 at hand_camera with Dissolve(0.8)
    m "아 가득 뿌려줬구나."
    scene 01lecture_367-09 at hand_camera with Dissolve(0.8)
    m "아 달링. 너무 맛있어."
    scene 01lecture_369-01 with Dissolve(2.0)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    jump v01_mcroom05

label v01_mcroom05:
    play music "audio/bgm/night.mp3"
    scene 01lecture_232 at hand_camera with dissolve
    pause
    scene 01lecture_234 at hand_camera with dissolve
    d "메리 선생님을 만나면 엄마를 만난거 같아.."
    scene 01lecture_235 at hand_camera with dissolve
    pause
    scene 01lecture_369-03 at hand_camera with dissolve
    d "젠장...."
    d "그녀는 정말 아름다운 여성이야...."
    d "............"
    scene 01lecture_369-04 at hand_camera with Dissolve(1.3)
    d "............"
    d "메리....메리...메리...."
    d "내 자지를 빠는 생각을 몇 번이나 했다니.."
    d "그녀도 그런 생각을 했다는게 믿기지가 않아."
    scene 01lecture_369-05 at hand_camera with Dissolve(1.3)
    d "하........."
    d "그녀의 숨결....."
    d "만약 그녀와 키스했다면......"
    scene 01lecture_235 at hand_camera with Dissolve(1.3)
    pause
    d "만약 그녀와 키스했다면...."
    d ".........................."
    d "그녀와 키스했다면 내 자지를 만져줬을까?"
    d "그랬다면 그녀와 나의 관계는 그것으로 끝이겠지."
    d "........................"
    scene 01lecture_235 at hand_camera with Dissolve(1.3)
    pause 1.5

    scene black with dissolve
    if in_replay:
        return
    jump v01_youthcenter_night

label v01_youthcenter_night:
    if not in_replay:
        $ persistent.unlock_v01_youthcenter_night = True
    scene 01lecture_370 with Dissolve(2.0)
    pause
    scene 01lecture_371 with Dissolve(2.0)
    pause
    play voice_f "audio/sex/fsigh04.mp3" 
    scene 01lecture_372 with Dissolve(2.0)
    m "아 피곤하다.."
    m "오늘 너무 많이 걸었나.."
    m ".............."
    scene 01lecture_373 with Dissolve(1.0)
    pause
    scene 01lecture_373-01 with Dissolve(1.0)
    m ".............."
    m "오늘 정말 미친 날이야."
    scene 01lecture_373-02 with Dissolve(1.0)
    m "하........"
    m "[d_name]."
    m "진짜 나랑 키스하려고 했니?"
    scene 01lecture_374 with Dissolve(1.0)
    m ".........."
    scene 01lecture_375 with Dissolve(1.0)
    m ".........."
    scene 01lecture_376 with dissolve
    m "................."
    scene 01lecture_377 with dissolve
    m "[d_name]이 녀석."
    m "대학가서 공부는 안하고 아주 좋은 것들만 배웠네."
    scene 01lecture_378 with dissolve
    m "............"
    m "미친년."
    m "꽤 괜찮은 물건을 가지고 있다고?"
    m "그래. 그건 인정해."
    m "뭐 물론 오늘 직접 본건 아니지만 말이야."
    scene 01lecture_373-03 with dissolve
    m "하하하하"
    m "뭐? [d_name]의 자지를 빨아주는 생각을 했었다고?"
    scene 01lecture_379 with dissolve
    play voice_f "audio/voices/flaugh02.mp3"
    m "메리 너 이 미친 여자야 하하하."
    m "대체 그에게 무슨 말을 지껄인거야 나."
    m "하.........."
    m "왜 당장 날 거칠게 따먹어달라고 얘기하지 그랬냐."
    m "내 구멍을 당장 가득 채워달라고. 허?"
    scene 01lecture_378 with dissolve
    m "[d_name]이 날 대체 어떻게 생각할까...."
    m "그런 소리를 해버렸으니..."
    m "날 다시 보러 올까?....."
    scene 01lecture_380 with dissolve
    n "그녀는 자신의 손가락을 잠시바라보며 생각했다."
    n "아들 같은 그와의 키스를 상상하는 자신이 부끄러웠지만 만약 [d_name]과 키스했다면 그 다음엔 어떤 일이 있었을지에 대한 생각을 떨칠수가 없었다."
    m "......................"
    m "오늘 [d_name]과 키스 했다면 무슨 기분이었을까..."
    m "서로 장난치고 있다는 느낌이 들었을까?"
    m "아니면 불이 확 당겨졌을까?"
    m "............................."
    scene 01lecture_381 with dissolve
    m "그와 키스했다면 그는 나에게 어디까지 요구했을까?"
    m "당연히 내 가슴을 만졌겠지...... 그리고는..."
    m "그의 지퍼를 내리고 빨아 달라고 했을까?"
    m "아니면 그 커플이 있던 나무 뒤로 가자고 했을까?"
    m "그리고는 나의 팬티를 벗겼을까?"
    scene 01lecture_377 with dissolve
    m "하........."
    m "머릿속에서 지워지질 않아..."
    scene 01lecture_377-01 with Dissolve(2.0)
    pause
    scene 01lecture_377-02 with Dissolve(2.0)
    pause
    scene 01lecture_377-03 with Dissolve(2.0)
    pause
    jump v01_mary_bj01



label v01_mary_bj01:

    $ renpy.stop_skipping()
    $ renpy.block_rollback()


    image v01_mary_bj01:
        function v01_mary_bj01
    $ anim_speed = 0.033
    $ last_anim_speed = anim_speed
    $ start_time = 0.0


    scene v01_mary_bj01
    play voice_f "audio/sex/oral02.mp3" loop volume 1.0
    call screen v01_mary_bj01 with dissolve


    image v01_mary_bj01_manual:
        function v01_mary_bj01_manual
    scene v01_mary_bj01_manual



    call screen v01_mary_bj01_manual 


    $ renpy.block_rollback()

label v01_mary_bj02:

    scene 01lecture_383-09 with Dissolve(1.0)
    pause

    image v01_mary_bj02:
        function v01_mary_bj02
    $ anim_speed = 0.033
    $ last_anim_speed = anim_speed
    $ start_time = 0.0

    scene v01_mary_bj02
    play voice_f "audio/sex/kisslong01.mp3" loop volume 1.0
    call screen v01_mary_bj02 with dissolve


    image v01_mary_bj02_manual:
        function v01_mary_bj02_manual
    scene v01_mary_bj02_manual

    call screen v01_mary_bj02_manual


    scene 01lecture_377-11 with Dissolve(1.0)
    pause
    stop voice_f
    play sound "audio/sex/cum01.mp3"
    scene 01lecture_377-12 with Dissolve(1.0)
    pause
    scene 01lecture_377-13 with Dissolve(1.0)
    pause
    jump v01_marywakeup

label v01_marywakeup:
    $ config.allow_skipping = True
    scene 01lecture_382 with Dissolve(2.0)
    m "..........."
    m "정신 차리자 메리야."
    play sound "audio/ambi/phonevib.mp3"
    m "지금 무슨 생각을 하는거야."
    m "너 무슨 문제있니?"
    scene 01lecture_383
    pause
    scene 01lecture_383-01 with Dissolve(1.0)
    pause
    scene 01lecture_383-01-01 with Dissolve(1.0)
    pause
    stop sound
    scene 01lecture_383-02 with Dissolve(2.0)
    n "전화기를 들고 그녀의 남편임을 확인한 그녀는 깊은 한숨을 내쉬었다."
    m "sigh....."
    scene 01lecture_383-03 with Dissolve(1.0)
    m "그래"
    m "오늘 조금 늦어졌어. 이제 퇴근 할거야."
    m "리차드. 미안한데 오늘 저녁은 좀 알아서 챙겨 먹어."
    m "그 정도는 할 수 있잖아?"
    scene 01lecture_383-04 with Dissolve(1.0)
    m "하....."
    m "나 오늘 정말 피곤해."
    m "제발 그렇게 얘기하지 말아줘."
    m "그게 무슨 말이야."
    m "제발 그렇게 날 그렇게 압박하지마."
    scene 01lecture_383-05 with Dissolve(1.0)
    pause
    scene 01lecture_383-06 with Dissolve(2.0)
    pause
    scene 01lecture_383-07 with Dissolve(2.0)
    pause
    scene 01lecture_383-08 with Dissolve(2.0)
    pause
    if in_replay:
        return
    jump v01_mcmary_phone

label v01_mcmary_phone:
    if not in_replay:
        $ persistent.unlock_v01_mcmary_phone_fake = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Shortly after midnight" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night02.mp3"
    scene 01lecture_389 with Dissolve(2.0)
    pause
    scene 01lecture_390 with Dissolve(2.0)
    pause
    scene 01lecture_391 with dissolve
    pause
    scene 01lecture_392 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_393 at hand_camera with Dissolve(0.8)
    n "그녀는 자정이 다 된 시각까지도 잠에 들 수 없었다."
    n "그녀의 머릿속엔 두근거림,흥분,부끄러움,갈증 등 많은 감정들이 뒤섞여 있었다."
    scene 01lecture_236-01 with Dissolve(2.0)
    pause
    play sound "audio/ambi/phonetext.mp3"
    scene 01lecture_236-02 at hand_camera with dissolve
    pause
    scene 01lecture_236-03 at hand_camera with dissolve
    pause
    scene 01lecture_236-04 at hand_camera with Dissolve(0.8)
    pause




    $ phone_start()
    show screen phone_ui
    $ switch_channel_view("mary_dm")

    $ npc_type_and_send("Mary", "Are you asleep?", "mary_dm", typing_time=1.2)
    $ present_phone_choices([("No. I was just lying down to sleep. What about you, Mary?", None, None)], "mary_dm")
    $ npc_type_and_send("Mary", "I’m tired, but I can’t fall asleep.", "mary_dm", typing_time=4)
    $ npc_type_and_send("Mary", "I want you to forget what I said today... you know, about your thing.", "mary_dm", typing_time=4)
    $ npc_type_and_send("Mary", "I can’t believe I said something like that to you...", "mary_dm", typing_time=2)
    $ npc_type_and_send("Mary", "I’ve failed as an adult.", "mary_dm", typing_time=3)

    call screen wait_and_continue(delay=2)






    hide screen phone_ui
    scene 01lecture_236-06 at hand_camera with Dissolve(0.8)
    d "......................"
    d "Damn..."
    d "What should I reply..."
    show screen phone_ui
    scene 01lecture_394 at hand_camera with Dissolve(0.8)
    $ present_phone_choices([("No, I’m the one who did things I shouldn’t have.", None, None)], "mary_dm")
    $ present_phone_choices([("I’m sorry, Mary.", None, None)], "mary_dm")
    $ npc_type_and_send("Mary", "Yeah...", "mary_dm", typing_time=1.5)
    $ present_phone_choices([("I know how much you care about me, Mary.", None, None)], "mary_dm")
    $ present_phone_choices([("I just want you to know how much I love you.", None, None)], "mary_dm")
    scene 01lecture_236-07 at hand_camera with Dissolve(0.8)
    $ npc_type_and_send("Mary", "Of course I know, sweetie.♥️", "mary_dm", typing_time=1.5)
    $ npc_type_and_send("Mary", "Anyway, when we see each other again, I hope things won’t be awkward because of today.", "mary_dm", typing_time=3)
    $ npc_type_and_send("Mary", "And please, drop that obsession with tongues.🙂", "mary_dm", typing_time=2)
    $ present_phone_choices([("Haha, I promise.", None, None)], "mary_dm")
    scene 01lecture_236-08 at hand_camera with Dissolve(0.8)
    $ npc_type_and_send("Mary", "Good.", "mary_dm", typing_time=1.5)
    $ npc_type_and_send("Mary", "Can you send me a photo of your face? I want to use it as your profile picture on my phone.", "mary_dm", typing_time=3)
    show screen phone_dialogue_gate
    d "My face photo? Hmm....."
    hide screen phone_dialogue_gate
    $ present_phone_choices([("Sure, just a moment.", None, None)], "mary_dm")
    hide screen phone_ui

    scene 01lecture_236-08 at hand_camera with Dissolve(0.8)
    d "Why is she asking for a photo at this hour?"
    d "Hmm....."

    menu:
        n "What should I do?"
        "Send a normal face photo.":
            if not in_replay:
                $ add_point("love_mary", 3, "love_mary")
            show screen phone_ui
            $ send_phone_message(phone_config["phone_player_name"], "images/phone/shots/10.jpg", "mary_dm", 2, do_pause=False)

            $ npc_type_and_send("Mary", "Did you go hiking? Hehe, your smile looks the best.", "mary_dm", typing_time=1.5)
            scene 01lecture_395 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Yes. I’ve gotten into outdoor activities lately.", None, None)], "mary_dm")
            $ present_phone_choices([("Would you like to go with me sometime?", None, None)], "mary_dm")
            scene 01lecture_236-08 at hand_camera with Dissolve(0.8)
            $ npc_type_and_send("Mary", "That’s a great idea. It’ll be really good for you.", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Let’s definitely go together next time!!", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Wow, it’s already this late. Let’s get some sleep.", "mary_dm", typing_time=1.5)
            scene 01lecture_396 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Okay, I will.", None, None)], "mary_dm")
            $ present_phone_choices([("I love you, Mary.", None, None)], "mary_dm")
            $ npc_type_and_send("Mary", "Love you, sweetie. ♥️", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Good night.", "mary_dm", typing_time=1.5)
            call screen wait_and_continue(delay=2)
            hide screen phone_ui
        "Send a shirtless photo.":

            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            show screen phone_ui
            $ send_phone_message(phone_config["phone_player_name"], "images/phone/shots/12.jpg", "mary_dm", 2, summary_alt="My face photo", do_pause=False)
            $ switch_channel_view("mary_dm")
            $ npc_type_and_send_hesitate("Mary", "Wow, [d_name]. Why did you send this photo?", "mary_dm", typing_time=3, loops=2)
            scene 01lecture_397 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Ah, sorry. I sent the wrong photo.", None, None)], "mary_dm")
            $ present_phone_choices([("See? I told you, I’ve gotten a lot healthier.", None, None)], "mary_dm")
            $ present_phone_choices([("I used to be really weak when I was a kid.", None, None)], "mary_dm")
            $ npc_type_and_send_hesitate("Mary", "Haha, good job, honey.", "mary_dm", typing_time=3, loops=2)
            $ npc_type_and_send("Mary", "I’m glad to see you looking healthy.🙂", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "You definitely look bigger now!", "mary_dm", typing_time=1.5)
            $ present_phone_choices([("Wait a second. I’ll send you a face photo.", None, None)], "mary_dm")
            $ send_phone_message(phone_config["phone_player_name"], "images/phone/shots/10.jpg", "mary_dm", 2, do_pause=False)

            $ npc_type_and_send("Mary", "Did you go hiking? Hehe, your smile looks the best.", "mary_dm", typing_time=1.5)
            if not in_replay:
                $ add_point("love_mary", 1, "love_mary")
            scene 01lecture_395 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Yes. I’ve gotten into outdoor activities lately.", None, None)], "mary_dm")
            $ present_phone_choices([("Would you like to go with me sometime?", None, None)], "mary_dm")
            scene 01lecture_236-08 at hand_camera with Dissolve(0.8)
            $ npc_type_and_send("Mary", "That’s a great idea. It’ll be really good for you.", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Let’s definitely go together next time!!", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Wow, it’s already this late. Let’s get some sleep.", "mary_dm", typing_time=1.5)
            scene 01lecture_396 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Yes. Good night, Mary.", None, None)], "mary_dm")
            $ npc_type_and_send("Mary", "Good night, sweetie.", "mary_dm", typing_time=1.5)
            call screen wait_and_continue(delay=2)
            hide screen phone_ui
            jump v01_mcmary_phone_branch

label v01_mcmary_phone_branch:
    if lust_mary >= 6:
        jump v01_mary_shock
    else:
        jump v01_mcroom06

label v01_mary_shock:
    scene 01lecture_236-06 at hand_camera with Dissolve(0.8)
    d "Damn, I can’t get what she said earlier today out of my head."
    d "This is driving me crazy."
    scene 01lecture_236-10 at hand_camera with Dissolve(0.8)
    d "............."
    d "She said she imagined sucking my cock..."
    d "........."
    d "What would her reaction be if I showed her mine?"
    d "Would she think I'm a pervert?"
    d "She clearly said she fantasizes too. It's just a picture, what's the big deal?"
    d "........................."
    scene 01lecture_236-11 at hand_camera with Dissolve(0.8)
    d "Damn it... Whatever happens, happens."
    d "Mary's an adult and so am I..."
    scene 01lecture_236-12 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/camera.mp3"
    d "Are you really going to do this?"
    show screen phone_ui
    $ send_phone_message(phone_config["phone_player_name"], "images/chapter01/05 - h.house/13.webp", "mary_dm", 2, do_pause=False)
    call screen wait_and_continue(delay=2)
    if not in_replay:
        $ add_point("lust_mary", 3, "lust_mary")
    hide screen phone_ui
    play voice_f "audio/voices/fshock01.mp3"
    play music "audio/bgm/erotic03.mp3"
    scene 01lecture_398 at hand_camera with Dissolve(0.8)
    n "그녀는 [d_name]이 전송한 사진을 보고 충격에 빠졌다."
    n "첫 번째 충격은 그녀가 젊은 시절 보았던 포르노에서나 보던 모양이었고,"
    n "두 번째 충격은 이 것이 [d_name]의 것일지 모른다는 생각 때문이었다."
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    m "What the hell is this?!"
    m "What the hell is he doing?"
    show screen phone_ui
    $ npc_type_and_send_hesitate("Mary", "Oh my... what is this? Is this... your...?", "mary_dm", typing_time=3, loops=2)
    $ npc_type_and_send("Mary", "[d_name]. What is this?", "mary_dm", typing_time=1.5)
    $ present_phone_choices([("I’m sorry, Mary. I sent it by mistake.", None, None)], "mary_dm")
    $ present_phone_choices([("I think I accidentally took that photo while touching my phone.", None, None)], "mary_dm")
    scene 01lecture_403 at hand_camera with Dissolve(0.8)
    $ npc_type_and_send_hesitate("Mary", "This is completely wrong, honey.", "mary_dm", typing_time=3, loops=2)
    $ npc_type_and_send("Mary", "You must never send photos like this to anyone. Ever.", "mary_dm", typing_time=1.5)
    scene 01lecture_400 at hand_camera with Dissolve(0.8)
    $ npc_type_and_send("Mary", "Otherwise, you could get into serious trouble. Do you understand?", "mary_dm", typing_time=1.5)
    scene 01lecture_398 at hand_camera with Dissolve(0.8)
    $ present_phone_choices([("I’m sorry... but I wanted you to know, Mary...", None, None)], "mary_dm")
    $ npc_type_and_send("Mary", "What do you mean, you wanted me to know?", "mary_dm", typing_time=1.5)
    scene 01lecture_404 at hand_camera with Dissolve(0.8)
    $ present_phone_choices([("I’m not a boy anymore.", None, None)], "mary_dm")
    $ npc_type_and_send("Mary", "I know, [d_name]. I know you’re a grown young man now.", "mary_dm", typing_time=1.5)
    $ present_phone_choices([("But even today, you treated me like a kid again.", None, None)], "mary_dm")
    $ present_phone_choices([("Even when I just link arms or hold your hand, I get a boner.", None, None)], "mary_dm")
    $ npc_type_and_send_hesitate("Mary", "I’m sorry, [d_name]. I guess I said something unnecessary to you today.", "mary_dm", typing_time=3, loops=2)
    $ npc_type_and_send("Mary", "There’s such a big gap between the [d_name] I knew and who you are now.", "mary_dm", typing_time=3)
    $ present_phone_choices([("I’m still the same [d_name] you know, Mary.", None, None)], "mary_dm")
    $ present_phone_choices([("I just want you to treat me a little more like an adult.", None, None)], "mary_dm")
    $ npc_type_and_send_hesitate("Mary", "Of course, honey.", "mary_dm", typing_time=3, loops=2)
    $ present_phone_choices([("Please don’t be mad at me.", None, None)], "mary_dm")
    $ npc_type_and_send("Mary", "No, I’m not mad.🙂", "mary_dm", typing_time=1.5)
    $ npc_type_and_send_hesitate("Mary", "Wow, you’re really healthy!", "mary_dm", typing_time=3, loops=2)
    call screen wait_and_continue(delay=2)
    hide screen phone_ui

    scene 01lecture_236-09 at hand_camera with Dissolve(0.8)
    d "You crazy shit. What the hell are you doing?"
    d "Are you trying to end things with Mary today?"
    d "............................."
    d "Oh my god. The damage is already done."
    d "I want to do it again."
    menu:
        "No, stop it now.":
            scene 01lecture_236-09 at hand_camera with Dissolve(0.8)
            d "You idiot… what are you thinking?"
            d "Let's sleep again."
        "One more time!!":
            scene 01lecture_236-13 at hand_camera with Dissolve(0.8)
            play sound "audio/ambi/camera.mp3"
            d "Again...."
            show screen phone_ui
            $ send_phone_message(phone_config["phone_player_name"], "images/chapter01/05 - h.house/14.webp", "mary_dm", 2, do_pause=False)
            call screen wait_and_continue(delay=3)
            if not in_replay:
                $ add_point("lust_mary", 3, "lust_mary")
            hide screen phone_ui
            play voice_f "audio/voices/fshock01.mp3"
            scene 01lecture_399 at hand_camera with Dissolve(0.8)
            m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
            n "두 번째 사진은 그녀에게 처음 보다 더 큰 충격으로 다가왔다."
            n "그 사진의 구도는 [d_name]의 고추와 그의 얼굴이 동시에 담겨있어 보다 더 적나라했다."
            n "시각적 임팩트는 그녀가 그녀의 이성의 끈을 간신히 잡고있게 만들 정도였다."
            m "Oh my god [d_name]!!"
            m "Again?"
            show screen phone_ui
            scene 01lecture_236-07 at hand_camera with Dissolve(0.8)
            $ npc_type_and_send_hesitate("Mary", "I don’t even know what to say.", "mary_dm", typing_time=3, loops=2)
            $ npc_type_and_send("Mary", "Oh my god.", "mary_dm", typing_time=1.5)
            scene 01lecture_399 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("But I saw yours today too.", None, None)], "mary_dm")
            $ present_phone_choices([("That makes us even.", None, None)], "mary_dm")
            scene 01lecture_236-07 at hand_camera with Dissolve(0.8)
            $ npc_type_and_send_hesitate("Mary", "That doesn’t make any sense.", "mary_dm", typing_time=3, loops=2)
            $ npc_type_and_send("Mary", "That was something that happened unintentionally.", "mary_dm", typing_time=1.5)
            $ present_phone_choices([("Anyway, I wanted to make it up to you.", None, None)], "mary_dm")
            $ npc_type_and_send_hesitate("Mary", "It’s late. Go to sleep, [d_name].", "mary_dm", typing_time=3, loops=2)
            $ npc_type_and_send("Mary", "We’ll talk about it later.", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "Good night, honey.", "mary_dm", typing_time=1.5)
            scene 01lecture_397 at hand_camera with Dissolve(0.8)
            $ present_phone_choices([("Wait, let me ask you one thing, Mary.", None, None)], "mary_dm")
            $ npc_type_and_send("Mary", "As long as it’s not a stupid question.", "mary_dm", typing_time=1.5)
            $ present_phone_choices([("What do you think of mine?", None, None)], "mary_dm")
            scene 01lecture_236-14 at hand_camera with Dissolve(0.8)
            $ npc_type_and_send("Mary", "What do you mean by that?", "mary_dm", typing_time=1.5)
            $ present_phone_choices([("My cock.", None, None)], "mary_dm")
            $ present_phone_choices([("Is it close to what you imagined?", None, None)], "mary_dm")
            $ npc_type_and_send_hesitate("Mary", "I... I think so...", "mary_dm", typing_time=3, loops=3)
            $ npc_type_and_send("Mary", "No, no.", "mary_dm", typing_time=1.5)
            $ npc_type_and_send("Mary", "What are you even saying right now...", "mary_dm", typing_time=1.5)
            $ present_phone_choices([("I was just curious what you thought.", None, None)], "mary_dm")
            $ npc_type_and_send_hesitate("Mary", "Let’s talk about it later, okay?", "mary_dm", typing_time=3, loops=2)
            $ npc_type_and_send("Mary", "Oh my god, [d_name]. Go to sleep.", "mary_dm", typing_time=1.5)
            call screen wait_and_continue(delay=2)           
            hide screen phone_ui
            play music "audio/bgm/night02.mp3"
            scene 01lecture_236-09 at hand_camera with dissolve
            pause
            scene 01lecture_236-10 at hand_camera with dissolve
            pause
            d "What the hell did I do?"
            d "This is like exhibitionism."
            scene 01lecture_398 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_400 at hand_camera with Dissolve(2.0)
            m "Oh my god [d_name]."
            n "사진들의 충격은 실로 엄청났다."
            n "그녀는 자신의 보지가 움찔거리고 젖어오는 것을 느꼈다."
            m "............"
            m "You've really bulked up."
            scene 01lecture_399 at hand_camera with Dissolve(2.0)
            m "Oh my god.."
            scene 01lecture_401 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_403 at hand_camera with Dissolve(2.0)
            pause

            if not in_replay:
                $ gallery_images.append({
                    "thumb": "images/chapter01/05 - h.house/13_thumb.jpg",
                    "phone": "images/chapter01/05 - h.house/13.webp",
                })
                $ gallery_images.append({
                    "thumb": "images/chapter01/05 - h.house/14_thumb.jpg",
                    "phone": "images/chapter01/05 - h.house/14.webp",
                })

            scene 01lecture_405 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_406 at hand_camera with Dissolve(2.0)
            n "그녀는 침대에 걸터 앉아 충격을 덜어내려 얼굴을 문질렀다."
            m "Oh my god oh my god oh my god..."
            m "What the hell is going on."
            scene 01lecture_407 at hand_camera with Dissolve(2.0)
            m "Oh no."
            scene 01lecture_408 at hand_camera with Dissolve(2.0)
            m "What the hell is going on here?"
            scene 01lecture_409 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_410 at hand_camera with Dissolve(2.0)
            pause
            scene 01lecture_411 at hand_camera with Dissolve(2.0)
            m "(Damn you, [d_name].)"
            m "(What did you do to me?)"
            scene 01lecture_412 at hand_camera with Dissolve(2.0)
            m "(Was there a true nature hidden behind that innocent face?)"
            scene 01lecture_413 at hand_camera with Dissolve(2.0)
            m "(Oh my god.)"
            m "(Did my words today give him confidence?)"
            scene 01lecture_414 at hand_camera with Dissolve(2.0)
            n "그녀는 다시 폰을 들고 그의 자지 사진을 들여다 보았다."
            n "이번엔 그것의 모양과 색깔, 힘줄 등을 더 자세히 관찰했다."
            n "그리고 자신의 허벅지 안쪽으로 무엇인가 흐르는것을 느꼈다."
            m "Oh my god, oh my god, oh my god..."
            m "............................"
            m "What am I supposed to do..."
            jump v01_mcroom06








label v01_mcroom06:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene 01lecture_384 with Dissolve(2.0)
    pause
    scene 01lecture_385 with Dissolve(2.0)
    pause
    scene 01lecture_386 with Dissolve(2.0)
    pause
    scene 01lecture_385 with dissolve
    scene 01lecture_387 with dissolve
    pause
    scene 01lecture_388 at hand_camera with dissolve
    n "[d_name]이 눈을 뜨자 침대 가장자리에 한 여성이 앉아 무언가 하고 있었다."
    n "그녀는 누구지?"
    n "그녀는 [h_name]일까?"
    n "그녀가 왜 속옷 차림으로 여기에 있는거지?"
    hide screen top_ui_buttons
    jump ch02_droom01
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
