image monologue_film = "images/chapter03/00 - monologue/ch03_monologue_film.jpg"

default ch03_started = False

label ch03_droom01:
    $ ch03_started = True
    if not in_replay:
        $ persistent.unlock_ch03_droom01 = True
    play music "audio/bgm/night04.mp3"

    if not in_replay:
        $ send_phone_message("Jason", "Yo, you ready for this?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Ready for what?", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_01.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "What the hell is this?", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_02.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_03.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Holy shit.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Hahaha. I fucking knew you'd react like that.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Who are they? You actually know them?", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Are you fucking kidding me? Just some shots I caught at the beach.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_04.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_05.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "How's that for your big bro's skills, huh?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "What are you? A fucking ghost or something?", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Hahaha. A little bitch like you would think that.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Goddamn. Show me more.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Want more? Start worshipping me then.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Bro, I'll be your bitch for life. Just send them.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_06.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "What you doing? Jerking off already? Hahaha. Then check this out.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_07.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_08.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "This is absolutely insane.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "I'm pretty sure they're mother and daughter.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Dude, just send the rest. All of them.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Hahaha. Knew it.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_09.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_10.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/ch03_jason_11.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Holy mother of god...", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Hahaha. That's the difference between a rookie and a pro.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Your turn now. If you've got any balls, bring something good to the table.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Alright, alright. Just wait a sec.", "jason_dm", do_pause=False)

        $ send_phone_message("Amanda", "Hey there, Anaconda.🐍", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Anaconda? Where did that come from all of a sudden?", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "It's your new nickname. Hahaha.", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Oh my god, Amanda.", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "Want to meet up somewhere?", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Sure. Where at?", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "The theater could be fun, or maybe a drive to the beach.", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Haha, I'm already looking forward to it!!", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "Alright, I'll be in touch, honey.", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I'll be waiting~", "amanda_dm", do_pause=False)

        $ send_phone_message("sophia", "How are you doing?", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Hello, Professor! I'm doing great.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "How have you been?", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "I'm doing well too. Just checking in to see how my students are spending their time.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Ah, I see. Thank you, Professor.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "Don't just slack off because it's break; make sure you read some books, alright?", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "I'll be checking once we meet again.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Haha, I got it!", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "Good. If anything comes up, or if you just miss me, give me a shout, [d_name].❤️", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yes, Professor. I'll keep in touch.", "sophia_dm", do_pause=False)

        $ send_phone_message("olivia", "Hey, why haven’t you contacted me once?", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I was just about to text you—perfect timing.", "olivia_dm", do_pause=False)
        $ send_phone_message("olivia", "Don’t lie.", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I’m serious.", "olivia_dm", do_pause=False)
        $ send_phone_message("olivia", "What were you going to write?", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "That Olivia is the most beautiful woman in the world.", "olivia_dm", do_pause=False)
        $ send_phone_message("olivia", "Between Amanda and me, who’s sexier?", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Of course, Olivia!!", "olivia_dm", do_pause=False)
        $ send_phone_message("Olivia", "images/phone/media/ch03_olivia_01.jpg", "olivia_dm", 2, summary_alt="olivia Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Holy...", "olivia_dm", do_pause=False)
        $ send_phone_message("olivia", "Hahaha. Cute.", "olivia_dm", do_pause=False)



    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/20_thumb.jpg",
            "phone": "images/phone/shots/20.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/21_thumb.jpg",
            "phone": "images/phone/shots/21.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/22_thumb.jpg",
            "phone": "images/phone/shots/22.jpg",
        })
        $ gallery_images.append({
            "thumb": "images/phone/shots/23_thumb.jpg",
            "phone": "images/phone/shots/23.jpg",
        })

        $ gallery_notif = True

    show screen top_ui_buttons
    scene chapter03_start with Dissolve(2.0)
    pause
    scene ch02_droom02_24 at hand_camera with Dissolve(2.0)
    h "**(그녀는 어디에 있는거지?)**"
    h "**(이 밤중에 어디로 간거야?)**"
    scene ch02_droom02_24-02 at hand_camera with Dissolve(0.8)
    h "**(허?)**"
    scene ch02_droom02_22 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_lena", 2, "lust_lena")
    l "**(저게 내가 진짜로 원하는 거야..)**"
    play voice_f  "audio/sex/fsigh.mp3"
    l "하...그냥 보는것만으로도 내 보지가 움찔거리네."
    scene ch02_droom02_24-02 at hand_camera with Dissolve(0.8)
    h "**(뭐?)**"
    h "**(보지가 움찔거린다고??)**"
    scene ch02_droom02_25 at hand_camera with Dissolve(0.8)
    h "레나! 거기서 뭐해?"
    play voice_f  "audio/voices/fhurt07.mp3"
    scene ch02_droom02_26 with dissolve
    l "**(!!!!!!!!!!!!!!!!!!!!!!!!!!!!)**"
    scene ch02_droom02_27 at hand_camera with Dissolve(0.8)
    h "[d_name] 방 문 열고 뭐해??"
    scene ch02_droom02_28 at hand_camera with Dissolve(0.8)
    d "아 레나!!!!"
    d "아 [h_name]!!!!"
    d "당신의 보지가 너무 타이트해요!!"
    scene ch02_droom02_26 at hand_camera with Dissolve(0.5)
    l "**(조용히해 바보야!!!!!!!!!)**"
    scene ch02_droom02_29 at hand_camera with Dissolve(2.0)
    n "[h_name]은 순간 자신의 귀를 의심했다."
    n "포르노에서 나오는 소음과 [d_name]의 말소리가 섞여 어떤 소리인지 판단이 쉽지 않았지만,"
    n "고요한 정적 사이로 확실히 들을 수 있는 것은 [d_name]이 내뱉는 작은 신음소리였다."
    scene ch03_droom01_01 at hand_camera with Dissolve(0.8)
    l "아 하하...."
    h "여기서 뭐하고 있었어??"
    scene ch03_droom01_02 at hand_camera with Dissolve(0.8)
    l "오해 하지마 베이비."
    l "문이 열려 있어서 지나가다 들여다 본거야."
    scene ch03_droom01_03 at hand_camera with Dissolve(0.8)
    h "..................."
    scene ch03_droom01_04 at hand_camera with Dissolve(0.8)
    h "**(허?)**"
    scene ch03_droom01_05 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fshock02.mp3"
    h "!!!!!!!!!!!!!!!!!!!"
    scene ch03_droom01_06 at hand_camera with Dissolve(0.8)
    d "아 [h_name]!!!!!!"
    d "네 그렇게 더 조여줘요!!!!"
    d "당신을 처음 보자마자 알 수 있었다구요!!"
    d "내 자지를 느껴보고 싶잖아요!!"
    scene ch03_droom01_06-02 at hand_camera with Dissolve(0.8)
    d "당신 안에 한 가득 싸줄게요!!"
    if not in_replay:
        $ add_point("lust_helen", 5, "lust_helen")
        $ add_point("sus_helen", 1, "sus_helen")
    h "**(뭐라고?!!!!)**"
    l "..............."
    scene ch03_droom01_07 at hand_camera with Dissolve(0.8)
    l "하..........."
    l "완벽하다 완벽해."
    scene ch03_droom01_08 at hand_camera with Dissolve(0.8)
    h "...................."
    h "**(맙소사.......)**"
    scene ch03_droom01_08-02 at hand_camera with Dissolve(0.8)
    h "...................."
    scene ch03_droom01_09 at hand_camera with Dissolve(0.8)
    d "허?!!!!!!!!!!!"
    scene ch03_droom01_10 at hand_camera with Dissolve(0.8)
    d "젠장!!"
    scene ch03_droom01_11 at hand_camera with Dissolve(0.8)
    d "**(뭐지?)**"
    d "**(..................)**"
    d "**(누가 왔었나?!!!)**"
    scene ch03_droom01_12 at hand_camera with Dissolve(0.8)
    d "..............."
    d "거기 누구 있어요?!!"
    scene ch03_droom01_13 at hand_camera with Dissolve(0.8)
    d "..............."
    d "**(어떤 목소리를 들은거 같은데......)**"
    d "..............."
    d "**(아닌가? 착각인가?)**"
    scene ch03_droom01_14 at hand_camera with Dissolve(1.3)
    n "상황 파악이 된 [h_name]은 놀라지도, 레나에게 화가 나지도 않았다."
    n "오로지 [d_name]의 사생활을 의도치 않게 훔쳐보게된 것으로 인한 미안함 뿐이었다."
    n "그가 자신을 자위의 대상으로 삼은 것 따위는 개의치 않았다."
    h "하............"
    h "레나 지금 뭐하는거야...."
    scene ch03_droom01_15 at hand_camera with Dissolve(0.8)
    h "하................"
    h "세상에 어떻게 이런 일이...."
    l "그렇게 과민반응 하지마..."
    l "별 일 아니야."
    scene ch03_droom01_16 at hand_camera with Dissolve(0.8)
    h "이리와봐 레나.."
    scene ch03_droom01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_droom01_18 at hand_camera with Dissolve(2.0)
    play voice_f  "audio/voices/fsigh06.mp3"
    h "하 레나...."
    h "대체 왜 그의 방을 훔쳐본거야?"
    h "내가 분명히 얘기 헀잖아..."
    h "그에게 너의 흑심을 보이는 순간 이 집에 출입금지 할거라고!!"
    scene ch03_droom01_19 at hand_camera with Dissolve(0.8)
    l "............."
    l "오해야 [h_name]. 내가 미쳤니 저 꼬마애에게 흑심이 있겠어?"
    l "내 주변에 남자들 많아."
    l "내가 굳이 저런 꼬마애를 꼬시겠냐고!"
    scene ch03_droom01_19-02 at hand_camera with Dissolve(0.8)
    h "하 레나...."
    h "거짓말이야. 난 너를 너무 잘알아."
    h "레나가 레나 한거야.안그래?"
    h "넌 그저 [d_name]을 어떻게 해보려고 온거잖아."
    h "어떻게 나의 세입자에게 그럴 수 있어?"
    scene ch03_droom01_20 at hand_camera with Dissolve(0.8)
    l "아니라고! 난 저 꼬마애에게 관심 없다니까."
    l "난 그저 너를 위해서......."
    scene ch03_droom01_21 at hand_camera with Dissolve(0.8)
    l "................"
    l "난 그저 저 애가 괜찮은 애인지 알고싶었다고.."
    l "..........."
    l "너와 같이 살아도 되는 애인지 알고 싶었다니까."
    l "그래서 몇마디 나눠보기 위해 잠깐 올라왔던거야."
    scene ch03_droom01_22 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/fwhat01.mp3"
    h "뭐?"
    h "그게 무슨 말이야?"
    h "어떻게 그게 나를 위해서라고 할 수 있어?"
    h "옷을 그렇게 입고 남자애랑 대화하러 왔다는걸 누가 믿겠어?"
    h "남의 사생활을 훔쳐보는게 어떻게 나를 위한거라고 할수 있는거야?!!"
    scene ch03_droom01_23 at hand_camera with Dissolve(0.8)
    d "..........................."
    d "**([h_name]을 위해서 나를 엿본거라고??)**"
    d "**(그게 무슨 말이지..)**"
    pause
    d "**(내가 이상한 놈일수도 있다고 걱정하는건가?)**"
    d "**(........)**"
    d "**(이거 좀 기분나쁜걸...)**"
    scene ch03_droom01_24 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/sus07.mp3"
    l "말했잖아.."
    l "너와 한 집에서 살 자격이 있는 녀석인지 알고싶었다고."
    l "내가 그정도 확인 할 자격은 있다고 생각해."
    scene ch03_droom01_25 at hand_camera with Dissolve(0.8)
    l "그리고 그냥 정말 몇마디 나눠볼려고 왔었어."
    l "근데 우연히 신음소리가 나길래 녀석에게 응급상황이 생긴줄 알았다고."
    l "그래서 문을 살짝 열어본거 뿐이었어."
    l "아니 그전에 당연히 노크도 했었지.."
    scene ch03_droom01_26 at hand_camera with Dissolve(0.8)
    h "............."
    h "대체 니가 무슨 말을 하는건지 하나도 이해가 안돼 레나..."
    scene ch03_droom01_27 at hand_camera with Dissolve(0.8)
    l "헤헤.그래서 나의 결론은..."
    l "아 뭐 물론 대화를 나눠보지 못했지만 어느 정도는 알 수 있었지."
    l "일단 그는 너의 삶에 새로운 활력소가 될 수 있을거 같아."
    l "너도 봤지? "
    scene ch03_droom01_28 at hand_camera with Dissolve(0.8)
    h "............."
    h "활력소라니?"
    h "뭘 봤냐는 거야?"
    scene ch03_droom01_29 at hand_camera with Dissolve(0.8)
    l "녀석의 튼실한 자지 말이야."
    h "!!!!!!!!!!!"
    l "너도 봤지 헤헤?"
    scene ch03_droom01_30 at hand_camera with Dissolve(0.8)
    h "레나....대체 지금 왜 그런말을 하는거야."
    h "미친 소리하지마 제발.. 하....."
    scene ch03_droom01_27-02 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/flaugh04.mp3"
    l "헤헤. 너 지금 얼굴 진짜 빨개졌어."
    l "마치 10대 소녀 같은걸 하하하."
    l "맘이 어때? 괜히 든든해지고 밝은 미래가 기다리고 있는거 같지 않아?"
    l "갑자기 너의 삶에 긴장감이 확 올라가는 느낌이지? 하하."
    scene ch03_droom01_31 at hand_camera with Dissolve(0.8)
    h "그만해."
    h "한 마디만 더하면 넌 오늘 밤 니 차안에서 자게 될거야!!"
    play voice_f "audio/voices/fsigh06.mp3"
    h "하...."
    scene ch03_droom01_32 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/flaugh03.wav"
    pause
    scene ch03_droom01_33 at hand_camera with Dissolve(1.3)
    d "......................."
    d "**(한 가지는 확실하군.)**"
    d "**(분명 내가 아니라 이 동네가 이상해진거야....)**"
    d "**(.........)**"
    d "**(난 아무래도 잘 못된 타이밍에 여기 온거 같아...)**"
    jump ch03_monologue01

label ch03_monologue01:
    if not in_replay:
        $ persistent.unlock_ch03_monologue01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A week later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/title02.mp3"
    show monologue_film onlayer monologue:
        blend "add"
        alpha 0.5
    scene ch03_monologue01 at hand_camera with Dissolve(1.2)
    d "**(내가 자위하는 것을 [h_name]과 레나가 본 뒤로 며칠이 지났다.)**"
    d "**(하.............)**"
    d "**(그 후로 [h_name]이 약간 나를 피하는듯 했다.)**"
    d "**(아니 정확히 말하면 그녀의 행동이 어색해졌다고 해야할까..)**"
    d "**(..................)**"
    d "**(하지만 시간이 지나면서 이내 다시 평소의 모습으로 돌아왔다.)**"
    scene ch03_monologue02 at hand_camera with Dissolve(1.2)
    d "**(우리는 같이 밥을 먹고 청소를 하며 일상을 함께하기 시작했다.)**"
    d "**(가까워질 틈도 없이 우리 사이를 파고든 어색함은 참기 힘든 압력이었다.)**"
    d "**(하지만 소소한 일상을 함께하면서 그녀와 나 사이의 어색함이 조금씩 사라지기 시작했다.)**"
    scene ch03_monologue03 at hand_camera with Dissolve(1.2)
    d "**(매일 조금씩 서로가 편해지기 시작했고 서로의 존재가 자연스럽게 느껴지기 시작했다.)**"
    d "**(마치 내가 원래부터 이 집의 일원이었다는 듯이 말이다.)**"
    d "**(그녀는 나를 긴장시키기도 하지만 편하게도 만들어주는 정말 신기한 매력을 지녔다.)**"
    scene ch03_monologue04 at hand_camera with Dissolve(1.2)
    d "**(우리들의 대화도 날이 갈수록 깊어졌다.)**"
    d "**(인사를 하고 안부를 묻는 것에서 서로의 관심사, 취향, 그리고)**"
    d "**(서로의 기분을 파악하려 노력하고 상대의 기분이 자신들의 삶에 영향을 주는 것을 기꺼이 받아들였다.)**"
    scene ch03_monologue05 at hand_camera with Dissolve(1.2)
    d "**(하지만 우리들의 관계는 어디까지나 랜드레이디와 세입자라는 관계가 허락하는데 까지다.)**"
    d "**(그것은 당연하다.)**"
    scene ch03_monologue06 at hand_camera with Dissolve(1.2)
    d "**(레나의 말처럼 그녀가 흑심을 가지고 나를 세입자로 들였을리가 없다.)**"
    d "**(이 집에 온 첫날부터 지금까지 그런 낌새를 단 한번도 느끼지 못했다.)**"
    d "**(물론 [h_name]의 옷차림에 과한 노출이 있긴 하지만 그것은 자연스러운 것이다.)**"
    d "**(여기는 그녀의 집이고 나 때문에 그녀가 불편해지는건 나도 원치 않기 때문이다.)**"
    d "**(또 그녀가 그녀의 옷차림을 신경쓰지 않아도 될 만큼 우리의 나이 차이가 크다....)**"
    scene ch03_monologue07 at hand_camera with Dissolve(1.2)
    d "**(하지만 한가지 걸리는점은 자위를 들킨 그날 밤 이후로 [h_name]은 애써 태연하게 행동하는듯 했지만..)**"
    d "**(그녀의 표정은 미세하게 부자연스러울 때가 종종 있었다.)**"
    scene ch03_monologue08 at hand_camera with Dissolve(1.2)
    d "**(아니 정확히 표현하면 나, 아니 나의 고추를 의식하기 시작한거 같다.)**"
    d "**(그녀는 이제 나의 얼굴을 보면 나의 고추가 자동으로 연상될 것이다.)**"
    d "**(그렇겠지?)**"
    scene ch03_monologue09 at hand_camera with Dissolve(1.2)
    d "**(이런걸 고전적 조건형성이라고 부르지. 심리학 수업 때 배웠어.)**"
    d "**(마치 파블로프의 개 처럼 내 얼굴을 보면 내 고추가 떠오를거야.)**"
    d "**(그녀의 의지와는 상관 없이 말이야.)**"
    d "**(글쎄....앞으로 최소 몇 달은 그럴거야 아마도.)**"
    scene ch03_monologue10 at hand_camera with Dissolve(1.2)
    d "**(물론 내가 그녀의 속마음을 알 수는 없어.)**"
    d "**(이 모든게 내 착각일 수 있어.)**"
    d "**(그녀는 쿨한 성격이고 자식을 키워본 엄마니까 아마 이 사건 따위는 전혀 개의치 않을수도 있어..)**"
    d "**(하지만 한 가지 확실한 것은..)**"
    scene ch03_monologue11 at hand_camera with Dissolve(1.2)
    d "**(그녀가 나와 가까이 있을 때 그녀의 얼굴에 자주 홍조가 생긴다는거야.)**"
    d "**(하..........)**"
    d "**(네 그렇게 더 조여줘요!!!!)**"
    d "**(당신을 처음 보자마자 알 수 있었다구요!!)**"
    d "**(내 자지를 느껴보고 싶잖아요!!)**"
    d "**(..............)**"
    d "**(이런 소리를 해버렸으니 그녀가 이런 반응을 보이는것도 당연하지...)**"
    scene ch03_monologue11-02 at hand_camera with Dissolve(1.2)
    d "**(하지만 그녀는 내가 불편함을 느끼지 않게 애써 태연한 척 하는거 같아.)**"
    d "**(젠장....그러지 않아도 된다고 얘기하고 싶지만..)**"
    d "**(그런 말들이 오히려 그 날에 대한 그녀의 기억을 다시 또렷하게 만들거야....)**"
    d "**(그 뭐였지....)**"
    d "**(맞다.대니얼 웨그너의 역설적 사고 억제 효과..)**"
    d "**(내가 그 사건에 대해 아무말도 하지 않는것이 그녀에게 도움이 될거야.)**"
    pause
    d "**(하 답답하다.)**"
    scene ch03_monologue12 at hand_camera with Dissolve(1.2)
    d "**(내가 무언가 할 수 있는것도, 해야 할게 있는게 아니지만..)**"
    d "**(마치 산소가 떨어진 산소통을 매고 열심히 숨을 쉬려고 안간힘을 쓰는 느낌이야.)**"
    d "**(이 집에 또 다른 누군가 있었다면 이렇게 답답하진 않을거 같은데..)**"
    d "**(.................)**"
    d "**(내가 뭔가 해야하나? 아니면 이대로 그 기억이 희미해지길 기다려야 하나?)**"
    d "**(쉣........)**"
    jump ch03_gym01

label ch03_gym01:
    if not in_replay:
        $ persistent.unlock_ch03_gym01 = True
    hide monologue_film onlayer monologue with dissolve
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A few days later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch03_gym01 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym02 at hand_camera with Dissolve(1.2)
    pause
    scene ch03_gym03 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_gym03-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym04 at hand_camera with Dissolve(0.8)
    h "................."
    scene ch03_gym04-02 at hand_camera with Dissolve(0.8)
    h "................."
    h "흠......."
    h "대체 모델들은 어떻게 이런 불편한 자세를 하루 종일 할 수 있는거지?"
    scene ch03_gym05 at hand_camera with Dissolve(0.8)
    h "우~~~~"
    h "당신은 매력적인 사람인가요 [h_name]?"
    scene ch03_gym06 at hand_camera with Dissolve(0.8)
    h "........"
    h "아니면 아무 색깔이 없는 사람인가요?"
    scene ch03_gym07 at hand_camera with Dissolve(0.8)
    h "........"
    h "안녕하세요. 저는 매력있는 여자 [h_name]이라고 합니다."
    h "저의 매력에 빠지면 헤어나지 못할거에요."
    h "........"
    h "................"
    h "........................"
    h "지금 뭐하고 있니 [h_name]?"
    h "운동 가기 싫어서 시간 끌고 있는거지?"
    scene ch03_gym08 with Dissolve(2.0)
    pause
    scene ch03_gym09 at hand_camera with Dissolve(0.8)
    h "운동은 거의 한 달 만인가?"
    h "하....... 그 사이에 체력이 얼마나 안좋아졌을지 걱정이네."
    h "아이비의 잔소리가 벌써부터 귀에 들리는거 같아."
    play sound "audio/ambi/cardooropen.mp3"
    scene ch03_gym10 with Dissolve(0.8)
    pause
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch03_gym11 with Dissolve(1.3)
    h "나중에 [d_name] 끌고 와서 같이 운동해야지 헤헤."
    h "그는 괜찮은 골격을 가지고 있는거 같아."
    play sound "audio/ambi/carstart01.mp3"
    h "그러니 조금만 운동 해도 몸이 좋아보일거 같아."
    scene ch03_gym12 with Dissolve(1.3)
    play sound "audio/ambi/carmoving01.mp3"
    pause
    scene ch03_gym13 with Dissolve(1.3)
    play sound "audio/ambi/carpass.mp3" volume 0.5
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_gym13-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/carpass02.mp3" volume 1.7
    pause
    stop sound
    scene ch03_gym14 with Dissolve(2.0)
    pause
    n "최근 몇 년 사이 [h_name]에게 일어난 중대한 일들로 인해 그녀의 삶엔 많은 변화가 있었다."
    scene ch03_gym14-02 at hand_camera with Dissolve(1.0)
    n "그 사건들은 그녀를 지치게 만들었었고 자신을 제대로 가꾸지 못할 정도로 그녀를 힘들게 했다."
    n "오랜 시간이 지나 비로소 그녀는 다시 삶의 트랙으로 돌아왔다."
    scene ch03_gym15 at hand_camera with Dissolve(1.5)
    h "하 맙소사...거울이 옆으로 좀 퍼져보이나?"
    h "지방이 좀 붙은거 같은데?"
    h "후......."
    h "심각하네.."
    scene ch03_gym15-02 at hand_camera with Dissolve(0.8)
    h "레나는 운동도 안하는거 같은데 어떻게 그렇게 날씬한거지? 신기하네."
    n "그녀가 다시 이전의 삶으로 돌아온것은 겨우 1년 전이다."
    n "다시 일을 시작하고, 모기지를 갚아나가고 여성으로서 자신의 신체를 관리하기 시작했다."
    scene ch03_gym16 at hand_camera with Dissolve(0.8)
    n "시간이 지나며 그녀의 삶은 이전에 평범했던 삶으로 돌아오기 시작했고,"
    n "[d_name]을 세입자로 들이는것은 그녀의 삶이 예전의 모습을 완전히 회복하는 것을 의미했다."
    n "그것은 그녀 자신 뿐만 아니라 다른 누군가를 돌볼 수 있다는 것을 의미하기 때문이다."
    scene ch03_gym16-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym17 at hand_camera with Dissolve(1.5)
    pause
    if not in_replay:
        $ bio_ivy = True
    scene ch03_gym17-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym17-03 at hand_camera with Dissolve(1.3)
    i "안녕 [h_name]!. 잘지냈어?"
    h "아이비~~~"
    scene ch03_gym18 at hand_camera with Dissolve(0.8)
    i "한동안 안보여서 보고싶었잖아 하하."
    i "내 잔소리가 걱정되지도 않았던거야?"
    scene ch03_gym19 at hand_camera with Dissolve(0.8)
    h "하하 매일 너의 잔소리가 걱정됐었지."
    h "잘 때마다 신경쓰일 정도였으니까 하하하."
    h "집에 일이 있어서 좀 바빴어. 이제 또 열심히 운동해야지 헤헤."
    h "몇가지 일들이 좀 겹쳐서 처리하느라.."
    scene ch03_gym19-02 at hand_camera with Dissolve(0.8)
    i "난 또 회원 한 명이 사라진줄 알았지 하하."
    i "니가 없으니까 남자들 표정이 다들 시무룩하더라고 하하하."
    h "하하 그런소리 하지마."
    i "좀 자주 좀 나와서 같이 운동하자."
    scene ch03_gym20 at hand_camera with Dissolve(0.8)
    h "알겠어. 이젠 자주 올게."
    h "이젠 최소 2일에 한 번은 운동할거야."
    i "좋았어 [h_name]!바로 그 결심이야!"
    scene ch03_gym21 with Dissolve(1.3)
    h "와 이거 작동하는 방법도 잊어버렸네 하하."
    h "이렇게 하는거였나??"
    scene ch03_gym21-02 with Dissolve(1.3)
    h "오 작동 됐다."
    scene ch03_gym22 at hand_camera with Dissolve(1.3)
    play sound "audio/ambi/treadmill.mp3"
    pause
    scene ch03_gym23 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym23-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_gym24 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/treadmill.mp3" loop
    h "헉헉..이제 아이비에게 잔소리들을 시간이 됐군."
    h "헉헉..뜸들이지 말고 어서 말해줘."
    scene ch03_gym25 at hand_camera with Dissolve(0.8)
    i "..............."
    scene ch03_gym25-02 at hand_camera with Dissolve(0.8)
    h "헉헉....."
    h "아무말도 안할거면 저리 가주시겠어요?"
    scene ch03_gym26 at hand_camera with Dissolve(0.8)
    i "그것봐 [h_name]."
    i "한동안 운동 안했다고 달리는 자세가 무너졌잖아."
    i "그 사이에 엉덩이가 커진거야?"
    i "가슴도 커진거 같은데?"
    scene ch03_gym27 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/heavybreath01.mp3" volume 2.0
    stop sound
    h "셧업."
    h "헉헉. 나도 알아. 나도 안다고.....헉헉."
    h "마지막에 달렸을땐 이렇게 힘들진 않았는데 헉헉."
    scene ch03_gym28 at hand_camera with Dissolve(0.8)
    i "원래 우리 신체가 그래요 하하하."
    i "인간의 신체는 원래 끊임없이 움직이도록 만들어졌어."
    i "심장도 근육이야."
    i "꾸준히 그리고 강하게 뛰게 하지 않으면 얇고 약해지는거야."
    i "니가 운동을 쉰 만큼 너의 수명도 줄어들었다고."
    scene ch03_gym29 at hand_camera with Dissolve(0.8)
    h "와우 그 말 엄청 훅 꽂히네."
    h "하지만 잔소리는 다음에 해주면 안될까?"
    h "하아하아......"
    h "아침을 안먹어서 그런가 여기 천장이 빙글빙글 도네."
    i "하하하."
    scene ch03_gym30 at hand_camera with Dissolve(0.8)
    i "너도 이렇게 되고 싶지 않아?"
    i "지금 시대는 강한 자만 살아남는 시대라고."
    i "너 스스로를 지킬 수 있는 신체를 만들어야 해."
    scene ch03_gym31 at hand_camera with Dissolve(0.8)
    h "뭐? 하하하. 고맙지만 나는 사양할게."
    h "나는 지금 내 몸에 만족하거든 헤헤."
    h "아니 지방만 약간 없애면 딱 완벽할거 같아."
    h "모르겠다.. 내 몸은 사랑하는 남자에게 지켜달라고 할거야 난 헤헤."
    i "하하하 나약한 소리 하지마."
    scene ch03_gym32 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym32-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym33 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym34 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym34-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fahem01.mp3"
    i "크흠!"
    scene ch03_gym35 at hand_camera with Dissolve(0.8)
    i "그건 그렇고 오늘 너의 운동 스케쥴은 힙업이야."
    i "마지막 왔을 때 팔 운동 했으니까 오늘은 너의 엉덩이를 위한 날이지."
    h "맙소사 내가 지난번에 한 운동을 기억하는거야?"
    i "기억이 아니라 너의 운동일지에 기록 해놓은거지."
    scene ch03_gym36 at hand_camera with Dissolve(0.8)
    h "하.....힙업이라니."
    h "일주일만에 왔으니까 대신 오늘은 좀 몸만 풀고 갈거야."
    h "오랜만에 운동하는데 무리하면 힘들어.."
    scene ch03_gym37 at hand_camera with Dissolve(0.8)
    i "하! 그러셔?"
    i "니가 나에게 그런 나약한 말을 하면 꼭 잔소리를 해달라고 나한테 신신당부 했거든?!!"
    i "불평은 과거의 너에게 하지 그래?"
    i "너를 그냥 보내면 그건 내가 직무유기 하는거야."
    scene ch03_gym37-02 at hand_camera with Dissolve(0.8)
    h "맙소사."
    h "내가 그런 말을 했었다고?"
    h "과거의 나에게 화가 다 나네 하하."
    scene ch03_gym38 at hand_camera with Dissolve(0.8)
    i "자 봐 [h_name]."
    i "이 정도는 돼야 힙업이라고."
    i "절로 동기부여가 되지 않아? 하하하."
    scene ch03_gym39 at hand_camera with Dissolve(0.8)
    h "하하 알겠어 알겠다고!!"
    h "밀프하임의 올해의 엉덩이는 너에게 양보할게 하하하."
    h "좋겠다 아이비."
    play music "audio/bgm/normal10.mp3"
    scene ch03_gym40 with Dissolve(2.0)
    i "더 더..종아리와 허벅지가 수직이 되도록 앉아야지!"
    i "엉덩이를 방아찍듯 튕기지말라고!!"
    i "하나도 안요염하거든?"
    h "하아............."
    scene ch03_gym41 at hand_camera with Dissolve(0.8)
    i "그래 [h_name]!! 한 세트만 더!!"
    h "뭐?!! 아 제발..."
    i "나약한 소리 하지마!"
    scene ch03_gym41-02 at hand_camera with Dissolve(0.8)
    i "튕기듯이 일어서지 마!!"
    i "허벅지로 너의 체중을 지탱하는걸 느껴야 해."
    play voice_f  "audio/voices/heavybreath01.mp3"
    scene ch03_gym41-03 at hand_camera with Dissolve(0.8)
    h "하아하아....."
    h "허벅지에 불이 나는거 같아."
    scene ch03_gym41-04 at hand_camera with Dissolve(0.8)
    i "한 달 동안 운동을 안한 결과야 하하."
    i "불평하지마."
    stop voice_f
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    scene ch03_gym42 with Dissolve(2.0)
    h "아......다리가 후들거리네.."
    h "망할 아이비...."
    h "사악해....사악해......"
    scene ch03_gym42-02 at hand_camera with Dissolve(0.8)
    h "..........."
    h "그래도 운동했더니 뿌듯하네 헤헤."
    h "이제 자주 운동해야지."
    h "다음엔 [d_name]도 데리고 와야겠다."
    scene ch03_gym43 with Dissolve(2.0)
    play sound "audio/ambi/shower02.mp3" loop
    h "하......"
    h "시원하다.."
    scene ch03_gym44 at hand_camera with Dissolve(0.8)
    h "그래도 오랜만에 다시 운동 시작하니까 뿌듯하네."
    h "이렇게 운동할 수 있는 건강이 있다는것에 감사해야지.."
    h "그래......."
    h "이렇게 살아서 운동하는것 자체가 기적이야...."
    scene ch03_gym45 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_gym45-02 at hand_camera with Dissolve(0.8)
    i "오 [h_name] 샤워하고 있었네?"
    scene ch03_gym46 at hand_camera with Dissolve(0.8)
    h "응. 내가 이 체육관에서 하는 행동중에 가장 자신있는 파트지.."
    h "난 샤워하면 행복해져 하하."
    h "근데 너도 샤워하게?"
    i "응. 약속이 있어서 나가봐야 하거든."
    scene ch03_gym47 at hand_camera with Dissolve(0.8)
    i "그리고 말이야.."
    i "샤워에 대한 열정을 운동에 좀 쏟아봐 하하."
    i "운동 만큼 자신의 인생을 주도적으로 살게 해주는게 없어."
    scene ch03_gym47-02 at hand_camera with Dissolve(0.8)
    i "좋잖아."
    i "몸도 건강해지고 자신감도 높아지고."
    i "남자들도 안보는거 같아도 바로 안다니까. 이 여자가 운동하는 여자인지 아닌지."
    i "허벅지가 두꺼우면 잘 조여줄거 같다고 생각하더라니까."
    h "뭐라고?"
    i "내 남친이 그러는데 나랑 처음 잔 날 얼마나 강한 조임일지 엄청 기대했었데."
    scene ch03_gym48 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    h "하하하 미치겠다 정말."
    h "지금 그 말 진짜 깊다 깊어.."
    h "아이비..이젠 나에게 동기부여 할 방법을 바꾼거야?"
    h "너의 나에 대한 관심에 감사해야 할지 불평해야 할지 모르겠네 하하하."
    h "난 지금 내 조임에 만족해."
    scene ch03_gym49 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/milflaugh06.mp3"
    i "하하하. 그래? 남자들이 괜찮은 조임이래?"
    h "닥쳐."
    i "진정해 진정해.."
    i "넌 내 친구니까 내가 더 특별히 신경쓰는거 뿐이야."
    scene ch03_gym50 at hand_camera with Dissolve(0.8)
    h "............."
    h "날 이뻐해 줄 남자나 있었으면 좋겠다."
    h "이런 작은 도시에서 누군갈 다시 만나는게 쉽지 않아."
    h "아저씨들은 먹고살기 바쁘고 어린 녀석들은 그저 어떻게 한 번 같이 자보려는 놈들 뿐이야."
    scene ch03_gym49 at hand_camera with Dissolve(0.8)
    i "하하하. 나랑 정확히 같은 생각을 하고 있네."
    i "난 정말 어린 녀석들 플러팅에 질려버렸어."
    i "체육관 등록하고 나에게 온갖 수작을 부리다가 다음날 사라지는 놈들이 한 트럭이야."
    i "요즘 애들은 부끄러움이 없는건지, 아니면 그냥 여자라면 다 찔러보는건지."
    i "................"
    i "근데 원래 남자들은 다 그렇잖아."
    i "그러니까 마음만 먹으면 이용해 먹을 수 있는거라고."
    h "흠........"
    h "이용해 먹는게 뭐지?"
    i "단순하게 생각해. 니가 이 세상의 중심이라고."
    scene ch03_gym51 at hand_camera with Dissolve(0.8)
    i "떡치고 싶으면 맘에 드는 놈 골라서 떡치는거고,"
    i "사랑하고 싶은 놈이 나타나면 사랑하면 되는거야."
    i "이게 뭐지? 이게 사랑인가? 아니야 이건 그냥 육체적인 끌림일 뿐이야."
    i "이런 생각 하다가 아까운 시간만 간다고."
    i "우리를 봐 [h_name]."
    i "벌써 인생의 반을 넘게 살았어."
    i "고민만하고 살다간 금방 할머니 된다."
    scene ch03_gym52 at hand_camera with Dissolve(0.8)
    h "와우 아이비. 오늘은 나의 친구가 아니라 나의 스승이라도 된거 같은데."
    h "............"
    h "잘 새겨 들을게. 하하하."
    scene ch03_gym53 at hand_camera with Dissolve(0.8)
    i "너......."
    i "남자 만나볼래?"
    i "여기 회원 중에 착실해 보이는 아저씨가 하나 있는데 사람 괜찮아보인던데."
    i "지금은 돌싱이고."
    i "삶에 여유도 좀 있는거 같아."
    i "어때 생각있어?"
    scene ch03_gym54 at hand_camera with Dissolve(0.8)
    h "............"
    h "잘 모르겠다 아이비.."
    h "내가 지금 누군갈 만나서 새로운 관계를 만들 수 있을지 잘 모르겠어.."
    h "생각해볼게. 고마워."
    scene ch03_gym55 at hand_camera with Dissolve(0.8)
    i "그래. 생각해보고 말해줘."
    h "그럴게. 고마워 아이비."
    i "괜찮아."
    scene ch03_gym56 at hand_camera with Dissolve(1.3)
    i "그리고 잊지마."
    h "잊지말라니?"
    i "..............."
    i "남자들은 너의 조임을 궁금해 한다고."
    h "셧업."
    stop sound
    jump ch03_hstudio01

label ch03_hstudio01:
    if not in_replay:
        $ persistent.unlock_ch03_hstudio01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next day" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    play sound "audio/ambi/park01.mp3" loop
    scene ch03_hstudio01_01 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/swim.mp3" loop
    scene ch03_hstudio01_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio01_03 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch03_hstudio01_03-02 at hand_camera with Dissolve(0.8)
    d "아 시원하다~~"
    d "이게 천국이지 하하."
    d "여기가 그냥 내가 평생 살 집이면 얼마나 좋을까.."
    d "[h_name]과 함께 평생 말이야 하하하."
    play sound "audio/ambi/phonering01.mp3" volume 0.2 loop
    n "폰이 울린다."
    scene ch03_hstudio01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio01_05 at hand_camera with Dissolve(0.8)
    stop sound
    play sound "audio/ambi/park01.mp3" loop
    d "아 [h_name]."
    d "무슨 일이에요?"
    h "안녕 [d_name]."
    h "혹시 지금 집에 있어요?"
    scene ch03_hstudio01_06 at hand_camera with Dissolve(0.8)
    d "네 지금 뒷마당에 있어요."
    h "정말 정말 미안한데 부탁 한가지 해도 돼요?"
    d "그럼요. 어떤 부탁이에요?"
    scene ch03_hstudio01_07 at hand_camera with Dissolve(0.8)
    h "내 방에 SD카드를 놓고 왔는데 지금 내가 스튜디오를 떠날수가 없어요."
    h "정말 미안한데 지금 시간있으면 SD 카드좀 여기로 가져다 줄 수 있어요??"
    scene ch03_hstudio01_07-02 at hand_camera with Dissolve(0.8)
    d "아 그럼요. 저야 남는게 시간인걸요 하하하."
    if not in_replay:
        $ add_point("love_helen", 1, "love_helen")
    d "지금 바로 가져다 드릴게요."
    h "아 정말 고마워요 [d_name]."
    h "너무 서두르진 않아도 돼요. 조심해요."
    scene ch03_hstudio01_08 at hand_camera with Dissolve(0.8)
    d "알겠습니다. 그럼 잠시 뒤에 봐요."
    stop sound
    scene ch03_hstudio01_09 at hand_camera with Dissolve(1.3)
    pause
    play sound "audio/ambi/drawer.mp3"
    scene ch03_hstudio01_10 at hand_camera with Dissolve(1.3)
    d "허?!!"
    scene ch03_hstudio01_11 at hand_camera with Dissolve(0.8)
    d "뭐지? 왜 새 팬티가 없지?....."
    pause
    d "아 젠장 맞다 어제 마지막 속옷 세탁기에 넣었구나......"
    scene ch03_hstudio01_11-02 at hand_camera with Dissolve(0.8)
    d "어쩔수 없다..그냥 오늘은 노빤스다."
    d "하하하. 노빤스하니까 아만다가 보고싶네."
    play sound "audio/ambi/garage.mp3"
    scene ch03_hstudio01_12 with Dissolve(1.5)
    d "잘 있었니 나의 사랑스러운 슈퍼카야."
    d "오늘도 나와 세상을 누비겠구나. 잘 부탁한다."
    d "오늘 목적지는 우리의 여왕님 [h_name]이 잡혀있는 마녀의 성이야."
    d "나는 그녀를 구하러 가는 정의의 기사야."
    scene ch03_hstudio01_13 at hand_camera with Dissolve(0.8)
    d "유후~"
    d "[h_name]의 스튜디오 처음 가보네...."
    d "그녀가 일하는 모습은 어떨지 궁금한걸.."
    scene ch03_hstudio01_13-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/bicycle01.mp3"
    d "하하. 빨리 가보고싶네."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_hstudio01_14 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal06.mp3"
    pause
    scene ch03_hstudio01_15 with Dissolve(1.5)
    pause
    scene ch03_hstudio01_16 with Dissolve(1.2)
    d "[h_name] [h_name] [h_name]......."
    d "당신의 백마탄 왕자님이 도착했다구요."
    d "가장 아름다운 모습으로 이 왕자님을 맞이해 주세요."
    scene ch03_hstudio01_17 at hand_camera with Dissolve(0.8)
    d "이 왕자님에게 뜨거운 키스를 해주세요."
    d "................"
    d "하........지금 무슨 생각하는거냐......"
    d "망상증이 날로 심해지는거 같네."
    d "이 말을 제이슨이 들으면 날 한심하게 보겠군 하하하."
    scene ch03_hstudio01_18 at hand_camera with Dissolve(1.5)
    d "여기가 맞겠지?"
    d "주소는 여기가 맞는데."
    scene ch03_hstudio01_18-02 at hand_camera with Dissolve(0.8)
    d "아 여기가 문인가보다."
    scene ch03_hstudio01_19 at hand_camera with Dissolve(0.8)
    d "The Luminous Studio..."
    d "여기가 [h_name]공주님이 사는 성인가요?"
    scene ch03_hstudio01_20 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/knock.mp3"
    pause
    scene ch03_hstudio01_20-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/dooropen.mp3"
    scene ch03_hstudio01_21 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio01_22 at hand_camera with Dissolve(0.8)
    n "곧 문이 열리고 [h_name]이 웃으며 그를 반겼다."
    h "안녕 [d_name]."
    h "정말 빨리 왔네요 헤헤."
    scene ch03_hstudio01_23 at hand_camera with Dissolve(0.8)
    h "이렇게 더운 날에 여기까지 오게해서 정말 미안해요."
    h "내가 좀 덤벙거려요 하하."
    h "너에게 큰 신세 졌어요."
    scene ch03_hstudio01_24 at hand_camera with Dissolve(0.8)
    d "아닙니다."
    d "[h_name]을 도울 수 있어서 기쁩니다 하하하."
    d "언제든 부탁만 하세요!"
    h "네 하하. SD카드는 가져왔죠??"
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_hstudio01_25 at hand_camera with Dissolve(0.8)
    d "아 잠깐만요."
    scene ch03_hstudio01_26 at hand_camera with Dissolve(0.8)
    d "여기 있습니다."
    d "아주 조심스럽게 모셔왔습니다 하하."
    scene ch03_hstudio01_27 at hand_camera with Dissolve(0.8)
    h "하하 고마워요."
    d "아니에요 헤헤."
    scene ch03_hstudio01_28 at hand_camera with Dissolve(0.8)
    d "................"
    scene ch03_hstudio01_29 at hand_camera with Dissolve(0.8)
    n "[d_name]이 스튜디오안을 들여다 봤을 때 그 안엔 속옷 상태의 여성이 서 있었다."
    d "**(!!!!!!!)**"
    scene ch03_hstudio01_30 at hand_camera with Dissolve(0.8)
    d "**(마이갓....)**"
    d "**([h_name]은 뭔가 촬영하는 일을 하는건가?)**"
    h "아 다행이다~~"
    scene ch03_hstudio01_31 at hand_camera with Dissolve(0.8)
    h "[d_name]덕분에 살았네요."
    h "이것도 안되면 쇼핑몰 까지 갔다왔어야 했는데 다행히 잘되네요."
    scene ch03_hstudio01_32 at hand_camera with Dissolve(0.8)
    d "아 다행입니다."
    d "제가 여기까지 온 보람이 있네요 하하."
    d "이 참에 제가 [h_name]의 비서 할까요? 하하하."
    h "하하 그럴래요?"
    scene ch03_hstudio01_33 at hand_camera with Dissolve(0.8)
    h "고마워요."
    scene ch03_hstudio01_34 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/fabric01.mp3"
    d "!!"
    scene ch03_hstudio01_35 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort01.mp3"
    n "쪽!"
    scene ch03_hstudio01_36 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 2, "lust_helen")
    pause
    scene ch03_hstudio01_37 at hand_camera with Dissolve(0.8)
    n "[h_name]은 그의 볼에 키스를 했다."
    n "그것이 감사의 의미인지, [d_name]에게 장난을 치는것인지는 그녀만 알고있지만,"
    pause
    scene ch03_hstudio01_38 at hand_camera with Dissolve(0.8)
    n "그녀의 그런 행동은 [d_name]의 심장에 불을 지폈다."
    n "그리고 그날 자위 사건 후로 어색했던 둘 사이의 장막을 걷어치우는 순간이었다."
    scene ch03_hstudio01_39 at hand_camera with Dissolve(0.8)
    d "**(........)**"
    h "!!!!!!!!!!!"
    h "**(오 보이..)**"
    scene ch03_hstudio01_40 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio01_41 at hand_camera with Dissolve(0.8)
    h "미안하지만 지금 일하고 있어서 들어가야 해요."
    h "시원한 물이라도 줘야 하는데 지금 상황이 그러네요."
    scene ch03_hstudio01_42 at hand_camera with Dissolve(0.8)
    d "괜찮아요 걱정하지 마세요 헤헤."
    d "나온김에 자전거 좀 타다 집에가면 돼요."
    scene ch03_hstudio01_43 at hand_camera with Dissolve(0.8)
    h "그래요 ㅎㅎ."
    h "그럼 저녁때 집에서 봐요."
    scene ch03_hstudio01_44 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio01_45 at hand_camera with Dissolve(0.8)
    d "아 저기....."
    scene ch03_hstudio01_46 at hand_camera with Dissolve(0.8)
    h "응?"
    scene ch03_hstudio01_47 at hand_camera with Dissolve(0.8)
    d "저....."
    d "[h_name]이 어떤 일을 하는지 궁금한데 잠깐 구경하고 가도 될까요?"
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
        $ add_point("sus_helen", 2, "sus_helen")
    scene ch03_hstudio01_48 at hand_camera with Dissolve(0.8)
    h "!!!!!!!!"
    h "내가 일하는걸 구경한다고요?"
    h "아......음....."
    scene ch03_hstudio01_49 at hand_camera with Dissolve(0.8)
    h "아...아마도 다음번에?"
    h "하하. 다음번에 볼 기회가 있을거에요..."
    scene ch03_hstudio01_50 at hand_camera with Dissolve(0.8)
    h "헤헤 미안해요 저녁에 봐요."
    h "자전거 조심 타요. 알았죠?"
    scene ch03_hstudio01_51 at hand_camera with Dissolve(0.8)
    d "흠......"
    scene ch03_hstudio01_52 at hand_camera with Dissolve(0.8)
    d "괜히 물어봤나.."
    d "............."
    jump ch03_orph01

label ch03_orph01:
    if not in_replay:
        $ persistent.unlock_ch03_orph01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Meanwhile, at the orphanage…." at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch03_orph01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_01-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ bio_evelyn = True
    unknownf "응 거기 표가 이상했던거 같아."
    unknownf "내가 그래서 임의로 수정했어."
    c "왜 담당 기관에서 서류를 이렇게 만들었을까..."
    c "담당자가 실수한거 같아."
    scene ch03_orph01_01-03 at hand_camera with Dissolve(0.8)
    unknownf "메리가 이 서류 오면 꼼꼼히 보라고 했는데 역시나 문제가 있었어."
    c "휴...니가 먼저 발견해서 다행이네."
    c "이거 이대로 제출 됐으면 여러 사람 곤란해질뻔 했어."
    c "니가 이 세계의 종말을 막았어."
    scene ch03_orph01_01-04 at hand_camera with Dissolve(0.8)
    unknownf "하하하. 그럼 이 영웅에게 술한잔 사라고!"
    unknownf "아니면 남자라도 소개시켜주던가!!"
    c "좋아! 영웅에게 걸맞는 대접을 해줄게 하하하."
    c "기대해 헤헤."
    scene ch03_orph01_02 at hand_camera with Dissolve(0.8)
    unknownf "그럼 영웅은 내 자리로 돌아갈게."
    c "알겠어용~ 이따 퇴근 할 때 봐~"
    scene ch03_orph01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_04 at hand_camera with Dissolve(0.8)
    c "........"
    c "비가 오려고 그러나 오늘은 좀 눅눅하네..."
    play sound "audio/ambi/dooropen.mp3"
    scene ch03_orph01_05 at hand_camera with Dissolve(0.8)
    c "원장님의 사무실 좀 정리좀 해줘야지.."
    scene ch03_orph01_06 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_orph01_06-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/knock.mp3"
    scene ch03_orph01_07 at hand_camera with Dissolve(0.8)
    n "똑똑똑!"
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_orph01_08 at hand_camera with Dissolve(0.8)
    c "**(메리가 사무실에 없나?..)**"
    scene ch03_orph01_09 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_orph01_10 at hand_camera with Dissolve(0.8)
    c "여기도 좀 눅눅하네."
    c "흠........"
    scene ch03_orph01_11 at hand_camera with Dissolve(1.3)
    c "요즘 메리에게 무슨 일이 있는건지 좀 이상해..."
    c "분명 그 날 [d_name]과 뭔가 일이 있었어."
    c "뭔가 서로 만졌던거 같기도 하고.."
    pause
    c "확실해.."
    scene ch03_orph01_12 at hand_camera with Dissolve(0.8)
    c "내 촉은 틀리는 법이 없거든!"
    c "후......."
    c "진짜로?"
    scene ch03_orph01_13 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_14 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_15 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/what.mp3"
    play music "audio/bgm/sus07.mp3"
    c "what the fuck!!!!!!!!!!!!!!!"
    c "뭐야 이게?"
    scene ch03_orph01_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_17 at hand_camera with Dissolve(0.8)
    c "맙소사 뭐야이거!!"
    pause
    c "메리가 이런 취향인가?"
    c "아니 그래도그렇지 어떻게 일하면서 이런 사진을 보고있는거야!!"
    pause
    c "설마 리처드 아저씨 사진은 아니겠지?"
    scene ch03_orph01_17-02 at hand_camera with Dissolve(0.8)
    c "우웩......."
    c "토할거 같아.."
    scene ch03_orph01_18 at hand_camera with Dissolve(0.8)
    c "마이갓 메리....."
    c "사무실에서 일하면서 이런걸 보고있던거야?"
    scene ch03_orph01_19 at hand_camera with Dissolve(0.8)
    c "이 사진은 뭐지..."
    scene ch03_orph01_16 at hand_camera with Dissolve(0.8)
    c "훔쳐봐서 미안해요 메리."
    scene ch03_orph01_19
    pause
    scene ch03_orph01_20
    play voice_f "audio/voices/fscream02.mp3"
    c "으악!!!!!!!!!!!!!!!!!!"
    scene ch03_orph01_21 at hand_camera with Dissolve(0.8)
    c "[d_name]???!!!!!"
    n "셀린이 사진을 넘겼을 때 나타난것은 [d_name]과 그의 발기한 모습이었다."
    n "그 장면은 너무 충격적인 나머지 그녀에게 전혀 현실로 인식되지 않았다."
    c "오 마이갓."
    if not in_replay:
        $ add_point("lust_celine", 10, "lust_celine")
    c "너 거기서 지금 뭐하는거야...."
    scene ch03_orph01_22 at hand_camera with Dissolve(0.8)
    c "홀리...."
    c "이거 무슨 일이야?"
    pause
    c "맙소사 그런거였어?"
    scene ch03_orph01_23 at hand_camera with Dissolve(0.8)
    c "하.......메리...."
    c "하....[d_name]..."
    scene ch03_orph01_23-02 at hand_camera with Dissolve(0.8)
    c "이런 사진들 까지 서로 교환하는 사이였어?"
    c "대체 언제부터 이런짓을 한거야..."
    c "...."
    c "......."
    c "..........."
    c "아 갑자기 속이 울렁거려...."
    scene ch03_orph01_24 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fhurt01.mp3"
    c "아!..."
    play sound "audio/ambi/fabric02.mp3"
    scene ch03_orph01_25 at hand_camera with Dissolve(0.8)
    c "으힉!!!!"
    play sound "audio/ambi/fabric03.mp3"
    scene ch03_orph01_26 at hand_camera with Dissolve(0.8)
    c "아야!"
    scene ch03_orph01_27 at hand_camera with Dissolve(0.8)
    c "아으.............."
    scene ch03_orph01_28 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_29 at hand_camera with Dissolve(0.8)
    c "맙소사........"
    c "어떻게 저런 크기가 있는거지?"
    scene ch03_orph01_30 at hand_camera with Dissolve(0.8)
    c "저런게 몸안에 들어갈 수 있는거야?"
    c "폰 카메라라 더 크게 보이는건가?"
    c "[d_name]의 얼굴과 전혀 매치가 되지 않아........"
    c "AI로 생성한건가? 요즘 누구나 다 이미지를 생성한다던데?"
    pause
    c "신이시여........"
    c "........."
    c "어떻게 저런 순진한 얼굴에 저런걸......"
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_orph01_31 at hand_camera with Dissolve(0.8)
    c "!!!!!!!!!!!!!!!!!!!!!!"
    play sound "audio/ambi/doorclose.mp3"
    scene ch03_orph01_32 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_33 at hand_camera with Dissolve(0.8)
    m "안녕 셀린~"
    m "아 청소해주고 있어네요. 고마워요."
    scene ch03_orph01_34 at hand_camera with Dissolve(0.8)
    c "아 하하 네...."
    c "거의 끝났어요.."
    c "이제 막 나가려던 참이었어요."
    c "습도가 높네요 오늘 하하."
    scene ch03_orph01_35 at hand_camera with Dissolve(0.8)
    c "**(젠장 큰일 났다.)**"
    scene ch03_orph01_36 at hand_camera with Dissolve(0.8)
    c "**(어떡하지?!!)**"
    c "**(어떡하냐고!!!!!!)**"
    scene ch03_orph01_36-02 at hand_camera with Dissolve(0.8)
    c "**(젠장!!)**"
    c "**(모니터 전원을 꺼야하나? 전원 버튼이 어디에 있지?!!!!)**"
    c "**(화면아 좀 꺼져라 제발......)**"
    c "**(젠장 젠장!!)**"
    scene ch03_orph01_37 at hand_camera with Dissolve(0.8)
    m "이 회사에서 날 챙겨주는건 셀린 뿐이네요."
    m "고마워요."
    scene ch03_orph01_38 at hand_camera with Dissolve(0.8)
    c "아 그리고 내일 밀프하임 헤럴드에서 인터뷰하러 올거에요."
    c "내일 질문지 목록 가져다 드릴게요."
    c "그리고 내일 오전에도 다시 한번 더 말씀드릴게요."
    scene ch03_orph01_39 at hand_camera with Dissolve(0.8)
    m "아 고마워. 깜빡하고 있었네."
    m "예산 지원 받으려면 내일 인터뷰 잘 해야겠지."
    m "내 사진도 실린다던데 창피하네요 하하."
    scene ch03_orph01_40 at hand_camera with Dissolve(0.8)
    c "네 ㅎㅎ. 인터뷰 준비에 필요한거 있으면 말씀하세요."
    m "그럴게."
    m "고마워 셀린."
    c "아 그리고 요즘 별일 없으시죠?"
    m "응?"
    c "아... 요즘 표정이 별로 안좋으신거 같아요."
    m "아 그래요?"
    m "좀 피곤해서 그런가보네요 하하."
    scene ch03_orph01_41 at hand_camera with Dissolve(0.8)
    m "물어봐줘서 고마워요."
    c "아니에요."
    c "그럼 나가볼게요."
    m "그래요."
    scene ch03_orph01_42 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph01_43 at hand_camera with Dissolve(0.8)
    c "**(젠장 젠장 젠장)**"
    c "**(모니터 꺼졌나??)**"
    c "**(젠장 젠장 젠장)**"
    scene ch03_orph01_44 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!"
    m "깜짝이야...하...."
    scene ch03_orph01_45 at hand_camera with Dissolve(0.8)
    m "마이갓......"
    m "................"
    m "이 사진들은 몇번을 봐도 통 익숙해지지가 않네..."
    play voice_f "audio/voices/fsigh06.mp3"
    scene ch03_orph01_46 at hand_camera with Dissolve(0.8)
    m "하............"
    m "사무실에서 지금 뭐하는거냐 메리야...."
    m "이래서 인터뷰 준비 제대로 하겠어?......"
    m "너 언제부터 이랬다고..."
    scene ch03_orph01_47 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    m "하............"
    scene ch03_orph01_48 with Dissolve(1.5)
    pause
    scene ch03_orph01_49 with Dissolve(1.5)
    m "[d_name]이 얄궂은 녀석.."
    m "대체 나에게 왜 이런 짓을 한거야.."
    scene ch03_orph01_50 with Dissolve(1.3)
    m "............"
    scene ch03_orph01_51 with Dissolve(1.3)
    m "지금 나에게 무언가 일이 벌어지고 있어....."
    m "도무지 마음이 가라앉지가 않아..."
    scene ch03_orph01_52 with Dissolve(1.3)
    c "................."
    c "젠장.....모니터 꺼졌을려나?"
    c "메리가 물어보면 뭐라고 변명하지?....."
    c "무슨 말이냐고 모른체해야하나?..."
    c "................."
    jump ch03_police01

label ch03_police01:
    if not in_replay:
        $ persistent.unlock_ch03_police01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Ivy’s Gym" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal06.mp3"
    scene ch03_police01 with Dissolve(2.0)
    pause
    scene ch03_police02 with Dissolve(1.2)
    pause
    if not in_replay:
        $ bio_diana = True
    scene ch03_police03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police04 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    pause
    scene ch03_police05 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/phonering02.mp3" loop
    n "전화가 울린다."
    scene ch03_police06 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch03_police07 at hand_camera with Dissolve(0.8)
    unknownf "네 서장님."
    scene ch03_police08 at hand_camera with Dissolve(0.8)
    unknownf "................"
    unknownf "네 이사는 마쳤고 잠시 밖에 나와있습니다."
    scene ch03_police09 at hand_camera with Dissolve(0.8)
    unknownf "................"
    unknownf "그런데 제가 지금 평상복이 아니고 운동복입니다."
    unknownf "괜찮으시겠습니까?"
    scene ch03_police10 at hand_camera with Dissolve(0.8)
    unknownf "................"
    scene ch03_police11 at hand_camera with Dissolve(0.8)
    unknownf "네 알겠습니다."
    unknownf "그럼 잠시 뒤에 뵙겠습니다."
    scene ch03_police12 at hand_camera with Dissolve(0.8)
    unknownf "..............."
    unknownf "흐음....."
    play sound "audio/ambi/city02.mp3"
    scene ch03_police12-01 with Dissolve(2.0)
    pause
    scene ch03_police12-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police13 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police14 at hand_camera with Dissolve(0.8)
    unknownf "흠......"
    unknownf "며칠 휴무였는데 좀 짜증나네......"
    scene ch03_police15 at hand_camera with Dissolve(0.8)
    unknownf "아직 정식 출근도 안했는데 쩝....."
    scene ch03_police16 at hand_camera with Dissolve(0.8)
    unknownf ".................."
    unknownf "그나저나 이 복장으로 사무실에 가는건 또 첨이네."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play sound "audio/ambi/park01.mp3"
    scene ch03_police17 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal08.mp3" volume 1.5
    pause
    scene ch03_police18 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/metaldoor.mp3"
    scene ch03_police18-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police19 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police20 at hand_camera with Dissolve(1.3)
    unknownf "**(흠.......)**"
    unknownf "**(경찰서가 생각보다 크네..)**"
    unknownf "**(근데 서장실이 어디지?)**"
    scene ch03_police21 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_police21-02 at hand_camera with Dissolve(0.8)
    unknownf "감사합니다."
    scene ch03_police22 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/knock.mp3"
    n "똑똑똑"
    scene ch03_police23 at hand_camera with Dissolve(0.8)
    chi "들어와."
    scene ch03_police24 at hand_camera with Dissolve(0.8)
    unknownf "크흠."
    scene ch03_police25 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene ch03_police26 at hand_camera with Dissolve(0.8)
    unknownf "안녕하십니까 서장님."
    unknownf "처음 뵙겠습니다."
    chi "아 어서오게."
    chi "빨리 와줘서 고맙네."
    if not in_replay:
        $ bio_harold = True
    scene ch03_police27 at hand_camera with Dissolve(0.8)
    unknownf "만나서 영광입니다 서장님."
    chi "휴무인데 불러내서 정말 미안하네 루테넌트 모건."
    chi "내가 내일 부터 잠시 자리를 비워야 해서 어쩔수 없이 오늘 보자고 했네."
    scene ch03_police28 at hand_camera with Dissolve(0.8)
    n "다이애나와 첫 인사를하던 서장은 갑자기 말을 멈췄다."
    n "그리고 그의 시선은 그녀의 가슴을 향했다."
    scene ch03_police29 at hand_camera with Dissolve(0.8)
    di "..........."
    di "**(맙소사...진짜로?)**"
    di "**(하.....정말 이 경찰 꼰대들 매너는 언제 나아지려나...)**"
    di "복장이 이래서 죄송합니다."
    chi "아니네. 신경쓰지말게."
    scene ch03_police30 at hand_camera with Dissolve(0.8)
    chi "자 어서 앉게."
    di "감사합니다."
    scene ch03_police31 at hand_camera with Dissolve(1.5)
    n "서장은 그녀를 앞에두고 서류를 들여다 보았다."
    scene ch03_police32 at hand_camera with Dissolve(1.5)
    n "그는 다이애나가 불편할 만큼 오랫동안 서류를 들여다보다 이윽고 말했다."
    chi "Rosenford 강력반에서 활약이 아주 대단했더군."
    chi "맡은 사건들을 거의 해결했다는게 정말 인상적이네."
    chi "이 곳 시골 경찰서엔 그렇게 의욕적인 형사들이 많지가 않아."
    di "칭찬 감사합니다."
    scene ch03_police33 at hand_camera with Dissolve(0.8)
    di "대부분 동료들과 같이 이뤄낸 성과들입니다."
    di "그리고 몇몇 사건은 운도 많이 따랐습니다."
    scene ch03_police34 at hand_camera with Dissolve(0.8)
    chi "그런가?"
    chi "흠......."
    chi "잡 인터뷰 아니니 편히 말하게."
    scene ch03_police35 at hand_camera with Dissolve(0.8)
    chi "음....."
    chi "자네도 들어서 알겠지만 최근 이 지역에 강력 범죄가 급증하고 있네."
    chi "정말 미친 속도로 말이지."
    chi "도저히 이곳 인력으론 어떻게 할 방도가 없을정도로 말이야."
    chi "때문에 주민들의 원성 또한 높아지고 있네."
    scene ch03_police36 at hand_camera with Dissolve(0.8)
    chi "자네 전임 팀장은 심리적으로 힘들었는지 갑작스럽게 경찰을 떠났다네."
    pause
    chi "그래서 내 친구인 Rosenford 서장에게 내가 특별히 요청했어."
    chi "그래서 자네와 함께 몇몇 경찰들이 이곳으로 오게 된거야."
    chi "날 너무 원망하지말게."
    chi "대신 이곳에서 팀장 임기가 끝나면 더 좋은 근무지로 갈 수 있도록 내 책임지겠네."
    scene ch03_police37 at hand_camera with Dissolve(0.8)
    di "아 그랬군요."
    di ".............."
    di "갑자기 제 어깨가 무거워 집니다."
    chi "초반에 이런 말들을 해서 미안하네."
    chi "자네 노하우와 수사력을 이 곳 형사들에게 전수를 해줘. 부디 압박으로 듣지는 말아주게."
    scene ch03_police38 at hand_camera with Dissolve(0.8)
    di "아닙니다 괜찮습니다."
    di "열심히 하겠습니다."
    di "저에게 주어진 임무만 확실히 처리하겠습니다."
    scene ch03_police39 at hand_camera with Dissolve(0.8)
    chi ".............."
    chi "그래. 이곳 시민들을 위하여 최선을 다해주게.."
    pause
    di "**(하...............)**"
    di "**(남자들은 참 신기해.)**"
    di "**(이 지역의 범죄 얘기를 하다말고 여자 가슴을 보고 싶나?)**"
    di "**(인상쓰면 모를줄 아나??)**"
    scene ch03_police39-02 at hand_camera with Dissolve(0.8)
    di "....."
    play voice_f "audio/voices/fahem01.mp3"
    di "크흠......"
    scene ch03_police36 at hand_camera with Dissolve(0.8)
    chi "아 그리고 알고는 있네만 혼자 산다지?"
    di "................"
    di "네 그렇습니다."
    scene ch03_police35 at hand_camera with Dissolve(0.8)
    chi "실례지만 이혼한건가?"
    chi "이유를 물어봐도 되겠나?"
    chi "업무와 관련 된 질문이니 이해해주게나."
    di "아 그건......"
    scene ch03_police36 at hand_camera with Dissolve(0.8)
    di "경찰 커리어 초기에 결혼 했었습니다만 경찰로서의 업무와 가정에 모두 충실할 수 없었습니다."
    di "혼자 지내온것이 경찰 업무에 더 도움이 되고 있습니다."
    di "......................"
    chi "음 그렇구만."
    chi "자네의 직업의식에 숙연해지는구만."
    scene ch03_police40 at hand_camera with Dissolve(0.8)
    chi "여성으로서 강력반 형사로 커리어를 이어가는게 얼마나 힘들었을지 난 상상도 안되네."
    chi "아무튼 이 도시를 위해서 여기 있는 동안 자네 고향이라 생각하고 최선을 다해주게."
    di "네 알겠습니다."
    chi "자 그럼 잠시 같이 갈까?"
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_police41 at hand_camera with Dissolve(0.8)
    chi "자네 사무실을 안내해주겠네."
    chi "전임 팀장은 별도 사무실이 없었지만 자네를 위해서 내가 특별히 마련했네."
    di "신경써주셔서 감사합니다."
    scene ch03_police42 at hand_camera with Dissolve(0.8)
    pause
    n "다이앤에게 남자들이 가득한 직장 분위기는 익숙했다."
    n "여자 형사로서 커리어를 쌓아 오는 동안 그녀는 범죄에 더해 동료 경찰들의 시선과 무시와 싸워야 했다."
    scene ch03_police43 at hand_camera with Dissolve(1.3)
    n "그러한 환경은 그녀를 더욱 수사에 매진하게 만들었고,"
    n "이곳의 서장이 그녀의 몸을 쳐다보든 말든 그녀에게 중요한 것은 오로지 사건의 해결 뿐이었다."
    scene ch03_police43-02 at hand_camera with Dissolve(0.8)
    di "**(젠장. 옷 엄청 신경쓰이네.)**"
    di "**(다른 사람들이 보면 체포돼서 잡혀온줄 알겠어.)**"
    scene ch03_police43-03 at hand_camera with Dissolve(0.8)
    di "**(흠.......여기가 팀장 사무실?)**"
    scene ch03_police44 at hand_camera with Dissolve(0.8)
    chi "여기일세."
    chi "여기가 자네가 앞으로 일 할 곳이네."
    scene ch03_police45 with Dissolve(1.5)
    pause
    scene ch03_police46 at hand_camera with Dissolve(0.8)
    n "서장의 행동과 말투는 그녀를 처음 만난 20분 전보다 눈에 띄게 부드러워져 있었다."
    chi "뭐 경찰 사무실은 어딜가든 삭막하지 하하하."
    di "이젠 익숙합니다 하하."
    di "그래고 생각했던것 보다 더 깔끔한 사무실입니다."
    scene ch03_police47 at hand_camera with Dissolve(0.8)
    chi "내가 내일부터 컨퍼런스 참석으로 며칠간 자리를 비워서 어쩔수 없이 오늘 불렀다네."
    chi "아 아까 말했군."
    chi "아무튼 휴무인데 불러내서 미안하네."
    chi "난 이만 가볼테니 그럼 대충 둘러보고 가보게나."
    scene ch03_police48 at hand_camera with Dissolve(0.8)
    di "네 알겠습니다."
    di "그럼 돌아오시면 보고 드리겠습니다."
    di "친히 안내해 주셔서 감사합니다."
    scene ch03_police49 at hand_camera with Dissolve(0.8)
    chi "좋아."
    di ".........."
    chi "여러모로 훌륭한 부하가 생겨서 든든하구만."
    chi "내가 다시 복귀하면 또 얘기하세."
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_police50 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police51 at hand_camera with Dissolve(1.5)
    di ".........."
    di "흠.....여러모로 훌륭한 부하라....."
    play sound "audio/ambi/doorclose.mp3"
    scene ch03_police52 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_police53 at hand_camera with Dissolve(0.8)
    n "그녀는 선택의 여지도 없이 주의 수도인 Rosenford 경찰에서 이곳으로 파견되었다."
    n "납득하지 못한 다이애나는 처음엔 경찰을 떠날 생각도 했었지만 이내 받아들였다."
    n "그녀가 경찰로 근무하는 이상 어디에 살던 그것은 중요한것이 아니라 생각했기 때문이다."
    scene ch03_police54 at hand_camera with Dissolve(0.8)
    n "그녀의 정의감, 수사에 대한 의지는 그녀 스스로도 꺽지 못했다."
    n "그리고 그녀가 일하게 될 그녀의 책상을 만지며 각오를 되새겼다."
    di "............"
    scene ch03_police55 at hand_camera with Dissolve(0.8)
    di "여기가 이제 내 집이란 말이지...."
    di "흠......"
    di "시골치곤 나쁘진 않네."
    scene ch03_police56 at hand_camera with Dissolve(0.8)
    di "경찰서와 체육관이 있으니 그걸로 된거 아니겠어?"
    scene ch03_police57 at hand_camera with Dissolve(0.8)
    di "여기엔 뭐가 있을까?"
    play sound "audio/ambi/drawer.mp3"
    scene ch03_police58 at hand_camera with Dissolve(0.8)
    di "아무 것도 없군."
    scene ch03_police59 at hand_camera with Dissolve(0.8)
    di "형사의 직감으론 여기엔 뭔가 있을거 같은데?"
    play sound "audio/ambi/drawer.mp3"
    scene ch03_police60 at hand_camera with Dissolve(0.8)
    di "!!"
    di "빙고!"
    di "응? 그런데 무슨 서류지?"
    scene ch03_police61 at hand_camera with Dissolve(0.8)
    di "뭐지? 사건 서류인가?"
    scene ch03_police62 at hand_camera with Dissolve(0.8)
    di "흠......"
    scene ch03_police63 with Dissolve(1.5)
    n "그녀의 책상 서랍 안에는 어떤 한 파일이 떨어져있었다."
    di "뭐지 이 서류는?"
    di "전임 팀장이 떨어뜨리고 잊은 파일인가?"
    scene ch03_police64 at hand_camera with Dissolve(0.8)
    n "그 파일 안에는 몇몇 서류와 2달러 지폐, 그리고 손으로 필기한 메모가 들어있었다."
    di "뭐야 이건"
    di "에드워드 형사님께?"
    scene ch03_police65 at hand_camera with Dissolve(0.8)
    di "..........."
    scene ch03_police66 at hand_camera with Dissolve(0.8)
    di "....."
    di "이거 조사 보고서 같은데 수사 진행이 안된건가??"
    di "흠............"
    di "이거 신임 팀장을 엿먹이는 새로운 방법인가?"
    scene ch03_police67 at hand_camera with Dissolve(0.8)
    di "흠..........."
    scene ch03_police68 at hand_camera with Dissolve(0.8)
    pause
    di "AAAE?"
    scene ch03_police69 at hand_camera with Dissolve(0.8)
    di "이건 회계자료 같은데 왜 강력반에 와있지?"
    scene ch03_police70 at hand_camera with Dissolve(0.8)
    di "..............."
    pause
    jump ch03_hhouse01

label ch03_hhouse01:
    if not in_replay:
        $ persistent.unlock_ch03_hhouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "That Night, at Helen’s House" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hhouse01_01 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hhouse01_02 at hand_camera with Dissolve(0.8)
    h "하하하. 어쩜 좋아."
    h "진짜 창피하겠다."
    scene ch03_hhouse01_03 at hand_camera with Dissolve(0.8)
    d "그러게요."
    d "저라면 뒤도 안돌아보고 집으로 도망갈거 같은데요 하하하."
    scene ch03_hhouse01_03-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/phonering01.mp3" volume 0.1 loop
    scene ch03_hhouse01_04 at hand_camera with Dissolve(0.8)
    d "앗 저 전화 온거 같은데요."
    scene ch03_hhouse01_05 at hand_camera with Dissolve(0.8)
    d "**(젠장 하필 이 타이밍에..)**"
    d "**(편안하니 분위기 좋았는데.)**"
    scene ch03_hhouse01_05-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hhouse01_06 at hand_camera with Dissolve(0.8)
    d "누구지? 제이슨인가?"
    scene ch03_hhouse01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hhouse01_08 at hand_camera with Dissolve(0.8)
    d "앗 메리에게 전화가 왔다!"
    stop sound
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hhouse01_09 at hand_camera with Dissolve(0.8)
    d "안녕하세요 메리."
    d "잘 지내셨어요? 하하."
    scene ch03_hhouse01_10 at hand_camera with Dissolve(0.8)
    m "응 난 잘지냈어."
    m "넌 어떻게 지냈니? 밥은 잘 챙겨먹고 있니?"
    scene ch03_hhouse01_11 at hand_camera with Dissolve(0.8)
    d "네 잘 먹고있습니다 하하."
    d "잘 지냈어요."
    d "이제 이 동네와 하숙집에 잘 적응해서 지내고 있어요."
    scene ch03_hhouse01_12 at hand_camera with Dissolve(0.8)
    m "다행이구나."
    m "목소리도 활기차게 들리네."
    pause
    n "잠시 뜸들인 메리는 약간 의기소침해진 목소리로 말했다."
    m "음....있잖아."
    m "내일 오전에 혹시 시간 되니?"
    scene ch03_hhouse01_13 at hand_camera with Dissolve(0.8)
    m "지난번에 말한 인턴쉽 건으로 할 얘기가 있어서 말이야."
    m "......................"
    m "센터로 와줬으면 해."
    d "그럼요! 당연히 갈수 있어요."
    m "그래 좋아!"
    scene ch03_hhouse01_12 at hand_camera with Dissolve(0.8)
    pause
    m "그리고...."
    m "그 뭐냐.."
    m "우리 다른 할 얘기도 있잖아...그치?..."
    scene ch03_hhouse01_14 at hand_camera with Dissolve(0.8)
    n "[d_name]이 기다리던, 그리고 동시에 걱정하던 순간이 오고있었다."
    n "순간 자신이 저지른 짓이 그의 머릿속에 맴돌았다."
    d ".............."
    d "네 메리. 기억하고 있어요."
    pause
    m "그래......."
    m "그럼 내일 오전에 센터로 와줘 허니."
    scene ch03_hhouse01_15 at hand_camera with Dissolve(0.8)
    d "네 알겠어요. 내일 오전에 거기로 갈게요."
    m "그래 알겠어."
    m "그럼 내일 보자."
    d "네 좋은 밤 보내세요."
    d "안녕."
    scene ch03_hhouse01_16 with Dissolve(2.0)
    m ".............."
    pause
    play voice_f "audio/voices/fsigh06.mp3"
    m "하.........."
    scene ch03_hhouse01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hhouse01_18 at hand_camera with Dissolve(0.8)
    d "하......"
    d "이거 걱정해야하나 아님 다행이라 생각해야 하나...."
    d "내 행동에 대한 카르마를 감당해야 하는 순간이 막상 닥치니 이거 좀 긴장되네..."
    scene ch03_hhouse01_19 with Dissolve(1.5)
    play sound "audio/ambi/doorclose.mp3"
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hhouse01_20 at hand_camera with Dissolve(0.8)
    n "그가 전화를 마치고 거실로 나왔을 때 [h_name]은 사라지고 없었다."
    scene ch03_hhouse01_21 at hand_camera with Dissolve(0.8)
    d "**(그녀가 방에 들어갔나?)**"
    d "**(술 마시던데 피곤해서 방에 들어갔나보다..)**"
    d "**(아쉽네..마저 같이 티비보고싶었는데..)**"
    scene ch03_hhouse01_22 with Dissolve(1.5)
    pause
    scene ch03_hhouse01_23 at hand_camera with Dissolve(0.8)
    d "**(젠장... 이러다 훔쳐보는거 버릇되는거 아냐?..)**"
    d "**(내 조상중에 도둑이라도 있었나 이거 계속 이런 짓을 하네...)**"
    scene ch03_hhouse01_24 at hand_camera with Dissolve(0.8)
    d "!!"
    play music "audio/bgm/night04.mp3"
    scene ch03_hhouse01_25 at hand_camera with Dissolve(1.3)
    n "그가 [h_name]의 방안을 들여다 봤을 때 그녀는 비오는 창밖을 보고 서있었다."
    scene ch03_hhouse01_26 at hand_camera with Dissolve(1.1)
    n "조금전 같이 티비를 볼 때의 유쾌했던 [h_name]의 모습과는 사뭇 달랐다."
    scene ch03_hhouse01_27 at hand_camera with Dissolve(1.1)
    pause
    scene ch03_hhouse01_28 at hand_camera with Dissolve(1.1)
    play voice_f "audio/voices/fsigh01.mp3"
    h "하..........."
    h "비 시원하게 오네....."
    scene ch03_hhouse01_29 at hand_camera with Dissolve(1.1)
    h ".................."
    scene ch03_hhouse01_30 at hand_camera with Dissolve(1.1)
    pause
    h "이 비에 내 상념들도 다 씻겨 내려갔으면 좋겠다....."
    scene ch03_hhouse01_30-02 at hand_camera with Dissolve(1.1)
    play voice_f "audio/voices/fsigh06.mp3"
    h "내 머릿속을 헤집고 있는 모든 상념들말이야..."
    h "요즘 왜 이렇게 생각이 많아졌지...."
    h "................"
    h "갱년기가 시작 되는건가..."
    scene ch03_hhouse01_31 at hand_camera with Dissolve(1.5)
    pause
    stop sound
    jump ch03_hcar01

label ch03_hcar01:
    if not in_replay:
        $ persistent.unlock_ch03_hcar01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    play sound "audio/ambi/rain01.mp3"  loop
    scene ch03_hcar01_01 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rainwindow01.mp3" volume 2.0 loop
    scene ch03_hcar01_02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hcar01_03 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene ch03_hcar01_04 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/rainwindow01.mp3" volume 2.0 loop
    pause
    scene ch03_hcar01_05 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch03_hcar01_06 at hand_camera with Dissolve(0.8)
    d "굿모닝 [h_name]."
    scene ch03_hcar01_07 at hand_camera with Dissolve(0.8)
    h "좋은 아침이에요 [d_name]."
    h "오늘 밖에 나가요?"
    scene ch03_hcar01_08 at hand_camera with Dissolve(0.8)
    d "네 볼 일이 있어서 유스센터에 갔다오려구요."
    scene ch03_hcar01_09 at hand_camera with Dissolve(0.8)
    h "네? 비가 이렇게 많이 오는데?"
    h "가능하겠어요?"
    scene ch03_hcar01_08 at hand_camera with Dissolve(0.8)
    d "어쩔수 없지요."
    d "우산을 들고 가던지 아니면 택시를 불러야 할거 같아요."
    scene ch03_hcar01_10 at hand_camera with Dissolve(0.8)
    h "................"
    h "안돼요.. 자전거는 절대 안되고.."
    h "택시도 이 동네는 부르면 한 시간도 더 걸려요."
    h "흠...."
    scene ch03_hcar01_11 at hand_camera with Dissolve(0.8)
    h "좋아요. 그럼 내가 차로 데려다 줄게요."
    h "그리 멀지 않으니까 내 차로 가요."
    scene ch03_hcar01_12 at hand_camera with Dissolve(0.8)
    d "아 정말요?.."
    d "그렇게 안하셔도 되는데..."
    if not in_replay:
        $ add_point("love_helen", 1, "love_helen")
    scene ch03_hcar01_13 at hand_camera with Dissolve(0.8)
    h "괜찮아요."
    h "어서 가요."
    scene ch03_hcar01_14 at hand_camera with Dissolve(0.8)
    d "정말 감사합니다!!"
    h "천만에요."
    scene ch03_hcar01_14-02 with Dissolve(1.3)
    pause
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch03_hcar01_15 at hand_camera with Dissolve(0.8)
    d "이렇게 비도 오는데 태워주셔서 감사합니다."
    play sound "audio/ambi/carstart01.mp3"
    h "하하. 아니에요."
    h "비가 이렇게 많이 오는데 맨몸으로 무작정 밖에 나가는 사람이 어디있어요 하하."
    play sound "audio/ambi/carmoving01.mp3"
    scene ch03_hcar01_16 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/rain01.mp3"  loop
    pause
    scene ch03_hcar01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hcar01_18 at hand_camera with Dissolve(0.8)
    h "그러고보니 같이 차를 타고 어딘가 가는건 처음이네요."
    d "하하 그러네요."
    scene ch03_hcar01_19 at hand_camera with Dissolve(1.5)
    h "나중에 외식이라도 같이 해요."
    h "나도 계속 내가 한 음식만 먹었더니 좀 질리네요 하하."
    d "네 좋습니다!!"
    scene ch03_hcar01_20 at hand_camera with Dissolve(0.8)
    d "전 [h_name]이 만든 음식이 너무 맛있어서 좋았습니다 하하."
    d "근래 들어서 제일 잘먹고 사는거 같아요."
    h "그래요? 헤헤. 너무 과찬인거 같네요."
    h "내 자식들은 매일 외식하자고 아우성이었어요 하하하."
    play sound "audio/ambi/raincar.mp3" volume 2.0 loop
    scene ch03_hcar01_21 at hand_camera with Dissolve(0.8)
    d ".................."
    h "..............."
    scene ch03_hcar01_22 at hand_camera with Dissolve(0.8)
    d "아 저 [h_name]......"
    d "뭐 하나 물어봐도 돼요?"
    scene ch03_hcar01_23 at hand_camera with Dissolve(0.8)
    h "네 그럼요."
    h "이제 우리 사이는 아무거나 막 물어봐도 되는 사이아니었어요? 하하."
    h "어떤 질문인데요?"
    scene ch03_hcar01_22 at hand_camera with Dissolve(0.8)
    d "아 저.."
    d "현관에 있는 사진 말이에요..."
    d "[h_name]과 젊은 남자가 같이 찍은 사진..."
    scene ch03_hcar01_24 at hand_camera with Dissolve(0.8)
    d "[h_name]의 아들이에요?"
    h "!!"
    scene ch03_hcar01_25 at hand_camera with Dissolve(0.8)
    n "그것은 그녀의 예상을 완전히 벗어난 질문이었다."
    n "순간 그녀는 그녀의 가슴에 무언가 훅 파고들어오는 듯한 감정을 느꼈다."
    h ".............."
    h "네 맞아요. 내 아들이에요."
    scene ch03_hcar01_26 at hand_camera with Dissolve(0.8)
    d "아 그렇군요."
    d "그럼 아드님은 집엔 언제 와요?"
    d ".........."
    h "음......"
    h "지금 해외에서 유학 후 그곳에서 살고 있어요."
    scene ch03_hcar01_27 at hand_camera with Dissolve(0.8)
    h "벌써 몇 년이 지났네요."
    d "............"
    scene ch03_hcar01_28 at hand_camera with Dissolve(0.8)
    d "아 그렇군요.."
    d "많이 보고싶으시겠어요."
    scene ch03_hcar01_27 at hand_camera with Dissolve(0.8)
    h "후후.."
    h "그럼요.. 어떤 엄마가 아들이 보고싶지 않겠어요."
    scene ch03_hcar01_28 at hand_camera with Dissolve(0.8)
    d "저기...."
    pause
    d "이런말이 좀 이상하게 들릴 수 있지만요.."
    scene ch03_hcar01_29 at hand_camera with Dissolve(0.8)
    d "**(젠장...이런 말 해도 되나?)**"
    d "**(괜히 또 이거 말실수 하는거 아닌가....)**"
    d "...................."
    scene ch03_hcar01_29-02 at hand_camera with Dissolve(0.8)
    d "왠지 [h_name]이 혼자 있는 모습을 보면 좀 쓸쓸해 보여요."
    d "뭐랄까.....아 아니에요 ㅎㅎ."
    d "심각한 얘기는 아니구요 그냥 제 느낌이니 시덥지 않은 소리로 들으세요 하하."
    scene ch03_hcar01_30 at hand_camera with Dissolve(0.8)
    pause
    h "............."
    if not in_replay:
        $ add_point("love_helen", 2, "love_helen")
        $ add_point("lust_helen", 1, "lust_helen")
    scene ch03_hcar01_31 at hand_camera with Dissolve(0.8)
    d "미안합니다.."
    d "제가 괜한 소리를 했네요. 그냥 제 느낌이었어요."
    d "언짢으셨다면 죄송합니다."
    scene ch03_hcar01_27 at hand_camera with Dissolve(0.8)
    h "괜찮아요."
    h "신경쓰지말아요."
    h "[d_name]군이 나를 그렇게 유심히 관찰하는지는 몰랐네요 하하."
    h "나의 행동을 이제 더 조심해야겠네요 헤헤."
    scene ch03_hcar01_29 at hand_camera with Dissolve(0.8)
    d "아 저 때문에 그러실 필요는 없습니다."
    d "전 그저 뭐랄까....."
    d "이상하게 들릴 수 있지만.."
    scene ch03_hcar01_32 at hand_camera with Dissolve(0.8)
    d "저와 [h_name]이 서로 안진 얼마 안됐지만 이렇게 한 집에 살게 된것도 인연이라고 생각합니다."
    d "당신도 알잖아요.."
    d "이 세상이 얼마나 넓고 얼마나 많은 사람들이 있는지.."
    scene ch03_hcar01_31 at hand_camera with Dissolve(0.8)
    d "그러니까 제가 하고싶은 말은 이거에요."
    d "제가 조금이나마 [h_name]의 삶에 보탬이 됐으면 합니다 헤헤."
    d "전 그러면 기쁠거 같아요.."
    if not in_replay:
        $ add_point("love_helen", 5, "love_helen")
    scene ch03_hcar01_33 at hand_camera with Dissolve(0.8)
    n "그녀는 [d_name]의 말이 꽤 귀엽다고 느꼈다."
    n "그는 종종 그녀의 기분을 좋게하기 위해 인위적인 말들을 하는 경우가 있다고 생각하곤 했지만,"
    n "지금 그의 말은 그녀 마음 깊은 곳, 그녀 마음의 문을 노크했다."
    scene ch03_hcar01_34 at hand_camera with Dissolve(0.8)
    h "음...."
    h "정확히 어떤 의미로 그런 말을 하는 지 모르겠지만..."
    scene ch03_hcar01_35 at hand_camera with Dissolve(0.8)
    h "이미 [d_name]은 나에게 보탬이 되고 있어요."
    h "암 그렇고 말구요. 이미 많은 보탬이 되고 있어요."
    h "사실 세입자를 받을지 정말 엄청 고민했었는데,"
    h "지금은 그렇게 한게 정말 잘한 결정이었던거 같아요."
    scene ch03_hcar01_36 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/carpass.mp3" volume 0.3
    scene ch03_hcar01_37 with Dissolve(1.3)
    pause
    jump ch03_orph02

label ch03_orph02:
    if not in_replay:
        $ persistent.unlock_ch03_orph02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    play sound "audio/ambi/rain01.mp3"  loop
    scene ch03_orph02_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_01-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/ambi/carmoving01.mp3"
    pause
    scene ch03_orph02_02 at hand_camera with Dissolve(1.5)
    h "아 시설이 여기에 있었군요."
    d "네 ㅎㅎ."
    d "태워주셔서 정말 감사합니다."
    scene ch03_orph02_03 at hand_camera with Dissolve(0.8)
    d "비가 많이 오는데 운전 조심하세요."
    h "네 ㅎㅎ 고마워요."
    play voice_f "audio/ambi/cardooropen.mp3"
    scene ch03_orph02_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_05 at hand_camera with Dissolve(0.8)
    h "볼일 잘 봐요."
    h "그리고 올때는 내가 돈을 줄테니 텍시 타고 와요. 알았죠?"
    scene ch03_orph02_06 at hand_camera with Dissolve(0.8)
    d "아닙니다. 그렇게까지 안해주셔도 됩니다. 하하."
    d "제가 알아서 잘 집에 가겠습니다."
    scene ch03_orph02_07 at hand_camera with Dissolve(0.8)
    h "그래요 너 편한대로 해요."
    h "혹시 무슨 일 있으면 전화해요."
    h "강해보이려고 허세 부리면 안돼요 알겠죠? 하하."
    d "네 그렇게 할게요. 감사합니다."
    scene ch03_orph02_07-02 with Dissolve(2.0)
    play voice_f "audio/ambi/carmoving01.mp3"
    pause
    scene ch03_orph02_08 at hand_camera with Dissolve(0.8)
    d "..........."
    d "당신은 정말 매력있는 여성이에요 [h_name]."
    d "그리고.."
    d "**(아니다 젠장...괜히 병신 같은 망상하지 말자...)**"
    scene ch03_orph02_09 at hand_camera with Dissolve(1.3)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_orph02_10 at hand_camera with Dissolve(1.2)
    d "헤이 셀린."
    play voice_f "audio/voices/fgrunt01.wav"
    c "!!!!!!!"
    d "잘 지냈어?"
    scene ch03_orph02_11 at hand_camera with Dissolve(0.8)
    c "아.. 안녕 [d_name]."
    c "조금 가....갑작스럽네 하하."
    d "갑작스럽다고? 뭐야 나 여기 오면 안되냐?"
    d "갑자기 부끄럼을 타기 시작한거야 뭐야."
    scene ch03_orph02_12 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_celine", 2, "lust_celine")
    pause
    scene ch03_orph02_13 at hand_camera with Dissolve(0.8)
    c "엄....잘 지냈어?"
    scene ch03_orph02_13-02 at hand_camera with Dissolve(0.8)
    c ".........."
    scene ch03_orph02_14 at hand_camera with Dissolve(0.8)
    d "..............."
    d "괜찮아 셀린?"
    d "컨디션이 좀 안좋아 보여."
    d "얼굴이 좀 빨간거 같은데?"
    scene ch03_orph02_15 at hand_camera with Dissolve(0.8)
    c "아.. 아니야.."
    c "약간 습도도 높고 더워서 그런거야 하하."
    c "메리에게 어서 가봐."
    c "널 기다리고 계실거야."
    c "비오는데 널 오라고 했다고 엄청 걱정하시더라."
    scene ch03_orph02_16 at hand_camera with Dissolve(0.8)
    d "..........."
    d "그래 알겠어. 이따 봐."
    scene ch03_orph02_16-02 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_orph02_16-03 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    c "하............."
    pause
    c "젠장 어떡하지?"
    c "머리에서 지워지질 않아!!"
    scene ch03_orph02_17 with Dissolve(1.5)
    d "셀린이 좀 이상한데? 왜 날 엄청 어색하게 대하지?"
    d "흠......."
    d "지난번에 문자도 그렇고 뭔가 좀 이상해..."
    d "뭐야 남매 같은 사이인데 그냥 말하면 되지 왜 그럴까..."
    scene ch03_orph02_17-02 with Dissolve(2.0)
    pause
    play sound "audio/ambi/knock.mp3"
    n "똑똑똑."
    scene ch03_orph02_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_19 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_orph02_20 at hand_camera with Dissolve(0.8)
    pause
    d "굿모닝 메리."
    scene ch03_orph02_21 at hand_camera with Dissolve(0.8)
    m "굿모닝 허니."
    m "비가 이렇게 많이 올줄 알았으면 부르지 않는건데 미안해."
    scene ch03_orph02_22 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_23 at hand_camera with Dissolve(0.8)
    d "아...아니에요. 랜드레이디가 차로 태워줬어요."
    n "문이 열리고 나타난 메리는 가슴골이 보이는 상의를 입고 있었다."
    n "그것은 [d_name]이 처음 마주하는 메리의 모습이었다."
    scene ch03_orph02_24 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_25 with Dissolve(2.0)
    c "............"
    c "하......"
    c "생리가 시작 되나 오늘 몸이 너무 무겁네....."
    scene ch03_orph02_25-02 with Dissolve(2.0)
    c "............"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3" volume 1.9
    play sound "audio/ambi/rain01.mp3"  loop
    scene ch03_orph02_26 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_orph02_27 at hand_camera with Dissolve(0.8)
    m "면접일자가 정해졌는데 이틀 뒤야."
    m "오늘 오후나 늦어도 내일 너에게 연락이 갈거야."
    m "모르는 번호로 전화가 오더라도 꼭 받아 알았지? "
    scene ch03_orph02_28 at hand_camera with Dissolve(0.8)
    d "넵 알겠습니다. 감사합니다 메리."
    d "메리에게 누가 되지 않도록 면접 잘 할게요."
    scene ch03_orph02_29 at hand_camera with Dissolve(0.8)
    m "그래...."
    m "힌트를 주자면 고객들의 리뷰와 시장 반응을 조사해서 제품의 개선 되어야 하는 점을 정리하는 업무야."
    m "심리학을 공부하고 있는 너에게 아마 잘 맞는 일일거 같아."
    scene ch03_orph02_28 at hand_camera with Dissolve(0.8)
    d "아 그렇다면 제가 잘 할수도 있는 일이겠네요."
    d "기대가 됩니다."
    scene ch03_orph02_30 at hand_camera with Dissolve(0.8)
    m "그래....."
    m "자만은 하지말고 하하."
    m "..........."
    scene ch03_orph02_28 at hand_camera with Dissolve(0.8)
    d "알겠습니다."
    d "저 때문에 어려운 부탁하셨을거 같은데 최선을 다할게요."
    scene ch03_orph02_27 at hand_camera with Dissolve(0.8)
    m "그래 그렇게 말하니 안심되네."
    m "또 한가지 힌트를 주자면 그 친구는... 음...."
    scene ch03_orph02_29 at hand_camera with Dissolve(0.8)
    m "처음 보면 좀 기가 쎄보이는데 외모일 뿐이니까 너무 방어적으로 대화할 필요는 없어."
    m "나와 대화한다 생각하고 있는그대로 너에 대해 얘기하면 돼."
    m "있는 그대로 진솔하게 얘기하는게 면접의 기본이야."
    scene ch03_orph02_28 at hand_camera with Dissolve(0.8)
    d "하하 그렇게 할게요."
    n "[d_name]은 메리와 마주 앉아 대화하고 있었지만 그녀의 말이 전혀 귀에 들어오지 않았다."
    n "그가 생각하고 있는 것은 메리의 나체의 몸과 그녀가 자신을 애무해주는 것들이었다."
    scene ch03_orph02_30-02 at hand_camera with Dissolve(0.8)
    d "근데 여기 좀 덥네요?"
    m "그치? 에어컨 성능이 좀 별로야."
    scene ch03_orph02_30-03 at hand_camera with Dissolve(0.8)
    m "나도 좀 덥네."
    m "자켓 좀 벗을게."
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_orph02_30-04 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    play music "audio/bgm/erotic06.mp3"
    scene ch03_orph02_30-05 at hand_camera with Dissolve(1.2)
    pause
    scene ch03_orph02_30-04 at hand_camera with Dissolve(0.8)
    d "와우 메리....."
    d "그렇게 입은 것은 처음봤어요.."
    scene ch03_orph02_30-05 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/milflaugh01.mp3"
    if not in_replay:
        $ add_point("lust_mary", 3, "lust_mary")
    m "하하하."
    m "어때? 잘 어울려?"
    scene ch03_orph02_30-04 at hand_camera with Dissolve(0.8)
    d "네...."
    d "아.. 아름다워요 메리."
    m "하하 고마워 [d_name]."
    m "리처드는 바람 났냐고 엄청 구박하던데 하하."
    scene ch03_orph02_30-06 at hand_camera with Dissolve(0.8)
    m "크흠.."
    m "그건 그렇고...."
    d ".........."
    scene ch03_orph02_30-07 with Dissolve(1.1)
    m "...................."
    scene ch03_orph02_30-08 with Dissolve(1.1)
    pause
    scene ch03_orph02_31 with Dissolve(1.1)
    n "또 다시 둘 사이에 어색한 침묵이 흘렀다."
    n "그들은 모두 어떤 말을 해야 할지 알았지만 입을 떼지 못했다."
    d ".........."
    m "................"
    scene ch03_orph02_32 at hand_camera with Dissolve(0.8)
    d "저기 메리...."
    pause
    d "지난번에 그 사진들 말이에요......"
    d "저의 그 고추 사진들이요...."
    scene ch03_orph02_33 at hand_camera with Dissolve(0.8)
    m "!!!"
    play sound "audio/ambi/fabric02.mp3"
    scene ch03_orph02_33-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_34 at hand_camera with Dissolve(1.5)
    play voice_f  "audio/voices/fsigh06.mp3"
    m "하.............."
    scene ch03_orph02_35 at hand_camera with Dissolve(0.8)
    n "메리는 한 참을 말없이 창 밖을 바라보았다."
    n "그녀의 사무실에 어색한 침묵이 흘렀다.."
    pause
    pause
    n "한 참을 침묵하던 그녀는 이윽고 입을 열었다."
    m "왜 그런 짓을 했니 [d_name]......."
    m "대체 내가 그걸 보고 어떻게 하라고 그런 짓을 한거야?"
    m "내가 얼마나 놀랐는지 아니?"
    m "그 때 옆에 리처드도 있었다고."
    m "하.....맙소사.."
    m "..................."
    m "어디서 그런 용기가...."
    scene ch03_orph02_36 with Dissolve(1.2)
    pause
    d "........"
    d "미안해요 메리."
    pause
    d "그 날 밤 제가 너무 흥분했었어요."
    d ".................."
    d "그날 메리와 한 대화들로 인해서 우리가 그런것들을 오픈해도 되는 사이가 된거라고 생각했었어요."
    scene ch03_orph02_37 at hand_camera with Dissolve(0.8)
    d "그 날 메리와 포옹을 하고 만지고 그런 것들이...."
    d "그런것들로 하여금 나와 메리가 전보다 더 가까워 졌다고 생각했어요."
    d ".........."
    scene ch03_orph02_35-02 at hand_camera with Dissolve(0.8)
    m ".................."
    m "아니야 허니. 그건 너의 일방적인 생각이야."
    m "연인들 조차도 그런 짓은 잘 하지 않아..."
    m "하물며 너와 나는.....하....."
    pause
    m "내가 너의 그런 행동들을 받아준것은 너를 당황하게 만들고 싶지 않았기 때문이야."
    scene ch03_orph02_38 with Dissolve(2.0)
    pause
    m "................"
    m "마치 나와의 그 오랜 시간들을, 추억들을 다 뒤엎어도 된다는듯한 너의 행동이 얼마나 미웠는지 아니?"
    m "그 날 너의 모습은...."
    m "그동안 나에게 수작을 부렸던 많은 남성들과 전혀 다르지 않았어....."
    scene ch03_orph02_39 at hand_camera with Dissolve(0.8)
    d "정말 미안해요 메리..."
    d ".............."
    d "하지만...."
    d "하지만 전 메리와 더 가까워지고 싶어요.."
    scene ch03_orph02_40 at hand_camera with Dissolve(0.8)
    m "가까워지고 싶다는게 무슨 말이니?"
    m "............."
    m "스윗허트...."
    scene ch03_orph02_40-02 at hand_camera with Dissolve(0.8)
    m "너와 나의 관계는 이미 더 이상 남은 공간이 없을 정도로 가까워.."
    m "무슨 말인지 아니?"
    m "남들이 우릴 보면 이상하게 볼 정도로 가깝다고.."
    scene ch03_orph02_36 at hand_camera with Dissolve(0.8)
    d "......"
    d ".............."
    menu:
        "전 메리를 사랑해요.":
            d "전 메리를 사랑해요."
    pause
    d "저번에 얘기 했잖아요."
    d "메리는 저에게 든든한 보호자이자 아름다운 한 여성이에요."
    d "메일 매일, 하루 종일 메리와 키스하는 상상을 해요."
    if not in_replay:
        $ add_point("lust_mary", 3, "lust_mary")
        $ add_point("love_mary", 3, "love_mary")
    scene ch03_orph02_40-03 at hand_camera with Dissolve(0.8)
    m "맙소사 [d_name]........"
    scene ch03_orph02_40-04 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "메리 옆으로 다가간다.":
            scene ch03_orph02_42 at hand_camera with Dissolve(0.8)
            d "오늘 절 왜 오라고 한거에요?"
            m "뭐?"
    scene ch03_orph02_43 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("sus_mary", 2, "sus_mary")
    m "!!"
    jump ch03_orph03

label ch03_orph03:
    if not in_replay:
        $ persistent.unlock_ch03_orph03 = True
    scene ch03_orph02_43-02 at hand_camera with Dissolve(0.8)
    d "왜 아무 말도 하지 않아요?"
    d "분명 나에게 하고 싶은 말이 있잖아요."
    m "뭐?!!"
    scene ch03_orph02_43-03 at hand_camera with Dissolve(0.8)
    d "그렇죠?"
    d "메리도 나를 생각하면서 무언가 상상하는거죠?"
    m "..........."
    d "아니 지금도 상상하고 있는거죠?"
    m "그만해."
    scene ch03_orph02_43-04 at hand_camera with Dissolve(0.8)
    d "메리는 절 진정으로 사랑하지 않아요?"
    d "메리는 절 다그치기만 하잖아요."
    d "전 그저 메리가 돌봐 온 많은 사람들 중에 한 명인거죠?"
    scene ch03_orph02_44 at hand_camera with Dissolve(0.8)
    d "그 때 공원에서 했던 말들은 그저 장난이었어요?"
    d ".........."
    d "나의 자지를 빨아주는 상상을 한다고 했잖아요."
    m "맙소사..."
    m "............"
    scene ch03_orph02_45 at hand_camera with Dissolve(0.8)
    d "메리가 그런 생각에 휩쌓일 땐 난 메리에게 쓸모있는 존재이지만.."
    d "............."
    d "냉정을 되찾을 땐 난 메리에게 아무것도 아닌 존재인거에요?"
    d "그건 절 가지고 장난치는거에요 메리.."
    scene ch03_orph02_46 at hand_camera with Dissolve(0.8)
    m "하........[d_name]...."
    m "나에게 이러지마.."
    m "그게 지금 대체 무슨 말이야.."
    m "넌 나에게 있어서 단 한순간도 소중한 존재가 아닌적이 없었어."
    m "그리고......."
    scene ch03_orph02_47 at hand_camera with Dissolve(0.8)
    m "나도 널 사랑하지만 우린 서로 다른 뜻의 말을 하고 있어."
    m "무슨 말인지 알겠니?"
    m "난 널 정말 사랑하지만 그게 어떤 사랑인지 너도 알잖니?"
    m "지금 이런 대화를 하는거 자체가 잘못된거야.."
    scene ch03_orph02_48 at hand_camera with Dissolve(0.8)
    d "메리가 무슨 말을 하는지 나도 알아요."
    d "정말이에요.."
    d "메리가 지금 어떤 의미의 말을 하는지 나도 잘알아요..."
    scene ch03_orph02_49 at hand_camera with Dissolve(0.8)
    d "그리고 나도 메리가 말하는 의미의 사랑으로 메리를 사랑한다."
    d "................"
    d "하지만 난 언제나 메리를 생각한다."
    scene ch03_orph02_50 at hand_camera with Dissolve(0.8)
    d "메리를 생각하면 가슴이 두근거리고 나의 자......"
    d "나의 자....."
    d "그러니까 내 몸이 반응한다.."
    scene ch03_orph02_51 at hand_camera with Dissolve(0.8)
    m ".........."
    m "지금 너무 혼란스러워서 뭐라고 말해야 할지 모르겠다..."
    m "지금 나에게 사랑고백 하는거니?"
    m "너의 보호자였던 이 나에게??"
    scene ch03_orph02_51-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    m "지금 너야 말로 날 보며 너와 나의 소중한 기억들을 지우려고 하고 있잖아."
    m ".........."
    m "넌 정말 우리가 돌이킬 수 없는 관계가 되도 상관없다는 듯이 말을 하고 있어..."
    m "정말 그래도 상관 없는거니?"
    scene ch03_orph02_51-03 with Dissolve(1.3)
    m "허니..."
    m "내 삶의 꽃잎들은 이미 떨어졌다."
    m "나는 남편이 있는 나이든 중년의 여성이다."
    scene ch03_orph02_51-04 at hand_camera with Dissolve(0.8)
    m "그런 나를 생각하면 가슴이 두근거린다니..."
    m "대체 그런 말을 어떻게 그렇게 쉽게 할 수 있니?"
    menu:
        n "What should I do?"
        "뭔가 해봐!!":
            play sound "audio/ambi/fabric01.mp3"
            scene ch03_orph02_52 at hand_camera with Dissolve(0.8)
            pause
    scene ch03_orph02_53 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!"
    scene ch03_orph02_54 at hand_camera with Dissolve(0.8)
    m "**(맙소사.......)**"
    scene ch03_orph02_55 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic03.mp3"
    play voice_f "audio/sex/kissshort01.mp3"
    m "읍......."
    if not in_replay:
        $ add_point("lust_mary", 5, "lust_mary")
    scene ch03_orph02_56 at hand_camera with Dissolve(0.8)
    n "그의 행동은 메리가 반응 할 시간을 주지 않았다."
    n "아니 메리는 반응 할 수 없었다."
    n "두 사람의 입술이 서로 포개어졌다."
    play voice_f "audio/sex/kissshort02.mp3"
    scene ch03_orph02_56-02 at hand_camera with Dissolve(0.8)
    pause
    n "그들의 머릿속에 그간에 있었던 책망과 원인을 규명하기 위한 대화는,"
    n "애초에 없었던 일 처럼 깨끗하게 사라졌다."
    n "그 순간 그들이 느끼는 것은 입술 끝에서 부터 전해지는 쾌감이었다."
    n "그리고 극도의 흥분상태에 돌입한 그들은 이내 다음 단계로 들어섰다."
    scene ch03_orph02_57 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/liquid01.mp3"
    n "누가 먼저라할거 없이 이내 그들은 서로의 혀를 교환했다."
    n "서로의 타액이 섞여 만들어지는 액체의 소리가 요란하게 방을 채웠다."
    scene ch03_orph02_58 at hand_camera with Dissolve(0.8)
    n "[d_name]은 수년간 메말라있던 메리의 비밀의 정원에 문을 노크했다."
    scene ch03_orph02_58-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort01.mp3"
    n "[d_name]이 메리의 정원에 들어섰을 때 그를 맞이한것은"
    n "자신의 가장 아름다웠던 날들을 기억하고 있는 한 명의 소녀였다."
    play voice_f "audio/sex/kisslong01.mp3" loop
    image ch03_orph02_kiss01:
        "ch03_orph02_58-03" with dissolve
        0.5
        "ch03_orph02_58-04" with dissolve
        0.5
        "ch03_orph02_58-03" with dissolve
        0.5
        "ch03_orph02_58-04" with dissolve
        0.5
        "ch03_orph02_58-05" with dissolve
        0.5
        "ch03_orph02_58-06" with dissolve
        1.0
        "ch03_orph02_58-05" with dissolve
        0.5
        "ch03_orph02_58-04" with dissolve
        0.5
        "ch03_orph02_58-03" with dissolve
        0.5
        repeat
    scene ch03_orph02_kiss01 at hand_camera
    pause
    n "[d_name]은 머리가 하얗게되어 자신이 어떤 행동을 하는지 제대로 인지하지 못했다."
    n "그의 몸은 그저 본능에 따라 움직였다."
    scene ch03_orph02_59 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    if not in_replay:
        $ add_point("sus_mary", 2, "sus_mary")
    scene ch03_orph02_59-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fmoanshort.mp3"
    m "웁..웁..."
    play voice_f "audio/sex/kisslong01.mp3" loop
    scene ch03_orph02_60 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_61 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 5, "lust_mary")
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_orph02_61-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_61-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_61-04 with Dissolve(1.2)
    pause
    scene ch03_orph02_61-05 at hand_camera with Dissolve(0.8)
    pause
    stop voice_f
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_orph02_01 with Dissolve(1.5)
    pause
    scene ch03_orph02_61-06 with Dissolve(1.2)
    play music "audio/bgm/erotic01.mp3"
    play voice_f "audio/sex/kisslong02.mp3" loop
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    d "하..메리............"
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_orph02_62 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_63 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_64 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    stop voice_f
    scene ch03_orph02_65 at hand_camera with Dissolve(0.8)
    m "그만!!!!!!!"
    scene ch03_orph02_65-02 at hand_camera with Dissolve(0.8)
    d "왜그래요?"
    d "제가 뭐 잘못했어요?"
    scene ch03_orph02_65 at hand_camera with Dissolve(0.8)
    m "............."
    m "이건 정말 잘못된거야..."
    scene ch03_orph02_66 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!"
    scene ch03_orph02_66-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_67 at hand_camera with Dissolve(0.8)
    d "괜찮아요 메리..."
    d "당신은 지금 너무 아름다워요..."
    scene ch03_orph02_67-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_67-03 at hand_camera with Dissolve(0.8)
    d "................."
    d "우리 사이의 약속 기억나요?"
    scene ch03_orph02_67 at hand_camera with Dissolve(0.8)
    m "................"
    scene ch03_orph02_68 at hand_camera with Dissolve(0.8)
    d "난 그저 약속대로 서로에게 솔찍해졌음 해요."
    d "......................."
    d "서로 거짓말하지 않기로 약속했잖아요."
    scene ch03_orph02_69 at hand_camera with Dissolve(0.8)
    m "............."
    menu:
        "내 자지를 보고싶죠?":
            d "내 자지를 보고싶죠?"
            if not in_replay:
                $ add_point("lust_mary", 2, "lust_mary")
        "지금 메리가 뭘 생각하고 있는지 알아요.":

            d "지금 메리가 뭘 생각하고 있는지 알아요."
    scene ch03_orph02_70 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fwhat01.mp3"
    m "뭐?!!"
    scene ch03_orph02_70-02 at hand_camera with Dissolve(0.8)
    d "내 자지요."
    scene ch03_orph02_70-03 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!!!!!!"
    scene ch03_orph02_70-02 at hand_camera with Dissolve(0.8)
    d "................."
    d "내 자지가 보고싶죠?"
    pause
    d "그게 이렇게 비가 많이오는데도 날 부른 이유잖아요."
    d "그리고 그렇게 가슴이 보이는 옷을 입은 이유잖아요."
    scene ch03_orph02_71 at hand_camera with Dissolve(0.8)
    m "하....[d_name]."
    m "또 무슨 말 하는거야...."
    m "대체 나에게 그런 말을 왜 하는거니?"
    scene ch03_orph02_71-02 at hand_camera with Dissolve(0.8)
    m "자 그래! 너와 나는 이제 연인 처럼 키스했어."
    m "좋아. 이건 우리 둘 사이의 비밀이라고 쳐. 그런데.."
    m "무...물론 정말 좋았지....."
    m "근데 너의 그...자....자지?!!"
    m "이 세계가 멸망해도 그런 일은 일어나지 않을거야!"
    scene ch03_orph02_72 at hand_camera with Dissolve(0.8)
    d "............."
    d "정말이에요 메리?"
    d "그럼 모니터의 저 사진들은 뭐에요?"
    scene ch03_orph02_71-02 at hand_camera with Dissolve(0.8)
    m "!!!!!!!"
    m "그...그건...."
    scene ch03_orph02_72-02 at hand_camera with Dissolve(0.8)
    m "그...그건 사진을 지우려고 폰을 컴퓨터에 연결했다가 사진이 화면에 뜬것일 뿐이야!"
    d "정말이에요? 정말 그런거에요?"
    d "................."
    d "정말 실제로 보고 싶지 않은거에요?"
    d "정말이에요?"
    scene ch03_orph02_73 at hand_camera with Dissolve(0.8)
    n "[d_name]은 마치 다른 자아가 자신을 지배한것 처럼 메리를 몰아부쳤다."
    n "지금 그에게 메리는 자신과 짝을 이룰 수 있는 한 명의 암컷이었다."
    d "그럼 이대로 돌아갈까요?"
    d "정말 내가 이대로 떠나길 바래요?"
    m "............"
    d "메리가 한 마디만 하면 돼요."
    d "걱정하기 말아요. 메리가 어떤 말을하고 행동을 한다고 난 놀라지 않을거에요."
    m "............"
    d "내걸 보고 싶죠?"
    scene ch03_orph02_74 at hand_camera with Dissolve(0.8)
    d "공원에 갔던 날 이후로 계속 날 상상하죠?"
    d "................."
    d "내가 매일 메리를 상상하는것처럼 말이죠."
    scene ch03_orph02_75 at hand_camera with Dissolve(0.8)
    d "솔직하게 말해줘요 메리."
    d "당신이 저에게 어떤 말을 한다해도 우리 관계가 바뀌는 일은 없을거에요."
    scene ch03_orph02_76 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/fsigh06.mp3"
    m "하아....."
    m "........."
    m ".............."
    m "....................."
    m "그래."
    scene ch03_orph02_76-02 at hand_camera with Dissolve(0.8)
    m "너의 자지를 보고싶어."
    pause
    pause
    m "너의 자지가 보고싶다고...."
    scene ch03_orph02_68 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!"
    n "[d_name]은 그녀의 말 한마디만으로 전신에 흐르는 짜릿함을 느꼈다."
    scene ch03_orph02_77 with Dissolve(1.3)
    menu:
        n "What should I do?"
        "지퍼를 내리고 고추를 꺼낸다.":
            play sound "audio/ambi/zipper.mp3"
            scene ch03_orph02_77-02 at hand_camera with Dissolve(0.8)
            pause
    scene ch03_orph02_78 with Dissolve(2.0)
    c "....."
    scene ch03_orph02_79 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_79-02 at hand_camera with Dissolve(0.8)
    c "오늘 언론사에서 인터뷰 오는데 메리가 기억하고 있나?"
    c "다시 알려줘야 겠네."
    scene ch03_orph02_77-02 with Dissolve(1.5)
    pause
    scene ch03_orph02_80 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_81 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/fsigh06.mp3"
    m "하아..........."
    play music "audio/bgm/erotic10.mp3" volume 2.0
    scene ch03_orph02_82 at hand_camera with Dissolve(0.8)
    m "맙소사 데미안......"
    if not in_replay:
        $ add_point("lust_mary", 5, "lust_mary")
    m "진짜로 저질러 버렸어!!"
    scene ch03_orph02_83 at hand_camera with Dissolve(0.8)
    d "어떤거 같아요?"
    d "........."
    d "사진에서 봤을 때와 느낌이 비슷해요?"
    scene ch03_orph02_84 at hand_camera with Dissolve(1.5)
    m "..........."
    n "그녀는 말 없이 그의 발기를 바라보았다."
    n "그의 우람한 물건을 본 그녀는 말로 형용할 수 없는 복잡한 감정을 느꼈다."
    n "[d_name]의 물건은 그녀의 삶의 가장 큰 공간,"
    n "그녀의 인생에서 비어있던 큰 공간을 채워줄 수 있는 것이었다."
    n "유스센터의 원장이 아닌, 누군가의 엄마이자 아내가 아닌,"
    n "한 명의 여성으로서 경험하지 못한 갈증을 해결해 줄 수 있는 것 말이다."
    scene ch03_orph02_85 at hand_camera with Dissolve(0.8)
    d "궁금해요 메리."
    menu:
        "그 날 이후로도 나의 자지를 빨아주는 생각을 했었어요?":
            d "그 날 이후로도 나의 자지를 빨아주는 생각을 했었어요?"
        "그 날 이후로 메리가 저의 여자가 되는 상상을 했어요.":

            d "그 날 이후로 메리가 저의 여자가 되는 상상을 했어요."
            if not in_replay:
                $ add_point("love_mary", 5, "love_mary")
    scene ch03_orph02_85-02 at hand_camera with Dissolve(0.8)
    m "뭐?!!!!!!!!!!!!!!"
    scene ch03_orph02_86 at hand_camera with Dissolve(0.8)
    m "[d_name].........."
    m "..............."
    d "......."
    menu:
        "지금 해보는거 어때요?":
            d "지금 여기서 해보는거 어때요?"
    scene ch03_orph02_86-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 5, "lust_mary")
    play voice_f  "audio/voices/fwhat01.mp3"
    m "뭐?!!!!!!!!!!!!!!"
    scene ch03_orph02_87 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_89 with Dissolve(1.5)
    d "내가 말했잖아요."
    d "난 메리가 항상 좋은 기분을 느꼈으면 해요."
    d "메리가 원하는 것이 있으면, 내 자지를 빨아서 그게 메리 기분이 나아지게 하는거면 난 항상 오케이에요."
    scene ch03_orph02_90 at hand_camera with Dissolve(0.8)
    m "하....[d_name]."
    m "그런 괴변이 어딨니..."
    m "그런식으로 사람을 조종하려 하면 안돼."
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_orph02_91 at hand_camera with Dissolve(0.8)
    m "..............."
    menu:
        n "What should I do?"
        "그녀에게 더 가까이 다가간다.":
            play sound "audio/ambi/fabric02.mp3"
            scene ch03_orph02_92 with Dissolve(1.3)
            m "!!!!!!!!!!!"
            m "지금 뭐하는거야?!!"
            d "그냥 한 번 해봐요 메리."
            d "난 그저 메리와 더 친밀한 사이가 되고 싶을 뿐이에요."
            d "오늘 우리 둘만의 비밀을 만들어봐요."
            d "작은 키스부터 시작하는거에요 메리...."
    scene ch03_orph02_93 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_92 at hand_camera with Dissolve(0.8)
    m "........."
    d "메리......"
    d "당신의 입술을 느끼고 싶어요."
    d "오늘이 내 인생에서 평생 잊지못할 날로 만들고 싶어요."
    m "........."
    scene ch03_orph02_94 at hand_camera with Dissolve(1.3)
    n "메리는 그녀의 손을 그의 성기로 가져갔다."
    scene ch03_orph02_95 with Dissolve(2.0)
    n "그리고 이내 그의 성기를 움켜쥐었다."
    n "그녀의 손에 그의 성기의 뜨거운 온기가 느껴졌다."
    n "평생 한 남자의 아내로 살아온 그녀는 [d_name]의 굵은 성기를 잡는것 만으로 압도당했다."
    d "아....."
    scene ch03_orph02_96 at hand_camera with Dissolve(0.8)
    d "메리......"
    scene ch03_orph02_97 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_97-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 5, "lust_mary")
    m "**(난 저주 받을거야....)**"
    m "**(메리.....너 왜 진짜로 하려고 하는거니?)**"
    m "**(어떻게 [d_name]의 자지를 내 입에.......)**"
    m "**(대체 왜 하려고 하냐고!!)**"
    play voice_f "audio/sex/Kissshort03.mp3"
    scene ch03_orph02_98 at hand_camera with Dissolve(0.8)
    d "윽........"
    scene ch03_orph02_98-02alt02 at hand_camera with Dissolve(0.8)
    scene ch03_orph02_98-02 at hand_camera with Dissolve(2.0)
    d "아..............."
    n "메리가 그의 귀두를 입술로 감싸자 그녀의 체온과 미끄러운 타액이 그의 귀두 끝으로부터 느껴졌다."
    scene ch03_orph02_98-03 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/Kissshort01.mp3"
    d "크흑...메리...."
    d "당신의 입안에 넣어주세요."
    play voice_f "audio/sex/liquid01.mp3"
    scene ch03_orph02_98-04 at hand_camera with Dissolve(0.8)
    d "아 메리......"
    d "당신의 입안....아 미칠거 같아요.."
    scene ch03_orph02_98-05 at hand_camera with Dissolve(0.8)
    d "더 깊게요!!"
    scene ch03_orph02_98-06 at hand_camera with Dissolve(0.8)
    m "................"
    play voice_f "audio/sex/liquid02.mp3"
    scene ch03_orph02_98-07 at hand_camera with Dissolve(0.8)
    d "아 메리!!!!!"
    play voice_f "audio/sex/gag01.mp3"
    m "끄억......"
    scene ch03_orph02_98-07-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag02.wav"
    m "커헉..........."
    n "메리의 움직임은 그녀의 이타적인 성격을 그대로 반영했다."
    n "그녀는 자신의 입으로 그의 성기를 온전히 감싸려 했다."
    n "마치 그녀가 [d_name]이라는 사람 자체를 케어하려 하듯이.."
    scene ch03_orph02_98-08 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    d "아 메리 그거에요!!"
    d "아..........."
    d "이제 움..움직여 주세요."
    pause


    image v03_mary_bj01:
        function v03_mary_bj01
    $ anim_speed = 0.033
    $ last_anim_speed = anim_speed
    $ start_time = 0.0


    scene v03_mary_bj01
    play voice_f "audio/sex/oral03.mp3" loop volume 2.0
    call screen v03_mary_bj01 with dissolve
    pause
    scene ch03_orph02_98-09 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag01.mp3"
    m "억...."
    m "억.........."
    play voice_f "audio/sex/gag03.wav"
    m "꺼억............"
    scene ch03_orph02_98-10 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/gag01.mp3"
    m "억......"
    scene ch03_orph02_98-10-02 with Dissolve(0.5)
    play voice_f "audio/sex/gag02.wav"
    scene ch03_orph02_98-10 at hand_camera with Dissolve(0.8)
    n "메리가 그의 성기를 그녀의 한계까지 밀어넣자"
    n "그의 귀두에 메리의 목젖이 느껴졌다."
    scene ch03_orph02_98-11 at hand_camera with Dissolve(0.8)
    d "아 메리!!!!!!!!"
    play voice_f "audio/sex/gag03.wav"
    scene ch03_orph02_98-12 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/breath01.mp3"
    m "하아!!!!!"
    m "하악 하악..."
    scene ch03_orph02_98-12-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/breath02.mp3"
    m "하악 하악..."
    m "이거 너무 커....."
    scene ch03_orph02_98-13 at hand_camera with Dissolve(1.5)
    d "당신의 입안은 정말 너무 느낌이 좋아요."
    d "당신은 정말 사랑스러워요."
    d "그거 알고 있었어요?"
    m ".............."
    menu:
        "그녀의 입에 손가락을 넣는다.":
            play voice_f "audio/sex/liquid01.mp3"
            scene ch03_orph02_98-14 at hand_camera with Dissolve(1.3)
            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            m "**(!!!!)**"
            m "**(나 지금 뭐하고 있는거지??)**"
            n "그녀는 마치 최면에 걸린것처럼 [d_name]의 그 어떤 행동도 거부감을 나타내지 않았다."
            n "오직 그의 눈만을 바라볼 뿐이었다."
            d "어서요 메리."
            d "다시 입에 넣어줘요."
    if love_mary >= 9:
        scene ch03_orph02_98-14-03 at hand_camera with Dissolve(1.5)
        pause
        scene ch03_orph02_98-14-04 at hand_camera with Dissolve(1.5)
        pause
        scene ch03_orph02_98-14-05 at hand_camera with Dissolve(0.8)
        pause
        scene ch03_orph02_98-14-06 at hand_camera with Dissolve(0.8)
        pause
        play voice_f "audio/sex/liquid01.mp3"
        scene ch03_orph02_98-14-07 at hand_camera with Dissolve(0.8)
        pause
        scene ch03_orph02_98-14-08 at hand_camera with Dissolve(0.8)
        pause
        play voice_f "audio/sex/Kissshort02.mp3"
        scene ch03_orph02_98-14-09 at hand_camera with Dissolve(0.8)
        pause
        scene ch03_orph02_98-14-10 at hand_camera with Dissolve(0.8)
        d "마이갓 메리......."
        d "당신의 입술은 정말 최고에요..."
    scene ch03_orph02_98-14-02 at hand_camera with Dissolve(0.8)
    pause    
    scene ch03_orph02_98-14-11 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag01.mp3"
    m "꺼억.."


    image v03_mary_bj02:
        function v03_mary_bj02
    $ anim_speed = 0.033
    $ last_anim_speed = anim_speed
    $ start_time = 0.0


    scene v03_mary_bj02
    play voice_f "audio/sex/oral03.mp3" loop volume 2.0
    call screen v03_mary_bj02 with dissolve
    pause
    scene ch03_orph02_98-15 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    m "억......"
    stop voice_f
    play sound "audio/ambi/knock.mp3"
    n "똑똑똑"
    scene ch03_orph02_99 at hand_camera with Dissolve(0.3)
    play voice_f "audio/sex/gag01.mp3"
    m "!!!!!!!!!!!"
    scene ch03_orph02_100 at hand_camera with Dissolve(0.3)
    d "!!!!!!"
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_orph02_101 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal04.mp3"
    c "안에 있어요 메리?"
    scene ch03_orph02_102 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_102-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_103 at hand_camera with Dissolve(0.8)
    c "..........."
    c "아 저.. 메리."
    scene ch03_orph02_104 at hand_camera with Dissolve(0.8)
    m "네 셀린? 무슨 일 있어요?"
    scene ch03_orph02_105 at hand_camera with Dissolve(0.8)
    c "**(맙소사 메리!)**"
    c "**(메리가 뭘 입고있는거지? ㅎㅎ)**"
    c "**(그녀가 지금 파티복을 입고 있는 건가?......)**"
    c "**(.............)**"
    c "이따가 언론사에서 인터뷰하러 오는거 기억하고 있죠?"
    c "혹시 해서 말씀드려요."
    scene ch03_orph02_106 at hand_camera with Dissolve(0.8)
    m "아 고마워요. 기억하고 있었어요."
    m "아.. 지금... [d_name]이 인터뷰 준비를 도와주고 있었어요 하하."
    scene ch03_orph02_107 at hand_camera with Dissolve(0.8)
    c "아 그랬었군요."
    scene ch03_orph02_108 at hand_camera with Dissolve(0.8)
    c "혹시 필요한게 있으면 말씀하세요."
    c "언론사에서 도착 10분전에 전화 준다고 했으니 연락오면 말씀드릴게요."
    scene ch03_orph02_109 at hand_camera with Dissolve(0.8)
    m "그렇게 할게요."
    m "고마워요."
    c "천만에요 헤헤."
    play sound  "audio/ambi/dooropen03.mp3"
    scene ch03_orph02_110 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_111 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_orph02_112 with dissolve
    play sound  "audio/ambi/doorclose.mp3"
    scene ch03_orph02_113 at hand_camera with Dissolve(1.3)
    c "뭐지?....."
    c "내가 잘못 본건가?"
    if not in_replay:
        $ add_point("lust_celine", 2, "lust_celine")
    scene ch03_orph02_114 at hand_camera with Dissolve(0.8)
    c "..........."
    c "설마....."
    c "저들 진짜로 일을 벌리는거야??!!!"
    c "오 마이 갓......."
    scene ch03_orph02_115 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    m "하............."
    m "심장이 떨어지는 줄 알았네...."
    scene ch03_orph02_116 at hand_camera with Dissolve(0.8)
    m "맙소사........"
    m "[d_name]........"
    scene ch03_orph02_117 at hand_camera with Dissolve(1.3)
    m "어서 가 허니."
    m "회사에서 전화 오면 면접 일정 잘 기억해."
    scene ch03_orph02_118 at hand_camera with Dissolve(0.8)
    d "........"
    d "알겠어요...."
    scene ch03_orph02_119 at hand_camera with Dissolve(1.3)
    d "........."
    m ".............."
    scene ch03_orph02_119-02 at hand_camera with Dissolve(0.8)
    n "그들은 한 동안 아무 말도 할 수 없었다."
    n "그녀의 머리에 이성이 다시 찾아오자 형용할 수 없는 후회가 밀려왔다."
    scene ch03_orph02_120 at hand_camera with Dissolve(1.5)
    m "맙소사 방금 무슨 일이 일어난거지?"
    m "우리 무슨 일을 저지른거지?"
    m "미안해 허니..."
    m "어떻게 내가 그런 짓을..."
    scene ch03_orph02_121 at hand_camera with Dissolve(0.8)
    d "..............."
    d "아니에요 메리..전 정말 좋았어요.."
    d "그저 메리와 저,서로를 아끼는 사이에서 일어날 수 있는 일이잖아요."
    m ".........."
    scene ch03_orph02_120 at hand_camera with Dissolve(0.8)
    m "그렇게 생각하니?"
    m "니가 나보다 어른스럽구나 스윗하트."
    scene ch03_orph02_122 at hand_camera with Dissolve(0.8)
    d "사랑해요 메리.."
    d "우린 서로 사랑하잖아요. 그거면 된거에요."
    pause
    d "메리도 절 사랑하죠?"
    m "그래. 난 너무도 널 사랑해."
    d "내가 이렇게 해도 사랑할거에요?"
    m "이렇게 해도라니? 무슨 말이야?"
    pause
    menu:
        n "What should I do?"
        "메리의 엉덩이를 만진다.":
            scene ch03_orph02_122-02 at hand_camera with Dissolve(0.8)
            m "............."
            scene ch03_orph02_123 at hand_camera with Dissolve(0.8)
            n "그녀는 지난번 [d_name]이 그녀를 만졌을때 만큼 놀라지 않았다."
            n "그녀 스스로도 인식하지 못하는 사이에 조금씩 [d_name]에게 자신의 몸을 허락하고 있었다."
            m "[d_name]....어서 나가..."
            m "여기서 이러면 안돼.."
            d "난 메리를 만지고 싶어요.."
            m "............."
            menu:
                "한 발 더 나아간다.":
                    play sound "audio/ambi/fabric01.mp3"
                    scene ch03_orph02_123-02 at hand_camera with Dissolve(1.3)
                    m "헤이!!"
                    scene ch03_orph02_124 at hand_camera with Dissolve(0.8)
                    play sound "audio/ambi/skin01.mp3"
                    m "흐응........"
                    n "[d_name]은 메리의 엉덩이를 쥐었다."
                    n "그의 손길은 메리에게 쾌감이자 수치심으로 다가왔다."
                    play sound "audio/ambi/fabric01.mp3"
                    if not in_replay:
                        $ add_point("lust_mary", 2, "lust_mary")
                    play sound "audio/ambi/fabric01.mp3"
                    scene ch03_orph02_125 at hand_camera with Dissolve(0.8)
                    m "!!!!!!"
                    m "맙소사 [d_name]......"
                    m "지금 뭐하려고....."
                    scene ch03_orph02_126 at hand_camera with Dissolve(0.8)
                    m "이러면 안돼....."
                    scene ch03_orph02_127 at hand_camera with Dissolve(0.8)
                    m "우린 큰 문제에 빠졌다. 이 나쁜녀석...."
                    d "........."
    scene ch03_orph02_128 at hand_camera with Dissolve(0.8)
    m "어서가.."
    d "알겠어요."
    play sound "audio/ambi/dooropen03.mp3"
    scene ch03_orph02_129 at hand_camera with Dissolve(0.8)
    d "안녕히계세요."
    m "그래."
    m "면접 보고나서 전화해줘 알겠지?"
    d "네 전화드릴게요."
    play sound "audio/ambi/doorclose.mp3"
    scene ch03_orph02_130 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    m "하..............."
    m "우린 큰 문제에 빠졌다."
    m "............."
    m "우린 큰 문제에 빠졌다고 허니....."
    scene ch03_orph02_131 with Dissolve(2.0)
    m "......................"
    m "하....메리 아줌마......"
    m "하.......이 미친년아...."
    scene ch03_orph02_132 with Dissolve(2.0)
    m "내가 [d_name]에게 무슨 짓을 저지른거지?..."
    m "말이 씨가 돼버렸구나....."
    m "..............."
    m "정말 말이 씨가 돼버렸어....."
    jump ch03_diner01

label ch03_diner01:
    if not in_replay:
        $ persistent.unlock_ch03_diner01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "A diner on the outskirts of town" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_diner01_01 with Dissolve(1.5)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 2.5 loop
    scene ch03_diner01_02 with Dissolve(1.5)
    tv "이어지는 소식입니다."
    tv "최근 밀프하임 스테이트 전역의 소도시들에서 조직 범죄가 눈에 띄게 증가하고 있습니다."
    scene ch03_diner01_02-02 with Dissolve(1.5)
    if not in_replay:
        $ bio_isabella = True
    tv "특히 외곽 지역을 중심으로 불법 도박장과 마약 유통 조직의 활동이 급격히 확대되고 있는 것으로 확인됐습니다."
    tv "경찰 당국은 서로 다른 도시에서 발생한 사건들 사이에 동일 조직의 개입 정황이 있다고 밝혔습니다."
    tv "이들은 기존의 범죄조직과 다르게 국적을 가리지 않는 다국적 조직으로 밝혀졌습니다."
    scene ch03_diner01_03 at hand_camera with Dissolve(0.8)
    tv "지난 한 달 동안 체포된 관련 인원만 10여 명에 달하지만, 핵심 인물들은 여전히 검거되지 않은 상태입니다."
    tv "일부 지역에서는 심야 총격 사건과 방화 사건까지 이어지며 주민들의 불안이 커지고 있습니다."
    tv "수사 관계자는 이번 조직이 기존 범죄 집단과는 다른 방식으로 자금을 세탁하고 세력을 확장하고 있다고 설명했습니다."
    tv "밀프하임 주 수사국은 관련 인력을 소도시들로 파견해 수사에 박차를 가하겠다는 계획입니다."
    scene ch03_diner01_04 at hand_camera with Dissolve(0.8)
    tv "주지사는 긴급 치안 강화 지침을 발표하며 각 카운티에 추가 예산을 배정하겠다고 밝혔습니다."
    tv "주민들께서는 수상한 움직임을 목격할 경우 즉시 신고해 달라고 당부드립니다."
    play sound "audio/ambi/doorbell.mp3"
    scene ch03_diner01_05 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/rainwindow02.mp3" volume 2.5 loop
    pause
    scene ch03_diner01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_06-02 at hand_camera with Dissolve(0.8)
    unknownf "어서오세요!"
    scene ch03_diner01_07 at hand_camera with Dissolve(0.8)
    do "여기에요 다이애나 형사님."
    if not in_replay:
        $ bio_owen = True
    scene ch03_diner01_08 at hand_camera with Dissolve(0.8)
    di "뭐? 다이애나 형사님?"
    scene ch03_diner01_09 at hand_camera with Dissolve(0.8)
    di "오랜만에 봤다고 그렇게 부르는거니?"
    di "좀 거리감이 느껴지네 하하."
    scene ch03_diner01_09-02 at hand_camera with Dissolve(0.8)
    di "........."
    scene ch03_diner01_10 at hand_camera with Dissolve(0.8)
    do "............"
    do "아니 옷차림이 그게 뭐에요?"
    do "시골로 왔다고 이젠 대충 입고 다니는거에요?"
    do "시골 사람들도 매너라는게 있다구요."
    scene ch03_diner01_11 at hand_camera with Dissolve(0.8)
    di "아 잔소리 하지마. 운동하다 바로 왔어."
    di "어제는 더 노출하고 사무실도 갔었는데 뭘 새삼스럽게."
    scene ch03_diner01_11-02 at hand_camera with Dissolve(0.8)
    do "뭐라고요?!!"
    do "그렇게 입고 경찰서에 갔었다구요?!!"
    scene ch03_diner01_11-03 at hand_camera with Dissolve(0.8)
    di "그렇다니까."
    di "서장도 아주 동공에 지진이 나더라."
    di "어찌나 그렇게 관찰하던지."
    di "아주 눈빛에 내 옷이 벗겨지는 줄 알았다니까."
    di "아 근데 1년 만에 본 보스에게 할 말이 그거 뿐이야?"
    scene ch03_diner01_12 at hand_camera with Dissolve(0.8)
    do "보스라니요."
    do "난 바이스 유닛이에요 이제. 강력반이 아니에요."
    di "그게 그거지 뭐.."
    di "..............."
    scene ch03_diner01_13 with Dissolve(2.0)
    do "근데 언제 여기로 온거에요?"
    do "아니 서운하네요. 여기 왔으면서 나에게 연락도 안주다니."
    do "내가 생각나지도 않았던거에요?"
    di "이렇게 봤으면 된거지 뭐."
    scene ch03_diner01_14 at hand_camera with Dissolve(0.8)
    do "뉴스 보니까 지방으로 파견 된 강력계 형사가 당신뿐만이 아닌거 같어요."
    do "와보니까 어때요?"
    do "시골이라 엄청 심심하죠?"
    scene ch03_diner01_15 at hand_camera with Dissolve(0.8)
    di "아 풍경이 너무 좋아. 공기도 좋고."
    di "사람들도 도시보다 더 여유롭고 친절하고.."
    di "이런 동네에 조직범죄가 급증이라니 믿어지지가 않는다."
    scene ch03_diner01_15-02 at hand_camera with Dissolve(0.8)
    di "근데 내가 널 따라서 밀프하임힐스로 온거 같은 모양새는 별로 안좋아 하하하."
    di "난 처음 이곳 파견 소식 들었을때 니가 무슨 술수라도 쓴줄알았다."
    scene ch03_diner01_16 at hand_camera with Dissolve(0.8)
    do "네? 그게 무슨 말이에요?"
    do "제가 보고 싶어서 보스가 여기로 파견 신청한거 아니었어요??!!"
    do "난 지금까지 그렇게 알고 있었는데요?"
    scene ch03_diner01_15-03 at hand_camera with Dissolve(0.8)
    di "닥쳐."
    di "너네 엄마가 너 잘 지내나 좀 보살펴달라고 하시더라."
    do "하하하하하하하."
    scene ch03_diner01_15-04 at hand_camera with Dissolve(0.8)
    pause
    do "..........."
    do "근데 왜 보자고 했어요?"
    do "나랑 다시 데이트하자고 부른건 아닐거고..."
    do "보스가 먼저 보자고 하는거면 뭔가 중요한게 있을거 같은데.."
    scene ch03_diner01_13 with Dissolve(2.0)
    n "다이애나는 말 없이 맥주를 한모금 들이켰다."
    n "잠시 뜸들인 그녀는 이내 말을 이어갔다."
    scene ch03_diner01_17 at hand_camera with Dissolve(0.8)
    di "너 혹시 AAAE라는 단체를 들어본 적 있어?"
    di "AAAE."
    scene ch03_diner01_18 at hand_camera with Dissolve(0.8)
    do "AAAE?"
    di "으흠."
    do "AAAE라........."
    do "어떤 조직인지 모르겠지만 A학점에 환장한 사람들의 모임으로 보이는데요."
    scene ch03_diner01_19 at hand_camera with Dissolve(0.8)
    di "........"
    di "그게 형사라는 사람의 대답 수준이야?"
    do "어떤 범죄에 연관된거에요?"
    scene ch03_diner01_20 at hand_camera with Dissolve(0.8)
    di "아니야."
    di "어디서 본거야. 그냥 혹시 알까해서 물어본거야."
    scene ch03_diner01_18 at hand_camera with Dissolve(0.8)
    do ".............."
    do "당신은 거짓말 하면 다 티나는거 알죠?"
    scene ch03_diner01_18-02 at hand_camera with Dissolve(1.3)
    do "보스는 오르가즘 연기도 못하잖아요."
    do "사람이 어떻게 그리 직설적인지."
    do "나 상처 받은 적 많다구요."
    scene ch03_diner01_18-03 at hand_camera with Dissolve(0.8)
    di "맙소사 좀 작게 말해.."
    di "하....."
    di "그리고 나 오르가즘 연기 잘하거든?"
    scene ch03_diner01_21 at hand_camera with Dissolve(0.8)
    di "............"
    di "실은 내가 쓸 책상의 서랍칸 밑에 어떤 서류 하나가 있었어."
    di "서류를 열어봤더니 2달러 지폐 한장이 끼워져 있는 사건 리포트였지."
    do "2달러 지폐요?"
    scene ch03_diner01_22 at hand_camera with Dissolve(0.8)
    di "그래.2달러 지폐.."
    di "리포트 내용은 어떤 조직 AAAE에 대한 내용이었어."
    do "수사 보고서였어요?"
    di "아니 수사 보고서는 아니고 수사 필요성에 대한 보고서였어."
    di "자세한 내용은 말해줄 수 없는데 꽤나 내 흥미를 끌더라고."
    scene ch03_diner01_22-02 at hand_camera with Dissolve(0.8)
    do "흠.............."
    di "그래서 말인데 여기 전임 강력반 팀장이 누구였지?"
    scene ch03_diner01_23 at hand_camera with Dissolve(0.8)
    do "음......"
    do "전임 팀장은 에드워드였어요."
    do "저도 자세히는 모르지만 갑작스럽게 경찰을 떠나면서 이 마을에서도 떠난걸로 알고있어요."
    scene ch03_diner01_23-02 at hand_camera with Dissolve(0.8)
    di "경찰을 떠났다는게 무슨말이야?"
    di "아예 은퇴를 했다고?"
    do "네 맞아요. 어떤 사람도 정확한 이유를 못들었다고 하던데요.."
    do "작별 인사도 없이 그냥 사직서만 놓고 사라졌데요."
    scene ch03_diner01_24 at hand_camera with Dissolve(0.8)
    di "......."
    di "흠.........."
    scene ch03_diner01_24-01 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_diner01_24-02 at hand_camera with Dissolve(1.3)
    wait "안녕하세요."
    wait "처음 보는거 같네요. 맞죠?"
    di "네 맞아요."
    wait "과자는 무료로 드리는거에요."
    scene ch03_diner01_24-03 at hand_camera with Dissolve(0.8)
    di "고마워요 헤헤."
    di "잘 먹을게요."
    scene ch03_diner01_24-04 at hand_camera with Dissolve(0.8)
    wait "당신도 오웬 처럼 경찰이신가봐요?"
    wait "그의 상사인거에요?"
    scene ch03_diner01_24-03 at hand_camera with Dissolve(0.8)
    di "네 그렇게 됐네요 하하."
    di "이 동네로 발령 받아서 여기는 처음 왔어요."
    scene ch03_diner01_24-04 at hand_camera with Dissolve(0.8)
    wait "아하."
    wait "어쩐지 제가 얼굴 기억을 잘하는데 얼굴을 모르겠더라니.."
    scene ch03_diner01_24-05 at hand_camera with Dissolve(0.8)
    wait "자주 오세요."
    wait "서비스 팍팍 드릴게요 하하하."
    scene ch03_diner01_24-03 at hand_camera with Dissolve(0.8)
    di "그럴게요 하하. 고마워요."
    scene ch03_diner01_24-06 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_diner01_24-07 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_25 with Dissolve(2.0)
    di "**(뭐야....)**"
    di "**(저 여자 날 탐색하러 왔던거야?)**"
    di "**(하 기가막히네.)**"
    di "**(난 필요없으니까 니가 다 가지세요.)**"
    scene ch03_diner01_26 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_27 at hand_camera with Dissolve(0.8)
    di "젠장 오언! 지금 내 젖이랑 얘기하니?"
    di "그렇게 뚫어져라 쳐다볼거면 형사답게 남이 모르게좀 해라."
    di "아니면 선글라스라도 좀 끼던가."
    scene ch03_diner01_28 at hand_camera with Dissolve(0.8)
    do "아 미안해요 하하하."
    do "저도 모르게 그만 제 눈알이 움직였어요 하하."
    scene ch03_diner01_29 at hand_camera with Dissolve(0.8)
    di "뭐? 내가 아름다워서가 아니라 그저 수컷의 본능에 의해 니 눈깔이 움직인거라고?"
    di "그렇게 표현이 투박하니까 여자들이 널 싫어하는거야."
    di "그래도 거짓말은 안하니까 최악은 아니네."
    scene ch03_diner01_12 at hand_camera with Dissolve(0.8)
    do "놉! 당신이 틀렸어요."
    do "여자들이 날 떠나는 이유는 첫 번째는 내가 경찰이라서고,"
    do "두 번째는 나의 체력을 감당하지 못해서라구요."
    image ch03_diner01_sex01:
        "ch03_diner01_29-02" with dissolve
        0.5
        "ch03_diner01_29-03" with dissolve
        0.5
        repeat
    play sound "audio/sex/penet02.mp3" volume 0.3 loop
    scene ch03_diner01_sex01 at hand_camera
    do "알잖아요."
    do "전 다음 날 아침까지인거."
    stop sound
    scene ch03_diner01_29-04 at hand_camera with Dissolve(0.8)
    do "기억 안나요?"
    scene ch03_diner01_29-05 at hand_camera with Dissolve(0.8)
    do "보스도 그게 힘들어서 날 떠난거잖아요."
    play sound "audio/ambi/rainwindow02.mp3" volume 2.5 loop
    scene ch03_diner01_30 at hand_camera with Dissolve(0.8)
    di "뭐?!!"
    di "..........."
    scene ch03_diner01_31 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/flaugh06.mp3"
    di "하하하하하.오언....."
    di "맙소사.."
    di "부업으로 소설가라도 된거야?"
    di "어이없게 깜빡 속을뻔했네."
    scene ch03_diner01_31-02 at hand_camera with Dissolve(0.8)
    do "하하하하하하."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_diner01_01 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_diner01_33 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_34 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_35 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/fsigh06.mp3"
    di "아 좀 알딸딸하네."
    di "이런...니 덕분에 오늘 운동효과 다 사라졌다."
    di "나쁜 녀석.."
    di "이제 택시 불러서 가야겠다."
    scene ch03_diner01_36 at hand_camera with Dissolve(0.8)
    do "택시요?"
    do "안돼요. 여긴 택시 부르면 1시간 기다리는건 기본이에요."
    do "내가 데려다 줄게요. 보스 차는 내일 와서 찾아가요."
    di "....................."
    di "알겠어."
    scene ch03_diner01_37 with Dissolve(2.0)
    di "아.... 나른하다.."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_diner01_38 with Dissolve(2.0)
    play sound "audio/ambi/rain01.mp3" loop
    n "그들은 비오는 시골 길을 달렸다."
    n "오랜만에 만난 반가움, 그리고 취기와 빗소리에 차안엔 묘한 정적이 흘렀다."
    n "도로를 달리는 타이어 마찰소리와 유리를 때리는 빗방울 소리가 이어지다 다이앤이 말했다."
    play sound "audio/ambi/raincar.mp3" volume 2.0 loop
    scene ch03_diner01_39 at hand_camera with Dissolve(0.8)
    di "술도 마셨고 비도 오고 분위기 죽이네.."
    do "그쵸? 하하."
    do "이게 시골길 드라이브의 매력이라구요."
    do "오랜만에 보스와 만나서 같이 밥먹으니 옛날 생각도 나고 좋네요."
    di "흠......."
    di "운전하는 남자가 너만 아니었으면 완벽한 밤이었는데 안타깝군."
    do "하하하하."
    do "익숙한게 좋은거라구요.. 알아들어요?"
    do "평생 긴장감만 쫓으며 살다간 정작 소중한 것들을 놓친다구요."
    scene ch03_diner01_40 at hand_camera with Dissolve(0.8)
    di "뭐라는거야. 난 긴장감 쫓으며 산적 없어."
    di "단지 금방 흥미를 잃을 뿐이야."
    do "그말이 그말이죠."
    di "뭐야 지금 니가 나에게 소중한 것이라는 말을 하고싶은거야?"
    do "하하하하."
    do "난 당신에게 소중한 존재 맞잖아요? 아니에요?"
    di "1년 전엔 그랬지."
    di "지금은 그렇게 까지 소중한 사람은 아닌데?"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_diner01_40-02 at hand_camera with Dissolve(0.8)
    do "역시 당신은 하나도 안변했네요...."
    di "하하하. 맘대로 생각해."
    scene ch03_diner01_41 with Dissolve(2.0)
    pause
    play sound "audio/ambi/cardooropen.mp3"
    scene ch03_diner01_42 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/rain01.mp3" loop
    pause
    scene ch03_diner01_43 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_diner01_44 at hand_camera with Dissolve(0.8)
    di "태워줘서 고마웠다."
    di "..........."
    pause
    di "사무실에서 봐."
    do "............."
    scene ch03_diner01_45 at hand_camera with Dissolve(0.8)
    do "아 저기 보스.."
    di "허?"
    di "왜 날 그렇게 애절하게 부르는거야?"
    scene ch03_diner01_46 at hand_camera with Dissolve(0.8)
    do "저....."
    pause
    do "비도 오고..."
    do "오랜만에 봐서 반갑기도하고.."
    scene ch03_diner01_47 at hand_camera with Dissolve(0.8)
    pause
    do "보스 집에 들어가도 돼요?"
    do ".........."
    do "오랜만에 얘기 하면서 술도 한잔 더 하고..."
    scene ch03_diner01_48 at hand_camera with Dissolve(0.8)
    pause
    di "........."
    di "뭐야 지금 그 말은?"
    di "...."
    di "나랑 다시 데이트 하자는거야?"
    scene ch03_diner01_49 at hand_camera with Dissolve(0.8)
    do "그게 그러니까..."
    scene ch03_diner01_50 at hand_camera with Dissolve(0.8)
    di "나 이제 직장 동료랑 같이 안잔다.."
    di "그리고 여기 경찰들 많이 사니까 조심해야 돼."
    di "비도 많이 오는데 까불지 말고 빨리 집에가."
    scene ch03_diner01_51 at hand_camera with Dissolve(0.8)
    di "오피스에서 보자. 안녕."
    scene ch03_diner01_47 at hand_camera with Dissolve(0.8)
    do "알겠어요. 나중에 봐요."
    do "피곤할텐데 좀 쉬어요."
    do "........."
    scene ch03_diner01_51-02 at hand_camera with Dissolve(0.8)
    di "그래 운전 조심해."
    scene ch03_diner01_52 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_diner01_53 at hand_camera with Dissolve(1.5)
    do "젠장.....괜히 말했나.."
    pause
    do "하.....이 병신 같은 놈.."
    do "1년만에 만났는데 할 말이 그거 뿐이었냐..."
    stop sound
    jump ch03_range01

label ch03_range01:
    if not in_replay:
        $ persistent.unlock_ch03_range01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next day" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/sus05.mp3"
    scene ch03_range01_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/rifle.mp3" loop
    n "Bang! Bang!"
    scene ch03_range01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_04 at hand_camera with Dissolve(0.8)
    n "Bang! Bang! Bang!"
    scene ch03_range01_05 at hand_camera with Dissolve(0.8)
    n "Bang! Bang!"
    scene ch03_range01_06 at hand_camera with Dissolve(0.8)
    n "Bang! Bang!"
    scene ch03_range01_07 at hand_camera with Dissolve(0.8)
    n "Bang! Bang! Bang!"
    stop sound
    scene ch03_range01_08 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_range01_09 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_10 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/pistol.mp3" loop
    n "Bang! Bang! Bang!"
    scene ch03_range01_11 at hand_camera with Dissolve(0.8)
    n "Bang! Bang! Bang!"
    scene ch03_range01_12 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch03_range01_13 at hand_camera with Dissolve(0.8)
    mi "............."
    scene ch03_range01_14 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_16 at hand_camera with Dissolve(0.8)
    mi "............."
    scene ch03_range01_17 with Dissolve(2.0)
    pause
    scene ch03_range01_18 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/gun.mp3"
    scene ch03_range01_19 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/phonevib.mp3"
    scene ch03_range01_19-02 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch03_range01_20 at hand_camera with Dissolve(0.8)
    mi "여보세요."
    unknownm "안녕 마이클. 잘 지냈나?"
    mi "잘 지냈다.왜 전화 했나?"
    unknownm "왜 전화했냐니."
    unknownm "내가 용건이 있어야만 전화할 수 있는 사람이었나?"
    scene ch03_range01_21 at hand_camera with Dissolve(0.8)
    mi ".............."
    unknownm "............."
    unknownm "하하하하 마이클 농담이야."
    unknownm "젠장 여전히 진지하구만."
    scene ch03_range01_22 at hand_camera with Dissolve(0.8)
    unknownm "오늘도 사격 연습 했나?"
    mi "맞아. 난 늘 정기적으로 연습한다."
    mi "너도 알잖아."
    unknownm "그렇군. 직업병 같은건가?"
    unknownm "얘기만 들어도 오금이 저리는구만."
    unknownm "너 같은 놈들이 지금도 세계에서 작전을 펼치고 있다고 생각하니 이 나라 국민인게 자랑스럽구만."
    scene ch03_range01_23 at hand_camera with Dissolve(1.5)
    mi "..............."
    mi "용건이 뭐야?"
    unknownm "음....."
    unknownm "[h_name]과 얘기는 해봤나?"
    scene ch03_range01_24 at hand_camera with Dissolve(0.8)
    mi "하고 있는 중이다."
    mi "그녀와 그 문제로 얘기 하던 중 일이 생겨서 확실히 결론내지 못하고 돌아왔다."
    unknownm "흠.....그렇군..."
    scene ch03_range01_24-02 at hand_camera with Dissolve(0.8)
    unknownm "헤이 마이클.."
    unknownm "너는 나의 친구다. 그리고..."
    unknownm "너는 나의 친구고. 맞지?"
    scene ch03_range01_22 at hand_camera with Dissolve(0.8)
    unknownm "................."
    unknownm "난 항상 니가 일하는 방식을 좋아했었다."
    unknownm "언제나 모두가 만족하는 솔루션을 제시해줬지."
    unknownm "그래서 그 난리통이 끝난 뒤에도 여전히 이쪽 관리를 너에게 맡긴거야."
    unknownm "뭐 그 덕분에 여기서 나의 입지도 많이 좋아졌지. 그건 정말 너에게 감사한다."
    scene ch03_range01_25 at hand_camera with Dissolve(0.8)
    unknownm "듣고 있나 마이클?"
    scene ch03_range01_26 at hand_camera with Dissolve(1.3)
    mi "듣고 있다. 계속해."
    unknownm "하지만 이번 일은 좀 실망스럽군."
    unknownm "나를 곤란하게 하지마라 마이클."
    unknownm "부탁이다."
    play sound "audio/ambi/lighter.mp3"
    scene ch03_range01_27 at hand_camera with Dissolve(0.8)
    unknownm "여기에서 내가 곤란해지면 니가 곤란해지고..."
    unknownm "그리고.."
    unknownm "그리고 결국 그녀도 곤란해지는거야."
    scene ch03_range01_28 at hand_camera with Dissolve(0.8)
    unknownm "친구에 대한 의리를 지켜라."
    mi "..........."
    mi "의리라...."
    pause
    mi "내가 지금껏 보여준 의리로도 부족한가 보지?"
    scene ch03_range01_29 at hand_camera with Dissolve(0.8)
    unknownm "아니 진심으로 자네를 걱정해서 하는 말이야."
    unknownm "자네가 하지 않으면 내가 나설수 밖에 없어. 잘 생각해봐."
    unknownm "................."
    mi "지금 협박하는 건가?"
    unknownm "협박이라니 마이클."
    unknownm "내가 협박한다고 니가 겁이나 먹겠나?"
    scene ch03_range01_30 at hand_camera with Dissolve(0.8)
    unknownm "난 단지 그녀가 하는 일에 아주 약간의 변화를 주기를 원하는거야."
    unknownm "그렇게 되면 [h_name]과 너, 그리고 나의 수익도 올라가잖아."
    unknownm "모두가 해피할텐데 대체 이게 그렇게 지연되고 있는 이유가 뭐지?"
    unknownm "그녀가 전에도 했던 일인데 왜 지금은 안된다는거야? 범죄도 아니잖아?"
    unknownm "봐. 내가 이 조직에서 [h_name]이 하고있는 일을 합법적인 비지니스와 연결시킨다고 했을때,"
    unknownm "여기서 내가 얼마나 곤란했었는지 너도 알잖아."
    unknownm "........."
    unknownm "이젠 나의 부탁을 들어달라는거야."
    scene ch03_range01_31 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_32 at hand_camera with Dissolve(0.8)
    mi "너도 알지않나."
    scene ch03_range01_33 at hand_camera with Dissolve(0.8)
    mi "일하는 방식은 그녀 스스로 결정할 문제다."
    mi "그리고 그녀가 사장이야. 너나 내가 아니다."
    mi "그녀는 너나 내가 그녀를 알기전부터도 이 일을 해왔다고."
    mi "그리고 더 큰 스튜디오들도 많은데 왜 그렇게 그녀에게 집착하는거야?"
    mi "이젠 그녀를 좀 내버려둬라."
    unknownm "......................."
    scene ch03_range01_34 at hand_camera with Dissolve(0.8)
    unknownm "부디 친구를 실망시키지 마라."
    unknownm "그녀가 하고 있는 촬영 단가 보다 최소 3배가 높잖아. 이걸로 그녀를 좀 설득해봐."
    unknownm "..................."
    unknownm "그리고 너의 사격 속도 만큼이나 빠르게 그녀와 대화를 마무리해."
    unknownm "내가 아닌 다른 사람이 나서게 되면 모든게 엉망이 될거야."
    unknownm "이 모델 비지니스에 대해 1도 모르는 인간이 나서면 엉망이 될거라고."
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_range01_35 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_36 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_37 at hand_camera with Dissolve(0.8)
    unknownm "듣고 있나 마이클?"
    scene ch03_range01_38 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_range01_39 at hand_camera with Dissolve(0.8)
    mi "듣고 있다."
    scene ch03_range01_39-02 at hand_camera with Dissolve(0.8)
    unknownm "좋아."
    unknownm "여자를 보내줄테니 오늘 밤은 마음껏 즐기고 내일 [h_name]을 만나봐."
    unknownm "군인이라면 환장하는 여자가 하나 있어. 너도 맘에 들거야."
    unknownm "너도 여자를 좀 만나봐. 그래야 삶이 좀 달라진다고."
    unknownm "언제까지 거기 틀어박혀서 총이나 쏘고 살거야?"
    unknownm "그리고 조만간 술한잔 하자고. 알겠지?"
    mi "..............."
    scene ch03_range01_40 at hand_camera with Dissolve(0.8)
    mi "여자는 필요없다."
    mi "그리고 난 전직 군인이지 지금은 민간인이야."
    mi "그녀와 다시 얘기해보고 너에게 전화하겠다."
    scene ch03_range01_41 at hand_camera with Dissolve(0.8)
    unknownm "알겠네. 그럼 또 통화하세."
    scene ch03_range01_42 at hand_camera with Dissolve(0.8)
    mi "..............."
    scene ch03_range01_43 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_range01_44 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_range01_45 at hand_camera with Dissolve(0.8)
    mi "다른 사람이 나서면 모든게 엉망이 된다고?"
    mi "진짜 엉망이 뭔지 본적도 없는 놈들이 잘도 떠드는구만."
    scene ch03_range01_46 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_range01_47 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_range01_48 at hand_camera with Dissolve(1.3)
    pause
    stop sound
    jump ch03_hstudio02

label ch03_hstudio02:
    if not in_replay:
        $ persistent.unlock_ch03_hstudio02 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next day" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/chill.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hstudio02_01 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hstudio02_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_04 at hand_camera with Dissolve(0.8)
    x "**(오랜만에 촬영이네)**"
    x "**(거의 두 달 만인가?..)**"
    scene ch03_hstudio02_05 at hand_camera with Dissolve(0.8)
    x "**(이것봐.)**"
    x "**(촬영을 안하니까 게을러져서 뱃살이 좀 생겼네.)**"
    x "**(좋지 않아.)**"
    scene ch03_hstudio02_06 at hand_camera with Dissolve(0.8)
    x "............"
    scene ch03_hstudio02_07 at hand_camera with Dissolve(0.8)
    x "**([h_name]에게 스케쥴을 더 많이 잡아달라고 해봐야겠다.)**"
    x "**(거리가 멀어서 한 번 오면 좀 많이 촬영했으면 좋겠어.)**"
    x "**(그게 아마 그녀에게도 좋지 않을까.)**"
    scene ch03_hstudio02_09 at hand_camera with Dissolve(0.8)
    pause
    x "흠........"
    scene ch03_hstudio02_10 at hand_camera with Dissolve(0.8)
    h "부인."
    scene ch03_hstudio02_11 at hand_camera with Dissolve(0.8)
    h "저기 준비됐어요?"
    h "이제 촬영 시작하려구요."
    x "넵 준비됐어요."
    scene ch03_hstudio02_12 at hand_camera with Dissolve(0.8)
    x "어때보여요?"
    x "고객이 보내준 레퍼런스에 잘 매칭 돼요?"
    scene ch03_hstudio02_13 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_14 at hand_camera with Dissolve(0.8)
    h "와우 부인."
    h "고객이 당신 사진을 본다면 전속 모델로 계약하자고 할거 같은걸요?"
    h "당신이 지구에서 가장 아름다운 여성이에요."
    play voice_f "audio/voices/milflaugh06.mp3"
    scene ch03_hstudio02_15 at hand_camera with Dissolve(0.8)
    x "아니다 하하. 그런 말 하지마라."
    x "가장 아름다운 여성은 당신 [h_name]이에요 헤헤."
    play voice_f "audio/voices/flaugh02.mp3"
    scene ch03_hstudio02_14 at hand_camera with Dissolve(0.8)
    h "고마워요 헤헤."
    h "그럼 오늘 촬영할 씬들 다시 한 번 체크 해볼게요."
    scene ch03_hstudio02_16 with Dissolve(1.5)
    pause
    scene ch03_hstudio02_16-02 at hand_camera with Dissolve(1.5)
    x "이 브랜드는 계속 디자인이 과감해지네요 하하."
    h "그쵸?"
    h "여기 디자이너가 부인이 아니면 안된다고 특별히 요청했어요."
    h "부인이 이 브랜드의 거의 전속 모델이 된거 같아요 하하."
    scene ch03_hstudio02_17 at hand_camera with Dissolve(1.5)
    h "이 브랜드에서 먼저 전속 모델 계약 요구를 할거 같아요."
    x "와우. 그럼 정말 좋겠어요 하하."
    x "저도 좋아요. 저의 이미지와도 잘 매칭되는 디자인들이에요."
    scene ch03_hstudio02_18 at hand_camera with Dissolve(0.8)
    h "아 그리고 얘기한대로 내일은 남성 모델과 같이 촬영이 예정 돼 있어요."
    h "속옷 브랜드이긴한데 세미누드를 요구해서 누드 촬영이 있을거에요."
    scene ch03_hstudio02_19 at hand_camera with Dissolve(0.8)
    x "네 기억하고 있어요."
    x "제 커리어에서 누드로는 첫 커플촬영이라 좀 긴장되네요 하하."
    scene ch03_hstudio02_20 at hand_camera with Dissolve(0.8)
    h "마담X는 프로니까 잘 할것이다. 평소처럼 하면 된다."
    h "남자 모델은 내가 컨트롤 할것이니 적정 안해도 된다."
    scene ch03_hstudio02_21 at hand_camera with Dissolve(0.8)
    h "그리고 당연히 모델료는 더 지급 될것이다."
    x "하하하.모델료는 신경쓰지마라. 나와 니가 그런거 신경쓸 사이는 아니다."
    scene ch03_hstudio02_22 at hand_camera with Dissolve(0.8)
    x "난 단지 이 모델일을 위해 내 몸매를 가꾸면서 더 건강해진걸로 만족한다."
    x "그리고 내 모델 커리어 자체를 만들어준 사람이 [h_name]이야."
    x "그런건 절대 신경쓰지말아라."
    scene ch03_hstudio02_23 at hand_camera with Dissolve(0.8)
    h "알겠어요 하하."
    h "그럼 이제 시작할까요?"
    play music "audio/bgm/normal10.mp3" volume 0.7
    scene ch03_hstudio02_24 with Dissolve(2.0)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    scene ch03_hstudio02_24-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋아요."
    scene ch03_hstudio02_24-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    scene ch03_hstudio02_25 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "아주 좋아요 부인."
    h "조금만 더 자신 있는 포즈를 취해주세요."
    scene ch03_hstudio02_26 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    scene ch03_hstudio02_26-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "아주 좋아요."
    scene ch03_hstudio02_26-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_26-04 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    scene ch03_hstudio02_26-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "훌륭해요."
    scene ch03_hstudio02_26-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    h "좋아요. 이제 도도하게 무표정하게 가볼까요?"
    scene ch03_hstudio02_26-07 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    h "좋아요. 그거에요."
    scene ch03_hstudio02_26-08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "엉덩이를 강조해볼까요?"
    scene ch03_hstudio02_26-09 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋아요. 아주 관능적이에요."
    h "모델이 좋으니 제품이 확 살아요 헤헤."
    scene ch03_hstudio02_26-10 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "아주 좋아요."
    h "이렇게 하나하나 정성들여 포즈를 취하는데 정작 사용 되는 사진은 한 두 장인게 안타까워요."
    x "저도 그래요. 나중에 화보집이라고 만들어볼까봐요."
    stop sound
    h "자 이제 라벤더색으로 갈아입을게요."
    scene ch03_hstudio02_27 with Dissolve(2.0)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    h "이번엔 가슴을 좀 강조해주세요."
    scene ch03_hstudio02_27-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "최고에요 부인!"
    scene ch03_hstudio02_27-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    scene ch03_hstudio02_27-04 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_27-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋아요. 자유롭게 포즈를 취해주세요."
    scene ch03_hstudio02_27-06 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    scene ch03_hstudio02_27-07 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_27-08 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_27-09 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_27-10 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_27-11 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    h "너무 아름다워요 부인."
    scene ch03_hstudio02_27-12 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    n "마담X와 [h_name]은 여느때 처럼 열정적으로 각자의 역할에 임했다."
    n "뜨거운 열기속에서 촬영은 순조롭게 진행되었다."
    scene ch03_hstudio02_27-13 at hand_camera with Dissolve(0.8)
    n "최고였어요 부인."
    n "이제 B세트로 갈아입고 의자 포즈 갈게요."
    scene ch03_hstudio02_27-14 at hand_camera with Dissolve(0.8)
    x "알겠어요."
    x "오랜만에 하는 촬영이라 그런지 더 열심히 하게 되네요."
    play music "audio/bgm/erotic09.mp3"
    scene ch03_hstudio02_28 with Dissolve(2.0)
    play sound "audio/ambi/shutter03.mp3" loop
    n "찰칵!"
    h "아주 좋아요!"
    scene ch03_hstudio02_29 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    scene ch03_hstudio02_30 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "엉덩이를 조금만 더 들어볼까요?"
    scene ch03_hstudio02_31 at hand_camera with Dissolve(0.8)
    h "지금 라인 아주 예쁘게 나와요."
    n "찰칵!"
    scene ch03_hstudio02_32 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "아주 좋아요!"
    scene ch03_hstudio02_33 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    h "좋아요, 지금 표정 아주 좋습니다. 그대로 유지해 주세요."
    scene ch03_hstudio02_34 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "조금더 과감하게 가볼까요?."
    scene ch03_hstudio02_34-02 at hand_camera with Dissolve(0.8)
    h "환상적이에요!"
    n "찰칵!"
    scene ch03_hstudio02_34-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    scene ch03_hstudio02_34-04 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_35 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_36 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_hstudio02_37 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3" loop
    n "찰칵!"
    scene ch03_hstudio02_38 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    h "너무 섹시해요. 이 분위기로 마무리해 보겠습니다."
    h "남자를 업신여기는 표정 한 번 해줄래요?"
    x "하하 좋아요."
    scene ch03_hstudio02_38-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio02_39 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "오늘 분위기 너무 좋았습니다, 마지막 컷입니다."
    scene ch03_hstudio02_40 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch03_hstudio02_41 at hand_camera with Dissolve(0.8)
    h "좋아요. 오늘 촬영은 끝났어요."
    h "좋은 촬영이었어요 X."
    scene ch03_hstudio02_42 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh06.mp3"
    x "하하 수고했어요 [h_name]"
    x "[h_name]이 잘 리드해준 덕분에 이번에도 즐겁게 촬영했어요."
    x "나는 가서 옷 갈아입을게요."
    play music "audio/bgm/normal08.mp3" volume 1.5
    scene ch03_hstudio02_43 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio02_43-02 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/phonering02.mp3" loop
    n "전화벨이 울린다."
    h "....."
    stop sound
    scene ch03_hstudio02_44 at hand_camera with Dissolve(0.8)
    mi "안녕 [h_name] 잘 지냈지?"
    h "아 마이클. 안그래도 전화하려고 했었는데..."
    h "아무일 없지?"
    scene ch03_hstudio02_45 at hand_camera with Dissolve(0.8)
    mi "로널드에게서 다시 전화가 왔었어."
    mi "다시 그 얘기를 꺼내더군."
    mi ".........."
    mi "이번엔 좀 강압적이었지."
    h "..............."
    h "저런..."
    h "이번에도 같은 요구인거야?"
    scene ch03_hstudio02_46 at hand_camera with Dissolve(0.8)
    mi "맞아.지난번에 내가 말했던 그 요구야."
    pause
    h "......"
    mi "이런 요구해서 미안해 [h_name]. "
    scene ch03_hstudio02_47 at hand_camera with Dissolve(0.8)
    h "하.....난감하네."
    h "그들이 또 그렇게 말했다 이거지....."
    h "어떻게 해야하지..."
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hstudio02_48 with Dissolve(1.5)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hstudio02_48-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하....마이클.."
    h "난 절대 하지 않을거야."
    h "난 이제 그런 사진 더이상 찍지 않는다는거 알잖아."
    h "내 입장을 분명히 전달했는데 또 그런 요구를 하는 이유가 뭐지?"
    h "맙소사. 더군다나 뭐? 영상?"
    h "내가 무슨 포르노 영화 감독이니?"
    scene ch03_hstudio02_49 at hand_camera with Dissolve(0.8)
    mi "나도 알아 [h_name]."
    mi "하지만 너도 그들을 알잖아."
    mi "니가 하지 않으면 일이 커질거 같아. 이런말 해서 미안하다."
    mi "이번만 좀 어떻게 촬영해주면 안될까?"
    mi "다음엔 내가 그들을 설득해 볼게."
    mi "우리가 다른 납품처를 찾기 전까진 그들에게 일감을 받을 수 밖에 없는거 너도 알잖아."
    scene ch03_hstudio02_50 at hand_camera with Dissolve(0.8)
    h "하....마이클!!"
    h "당장 촬영이 내일인데 마담X와 남자 모델을 둘다 어떻게 설득하냐고!!"
    h "맙소사 마이클.."
    h "성기를 노출한 연출 사진들이라니..."
    scene ch03_hstudio02_51 at hand_camera with Dissolve(0.8)
    h "그렇게 되면 그냥 예전으로 돌아가는거잖아....."
    pause
    play voice_f "audio/voices/fsigh06.mp3"
    h "하.............."
    scene ch03_hstudio02_52 at hand_camera with Dissolve(0.8)
    h "소리 질러서 미안해 마이클."
    h "..............."
    h "지금 선택의 여지는 없는거지?"
    mi "..............."
    mi "지금으로선 그래."
    mi "내 생각엔 일단 큰 충돌은 막는게 나을거 같아."
    mi "이번건은 내가 로널드에게 얘기해서 납품 단가를 좀 올려볼게."
    mi "그정도 말은 통하는 녀석이니까 가능할거야."
    scene ch03_hstudio02_53 at hand_camera with Dissolve(0.8)
    h "아냐 괜찮아. 널 곤란하게 하고싶지 않아."
    h "내가 모델들에게 얘기해보고 다시 전화줄게."
    h "이젠 진짜 다른 거래처를 뚫을 때가 온거 같아."
    mi "그래 나도 그렇게 생각해."
    scene ch03_hstudio02_54 at hand_camera with Dissolve(1.5)
    h "하........"
    x "무슨 일 생겼어요?"
    h "............."
    scene ch03_hstudio02_55 at hand_camera with Dissolve(0.8)
    h "아 저기 부인......"
    h "좀 곤란한 일이 생겼네요."
    x "곤란한 일이요?"
    h "네..."
    scene ch03_hstudio02_56 at hand_camera with Dissolve(0.8)
    h "내일 예정 된 촬영의 성격이 좀 바뀌었어요."
    h "아니 좀 많이 바뀌었다고 해야겠네요.."
    x "촬영의 성격이요? 어떤걸 말하는거에요?"
    scene ch03_hstudio02_60 at hand_camera with Dissolve(0.8)
    h "내일 남자 모델과 함께 전신 누드 촬영을 해야할거 같아요."
    x "!!"
    h "그리고 약간의 성행위 묘사가 있을거에요."
    scene ch03_hstudio02_61 at hand_camera with Dissolve(0.8)
    x "성행위요?!!!!!!!!!"
    x "속옷 브랜드라고 하지않았어요?"
    h "미안해요."
    h "그 브랜드를 소유하고 있는 엔터테인먼트 회사로부터 온 요구에요.."
    x "............"
    x "아무리 그래도 전 날 이렇게 갑자기 바꾼다니 그럴수 있나요?"
    h "그러게 말이에요..."
    x "............"
    x "성행위를 진짜로 한다는거에요??"
    scene ch03_hstudio02_62 at hand_camera with Dissolve(0.8)
    h "아니요 절대 아니에요."
    h "만약 그런거 였으면 당연히 내가 거절했을거에요."
    h "실제 섹스는 아니고 약간의 애무와 성행위 하는 척 할거에요."
    h "내가 카메라 각도를 조절해서 실제 성행위 처럼 보이게 할거에요."
    h "성인 잡지사에 납품할 사진인데 노골적인 삽입은 없는 잡지라서요.."
    scene ch03_hstudio02_63 at hand_camera with Dissolve(0.8)
    x "아 그렇군요...."
    h "정말 미안해요. 내키지 않으면 하지 않아도 돼요."
    scene ch03_hstudio02_63-02 at hand_camera with Dissolve(0.8)
    h "절대 강요하는거 아니에요."
    x "사진은 어디에 실리는건지 알아요?"
    h "사진은 아마 벨벳서사이어티에 실릴거에요.."
    x "!!!!!!!!!!!!!"
    scene ch03_hstudio02_63-03 at hand_camera with Dissolve(0.8)
    x "맙소사.. 그 벨벳서사이어티요?"
    h "네 맞아요."
    x "와우..."
    scene ch03_hstudio02_64 at hand_camera with Dissolve(0.8)
    x "후아.........."
    x "이건 좀 고민되네요."
    x "그 벨벳서사이어티라니.."
    scene ch03_hstudio02_64-02 at hand_camera with Dissolve(0.8)
    x "..............."
    scene ch03_hstudio02_65 at hand_camera with Dissolve(0.8)
    x "좋아요 할게요."
    x "얼굴 공개도 아니고, 실제 섹스도 아닌데 안될게 뭐가 있나요 하하."
    scene ch03_hstudio02_66 at hand_camera with Dissolve(0.8)
    h "하... 정말 고마워요."
    h "이번 모델비용은 내가 더 얹어서 줄게요."
    h "이런 부탁해서 정말정말 미안해요."
    x "하하 그런말 안해도 돼요."
    scene ch03_hstudio02_67 at hand_camera with Dissolve(0.8)
    x "나의 모델 커리어를 만들어준 사람이 [h_name]인데 당연히 해야죠."
    x "그리고 약간 흥분도 되고 흥미진진할거 같아요."
    scene ch03_hstudio02_67-02 at hand_camera with Dissolve(0.8)
    x "어떤 모델이 벨벳 서사이어티에 사진이 실린다는데 마다하겠어요 하하."
    x "제 인생에 새로운 도전이 될거 같네요."
    scene ch03_hstudio02_68 at hand_camera with Dissolve(1.5)
    h "하......고마워요."
    h "언제 나의 집으로 한 번 초대할게요. 꼭 저녁식사 같이해요."
    x "하하 그래요. 기대 할게요."
    x "꼭 초대 해줘요 하하."
    stop sound
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night04.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hhouse01_01 with Dissolve(1.5)
    pause
    play sound "audio/ambi/rainwindow02.mp3" volume 3.0 loop
    scene ch03_hstudio02_70 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio02_71 at hand_camera with Dissolve(1.0)
    n "미친 듯이 폭우가 쏟아지는 늦은 저녁,"
    n "[h_name]은 초조한 모습으로 창가에 서서 전화를 하고 있었다."
    h "하... 알겠어요. 미안해하지 않아도 돼요."
    h "애초에 내 요구가 무리한거였어요."
    h "내가 이런걸 너에게 부탁했다는게 부끄럽네요.."
    scene ch03_hstudio02_72 at hand_camera with Dissolve(0.8)
    h "............"
    h "그렇게 생각해줘서 정말 고마워요."
    h "다음 스케쥴 잡히면 연락할게요."
    h "잘지내요."
    scene ch03_hstudio02_73 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하......내가 이럴줄알았다."
    h "살짝 기대는 했었는데 역시나군."
    h "이렇게 촬영 스크립트를 바꾸면 나 같아도 거절하겠지...."
    scene ch03_hstudio02_74 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하.........."
    h "어디서 성인 잡지 사이즈의 남자 모델을 구하냐 이 밤중에......"
    h "미치겠네....."
    scene ch03_hstudio02_75 at hand_camera with Dissolve(0.8)
    h "레나에게 연락해볼까?"
    h "그녀라면 그런 남자들을 알지 않을까?...."
    scene ch03_hstudio02_76 at hand_camera with Dissolve(0.8)
    h "아냐.....하......"
    h "너무멀고 더군다나 시간도 너무 늦었어....."
    h "하 미치겠네..."
    h "그냥 마이클에게 못하겠다고 할까? 하......."
    h "아니야...그러면 그들이 모든 일을 다 끊을게 분명해......"
    scene ch03_hstudio02_77 at hand_camera with Dissolve(1.3)
    pause
    scene ch03_hstudio02_78 at hand_camera with Dissolve(0.8)
    d "아 [h_name] 거기 있었네요."
    d "괜찮아요?"
    d "........."
    d "무슨 일 있어요?"
    scene ch03_hstudio02_79 at hand_camera with Dissolve(0.8)
    h "아 [d_name]군 집에 있었네요."
    h "제가 저녁식사도 안챙겨주고 미안해요."
    h "내가 일이 좀 생겨서 지금 정신이 없네요."
    scene ch03_hstudio02_80 at hand_camera with Dissolve(0.8)
    d "아니에요 괜찮습니다."
    d "비가 많이오는데 인기척이 없어서 걱정 돼서 당신에게 전화하려던 참이었어요."
    h "아 그랬군요..고마워요."
    scene ch03_hstudio02_81 at hand_camera with Dissolve(0.8)
    d "괜찮아요 [h_name]?"
    d "안색이 좀 안좋은데요?"
    scene ch03_hstudio02_82 at hand_camera with Dissolve(0.8)
    h "아 하하 별일 아니에요.."
    h "별일 아니에요.."
    scene ch03_hstudio02_83 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch03_hstudio02_83-02 at hand_camera with Dissolve(1.3)
    play voice_f "audio/voices/fsigh06.mp3"
    h "하.............."
    pause
    h "사실은 별일 있는거 맞아요....."
    scene ch03_hstudio02_84 at hand_camera with Dissolve(0.8)
    d "왜 그래요?..."
    d "제가 도울 수 있는 일이에요?"
    scene ch03_hstudio02_85 at hand_camera with Dissolve(0.8)
    h "하하 도와줄수 있는 일이냐구요?"
    if not in_replay:
        $ add_point("love_helen", 1, "love_helen")
    h "............"
    n "그녀는 자신도 모르게 [d_name]의 사타구니를 쳐다봤다."
    scene ch03_hstudio02_85-02 at hand_camera with Dissolve(0.8)
    h "............."
    h "**(지금 무슨 생각하는거니 미친년아....)**"
    scene ch03_hstudio02_86 at hand_camera with Dissolve(0.8)
    pause
    h "저기 [d_name]...."
    d "네."
    scene ch03_hstudio02_87 at hand_camera with Dissolve(0.8)
    h "하....아니에요..."
    scene ch03_hstudio02_88 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio02_89 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_90 at hand_camera with Dissolve(0.8)
    d "저기 [h_name]...."
    d "무슨 일인지는 모르겠지만 편하게 얘기해요."
    d "제가 도울 수 있는 일일지도 모르잖아요."
    h "..........."
    h "저기 [d_name]...."
    pause
    h "나에게 문제가 하나 생겼어요....."
    d "문제요?"
    scene ch03_hstudio02_91 at hand_camera with Dissolve(1.3)
    h "정말 미안한데 이번 한번만 날 좀 도와줄래요?"
    scene ch03_hstudio02_89 at hand_camera with Dissolve(0.8)
    d "당연히 도와드려야죠."
    d "어떤 일이에요?"
    scene ch03_hstudio02_91-01 at hand_camera with Dissolve(0.8)
    h "그게......"
    h "................."
    scene ch03_hstudio02_89 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_91-02 at hand_camera with Dissolve(0.8)
    h "너 옷을 좀 벗어야 하는데....."
    h ".............."
    h "홀딱....."
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    scene ch03_hstudio02_89 at hand_camera with Dissolve(0.8)
    d "홀딱 벗는다구요??!!!!"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch03_hstudio02_92 at hand_camera with Dissolve(0.8)
    h "정말 미안해요."
    h "랜드레이디가 돼서 세입자에게 이런 부탁을 하다니...."
    scene ch03_hstudio02_93 at hand_camera with Dissolve(0.8)
    h "내가 잠깐 정신이 어떻게 됐어나봐요."
    h "후.........."
    scene ch03_hstudio02_94 at hand_camera with Dissolve(0.8)
    d "하하하 아니에요 걱정하지 마세요."
    d "오히려 재미있을거 같아요 하하."
    d "이거 잘하면 친구들에게 평생 자랑거리 될거 같은걸요? 하하하하하."
    scene ch03_hstudio02_95 at hand_camera with Dissolve(0.8)
    d "방학동안 색다른 경험을 할 수 있고.."
    d "무엇보다 [h_name]을 도울 수 있어서 오히려 기쁩니다."
    scene ch03_hstudio02_95-02 at hand_camera with Dissolve(0.8)
    d "그리고 가면을 쓰는데 안될거 없어요."
    d "물론 [h_name]이 괜찮다면 말이죠 하하하."
    scene ch03_hstudio02_96 at hand_camera with Dissolve(0.8)
    h "아...그.."
    h "이런 표현이 맞는지는 모르겠지만 난 괜찮아요."
    scene ch03_hstudio02_97 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/voices/fsigh06.mp3"
    h "하........."
    h "정말 고마워요 [d_name]....."
    h "아니 미안해요..."
    menu:
        n "What should I do?"
        "그녀의 곁으로 간다.":
            d "저기 [h_name].."
            scene ch03_hstudio02_98 at hand_camera with Dissolve(0.8)
            pause
    scene ch03_hstudio02_99 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "그녀를 위로 한다.":
            d "전 정말 괜찮아요. 너무 자책하지 맗아요."
            d "아니 오히려 [h_name]을 도울 수 있어서 기쁩니다."
            scene ch03_hstudio02_100 at hand_camera with Dissolve(0.8)
            h "!!"
    scene ch03_hstudio02_100-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 2, "lust_helen")
    d "저 [h_name]...."
    d "걱정하지 말아요. 전 정말 괜챃습니다."
    d "절 믿어보세요."
    d "전 이미 준비 돼 있어요."
    scene ch03_hstudio02_101 at hand_camera with Dissolve(0.8)
    h "........."
    d "........."
    scene ch03_hstudio02_102 at hand_camera with Dissolve(1.5)
    h "고마워요."
    h "내가 [d_name]에게 큰 빚을 졌어요."
    scene ch03_hstudio02_103 at hand_camera with Dissolve(1.5)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Shortly after midnight" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night02.mp3"
    scene ch03_hstudio02_104 with Dissolve(1.5)
    pause
    scene ch03_hstudio02_105 at hand_camera with Dissolve(0.8)
    d "하하. 이거 엄청 기대되네."
    pause
    d "긴장되기도 하고."
    d ".............."
    d "누드 촬영을 한다고?!!"
    d "랜드레이디와?!!"
    d "하하하. 다 꺼내놓는다는거잖아."
    scene ch03_hstudio02_106 at hand_camera with Dissolve(0.8)
    d ".............."
    d "근데 [h_name]이 저렇게 난감해 하는건 처음 봤어.."
    d "사진 몇 장 찍는건데 왜 그렇게 나한테 부탁하는걸 힘들어하는거지?"
    d ".............."
    d "내 고추를 다시 보는게 힘든가?"
    d "흠........."
    scene ch03_hstudio02_107 with Dissolve(1.3)
    pause
    scene ch03_hstudio02_108 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio02_109 at hand_camera with Dissolve(1.5)
    play voice_f  "audio/voices/fsigh06.mp3"
    h "하........."
    h "이렇게 하는게 맞나?"
    scene ch03_hstudio02_110 at hand_camera with Dissolve(0.8)
    h "..................."
    h "[d_name]에게 이런 부탁을 하는게 맞는거냐고......."
    scene ch03_hstudio02_111 with Dissolve(1.5)
    h "하........"
    h "모르겠다...[h_name]."
    h "모르겠다고.."
    h "젠장 젠장 젠장."
    jump ch03_hstudio03

label ch03_hstudio03:
    if not in_replay:
        $ persistent.unlock_ch03_hstudio03 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next day" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hstudio03_00 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio03_000 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio03_01 at hand_camera with Dissolve(1.5)
    pause
    stop sound
    scene ch03_hstudio03_01-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_02 at hand_camera with Dissolve(0.8)
    h "먼저 왔있었네요 부인."
    h "비가 참 많이도 내리네요."
    scene ch03_hstudio03_03 at hand_camera with Dissolve(0.8)
    x "굿모닝 [h_name]."
    x "마음도 좀 가라 앉힐겸 책읽고 있었어요."
    scene ch03_hstudio03_04 at hand_camera with Dissolve(0.8)
    d "안녕하세요 [d_name]이라고 합니다."
    d "잘 부탁드립니다."
    d "**(여기가 [h_name]의 스튜디오구나 헤헤.)**"
    scene ch03_hstudio03_04-02 at hand_camera with Dissolve(0.8)
    x "!!!!!!!!!!!"
    x "**([d_name]???)**"
    if not in_replay:
        $ add_point("love_sophia", 1, "love_sophia")
        $ add_point("lust_sophia", 1, "lust_sophia")
    n "소피아가 고개를 들었을 때 거기엔 그의 학생인 [d_name]이 해맑게 웃고 있었다."
    n "그 짧은 순간 소피아는 그가 [h_name]의 가족이라 생각했지만,"
    n "그가 오늘 같이 촬영할 남자 모델이라는 생각에 거대한 절망감을 느꼈다."
    scene ch03_hstudio03_05 at hand_camera with Dissolve(0.8)
    x "아....[h_name]."
    x "잠깐 따로 얘기할 수 있을까요?"
    scene ch03_hstudio03_05-02 at hand_camera with Dissolve(0.8)
    h "네 물론이죠."
    h "..........."
    scene ch03_hstudio03_06 with Dissolve(1.5)
    h "왜 그래요 부인?"
    h "어떤 문제라도 있어요?"
    scene ch03_hstudio03_07 at hand_camera with Dissolve(0.8)
    x "혹시 저 남자애가 오늘 같이 촬영할 모델이에요?"
    x "아니죠?"
    x ".............."
    x "그냥 [h_name]과 아는 사이인거죠?"
    scene ch03_hstudio03_08 at hand_camera with Dissolve(0.8)
    h "음........."
    h "모델은 아니구요 실은....."
    h "실은 그는 제 남자친구에요."
    scene ch03_hstudio03_07 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
        $ add_point("sus_sophia", 1, "sus_sophia")
    x "............."
    x "남...남자 친구요?"
    scene ch03_hstudio03_08 at hand_camera with Dissolve(0.8)
    h "네.."
    h "하도 제가 일하는 모습을 보고 싶다고 해서 같이 왔어요."
    h "나이 차이가 많이 나보이긴 하죠?"
    scene ch03_hstudio03_07 at hand_camera with Dissolve(0.8)
    x "............."
    play voice_f "audio/voices/flaugh02.mp3"
    scene ch03_hstudio03_08 at hand_camera with Dissolve(0.8)
    h "하하 농담이에요."
    h "오늘 같이 촬영할 남자 모델이에요."
    h "아 좀 어리죠? 하하. 미안해요 갑자기 모델이 교체됐어요."
    h "예정 돼 있던 모델이 변경 된 스크립트로는 촬영을 못하겠다고 해서 어쩔 수 없었어요."
    h "정말 미안해요. 이번 건 내 잘못이에요."
    scene ch03_hstudio03_09 at hand_camera with Dissolve(0.8)
    x "아...."
    x "아니에요. 괜찮아요 [h_name]."
    x "나이는 상관 없어요..."
    x "혹시...."
    x "너의 아들이나 친척이에요??"
    scene ch03_hstudio03_10 at hand_camera with Dissolve(0.8)
    h "아 아니에요."
    h "저 그..."
    h "내 친구가 소개해준 모델이에요."
    h "왜요 혹시 같이 촬영하기 불편할거 같아요?"
    scene ch03_hstudio03_09 at hand_camera with Dissolve(0.8)
    x "아니에요."
    x "............."
    x "내가 좀 긴장했나봐요."
    scene ch03_hstudio03_12 at hand_camera with Dissolve(0.8)
    x "아 그리고 오늘 내가 목이 좋지않아서 가능한 말을 하지 않을게요."
    x "상관없죠?"
    h "그럼요 전혀 문제될거 없어요 부인."
    scene ch03_hstudio03_13 at hand_camera with Dissolve(0.8)
    h "오늘은 최대한 부인에게 맞춰서 촬영할게요."
    h "혹시 뭔가 불편하면 신호를 줘요. 바로 중단할게요."
    scene ch03_hstudio03_14 at hand_camera with Dissolve(0.8)
    x "알겠어요. 고마워요."
    x "옷 입고 나갈게요."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch03_hstudio03_15 at hand_camera with Dissolve(0.8)
    n "그들은 촬영에 앞서 스크립트를 다시 확인했다."
    scene ch03_hstudio03_16 at hand_camera with Dissolve(0.8)
    d "와우...이 포즈 대단하네요..."
    h "그...그렇죠? 하하....."
    h "포즈연기가 어색할 수 있는데 내가 알려주는대로만 하면 돼요."
    d "네 기억할게요!"
    play music "audio/bgm/erotic05.mp3"
    scene ch03_hstudio03_17 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio03_18 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    scene ch03_hstudio03_19 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_20 at hand_camera with Dissolve(0.8)
    x "자 그럼 촬영 시작할까요?"
    scene ch03_hstudio03_21 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    scene ch03_hstudio03_23 at hand_camera with Dissolve(0.8)
    x "............."
    scene ch03_hstudio03_24 at hand_camera with Dissolve(0.8)
    h "저..... 부인..."
    h "혹시 불편하면 남자 모델을 잠시 안보이는 곳에서 기다리라고 할까요?"
    scene ch03_hstudio03_25 at hand_camera with Dissolve(0.8)
    n "[h_name]의 말에 소피아는 속삭이듯 말했다."
    x "괜찮아요."
    x "우리는 모두 프로잖아요 그쵸?"
    scene ch03_hstudio03_26 at hand_camera with Dissolve(0.8)
    x "그도 촬영 분위기에 익숙해져야 하니 다 지켜보는게 좋을거 같아요."
    h "그래요 알겠어요."
    h "잠깐만요 부인, 그에게도 잠시 얘기하고 올게요."
    scene ch03_hstudio03_27 at hand_camera with Dissolve(0.8)
    n "[h_name]은 촬영에 앞서 다시 그의 의사를 확인하고 싶었다."
    n "촬영 스크립트에 있는 포즈들은 분명 이 곳 모두에게 버거운 것이었다."
    h "잠깐만 얘기좀 해요."
    scene ch03_hstudio03_28 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio03_29 at hand_camera with Dissolve(0.8)
    x "............"
    x "내 제자에게 나의 벌거벗은 몸을 보여준다고?...."
    x "어떻게 [d_name]과 섹스 연출을 해야하지?....."
    x "하......어떻게 이런일이.."
    x "진정해 소피아.....진정해..."
    x "그냥 둘이서 촬영하는 사진들일 뿐이야.."
    scene ch03_hstudio03_30 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_31 at hand_camera with Dissolve(0.8)
    h "저...."
    h "마지막으로 물어볼게요."
    h "정말 괜찮겠어요 [d_name]?"
    scene ch03_hstudio03_32 at hand_camera with Dissolve(0.8)
    menu:
        n "What should I do?"
        "남자는 한입으로 두 말 하지 않는다.":
            d "하하 또 물어보지 않아도 됩니다."
            scene ch03_hstudio03_33 at hand_camera with Dissolve(0.8)
            d "남자는 절대 한입으로 두 말하지 않습니다."
            d "정말 전 괜찮아요."
            d "친구에게 오늘 일을 얘기 할 생각에 오히려 즐거워요 하하하."
    scene ch03_hstudio03_34 at hand_camera with Dissolve(0.8)
    d "전 이 일을 하기 위해 태어났어요 하하하."
    h "하하 그게 무슨 말이에요."
    d "즐거운 방학, 돈이 되는 알바거리, 아름다운 두 여인."
    d "문제 없어요!"
    scene ch03_hstudio03_35 at hand_camera with Dissolve(0.8)
    h "뭐?!!"
    play voice_f "audio/voices/flaugh02.mp3"
    h "하하 [d_name]이 달변가라는걸 잊고 있었네요."
    h "하하 그럼 어서 들어가요."
    scene ch03_hstudio03_36 at hand_camera with Dissolve(0.8)
    pause
    n "[d_name]은 복잡한 감정의 소용돌이 한 가운데 들어갔다."
    n "자신이 당당한 모습을 보여줌으로서 걱정하고 있는 [h_name]을 안심시키려 했고,"
    n "또한 그럼으로서 그녀에게 자신이 의지할 수 있는 남성임을 어필하고 싶었다."
    n "[h_name]에게 확실히 점수를 따고 싶었던 것이다."
    n "그리고 이름모를 여성 모델에게도 자신이 주도적인 매력있는 남성임을 알리고 싶었다."
    n "그 결과 그는 의도치 않은 잘못된 선택을 하고 말았다."
    menu:
        "그녀의 허리를 안는다.":
            scene ch03_hstudio03_37 at hand_camera with Dissolve(0.8)
            n "그들이 다시 촬영장으로 들어설 때 [d_name]의 손이 그녀의 허리를 감쌌다."
            scene ch03_hstudio03_37-02 at hand_camera with Dissolve(0.8)
            n "그녀는 깜짝 놀랐지만 반응하지 못했다."
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
            n "아니 촬영에 앞서 어색한 분위기를 만들고 싶지 않았다."
            h "!!"
            h ".........."
    scene ch03_hstudio03_37-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_37-04 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_37-05 at hand_camera with Dissolve(0.8)
    x "오 보이.."
    scene ch03_hstudio03_37-06 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
    x "**(그가 [h_name]의 허리에 손을 올려??)**"
    x "**(진짜 [h_name]이랑 사귀는거 아냐??)**"
    x "**(...................)**"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/erotic09.mp3" volume 1.7
    scene ch03_hstudio03_38 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    n "소피아와 [h_name]은 늘 해왔든 능숙하게 서로의 일을 시작했다."
    n "소피아도 [d_name]을 전혀 의식하지 않는 듯 아름답고 과감한 자세들을 연출했다."
    scene ch03_hstudio03_38-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter02.mp3"
    n "찰칵!"
    scene ch03_hstudio03_39 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    n "촬영이 진행 될 수록 스튜디오엔 고요함이 흘렀다."
    n "오로지 들리는 것은 창문을 때리는 빗방울 소리와 카메라 셔터 소리 뿐이었다."
    play sound "audio/ambi/shutter01.mp3"
    scene ch03_hstudio03_39-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_39-03 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3"
    scene ch03_hstudio03_39-04 at hand_camera with Dissolve(1.5)
    n "찰칵!"
    scene ch03_hstudio03_39-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "제3자의 등장으로 인해 약간의 긴장감이 감도는 스튜디오에서,"
    n "촬영은 순조롭고 빠르게 진행되었다."
    n "하지만 촬영이 진행되면서 소피아의 누드 촬영이 다가오고 있었고,"
    scene ch03_hstudio03_40-01 at hand_camera with Dissolve(1.5)
    n "찰칵!"
    play sound "audio/ambi/shutter02.mp3" 
    scene ch03_hstudio03_40-02 at hand_camera with Dissolve(0.8)
    n "그녀 마음속 깊은 곳에 알 수 없는 감정이 휘몰아치고 있었다."
    n "그 감정은 그녀의 심리학 지식으로도 설명할 수 없다는것이 그녀를 더 혼란스럽게 했다."
    scene ch03_hstudio03_40-02-02 with Dissolve(1.3)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    scene ch03_hstudio03_40-02-03 with Dissolve(1.3)
    n "찰칵!"
    n "[h_name]의 카메라 셔터 소리가 연신 스튜디오에 울렸다."
    n "소피아는 아까의 충격을 잊어가는 듯 평소와 다름 없는 그녀만의 포즈를 표현하는데 몰두했다."
    n "그리고 얼마의 시간이 흐르고 촬영의 전반부가 끝났다."
    scene ch03_hstudio03_40-03 with Dissolve(2.0)
    h "너무 수고했어요 부인!"
    h "잠시 쉬고 누드 촬영 시작할게요!"
    scene ch03_hstudio03_40-04 at hand_camera with Dissolve(0.8)
    d "!!!!!!!"
    scene ch03_hstudio03_40-05 at hand_camera with Dissolve(1.5)
    x "휴........."
    scene ch03_hstudio03_40-06 with Dissolve(2.0)
    n "그들은 얼마간 휴식을 가졌다."
    n "[h_name]은 찍은 사진들을 확인 했고, [d_name]은 연신 심호흡을 하며 긴장하지 않으려 애썼다."
    scene ch03_hstudio03_40-07 with Dissolve(1.3)
    pause
    play music "audio/bgm/erotic06.mp3"
    scene ch03_hstudio03_40-08 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!"
    scene ch03_hstudio03_40-09 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch03_hstudio03_40-10 at hand_camera with Dissolve(0.8)
    h "자 촤...촬영 시작할게요....."
    h ".................."
    scene ch03_hstudio03_40-11 at hand_camera with Dissolve(0.8)
    n "소피아는 평정심을 유지하게 위해 계속해서 자신을 다독였다."
    n "하지만 자신의 학생인 [d_name]앞에 자신의 은밀한 곳을 드러내는 것은 쉽지 않았다."
    n "부디 그가 자신을 온전히 알아보지 않기를 바랄뿐이었다."
    scene ch03_hstudio03_40-12 with Dissolve(2.0)
    n "긴장감이 감도는 분위기 속에서 촬영이 다시 시작되었다."
    play sound "audio/ambi/shutter01.mp3"
    scene ch03_hstudio03_41-02 at hand_camera with Dissolve(1.5)
    n "찰칵!"
    scene ch03_hstudio03_40-14 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/shutter02.mp3"
    n "찰칵!"
    scene ch03_hstudio03_40-15 at hand_camera with Dissolve(1.5)
    n "찰칵!"
    h "정말 아름다워요 부인! 어깨 힘 조금만 빼고 자연스럽게."
    scene ch03_hstudio03_41 at hand_camera with Dissolve(0.8)
    d "**(와우....[h_name]과 저 모델은 모두 다 프로구나....)**"
    play sound "audio/ambi/shutter01.mp3"
    d "**(스튜디오의 열기가 대단하네..)**"
    scene ch03_hstudio03_40-13 at hand_camera with Dissolve(1.5)
    n "찰칵!"
    n "[d_name]은 자신이 저 모델과 함께 호흡을 맞출 수 있을지 걱정되기 시작했다."
    n "그만큼 소피아의 퍼포먼스는 프로다웠다."
    n "그녀는 자신의 제자가 보는 앞에서 과감한 포즈와 함께 첫번째 촬영을 마쳤다."
    stop sound
    h "수고 했어요 부인. 이제 2번 착장으로 갈아 입을게요."
    scene ch03_hstudio03_42 at hand_camera with Dissolve(1.5)
    h "잠깐만요. 테스트 샷좀 찍어볼게요."
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch03_hstudio03_43 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    h "허리 라인 아주 예쁘게 나옵니다, 그대로 유지해 주세요."
    scene ch03_hstudio03_43-02 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "소피아는 자신의 학생 앞에서 자신의 은밀한 곳을 드러냈다."
    n "[d_name]이 자신의 얼굴을 알아봤는지 아닌지는 이젠 중요하지 않았다."
    n "치욕스러움, 그리고 이런 선택을 한 자신에 대한 원망.."
    scene ch03_hstudio03_44 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    n "그녀는 처음으로 자신의 음란한 몸에 대해 부끄러움을 느꼈다."
    n "자신의 의지와는 상관없이 발기한 젖꼭지들을 당장이라도 가리고 싶었다."
    n "이러한 경험은 그녀의 나르시즘이란 견고한 성에 미세한 균열을 일으키기 시작했다."
    scene ch03_hstudio03_45 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "와우 방금 표현 정말 좋았어요."
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_45-01 with Dissolve(1.5)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    n "그리고 그 균열은 생각보다 더 빠르게 커지기 시작했다."
    scene ch03_hstudio03_45-02 with Dissolve(1.5)
    n "찰칵!"
    scene ch03_hstudio03_45-03 at hand_camera with Dissolve(1.3)
    h "!!!!!!!"
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    if not in_replay:
        $ add_point("lust_sophia", 5, "lust_sophia")
        $ add_point("lust_helen", 1, "lust_helen")
    play sound "audio/ambi/shutter03.mp3"
    n "그녀는 포즈를 바꿀때마다 [d_name]의 표정을 살폈다."
    play sound "audio/ambi/shutter03.mp3"
    n "촬영 스크립트 보다 더 음란한 자세를 취하면서 그녀의 부끄러움은 묘한 흥분으로 바뀌고 있었다."
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_45-04 at hand_camera with Dissolve(1.3)
    n "찰칵!"
    play sound "audio/ambi/shutter03.mp3"
    d "**(홀리쉣!!!!)**"
    play sound "audio/ambi/shutter03.mp3"
    n "하지만 무너지는 것은 그녀의 나르시즘이 아니었다."
    play sound "audio/ambi/shutter03.mp3"
    n "자신의 몸을 [d_name]에게 보여줌으로서 오히려 그녀의 나르시즘을 완성하고 있었다."
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_45-05 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter02.mp3"
    n "[d_name]이 자신의 몸을 넋을 잃고 바라볼수록 그녀는 쾌감에 휩쌓여 갔다."
    n "그럴수록 그녀의 성기는 붉게 상기되어갔다."
    scene ch03_hstudio03_45-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3"
    scene ch03_hstudio03_46 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    d "..........."
    scene ch03_hstudio03_47 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "조금 더 과감하게 가볼까요?"
    scene ch03_hstudio03_48 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter02.mp3"
    n "찰칵!"
    h "카메라 의식하지 말고, 부인 그대로의 모습을 보여주세요."
    scene ch03_hstudio03_49 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    h "좋아요. 사랑하는 남자에게 날 보여준다는 느낌으로!!"
    scene ch03_hstudio03_50 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter01.mp3"
    h "환상적이에요!!"
    scene ch03_hstudio03_45-06 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    play sound "audio/ambi/rain01.mp3" loop
    scene ch03_hstudio02_01 at hand_camera with Dissolve(1.5)
    pause
    scene ch03_hstudio02_02 at hand_camera with Dissolve(1.5)
    n "촬영은 순조롭게 진행되었다."
    n "어느때와 달리 스튜디오의 열기가 뜨겁다는 걸 소피아와 [h_name]모두 느끼고 있었다."
    scene ch03_hstudio03_51 at hand_camera with Dissolve(1.5)
    stop sound
    play voice_f "audio/voices/fsigh06.mp3"
    h "후아....!"
    h "훌륭해요 부인!"
    h "잠시 쉬었다가 커플 촬영할게요."
    h "고생했어요. 오늘 따라 더 후덥지근하네요."
    play music "audio/bgm/normal04.mp3"
    scene ch03_hstudio03_52 with Dissolve(1.5)
    pause
    scene ch03_hstudio03_53 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_54 at hand_camera with Dissolve(0.8)
    h "당신은 정말 아름다워요 하하."
    h "어쩜 이렇게 가슴 모양이 이쁠까요 헤헤."
    x "하하 그런말 하지말아요."
    x "부끄러워요."
    scene ch03_hstudio03_54-02 at hand_camera with Dissolve(0.8)
    x "이 나이에 누드라니 좀 주책이지 않을까요?"
    h "아니에요! 당신은 지금 팜므파탈이에요."
    x "하하하 그런 말을 들으니 쑥스럽네요."
    scene ch03_hstudio03_55 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_56 at hand_camera with Dissolve(0.8)
    x "............."
    scene ch03_hstudio03_55-02 at hand_camera with Dissolve(0.8)
    x "**(맙소사......)**"
    x "**(이제 [d_name]과 진짜 촬영하는건가?....)**"
    x "**(자신의 제자와 섹스 장면을 연출하는 교수님이 세상에 어디있니.....)**"
    x "**(이건 미친짓이야.....)**"
    scene ch03_hstudio03_57 with Dissolve(2.0)
    h "자 그럼 이제 커플 촬영할게요."
    h "**(괜히 긴팔티를 입었네. 오늘 엄청 습하고 덥네....)**"
    h "저 [d_name].."
    d "네!"
    scene ch03_hstudio03_58 at hand_camera with Dissolve(0.8)
    h "가서 탈의실에 준비 된 속옷으로 갈아입고 와요."
    d "넵 알겠습니다."
    scene ch03_hstudio03_58-02 at hand_camera with Dissolve(0.8)
    h "혹시 무슨 문제있으면 날 불러요. 알았죠?"
    d "네 알겠습니다."
    scene ch03_hstudio03_59 at hand_camera with Dissolve(0.8)
    d "**(막상 시작 되니까 두근두근하는걸....)**"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/erotic03.mp3"
    scene ch03_hstudio03_60 with Dissolve(2.0)
    d "다 입었습니다!!"
    scene ch03_hstudio03_61 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_62 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_sophia", 1, "lust_sophia")
        $ add_point("lust_helen", 1, "lust_helen")
    x "..........."
    h "자 그럼 두 사람 모두 이쪽으로 와주세요."
    scene ch03_hstudio03_64 with Dissolve(2.0)
    d "저.."
    d "잘 부탁드립니다."
    h "하하 그래요. 두분 다 긴장하지 말고 편하게 연기 해주세요."
    scene ch03_hstudio03_65 at hand_camera with Dissolve(0.8)
    x "........."
    h "자 시작할게요."
    h "우선 시작으로..."
    h "부인의 어깨에 친근하게 손을 올려주세요."
    scene ch03_hstudio03_66 at hand_camera with Dissolve(1.3)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch03_hstudio03_66-02 at hand_camera with Dissolve(0.8)
    h "지금 약간 어색한데 두 사람 모두 자유롭게 포즈 취해주세요.."
    h "두 사람 모두 마치 보고 싶은 연인을 오랜만에 봤다라고 상상하고 감정을 잡아주세요."
    h "[d_name]은 너무 긴장하지 마세요."
    h "그냥 연인과 잠깐 재미있게 논다고 생각해요."
    scene ch03_hstudio03_66-03 at hand_camera with Dissolve(0.8)
    d "아..알겠습니다!!"
    d "연인과 재미있게 논다....."
    scene ch03_hstudio03_67 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    h "좋아요!"
    scene ch03_hstudio03_67-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_sophia", 5, "lust_sophia")
        $ add_point("lust_helen", 1, "lust_helen")
    d "**(후아...후아...후아...)**"
    d "**(그녀의 피부가 마치 비단결 같아..)**"
    scene ch03_hstudio03_67-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    h "[d_name]이 그녀를 뒤에서 안아줄래요?"
    scene ch03_hstudio03_68 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "카메라는 없다고 생각하고 사랑하는 연인과 함께 거울을 보고 있는거에요!"
    scene ch03_hstudio03_68-02 at hand_camera with Dissolve(0.8)
    stop sound
    x "**(헤이!!)**"
    x "**(진정해 진정해!! 너 진짜로 나에게 비비고 있잖아!!)**"
    x "**(말을 못하니까 진짜 답답하네.)**"
    scene ch03_hstudio03_68-03 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter02.mp3"
    x "**(맙소사 [d_name]!! 진정해!)**"
    x "**(진정하라고!!)**"
    scene ch03_hstudio03_69 at hand_camera with Dissolve(0.8)
    x "**(힘 조절 좀 하라고!!)**"
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "좋아요! [d_name]은 부인을 더 사랑해주세요!"
    scene ch03_hstudio03_69-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3"
    n "찰칵!"
    x "**(날 사랑해주라고??)**"
    d "**(젠장.....)**"
    scene ch03_hstudio03_70 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    scene ch03_hstudio03_71 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    h "좋아요 더 과감하게 가볼게요."
    s "**(후아...이거 내 생각보다 더 뭔가 진행되는거 같아...)**"
    scene ch03_hstudio03_71-02 at hand_camera with Dissolve(0.8)
    d "**(더 과감하게는 어떻게 해야하지??)**"
    d "**(애무해야하나? 아냐 그건 아닐거야.)**"
    scene ch03_hstudio03_72 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    if not in_replay:
        $ add_point("lust_sophia", 3, "lust_sophia")
        $ add_point("lust_helen", 1, "lust_helen")
    n "찰칵!"
    x "**(마이갓...)**"
    scene ch03_hstudio03_73 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    x "**(그의 몸이 정달 단단해..)**"
    x "**(아...이 녀석!!)**"
    scene ch03_hstudio03_74 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    stop sound
    h "서로의 사타구니를 더 밀착해주세요."
    h "기억하세요. 당신들은 오랜만에 만난 연인이에요!"
    n "촬영이 진행 되면서 소피아는 [d_name]의 과감함에 말려들고 있었다."
    n "지금 그녀의 교수로서의 지배자적 본능 보다 우선시 되는건...."
    scene ch03_hstudio03_74-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "제자에게 만져지고 있는데서 오는 정체모를 감정과..."
    n "한 동안 그녀의 깊은 곳 어딘가에 숨겨져 있던 그녀의 성욕이었다."
    n "찰칵!"
    n "촬영이 진행 될 수록 스튜디오엔 뜨거운 열기가 차오르고 있었다."
    n "모두 각자의 일을 하고 있었지만,"
    n "세 사람 모두 마음 깊은 곳에서 서서히 커지는 무언가를 느끼고 있었다."
    scene ch03_hstudio03_75 at hand_camera with Dissolve(0.8)
    n "찰칵!"
    play sound "audio/ambi/shutter02.mp3"
    h "좋아요! 부인!"
    h "당신은 남자친구에게 거칠게 당하고 있어요!"
    scene ch03_hstudio03_76 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    h "[d_name]! 그녀를 마음대로 범해주세요!!"
    x "**(뭐라고?!!)**"
    d "**(뭐?!! 원래 촬영할 때 저렇게 표현을 하나?..)**"
    d "**(대단한 표현이야!..)**"
    scene ch03_hstudio03_76-02 at hand_camera with Dissolve(0.8)
    stop sound
    h "**(후.....오늘 진짜 덥네.)**"
    h "**(에어컨 상태가 안좋나..)**"
    scene ch03_hstudio03_77 with Dissolve(1.2)
    x "**(아흥.....)**"
    play sound "audio/ambi/shutter01.mp3" volume 0.7 loop
    n "찰칵!"
    h "그래요 그녀에게 너의 사랑을 보여주세요."
    scene ch03_hstudio03_77-02 with Dissolve(1.2)
    n "찰칵!"
    scene ch03_hstudio03_77-03 with Dissolve(1.2)
    n "찰칵!"
    h "좋아요!"
    scene ch03_hstudio03_77-04 with Dissolve(1.2)
    play sound "audio/ambi/shutter01.mp3" volume 0.6 loop
    n "찰칵!"
    n "[d_name]은 자신의 성기를 그녀의 음부에 밀착하여 압박했다."
    n "자신이 맡은 파트를 제대로 해내겠다는 생각에 사로잡혀 불필요한 접촉을 하고 있었다."
    scene ch03_hstudio03_77-05 with Dissolve(1.2)
    n "찰칵!"
    x "**(그렇게 비비지마 [d_name]......)**"
    if not in_replay:
        $ add_point("lust_sophia", 3, "lust_sophia")
        $ add_point("lust_helen", 2, "lust_helen")
    x "**(그렇게 닿지않아도 된다고 이 녀석아!!)**"
    x "**(지금 카메라는 우리 뒤가 아니라 앞에 있잖아!!)**"
    n "소피아는 자신의 정체를 밝히지 않기 위해 목소리를 내지않고 있었다."
    n "그리고 그러한 조건들이 그녀에게 알 수 없는 흥분을 불러일으키고 있었다."
    n "자신의 제자에게 성기가 비벼지고 있는 교수님이 됐다는 생각이 그녀를 수렁으로 떨어뜨렸다."
    scene ch03_hstudio03_78 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    x "**(오 마이갓.....아흥...)**"
    play sound "audio/ambi/shutter03.mp3"
    h "여기는 두 사람만의 공간이에요. 둘만 있다고 생각하세요."
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_79 at hand_camera with Dissolve(0.8)
    h "자 이제....부인..."
    h "그의 앞에 앉아서 천천히 그의 팬티를 잡아요."
    h "앉을 때 가능한 에로틱한 포즈를 연출해줄래요?"
    scene ch03_hstudio03_79-02 at hand_camera with Dissolve(0.8)
    x "............"
    scene ch03_hstudio03_80 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    x "**(하.............)**"
    x "**(무슨 일이 벌어지고 있는건지....)**"
    scene ch03_hstudio03_81 at hand_camera with Dissolve(1.5)
    n "소피아는 [d_name] 앞에 가랑이를 벌리고 앉아 그의 속옷을 잡았다."
    h "좋아요."
    h "**(맙소사.....나 정말 이래도 되나?.....)**"
    scene ch03_hstudio03_81-02 at hand_camera with Dissolve(0.8)
    h "............"
    h "**(촬영 작가인 내가 이렇게 확신이 없는 촬영을 해도 되는거니?)**"
    h "이제 천천히 그의 패...팬티를 내리세요."
    scene ch03_hstudio03_82 at hand_camera with Dissolve(0.8)
    d "**(으아........)**"
    d "**(처음 보는 여성과 [h_name]에게 내 자지를 보여준다 이제.......)**"
    n "스튜디오안에는 완전한 정적이 흘렀다."
    n "오직 창문을 때리는 빗방울 소리만이 울릴 뿐이었다."
    scene ch03_hstudio03_83 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    scene ch03_hstudio03_84 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    play sound "audio/ambi/shutter03.mp3"
    x "!!!!!!!!!"
    play sound "audio/ambi/shutter03.mp3"
    scene ch03_hstudio03_84-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    if not in_replay:
        $ add_point("lust_sophia", 3, "lust_sophia")
        $ add_point("lust_helen", 2, "lust_helen")
    x "**(하아 하아....)**"
    n "소피아의 코에 [d_name]의 체취가 훅 풍겨져 왔다."
    scene ch03_hstudio03_85 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/shutter03.mp3"
    h "그렇게 반만 내린 상태로 잠시 멈출게요. 좋아요."
    play sound "audio/ambi/shutter03.mp3"
    n "찰칵!"
    h "**(하... 너무 더워서 안되겠다.)**"
    scene ch03_hstudio03_85-02 at hand_camera with Dissolve(0.8)
    h "두 사람 모두 잠깐만요."
    h "촬영을 멈춰서 미안해요."
    scene ch03_hstudio03_85-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_85-04 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch03_hstudio03_85-05 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_85-06 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_85-07 at hand_camera with Dissolve(0.8)
    pause
    scene ch03_hstudio03_85-08 at hand_camera with Dissolve(0.8)
    n "갑작스러운 [h_name]의 행동에 스튜디오엔 묘한 긴장감이 엄습했다."



    scene ch03_hstudio03_85-09 at hand_camera with Dissolve(0.8)
    n "그녀의 이 선택에 대한 트리거는 더위와 습도였지만..."
    n "나체의 그들에게 조금이나마 동참함으로서 그녀의 불편한 마음에 대한 해방감을 얻기 위함이었다."
    scene ch03_hstudio03_85-10 at hand_camera with Dissolve(0.8)
    h "하... 이제 좀 살만하네요."
    h "제 맘대로 촬영을 끊어서 미안해요."
    scene ch03_hstudio03_85-10-02 at hand_camera with Dissolve(0.8)
    x "............."
    h "흐름을 끊어서 정말 미안해요."
    scene ch03_hstudio03_85-11 at hand_camera with Dissolve(0.8)
    h "맘 같아선 다 벗고 싶지만..."
    h "전 모델이 아니기에 하하하."
    h "자 그럼 다시 시작할게요."
    pause
    hide screen top_ui_buttons
    jump ch04_hstudio01
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
