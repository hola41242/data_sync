
define phone_mode = False
default phone_menu_state = "home"
default phone_scroll = {}
default chat_adj = ui.adjustment()

default phone_scroll_target = None

init -1 python:
    import re


    phone_config = {
        
        "play_sound_send": True,
        "play_sound_receive": True,
        "no_sound_current_chat": False, 
        
        "preview_no_message": "Empty chat...",
        "channels_title": "Messages",
        "history_timestamp_prefix": "Time:",
        "phone_player_name": "Me",
        "group_added": "{adder} added {participant} to the group.",
        "group_joined": "{participant} joined the group.",
        "group_left": "{participant} left the group.",
        
        "message_font_size": 24,
        "choice_font_size": 24,
        "timestamp_font_size": 20,
        "auto_scroll": True,
        "show_sender_in_preview": True,
        "default_icon": "phone/icon.png",
        "user_colour": "#FFFFFF",
        "character_colour": "#000000",
        "timestamp_colour": "#000000",
        "sort_channels_by_latest": True,
        "message_padding": 0.025,
        "preview_max_length": 25,
        "emojis": {
            "size": 32,
        },
        "phone_theme": "light",  
        "light": {
            
            "message_player_text_colour": "#FFFFFF",
            "message_character_text_colour": "#333333",
            "timestamp_text_colour": "#AAAAAA",
            "header_text_colour": "#FFFFFF",
            "channel_name_text_colour": "#FFFFFF",
            "channel_preview_text_colour": "#BBBBBB",
            "sender_name_text_colour": "#AAAAAA",
            "channel_divider_colour": "#444444",
            "channel_button_hover_background": "#333333",
            "empty_channel_text_colour": "#FFFFFF",
            
            "screen_background_image": "phone/screen.png",
            "header_background_image": "phone/header.png",
            "base_background_image": "phone/base.png",
            "back_button_idle_image": "phone/back.png",
            "back_button_notif_image": "phone/back_notif.png",
            "notification_dot_image": "phone/notif.png",
            "player_bubble_image": "phone/player_bubble.png",
            "player_bubble_hover_image": "phone/player_bubble_hover.png",
            "character_bubble_image": "phone/character_bubble.png",
        },
        "dark": { 
            
            "message_player_text_colour": "#FFFFFF",
            "message_character_text_colour": "#FFFFFF",
            "timestamp_text_colour": "#AAAAAA",
            "header_text_colour": "#FFFFFF",
            "channel_name_text_colour": "#FFFFFF",
            "channel_preview_text_colour": "#BBBBBB",
            "sender_name_text_colour": "#AAAAAA",
            "channel_divider_colour": "#444444",
            "channel_button_hover_background": "#333333",
            "empty_channel_text_colour": "#FFFFFF",
            
            "screen_background_image": "phone/skins/dark_mode/screen.png",
            "header_background_image": "phone/skins/dark_mode/header.png",
            "base_background_image": "phone/skins/dark_mode/base.png",
            "back_button_idle_image": "phone/skins/dark_mode/back.png",
            "back_button_notif_image": "phone/skins/dark_mode/back_notif.png",
            "notification_dot_image": "phone/skins/dark_mode/notif.png",
            "player_bubble_image": "phone/skins/dark_mode/player_bubble.png",
            "player_bubble_hover_image": "phone/skins/dark_mode/player_bubble_hover.png",
            "character_bubble_image": "phone/skins/dark_mode/character_bubble.png",
        },
        "flip": {
            
            "message_player_text_colour": "#FFFFFF",
            "message_character_text_colour": "#000000",
            "timestamp_text_colour": "#000000",
            "header_text_colour": "#000000",
            "channel_name_text_colour": "#000000",
            "channel_preview_text_colour": "#555555",
            "sender_name_text_colour": "#666666",
            "channel_divider_colour": "#E0E0E0",
            "channel_button_hover_background": "#EFEFEF",
            "empty_channel_text_colour": "#000000",
            
            "screen_background_image": "phone/skins/flip_phone/screen.png",
            "header_background_image": "phone/header.png",
            "base_background_image": "phone/skins/flip_phone/base.png",
            "back_button_idle_image": "phone/back.png",
            "back_button_notif_image": "phone/back_notif.png",
            "notification_dot_image": "phone/notif.png",
            "player_bubble_image": "phone/player_bubble.png",
            "player_bubble_hover_image": "phone/player_bubble_hover.png",
            "character_bubble_image": "phone/character_bubble.png",
        },
        "status_bar": {
            
            "message_player_text_colour": "#FFFFFF",
            "message_character_text_colour": "#000000",
            "timestamp_text_colour": "#000000",
            "header_text_colour": "#000000",
            "channel_name_text_colour": "#000000",
            "channel_preview_text_colour": "#555555",
            "sender_name_text_colour": "#666666",
            "channel_divider_colour": "#E0E0E0",
            "channel_button_hover_background": "#EFEFEF",
            "empty_channel_text_colour": "#000000",
            
            "screen_background_image": "phone/screen.png",
            "header_background_image": "phone/skins/status_bar/header.png",
            "base_background_image": "phone/base.png",
            "back_button_idle_image": "phone/back.png",
            "back_button_notif_image": "phone/back_notif.png",
            "notification_dot_image": "phone/notif.png",
            "player_bubble_image": "phone/player_bubble.png",
            "player_bubble_hover_image": "phone/player_bubble_hover.png",
            "character_bubble_image": "phone/character_bubble.png",
        },
        
        "pause": { 
            "do_pause": True, 
            "pause_time": False, 
            "pause_length": 1.0 
        }
    }



    def replace_emojis(text):
        """ Replaces custom emoji tags like <emoji_name> with Ren'Py image tags.
            This is an internal helper function to allow for easy emoji syntax in messages.
            Args:
                text (str): The message text that might contain emoji tags.
        """
        def sub(match):
            name = match.group(1)
            return "{image=%s}" % name
        return re.sub(r"<([A-Za-z0-9_]+)>", sub, text)





    PHONE_SCROLL_BOTTOM = 1000000000.0

    def phone_scroll_initial_position(view_name):
        
        return 0.0 if view_name == "channel_list" else PHONE_SCROLL_BOTTOM

    def phone_scroll_user_changed(value):
        
        global phone_scroll_target
        if current_phone_view is not None:
            phone_scroll[current_phone_view] = max(0.0, float(value))
        
        phone_scroll_target = None

    def phone_scroll_range_changed(adjustment):
        
        
        
        if current_phone_view is not None and phone_scroll_target is not None:
            adjustment.value = phone_scroll_target

    def phone_scroll_bind():
        
        chat_adj.changed = phone_scroll_user_changed
        chat_adj.ranged = phone_scroll_range_changed
        return chat_adj

    def phone_scroll_save_current():
        if current_phone_view is not None:
            
            value = phone_scroll_target if phone_scroll_target is not None else float(chat_adj.value)
            phone_scroll[current_phone_view] = value

    def phone_scroll_restore_current():
        global phone_scroll_target
        phone_scroll_bind()
        if current_phone_view is None:
            phone_scroll_target = None
            return
        phone_scroll_target = phone_scroll.get(current_phone_view, phone_scroll_initial_position(current_phone_view))
        chat_adj.value = phone_scroll_target

    def phone_set_view(view_name):
        global current_phone_view
        if current_phone_view != view_name:
            phone_scroll_save_current()
            current_phone_view = view_name
            phone_scroll_restore_current()
        renpy.restart_interaction()

    def phone_scroll_new_content(channel_name):
        
        
        global phone_scroll_target
        if not phone_config.get("auto_scroll", True):
            return
        phone_scroll[channel_name] = PHONE_SCROLL_BOTTOM
        if current_phone_view == channel_name:
            phone_scroll_bind()
            phone_scroll_target = PHONE_SCROLL_BOTTOM
            chat_adj.value = PHONE_SCROLL_BOTTOM


    def refresh_phone_contact_avatars():
        current_icons = {
            "Sophia": "phone/icons/sophia.png",
            "Olivia": "phone/icons/olivia.png",
        }
        for channel in phone_channel_data.values():
            display_name = channel.get("display_name")
            if display_name in current_icons:
                channel["icon"] = current_icons[display_name]


    def phone_contact_avatar(channel_id):
        channel = phone_channel_data.get(channel_id, {})
        name = str(channel.get("display_name", "")).strip().lower()
        key = str(channel_id).lower()
        if name == "sophia" or key == "sophia_dm":
            return "phone/icons/sophia.png"
        if name == "olivia" or key == "olivia_dm":
            return "phone/icons/olivia.png"
        return channel.get("icon", phone_config["default_icon"])


    def create_phone_channel(channel_id, display_name, participants, icon_path, is_group=False):
        """ Creates a new phone channel, like a DM or a group chat.
            This function sets up the basic information for a new chat conversation.
            Args:
                channel_id (str): A unique identifier for the channel (e.g., "vanessa_dm").
                display_name (str): The name that appears at the top of the chat screen.
                participants (list): A list of strings with the names of everyone in the chat.
                icon_path (str): The file path to the icon for this channel.
                is_group (bool, optional): Set to True if this is a group chat. Defaults to False.
        """
        global phone_channel_data, phone_channels, channel_last_message_id, channel_notifs, channel_seen_latest, channel_visible
        if channel_id not in phone_channel_data:
            phone_channel_data[channel_id] = {
                "display_name": display_name,
                "icon": icon_path,
                "participants": participants,
                "is_group": is_group
            }
            phone_channels[channel_id] = []
            channel_last_message_id[channel_id] = 0
            channel_notifs[channel_id] = False
            channel_seen_latest[channel_id] = True
            channel_visible[channel_id] = True
            channel_latest_global_id[channel_id] = 0


    def send_phone_message(sender, message_text, channel_name, message_kind=0, summary_alt="none", image_x=320, image_y=320, do_pause=True):
        """ Sends a message to a specific phone channel and updates the UI.
            Args:
                sender (str): The name of the character sending the message.
                message_text (str): The content of the message or the path to an image.
                channel_name (str): The unique ID of the channel to send the message to.
                message_kind (int, optional): The type of message. 
                    0=text, 1=timestamp, 2=photo, 3=text with emoji. Defaults to 0.
                summary_alt (str, optional): Alternative text for the channel preview list. Defaults to "none".
                image_x (int, optional): The max width for a photo message. Defaults to 320.
                image_y (int, optional): The max height for a photo message. Defaults to 320.
                do_pause (bool, optional): Whether to pause the game after the message is sent. Defaults to True.
        """
        global _phone_global_message_counter, current_global_id
        
        if channel_name not in phone_channels:
            renpy.log("Tried to send message to non-existent channel: " + channel_name)
            return
        
        if message_kind != 1:
            if sender == phone_config["phone_player_name"]:
                if phone_config.get("play_sound_send", False):
                    renpy.sound.play("audio/phone/send.mp3", channel="sound")
            else:
                play_the_sound = True
                if phone_config.get("no_sound_current_chat", False):
                    if current_phone_view == channel_name:
                        play_the_sound = False
                if phone_config.get("play_sound_receive", False) and play_the_sound:
                    renpy.sound.play("audio/phone/receive.mp3", channel="sound")
        _phone_global_message_counter += 1
        current_global_id = _phone_global_message_counter
        channel_latest_global_id[channel_name] = current_global_id
        last_id = channel_last_message_id.get(channel_name, 0)
        current_id = last_id + 1
        channel_last_message_id[channel_name] = current_id
        message_data = (current_id, sender, message_text, message_kind, current_global_id, summary_alt, image_x, image_y)
        phone_channels[channel_name].append(message_data)
        channel_notifs[channel_name] = True
        channel_seen_latest[channel_name] = False
        phone_scroll_new_content(channel_name)
        renpy.restart_interaction()
        if message_kind == 0:
            narrator.add_history(kind="adv", who=sender, what=message_text)
        elif message_kind == 1:
            narrator.add_history(kind="adv", who=phone_config["history_timestamp_prefix"], what=message_text)
        elif message_kind == 2:
            narrator.add_history(kind="adv", who=sender, what="Sent a photo.")
        renpy.checkpoint()
        if do_pause and phone_config["pause"]["do_pause"]:
            if phone_config["pause"]["pause_time"]:
                renpy.pause(phone_config["pause"]["pause_length"])
            else:
                renpy.pause()


    def clear_notifications():
        """ Marks all channels as read and clears all notification dots.
            This is useful for when the story starts, to clear any pre-loaded messages,
            or if you want to programmatically mark everything as seen.
        """
        global channel_notifs, channel_seen_latest
        for channel_name in phone_channel_data.keys():
            if channel_name in channel_notifs:
                channel_notifs[channel_name] = False
            if channel_name in channel_seen_latest:
                channel_seen_latest[channel_name] = True
        renpy.restart_interaction()


    def reset_phone_data():
        """ Resets all phone data to a clean slate.
            This function clears all channels, messages, and notifications.
            You can add initial setup calls (like create_phone_channel)
            inside this function to pre-populate the phone.
        """
        global current_phone_view, phone_channels, channel_last_message_id, channel_notifs, channel_seen_latest, channel_visible, phone_channel_data
        global channel_latest_global_id, _phone_global_message_counter, phone_scroll, phone_scroll_target
        
        phone_scroll = {}
        phone_scroll_target = None
        chat_adj.value = 0.0
        phone_channel_data = {}
        phone_channels = {}
        channel_last_message_id = {}
        channel_notifs = {}
        channel_seen_latest = {}
        channel_visible = {}
        channel_latest_global_id = {}
        _phone_global_message_counter = 0
        current_phone_view = "channel_list"
        
        create_phone_channel("sophia_dm", "Sophia", ["Sophia", phone_config["phone_player_name"]], "phone/icons/sophia.png")
        create_phone_channel("jason_dm", "Jason", ["Jason", phone_config["phone_player_name"]], "phone/icons/jason.png")
        create_phone_channel("amanda_dm", "Amanda", ["Amanda", phone_config["phone_player_name"]], "phone/icons/amanda.png")
        create_phone_channel("mary_dm", "Mary", ["Mary", phone_config["phone_player_name"]], "phone/icons/mary.png")
        
        send_phone_message("sophia", "Congrats on getting in! Don't be late for your first class.", "sophia_dm", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "Got it, Professor!", "sophia_dm", do_pause=False)
        send_phone_message("sophia", "Heads up, we've got midterms tomorrow. [d_name], you're especially on my radar.", "sophia_dm", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "I'm totally ready for this!", "sophia_dm", do_pause=False)
        send_phone_message("Jason", "I envy you for getting a new phone. here's my number.", "jason_dm", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "Okay, bro.", "jason_dm", do_pause=False)
        send_phone_message("Jason", "images/phone/media/classgirl01.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        send_phone_message("Jason", "Damn, check her out. She's always ready, man.", "jason_dm", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "Damn...", "jason_dm", do_pause=False)
        send_phone_message("Amanda", "Honey. I miss you so much. ❤︎ Don't worry too much about what Frank said. You're always welcome.", "amanda_dm", do_pause=False)
        send_phone_message("Amanda", "images/phone/media/amanda01.jpg", "amanda_dm", 2, summary_alt="amanda Photo", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "Got it. I'll be there soon. Love you Amanda.", "amanda_dm", do_pause=False)
        send_phone_message("Mary", "Vacation's almost here!! You definitely have to come visit me.", "mary_dm", do_pause=False)
        send_phone_message("Mary", "images/phone/media/mary01.webp", "mary_dm", 2, summary_alt="mary Photo", do_pause=False)
        send_phone_message("Mary", "Oh dear. I sent the wrong picture! Could you delete that message?", "mary_dm", do_pause=False)
        send_phone_message(phone_config["phone_player_name"], "What message? I haven't received anything. Maybe you canceled it before it was sent.", "mary_dm", do_pause=False)
        send_phone_message("Mary", "Oh, that's such a relief. By the way, see you soon, honey. Mwah.❤︎", "mary_dm", do_pause=False)
        send_phone_message("Mary", "images/phone/media/mary02.webp", "mary_dm", 2, summary_alt="mary Photo", do_pause=False)
        
        
        clear_notifications()
        renpy.restart_interaction()


    def phone_pause(length=1.0):
        """ Pauses the game for a specific amount of time within the phone.
            This is a simple wrapper around renpy.pause() for convenience, allowing for
            timed delays between messages without relying on the automatic pause config.
            Args:
                length (float, optional): The duration of the pause in seconds. Defaults to 1.0.
        """
        renpy.pause(length)


    def phone_start():
        """ Activates phone mode, preparing the UI for the phone screen.
            This function sets a flag that can be used to hide the normal
            dialogue window, ensuring the phone UI doesn't overlap with it.
            It should be called right before showing the phone_ui screen.
        """
        global phone_mode
        phone_mode = True
        renpy.restart_interaction()


    def phone_end():
        """ Deactivates phone mode, restoring the normal game UI.
            This function resets the flag set by phone_start(), which should
            bring back the standard dialogue window. It should be called
            right after hiding the phone_ui screen.
        """
        global phone_mode
        phone_mode = False
        renpy.hide_screen("phone_ui")
        renpy.restart_interaction()


    def lock_phone_screen():
        """ Disables the back button on the phone screen.
            This locks the player into the current view (a specific chat)
            and prevents them from returning to the channel list. Useful for
            scripted sequences where you need the player's focus.
        """
        global disable_phone_menu_switch
        disable_phone_menu_switch = True


    def unlock_phone_screen():
        """ Enables the back button on the phone screen.
            This restores the player's ability to navigate back to the channel
            list from a chat view (basically just undoing the effect of lock_phone_screen()).
        """
        global disable_phone_menu_switch
        disable_phone_menu_switch = False


    def present_phone_choices(choices, channel_name):
        """ Presents a set of choices to the player within a phone channel.
            This function displays tappable choice bubbles for the player. The game
            will pause and wait for the player to make a selection.
            Args:
                choices (list): A list of tuples defining the choices. Each tuple is in the
                    format ("preview_text", "message_to_send", action).
                    - "preview_text": The text shown on the choice button.
                    - "message_to_send": The message text that gets sent. If None, uses preview_text.
                    - "action": A Ren'Py action (like Call() or Jump()) to run after sending. Can be None.
                channel_name (str): The unique ID of the channel where the choices will appear.
        """
        
        
        global phone_choice_options, phone_choice_channel
        phone_choice_options = choices
        phone_choice_channel = channel_name
        phone_scroll_new_content(channel_name)
        renpy.restart_interaction()
        renpy.ui.interact()  


    def get_channel_preview(channel_name):
        """ Gets the preview text for a channel to display on the channel list.
            This function retrieves the last message of a channel, formats it for
            the preview (e.g., adding sender for group chats, truncating), and
            returns it. It's an internal function used by the phone_ui screen.

            Args:
                channel_name (str): The unique ID of the channel to get the preview for.
        """
        if channel_name in phone_channels and phone_channels[channel_name]:
            for last_message_tuple in reversed(phone_channels[channel_name]):
                if last_message_tuple[3] != 1:  
                    summary_alt = last_message_tuple[5] if len(last_message_tuple) > 5 else None
                    if summary_alt and summary_alt != "none":
                        return summary_alt
                    sender = last_message_tuple[1]
                    message_text = last_message_tuple[2]
                    message_kind = last_message_tuple[3]
                    preview_text = message_text
                    if message_kind == 3: 
                        preview_text = re.sub(r"<[^>]+>", "", preview_text).strip()
                    
                    is_group = phone_channel_data.get(channel_name, {}).get("is_group", False)
                    if is_group and sender != phone_config["phone_player_name"]:
                        full_preview = "{}: {}".format(sender, preview_text)
                    else:
                        full_preview = preview_text
                    max_len = phone_config.get("preview_max_length", 35) 
                    if len(full_preview) > max_len:
                        
                        return full_preview[:max_len - 3] + "..."
                    else:
                        return full_preview
        return phone_config["preview_no_message"]


    def switch_channel_view(channel_name):
        """ Forces the phone to open a specific channel or the channel list.
            This can be used to guide the player to a new message or event in a
            different chat without requiring them to tap on it manually.
            Args:
                channel_name (str): The unique ID of the channel to switch to. Can also be
                    "channel_list" to return to the main message list.
        """
        global channel_notifs, channel_seen_latest
        phone_set_view(channel_name)
        channel_notifs[channel_name] = False
        channel_seen_latest[channel_name] = True


    def hide_phone_channel(channel_name):
        """ Hides a channel from the channel list without deleting its history.
            The channel and its messages are preserved and can be made visible again
            using show_phone_channel().
            Args:
                channel_name (str): The unique ID of the channel to hide.
        """
        global channel_visible
        if channel_name in channel_visible:
            channel_visible[channel_name] = False
            renpy.restart_interaction()


    def show_phone_channel(channel_name):
        """ Makes a previously hidden channel visible again on the channel list.
            This function reverses the effect of hide_phone_channel().
            Args:
                channel_name (str): The unique ID of the channel to show.
        """
        global channel_visible
        if channel_name in channel_visible:
            channel_visible[channel_name] = True
            renpy.restart_interaction()


    def delete_phone_channel(channel_name):
        """ Permanently deletes a channel and all of its associated data.
            This action is irreversible and will remove the channel, its messages,
            and all related settings from the phone.
            Args:
                channel_name (str): The unique ID of the channel to delete.
        """
        global phone_channel_data, phone_channels, channel_last_message_id, channel_seen_latest, channel_notifs, channel_visible, channel_latest_global_id, current_phone_view
        if channel_name in phone_channel_data:
            del phone_channel_data[channel_name]
        if channel_name in phone_channels:
            del phone_channels[channel_name]
        if channel_name in channel_last_message_id:
            del channel_last_message_id[channel_name]
        if channel_name in channel_seen_latest:
            del channel_seen_latest[channel_name]
        if channel_name in channel_notifs:
            del channel_notifs[channel_name]
        if channel_name in channel_visible:
            del channel_visible[channel_name]
        if channel_name in channel_latest_global_id:
            del channel_latest_global_id[channel_name]
        
        if current_phone_view == channel_name:
            switch_channel_view("channel_list")
        phone_scroll.pop(channel_name, None)
        renpy.restart_interaction()


    def add_participant_to_group(channel_name, new_participant_name, added_by_name=None):
        """ Adds a participant to a group chat and posts a notification message.
            This will update the channel's participant list and send a system message
            (like "X added Y to the group") to the chat.
            Args:
                channel_name (str): The unique ID of the group channel.
                new_participant_name (str): The name of the character being added.
                added_by_name (str, optional): The name of the character who added the new
                    participant. If None, a generic "joined" message is shown. Defaults to None.
        """
        if channel_name in phone_channel_data and phone_channel_data[channel_name]["is_group"]:
            phone_channel_data[channel_name]["participants"].append(new_participant_name)
            if added_by_name:
                template = phone_config.get("group_added", "{adder} added {participant} to the group.")
                message_text = template.format(adder=added_by_name, participant=new_participant_name)
            else:
                template = phone_config.get("group_joined", "{participant} joined the group.")
                message_text = template.format(participant=new_participant_name)
            send_phone_message("", message_text, channel_name, message_kind=1, do_pause=True)

    def remove_participant_from_group(channel_name, participant_to_remove):
        """Removes a participant from a group chat and posts a notification message.
            This will update the channel's participant list and send a system message
            (like "X left the group") to the chat.
            Args:
                channel_name (str): The unique ID of the group channel.
                participant_to_remove (str): The name of the character to remove.
        """
        if channel_name in phone_channel_data and phone_channel_data[channel_name]["is_group"]:
            if participant_to_remove in phone_channel_data[channel_name]["participants"]:
                phone_channel_data[channel_name]["participants"].remove(participant_to_remove)
                template = phone_config.get("group_left", "{participant} left the group.")
                message_text = template.format(participant=participant_to_remove)
                send_phone_message("", message_text, channel_name, message_kind=1, do_pause=True)


    def has_any_notification():
        """Checks if any channel has an active notification."""
        return any(channel_notifs.values())


    def has_any_notification_not_active():
        """Checks if any channel OTHER than the current one has an active notification."""
        return any(has_notif for channel, has_notif in channel_notifs.items() if channel != current_phone_view)


    def get_phone_theme_value(key):
        """Retrieves a theme-specific value from phone_config based on the current theme."""
        current_theme = phone_config["phone_theme"]
        
        return phone_config[current_theme].get(key)


    def set_phone_theme(theme_name):
        """Sets the phone's theme to a new value.
            This function changes the current theme of the phone UI, which can be used
            to switch between light, dark, or flip themes dynamically.
            Args:
                theme_name (str): The name of the theme to switch to (e.g., "light", "dark", "flip").
        """
        if theme_name in phone_config:
            phone_config["phone_theme"] = theme_name
            renpy.restart_interaction()
        else:
            renpy.log("Invalid phone theme: " + theme_name)

default phone_channel_data = {}
default phone_channels = {}
default channel_last_message_id = {}
default channel_seen_latest = {}
default channel_notifs = {}
default channel_visible = {}
default current_phone_view = None
default disable_phone_menu_switch = False
default phone_choice_options = []
default phone_choice_channel = None
default channel_latest_global_id = {}
default _phone_global_message_counter = 0






default phone_zoom = 0.9
default phone_x = 0.5
default phone_y = 0.5
transform phone_position(p_zoom, p_x, p_y):
    anchor (0.5, 0.5)
    pos (p_x, p_y)
    zoom p_zoom


screen phone_image_fullscreen(image_path=""):
    tag phone_image_viewer
    modal True
    zorder 999


    add Solid("#000F")

    add image_path:
        xalign 0.5
        yalign 0.5
        fit "contain"

    key "mouseup_1" action Hide("phone_image_fullscreen")
    key "K_ESCAPE" action Hide("phone_image_fullscreen")



image emoji_sob = "phone/emoji/sob.png"
image emoji_dizzy = "phone/emoji/dizzy.png"

screen phone_ui():
    tag phone_ui

    on "show" action [SetVariable("phone_mode", True), Function(refresh_phone_contact_avatars), Function(phone_scroll_restore_current)]
    on "hide" action [Function(phone_scroll_save_current), SetVariable("phone_mode", False)]

    modal True

    zorder 100
    default was_channel_unread = False

    window:
        at phone_position(phone_zoom, phone_x, phone_y)
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 1000

        add get_phone_theme_value("screen_background_image")
        add get_phone_theme_value("header_background_image")
        add get_phone_theme_value("base_background_image")

        imagebutton:
            idle "phone/close.png"
            hover "phone/close_hover.png"
            xalign 0.5
            yalign 0.91
            xysize (172, 51)
            action [Hide("phone_ui"), Function(phone_end)]


        if current_phone_view is None:

            imagebutton:
                idle "phone/patreon_icon.png"
                hover "phone/patreon_icon_hover.png"
                action OpenURL("https://www.patreon.com/c/Bittersweet3D")
                xpos 80
                ypos 90


            if ch06_started:
                imagebutton:
                    idle "phone/milfgram_icon.png"
                    hover "phone/milfgram_icon_hover.png"
                    xpos 380
                    ypos 90
                    action Show("milfgram_ui")
            else:
                imagebutton:
                    idle "phone/soon_icon.png"
                    hover "phone/soon_icon_hover.png"
                    xpos 380
                    ypos 90
                    action NullAction()

            imagebutton:
                idle "phone/discord_icon.png"
                hover "phone/discord_icon_hover.png"
                xpos 230
                ypos 90
                action OpenURL("https://discord.gg/UGQgKVfxYn")

            imagebutton:
                idle "phone/messages_icon.png"
                hover "phone/messages_icon_hover.png"
                xpos 80
                ypos 240
                xysize (120, 120)
                action Function(phone_set_view, "channel_list")
            if any(channel_notifs.values()):
                add "phone/notif.png":
                    xpos 170
                    ypos 230
                    zoom 0.9


            imagebutton:
                idle "phone/gallery_icon.png"
                hover "phone/gallery_icon_hover.png"
                xpos 230
                ypos 240
                action [Hide("phone_ui"), Show("phone_gallery_thumbs")]


            if ch06_started:
                imagebutton:
                    idle "phone/milfgram_red_icon.png"
                    hover "phone/milfgram_red_icon_hover.png"
                    xpos 380
                    ypos 240
                    xysize (120, 120)
                    action Show("milfgram_red_ui")
            else:
                imagebutton:
                    idle "phone/soon_icon.png"
                    hover "phone/soon_icon_hover.png"
                    xpos 380
                    ypos 240
                    xysize (120, 120)
                    action NullAction()


        if current_phone_view and not disable_phone_menu_switch:
            $ back_icon_path = get_phone_theme_value("back_button_notif_image") if has_any_notification_not_active() else get_phone_theme_value("back_button_idle_image")

            imagebutton:
                xalign 0.15
                yalign 0.1075
                idle back_icon_path
                hover back_icon_path
                xysize (75, 75)
                action If(current_phone_view == "channel_list", Function(phone_set_view, None), Function(phone_set_view, "channel_list"))


        if current_phone_view:
            vbox:
                id "phone_viewport"
                xsize 450
                ysize 775
                yalign 0.325
                xalign 0.475
                vbox:
                    spacing 10

                if current_phone_view != "channel_list":
                    null height 5
                    add phone_contact_avatar(current_phone_view):
                        xalign 0.5
                        xysize (50, 50)
                    text phone_channel_data[current_phone_view]["display_name"]:
                        style "phone_header_style"
                        ypos -5
                else:
                    null height 40
                    text phone_config["channels_title"]:
                        style "phone_header_style"
                null height 19

                if current_phone_view == "channel_list":
                    $ yadj = phone_scroll_bind()
                    viewport:
                        id "message_viewport"
                        xfill True
                        ysize 750
                        yadjustment yadj
                        scrollbars "vertical"
                        mousewheel True
                        draggable True

                        style_prefix "phone"

                        has vbox
                        spacing 15
                        $ visible_channels = [ch for ch in phone_channel_data.keys() if channel_visible.get(ch, True)]
                        python:
                            if phone_config["sort_channels_by_latest"]:
                                channel_list_to_display = sorted(visible_channels, key=lambda ch_name: channel_latest_global_id.get(ch_name, 0), reverse=True)
                            else:
                                channel_list_to_display = visible_channels
                        for channel_name in channel_list_to_display:
                            button:
                                action [
                                        SetDict(channel_notifs, channel_name, False),
                                        Function(phone_set_view, channel_name)
                                    ]
                                style "phone_channel_button_style"
                                xfill True

                                has vbox

                                hbox:

                                    spacing 10
                                    add phone_contact_avatar(channel_name):
                                        xysize (50, 50)
                                        yalign 0.5

                                    vbox:
                                        text phone_channel_data[channel_name]["display_name"]:
                                            style "phone_channel_name_style"
                                        text get_channel_preview(channel_name):
                                            style "phone_channel_preview_style"

                                    if channel_notifs.get(channel_name, False):
                                        add get_phone_theme_value("notification_dot_image"):
                                            xalign 1.0
                                            yalign 0.6
                                            xoffset -5
                                            size (25, 25)

                                null height 10
                                frame:
                                    background get_phone_theme_value("channel_divider_colour")
                                    xfill True
                                    ysize 1
                else:

                    $ yadj = phone_scroll_bind()

                    viewport:
                        id "message_viewport"
                        xfill True
                        ysize 750
                        yadjustment yadj
                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        style_prefix "phone"

                        has vbox
                        spacing 8
                        xfill True
                        if current_phone_view in phone_channels:
                            $ latest_channel_id = channel_last_message_id.get(current_phone_view, 0)
                            $ last_sender_in_chat_view = None

                            for message_data in phone_channels[current_phone_view]:
                                $ msg_id, sender, message_text, message_kind, current_global_id, summary_alt, image_x, image_y = message_data
                                if sender == phone_config["phone_player_name"]:
                                    $ bubble_image = get_phone_theme_value("player_bubble_image")
                                    $ text_colour = get_phone_theme_value("message_player_text_colour")
                                    $ anim_direction = 1
                                else:
                                    $ bubble_image = get_phone_theme_value("character_bubble_image")
                                    $ text_colour = get_phone_theme_value("message_character_text_colour")
                                    $ anim_direction = -1
                                $ msg_padding = phone_config["message_padding"]

                                $ is_group_chat = phone_channel_data[current_phone_view]["is_group"]
                                if is_group_chat and sender != phone_config["phone_player_name"] and sender != last_sender_in_chat_view:
                                    text sender:
                                        style "phone_sender_name_style"
                                        xalign msg_padding
                                        xoffset 5

                                if message_kind == 0:
                                    frame:
                                        if sender == phone_config["phone_player_name"]:
                                            xpos 1.0 - msg_padding xanchor 1.0
                                        else:
                                            xpos msg_padding xanchor 0.0
                                        background Frame(bubble_image, 23, 23)
                                        padding (15, 10)
                                        xmaximum 360
                                        if msg_id == latest_channel_id and not channel_seen_latest[current_phone_view]:
                                            at message_appear(anim_direction)
                                            $ channel_seen_latest[current_phone_view] = True
                                            $ channel_notifs[current_phone_view] = False
                                        text message_text:
                                            font noto_font
                                            color text_colour
                                            size phone_config["message_font_size"]
                                            layout "tex"
                                    $ last_sender_in_chat_view = sender
                                elif message_kind == 1:

                                    null height 15
                                    hbox:
                                        xalign 0.5
                                        xmaximum 360
                                        if msg_id == latest_channel_id and not channel_seen_latest[current_phone_view]:
                                            at timestamp_appear()
                                            $ channel_seen_latest[current_phone_view] = True
                                            $ channel_notifs[current_phone_view] = False
                                        text message_text:
                                            color get_phone_theme_value("timestamp_text_colour")
                                            size phone_config["timestamp_font_size"]
                                            layout "tex"
                                    null height 15
                                    $ last_sender_in_chat_view = None

                                elif message_kind == 5:

                                    null height 15
                                    add Solid("#aaaaaa") xalign 0.5 xsize 360 ysize 2
                                    null height 15
                                    $ last_sender_in_chat_view = None

                                elif message_kind == 2:

                                    frame:
                                        if sender == phone_config["phone_player_name"]:
                                            xpos 1.0 - msg_padding xanchor 1.0
                                        else:
                                            xpos msg_padding xanchor 0.0
                                        background Frame(bubble_image, 23, 23)
                                        padding (10, 10)
                                        xmaximum 360
                                        if msg_id == latest_channel_id and not channel_seen_latest[current_phone_view]:
                                            at message_appear(anim_direction)
                                            $ channel_seen_latest[current_phone_view] = True
                                            $ channel_notifs[current_phone_view] = False
                                        imagebutton:
                                            idle Image(message_text)
                                            hover Image(message_text)
                                            at scale_to_fit(image_x, image_y)
                                            action Show("phone_image_fullscreen", image_path=message_text)
                                    $ last_sender_in_chat_view = sender
                                elif message_kind == 3:

                                    frame:
                                        if sender == phone_config["phone_player_name"]:
                                            xpos 1.0 - msg_padding xanchor 1.0
                                        else:
                                            xpos msg_padding xanchor 0.0
                                        background Frame(bubble_image, 23, 23)
                                        padding (10, 10)
                                        xmaximum 360
                                        if msg_id == latest_channel_id and not channel_seen_latest[current_phone_view]:
                                            at message_appear(anim_direction)
                                            $ channel_seen_latest[current_phone_view] = True
                                            $ channel_notifs[current_phone_view] = False
                                        hbox:
                                            spacing 5
                                            xmaximum 340
                                            text replace_emojis(message_text):
                                                size phone_config["message_font_size"]
                                                color text_colour
                                                layout "tex"
                                    $ last_sender_in_chat_view = sender
                                elif message_kind == TYPING_KIND:

                                    frame:
                                        if sender == phone_config["phone_player_name"]:
                                            xpos 1.0 - msg_padding xanchor 1.0
                                        else:
                                            xpos msg_padding xanchor 0.0
                                        background Frame(bubble_image, 23, 23)
                                        padding (10, 10)
                                        xmaximum 360
                                        if msg_id == latest_channel_id and not channel_seen_latest[current_phone_view]:
                                            at message_appear(anim_direction)
                                            $ channel_seen_latest[current_phone_view] = True
                                            $ channel_notifs[current_phone_view] = False
                                        text "…":
                                            size phone_config["message_font_size"]
                                            color text_colour
                                            layout "tex"
                                    $ last_sender_in_chat_view = sender
                        else:
                            text phone_config["empty_channel_message"]:
                                style "phone_message_style"

                        if phone_choice_options and phone_choice_channel == current_phone_view:

                            null height 20
                            vbox:
                                xalign 0.5
                                spacing 8
                                for i, (preview_text, actual_message, action) in enumerate(phone_choice_options):
                                    $ message_to_send = actual_message if actual_message is not None else preview_text
                                    $ text_colour = get_phone_theme_value("message_player_text_colour")
                                    textbutton preview_text at choice_appear(delay = i * 0.1):
                                        action [
                                                SetVariable("phone_choice_options", []),
                                                SetVariable("phone_choice_channel", None),
                                                SetVariable("disable_phone_menu_switch", False),
                                                Function(send_phone_message, sender=phone_config["phone_player_name"], message_text=message_to_send, channel_name=current_phone_view, do_pause=False),
                                                If(action is not None, action),
                                                Return()
                                            ]
                                        background Frame(get_phone_theme_value("player_bubble_image"), 23, 23)
                                        idle_background Frame(get_phone_theme_value("player_bubble_image"), 23, 23)
                                        hover_background Frame(get_phone_theme_value("player_bubble_hover_image"), 23, 23)
                                        text_color text_colour
                                        text_size phone_config["choice_font_size"]
                                        text_align 0.5
                                        xalign 0.5
                                        padding (15, 10)

                        null height 30


default gallery_images = [
    {
        "thumb": "images/phone/shots/01_thumb.jpg",
        "phone": "images/phone/shots/01.jpg",
    },
    {
        "thumb": "images/phone/shots/02_thumb.jpg",
        "phone": "images/phone/shots/02.jpg",
    },
    {
        "thumb": "images/phone/shots/04_thumb.jpg",
        "phone": "images/phone/shots/04.jpg",
    },
    {
        "thumb": "images/phone/shots/05_thumb.jpg",
        "phone": "images/phone/shots/05.jpg",
    },
    {
        "thumb": "images/phone/shots/06_thumb.jpg",
        "phone": "images/phone/shots/06.jpg",
    },
    {
        "thumb": "images/phone/shots/07_thumb.jpg",
        "phone": "images/phone/shots/07.jpg",
    },
    {
        "thumb": "images/phone/shots/08_thumb.jpg",
        "phone": "images/phone/shots/08.jpg",
    },
    {
        "thumb": "images/phone/shots/09_thumb.jpg",
        "phone": "images/phone/shots/09.jpg",
    },
    {
        "thumb": "images/phone/shots/10_thumb.jpg",
        "phone": "images/phone/shots/10.jpg",
    },
    {
        "thumb": "images/phone/shots/11_thumb.jpg",
        "phone": "images/phone/shots/11.jpg",
    }
]


default selected_gallery_image = 0


style phone_header_style is default:
    font noto_font
    size 28
    color get_phone_theme_value("header_text_colour")
    xalign 0.5

style phone_channel_button_style is button:
    font noto_font
    background None
    hover_background get_phone_theme_value("channel_button_hover_background")
    xpadding 10
    ypadding 8

style phone_channel_name_style is default:
    font noto_font
    size 22
    color get_phone_theme_value("channel_name_text_colour")
    bold True

style phone_channel_preview_style is default:
    font noto_font
    size 18
    color get_phone_theme_value("channel_preview_text_colour")

style phone_message_style is default:
    font noto_font
    size 20
    color get_phone_theme_value("empty_channel_text_colour")
    xalign 0.0

style phone_sender_name_style is default:
    font noto_font
    size 16
    color get_phone_theme_value("sender_name_text_colour")
    yoffset 2
    ypadding 0
    yalign 1.0

transform message_appear(pDirection):
    alpha 0.0
    xoffset 50 * pDirection
    parallel:
        ease 0.5 alpha 1.0
    parallel:
        easein_back 0.5 xoffset 0
    alpha 1.0

transform timestamp_appear():
    alpha 0.0
    yoffset 50
    parallel:
        ease 0.5 alpha 1.0
    parallel:
        easein_back 0.5 yoffset 0

transform choice_appear(delay=0.0):
    alpha 0.0
    yoffset 50
    pause delay
    parallel:
        ease 0.5 alpha 1.0
    parallel:
        easein_back 0.5 yoffset 0

transform scale_to_fit(maxw, maxh):
    size (maxw, maxh)
    fit "contain"

init python:

    TYPING_KIND = 4

    def npc_type_and_send(sender, text, channel_name="mary_dm", typing_time=1.2, kind=0):
        """
        1) '…' 타이핑 버블 추가
        2) typing_time 만큼 기다림 (screen 기반)
        3) 타이핑 버블 제거 + 진짜 메시지 전송
        """
        global _phone_global_message_counter
        
        if channel_name not in phone_channels:
            renpy.log("Tried to send typing to non-existent channel: " + channel_name)
            return
        
        
        _phone_global_message_counter += 1
        gid = _phone_global_message_counter
        last_id = channel_last_message_id.get(channel_name, 0)
        mid = last_id + 1
        channel_last_message_id[channel_name] = mid
        
        
        phone_channels[channel_name].append((mid, sender, "…", TYPING_KIND, gid, "none", 320, 320))
        channel_notifs[channel_name] = True
        channel_seen_latest[channel_name] = False
        channel_latest_global_id[channel_name] = gid
        phone_scroll_new_content(channel_name)
        renpy.restart_interaction()
        
        
        renpy.call_screen("wait_and_continue", delay=typing_time)
        
        
        for i in range(len(phone_channels[channel_name]) - 1, -1, -1):
            if phone_channels[channel_name][i][3] == TYPING_KIND:
                del phone_channels[channel_name][i]
                break
        
        
        send_phone_message(sender, text, channel_name, message_kind=kind, do_pause=False)


    def npc_type_and_send_hesitate(sender, text, channel_name="mary_dm", typing_time=1.0, loops=2):
        """
        여러 번 타이핑 했다가 지우고, 마지막에 메시지 보내는 '망설임' 연출
        """
        global _phone_global_message_counter
        
        if channel_name not in phone_channels:
            renpy.log("Tried to send typing to non-existent channel: " + channel_name)
            return
        
        for i in range(loops):
            
            _phone_global_message_counter += 1
            gid = _phone_global_message_counter
            last_id = channel_last_message_id.get(channel_name, 0)
            mid = last_id + 1
            channel_last_message_id[channel_name] = mid
            
            phone_channels[channel_name].append(
                (mid, sender, "…", TYPING_KIND, gid, "none", 320, 320)
            )
            channel_notifs[channel_name] = True
            channel_seen_latest[channel_name] = False
            channel_latest_global_id[channel_name] = gid
            phone_scroll_new_content(channel_name)
            
            
            renpy.restart_interaction()
            
            
            renpy.call_screen("wait_and_continue", delay=typing_time)
            
            
            for j in range(len(phone_channels[channel_name]) - 1, -1, -1):
                if phone_channels[channel_name][j][3] == TYPING_KIND:
                    del phone_channels[channel_name][j]
                    break
            
            
            renpy.restart_interaction()
            
            
            renpy.call_screen("wait_and_continue", delay=0.3)
        
        
        send_phone_message(sender, text, channel_name, message_kind=0, do_pause=False)
        renpy.restart_interaction()

style phone_vscrollbar is vscrollbar:
    base_bar Frame(
        "gui/scrollbar/my_phone_scrollbar.png",
        Borders(10, 10, 10, 10, 0, 0, 0, 0)
    )
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
