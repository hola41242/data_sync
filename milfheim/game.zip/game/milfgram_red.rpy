






default mgr_unlocked_posts = ["mc_red_001", "olivia_red_001"]
default mgr_liked_posts = []
default mgr_player_comments = {}
default mgr_owner_comment_hearts = {}
default mgr_npc_comment_hearts = mgr_initial_npc_comment_hearts()

init -1 python:




    mgr_accounts = {
        "mc": {
            "handle": "nocturnal_404",
            "name": "nocturnal_404",
            "bio": "No face. No questions. Just after dark.",
            "avatar": "images/phone/milfgram_red/mc_milfgram_red.png",
            "followers": "7,284",
            "following": "037",
            "color": "#352022",
        },
        "olivia": {
            "handle": "velvet_sin",
            "name": "velvet_sin",
            "bio": "A little trouble looks good on me.",
            "avatar": "images/phone/milfgram_red/olivia_milfgram_red.png",
            "followers": "2,204",
            "following": "003",
            "color": "#352022",
        },
        "lena": {
            "handle": "cum4me",
            "name": "cum4me",
            "bio": "A little trouble looks good on me.",
            "avatar": "images/phone/milfgram_red/lena_milfgram_red.png",
            "followers": "8,904",
            "following": "001",
            "color": "#352022",
        },
        'amanda': {
            "handle": 'still_wild_at50',
            "name": 'still_wild_at50',
            "bio": 'Old enough to know better. Horny enough not to give a fuck. 💋',
            "avatar": "images/phone/milfgram_red/amanda_milfgram_red.png",
            "followers": '811',
            "following": '093',
            "color": "#352022",
        },
        'jason': {
            "handle": 'boobguy404',
            "name": 'boobguy404',
            "bio": "Boobs, asses, and zero fucking shame. Yeah, I'm that guy.",
            "avatar": "images/phone/milfgram_red/jason_milfgram_red.png",
            "followers": '196',
            "following": '329',
            "color": "#352022",
        },
        'helen': {
            "handle": 'wine_n_badchoices',
            "name": 'wine_n_badchoices',
            "bio": 'Good wine, bad men, and a bra that never stays on. Fuck it. 🍷',
            "avatar": "images/phone/milfgram_red/helen_milfgram_red.png",
            "followers": '2,146',
            "following": '187',
            "color": "#352022",
        },
        'mary': {
            "handle": 'sweetest_sin69',
            "name": 'sweetest_sin69',
            "bio": 'Sweet smile. Filthy fantasies. If you only knew what gets me hot. 😇',
            "avatar": "images/phone/milfgram_red/mary_milfgram_red.png",
            "followers": '1,578',
            "following": '116',
            "color": "#352022",
        },
        'alessia': {
            "handle": 'fuckdresscodes',
            "name": 'fuckdresscodes',
            "bio": 'Fuck the dress code. I look better with fewer clothes anyway.',
            "avatar": "images/phone/milfgram_red/alessia_milfgram_red.png",
            "followers": '3,021',
            "following": '284',
            "color": "#352022",
        },
        'anna': {
            "handle": 'mommyneedsfun',
            "name": 'mommyneedsfun',
            "bio": "I'm everybody's responsible adult by day. At night? Horny as fuck.",
            "avatar": "images/phone/milfgram_red/anna_milfgram_red.png",
            "followers": '1,104',
            "following": '208',
            "color": "#352022",
        },
        'beth': {
            "handle": 'no_panties_today',
            "name": 'no_panties_today',
            "bio": "No panties, no regrets. If you're staring, at least say hi. 😉",
            "avatar": "images/phone/milfgram_red/beth_milfgram_red.png",
            "followers": '1,745',
            "following": '144',
            "color": "#352022",
        },
        'celine': {
            "handle": 'oops_im_horny',
            "name": 'oops_im_horny',
            "bio": 'I look sweet until the dirty talk starts. Then all bets are off. 😈',
            "avatar": "images/phone/milfgram_red/celine_milfgram_red.png",
            "followers": '986',
            "following": '341',
            "color": "#352022",
        },
        'chloe': {
            "handle": 'badbitch.exe',
            "name": 'badbitch.exe',
            "bio": 'Nice tits, bad attitude, and no fucking interest in behaving.',
            "avatar": "images/phone/milfgram_red/chloe_milfgram_red.png",
            "followers": '4,218',
            "following": '299',
            "color": "#352022",
        },
        'diana': {
            "handle": 'fuckaround_findout',
            "name": 'fuckaround_findout',
            "bio": "Don't send me dick pics. I give the fucking orders here.",
            "avatar": "images/phone/milfgram_red/diana_milfgram_red.png",
            "followers": '1,223',
            "following": '87',
            "color": "#352022",
        },
        'emma': {
            "handle": 'happyendingz',
            "name": 'happyendingz',
            "bio": 'These hands are talented. Your dirty imagination is your problem. 😉',
            "avatar": "images/phone/milfgram_red/emma_milfgram_red.png",
            "followers": '8,618',
            "following": '002',
            "color": "#352022",
        },
        'ethan': {
            "handle": 'whiskey_n_women',
            "name": 'whiskey_n_women',
            "bio": 'Whiskey, women, and one-night mistakes. Spare me the love songs.',
            "avatar": "images/phone/milfgram_red/ethan_milfgram_red.png",
            "followers": '684',
            "following": '193',
            "color": "#352022",
        },
        'evan': {
            "handle": 'virgin_killer404',
            "name": 'virgin_killer404',
            "bio": 'Too horny to play it cool. Still shooting my shot. 😏',
            "avatar": "images/phone/milfgram_red/evan_milfgram_red.png",
            "followers": '218',
            "following": '476',
            "color": "#352022",
        },
        'evelyn': {
            "handle": 'holyshit_amen',
            "name": 'holyshit_amen',
            "bio": "Angel face, filthy mind. My halo's in the fucking trash. 😇",
            "avatar": "images/phone/milfgram_red/evelyn_milfgram_red.png",
            "followers": '901',
            "following": '226',
            "color": "#352022",
        },
        'frank': {
            "handle": 'cash4ass',
            "name": 'cash4ass',
            "bio": 'Cash, tits, and booze. I came for fun, not fucking feelings.',
            "avatar": "images/phone/milfgram_red/frank_milfgram_red.png",
            "followers": '302',
            "following": '154',
            "color": "#352022",
        },
        'harold': {
            "handle": 'the_big_boss69',
            "name": 'the_big_boss69',
            "bio": 'Power, pleasure, and a big fucking ego. Deal with it.',
            "avatar": "images/phone/milfgram_red/harold_milfgram_red.png",
            "followers": '412',
            "following": '068',
            "color": "#352022",
        },
        'isabella': {
            "handle": 'fuck_love_247',
            "name": 'fuck_love_247',
            "bio": "If we're fucking, at least act like I matter afterward.",
            "avatar": "images/phone/milfgram_red/isabella_milfgram_red.png",
            "followers": '1,369',
            "following": '205',
            "color": "#352022",
        },
        'ivy': {
            "handle": 'dicksonlyplz',
            "name": 'dicksonlyplz',
            "bio": 'I like good dick, dirty talk, and absolutely no fake innocence.',
            "avatar": "images/phone/milfgram_red/ivy_milfgram_red.png",
            "followers": '2,906',
            "following": '317',
            "color": "#352022",
        },
        'kevin': {
            "handle": 'ballsdeep420',
            "name": 'ballsdeep420',
            "bio": 'Too horny to sleep, too dumb to stay out of trouble. 😂',
            "avatar": "images/phone/milfgram_red/kevin_milfgram_red.png",
            "followers": '479',
            "following": '410',
            "color": "#352022",
        },
        'leila': {
            "handle": 'lickme_later',
            "name": 'lickme_later',
            "bio": 'Pretty lips, dirty mouth, and a head full of bad fucking ideas.',
            "avatar": "images/phone/milfgram_red/leila_milfgram_red.png",
            "followers": '1,847',
            "following": '156',
            "color": "#352022",
        },
        'marcus': {
            "handle": 'notyourdaddy',
            "name": 'notyourdaddy',
            "bio": "Not your daddy, not your boyfriend. Don't fucking get attached.",
            "avatar": "images/phone/milfgram_red/marcus_milfgram_red.png",
            "followers": '739',
            "following": '265',
            "color": "#352022",
        },
        'michael': {
            "handle": 'ghostmode_77',
            "name": 'ghostmode_77',
            "bio": 'No names, no faces, no fucking receipts. What happens stays buried.',
            "avatar": "images/phone/milfgram_red/michael_milfgram_red.png",
            "followers": '087',
            "following": '021',
            "color": "#352022",
        },
        'monica': {
            "handle": 'drunk_n_flirty',
            "name": 'drunk_n_flirty',
            "bio": 'I pour the drinks. You get drunk, horny, and way too honest. 🍸',
            "avatar": "images/phone/milfgram_red/monica_milfgram_red.png",
            "followers": '2,034',
            "following": '369',
            "color": "#352022",
        },
        'owen': {
            "handle": 'fuckbuddiesonly',
            "name": 'fuckbuddiesonly',
            "bio": 'Here for sex, not feelings. No strings, no fucking drama.',
            "avatar": "images/phone/milfgram_red/owen_milfgram_red.png",
            "followers": '543',
            "following": '162',
            "color": "#352022",
        },
        'rebecca': {
            "handle": 'bralessnblessed',
            "name": 'bralessnblessed',
            "bio": 'Braless, shameless, and thinking dirty thoughts. Fuck the rules.',
            "avatar": "images/phone/milfgram_red/rebecca_milfgram_red.png",
            "followers": '1,782',
            "following": '238',
            "color": "#352022",
        },
        'rose': {
            "handle": 'kneel4me',
            "name": 'kneel4me',
            "bio": "I don't beg. I make you beg. Know your fucking place.",
            "avatar": "images/phone/milfgram_red/rose_milfgram_red.png",
            "followers": '7,502',
            "following": '000',
            "color": "#352022",
        },
        'shakira': {
            "handle": 'thicknwicked',
            "name": 'thicknwicked',
            "bio": 'Thick thighs, dirty mouth, zero fucking apologies. 🍑',
            "avatar": "images/phone/milfgram_red/shakira_milfgram_red.png",
            "followers": '3,814',
            "following": '403',
            "color": "#352022",
        },
        'sophia': {
            "handle": 'extra_credit_xxx',
            "name": 'extra_credit_xxx',
            "bio": "Brains and a filthy imagination. My private life isn't your homework.",
            "avatar": "images/phone/milfgram_red/sophia_milfgram_red.png",
            "followers": '2,587',
            "following": '174',
            "color": "#352022",
        },
        'stella': {
            "handle": 'wetdreamdealer',
            "name": 'wetdreamdealer',
            "bio": "Sweet dreams? Nah. I'm the reason yours get fucking dirty.",
            "avatar": "images/phone/milfgram_red/stella_milfgram_red.png",
            "followers": '2,332',
            "following": '221',
            "color": "#352022",
        },
        'veronica': {
            "handle": 'kissmyass_baby',
            "name": 'kissmyass_baby',
            "bio": 'Kiss my ass, not my ego. Actually, kiss both. 💋',
            "avatar": "images/phone/milfgram_red/veronica_milfgram_red.png",
            "followers": '1,688',
            "following": '129',
            "color": "#352022",
        },
        'vivian': {
            "handle": 'dirtylilsecret',
            "name": 'dirtylilsecret',
            "bio": 'Good manners in public. Filthy fucking secrets in private.',
            "avatar": "images/phone/milfgram_red/vivian_milfgram_red.png",
            "followers": '1,921',
            "following": '135',
            "color": "#352022",
        },
    }





    mgr_posts = [
        {
            "id": "olivia_red_001",
            "account": "olivia",
            "image": "images/phone/milfgram_red/olivia_red/olivia_milfgram_red_01.jpg",
            "orientation": "portrait",  
            "chapter": 6,  
            "show_by_default": True,
            "caption": "No names. No innocent thoughts. 😈",
            "likes": 684,
            "comments": [
                ("pervy_pete", "I forgot what I was supposed to be doing."),
                ("dirty_donna69", "This is why my screen time is out of control. 🔥"),
                ("panty_professor", "I have a PhD in making bad decisions."),
            ],
        },
        {
            "id": "mc_red_001",
            "account": "mc",
            "image": "images/phone/milfgram_red/mc_red/mc_milfgram_red_01.jpg",
            "orientation": "portrait",  
            "chapter": 6,  
            "show_by_default": True,
            "caption": "Don't ask who I am. Enjoy the mystery. 🖤",
            "likes": 317,
            "comments": [
                ("thirsty_tracy", "Well, there goes my concentration."),
                ("horny_hank420", "Bro, I came here to lurk, not to be jealous."),
                ("bad_bunny_xo", "Okay, mystery man. You have my attention. 👀"),
                ("badgirl_69", "Holy fuck, that thing is massive! 🥵"),
                ("hungry_milf77", "Damn, I wouldn't know what to do with all that. 😈"),
            ],
        },
        {
            "id": "lena_red_001",
            "account": "lena",
            "image": "images/phone/milfgram_red/lena_red/lena_milfgram_red_01.jpg",
            "orientation": "portrait",  
            "chapter": 6,  
            "show_by_default": True,
            "caption": "Only showing half the evidence. 😈💦",
            "likes": 1204,
            "comments": [
                ("nuttyprofessor69", "Damn, someone had a good night 💦"),
                ("thirsty_bastard", "Now I wanna see the other half 😏"),
                ("cumslut_404", "Girl, you look way too proud of that 😂"),
                ("dickdetective", "Okay but WHO did this?? 👀"),
            ],
        },
        {
            "id": "rose_red_001",
            "account": "rose",
            "image": "images/phone/milfgram_red/rose_red/rose_milfgram_red_01.jpg",
            "images": [
                "images/phone/milfgram_red/rose_red/rose_milfgram_red_01.jpg",
                "images/phone/milfgram_red/rose_red/rose_milfgram_red_02.jpg",
            ],
            "orientation": "portrait",  
            "chapter": 6,  
            "show_by_default": True,
            "caption": "Don't DM me. I post these nudes for my own pleasure, not yours.",
            "likes": 1327,
            "comments": [
                ("tittyaddict69", "Fuck, I wanna suck those gorgeous tits so bad. 🥵"),
                ("ballsdeep420", "Goddamn, I'd love to fuck you all night.🔥"),
                ("hornybastard77", "Those nipples are begging for my mouth."),
                ("rawdog_king", "Holy shit, I'd bend you over in a heartbeat."),
            ],
        },
        {
            "id": "emma_red_001",
            "account": "emma",
            "image": "images/phone/milfgram_red/emma_red/emma_milfgram_red_01.jpg",
            "orientation": "portrait",  
            "chapter": 6,  
            "show_by_default": True,
            "caption": "You know where to find me, right? 😈💋",
            "likes": 3227,
            "comments": [
                ("hardup69", "Fuck, I'd pay double for a private session. 🥵"),
                ("pervyoldman", "Goddamn, those legs are driving me insane! 🤤"),
                ("bigdaddy_247", "Does the massage come with a happy ending? 😏"),
                ("hornydog_88", "Holy shit, take my fucking money already! 🔥"),
            ],
        },
    ]

    def mgr_post_images(post):
        """Optional multi-photo carousel; preserve all older single-image posts."""
        images = post.get("images")
        if images:
            return images
        return [post["image"]]

    def mgr_set_image_page(pages, post_id, page_number, image_count):
        """Update only this post's UI slide, without changing game save data."""
        updated_pages = dict(pages)
        updated_pages[post_id] = page_number % image_count
        return updated_pages

    def mgr_npc_comment_key(post, comment_index):
        """Stable identity for hand-written NPC comments, including duplicates.

        The author's handle and body make each comment independent of its
        position, so adding an earlier comment won't shuffle saved reactions.
        """
        entry = tuple(post["comments"][comment_index])
        duplicate_number = sum(1 for earlier in post["comments"][:comment_index]
                               if tuple(earlier) == entry)
        return (entry[0], entry[1], duplicate_number)

    def mgr_initial_npc_comment_hearts():
        """Roll each predefined comment at new-game initialization (once)."""
        result = {}
        for post in mgr_posts:
            result[post["id"]] = {
                mgr_npc_comment_key(post, i): renpy.random.random() < 0.5
                for i in range(len(post["comments"]))
            }
        return result

    def mgr_ensure_npc_comment_hearts():
        """Add rolls for newly authored comments/posts on existing saved games.

        Never reroll an already saved comment; don't disturb other post states.
        """
        s = renpy.store
        saved = s.mgr_npc_comment_hearts
        updated = dict(saved)
        for post in mgr_posts:
            post_id = post["id"]
            existing = saved.get(post_id, {})
            states = dict(existing)
            for i in range(len(post["comments"])):
                key = mgr_npc_comment_key(post, i)
                if key not in states:
                    states[key] = renpy.random.random() < 0.5
            if states != existing:
                updated[post_id] = states
        if updated != saved:
            renpy.retain_after_load()
            s.mgr_npc_comment_hearts = updated

    def mgr_npc_comment_has_owner_heart(post_id, comment_index):
        """Get the saved 50% NPC heart, without rolling during UI rendering."""
        post = mgr_post_by_id(post_id)
        if post is None or not (0 <= comment_index < len(post["comments"])):
            return False
        key = mgr_npc_comment_key(post, comment_index)
        return renpy.store.mgr_npc_comment_hearts.get(post_id, {}).get(key, False) is True

    def mgr_safe(text):
        """Display typed comments literally instead of parsing Ren'Py text tags."""
        return str(text).replace("{", "{{").replace("[", "[[")

    def mgr_unlock_post(post_id):
        """Call from the VN script: $ mgr_unlock_post('helen_002')."""
        s = renpy.store
        known = any(p["id"] == post_id for p in mgr_posts)
        if known and post_id not in s.mgr_unlocked_posts:
            s.mgr_unlocked_posts = list(s.mgr_unlocked_posts) + [post_id]

    def mgr_toggle_like(post_id):
        s = renpy.store
        
        renpy.retain_after_load()
        if post_id in s.mgr_liked_posts:
            s.mgr_liked_posts = [p for p in s.mgr_liked_posts if p != post_id]
        else:
            s.mgr_liked_posts = list(s.mgr_liked_posts) + [post_id]

    def mgr_submit_comment(post_id, draft):
        """Store free text exactly as entered (other than trimming outer spaces)."""
        body = str(draft).strip()
        if not body or post_id not in [p["id"] for p in mgr_posts]:
            return
        s = renpy.store
        renpy.retain_after_load()
        
        updated = dict(s.mgr_player_comments)
        updated[post_id] = list(updated.get(post_id, [])) + [body]
        s.mgr_player_comments = updated
        
        hearts = dict(s.mgr_owner_comment_hearts)
        states = list(hearts.get(post_id, []))
        states += [None] * max(0, len(updated[post_id]) - 1 - len(states))
        states.append(None)
        hearts[post_id] = states
        s.mgr_owner_comment_hearts = hearts

    def mgr_delete_comment(post_id, comment_index):
        """Delete only the player's saved comment at the given index."""
        s = renpy.store
        player_comments = list(s.mgr_player_comments.get(post_id, []))
        if not (0 <= comment_index < len(player_comments)):
            return
        renpy.retain_after_load()
        del player_comments[comment_index]
        updated = dict(s.mgr_player_comments)
        if player_comments:
            updated[post_id] = player_comments
        else:
            updated.pop(post_id, None)
        s.mgr_player_comments = updated
        
        hearts = dict(s.mgr_owner_comment_hearts)
        states = list(hearts.get(post_id, []))
        states += [None] * max(0, len(player_comments) + 1 - len(states))
        del states[comment_index]
        if player_comments:
            hearts[post_id] = states
        else:
            hearts.pop(post_id, None)
        s.mgr_owner_comment_hearts = hearts

    def mgr_comment_has_owner_heart(post_id, comment_index):
        """One reaction per MC comment. No heart until the phone is fully closed."""
        s = renpy.store
        states = s.mgr_owner_comment_hearts.get(post_id, [])
        return 0 <= comment_index < len(states) and states[comment_index] is True

    def mgr_finalize_owner_hearts():
        """Perform each pending 50% roll once, when phone_end() actually closes the phone."""
        s = renpy.store
        hearts = {}
        own_post_ids = {p["id"] for p in mgr_posts if p["account"] == "mc"}
        for post_id, comments in s.mgr_player_comments.items():
            states = list(s.mgr_owner_comment_hearts.get(post_id, []))[:len(comments)]
            states += [None] * max(0, len(comments) - len(states))
            for index, state in enumerate(states):
                if state is None:
                    
                    states[index] = False if post_id in own_post_ids else renpy.random.random() < 0.5
            hearts[post_id] = states
        if hearts != s.mgr_owner_comment_hearts:
            renpy.retain_after_load()
            s.mgr_owner_comment_hearts = hearts

    def mgr_post_by_id(post_id):
        for post in mgr_posts:
            if post["id"] == post_id:
                return post
        return None

    def mgr_latest_started_chapter():
        """Read existing chapter flags from this save (not from persistent data).

        A started later chapter also includes earlier chapter posts, even when
        a tester jumps directly to a later chapter without playing Chapter 6.
        Future chapter files can use: default ch07_started = False;
        then $ ch07_started = True at the start of that chapter.
        """
        s = renpy.store
        for number in range(99, 5, -1):
            if getattr(s, "ch{:02d}_started".format(number), False):
                return number
        return 0

    def mgr_visible_posts_for(account=None):
        s = renpy.store
        latest_chapter = mgr_latest_started_chapter()
        return [p for p in reversed(mgr_posts)
                if p.get("chapter", 6) <= latest_chapter
                and (p.get("show_by_default", False) or p["id"] in s.mgr_unlocked_posts)
                and (account is None or p["account"] == account)]




init 100 python:
    if not getattr(renpy.store, "_mg_owner_hearts_close_hook_installed", False):
        _mg_original_phone_end = phone_end
        
        def _mg_phone_end_with_owner_hearts():
            for name in ("mg_finalize_owner_hearts", "mgr_finalize_owner_hearts"):
                processor = getattr(renpy.store, name, None)
                if processor is not None:
                    processor()
            return _mg_original_phone_end()
        
        phone_end = _mg_phone_end_with_owner_hearts
        _mg_owner_hearts_close_hook_installed = True




screen milfgram_red_ui():
    tag milfgram_red_ui

    on "show" action [Hide("phone_ui"), Function(mgr_ensure_npc_comment_hearts)]
    on "hide" action Show("phone_ui")
    modal True
    zorder 200


    default mgr_page = "feed"
    default mgr_account = "mc"
    default mgr_post_id = "mc_red_001"
    default mgr_post_return = "feed"
    default mgr_comment_draft = ""
    default mgr_image_pages = {}
    default mgr_feed_scroll = ui.adjustment()


    key "K_ESCAPE" action If(
        mgr_page == "feed",
        Hide("milfgram_red_ui"),
        If(mgr_page == "post",
           SetScreenVariable("mgr_page", mgr_post_return),
           SetScreenVariable("mgr_page", "feed"))
    )

    window:
        at phone_position(phone_zoom, phone_x, phone_y)
        background None
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 1000


        add get_phone_theme_value("screen_background_image")
        add get_phone_theme_value("header_background_image")
        add get_phone_theme_value("base_background_image")



        frame:
            xpos 74
            ypos 104
            xysize (452, 800)
            background "#0c1015"
            padding (0, 0)

            has vbox
            xfill True
            spacing 0


            frame:
                background "#10161c"
                xfill True
                ysize 60
                padding (12, 8)

                has fixed
                xfill True
                ysize 44
                textbutton "< Back":
                    xpos 0
                    yalign 0.5
                    text_font noto_font
                    text_size 23
                    text_color "#ffffff"
                    background None
                    action If(
                                mgr_page == "feed",
                                Hide("milfgram_red_ui"),
                                If(mgr_page == "post",
                                   SetScreenVariable("mgr_page", mgr_post_return),
                                   SetScreenVariable("mgr_page", "feed"))
                            )


                if renpy.loadable("images/phone/milfgram_red_logo.png"):
                    add "images/phone/milfgram_red_logo.png":
                        xalign 1.0
                        yalign 0.5
                else:
                    text "Milfgram Red":
                        font noto_font
                        size 26
                        bold True
                        color "#ffffff"
                        xalign 1.0
                        yalign 0.5

            if mgr_page == "feed":
                viewport:
                    yadjustment mgr_feed_scroll
                    xfill True
                    ysize 740
                    draggable True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox
                    xfill True
                    spacing 18

                    for post in mgr_visible_posts_for():
                        $ account = mgr_accounts[post["account"]]
                        $ p_id = post["id"]
                        $ comment_count = len(post["comments"]) + len(mgr_player_comments.get(p_id, []))

                        vbox:
                            xfill True
                            spacing 8



                            hbox:
                                xsize 400
                                xalign 0.5
                                xoffset 12
                                spacing 10
                                button:
                                    xysize (57, 57)
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mgr_account", post["account"]),
                                                SetScreenVariable("mgr_page", "profile")
                                            ]
                                    if account["avatar"] and renpy.loadable(account["avatar"]):
                                        add account["avatar"]:
                                            xysize (57, 57)
                                            fit "contain"
                                    else:
                                        frame:
                                            xysize (57, 57)
                                            padding (0, 0)
                                            background account["color"]
                                            text account["name"][:1]:
                                                xalign 0.5
                                                yalign 0.5
                                                font noto_font
                                                size 24
                                                color "#ffffff"
                                button:
                                    xysize (333, 57)
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mgr_account", post["account"]),
                                                SetScreenVariable("mgr_page", "profile")
                                            ]
                                    text account["handle"]:
                                        xalign 0.0
                                        yalign 0.5
                                        font noto_font
                                        size 22
                                        bold False
                                        color "#c41f1f"


                            $ mgr_photos = mgr_post_images(post)
                            $ mgr_slide = mgr_image_pages.get(p_id, 0) % len(mgr_photos)
                            $ mgr_current_photo = mgr_photos[mgr_slide]
                            if renpy.loadable(mgr_current_photo):
                                button:
                                    xalign 0.5
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mgr_post_id", p_id),
                                                SetScreenVariable("mgr_post_return", "feed"),
                                                SetScreenVariable("mgr_page", "post")
                                            ]
                                    add mgr_current_photo:
                                        maxsize (420, 620)
                            else:
                                $ mgr_preview_size = (420, 236) if post.get("orientation") == "landscape" else (349, 620)
                                button:
                                    xalign 0.5
                                    xysize mgr_preview_size
                                    padding (0, 0)
                                    background "#242b35"
                                    action [
                                                SetScreenVariable("mgr_post_id", p_id),
                                                SetScreenVariable("mgr_post_return", "feed"),
                                                SetScreenVariable("mgr_page", "post")
                                            ]
                                    text "IMAGE: " + mgr_current_photo:
                                        font noto_font
                                        size 16
                                        color "#cccccc"
                                        xalign 0.5
                                        yalign 0.5
                                        xmaximum 300

                            if len(mgr_photos) > 1:
                                hbox:
                                    xalign 0.5
                                    spacing 25
                                    textbutton "‹":
                                        background None
                                        padding (10, 0)
                                        text_font noto_font
                                        text_size 30
                                        text_color "#ffffff"
                                        text_hover_color "#f44863"
                                        action SetScreenVariable("mgr_image_pages", mgr_set_image_page(mgr_image_pages, p_id, mgr_slide - 1, len(mgr_photos)))
                                    text "{} / {}".format(mgr_slide + 1, len(mgr_photos)):
                                        font noto_font
                                        size 18
                                        color "#cccccc"
                                        yalign 0.5
                                    textbutton "›":
                                        background None
                                        padding (10, 0)
                                        text_font noto_font
                                        text_size 30
                                        text_color "#ffffff"
                                        text_hover_color "#f44863"
                                        action SetScreenVariable("mgr_image_pages", mgr_set_image_page(mgr_image_pages, p_id, mgr_slide + 1, len(mgr_photos)))

                            hbox:
                                spacing 13
                                xoffset 30
                                textbutton ("♥" if p_id in mgr_liked_posts else "♡"):
                                    background None
                                    text_font notok_font
                                    text_size 32
                                    text_color ("#f44863" if p_id in mgr_liked_posts else "#ffffff")
                                    action Function(mgr_toggle_like, p_id)
                                textbutton "Comments ({})".format(comment_count):
                                    yalign 0.5
                                    background None
                                    text_font noto_font
                                    text_size 20
                                    text_color "#dddddd"
                                    action [
                                                SetScreenVariable("mgr_post_id", p_id),
                                                SetScreenVariable("mgr_post_return", "feed"),
                                                SetScreenVariable("mgr_page", "post")
                                            ]
                            text "{} likes".format(post["likes"] + (1 if p_id in mgr_liked_posts else 0)):
                                font noto_font
                                size 20
                                color "#ffffff"
                                bold True
                                xoffset 30
                            text "{{color=#c41f1f}}{}{{/color}}  {}".format(mgr_safe(account["handle"]), mgr_safe(post["caption"])):
                                font noto_font
                                size 20
                                color "#ffffff"
                                xoffset 30
                                xmaximum 385
                            null height 18
                        frame:
                            background "#292e35"
                            xfill True
                            ysize 1
                            padding (0, 0)

                    if not mgr_visible_posts_for():
                        text "No posts yet.":
                            font noto_font
                            color "#ffffff"
                            size 24
                            xalign 0.5
                            yalign 0.5

            elif mgr_page == "profile":
                $ account = mgr_accounts[mgr_account]
                $ account_posts = mgr_visible_posts_for(mgr_account)

                viewport:
                    xfill True
                    ysize 740
                    draggable True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox
                    xfill True
                    spacing 18

                    null height 8
                    hbox:
                        xsize 400
                        xalign 0.5
                        xoffset 12
                        spacing 16
                        fixed:
                            xysize (142, 142)
                            if account["avatar"] and renpy.loadable(account["avatar"]):
                                add account["avatar"]:
                                    xysize (142, 142)
                                    fit "contain"
                            else:
                                frame:
                                    xysize (142, 142)
                                    padding (0, 0)
                                    background account["color"]
                                    text account["name"][:1]:
                                        font noto_font
                                        size 58
                                        color "#ffffff"
                                        xalign 0.5
                                        yalign 0.5
                        vbox:
                            spacing 8
                            text account["name"]:
                                font noto_font
                                size 26
                                bold False
                                color "#c41f1f"
                            text "{} posts".format(len(account_posts)):
                                font noto_font
                                size 18
                                color "#ffffff"
                            text "{} followers".format(account["followers"]):
                                font noto_font
                                size 18
                                color "#ffffff"
                            text "{} following".format(account["following"]):
                                font noto_font
                                size 18
                                color "#ffffff"

                    text account["bio"]:
                        xoffset 30
                        font noto_font
                        size 21
                        color "#dddddd"
                        xmaximum 385
                    frame:
                        background "#292e35"
                        xfill True
                        ysize 1
                        padding (0, 0)
                    text "POSTS":
                        font noto_font
                        size 21
                        bold True
                        color "#ffffff"
                        xalign 0.5

                    grid 3 max(1, (len(account_posts) + 2) // 3):
                        spacing 6
                        xalign 0.5
                        for post in account_posts:
                            button:
                                background "#222832"
                                padding (0, 0)
                                xysize (132, 132)
                                action [
                                            SetScreenVariable("mgr_post_id", post["id"]),
                                            SetScreenVariable("mgr_post_return", "profile"),
                                            SetScreenVariable("mgr_page", "post")
                                        ]
                                if renpy.loadable(post["image"]):
                                    add post["image"]:
                                        xysize (132, 132)
                                        fit "cover"
                                else:
                                    text "Image":
                                        font noto_font
                                        color "#bbbbbb"
                                        size 18
                                        xalign 0.5
                                        yalign 0.5
                        for _ in range((3 - len(account_posts) % 3) % 3 if account_posts else 3):
                            null width 132 height 132

            elif mgr_page == "post":
                $ post = mgr_post_by_id(mgr_post_id)
                if post is not None:
                    $ account = mgr_accounts[post["account"]]
                    $ p_id = post["id"]

                    viewport:
                        xfill True
                        ysize 674
                        draggable True
                        mousewheel True
                        scrollbars "vertical"

                        has vbox
                        spacing 12
                        xfill True
                        null height 5

                        hbox:
                            xsize 400
                            xalign 0.5
                            xoffset 12
                            spacing 10
                            button:
                                xysize (57, 57)
                                padding (0, 0)
                                background None
                                action [
                                            SetScreenVariable("mgr_account", post["account"]),
                                            SetScreenVariable("mgr_page", "profile")
                                        ]
                                if account["avatar"] and renpy.loadable(account["avatar"]):
                                    add account["avatar"]:
                                        xysize (57, 57)
                                        fit "contain"
                                else:
                                    frame:
                                        background account["color"]
                                        padding (0, 0)
                                        xysize (57, 57)
                                        text account["name"][:1]:
                                            xalign 0.5
                                            yalign 0.5
                                            font noto_font
                                            size 24
                                            color "#ffffff"
                            button:
                                background None
                                padding (0, 0)
                                xysize (333, 57)
                                action [
                                            SetScreenVariable("mgr_account", post["account"]),
                                            SetScreenVariable("mgr_page", "profile")
                                        ]
                                text account["handle"]:
                                    font noto_font
                                    size 22
                                    bold False
                                    color "#c41f1f"
                                    xalign 0.0
                                    yalign 0.5


                        $ mgr_photos = mgr_post_images(post)
                        $ mgr_slide = mgr_image_pages.get(p_id, 0) % len(mgr_photos)
                        $ mgr_current_photo = mgr_photos[mgr_slide]
                        if renpy.loadable(mgr_current_photo):
                            add mgr_current_photo:
                                maxsize (420, 620)
                                xalign 0.5
                        else:
                            $ mgr_detail_preview = (420, 236) if post.get("orientation") == "landscape" else (349, 620)
                            frame:
                                xalign 0.5
                                xysize mgr_detail_preview
                                background "#222832"
                                padding (0, 0)
                                text "IMAGE: " + mgr_current_photo:
                                    font noto_font
                                    size 17
                                    color "#ffffff"
                                    xalign 0.5
                                    yalign 0.5
                                    xmaximum 285

                        if len(mgr_photos) > 1:
                            hbox:
                                xalign 0.5
                                spacing 25
                                textbutton "‹":
                                    background None
                                    padding (10, 0)
                                    text_font noto_font
                                    text_size 30
                                    text_color "#ffffff"
                                    text_hover_color "#f44863"
                                    action SetScreenVariable("mgr_image_pages", mgr_set_image_page(mgr_image_pages, p_id, mgr_slide - 1, len(mgr_photos)))
                                text "{} / {}".format(mgr_slide + 1, len(mgr_photos)):
                                    font noto_font
                                    size 18
                                    color "#cccccc"
                                    yalign 0.5
                                textbutton "›":
                                    background None
                                    padding (10, 0)
                                    text_font noto_font
                                    text_size 30
                                    text_color "#ffffff"
                                    text_hover_color "#f44863"
                                    action SetScreenVariable("mgr_image_pages", mgr_set_image_page(mgr_image_pages, p_id, mgr_slide + 1, len(mgr_photos)))

                        hbox:
                            spacing 12
                            xoffset 30
                            textbutton ("♥" if p_id in mgr_liked_posts else "♡"):
                                background None
                                text_font notok_font
                                text_size 30
                                text_color ("#f44863" if p_id in mgr_liked_posts else "#ffffff")
                                action Function(mgr_toggle_like, p_id)
                            text "{} likes".format(post["likes"] + (1 if p_id in mgr_liked_posts else 0)):
                                font noto_font
                                size 20
                                color "#ffffff"
                                yalign 0.5
                        text "{{color=#c41f1f}}{}{{/color}}  {}".format(mgr_safe(account["handle"]), mgr_safe(post["caption"])):
                            font noto_font
                            size 20
                            color "#ffffff"
                            xoffset 30
                            xmaximum 385
                        text "Comments":
                            xoffset 30
                            font noto_font
                            size 23
                            bold True
                            color "#ffffff"
                        for npc_index in range(len(post["comments"])):
                            $ handle, comment = post["comments"][npc_index]
                            hbox:
                                xoffset 30
                                spacing 8
                                text "{{color=#c41f1f}}{}{{/color}}  {}".format(mgr_safe(handle), mgr_safe(comment)):
                                    font noto_font
                                    size 20
                                    color "#dddddd"
                                    xmaximum 350
                                if mgr_npc_comment_has_owner_heart(p_id, npc_index):
                                    text "♥":
                                        font notok_font
                                        size 20
                                        color "#ef4263"
                                        yalign 0.0
                        for comment_index in range(len(mgr_player_comments.get(p_id, []))):
                            $ comment = mgr_player_comments[p_id][comment_index]
                            hbox:
                                spacing 8
                                xoffset 30
                                text mgr_accounts["mc"]["handle"]:
                                    font noto_font
                                    size 20
                                    bold False
                                    color "#c41f1f"
                                text mgr_safe(comment):
                                    font noto_font
                                    size 20
                                    color "#dddddd"
                                    xmaximum 184
                                if mgr_comment_has_owner_heart(p_id, comment_index):
                                    text "♥":
                                        font notok_font
                                        size 20
                                        color "#ef4263"
                                        yalign 0.0
                                textbutton "×":
                                    yalign 0.0
                                    padding (2, 0)
                                    background None
                                    text_font noto_font
                                    text_size 23
                                    text_color "#aaaaaa"
                                    text_hover_color "#ff5555"
                                    action Function(mgr_delete_comment, p_id, comment_index)
                        null height 28


                    frame:
                        background "#161c24"
                        xfill True
                        ysize 66
                        padding (8, 8)
                        has hbox
                        spacing 10
                        yalign 0.5
                        frame:
                            background "#29323d"
                            xysize (334, 49)
                            padding (9, 8)
                            input:
                                value ScreenVariableInputValue("mgr_comment_draft")
                                font noto_font
                                size 20
                                color "#ffffff"
                                length 200
                                pixel_width 300
                        textbutton "Post":
                            yalign 0.5
                            text_font noto_font
                            text_size 21
                            text_color "#70a9ff"
                            background None
                            action [
                                        Function(mgr_submit_comment, p_id, mgr_comment_draft),
                                        SetScreenVariable("mgr_comment_draft", "")
                                    ]
                else:
                    text "Post not found." color "#ffffff"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
