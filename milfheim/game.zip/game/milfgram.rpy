






default mg_unlocked_posts = ["jason_001", "amanda_001"]
default mg_liked_posts = []
default mg_player_comments = {}
default mg_owner_comment_hearts = {}
default mg_npc_comment_hearts = mg_initial_npc_comment_hearts()

init -1 python:



    mg_accounts = {
        "amanda": {
            "handle": "amanda",
            "name": "Amanda",
            "bio": "",
            "avatar": "images/phone/milfgram/amanda_milfgram.png",
            "followers": "1988",
            "following": "003",
            "color": "#8a6577",
        },
        "jason": {
            "handle": "jason",
            "name": "Jason",
            "bio": "",
            "avatar": "images/phone/milfgram/jason_milfgram.png",
            "followers": "007",
            "following": "467",
            "color": "#668b82",
        },
        
        "helen": {
            "handle": "helen",
            "name": "Helen",
            "bio": "Milfheim City",
            "avatar": "images/phone/milfgram/helen_milfgram.png",
            "followers": "1,208",
            "following": "184",
            "color": "#8a6577",
        },
        "mary": {
            "handle": "mary",
            "name": "Mary",
            "bio": "A little happiness, every day.",
            "avatar": "images/phone/milfgram/mary_milfgram.png",
            "followers": "1805",
            "following": "002",
            "color": "#668b82",
        },
        "alessia": {
            "handle": "alessia",
            "name": "Alessia",
            "bio": "",
            "avatar": "images/phone/milfgram/alessia_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#6e8390",
        },
        "anna": {
            "handle": "anna",
            "name": "Anna",
            "bio": "",
            "avatar": "images/phone/milfgram/anna_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9b8276",
        },
        "beth": {
            "handle": "beth",
            "name": "Beth",
            "bio": "",
            "avatar": "images/phone/milfgram/beth_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#82917c",
        },
        "celine": {
            "handle": "celine",
            "name": "Celine",
            "bio": "",
            "avatar": "images/phone/milfgram/celine_milfgram.png",
            "followers": "1788",
            "following": "010",
            "color": "#9a8198",
        },
        "chloe": {
            "handle": "chloe",
            "name": "Chloe",
            "bio": "",
            "avatar": "images/phone/milfgram/chloe_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#8a6577",
        },
        "diana": {
            "handle": "diana",
            "name": "Diana",
            "bio": "",
            "avatar": "images/phone/milfgram/diana_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#668b82",
        },
        "emma": {
            "handle": "emma",
            "name": "Emma",
            "bio": "",
            "avatar": "images/phone/milfgram/emma_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#6e8390",
        },
        "ethan": {
            "handle": "ethan",
            "name": "Ethan",
            "bio": "",
            "avatar": "images/phone/milfgram/ethan_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9b8276",
        },
        "evan": {
            "handle": "evan",
            "name": "Evan",
            "bio": "",
            "avatar": "images/phone/milfgram/evan_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#82917c",
        },
        "evelyn": {
            "handle": "evelyn",
            "name": "Evelyn",
            "bio": "",
            "avatar": "images/phone/milfgram/evelyn_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9a8198",
        },
        "frank": {
            "handle": "frank",
            "name": "Frank",
            "bio": "",
            "avatar": "images/phone/milfgram/frank_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#8a6577",
        },
        "harold": {
            "handle": "harold",
            "name": "Harold",
            "bio": "",
            "avatar": "images/phone/milfgram/harold_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#668b82",
        },
        "isabella": {
            "handle": "isabella",
            "name": "Isabella",
            "bio": "",
            "avatar": "images/phone/milfgram/isabella_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#6e8390",
        },
        "ivy": {
            "handle": "ivy",
            "name": "Ivy",
            "bio": "",
            "avatar": "images/phone/milfgram/ivy_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9b8276",
        },
        "kevin": {
            "handle": "kevin",
            "name": "Kevin",
            "bio": "",
            "avatar": "images/phone/milfgram/kevin_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#82917c",
        },
        "leila": {
            "handle": "leila",
            "name": "Leila",
            "bio": "",
            "avatar": "images/phone/milfgram/leila_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9a8198",
        },
        "lena": {
            "handle": "lena",
            "name": "Lena",
            "bio": "",
            "avatar": "images/phone/milfgram/lena_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#8a6577",
        },
        "marcus": {
            "handle": "marcus",
            "name": "Marcus",
            "bio": "",
            "avatar": "images/phone/milfgram/marcus_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#668b82",
        },
        "michael": {
            "handle": "michael",
            "name": "Michael",
            "bio": "",
            "avatar": "images/phone/milfgram/michael_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#6e8390",
        },
        "monica": {
            "handle": "monica",
            "name": "Monica",
            "bio": "",
            "avatar": "images/phone/milfgram/monica_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9b8276",
        },
        "olivia": {
            "handle": "olivia",
            "name": "Olivia",
            "bio": "",
            "avatar": "images/phone/milfgram/olivia_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#82917c",
        },
        "owen": {
            "handle": "owen",
            "name": "Owen",
            "bio": "",
            "avatar": "images/phone/milfgram/owen_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9a8198",
        },
        "rebecca": {
            "handle": "rebecca",
            "name": "Rebecca",
            "bio": "",
            "avatar": "images/phone/milfgram/rebecca_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#8a6577",
        },
        "rose": {
            "handle": "rose",
            "name": "Rose",
            "bio": "",
            "avatar": "images/phone/milfgram/rose_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#668b82",
        },
        "shakira": {
            "handle": "shakira",
            "name": "Shakira",
            "bio": "",
            "avatar": "images/phone/milfgram/shakira_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#6e8390",
        },
        "sophia": {
            "handle": "sophia",
            "name": "Sophia",
            "bio": "",
            "avatar": "images/phone/milfgram/sophia_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9b8276",
        },
        "stella": {
            "handle": "stella",
            "name": "Stella",
            "bio": "",
            "avatar": "images/phone/milfgram/stella_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#82917c",
        },
        "veronica": {
            "handle": "veronica",
            "name": "Veronica",
            "bio": "",
            "avatar": "images/phone/milfgram/veronica_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#9a8198",
        },
        "vivian": {
            "handle": "vivian",
            "name": "Vivian",
            "bio": "",
            "avatar": "images/phone/milfgram/vivian_milfgram.png",
            "followers": "0",
            "following": "0",
            "color": "#8a6577",
        },
    }






    mg_posts = [
        {
            "id": "amanda_001",
            "account": "amanda",
            "image": "images/phone/milfgram/amanda/amanda_milfgram_01.jpg",
            "orientation": "portrait",
            "chapter": 6,  
            "show_by_default": True,
            "caption": "A lovely day. ✨",
            "likes": 1096,
            "comments": [
                ("mary", "Beautiful picture! 💕"),
                ("citylife", "Love this!"),
                ("citywalker", "Damn, I love you ma'am.😍"),
            ],
        },
        {
            "id": "jason_001",
            "account": "jason",
            "image": "images/phone/milfgram/jason/jason_milfgram_01.jpg",
            "orientation": "landscape",
            "chapter": 6,  
            "show_by_default": True,
            "caption": "A great view today. 🌴",
            "likes": 126,
            "comments": [
                ("citywalker", "Nice shot! 🔥"),
                ("mike", "Where is this?"),
            ],
        },
        {
            "id": "mary_001",
            "account": "mary",
            "image": "images/phone/milfgram/mary/mary_milfgram_01.jpg",
            "orientation": "portrait",
            "chapter": 6,  
            "show_by_default": True,
            "caption": "Double trouble. 💋💕",
            "likes": 1778,
            "comments": [
                ("jascob_92", "You two look gorgeous! 😍"),
                ("sweetemma", "Queens! 👑💕"),
                ("matt89", "Double trouble indeed! 🔥🔥"),
                ("celine", "Haha, we're trouble together, aren't we? 😘"),
            ],
        },
        {
            "id": "celine_001",
            "account": "celine",
            "image": "images/phone/milfgram/celine/celine_milfgram_01.jpg",
            "orientation": "portrait",
            "chapter": 6,  
            "show_by_default": True,
            "caption": "A little something to make tonight sweeter. 🍹✨",
            "likes": 1378,
            "comments": [
                ("tipsyqueen", "Okay, that looks SO good! 😍"),
                ("nightowl_92", "Save me a sip! 🍹"),
                ("cocktailjunkie", "Girl, where's my invite?! 😂"),
            ],
        },
    ]

    def mg_post_images(post):
        """Optional multi-photo carousel; preserve all older single-image posts."""
        images = post.get("images")
        if images:
            return images
        return [post["image"]]

    def mg_set_image_page(pages, post_id, page_number, image_count):
        """Update only this post's UI slide, without changing game save data."""
        updated_pages = dict(pages)
        updated_pages[post_id] = page_number % image_count
        return updated_pages

    def mg_npc_comment_key(post, comment_index):
        """Stable identity for hand-written NPC comments, including duplicates.

        The author's handle and body make each comment independent of its
        position, so adding an earlier comment won't shuffle saved reactions.
        """
        entry = tuple(post["comments"][comment_index])
        duplicate_number = sum(1 for earlier in post["comments"][:comment_index]
                               if tuple(earlier) == entry)
        return (entry[0], entry[1], duplicate_number)

    def mg_initial_npc_comment_hearts():
        """Roll each predefined comment at new-game initialization (once)."""
        result = {}
        for post in mg_posts:
            result[post["id"]] = {
                mg_npc_comment_key(post, i): renpy.random.random() < 0.5
                for i in range(len(post["comments"]))
            }
        return result

    def mg_ensure_npc_comment_hearts():
        """Add rolls for newly authored comments/posts on existing saved games.

        Never reroll an already saved comment; don't disturb other post states.
        """
        s = renpy.store
        saved = s.mg_npc_comment_hearts
        updated = dict(saved)
        for post in mg_posts:
            post_id = post["id"]
            existing = saved.get(post_id, {})
            states = dict(existing)
            for i in range(len(post["comments"])):
                key = mg_npc_comment_key(post, i)
                if key not in states:
                    states[key] = renpy.random.random() < 0.5
            if states != existing:
                updated[post_id] = states
        if updated != saved:
            renpy.retain_after_load()
            s.mg_npc_comment_hearts = updated

    def mg_npc_comment_has_owner_heart(post_id, comment_index):
        """Get the saved 50% NPC heart, without rolling during UI rendering."""
        post = mg_post_by_id(post_id)
        if post is None or not (0 <= comment_index < len(post["comments"])):
            return False
        key = mg_npc_comment_key(post, comment_index)
        return renpy.store.mg_npc_comment_hearts.get(post_id, {}).get(key, False) is True

    def mg_safe(text):
        """Display typed comments literally instead of parsing Ren'Py text tags."""
        return str(text).replace("{", "{{").replace("[", "[[")

    def mg_unlock_post(post_id):
        """Call from the VN script: $ mg_unlock_post('helen_002')."""
        s = renpy.store
        known = any(p["id"] == post_id for p in mg_posts)
        if known and post_id not in s.mg_unlocked_posts:
            s.mg_unlocked_posts = list(s.mg_unlocked_posts) + [post_id]

    def mg_toggle_like(post_id):
        s = renpy.store
        
        renpy.retain_after_load()
        if post_id in s.mg_liked_posts:
            s.mg_liked_posts = [p for p in s.mg_liked_posts if p != post_id]
        else:
            s.mg_liked_posts = list(s.mg_liked_posts) + [post_id]

    def mg_submit_comment(post_id, draft):
        """Store free text exactly as entered (other than trimming outer spaces)."""
        body = str(draft).strip()
        if not body or post_id not in [p["id"] for p in mg_posts]:
            return
        s = renpy.store
        renpy.retain_after_load()
        
        updated = dict(s.mg_player_comments)
        updated[post_id] = list(updated.get(post_id, [])) + [body]
        s.mg_player_comments = updated
        
        hearts = dict(s.mg_owner_comment_hearts)
        states = list(hearts.get(post_id, []))
        states += [None] * max(0, len(updated[post_id]) - 1 - len(states))
        states.append(None)
        hearts[post_id] = states
        s.mg_owner_comment_hearts = hearts

    def mg_delete_comment(post_id, comment_index):
        """Delete only the player's saved comment at the given index."""
        s = renpy.store
        player_comments = list(s.mg_player_comments.get(post_id, []))
        if not (0 <= comment_index < len(player_comments)):
            return
        renpy.retain_after_load()
        del player_comments[comment_index]
        updated = dict(s.mg_player_comments)
        if player_comments:
            updated[post_id] = player_comments
        else:
            updated.pop(post_id, None)
        s.mg_player_comments = updated
        
        hearts = dict(s.mg_owner_comment_hearts)
        states = list(hearts.get(post_id, []))
        states += [None] * max(0, len(player_comments) + 1 - len(states))
        del states[comment_index]
        if player_comments:
            hearts[post_id] = states
        else:
            hearts.pop(post_id, None)
        s.mg_owner_comment_hearts = hearts

    def mg_comment_has_owner_heart(post_id, comment_index):
        """One reaction per MC comment. No heart until the phone is fully closed."""
        s = renpy.store
        states = s.mg_owner_comment_hearts.get(post_id, [])
        return 0 <= comment_index < len(states) and states[comment_index] is True

    def mg_finalize_owner_hearts():
        """Perform each pending 50% roll once, when phone_end() actually closes the phone."""
        s = renpy.store
        hearts = {}
        for post_id, comments in s.mg_player_comments.items():
            states = list(s.mg_owner_comment_hearts.get(post_id, []))[:len(comments)]
            states += [None] * max(0, len(comments) - len(states))
            for index, state in enumerate(states):
                if state is None:
                    states[index] = renpy.random.random() < 0.5
            hearts[post_id] = states
        if hearts != s.mg_owner_comment_hearts:
            renpy.retain_after_load()
            s.mg_owner_comment_hearts = hearts

    def mg_post_by_id(post_id):
        for post in mg_posts:
            if post["id"] == post_id:
                return post
        return None

    def mg_latest_started_chapter():
        """Read existing chapter flags from this save (not from persistent data).

        A started later chapter also includes earlier chapter posts, even when
        a tester jumps directly to a later chapter without playing Chapter 6.
        Future chapter files can use: default ch07_started = False;
        then $ ch07_started = True at the start of that chapter.
        """
        s = renpy.store
        for number in range(99, 5, -1):
            if getattr(s, "ch{:02d}_started".format(number), False):
                return number
        return 0

    def mg_visible_posts_for(account=None):
        s = renpy.store
        latest_chapter = mg_latest_started_chapter()
        return [p for p in reversed(mg_posts)
                if p.get("chapter", 6) <= latest_chapter
                and (p.get("show_by_default", False) or p["id"] in s.mg_unlocked_posts)
                and (account is None or p["account"] == account)]




init 100 python:
    if not getattr(renpy.store, "_mg_owner_hearts_close_hook_installed", False):
        _mg_original_phone_end = phone_end
        
        def _mg_phone_end_with_owner_hearts():
            for name in ("mg_finalize_owner_hearts", "mgr_finalize_owner_hearts"):
                processor = getattr(renpy.store, name, None)
                if processor is not None:
                    processor()
            return _mg_original_phone_end()
        
        phone_end = _mg_phone_end_with_owner_hearts
        _mg_owner_hearts_close_hook_installed = True




screen milfgram_ui():
    tag milfgram_ui

    on "show" action [Hide("phone_ui"), Function(mg_ensure_npc_comment_hearts)]
    on "hide" action Show("phone_ui")
    modal True
    zorder 200


    default mg_page = "feed"
    default mg_account = "jason"
    default mg_post_id = "jason_001"
    default mg_post_return = "feed"
    default mg_comment_draft = ""
    default mg_image_pages = {}
    default mg_feed_scroll = ui.adjustment()


    key "K_ESCAPE" action If(
        mg_page == "feed",
        Hide("milfgram_ui"),
        If(mg_page == "post",
           SetScreenVariable("mg_page", mg_post_return),
           SetScreenVariable("mg_page", "feed"))
    )

    window:
        at phone_position(phone_zoom, phone_x, phone_y)
        background None
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 1000


        add get_phone_theme_value("screen_background_image")
        add get_phone_theme_value("header_background_image")
        add get_phone_theme_value("base_background_image")



        frame:
            xpos 74
            ypos 104
            xysize (452, 800)
            background "#0c1015"
            padding (0, 0)

            has vbox
            xfill True
            spacing 0


            frame:
                background "#10161c"
                xfill True
                ysize 60
                padding (12, 8)

                has fixed
                xfill True
                ysize 44
                textbutton "< Back":
                    xpos 0
                    yalign 0.5
                    text_font noto_font
                    text_size 23
                    text_color "#ffffff"
                    background None
                    action If(
                                mg_page == "feed",
                                Hide("milfgram_ui"),
                                If(mg_page == "post",
                                   SetScreenVariable("mg_page", mg_post_return),
                                   SetScreenVariable("mg_page", "feed"))
                            )


                if renpy.loadable("images/phone/milfgram_logo.png"):
                    add "images/phone/milfgram_logo.png":
                        xalign 1.0
                        yalign 0.5
                else:
                    text "Milfgram":
                        font noto_font
                        size 26
                        bold True
                        color "#ffffff"
                        xalign 1.0
                        yalign 0.5

            if mg_page == "feed":
                viewport:
                    yadjustment mg_feed_scroll
                    xfill True
                    ysize 740
                    draggable True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox
                    xfill True
                    spacing 18

                    for post in mg_visible_posts_for():
                        $ account = mg_accounts[post["account"]]
                        $ p_id = post["id"]
                        $ comment_count = len(post["comments"]) + len(mg_player_comments.get(p_id, []))

                        vbox:
                            xfill True
                            spacing 8



                            hbox:
                                xsize 400
                                xalign 0.5
                                xoffset 12
                                spacing 10
                                button:
                                    xysize (57, 57)
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mg_account", post["account"]),
                                                SetScreenVariable("mg_page", "profile")
                                            ]
                                    if account["avatar"] and renpy.loadable(account["avatar"]):
                                        add account["avatar"]:
                                            xysize (57, 57)
                                            fit "contain"
                                    else:
                                        frame:
                                            xysize (57, 57)
                                            padding (0, 0)
                                            background account["color"]
                                            text account["name"][:1]:
                                                xalign 0.5
                                                yalign 0.5
                                                font noto_font
                                                size 24
                                                color "#ffffff"
                                button:
                                    xysize (333, 57)
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mg_account", post["account"]),
                                                SetScreenVariable("mg_page", "profile")
                                            ]
                                    text account["handle"]:
                                        xalign 0.0
                                        yalign 0.5
                                        font noto_font
                                        size 22
                                        bold False
                                        color "#ffffff"


                            $ mg_photos = mg_post_images(post)
                            $ mg_slide = mg_image_pages.get(p_id, 0) % len(mg_photos)
                            $ mg_current_photo = mg_photos[mg_slide]
                            if renpy.loadable(mg_current_photo):
                                button:
                                    xalign 0.5
                                    padding (0, 0)
                                    background None
                                    action [
                                                SetScreenVariable("mg_post_id", p_id),
                                                SetScreenVariable("mg_post_return", "feed"),
                                                SetScreenVariable("mg_page", "post")
                                            ]
                                    add mg_current_photo:
                                        maxsize (420, 620)
                            else:
                                $ mg_preview_size = (420, 236) if post.get("orientation") == "landscape" else (349, 620)
                                button:
                                    xalign 0.5
                                    xysize mg_preview_size
                                    padding (0, 0)
                                    background "#242b35"
                                    action [
                                                SetScreenVariable("mg_post_id", p_id),
                                                SetScreenVariable("mg_post_return", "feed"),
                                                SetScreenVariable("mg_page", "post")
                                            ]
                                    text "IMAGE: " + mg_current_photo:
                                        font noto_font
                                        size 16
                                        color "#cccccc"
                                        xalign 0.5
                                        yalign 0.5
                                        xmaximum 300

                            if len(mg_photos) > 1:
                                hbox:
                                    xalign 0.5
                                    spacing 25
                                    textbutton "‹":
                                        background None
                                        padding (10, 0)
                                        text_font noto_font
                                        text_size 30
                                        text_color "#ffffff"
                                        text_hover_color "#f44863"
                                        action SetScreenVariable("mg_image_pages", mg_set_image_page(mg_image_pages, p_id, mg_slide - 1, len(mg_photos)))
                                    text "{} / {}".format(mg_slide + 1, len(mg_photos)):
                                        font noto_font
                                        size 18
                                        color "#cccccc"
                                        yalign 0.5
                                    textbutton "›":
                                        background None
                                        padding (10, 0)
                                        text_font noto_font
                                        text_size 30
                                        text_color "#ffffff"
                                        text_hover_color "#f44863"
                                        action SetScreenVariable("mg_image_pages", mg_set_image_page(mg_image_pages, p_id, mg_slide + 1, len(mg_photos)))

                            hbox:
                                spacing 13
                                xoffset 30
                                textbutton ("♥" if p_id in mg_liked_posts else "♡"):
                                    background None
                                    text_font notok_font
                                    text_size 32
                                    text_color ("#f44863" if p_id in mg_liked_posts else "#ffffff")
                                    action Function(mg_toggle_like, p_id)
                                textbutton "Comments ({})".format(comment_count):
                                    yalign 0.5
                                    background None
                                    text_font noto_font
                                    text_size 20
                                    text_color "#dddddd"
                                    action [
                                                SetScreenVariable("mg_post_id", p_id),
                                                SetScreenVariable("mg_post_return", "feed"),
                                                SetScreenVariable("mg_page", "post")
                                            ]
                            text "{} likes".format(post["likes"] + (1 if p_id in mg_liked_posts else 0)):
                                font noto_font
                                size 20
                                color "#ffffff"
                                bold True
                                xoffset 30
                            text "{}  {}".format(account["handle"], mg_safe(post["caption"])):
                                font noto_font
                                size 20
                                color "#ffffff"
                                xoffset 30
                                xmaximum 385
                            null height 18
                        frame:
                            background "#292e35"
                            xfill True
                            ysize 1
                            padding (0, 0)

                    if not mg_visible_posts_for():
                        text "No posts yet.":
                            font noto_font
                            color "#ffffff"
                            size 24
                            xalign 0.5
                            yalign 0.5

            elif mg_page == "profile":
                $ account = mg_accounts[mg_account]
                $ account_posts = mg_visible_posts_for(mg_account)

                viewport:
                    xfill True
                    ysize 740
                    draggable True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox
                    xfill True
                    spacing 18

                    null height 8
                    hbox:
                        xsize 400
                        xalign 0.5
                        xoffset 12
                        spacing 16
                        fixed:
                            xysize (142, 142)
                            if account["avatar"] and renpy.loadable(account["avatar"]):
                                add account["avatar"]:
                                    xysize (142, 142)
                                    fit "contain"
                            else:
                                frame:
                                    xysize (142, 142)
                                    padding (0, 0)
                                    background account["color"]
                                    text account["name"][:1]:
                                        font noto_font
                                        size 58
                                        color "#ffffff"
                                        xalign 0.5
                                        yalign 0.5
                        vbox:
                            spacing 8
                            text account["name"]:
                                font noto_font
                                size 26
                                bold False
                                color "#ffffff"
                            text "{} posts".format(len(account_posts)):
                                font noto_font
                                size 18
                                color "#ffffff"
                            text "{} followers".format(account["followers"]):
                                font noto_font
                                size 18
                                color "#ffffff"
                            text "{} following".format(account["following"]):
                                font noto_font
                                size 18
                                color "#ffffff"

                    text account["bio"]:
                        xoffset 30
                        font noto_font
                        size 21
                        color "#dddddd"
                        xmaximum 385
                    frame:
                        background "#292e35"
                        xfill True
                        ysize 1
                        padding (0, 0)
                    text "POSTS":
                        font noto_font
                        size 21
                        bold True
                        color "#ffffff"
                        xalign 0.5

                    grid 3 max(1, (len(account_posts) + 2) // 3):
                        spacing 6
                        xalign 0.5
                        for post in account_posts:
                            button:
                                background "#222832"
                                padding (0, 0)
                                xysize (132, 132)
                                action [
                                            SetScreenVariable("mg_post_id", post["id"]),
                                            SetScreenVariable("mg_post_return", "profile"),
                                            SetScreenVariable("mg_page", "post")
                                        ]
                                if renpy.loadable(post["image"]):
                                    add post["image"]:
                                        xysize (132, 132)
                                        fit "cover"
                                else:
                                    text "Image":
                                        font noto_font
                                        color "#bbbbbb"
                                        size 18
                                        xalign 0.5
                                        yalign 0.5
                        for _ in range((3 - len(account_posts) % 3) % 3 if account_posts else 3):
                            null width 132 height 132

            elif mg_page == "post":
                $ post = mg_post_by_id(mg_post_id)
                if post is not None:
                    $ account = mg_accounts[post["account"]]
                    $ p_id = post["id"]

                    viewport:
                        xfill True
                        ysize 674
                        draggable True
                        mousewheel True
                        scrollbars "vertical"

                        has vbox
                        spacing 12
                        xfill True
                        null height 5

                        hbox:
                            xsize 400
                            xalign 0.5
                            xoffset 12
                            spacing 10
                            button:
                                xysize (57, 57)
                                padding (0, 0)
                                background None
                                action [
                                            SetScreenVariable("mg_account", post["account"]),
                                            SetScreenVariable("mg_page", "profile")
                                        ]
                                if account["avatar"] and renpy.loadable(account["avatar"]):
                                    add account["avatar"]:
                                        xysize (57, 57)
                                        fit "contain"
                                else:
                                    frame:
                                        background account["color"]
                                        padding (0, 0)
                                        xysize (57, 57)
                                        text account["name"][:1]:
                                            xalign 0.5
                                            yalign 0.5
                                            font noto_font
                                            size 24
                                            color "#ffffff"
                            button:
                                background None
                                padding (0, 0)
                                xysize (333, 57)
                                action [
                                            SetScreenVariable("mg_account", post["account"]),
                                            SetScreenVariable("mg_page", "profile")
                                        ]
                                text account["handle"]:
                                    font noto_font
                                    size 22
                                    bold False
                                    color "#ffffff"
                                    xalign 0.0
                                    yalign 0.5


                        $ mg_photos = mg_post_images(post)
                        $ mg_slide = mg_image_pages.get(p_id, 0) % len(mg_photos)
                        $ mg_current_photo = mg_photos[mg_slide]
                        if renpy.loadable(mg_current_photo):
                            add mg_current_photo:
                                maxsize (420, 620)
                                xalign 0.5
                        else:
                            $ mg_detail_preview = (420, 236) if post.get("orientation") == "landscape" else (349, 620)
                            frame:
                                xalign 0.5
                                xysize mg_detail_preview
                                background "#222832"
                                padding (0, 0)
                                text "IMAGE: " + mg_current_photo:
                                    font noto_font
                                    size 17
                                    color "#ffffff"
                                    xalign 0.5
                                    yalign 0.5
                                    xmaximum 285

                        if len(mg_photos) > 1:
                            hbox:
                                xalign 0.5
                                spacing 25
                                textbutton "‹":
                                    background None
                                    padding (10, 0)
                                    text_font noto_font
                                    text_size 30
                                    text_color "#ffffff"
                                    text_hover_color "#f44863"
                                    action SetScreenVariable("mg_image_pages", mg_set_image_page(mg_image_pages, p_id, mg_slide - 1, len(mg_photos)))
                                text "{} / {}".format(mg_slide + 1, len(mg_photos)):
                                    font noto_font
                                    size 18
                                    color "#cccccc"
                                    yalign 0.5
                                textbutton "›":
                                    background None
                                    padding (10, 0)
                                    text_font noto_font
                                    text_size 30
                                    text_color "#ffffff"
                                    text_hover_color "#f44863"
                                    action SetScreenVariable("mg_image_pages", mg_set_image_page(mg_image_pages, p_id, mg_slide + 1, len(mg_photos)))

                        hbox:
                            spacing 12
                            xoffset 30
                            textbutton ("♥" if p_id in mg_liked_posts else "♡"):
                                background None
                                text_font notok_font
                                text_size 30
                                text_color ("#f44863" if p_id in mg_liked_posts else "#ffffff")
                                action Function(mg_toggle_like, p_id)
                            text "{} likes".format(post["likes"] + (1 if p_id in mg_liked_posts else 0)):
                                font noto_font
                                size 20
                                color "#ffffff"
                                yalign 0.5
                        text "{}  {}".format(account["handle"], mg_safe(post["caption"])):
                            font noto_font
                            size 20
                            color "#ffffff"
                            xoffset 30
                            xmaximum 385
                        text "Comments":
                            xoffset 30
                            font noto_font
                            size 23
                            bold True
                            color "#ffffff"
                        for npc_index in range(len(post["comments"])):
                            $ handle, comment = post["comments"][npc_index]
                            hbox:
                                xoffset 30
                                spacing 8
                                text "{}  {}".format(mg_safe(handle), mg_safe(comment)):
                                    font noto_font
                                    size 20
                                    color "#dddddd"
                                    xmaximum 350
                                if mg_npc_comment_has_owner_heart(p_id, npc_index):
                                    text "♥":
                                        font notok_font
                                        size 20
                                        color "#ef4263"
                                        yalign 0.0
                        for comment_index in range(len(mg_player_comments.get(p_id, []))):
                            $ comment = mg_player_comments[p_id][comment_index]
                            hbox:
                                spacing 8
                                xoffset 30
                                text "[d_name]":
                                    font noto_font
                                    size 20
                                    bold True
                                    color "#ffffff"
                                text mg_safe(comment):
                                    font noto_font
                                    size 20
                                    color "#dddddd"
                                    xmaximum 220
                                if mg_comment_has_owner_heart(p_id, comment_index):
                                    text "♥":
                                        font notok_font
                                        size 20
                                        color "#ef4263"
                                        yalign 0.0
                                textbutton "×":
                                    yalign 0.0
                                    padding (2, 0)
                                    background None
                                    text_font noto_font
                                    text_size 23
                                    text_color "#aaaaaa"
                                    text_hover_color "#ff5555"
                                    action Function(mg_delete_comment, p_id, comment_index)
                        null height 28


                    frame:
                        background "#161c24"
                        xfill True
                        ysize 66
                        padding (8, 8)
                        has hbox
                        spacing 10
                        yalign 0.5
                        frame:
                            background "#29323d"
                            xysize (334, 49)
                            padding (9, 8)
                            input:
                                value ScreenVariableInputValue("mg_comment_draft")
                                font noto_font
                                size 20
                                color "#ffffff"
                                length 200
                                pixel_width 300
                        textbutton "Post":
                            yalign 0.5
                            text_font noto_font
                            text_size 21
                            text_color "#70a9ff"
                            background None
                            action [
                                        Function(mg_submit_comment, p_id, mg_comment_draft),
                                        SetScreenVariable("mg_comment_draft", "")
                                    ]
                else:
                    text "Post not found." color "#ffffff"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
