










init -1480 python in _mods.ZLZK._base_:

    import sys
    import os
    import re



    if 'PY2' not in globals():
        PY2 = True

    if 'pystr' not in globals():
        pystr = __builtins__['str']

    if 'unicode' not in globals():
        unicode = type("")



    @init()
    def wraps():
        """ Reserved namespace. """
        
        from functools import wraps
        
        
        
        if PY2:
            
            def PY2_wraps(callable):
                return wraps(callable, ("__name__", "__doc__"), ())
            
            
            
            try:
                return PY2_wraps
            finally:
                del PY2_wraps
        
        
        
        return wraps




    RPY_object = object
    RPY_dict   = dict
    RPY_list   = list
    RPY_set    = set
    RPY_str    = unicode




    eval = __builtins__['eval']


    object = python_object
    dict   = python_dict
    list   = python_list
    set    = python_set
    str    = pystr


    __renpy__dict__ = dict
    __renpy__list__ = list
    __renpy__set__  = set



    RPY_persistent = renpy.game.persistent
    RPY_config     = renpy.config
    RPY_store      = renpy.store



    del python_object
    del python_dict
    del python_list
    del python_set

    del _object
    del _dict
    del _list
    del _set

    del pystr
    del unicode
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
