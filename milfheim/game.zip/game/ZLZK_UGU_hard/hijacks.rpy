










init 1400 python in _mods.ZLZK._base_:

    @init()
    def _():
        """ Reserved namespace. """
        
        
        @CallablePatcher(renpy, 'seen_label')
        def hijack(func, *args, **kwargs):
            return True
        
        
        @CallablePatcher(renpy, 'seen_image')
        def hijack(func, *args, **kwargs):
            return True
        
        
        @CallablePatcher(renpy, 'seen_audio')
        def hijack(func, *args, **kwargs):
            return True
        
        
        
        
        @CallablePatcher(RPY_store._m1_00gallery__GalleryArbitraryCondition, 'check')
        def hijack(method, *args, **kwargs):
            return True



    @init()
    def _():
        """ Reserved namespace. """
        
        
        @CallablePatcher(renpy.game.Persistent, '__getattr__')
        def hijack(func, inst, name):
            if not name.startswith("_"):
                return True
            return func(name)
        
        
        @CallablePatcher(renpy.game.Persistent, '__getattribute__')
        def hijack(func, inst, name):
            if not name.startswith("_"):
                return UGU_fake_value(func(name))
            return func(name)





    @init()
    def _():
        """ Reserved namespace. """
        
        replaced = ZLZK_replaced_callables
        inserted = ZLZK_inserted_callables
        
        
        
        @CallablePatcher(renpy, 'utter_restart')
        def hijack(func, *args, **kwargs):
            while replaced:
                setattr( *replaced.pop() )
            while inserted:
                delattr( *inserted.pop() )
            return func(*args, **kwargs)
        del hijack
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
