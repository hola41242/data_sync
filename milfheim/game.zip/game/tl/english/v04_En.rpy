translate english ch04_hstudio01_7bd9802d:

    x "**(Pant... Pant...)**"

translate english ch04_hstudio01_fad01e7b:

    n "A sudden whiff of [d_name]'s scent hit Sophia's nose."

translate english ch04_hstudio01_17867412:

    n "The scent of a man other than her husband left her feeling unsettled."

translate english ch04_hstudio01_c259741d:

    h "Hold them halfway down for a second... Perfect."

translate english ch04_hstudio01_058667db:

    n "Click!"

translate english ch04_hstudio01_582f459a:

    h "**(Whew... It's way too hot in here.)**"

translate english ch04_hstudio01_7977908a:

    h "Hang on, you two."

translate english ch04_hstudio01_131afde3:

    h "Sorry for stopping the shoot."

translate english ch04_hstudio01_4f77ac87:

    h "Whew... That's much better."

translate english ch04_hstudio01_d957c0be:

    h "Sorry for calling a break without asking first."

translate english ch04_hstudio01_92a90223:

    x "............."

translate english ch04_hstudio01_fe5fd224:

    h "It's really muggy today."

translate english ch04_hstudio01_a09a9b93:

    h "Honestly, I'd love to take everything off too, but..."

translate english ch04_hstudio01_426dd94b:

    h "But I'm the photographer, not the model. Haha."

translate english ch04_hstudio01_967252d1:

    h "Alright, let's get back to it."

translate english ch04_hstudio01_ba590549:

    h "Now pull them all the way down, Madam!"

translate english ch04_hstudio01_058667db_1:

    n "Click!"

translate english ch04_hstudio01_058667db_2:

    n "Click!"

translate english ch04_hstudio01_9d54c70b:

    x "Ngh!!"

translate english ch04_hstudio01_058667db_3:

    n "Click!"

translate english ch04_hstudio01_058667db_4:

    n "Click!"

translate english ch04_hstudio01_a841b381:

    n "As Sophia pulled his underwear all the way down, his large penis sprang free and slapped her across the face."

translate english ch04_hstudio01_ba166e9a:

    n "It didn't fit the image of [d_name] she had always had in her mind."

translate english ch04_hstudio01_117bb1f8:

    x "**(..............)**"

translate english ch04_hstudio01_7eb9bb98:

    x "**(Oh my God, [d_name]!!!!!)**"

translate english ch04_hstudio01_0e871912:

    n "The moment she saw [d_name]'s penis, every preconceived notion she'd ever had about her former student shattered."

translate english ch04_hstudio01_d207e582:

    x "**(Is that... really yours?....)**"

translate english ch04_hstudio01_117bb1f8_1:

    x "**(..............)**"

translate english ch04_hstudio01_737704ac:

    x "**(It doesn't suit you at all...)**"

translate english ch04_hstudio01_2a6861f0:

    n "To her, [d_name] was no longer the boy who used to joke around with Jason."

translate english ch04_hstudio01_79a304d1:

    h "**(Oh my God....)**"

translate english ch04_hstudio01_058667db_5:

    n "Click!"

translate english ch04_hstudio01_efae12c1:

    x "**(Isn't he embarrassed at all?)**"

translate english ch04_hstudio01_9bcc0ea9:

    x "**(Cognitive dissonance... schema violation... expectancy violation...)**"

translate english ch04_hstudio01_2bbaaa77:

    x "**(......)**"

translate english ch04_hstudio01_058667db_6:

    n "Click!"

translate english ch04_hstudio01_ff2b9fbe:

    h "G-Great!"

translate english ch04_hstudio01_5d4492b5:

    h "The chemistry between you two is incredible right now."

translate english ch04_hstudio01_d208adb5:

    h "Let's keep riding that energy!"

translate english ch04_hstudio01_da038a80:

    h "Look at him the way you'd look at your boyfriend's erection."

translate english ch04_hstudio01_6a6b5bbc:

    h "Perfect! That expression is fantastic."

translate english ch04_hstudio01_058667db_7:

    n "Click!"

translate english ch04_hstudio01_e35d5540:

    x "..............."

translate english ch04_hstudio01_108a800b:

    x "**(What kind of expression am I making right now?)**"

translate english ch04_hstudio01_e9ea8c41:

    x "**(.........)**"

translate english ch04_hstudio01_8174cb1f:

    x "**(When was the last time I saw a man's penis this close?... )**"

translate english ch04_hstudio01_1882712d:

    h "Ahem…"

translate english ch04_hstudio01_a8a89ba6:

    h "Madam."

translate english ch04_hstudio01_b9bb2bf9:

    h "Now, please take hold of his penis."

translate english ch04_hstudio01_47532148:

    d "**(!!!!!)**"

translate english ch04_hstudio01_11b443c8:

    h "Uh...I mean.."

translate english ch04_hstudio01_c6a4d2d7:

    h "Please hold the base of his penis."

translate english ch04_hstudio01_117bb1f8_2:

    x "**(..............)**"

translate english ch04_hstudio01_0d60af25:

    x "**(........)**"

translate english ch04_hstudio01_058667db_8:

    n "Click!"

translate english ch04_hstudio01_5aecafb3:

    d "Ugh..."

translate english ch04_hstudio01_058667db_9:

    n "Click!"

translate english ch04_hstudio01_b0450d16:

    d "**(Damn....)**"

translate english ch04_hstudio01_16fbef11:

    d "**(Her hand feels way too good....)**"

translate english ch04_hstudio01_9bdbb813:

    d "**(It's so soft...)**"

translate english ch04_hstudio01_00280fdc:

    h "Excellent, Madam."

translate english ch04_hstudio01_1ce8476e:

    h "Now, I want you to imagine you're a couple. Caress his penis, then act out the motions leading into oral sex."

translate english ch04_hstudio01_f5d4777e:

    h "Let me explain again."

translate english ch04_hstudio01_ddba8765:

    h "You and [d_name] are lovers who can't get enough of each other."

translate english ch04_hstudio01_1aa62551:

    h "Right now, it's just you and [d_name] in this room!"

translate english ch04_hstudio01_058667db_10:

    n "Click!"

translate english ch04_hstudio01_e49db453:

    x "**(..........)**"

translate english ch04_hstudio01_058667db_11:

    n "Click!"

translate english ch04_hstudio01_058667db_12:

    n "Click!"

translate english ch04_hstudio01_058667db_13:

    n "Click!"

translate english ch04_hstudio01_2714d2e8:

    d "**(Damn!!)**"

translate english ch04_hstudio01_92dc159c:

    d "**(I can feel every breath from her mouth... God...)**"

translate english ch04_hstudio01_058667db_14:

    n "Click!"

translate english ch04_hstudio01_5fdab084:

    n "The warmth of her breath washed over [d_name]'s penis."

translate english ch04_hstudio01_d06bc323:

    n "He could feel every exhale against it."

translate english ch04_hstudio01_def0b928:

    n "The sensation reminded him of Mary's mouth, sending a powerful surge of arousal through him."

translate english ch04_hstudio01_058667db_15:

    n "Click!"

translate english ch04_hstudio01_94fdaf49:

    h "Perfect."

translate english ch04_hstudio01_cc186043:

    h "[d_name], place your hand on Madam's head."

translate english ch04_hstudio01_94fdaf49_1:

    h "That's it."

translate english ch04_hstudio01_058667db_16:

    n "Click!"

translate english ch04_hstudio01_058667db_17:

    n "Click!"

translate english ch04_hstudio01_058667db_18:

    n "Click!"

translate english ch04_hstudio01_02c07eb9:

    n "Though it was only an act for the photoshoot, to Sophia it was a form of self-gratification."

translate english ch04_hstudio01_22e34daa:

    n "It only reinforced her narcissism."

translate english ch04_hstudio01_e9d86f3c:

    n "She took quiet satisfaction in believing she was the reason [d_name] was so hard."

translate english ch04_hstudio01_0a7dc162:

    d "**(This is torture.....)**"

translate english ch04_hstudio01_b53297d3:

    d "**(For a man, this is pure torture...)**"

translate english ch04_hstudio01_058667db_19:

    n "Click!"

translate english ch04_hstudio01_c4afb0b3:

    n "As a result, her passionate performance of oral sex was,"

translate english ch04_hstudio01_a037d180:

    n "In a way, her reward for the young man's erection she believed she'd caused."

translate english ch04_hstudio01_058667db_20:

    n "Click!"

translate english ch04_hstudio01_035c892a:

    x "**(I'm so confused... So confused...)**"

translate english ch04_hstudio01_b7875c81:

    x "**(What are you doing here, Sophia?)**"

translate english ch04_hstudio01_8e593ff9:

    x "**(............)**"

translate english ch04_hstudio01_6eb94111:

    x "**(Why am I putting on such a lewd performance?...)**"

translate english ch04_hstudio01_058667db_21:

    n "Click!"

translate english ch04_hstudio01_7e0692f1:

    h "Very nice."

translate english ch04_hstudio01_63d67d62:

    h "Alright, Madam."

translate english ch04_hstudio01_83c235fb:

    h "Lift up his penis and prete..."

translate english ch04_hstudio01_a01f4f46:

    h ".........."

translate english ch04_hstudio01_45e6fec7:

    h "Pretend to act like you're licking his testicles."

translate english ch04_hstudio01_07e558d4:

    d "**(Shit.....)**"

translate english ch04_hstudio01_e35d5540_1:

    x "..............."

translate english ch04_hstudio01_f9bc84c9:

    x "**(Seriously?)**"

translate english ch04_hstudio01_bb15e894:

    x "**(Wow, [h_name]....)**"

translate english ch04_hstudio01_834712c8:

    x "**(You're really good at coming up with poses like this...)**"

translate english ch04_hstudio01_058667db_22:

    n "Click!"

translate english ch04_hstudio01_058667db_23:

    n "Click!"

translate english ch04_hstudio01_c099f580:

    d "*Mmm...*"

translate english ch04_hstudio01_058667db_24:

    n "Click!"

translate english ch04_hstudio01_058667db_25:

    n "Click!"

translate english ch04_hstudio01_92a90223_1:

    x "............."

translate english ch04_hstudio01_a64e73a1:

    x "**(Oh my God..)**"

translate english ch04_hstudio01_65df989e:

    x "**(His scent is all around me.....)**"

translate english ch04_hstudio01_058667db_26:

    n "Click!"

translate english ch04_hstudio01_058667db_27:

    n "Click!"

translate english ch04_hstudio01_058667db_28:

    n "Click!"

translate english ch04_hstudio01_cabd13d1:

    d "**(That's it, Madam!!)**"

translate english ch04_hstudio01_c07d36cf:

    d "**(Ah.......)**"

translate english ch04_hstudio01_11944973:

    d "**(Just a little more... make it look a little more convincing...)**"

translate english ch04_hstudio01_94fdaf49_2:

    h "Perfect."

translate english ch04_hstudio01_058667db_29:

    n "Click!"

translate english ch04_hstudio01_058667db_30:

    n "Click!"

translate english ch04_hstudio01_2efa93b9:

    x "**(Ah!!!!!)**"

translate english ch04_hstudio01_e05fa6ec:

    d "Ugh..."

translate english ch04_hstudio01_058667db_31:

    n "Click!"

translate english ch04_hstudio01_058667db_32:

    n "Click!"

translate english ch04_hstudio01_1d74e97e:

    x "**(It touched...)**"

translate english ch04_hstudio01_058667db_33:

    n "Click!"

translate english ch04_hstudio01_60f11cdd:

    d "**(That's it, Madam!!!)**"

translate english ch04_hstudio01_265e313c:

    d "**(It tickles!!)**"

translate english ch04_hstudio01_058667db_34:

    n "Click!"

translate english ch04_hstudio01_c1a63737:

    h "Are you alright, [d_name]?"

translate english ch04_hstudio01_488ad223:

    h "Is that position uncomfortable at all?"

translate english ch04_hstudio01_75967848:

    d "Yes, I'm fine!"

translate english ch04_hstudio01_de4ca356:

    d "Everything's great!"

translate english ch04_hstudio01_94fdaf49_3:

    h "Good."

translate english ch04_hstudio01_1e4dfd49:

    h "Now both of you, stand up and face each other."

translate english ch04_hstudio01_23281d5e:

    h "This is the moment right after you've finished oral sex and are looking into each other's eyes."

translate english ch04_hstudio01_57ab04d1:

    h "Madam, I'd like you to pretend to tease [d_name]'s nipple with your mouth."

translate english ch04_hstudio01_7a8dc88c:

    h "Too much acting starts to look unnatural, so I'd appreciate your understanding."

translate english ch04_hstudio01_56737a35:

    h "From here on, if you're both comfortable with it, you can do some light, genuine foreplay on each other's upper body."

translate english ch04_hstudio01_9b8fa351:

    h "If either of you feels uncomfortable, just signal with your hand and the other person should stop."

translate english ch04_hstudio01_45c636b9:

    h "I'll try to keep my directions to a minimum from here on."

translate english ch04_hstudio01_3be0d584:

    d "Understood!"

translate english ch04_hstudio01_0f5e567d:

    x "**(What?)**"

translate english ch04_hstudio01_100963d8:

    x "**(What did [h_name] just say?)**"

translate english ch04_hstudio01_e9ea8c41_1:

    x "**(.........)**"

translate english ch04_hstudio01_d0b08117:

    x "**(Did she tell me to suck [d_name]'s nipple?)**"

translate english ch04_hstudio01_e9ea8c41_2:

    x "**(.........)**"

translate english ch04_hstudio01_d3a0316f:

    x "**(...Or did she just mean to pretend?)**"

translate english ch04_hstudio01_94fdaf49_4:

    h "Perfect."

translate english ch04_hstudio01_058667db_35:

    n "Click!"

translate english ch04_hstudio01_058667db_36:

    n "Click!"

translate english ch04_hstudio01_846ffc6c:

    d "Ugh..."

translate english ch04_hstudio01_058667db_37:

    n "Click!"

translate english ch04_hstudio01_058667db_38:

    n "Click!"

translate english ch04_hstudio01_8a08e805:

    x "**(Phew......)**"

translate english ch04_hstudio01_7fba98cd:

    x "**(Okay........)**"

translate english ch04_hstudio01_1bd99552:

    x "**(It's nothing... It's just acting.)**"

translate english ch04_hstudio01_e11a1d63:

    x "**(I'm not actually sucking my student's nipple.)**"

translate english ch04_hstudio01_52791708:

    x "**(It's only acting..........)**"

translate english ch04_hstudio01_86a6fd36:

    n "*Kiss*"

translate english ch04_hstudio01_71b75a09:

    d "**(Shit!!!!!!!!)**"

translate english ch04_hstudio01_413bc5aa:

    d "**(Madam............)**"

translate english ch04_hstudio01_dc4492be:

    d "**(Ahh....)**"

translate english ch04_hstudio01_058667db_39:

    n "Click!"

translate english ch04_hstudio01_797c31eb:

    d "**(Ah, Madam............)**"

translate english ch04_hstudio01_058667db_40:

    n "Click!"

translate english ch04_hstudio01_3819fcc2:

    d "**(Damn......)**"

translate english ch04_hstudio01_0318caef:

    d "**(To hell with the photoshoot... I just want to fuck her!!!!)**"

translate english ch04_hstudio01_fb4342b7:

    d "**(..........)**"

translate english ch04_hstudio01_ebd8f5fa:

    d "**(At this rate... maybe I really do have a chance.)**"

translate english ch04_hstudio01_058667db_41:

    n "Click!"

translate english ch04_hstudio01_3819fcc2_1:

    d "**(Damn......)**"

translate english ch04_hstudio01_8eccdcab:

    x "**(!!!!!!!!!!!!)**"

translate english ch04_hstudio01_058667db_42:

    n "Click!"

translate english ch04_hstudio01_2d37197e:

    x "**(Ahh...)**"

translate english ch04_hstudio01_058667db_43:

    n "Click!"

translate english ch04_hstudio01_058667db_44:

    n "Click!"

translate english ch04_hstudio01_c9abd11a:

    d "**(Damn, I want to put it inside her!!!!)**"

translate english ch04_hstudio01_058667db_45:

    n "Click!"

translate english ch04_hstudio01_25e6f490:

    x "**(Mmm...)**"

translate english ch04_hstudio01_058667db_46:

    n "Click!"

translate english ch04_hstudio01_058667db_47:

    n "Click!"

translate english ch04_hstudio01_2722eec2:

    x "**(Oh my God.....)**"

translate english ch04_hstudio01_a84ad950:

    x "**(His cock is so hot...)**"

translate english ch04_hstudio01_d3cbba92:

    x "**(...........)**"

translate english ch04_hstudio01_fee72241:

    x "**(Did my body make him this excited?)**"

translate english ch04_hstudio01_058667db_48:

    n "Click!"

translate english ch04_hstudio01_cfa4a1f6:

    d "**(I want to fuck you, Madam!!)**"

translate english ch04_hstudio01_be09061b:

    d "**(Why don't we do it?... )**"

translate english ch04_hstudio01_058667db_49:

    n "Click!"

translate english ch04_hstudio01_ccfd8bc2:

    d "**(Don't you think [h_name] would understand... considering the situation?)**"

translate english ch04_hstudio01_058667db_50:

    n "Click!"

translate english ch04_hstudio01_cec2df53:

    d "**(Hah........)**"

translate english ch04_hstudio01_1a244e04:

    d "**(I really want to put it inside....)**"

translate english ch04_hstudio01_058667db_51:

    n "Click!"

translate english ch04_hstudio01_3877e1e1:

    x "**(Ah......)**"

translate english ch04_hstudio01_058667db_52:

    n "Click!"

translate english ch04_hstudio01_058667db_53:

    n "Click!"

translate english ch04_hstudio01_a84b7f33:

    d "**(She did it, so it's only fair if I do it too... right??)**"

translate english strings:
    old "그녀의 젖꼭지를 입에 넣는다."
    new "Take her nipple in your mouth."

translate english ch04_hstudio01_92f21ed5:

    n ""

translate english ch04_hstudio01_829d89c6:

    x "**(Ah!!!!!!)**"

translate english ch04_hstudio01_f1015543:

    d "**(I'm gonna eat you up!!)**"

translate english ch04_hstudio01_058667db_54:

    n "Click!"

translate english ch04_hstudio01_058667db_55:

    n "Click!"

translate english ch04_hstudio01_36558e8a:

    x "Mmm..."

translate english ch04_hstudio01_740e8c17:

    x ".........."

translate english ch04_hstudio01_54b50d03:

    x "**(Ah!!)**"

translate english ch04_hstudio01_e627675c:

    x "**(Hey! Don't move your tongue like that!!)**"

translate english ch04_hstudio01_27849914:

    x "Ahh..."

translate english ch04_hstudio01_d88ae46f:

    x "Hah... ahh..."

translate english ch04_hstudio01_f806a961:

    h "**(My God.....)**"

translate english ch04_hstudio01_058667db_56:

    n "Click!"

translate english ch04_hstudio01_058667db_57:

    n "Click!"

translate english ch04_hstudio01_3340fea0:

    x "**(Something's not right!!)**"

translate english ch04_hstudio01_ed891687:

    x "**(This doesn't feel like acting anymore.)**"

translate english ch04_hstudio01_300f763d:

    x "**(This is real...!)**"

translate english ch04_hstudio01_fe25500a:

    x "Ahh......"

translate english ch04_hstudio01_058667db_58:

    n "Click!"

translate english ch04_hstudio01_ea5c73f3:

    h "Ah... [d_name]... I think that might've been a little too much."

translate english ch04_hstudio01_fb848b09:

    x "**(Stop!!!)**"

translate english ch04_hstudio01_b47481be:

    d "**(Shit!)**"

translate english ch04_hstudio01_058667db_59:

    n "Click!"

translate english ch04_hstudio01_8e0ad4ac:

    d "Ah... I'm sorry."

translate english ch04_hstudio01_58d99f72:

    h "You both did an amazing job!!"

translate english ch04_hstudio01_0a4d6835:

    h "Just a moment."

translate english ch04_hstudio01_f49bac2f:

    h "Phew........."

translate english ch04_hstudio01_4338f07b:

    h "..........."

translate english ch04_hstudio01_82ec30ec:

    h "Umm... next..."

translate english ch04_hstudio01_feb70977:

    x "**(You little brat!!)**"

translate english ch04_hstudio01_92ee3431:

    x "**(.............)**"

translate english ch04_hstudio01_6f4f613c:

    x "**(Does he recognize me and is just pretending he doesn't?...)**"

translate english ch04_hstudio01_0d60af25_1:

    x "**(........)**"

translate english ch04_hstudio01_20e75432:

    x "**(So that's what you've been hiding behind that innocent face.)**"

translate english ch04_hstudio01_92ee3431_1:

    x "**(.............)**"

translate english ch04_hstudio01_351ad07c:

    x "**(Damn......)**"

translate english ch04_hstudio01_8b901bcc:

    h "Ah... Now we're on to the last part."

translate english ch04_hstudio01_7caf97d7:

    h "............."

translate english ch04_hstudio01_6be75948:

    h "Alright, let's move over to the sofa and get some more relaxed shots. Hehe."

translate english ch04_hstudio01_d5f9447b:

    h "You two have been working hard in this heat."

translate english ch04_hstudio01_9ff49dbc:

    h "Sorry, but could you help me move the sofa for a second?"

translate english ch04_hstudio02_2bbaaa77:

    x "**(......)**"

translate english ch04_hstudio02_4cb1efd7:

    x "**(How is he still hard??)**"

translate english ch04_hstudio02_7caf97d7:

    h "............."

translate english ch04_hstudio02_eb14108c:

    h "Sorry for making you do this too."

translate english ch04_hstudio02_757cff75:

    h "Everything came together so suddenly that I wasn't fully prepared."

translate english ch04_hstudio02_537e46ab:

    d "Haha, it's alright."

translate english ch04_hstudio02_2bd24d99:

    h "Everything used to be set up and ready to go..."

translate english ch04_hstudio02_81c45532:

    h "Haha... Too bad I don't have all that anymore."

translate english ch04_hstudio02_914f0369:

    d "Oh, really?"

translate english ch04_hstudio02_c2da4f99:

    h "Yeah. Haha, not to brag, but..."

translate english ch04_hstudio02_d0203895:

    h "Since things turned out this way..."

translate english ch04_hstudio02_07c06a61:

    h "Let me tell you a little secret..."

translate english ch04_hstudio02_92ad9932:

    h "............"

translate english ch04_hstudio02_b047d615:

    h "My studio actually used to be an adult photography studio. Haha."

translate english ch04_hstudio02_204b1c71:

    h "A place filled with bare skin and passionate moans..."

translate english ch04_hstudio02_7c0a9214:

    d ".............."

translate english ch04_hstudio02_13cfbdea:

    h "It was a more private, uninhibited space for adults... a secret hidden from the world."

translate english ch04_hstudio02_a313a823:

    h "It was a place where bare skin rubbed together, with moans and camera shutters completely drowning out everything else..."

translate english ch04_hstudio02_9edeaeed:

    h "A place where being clothed felt completely unnatural."

translate english ch04_hstudio02_b0450d16:

    d "**(Damn....)**"

translate english ch04_hstudio02_d6c51954:

    h "Men walked around with their cocks swinging freely..."

translate english ch04_hstudio02_ca3fe927:

    h "And women would openly spread their legs for everyone to see..."

translate english ch04_hstudio02_3a553aec:

    d "**(Oh my God.....)**"

translate english ch04_hstudio02_7b8aafbc:

    d "**(What kind of work did she used to do??)**"

translate english ch04_hstudio02_41a2ee99:

    d "**(Did they shoot porn here or something??)**"

translate english ch04_hstudio02_fc72e490:

    x "**(Haha, [h_name]...)**"

translate english ch04_hstudio02_6b291053:

    x "**(You really shouldn't tease the poor kid like that. Hahaha.)**"

translate english ch04_hstudio02_1990e2ac:

    h "Alright, we've got everything set up pretty close to the reference."

translate english ch04_hstudio02_6bc4cbc2:

    h "Hmm..."

translate english ch04_hstudio02_78657033:

    h "Alright, it's time for the final highlight of the shoot."

translate english ch04_hstudio02_281b51cf:

    h "We've finished the foreplay... now it's time for the real thing."

translate english ch04_hstudio02_46cce89b:

    h "[d_name], take a seat on the sofa. Madam, please stand right next to him and pose."

translate english ch04_hstudio02_3be0d584:

    d "Got it!"

translate english ch04_hstudio02_058667db:

    n "Click!"

translate english ch04_hstudio02_0187e6c0:

    h "Yes, the framing looks great."

translate english ch04_hstudio02_058667db_1:

    n "Click!"

translate english ch04_hstudio02_058667db_2:

    n "Click!"

translate english ch04_hstudio02_cbb4fa18:

    h "Madam, please stand up, and [d_name], wrap your arms around her."

translate english ch04_hstudio02_058667db_3:

    n "Click!"

translate english ch04_hstudio02_058667db_4:

    n "Click!"

translate english ch04_hstudio02_e3bc2e3d:

    h "Perfect."

translate english ch04_hstudio02_c20e88d9:

    h "I'm honestly surprised by how good you two look together!"

translate english ch04_hstudio02_96c6b80a:

    h "Age really is just a number, isn't it!"

translate english ch04_hstudio02_f6399b49:

    d "**(Exactly, [h_name]!!)**"

translate english ch04_hstudio02_08e135ac:

    d "**(So please let me fuck Madam!!!!)**"

translate english ch04_hstudio02_f04061ec:

    d "**(Please.....)**"

translate english ch04_hstudio02_090db06f:

    h "Madam, would you turn around for me?"

translate english ch04_hstudio02_058667db_5:

    n "Click!"

translate english ch04_hstudio02_e3bc2e3d_1:

    h "Perfect."

translate english ch04_hstudio02_058667db_6:

    n "Click!"

translate english ch04_hstudio02_897c3a68:

    h "Alright. Now, please take off her panties."

translate english ch04_hstudio02_8fb1035e:

    h "Take it one step at a time. Pause after each movement."

translate english ch04_hstudio02_058667db_7:

    n "Click!"

translate english ch04_hstudio02_95e48bcb:

    x "**(Phew.......)**"

translate english ch04_hstudio02_25e9e9c4:

    n "The moment he took hold of Sophia's panties, a strange thrill ran through her."

translate english ch04_hstudio02_bda4d0d5:

    n "There was zero chance that the dynamic between a university professor and her student would ever be flipped."

translate english ch04_hstudio02_f1b32f80:

    n "However, during this shoot, being controlled by a third party and exposing her naked body to her student,"

translate english ch04_hstudio02_063f17b5:

    n "and having her underwear pulled down made her feel an indescribable mix of humiliation and pleasure."

translate english ch04_hstudio02_058667db_8:

    n "Click!"

translate english ch04_hstudio02_3edd6682:

    n "It felt as though her ethical burdens were being stripped away right along with her panties."

translate english ch04_hstudio02_1678b84e:

    x "**(Hah.......)**"

translate english ch04_hstudio02_ada668e2:

    x "**(It's only [h_name] watching us... so why am I so turned on... and so embarrassed?)**"

translate english ch04_hstudio02_058667db_9:

    n "Click!"

translate english ch04_hstudio02_5abdc95e:

    h "Alright, Madam. Now, please sit on his lap."

translate english ch04_hstudio02_058667db_10:

    n "Click!"

translate english ch04_hstudio02_058667db_11:

    n "Click!"

translate english ch04_hstudio02_058667db_12:

    n "Click!"

translate english ch04_hstudio02_7fcccb31:

    d "**(Damn..)**"

translate english ch04_hstudio02_058667db_13:

    n "Click!"

translate english ch04_hstudio02_33948309:

    h "Just to be clear, don't actually put it in. Haha."

translate english ch04_hstudio02_e49db453:

    x "**(..........)**"

translate english ch04_hstudio02_781f9fd3:

    h "................"

translate english ch04_hstudio02_e8964639:

    h "Sorry. Bad joke."

translate english ch04_hstudio02_563ae502:

    d "**(No, no, no!!)**"

translate english ch04_hstudio02_aa51b9c7:

    d "**(It's okay if you do!!!)**"

translate english ch04_hstudio02_e9ea8c41:

    x "**(.........)**"

translate english ch04_hstudio02_058667db_14:

    n "Click!"

translate english ch04_hstudio02_058667db_15:

    n "Click!"

translate english ch04_hstudio02_2dcd8b29:

    x "**(Phew..........)**"

translate english ch04_hstudio02_a9dcae5c:

    x "**(Why does his penis keep twitching?.......)**"

translate english ch04_hstudio02_94fdaf49:

    h "Perfect."

translate english ch04_hstudio02_b9587492:

    h "Madam, relax and let yourself lean completely into him."

translate english ch04_hstudio02_4b9d9b5a:

    h "And [d_name], position your penis in front of her butt."

translate english ch04_hstudio02_058667db_16:

    n "Click!"

translate english ch04_hstudio02_058667db_17:

    n "Click!"

translate english ch04_hstudio02_94fdaf49_1:

    h "Perfect."

translate english ch04_hstudio02_de37d43b:

    h "Madam, turn your head and look at the camera."

translate english ch04_hstudio02_058667db_18:

    n "Click!"

translate english ch04_hstudio02_94fdaf49_2:

    h "Perfect."

translate english ch04_hstudio02_0a4aac30:

    h "That's really hot."

translate english ch04_hstudio02_5aefa9ff:

    h "You two look amazing together."

translate english ch04_hstudio02_2798c436:

    h "Alright, [d_name], lie back and make yourself comfortable."

translate english ch04_hstudio02_762433a9:

    h "And Madam, get on top of him and raise your hips a little."

translate english ch04_hstudio02_058667db_19:

    n "Click!"

translate english ch04_hstudio02_058667db_20:

    n "Click!"

translate english ch04_hstudio02_ffbd629b:

    h "**(My God......)**"

translate english ch04_hstudio02_6b52134c:

    h "**(This shot is unbelievably sexy.....)**"

translate english ch04_hstudio02_058667db_21:

    n "Click!"

translate english ch04_hstudio02_4ddc3743:

    h "**(I wonder what it'd feel like if that went inside her...)**"

translate english ch04_hstudio02_5a238b3a:

    h "**(.......)**"

translate english ch04_hstudio02_fd89a6d0:

    h "**(............)**"

translate english ch04_hstudio02_8f1775b0:

    h "**(What would it feel like....)**"

translate english ch04_hstudio02_058667db_22:

    n "Click!"

translate english ch04_hstudio02_ecb08039:

    h "Now, naturally act out everything leading up to the moment just before penetration."

translate english ch04_hstudio02_135416f4:

    h "I mean everything right up until the very last moment before it goes in."

translate english ch04_hstudio02_83261455:

    h "........."

translate english ch04_hstudio02_058667db_23:

    n "Click!"

translate english ch04_hstudio02_727604b2:

    x "**(Hah.......)**"

translate english ch04_hstudio02_77ec1c52:

    x "**(Sophia... you pathetic woman...)**"

translate english ch04_hstudio02_419cc279:

    x "**(What are you doing, making such a disgraceful pose...?)**"

translate english ch04_hstudio02_15077133:

    x "**(Hah........)**"

translate english ch04_hstudio02_08ddee37:

    x "**(Who would've thought I'd be doing this with him during summer break...)**"

translate english ch04_hstudio02_058667db_24:

    n "Click!"

translate english ch04_hstudio02_565bb37a:

    x "**(Mmm....)**"

translate english ch04_hstudio02_ac43ddec:

    x "**(.....)**"

translate english ch04_hstudio02_c8d4eb86:

    x "**(Why does being held by him turn me on so much......?)**"

translate english ch04_hstudio02_9490d9a6:

    x "**(Did I really make him this hard?)**"

translate english ch04_hstudio02_ac43ddec_1:

    x "**(.....)**"

translate english ch04_hstudio02_9e22d862:

    x "**(This brat is hard just from looking at me, a woman thirty years older than him.)**"

translate english ch04_hstudio02_058667db_25:

    n "Click!"

translate english ch04_hstudio02_058667db_26:

    n "Click!"

translate english ch04_hstudio02_64efc18a:

    x "**(Ahh.....)**"

translate english ch04_hstudio02_058667db_27:

    n "Click!"

translate english ch04_hstudio02_013e1f89:

    x "**(This should never have happened.....)**"

translate english ch04_hstudio02_ac8dea37:

    x "**(How could my own student do this to me...?)**"

translate english ch04_hstudio02_7b87c210:

    x "**(You pathetic idiot!!)**"

translate english ch04_hstudio02_058667db_28:

    n "Click!"

translate english ch04_hstudio02_e5ee7b13:

    d "**(Damn, I want to put it in!!)**"

translate english ch04_hstudio02_0bb56730:

    d "**(.....)**"

translate english ch04_hstudio02_020cd0be:

    d "**(Should I just sneak the tip in...?)**"

translate english ch04_hstudio02_0bb56730_1:

    d "**(.....)**"

translate english strings:
    old "그녀의 질에 귀두를 삽입한다."
    new "Slip just the tip inside her."

translate english ch04_hstudio02_92f21ed5:

    n ""

translate english ch04_hstudio02_e571e212:

    x "**(!!!!!!!!!!!!!!!!!!!!!!!!!!!!)**"

translate english ch04_hstudio02_058667db_29:

    n "Click!"

translate english ch04_hstudio02_02a018db:

    h "Ah... [d_name]."

translate english ch04_hstudio02_752335d2:

    h "Um..."

translate english ch04_hstudio02_6a5abdcc:

    h "That's close enough, alright?"

translate english ch04_hstudio02_c026951f:

    h "Please be careful."

translate english ch04_hstudio02_6e37994c:

    h "Don't push in any further!!"

translate english ch04_hstudio02_8d953131:

    d "O-Okay, understood!"

translate english ch04_hstudio02_058667db_30:

    n "Click!"

translate english ch04_hstudio02_727604b2_1:

    x "**(Hah.......)**"

translate english ch04_hstudio02_17609071:

    x "**(What are we all doing...?.)**"

translate english ch04_hstudio02_92ee3431:

    x "**(.............)**"

translate english ch04_hstudio02_fedfe7ae:

    x "**(Why am I moving my ass against him like a slut?...)**"

translate english ch04_hstudio02_6dc2aef3:

    d "**(Shit....)**"

translate english ch04_hstudio02_033e8adc:

    d "**(She's moving along with me too...)**"

translate english ch04_hstudio02_058667db_31:

    n "Click!"

translate english ch04_hstudio02_058667db_32:

    n "Click!"

translate english ch04_hstudio02_0411797d:

    d "**(......)**"

translate english ch04_hstudio02_ecfa2717:

    d "**(My God......)**"

translate english ch04_hstudio02_4debd8b1:

    d "**(Hah... I want to put it in... I want to put it in...)**"

translate english ch04_hstudio02_3104b575:

    d "**(Maybe I should ask if I can just put it in once... and pull it right back out.)**"

translate english ch04_hstudio02_23846981:

    d "**(Maybe they'd actually let me.)**"

translate english ch04_hstudio02_89b33729:

    h "Fantastic!!"

translate english ch04_hstudio02_63237e8a:

    h "You two, hold on a second!!"

translate english ch04_hstudio02_d292fb68:

    h "Alright, we're on the last scene now."

translate english ch04_hstudio02_7caf97d7_1:

    h "............."

translate english ch04_hstudio02_3a115fcb:

    h "Hmm..."

translate english ch04_hstudio02_3f019b1c:

    h "Madam, lie down on the sofa, and [d_name], stand up and hold her ankles."

translate english ch04_hstudio02_da58aed0:

    d "**(Shit........)**"

translate english ch04_hstudio02_f13bfa84:

    d "O-Okay!"

translate english ch04_hstudio02_40b172a9:

    x "*Phew......*"

translate english ch04_hstudio02_6c9ac422:

    x ".............."

translate english ch04_hstudio02_058667db_33:

    n "Click!"

translate english ch04_hstudio02_fe7f8544:

    d "**(Ah, damn... I'd rather just jerk off...)**"

translate english ch04_hstudio02_8e4a6778:

    d "**(This is torture... pure torture!!)**"

translate english ch04_hstudio02_936ea5e4:

    d "**(.............)**"

translate english ch04_hstudio02_60198213:

    d "**(Look at her...)**"

translate english ch04_hstudio02_c442b7f4:

    d "**(She's basically asking for it.)**"

translate english ch04_hstudio02_936ea5e4_1:

    d "**(.............)**"

translate english ch04_hstudio02_acefe43c:

    d "**(At her age, she's probably done plenty of shoots that ended in actual sex... right?)**"

translate english ch04_hstudio02_058667db_34:

    n "Click!"

translate english ch04_hstudio02_041ef0ba:

    d "**(If she does this kind of work, maybe she's even been in adult films?)**"

translate english ch04_hstudio02_936ea5e4_2:

    d "**(.............)**"

translate english ch04_hstudio02_8f503645:

    d "**(Hah... How am I supposed to convince her??)**"

translate english ch04_hstudio02_fb4342b7:

    d "**(..........)**"

translate english ch04_hstudio02_1e3b1bbc:

    d "**(Or should I just do it?)**"

translate english ch04_hstudio02_058667db_35:

    n "Click!"

translate english ch04_hstudio02_4a38ba34:

    d "**(Would [h_name] allow it?)**"

translate english ch04_hstudio02_ab5b5082:

    h "Now spread her legs for me."

translate english ch04_hstudio02_058667db_36:

    n "Click!"

translate english ch04_hstudio02_86af3834:

    x "Ahh.........."

translate english ch04_hstudio02_caf396f4:

    d "**(Look at her....)**"

translate english ch04_hstudio02_4abba861:

    d "**(Even if it's just a shoot, she's leaving herself wide open....)**"

translate english ch04_hstudio02_936ea5e4_3:

    d "**(.............)**"

translate english ch04_hstudio02_97e833b7:

    d "**(She wants this to be real too.)**"

translate english ch04_hstudio02_058667db_37:

    n "Click!"

translate english ch04_hstudio02_4720b7e2:

    d "**(W-What if [h_name] secretly wants me to stop pretending and actually do it?)**"

translate english ch04_hstudio02_4f52b0b1:

    d "**(............)**"

translate english ch04_hstudio02_49588ad8:

    d "**(Maybe... she'd just go along with it if I just do it???)**"

translate english ch04_hstudio02_65553c54:

    d "**(Hah... Damn!!!!)**"

translate english ch04_hstudio02_f90f80af:

    d "**(When was the last time I had sex?)**"

translate english ch04_hstudio02_86af3834_1:

    x "Ahh.........."

translate english ch04_hstudio02_81eaf9bd:

    x "**(Look at me….)**"

translate english ch04_hstudio02_e2ad6643:

    x "**(Who'd ever believe I'm a university professor?..)**"

translate english ch04_hstudio02_058667db_38:

    n "Click!"

translate english ch04_hstudio02_058667db_39:

    n "Click!"

translate english ch04_hstudio02_44659093:

    x "**(Hah..........)**"

translate english ch04_hstudio02_9e4437a5:

    x "**(When was the last time I had sex?.....)**"

translate english ch04_hstudio02_8e593ff9:

    x "**(............)**"

translate english ch04_hstudio02_0546b20d:

    x "**(My God, Sophia.....)**"

translate english ch04_hstudio02_9d77f73a:

    x "**(Have I really been living like a sexless housewife all this time....?)**"

translate english ch04_hstudio02_2cf566f8:

    d "**(My God....)**"

translate english ch04_hstudio02_18f1e7e2:

    d "**(She's enjoying this..)**"

translate english ch04_hstudio02_058667db_40:

    n "Click!"

translate english ch04_hstudio02_e8354a9b:

    d "**(Just rubbing against her like this is driving me crazy....)**"

translate english ch04_hstudio02_cec2df53:

    d "**(Hah........)**"

translate english ch04_hstudio02_8a3d0b5e:

    d "**(I want to put it in!! I want to put it in!! I want to put it in!!)**"

translate english ch04_hstudio02_936ea5e4_4:

    d "**(.............)**"

translate english ch04_hstudio02_508c3ab5:

    d "**(Alright... I'll just slip it in and pretend it was an accident.)**"

translate english ch04_hstudio02_fd8a2467:

    d "**(I'll deal with the consequences later!!)**"

translate english ch04_hstudio02_24bb78fc:

    h "Now, [d_name], move in a little closer to her."

translate english ch04_hstudio02_5dbd1a2f:

    h "Then slowly rock your hips back and forth as if you were about to penetrate her."

translate english ch04_hstudio02_a7e14b3d:

    d "O-Okay."

translate english ch04_hstudio02_73fcc152:

    x "Hah......."

translate english ch04_hstudio02_058667db_41:

    n "Click!"

translate english ch04_hstudio02_1680f6da:

    d "**(Wait, shit... maybe that's a bad idea?)**"

translate english ch04_hstudio02_1f7fe053:

    d "**(Would that be a complete disaster??)**"

translate english ch04_hstudio02_09d9fa60:

    d "**(What if I get busted for doing it without asking??)**"

translate english ch04_hstudio02_058667db_42:

    n "Click!"

translate english ch04_hstudio02_78a8e21e:

    x "**(!!!!!!!!!)**"

translate english ch04_hstudio02_8aaf9f7a:

    n "It started out as acting, but her mind was already completely scrambled by [d_name]."

translate english ch04_hstudio02_058667db_43:

    n "Click!"

translate english ch04_hstudio02_cb7097ad:

    n "Under the environment [h_name] had orchestrated, she found herself unable to react to anything [d_name] did."

translate english ch04_hstudio02_332c90a1:

    x "**(Oh my God, [h_name]!!)**"

translate english ch04_hstudio02_6d223e68:

    x "**(I had no idea the shoot would go this far....)**"

translate english ch04_hstudio02_54929e0e:

    x "**(Oh, [h_name]......)**"

translate english ch04_hstudio02_058667db_44:

    n "Click!"

translate english ch04_hstudio02_7efe60eb:

    d "**(I can feel it!! I can actually feel it.....)**"

translate english ch04_hstudio02_dea66687:

    d "**(It's so wet and slippery....)**"

translate english ch04_hstudio02_71b75a09:

    d "**(Shit!!)**"

translate english ch04_hstudio02_058667db_45:

    n "Click!"

translate english ch04_hstudio02_f127a714:

    x "**(Oh my God, [d_name].....)**"

translate english ch04_hstudio02_5009bec6:

    x "**(Oh dear.....)**"

translate english ch04_hstudio02_6ad1b55a:

    x "**(You're actually enjoying this, aren't you?)**"

translate english ch04_hstudio02_d125d2fa:

    x "**(Getting hard while rubbing against your own professor?!!)**"

translate english ch04_hstudio02_3fa893c0:

    x "**(I was just giving you a lecture the other day, you little brat..)**"

translate english ch04_hstudio02_058667db_46:

    n "Click!"

translate english ch04_hstudio02_095116d2:

    d "**(I'm going out of my mind.......)**"

translate english ch04_hstudio02_a0cf64c3:

    d "**(This is fucking torture for me.....)**"

translate english strings:
    old "그녀의 보지에 귀두를 비빈다."
    new "Rub the glans against her pussy."

translate english ch04_hstudio02_92f21ed5_1:

    n ""

translate english ch04_hstudio02_058667db_47:

    n "Click!"

translate english ch04_hstudio02_78a8e21e_1:

    x "**(!!!!!!!!!)**"

translate english ch04_hstudio02_058667db_48:

    n "Click!"

translate english ch04_hstudio02_058667db_49:

    n "Click!"

translate english ch04_hstudio02_0cfb9302:

    x "Mmm...."

translate english ch04_hstudio02_339da0c7:

    x "Ah........"

translate english ch04_hstudio02_30b27b0a:

    h "**(!!!!!!!!!!!!!!!!)**"

translate english ch04_hstudio02_058667db_50:

    n "Click!"

translate english ch04_hstudio02_a01f4f46:

    h ".........."

translate english ch04_hstudio02_75188300:

    x "**(Oh my God, [h_name]....)**"

translate english ch04_hstudio02_4f812d5f:

    x "**(You're really not going to stop this??)**"

translate english ch04_hstudio02_7564a668:

    x "**(What are you doing?!!)**"

translate english ch04_hstudio02_969bef8c:

    d "**(Ah.............)**"

translate english ch04_hstudio02_058667db_51:

    n "Click!"

translate english ch04_hstudio02_53772d84:

    h "**(What's wrong with the camera?)**"

translate english ch04_hstudio02_c6e06337:

    n "He clung to the last shred of his self-control, torn by indecision."

translate english ch04_hstudio02_b60bd713:

    n "As he repeatedly rubbed his cock against her entrance, he kept watching for any reaction."

translate english ch04_hstudio02_058667db_52:

    n "Click!"

translate english ch04_hstudio02_65a6ddb9:

    h "**(Is the SD card acting up again?)**"

translate english ch04_hstudio02_2ee1e1d0:

    n "Having her student rub right against her pussy like that made her humiliation hit an all-time high."

translate english ch04_hstudio02_15077133_1:

    x "**(Hah........)**"

translate english ch04_hstudio02_607fda93:

    x "**(I don't even know what's happening anymore.......)**"

translate english ch04_hstudio02_f77cf934:

    x "**(Am I under some kind of spell......?)**"

translate english ch04_hstudio02_058667db_53:

    n "Click!"

translate english ch04_hstudio02_45f8715f:

    n "It was unlike anything she had ever experienced before."

translate english ch04_hstudio02_15077133_2:

    x "**(Hah........)**"

translate english ch04_hstudio02_f127a714_1:

    x "**(Oh my God, [d_name].....)**"

translate english ch04_hstudio02_cfd39cd2:

    x "**(What are you trying to do...?)**"

translate english ch04_hstudio02_2225a219:

    n "She'd slept with a few men over the course of her life,"

translate english ch04_hstudio02_32b22adc:

    n "but she had never rubbed herself against a guy younger than her own son."

translate english ch04_hstudio02_058667db_54:

    n "Click!"

translate english ch04_hstudio02_fa732ee8:

    h "G-Great job, [d_name]."

translate english ch04_hstudio02_8e44d9cb:

    h "........"

translate english ch04_hstudio02_ca09423c:

    h "Ah, you two, hold on a second."

translate english ch04_hstudio02_4338f07b:

    h "..........."

translate english ch04_hstudio02_8608c1b6:

    h "Something's wrong with the camera. Would you mind taking a short break?"

translate english ch04_hstudio02_4ec837b4:

    h "Sorry..."

translate english ch04_hstudio02_31375fe7:

    n "Both Sophia and [d_name] heard what [h_name] had just said."

translate english ch04_hstudio02_139b8b05:

    n "But [d_name] was far too aroused to stop himself."

translate english ch04_hstudio02_fa8babfd:

    d "Hah....."

translate english ch04_hstudio02_0cfb9302_1:

    x "Mmm...."

translate english strings:
    old "그녀의 보지에 삽입한다."
    new "Slide your cock inside her pussy."

translate english ch04_hstudio02_92f21ed5_2:

    n ""

translate english ch04_hstudio02_e9ea8c41_1:

    x "**(.........)**"

translate english ch04_hstudio02_1fda55a6:

    x "**(Wait, what...? Is he pushing inside me...?)**"

translate english ch04_hstudio02_b90e2845:

    x "**(What?!!!!!!!)**"

translate english ch04_hstudio02_852b2d19:

    x "**(Is this brat actually trying to slide it in??!!!!!)**"

translate english ch04_hstudio02_4d2705e2:

    x "**(He is!! He's really pushing it in!!!)**"

translate english ch04_hstudio02_2f5b9d46:

    x "!!!!!!!!!!"

translate english ch04_hstudio02_ca69caa4:

    x "W-Wait!!!!!"

translate english ch04_hstudio02_2f5b9d46_1:

    x "!!!!!!!!!!"

translate english ch04_hstudio02_0172d4c7:

    d "Ah, damn...it's slipping in!!!"

translate english ch04_hstudio02_d82f1dab:

    x "What?!!!"

translate english ch04_hstudio02_faab4c0a:

    x "Hey!!!"

translate english ch04_hstudio02_13b9c1d1:

    x "What the hell are you doing?!!!!!"

translate english ch04_hstudio02_fc33a5b4:

    d "Ah!!!!!!!!"

translate english ch04_hstudio02_43650ce5:

    h "Huh?"

translate english ch04_hstudio02_12ddc04b:

    d "Ah!!!!!!!!!!"

translate english ch04_hstudio02_a85e86da:

    h "!!!!!!!!!!!!!!!!!"

translate english ch04_hstudio02_d4105e07:

    d "Ah.................."

translate english ch04_hstudio02_beedca2d:

    d "**(I'm..)**"

translate english ch04_hstudio02_64a5c3b8:

    d "**(I'm so...)**"

translate english ch04_hstudio02_c82f5c3d:

    d "**(I'm so fucked........)**"

translate english ch04_hstudio02_a0b933a9:

    d "**(Damn...........)**"

translate english ch04_hstudio02_2490b6bb:

    d "**(........)**"

translate english ch04_hstudio02_c74103e5:

    d "**(What the hell have I done....?)**"

translate english ch04_hstudio02_00f066ea:

    h "......."

translate english ch04_hstudio02_1f129e5c:

    d "I'm sorry...."

translate english ch04_hstudio02_83448492:

    h "No."

translate english ch04_hstudio02_9d02d18b:

    h "It's okay....."

translate english ch04_hstudio02_1db87ab6:

    h "I'm sorry, Madam..."

translate english ch04_hstudio02_e75be884:

    h "Are you alright?"

translate english ch04_hstudio02_b6ed977e:

    x "I'm fine."

translate english ch04_hstudio02_586abce7:

    x "Go worry about your boyfriend instead. Haha."

translate english ch04_hstudio02_b702562e:

    d "......................."

translate english ch04_hstudio02_fc67ec75:

    d "I'm sorry, Madam....."

translate english ch04_hstudio02_485dcbff:

    d "I'm sorry, [h_name]..."

translate english ch04_hstudio02_5551fbe8:

    h "It's alright."

translate english ch04_hstudio02_cf3486f0:

    h "The shoot's over now, so don't worry about it."

translate english ch04_hstudio02_88863bbb:

    h "....................."

translate english ch04_hstudio02_8e44d9cb_1:

    h "........"

translate english ch04_hstudio02_e3c92b81:

    d "!!!!!!!!!!!"

translate english ch04_hstudio02_eb9ce0b4:

    d "I'll clean it up!!!!"

translate english ch04_hstudio02_1271c61f:

    h "Ah! You startled me..."

translate english ch04_hstudio02_b61e37b6:

    h "O-Okay."

translate english ch04_hstudio02_6c9ac422_1:

    x ".............."

translate english ch04_hstudio02_3f41e9ad:

    x "**(My God......)**"

translate english ch04_hstudio02_34defc7a:

    x "**(How is he still rock hard?........)**"

translate english ch04_hstudio02_6f368ede:

    h "**(.....................)**"

translate english ch04_hstudio02_0c59361e:

    h "**(Oh my God, [d_name]....)**"

translate english ch04_hstudio02_d55658c6:

    x "**(......................)**"

translate english ch04_hstudio02_73c476f6:

    h "**(.............)**"

translate english ch04_hcar01_1a93e69d:

    n "[h_name] was on the phone with Sophia."

translate english ch04_hcar01_e5651fbd:

    n "Wanting their conversation to remain private, she chose not to use her car's hands-free system."

translate english ch04_hcar01_6f77b5f4:

    h "Haha, alright, Madam."

translate english ch04_hcar01_c97d2b75:

    h "I'll do that. Anyway, thank you so much for today."

translate english ch04_hcar01_00f066ea:

    h "......."

translate english ch04_hcar01_781f9fd3:

    h "................"

translate english ch04_hcar01_c729f697:

    h "I'll be sure to pass that along to my boyfriend too."

translate english ch04_hcar01_fcc4f1e2:

    d "**(Boyfriend??)**"

translate english ch04_hcar01_2e9c6444:

    d "**(.......)**"

translate english ch04_hcar01_6ef10134:

    d "**(Since when did she have a boyfriend??)**"

translate english ch04_hcar01_cccf54d1:

    h "Sounds good."

translate english ch04_hcar01_fe1f78a1:

    h "How about we have dinner at my place next weekend?"

translate english ch04_hcar01_7caf97d7:

    h "............."

translate english ch04_hcar01_54dfc040:

    h "Haha, sounds great. I'll see you next weekend."

translate english ch04_hcar01_6cea0db2:

    h "Talk to you later."

translate english ch04_hcar01_3f0d2f87:

    h "I'll give you a call."

translate english ch04_hcar01_0f4e2e05:

    d "Um..."

translate english ch04_hcar01_083e1942:

    d "Isn't she angry because of what I did?"

translate english ch04_hcar01_203cc60b:

    d "......."

translate english ch04_hcar01_f0768f32:

    h "..............."

translate english ch04_hcar01_494539f8:

    h "She's not angry."

translate english ch04_hcar01_d5a1a798:

    h "She was just a little surprised."

translate english ch04_hcar01_888485e8:

    h "She's a seasoned professional who's seen it all."

translate english ch04_hcar01_02eb3b00:

    h "What happened earlier doesn't really bother her."

translate english ch04_hcar01_dee56e13:

    d "That's a relief..."

translate english ch04_hcar01_485f778b:

    d "Phew......."

translate english ch04_hcar01_203cc60b_1:

    d "......."

translate english ch04_hcar01_819bbb88:

    d "I can't believe I actually came right then... God..."

translate english ch04_hcar01_e5c36b54:

    d "..........."

translate english ch04_hcar01_b5a23ce9:

    d "I guess I'm hopeless."

translate english ch04_hcar01_2c4f06ef:

    h "................."

translate english ch04_hcar01_1ad5dd6d:

    h "If anything, I feel like I owe both you and Madam an apology..."

translate english ch04_hcar01_781f9fd3_1:

    h "................"

translate english ch04_hcar01_60ef75f5:

    h "I was the one who asked too much of you in the first place, [d_name]..."

translate english ch04_hcar01_a605bb43:

    h "My God... what was I thinking?"

translate english ch04_hcar01_77673f80:

    d "........."

translate english ch04_hcar01_13604e55:

    h "I should've kept the shoot under control..."

translate english ch04_hcar01_6d3d88ef:

    h "Instead, I got completely caught up in the moment..."

translate english ch04_hcar01_06ca3dad:

    h "Before I knew it, I was just standing there pressing the shutter..."

translate english ch04_hcar01_fac8215b:

    d "............"

translate english ch04_hcar01_81624349:

    d "No..."

translate english ch04_hcar01_244eb075:

    d "I was the idiot."

translate english ch04_hcar01_7c0a9214:

    d ".............."

translate english ch04_hcar01_7d5e62a2:

    d "I can't believe I actually came at that moment... God..."

translate english ch04_hcar01_76997a14:

    d "And..."

translate english strings:
    old "무슨 일이 있었는지 실토한다."
    new "Tell her what really happened."

translate english strings:
    old "아무말도 하지 않는다."
    new "Say nothing."

translate english ch04_hcar01_77673f80_1:

    d "........."

translate english ch04_hcar01_cb93c559:

    d "The truth is..."

translate english ch04_hcar01_4cd15d58:

    d "....."

translate english ch04_hcar01_b1fbc38f:

    d "I was actually trying to penetrate Madam..."

translate english ch04_hcar01_2c4f06ef_1:

    h "................."

translate english ch04_hcar01_a318dd94:

    d "You know..."

translate english ch04_hcar01_edbb7d05:

    d "........"

translate english ch04_hcar01_187ea0d2:

    d "I got so worked up rubbing against her that I..."

translate english ch04_hcar01_a797f6ce:

    d "............."

translate english ch04_hcar01_ec2a5d03:

    d "I almost came inside her by accident..."

translate english ch04_hcar01_3f9a24db:

    h ".................."

translate english ch04_hcar01_335baa5e:

    d "......................"

translate english ch04_hcar01_21cb352e:

    d "Um..."

translate english ch04_hcar01_80be3578:

    d "Do you think I should see a doctor?"

translate english ch04_hcar01_f507b5d9:

    h "What?!!"

translate english ch04_hcar01_270b7925:

    h "Haha. A doctor? Don't be silly."

translate english ch04_hcar01_ff88bfb4:

    h "Why would you think that..."

translate english ch04_hcar01_8e44d9cb:

    h "........"

translate english ch04_hcar01_1d65689a:

    h "Busting a nut is perfectly natural for a guy. Don't worry about it."

translate english ch04_hcar01_717238d4:

    d "You think so?......"

translate english ch04_hcar01_e5c36b54_1:

    d "..........."

translate english ch04_hcar01_dee1d1bf:

    d "No... but still... I-I didn't even penetrate her, so how did I..."

translate english ch04_hcar01_4338f07b:

    h "..........."

translate english ch04_hcar01_3a115fcb:

    h "Hmm..."

translate english ch04_hcar01_f6757e06:

    h "Well..."

translate english ch04_hcar01_8ac71e62:

    h "You don't actually have to penetrate someone to..."

translate english ch04_hcar01_27fdc027:

    h "Don't worry about it."

translate english ch04_hcar01_f5b2107c:

    h "You were probably just overwhelmed and nervous."

translate english ch04_hcar01_8fcb4640:

    h "And, um..."

translate english ch04_hcar01_7caf97d7_1:

    h "............."

translate english ch04_hcar01_6c0f8f56:

    h "I've heard it's pretty common for younger guys to have trouble controlling themselves."

translate english ch04_hcar01_2c7276d3:

    h "You know..."

translate english ch04_hcar01_49bc1c81:

    h "Everything feels so much more intense when you're young..."

translate english ch04_hcar01_7caf97d7_2:

    h "............."

translate english ch04_hcar01_c98b790e:

    h "So don't beat yourself up over it."

translate english ch04_hcar01_e1ff151f:

    d "..................."

translate english ch04_hcar01_b1ab1d89:

    d "Actually... the same thing happened the first time I was with my girlfriend..."

translate english ch04_hcar01_7f98bce4:

    d "Hah........"

translate english ch04_hcar01_c7e0d06f:

    d "You have no idea how much that crushes a guy's pride, Landlady..."

translate english ch04_hcar01_f0768f32_1:

    h "..............."

translate english ch04_hcar01_4b5f6ecd:

    h "You've got everything going for you, so you don't have to worry."

translate english ch04_hcar01_5e3aec4e:

    d ".........."

translate english ch04_hcar01_a2a59bf7:

    d "What do you mean?"

translate english ch04_hcar01_3ed3f0c7:

    h "Ah... well..."

translate english ch04_hcar01_61511cc0:

    h "What I meant was..."

translate english ch04_hcar01_983552d4:

    h "**(Hmm.......)**"

translate english ch04_hcar01_0e1fcd3e:

    h "**(Is he seriously asking because he doesn't know?.....)**"

translate english ch04_hcar01_1c804464:

    h "You're perfectly healthy. Once you get a little more experience, you'll be amazing in bed. Hehe."

translate english ch04_hcar01_cc82c9a7:

    h "Ah... I don't mean you should force yourself to go looking for experience."

translate english ch04_hcar01_781f9fd3_2:

    h "................"

translate english ch04_hcar01_4fe4e122:

    h "You know what I mean, right?"

translate english ch04_hcar01_86825692:

    h "I'm just saying there's no reason to feel ashamed."

translate english ch04_hcar01_0112e406:

    d "Thank you... I really appreciate you saying that."

translate english ch04_hcar01_a9861e1d:

    d "...................."

translate english ch04_hcar01_898def38:

    d "The truth is..."

translate english ch04_hcar01_da1fbbda:

    d "I don't really have much experience..."

translate english ch04_hcar01_6a21657e:

    d "..............."

translate english ch04_hcar01_34624160:

    d "Like I mentioned when we had dinner the other day..."

translate english ch04_hcar01_e37c1f8d:

    d "I have somewhat unconventional tastes when it comes to women."

translate english ch04_hcar01_2eabd647:

    h "What do you mean by unconventional?"

translate english ch04_hcar01_af3181c4:

    h "......"

translate english ch04_hcar01_203cc60b_2:

    d "......."

translate english ch04_hcar01_a7bc21aa:

    d "I'm attracted to women who are older than I am."

translate english ch04_hcar01_781f9fd3_3:

    h "................"

translate english strings:
    old "[h_name]의 나이대 여성이 좋아요....."
    new "I like women around your age, [h_name]..."

translate english strings:
    old "중년의 여성이 좋아요."
    new "I like middle-aged women."

translate english ch04_hcar01_cbdbf568:

    d "I like women around your age, [h_name]..."

translate english ch04_hcar01_cf0101e3:

    d "I like middle-aged women."

translate english ch04_hcar01_f0768f32_2:

    h "..............."

translate english ch04_hcar01_c6f725e8:

    d "That's why I could never get into girls my own age all through college..."

translate english ch04_hcar01_ca78a776:

    d "How should I put it..."

translate english ch04_hcar01_0217fed5:

    d "They just seemed too childish..."

translate english ch04_hcar01_e5be7f52:

    d "Always giggling, hanging out in groups, fooling around..."

translate english ch04_hcar01_10c6e7a8:

    d "Instead, I found myself drawn to female professors in their thirties and forties..."

translate english ch04_hcar01_edbb7d05_1:

    d "........"

translate english ch04_hcar01_e5117f40:

    d "There were a few in their fifties, too."

translate english ch04_hcar01_8f04e27e:

    d "Come to think of it..."

translate english ch04_hcar01_2d5083e8:

    d "Women like Madam from today's shoot..."

translate english ch04_hcar01_e23d1431:

    d "Women who feel like they'd accept me for who I am..."

translate english ch04_hcar01_edbb7d05_2:

    d "........"

translate english ch04_hcar01_64b7c287:

    d "Women who are mature instead of childish..."

translate english ch04_hcar01_dfe4ba48:

    d "Well... to be more accurate, I do like women my own age too..."

translate english ch04_hcar01_0c760312:

    d "It's just..."

translate english ch04_hcar01_e4922ffa:

    d "I don't know..."

translate english ch04_hcar01_86fc3997:

    d "Now it just sounds like I'm into every woman out there. Hahaha."

translate english ch04_hcar01_223a11e8:

    d "I'm not explaining this very well..."

translate english ch04_hcar01_30eeb7be:

    h "I see...."

translate english ch04_hcar01_d362917b:

    h "There's nothing strange about that. So why do you look so down? Haha."

translate english ch04_hcar01_9b218503:

    h "You're only a college freshman. Don't worry so much about it."

translate english ch04_hcar01_a01f4f46:

    h ".........."

translate english ch04_hcar01_63155b77:

    h "There are plenty of women in this world."

translate english ch04_hcar01_a423d9eb:

    h "As you meet more people, you'll naturally figure out what kind of woman you're really attracted to, [d_name]."

translate english ch04_hcar01_71fef804:

    h "I'm not saying you should date recklessly, of course..."

translate english ch04_hcar01_cc744f50:

    h "Hmm..."

translate english ch04_hcar01_00bf545b:

    h "You have plenty of time ahead of you, so you'll get to know yourself little by little. Hehe."

translate english ch04_hcar01_ad893dfa:

    d "......"

translate english ch04_hcar01_cb279da9:

    d "I guess you're right...."

translate english ch04_hcar01_19b5a46f:

    h "If we stay here any longer, I think I'm going to fall asleep."

translate english ch04_hcar01_56c4a3c1:

    h "Come on, let's head home."

translate english ch04_hhouse01_6ed45f7a:

    h "Ah... there's no place like home."

translate english ch04_hhouse01_8f318c73:

    h "Well... I guess half of it still belongs to the bank."

translate english ch04_hhouse01_729fcf2d:

    h "Feels like I haven't been home in forever. Haha."

translate english ch04_hhouse01_79259c23:

    h "Ah... this is so comfortable........."

translate english ch04_hhouse01_4338f07b:

    h "..........."

translate english ch04_hhouse01_70c02c46:

    h "Hey, [d_name]..."

translate english ch04_hhouse01_8096b08a:

    d "Yeah?"

translate english ch04_hhouse01_91017e31:

    h "Could you undress me? Hahaha."

translate english ch04_hhouse01_3b84a8ae:

    d "Huh??!!!"

translate english ch04_hhouse01_a47d07a5:

    d "Hahaha."

translate english ch04_hhouse01_77673f80:

    d "........."

translate english ch04_hhouse01_7c0a9214:

    d ".............."

translate english ch04_hhouse01_1dffbb2f:

    h "You're probably exhausted too. Have a seat."

translate english ch04_hhouse01_3a321faa:

    d "Ah, okay."

translate english ch04_hhouse01_7e7a46a5:

    h "Are you just going to stand there staring at my body?"

translate english ch04_hhouse01_6f4dc862:

    d "Ah... I got lost in thought for a second..."

translate english ch04_hhouse01_7c0a9214_1:

    d ".............."

translate english ch04_hhouse01_23698b43:

    n "An awkward silence settled between them."

translate english ch04_hhouse01_6abd0a27:

    n "The two of them had definitely grown closer than they were yesterday."

translate english ch04_hhouse01_961ac6ef:

    n "They were more comfortable around each other now."

translate english ch04_hhouse01_3e55da63:

    n "And yet, somehow, the awkwardness between them had grown even stronger than the day they first met."

translate english ch04_hhouse01_7aec317d:

    d "Would you like a glass of water?"

translate english ch04_hhouse01_469fbe12:

    h "Thanks. Hehe."

translate english ch04_hhouse01_179f7e66:

    n "The reason was..."

translate english ch04_hhouse01_95872e1d:

    n "[h_name] had begun to see him as a real man."

translate english ch04_hhouse01_bdf0126f:

    n "And for the first time, she had begun to rely on [d_name] emotionally."

translate english ch04_hhouse01_6b035ceb:

    d "Here, have some water."

translate english ch04_hhouse01_469fbe12_1:

    h "Thank you. Hehe."

translate english ch04_hhouse01_b597d4b4:

    d "You must be tired, so get some rest."

translate english ch04_hhouse01_d9648451:

    d "I'm going upstairs."

translate english ch04_hhouse01_56c9cd99:

    h "You sure?"

translate english ch04_hhouse01_f0980a4f:

    h "Alright then. Get some rest."

translate english ch04_hhouse01_06fea90e:

    h "Oh, [d_name]."

translate english ch04_hhouse01_9f384fb4:

    d "Yeah?"

translate english ch04_hhouse01_203cc60b:

    d "......."

translate english ch04_hhouse01_5a93bf78:

    d "Do you need something?"

translate english ch04_hhouse01_4338f07b_1:

    h "..........."

translate english ch04_hhouse01_edbb7d05:

    d "........"

translate english ch04_hhouse01_a73d951b:

    h "Would you like to make dinner tonight?"

translate english ch04_hhouse01_8096b08a_1:

    d "Huh?"

translate english ch04_hhouse01_ea1bc054:

    d "Dinner?"

translate english ch04_hhouse01_58d2683e:

    h "Yeah."

translate english ch04_hhouse01_b1c3d589:

    h "I'd like to try something you cooked. Hehe."

translate english ch04_hhouse01_a24ad316:

    d "Haha, sure."

translate english ch04_hhouse01_e29d52fe:

    d "But if my cooking poisons you, don't blame me."

translate english ch04_hhouse01_97d62969:

    h "Hahaha. Deal."

translate english ch04_hhouse01_0724cf7a:

    h "Then let's make it together later."

translate english ch04_hhouse01_706198ba:

    d "Sounds good. Hahaha."

translate english ch04_hhouse01_9e476796:

    d "I'll make sure to get in your way."

translate english ch04_hhouse01_35c6abf3:

    n "The two of them prepared dinner together in the kitchen on the first floor."

translate english ch04_hhouse01_0c2dc3e1:

    n "Without realizing it, she found herself spending more and more time downstairs."

translate english ch04_hhouse01_f087469c:

    n "When she had lived here alone, she rarely spent time on the first floor, where her husband had usually stayed."

translate english ch04_hhouse01_b5e907d8:

    n "But after [d_name] moved in, the space she naturally occupied within the house gradually grew."

translate english ch04_hhouse01_3a9c0b92:

    d "**(She's dressed casually again...)**"

translate english ch04_hhouse01_d3bb01a2:

    d "**(My God..)**"

translate english ch04_hhouse01_0411797d:

    d "**(......)**"

translate english ch04_hhouse01_45b27b5e:

    d "**(I want to make [h_name] mine...)**"

translate english ch04_hhouse01_e5c36b54:

    d "..........."

translate english ch04_hhouse01_3fca0b77:

    d "**(She's such a tease....)**"

translate english ch04_hhouse01_ad893dfa:

    d "......"

translate english ch04_hhouse01_5b392218:

    d "**(Sometimes she feels like an older sister... sometimes a friend... sometimes even a mother...)**"

translate english ch04_hhouse01_cec2df53:

    d "**(Hah........)**"

translate english ch04_hhouse01_590cc210:

    d "**(I want to hold her...)**"

translate english ch04_hhouse01_4f52b0b1:

    d "**(............)**"

translate english ch04_hhouse01_401c62d3:

    d "**(I want her to be mine...)**"

translate english ch04_hhouse01_7e2d8ad2:

    d "**(I want to be the man she loves.....)**"

translate english ch04_hhouse01_2490b6bb:

    d "**(........)**"

translate english ch04_hhouse01_b1043688:

    d "**(I want to be a man she can be proud of...)**"

translate english ch04_hhouse01_781c1b4c:

    d "**(Would this be what it'd feel like if I married her?.....)**"

translate english ch04_hhouse01_203cc60b_1:

    d "......."

translate english ch04_hhouse01_a3b623d0:

    d "**(She'd welcome me home... cook for me every day....)**"

translate english ch04_hhouse01_ae2c4be6:

    d "**(We'd have sex all over the house every single day...)**"

translate english ch04_hhouse01_2e9c6444:

    d "**(.......)**"

translate english ch04_hhouse01_78dedb16:

    d "**(I wonder how she sees me right now...)**"

translate english ch04_hhouse01_d984260e:

    d "**(Does she still think of me as just some kid?)**"

translate english ch04_hhouse01_3c7a7f55:

    d "**(...........)**"

translate english ch04_hhouse01_2c82eeaa:

    d "**(Does any part of her see me as a man?......)**"

translate english ch04_hhouse01_c0cbe941:

    h "Hehe..."

translate english ch04_hhouse01_0e508a9d:

    h "We're almost done."

translate english ch04_hhouse01_53187b91:

    h "Alright, let's dig in."

translate english ch04_hhouse01_37d8feb4:

    h "After getting through that intense shoot today, I'm starving. Hahaha."

translate english ch04_hhouse01_6780f0f2:

    h "You're hungry too, aren't you, [d_name]?"

translate english ch04_hhouse01_5b541c30:

    d "Yeah, I'm starving. Hahaha."

translate english ch04_hhouse01_6b51217e:

    d "Let's eat."

translate english ch04_hhouse01_fa4f038a:

    h "I guess cooking for you is bringing out the woman in me again."

translate english ch04_hhouse01_a9f8f31b:

    d "Haha. Really?"

translate english ch04_hhouse01_3ed5d244:

    h "Back when I was living with my husband and the kids, I hated cooking..."

translate english ch04_hhouse01_be9deb26:

    h "But now I'm actually enjoying it again."

translate english ch04_hhouse01_99128740:

    d "Thanks for the meal."

translate english ch04_hhouse01_19164b4a:

    h "Haha, thanks for the meal."

translate english ch04_hhouse01_820d49eb:

    h "Enjoy."

translate english ch04_hhouse01_bb04f1d4:

    h "Sorry I worked you so hard today."

translate english ch04_hhouse01_23e92537:

    d "Haha, it's okay."

translate english ch04_hhouse01_d6b484b5:

    d "By the way..."

translate english ch04_hhouse01_6c9678a8:

    d "What happens to those photos now?"

translate english ch04_hhouse01_c516f946:

    h "Hmm... First, I'll go through all of them myself and narrow them down."

translate english ch04_hhouse01_d03004ca:

    h "I'll remove the ones with awkward expressions, funny poses, or blurry shots."

translate english ch04_hhouse01_1e0a33f1:

    h "After that, I'll organize them by category and send them to the client."

translate english ch04_hhouse01_91e4e341:

    h "Then they'll make the final selections and publish them in the magazine and on their website."

translate english ch04_hhouse01_32310c96:

    d "I see..."

translate english ch04_hhouse01_8d2aa1d3:

    d "So how does the payment work?"

translate english ch04_hhouse01_d67a84b0:

    d "It's not like I need the money right away. I'm just curious."

translate english ch04_hhouse01_43860803:

    h "It depends on how many platforms they're published on,"

translate english ch04_hhouse01_cf585392:

    h "but this shoot will appear both online and in the magazine, so the models are getting paid pretty well."

translate english ch04_hhouse01_6249a46b:

    d "So... are Madam's older photos on the website too?"

translate english ch04_hhouse01_e84bdc13:

    h "Yep, that's right."

translate english ch04_hhouse01_5e3aec4e:

    d ".........."

translate english ch04_hhouse01_05ade0a0:

    d "Um... then..."

translate english ch04_hhouse01_a1e566b5:

    d "Does that mean Madam is actually... an adult star who does live-action sex scenes?"

translate english ch04_hhouse01_ec406827:

    h "Hahaha. Madam's actually a pretty popular model. She even has her own fan club."

translate english ch04_hhouse01_f89f7c02:

    h "She doesn't do that kind of work, and today was actually her first time posing completely naked."

translate english ch04_hhouse01_687752d9:

    h "There are tons of male models who want to work with her."

translate english ch04_hhouse01_5ff85c0b:

    h "You got to shoot with a star model on your very first job. Hahaha."

translate english ch04_hhouse01_00a3a6b1:

    d "Haha, I'm honored."

translate english ch04_hhouse01_8704e5a6:

    d "I'd love to get close with her in private."

translate english ch04_hhouse01_b224584e:

    h "I invited her over next weekend, so we'll all have dinner together."

translate english ch04_hhouse01_13245be0:

    h "You probably won't be working together again, but it's nice to keep in touch."

translate english ch04_hhouse01_663ed274:

    d "I'm looking forward to it. Haha."

translate english ch04_hhouse01_56a81022:

    d "**(I wish we could keep shooting together......)**"

translate english ch04_hhouse01_0aaea236:

    d "Oh, right!"

translate english ch04_hhouse01_8e966651:

    d "I have a job interview at a marketing company tomorrow."

translate english ch04_hhouse01_47269d3c:

    d "Mary helped me get the interview."

translate english ch04_hhouse01_9dc125e7:

    h "Oh, that's great news."

translate english ch04_hhouse01_bb7594d1:

    h "You must be nervous. Haha."

translate english ch04_hhouse01_2d31fb02:

    h "Don't stress yourself out too much. You'll do fine."

translate english ch04_hhouse01_7220cd0f:

    d "Thank you. Haha."

translate english ch04_hhouse01_63931a08:

    d "I really hope I get the job and start earning my own money."

translate english ch04_hhouse01_65b7e814:

    d "I want to help out while I'm living here with you, [h_name]."

translate english ch04_hhouse01_e5c36b54_1:

    d "..........."

translate english ch04_hhouse01_d22ce05b:

    d "I mean..."

translate english ch04_hhouse01_a85f2cd6:

    d "I want to be recognized as a real man in this house. Haha."

translate english ch04_hhouse01_7f347d92:

    d "After all, I want to be the man of this house someday. Hehe."

translate english ch04_hhouse01_83261455:

    h "........."

translate english ch04_hhouse01_9ed84c00:

    h "You will."

translate english ch04_hhouse01_876f3dfb:

    h "Hmm, then..."

translate english ch04_hhouse01_4563721b:

    h "It might rain tomorrow..."

translate english ch04_hhouse01_58eef9e6:

    h "So, as a little good luck charm..."

translate english ch04_hhouse01_7e2a78c7:

    h "I'll drive you to the company tomorrow."

translate english ch04_hhouse01_973db2d4:

    h "It's hot out. Walking around in a dress shirt soaked in sweat isn't exactly a good look. Haha."

translate english ch04_hhouse01_1bd77f50:

    d "You really don't have to do that..."

translate english ch04_hhouse01_ae72d976:

    d "Thank you so much..."

translate english ch04_hhouse01_a01f4f46:

    h ".........."

translate english ch04_hhouse01_02afbbd2:

    h "It's no big deal. Hehe."

translate english ch04_hhouse01_cabb6c7d:

    h "Come on, finish your dinner."

translate english ch04_hhouse02_86b401b0:

    d "So much has happened lately..."

translate english ch04_hhouse02_c1263c51:

    d "Hah........."

translate english ch04_hhouse02_8486b40f:

    d "Sex is all I ever think about these days..."

translate english ch04_hhouse02_edbb7d05:

    d "........"

translate english ch04_hhouse02_005d3da3:

    d "When the hell am I going to do Professor sophia's assignment?"

translate english ch04_hhouse02_44a92def:

    d "Damn..."

translate english ch04_hhouse02_b8d914d0:

    h "Phew.........."

translate english ch04_hhouse02_f59ebfe1:

    h "I'm exhausted....."

translate english ch04_hhouse02_94253ada:

    h "....."

translate english ch04_hhouse02_284946bb:

    h "I'm getting old... My legs are killing me after just half a day of shooting."

translate english ch04_hhouse02_1cb78ef5:

    h "Back in my twenties, I could shoot all night..."

translate english ch04_hhouse02_92ad9932:

    h "............"

translate english ch04_hhouse02_7806ba58:

    h "He was actually trying to slip it inside Madam....."

translate english ch04_hhouse02_4d48f559:

    h "Was he really?..."

translate english ch04_hhouse02_92ad9932_1:

    h "............"

translate english ch04_hhouse02_bb73751c:

    h "How could he even think that with me standing right there?"

translate english ch04_hhouse02_8e44d9cb:

    h "........"

translate english ch04_hhouse02_5aa3225e:

    h "Were those two somehow giving each other signals?..."

translate english ch04_hhouse02_2d56a091:

    h "No way..."

translate english ch04_hhouse02_7caf97d7:

    h "............."

translate english ch04_hhouse02_abebc958:

    h "Honestly, though... some of those scenes were really fucking hot..."

translate english ch04_hhouse02_00f066ea:

    h "......."

translate english ch04_hhouse02_7caf97d7_1:

    h "............."

translate english ch04_hhouse02_898cc540:

    h "Do I look that sexy when I'm having sex?"

translate english ch04_hhouse02_83261455:

    h "........."

translate english ch04_hhouse02_856c416e:

    h "Was I getting just as soaking wet as Madam?......."

translate english ch04_hhouse02_94253ada_1:

    h "....."

translate english ch04_hhouse02_f9889c53:

    h "Hah............"

translate english ch04_hhouse02_94253ada_2:

    h "....."

translate english ch04_hhouse02_b0fbafb3:

    h "When was the last time I had sex...?"

translate english ch04_hhouse02_b8d914d0_1:

    h "Phew.........."

translate english ch04_hhouse02_83261455_1:

    h "........."

translate english ch04_hhouse02_b167ded3:

    h "He's unbelievably healthy..."

translate english ch04_hhouse02_af3181c4:

    h "......"

translate english ch04_hhouse02_4c2099e3:

    h "How was he still hard even after he came...?"

translate english ch04_hhouse02_85a2341c:

    h "Hah......."

translate english ch04_hhouse02_441c8b37:

    h "I guess I'm just in the mood today..."

translate english ch04_hhouse02_9ce42b14:

    d "Ugh..."

translate english ch04_hhouse02_4341de64:

    d "Ah, [h_name]..."

translate english ch04_hhouse02_db8393d8:

    d "It feels so damn good when you do that..."

translate english ch04_hhouse02_1d28cd2d:

    d "Ah, [h_name]........"

translate english ch04_hhouse02_482d5313:

    d "Devour it!! Eat me up!!"

translate english ch04_hhouse02_85fc5fbe:

    d "Ah........"

translate english ch04_hhouse02_28a5d24f:

    d "[h_name]!!!"

translate english ch04_hhouse02_b812946a:

    d "Get up and come here!!"

translate english ch04_hhouse02_fea64519:

    d "I wanted to fuck with you the moment I saw you!!"

translate english ch04_hhouse02_4554cacc:

    d "I wanted to rip that green dress off you and fuck your brains out!!"

translate english ch04_hhouse02_4a57d0d7:

    d "I know you wanted to ride my cock the first day we met too, Landlady!!"

translate english ch04_hhouse02_b4582326:

    d "That's why you kept showing me around the house as an excuse!!!"

translate english ch04_hhouse02_bc2f4d18:

    h "Hah......"

translate english ch04_hhouse02_790f61b1:

    h "I'm so horny today..."

translate english ch04_hhouse02_fd587bab:

    h ".............."

translate english ch04_hhouse02_1a0127a3:

    h "I want to be fucked hard..."

translate english ch04_hhouse02_fd587bab_1:

    h ".............."

translate english ch04_hhouse02_0ccedb6b:

    h "Phew............"

translate english ch04_hhouse02_00f066ea_1:

    h "......."

translate english ch04_hhouse02_7718bc0d:

    h "I guess my period's coming..."

translate english ch04_hhouse02_4bd01ca7:

    h "I can't get the image of [d_name] with that erection out of my head..."

translate english ch04_hhouse02_fd587bab_2:

    h ".............."

translate english ch04_hhouse02_b1048119:

    h "Look at you, [h_name]..."

translate english ch04_hhouse02_a142bfbd:

    h "Getting turned on just thinking about a younger man's body..."

translate english ch04_hhouse02_fd587bab_3:

    h ".............."

translate english ch04_hhouse02_acbff0fd:

    h "You're disgusting..."

translate english ch04_hhouse02_d4ccb5c4:

    d "You wanted me to fuck you in the living room... in my room... even out in the backyard... didn't you?"

translate english ch04_hhouse02_10b79667:

    d "You've been waiting for me to make a move... haven't you?!"

translate english ch04_hhouse02_be600df9:

    d "You wanted me to fuck you in the kitchen too... didn't you?!"

translate english ch04_hhouse02_7cbc006b:

    d "You wanted Madam and me to fuck you together today... didn't you?!!!"

translate english ch04_hhouse02_83261455_2:

    h "........."

translate english ch04_hhouse02_85e14097:

    h "Was [d_name] really this big?"

translate english ch04_hhouse02_83261455_3:

    h "........."

translate english ch04_hhouse02_9787ae79:

    h "No...I think it was actually a little thicker."

translate english ch04_hhouse02_ef829db7:

    h "Hah........"

translate english ch04_hhouse02_0486ec8d:

    h "And I lectured Rena after doing all this?..."

translate english ch04_hhouse02_68df3ff3:

    h "I can almost hear Lena laughing at me..."

translate english ch04_hhouse02_0d7cbb9f:

    h "Hmm...."

translate english ch04_hhouse02_c866843e:

    d "Ah, [h_name]!!!"

translate english ch04_hhouse02_9f3cdd6d:

    d "You're mine now, got it?!!"

translate english ch04_hhouse02_54b5ecde:

    d "You're my woman now!!"

translate english ch04_hhouse02_6bbd9581:

    d "Damn!!"

translate english ch04_hhouse02_8362a50c:

    d "Ah, [h_name]!!!!!"

translate english ch04_hhouse02_a66fd6ce:

    d "Aah......"

translate english ch04_hhouse02_551e0487:

    d "Ahh....."

translate english ch04_company01_c70cc875:

    n "The next morning, under clear skies, she was waiting for him in the living room."

translate english ch04_company01_029b22a6:

    n "It reminded her of the life she used to have."

translate english ch04_company01_0b4724f2:

    n "The only thing that had changed was the man who would be walking out of that room."

translate english ch04_company01_0b3a5235:

    h "[d_name]!!"

translate english ch04_company01_799829ff:

    h "You're going to be late. Come on out."

translate english ch04_company01_6ba0cc5d:

    h "Do you need me to start nagging you?"

translate english ch04_company01_5df40a27:

    d "Yep! Coming!!"

translate english ch04_company01_67a51b84:

    d "I was taking forever. Haha."

translate english ch04_company01_5d2e940c:

    d "I'm coming, I'm coming."

translate english ch04_company01_cd2fa4d2:

    d "I've hardly ever dressed like this before, so it took me a while."

translate english ch04_company01_e5ff2ced:

    h "Wow, [d_name]."

translate english ch04_company01_d926b452:

    h "You really look like an office worker dressed like that. Hehe."

translate english ch04_company01_428df35b:

    h "I'm glad my son's clothes fit you perfectly."

translate english ch04_company01_8f81cca5:

    h "You look like a real gentleman. Haha."

translate english ch04_company01_074158f4:

    d "I've always been a gentleman, you know?!!"

translate english ch04_company01_42c256b1:

    d "Did you forget already? Hahaha."

translate english ch04_company01_376bfe02:

    h "Come on."

translate english ch04_company01_9527b785:

    h "Good thing the rain stopped. The weather's nice today."

translate english ch04_company01_f41a4175:

    h "But I'm almost as nervous as if I were the one going to the interview. Hahaha."

translate english ch04_company01_8e2366de:

    d "Haha, really?"

translate english ch04_company01_37204f66:

    h "Ow....."

translate english ch04_company01_9fe0f62d:

    h "My shoulder's sore just from carrying the camera yesterday."

translate english ch04_company01_f72ce763:

    h "See? That's what being a old woman is like."

translate english ch04_company01_956b07b8:

    h "I'm not like those young women in their twenties anymore. Haha."

translate english ch04_company01_a797f6ce:

    d "............."

translate english ch04_company01_219d730d:

    d "Thanks for the ride."

translate english ch04_company01_67773795:

    d "I'll do my best in the interview. Hehe."

translate english ch04_company01_cccf54d1:

    h "You will."

translate english ch04_company01_9a425eeb:

    h "Don't be nervous. Just do your best."

translate english ch04_company01_1d855824:

    h "If anything comes up, give me a call, okay?"

translate english ch04_company01_0d4d0ea7:

    d "Yes, ma'am."

translate english ch04_company01_e63dee7e:

    d "Thank you."

translate english ch04_company01_814707b6:

    d "Ill crush this interview just for you, [h_name]!!"

translate english ch04_company01_f38afc61:

    h "Hahaha, alright."

translate english ch04_company01_ec997cad:

    d "**(If [h_name] were my wife and I got to leave for work like this every day... I'd be happy.)**"

translate english ch04_company01_a08d42fa:

    d "**(And she'd be waiting for me at night in sexy lingerie...)**"

translate english ch04_company01_09fac8b4:

    d "**(Damn it... focus on the interview.)**"

translate english ch04_company01_c1306ef7:

    d "**(Get it together, [d_name]!!)**"

translate english ch04_company01_bee45722:

    n "*Tap tap tap tap.*"

translate english ch04_company01_932bbcf7:

    d "Hi..."

translate english ch04_company01_1e92481f:

    d "Um... I'm here for my interview."

translate english ch04_company01_fac8215b:

    d "............"

translate english ch04_company01_7556f201:

    unknownf "Hello."

translate english ch04_company01_a0d77226:

    unknownf "You must be [d_name], right?"

translate english ch04_company01_7fc7458b:

    d "Yes, that's me."

translate english ch04_company01_9c710b35:

    d "I'm here for my interview today."

translate english ch04_company01_657e8b73:

    d "My name is [d_name]."

translate english ch04_company01_7ec61a5d:

    unknownf "Nice to meet you."

translate english ch04_company01_910c53cf:

    unknownf "Please follow me."

translate english ch04_company01_e63dee7e_1:

    d "Thank you."

translate english ch04_company01_a90e6be2:

    unknownf "Please wait here for a moment."

translate english ch04_company01_606d75a2:

    unknownf "The CEO will be with you shortly."

translate english ch04_company01_406c813e:

    unknownf "Can I get you something to drink?"

translate english ch04_company01_666bae08:

    d "No, thank you. I'm fine."

translate english ch04_company01_e63dee7e_2:

    d "Thank you."

translate english ch04_company01_74616a36:

    d "Hmm......."

translate english ch04_company01_bf6823f3:

    d "**(Doesn't seem like a very big company...)**"

translate english ch04_company01_63b441d1:

    d "**(Then again, that's pretty normal for a small city like this...)**"

translate english ch04_company01_e7d0b0a3:

    n "He was almost surprised by how calm he felt."

translate english ch04_company01_98796fdc:

    n "He was beginning to wonder if working at a company really wasn't such a big deal after all."

translate english ch04_company01_fac8215b_1:

    d "............"

translate english ch04_company01_a9879c6c:

    d "**(I wonder what Mary's friend is like.....)**"

translate english ch04_company01_93968949:

    d "**(Hmm......)**"

translate english ch04_company01_0411797d:

    d "**(......)**"

translate english ch04_company01_e92699b2:

    d "**(Will she be a sexy MILF... or just some chubby old woman..?)**"

translate english ch04_company01_fe0a2349:

    d "**(Hehehe.)**"

translate english ch04_company01_4c0bc9dc:

    d "!!"

translate english ch04_company01_0c2760b5:

    r "Have I kept you waiting?"

translate english ch04_company01_ec9c36be:

    d "Huh?!!"

translate english ch04_company01_f442e29c:

    d "N-No, not at all."

translate english ch04_company01_112c07da:

    d "I was just thinking about the interview."

translate english ch04_company01_af2e4229:

    n "When he looked up, the woman standing before him was nothing like he had imagined."

translate english ch04_company01_25d9dae0:

    n "As she moved, a gentle breeze carried the rich scent of her perfume toward him."

translate english ch04_company01_f89ee523:

    n "Every thought he had about the interview instantly vanished."

translate english ch04_company01_335baa5e:

    d "......................"

translate english ch04_company01_2d9d5996:

    r "........."

translate english ch04_company01_f3552241:

    r "Hmm........"

translate english ch04_company01_c89a9fcc:

    n "Her mere presence was enough to overwhelm [d_name]."

translate english ch04_company01_2d9d5996_1:

    r "........."

translate english ch04_company01_ab01ff9d:

    n "During those few silent seconds, he couldn't even hear himself breathe."

translate english ch04_company01_05167016:

    r "First..."

translate english ch04_company01_6b679911:

    r "There's something I've been curious about."

translate english ch04_company01_480a0ed3:

    r "Before that, though... I should warn you. Sometimes I can be a little blunt."

translate english ch04_company01_e4c3e046:

    r "It's a bad habit of mine, so don't take it the wrong way."

translate english ch04_company01_a7cd48db:

    r "Understood?"

translate english ch04_company01_fb5d6485:

    d "Y-Yes... I understand."

translate english ch04_company01_ec46d0ae:

    r "So, what's your relationship with Mary?"

translate english ch04_company01_07e1fb9b:

    r "..........."

translate english ch04_company01_1f34774a:

    r "How did the two of you meet?"

translate english ch04_company01_8da1570c:

    d "Ah... well..."

translate english ch04_company01_203cc60b:

    d "......."

translate english ch04_company01_66ddc0e1:

    d "Yes, I'm originally from this town."

translate english ch04_company01_7afb4777:

    d "I was abandoned as a child and ended up in an orphanage."

translate english ch04_company01_74908377:

    d "Although, to be honest, I only found that out because Mary told me."

translate english ch04_company01_07e1fb9b_1:

    r "..........."

translate english ch04_company01_56526afb:

    d "Mary was the one who took care of me at the orphanage."

translate english ch04_company01_4e13395e:

    d "I was placed with a foster family when I was a teenager, but we've stayed close ever since. She's been like a friend to me."

translate english ch04_company01_2d9d5996_2:

    r "........."

translate english ch04_company01_cda42f36:

    r "I see."

translate english ch04_company01_d7a2a624:

    r "Sounds like you had a pretty difficult childhood."

translate english ch04_company01_2d9d5996_3:

    r "........."

translate english ch04_company01_5c2602af:

    r "Actually, Mary called me just yesterday."

translate english ch04_company01_d63ed435:

    d "Oh... really?.."

translate english ch04_company01_3dcac921:

    r "She told me you were a good student and asked if I'd give you a chance."

translate english ch04_company01_b4d5c526:

    r "She's never asked me for a favor in all the years I've known her, so I have to admit, it surprised me."

translate english ch04_company01_a2aa629e:

    d "I see."

translate english ch04_company01_5e3aec4e:

    d ".........."

translate english ch04_company01_e830c7b1:

    d "I owe her more than I could ever repay."

translate english ch04_company01_9c093afb:

    r "More than you could ever repay?"

translate english ch04_company01_4fe2f25a:

    d "Yes."

translate english ch04_company01_68a9aef1:

    d "She's always treated me like family."

translate english ch04_company01_77673f80:

    d "........."

translate english ch04_company01_92096839:

    d "And she's a truly beautiful woman."

translate english ch04_company01_77673f80_1:

    d "........."

translate english ch04_company01_de512d9e:

    d "Sorry... I got off topic."

translate english ch04_company01_bc96dc3b:

    r "............"

translate english ch04_company01_a7f21798:

    r "That's true."

translate english ch04_company01_f360c6e2:

    r "Even as a woman, I have to admit Mary is the kind of woman anyone would fall for. Hahaha."

translate english ch04_company01_fcee0436:

    r "She's my friend, but sometimes she's like a little girl, and other times she's like a mother."

translate english ch04_company01_d09c9352:

    n "She paused for a moment before staring at the monitor with a serious expression."

translate english ch04_company01_73454583:

    d "**(O-Oh, shit....)**"

translate english ch04_company01_f677d58c:

    d "**(The pressure is unreal......)**"

translate english ch04_company01_2a5608b3:

    r "I heard you've been studying psychology at university."

translate english ch04_company01_490f22fa:

    r "You've only been at it for about a year, but how has it been so far?"

translate english ch04_company01_2bd803d1:

    d "I've really enjoyed it."

translate english ch04_company01_a450a401:

    d "I've always loved digging into the raw, fundamental principles of how things work."

translate english ch04_company01_4a2f6e51:

    d "That's why I believe no discipline is more essential to marketing than psychology, since it literally decodes human nature."

translate english ch04_company01_bdf9a62e:

    d "More than anything, I love that it's a field dedicated to understanding people."

translate english ch04_company01_098cb77b:

    r "I see."

translate english ch04_company01_d5882076:

    r "So do you think what you've learned over the past year will actually be useful at a marketing company?"

translate english ch04_company01_60a77ddb:

    d "**(Thank God...)**"

translate english ch04_company01_d002e694:

    d "**(Good thing I prepared an answer for this last night. Haha.)**"

translate english ch04_company01_4fe2f25a_1:

    d "Yes, I do."

translate english ch04_company01_93172ea7:

    d "Marketing is a field where understanding people has to come first."

translate english ch04_company01_09dde169:

    d "That's why I believe there's no field more valuable to marketing than psychology, since it's fundamentally the study of human nature."

translate english ch04_company01_6a21657e:

    d "..............."

translate english ch04_company01_695f76ba:

    d "I want to learn firsthand how people's minds work in marketing,"

translate english ch04_company01_ad7209f6:

    d "and how those thoughts and emotions ultimately influence what they choose to buy."

translate english ch04_company01_5447ebb5:

    r "**(..............)**"

translate english ch04_company01_765c4b76:

    r "**(That answer is so cliché it's almost laughable...)**"

translate english ch04_company01_156aea3a:

    r "**(Did he just look that up on AI or something?..)**"

translate english ch04_company01_4d8936d7:

    r "Consumer behavior, huh..."

translate english ch04_company01_c3eafc2c:

    r "[d_name], you're still young enough to be my son, so I'll be frank with you."

translate english ch04_company01_09ce443b:

    r "In the end, marketing is the art of seduction."

translate english ch04_company01_dfda223a:

    r "Making them absolutely crave what you've got."

translate english ch04_company01_139d33b5:

    r "As a psychology student, you understand that, don't you?"

translate english ch04_company01_0efc3faa:

    r "How to tap into people's deepest desires."

translate english ch04_company01_77673f80_2:

    d "........."

translate english ch04_company01_99e64fe7:

    d "Exactly."

translate english ch04_company01_2f161136:

    d "I think the key is identifying what people feel they're missing, then convincing them you can fill that void."

translate english ch04_company01_4cefc774:

    r "................."

translate english ch04_company01_7d7d2872:

    r "What kind of person do you think I am?"

translate english ch04_company01_4cefc774_1:

    r "................."

translate english ch04_company01_8e71a941:

    r "Analyze me from a psychology student's perspective."

translate english ch04_company01_7b5e7e45:

    d "You want me to analyze you, ma'am?..."

translate english ch04_company01_73770cab:

    r "Relax. Whatever's said in this room stays in this room."

translate english ch04_company01_f0a1306d:

    r "There's no hidden agenda. I ask this in every interview."

translate english ch04_company01_2a2bbbab:

    d "Ah... alright."

translate english ch04_company01_df634330:

    r "Analyze anything you can observe about me."

translate english ch04_company01_dc2d9e85:

    r "You can even talk about my huge tits that you've been staring at so hard. Hahaha."

translate english ch04_company01_2266e260:

    d "What?!!!!"

translate english ch04_company01_e87c7f72:

    d "**(O-Oh, shit...)**"

translate english ch04_company01_776c14f4:

    d "**(I wish the floor would just swallow me up......)**"

translate english ch04_company01_46a36509:

    unknownf "What's going on in there?"

translate english ch04_company01_6cb03345:

    r "But if you actually dare to mention my tits, you can forget about working here."

translate english ch04_company01_e6fce689:

    d "*Cough, cough.*"

translate english ch04_company01_fb5d6485_1:

    d "Y-Yes... understood."

translate english ch04_company01_9c65a309:

    d "**(Damn... I almost said it..)**"

translate english ch04_company01_d9a1ced7:

    r "..............."

translate english ch04_company01_bb0f76cd:

    r "Go on. Tell me what you've read about me."

translate english ch04_company01_a339b6bd:

    r "I'm not the type to hold a grudge, so be as honest as you can."

translate english ch04_company01_6c7bfe69:

    r "I'm curious how a kid like you would analyze me."

translate english ch04_company01_3c64d378:

    n "[d_name] felt uneasy under her teasing demeanor."

translate english ch04_company01_41c1a3f9:

    n "For a brief moment, he pictured Mary asking Rose to give him a job."

translate english ch04_company01_6568a5e5:

    n "That image alone was enough to make him resent Rose."

translate english ch04_company01_34f497b2:

    n "And being looked down on by a woman old enough to be his mother only made him angrier."

translate english ch04_company01_a1cd1409:

    n "The memory of being abandoned by his birth mother had become one of the biggest reasons he was drawn to older women."

translate english ch04_company01_30564186:

    n "The way Rose was acting now was more than enough to make him uncomfortable—and angry."

translate english ch04_company01_bff9b761:

    n "So he decided to vent that anger through his analysis of her."

translate english ch04_company01_b5c44afe:

    d "Right now, you're completely armored."

translate english ch04_company01_a797f6ce_1:

    d "............."

translate english ch04_company01_fee02094:

    d "The bold makeup contrasting with your black hair, your impeccable outfit, and the commanding confidence you carry."

translate english ch04_company01_d5060334:

    d "I'd even guess you have your hair professionally styled on a regular basis."

translate english ch04_company01_5dacac1b:

    d "And... I'd also guess you're completely shaved and waxed down there as well."

translate english ch04_company01_1c55f59f:

    r ".........."

translate english ch04_company01_070412bd:

    d "For the CEO of a marketing company, it's all part of the armor."

translate english ch04_company01_0608acea:

    d "And of course, they're also for your own personal satisfaction."

translate english ch04_company01_364db289:

    d "A desire to keep both your company and yourself under perfect control."

translate english ch04_company01_08dc8aed:

    d "But......."

translate english ch04_company01_131410d6:

    r "..........."

translate english ch04_company01_0aec4d98:

    r "But?"

translate english ch04_company01_06ce0ff2:

    d "That beauty mark beside your lips..."

translate english ch04_company01_f3763cea:

    d "I believe it's drawn on with makeup."

translate english ch04_company01_1c55f59f_1:

    r ".........."

translate english ch04_company01_be9689aa:

    d "I don't think you'd rather have people fear you."

translate english ch04_company01_84345e18:

    d "Deep down, don't you want someone to see past that armor and see you as a woman?"

translate english ch04_company01_781b35b1:

    d "In other words, beneath the CEO's armor..."

translate english ch04_company01_bd5f49c4:

    d "You want people to see that there's an attractive woman underneath it."

translate english ch04_company01_67b5164e:

    r "....................."

translate english ch04_company01_68409622:

    d "No... to be more precise, I think you're using your femininity as another tool to run your business."

translate english ch04_company01_fc509a7d:

    d "In short, you've turned yourself into a product."

translate english ch04_company01_77f4106c:

    r "Go on."

translate english ch04_company01_a6c20fb8:

    d "If marketing is the art of seduction, then you're its perfect subject."

translate english ch04_company01_7ae08661:

    d "But everyone's so intimidated by your status and appearance that they never get close enough to see the emptiness the real Rose carries inside."

translate english ch04_company01_7a7b71b9:

    d "Behind the mask of a successful middle-aged businesswoman, I see someone starving for raw, instinctive attention..."

translate english ch04_company01_d220f1a8:

    d "That's what I see."

translate english ch04_company01_1453c16d:

    d "Everyone's so intimidated by your success that all they ever do is tell you what you want to hear."

translate english ch04_company01_9614944d:

    d "In fact, I think you're more intrigued by people who treat you casually—or even rudely."

translate english ch04_company01_335baa5e_1:

    d "......................"

translate english ch04_company01_004f14fa:

    d "In short, you've turned yourself into a marketing experiment."

translate english ch04_company01_daf5ab38:

    r "............."

translate english ch04_company01_ddc1cac8:

    r "A marketing experiment..."

translate english ch04_company01_2b6b4baf:

    r "You're not the first guy, [d_name], who's talked shit like he knows exactly what's missing inside me."

translate english ch04_company01_c87464c7:

    r "Most of them were just using their so-called analysis as a cheap pickup tactic. It got old fast."

translate english ch04_company01_ea7f9aeb:

    r "Don't you think?"

translate english ch04_company01_a02fb7bd:

    d "The difference between them and me is simple."

translate english ch04_company01_a139b5b7:

    d "I'm not interested in telling you what you want to hear."

translate english ch04_company01_0e874ff3:

    d "I don't have the knowledge or experience to say those kinds of things anyway."

translate english ch04_company01_251d5d01:

    d "I'm interested in the things you're trying to hide."

translate english ch04_company01_ac4a25fc:

    d "To be honest, this kind of analysis is risky."

translate english ch04_company01_5819891c:

    d "If the other person doesn't like it, you just end up looking like some rude young punk."

translate english ch04_company01_5cfc80d9:

    d "But instead of getting angry, you only seemed to grow more interested in what I had to say."

translate english ch04_company01_d8251297:

    d "I think what fascinated you wasn't my analysis itself, but the fact that someone actually looked that deeply into you."

translate english ch04_company01_c8f6fa5d:

    d "That's why I kept going."

translate english ch04_company01_daf5ab38_1:

    r "............."

translate english ch04_company01_06dd86c9:

    r "Hahahahaha."

translate english ch04_company01_ec4baa0d:

    r "My goodness!"

translate english ch04_company01_a2f993ca:

    r "Mary really sent me quite a find."

translate english ch04_company01_b53cbff6:

    r "I never expected to hear something like that from a freshman in college."

translate english ch04_company01_a8b4535c:

    d "I apologize if I was disrespectful..."

translate english ch04_company01_8bb09645:

    d "But you asked me to be honest, so I just said exactly what came to mind."

translate english ch04_company01_effb8546:

    r "Hahaha. No."

translate english ch04_company01_831415d4:

    r "It was honest, but unbelievably immature."

translate english ch04_company01_2951352b:

    d "**(Damn.)**"

translate english ch04_company01_3acd62e3:

    d "**(I went overboard.)**"

translate english ch04_company01_38de2457:

    r "For a second, I thought I was listening to dialogue from some third-rate novel. Hahaha."

translate english ch04_company01_187a3e48:

    d "I'm sorry..."

translate english ch04_company01_d1c54083:

    r "No, it's fine."

translate english ch04_company01_b867fa98:

    r "But I've never heard such a fresh perspective before. Hahaha."

translate english ch04_company01_2d8caffa:

    r "Now that's exactly the kind of unexpected insight I was hoping for."

translate english ch04_company01_a3fbba63:

    r "It was childish, sure, but at least it wasn't another cookie-cutter answer."

translate english ch04_company01_e30f082f:

    r "What you learn in school and what you learn in the real world are worlds apart..."

translate english ch04_company01_384af1eb:

    r "You seem to have a natural talent for reading people, [d_name]."

translate english ch04_company01_bc96dc3b_1:

    r "............"

translate english ch04_company01_2762f69c:

    d "Th-Thank you."

translate english ch04_company01_b7da6888:

    d "But I was a little disrespectful..."

translate english ch04_company01_936ea5e4:

    d "**(.............)**"

translate english ch04_company01_58a229ca:

    r "You were."

translate english ch04_company01_4047ea05:

    r "At a more uptight company, they would've sent you home on the spot."

translate english ch04_company01_7ab39cb0:

    d "!!!!"

translate english ch04_company01_a9ea1267:

    r "It's alright."

translate english ch04_company01_1cfcfd38:

    r "By my standards, you weren't disrespectful at all."

translate english ch04_company01_f7f4c921:

    r "If anything, I found it entertaining."

translate english ch04_company01_d9a1ced7_1:

    r "..............."

translate english ch04_company01_409aff64:

    r "This might sound a little harsh for someone your age,"

translate english ch04_company01_190da933:

    r "but the moment I touched the inferiority complex buried deep inside you, you immediately showed me who you really are."

translate english ch04_company01_60915de0:

    r "......."

translate english ch04_company01_22365ee2:

    r "There's nothing wrong with that, but to me, it feels like you're trapped inside a hard shell."

translate english ch04_company01_936ea5e4_1:

    d "**(.............)**"

translate english ch04_company01_5190f095:

    d "A... a shell?"

translate english ch04_company01_b2b1e648:

    r "That's right. A shell."

translate english ch04_company01_331b5d0d:

    r "It's like... something's holding you back, like a bird trapped inside its shell."

translate english ch04_company01_d9a1ced7_2:

    r "..............."

translate english ch04_company01_edbb7d05:

    d "........"

translate english ch04_company01_838ce6e7:

    r "Alright, kid."

translate english ch04_company01_40dc5923:

    r "Whether your analysis is right or wrong, you'll find out through your own experiences."

translate english ch04_company01_d9a1ced7_3:

    r "..............."

translate english ch04_company01_70eada4a:

    r "Actually... since you hide such sharp instincts behind that innocent face, I'll tell you the truth."

translate english ch04_company01_ca2a8dc4:

    r "I already knew about your childhood."

translate english ch04_company01_f1447191:

    r "I should apologize for keeping that from you."

translate english ch04_company01_4f93b497:

    r "And to be honest, I'd already decided to hire you as an intern after talking with Mary."

translate english ch04_company01_afb36878:

    r "I was looking for the fresh perspective of a college freshman."

translate english ch04_company01_799ce5e5:

    r "You probably noticed when you came in, but none of my employees are anywhere near your age."

translate english ch04_company01_fd3453ec:

    r "And since you're so close to my best friend, Mary, hiring you was an easy decision."

translate english ch04_company01_c00ab452:

    r "Besides, when a small company like ours hires a student intern, the state helps subsidize their wages."

translate english ch04_company01_4cefc774_2:

    r "................."

translate english ch04_company01_1f2f26f1:

    r "But even without all those reasons, I think I still would've hired you."

translate english ch04_company01_f45d7c1a:

    r "Do you know why?"

translate english ch04_company01_d14ee744:

    d "No... I don't."

translate english ch04_company01_80b249b0:

    r "Alright, [d_name]."

translate english ch04_company01_45003eaa:

    r "The most important thing in marketing is honesty."

translate english ch04_company01_d8679fc4:

    r "Being exactly who you are."

translate english ch04_company01_1350a6d7:

    r "Like the side of yourself you just showed me."

translate english ch04_company01_cc416e60:

    r "Isn't psychology the same?"

translate english ch04_company01_90059e9e:

    r "If you want to understand someone's mind, you first have to see that person for who they really are."

translate english ch04_company01_09ce054c:

    r "If you force things or just cover everything up with words people want to hear... you might fool them for a while, but the truth always comes out."

translate english ch04_company01_187feda0:

    r "People are far more perceptive than you think."

translate english ch04_company01_0523cbb7:

    r "Instinctively, they can tell the difference between what's real and what's fake—between sincerity and packaging."

translate english ch04_company01_ad204a5b:

    r "And business is no different."

translate english ch04_company01_902ef25a:

    r "Most people think marketing is about creating value where there is none, or dressing up something ordinary until it sparkles."

translate english ch04_company01_b3de5795:

    r "That's not entirely wrong."

translate english ch04_company01_f08bf8b8:

    r "But that approach never lasts."

translate english ch04_company01_e97c8391:

    r "Because empty packaging always gets torn away."

translate english ch04_company01_d85e3ce8:

    r "Exaggerated promises, inflated images, manufactured fantasies..."

translate english ch04_company01_aaa2d183:

    r "They might grab people's attention at first, but all they leave behind is disappointment."

translate english ch04_company01_3cc5956d:

    r "And disappointment erodes trust."

translate english ch04_company01_c41de5cb:

    r "That backlash can damage a brand's credibility even more than before the marketing ever began."

translate english ch04_company01_65dff47a:

    r "Once trust is broken, money alone can't easily buy it back."

translate english ch04_company01_59c0655f:

    r "That's why real marketing isn't about creating something that doesn't exist."

translate english ch04_company01_f6897fdf:

    r "It's about the value that's already there."

translate english ch04_company01_7f435616:

    r "The genuine meaning the brand already possesses..."

translate english ch04_company01_86ccbc4d:

    r "Finding the clearest, most accurate, and most compelling way to communicate it."

translate english ch04_company01_25eadd96:

    r "That's where it all begins."

translate english ch04_company01_dd82c6d8:

    r "Simply put... marketing isn't the art of adding something fake. It's the art of conveying what's real."

translate english ch04_company01_16fa83b6:

    r "That's how you truly move people."

translate english ch04_company01_3a43c129:

    r "In the end, what moves people isn't illusion—it's connection."

translate english ch04_company01_48d969e8:

    r "When someone decides to spend their money on something..."

translate english ch04_company01_a656fbd5:

    r "When a deal is made between A and B..."

translate english ch04_company01_bc96dc3b_2:

    r "............"

translate english ch04_company01_012417d6:

    r "When a woman strips down and spreads her legs for a guy,"

translate english ch04_company01_a1d1f50a:

    r "Do you know what the absolute prerequisite is?"

translate english ch04_company01_e7846a0f:

    d "I... I don't."

translate english ch04_company01_d9a1ced7_4:

    r "..............."

translate english ch04_company01_77db0722:

    r "You already know the answer."

translate english ch04_company01_8df17476:

    r "Certainty."

translate english ch04_company01_404dcc09:

    r "That it's safe to buy this product,"

translate english ch04_company01_5bea1174:

    r "That it's safe to do business with this person,"

translate english ch04_company01_4077336f:

    r "That it's okay to spread my legs for this man..."

translate english ch04_company01_3c90c099:

    r "Every decision people make, every action they take, begins with that sense of certainty."

translate english ch04_company01_728ad9fc:

    r "And that certainty starts with the honesty you showed me..."

translate english ch04_company01_d4c525e8:

    d "I... I see..."

translate english ch04_company01_a9b324fc:

    r "You didn't tiptoe around me trying to tell me what I wanted to hear, and you didn't make things up just to impress me."

translate english ch04_company01_b09ee965:

    r "You simply told me what you saw."

translate english ch04_company01_fc7278ee:

    r "It could've come across as rude, but at the same time, it was incredibly powerful..."

translate english ch04_company01_8641aa02:

    r "That's what marketing is really about—authenticity."

translate english ch04_company01_a25799e4:

    r "So let me repay you with a line straight out of a cheesy novel."

translate english ch04_company01_7c0a9214:

    d ".............."

translate english ch04_company01_81ca6bbe:

    r "I'm looking forward to it."

translate english ch04_company01_dee83213:

    r "To seeing how you'll fill the void you think you found in me..."

translate english ch04_company01_0d0fc650:

    r "Don't get the wrong idea."

translate english ch04_company01_32724b0a:

    r "I mean the company's, not mine."

translate english ch04_company01_77673f80_3:

    d "........."

translate english ch04_company01_fd499680:

    r "Oh, and one more thing..."

translate english ch04_company01_c1cff048:

    r "This beauty mark is real."

translate english ch04_company01_fee59fe6:

    r "It's not makeup!"

translate english ch04_company01_4ba3449b:

    r "I'm not that childish."

translate english ch04_company01_77673f80_4:

    d "........."

translate english ch04_company01_fab576ab:

    d "I... I see."

translate english ch04_company01_f6ef9ef5:

    d "**(This woman is completely impossible to read...)**"

translate english ch04_company01_f67c8391:

    d "**(How does she keep throwing people off balance like this?...)**"

translate english ch04_company01_917af486:

    r "Alright, then..."

translate english ch04_company01_9c7e048d:

    r "How about you take today and tomorrow for yourself, then start work the day after?"

translate english ch04_company01_b4815ac8:

    d "Yes, I'll do that!"

translate english ch04_company01_61f29521:

    r "Good. Nice work today."

translate english ch04_company01_c87e7a39:

    r "I'll have your desk and everything else ready for you."

translate english ch04_company01_6252ca8e:

    r "And give Mary a call, too."

translate english ch04_company01_2d632ab8:

    d "Yes, I will!"

translate english ch04_company01_2cf566f8:

    d "**(My God....)**"

translate english ch04_company01_d93cf845:

    d "**(I've never met anyone so impossible to figure out.)**"

translate english ch04_company01_6058ecae:

    d "**(.........)**"

translate english ch04_company01_e54a9e02:

    d "**(Does that just come naturally with age?)**"

translate english ch04_company01_539598b0:

    d "Phew........."

translate english ch04_company01_594df048:

    d "She has an incredible presence..."

translate english ch04_company01_34945e96:

    d "I guess that's why she's able to run a company like this..."

translate english ch04_company01_6236e1df:

    n "The phone rings."

translate english ch04_company01_d6a56aba:

    d "Amanda!!"

translate english ch04_company01_17571bf8:

    d "How've you been?"

translate english ch04_company01_46418b0f:

    a "I've been good. How about you?"

translate english ch04_company01_b4c19eed:

    d "I've been great!!"

translate english ch04_company01_b3464382:

    d "I just got out of a job interview!"

translate english ch04_company01_adbd6a36:

    a "A job interview??"

translate english ch04_company01_6b7a648b:

    d "Yeah!"

translate english ch04_company01_10ae6189:

    d "Mary got me the hookup, and I start work in two days."

translate english ch04_company01_d3388ff1:

    a "Oh, that's wonderful."

translate english ch04_company01_e8c4dd9a:

    a "Looks like I called at the perfect time."

translate english ch04_company01_02bf480a:

    a "Then how about we celebrate your new job with a trip to the beach?"

translate english ch04_company01_da23f370:

    a "What do you think?"

translate english ch04_company01_dce95acd:

    d "Right now?"

translate english ch04_company01_031fc3f0:

    a "Yep, right now."

translate english ch04_company01_ca640757:

    d "Sounds great!!"

translate english ch04_company01_7f45145a:

    d "But I don't have any clothes with me. What should I do?"

translate english ch04_company01_2190fe6b:

    a "You won't even need any clothes. Hahaha."

translate english ch04_company01_12629c1f:

    a "Go kill some time at a bookstore or something."

translate english ch04_company01_adf5f508:

    a "I'll be there soon, okay?"

translate english ch04_company01_678fcfa7:

    f ".............."

translate english ch04_company01_8c1e8e6f:

    f "You're going to see [d_name], aren't you?"

translate english ch04_company01_e629fa22:

    f "..............."

translate english ch04_company01_a5e7a973:

    f "What's with that outfit??"

translate english ch04_company01_56b73f72:

    f "You're not actually going out dressed like that, are you??"

translate english ch04_company01_0640f261:

    f "What are you, a fucking whore?!!"

translate english ch04_company01_bce4a2bd:

    f "You're embarrassing me in front of the whole neighborhood!!"

translate english ch04_company01_b00ad13b:

    a "............."

translate english ch04_company01_f1382988:

    a "Mind your own business."

translate english ch04_company01_c010d663:

    a "I'll have dinner ready, so take care of yourself."

translate english ch04_company01_6c629907:

    a "I might be home late tonight."

translate english ch04_company01_418f2d9f:

    a "Or why don't you go to that massage parlor you like so much?"

translate english ch04_company01_678fcfa7_1:

    f ".............."

translate english ch04_company01_0390e08b:

    f "Th-That's..."

translate english ch04_company01_c02126e9:

    a "You didn't actually think I didn't know, did you?"

translate english ch04_company01_b72743fa:

    a "Oh, Frank..."

translate english ch04_company01_678fcfa7_2:

    f ".............."

translate english ch04_company01_7ddef18b:

    a "You've disappointed me..."

translate english ch04_company01_a79822de:

    a "........"

translate english ch04_company01_fff813ef:

    a "Again..."

translate english ch04_company01_678fcfa7_3:

    f ".............."

translate english ch04_acar01_6dd334c8:

    a "Hahaha."

translate english ch04_acar01_133df301:

    a "That must've been quite an overwhelming interview."

translate english ch04_acar01_128a39ec:

    d "Yeah, it really was. Hahaha."

translate english ch04_acar01_203cc60b:

    d "......."

translate english ch04_acar01_c888bac4:

    d "But I think it was a great experience."

translate english ch04_acar01_e40071ca:

    a "Weren't you sweating bullets? Haha."

translate english ch04_acar01_1c5ecbbb:

    a "I bet even your balls are sweaty. Haha."

translate english ch04_acar01_596aae27:

    d "Oh my God, Amanda!!"

translate english ch04_acar01_1dc16800:

    d "They didn't get that sweaty."

translate english ch04_acar01_47ab915f:

    a "Want me to check? Hahaha."

translate english ch04_acar01_ff7404d3:

    d "Oh, really?"

translate english ch04_acar01_071112b9:

    d "Should I pull my anaconda out then?"

translate english ch04_acar01_6dd334c8_1:

    a "Hahaha."

translate english ch04_acar01_38afc469:

    a "So you actually liked that nickname?"

translate english ch04_acar01_ced0228c:

    a "I had a feeling you would."

translate english ch04_acar01_1c7eb40a:

    d "Ha! Not even a little."

translate english ch04_acar01_e19886bc:

    a "Not now."

translate english ch04_acar01_32c136fb:

    a "You'll need to take it out later."

translate english ch04_acar01_8096b08a:

    d "Huh?"

translate english ch04_acar01_be2cdb95:

    d "You mean I have to pull my anaconda out later?"

translate english ch04_acar01_128c8efd:

    d "I'll get arrested for indecent exposure if I do that at the beach."

translate english ch04_acar01_809535d8:

    d "How's Frank?"

translate english ch04_acar01_2098fdb9:

    d "Did he come over right after I left that day?"

translate english ch04_acar01_7b3692e5:

    a "Oh, don't even get me started..."

translate english ch04_acar01_fa9e3535:

    a "He came over that morning and talked all kinds of shit."

translate english ch04_acar01_d2b9bb20:

    a "Why did you take a shower so early? Did you sneak a man into the house last night?"

translate english ch04_acar01_ec46fd81:

    a "Then he was going around sniffing everything."

translate english ch04_acar01_a1221018:

    d "No way, seriously?!!"

translate english ch04_acar01_08ec000d:

    a "I remember thinking, He's finally lost it."

translate english ch04_acar01_80f507ef:

    d "That's really crazy."

translate english ch04_acar01_2f7e1a7a:

    d "Frank never changes."

translate english ch04_acar01_17659cc8:

    a ".............."

translate english ch04_acar01_6d41ba58:

    a "Maybe he's just getting worse with age..."

translate english ch04_acar01_285720c4:

    a "You know..."

translate english ch04_acar01_1d1dff82:

    a "I think it's finally time to put our plan into action."

translate english ch04_acar01_e513fc8a:

    d "Hahahahaha."

translate english ch04_acar01_e5345f24:

    d "I totally forgot about that."

translate english ch04_acar01_2b0a8a3f:

    a "By the way, did you go to the orphanage?"

translate english ch04_acar01_38cfc1c8:

    a "Is Mary doing well?"

translate english ch04_acar01_3e829a9c:

    a "Man... I really need to get together with Mary for coffee sometime."

translate english ch04_acar01_973f6d68:

    d "Y-Yeah... I saw her."

translate english ch04_acar01_5e3aec4e:

    d ".........."

translate english ch04_acar01_be9766d0:

    d "Everyone at the orphanage is doing well."

translate english ch04_acar01_c4bdad2d:

    d "Celine's doing well, too."

translate english ch04_acar01_d0bda9fb:

    a "Oh, my sweet Celine."

translate english ch04_acar01_0ec540c5:

    a "I miss her, too."

translate english ch04_acar01_8691fd11:

    d ".................."

translate english ch04_acar01_7873feea:

    d "I had a great time with Mary..."

translate english ch04_acar01_bcecb754:

    a ".........."

translate english ch04_acar01_3169be7c:

    d "Mary always welcomes me with open arms whenever I visit the orphanage."

translate english ch04_acar01_f8e32d4d:

    a "She does..."

translate english ch04_acar01_aae77473:

    a "Mary really is a wonderful person."

translate english ch04_acar01_4c5c5fa2:

    a "If I were the mayor, I'd give her a community service award or something. Seriously. Hahaha."

translate english ch04_acar01_f9ef9187:

    d "Y-Yeah..."

translate english ch04_acar01_77673f80:

    d "........."

translate english ch04_acar01_aafdd044:

    d "I'm planning to visit more often now..."

translate english ch04_acar01_77673f80_1:

    d "........."

translate english ch04_acar01_ee37f13e:

    d "I think Mary would like that too..."

translate english ch04_acar01_0c5d7a66:

    a "I see..."

translate english ch04_acar01_ec487ffd:

    a "I'm glad."

translate english ch04_acar01_b00ad13b:

    a "............."

translate english ch04_acar01_ea8effc0:

    a "You should know how lucky you are!"

translate english ch04_acar01_f9b4991b:

    a "You know what I mean?"

translate english ch04_acar01_8717e6c5:

    a "How many women do you have looking out for you like that? Hahaha."

translate english ch04_acar01_1b0b453e:

    d "Hahaha. I know."

translate english ch04_acar01_e0c7c546:

    d "I think I'm a pretty lucky guy."

translate english ch04_acar01_8daa2297:

    a "That's right. Be grateful."

translate english ch04_acar01_f87037a0:

    a "Anyway, don't spend all your time with Mary. Save some for me too!"

translate english ch04_acar01_d31b0399:

    d "O-Of course. Hehe..."

translate english ch04_acar01_8ceac0c9:

    a "You know what happens when a woman gets jealous, right?"

translate english ch04_acar01_3fd95ed8:

    a "It's a disaster for a small town like this. Hahaha."

translate english ch04_acar01_e6a7463f:

    d "Hahaha. You're the only one for me, Amanda."

translate english ch04_acar01_4f512da1:

    d "I always imagine spending time with you. Hehe..."

translate english ch04_acar01_f8dd4687:

    a "..............."

translate english ch04_acar01_b30bbfe5:

    a "We're getting close to the beach!!!"

translate english ch04_acar01_1204c624:

    d "Yay~~~"

translate english ch04_acar01_9c934a25:

    a "Woohoo~~~"

translate english ch04_beach01_d25ae72a:

    d "Is there anything you want me to carry?"

translate english ch04_beach01_b9302bee:

    a "Just take the beach mat."

translate english ch04_beach01_98540d4c:

    a "I'll carry the rest."

translate english ch04_beach01_04794f26:

    a "Man, it's been forever since I've been to the beach."

translate english ch04_beach01_aa494d04:

    a "This is great. Hehe."

translate english ch04_beach01_b464de45:

    a "Haha!!"

translate english ch04_beach01_13e87647:

    a "Looks like we've got this spot all to ourselves."

translate english ch04_beach01_7d895fad:

    a "It's tucked away behind the grass, so it's a great place to relax."

translate english ch04_beach01_34bc16d8:

    d "Nice spot. Hahaha."

translate english ch04_beach01_90e8cfcd:

    a "Right? Hehe."

translate english ch04_beach01_01b47006:

    a "Oh, by the way, it's a little different from the last time we came here."

translate english ch04_beach01_7761363e:

    d "Different? How?"

translate english ch04_beach01_481fdefd:

    d "Looks the same to me."

translate english ch04_beach01_6dd334c8:

    a "Hahaha."

translate english ch04_beach01_a9e78c9c:

    a "You probably won't notice it right away."

translate english ch04_beach01_7c29bbf0:

    a "Look over there."

translate english ch04_beach01_4b33ec17:

    d "Huh? The sign?"

translate english ch04_beach01_9c9ff00d:

    d "!!!!!!!!!"

translate english ch04_beach01_cf5004f8:

    n "When he looked where Amanda was pointing, he noticed a sign."

translate english ch04_beach01_e7bf5b26:

    n "It informed visitors that nudity was permitted in this area."

translate english ch04_beach01_1788beff:

    d "Wait... since when did this happen??"

translate english ch04_beach01_07663fc4:

    d "No way..."

translate english ch04_beach01_8fdbc629:

    d "Does it start past that sign?"

translate english ch04_beach01_fd85a45b:

    d "Or... does it mean this side too?"

translate english ch04_beach01_ddfe2bfa:

    a "I have no idea."

translate english ch04_beach01_c904f424:

    a "Does it really matter?"

translate english ch04_beach01_a19b5268:

    a "The rules are the rules. Hahaha."

translate english ch04_beach01_b718ae38:

    a "I'm just telling you so you don't stand there looking around with your eyes popping out like a tourist."

translate english ch04_beach01_a47d07a5:

    d "Hahaha."

translate english ch04_beach01_c1122ea4:

    d "Don't worry."

translate english ch04_beach01_f2f806c3:

    d "I'm good at playing it cool."

translate english ch04_beach01_73f2de66:

    a "Hahaha. I know."

translate english ch04_beach01_db93d1b9:

    a "By the way..."

translate english ch04_beach01_b0c96f01:

    a "How's that thing we talked about the other day coming along?"

translate english ch04_beach01_a5750075:

    a "You remember, don't you?"

translate english ch04_beach01_e632c6d2:

    d "What thing?"

translate english ch04_beach01_7c7e58c4:

    a "I told you to start working out."

translate english ch04_beach01_0c794b7f:

    a "Don't tell me you already forgot."

translate english ch04_beach01_7cb43e52:

    a "Especially your legs."

translate english ch04_beach01_07300d47:

    d "I remember..."

translate english ch04_beach01_8d9fcc1c:

    a "Eating well is important, but exercising is just as important."

translate english ch04_beach01_6376e817:

    a "If you don't take care of yourself, you could end up looking like Frank."

translate english ch04_beach01_8aee64a9:

    d "I haven't actually started yet."

translate english ch04_beach01_3b851017:

    d "For now, I've just been swimming in the backyard at my boarding house."

translate english ch04_beach01_bc3743b9:

    d "My landlady works out too, so I was thinking maybe we'd do it together."

translate english ch04_beach01_33711ea3:

    a "That's a great idea."

translate english ch04_beach01_57914546:

    a "Exercise is something you should do for the rest of your life."

translate english ch04_beach01_f9d69f03:

    a "Remember?"

translate english ch04_beach01_a797f6ce:

    d "............."

translate english ch04_beach01_57a484f1:

    a "Hahaha. You need a strong lower body if you want to pull off all kinds of positions."

translate english ch04_beach01_77673f80:

    d "........."

translate english ch04_beach01_b2eefa43:

    d "Yeah..."

translate english ch04_beach01_a797f6ce_1:

    d "............."

translate english ch04_beach01_bd603212:

    d "Of course I remember. Hehe."

translate english ch04_beach01_9c1f285e:

    d "I remind myself every single day."

translate english ch04_beach01_eea97683:

    a "How's your landlady?"

translate english ch04_beach01_95d6bf8f:

    a "Now that you've been living with her, what's she like?"

translate english ch04_beach01_ed15085e:

    d "She's a good person."

translate english ch04_beach01_66baf43f:

    d "I was worried she'd only see me as someone paying rent,"

translate english ch04_beach01_fb846cbe:

    d "but she's treated me like an actual person and looked out for me."

translate english ch04_beach01_bc638e2b:

    d "She even cooks for me sometimes."

translate english ch04_beach01_7e67be40:

    d "She's just naturally cool."

translate english ch04_beach01_9a2cca49:

    a "That's good to hear."

translate english ch04_beach01_a778383b:

    a "There are a lot of strange people out there these days, so you have to be careful."

translate english ch04_beach01_fff1b15e:

    a "Some psychopaths don't show their true colors until the worst possible moment."

translate english ch04_beach01_471380dd:

    a "There are also women out there who are desperate to prey on young guys."

translate english ch04_beach01_8e03f73c:

    d "Yeah, I know what you mean."

translate english ch04_beach01_5bd78c24:

    d "You've repeated that so many times it's burned into my brain, Amanda. Hahaha."

translate english ch04_beach01_cfbd1223:

    d "Stay away from dangerous people and avoid dangerous situations whenever you can."

translate english ch04_beach01_7aa60de2:

    d "But if you ever find yourself in one, getting out as fast as possible is the only way to protect yourself."

translate english ch04_beach01_76db92cf:

    d "The places you go and the people you surround yourself with will ultimately shape the course of your life."

translate english ch04_beach01_9f933812:

    a "Good."

translate english ch04_beach01_45ab9424:

    a "You remembered."

translate english ch04_beach01_9437cd7c:

    a "Makes all my nagging worth it. I'm proud of you."

translate english ch04_beach01_a79822de:

    a "........"

translate english ch04_beach01_7c358d93:

    a "But add one more thing to that list."

translate english ch04_beach01_e070eb5e:

    d "Seriously?"

translate english ch04_beach01_76e8e07a:

    d "I'm already trying to remember all that. What else?"

translate english ch04_beach01_aa1ecb3c:

    a "A man needs strong legs."

translate english ch04_beach01_2f564115:

    d "Hahaha. Got it."

translate english ch04_beach01_399db8e5:

    a "............"

translate english ch04_beach01_2dfba86d:

    d "Holy shit..."

translate english ch04_beach01_77673f80_1:

    d "........."

translate english ch04_beach01_6f664c43:

    unknownm "Well, well..."

translate english ch04_beach01_2d1154d2:

    unknownm "Hey, you two!"

translate english ch04_beach01_3a00b8de:

    unknownm "This is a nude beach. Why are you still wearing clothes?"

translate english ch04_beach01_061f725a:

    unknownm "Hahahahaha."

translate english ch04_beach01_942af8c5:

    unknownm "Don't you know you're the odd one out if you're wearing clothes here?"

translate english ch04_beach01_0f0d6d08:

    unknownf "Hey, lady!"

translate english ch04_beach01_652864df:

    unknownf "You look so uncomfortable. Why not just take it all off?"

translate english ch04_beach01_f4c08601:

    unknownf "I mean, you're practically naked already. So why bother wearing those tacky rags?"

translate english ch04_beach01_fbb69263:

    unknownm "Hahahaha."

translate english ch04_beach01_c529ba88:

    unknownf "You brought your little pet along, and now you're the one feeling shy? Hahaha."

translate english ch04_beach01_fbb69263_1:

    unknownm "Hahahaha."

translate english ch04_beach01_ac48d631:

    a "*sigh...*"

translate english ch04_beach01_3b0307ee:

    a "That's not what's going on, so why don't you all move along?"

translate english ch04_beach01_4ac4d0a8:

    a "Quit picking on people who are just minding their own business."

translate english ch04_beach01_f8e0b6c3:

    unknownm "Then give us your spot if you're not gonna strip."

translate english ch04_beach01_a3f48074:

    unknownm "It's rude to take up space in the nude section while you're still wearing clothes."

translate english ch04_beach01_0b178d40:

    unknownm "That spot was ours."

translate english ch04_beach01_120f2c5d:

    a "*Sigh...*"

translate english ch04_beach01_91711331:

    unknownf "If you're so embarrassed by that washed-up old-lady body of yours, head down to the other end of the beach."

translate english ch04_beach01_d3041704:

    unknownf "There are plenty of old ladies like you down there."

translate english ch04_beach01_480ffc5e:

    unknownf "So what are you doing here? Hahaha."

translate english ch04_beach01_e3295fcb:

    d "Hey!!"

translate english ch04_beach01_c85fb10b:

    d "Shut the fuck up and get the hell out of here."

translate english ch04_beach01_e97a3c6b:

    a "If I took everything off, every man around here would lose his damn mind."

translate english ch04_beach01_ada386f9:

    a "That's why I'm hiding out here—I'm doing you little brats a favor."

translate english ch04_beach01_7119e702:

    unknownf "Keep dreaming, lady!!"

translate english ch04_beach01_e81a5035:

    unknownf "How pathetic!!"

translate english ch04_beach01_6dd334c8_1:

    a "Hahaha."

translate english ch04_beach01_2a7f029a:

    a "I knew it."

translate english ch04_beach01_f4cda87e:

    unknownf ".............."

translate english ch04_beach01_9d45f683:

    a "Alright, kids. Go play somewhere else."

translate english ch04_beach01_4f071893:

    a "That's right. Off you go."

translate english ch04_beach01_0aca6439:

    d "Shit... Amanda."

translate english ch04_beach01_39f8159b:

    n "On the quiet beach, Amanda and [d_name] soaked up the warm sunshine."

translate english ch04_beach01_a3424610:

    n "The two of them lay side by side, completely naked."

translate english ch04_beach01_5d295332:

    a "Honey."

translate english ch04_beach01_8096b08a:

    d "Yeah?"

translate english ch04_beach01_78428991:

    a "Put some sunscreen on me."

translate english ch04_beach01_33bf8f25:

    d "Sure."

translate english ch04_beach01_33219091:

    d "On your whole body?"

translate english ch04_beach01_4bed42c6:

    a "Of course."

translate english ch04_beach01_fc04074c:

    a "Make sure you get every inch."

translate english ch04_beach01_1494a0b2:

    d "Every inch...?"

translate english ch04_beach01_782bbec9:

    a "Mm-hmm. Every single inch."

translate english ch04_beach01_5bd1213c:

    a "Just because we're naked doesn't mean we have anything to be embarrassed about, right?"

translate english ch04_beach01_0d0bdb21:

    d "Hahaha. Why would I be embarrassed?"

translate english ch04_beach01_00bd87f4:

    d "Besides, we've already seen everything there is to see."

translate english ch04_beach01_b599415b:

    a "What's that supposed to mean?"

translate english ch04_beach01_67b97104:

    a "You only got a quick peek, that's all."

translate english ch04_beach01_8e2366de:

    d "Haha. Is that so?"

translate english ch04_beach01_485579d3:

    d "Anyway, I'll make sure to cover every inch."

translate english ch04_beach01_b5d4c38e:

    a "Haha. Good."

translate english ch04_beach01_3819fcc2:

    d "**(Damn......)**"

translate english ch04_beach01_7ac64a8d:

    d "**(Even if she's comfortable around me, isn't she way too defenseless?)**"

translate english ch04_beach01_2e9c6444:

    d "**(.......)**"

translate english strings:
    old "팔에 썬크림을 바른다."
    new "Apply sunscreen to her arms."

translate english strings:
    old "다리에 썬크림을 바른다."
    new "Apply sunscreen to her legs."

translate english strings:
    old "허리와 등에 썬크림을 바른다."
    new "Apply sunscreen to her waist and back."

translate english ch04_beach01_3ecc798d:

    d "You know something?"

translate english ch04_beach01_ebb7583f:

    a "Hmm? What's that?"

translate english ch04_beach01_a55b91c3:

    d "Your skin is really soft, Amanda."

translate english ch04_beach01_a79822de_1:

    a "........"

translate english ch04_beach01_d3617b77:

    d "Touching it makes me feel so good. Hehehe."

translate english ch04_beach01_6dd334c8_2:

    a "Hahaha."

translate english ch04_beach01_eb0b5f9a:

    a "You're only just noticing?"

translate english ch04_beach01_77673f80_2:

    d "........."

translate english ch04_beach01_27f5d046:

    d "Just saying. Hehehe."

translate english ch04_beach01_a550f931:

    a "How old do you think I am? You're telling me my skin's soft?"

translate english ch04_beach01_ac41558c:

    d "I'm serious."

translate english ch04_beach01_31ad7c36:

    a "Then go ahead and touch all you want, mister."

translate english ch04_beach01_f20b79ae:

    d "Yes, ma'am."

translate english ch04_beach01_f1fbe893:

    a "Hahaha. Stop it, that's so cheesy!!"

translate english ch04_beach01_a47d07a5_1:

    d "Hahaha."

translate english ch04_beach01_77673f80_3:

    d "........."

translate english ch04_beach01_77a214b8:

    a "..........."

translate english ch04_beach01_08c2d9cd:

    n "[d_name] gently ran his hand along her arm."

translate english ch04_beach01_bd40026f:

    n "She quietly savored the feel of his hand."

translate english ch04_beach01_073a77a0:

    n "His touch was gentle, yet unmistakably masculine."

translate english ch04_beach01_8d033efe:

    n "The feel of his hands stirred a quiet sense of arousal within Amanda."

translate english ch04_beach01_ada46b53:

    a "Mmm... that feels nice..."

translate english ch04_beach01_a79822de_2:

    a "........"

translate english ch04_beach01_5f192600:

    a "I wish Frank were as sweet as you."

translate english ch04_beach01_a79822de_3:

    a "........"

translate english ch04_beach01_f30c3d25:

    a "Damn you, Frank..."

translate english ch04_beach01_ad893dfa:

    d "......"

translate english ch04_beach01_fac8215b:

    d "............"

translate english ch04_beach01_55c02367:

    a "......."

translate english ch04_beach01_ab689ed6:

    d "I'm sorry, Amanda."

translate english ch04_beach01_1b5f855a:

    a "Hmm? For what?"

translate english ch04_beach01_203cc60b:

    d "......."

translate english ch04_beach01_15c0ecdc:

    d "About Frank."

translate english ch04_beach01_b2b821d1:

    a "........."

translate english ch04_beach01_8391bcfc:

    a "What do you have to be sorry for?"

translate english ch04_beach01_66d04053:

    d "I don't know...That's just how I feel."

translate english ch04_beach01_5e3aec4e:

    d ".........."

translate english ch04_beach01_114a1a6d:

    d "You deserve to be treated so much better, Amanda."

translate english ch04_beach01_bcecb754:

    a ".........."

translate english ch04_beach01_c7dcfe5d:

    a "It's okay. I'll kill him when the time comes."

translate english ch04_beach01_a47d07a5_2:

    d "Hahaha."

translate english ch04_beach01_c361ff08:

    d "I'll do your legs now."

translate english ch04_beach01_56dcbb93:

    a "Mmm."

translate english ch04_beach01_44a92def:

    d "Damn..."

translate english ch04_beach01_4f8e8a09:

    a "What was that?"

translate english ch04_beach01_91595bac:

    d "**(Damn, I said it out loud.)**"

translate english ch04_beach01_ba69871a:

    d "O-Oh, it was nothing."

translate english ch04_beach01_bcecb754_1:

    a ".........."

translate english ch04_beach01_c985be96:

    a "Why? Is there something you want to say?"

translate english ch04_beach01_8096b08a_1:

    d "Huh?"

translate english ch04_beach01_8fdcbbe5:

    d "Oh, I just got lost in thought for a second."

translate english ch04_beach01_4a65d3af:

    a "What was so important that you zoned out while putting sunscreen on me?"

translate english ch04_beach01_cfce39d4:

    a "You're silly..."

translate english ch04_beach01_5848a275:

    a "If you've got something to say, just say it."

translate english ch04_beach01_a2f4e746:

    a "There's nothing we can't talk about, right?"

translate english ch04_beach01_5e3aec4e_1:

    d ".........."

translate english ch04_beach01_715ec16f:

    d "It's just..."

translate english ch04_beach01_1b919829:

    d "Aren't you embarrassed, showing me... everything like this?"

translate english ch04_beach01_dbdab605:

    a "What?"

translate english ch04_beach01_a4d72727:

    a "What do you mean by that?"

translate english ch04_beach01_645e561c:

    a "What exactly am I showing you?"

translate english ch04_beach01_3db3db55:

    d "Well... it's just..."

translate english ch04_beach01_fac8215b_1:

    d "............"

translate english ch04_beach01_f14b1108:

    d "Amanda... your... um... private parts are just completely out in the open."

translate english ch04_beach01_94a5a67e:

    a "What are you talking about?"

translate english ch04_beach01_66560ab2:

    a "My pussy?"

translate english ch04_beach01_270a9675:

    d "Huh?!"

translate english ch04_beach01_6dd334c8_3:

    a "Hahaha."

translate english ch04_beach01_cc5dea64:

    d "Holy shit, Amanda..."

translate english ch04_beach01_ed40e002:

    a "What? Did you forget how to speak English?"

translate english ch04_beach01_159a873f:

    a "Why are you dancing around it instead of just saying the word?"

translate english ch04_beach01_399db8e5_1:

    a "............"

translate english ch04_beach01_d23c85f0:

    a "Besides, I've seen yours, and you've seen mine."

translate english ch04_beach01_125bf6ec:

    a "Are you trying to ask why I got naked at a nude beach? Hahaha."

translate english ch04_beach01_2bfcaf5c:

    d "N-No, that's not it..."

translate english ch04_beach01_218de310:

    d "What I meant was..."

translate english ch04_beach01_6751e7ec:

    a "Okay, honey. Let's make a deal."

translate english ch04_beach01_83e36af6:

    a "From this moment on, no more hemming and hawing. Just say what you want to say, okay?"

translate english ch04_beach01_71464ac1:

    a "It's good to be careful, but if you make a habit of talking like that, every woman you meet will end up running away."

translate english ch04_beach01_4d654e85:

    n "Hearing Amanda say that reminded him of something Rose had said earlier that morning."

translate english ch04_beach01_7104df9b:

    n "Rose had told him that something was holding him back, like a bird trapped inside its shell."

translate english ch04_beach01_f140d844:

    n "He couldn't help but think Amanda's words about him always hemming and hawing meant exactly the same thing."

translate english ch04_beach01_a797f6ce_2:

    d "............."

translate english ch04_beach01_9e2fc164:

    n "Amanda's words once again struck at his pride."

translate english ch04_beach01_b9343047:

    d "Alright, Amanda."

translate english strings:
    old "여기서 보는 풍경이 죽이네요."
    new "The view from here is incredible."

translate english strings:
    old "아만다 보지 이쁘네요."
    new "Amanda, your pussy looks beautiful."

translate english ch04_beach01_b3713e73:

    d "The view from here is incredible."

translate english ch04_beach01_b2b821d1_1:

    a "........."

translate english ch04_beach01_37fad21b:

    d "Amanda, your pussy is beautiful."

translate english ch04_beach01_11592464:

    a "........."

translate english ch04_beach01_4c30816e:

    d "Y-you told me to just say what I want to say."

translate english ch04_beach01_732a8756:

    a "......"

translate english ch04_beach01_d2136995:

    a "Hey!"

translate english ch04_beach01_9d4c6e8b:

    a "That wasn't funny at all."

translate english ch04_beach01_a47d07a5_3:

    d "Hahaha."

translate english ch04_beach01_fae3ccb4:

    d "It was the perfect place to set the sunscreen."

translate english ch04_beach01_50d6ecb1:

    d "Amanda, your butt crack was just the perfect little shelf for it."

translate english ch04_beach01_6d5f0463:

    a "So you've decided to challenge the Goddess of Pranks?"

translate english ch04_beach01_292e77b2:

    a "I'll get you back before the day's over. You'd better be ready."

translate english ch04_beach01_e5c36b54:

    d "..........."

translate english ch04_beach01_b954178d:

    d "By the way, Amanda..."

translate english ch04_beach01_78686024:

    a "Yeah, honey?"

translate english ch04_beach01_5e3aec4e_2:

    d ".........."

translate english ch04_beach01_ba062626:

    d "About that day in the shower..."

translate english ch04_beach01_55c02367_1:

    a "......."

translate english ch04_beach01_8305c21a:

    a "The day you came over?"

translate english ch04_beach01_a9c2cc01:

    d "Yeah... when we showered together."

translate english ch04_beach01_869a6046:

    a "Mm-hmm. What about it?"

translate english ch04_beach01_5e3aec4e_3:

    d ".........."

translate english ch04_beach01_26f47ab6:

    d "Um..."

translate english ch04_beach01_682d6f43:

    a "Just say it."

translate english ch04_beach01_23234597:

    a "Just don't be vulgar about it."

translate english ch04_beach01_6c6dfe21:

    d "...Alright!!"

translate english ch04_beach01_e7175f47:

    d "You saw my dick that day."

translate english ch04_beach01_edbb7d05:

    d "........"

translate english ch04_beach01_33b4e389:

    d "Up close."

translate english ch04_beach01_bcecb754_2:

    a ".........."

translate english ch04_beach01_37978346:

    d "What were you thinking?"

translate english ch04_beach01_5e3aec4e_4:

    d ".........."

translate english ch04_beach01_bcecb754_3:

    a ".........."

translate english ch04_beach01_429c3744:

    a "Hmm... all kinds of things."

translate english ch04_beach01_9b66ff6b:

    a "Confusion..."

translate english ch04_beach01_13c87170:

    a "Embarrassment..."

translate english ch04_beach01_b0e5ce85:

    a "Shock..."

translate english ch04_beach01_e2e48347:

    a "A bit of pride? Things like that."

translate english ch04_beach01_edbb7d05_1:

    d "........"

translate english ch04_beach01_c553c61d:

    d "Didn't it turn you on?"

translate english ch04_beach01_dbdab605_1:

    a "What?"

translate english ch04_beach01_17b34edf:

    d "You know..."

translate english ch04_beach01_23b89b50:

    d "When I had an erection right in front of you..."

translate english ch04_beach01_bd242a42:

    d "I mean, I was fully hard..."

translate english ch04_beach01_bcecb754_4:

    a ".........."

translate english ch04_beach01_105a9a87:

    d "I was incredibly embarrassed..."

translate english ch04_beach01_e5c36b54_1:

    d "..........."

translate english ch04_beach01_059f7bea:

    a "Embarrassed, but what?"

translate english ch04_beach01_4c051ee4:

    d "To be honest... it turned me on a little too..."

translate english ch04_beach01_bcecb754_5:

    a ".........."

translate english ch04_beach01_31c24273:

    d "We've always been pretty comfortable around each other,"

translate english ch04_beach01_e7bd6738:

    d "but that was the first time we'd both been completely naked... and I'd gotten hard in front of you."

translate english ch04_beach01_e5c36b54_2:

    d "..........."

translate english ch04_beach01_35a23d27:

    d "Right in front of your face..."

translate english ch04_beach01_ff4da4a8:

    d "And... I think I started having some dirty thoughts..."

translate english ch04_beach01_edbb7d05_2:

    d "........"

translate english ch04_beach01_182930f3:

    d "I'm sorry, Amanda..."

translate english ch04_beach01_cd439ff6:

    d "I didn't want to hide it from you..."

translate english ch04_beach01_4cd15d58:

    d "....."

translate english ch04_beach01_3d843283:

    d "Lately... no, all day long...it feels like sex is the only thing on my mind."

translate english ch04_beach01_bcecb754_6:

    a ".........."

translate english ch04_beach01_f98dc5a5:

    d "I'm sorry..."

translate english ch04_beach01_31d796dc:

    a "...."

translate english ch04_beach01_2d360470:

    a "Yeah..."

translate english ch04_beach01_b2b821d1_2:

    a "........."

translate english strings:
    old "엉덩이에 썬크림을 바른다."
    new "Apply sunscreen to her butt."

translate english ch04_beach01_b0450d16:

    d "**(Damn....)**"

translate english ch04_beach01_4f52b0b1:

    d "**(............)**"

translate english ch04_beach01_97d9d1eb:

    d "**(Isn't she embarrassed being in a position like this?)**"

translate english ch04_beach01_0411797d:

    d "**(......)**"

translate english ch04_beach01_9c1fa20d:

    d "**(At this point... is she doing this on purpose so I'll look?...)**"

translate english ch04_beach01_3f5a2cff:

    d "**(No, that's not what I mean...)**"

translate english ch04_beach01_3c7a7f55:

    d "**(...........)**"

translate english ch04_beach01_e054fb54:

    d "**(Maybe this is how she satisfies her urges... by showing off her body like this?....)**"

translate english ch04_beach01_a0b933a9:

    d "**(Damn...........)**"

translate english ch04_beach01_952639d0:

    d "**(She keeps telling me to work on my lower body...)**"

translate english ch04_beach01_4552a5bf:

    d "**(Could she have another reason for saying that?.....)**"

translate english ch04_beach01_66fb2612:

    a "All done?"

translate english ch04_beach01_5fd9466e:

    a "Should I roll over now?"

translate english ch04_beach01_af6b7766:

    d "Hang on a second."

translate english ch04_beach01_9b44f11a:

    d "I haven't done your butt yet."

translate english ch04_beach01_80fadbd6:

    a "Ooh..."

translate english ch04_beach01_4c9f3a43:

    a "You're so thorough. Hehe."

translate english ch04_beach01_1fcec4b2:

    d "Can't skip your butt, that'd be a shame."

translate english ch04_beach01_77673f80_4:

    d "........."

translate english ch04_beach01_9dfaa1b3:

    a "Mmm.........."

translate english ch04_beach01_e0002d21:

    a "That feels nice..."

translate english ch04_beach01_3819fcc2_1:

    d "**(Damn......)**"

translate english ch04_beach01_468af07f:

    d "**(I want to bury my face in it..)**"

translate english ch04_beach01_be78b6de:

    d "**(I want to taste Amanda's body..)**"

translate english ch04_beach01_b3beae20:

    d "**(Maybe she'd actually let me?..)**"

translate english ch04_beach01_6058ecae:

    d "**(.........)**"

translate english ch04_beach01_b7e200fa:

    d "**(What the hell is wrong with you?..)**"

translate english ch04_beach01_fac8215b_2:

    d "............"

translate english ch04_beach01_6ac59204:

    d "Should I put more on your butt?"

translate english ch04_beach01_56dcbb93_1:

    a "Mmm."

translate english ch04_beach01_d882ef96:

    a "Whatever you think is best, mister."

translate english ch04_beach01_c07042ee:

    n "He continued rubbing sunscreen onto Amanda's butt."

translate english ch04_beach01_c23ef8de:

    n "Little by little, his thumb drifted closer to her anus."

translate english ch04_beach01_85530955:

    d "**(Damn, damn, damn!!)**"

translate english ch04_beach01_7462f18c:

    d "**(Maybe I should just try it?)**"

translate english ch04_beach01_0411797d_1:

    d "**(......)**"

translate english ch04_beach01_ac58ed0c:

    d "**(If Amanda gets mad, I'll just say it was an accident.)**"

translate english ch04_beach01_65caea5a:

    d "**(That my hand slipped and my face ended up there.)**"

translate english ch04_beach01_12c2961a:

    n "He began brushing his fingers around Amanda's anus."

translate english ch04_beach01_81e83124:

    n "He wanted to find out where Amanda's line was."

translate english ch04_beach01_af3ecb22:

    n "Then his fingers began tracing the boundary of her most intimate place."

translate english ch04_beach01_6dc2aef3:

    d "**(Shit....)**"

translate english ch04_beach01_079c930e:

    d "**(Amanda's pussy is wet.)**"

translate english ch04_beach01_6a35637c:

    d "**(She's wet because I touched her....)**"

translate english ch04_beach01_4f52b0b1_1:

    d "**(............)**"

translate english ch04_beach01_7aff5c18:

    d "**(She wants me to do something... doesn't she?)**"

translate english ch04_beach01_b2b821d1_3:

    a "........."

translate english ch04_beach01_763558e5:

    a "**(What's he doing?)**"

translate english ch04_beach01_d63fc03e:

    a "**(He's not putting sunscreen on anymore...)**"

translate english ch04_beach01_77a214b8_1:

    a "..........."

translate english ch04_beach01_7a733fba:

    a "Honey..."

translate english ch04_beach01_8096b08a_2:

    d "Yeah?"

translate english ch04_beach01_657d84eb:

    a "What are you doing?"

translate english ch04_beach01_c917c556:

    a "That's not how you put sunscreen on."

translate english ch04_beach01_bcecb754_7:

    a ".........."

translate english ch04_beach01_0f4950fd:

    a "Just because you want to touch it doesn't mean you can, does it?"

translate english ch04_beach01_7e5d6521:

    d "I'm sorry, Amanda."

translate english ch04_beach01_edbb7d05_3:

    d "........"

translate english ch04_beach01_8dfb9e0a:

    d "I just..."

translate english ch04_beach01_f655bade:

    d "got carried away trying to make sure I covered everything."

translate english ch04_beach01_8832dad9:

    a "Hahahahaha."

translate english ch04_beach01_aaa4102f:

    a "I'm kidding."

translate english ch04_beach01_9f384fb4:

    d "Huh??"

translate english ch04_beach01_d8f7d4b0:

    a "Go ahead. Do whatever you want."

translate english ch04_beach01_684f0705:

    a "It's not like it'll wear out from being touched. Why not?"

translate english ch04_beach01_fbb33f9c:

    d "**(Do whatever I want??)**"

translate english ch04_beach01_3c7a7f55_1:

    d "**(...........)**"

translate english ch04_beach01_4721cff9:

    d "**(Does she literally mean whatever I want?...)**"

translate english ch04_beach01_2e9c6444_1:

    d "**(.......)**"

translate english ch04_beach01_4596c9f7:

    d "**(Alright then....)**"

translate english strings:
    old "그녀의 똥구멍을 활짝 벌린다."
    new "Spread her anus wide."

translate english ch04_beach01_92f21ed5:

    n ""

translate english ch04_beach01_3c4c9727:

    a "What do you think you're doing? Huh?"

translate english ch04_beach01_7021d613:

    d "I..."

translate english ch04_beach01_98ab8ba1:

    d "You told me to do whatever I wanted..."

translate english ch04_beach01_645cd9ec:

    a "**(............)**"

translate english ch04_beach01_98b41fa0:

    a "**(What's gotten into him...? )**"

translate english ch04_beach01_a366f88d:

    a "**(Phew.....)**"

translate english ch04_beach01_4517a189:

    a "Thanks, honey."

translate english ch04_beach01_fff104d8:

    a "Good job."

translate english ch04_beach01_aefae3b1:

    a "Now let's get the front, too. Hehe."

translate english ch04_beach01_a529f973:

    a "Huh?"

translate english ch04_beach01_0ef3a6d0:

    a "....."

translate english ch04_beach01_ca008ebc:

    n "When she rolled onto her back, [d_name] was standing before her with another erection."

translate english ch04_beach01_3132aa03:

    n "This time, she found herself studying his penis even more closely than she had before."

translate english ch04_beach01_23eb7a9d:

    a "**(My God, [d_name].....)**"

translate english ch04_beach01_399db8e5_2:

    a "............"

translate english ch04_beach01_1eb84911:

    a "Hey, you..."

translate english ch04_beach01_2da63710:

    a "Don't you get hard a little too easily?"

translate english ch04_beach01_0e97cca3:

    d "What can I do...?"

translate english ch04_beach01_19acb535:

    d "It's not like I can stop it."

translate english ch04_beach01_ad893dfa_1:

    d "......"

translate english ch04_beach01_dad04217:

    d "It's because you're too sexy, Amanda. Hahaha."

translate english ch04_beach01_b00ad13b:

    a "............."

translate english ch04_beach01_64ea3c3f:

    a "Even so..."

translate english ch04_beach01_52fd5c58:

    d "Don't get me wrong."

translate english ch04_beach01_0d44605d:

    d "I'm just being completely honest, like you told me to."

translate english ch04_beach01_c08031bd:

    d "To be honest... I've gotten hard thinking about you a lot."

translate english ch04_beach01_dbdab605_2:

    a "What?"

translate english ch04_beach01_e080b790:

    a "You've gotten hard thinking about me?"

translate english ch04_beach01_6225b646:

    d "Yeah."

translate english ch04_beach01_3774519e:

    d "Did that shock you? Hahaha."

translate english ch04_beach01_b2b821d1_4:

    a "........."

translate english ch04_beach01_5add4b05:

    d "I've even imagined having sex with you."

translate english ch04_beach01_9b0b4e54:

    a "!!!!!!!!!!!"

translate english ch04_beach01_c046f4b0:

    a "You've imagined having sex with me?!!!!!!"

translate english ch04_beach01_b1f04730:

    a "My God, [d_name]..."

translate english ch04_beach01_17659cc8:

    a ".............."

translate english ch04_beach01_54341d36:

    a "How could you even think something like that...?"

translate english ch04_beach01_038d772e:

    d "Hey, don't take it so seriously..."

translate english ch04_beach01_2c6fafbe:

    d "It's just..."

translate english ch04_beach01_eddc22d2:

    d "Guys have all kinds of stupid fantasies when they jerk off. Hahaha."

translate english ch04_beach01_4a55d9d6:

    d "I'm sorry if that shocked you, Amanda..."

translate english ch04_beach01_a095720c:

    d "Was I a little too honest? Hahaha."

translate english ch04_beach01_03eacd22:

    a "Y-You fantasize about having sex with me??"

translate english ch04_beach01_399db8e5_3:

    a "............"

translate english ch04_beach01_ca232bb7:

    d "**(Damn... maybe I shouldn't have said that....)**"

translate english ch04_beach01_12ae0042:

    d "**(I think things just got really awkward...)**"

translate english ch04_beach01_f9a2e782:

    a "You..."

translate english ch04_beach01_1aa41c1e:

    a "You jerk off thinking about me?"

translate english ch04_beach01_2ff7a5ee:

    a "How could you say something like that to me...?"

translate english ch04_beach01_44a92def_1:

    d "Damn..."

translate english ch04_beach01_d102715e:

    d "I'm sorry, Amanda..."

translate english ch04_beach01_5bc8587e:

    a "Hahahahahahahaha."

translate english ch04_beach01_cc294f4b:

    a "I'm kidding, I'm kidding."

translate english ch04_beach01_25798e07:

    a "You fell for it again? Hahahaha."

translate english ch04_beach01_6e8176a9:

    a "Come on, isn't that perfectly normal for a young guy?"

translate english ch04_beach01_549bdb25:

    a "You're free to fantasize about whatever you want. Who am I to judge?"

translate english ch04_beach01_884e5819:

    a "Katie told me her son used to sniff her panties while jerking off. Hahaha."

translate english ch04_beach01_855d0392:

    a "It's all part of growing up."

translate english ch04_beach01_9d765d7b:

    d "So... have you ever imagined having sex with me?"

translate english ch04_beach01_dbdab605_3:

    a "What?"

translate english ch04_beach01_48a3b32f:

    d "I mean..."

translate english ch04_beach01_e804f19c:

    d "My cock?"

translate english ch04_beach01_63be2abf:

    a "My God, honey..."

translate english ch04_beach01_a882ec2d:

    a "What kind of crazy question is that?"

translate english ch04_beach01_9468afa5:

    d "Have you?"

translate english ch04_beach01_bcecb754_8:

    a ".........."

translate english ch04_beach01_f8dd4687:

    a "..............."

translate english ch04_beach01_81e911ee:

    a "I mean... yeah."

translate english ch04_beach01_bd476c0d:

    a "No, what I meant is..."

translate english ch04_beach01_bcecb754_9:

    a ".........."

translate english ch04_beach01_e59c8a3c:

    a "I've imagined having sex with you too."

translate english ch04_beach01_bcecb754_10:

    a ".........."

translate english ch04_beach01_3f45706f:

    a "Just as a fantasy..."

translate english ch04_beach01_16735d00:

    a "!!!!!!!"

translate english ch04_beach01_970c3751:

    a "What are you doing?!!!"

translate english ch04_beach01_a79822de_4:

    a "........"

translate english ch04_beach01_4e19fcf0:

    d "Can we just stay like this for a minute? Hehe."

translate english ch04_beach01_38b6a806:

    d "Ah.........."

translate english ch04_beach01_f9590636:

    d "Holding you just feels so good, Amanda..."

translate english ch04_beach01_a79822de_5:

    a "........"

translate english ch04_beach01_3edd41dc:

    a "You're crazy, you know that?"

translate english ch04_beach01_a47d07a5_4:

    d "Hahaha."

translate english ch04_beach01_3754cb7d:

    a "You little psycho."

translate english ch04_beach01_a4de80f2:

    a "**(Sigh........)**"

translate english ch04_beach01_f424c17b:

    a "**(This is what I've been needing.....)**"

translate english ch04_beach01_dadd8b06:

    a "**(...........)**"

translate english ch04_beach01_882634e7:

    a "**(Amanda, you dirty woman... get a grip..)**"

translate english ch04_beach01_43ca864b:

    unknownm "Hey, you two!!"

translate english ch04_beach01_704451b0:

    d "Huh?"

translate english ch04_beach01_ba905c87:

    unknownm "Well, well..."

translate english ch04_beach01_de9037ec:

    unknownm "Looks like we've got a youngster here."

translate english ch04_beach01_3ab34b27:

    unknownm "Aww~~ baby~~~"

translate english ch04_beach01_427740d3:

    unknownm "So, how's my cock taste?"

translate english ch04_beach01_01f2c782:

    unknownm "Pretty exciting fucking outdoors, huh?"

translate english ch04_beach01_57fa12a8:

    unknownf "Hahahaha. Stop it!!"

translate english ch04_beach01_67316903:

    unknownm "Sorry for interrupting."

translate english ch04_beach01_d86513b9:

    unknownm "Good luck."

translate english ch04_beach01_101a8740:

    unknownf "Hahaha."

translate english ch04_beach01_518ab0f8:

    a "It's hot. Get off me. Haha."

translate english ch04_beach01_3d88a30f:

    a "**(Mmm...)**"

translate english ch04_beach01_a111d0fd:

    a "Haha... *cough*..."

translate english ch04_beach01_6c6c18df:

    a "Would you finish putting it on for me, you little pervert?"

translate english ch04_beach01_37d6c85c:

    d "Yes, ma'am. The local pervert is on the job."

translate english ch04_beach01_6dd334c8_4:

    a "Hahaha."

translate english ch04_beach01_11194fd3:

    a "Damn it, now that you put it that way, I'm suddenly self-conscious!!"

translate english ch04_beach01_c294af99:

    d "Um..."

translate english ch04_beach01_3d8b161a:

    d "Did you wax?"

translate english ch04_beach01_77a214b8_2:

    a "..........."

translate english ch04_beach01_e4277247:

    a "Yes, I did, sir."

translate english ch04_beach01_50642672:

    a "I got waxed because I wanted to wear a bikini."

translate english ch04_beach01_fab576ab:

    d "I... see."

translate english ch04_beach01_0336a4ec:

    a "Why do you ask?"

translate english ch04_beach01_435fa4c7:

    d "Personally, I like a full bush. Hahaha."

translate english ch04_beach01_20674564:

    a "Really?"

translate english ch04_beach01_c90c635b:

    d "I don't know... it just feels sexier."

translate english ch04_beach01_4cd43140:

    d "Seeing it all out there in its natural state. Hahaha."

translate english ch04_beach01_8f541114:

    d "More primal, you know?"

translate english ch04_beach01_bcecb754_11:

    a ".........."

translate english ch04_beach01_e66cd4f5:

    a "So that's your type, huh?"

translate english ch04_beach01_21cb352e:

    d "Um..."

translate english ch04_beach01_bcecb754_12:

    a ".........."

translate english ch04_beach01_0f374142:

    a "Honey... just say it."

translate english ch04_beach01_a6fecba6:

    a "Hesitate one more time, and I'm changing your nickname from Anaconda to Mr. Shy."

translate english ch04_beach01_cd9bb6ab:

    d "Hahahaha, alright."

translate english ch04_beach01_2ceddc2c:

    d "Yeah, I can't let that happen. Hahaha."

translate english ch04_beach01_74b00890:

    d "Amanda, when was the last time you had sex?"

translate english ch04_beach01_bcecb754_13:

    a ".........."

translate english ch04_beach01_04598399:

    a "Wow."

translate english ch04_beach01_8158e9b4:

    a "On second thought, maybe I should change your nickname from Mr. Shy to Mr. Zero-to-a-Hundred."

translate english ch04_beach01_e9a1609a:

    d "Hey, you told me to just ask."

translate english ch04_beach01_872c81a4:

    a "That's true. I like this version of you a lot better."

translate english ch04_beach01_bcecb754_14:

    a ".........."

translate english ch04_beach01_7a753905:

    a "The last time I had sex..."

translate english ch04_beach01_839cb8f8:

    a "Oh dear..."

translate english ch04_beach01_7e53e52e:

    a "I honestly can't remember."

translate english ch04_beach01_ef421f38:

    d "Oh, come on. You're kidding."

translate english ch04_beach01_f4a79eda:

    d "How can you not remember?"

translate english ch04_beach01_10aed208:

    a "...................."

translate english ch04_beach01_5128270d:

    a "No, seriously."

translate english ch04_beach01_bcecb754_15:

    a ".........."

translate english ch04_beach01_c6b05459:

    a "You know, don't you?"

translate english ch04_beach01_253b5aa5:

    a "Frank and I haven't had sex in ages."

translate english ch04_beach01_f69a7c0e:

    d "................"

translate english ch04_beach01_fab576ab_1:

    d "I... see."

translate english ch04_beach01_203cc60b_1:

    d "......."

translate english ch04_beach01_fac8215b_3:

    d "............"

translate english ch04_beach01_c3ae071d:

    a "Why? Is there something you're trying to ask?"

translate english ch04_beach01_9b04f6e9:

    d "Well..."

translate english ch04_beach01_1e839058:

    d "Then... I guess you must miss sex too?"

translate english ch04_beach01_bcecb754_16:

    a ".........."

translate english ch04_beach01_5a8c0ba5:

    a "You call that a question?"

translate english ch04_beach01_b5f7ebd4:

    a "Some days I want it, some days I don't."

translate english ch04_beach01_21cb352e_1:

    d "Um..."

translate english ch04_beach01_bcecb754_17:

    a ".........."

translate english ch04_beach01_de589dac:

    d "Amanda... are you seeing another man behind Frank's back?"

translate english ch04_beach01_bcecb754_18:

    a "Whoa there!!"

translate english ch04_beach01_692c7add:

    a "Why would you ask me that?"

translate english ch04_beach01_4bacfe26:

    a "I'm sensing an ulterior motive here."

translate english ch04_beach01_f69a7c0e_1:

    d "................"

translate english ch04_beach01_d021118c:

    d "It's just..."

translate english ch04_beach01_bcecb754_19:

    a ".........."

translate english ch04_beach01_dada8899:

    d "I've never been married, so I wouldn't really know, but you and Frank are husband and wife..."

translate english ch04_beach01_7e63c1ac:

    d "I've heard that a healthy sex life is a pretty important part of a marriage."

translate english ch04_beach01_3dcebc05:

    d "Not just for keeping the marriage together, but... how should I put it..."

translate english ch04_beach01_bcecb754_20:

    a ".........."

translate english ch04_beach01_58861d26:

    d "Sex drive is just part of being human."

translate english ch04_beach01_21273f15:

    d "If you can never satisfy it... I think that'd be pretty tragic."

translate english ch04_beach01_bcecb754_21:

    a ".........."

translate english ch04_beach01_524d389a:

    a "So that's why you asked if I was secretly seeing another man?"

translate english ch04_beach01_ddd009eb:

    d "No, I mean..."

translate english ch04_beach01_82a59d7d:

    d "What I'm trying to say is..."

translate english ch04_beach01_9e021545:

    d "You're human too, Amanda."

translate english ch04_beach01_d10f7738:

    d "So of course you'd want to feel sexually fulfilled."

translate english ch04_beach01_bcecb754_22:

    a ".........."

translate english ch04_beach01_4f58cef3:

    d "I just figured... when people are in that situation, they usually find other ways..."

translate english ch04_beach01_bcecb754_23:

    a ".........."

translate english ch04_beach01_33026345:

    a "So there was actually some thought behind that, huh, mister."

translate english ch04_beach01_b7af0384:

    d "Hahaha. That's right, ma'am."

translate english ch04_beach01_bcecb754_24:

    a ".........."

translate english ch04_beach01_38c6270d:

    a "**(Oh my!)**"

translate english ch04_beach01_e5383684:

    a "**(Has he seriously not noticed this? Why isn't he saying anything?...)**"

translate english ch04_beach01_4055a96e:

    a "**(My God....)**"

translate english ch04_beach01_a679caf4:

    a "**(..........)**"

translate english ch04_beach01_4635b16d:

    a "**(He's really solid...)**"

translate english ch04_beach01_a679caf4_1:

    a "**(..........)**"

translate english ch04_beach01_f212b4d7:

    a "**(Pretty heavy, too....)**"

translate english ch04_beach01_99d94fc8:

    a "Oh, sorry. Haha."

translate english ch04_beach01_239e45f8:

    a "I didn't realize my hand was touching it."

translate english ch04_beach01_7fd535f3:

    d "I-It's okay......"

translate english ch04_beach01_8897c7da:

    a "What's okay about it, you goof?"

translate english ch04_beach01_42f00050:

    d "It's not like it's going to wear out just because you touched it."

translate english ch04_beach01_bcecb754_25:

    a ".........."

translate english ch04_beach01_6e23f1ce:

    a "No, it won't wear out from being touched..."

translate english ch04_beach01_8a5cf0d4:

    d "Um..."

translate english ch04_beach01_9fc92f19:

    d "Did you like it?"

translate english ch04_beach01_a8f3bf58:

    a "Mm-hmm. It felt nice having you put sunscreen on me. Hehe."

translate english ch04_beach01_edbb7d05_4:

    d "........"

translate english ch04_beach01_0e024411:

    d "No, that's not what I meant..."

translate english ch04_beach01_edbb7d05_5:

    d "........"

translate english ch04_beach01_c7ed9b2d:

    d "You said you've imagined having sex with me."

translate english ch04_beach01_edbb7d05_6:

    d "........"

translate english ch04_beach01_3f53c577:

    d "When you imagined it... did you like it?"

translate english ch04_beach01_ec1dc0c2:

    a "What do you mean, did I like it?"

translate english ch04_beach01_bcecb754_26:

    a ".........."

translate english ch04_beach01_8d95ef8e:

    a "It was just a fantasy. It's not like it was good or bad..."

translate english ch04_beach01_edbb7d05_7:

    d "........"

translate english ch04_beach01_543da36b:

    d "Yeah..."

translate english ch04_beach01_edbb7d05_8:

    d "........"

translate english ch04_beach01_7c7441bd:

    d "Then... did you ever masturbate while thinking about having sex with me?"

translate english ch04_beach01_bcecb754_27:

    a ".........."

translate english ch04_beach01_b1f04730_1:

    a "My God, [d_name]..."

translate english ch04_beach01_edbb7d05_9:

    d "........"

translate english ch04_beach01_4eb76362:

    d "I'm just asking."

translate english ch04_beach01_bcecb754_28:

    a ".........."

translate english ch04_beach01_a79822de_6:

    a "........"

translate english ch04_beach01_853b4926:

    a "That's right."

translate english ch04_beach01_8e2819ea:

    a "I have."

translate english ch04_beach01_edbb7d05_10:

    d "........"

translate english ch04_beach01_96dca060:

    d "Thanks for being honest with me, Amanda."

translate english ch04_beach01_ad893dfa_2:

    d "......"

translate english ch04_beach01_a81de3d3:

    d "I jerk off thinking about you too."

translate english ch04_beach01_10794aa5:

    a "My God, honey..."

translate english ch04_beach01_f8ca2210:

    a "You masturbate thinking about me?"

translate english ch04_beach01_ad893dfa_3:

    d "......"

translate english ch04_beach01_a2abb764:

    a "Of all the women out there, why me? Hahaha."

translate english ch04_beach01_edbb7d05_11:

    d "........"

translate english ch04_beach01_c4794883:

    d "Well... I think about other women too. Hahaha."

translate english ch04_beach01_b2b821d1_5:

    a "........."

translate english ch04_beach01_92d9dac7:

    a "So who do you usually fantasize about?"

translate english ch04_beach01_edbb7d05_12:

    d "........"

translate english ch04_beach01_a5317097:

    d "I'll be honest, but you can't creep out, okay?"

translate english ch04_beach01_4b090aba:

    a "Alright, I promise. Hahaha."

translate english ch04_beach01_5d40df54:

    a "Now you've got me even more suspicious."

translate english ch04_beach01_2e5ef7b4:

    d "It's really not that weird..."

translate english ch04_beach01_cffcac98:

    d "I think about my landlady,"

translate english ch04_beach01_bcecb754_29:

    a ".........."

translate english ch04_beach01_2da060ce:

    d "my college professor,"

translate english ch04_beach01_5e3aec4e_5:

    d ".........."

translate english ch04_beach01_0a8ed04b:

    d "and Mary too..."

translate english ch04_beach01_7a979e93:

    a "Mary too?!!!"

translate english ch04_beach01_dc18d7e6:

    d "Yeah......"

translate english ch04_beach01_a96299f5:

    a "Wow..."

translate english ch04_beach01_edbb7d05_13:

    d "........"

translate english ch04_beach01_1421f0b6:

    d "I fantasize about Olivia too..."

translate english ch04_beach01_f0ac2786:

    a "Yeah, I figured as much."

translate english ch04_beach01_edbb7d05_14:

    d "........"

translate english ch04_beach01_2c58b97c:

    d "Sometimes I think about Mrs. Katie next door, too."

translate english ch04_beach01_40078c56:

    a "Oh my God..."

translate english ch04_beach01_4f330ca7:

    a "Wow, [d_name]."

translate english ch04_beach01_edbb7d05_15:

    d "........"

translate english ch04_beach01_4cd24902:

    d "I even think about Frank."

translate english ch04_beach01_9d142523:

    a "Fuck you!"

translate english ch04_beach01_541c921b:

    a "You got a death wish?"

translate english ch04_beach01_770f07b5:

    d "Hahahahahaha."

translate english ch04_beach01_7fcccb31:

    d "**(Damn..)**"

translate english ch04_beach01_fd9e2894:

    d "**(Her pussy keeps twitching...)**"

translate english ch04_beach01_a64126a3:

    n "Amanda's pussy had grown slick with arousal."

translate english ch04_beach01_fbca5a86:

    n "[d_name]'s touch and his filthy words were turning her on."

translate english ch04_beach01_e5c36b54_3:

    d "..........."

translate english ch04_beach01_8ffe50e5:

    d "A-Amanda... did you know?"

translate english ch04_beach01_ad777f97:

    a "Hmm? What are you talking about?"

translate english ch04_beach01_7e3d1318:

    d "Can I say it straight?"

translate english ch04_beach01_ed833428:

    a "Go ahead. Say it."

translate english ch04_beach01_e5c36b54_4:

    d "..........."

translate english ch04_beach01_95594d7b:

    d "Amanda... your pussy's wet."

translate english ch04_beach01_17659cc8_1:

    a ".............."

translate english ch04_beach01_a204b258:

    d "I bet I could slide right in."

translate english ch04_beach01_b7a9376e:

    a "Huh? What did you just say?"

translate english ch04_beach01_1228f72d:

    d "I bet I could….."

translate english ch04_beach01_eec14d39:

    d "N-Never mind. Forget it."

translate english ch04_beach01_31d796dc_1:

    a "...."

translate english ch04_beach01_53b959b9:

    a "*Sigh...*"

translate english ch04_beach01_74633325:

    a "It feels like all my stress is just melting away."

translate english ch04_beach01_b2b821d1_6:

    a "........."

translate english ch04_beach01_57dcf636:

    a "The sound of the waves…and the cool ocean breeze..."

translate english ch04_beach01_d884524e:

    a "And the touch of my beloved [d_name]..."

translate english ch04_beach01_f9a128b1:

    a "Your hands feel so good, honey..."

translate english ch04_beach01_e5c36b54_5:

    d "..........."

translate english ch04_beach01_4fa22628:

    d "**(My cock feels even better.)**"

translate english strings:
    old "배에 썬크림을 바른다."
    new "Apply sunscreen to her stomach."

translate english ch04_beach01_92f21ed5_1:

    n ""

translate english ch04_beach01_5fc68b36:

    d "I'm moving up."

translate english ch04_beach01_dbdab605_4:

    a "What?"

translate english ch04_beach01_a79822de_7:

    a "........"

translate english ch04_beach01_e51137be:

    a "See?"

translate english ch04_beach01_e990373d:

    d "See what?"

translate english ch04_beach01_4a7a5812:

    a "You're too light, honey..."

translate english ch04_beach01_a7b4e687:

    a "You could stand to weigh twice as much as you do now."

translate english ch04_beach01_a47d07a5_5:

    d "Hahaha."

translate english ch04_beach01_13bdfdac:

    d "Meaning I should be able to pick you up and fuck you?"

translate english ch04_beach01_77a214b8_3:

    a "..........."

translate english ch04_beach01_a8262d8b:

    a "Oh my god, seriously..."

translate english ch04_beach01_00314473:

    a "Are you really the same [d_name] who couldn't get a sentence out a little while ago?"

translate english ch04_beach01_5c1aec37:

    a "Can someone please bring back my original [d_name]?"

translate english ch04_beach01_e513fc8a:

    d "Hahahahaha."

translate english ch04_beach01_33c12968:

    a "Yeah..."

translate english ch04_beach01_4dc44113:

    a "If you can pick me up and fuck me with ease, you pass."

translate english ch04_beach01_732a8756_1:

    a "......"

translate english ch04_beach01_15949e98:

    a "That's my standard for a man who can have me..."

translate english ch04_beach01_14dbc012:

    a "Mmm..."

translate english ch04_beach01_e5c36b54_6:

    d "..........."

translate english ch04_beach01_31035dd0:

    d "Does it feel good?"

translate english ch04_beach01_55c02367_2:

    a "......."

translate english ch04_beach01_69e71bb1:

    a "Yeah."

translate english ch04_beach01_ea67aa37:

    a "It feels good because my beloved [d_name] is touching me."

translate english ch04_beach01_afdf479c:

    d "Want me to make you feel even better?"

translate english ch04_beach01_55c02367_3:

    a "......."

translate english ch04_beach01_a4d72727_1:

    a "What do you mean by that?"

translate english ch04_beach01_e5c36b54_7:

    d "..........."

translate english ch04_beach01_9b04f6e9_1:

    d "Well..."

translate english ch04_beach01_77673f80_5:

    d "........."

translate english ch04_beach01_35fd8e3b:

    a "Mister..."

translate english ch04_beach01_4de1a32d:

    a "Just spit it out."

translate english ch04_beach01_77673f80_6:

    d "........."

translate english ch04_beach01_3336c71b:

    n "[d_name] hesitated for a moment."

translate english ch04_beach01_02ccc1ab:

    n "He wanted to use the situation to his advantage."

translate english ch04_beach01_a1dd9c95:

    n "The woman lying in front of him was a female who had completely given herself to him."

translate english ch04_beach01_6f18c59f:

    d "Ah, fuck!! Alright."

translate english ch04_beach01_5ce31757:

    d "Want me to give you an erotic massage?"

translate english ch04_beach01_9de919e5:

    a "An erotic massage?"

translate english ch04_beach01_55c02367_4:

    a "......."

translate english ch04_beach01_1f0d78b4:

    a "Isn't that what you're already doing?"

translate english ch04_beach01_19f7216d:

    d "No, I mean..."

translate english ch04_beach01_7347c7d4:

    d "I'm not touching your erogenous zones right now..."

translate english ch04_beach01_5e3aec4e_6:

    d ".........."

translate english ch04_beach01_40ba955a:

    d "Want me to?"

translate english ch04_beach01_bcecb754_30:

    a ".........."

translate english ch04_beach01_6dd334c8_5:

    a "Hahaha."

translate english ch04_beach01_ee59d81f:

    a "Look who's been learning things..."

translate english ch04_beach01_bcecb754_31:

    a ".........."

translate english ch04_beach01_5ca8cc57:

    a "Do you even know how to do one?"

translate english ch04_beach01_edbb7d05_16:

    d "........"

translate english ch04_beach01_a681e70d:

    a "Go ahead then, mister..."

translate english ch04_beach01_01410937:

    a "Just don't cross the line."

translate english ch04_beach01_a2d21251:

    a "Try anything funny, and I'm writing you out of the family."

translate english ch04_beach01_58ae487e:

    d "Hahahaha."

translate english ch04_beach01_bcecb754_32:

    a ".........."

translate english ch04_beach01_bdb8c8d9:

    a "This is your idea of an erotic massage?"

translate english ch04_beach01_bb5e06f0:

    a "I'm disappointed..."

translate english ch04_beach01_5e3aec4e_7:

    d ".........."

translate english ch04_beach01_14dbc012_1:

    a "Mmm..."

translate english ch04_beach01_14dbc012_2:

    a "Mmm..."

translate english ch04_beach01_239ed756:

    a "Damn..."

translate english ch04_beach01_5a110ff0:

    d "**(Damn it, Amanda, I'm the one who's in trouble here!!)**"

translate english ch04_beach01_18d4ff7b:

    d "**(Damn... after what happened with Sophia yesterday, now this...)**"

translate english ch04_beach01_1a0059df:

    d "**(..............)**"

translate english ch04_beach01_772847fa:

    d "**(Maybe I should just slip it in a little?)**"

translate english ch04_beach01_aae96edc:

    d "**(Maybe Amanda would let me?)**"

translate english ch04_beach01_38fe645c:

    d "**(She's already wet...)**"

translate english ch04_beach01_6058ecae_1:

    d "**(.........)**"

translate english ch04_beach01_eb17ff94:

    d "**(She looks like she wants it just as badly right now...)**"

translate english ch04_beach01_0411797d_2:

    d "**(......)**"

translate english ch04_beach01_4f52b0b1_2:

    d "**(............)**"

translate english ch04_beach01_194e69bd:

    a "!!!!!!!!!!"

translate english ch04_beach01_4055a96e_1:

    a "**(My God....)**"

translate english ch04_beach01_d4a62b7d:

    a "**(Is he actually trying to put it in?.....)**"

translate english ch04_beach01_7e9c4c40:

    a "**(Doesn't he realize it's already touching me...?)**"

translate english ch04_beach01_bcecb754_33:

    a ".........."

translate english ch04_beach01_80936054:

    a "**(Phew..........)**"

translate english ch04_beach01_027c17fb:

    a "Honey?"

translate english ch04_beach01_8096b08a_3:

    d "Yeah?"

translate english ch04_beach01_d93a7c68:

    a "What are you doing?"

translate english ch04_beach01_77a214b8_4:

    a "..........."

translate english ch04_beach01_81846375:

    a "My God..."

translate english ch04_beach01_c4a9a0ea:

    a "Do you know where your dick is right now?"

translate english ch04_beach01_704451b0_1:

    d "Huh?"

translate english ch04_beach01_8225f230:

    d "Oh..."

translate english ch04_beach01_18edbce7:

    d "I'm sorry."

translate english ch04_beach01_5e3aec4e_8:

    d ".........."

translate english ch04_beach01_ec73a879:

    d "I didn't even notice it was there. Hehe."

translate english ch04_beach01_fab68504:

    a "................"

translate english ch04_beach01_edbb7d05_17:

    d "........"

translate english ch04_beach01_afcd4fdf:

    n "Amanda's words never reached him."

translate english ch04_beach01_4c541ab6:

    n "All he could see now were their aroused bodies pressed together."

translate english ch04_beach01_08e6bba3:

    n "Neither of them moved away."

translate english ch04_beach01_00e9824d:

    n "Slowly, he began inching his cock forward."

translate english ch04_beach01_36a950fd:

    a "Hey!!"

translate english ch04_beach01_4055a96e_2:

    a "**(My God....)**"

translate english ch04_beach01_898b9af6:

    a "**(What's he doing?)**"

translate english ch04_beach01_f6862f25:

    a "Mmm..."

translate english ch04_beach01_55c02367_5:

    a "......."

translate english ch04_beach01_8ee496b8:

    d "Ah... Amanda..."

translate english ch04_beach01_249ea80f:

    a "My God, [d_name]..."

translate english ch04_beach01_aac3b416:

    a "What are you doing? Hahaha."

translate english ch04_beach01_e384d1c9:

    a "Are you crazy??"

translate english ch04_beach01_b2b821d1_7:

    a "........."

translate english ch04_beach01_33c6f324:

    a "You're trying to put it inside me right now, aren't you??!!"

translate english ch04_beach01_1a629800:

    a "My God, honey..."

translate english ch04_beach01_e02d36dc:

    a "Are you actually trying to have sex with me?!!"

translate english ch04_beach01_55c02367_6:

    a "......."

translate english ch04_beach01_da853277:

    a "Oh my god..."

translate english ch04_beach01_dd6d9bc3:

    a "You did a great job, honey..."

translate english ch04_beach01_eef330c3:

    a "Let's take a little break now."

translate english ch04_beach01_96f72afd:

    d "We're not done yet."

translate english ch04_beach01_a529f973_1:

    a "Huh?"

translate english strings:
    old "성기 주변에 썬크림을 바른다."
    new "Apply sunscreen around her genitals."

translate english ch04_beach01_92f21ed5_2:

    n ""

translate english ch04_beach01_07750947:

    a "!!"

translate english ch04_beach01_b2b821d1_8:

    a "........."

translate english ch04_beach01_b515d55a:

    a "What are you about to do?..."

translate english ch04_beach01_edbb7d05_18:

    d "........"

translate english ch04_beach01_14dbc012_3:

    a "Mmm..."

translate english ch04_beach01_31035dd0_1:

    d "Does that feel good?"

translate english ch04_beach01_4ef2029a:

    d "Does it finally feel like an erotic massage now?"

translate english ch04_beach01_732a8756_2:

    a "......"

translate english ch04_beach01_edc71f50:

    d "What do you fantasize about when you masturbate, Amanda?"

translate english ch04_beach01_732a8756_3:

    a "......"

translate english ch04_beach01_c880a9f7:

    a "Why would you ask me something like that..."

translate english ch04_beach01_18b0dca7:

    d "I'm curious..."

translate english ch04_beach01_658691bf:

    d "I want to know what you fantasize about when you masturbate..."

translate english ch04_beach01_732a8756_4:

    a "......"

translate english ch04_beach01_dd7d968e:

    d "If I knew, maybe I could fill that void for you."

translate english ch04_beach01_aac6e6e7:

    a "What?!!!"

translate english ch04_beach01_2ed60dad:

    d "The things we fantasize about usually reflect our hidden desires, don't they...?"

translate english ch04_beach01_732a8756_5:

    a "......"

translate english ch04_beach01_b80a8d50:

    a "My God, [d_name]."

translate english ch04_beach01_54218755:

    a "Studying psychology has you asking some pretty intense questions."

translate english ch04_beach01_9e48d86e:

    a "Phew..."

translate english ch04_beach01_0f43cd5b:

    d "I just..."

translate english ch04_beach01_15722bed:

    d "I just want to get to know you better, Amanda."

translate english ch04_beach01_5cedc408:

    n "Amanda knew what [d_name] was getting at."

translate english ch04_beach01_96bf8287:

    n "But instead of stopping him, she simply lay there, feeling his touch."

translate english ch04_beach01_195b2ca0:

    n "She knew everything they were doing was inappropriate and everything they were saying was inappropriate."

translate english ch04_beach01_c049c099:

    n "But she wanted to know."

translate english ch04_beach01_669a32dd:

    n "What she meant to [d_name]."

translate english ch04_beach01_2a5481df:

    d "What positions Amanda likes..."

translate english ch04_beach01_ea875f52:

    d "How long she likes it to last..."

translate english ch04_beach01_896a77b9:

    a "My God..."

translate english ch04_beach01_77673f80_7:

    d "........."

translate english ch04_beach01_91146dfa:

    d "But..."

translate english ch04_beach01_540e69d9:

    d "There's something I've figured out from everything we've talked about."

translate english ch04_beach01_b2b821d1_9:

    a "........."

translate english ch04_beach01_e0f43323:

    a "Figured out what?"

translate english ch04_beach01_d09a7055:

    a "Mmm..."

translate english ch04_beach01_77673f80_8:

    d "........."

translate english ch04_beach01_a112e344:

    d "You want to be completely dominated, don't you?"

translate english ch04_beach01_ca98b010:

    d "You want to have sex while you're completely under a man's control, don't you?"

translate english ch04_beach01_77a214b8_5:

    a "..........."

translate english ch04_beach01_1a28f8b1:

    d "Like when a guy picks you up and fucks you while he's holding you."

translate english ch04_beach01_e113c67a:

    a "My God, honey..."

translate english ch04_beach01_a79822de_8:

    a "........"

translate english ch04_beach01_642176e3:

    a "I really shouldn't have said those things to you."

translate english ch04_beach01_ccfcd313:

    a "Stop."

translate english ch04_beach01_08a4decb:

    d "What do you mean, shouldn't have?"

translate english ch04_beach01_d56c595f:

    d "Even if I figured that out, what difference would it make?"

translate english ch04_beach01_427bc66b:

    d "It's not like I'm ever actually going to have sex with you..."

translate english ch04_beach01_a79822de_9:

    a "........"

translate english ch04_beach01_90d9097c:

    d "It just means I understand you a little better."

translate english ch04_beach01_fac8215b_4:

    d "............"

translate english ch04_beach01_79a7a6f9:

    d "I just want to know you better, Amanda..."

translate english ch04_beach01_edbb7d05_19:

    d "........"

translate english ch04_beach01_89e91716:

    d "I just want to know how to make you feel even better."

translate english ch04_beach01_56bf299a:

    d "...."

translate english ch04_beach01_384cd7e2:

    d "Because you're a woman who deserves that."

translate english ch04_beach01_5e3aec4e_9:

    d ".........."

translate english ch04_beach01_634589fc:

    d "You're really wet right now, Amanda..."

translate english ch04_beach01_a79822de_10:

    a "........"

translate english ch04_beach01_3f7f5f8b:

    a "My God... what are we even doing right now..."

translate english ch04_beach01_cbfbc352:

    a "Looks like we're done here, so let's just relax together for a while."

translate english strings:
    old "그녀의 질 입구를 벌린다."
    new "Spread open her pussy."

translate english ch04_beach01_92f21ed5_3:

    n ""

translate english ch04_beach01_194e69bd_1:

    a "!!!!!!!!!!"

translate english ch04_beach01_bcecb754_34:

    a ".........."

translate english ch04_beach01_249ea80f_1:

    a "My God, [d_name]..."

translate english ch04_beach01_2a86c200:

    a "What's gotten into you?"

translate english ch04_beach01_7264d1bc:

    a "I'm warning you, I'm getting serious."

translate english ch04_beach01_bae69210:

    n "When Amanda looked up at him and spoke,"

translate english ch04_beach01_fe0d31c9:

    n "He felt the muscles around her pussy and between her legs tense beneath his fingers."

translate english ch04_beach01_ec7f2e0b:

    n "Ignoring what she said, he continued caressing her."

translate english ch04_beach01_bcecb754_35:

    a ".........."

translate english ch04_beach01_629fb642:

    a "Mmm..."

translate english ch04_beach01_a75ba04a:

    d "I told you..."

translate english ch04_beach01_d57c0346:

    d "I was going to give you an erotic massage..."

translate english ch04_beach01_bcecb754_36:

    a ".........."

translate english ch04_beach01_a797f6ce_3:

    d "............."

translate english strings:
    old "아만다와 하고 싶어요."
    new "I want you, Amanda."

translate english ch04_beach01_66137b78:

    d "I want you, Amanda..."

translate english ch04_beach01_d6bbd58d:

    a "Huh?? What did you just say?"

translate english ch04_beach01_77673f80_9:

    d "........."

translate english ch04_beach01_6a7afad4:

    d "Can I put it in?"

translate english ch04_beach01_4841f932:

    a "**(What??!!)**"

translate english ch04_beach01_d2b35c71:

    a "**(Did he just ask if he could put it in??)**"

translate english ch04_beach01_a679caf4_2:

    a "**(..........)**"

translate english ch04_beach01_dde42e4e:

    a "**(Has he lost his mind..? )**"

translate english ch04_beach01_6bd79908:

    a "*Mmm...*"

translate english ch04_beach01_1f3b2f91:

    a "H-Honey..."

translate english ch04_beach01_30fab333:

    a "You've done more than enough."

translate english ch04_beach01_b80a8d50_1:

    a "My God, [d_name]."

translate english ch04_beach01_8fb5b13d:

    a "Phew..........."

translate english ch04_beach01_11b0ed80:

    a "**(My God, Amanda.....)**"

translate english ch04_beach01_e7e54dd6:

    a "**(You're really soaking wet....)**"

translate english ch04_beach01_a679caf4_3:

    a "**(..........)**"

translate english ch04_beach01_a4a3ad25:

    unknownf "I knew it. I knew this was coming."

translate english ch04_beach01_19e371ca:

    unknownf "That cougar's got herself a young boy toy."

translate english ch04_beach01_14379926:

    unknownf "Just how many years apart are you two, huh?"

translate english ch04_beach01_4746ab86:

    unknownf "Seriously, how big's the age gap?"

translate english ch04_beach01_cea6e5ae:

    unknownf "You disgusting bitch."

translate english ch04_beach01_82670022:

    unknownf ".........."

translate english ch04_beach01_5734fc87:

    unknownf "Look at that. Look at that."

translate english ch04_beach01_6dea375e:

    unknownf "Look how shameless she is. He hasn't even put it in yet, and she can barely sit still."

translate english ch04_beach01_c105771a:

    unknownf "What a sneaky bitch."

translate english ch04_beach01_9859921f:

    unknownf "Oh, that poor little boy."

translate english ch04_beach01_ddff2f0b:

    unknownf "What a waste of a magnificent cock."

translate english ch04_beach01_1fdcfe66:

    unknownf "He should just shove it inside that bitch and teach her a lesson."

translate english ch04_beach01_478d70f7:

    unknownf "She must've trained him like a slave if he just stands there like an idiot the moment she tells him to stop."

translate english ch04_beach01_16a21bbc:

    unknownf "..........."

translate english ch04_beach01_a105d9e7:

    a "Want me to do it now?"

translate english ch04_beach01_affa30c2:

    d "Ah... no, I'm okay."

translate english ch04_beach01_ae70d4a1:

    d "I'm just going to have a drink in the shade and rest."

translate english ch04_beach01_4ac365be:

    a "Alright then..."

translate english ch04_beach01_43851d55:

    a "I'm going to take a 30-minute nap. You should rest too."

translate english ch04_beach01_77a214b8_6:

    a "..........."

translate english ch04_beach01_02_17659cc8:

    a ".............."

translate english ch04_beach01_02_e5c36b54:

    d "..........."

translate english ch04_beach01_02_831be537:

    n "She turned over."

translate english ch04_beach01_02_fc7a8f9d:

    n "As she lay there completely defenseless, his eyes fell on her exposed lower body."

translate english ch04_beach01_02_a47d07a5:

    d "Haha."

translate english ch04_beach01_02_168cbf33:

    d "Aren't you afraid of sleeping naked right next to me?"

translate english ch04_beach01_02_f53d7551:

    d "I'm a pretty perverted guy, you know that, haha."

translate english ch04_beach01_02_442b03ba:

    n "Then he moved his cock toward hers."

translate english ch04_beach01_02_840830a1:

    n "Amanda also felt something approaching her."

translate english ch04_beach01_02_6dd334c8:

    a "Haha."

translate english ch04_beach01_02_af4ff0d1:

    a "You really do say some strange things sometimes, you know that?"

translate english ch04_beach01_02_43df59c0:

    a "Stop bothering me and go away."

translate english ch04_beach01_02_b83aeb90:

    d "Mmm......"

translate english ch04_beach01_02_ef154f57:

    d "I'm just saying, haha."

translate english ch04_beach01_02_3afa1029:

    d "**(Mmm......)**"

translate english ch04_beach01_02_59e73e79:

    a "I'm going to sleep, honey."

translate english ch04_beach01_02_79128e7f:

    a "You should rest too."

translate english ch04_beach01_02_f000c349:

    d "**(Damn......)**"

translate english ch04_beach01_02_aac778ef:

    d "**(I want to put it in..... I really want to.....)**"

translate english ch04_beach01_02_2a25e6cb:

    d "**(Haa.............)**"

translate english ch04_beach01_02_7341f0bd:

    d "**(She didn't even complain when I touched her pussy......)**"

translate english ch04_beach01_02_e707ca71:

    d "**(Maybe she'd actually let me go a little further...? )**"

translate english ch04_beach01_02_618704b1:

    d "**(...............)**"

translate english ch04_beach01_02_e4e2034d:

    d "**(Just...)**"

translate english ch04_beach01_02_0ce2485f:

    d "**(This is a way of showing love too... isn't it?)**"

translate english ch04_beach01_02_46a36509:

    unknownf "........"

translate english strings:
    old "그녀의 항문에 삽입한다."
    new "Slide it into her ass."

translate english ch04_beach01_02_074255e0:

    a "?????"

translate english ch04_beach01_02_9b396464:

    n "[d_name] pressed the head of his cock against Amanda's anus."

translate english ch04_beach01_02_829730da:

    n "Her vagina was blocked,"

translate english ch04_beach01_02_249c82e9:

    n "and he figured her anus would be relaxed enough from his foreplay."

translate english ch04_beach01_02_b3230473:

    a "What......"

translate english ch04_beach01_02_644f3ae2:

    a "What..... the....."

translate english ch04_beach01_02_bf30d24e:

    a "What..... the..... fuck......"

translate english ch04_beach01_02_81d59848:

    a "............."

translate english ch04_beach01_02_e07f2e74:

    a "What on earth is this...."

translate english strings:
    old "고추를 조금 더 전진시킨다."
    new "Push it in a little farther."

translate english ch04_beach01_02_ec5ac95a:

    n "As his cock pressed against Amanda's anus, she felt an indescribable sensation."

translate english ch04_beach01_02_d3fade1b:

    n "At that moment, every single one of her senses became entirely focused on her anus."

translate english ch04_beach01_02_33dfd5fb:

    d "**(Damn it...)**"

translate english ch04_beach01_02_c425ed2d:

    d "**(She wants it too.)**"

translate english ch04_beach01_02_0411797d:

    d "......"

translate english ch04_beach01_02_a4c9ea2c:

    d "**(Look at this. She's just lying there without moving.)**"

translate english ch04_beach01_02_ee577d3b:

    a "Hey, what are you doing right now?"

translate english ch04_beach01_02_e5c36b54_1:

    d "..........."

translate english ch04_beach01_02_6ea4ef2c:

    d "Uh... well..."

translate english ch04_beach01_02_9b04f6e9:

    d "I mean..."

translate english ch04_beach01_02_5e3aec4e:

    d ".........."

translate english ch04_beach01_02_7bfb42d4:

    d "I just wanted to make you feel good..."

translate english ch04_beach01_02_7e130594:

    d "Like... an extension of the erotic massage..."

translate english ch04_beach01_02_77a214b8:

    a "..........."

translate english ch04_beach01_02_77a214b8_1:

    a "..........."

translate english ch04_beach01_02_b23e8774:

    a "Hey, you really think something that thick is just gonna fit in there?"

translate english ch04_beach01_02_8096b08a:

    d "Huh?"

translate english ch04_beach01_02_77a214b8_2:

    a "..........."

translate english ch04_beach01_02_81846375:

    a "My God..."

translate english ch04_beach01_02_77a214b8_3:

    a "..........."

translate english ch04_beach01_02_cb39cf82:

    a "You need to use your fingers or a plug to stretch it first."

translate english ch04_beach01_02_1d74ea04:

    a "Of course it won't go in if you just force it, you idiot."

translate english ch04_beach01_02_3b4aece5:

    d "Ah..."

translate english ch04_beach01_02_58c24b75:

    d "Then…"

translate english ch04_beach01_02_93357346:

    d "Should I start with my fingers?"

translate english ch04_beach01_02_0794517a:

    a "Haa... [d_name]..."

translate english ch04_beach01_02_e29b6b5a:

    a "Sorry, but can you leave me alone? I'm going to sleep."

translate english ch04_beach01_02_5e3aec4e_1:

    d ".........."

translate english ch04_beach01_02_54dcc57a:

    d "Okay... I'm sorry."

translate english ch04_beach01_02_e6bd0f96:

    a "I'm going to get mad, okay?"

translate english ch04_beach01_02_e39d30bf:

    d "Ah... sorry, sorry..."

translate english ch04_beach01_02_c5f6fac0:

    d "I think I lost my mind for a second..."

translate english ch04_beach01_02_853b4926:

    a "Yeah."

translate english ch04_beach01_02_37928ab6:

    a "You really look like a crazy guy right now, you know that?"

translate english ch04_beach01_02_81846375_1:

    a "My God..."

translate english ch04_beach01_02_0ef3a6d0:

    a "....."

translate english ch04_beach01_02_39ecc716:

    a "**(Does he think I'm some kind of sex doll?)**"

translate english ch04_beach01_02_0ef3a6d0_1:

    a "....."

translate english ch04_beach01_02_a392de10:

    a "**(Did he want to try anal or something?)**"

translate english ch04_beach01_02_7aa6be0e:

    a "**(But even so, how could he say that to me...)**"

translate english ch04_beach01_02_cea73e48:

    a "**(.........)**"

translate english ch04_beach01_02_56bf00d0:

    a "**(Is he crazy??)**"

translate english ch04_beach02_f16f2749:

    d "**(What is this woman...?)**"

translate english ch04_beach02_2e9c6444:

    d "**(.......)**"

translate english ch04_beach02_9045afd2:

    unknownf "Hi."

translate english ch04_beach02_c7283a2c:

    d "Ah... hi..."

translate english ch04_beach02_9b2c160a:

    d "**(Why does she feel so familiar...?)**"

translate english ch04_beach02_704451b0:

    d "Huh?"

translate english ch04_beach02_7fcccb31:

    d "**(Shit..)**"

translate english ch04_beach02_a88a07e6:

    unknownf "Hehe."

translate english ch04_beach02_e5e10003:

    unknownf "Cute."

translate english ch04_beach02_106f1b84:

    d "What are you doing?"

translate english ch04_beach02_83fa57b5:

    unknownf "Shh..."

translate english ch04_beach02_ff72dfa3:

    unknownf "Keep your voice down."

translate english ch04_beach02_ff940ca5:

    unknownf "Let me put sunscreen on you."

translate english ch04_beach02_8096b08a:

    d "Huh?"

translate english ch04_beach02_299ba199:

    unknownf "Just stay still."

translate english ch04_beach02_77673f80:

    d "........."

translate english ch04_beach02_50fd967f:

    unknownf "Good boy."

translate english ch04_beach02_e775273f:

    unknownf "Yeah, just like that....."

translate english ch04_beach02_9707a391:

    d "W...wait, who are you?"

translate english ch04_beach02_d4659d9c:

    d "Is this really okay??"

translate english ch04_beach02_f4cda87e:

    unknownf ".............."

translate english ch04_beach02_5a9173a3:

    unknownf "Doesn't matter, hehe."

translate english ch04_beach02_ac4de9d5:

    unknownf "I'm just giving you what you deserve."

translate english ch04_beach02_5e3aec4e:

    d ".........."

translate english ch04_beach02_f15b9b9e:

    d "What?"

translate english ch04_beach02_621ffa6d:

    unknownf "Shh!"

translate english ch04_beach02_b2b7d6ec:

    unknownf "Just stay still."

translate english ch04_beach02_e85a95d0:

    unknownf "Hehe."

translate english ch04_beach02_34b9985e:

    unknownf "You can touch as much as you want."

translate english ch04_beach02_a254b6d4:

    d "!!!!!"

translate english ch04_beach02_e4252deb:

    d "R...really??"

translate english ch04_beach02_1704d7c2:

    unknownf "Yeah, baby. Touch me."

translate english strings:
    old "그녀의 성기를 만진다."
    new "Touche her genitals."

translate english ch04_beach02_3b837274:

    unknownf "Yes, baby..."

translate english ch04_beach02_670ca6cc:

    unknownf "Yeah, just like that..."

translate english ch04_beach02_cab7c488:

    unknownf "I'm already getting wet..."

translate english ch04_beach02_edbb7d05:

    d "........"

translate english ch04_beach02_8806b4d7:

    unknownf "Check this, darling."

translate english ch04_beach02_3debc41c:

    d "Huh?!"

translate english ch04_beach02_6e9cbf39:

    unknownf "Put your finger in."

translate english ch04_beach02_a254b6d4_1:

    d "!!!!!"

translate english strings:
    old "그녀의 성기에 손가락을 넣는다."
    new "Slip a finger inside her."

translate english ch04_beach02_56229f70:

    n "As his finger slid into her vagina, he could feel how incredibly wet and ribbed she was."

translate english ch04_beach02_8feda27e:

    unknownf "Go deeper."

translate english ch04_beach02_edbb7d05_1:

    d "........"

translate english ch04_beach02_16a6efba:

    unknownf "Yes........."

translate english ch04_beach02_23b4d70f:

    n "He could feel her walls twitching around his finger."

translate english ch04_beach02_94345503:

    unknownf "Deeper..."

translate english ch04_beach02_c1fe6098:

    unknownf "Ahh....."

translate english ch04_beach02_c1fe6098_1:

    unknownf "Ahh....."

translate english ch04_beach02_cdfe8e11:

    unknownf "You know what?"

translate english ch04_beach02_8096b08a_1:

    d "Huh?"

translate english ch04_beach02_baba867e:

    unknownf "Fuck the sunscreen."

translate english ch04_beach02_07905da9:

    d "What did you say??"

translate english ch04_beach02_bb920e29:

    d "!!!!!!!"

translate english ch04_beach02_371ebb9d:

    n "She stopped applying sunscreen and climbed on top of him with her legs spread."

translate english ch04_beach02_590b68d7:

    d "**(My God!!)**"

translate english ch04_beach02_62845282:

    n "And without any hesitation, she grabbed [d_name]'s cock."

translate english ch04_beach02_9ae6a0df:

    d "**(This woman is insane..)**"

translate english ch04_beach02_ce03aa1d:

    n "And her bush brushed against his mouth."

translate english ch04_beach02_e4ff7b5a:

    n "And then he felt something warm and wet wrapping around his cock."

translate english ch04_beach02_4f52b0b1:

    d "**(............)**"

translate english ch04_beach02_43cddf1d:

    n "Slurp.."

translate english ch04_beach02_d5a313bf:

    unknownf "Hmm....."

translate english ch04_beach02_b4da7b18:

    d "**(Ugh......)**"

translate english ch04_beach02_0b9dc8e3:

    unknownf "Gulp....."

translate english ch04_beach02_3819fcc2:

    d "**(Damn......)**"

translate english ch04_beach02_3974ce22:

    d "**(Is this a dream?...)**"

translate english ch04_beach02_def99bd7:

    unknownf "Slurp slurp"

translate english ch04_beach02_35b996b5:

    d "**(Ah... she smells good...)**"

translate english ch04_beach02_f1489119:

    d "**(Does she spray something there too??)**"

translate english ch04_beach02_bdcd82af:

    d "**(.................)**"

translate english ch04_beach02_95fc1851:

    d "Ugh......"

translate english ch04_beach02_0b9dc8e3_1:

    unknownf "Gulp....."

translate english ch04_beach02_bb6df1d4:

    d "**(Ngh...)**"

translate english ch04_beach02_d309a37e:

    d "**(It's touching her throat...)**"

translate english ch04_beach02_9665381d:

    d "**(Ugh......)**"

translate english ch04_beach02_4c3771f5:

    d "**(Damn.....)**"

translate english ch04_beach02_ce07d6c4:

    d "**(It feels like I'm being sucked into her mouth!!)**"

translate english ch04_beach02_9665381d_1:

    d "**(Ugh......)**"

translate english ch04_beach02_d841dd5a:

    d "**(Shit!!!!!)**"

translate english ch04_beach02_0b9dc8e3_2:

    unknownf "Gulp....."

translate english ch04_beach02_d6497df6:

    d "**(Ah......)**"

translate english ch04_beach02_6f7354e3:

    d "**(This is what an experienced woman feels like...)**"

translate english ch04_beach02_3c7a7f55:

    d "**(...........)**"

translate english ch04_beach02_606bfb54:

    d "**(She's on a whole different level than Mary..)**"

translate english ch04_beach02_eb526170:

    d "**(Hmm......)**"

translate english ch04_beach02_25955b56:

    d "**(She's so skilled...)**"

translate english ch04_beach02_7886dfa1:

    d "**(Ah..........)**"

translate english ch04_beach02_39c0b5cb:

    unknownf "Ahh....."

translate english ch04_beach02_295ecbef:

    unknownf "Yes baby, yes!!"

translate english ch04_beach02_4cf04f65:

    unknownf "Eat me up, darling."

translate english ch04_beach02_f2b59476:

    n "Chomp chomp"

translate english ch04_beach02_60e6244e:

    n "Smooch smooch"

translate english ch04_beach02_c9af7824:

    n "On a quiet rural beach..."

translate english ch04_beach02_e26647e9:

    n "[d_name] was receiving oral sex from a strange woman right next to Amanda."

translate english ch04_beach02_0ca9b8df:

    n "The fear that Amanda might wake up was being erased by the pleasure surging from his body."

translate english ch04_beach02_4c3771f5_1:

    d "**(Damn......)**"

translate english ch04_beach02_6911a8f0:

    d "**(I've never had a blowjob like this before....)**"

translate english ch04_beach02_6058ecae:

    d "**(.........)**"

translate english ch04_beach02_a2a350e3:

    d "**(Feels like I'm being pulled in..... haa....)**"

translate english ch04_beach02_91d58c5b:

    d "Phew......"

translate english ch04_beach02_4a70f569:

    unknownf "Hmm........"

translate english ch04_beach02_edbb7d05_2:

    d "........"

translate english ch04_beach02_e5c36b54:

    d "..........."

translate english ch04_beach02_c27326a1:

    d "**(Is it over?...)**"

translate english ch04_beach02_4cd15d58:

    d "....."

translate english ch04_beach02_7902ee2b:

    d "**(Kind of a shame if she stops...)**"

translate english ch04_beach02_4b2c579a:

    d "**(!!!)**"

translate english ch04_beach02_aa0c733b:

    n "As he was feeling a bit disappointed, he felt something wrap around his cock."

translate english ch04_beach02_1d0af2f6:

    unknownf "............."

translate english ch04_beach02_5e3aec4e_1:

    d "..........."

translate english ch04_beach02_c2e82c59:

    n "When he looked up, she was putting a condom on him."

translate english ch04_beach02_fbc90ae3:

    unknownf "**(Damn, this was a small size condom....)**"

translate english ch04_beach02_312b8806:

    unknownf "**(I bought it in a rush and didn't check...)**"

translate english ch04_beach02_588f637f:

    unknownf "**(Whatever...)**"

translate english ch04_beach02_7cae9309:

    n "Then she grabbed his cock and guided it inside."

translate english ch04_beach02_a7b77a20:

    d "Holy shit!!"

translate english ch04_beach02_06589825:

    unknownf "Shhh~~~"

translate english ch04_beach02_37ca4128:

    unknownf "Just relax and enjoy it, hehe."

translate english ch04_beach02_0ffedd5f:

    unknownf "My God..."

translate english ch04_beach02_c9cfafa5:

    unknownf "You're really thick."

translate english ch04_beach02_f34da1bf:

    unknownf "Hmm......"

translate english ch04_beach02_abcc0d1c:

    d "**(Ah... it's going in...)**"

translate english ch04_beach02_4295088a:

    unknownf "Yes...."

translate english ch04_beach02_a57ce849:

    d "**(Ah...........)**"

translate english ch04_beach02_c1fe6098_2:

    unknownf "Ahh....."

translate english ch04_beach02_2fdd3396:

    unknownf "**(Yes yes yes......)**"

translate english ch04_beach02_e47d06ec:

    unknownf "**(It's much better than I thought...)**"

translate english ch04_beach02_b03a4b73:

    unknownf "**(Ah......)**"

translate english ch04_beach02_b289834a:

    unknownf "**(My God.....)**"

translate english ch04_beach02_aa236028:

    unknownf "**(This feels so good.....)**"

translate english ch04_beach02_2810c13d:

    unknownf "**(Yes baby!!)**"

translate english ch04_beach02_480ab6cc:

    unknownf "**(Fuck me!!)**"

translate english ch04_beach02_05810aba:

    d "**(Ugh....)**"

translate english ch04_beach02_2490b6bb:

    d "**(.........)**"

translate english ch04_beach02_61bd76d8:

    d "**(Ahh......)**"

translate english ch04_beach02_c20f34d3:

    unknownf "Hmm......."

translate english ch04_beach02_05810aba_1:

    d "**(Ugh....)**"

translate english ch04_beach02_a54fac0e:

    unknownf "Huff...."

translate english ch04_beach02_f7c85858:

    unknownf "**(Oh my God!!!!)**"

translate english ch04_beach02_ebfa783a:

    unknownf "**(Yes baby!! Yes!!)**"

translate english ch04_beach02_ba7ea7cb:

    unknownf "**(Fuck me faster!!!!!)**"

translate english ch04_beach02_3fab0ff4:

    unknownf "**(Yes!! Yes!! Yes!!)**"

translate english ch04_beach02_1a5bcf41:

    d "**(Ah......)**"

translate english ch04_beach02_996c9106:

    d "**(This is insane...)**"

translate english ch04_beach02_fb4342b7:

    d "**(..........)**"

translate english ch04_beach02_944cdd32:

    d "**(Ah........)**"

translate english ch04_beach02_f7c85858_1:

    unknownf "**(Oh my God!!!!)**"

translate english ch04_beach02_ebfa783a_1:

    unknownf "**(Yes baby!! Yes!!)**"

translate english ch04_beach02_18437389:

    unknownf "**(!!!!)**"

translate english ch04_beach02_150ae2eb:

    unknownf "**(Ah..........)**"

translate english ch04_beach02_1dcc0c97:

    d "**(Damn, I'm already about to blow.)**"

translate english ch04_beach02_6058ecae_1:

    d "**(.........)**"

translate english ch04_beach02_a4b476da:

    d "**(Shit...)**"

translate english ch04_beach02_a4b476da_1:

    d "**(Shit...)**"

translate english ch04_beach02_63f392de:

    d "**(She’s like a machine....)**"

translate english ch04_beach02_7a74c604:

    d "**(A sex machine...)**"

translate english ch04_beach02_49d9573d:

    d "**(Shit...)**"

translate english ch04_beach02_7712cd25:

    d "**(Who the hell is this woman...?)**"

translate english ch04_beach02_8a2c284b:

    n "Watching her ride him, he was completely captivated."

translate english ch04_beach02_b6e9e57d:

    n "He wished every woman he knew would just cut the crap and fuck him like this."

translate english ch04_beach02_b7ccc80c:

    n "He wanted to keep seeing her and learn about sex from her."

translate english ch04_beach02_095a2411:

    d "**(Damn, I’m about to cum...)**"

translate english ch04_beach02_3a5c26d1:

    unknownf "**(My God....)**"

translate english ch04_beach02_3fab0ff4_1:

    unknownf "**(Yes!! Yes!! Yes!!)**"

translate english ch04_beach02_a4b476da_2:

    d "**(Shit...)**"

translate english ch04_beach02_6651af55:

    unknownf "**(Yes!!)**"

translate english ch04_beach02_db85d1df:

    unknownf "**(Yes!! Yes!!)**"

translate english ch04_beach02_3fab0ff4_2:

    unknownf "**(Yes!! Yes!! Yes!!)**"

translate english ch04_beach02_4ad495c9:

    unknownf "**(Fuck!!!!)**"

translate english ch04_beach02_6ccd6991:

    unknownf "**(..........)**"

translate english ch04_beach02_d99ce62d:

    d "**(Ugh........)**"

translate english ch04_beach02_df426054:

    unknownf "**(Haaah!!!!!!!!!)**"

translate english ch04_beach02_6ccd6991_1:

    unknownf "**(..........)**"

translate english ch04_beach02_f31bbaa2:

    unknownf "**(Haa... haa....)**"

translate english ch04_beach02_fe2eef5b:

    unknownf "**(My God......)**"

translate english ch04_beach02_11581281:

    unknownf "**(Have I ever come this fast before?...)**"

translate english ch04_beach02_16a21bbc:

    unknownf "..........."

translate english ch04_beach02_8b20b447:

    unknownf "You're amazing...."

translate english ch04_beach02_46a36509:

    unknownf "........"

translate english ch04_beach02_8a2a6b7c:

    unknownf "Do you love me?"

translate english ch04_beach02_dd84cc7a:

    d "Yes... I love you..."

translate english ch04_beach02_4cd15d58_1:

    d "....."

translate english ch04_beach02_cd1aeaac:

    unknownf "I love you too, darling."

translate english ch04_beach02_8aaf057c:

    unknownf "Fuck my pussy...."

translate english ch04_beach02_3d845596:

    unknownf "Come on, fuck my pussy...."

translate english ch04_beach02_b7ad5667:

    d "Ah... alright..."

translate english ch04_beach02_7dd1ec11:

    unknownf "Yes baby..."

translate english ch04_beach02_e3bdf5b2:

    unknownf "Yes baby......."

translate english ch04_beach02_fa2fc134:

    unknownf "Tell me my pussy feels good."

translate english ch04_beach02_e29f6bd2:

    d "Your pussy is the best...."

translate english ch04_beach02_1d1d5dcd:

    unknownf "Ahh...."

translate english ch04_beach02_7deaa142:

    unknownf "Mmm....."

translate english ch04_beach02_3fe9bf6a:

    unknownf "Mmm....."

translate english ch04_beach02_319a8eae:

    d "**(Ugh.......)**"

translate english ch04_beach02_7fe74448:

    unknownf "Ahh........"

translate english ch04_beach02_60b39fe5:

    unknownf "**(Is this dick magic or what?)**"

translate english ch04_beach02_b31fdb38:

    unknownf "**(I’m about to cum again..... ah.....)**"

translate english ch04_beach02_261e0798:

    n "Snap!"

translate english ch04_beach02_bfe5e760:

    d "**(Ah..... it feels even better now.....)**"

translate english ch04_beach02_7f8197b6:

    d "**(So warm...)**"

translate english ch04_beach02_a42c28d7:

    unknownf "**(Ahh.....)**"

translate english ch04_beach02_12ed9d46:

    unknownf "**(I’m coming... again...)**"

translate english ch04_beach02_a9f985be:

    unknownf "**(Ugh!!!!!!)**"

translate english ch04_beach02_4196f126:

    unknownf "**(Yes~~~~~~!!!!!!)**"

translate english ch04_beach02_989f5fa0:

    unknownf "**(..........)**"

translate english ch04_beach02_468d81fd:

    unknownf "**(Ah...............)**"

translate english ch04_beach02_aa6f0e67:

    d "Ah..."

translate english ch04_beach02_8f9cbb7b:

    d "I’m gonna cum..."

translate english ch04_beach02_469d61c0:

    unknownf "Fill me up....."

translate english ch04_beach02_4bba8e8a:

    d "Ahh.."

translate english ch04_beach02_9c7afa84:

    n "He was swept up by overwhelming pleasure and came deep inside her."

translate english ch04_beach02_ef542f24:

    n "Her inner walls squeezed and clamped down on his cock."

translate english ch04_beach02_dc027646:

    n "He filled her completely without leaving a single drop behind."

translate english ch04_beach02_da9a07c3:

    d "Ah............"

translate english ch04_beach02_1c893654:

    d "**(It feels like a fucking vacuum cleaner in here...)**"

translate english ch04_beach02_44f93f10:

    unknownf "Huh?!!"

translate english ch04_beach02_1039570c:

    unknownf "Shit!!"

translate english ch04_beach02_b289834a_1:

    unknownf "**(My God.....)**"

translate english ch04_beach02_70023963:

    unknownf "**(.........)**"

translate english ch04_beach02_4f07e356:

    unknownf "**(Wait... when did it get this bad...?)**"

translate english ch04_beach02_70023963_1:

    unknownf "**(.........)**"

translate english ch04_beach02_f3d3678e:

    unknownf "**(This might not be a good time...)**"

translate english ch04_beach02_94d2f55d:

    unknownf "Haa......"

translate english ch04_beach02_27bbfe0c:

    unknownf "**(I should've bought the morning-after pill when I got the condoms... Sigh...)**"

translate english ch04_beach02_a997f233:

    unknownf "**(Damn, I rushed it...)**"

translate english ch04_beach02_9ea52664:

    d "Ah... sorry..."

translate english ch04_beach02_bf84d805:

    d "I didn’t even realize it ended up like that......."

translate english ch04_beach02_41534512:

    d "W-What should we do?"

translate english ch04_beach02_77673f80_1:

    d "........."

translate english ch04_beach02_ed2da9dd:

    unknownf "Hehe, it's okay. It's okay."

translate english ch04_beach02_268f7958:

    unknownf "What's done is done. Nothing we can do now."

translate english ch04_beach02_47ca403f:

    unknownf "If I get pregnant, I'll just keep it. Haha."

translate english ch04_beach02_a2127452:

    d "What?!!"

translate english ch04_beach02_be504391:

    unknownf "Hmm...."

translate english ch04_beach02_63bbe54b:

    unknownf "Oh my God... did you really just cum?"

translate english ch04_beach02_cd0f90c7:

    unknownf "You’re amazing..."

translate english ch04_beach02_b4c125cc:

    unknownf "Ahh......"

translate english ch04_beach02_d99ce62d_1:

    d "**(Ugh........)**"

translate english ch04_beach02_b45ae0cf:

    d "!!!"

translate english ch04_beach02_72d3378f:

    unknownf "Ahh........"

translate english ch04_beach02_28f2b003:

    unknownf "Shit..."

translate english ch04_beach02_b4c125cc_1:

    unknownf "Ahh......"

translate english ch04_beach02_d99ce62d_2:

    d "**(Ugh........)**"

translate english ch04_beach02_789daf7d:

    unknownf "Yes!!!!!!!"

translate english ch04_beach02_320849fb:

    d "**(Ugh!!!!!!!)**"

translate english ch04_beach02_ed81024d:

    unknownf "Hmm..."

translate english ch04_beach02_16a21bbc_1:

    unknownf "..........."

translate english ch04_beach02_7041a367:

    unknownf "Fuck…"

translate english ch04_beach02_e9843517:

    unknownf "This is insane..."

translate english ch04_beach02_16a21bbc_2:

    unknownf "..........."

translate english ch04_beach02_7c0bea00:

    a "Ugh...."

translate english ch04_beach02_83fa57b5_1:

    unknownf "Shhh"

translate english ch04_beach02_e5e45dd8:

    unknownf "Let me get up."

translate english ch04_beach02_70023963_2:

    unknownf "**(.........)**"

translate english ch04_beach02_907925ea:

    unknownf "**(I won, bitch... haha.)**"

translate english ch04_beach02_e32b61a9:

    unknownf "**(Did you think you could mess with me and get away with it?)**"

translate english ch04_beach02_4149258c:

    unknownf "**(.....)**"

translate english ch04_beach02_6ccd6991_2:

    unknownf "**(..........)**"

translate english ch04_beach02_508f1da6:

    unknownf "**(................)**"

translate english ch04_beach02_5f3c43cd:

    unknownf "Damn....."

translate english ch04_beach02_6ccd6991_3:

    unknownf "**(..........)**"

translate english ch04_beach02_9ec2868d:

    unknownf "**(I thought I’d feel better after getting revenge...)**"

translate english ch04_beach02_70023963_3:

    unknownf "**(.........)**"

translate english ch04_beach02_7b489d16:

    unknownf "**(Why do I feel even worse...?)**"

translate english ch04_beach02_70023963_4:

    unknownf "**(.........)**"

translate english ch04_beach02_0909535f:

    unknownf "**(My legs are shaking....)**"

translate english ch04_beach02_e5c36b54_1:

    d "..........."

translate english ch04_beach02_50f2fb71:

    d "**(What is that woman...?)**"

translate english ch04_beach02_edbb7d05_3:

    d "........"

translate english ch04_beach02_ec7bde07:

    d "**(Haa........)**"

translate english ch04_beach02_dceeb191:

    n "The phone rings."

translate english ch04_beach02_9add122f:

    a "Ahh, I feel dizzy after that nap..."

translate english ch04_beach02_3168f168:

    a "Hello, my sweet sister."

translate english ch04_beach02_60405016:

    a "What's up?"

translate english ch04_beach02_368cf441:

    o "Nothing, just calling to check on you."

translate english ch04_beach02_e83554b5:

    o "Did you meet [d_name] today?"

translate english ch04_beach02_b2b821d1:

    a "........."

translate english ch04_beach02_33251edd:

    a "How did you know that?"

translate english ch04_beach02_7e6684e2:

    a "I had a feeling, and now you've finally become a witch."

translate english ch04_beach02_87af78b1:

    o "Oh, what are you talking about?"

translate english ch04_beach02_a8fa90b1:

    a "We're just relaxing at the beach right now."

translate english ch04_beach02_e8a98513:

    o "Perfect."

translate english ch04_beach02_08e35b29:

    o "That's close enough."

translate english ch04_beach02_b2b821d1_1:

    a "........."

translate english ch04_beach02_8e33ac67:

    o "Come to my cabin tonight."

translate english ch04_beach02_3943de69:

    o "I’ll prepare some food."

translate english ch04_beach02_cd6c73fb:

    o "It’s been a while, let’s have some drinks together as sisters."

translate english ch04_beach02_8f18d97f:

    o "How about it?"

translate english ch04_beach02_6054c265:

    a "Hmm........"

translate english ch04_beach02_a516571f:

    a "Alright then."

translate english ch04_beach02_e03d43b0:

    a "I'll tell him."

translate english ch04_beach02_f739079c:

    o "Don't even ask him."

translate english ch04_beach02_2fe132b9:

    o "Just drag him over here, haha."

translate english ch04_beach02_2b2fc249:

    o "Anyway, don’t be late."

translate english ch04_beach02_72a5717c:

    a "Alright. See you later."

translate english ch04_beach02_a79822de:

    a "........"

translate english ch04_beach02_ec35b229:

    a "What is this..."

translate english ch04_beach02_a79822de_1:

    a "........"

translate english ch04_beach02_4e9c58ad:

    a "Is this some new trendy way of masturbating?"

translate english ch04_beach02_bcecb754:

    a ".........."

translate english ch04_beach02_61499aab:

    a "My God.."

translate english ch04_beach02_bcecb754_1:

    a ".........."

translate english ch04_beach02_f2f14064:

    a "**(What the hell is this....)**"

translate english ch04_beach02_bcecb754_2:

    a ".........."

translate english ch04_beach02_bcecb754_3:

    a ".........."

translate english ch04_beach02_c608b930:

    a "**(That’s a condom.)**"

translate english ch04_beach02_a2f1b729:

    a "**(Why the hell is he wearing that?)**"

translate english ch04_beach02_07750947:

    a "!!"

translate english ch04_beach02_dadd8b06:

    a "**(...........)**"

translate english ch04_beach02_b7058ce8:

    a "**(That woman.....)**"

translate english ch04_beach02_b0800aa4:

    a "**(Have I seen her somewhere? Why does she look familiar?)**"

translate english ch04_beach02_dadd8b06_1:

    a "**(...........)**"

translate english ch04_beach02_dadd8b06_2:

    a "**(...........)**"

translate english ch04_beach02_7c3fb24b:

    n "She looked at his cock closely for the first time."

translate english ch04_beach02_b1a6e1f3:

    a "**(This.......)**"

translate english ch04_beach02_3dc08daa:

    a "**(Is it hard or not?... )**"

translate english ch04_beach02_abc276b1:

    n "She examined its size, color, and veins in as much detail as she could."

translate english ch04_beach02_dadd8b06_3:

    a "**(...........)**"

translate english ch04_beach02_d8c37d6c:

    a "**(Or is it in the middle of getting hard?... )**"

translate english ch04_beach02_46b9cc0b:

    a "**(!!!!!!!!!!!!!!!)**"

translate english ch04_beach02_20a3609f:

    n "As it pointed toward her face, even the urethral opening was fully exposed."

translate english ch04_beach02_b6acf085:

    n "The sight alone was enough to overwhelm her with arousal."

translate english ch04_beach02_dadd8b06_4:

    a "**(...........)**"

translate english ch04_beach02_cd278011:

    a "**(My God......)**"

translate english ch04_beach02_294e2f72:

    a "**(Look at those veins..)**"

translate english ch04_beach02_f3b8496d:

    a "**([d_name].............)**"

translate english ch04_beach02_dadd8b06_5:

    a "**(...........)**"

translate english ch04_beach02_7fb33515:

    n "And before she knew it, she had begun imagining him penetrating her."

translate english ch04_beach02_5ac93e27:

    a "**(......)**"

translate english ch04_beach02_e796b36f:

    a "**(You were going to shove that into my ass?!!!)**"

translate english ch04_beach02_5ac93e27_1:

    a "**(......)**"

translate english ch04_beach02_057c81c5:

    a "**(Would that even fit?)**"

translate english ch04_beach02_a816c05d:

    a "**(My God......)**"

translate english ch04_beach02_5ac93e27_2:

    a "**(......)**"

translate english ch04_beach02_7c34d0ef:

    a "**(It’s like three times Frank’s size....)**"

translate english ch04_beach02_6e8e358e:

    a "**(.....)**"

translate english ch04_beach02_dadd8b06_6:

    a "**(...........)**"

translate english ch04_beach02_5378393e:

    d "Was that Olivia on the phone?"

translate english ch04_beach02_3350b588:

    a "!!!!!!!!!!!!!!!"

translate english ch04_beach02_5378393e_1:

    d "Was that Olivia on the phone?"

translate english ch04_beach02_6e94428b:

    a "Hmm... yeah..."

translate english ch04_beach02_853b4926:

    a "That's right."

translate english ch04_beach02_399db8e5:

    a "............"

translate english ch04_beach02_4b4ffd90:

    a "She said we should go to her cabin and have dinner together."

translate english ch04_beach02_bbd0d4ed:

    a "Let's go together."

translate english ch04_beach02_fad3b965:

    d "Yeah, sounds good."

translate english ch04_beach02_5e3aec4e_2:

    d ".........."

translate english ch04_beach02_897c436d:

    d "Amanda, are you okay?"

translate english ch04_beach02_ed871125:

    a "Yeah, I'm fine."

translate english ch04_beach02_56dd9b76:

    a "I just got a little dizzy when I stood up suddenly."

translate english ch04_beach02_b1a4543d:

    d "Want to lie down next to me for a bit?"

translate english ch04_beach02_65eb85cc:

    a "No, let's just clean up and go."

translate english ch04_beach02_b693dd5a:

    a "**(Hehehe.)**"

translate english ch04_beach02_3274e68d:

    a "**(Goodbye, kid.)**"

translate english ch04_beach02_cea73e48:

    a "**(.........)**"

translate english ch04_beach02_77a214b8:

    a "..........."

translate english ch04_beach02_108e351f:

    a "What a sneaky bitch..."

translate english ch04_cabin01_d63f03bd:

    o "Come in."

translate english ch04_cabin01_5bc79ace:

    o "Feels like I just saw you recently, but also like it's been a long time."

translate english ch04_cabin01_e7333312:

    a "What is it?"

translate english ch04_cabin01_b8f866de:

    a "What's with that outfit?"

translate english ch04_cabin01_df435958:

    a "You’re not even divorced yet, acting like a virgin again?"

translate english ch04_cabin01_55d1c2ba:

    a "So, what guy came over today?"

translate english ch04_cabin01_43ddd429:

    o "Cut it out."

translate english ch04_cabin01_b3044eb0:

    o "Nothing like that happened."

translate english ch04_cabin01_8a1ebd5d:

    o "What about you? What's with that skirt?"

translate english ch04_cabin01_a59dd9fe:

    o "What are you, some street hooker?"

translate english ch04_cabin01_f7269c00:

    a "Yeah, I am."

translate english ch04_cabin01_41e7b1d3:

    a "I just got back from turning tricks."

translate english ch04_cabin01_2cf566f8:

    d "**(My God....)**"

translate english ch04_cabin01_936ea5e4:

    d "**(.............)**"

translate english ch04_cabin01_9953138c:

    o "How have you been? Hehe."

translate english ch04_cabin01_8d33cd85:

    d "Yeah, I've been good."

translate english ch04_cabin01_53a41bd0:

    o "Did you get more manly since then?"

translate english ch04_cabin01_8826c8a7:

    d "Haha, I’m not sure."

translate english ch04_cabin01_635d0ca3:

    o "You didn’t even text me once. What were you doing?"

translate english ch04_cabin01_2a36363b:

    o "Did you not miss me at all?"

translate english ch04_cabin01_71589d28:

    d "Sorry haha."

translate english ch04_cabin01_74dd5002:

    d "I’ve just been busy with a lot of things."

translate english ch04_cabin01_0186dd88:

    d "Wow, it smells amazing!"

translate english ch04_cabin01_5b850a7f:

    o "Haha."

translate english ch04_cabin01_c7fae135:

    o "Did you forget I run a restaurant?"

translate english ch04_cabin01_033135b9:

    o "My cooking is on a completely different level from Amanda’s."

translate english ch04_cabin01_0685b78a:

    a "Don’t be ridiculous."

translate english ch04_cabin01_c132a227:

    a "If I hadn’t helped you, you wouldn’t even have started this restaurant."

translate english ch04_cabin01_45c08218:

    a "Get your facts straight."

translate english ch04_cabin01_a8116c7b:

    a "Hmm......"

translate english ch04_cabin01_ac79acc5:

    a "Something’s off"

translate english ch04_cabin01_b2b821d1:

    a ".........."

translate english ch04_cabin01_98e5e932:

    a "Are you actually cooking properly?"

translate english ch04_cabin01_17b50d4a:

    o "Stop talking nonsense."

translate english ch04_cabin01_dc874888:

    o "I make this all the time. What are you complaining about?"

translate english ch04_cabin01_56bcccea:

    o "Besides, this is my house."

translate english ch04_cabin01_7fbfa247:

    o "Mind your own business."

translate english ch04_cabin01_cde14580:

    o "Quit picking on me and go relax with [d_name]."

translate english ch04_cabin01_05657511:

    o "Or go cuddle with him in bed. Haha."

translate english ch04_cabin01_e5c36b54:

    d "..........."

translate english ch04_cabin01_d0af05c4:

    a "I'm pretty tired after that drive."

translate english ch04_cabin01_9663a1f1:

    a "I'm gonna go rest in my room."

translate english ch04_cabin01_aa86cd65:

    o "Okay."

translate english ch04_cabin01_07dfff03:

    o "I'll call you when I'm ready."

translate english ch04_cabin01_eb643e1a:

    o "Come here, honey."

translate english ch04_cabin01_a29e6c5a:

    o "Talk to me so I don't get bored."

translate english ch04_cabin01_7fc229f7:

    d "Sure. hehe."

translate english ch04_cabin01_7e55e43c:

    o "So, how was the beach?"

translate english ch04_cabin01_f1dd0c8a:

    o "First time you've been back in a while, huh?"

translate english ch04_cabin01_f318543d:

    d "Yeah. Haha"

translate english ch04_cabin01_0c591a76:

    d "I hadn't been there in years. It's changed a lot."

translate english ch04_cabin01_77c7760c:

    d "Still... the ocean's still the ocean."

translate english ch04_cabin01_03f401ae:

    d "You know... it's got that small beach town feel."

translate english ch04_cabin01_9a8b1c8e:

    o "And what's that supposed to mean?"

translate english ch04_cabin01_77673f80:

    d "........."

translate english ch04_cabin01_fce6d430:

    d "I don't know..."

translate english ch04_cabin01_062166a9:

    d "I like that it never gets too crowded, but there's still plenty to do."

translate english ch04_cabin01_089c787e:

    d "Though you still run into the occasional idiot. Haha."

translate english ch04_cabin01_892d09af:

    o "Haha."

translate english ch04_cabin01_e3ce0ded:

    o "The ocean's always nice, no matter how many times you come."

translate english ch04_cabin01_3a9860d7:

    o "Whenever I go, I feel like a weight's been lifted off my shoulders."

translate english ch04_cabin01_c509dfc3:

    o "Like I can leave all my worries behind for a while..."

translate english ch04_cabin01_72fdffce:

    d "Yeah, I know what you mean."

translate english ch04_cabin01_77673f80_1:

    d "........."

translate english ch04_cabin01_23b4aede:

    d "I can't say I have much to worry about, though. Haha."

translate english ch04_cabin01_8378e8dc:

    o "I should take some time for myself like that too..."

translate english ch04_cabin01_f4e51997:

    o "............."

translate english ch04_cabin01_bedbf23d:

    o "Between the restaurant and everything going on with my husband, I've barely had a chance to breathe."

translate english ch04_cabin01_3b4aece5:

    d "Oh..."

translate english ch04_cabin01_afe71565:

    d "So... are you two completely done?"

translate english ch04_cabin01_16afcf0f:

    d "Or are you already divorced?"

translate english ch04_cabin01_e842596d:

    o "........"

translate english ch04_cabin01_cb8474a2:

    n "Instead of answering right away, Olivia fell silent for a moment."

translate english ch04_cabin01_e7db3b5b:

    n "She hesitated as if gathering her thoughts before speaking again."

translate english ch04_cabin01_bea3fafa:

    o "No. Not yet."

translate english ch04_cabin01_a6021c56:

    o "The divorce is still ongoing."

translate english ch04_cabin01_e842596d_1:

    o "........"

translate english ch04_cabin01_b83aeb90:

    d "I see..."

translate english ch04_cabin01_cf5c0c45:

    d "Did something happen?"

translate english ch04_cabin01_e30a71ad:

    o "Let's just call it grown-up problems. Haha."

translate english ch04_cabin01_21966b92:

    o "Let's just say my husband was mostly at fault..."

translate english ch04_cabin01_e0159ffd:

    d "I... I see..."

translate english ch04_cabin01_8ba86927:

    o "The court will decide all that."

translate english ch04_cabin01_0ec1887f:

    o "What matters is..."

translate english ch04_cabin01_4db292e9:

    o "I'm finally free. Haha."

translate english ch04_cabin01_48998b97:

    d "Haha.."

translate english ch04_cabin01_77673f80_2:

    d "........."

translate english ch04_cabin01_5f502324:

    o "Living alone is heaven."

translate english ch04_cabin01_aea0002b:

    o "I feel sooooo free."

translate english ch04_cabin01_0a5b31ff:

    d "I guess so. Haha."

translate english ch04_cabin01_469450f9:

    n "As Olivia rested her arm against [d_name], her scent drifted toward him."

translate english ch04_cabin01_ba7cf42b:

    d "**(God... she smells amazing...)**"

translate english ch04_cabin01_c1ef500d:

    d "**(It's a little like Amanda's... but completely different at the same time...)**"

translate english ch04_cabin01_5626614a:

    d "**(Man...)**"

translate english strings:
    old "그녀의 허리에 손을 올린다."
    new "Place your hand on her waist."

translate english ch04_cabin01_e842596d_2:

    o "........"

translate english ch04_cabin01_6ed5dd7c:

    n "She couldn't help noticing how different he seemed from the last time they'd met."

translate english ch04_cabin01_6573637f:

    n "When [d_name]'s hand came to rest on her waist, Olivia felt an unexpected spark of sexual tension."

translate english ch04_cabin01_ed995af0:

    o "I don't want to stay single forever, of course..."

translate english ch04_cabin01_48ded625:

    o "But for now..."

translate english ch04_cabin01_62c0ba6a:

    o "I'm just going to enjoy my freedom."

translate english ch04_cabin01_dba1e635:

    d "I see..."

translate english strings:
    old "그녀의 허리를 쓰다듬는다."
    new "Gently caress her waist."

translate english ch04_cabin01_a22800d8:

    d "You've really had a rough time with everything..."

translate english ch04_cabin01_e842596d_3:

    o "........"

translate english ch04_cabin01_79d15e6f:

    d "Doesn't it get lonely, though... suddenly living here all by yourself?"

translate english ch04_cabin01_77673f80_3:

    d "........."

translate english ch04_cabin01_c31098a2:

    d "Especially at night..."

translate english ch04_cabin01_a71bf9a4:

    d "I mean..."

translate english ch04_cabin01_cb07ad9c:

    d "This place is pretty far from town and all..."

translate english ch04_cabin01_5b850a7f_1:

    o "Hahaha."

translate english ch04_cabin01_d971ddf1:

    o "You mean I get lonely at night because I'm here all by myself?"

translate english ch04_cabin01_d35925a3:

    d "Huh? N-No, that's not what I..."

translate english ch04_cabin01_1776689a:

    o "Hahaha. I'm just messing with you."

translate english ch04_cabin01_1e6ef186:

    o "You should move in with me. Then I won't have to be lonely. Hehe."

translate english ch04_cabin01_db618281:

    o "Come live with me and take good care of me like a real man."

translate english ch04_cabin01_823f604e:

    d "Huh? Hahaha."

translate english ch04_cabin01_a559a071:

    o "!!"

translate english ch04_cabin01_608d9ce8:

    o "Oops."

translate english ch04_cabin01_9256ec79:

    o "Sorry, Apple."

translate english ch04_cabin01_7ab39cb0:

    d "!!!!"

translate english ch04_cabin01_d1981947:

    d "**(What the fuck?)**"

translate english ch04_cabin01_b0d27612:

    o "Oops!"

translate english ch04_cabin01_e842596d_4:

    o "........"

translate english ch04_cabin01_629e908d:

    d "Ah... I'm sorry..."

translate english ch04_cabin01_203cc60b:

    d "......."

translate english ch04_cabin01_96190516:

    d "I wasn't trying to look..."

translate english ch04_cabin01_bff6402b:

    o "Hm? Hahaha. It's okay."

translate english ch04_cabin01_203cc60b_1:

    d "......."

translate english ch04_cabin01_52370f65:

    o "I told you before."

translate english ch04_cabin01_701fbbf4:

    o "I don't wear underwear at home."

translate english ch04_cabin01_203cc60b_2:

    d "......."

translate english ch04_cabin01_6c0d8395:

    d "Oh... right."

translate english ch04_cabin01_79ed984f:

    d "You did say that..."

translate english ch04_cabin01_203cc60b_3:

    d "......."

translate english ch04_cabin01_1edffedd:

    d "I honestly thought you were kidding..."

translate english ch04_cabin01_c597ef88:

    o "What do you think?"

translate english ch04_cabin01_7f3c4057:

    d "Huh? About what?"

translate english ch04_cabin01_f6df5197:

    o "What else? What you just saw."

translate english ch04_cabin01_ec51d1ef:

    d "Huh?!!!!!"

translate english ch04_cabin01_82582280:

    o "Actually..."

translate english ch04_cabin01_f61cbfa2:

    o "My pussy."

translate english ch04_cabin01_a797f6ce:

    d "............."

translate english ch04_cabin01_bef5596e:

    d "Ollie..."

translate english ch04_cabin01_4ae2bb2d:

    o "Hahaha. Was that a little too blunt?"

translate english ch04_cabin01_f96c0300:

    o "..........."

translate english ch04_cabin01_df92dab2:

    o "You've got that blank look on your face again, don't you?"

translate english ch04_cabin01_683252aa:

    o "Pretty cute for a woman my age, isn't it?"

translate english ch04_cabin01_a797f6ce_1:

    d "............."

translate english ch04_cabin01_bb3a945d:

    o "No? Hahaha."

translate english ch04_cabin01_179fc7c4:

    o "Maybe I should've waxed a little better. Hehe."

translate english ch04_cabin01_7c0a9214:

    d ".............."

translate english ch04_cabin01_8b7a5c2b:

    d "Uh..."

translate english ch04_cabin01_ab16ad10:

    d "The truth is..."

translate english ch04_cabin01_07d8beef:

    d "I... haven't really seen enough pussies to compare them..."

translate english ch04_cabin01_a891ab84:

    o "What?"

translate english ch04_cabin01_62d1ed2a:

    d "I-I mean..."

translate english ch04_cabin01_f929f31c:

    d "I think your... pussy is gorgeous..."

translate english ch04_cabin01_b9571570:

    o "What? Hahahahaha."

translate english ch04_cabin01_f26dc300:

    o "Oh my God..."

translate english ch04_cabin01_72aee648:

    o "You really leave me scratching my head sometimes."

translate english ch04_cabin01_a183608c:

    o "I can't tell if you're genuinely innocent..."

translate english ch04_cabin01_c90b2dd2:

    o "Or if you're just pretending because you've got an angle."

translate english ch04_cabin01_f96c0300_1:

    o "..........."

translate english ch04_cabin01_c0aaa29a:

    o "Does acting innocent usually work for you?"

translate english ch04_cabin01_7c0a9214_1:

    d ".............."

translate english ch04_cabin01_f796837d:

    d "No... not really..."

translate english ch04_cabin01_9a104b70:

    o "............"

translate english ch04_cabin01_31fa6964:

    o "You dummy."

translate english ch04_cabin01_a6b67887:

    d "I'm not a dummy!"

translate english ch04_cabin01_6572819d:

    d "Would you stop teasing me?"

translate english ch04_cabin01_079f89c5:

    o "Sure you are."

translate english ch04_cabin01_f6a8d23b:

    d "I said I'm not!!"

translate english ch04_cabin01_1b755e47:

    o "You're a dummy, [d_name]."

translate english strings:
    old "그녀를 뒤에서 껴앉는다."
    new "Wrap your arms around her from behind."

translate english ch04_cabin01_92f21ed5:

    n "What should I do?"

translate english ch04_cabin01_35229552:

    d "Oh, come on!!"

translate english ch04_cabin01_ffc308e0:

    o "!!!!"

translate english ch04_cabin01_f6a8d23b_1:

    d "See? I'm not a dummy."

translate english ch04_cabin01_d226b6b8:

    o ".........."

translate english ch04_cabin01_8b716246:

    o "What are you doing, kiddo? Hahaha."

translate english ch04_cabin01_516508c1:

    d "That's what you get for calling me a dummy."

translate english ch04_cabin01_74543f78:

    o "Heh..."

translate english ch04_cabin01_616127e6:

    o "That's a pretty pathetic punishment."

translate english ch04_cabin01_dac0d7b9:

    o "You're still a dummy. Hahaha."

translate english ch04_cabin01_d441ed68:

    o "[d_name]'s a dummy."

translate english ch04_cabin01_096c1334:

    d "I'm not! Hahaha."

translate english ch04_cabin01_a559a071_1:

    o "!!"

translate english ch04_cabin01_965f7a91:

    d "So... I'm not a dummy now, right?"

translate english ch04_cabin01_f6c37117:

    d "Right?"

translate english ch04_cabin01_a151db34:

    o "......."

translate english ch04_cabin01_6cbd768a:

    o "..............."

translate english ch04_cabin01_3b7d7532:

    d "Still think I'm a dummy?"

translate english ch04_cabin01_ddf12d46:

    d "Hmm...."

translate english strings:
    old "드레스 속으로 손을 넣는다."
    new "Slip your hand under her dress."

translate english ch04_cabin01_94652d89:

    o "!!!!!!!!!"

translate english ch04_cabin01_11dd7096:

    o "Hey! What do you think you're doing?"

translate english ch04_cabin01_0e7a980a:

    d "Wow... your skin's just as soft as Amanda's."

translate english ch04_cabin01_d1c86bea:

    o "Hahaha. Excuse me?"

translate english ch04_cabin01_7dec9b68:

    d "Still think I'm a goofball?"

translate english ch04_cabin01_c012be7d:

    o "Yep."

translate english strings:
    old "손을 더 깊히 넣는다."
    new "Slide your hand in deeper."

translate english ch04_cabin01_233ca93e:

    o "Mmm..."

translate english ch04_cabin01_f1b1cfc6:

    o "........."

translate english ch04_cabin01_65e90f03:

    o "Is that as far as you've got, dummy?"

translate english ch04_cabin01_b30b4aa4:

    o "Your hand's only on my thigh. Is that it?"

translate english ch04_cabin01_323ffa9a:

    n "As he pushed his hand farther in, his fingertips brushed against the coarse hair between her legs."

translate english ch04_cabin01_1b566eaf:

    o "Damn it!!"

translate english ch04_cabin01_2bd467a7:

    o "Knock it off, you little goof!"

translate english ch04_cabin01_da515ae3:

    o "You really are getting way too bold."

translate english ch04_cabin01_5d50e048:

    o "Are you starting to take after Amanda?"

translate english ch04_cabin01_42e578c3:

    d "I'm a goofball, remember? I don't know what stop means."

translate english ch04_cabin01_b961607f:

    o "You really are a goofball."

translate english ch04_cabin01_284f6975:

    o "You little pervert."

translate english ch04_cabin01_a47d07a5:

    d "Hahaha."

translate english ch04_cabin01_ef321515:

    o "Get off me, it's getting hot in here. Hahaha."

translate english ch04_cabin01_81bec046:

    a "Is the food ready?"

translate english ch04_cabin01_3235726d:

    o "Come on, have a seat."

translate english ch04_cabin01_0b6665ba:

    o "Everything's ready."

translate english ch04_cabin01_1b5a9121:

    o "Thanks to [d_name], dinner was ready in no time. Hahaha."

translate english ch04_cabin01_546653cb:

    d "Thanks for the food!"

translate english ch04_cabin01_a26bec58:

    o "Dig in, everyone."

translate english ch04_cabin01_e027a1b4:

    a "Thanks."

translate english ch04_cabin01_c2801721:

    o "I can't even remember the last time the three of us had dinner together."

translate english ch04_cabin01_96e3d588:

    o "I think the first time [d_name] joined our little family was also the last."

translate english ch04_cabin01_e4461b05:

    a "That was really the last time? Wow..."

translate english ch04_cabin01_edbb7d05:

    d "........"

translate english ch04_cabin01_a313cc18:

    o "Hahahaha. Oh my God."

translate english ch04_cabin01_161c88b6:

    o "They actually called [d_name] a little slave? Hahaha."

translate english ch04_cabin01_6225b646:

    d "Yeah."

translate english ch04_cabin01_10a0e792:

    d "It was pretty ridiculous hearing them say that while they were all naked."

translate english ch04_cabin01_fd390f0d:

    d "They looked just as suspicious themselves."

translate english ch04_cabin01_bcecb754:

    a ".........."

translate english ch04_cabin01_03b6b561:

    a "What's with young people these days? Whatever happened to having manners?"

translate english ch04_cabin01_55c02367:

    a "......."

translate english ch04_cabin01_cf188801:

    a "So I just flashed them."

translate english ch04_cabin01_f23afbd4:

    a "Told them to shut the fuck up after getting an eyeful."

translate english ch04_cabin01_83a9ebd7:

    a "You should've seen the look on those guys' faces. Hahaha."

translate english ch04_cabin01_dfa2ba5e:

    a "Actually, you should've seen the woman standing next to them."

translate english ch04_cabin01_5b850a7f_2:

    o "Hahaha."

translate english ch04_cabin01_bb49c151:

    o "Exactly. My sister's never been one to let things slide."

translate english ch04_cabin01_b1b93400:

    o "She always gets even."

translate english ch04_cabin01_88de05a2:

    o "Her motto's always been, An eye for an eye."

translate english ch04_cabin01_f96c0300_2:

    o "..........."

translate english ch04_cabin01_03d2178a:

    o "So... did you just spend the whole day looking at the ocean?"

translate english ch04_cabin01_41a29968:

    a "No, something happened!!"

translate english ch04_cabin01_81baf2f2:

    d "**(?????)**"

translate english ch04_cabin01_328fa234:

    a "And [d_name] put sunscreen on me."

translate english ch04_cabin01_77a214b8:

    a "..........."

translate english ch04_cabin01_f1ec7d1c:

    a "Every last inch."

translate english ch04_cabin01_a9aac3ee:

    o "Every last inch?"

translate english ch04_cabin01_a79822de:

    a "........"

translate english ch04_cabin01_27a40f74:

    a "Maybe a little *too* thoroughly."

translate english ch04_cabin01_a151db34_1:

    o "......."

translate english ch04_cabin01_1268f1a8:

    o "Right..."

translate english ch04_cabin01_c45510a1:

    o "**(They were both completely naked while he put sunscreen on her? Seriously?)**"

translate english ch04_cabin01_2a0d6cd5:

    o "**(Amanda... Amanda... Amanda...)**"

translate english ch04_cabin01_f6010f96:

    o "**(You shameless bitch!)**"

translate english ch04_cabin01_b296d0e0:

    a "He was unbelievably thorough. Hahaha."

translate english ch04_cabin01_ccf60716:

    a "He's so meticulous when he gets focused like that..."

translate english ch04_cabin01_67841ca1:

    a "We almost had a major incident. Haha."

translate english ch04_cabin01_148b17ce:

    a "Anyway, he just loves fussing over every little thing."

translate english ch04_cabin01_1a0059df:

    d "**(..............)**"

translate english ch04_cabin01_9650087d:

    a "Kids these days have no sense of shame."

translate english ch04_cabin01_7ada4290:

    d "What do you mean? I'm really shy. Haha."

translate english ch04_cabin01_3fe10366:

    d "I was just focused on applying it evenly."

translate english ch04_cabin01_0685b78a_1:

    a "Oh, please."

translate english ch04_cabin01_2b9458c0:

    a "You little perv."

translate english ch04_cabin01_8bb7eea0:

    o "Hmm........."

translate english ch04_cabin01_035eccb6:

    o "**(That's all that happened?)**"

translate english ch04_cabin01_c2038ef2:

    o "**(What have those two really been up to?)**"

translate english ch04_cabin01_e7cda966:

    o "**(That slutty bitch.)**"

translate english ch04_cabin01_eea951a6:

    o "**(She took him to a nude beach?!)**"

translate english ch04_cabin01_892d09af_1:

    o "Haha."

translate english ch04_cabin01_00b6b40a:

    o "Next time, you're coming with me."

translate english ch04_cabin01_11a8849c:

    o "Got it?"

translate english ch04_cabin01_1fd595a0:

    d "Sure. Haha......"

translate english ch04_cabin02_cc81d519:

    n "After so long apart, the three of them enjoyed a pleasant meal together in the privacy of the cabin."

translate english ch04_cabin02_fd0c3c5f:

    n "Amanda and Olivia shared drinks together for the first time in a long while."

translate english ch04_cabin02_7836be68:

    n "As the alcohol gradually kicked in, the conversation became increasingly open and uninhibited."

translate english ch04_cabin02_4602a17d:

    d "Ugh... Amanda..."

translate english ch04_cabin02_144660ca:

    d "Do we really have to talk about that?..."

translate english ch04_cabin02_a891ab84:

    o "What?"

translate english ch04_cabin02_4a739e6c:

    o "What are you talking about?"

translate english ch04_cabin02_1c9d30a5:

    a "I'm serious."

translate english ch04_cabin02_c1a3055a:

    a "Even I was shocked."

translate english ch04_cabin02_6651e710:

    a "I mean, he just wouldn't keep his hands off my pussy..."

translate english ch04_cabin02_8f13324f:

    a "Then he actually spread my pussy open to look."

translate english ch04_cabin02_2954a802:

    d "Ugh.........."

translate english ch04_cabin02_0ad716ce:

    d "I wasn't trying to do that..."

translate english ch04_cabin02_dcc080ff:

    o "What??!!"

translate english ch04_cabin02_8fdeae13:

    o "[d_name] spread your... your pussy open?!!!!"

translate english ch04_cabin02_707e045d:

    n "Olivia could hardly believe what she was hearing."

translate english ch04_cabin02_ac3ee671:

    n "The way Amanda described [d_name]'s behavior was far beyond anything she had imagined."

translate english ch04_cabin02_7ebb1496:

    a "I'm telling you."

translate english ch04_cabin02_a79822de:

    a "........"

translate english ch04_cabin02_f1c214ec:

    a "What on earth was going through his head..."

translate english ch04_cabin02_6293b514:

    o "Oh my God..."

translate english ch04_cabin02_720d4821:

    o "You two planned this just to mess with me, didn't you?"

translate english ch04_cabin02_fea3d886:

    a "You think that was all?"

translate english ch04_cabin02_38fbae43:

    a "He was pretending to put on sunscreen, but he was really just rubbing his cock against my pussy."

translate english ch04_cabin02_974f859c:

    d "Amanda..."

translate english ch04_cabin02_917100e8:

    d "C-Could you at least choose your words a little more carefully?..."

translate english ch04_cabin02_e6f46eaa:

    d "I-I mean…it just ended up that way."

translate english ch04_cabin02_e5fe4ce0:

    o ".................."

translate english ch04_cabin02_4781fe9e:

    o "Wait... why? How did that even happen??"

translate english ch04_cabin02_e842596d:

    o "........"

translate english ch04_cabin02_9264c37e:

    o "D-Don't tell me...You two were getting turned on together?"

translate english ch04_cabin02_55b83ff4:

    o "I mean.."

translate english ch04_cabin02_fd3ee18c:

    o "Are you two getting intimate?"

translate english ch04_cabin02_bb22947b:

    a "Have you lost your mind?"

translate english ch04_cabin02_1b25416b:

    a "Is that seriously what you're asking me?"

translate english ch04_cabin02_4fa520ea:

    a "Oh, and he had a rock-hard boner from the second we got to the beach until we left."

translate english ch04_cabin02_9ce98487:

    a "It must be nice to be young."

translate english ch04_cabin02_d4367265:

    a "Must've been three hours straight."

translate english ch04_cabin02_19465cbe:

    d "Please... it wasn't like that..."

translate english ch04_cabin02_6c065e03:

    d "I'm sorry, Amanda... Ugh..."

translate english ch04_cabin02_165445bd:

    d "I must've completely lost my mind..."

translate english ch04_cabin02_ee8936f8:

    o "..................."

translate english ch04_cabin02_6490c8a2:

    o "**(Have these two already done it?)**"

translate english ch04_cabin02_e842596d_1:

    o "........"

translate english ch04_cabin02_2aea8be3:

    o "**(Haven't they already had sex??)**"

translate english ch04_cabin03_e8fc7dce:

    a "Oh! Then, when I rolled over to go to sleep..."

translate english ch04_cabin03_2f53747f:

    a "Hahahaha."

translate english ch04_cabin03_4b2bb759:

    a "He tried to shove his cock right up my ass."

translate english ch04_cabin03_fa8dfa56:

    o "Cough!"

translate english ch04_cabin03_37133a04:

    o "Cough! Cough!"

translate english ch04_cabin03_baea5bd4:

    o "!!!!!!"

translate english ch04_cabin03_006f532e:

    o "What did you just say?........"

translate english ch04_cabin03_25ba0e2f:

    o "......"

translate english ch04_cabin03_45c99343:

    n "As Amanda's story continued, Olivia found herself struggling to process what she was hearing."

translate english ch04_cabin03_cbfa621e:

    n "She had been playfully flirting with [d_name] herself, never entirely serious."

translate english ch04_cabin03_b025eb50:

    n "Even so, what Amanda described completely caught her off guard."

translate english ch04_cabin03_0a0bdb98:

    o "He tried to put what... in your ass?!!"

translate english ch04_cabin03_25ba0e2f_1:

    o "......"

translate english ch04_cabin03_3be4b633:

    o "Is that really true, [d_name]?!!"

translate english ch04_cabin03_edbb7d05:

    d "........"

translate english ch04_cabin03_e4d72c08:

    d "I-I..."

translate english ch04_cabin03_33bfa616:

    d "Ugh..."

translate english ch04_cabin03_edbb7d05_1:

    d "........"

translate english ch04_cabin03_c04a6af5:

    d "I just wanted to make Amanda feel good..."

translate english ch04_cabin03_88cbf3b2:

    d "I mean..."

translate english ch04_cabin03_4eb42b19:

    d "I guess I just lost control... like a moth to a flame..."

translate english ch04_cabin03_a7d61c02:

    o "Like a moth to a flame?...."

translate english ch04_cabin03_e842596d:

    o "........"

translate english ch04_cabin03_184d8352:

    o "Oh my God..."

translate english ch04_cabin03_6dd334c8:

    a "Hahaha."

translate english ch04_cabin03_9dedd39b:

    a "Even with me staring at him in disbelief, he just kept trying to shove it in anyway."

translate english ch04_cabin03_61d0a554:

    a "What am I, a sex doll? Hahahaha."

translate english ch04_cabin03_9a20c93e:

    d "I mean... that's not..."

translate english ch04_cabin03_bd20ba06:

    d "It's not like I was actually trying to... you know..."

translate english ch04_cabin03_7f98bce4:

    d "Ugh..."

translate english ch04_cabin03_a6ae4c95:

    d "I must've lost my mind..."

translate english ch04_cabin03_f2c5cbc7:

    d "I mean..."

translate english ch04_cabin03_00ab392a:

    d "It was kind of..."

translate english ch04_cabin03_e842596d_1:

    o "........"

translate english ch04_cabin03_cad97991:

    d "Kind of..."

translate english ch04_cabin03_88b63258:

    d "Something I did without even thinking..."

translate english ch04_cabin03_d54cfd2f:

    a "Hahahaha..."

translate english ch04_cabin03_56d355f6:

    a "Honey..."

translate english ch04_cabin03_89e4a711:

    a "Next time, at least spit on your cock before you try that, okay?"

translate english ch04_cabin03_af1b2aa2:

    o "Amanda, stop it!"

translate english ch04_cabin03_e5c36b54:

    d "..........."

translate english ch04_cabin03_6994db9d:

    a "If you'd aimed for my pussy, it would've slid right in, you idiot. Hahahaha."

translate english ch04_cabin03_769bcf98:

    o "Amanda!! Have you lost your mind?!"

translate english ch04_cabin03_e45528c9:

    a "Whew..."

translate english ch04_cabin03_8edfdf07:

    a "I still can't believe this brat actually shoved his cock at me..."

translate english ch04_cabin03_237cdd3a:

    a "What is this world coming to..."

translate english ch04_cabin03_ac335475:

    n "For a moment, silence settled over the table."

translate english ch04_cabin03_1db5cf15:

    n "It was hard to tell just how drunk they were, but each of them was lost in their own private thoughts."

translate english ch04_cabin03_73907d8c:

    n "The three of them fell silent for a while, taking another drink."

translate english ch04_cabin04_0f412ad3:

    n "Amanda and Olivia kept refilling their glasses."

translate english ch04_cabin04_3e775e19:

    n "As more empty glasses piled up on the table, the sisters became noticeably drunker."

translate english ch04_cabin04_fd1f8511:

    n "Now thoroughly tipsy, the sisters all but forgot about [d_name] and slipped into their own conversation."

translate english ch04_cabin04_dbf85074:

    a "Oh, are we seriously still talking about that?"

translate english ch04_cabin04_9714badf:

    a "You gonna bring it up at my funeral too?"

translate english ch04_cabin04_c06aabfc:

    o "That's why you have no room to judge his ex!"

translate english ch04_cabin04_501041bc:

    o "You're the one who stole my boyfriend back then."

translate english ch04_cabin04_14199b78:

    a "Whew..."

translate english ch04_cabin04_c46d2e55:

    a "You're really bringing up something from over twenty years ago?"

translate english ch04_cabin04_c4432429:

    o "You selfish bitch!"

translate english ch04_cabin04_1197a451:

    a "Watch your mouth when you're talking to your sister, bitch!"

translate english ch04_cabin04_77673f80:

    d "........."

translate english ch04_cabin04_9f811992:

    a "And get your story straight."

translate english ch04_cabin04_f8ccdcb6:

    a "That asshole never told me he was seeing you. He lied to me."

translate english ch04_cabin04_64d91938:

    a "Do you really think I'm crazy enough to date a guy who's seeing my little sister?"

translate english ch04_cabin04_5b850a7f:

    o "Hahaha."

translate english ch04_cabin04_6cbd768a:

    o "..............."

translate english ch04_cabin04_27b6dd59:

    o "But damn, he was packing."

translate english ch04_cabin04_e1402938:

    a "Sigh..."

translate english ch04_cabin04_ec2527cc:

    a "Wow, this stuff really goes down easy."

translate english ch04_cabin04_77673f80_1:

    d "........."

translate english ch04_cabin04_f74e2faf:

    d "**(Damn... Amanda can really hold her liquor...)**"

translate english ch04_cabin04_8d2cbd2a:

    o "He was definitely packing..."

translate english ch04_cabin04_cff83ec8:

    o "Then again, he was an athlete, so of course he had insane stamina. Hahaha."

translate english ch04_cabin04_ecf2e47e:

    o "He's the one who showed me what great sex was like. Hehe."

translate english ch04_cabin04_936ea5e4:

    d "**(.............)**"

translate english ch04_cabin04_16f0adc7:

    d "**(What great sex was like...)**"

translate english ch04_cabin04_20f6670c:

    a "Hmm..."

translate english ch04_cabin04_a527d883:

    a "Yeah, he was definitely well-endowed."

translate english ch04_cabin04_2dc90255:

    a "I'd say he was about the same size as [d_name]."

translate english ch04_cabin04_ed614ced:

    a "Actually... no. [d_name]'s definitely thicker."

translate english ch04_cabin04_a891ab84:

    o "What?"

translate english ch04_cabin04_7d068145:

    o "What, is his dick as big as your arm? Hahaha."

translate english ch04_cabin04_44237aa4:

    o "Now you've got me curious."

translate english ch04_cabin04_4bdb03c8:

    a "Hehe."

translate english ch04_cabin04_79e412b5:

    a "Wow, this booze is stronger than I remembered!!"

translate english ch04_cabin04_f5f1a4eb:

    o "Told you. Hahaha."

translate english ch04_cabin04_7c502394:

    o "This isn't something I break out just anytime."

translate english ch04_cabin04_d3e5d7b2:

    o "It's the most expensive bottle in the house."

translate english ch04_cabin04_2d6b34ef:

    o "I was saving it for after I won my divorce case..."

translate english ch04_cabin04_ba77a0ec:

    o "Time really flies..."

translate english ch04_cabin04_b2ff42be:

    o "Can't believe it's been over twenty years already..."

translate english ch04_cabin04_33dd0fc6:

    a "I know."

translate english ch04_cabin04_0d0c3148:

    a "Time really does fly."

translate english ch04_cabin04_aa9d1629:

    a "I still think about him once in a while."

translate english ch04_cabin04_e912dd18:

    a "Wonder what he's doing these days..."

translate english ch04_cabin04_242cc9b4:

    o "What's gotten into you? Getting all nostalgic on us?"

translate english ch04_cabin04_6db6e027:

    a "Hehe..."

translate english ch04_cabin04_44aaccfb:

    a "It's not that. It's just... we made a lot of unforgettable memories back then."

translate english ch04_cabin04_49d27738:

    a "Those were some of the best years of my life, that's all..."

translate english ch04_cabin04_3bf69761:

    a "Did you ever hear what happened between us and that guy?"

translate english ch04_cabin04_8096b08a:

    d "Huh?"

translate english ch04_cabin04_176330b0:

    o "Oh no... what are you about to tell him now?"

translate english ch04_cabin04_49118f5d:

    o "I swear, you always make me nervous when you drink."

translate english ch04_cabin04_064dda5e:

    a "Ollie and I fought over him so much that we ended up..."

translate english ch04_cabin04_2d32b5ce:

    a "We ended up having a three..."

translate english ch04_cabin04_9adcadfb:

    o "!!!!!"

translate english ch04_cabin04_39cab2c2:

    a "Mmph..."

translate english ch04_cabin04_9adcadfb_1:

    o "!!!!!"

translate english ch04_cabin04_39cab2c2_1:

    a "Mmph..."

translate english ch04_cabin04_66948d4b:

    o "Hahaha. You really do say the craziest things."

translate english ch04_cabin04_b85878c9:

    o "You've definitely had too much to drink."

translate english ch04_cabin04_40f06115:

    o "Why are you telling stories that never even happened?"

translate english ch04_cabin04_74046a02:

    o "What are you saying in front of [d_name]?"

translate english ch04_cabin04_e548b611:

    a "Oh, shut up. I'm not drunk!!"

translate english ch04_cabin04_34ed903f:

    a "Wait... wasn't it a foursome after his little brother showed up?"

translate english ch04_cabin04_cb231901:

    a "I'm remembering that right, aren't I?"

translate english ch04_cabin04_6c57a9e6:

    o "That never happened, you crazy bitch!!!"

translate english ch04_cabin04_ac48d631:

    a "Sigh..."

translate english ch04_cabin04_eb7b4f0e:

    a "I was quite the catch back then..."

translate english ch04_cabin04_967a80a4:

    a "Guys used to line up down the block for me..."

translate english ch04_cabin04_607d60ac:

    a "God... how the hell did I end up married to a man like Frank..."

translate english ch04_cabin04_5b06dbeb:

    n "Amanda's words struck a chord deep inside Olivia."

translate english ch04_cabin04_e7225556:

    n "With her own divorce looming, she understood better than anyone how miserable Amanda's marriage had become."

translate english ch04_cabin04_a9ac90fb:

    a "Damn you, Frank."

translate english ch04_cabin04_c6d473b9:

    a "Hey, [d_name]!!"

translate english ch04_cabin04_399db8e5:

    a "............"

translate english ch04_cabin04_69f0fc45:

    a "You little idiot!!!"

translate english ch04_cabin04_77673f80_2:

    d "........."

translate english ch04_cabin04_38e10aa6:

    a "Do you want to fuck me?"

translate english ch04_cabin04_f4f9b1e1:

    d "Huh?....."

translate english ch04_cabin04_399db8e5_1:

    a "............"

translate english ch04_cabin04_efefad15:

    a "Don't you understand English?"

translate english ch04_cabin04_399db8e5_2:

    a "............"

translate english ch04_cabin04_f69ec95e:

    a "Do you wanna fuck my brains out or not?"

translate english ch04_cabin04_ad893dfa:

    d "......"

translate english ch04_cabin04_b2b821d1:

    a "........."

translate english ch04_cabin04_dc1802ff:

    a "You still wanna stick it in my pussy, don't you?"

translate english ch04_cabin04_b2b821d1_1:

    a "........."

translate english ch04_cabin04_d3a2b4b3:

    a "Or is it my ass you're after?"

translate english ch04_cabin04_5de3e0a9:

    o "Amanda..."

translate english ch04_cabin04_7c0a9214:

    d ".............."

translate english ch04_cabin04_b9caf542:

    a "You wanna sleep with me, don't you?"

translate english ch04_cabin04_32b9bb5a:

    a "No... you're dying to fuck Olivia right now, aren't you?"

translate english ch04_cabin04_7c0a9214_1:

    d ".............."

translate english ch04_cabin04_ba1f7abf:

    a "Kids these days treat sex like it's just another sport, don't they?"

translate english ch04_cabin04_188ec10f:

    a "You all fuck first and decide whether you even want to date afterward, right?"

translate english ch04_cabin04_bcecb754:

    a ".........."

translate english ch04_cabin04_4a56e78f:

    a "How about the three of us fuck right here?"

translate english ch04_cabin04_d4eeb728:

    n "Amanda's words caught him completely off guard."

translate english ch04_cabin04_1705a2dc:

    n "And yet, deep down, part of him wished it really would happen."

translate english ch04_cabin04_10a47def:

    n "For the briefest moment, his mind wandered to something else."

translate english ch04_cabin04_73acfc19:

    n "What would happen to the relationship between the three of them if they actually went through with it?"

translate english ch04_cabin04_0efcf793:

    n "The thought was absurd... and strangely hard to shake."

translate english ch04_cabin04_6293b514:

    o "Oh my God..."

translate english ch04_cabin04_4539b39f:

    o "You've had way too much to drink, Amanda."

translate english ch04_cabin04_6e29ae50:

    o "I think you're exhausted."

translate english ch04_cabin04_2d4248b6:

    o "Come on, let's get you to bed."

translate english ch04_cabin04_dafc9f28:

    a "Shut the fuck up."

translate english ch04_cabin04_f107ff05:

    a "You cock-crazy bitch."

translate english ch04_cabin04_9a104b70:

    o "............"

translate english ch04_cabin04_6223fdd9:

    o "Really?"

translate english ch04_cabin04_7c159184:

    o "So... wanna fuck?"

translate english ch04_cabin04_0a2f96d2:

    d "???!!!"

translate english ch04_cabin04_8f18d97f:

    o "What do you think?"

translate english ch04_cabin04_0b778c47:

    o "Frank's gone. My husband's gone. Nobody's here to stop us."

translate english ch04_cabin04_117dc559:

    o "Let's fuck our brains out here in the middle of nowhere."

translate english ch04_cabin04_4e7ca7a7:

    o "Sounds perfect. Drink, fuck, drink, fuck..."

translate english ch04_cabin04_9a104b70_1:

    o "............"

translate english ch04_cabin04_582f735a:

    o "Come on, Amanda. Take your clothes off."

translate english ch04_cabin04_ccb0bc07:

    o "I'll strip too."

translate english ch04_cabin04_55c02367:

    a "......."

translate english ch04_cabin04_bc7e63c6:

    a "Shut up, you crazy bitch."

translate english ch04_cabin04_434cab81:

    a "I'm not the crazy one."

translate english ch04_cabin04_b2b821d1_2:

    a "........."

translate english ch04_cabin04_8f70c5f3:

    a "But you two are out of your minds, so I'm sure you'll get into something tonight, won't you?!"

translate english ch04_cabin04_b2b821d1_3:

    a "........."

translate english ch04_cabin04_ee6db636:

    a "This damn world..."

translate english ch04_cabin04_937d717b:

    a "What the hell has this world come to..."

translate english ch04_cabin04_7cfe7162:

    a "Urgh..."

translate english ch04_cabin04_c28a8e4f:

    d "Damn..."

translate english ch04_cabin04_4cd15d58:

    d "....."

translate english ch04_cabin04_c2dbc575:

    d "What the hell have I done to Amanda...?"

translate english ch04_cabin04_22b19dfa:

    d "What kind of person am I...?"

translate english ch04_cabin05_2ae15012:

    o "Phew..."

translate english ch04_cabin05_e3c7ac3c:

    o "What a night. Hahaha."

translate english ch04_cabin05_d36172d0:

    n "A little while later, after putting Amanda to bed, Olivia came back."

translate english ch04_cabin05_55fc7307:

    n "[d_name] could tell she was drunk too."

translate english ch04_cabin05_a413ee90:

    n "There was a warmth in her voice that hadn't been there before."

translate english ch04_cabin05_54e69972:

    o "You okay?"

translate english ch04_cabin05_dc18d7e6:

    d "Yeah......"

translate english ch04_cabin05_a4651670:

    d "Is Amanda alright?"

translate english ch04_cabin05_dfd2d9fb:

    o "Yeah. She's asleep."

translate english ch04_cabin05_859781b6:

    o "I've never seen her this drunk before."

translate english ch04_cabin05_a0d646fd:

    d "I think I really hurt her."

translate english ch04_cabin05_bb8ec33e:

    o "No, no. She's just drunk, that's all."

translate english ch04_cabin05_90389c9b:

    o "She probably won't even remember any of this tomorrow. Hahaha."

translate english ch04_cabin05_30795e2d:

    n "For a while, the two of them sat together in silence."

translate english ch04_cabin05_6f1f418a:

    n "The conversation from earlier lingered in both of their minds as they sat together in silence."

translate english ch04_cabin05_12065254:

    o "Frank and Amanda have had their share of problems lately..."

translate english ch04_cabin05_9a104b70:

    o "............"

translate english ch04_cabin05_e14e822a:

    o "Good Lord... Amanda."

translate english ch04_cabin05_d3bd822f:

    o "She really is something else."

translate english ch04_cabin05_a151db34:

    o "......."

translate english ch04_cabin05_a28773a8:

    o "Amanda was something of a legend when she was younger..."

translate english ch04_cabin05_42d91d79:

    o "Every guy in town knew who she was..."

translate english ch04_cabin05_0c370b97:

    o "She had a way of wrapping men around her finger..."

translate english ch04_cabin05_a151db34_1:

    o "......."

translate english ch04_cabin05_e5c36b54:

    d "..........."

translate english ch04_cabin05_518a5a12:

    d "I can believe that."

translate english ch04_cabin05_4805daf1:

    o "So... nothing since then?"

translate english ch04_cabin05_f96c0300:

    o "..........."

translate english ch04_cabin05_a0836f44:

    d "Nothing?"

translate english ch04_cabin05_cefb6598:

    o "I'm talking about sex."

translate english ch04_cabin05_fe2d8a5e:

    o "After you slept with your girlfriend in college, was that really the last time?"

translate english ch04_cabin05_8b7a5c2b:

    d "Ah..."

translate english ch04_cabin05_2f3acb3f:

    d "Well..."

translate english ch04_cabin05_e842596d:

    o "........"

translate english ch04_cabin05_6e9739d0:

    o "Now that I think about it...When was the last time for me?"

translate english ch04_cabin05_830e68cc:

    o "Hehe..."

translate english ch04_cabin05_7c294a64:

    d "Actually..."

translate english ch04_cabin05_b4f3cee8:

    d "Well..."

translate english ch04_cabin05_6b8511b5:

    d "I... actually did it at the beach today..."

translate english ch04_cabin05_e842596d_1:

    o "........"

translate english ch04_cabin05_debffffa:

    o "What?!!!!"

translate english ch04_cabin05_0897af19:

    o "You had sex with Amanda on the beach?!!!!"

translate english ch04_cabin05_c69eb625:

    o "You're serious??!!"

translate english ch04_cabin05_11ffb864:

    o "You actually had sex with Amanda today?!??"

translate english ch04_cabin05_afa8a415:

    d "N-No!!"

translate english ch04_cabin05_9ad6ed83:

    d "What are you talking about?! How could I possibly have sex with Amanda?!"

translate english ch04_cabin05_35600e89:

    o "I'm kidding, I'm kidding. Hahaha..."

translate english ch04_cabin05_9f384fb4:

    d "Huh??"

translate english ch04_cabin05_5e8e7478:

    o "Why'd you freak out like that?"

translate english ch04_cabin05_e842596d_2:

    o "........"

translate english ch04_cabin05_3a5d6947:

    o "There's nothing wrong with sleeping with Amanda."

translate english ch04_cabin05_1470a7c0:

    o "The world's not gonna end if you do."

translate english ch04_cabin05_5b2fa9f6:

    d "Huh?..."

translate english ch04_cabin05_80ffc447:

    o "Why are you looking at me like that?"

translate english ch04_cabin05_1df19198:

    o "Hahaha. You tried to stick it in her ass, didn't you?"

translate english ch04_cabin05_bdc69b67:

    o "Maybe you'll sleep with Amanda someday. Maybe you'll sleep with me."

translate english ch04_cabin05_d226b6b8:

    o ".........."

translate english ch04_cabin05_8b02866b:

    o "Maybe Mary from the orphanage. Maybe your college professor."

translate english ch04_cabin05_6a21657e:

    d "..............."

translate english ch04_cabin05_ed7ab3b0:

    o "Maybe your landlady."

translate english ch04_cabin05_499b8d75:

    o "Or your ex-girlfriend's mom. Or one of the women who works at my restaurant."

translate english ch04_cabin05_c35185f5:

    d "Oh my God..."

translate english ch04_cabin05_f30b0645:

    d "That only happens in porn…I think…"

translate english ch04_cabin05_d226b6b8_1:

    o ".........."

translate english ch04_cabin05_6f4eeb57:

    o "Just remember one thing."

translate english ch04_cabin05_c00daa17:

    o "Men have a lot more freedom when it comes to sex."

translate english ch04_cabin05_c855a033:

    o "Both physically and mentally."

translate english ch04_cabin05_c086a0e4:

    o "You know what I mean?"

translate english ch04_cabin05_9eaf6c80:

    o "The hard part is finding a woman who's willing."

translate english ch04_cabin05_66d34440:

    o "Women, on the other hand, are the ones who get to choose their partners."

translate english ch04_cabin05_eaa6b9eb:

    o "Men are the ones who have to be chosen."

translate english ch04_cabin05_a9eac334:

    o "So even if you're popular with women, don't sleep with just anyone."

translate english ch04_cabin05_b9e8839d:

    o "And if you're not, don't go desperately chasing after women either. It just makes you look pathetic."

translate english ch04_cabin05_faf64626:

    o "Got it?"

translate english ch04_cabin05_45c5a0ac:

    o "I'm saying, never become that pathetic kind of man."

translate english ch04_cabin05_0a1df568:

    o "If the opportunity comes, you take it..."

translate english ch04_cabin05_a151db34_2:

    o "......."

translate english ch04_cabin05_070f2edf:

    o "You do it when the moment naturally comes."

translate english ch04_cabin05_6985ed36:

    n "With that, she picked up her drink and walked over to the couch."

translate english ch04_cabin05_40f230d3:

    n "She tried not to show it, but the alcohol had made her steps unsteady."

translate english ch04_cabin05_8e695e44:

    o "Phew..."

translate english ch04_cabin05_8e9fd869:

    o "You just let it happen when the mood naturally feels right..."

translate english ch04_cabin05_bab87dfd:

    o "Ah... this is nice..."

translate english ch04_cabin05_25ba0e2f:

    o "......"

translate english ch04_cabin05_28364b28:

    d "Sleepy?"

translate english ch04_cabin05_25ba0e2f_1:

    o "......"

translate english ch04_cabin05_65c99003:

    o "A little."

translate english ch04_cabin05_e76c80b6:

    d "I'm getting tired too..."

translate english ch04_cabin05_96dc48b2:

    o "I think I'm gonna call it a night..."

translate english ch04_cabin05_f96c0300_1:

    o "..........."

translate english ch04_cabin05_8a824250:

    o "Is it really as big as Amanda says?"

translate english ch04_cabin05_8096b08a:

    d "Huh?"

translate english ch04_cabin05_11bf4ead:

    o "Do you stay hard for long?"

translate english ch04_cabin05_56bf299a:

    d "...."

translate english ch04_cabin05_f79117c4:

    d "Stay hard?"

translate english ch04_cabin05_aaed2e5a:

    o "Yeah, get an erection."

translate english ch04_cabin05_1bd8322c:

    o "From what I can tell, it looks like you're packing something pretty nice down there."

translate english ch04_cabin05_c9e74566:

    o "....."

translate english ch04_cabin05_d76c11bc:

    o "When Amanda talks about your cock, her whole face just lights up..."

translate english ch04_cabin05_e842596d_3:

    o "........"

translate english ch04_cabin05_542bc44e:

    o "I wonder just how impressive your cock must have been..."

translate english ch04_cabin05_09584dc5:

    o "Am I right?"

translate english ch04_cabin05_fac8215b:

    d "............"

translate english strings:
    old "그녀에게 가까이 간다."
    new "Walk over to her."

translate english strings:
    old "작지는 않은거 같아요 하하."
    new "I'd say it's pretty useful. Haha."

translate english ch04_cabin05_92f21ed5:

    n ""

translate english ch04_cabin05_bd2f5021:

    o "??"

translate english ch04_cabin05_e819bdbe:

    n "He walked over and stopped in front of Olivia, his hand resting on the zipper of his pants."

translate english ch04_cabin05_6215acf1:

    n "A rush of excitement ran through him as he remembered the first time he had shown Mary his cock."

translate english ch04_cabin05_7e36d751:

    n "Knowing Olivia was drunk only made the thrill even stronger."

translate english strings:
    old "고추를 꺼내서 그녀에게 보여준다."
    new "Take out your cock and show it to her."

translate english ch04_cabin05_f96c0300_2:

    o "..........."

translate english ch04_cabin05_3e6026de:

    n "When Olivia opened her eyes, [d_name]'s fully erect cock was right in front of her."

translate english ch04_cabin05_0d697235:

    n "She'd been drifting in and out of sleep, and it took her a moment to realize what she was seeing was real."

translate english ch04_cabin05_bc0498f6:

    n "[d_name]'s cock was even bigger than she had imagined."

translate english ch04_cabin05_fd4b918f:

    n "A moment after he pulled down his pants, his scent drifted toward Olivia."

translate english ch04_cabin05_89808873:

    d "So?"

translate english ch04_cabin05_169b3481:

    d "Think women would be happy with this?"

translate english ch04_cabin05_6a21657e_1:

    d "..............."

translate english ch04_cabin05_f4a27b1d:

    o "Oh my God, [d_name]..."

translate english ch04_cabin05_c9ff3cfe:

    o "What are you..."

translate english ch04_cabin05_a99ebf8b:

    o "I'm not that drunk, you know."

translate english ch04_cabin05_a151db34_3:

    o "......."

translate english ch04_cabin05_3e17a777:

    o "Sigh... you really are a fool."

translate english ch04_cabin05_f04046c5:

    d "Well, I got a look at yours today too."

translate english ch04_cabin05_fac8215b_1:

    d "............"

translate english ch04_cabin05_faabaf7b:

    d "I'd say we're even."

translate english ch04_cabin05_89808873_1:

    d "So? what do you think?"

translate english ch04_cabin05_0f1b715c:

    d "Think I've got a pretty nice cock?"

translate english ch04_cabin05_77673f80:

    d "........."

translate english ch04_cabin05_8af402f9:

    o "You want to know if you've got a nice cock?"

translate english ch04_cabin05_a151db34_4:

    o "......."

translate english ch04_cabin05_d226b6b8_2:

    o ".........."

translate english ch04_cabin05_ead4675b:

    n "If she had been completely sober, she probably wouldn't have said a word."

translate english ch04_cabin05_acaa4084:

    n "But with the alcohol loosening her inhibitions, Olivia took a long look at [d_name]'s cock."

translate english ch04_cabin05_beff0f62:

    n "She steadied her breathing and gave it an honest appraisal."

translate english ch04_cabin05_cc92a42c:

    o "Impressive."

translate english ch04_cabin05_f96c0300_3:

    o "..........."

translate english ch04_cabin05_cc5d4db4:

    o "Really impressive, honey..."

translate english ch04_cabin05_e842596d_4:

    o "........"

translate english ch04_cabin05_19c3bb2c:

    o "But you're still too inexperienced..."

translate english ch04_cabin05_52f5b845:

    o "You've got the hardware, but you don't know how to use it yet..."

translate english ch04_cabin05_894fcb4a:

    d "What do you mean?"

translate english ch04_cabin05_f1b1cfc6:

    o "........."

translate english ch04_cabin05_29dfce84:

    o "Your cock isn't what matters most..."

translate english ch04_cabin05_5850752a:

    o "Before that, it's all about the vibe..."

translate english ch04_cabin05_fa59f251:

    o "No woman wants to get fucked by some awkward, clumsy boy."

translate english ch04_cabin05_37b86382:

    o "You can't just shove your dick in a woman's face."

translate english ch04_cabin05_2625bb78:

    o "It's about the vibe, not the size..."

translate english ch04_cabin05_25ba0e2f_2:

    o "......"

translate english ch04_cabin05_87bb3b67:

    o "It's the chemistry... not the size."

translate english ch04_cabin05_322d36c5:

    o "Sigh.........."

translate english ch04_cabin05_84311b2c:

    o "Oh, [d_name]..You really have no shame, do you?"

translate english ch04_cabin05_c05c350c:

    o "**(.........)**"

translate english ch04_cabin05_46b41b84:

    o "**(Oh my God.......)**"

translate english ch04_cabin05_c9dccd84:

    o "**(This might just push me over the edge...)**"

translate english ch04_cabin05_203cc60b:

    d "......."

translate english ch04_cabin05_a797f6ce:

    d "............."

translate english ch04_cabin05_c8e3dd18:

    d "Haha... why are you looking at me like that?..."

translate english ch04_cabin05_f4a38ecd:

    o "Quit bothering Amanda and go sleep in the other room."

translate english ch04_cabin05_5e3aec4e:

    d ".........."

translate english ch04_cabin05_0d4a8c7c:

    d "I don't think it's exactly small. Haha."

translate english ch04_cabin05_9e9670b8:

    o "Hahaha. Is that so?"

translate english ch04_cabin05_57375319:

    o "Sounds like someone's pretty confident."

translate english ch04_cabin05_aa61162d:

    d "Want to find out?"

translate english ch04_cabin05_f1b1cfc6_1:

    o "........."

translate english ch04_cabin05_4db717b3:

    d "Should I take it out?"

translate english ch04_cabin05_f4e51997:

    o "............."

translate english ch04_cabin05_94137485:

    o "Hmm... not tonight..."

translate english ch04_cabin05_748efa6e:

    o "God, I'm sleepy..."

translate english ch04_cabin05_d226b6b8_3:

    o ".........."

translate english ch04_cabin05_455b0429:

    o "[d_name]..."

translate english ch04_cabin05_98c0e620:

    o "[d_name]...[d_name]..."

translate english ch04_cabin05_ebaf00a7:

    o "[d_name]...[d_name]...[d_name]..."

translate english ch04_cabin05_bc2266e9:

    o "I'm sure I'll get another chance to see it."

translate english ch04_cabin05_f4a38ecd_1:

    o "Don't bother Amanda. Go sleep in the other room."

translate english ch04_cabin05_11a8849c:

    o "Okay?"

translate english ch04_cabin05_33bf8f25:

    d "Yes, ma'am."

translate english ch04_cabin05_f8ae30aa:

    d "Good night, Oli."

translate english ch04_cabin05_5e3aec4e_1:

    d ".........."

translate english ch04_cabin06_a797f6ce:

    d "............."

translate english ch04_cabin06_d76a603a:

    d "Damn... what time is it?"

translate english ch04_cabin06_4a249208:

    d "I can't sleep... I just can't sleep..."

translate english ch04_cabin06_7f98bce4:

    d "Sigh..."

translate english ch04_cabin06_2b63ae6b:

    d "My mysterious stranger..."

translate english ch04_cabin06_203cc60b:

    d "......."

translate english ch04_cabin06_2e33d419:

    d "I wonder how old she is..."

translate english ch04_cabin06_c0fa45ca:

    d "In her thirties?"

translate english ch04_cabin06_49a4a3cb:

    d "Forties?"

translate english ch04_cabin06_203cc60b_1:

    d "......."

translate english ch04_cabin06_8c1ae206:

    d "She was only the second woman I've ever slept with..."

translate english ch04_cabin06_60ec3e4f:

    d "Phew........"

translate english ch04_cabin06_edbb7d05:

    d "........"

translate english ch04_cabin06_30065d88:

    d "I should've at least asked for her number..."

translate english ch04_cabin06_4cd15d58:

    d "....."

translate english ch04_cabin06_b742fc42:

    d "What a shame..."

translate english ch04_cabin06_c779ee7f:

    n "Giggle"

translate english ch04_cabin06_a6ce4ca6:

    n "As he took a drink of water, he heard a faint laugh coming from outside."

translate english ch04_cabin06_77082a5e:

    n "Olivia was sitting alone on the patio."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
