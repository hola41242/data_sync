translate english set_woman_name_7fbffb46:

    n "Here's the heroine of this story."

translate english set_woman_name_95d14d08:

    n "She's a quiet, but deeply scarred middle-aged woman.\nNo one knows what dark things have happened in her past."

translate english set_woman_name_050ab755:

    n "You can name her or go with the default name."

translate english set_mc_name_f37c96a6:

    n "He's the hero of this story."

translate english set_mc_name_2692b8b3:

    n "This young man grew up in a youth center and a foster home and is now a university student. \nFor the vacation, he returned to his hometown. His past is shrouded in mystery."

translate english set_mc_name_3a43bec7:

    n "You can name him or go with the default name."

translate english set_mc_name_14278072:

    nCenter "presented by Bittersweet3D"

translate english v01_lecture01_65df89de:

    n "Milfheim University"

translate english v01_lecture01_e2d78309:

    s "Alright everyone, we've already reached the final chapter of this semester..."

translate english v01_lecture01_45e58cfa:

    s "Perhaps you'll gain insights that could be essential for your life."

translate english v01_lecture01_f06eb005:

    s "So please, focus and listen carefully."

translate english v01_lecture01_eb658754:

    s "In summary, psychology is not merely a discipline made up of theory alone."

translate english v01_lecture01_ecf2586c:

    s "Ultimately, it involves the act of deeply observing and understanding both our own minds and those of others."

translate english v01_lecture01_3c843da3:

    s "It’s a field that explores the subtle and hidden layers of emotions and behaviors we often fail to notice."

translate english v01_lecture01_4f94e8da:

    s "Why do we feel certain emotions in specific situations, and why do we act in ways we sometimes can’t explain... It’s about tracing those roots."

translate english v01_lecture01_ef46810b:

    s "But what’s important here is that this exploration isn’t about forcefully dissecting or controlling someone else’s mind."

translate english v01_lecture01_b857793c:

    s "It all begins with the skill to delicately analyze and understand one’s own mind."

translate english v01_lecture01_8cfd50be:

    s "It starts with asking yourself why you feel a certain way now, why you made certain choices in the past... Everything begins with understanding yourself deeply."

translate english v01_lecture01_72b28246:

    s "We often try to find the cause of our emotions in external situations or other people, but in truth, it often originates from the complex workings of our inner world."

translate english v01_lecture01_4d95e61f:

    s "The true purpose is ultimately to create a better life and healthier relationships."

translate english v01_lecture01_b3cfa1f6:

    s "It’s a constant effort to understand one another more deeply and, as a result, to form more genuine connections."

translate english v01_lecture01_32d42452:

    s "Think of psychology as a delicate tool that helps us see the tangled threads of emotion we share with others more clearly and transparently."

translate english v01_lecture01_2f8b02e1:

    s "Why are we so strongly drawn to someone—or, on the contrary, why do our feelings suddenly fade?"

translate english v01_lecture01_84fdc388:

    s "We aim to understand how complex emotions like love, friendship, and even hatred are formed and transformed."

translate english v01_lecture01_bf0ba319:

    s "I’m talking about those waves of emotion that hit your chest or fleeting sensations that words can’t describe."

translate english v01_lecture01_cfb5eec9:

    s "Even those, in fact, are reactions that arise from the deepest part of our mind, below the surface of consciousness."

translate english v01_lecture01_4e27b38d:

    s "The source of all these complex emotions and behaviors lies deep within the psyche—in the unconscious, which we can hardly control."

translate english v01_lecture01_ca685279:

    s "This unconscious isn’t merely a hidden darkness; it’s constantly shaped and reshaped by old memories, intense emotions, and countless experiences we never fully realized."

translate english v01_lecture01_c9f532ba:

    s "It becomes the vast foundation for everything we feel and judge in the present."

translate english v01_lecture01_45fda020:

    s "Whether you recognize its existence or not, or are aware of its influence or not, it still affects you all the same."

translate english v01_lecture01_4abbfe84:

    s "In the deepest parts of our minds—the unconscious—reactions have already begun, and what we experience are only the emotions and behaviors that surface as a result."

translate english v01_lecture01_a1cb78a7:

    s "Like a powerful current moving beneath the water’s surface."

translate english v01_lecture01_32d46c41:

    s "For example, when you’re alone with someone you really like, and suddenly your words get stuck while your heart races uncontrollably—you’ve all felt that at least once."

translate english v01_lecture01_9576bc05:

    s "There’s a kind of pull there that can’t simply be explained away as nervousness."

translate english v01_lecture01_c6e0bead:

    s "These experiences aren’t just momentary emotional shifts; they may be part of very complex psychological patterns woven together with past memories and experiences."

translate english v01_lecture01_a5b34b76:

    s "It might even mean that we’ve been unconsciously programmed to react in certain ways in specific situations or around certain people."

translate english v01_lecture01_77199c6e:

    s "Sometimes the unconscious whispers cold, intuitive judgments, separate from our conscious thoughts, as if saying—"

translate english v01_lecture01_24c7fe05:

    s "“This person seems dangerous, yet strangely attractive,” or “This person feels safe and comfortable, but somehow dull and boring.”"

translate english v01_lecture01_edd5b3e2:

    s "These unconscious messages profoundly affect our conscious decisions and actions."

translate english v01_lecture01_3cafc317:

    j "…Professor, then are you saying that even falling in love can be academically explained?"

translate english v01_lecture01_96fd087b:

    j "Can even such feelings be broken down into theories or patterns?"

translate english v01_lecture01_0665dc09:

    s "We can’t explain everything, but yes—much of it can indeed be explained."

translate english v01_lecture01_d82dbd69:

    s "Love as an emotion, and attraction as a phenomenon, are far more complex sums of countless feelings and experiences than we realize."

translate english v01_lecture01_6bdac939:

    s "Yet even within that complexity, clear flows and repeating patterns exist—it’s a scientific discovery in itself."

translate english v01_lecture01_fd9ef5b4:

    s "And understanding those patterns can greatly help us understand ourselves and others."

translate english v01_lecture01_db7c6ba8:

    s "Sometimes, the trigger that draws us strongly to someone doesn’t stem from their appearance or obvious traits, but from something much deeper within ourselves."

translate english v01_lecture01_1b155996:

    s "In unexpected moments, a person’s tone of voice, their unique way of speaking, a faint perfume scent, or even one casual remark may flash and connect with a significant past memory or emotional experience."

translate english v01_lecture01_823ee28b:

    s "Before rational judgment intervenes, our unconscious has already reacted—making us feel an inexplicable attraction to that person."

translate english v01_lecture01_a19ca1c6:

    s "This is the true power of the unconscious."

translate english v01_lecture01_7a70a6a3:

    d "Is that... something like a psychological wound?"

translate english v01_lecture01_3fb56565:

    d "Do the pain or loneliness we experienced in the past affect our current emotions?"

translate english v01_lecture01_ce871932:

    s "Exactly. The sense of lack or unfulfilled emotions we felt as children can still draw us toward others as adults."

translate english v01_lecture01_5df64977:

    s "For example, a child who was constantly ignored tends to be strangely drawn to someone who acknowledges them."

translate english v01_lecture01_05fce410:

    s "Freud called that the repetition compulsion."

translate english v01_lecture01_5eee10d2:

    s "Unresolved emotions buried in the unconscious repeatedly attract similar situations."

translate english v01_lecture01_d546f958:

    s "In the end, we often build new relationships through those unhealed emotions."

translate english v01_lecture01_80f81d82:

    s "So, I’ll give you an assignment for this vacation."

translate english v01_lecture01_f43f6f24:

    s "What’s more important than academic theory is how you apply it in real life."

translate english v01_lecture01_e1f0a4aa:

    s "Ask someone close to you, “What kind of person am I to you?”"

translate english v01_lecture01_ec04dc18:

    s "It could be a lover, a family member, or a friend—anyone is fine."

translate english v01_lecture01_021eb28e:

    s "That single question could change your relationship with that person."

translate english v01_lecture01_1c8c81b7:

    s "Of course, when you ask, make sure the timing and situation are appropriate so the other person doesn’t feel awkward or pressured."

translate english v01_lecture01_439a2fa2:

    s "Emotions are delicate and sensitive things. You must learn to handle them gently, like fragile porcelain. Rushing in recklessly is immature."

translate english v01_lecture01_ebe097bc:

    s "This assignment will serve as both a lesson in relationships and a test of your maturity."

translate english v01_lecture01_3bbd9022:

    j "Good lord."

translate english v01_lecture01_4ab42d4c:

    j "What a breathtaking view."

translate english v01_lecture01_65a39f4f:

    j "Is this some kind of hidden camera?"

translate english v01_lecture01_c4fff5eb:

    d "What?"

translate english v01_lecture01_708f6d1c:

    s "You’re following along, right, everyone?"

translate english v01_lecture01_3a226d37:

    j "Damn, I want to run up there and caress her ass."

translate english v01_lecture01_fa862938:

    j "If I could, I might actually die happy."

translate english v01_lecture01_b3c42144:

    d "Hey, vacation just started. Try staying alive first."

translate english v01_lecture01_b6c56915:

    s "Oops!"

translate english v01_lecture01_245450fa:

    s "(( ............ ))"

translate english v01_lecture01_12ed665e:

    s "Psychology isn’t a means to control relationships."

translate english v01_lecture01_5388b2aa:

    s "It’s not about the desire to manipulate someone, but rather the art of gently touching another person’s heart."

translate english v01_lecture01_e0530ec7:

    s "Whether that heart holds pain or hope… understanding it is the first step."

translate english v01_lecture01_e95cf295:

    s "Alright, that’s it for today’s class."

translate english v01_lecture01_f6c68d2a:

    s "Enjoy your vacation, and feel free to share your learning progress with me by email."

translate english v01_lecture01_a69475a4:

    s "Listening to your stories is always a great learning experience for me, too."

translate english v01_afterschool_7c40f46d:

    n "Finally, the last class of the semester ended."

translate english v01_afterschool_d7823d26:

    n "Sophia stood organizing her papers, lost in thought."

translate english v01_afterschool_6cce4fe6:

    n "Suddenly, she sensed someone approaching behind her."

translate english v01_afterschool_efad931f:

    n "The length of her skirt made her slightly self-conscious."

translate english v01_afterschool_572b4440:

    n "Her hands moved faster as she sorted the papers."

translate english v01_afterschool_09f736a6:

    s "….............."

translate english v01_afterschool_d2fee590:

    n "She recognized them as [d_name] and Jason, but feeling they were a bit rude, she didn't greet them warmly."

translate english v01_afterschool_944c823c:

    j "Professor, that was an amazing lecture today."

translate english v01_afterschool_e047e2bf:

    j "Seriously, my heart was pounding the whole time."

translate english v01_afterschool_835d16ac:

    j "It felt like a true moment of psychological awakening."

translate english v01_afterschool_663b737a:

    s "Jason, quite the passionate praise today. Remind me—who was the student nodding off when class started?"

translate english v01_afterschool_4e25c44d:

    s "And yet by the end, your eyes were sparkling. Don’t tell me it was my ass that finally woke you up?"

translate english v01_afterschool_63027523:

    s "I wonder if you were focusing on the wrong subject instead of the lecture."

translate english v01_afterschool_e5c8df11:

    dj "................"

translate english v01_afterschool_e7c78166:

    s "It would be a lie to say I’m not worried about your exam grades?"

translate english v01_afterschool_16e74ffb:

    s "but honestly, your honest reactions today were more impressive."

translate english v01_afterschool_27407994:

    j "No, professor."

translate english v01_afterschool_83a50285:

    j "Whenever I return to the dorm, I always replay your lectures in my mind."

translate english v01_afterschool_508ea96a:

    j "Your charismatic tone, subtle facial expressions, even the elegance of your gestures—everything. I truly find it amazing!"

translate english v01_afterschool_e5c8df11_1:

    dj "................"

translate english v01_afterschool_1035f99c:

    s "Even the gestures... that much detail? Jason, you’re not secretly recording and replaying it in slow motion, are you?"

translate english v01_afterschool_9ae33931:

    d "No, professor, I think I understand what Jason means."

translate english v01_afterschool_4dfac21b:

    d "Especially when you pick up your pen or write on the board—those movements are... intense, in a way."

translate english v01_afterschool_a25638cb:

    d "It felt like something broke through my psychological defenses. A wave of emotion hit me all at once. I could literally feel my heart rate rise."

translate english v01_afterschool_f355ac99:

    n "She hesitated for a moment, wondering how to handle them as they subtly crossed her boundaries, but then replied as if to agree."

translate english v01_afterschool_d95e9838:

    s "Hmm... Really? I didn't realize you'd notice such subtle details."

translate english v01_afterschool_57a1cd89:

    s "So, you only keep replaying my “hand gestures”? Were there no other parts... that caught your attention? Nothing else worth remembering?"

translate english v01_afterschool_08475b4f:

    s "Wasn’t there something even more impressive?"

translate english v01_afterschool_a0811801:

    n "They were speechless at Sofia's completely unexpected reaction."

translate english v01_afterschool_e5c8df11_2:

    dj "................"

translate english v01_afterschool_e0c6c17a:

    s "Haha, I’m just joking."

translate english v01_afterschool_734759c9:

    s "Sorry if I made you all uncomfortable."

translate english v01_afterschool_f1894c3c:

    s "[d_name], what are your plans for the vacation?"

translate english v01_afterschool_835538b3:

    d "I’m going back to my hometown."

translate english v01_afterschool_293e9a21:

    d "There are people I want to meet... and honestly, I just miss home."

translate english v01_afterschool_2b915734:

    s "Oh, that’s a wonderful idea! Excellent, really."

translate english v01_afterschool_5e9de481:

    s "It’s important to unwind and recharge after a long semester."

translate english v01_afterschool_b4b4e25a:

    s "Travel, experience new things, and most importantly—meet lots of people."

translate english v01_afterschool_c156513f:

    s "Through open conversations with different people, you might discover sides of yourself you never knew existed."

translate english v01_afterschool_c20a8967:

    s "Our hearts grow richer through relationships."

translate english v01_afterschool_bd589bff:

    d "Yeah, there are people I need to see back home."

translate english v01_afterschool_b9f1f057:

    d "And... I kind of want to get away from this guy for a bit. Hahaha."

translate english v01_afterschool_77be7007:

    s "Hahaha! I can understand that completely."

translate english v01_afterschool_fdf33a92:

    s "Alright then, if you ever have questions during vacation, feel free to email me anytime."

translate english v01_afterschool_c0830b24:

    s "Relationship advice, dating dilemmas—anything’s fine, even if you’re unsure what to ask someone you’re seeing."

translate english v01_afterschool_8a7f4490:

    d "Really? I’m not sure my messy love life is something you’d want to hear, professor. Hahaha."

translate english v01_afterschool_a2f9b3be:

    d "My romantic stories might even shake your composure as a psychologist!"

translate english v01_afterschool_f38c9bbe:

    n "She sensed they were appealing to the fact that they were men with more experience than their age suggested."

translate english v01_afterschool_40536051:

    n "And she thought they were no different from the countless freshmen she had seen throughout her life."

translate english v01_afterschool_5cce2c72:

    s "Hmm... Don’t worry, [d_name]."

translate english v01_afterschool_b8402362:

    s "I’ve been through every kind of battle in this field—nothing surprises me anymore. There’s nothing I can’t handle."

translate english v01_afterschool_c661207a:

    s "Giving advice on your young, innocent love stories would actually be fun for me. Don’t worry—your secrets are safe."

translate english v01_afterschool_77198567:

    s "Alright boys, see you again."

translate english v01_afterschool_d9f7887f:

    s "And until then... don’t forget to think of me often."

translate english v01_afterschool_fcd9333d:

    n "They could only stand watching as Sophia walked away."

translate english v01_afterschool_006bc0af:

    n "To their eyes, she was a mature woman, poised and confident, who knew exactly how to handle men."

translate english v01_afterschool_40c2795f:

    j "Damn, no one can beat a psychology professor. My mind’s in pieces."

translate english v01_afterschool_f69a7c0e:

    d "................"

translate english v01_afterschool_a88c3781:

    d "Jason, maybe we’re just rookies compared to her—barely dust on her heels. Let’s just consider this a lesson."

translate english v01_afterschool_c9e1ee9f:

    d "Even now, who knows how deeply the professor has already infiltrated our unconscious minds..."

translate english v01_restroom_579c67ae:

    s "(( Thank God... the semester’s finally over. ))"

translate english v01_restroom_2a2593f9:

    s "(( Still, those freshmen eyes were lively. Not bad. ))"

translate english v01_restroom_9a6f7469:

    s "(( The last few minutes are always the most exhausting. ))"

translate english v01_restroom_420fd81f:

    s "(( They listen so seriously at first, but toward the end, their eyes start to change. ))"

translate english v01_restroom_a77bdfdb:

    s "(( I envy that... that youthful energy that never fades all day long. ))"

translate english v01_restroom_c77b171d:

    s "(( Those boys... ))"

translate english v01_restroom_7adc015a:

    s "(( Sometimes they’re so predictable it’s almost funny. ))"

translate english v01_restroom_ad85c2b1:

    s "(( They don’t even try to hide it. Do they really think I wouldn’t notice? ))"

translate english v01_restroom_ee04fd02:

    s "(( Is it admiration, flirting, or just youthful mischief...? ))"

translate english v01_restroom_e57d40fd:

    s "(( First-years—they’re all the same. ))"

translate english v01_restroom_ad514876:

    s "(( Heh, those silly little boys think they know anything? This professor’s seen right through men’s minds for years. ))"

translate english v01_restroom_230f121a:

    s "(( Still... their reactions are so easy to read it’s oddly entertaining. I can see right through what they’re thinking. ))"

translate english v01_restroom_d2d6c0be:

    s "(( Attracted to an older woman, huh... ))"

translate english v01_restroom_f814fb0d:

    s "(( Such a classic trope. ))"

translate english v01_restroom_1b99dccf:

    s "(( And yet, I can’t say I fully understand why young men long for older women. ))"

translate english v01_restroom_b54353f7:

    s "(( Do they see me as a “woman”? Or just as a “body”? Or... both? ))"

translate english v01_restroom_aa5e4633:

    s "(( Oedipus complex, maybe? ))"

translate english v01_restroom_133a670b:

    s "(( It's just the instinct of males, I suppose. ))"

translate english v01_restroom_ed7d52f6:

    s "(( Haa... mirror, mirror... I’m not what I used to be. No matter how much I take care of myself, time always leaves its trace. ))"

translate english v01_restroom_95444a4b:

    s "(( Be honest, Sophia—you’re getting older. Stop pretending not to see it. ))"

translate english v01_restroom_4683541d:

    s "(( Still... my charm hasn’t gone anywhere, has it? ))"

translate english v01_restroom_1b99c4ab:

    s "(( Oh Jason... You replays my lectures at home every night? Ha. As if. ))"

translate english v01_restroom_5bde6803:

    s "(( Go on then, replay them all you want. ))"

translate english v01_restroom_53677135:

    s "(( He actually tried to pull that cheesy line on me. ))"

translate english v01_restroom_a68e1e18:

    s "Funny kid."

translate english v01_restroom_1810fd9e:

    s "(( How dare he flirt with his own professor. ))"

translate english v01_restroom_3b85a753:

    n "She was surprised to find herself feeling a little nervous."

translate english v01_restroom_fdb60a95:

    n "And as she opened her breast in front of the mirror, she felt a slight sense of liberation and her tension ease away."

translate english v01_restroom_baf73081:

    s "(( That [d_name] though... he’s a little different. ))"

translate english v01_restroom_d938407a:

    s "(( His eyes are oddly deep... and sometimes he gives that look, like he’s hiding something. ))"

translate english v01_restroom_e009fc5e:

    s "(( He’s... hard to read. ))"

translate english v01_restroom_17639ffb:

    s "(( Maybe he just wants to show he’s more refined than Jason? ))"

translate english v01_restroom_5b30f71d:

    s ".........."

translate english v01_restroom_10fe9619:

    s "............."

translate english v01_restroom_bdb4183b:

    s "(( Men—young or old.. ))"

translate english v01_restroom_e95b013d:

    s "(( They’re all the same. ))"

translate english v01_restroom_12bb0ab1:

    s "(( [d_name], you’re no different. ))"

translate english v01_restroom_659423f8:

    s "(( Don’t pretend to be so noble. ))"

translate english v01_dormroom_7d780bce:

    d "I could sleep straight through till next year."

translate english v01_dormroom_8c2b1622:

    d "Can’t believe the semester’s really over."

translate english v01_dormroom_9abd2638:

    d "I thought everyone would be partying and making noise everywhere."

translate english v01_dormroom_7c02502c:

    j "Don’t you feel kind of empty now that it’s over?"

translate english v01_dormroom_2b3998ce:

    j "Still, freedom starts now, haha."

translate english v01_dormroom_7dd174cc:

    j "I’m gonna game all day, maybe travel a bit too."

translate english v01_dormroom_30165a1f:

    j "Eat, sleep, game, sleep, game, sleep—"

translate english v01_dormroom_8b42323c:

    j "Wait a sec!"

translate english v01_dormroom_1a848ceb:

    j "That means I won’t see Professor Sophia for months!"

translate english v01_dormroom_b4554aa4:

    j "Damn it, how long am I supposed to live without my Sophia?"

translate english v01_dormroom_58bfd618:

    j "I haven’t even admired her long enough to picture her perfectly yet!"

translate english v01_dormroom_154c330e:

    j "Every time she writes on the board… that curve…"

translate english v01_dormroom_e7170101:

    d "Hahaha bro."

translate english v01_dormroom_e0b6fe2d:

    d "I was thinking the same thing."

translate english v01_dormroom_6df6f8ee:

    d "I’ve met a lot of women in my life, but Sophia’s the first truly hot MILF I’ve ever seen."

translate english v01_dormroom_ce7d40e3:

    d "When she looks at me, it feels like her eyes are stripping me naked."

translate english v01_dormroom_c5daeecf:

    d "Damn, she’s the treasure of this city—and this school."

translate english v01_dormroom_0636f9c9:

    d "The true mother of our generation..."

translate english v01_dormroom_a26bf7c3:

    d "But that body? She’s no mother—she’s a true goddess."

translate english v01_dormroom_d9a5f25b:

    j "Mother? Goddess? Don’t make me laugh."

translate english v01_dormroom_5742d4a5:

    j "To me, she’s a beautiful female. That’s all that matters."

translate english v01_dormroom_4d38b619:

    j "To hell with age."

translate english v01_dormroom_97ead996:

    j "Ah... I’m going to marry her."

translate english v01_dormroom_f74de685:

    j "A beautiful honeymoon with Sophia... and a fiery first night..."

translate english v01_dormroom_4e1f5a39:

    d "Hahaha, what did you just say?"

translate english v01_dormroom_39e2120c:

    d "Her kids are probably older than us, man."

translate english v01_dormroom_f8fb17dd:

    d "You really think a woman like her sees freshmen like us as men?"

translate english v01_dormroom_5a798641:

    d "Sorry, but you’d better find someone a bit more realistic."

translate english v01_dormroom_1bf44871:

    d "There were some hot freshmen girls around too, you know."

translate english v01_dormroom_bc7ac79d:

    j "Tch, those childish girls? No thanks."

translate english v01_dormroom_aa35b161:

    j "I don’t care."

translate english v01_dormroom_86ab13b8:

    j "Love knows no borders, no age."

translate english v01_dormroom_59702a32:

    j "When you’re naked, you’re just a male and a female, that’s all."

translate english v01_dormroom_bc366d19:

    j "Have you ever imagined her hand caressing your body?"

translate english v01_dormroom_3b39fde1:

    j "It’d feel like a holy knight getting a full heal from a max-level healer! Hahaha."

translate english v01_dormroom_78195116:

    d "Level up the moment her hand touches you?"

translate english v01_dormroom_0110c82c:

    d "Haha, then I'll stop you from leveling up."

translate english v01_dormroom_54d507a9:

    d "The stronger one takes the MILF."

translate english v01_dormroom_a39ed680:

    j "What did you just say?"

translate english v01_dormroom_6e5b5897:

    j "You're the monster interfering with my breeding?"

translate english v01_dormroom_1075f1ea:

    d "You’ll have to kill me if you want to have her."

translate english v01_dormroom_3ef327bf:

    d "And a weakling like you could never beat me!"

translate english v01_dormroom_11759e4d:

    j "Hey, I have to kill you?"

translate english v01_dormroom_d85c8290:

    j "You idiot—why don’t we just both marry her?"

translate english v01_dormroom_9a1b45f2:

    j "I’m down. We’ll hunt together by day and spend hot nights together."

translate english v01_dormroom_71d0e2d4:

    d "Man..."

translate english v01_dormroom_ba01eb8d:

    d "You do realize you sometimes seem insane, right?"

translate english v01_dormroom_da328f43:

    j "You’re a damned hypocrite, [d_name]."

translate english v01_dormroom_79868a5c:

    j "If you ever acted out the fantasies in your head, you’d rack up several life sentences. Hahaha."

translate english v01_dormroom_98b3f054:

    j "Be honest."

translate english v01_dormroom_545d3752:

    j "When we said we’d both marry Sophia, you imagined a threesome, didn’t you!"

translate english v01_dormroom_434dba27:

    d "Imagination is free, Jason."

translate english v01_dormroom_3d8ed1a0:

    d "And God gave humans reason."

translate english v01_dormroom_e0a6ece3:

    d "I’m someone who makes rational decisions."

translate english v01_dormroom_5de12b28:

    d "But that ass—seriously..."

translate english v01_dormroom_17e01488:

    d "It’s on another level..."

translate english v01_dormroom_02d13543:

    d "Damn..."

translate english v01_dormroom_279c51e5:

    d "It’s a perfect ass. Haha."

translate english v01_dormroom_2768cbae:

    j "I want to live in a world filled only with MILFs."

translate english v01_dormroom_700d0521:

    j "In Milfheim."

translate english v01_dormroom_f602cf58:

    j "I like women who are experienced, relaxed, and sultry."

translate english v01_dormroom_e4350cb8:

    j "Damn it, I want to be chosen by a woman with that kind of experience."

translate english v01_dormroom_f4d082b9:

    d "Haha, keep spreading those wings of imagination."

translate english v01_dormroom_a5232231:

    d "I’m getting out of this black-hole room."

translate english v01_dormroom_9642266a:

    j "Heading straight to your hometown?"

translate english v01_dormroom_45aec1da:

    j "There’s an party tonight—aren’t you going?"

translate english v01_dormroom_8649ecd9:

    d "Yeah, if I stay in the dorm one more day I’ll go crazy."

translate english v01_dormroom_6a1e39c5:

    d "I also just want to go home."

translate english v01_dormroom_e8be186e:

    d "And I told the landlady at my boarding house I’d stop by this afternoon."

translate english v01_dormroom_53eb7f1c:

    j "Right, the girls at this school would struggle to handle even just me."

translate english v01_dormroom_714f1097:

    j "I’ll party enough for the both of us, then."

translate english v01_dormroom_cea4da02:

    d "That’s why I’m bowing out. Haha."

translate english v01_dormroom_5d42a97f:

    d "Aren’t you going home?"

translate english v01_dormroom_74d75b8a:

    j "My parents told me to stay on campus and study this break."

translate english v01_dormroom_cae0ee30:

    j "They’re traveling for a month."

translate english v01_dormroom_2a4b78c6:

    j "It’s weird being treated like an adult without any prep."

translate english v01_dormroom_7e25b4c7:

    j "Whatever—being alone is nothing new."

translate english v01_dormroom_4d9ac38a:

    j "I’ll just spend the time looking at photos of Professor Sophia instead."

translate english v01_dormroom_596c1e8a:

    j "I’ve got a cherished collection of her pictures!"

translate english v01_dormroom_cc1c3170:

    d "What? You have photos of Sophia?"

translate english v01_dormroom_b6df56f3:

    d "What photos—social media?"

translate english v01_dormroom_a15c6a79:

    d "Hey, you! Why aren't you sharing it yet?"

translate english v01_dormroom_6d915365:

    j "Sigh... did my parents just abandon me?"

translate english v01_dormroom_ae12deb4:

    d "Look at this bastard changing the subject. Haha."

translate english v01_dormroom_e30dc665:

    j "You think I’d actually have pics like that? I was messing with you, idiot."

translate english v01_dormroom_cb4b0edd:

    j "I check social media every day, and there aren’t any photos of her anywhere."

translate english v01_dormroom_ee812f3a:

    j "I found a model who looks a lot like the professor, but it’s not her."

translate english v01_dormroom_8a56f846:

    j "Haa... even adults need someone to take care of them sometimes."

translate english v01_dormroom_99d0afc3:

    j "Someone please take care of me!"

translate english v01_dormroom_b702562e:

    d "......................."

translate english v01_dormroom_07a1918d:

    dj "The care of a woman like Sophia!"

translate english v01_busdeparture_b80646f7:

    d "(( At last, time to leave. Goodbye to dorm life—at least for the break. ))"

translate english v01_busdeparture_adb452ff:

    d "(( It feels good to move out, but still... ))"

translate english v01_busdeparture_e6604255:

    d "(( It’s a bit sad not being able to hang out with Jason. ))"

translate english v01_busdeparture_78455336:

    d "(( And honestly, like Jason said... not seeing Professor Sophia for a while feels kind of disappointing. ))"

translate english v01_busdeparture_e7ece527:

    d "(( What was the address again? Ah! ))"

translate english v01_busdeparture_10a50103:

    d "412 Rosebridge Avenue, Milfheim Hills."

translate english v01_busdeparture_579e99e6:

    d "So this is where I’ll be living, huh?"

translate english v01_busdeparture_3d31e040:

    d "Knock knock, is anyone home?"

translate english v01_busdeparture_184d21ee:

    d "It’d be nice if people looking for boarders posted their own pictures, too. I’m curious who lives here."

translate english v01_busdeparture_4aacc384:

    d "................."

translate english v01_busdeparture_d21ee3d6:

    n "As he looked up, a woman was walking briskly toward him from the opposite direction."

translate english v01_busdeparture_7b5bce55:

    n "She appeared to be carrying no luggage whatsoever."

translate english v01_busdeparture_5afce26b:

    n "[d_name] sensed that she, too, was looking at him."

translate english v01_busdeparture_1ddbe62b:

    d "(( Hmm... looks like someone dressed for a night out. ))"

translate english v01_busdeparture_59ba99a7:

    d "(( Her face seems a bit flushed... ))"

translate english v01_busdeparture_b6d91e6e:

    d "(( Did she party all night or something? ))"

translate english v01_busdeparture_738d2846:

    d "(( She looks a bit too mature to have been out all night partying... ))"

translate english v01_busdeparture_06c6d3d2:

    d "(( Hey, girl... ))"

translate english v01_busdeparture_bf32f939:

    d "(( Oh... she looks older, but damn, she’s attractive. ))"

translate english v01_busdeparture_1deafd1b:

    d "(( ................... ))"

translate english v01_busdeparture_e1517a60:

    d "Finally."

translate english v01_busdeparture_82d4823d:

    n "[d_name] looked back at the woman walking away."

translate english v01_busdeparture_77c6bbdb:

    d "(( Is that her walking this way? ))"

translate english v01_busdeparture_a6c05642:

    d "(( Oh my God... ))"

translate english v01_busdeparture_8a5387d3:

    d "(( What the hell is she doing?! ))"

translate english v01_busdeparture_5c4ae736:

    n "She had taken off her dress, exposing her breasts completely."

translate english v01_busdeparture_9c82a899:

    d "(( Is it the end of the world today or what...? ))"

translate english v01_busdeparture_413244c6:

    d "(( Holy shit. ))"

translate english v01_busdeparture_2e139dc0:

    n "She pinched her nipple and lifted it, letting out a soft moan."

translate english v01_busdeparture_508b9ae9:

    d "(( What the hell is going on... ))"

translate english v01_busdeparture_687c9eaa:

    d "(( Hey, miss! You’ll get arrested if you keep that up! ))"

translate english v01_busdeparture_5231d2aa:

    n "[d_name] froze in place."

translate english v01_busdeparture_b3a0e7b3:

    n "The thought that flashed through his mind was that he wanted to somehow let Jason know about this situation."

translate english v01_busdeparture_99f57417:

    d "(( ............ ))?"

translate english v01_busdeparture_92f21ed5:

    n "What should I do?"

translate english v01_busdeparture_b322f961:

    n "[d_name] hesitated for a moment but decided to be satisfied with just watching."

translate english v01_busdeparture_dec4ec6a:

    d "Wow, what a crazy world."

translate english v01_busdeparture_3e7bb137:

    d "Haha, today’s been full of surprises."

translate english v01_buscamera_188adb91:

    d "I need to tell Jason about this, hahaha."

translate english v01_buscamera_2c89ab47:

    d "Hurry..."

translate english v01_buscamera_ad439410:

    n "She reacted with slight surprise upon seeing [d_name] taking a photo of herself."

translate english v01_buscamera_9754e14c:

    d "Did I get it?"

translate english v01_buscamera_d018cdac:

    d "Did it come out right?"

translate english v01_buscamera_1e659cdc:

    d "Damn it."

translate english v01_buscamera_f470baa4:

    d "If it were Jason, he would’ve filmed it perfectly. I’m still such an amateur..."

translate english v01_buscamera_76577c7c:

    d "...................."

translate english v01_buscamera_75da8385:

    d "(( Today’s been full of strange events... ))"

translate english v01_lenaphone_8924c005:

    unknown "My God..."

translate english v01_lenaphone_68afb789:

    unknown "What the hell did I just do? Hahaha."

translate english v01_lenaphone_82a44d0a:

    unknown "This is incredibly thrilling."

translate english v01_lenaphone_c2445abe:

    unknown "Hey..."

translate english v01_lenaphone_5daa0496:

    unknown "I think I’ve lost my mind, hahaha."

translate english v01_lenaphone_888240b8:

    unknown "Guess what I just did."

translate english v01_lenaphone_bc46cc1c:

    unknown "I discovered a whole new side of myself today! It’s on another level."

translate english v01_lenaphone_12bb7384:

    unknown "I’m serious, haha."

translate english v01_lenaphone_cd3eb020:

    unknown "I showed him. Hahaha."

translate english v01_lenaphone_425cb7e6:

    unknown "It was a thrill from another dimension."

translate english v01_lenaphone_cde0a512:

    unknown "So what if it was just about the breasts?"

translate english v01_lenaphone_2b5db250:

    unknown "I know. I know!"

translate english v01_lenaphone_7f5c296e:

    unknown "Haha, what can I do? It’s my nature."

translate english v01_lenaphone_0aaba174:

    unknown "Exhibitionism."

translate english v01_lenaphone_818cc7b1:

    unknown "Exhibitionism, nymphomania."

translate english v01_lenaphone_59519065:

    unknown "Exhibitionism, nymphomania, bisexuality."

translate english v01_lenaphone_61d9bfcf:

    unknown "Exhibitionism, nymphomania, bisexuality, impulsive behavior."

translate english v01_lenaphone_aea95878:

    unknown "Wow, aren’t I basically the next stage of human evolution? Haha."

translate english v01_lenaphone_105725a4:

    unknown "You’re the hypocrite. I’m just being honest with myself."

translate english v01_lenaphone_e1c07f9f:

    unknown "And it’s nothing to be shocked about anyway."

translate english v01_lenaphone_5a816a14:

    unknown "Hey, this isn’t even that weird, you know."

translate english v01_lenaphone_85f4f886:

    unknown "Who knows—maybe I just made that boy’s day."

translate english v01_lenaphone_0a0be5a4:

    unknown "Yeah, yeah, I know. I get it!"

translate english v01_lenaphone_04d6cb03:

    unknown "Hahaha. Hardly. I’m just enjoying life."

translate english v01_lenaphone_2320a95b:

    unknown "Come on, baby, admit it—you’re just jealous of me, right?"

translate english v01_lenaphone_9a255263:

    unknown "Haha, fine. See you this weekend."

translate english v01_lenaphone_bc1981ac:

    unknown "We’ll finish our talk in person. See you soon, darling. Love you."

translate english v01_busarrival_9063d3e1:

    n "He watched the bus recede from the village for a while as dusk fell."

translate english v01_busarrival_fce32c23:

    n "Soon, familiar sights came into view, and he felt a slight flutter in his heart."

translate english v01_busarrival_1511991c:

    d "Welcome home, [d_name]."

translate english v01_busarrival_5f269430:

    d "Has it really been a year?"

translate english v01_busarrival_6baca52b:

    d "Breathing in the air of my hometown really does feel calming."

translate english v01_busarrival_aef098dd:

    d "I can’t wait to see Amanda again."

translate english v01_busarrival_5db1462d:

    d "Taxi!"

translate english v01_helenhouse_98740f1b:

    n "He looked around, searching for the house where he would stay, leaving the unfamiliar scenery behind."

translate english v01_helenhouse_72db50e2:

    n "And soon he found the house he had seen on the app."

translate english v01_helenhouse_2fc4431d:

    d "This must be the house."

translate english v01_helenhouse_9bd5e392:

    d "Is it?"

translate english v01_helenhouse_b5707504:

    d "Yeah, it looks just like the one from the picture."

translate english v01_helenhouse_dd4b7e91:

    d "Nice house."

translate english v01_helenhouse_8ee805f1:

    d "Looks like the most stylish one in the neighborhood."

translate english v01_helenhouse_ee9e8202:

    d "I wonder if my room’s on the second floor."

translate english v01_helenhouse_06148c23:

    d "(( My heart’s pounding. ))"

translate english v01_helenhouse_5fbd5a5f:

    n "As with all beginnings, tension and curiosity enveloped him."

translate english v01_helenhouse_ba717032:

    n "And no one could have foreseen that this very step would bring a storm to the peaceful village."

translate english v01_helenhouse_0ca45605:

    d "Alright."

translate english v01_helenhouse_f5efa10a:

    n "The door opened, and a man appeared with a somewhat stiff expression."

translate english v01_helenhouse_52023f83:

    mi "..........."

translate english v01_helenhouse_0daa265f:

    mi "What is it?"

translate english v01_helenhouse_c625c5b1:

    d "Hello, I’m [d_name]."

translate english v01_helenhouse_5ac421fd:

    d "I’m the student who’s supposed to stay here starting today."

translate english v01_helenhouse_60d1ef94:

    d "Could I speak with the landlady, [h_name]?"

translate english v01_helenhouse_66cee398:

    n "The man stared at [d_name] for a moment before finally opening his mouth."

translate english v01_helenhouse_a7b78e5e:

    mi "Ah, so you’re the one?"

translate english v01_helenhouse_8e7090aa:

    mi "..................."

translate english v01_helenhouse_066311c7:

    mi "You’re a bit early, aren’t you?"

translate english v01_helenhouse_d7bd859a:

    h "Hello, [d_name]."

translate english v01_helenhouse_1a74b0b2:

    h "You arrived earlier than I expected."

translate english v01_helenhouse_309c0616:

    n "The woman interrupted the man and spoke up."

translate english v01_helenhouse_83c43b0f:

    n "[d_name] recognized her as the woman he had spoken with and felt relieved."

translate english v01_helenhouse_4886a97e:

    h "You must be tired from the trip. Come in."

translate english v01_helenhouse_8a068897:

    h "Please, come inside."

translate english v01_helenhouse_bdae8a79:

    h "Go on, Michael."

translate english v01_helenhouse_63baf46e:

    h "Isn’t today’s discussion finished?"

translate english v01_helenhouse_68f5673e:

    h "Let’s finish talking later."

translate english v01_helenhouse_f77e0547:

    mi "Take care, [h_name]."

translate english v01_helenhouse_12f30cfe:

    h "Come on Michael."

translate english v01_helenhouse_95c66660:

    n "[d_name] turned to watch the man receding into the distance."

translate english v01_helenhouse_88e494b4:

    n "He thought the man had an inexplicably intimidating presence."

translate english v01_helenhouse_e5c36b54:

    d "..........."

translate english v01_helenhouse_3df2d701:

    d "(( He doesn’t seem like the landlord... ))"

translate english v01_helenhouse_5c983d8c:

    d "(( He’s got quite a cynical attitude. ))"

translate english v01_helenhouse_518ae386:

    mi ".........."

translate english v01_helenhouse_c36e5cb1:

    mi "A tenant, huh?"

translate english v01_helenhouse_43093cfe:

    mi "I’ll be keeping an eye on you, kid."

translate english v01_helenhouseinside_9b3d200a:

    h "This way, [d_name]."

translate english v01_helenhouseinside_5fff6faa:

    d "Yes, ma’am."

translate english v01_helenhouseinside_dfe5f8ed:

    n "She led [d_name] upstairs to the second floor."

translate english v01_helenhouseinside_e5f1b758:

    n "Her dress was short and tight enough to draw [d_name]'s gaze."

translate english v01_helenhouseinside_68efc38a:

    n "[d_name] felt overwhelmed by the unfamiliar surroundings and people, compounded by the spectacle unfolding before his eyes."

translate english v01_helenhouseinside_1be57524:

    n "Upon reaching the second floor, [h_name] turned and said to [d_name]."

translate english v01_helenhouseinside_c6fb28bd:

    h "So, you’re a college student now?"

translate english v01_helenhouseinside_f7fbda18:

    h "Spending your vacation away from home—seems you’re quite independent."

translate english v01_helenhouseinside_75aaf6b2:

    d "Yes, it’s break season, so I came back to my hometown."

translate english v01_helenhouseinside_5e942f30:

    h "Milfheim is your hometown?"

translate english v01_helenhouseinside_1d829f6d:

    h "Why not stay with your parents instead...?"

translate english v01_helenhouseinside_00744580:

    d "Wow, the house feels cozy and elegant."

translate english v01_helenhouseinside_c56ff836:

    d "The atmosphere inside is different from what I imagined outside."

translate english v01_helenhouseinside_d88484cd:

    d "Actually, I don’t know who my parents are."

translate english v01_helenhouseinside_f84cdb5c:

    d "I was left in an orphanage as a child and grew up in the facility."

translate english v01_helenhouseinside_0b7b8ee4:

    d "When I was in middle and high school, a few adults looked out for me.."

translate english v01_helenhouseinside_37508334:

    d "To be honest, I'm not 100 percent sure if this is really my hometown."

translate english v01_helenhouseinside_4e76d83b:

    n "She paused for a moment and thought."

translate english v01_helenhouseinside_54cf2c4d:

    n "[d_name] wondered if he had to fabricate his background on the spot."

translate english v01_helenhouseinside_0912bb73:

    h "Oh, I’m sorry. I didn’t know that..."

translate english v01_helenhouseinside_73439e10:

    h "I shouldn’t have brought it up so casually."

translate english v01_helenhouseinside_f9c2e39c:

    h "It wasn’t something to ask a stranger on first meeting."

translate english v01_helenhouseinside_093dd945:

    d "It’s fine."

translate english v01_helenhouseinside_0af27b3d:

    d "It’s such an old story, I don’t really feel anything about it anymore."

translate english v01_helenhouseinside_a8c5ab11:

    d "All I know are the names on the documents—nothing more."

translate english v01_helenhouseinside_83261455:

    h "........."

translate english v01_helenhouseinside_5ec6a4a7:

    h "I see."

translate english v01_helenhouseinside_969b7622:

    h "Not many can speak of that so calmly."

translate english v01_helenhouseinside_9f499ea0:

    h "Come along, I’ll show you around the house."

translate english v01_helenhouseinside_1c2cac14:

    h "Since we’ll be living together, I hope we can be comfortable with each other."

translate english v01_helenhouseinside_d709ad65:

    h "For now, it’s just you and me here."

translate english v01_helenhouseinside_54e666e6:

    n "She turned and headed toward the kitchen."

translate english v01_helenhouseinside_e8081efc:

    n "[d_name] watched her back for a moment."

translate english v01_helenhouseinside_23f26479:

    n "He thought she must be a woman who takes care of herself, given how good her figure was for her age."

translate english v01_helenhouseinside_70c0692f:

    h "This is the kitchen."

translate english v01_helenhouseinside_1d3e72bf:

    h "You can cook or eat whatever you like."

translate english v01_helenhouseinside_8c8c3390:

    h "As long as you keep the fridge tidy, help yourself to anything."

translate english v01_helenhouseinside_540a938c:

    h "The kitchen downstairs is larger, so you can use that too—just clean up afterward."

translate english v01_helenhouseinside_bda91770:

    h "There’s a housekeeper, but it’s better if we both keep things neat."

translate english v01_helenhouseinside_2ea79213:

    d "Yes, ma’am."

translate english v01_helenhouseinside_ccc4b321:

    d "Not a problem at all."

translate english v01_helenhouseinside_81b66d86:

    h "That room over there is my room."

translate english v01_helenhouseinside_6116bfba:

    h "If it’s urgent, you can knock—but only if it’s really urgent. Hehe."

translate english v01_helenhouseinside_27d0c4a2:

    n "How should I respond?"

translate english v01_helenhouseinside_b39b1d5b:

    n "[d_name] said this because he wanted to make a good first impression on her."

translate english v01_helenhouseinside_5e5dfc93:

    d "That room probably smells nice, hehe."

translate english v01_helenhouseinside_97300b6b:

    h "Oh, you think?"

translate english v01_helenhouseinside_8e44d539:

    d "I learned in class that a lady’s room is best on the inside, and a gentleman’s near the entrance—it creates psychological comfort."

translate english v01_helenhouseinside_7d6ea442:

    h "HeHe"

translate english v01_helenhouseinside_2c6c593c:

    h "Quite the memory you’ve got there."

translate english v01_helenhouseinside_6b1fce5e:

    h "What kind of class teaches something like that? Haha."

translate english v01_helenhouseinside_756fb17a:

    h "This is the living room, as you can see."

translate english v01_helenhouseinside_23f449f2:

    h "That’s the bathroom over there."

translate english v01_helenhouseinside_504ecbc7:

    h "There’s another bathroom in the master bedroom downstairs—use that if you’re in a hurry."

translate english v01_helenhouseinside_a3c5bac5:

    h "Okay."

translate english v01_helenhouseinside_086859cd:

    h "Now, let me show you your room, [d_name]."

translate english v01_helenhouseinside_d364ced1:

    n "She stepped into the room and turned on the light."

translate english v01_helenhouseinside_daa107bb:

    n "[d_name] looked into the room over her shoulder and followed her inside."

translate english v01_helenhouseinside_a01f4f46:

    h ".........."

translate english v01_helenhouseinside_8b5c5e18:

    h "This is it..."

translate english v01_mcroom01_7d6d0650:

    n "But what caught his eye wasn't the room he'd be staying in—it was her butt."

translate english v01_mcroom01_44e6814a:

    n "He thought she wasn't wary enough of him."

translate english v01_mcroom01_fcd8e120:

    n "On the other hand, he also wondered if she simply didn't see him as a man, to the point where she didn't need to be wary."

translate english v01_mcroom01_a94345f6:

    h "This will be the room you’ll stay in during the vacation."

translate english v01_mcroom01_71a4d0d2:

    h "It looks a bit empty, doesn’t it?"

translate english v01_mcroom01_3ff3e516:

    h "You can freely put your belongings here, [d_name]."

translate english v01_mcroom01_4f3356a3:

    h "The bedding is newly prepared, so please make yourself comfortable."

translate english v01_mcroom01_ac9205eb:

    h "There are women’s clothes in the closet, but they belong to someone. I’ll ask her to move them out."

translate english v01_mcroom01_557fb13d:

    d "The room feels cozy."

translate english v01_mcroom01_88e43de7:

    d "Compared to the dorm I shared with a friend, this feels like a luxury suite. Haha."

translate english v01_mcroom01_196d3912:

    d "Whose desk and computer are these?"

translate english v01_mcroom01_29523ed8:

    h "Those were my son’s, but he doesn’t use them anymore."

translate english v01_mcroom01_1f5a92ce:

    h "I left them as they are so it wouldn’t inconvenience your studies. You’re free to use them."

translate english v01_mcroom01_80d0e285:

    h "If the space feels cramped, you can move the computer and use the room however you want."

translate english v01_mcroom01_e216d7eb:

    h "Ah, let me show you the first floor too."

translate english v01_mcroom01_9c98d9e2:

    h "Come on down."

translate english v01_1stfloor_cc84692f:

    h "This used to be my ex-husband’s space."

translate english v01_1stfloor_8b5ce601:

    h "When guests come over, we usually spend time here."

translate english v01_1stfloor_5f5fc537:

    h "But I rarely come down to the first floor these days."

translate english v01_1stfloor_97e61f7c:

    h "If you like this space, feel free to use it for your free time."

translate english v01_1stfloor_1ce4fe20:

    h "Over there is the master bedroom."

translate english v01_1stfloor_02cb9265:

    h "It also has a bathroom and shower, so if that’s more convenient, you can use it."

translate english v01_1stfloor_a5c7acab:

    h "And of course, this is the living room. You can use the TV freely here."

translate english v01_1stfloor_c40c98e6:

    h "I’m sensitive to noise, so if you want to watch TV or a movie at night, please do it here."

translate english v01_1stfloor_2c4f06ef:

    h "................."

translate english v01_1stfloor_f01340f4:

    h "That door leads to the stairs going up to the second floor, and below them is the door to the laundry room."

translate english v01_1stfloor_d27470d0:

    h "You can do your own laundry, or if you leave it in the empty basket, the housekeeper will wash it."

translate english v01_1stfloor_09785755:

    h "Just make sure not to mix your clothes with anyone else’s."

translate english v01_1stfloor_040c617f:

    h "Still, if you’re a gentleman, I hope you’ll wash your own clothes. hehe."

translate english v01_1stfloor_7b49f551:

    h "That way leads to the backyard."

translate english v01_1stfloor_86747a01:

    h "Would you like to take a look?"

translate english v01_backyard_26aeae7a:

    n "[d_name] gazed at the backyard and paused in thought."

translate english v01_backyard_89673d7e:

    n "It wasn't a grand mansion, but he imagined the effort she must have put into decorating the space,"

translate english v01_backyard_c8153f89:

    n "and he thought that someday he too would like to find a house like this to live in with his beloved partner."

translate english v01_backyard_f643f511:

    d "Wow, this place is really well designed."

translate english v01_backyard_232f52f5:

    d "I’m impressed."

translate english v01_backyard_e1c22e54:

    h "There’s a swimming pool and a patio in the backyard."

translate english v01_backyard_020918ae:

    h "On summer nights, I like to sit here, have a glass of wine, and read a book."

translate english v01_backyard_3b176801:

    h "Hehe."

translate english v01_backyard_e63b067b:

    n "She once again acted without a care for [d_name]."

translate english v01_backyard_b4e44037:

    h "Ugh... there we go..."

translate english v01_backyard_cc1d7e33:

    h "Like this..."

translate english v01_backyard_61ad8940:

    n "She lay back in the chair, closed her eyes, and let out a strange moan."

translate english v01_backyard_cdf15bcc:

    h "Ah, that feels so good."

translate english v01_backyard_e31d8d25:

    h "Lying here makes me feel like all the fatigue of the day just melts away."

translate english v01_backyard_86a23a8e:

    h "As I get older, I prefer lying down to sitting."

translate english v01_backyard_9ca0c2d2:

    h "This is my favorite place in the whole house."

translate english v01_backyard_9bcdfb9e:

    h "If you can’t find me inside, assume I’m here. Haha."

translate english v01_backyard_eae2f5f1:

    h "During the day, I usually dress comfortably here, so don’t be too surprised if you see me. Haha."

translate english v01_backyard_c8fc929c:

    h "(( !!!!!!!! ))"

translate english v01_backyard_62714f2e:

    n "His cock was rock hard, straining to burst."

translate english v01_backyard_86d297c6:

    n "Its shape was starkly visible through the denim of his jeans."

translate english v01_backyard_6a21657e:

    d "..............."

translate english v01_backyard_92ad9932:

    h "............"

translate english v01_backyard_cf485a6a:

    h "Oh, I’m sorry. I was only thinking about myself."

translate english v01_backyard_9d84819e:

    h "I must’ve gotten too comfortable even though we just met."

translate english v01_backyard_5c0c1352:

    h "Shall we go back inside?"

translate english v01_backyard_9d482c1e:

    h "You must be tired. Let’s have dinner and rest."

translate english v01_backyard_687849c2:

    n "They walked into the house amid a strange atmosphere."

translate english v01_backyard_781f9fd3:

    h "................"

translate english v01_backyard_ee1d71f1:

    d "(( She probably noticed... ))"

translate english v01_backyard_8b2c6d6b:

    d "(( Damn it, what the hell am I doing on the first day... ))"

translate english v01_backyard_13fc9075:

    d "(( When I wake up tomorrow, will she tell me to leave? ))"

translate english v01_mcroom02_3365f1ee:

    h "You must be tired. Go unpack and get some rest."

translate english v01_mcroom02_fc488b2f:

    h "I’ll call you when dinner’s ready."

translate english v01_mcroom02_0dde321b:

    h "My cooking skills aren’t great, but tonight I’ll make something special myself."

translate english v01_mcroom02_79944f47:

    n "He felt relieved, thinking her mood hadn't changed particularly."

translate english v01_mcroom02_c00d3e57:

    d "Thank you so much, landlady."

translate english v01_mcroom02_5d0074ff:

    d "My rent is already so cheap, I don’t know if it’s okay for you to even provide meals like this."

translate english v01_mcroom02_5ede6b9d:

    d "I’ll stay quiet and make sure I’m not a bother."

translate english v01_mcroom02_4aacc384:

    d "................."

translate english v01_mcroom02_adebe93b:

    h "I’ll call you when the food’s ready."

translate english v01_mcroom02_4ef0c985:

    d "That should do for now."

translate english v01_mcroom02_936169ad:

    d "I’ll finish unpacking tomorrow."

translate english v01_mcroom02_4ec92a6b:

    d "I’m thirsty."

translate english v01_mcroom02_75c6fad6:

    d "I need an iced coffee."

translate english v01_kitchen01_d7f9f362:

    d "Excuse me."

translate english v01_kitchen01_6857cc4c:

    d "[h_name]."

translate english v01_kitchen01_44c0cd53:

    d "Would it be okay if I used the coffee machine over there?"

translate english v01_kitchen01_6a21657e:

    d "..............."

translate english v01_kitchen01_7c0a9214:

    d ".............."

translate english v01_kitchen01_64c1c609:

    d "(( whatever... ))"

translate english v01_kitchen01_2f6671d6:

    d "(( It’s not something I really need to ask about. ))"

translate english v01_kitchen01_463a7718:

    d "(( Here it is. ))"

translate english v01_kitchen01_3b9e1628:

    d "(( Is it okay if I just use any cup? ))"

translate english v01_kitchen01_7dc96086:

    n "Just as he picked up the cup, a sound came from her room."

translate english v01_kitchen01_fc10b94c:

    n "*rustle rustle*"

translate english v01_kitchen01_fc10b94c_1:

    n "*rustle rustle*"

translate english v01_kitchen01_a94a95b4:

    d "Huh?"

translate english v01_kitchen01_703b8028:

    n "He turned his head toward the sound and saw [h_name]'s room."

translate english v01_kitchen01_dcf6fb1b:

    n "A faint shadow seemed to be moving inside."

translate english v01_kitchen01_7c0a9214_1:

    d ".............."

translate english v01_kitchen01_25a33f65:

    d "!!!!!!!!!!!!!!!!!!"

translate english v01_kitchen01_e6078263:

    h "Hmm?"

translate english v01_kitchen01_9e580dc2:

    d "Shit."

translate english v01_kitchen01_87e4c592:

    d "Shit..."

translate english v01_kitchen01_d51af7b6:

    h "Ahem."

translate english v01_kitchen01_625e3197:

    n "He was incredibly surprised that [h_name] appeared much sooner than he expected."

translate english v01_kitchen01_db2acb90:

    n "He wondered if she might have seen him peeking into her room."

translate english v01_kitchen01_f483396c:

    h "Did you just say something?"

translate english v01_kitchen01_5fb0af14:

    n "She looked at [d_name]'s startled expression with puzzlement."

translate english v01_kitchen01_7ec18b78:

    d "Oh... Um"

translate english v01_kitchen01_7aeea519:

    d "I was just looking for the coffee machine."

translate english v01_kitchen01_e9034e8c:

    d "Is it okay if I make some coffee?"

translate english v01_kitchen01_af698a5d:

    h "Oh, I’m sorry. I didn’t even offer you water yet."

translate english v01_kitchen01_99aab049:

    h "Feel free to use anything in the kitchen."

translate english v01_kitchen01_e8473b83:

    h "It’s all included in your rent, so don’t worry about it. Haha."

translate english v01_kitchen01_82fedef2:

    d "Understood."

translate english v01_dinner_eb69c6f4:

    h "(( It’s been such a long time since I last cooked... ))"

translate english v01_dinner_b56ecbfa:

    h "(( When I did it every day, I was so tired of it. ))"

translate english v01_dinner_f49b92e9:

    h "(( But it’s kind of nice having someone to share a meal with again. ))"

translate english v01_dinner_8ab142cb:

    n "She began carrying foods to the dining table."

translate english v01_dinner_8109741d:

    h "Alright, all done."

translate english v01_dinner_e43c0f92:

    h "You must be hungry, right?"

translate english v01_dinner_c2b79ed8:

    d "Yeah, hehe."

translate english v01_dinner_eafdcb3a:

    d "Come to think of it, I haven’t eaten a single meal since this morning."

translate english v01_dinner_eab1076a:

    h "You haven’t eaten all day?"

translate english v01_dinner_d57d3087:

    h "Then how are you still standing like that? Haha."

translate english v01_dinner_09225033:

    h "My son used to skip meals a lot too, and I used to scold him terribly."

translate english v01_dinner_84281f6b:

    h "Being full of youthful energy is great, but you should take care to eat properly."

translate english v01_dinner_74b76fe4:

    n "They sat facing each other."

translate english v01_dinner_021d0de3:

    n "She had prepared a soda for [d_name] and whiskey for herself."

translate english v01_dinner_b5c56c6e:

    h "Now, the menu isn’t large, but let’s eat."

translate english v01_dinner_6c853bac:

    d "Wow, this looks really delicious."

translate english v01_dinner_037e1f7c:

    d "I don’t even remember when I last ate food made with such care. Haha."

translate english v01_dinner_0b4c2fe1:

    d "Compared to the notoriously awful cafeteria food at my school, this is restaurant-grade cuisine. Haha."

translate english v01_dinner_ef09e541:

    h "Oh, it’s not that much. Haha."

translate english v01_dinner_bfc83208:

    h "I just got to show off my skills a bit after a long time. Haha."

translate english v01_dinner_c17b2370:

    h "Usually I’m lazy and just eat anything. Having a guest makes a difference."

translate english v01_dinner_d8d69335:

    h "This will probably be the first and last time I serve food like this."

translate english v01_dinner_3bb91a63:

    h "I have a housekeeper who cooks meals and cleans every other day."

translate english v01_dinner_bb0bfe8e:

    d "Ah, I see."

translate english v01_dinner_07012013:

    d "I’ll make sure not to be a burden to the housekeeper."

translate english v01_dinner_d6609441:

    h "Haha, good."

translate english v01_dinner_0947ab66:

    h "You didn’t eat poorly in the dorm at university, did you?"

translate english v01_dinner_eb154119:

    h "So enjoy your meal."

translate english v01_dinner_57ccd941:

    d "By the way, landlady..."

translate english v01_dinner_805d1403:

    d "I’m not sure if I should ask this, but..."

translate english v01_dinner_538eb26d:

    d "Do you live here alone?"

translate english v01_dinner_b7edd723:

    n "His somewhat unexpected question caused [h_name] to hesitate for a moment."

translate english v01_dinner_28965f45:

    h ".........................."

translate english v01_dinner_8f045ecb:

    h "Yes. My children have all left home."

translate english v01_dinner_cae2dc19:

    h "I’ve grown used to the quiet."

translate english v01_dinner_5be82d1b:

    h "Aside from sometimes missing the sound of them chatting, I find living alone comfortable."

translate english v01_dinner_2e56c9e5:

    h "This used to be the house I lived in with my husband, but after the divorce I live here by myself now."

translate english v01_dinner_2c58554d:

    h "Ironically, it was the house my ex-husband stubbornly picked."

translate english v01_dinner_9580ea14:

    d "Ah, I’m sorry."

translate english v01_dinner_d6c1aa2c:

    d "I asked an inappropriate question."

translate english v01_dinner_a081b6c3:

    h "No, it’s fine."

translate english v01_dinner_c3475e6d:

    h "It’s in the past. I’m quite comfortable living alone now."

translate english v01_dinner_a806c1c6:

    h "My eldest daughter got married last year, and the younger daughter is in college."

translate english v01_dinner_72e04d10:

    h "They’ve finally escaped from me, I suppose. Haha."

translate english v01_dinner_4c0bc9dc:

    d "!!"

translate english v01_dinner_5f7c9cd0:

    d "Married?! College?!"

translate english v01_dinner_24f96077:

    h "Hmm."

translate english v01_dinner_fb91699c:

    h "My eldest lives in this area, and the younger is majoring in film at university."

translate english v01_dinner_8b983d47:

    h "The younger is probably about the same age as you."

translate english v01_dinner_ddebf696:

    d "That surprised me. You don’t look like someone who would have children old enough to be married."

translate english v01_dinner_927f0c11:

    d "Landlady must be at most..."

translate english v01_dinner_f197840b:

    n "She sensed what he was about to say."

translate english v01_dinner_13f52cc2:

    n "But she became quite curious about what answer he was going to give."

translate english v01_dinner_615e97dc:

    h "Hm? At most what age?"

translate english v01_dinner_4d67bcda:

    h "How old do I look?"

translate english v01_dinner_722c73f6:

    h "You can be honest. Haha."

translate english v01_dinner_1e7dc3cb:

    d "In my opinion......."

translate english v01_dinner_27d0c4a2:

    n "How should I respond?"

translate english v01_dinner_f8190e00:

    d "You look about my age. Haha."

translate english v01_dinner_35a0555b:

    n "She took a sip of her drink without answering."

translate english v01_dinner_0db018c0:

    h "Whoa, that’s going too far."

translate english v01_dinner_07c6be1a:

    h "Saying that to a middle-aged woman is rude."

translate english v01_dinner_93929744:

    n "[d_name] realized he had made a mistake."

translate english v01_dinner_187a3e48:

    d "I’m sorry.."

translate english v01_dinner_bb4a44d2:

    d "I’m sorry.. I didn’t mean anything by it.."

translate english v01_dinner_73976b1d:

    d "I don’t know, to me you look like you’re in your early thirties."

translate english v01_dinner_29388980:

    d "I was just being honest. Haha."

translate english v01_dinner_0d8ae26d:

    h "Hahahahaha."

translate english v01_dinner_963f2280:

    h "Early thirties?"

translate english v01_dinner_f02b401d:

    h "Why do you think that? You’re starting to sound suspicious."

translate english v01_dinner_6d9e5049:

    h "If I could go back to my early thirties, I’d have no other wish."

translate english v01_dinner_1ab4638f:

    h "I won’t ask what exactly you meant by that."

translate english v01_dinner_5c4f74a0:

    h "I can see the eloquence of a talkative student."

translate english v01_dinner_8baeed6d:

    h "You boys these days are really something."

translate english v01_dinner_03b89fe6:

    n "She looked at him for a moment before speaking."

translate english v01_dinner_f0768f32:

    h "..............."

translate english v01_dinner_2ca1d7bf:

    h "I’m probably more than twice your age."

translate english v01_dinner_548ec87e:

    h "At least."

translate english v01_dinner_d485bea6:

    d "Ah, my apologies. I just meant that you look so young, and that slipped out..."

translate english v01_dinner_5551fbe8:

    h "It’s alright."

translate english v01_dinner_f43aecb1:

    h "I’ll take it as a compliment."

translate english v01_dinner_b1798bc1:

    h "It’s been a while since I’ve had such a pleasant conversation."

translate english v01_dinner_72ad5c21:

    h "But I’d prefer we not take things too far."

translate english v01_dinner_f5722a5f:

    h "If you don’t mind, [d_name], can you tell me a little about yourself?"

translate english v01_dinner_a52fadb4:

    h "How long are you planning to stay here in Milfheim?"

translate english v01_dinner_3218af5f:

    h "............................."

translate english v01_dinner_4b208083:

    h ".......................?"

translate english v01_dinner_d56192e1:

    h "(( Is he? ))"

translate english v01_dinner_e89d6e2c:

    h "(( Is he... looking at my breasts? ))"

translate english v01_dinner_3b323361:

    h "(( Hmm................ ))"

translate english v01_dinner_f5722a5f_1:

    h "If you don’t mind, [d_name], can you tell me a little about yourself?"

translate english v01_dinner_a52fadb4_1:

    h "How long are you planning to stay here in Milfheim?"

translate english v01_dinner_8096b08a:

    d "Huh?"

translate english v01_dinner_7d8bd183:

    d "Ah, I came here planning to stay for the whole vacation."

translate english v01_dinner_6f02a28b:

    d "My major is psychology, and my advisor gave us an assignment — to meet as many people as we can during break, analyze them, and write an essay."

translate english v01_dinner_5fc63c31:

    d "While meeting people, I’m also hoping to find an internship at a local company if possible."

translate english v01_dinner_4c623c8e:

    d "I do receive some financial support from the government, but I also want to do something to give back to society."

translate english v01_dinner_a42f7706:

    d "This is my hometown, but it’s even more special to me because there are people here who took care of me growing up."

translate english v01_dinner_0a5da121:

    h "What a thoughtful young man you are."

translate english v01_dinner_c359578f:

    h "A psychology student from Milfheim who wants to serve society..."

translate english v01_dinner_39f4d7c6:

    h "It may not have been a fancy dinner, but I already feel glad I cooked for you tonight, [d_name]. Hehe."

translate english v01_dinner_32e907b6:

    h "......................"

translate english v01_dinner_93e89ca9:

    h "Were you taken in by another family when you were a kid?"

translate english v01_dinner_29532f0a:

    d "When I was very young, I grew up at the Youth Center."

translate english v01_dinner_909dad89:

    d "I stayed there until middle school, then I lived with a family who were friends with Ms. Mary through high school."

translate english v01_dinner_b2b55bd2:

    d "Ms. Mary is someone I owe a lot to."

translate english v01_dinner_e2c6d36f:

    h "I see. Mary... that name sounds familiar somehow."

translate english v01_dinner_a833eadd:

    h "I know that place — Milfheim Youth Center."

translate english v01_dinner_c36d1f86:

    h "It used to be up in the mountains, big like Hogwarts, right?"

translate english v01_dinner_fcd6db05:

    d "You know it well."

translate english v01_dinner_539ff4e2:

    d "Later, as the town’s population declined, they relocated it to where it is now."

translate english v01_dinner_74f32242:

    h "I see."

translate english v01_dinner_26dc4d16:

    h "I passed by once — I thought it was just a branch, but it was actually relocated."

translate english v01_dinner_3125fdea:

    h "Oh right, I meant to ask you something earlier but forgot."

translate english v01_dinner_15ccfc6b:

    h "But now that you're back in your hometown, why did you get a room at a boarding house instead of staying where you used to live?"

translate english v01_dinner_6ebbcfd5:

    h "Have you become independent now?"

translate english v01_dinner_d93375a8:

    d "Ah, well..."

translate english v01_dinner_dda4a061:

    n "[d_name] paused briefly before continuing."

translate english v01_dinner_df0cdb22:

    d "The atmosphere at the house I stayed at was kind of... haha."

translate english v01_dinner_1e1d99b2:

    d "Frank was kind most of the time, but he often got angry or irritated, so he made my life a bit difficult."

translate english v01_dinner_031acae8:

    d "I still don’t know what exactly he found so displeasing about me."

translate english v01_dinner_8beec781:

    d "When I think of him, the first thing that comes to mind is his twitching mustache."

translate english v01_dinner_b391fb62:

    d "Amanda, on the other hand, was incredibly kind and caring."

translate english v01_dinner_82e70ad0:

    d "She took really good care of me."

translate english v01_dinner_c00ee9e3:

    d "She listened to everything I said like a friend, too."

translate english v01_dinner_41f974ae:

    d "Frank told me I'd have to live on my own once I went to college..."

translate english v01_dinner_75aadc2f:

    h "Why?"

translate english v01_dinner_1482dd73:

    h "Did you cause a lot of trouble?"

translate english v01_dinner_33344883:

    d "I caused a lot of trouble when they first took me in."

translate english v01_dinner_b4085dae:

    d "I even hung out with the local delinquents, haha."

translate english v01_dinner_8b57aff0:

    d "But the main reason he got angry wasn’t that."

translate english v01_dinner_12a55b3c:

    h "Can I ask what the reason was?"

translate english v01_dinner_8210f47f:

    h "It’s okay if you don’t want to say."

translate english v01_dinner_d810aab1:

    d "The first was, “Study harder.”"

translate english v01_dinner_b790cf4e:

    d "The second reason was that I was too close to Amanda."

translate english v01_dinner_dd0b2389:

    h "Huh?"

translate english v01_dinner_7892ec1a:

    h "What do you mean by “too close”?"

translate english v01_dinner_c7193610:

    h "Of course you'd be close to someone who took care of you, right?"

translate english v01_dinner_dc31f2cc:

    d "Frank got furious, saying Amanda and I were being too physically affectionate for our roles."

translate english v01_dinner_5546b815:

    d "He said our behavior, our clothes, our gestures — all of it was too casual, too intimate."

translate english v01_dinner_8d3526ff:

    d "He told me I’d ruined the family’s peace."

translate english v01_dinner_7aaeb054:

    d "He said he'd done his duty and told me not to come back once I went to college. He told me to just focus on my studies and stay in the dorms."

translate english v01_dinner_f5067f26:

    n "She paused to consider what [d_name] meant."

translate english v01_dinner_56171dff:

    n "She had a feeling he was hiding something, but she didn't think much of it."

translate english v01_dinner_14e9bf85:

    h "Oh dear..."

translate english v01_dinner_8b6a1e90:

    h "“Too much physical affection,” he said? That sounds harsh..."

translate english v01_dinner_d079f148:

    h "It must have been difficult living in that kind of household."

translate english v01_dinner_e40b706a:

    h "I don't know how he could be so cold to you."

translate english v01_dinner_6641c719:

    d "Yeah, it was a bit hard."

translate english v01_dinner_24a3dfd3:

    d "But Amanda took such great care of me that I was able to get by just fine."

translate english v01_dinner_5fb9cb27:

    d "I’ll just have to visit her when Frank’s not around, haha."

translate english v01_dinner_49a12e24:

    d "He’s going on a fishing trip the day after tomorrow, so I’m planning to go then."

translate english v01_dinner_dfad204c:

    h "Still, it’s admirable that you didn’t go astray and grew into such a respectable young man."

translate english v01_dinner_734f279c:

    h "You seem mature for your age, if I may say so."

translate english v01_dinner_75c5cfa5:

    h "It’s touching... I can only imagine how hard your childhood must’ve been."

translate english v01_dinner_1171aa6d:

    h "If you’re curious about me or this house, [d_name], feel free to ask."

translate english v01_dinner_c03db20b:

    h "Anything at all."

translate english v01_dinner_45b120f8:

    d "Then... may I ask something?"

translate english v01_dinner_d03c8af8:

    d "The man who was leaving the house when I arrived — who was he?"

translate english v01_dinner_0f75b2b2:

    d "Was he your ex-husband, Landlady?"

translate english v01_dinner_e6b4c8b7:

    n "She took another sip of whiskey."

translate english v01_dinner_3f9a24db:

    h ".................."

translate english v01_dinner_ff98971c:

    h "That’s not a question I expected."

translate english v01_dinner_86ea35f6:

    h "He’s not my husband — his name is Michael, a friend of mine."

translate english v01_dinner_af9f24f1:

    h "He’s connected to the work I do. Sometimes he comes by to discuss things or just to talk. You could say he’s a business partner."

translate english v01_dinner_f3e2a67e:

    h "You’ll probably run into him a few times while staying here."

translate english v01_dinner_71c24cb4:

    h "But he’s not exactly sociable or warm, so it’ll be hard to get close to him."

translate english v01_dinner_84d2a4ea:

    h "He’s a rather guarded person."

translate english v01_dinner_39021560:

    h "By the way, [d_name], I imagine your girlfriend must be missing you."

translate english v01_dinner_b8ed315a:

    h "It’s vacation — normally you’d want to spend it together, but here you are, back in your hometown."

translate english v01_dinner_e6078263:

    h "Hmm?"

translate english v01_dinner_28965f45_1:

    h ".........................."

translate english v01_dinner_4530c488:

    h "(( Oh, boy. ))"

translate english v01_dinner_79919520:

    h "(( So he really was staring at my breast. ))"

translate english v01_dinner_8da2177a:

    h "[d_name]."

translate english v01_dinner_2c4f06ef:

    h "................."

translate english v01_dinner_2cb30df9:

    h "[d_name]?"

translate english v01_dinner_8096b08a_1:

    d "Yes?"

translate english v01_dinner_690785c8:

    d "Ah, that girlfriend..."

translate english v01_dinner_cb0ca1f9:

    d "I don’t have one right now, haha."

translate english v01_dinner_1324aa18:

    d "I was dating someone early in the semester, but we broke up."

translate english v01_dinner_422c01f0:

    h "Oh dear… that must have hurt."

translate english v01_dinner_660e7a9a:

    h "It’s always hard to steady your heart after a first love ends."

translate english v01_dinner_e30d012f:

    d "It was really hard at first."

translate english v01_dinner_3be3994f:

    d "My roommate Jason helped me through it with both carrots and sticks, haha."

translate english v01_dinner_8776416a:

    d "And after being with someone once, I figured out what kind of woman I’m into."

translate english v01_dinner_a6b3cc3a:

    h "Oh really?"

translate english v01_dinner_81166e99:

    h "Now I’m curious — what kind of woman is that?"

translate english v01_dinner_921ac968:

    d "Well… how should I put it…"

translate english v01_dinner_06006f58:

    d "I guess I like older women."

translate english v01_dinner_aa34b01a:

    h "!!"

translate english v01_dinner_ee4a5007:

    h "Hmm…"

translate english v01_dinner_74f32242_1:

    h "I see."

translate english v01_dinner_b94d2447:

    d "I talked about it once with my professor — she said both a lack of maternal affection and, conversely, too much of it in childhood can lead to attraction toward older women."

translate english v01_dinner_347ab10f:

    d "I’ve tried to figure out which applies to me, but honestly, I still don’t know, haha."

translate english v01_dinner_048dc1f3:

    h "Hmm..."

translate english v01_dinner_d03aa42d:

    h "From a mother’s experience — having raised a son — I can say a lot of men your age go through that phase."

translate english v01_dinner_98e61255:

    h "My son did too… maybe your attraction to older women is just temporary."

translate english v01_dinner_c93b62d9:

    h "But that doesn’t mean your professor was wrong."

translate english v01_dinner_1713a910:

    h "It’s just my personal opinion, so don’t take it too seriously, haha."

translate english v01_dinner_fd6e26de:

    h "...................."

translate english v01_dinner_c476ff28:

    n "She noticed [d_name] staring at her breasts again."

translate english v01_dinner_5d1942f7:

    h "!!!!"

translate english v01_dinner_b0880856:

    h "(( Again? ))"

translate english v01_dinner_d82abf6d:

    h "Ahem..."

translate english v01_dinner_8da2177a_1:

    h "[d_name]."

translate english v01_dinner_d2fb3ffa:

    d "I’m sorry."

translate english v01_dinner_b15a48cc:

    d "Sometimes I get lost in thought and completely miss what people say."

translate english v01_dinner_8a6c2b5d:

    h "It’s alright, haha."

translate english v01_dinner_885a3ce8:

    h "Did you enjoy the meal?"

translate english v01_dinner_c460daf4:

    d "Yes, I think it’s been almost a year since I’ve had something this delicious."

translate english v01_dinner_83039626:

    d "Thank you for the meal, Landlady."

translate english v01_dinner_f219ff15:

    h "Just call me [h_name]."

translate english v01_dinner_0f3d1a7c:

    h "We’ll be living together for a few months — no need to be so formal."

translate english v01_dinner_ee747611:

    h "Shall we call it a night then?"

translate english v01_mcroom03_fa418945:

    d "Today was such a long day."

translate english v01_mcroom03_9e29911d:

    d "Jason’s probably having fun at the party right now."

translate english v01_mcroom03_5e3aec4e:

    d ".........."

translate english v01_mcroom03_90e0b87f:

    d "This feeling… it’s strange. Comfortable, but also tense somehow."

translate english v01_mcroom03_6336d2cd:

    d "Coming back to my hometown feels like falling into Wonderland."

translate english v01_mcroom03_96875f37:

    d "[d_name] in Wonderland."

translate english v01_mcroom03_3b0f6b30:

    d "[d_name] of Milfheim Hills."

translate english v01_mcroom03_44a92def:

    d "Damn..."

translate english v01_mcroom03_c35185f5:

    d "Damn..."

translate english v01_mcroom03_799527af:

    d "What a day it’s been."

translate english v01_mcroom03_79f3abb7:

    n "He stared at the ceiling, reflecting on the day."

translate english v01_mcroom03_9edb3653:

    n "Then, closing his eyes to calm the slight flushed feeling as he ended the day in this unfamiliar place."

translate english v01_mcroom04_d49deee3:

    n "[d_name] sat up, perched on the edge of the bed, and uttered the words he always spoke upon waking each morning."

translate english v01_mcroom04_d05dbefe:

    n "He himself couldn't remember when he'd started saying this every morning."

translate english v01_mcroom04_b52c9bb1:

    d "I survived yesterday, and here I am, waking up to a new morning."

translate english v01_mcroom04_95939a96:

    d "Hmm..."

translate english v01_mcroom04_fbc33e68:

    d "Where was I supposed to go today? The orphanage, right?"

translate english v01_helencoffee_4eb035ff:

    n "He stepped out of the room and paused briefly upon seeing [h_name]."

translate english v01_helencoffee_9f997f16:

    n "[h_name] was sitting in a chair, lifting her skirt and stroking her own legs."

translate english v01_helencoffee_22703571:

    h "(( My legs feel so tired... ))"

translate english v01_helencoffee_b74eac3a:

    h "(( I can’t wear high heels for long anymore... ))"

translate english v01_helencoffee_a3fd9e10:

    h "(( From now on, I should just dress comfortably for work. ))"

translate english v01_helencoffee_2105f4d0:

    h "Did you sleep well?"

translate english v01_helencoffee_1fae78ff:

    h "Oh! That shirt looks great on you, [d_name]."

translate english v01_helencoffee_a9a35536:

    d "Good morning, Landlady."

translate english v01_helencoffee_66abdb1e:

    d "Heading out somewhere?"

translate english v01_helencoffee_24f96077:

    h "Mm-hmm."

translate english v01_helencoffee_fb30c4e8:

    h "I’m going to work."

translate english v01_helencoffee_89f6a3a4:

    h "And please, call me [h_name]. I prefer that."

translate english v01_helencoffee_ac4b562e:

    h "The mortgage on this house isn’t paid off yet, so I work like an ant, haha."

translate english v01_helencoffee_281b4cb9:

    h "Normally the housekeeper handles things, but she’s been busy lately, so I’ve been taking over."

translate english v01_helencoffee_30c1376f:

    h "There’s breakfast in the kitchen — heat it up and eat whenever you want."

translate english v01_helencoffee_4b8109f0:

    h "You're going out today, right?"

translate english v01_helencoffee_659ee4c1:

    h "There’s a bike in the garage — feel free to use it."

translate english v01_helencoffee_f5befff2:

    h "And if you ever plan to stay out overnight, just send me a text, alright?"

translate english v01_helencoffee_574fd239:

    n "She waved to [d_name] and descended the stairs."

translate english v01_helencoffee_3f79aa5c:

    n "He watched her go as she walked down."

translate english v01_helencoffee_1cf5a33b:

    n "He felt relieved that she didn't find it strange when he saw himself getting an erection yesterday, and that she seemed a kinder person than he had thought."

translate english v01_helencoffee_a9861e1d:

    d "...................."

translate english v01_helencoffee_bca4a125:

    d "She’s beautiful... and kind."

translate english v01_helencoffee_06e0e0af:

    d "(( I wonder if I can get close to her while I’m living here… maybe even become friends? ))"

translate english v01_helencoffee_047a8c35:

    d "(( There's no way that could happen. ))"

translate english v01_helencoffee_6c717d2f:

    d "Oh, nice bike."

translate english v01_helencoffee_5dff4a65:

    d "I doubt [h_name] rides this herself."

translate english v01_helencoffee_69ee00fb:

    d "Hmm....."

translate english v01_helencoffee_cd640d1b:

    d "Well then… I’ll borrow it gratefully."

translate english v01_youthcenter_day_ff840c33:

    n "He rode his bicycle for quite a while and arrived at the newly relocated daycare center."

translate english v01_youthcenter_day_f5d67457:

    n "As he entered the facility, a smile spread across his face without him even realizing it."

translate english v01_youthcenter_day_9cc364bc:

    d "Heh… feels like I’m really home now."

translate english v01_youthcenter_day_896b40a1:

    d "Now that I’m here, it truly feels like I’ve come back to my hometown."

translate english v01_youthcenter_day_376f296b:

    c "[d_name], you’re back!!"

translate english v01_youthcenter_day_4b512d77:

    d "Wow, you’ve gotten even prettier, Celine."

translate english v01_youthcenter_day_8b5a5faf:

    c "When did you get back?"

translate english v01_youthcenter_day_6a93bf79:

    c "You could’ve at least texted me, you jerk! What’s this, some mysterious comeback act?"

translate english v01_youthcenter_day_5cf92ccd:

    c "How’s college treating you?"

translate english v01_youthcenter_day_ff244754:

    d "It’s rough — I’m barely keeping up, haha."

translate english v01_youthcenter_day_78af37a3:

    d "Luckily, I met someone even dumber than me."

translate english v01_youthcenter_day_c1d787c7:

    c "Oh come on, haha."

translate english v01_youthcenter_day_8bbebfed:

    c "That lame sense of humor hasn’t changed, even in college."

translate english v01_youthcenter_day_95ed1575:

    d "I heard the news."

translate english v01_youthcenter_day_e129b651:

    d "You abandoned me, didn’t you, Celine?"

translate english v01_youthcenter_day_82318467:

    n "She raised her hand to show off her wedding ring."

translate english v01_youthcenter_day_465de1d0:

    d "Don't you think that's a bit much, not even telling me?"

translate english v01_youthcenter_day_5b5fb03d:

    d "If you’d told me the place, I could’ve crashed the wedding and kidnapped you."

translate english v01_youthcenter_day_41e714ac:

    c "We decided to have a quiet ceremony with just family, so I didn’t tell many people."

translate english v01_youthcenter_day_12b9f3f3:

    c "My husband’s from another city, so there weren’t many guests anyway."

translate english v01_youthcenter_day_db4d23a6:

    d "Ah, I see."

translate english v01_youthcenter_day_526bcb35:

    d "Still, you could’ve told me."

translate english v01_youthcenter_day_dd433f19:

    d "We grew up together, remember?"

translate english v01_youthcenter_day_aa9bf1b9:

    d "You should’ve at least given me a chance, haha."

translate english v01_youthcenter_day_2736006f:

    n "She stared at him for a moment, thinking [d_name] had changed slightly."

translate english v01_youthcenter_day_f1c79eec:

    n "As a married woman, she felt a bit confused about what kind of words she should tolerate, but she didn't care much."

translate english v01_youthcenter_day_0b163e8c:

    c "What the— you’ve gotten cheeky since moving to the city, huh?"

translate english v01_youthcenter_day_63c5849c:

    c "I’m older than you, remember?"

translate english v01_youthcenter_day_72db3ac2:

    c "When you were a kid, I was already a teenager."

translate english v01_youthcenter_day_1ecc034f:

    d "Haha, yeah, but still — you’re married already?"

translate english v01_youthcenter_day_b58f2275:

    d "We should grab a drink sometime so you can tell me all about it."

translate english v01_youthcenter_day_5c2662ee:

    d "Ah, right… now that you’re married, should I be careful?"

translate english v01_youthcenter_day_013ccb6a:

    c "Hehe."

translate english v01_youthcenter_day_532bf91b:

    c "You think marriage means I can’t meet my friends anymore? Haha."

translate english v01_youthcenter_day_5384132b:

    d "Heh, okay then — text me when you have some free time."

translate english v01_youthcenter_day_7fe92d94:

    d "Is Mary working today?"

translate english v01_youthcenter_day_8e7bafa4:

    c "“Working today”? She’s the director now!"

translate english v01_youthcenter_day_fe2c4ce6:

    c "Seriously, you really stopped keeping in touch with anyone here."

translate english v01_youthcenter_day_6649adab:

    d "Wow, Director Mary!"

translate english v01_youthcenter_day_98b1d841:

    d "It’s not like I’ve been on Mars — how did I miss all this?"

translate english v01_youthcenter_day_f33506d0:

    c "Go on, get in there."

translate english v01_youthcenter_day_f5ae7e44:

    c "She’ll be thrilled to see you."

translate english v01_youthcenter_day_12a49367:

    c "And you’d better visit more often, haha."

translate english v01_youthcenter_day_9dcc2248:

    c "You’ve been so out of touch you didn’t even know Mary became the director."

translate english v01_youthcenter_day_7bf9afd6:

    c "She’s missed you so much, you know."

translate english v01_youthcenter_day_527bf5e0:

    c "Anyway, go on, hurry up."

translate english v01_youthcorridor_d6be7b44:

    d "Is Mary not inside?"

translate english v01_youthcorridor_a94a95b4:

    d "Huh?"

translate english v01_youthcorridor_3d01f287:

    d "(( !!!!!!!!!!!!! ))"

translate english v01_youthcorridor_696989f4:

    d "(( ............ ))"

translate english v01_youthcorridor_01bd4db3:

    d "(( Gulp... ))"

translate english v01_youthcorridor_6f2615ad:

    d "(( What was that...? ))"

translate english v01_youthcorridor_fea1e693:

    d "(( What did I just see...? ))"

translate english v01_youthcorridor_33999bba:

    d "(( ........ ))"

translate english v01_youthcorridor_58b0e12e:

    n "He quietly opened the door and peered inside."

translate english v01_youthcorridor_378022c3:

    m "(( What on earth just happened... ))"

translate english v01_youthcorridor_126c38b9:

    m "(( Who did I just show myself to...? ))"

translate english v01_youthcorridor_cf6596b7:

    m "(( Why wasn’t the door locked...? ))"

translate english v01_youthcorridor_e12302a4:

    m "(( I swear I locked it... ))"

translate english v01_youthcorridor_6c6fe98a:

    m "(( Hah... Mary, you really need to get it together. ))"

translate english v01_youthcorridor_f6ed58e9:

    m "!!........."

translate english v01_youthcorridor_8c4c49b3:

    m "(( Is he... staring at me? ))"

translate english v01_youthcorridor_a5e670b2:

    m "(( Is he insane? ))"

translate english v01_youthcorridor_612fe88e:

    m "(( Does he think I’m putting on some kind of strip show? ))"

translate english v01_youthcorridor_a797f6ce:

    d "............."

translate english v01_youthcorridor_137c7fc7:

    n "He quietly closed the door and stood frozen in place before it like a statue."

translate english v01_maryoffice_995abb3c:

    m "Come in."

translate english v01_maryoffice_ef6d92ed:

    m "........."

translate english v01_maryoffice_ee022d2c:

    d "Hi, Mary! I'm Home!"

translate english v01_maryoffice_29224e12:

    m "What??"

translate english v01_maryoffice_a3e8fec4:

    m "[d_name]!!"

translate english v01_maryoffice_a0b72204:

    n "She embraced him without a moment's hesitation."

translate english v01_maryoffice_ac129767:

    n "[d_name] felt happiness wash over him as he hugged her back. And soon, her familiar scent filled his senses."

translate english v01_maryoffice_a71d8e5c:

    m "[d_name], it’s been so long!"

translate english v01_maryoffice_3849c853:

    d "I’ve missed you, Mary."

translate english v01_maryoffice_d318bbc9:

    m "I told you to visit more often, you little rascal!"

translate english v01_maryoffice_2abd7512:

    m "Come on, sit, sit."

translate english v01_maryoffice_8193368f:

    m "Oh my goodness..."

translate english v01_maryoffice_d4941b26:

    m "[d_name], hahahaha!"

translate english v01_maryoffice_853f5c6e:

    m "You passed out drunk next to your girlfriend? Haha!"

translate english v01_maryoffice_e5d8e78f:

    m "Still the same ridiculous boy as ever."

translate english v01_maryoffice_c209a0e0:

    d "Yeah. The next day she texted me..."

translate english v01_maryoffice_f9b5886f:

    d "“You’ve humiliated me.” That’s literally what she said, haha."

translate english v01_maryoffice_b36d891e:

    d "So that’s how we broke up."

translate english v01_maryoffice_5dc75cc7:

    m "Hahaha, oh my. Why’d you do that?"

translate english v01_maryoffice_110f306f:

    m "Guess you weren’t that into her, huh?"

translate english v01_maryoffice_40feb09c:

    m "Come on, [d_name]."

translate english v01_maryoffice_4164ec15:

    m "Let’s take a walk in the park — the one we used to go to all the time."

translate english v01_maryoffice_e8615231:

    m "I’ve been gaining weight lately, so I really need to walk more."

translate english v01_park_b795c577:

    n "They arrived at the park they often visited and walked side by side."

translate english v01_park_632b5377:

    n "The park was peaceful, and the birdsong sounded pleasant."

translate english v01_park_6dfcb67e:

    m "So, how long are you staying here?"

translate english v01_park_bb1bbc74:

    m "And why didn’t you go back to your home?"

translate english v01_park_6405609a:

    d "You know already — Frank told me not to come back now that I’m an adult."

translate english v01_park_3ac8bec7:

    d "I spent my first night at the boarding house yesterday."

translate english v01_park_a819c74f:

    d "Luckily, the landlady seems like a good person."

translate english v01_park_6a7cb16e:

    m "I see."

translate english v01_park_19f0da1f:

    m "That man hasn’t changed at all, huh?"

translate english v01_park_e7f0386f:

    m "Still, you have to be careful these days — even normal-looking homes can hide strange people."

translate english v01_park_0cbfab6d:

    m "Come on, [d_name]. Walk with me like the old days."

translate english v01_park_96714c7b:

    n "She pulled [d_name]'s arm and said."

translate english v01_park_2b28896b:

    m "Feeling awkward just because it’s been a while? You’re making me sad."

translate english v01_park_ef7e53b9:

    d "Haha, alright, alright."

translate english v01_park_dc6e2010:

    d "Just like old times..."

translate english v01_park_ad927995:

    n "They began walking, their bodies pressed close together."

translate english v01_park_bcf44cb1:

    m "You’ve really grown up, [d_name]. I can feel it."

translate english v01_park_174a9542:

    m "If you want, you could even stay here."

translate english v01_park_e85d30ce:

    m "We don’t run the place as big as before, since we focus on adoption services now, but we still have dorm rooms."

translate english v01_park_13b5fa2f:

    d "Haha, really? So I can just drop by anytime?"

translate english v01_park_ad4d8480:

    d "The staff might get exhausted just seeing me though, haha."

translate english v01_park_06467796:

    m "Haha."

translate english v01_park_4e6eaa15:

    m "This place will always be your home, [d_name]."

translate english v01_park_c31a8551:

    m "Come whenever you like."

translate english v01_park_1a0163fe:

    n "Her breasts and thighs were pressed against [d_name]'s arms."

translate english v01_park_6543b168:

    n "He felt his cock swelling as if it would burst."

translate english v01_park_1776cd0b:

    m "So, what’s your plan now?"

translate english v01_park_65d4d929:

    d "I’m going to meet people, maybe get an internship while I’m here."

translate english v01_park_0e820cea:

    d "My professor gave me an assignment — to meet as many people as possible and broaden my understanding of human relationships."

translate english v01_park_2403df49:

    m "That’s a good plan."

translate english v01_park_f4823e46:

    m "Now that you’re in college, this is your first step into real society."

translate english v01_park_ff3e2340:

    m "Actually, one of my friends runs a small startup — want me to see if they’re looking for interns?"

translate english v01_park_c4b10016:

    d "Really? That’d be amazing!"

translate english v01_park_17fa0eab:

    m "Good."

translate english v01_park_067e511d:

    m "I’ll talk to her about it."

translate english v01_park_ab9306c6:

    m "But you’ll still have to pass the interview, of course."

translate english v01_park_d93e196e:

    m "Ahh... what a beautiful day."

translate english v01_park_0f0f313b:

    m "I feel healthier already."

translate english v01_park_sex_e3d54317:

    m "Huh?!"

translate english v01_park_sex_af841d5a:

    m "What?"

translate english v01_park_sex_64a9b43b:

    d "Huh??"

translate english v01_park_sex_98c9aeea:

    n "[d_name] tried to look in the direction the sound was coming from, but she quickly turned his head to face her."

translate english v01_park_sex_093fb4ec:

    m "Hey, [d_name]!"

translate english v01_park_sex_e3bad657:

    m "I’m really glad to see you again."

translate english v01_park_sex_bd282d11:

    m "But showing up after a whole year? You deserve a scolding for that!"

translate english v01_park_sex_b304302a:

    d "Hahaha."

translate english v01_park_sex_9862a9b6:

    d "I think I’m a bit too old to be scolded now, don’t you think?"

translate english v01_park_sex_c9a38c22:

    n "Ahhhhh........"

translate english v01_park_sex_1d9faad2:

    d "What was that sound?"

translate english v01_park_sex_3d2fa18a:

    d "!!!!!!!!!!!!"

translate english v01_park_sex_72c53817:

    n "He looked toward the source of the sound and saw a couple performing oral sex behind a tree."

translate english v01_park_sex_7c0a9214:

    d ".............."

translate english v01_park_sex_1691d744:

    n "Feeling something on his thigh, [d_name] lowered his head."

translate english v01_park_sex_7c0a9214_1:

    d ".............."

translate english v01_park_sex_4b78c52a:

    d "What...?"

translate english v01_park_sex_203cc60b:

    d "......."

translate english v01_park_sex_43f9a39d:

    d "Mary..."

translate english v01_park_sex_ee35104c:

    m "Hmm?"

translate english v01_park_sex_84420611:

    m "Shall we head back?"

translate english v01_park_sex_454742b6:

    m "............"

translate english v01_park_sex_6f8d6a6d:

    m "What’s wrong?"

translate english v01_park_sex_6c052d01:

    m "..............."

translate english v01_park_sex_3e8565d4:

    m "!!!!!!!!!!!!!!!!!!!"

translate english v01_park_sex_2b44d47b:

    m "Ah!!"

translate english v01_park_sex_4937e4ec:

    m "I’m sorry, honey!"

translate english v01_park_sex_8b4f5d9d:

    m "I didn’t even realize..."

translate english v01_park_sex_1f690052:

    m "I just rested my hand on your thigh without thinking."

translate english v01_park_sex_b5eddae2:

    d "It’s okay, Mary. Really."

translate english v01_park_lovers_6300001f:

    n "Sensing someone nearby, they looked over and saw the couple approaching."

translate english v01_park_lovers_83904f11:

    n "The couple stopped in front of them and spoke up."

translate english v01_park_lovers_41e39c7c:

    unknownf "Well, hello there."

translate english v01_park_lovers_b080a929:

    m "Oh, hello."

translate english v01_park_lovers_4712312e:

    unknownf "Isn’t it such a beautiful day?"

translate english v01_park_lovers_b210308b:

    unknownf "You two look perfect together."

translate english v01_park_lovers_67d3b994:

    unknownf "Another age-gap couple like us, huh?"

translate english v01_park_lovers_06d2a00e:

    unknownf "Out on a park date today?"

translate english v01_park_lovers_f8861c9e:

    m "Excuse me? A couple?"

translate english v01_park_lovers_5bb78dda:

    m "That’s a rather rude assumption."

translate english v01_park_lovers_dd1bacdd:

    m "We’re just…"

translate english v01_park_lovers_e27e8003:

    unknownf "It’s fine, haha."

translate english v01_park_lovers_64933a94:

    unknownf "I didn’t mean to interrupt."

translate english v01_park_lovers_cdb65568:

    unknownf "I just wanted to say hi to such a lovely pair."

translate english v01_park_lovers_790961ea:

    unknownf "You’re not mother and son, are you?"

translate english v01_park_lovers_4fe40693:

    m "I..."

translate english v01_park_lovers_d82a1493:

    m "I'm his teacher!!"

translate english v01_park_lovers_ba96b63d:

    m "And honestly, I don’t see why I have to explain that to you."

translate english v01_park_lovers_3679389a:

    m "A couple? That’s ridiculous."

translate english v01_park_lovers_deccb774:

    unknownf "Oh, really? My apologies if that made you uncomfortable."

translate english v01_park_lovers_c7728f69:

    unknownf "But you two are sitting awfully close for that, aren’t you? Haha."

translate english v01_park_lovers_e1eecd6f:

    unknownf "...................."

translate english v01_park_lovers_ffcc5f14:

    unknownf "You know..."

translate english v01_park_lovers_b2d1b248:

    unknownf "We noticed you two were watching us."

translate english v01_park_lovers_c43e20b2:

    unknownf "From the very beginning — we saw everything."

translate english v01_park_lovers_a156670d:

    n "Mary was momentarily taken aback by her unexpected words."

translate english v01_park_lovers_79b70afa:

    m "!!!!!!!"

translate english v01_park_lovers_664147c7:

    m "You... what are you saying..."

translate english v01_park_lovers_e27e8003_1:

    unknownf "It’s alright, haha."

translate english v01_park_lovers_916ebf93:

    unknownf "It actually made me more excited and felt even better."

translate english v01_park_lovers_950ebb02:

    unknownf "I never knew being watched could turn me on so much."

translate english v01_park_lovers_e4683289:

    n "She hesitated for a moment before continuing."

translate english v01_park_lovers_07f4bb2a:

    unknownf "How about you?"

translate english v01_park_lovers_e5973371:

    unknownf "Did it excite you too?"

translate english v01_park_lovers_099b0bbf:

    unknownf "Did you imagine becoming one with the young man next to you?"

translate english v01_park_lovers_1d85a2d9:

    unknownf "Did you picture his cock filling you completely?"

translate english v01_park_lovers_ef07149d:

    m "What on earth are you saying?!!!"

translate english v01_park_lovers_4d9af0d7:

    m "Get away from us!"

translate english v01_park_lovers_64e65865:

    m "Or I’m calling the police right now!"

translate english v01_park_lovers_0ddb39c2:

    unknownm "Whoa, whoa"

translate english v01_park_lovers_a1f5b7c6:

    unknownm "Calm down, ma’am."

translate english v01_park_lovers_af41b301:

    unknownm "We don’t mean any harm."

translate english v01_park_lovers_735d1cf5:

    unknownm "We just think you two make a wonderful pair."

translate english v01_park_lovers_148cf1f4:

    unknownm "Sitting that close, it’s obvious there’s something between you."

translate english v01_park_lovers_d40fac0e:

    unknownm "Age doesn’t matter — it’s either now or never."

translate english v01_park_lovers_2c0f749f:

    unknownm "I can tell you like each other but keep pretending otherwise."

translate english v01_park_lovers_c0d10521:

    unknownm "I bet the young man agrees with me, doesn’t he? Hahaha."

translate english v01_park_lovers_08a3aef5:

    n "[d_name] looked perplexed at the man's words."

translate english v01_park_lovers_a797f6ce:

    d "............."

translate english v01_park_lovers_81f22407:

    n "Mary found it strange that [d_name] showed no particular reaction to their words."

translate english v01_park_lovers_af841d5a:

    m "What?"

translate english v01_park_lovers_149c6e88:

    m "[d_name]... why aren’t you saying anything?"

translate english v01_park_lovers_406c01e2:

    m "Do you... think the same as them?"

translate english v01_park_lovers_7a867dfe:

    m "Me?"

translate english v01_park_lovers_3de95730:

    m "Oh my god... do you really think that way?"

translate english v01_park_lovers_37ff3476:

    d ".........................................."

translate english v01_park_lovers_8fbbaa7c:

    unknownm "See? Hahaha."

translate english v01_park_lovers_03b36003:

    unknownm "What man wouldn’t be drawn to a woman as charming as you?"

translate english v01_park_lovers_f48a8fb1:

    unknownm "Just look at how he’s staring at you — it says everything."

translate english v01_park_lovers_1ffb2b74:

    unknownm "That charm of yours is a gift."

translate english v01_park_lovers_5d9e1e7d:

    m "Stop it."

translate english v01_park_lovers_26788c28:

    m "I’m not like you people — I don’t live by pure instinct."

translate english v01_park_lovers_746080d7:

    m "I’m just an ordinary housewife."

translate english v01_park_lovers_542c55c6:

    unknownf "So am I. I’m an ordinary housewife too."

translate english v01_park_lovers_40f1018a:

    unknownf "I used to be a pitiful woman like you — always yearning for something I couldn’t have."

translate english v01_park_lovers_0d422eeb:

    unknownf "Then I realized life is far too short. To live and die like that would be torture to myself. So I changed."

translate english v01_park_lovers_6806dc0f:

    unknownf "Please don’t think I’m being presumptuous."

translate english v01_park_lovers_74134eed:

    unknownf "I’m only saying this because I see the old me in you — and it breaks my heart."

translate english v01_park_lovers_538a4c6a:

    unknownf "Look."

translate english v01_park_lovers_60f3611c:

    n "The woman suddenly approached [d_name]."

translate english v01_park_lovers_c9c5999d:

    m "Hey, what are you doing?"

translate english v01_park_lovers_7318ad12:

    m "Step back!"

translate english v01_park_lovers_1fe1d88a:

    unknownf "Look at this young man’s eyes — so clear and pure."

translate english v01_park_lovers_c309a42f:

    unknownf "You can see his untainted soul in them."

translate english v01_park_lovers_46a7f760:

    unknownf "What woman wouldn’t fall for someone like that?"

translate english v01_park_lovers_f8a1e1f8:

    unknownf "See? It’s easy — if you just let yourself."

translate english v01_park_lovers_cb955266:

    n "Without a moment's hesitation, the woman pressed her lips firmly against [d_name]'s."

translate english v01_park_lovers_648ef7b2:

    n "Mary couldn't believe what was happening right before her eyes."

translate english v01_park_lovers_cb955266_1:

    n "The unmistakable sound of their saliva mingling spread through the air around them."

translate english v01_park_lovers_2f5d18f1:

    unknownf "You kiss well... So good."

translate english v01_park_lovers_4a7b1569:

    unknownf "........."

translate english v01_park_lovers_d9a0aaf4:

    unknownf "Wow."

translate english v01_park_lovers_ce1108e0:

    unknownf "So that’s why this beautiful woman fell for you."

translate english v01_park_lovers_a4bddb54:

    unknownf "You’ve got quite an impressive piece there."

translate english v01_park_lovers_69edce6a:

    unknownf "Have you ever shown it to the lady next to you?"

translate english v01_park_lovers_b5da01e8:

    n "The woman crouched down in front of Mary and [d_name]."

translate english v01_park_lovers_0ea8c8ff:

    n "She studied Mary's expression before beginning to speak."

translate english v01_park_lovers_7d7c4bb7:

    unknownf "How about this?"

translate english v01_park_lovers_7bb304be:

    unknownf "Shall we give this young man an unforgettable experience together?"

translate english v01_park_lovers_021eb3bd:

    m "......................."

translate english v01_park_lovers_32bd2547:

    m "What do you mean, “unforgettable experience”?"

translate english v01_park_lovers_57630716:

    n "Her right hand was resting on [d_name]'s cock."

translate english v01_park_lovers_3e8c0533:

    unknownf "Look at his cock."

translate english v01_park_lovers_61757a53:

    m "What did you just say?!!!!!!!"

translate english v01_park_lovers_115ffde4:

    unknownf "You can’t just ignore something like that, hehe."

translate english v01_park_lovers_401fd02f:

    unknownf "It wouldn’t be good for the young man either."

translate english v01_park_lovers_df0cce6a:

    unknownf "I want to kneel beside you and suck this boy’s young cock."

translate english v01_park_lovers_7ef84d50:

    m "What on earth are you saying…"

translate english v01_park_lovers_78b7b330:

    unknownf "Don’t you want to show him what real feminine affection feels like?"

translate english v01_park_lovers_800af3ee:

    unknownf "Be honest — when you watched me having sex earlier, you wanted to suck his cock, didn’t you?"

translate english v01_park_lovers_cc0bee3c:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_park_lovers_890a8bcf:

    m "Are you insane?!"

translate english v01_park_lovers_79dd176d:

    m "How can you say something like that..."

translate english v01_park_lovers_81d902da:

    unknownf "No, I’m not insane."

translate english v01_park_lovers_9b2b1977:

    unknownf "I have a PhD, actually."

translate english v01_park_lovers_3a769037:

    unknownf "Like I said, I just wanted to see a beautiful couple like you two come together on such a beautiful day, in such a beautiful park."

translate english v01_park_lovers_544523a1:

    unknownf "There’s nothing wrong with pleasing the person you love."

translate english v01_park_lovers_e3d81a1c:

    unknownf "Look at him — his cock must be aching to be inside you right now."

translate english v01_park_lovers_1e43b32a:

    unknownf "Be honest with yourself."

translate english v01_park_lovers_070ff636:

    unknownf "The whole time you watched me having sex, you were thinking about this young man’s cock."

translate english v01_park_lovers_c6ae4fe5:

    n "As she spoke, the woman slipped her left hand under Mary's skirt."

translate english v01_park_lovers_c9aa32ee:

    unknownf "This young man belongs to me."

translate english v01_park_lovers_08606bc3:

    unknownf "Only I can have him."

translate english v01_park_lovers_c2b012f3:

    unknownf "I want to suck his cock right now, but I’ll wait for the right moment."

translate english v01_park_lovers_18ef5761:

    unknownf "If I just gave the word, he’d thrust himself into my mouth."

translate english v01_park_lovers_4ef85b58:

    m "Get your filthy hands..."

translate english v01_park_lovers_b790e21d:

    m "Off me."

translate english v01_park_lovers_b315b32e:

    m "Right now!!"

translate english v01_park_lovers_6ab2b741:

    m "Or I’ll call the police!"

translate english v01_park_lovers_592a5422:

    unknownf "Alright, alright."

translate english v01_park_lovers_51e1b21f:

    unknownf "I may have gotten ahead of myself, haha."

translate english v01_park_lovers_b7934c33:

    unknownf "You just need time, I see."

translate english v01_park_lovers_21e9ec55:

    unknownf "But don’t waste too much of it."

translate english v01_park_lovers_e10ed247:

    unknownf "If you don’t make him yours completely, you’ll lose your chance forever."

translate english v01_park_lovers_ffd58268:

    unknownf "Well then, have a lovely day."

translate english v01_park_lovers_dd6587f4:

    unknownf "Maybe we’ll meet again if fate allows."

translate english v01_park_lovers_cc796608:

    unknownf "If we do, I hope you two will be even closer by then."

translate english v01_park_lovers_68c5c9cf:

    unknownf "Remember —"

translate english v01_park_lovers_275cc9b5:

    unknownf "Life is far too short to spend it just worrying."

translate english v01_park_lovers_4f96195c:

    unknownf "I didn’t mean to make you uncomfortable."

translate english v01_park_lovers_9b482d44:

    unknownf "I do hope we meet again someday."

translate english v01_park_lovers_da6ad9a6:

    unknownf "If fate allows..."

translate english v01_park_flirt_e15b4987:

    n "Mary and [d_name] couldn't believe what had happened."

translate english v01_park_flirt_bff7cdc1:

    n "They just sat there silently for a while."

translate english v01_park_flirt_c9497706:

    n "Mary only now felt his hand resting on the upper part of her buttocks."

translate english v01_park_flirt_ef6a65d4:

    m "I’m so sorry, sweetie. I shouldn’t have asked you to come to this park and run into those lunatics."

translate english v01_park_flirt_3b97fd49:

    m "Are you okay?"

translate english v01_park_flirt_a797f6ce:

    d "............."

translate english v01_park_flirt_3f019474:

    d "Yes, I’m fine. You must’ve been more shaken up than I was."

translate english v01_park_flirt_6c052d01:

    m "..............."

translate english v01_park_flirt_38ae1b11:

    n "She hesitated for a moment before continuing."

translate english v01_park_flirt_0630365b:

    m "You....."

translate english v01_park_flirt_b3c6027b:

    m "Do you really see me as a woman?"

translate english v01_park_flirt_e5c36b54:

    d "..........."

translate english v01_park_flirt_d9454b35:

    d "What do you mean...?"

translate english v01_park_flirt_4069dc60:

    m "That man’s words."

translate english v01_park_flirt_267340a2:

    m "Do you think the same?"

translate english v01_park_flirt_5e59baf1:

    m "No matter the age..."

translate english v01_park_flirt_e5c36b54_1:

    d "..........."

translate english v01_park_flirt_e1ef2c19:

    d "Mary is kind and beautiful."

translate english v01_park_flirt_caef3c86:

    d "Everyone likes you."

translate english v01_park_flirt_f182f354:

    d "Me too."

translate english v01_park_flirt_5f2319a4:

    n "She looked at [d_name] for a moment."

translate english v01_park_flirt_efc37f90:

    n "Her face was slightly flushed."

translate english v01_park_flirt_40940e76:

    m "No, that’s not what I mean..."

translate english v01_park_flirt_021eb3bd:

    m "......................."

translate english v01_park_flirt_843dd494:

    m "I’m asking if you’ve ever felt any sexual feelings toward me."

translate english v01_park_flirt_c014cc50:

    m "Do you really see me as a woman?"

translate english v01_park_flirt_e5c36b54_2:

    d "..........."

translate english v01_park_flirt_72fdffce:

    d "Yes, that’s right."

translate english v01_park_flirt_680bf6d6:

    m "........................"

translate english v01_park_flirt_58029c9a:

    m "How... when did that start?"

translate english v01_park_flirt_32e75870:

    m "When did it begin?"

translate english v01_park_flirt_0ab7c69c:

    d "I don’t know."

translate english v01_park_flirt_aded11cc:

    d "You know how that is."

translate english v01_park_flirt_9454b31b:

    d "You know how sometimes people just pop into your mind for no reason, even for a moment."

translate english v01_park_flirt_72f221e8:

    d "At some point, when I thought of Mary, she didn’t feel like a teacher, but like an attractive woman."

translate english v01_park_flirt_680bf6d6_1:

    m "........................"

translate english v01_park_flirt_20b0276b:

    m "[d_name]......."

translate english v01_park_flirt_8e4737d0:

    d "Maybe it’s just my imagination."

translate english v01_park_flirt_40b7db7b:

    d "As I became an adult and more sexually active, maybe I started to feel that way toward any woman."

translate english v01_park_flirt_a98382fc:

    d "So maybe Mary moved from the “teacher” category in my head to “woman.”"

translate english v01_park_flirt_3e57cdc8:

    d "If we hadn’t started this conversation, I probably would’ve kept it as a feeling only inside me."

translate english v01_park_flirt_81cd8613:

    d "I’m sorry, Mary."

translate english v01_park_flirt_77da45b4:

    m "No, [d_name]."

translate english v01_park_flirt_6fd0d27b:

    m "You don’t have to apologize."

translate english v01_park_flirt_5b8116f0:

    m "Thank you for being honest with me."

translate english v01_park_flirt_6ef853e4:

    m "I also think you’ve grown into a healthy, attractive young man."

translate english v01_park_flirt_42b9f7d5:

    m "Don’t take what they said to heart."

translate english v01_park_flirt_16260fcd:

    m "If you live like them—especially being reckless about sex—you’ll end up hurting both your mind and body."

translate english v01_park_flirt_51f45bac:

    m "My goodness."

translate english v01_park_flirt_b855512d:

    m "Who's sucking who off, and what's going into which hole."

translate english v01_park_flirt_20cb7249:

    m "Crazy people. What are they even saying to someone they just met?"

translate english v01_park_flirt_2530b00a:

    m "Can you imagine that, [d_name]?"

translate english v01_park_flirt_55333fa9:

    m "Me giving you a blowjob?"

translate english v01_park_flirt_ec51d1ef:

    d "What?!!!!"

translate english v01_park_flirt_bdfe060f:

    d "A blowjob?!!!"

translate english v01_park_flirt_51f45bac_1:

    m "No no no."

translate english v01_park_flirt_e45688c4:

    m "I didn’t mean actually doing it—I was just asking hypothetically."

translate english v01_park_flirt_1a11c330:

    d "....................."

translate english v01_park_flirt_f6b48051:

    n "After pondering for a while, [d_name] said."

translate english v01_park_flirt_416ff332:

    d "I’ve imagined it."

translate english v01_park_flirt_885cb622:

    m "What?"

translate english v01_park_flirt_dc2c76fa:

    m "You said you’ve imagined it?"

translate english v01_park_flirt_2885d943:

    m "What exactly did you imagine?"

translate english v01_park_flirt_e5c36b54_3:

    d "..........."

translate english v01_park_flirt_9945bb9b:

    d "The thought of you sucking my cock.."

translate english v01_park_flirt_69dc8382:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_park_flirt_54e78dc5:

    n "Mary couldn't believe what she had just heard."

translate english v01_park_flirt_e6b2e153:

    m "I'm sucking your c....."

translate english v01_park_flirt_5e001d28:

    m "Wow, [d_name]."

translate english v01_park_flirt_8c0956d1:

    m "That’s... surprisingly honest of you."

translate english v01_park_flirt_80e761db:

    m "I’m seeing a new side of you today."

translate english v01_park_flirt_855792af:

    d "I hope you don’t feel offended, Mary."

translate english v01_park_flirt_03a2bf85:

    d "Guys my age, all they think about is sex from the moment they wake up until they go to sleep, you know?"

translate english v01_park_flirt_fa0d943d:

    d "I know I didn’t have to say any of this."

translate english v01_park_flirt_7de82b91:

    d "But since it came up, I didn’t want to hide it from you."

translate english v01_park_flirt_c5674cd6:

    d "It’s one of the long-standing rules between us, right?"

translate english v01_park_flirt_b5249413:

    d "Never lie to Mary."

translate english v01_park_flirt_ec8bd2af:

    d "What about you, Mary?"

translate english v01_park_flirt_b61607d0:

    d "Have you ever thought about sucking my cock?"

translate english v01_park_flirt_69dc8382_1:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_park_flirt_8fb8e8b3:

    m "Whoa, hey there. Do you realize what you just said?"

translate english v01_park_flirt_9bc0863c:

    d "I was just asking."

translate english v01_park_flirt_c3cdec40:

    d "Today feels kind of crazy, doesn’t it?"

translate english v01_park_flirt_42a58810:

    d "I saw your body..."

translate english v01_park_flirt_fd4770f4:

    d "And now we’re having this kind of talk."

translate english v01_park_flirt_7f9d9bc5:

    d "I just hope you’ll be honest with me too."

translate english v01_park_flirt_b702562e:

    d "......................."

translate english v01_park_flirt_3331bead:

    d "I’m sorry if I made you upset..."

translate english v01_park_flirt_fcc4f69b:

    m "I’m sorry, honey. I’m not angry."

translate english v01_park_flirt_556d1d51:

    m "Actually..."

translate english v01_park_flirt_ff389d77:

    n "They didn't even notice their legs touching."

translate english v01_park_flirt_38743f5d:

    n "Or perhaps they were all enjoying the feel of each other's skin."

translate english v01_park_flirt_52187780:

    n "The sense of security they had felt was now turning into a slight sexual arousal."

translate english v01_park_flirt_6ec2f17b:

    m "........................."

translate english v01_park_flirt_fbd4f50e:

    m "I’ve imagined something like that too."

translate english v01_park_flirt_6ec2f17b_1:

    m "................................."

translate english v01_park_flirt_29880e28:

    m "You know..."

translate english v01_park_flirt_dfd6b6e0:

    m "Your c..."

translate english v01_park_flirt_ad825719:

    m "Your thing..."

translate english v01_park_flirt_3efe2eab:

    m "I mean, putting it in my mouth..."

translate english v01_park_flirt_cf4d1b40:

    m "............."

translate english v01_park_flirt_3edb81bf:

    m "Oh my..."

translate english v01_park_flirt_c43e72dc:

    m "This feels like a confession."

translate english v01_park_flirt_ebf3e5fe:

    m "................"

translate english v01_park_flirt_8b7ff61b:

    m "I’m not saying this to match what you just said."

translate english v01_park_flirt_beb67624:

    m "I’m like you, [d_name]."

translate english v01_park_flirt_6678a8e5:

    m "It’s not that I really want to do it—it’s just a thought that crosses my mind, something that will never happen."

translate english v01_park_flirt_ca092dfe:

    m "People act all proper on the outside, but deep down everyone has their own dirty thoughts."

translate english v01_park_flirt_d8c3fe2e:

    m "I’m sorry, honey."

translate english v01_park_flirt_64be7efd:

    d "No, Mary. It’s not dirty at all."

translate english v01_park_flirt_9db3259a:

    d "Everyone here in the park..."

translate english v01_park_flirt_554749f2:

    d "Exercising, talking, walking..."

translate english v01_park_flirt_cd170f2c:

    d "They might all seem like good people, but nobody really knows what they’re thinking."

translate english v01_park_flirt_831279c0:

    d "Everyone gains complete freedom inside their imagination."

translate english v01_park_flirt_baad8a35:

    d "No matter what you think or say, Mary, you’ll always be my best teacher."

translate english v01_park_flirt_5e001d28_1:

    m "Wow, [d_name]."

translate english v01_park_flirt_856ded18:

    m "You’ve really grown up."

translate english v01_park_flirt_49344987:

    m "Now it feels like I should be learning from you."

translate english v01_park_flirt_a473ae78:

    m "Thank you, honey."

translate english v01_park_flirt_0bab57fb:

    m "Today, you really seem like a wonderful man to me."

translate english v01_park_flirt_1a54ede8:

    n "She was grateful to [d_name] for letting her shocking confession roll off her back."

translate english v01_park_flirt_1759ca08:

    d "So whatever you think, don’t judge yourself for it."

translate english v01_park_flirt_1bec68af:

    d "Thoughts are something we can’t control."

translate english v01_park_flirt_8cd2a613:

    m "That’s right, [d_name]."

translate english v01_park_flirt_8a3618c9:

    m "Then shall we make another promise?"

translate english v01_park_flirt_4d21b587:

    m "Like the one where we promised not to lie to each other."

translate english v01_park_flirt_8c5308c4:

    d "Sure, Mary. Haha."

translate english v01_park_flirt_69dd03f8:

    d "What kind of promise?"

translate english v01_park_flirt_5e310a87:

    m "If one of us asks what the other is thinking, we have to tell the truth."

translate english v01_park_flirt_391fcddf:

    m "What do you think? Haha."

translate english v01_park_flirt_b682cca1:

    d "Alright, I promise."

translate english v01_park_flirt_fea73c27:

    d "Wow, when combined with “never lie to each other,” this is a really strong promise."

translate english v01_park_flirt_2a0fcb2b:

    d "It means if we ask what the other is thinking, we have to tell the truth no matter what."

translate english v01_park_flirt_dbb543ba:

    m "Oh my, you’re right. Haha."

translate english v01_park_flirt_96601f2b:

    m "Then should we try asking each other right now?"

translate english v01_park_flirt_ecfbb1ad:

    m "What are you thinking about, [d_name]?"

translate english v01_park_flirt_da9a6c21:

    n "Mary's question wasn't exactly well-timed."

translate english v01_park_flirt_538b578e:

    n "Or it could have been perceived as having some ulterior motive."

translate english v01_park_flirt_67b5db17:

    d "Uh.............."

translate english v01_park_flirt_b4f3cee8:

    d "Well, I..."

translate english v01_park_flirt_67eccf6a:

    m "What? You just made a promise—are you going to break it already?"

translate english v01_park_flirt_19a56bbc:

    m "Is there anything you can’t tell me?"

translate english v01_park_flirt_fae5d319:

    m "Come on, tell me. We’ve crossed so many lines today. Haha."

translate english v01_park_flirt_0e6d9724:

    d "(( Is she leading me on, knowing what I’m about to say? ))"

translate english v01_park_flirt_4aacc384:

    d "................."

translate english v01_park_flirt_403a2428:

    d "I’m thinking about kissing you, Mary."

translate english v01_park_flirt_5fd318ca:

    m "Really? That’s cute."

translate english v01_park_flirt_934bd089:

    d "I mean.."

translate english v01_park_flirt_f21fd0e2:

    d "Not the kind of kiss a teacher gives..."

translate english v01_park_flirt_5af2c4c5:

    d "A kiss... like the one between lovers..."

translate english v01_park_flirt_198f9748:

    d "With my tongue......."

translate english v01_park_flirt_29a4f6ab:

    m "!!!"

translate english v01_park_flirt_287b7c97:

    m "I see..."

translate english v01_park_flirt_b1472289:

    m "Yeah, that’s the kind of thought anyone could have."

translate english v01_park_flirt_6ec2f17b_2:

    m "................................."

translate english v01_park_flirt_ecd04673:

    m "Any other thoughts?"

translate english v01_park_flirt_4aacc384_1:

    d "................."

translate english v01_park_flirt_608f530d:

    d "(( This feels risky to say... even in this mood, she might get angry. ))"

translate english v01_park_flirt_6ad2a7e5:

    d "Your......."

translate english v01_park_flirt_96b48849:

    d "Your body I saw at the center earlier..."

translate english v01_park_flirt_79b70afa:

    m "!!!!!!!"

translate english v01_park_flirt_287b7c97_1:

    m "I see..."

translate english v01_park_flirt_6eec93ab:

    d "What about you, Mary?"

translate english v01_park_flirt_db4c8fc0:

    d "What are you thinking right now?"

translate english v01_park_flirt_1aefa8b4:

    m ".............."

translate english v01_park_flirt_0f593711:

    m "I... I was..."

translate english v01_park_flirt_fcd885d0:

    m "Thinking we should go back to the center and finish our work."

translate english v01_park_flirt_fac8215b:

    d "............"

translate english v01_park_flirt_d3997eee:

    d "Really?"

translate english v01_park_flirt_1aefa8b4_1:

    m ".............."

translate english v01_park_flirt_1aefa8b4_2:

    m ".............."

translate english v01_park_flirt_c4e8e90a:

    m "Actually..."

translate english v01_park_flirt_2147b9e6:

    m "Actually, I thought about your body too."

translate english v01_park_flirt_95a0f8fe:

    m "Your... c...."

translate english v01_park_flirt_0236d3a3:

    m "Your cock..."

translate english v01_park_flirt_adbd1dcc:

    m "In my mouth..."

translate english v01_park_flirt_0354cbe0:

    m "Filling my face and mouth with yours..."

translate english v01_park_flirt_c109c904:

    d "!!!!!!!!!!"

translate english v01_park_flirt_cdb8f743:

    n "[d_name] couldn't believe his ears at Mary's answer."

translate english v01_park_flirt_2a1f0ef1:

    n "It was the most shocking and obscene thing he had ever heard in his entire life."

translate english v01_park_flirt_29107ea9:

    m "Oh my... what am I even saying?"

translate english v01_park_flirt_992861b4:

    m "I’m sorry, [d_name]!"

translate english v01_park_flirt_9000589d:

    m "It’s a lie."

translate english v01_park_flirt_a75bb7d4:

    m "No—it’s not really a lie..."

translate english v01_park_flirt_0e04113e:

    m "Sigh............."

translate english v01_park_flirt_11791180:

    m "I’m sorry, [d_name]."

translate english v01_park_flirt_3f60ec35:

    m "It’s been a year since we last met, what’s happening to me?"

translate english v01_park_flirt_71ce81f7:

    m "I've cared for you like no one else..."

translate english v01_park_flirt_547c0dd8:

    d "It’s okay, Mary."

translate english v01_park_flirt_6f61d0c4:

    d "I told you before."

translate english v01_park_flirt_f69a7c0e:

    d "................"

translate english v01_park_flirt_6d81dd25:

    d "Actually, it's not just about you."

translate english v01_park_flirt_cf4d1b40_1:

    m "............."

translate english v01_park_flirt_9f289d8f:

    m "What do you mean you don’t only think about me?"

translate english v01_park_flirt_69004b05:

    d "Actually...."

translate english v01_park_flirt_9aa32341:

    d "I often imagine the bodies of almost every woman I know."

translate english v01_park_flirt_3b367cd8:

    m "Okay, [d_name]."

translate english v01_park_flirt_f5e52c01:

    m "I’m not that surprised. You mean guys your age—no, almost all men—think about women all day long."

translate english v01_park_flirt_1e886e5d:

    d ".........................."

translate english v01_park_flirt_dace0676:

    d "Amanda is included too."

translate english v01_park_flirt_3e8565d4:

    m "!!!!!"

translate english v01_park_flirt_b996c2f9:

    m "A…"

translate english v01_park_flirt_8556c5a2:

    m "Amanda?"

translate english v01_park_flirt_f04d9d3c:

    m "Amanda? The Amanda I know??!!!!?"

translate english v01_park_flirt_4074c170:

    d "Yes..............."

translate english v01_park_flirt_8fbef95d:

    n "She made an effort not to show how shocked she was and spoke up."

translate english v01_park_flirt_9477e89f:

    m "What were you thinking about?...."

translate english v01_park_flirt_7c37f422:

    d "Well, you know."

translate english v01_park_flirt_655420fd:

    d "Things similar to what we’ve been talking about..."

translate english v01_park_flirt_85227d89:

    d "Amanda caressing my cock and giving me blowjob... that sort of thing..."

translate english v01_park_flirt_f802d487:

    m "..................."

translate english v01_park_flirt_45c57229:

    m "So you see Amanda as a woman too?"

translate english v01_park_flirt_60b2324b:

    d "No, it’s a bit different."

translate english v01_park_flirt_3e0b909d:

    d "It’s like… yes and no at the same time…"

translate english v01_park_flirt_061d222d:

    d "I don’t really know."

translate english v01_park_flirt_6db00409:

    d "I just don’t know."

translate english v01_park_flirt_787eafb4:

    d "It just became like that at some point."

translate english v01_park_flirt_b702562e_1:

    d "......................."

translate english v01_park_flirt_b27c39d7:

    m "............................"

translate english v01_park_flirt_1d7c83d2:

    d "Mary, are you okay?"

translate english v01_park_flirt_672cbb50:

    n "Mary?"

translate english v01_park_flirt_507eeb42:

    n "She was shocked that [d_name] would imagine having sex with a middle-aged woman like that."

translate english v01_park_flirt_648ace70:

    d "Mary?"

translate english v01_park_flirt_be7e6a62:

    d "Mary? What’s wrong?"

translate english v01_park_flirt_f8e2ebe1:

    d "Say something."

translate english v01_park_flirt_1aefa8b4_3:

    m ".............."

translate english v01_park_flirt_f7ac5e9b:

    m "I’m sorry."

translate english v01_park_flirt_1ed6059b:

    m "I was just lost in thought for a moment."

translate english v01_park_flirt_39379f7a:

    m "I think I’m not feeling well today."

translate english v01_park_flirt_1161ea06:

    m "Don’t you think it’s unusually hot today?"

translate english v01_park_flirt_6225b646:

    d "Yes, it does."

translate english v01_park_flirt_954a970f:

    d "It feels hotter than usual to me as well."

translate english v01_park_flirt_6c052d01_1:

    m "..............."

translate english v01_park_flirt_04c3c441:

    n "They sat close together naturally."

translate english v01_park_flirt_42c7fe48:

    n "Then they gazed alternately at each other's eyes and lips."

translate english v01_park_flirt_bb97a41f:

    n "And then, without either one starting first, they began to part their lips."

translate english v01_park_flirt_6c052d01_2:

    m "..............."

translate english v01_park_flirt_379a7df1:

    m "What are we even doing right now?"

translate english v01_park_flirt_aae30f09:

    m "I think that couple earlier really got to both of us."

translate english v01_park_flirt_9291946d:

    m "Shall we go back now?"

translate english v01_park_flirt_1990630f:

    d "Yes, let’s go back now…"

translate english v01_youthcenter_evening_31d748c2:

    n "They rose from their seats and began walking."

translate english v01_youthcenter_evening_3286853a:

    n "For a while, they walked in silence."

translate english v01_youthcenter_evening_656c5a52:

    n "They needed time to think for themselves..."

translate english v01_youthcenter_evening_17d0c129:

    n "A sense of regret mingled with relief that they hadn't made a mistake."

translate english v01_youthcenter_evening_228848e3:

    m "Then, dear, you’ll come again soon, right?"

translate english v01_youthcenter_evening_bbba10ac:

    d "Of course. I’ll come see you every day, teacher. Haha."

translate english v01_youthcenter_evening_9c409ecc:

    m "And let’s just forget about everything that happened today."

translate english v01_youthcenter_evening_cc22559d:

    m "Just think of it as a strange day you experienced."

translate english v01_youthcenter_evening_4c4d9b7c:

    d "Alright, Mary."

translate english v01_youthcenter_evening_84440947:

    d "You know I love you, right?"

translate english v01_youthcenter_evening_a45c4e43:

    m "Of course, [d_name]. You know how much I care about and love you."

translate english v01_youthcenter_evening_7cda69e2:

    m "You’ve grown into such a fine young man, both in body and mind, [d_name]."

translate english v01_youthcenter_evening_0e89eb05:

    m "(( .................................... ))"

translate english v01_youthcenter_evening_2a8405f1:

    n "[d_name] pressed his body as close as possible to hers."

translate english v01_youthcenter_evening_22cd6e0f:

    m "(( Damn it, his penis keeps poking my belly. ))"

translate english v01_youthcenter_evening_c0311aa4:

    d "(( Uh................... ))"

translate english v01_youthcenter_evening_0b97efc6:

    d "(( Mary's scent... I feel like I might go crazy... ))"

translate english v01_youthcenter_evening_07fd11d9:

    n "His hand slid down precariously onto the upper part of Mary's buttocks."

translate english v01_youthcenter_evening_4139e1ea:

    n "Even though it was the upper part of her buttocks, he could feel the curve of her hipbone."

translate english v01_youthcenter_evening_ef6d92ed:

    m "........."

translate english v01_youthcenter_evening_a9dcd062:

    m "(( He still seems excited from our earlier conversation. ))"

translate english v01_youthcenter_evening_89d4fc5b:

    m "(( He’s gotten way too bold. ))"

translate english v01_youthcenter_evening_6a21657e:

    d "..............."

translate english v01_youthcenter_evening_4579293d:

    n "His hand completely enveloped the center of Mary's buttocks."

translate english v01_youthcenter_evening_c8351353:

    n "And his fingertips began to press, as if trying to spread her buttocks apart."

translate english v01_youthcenter_evening_5e90e29e:

    m "((What?))"

translate english v01_youthcenter_evening_fee68152:

    m "!!!!"

translate english v01_youthcenter_evening_cae26f4e:

    m "[d_name]. Your hand seems to be going too low."

translate english v01_youthcenter_evening_957f5e8d:

    m "I’m so happy to see you, [d_name]."

translate english v01_youthcenter_evening_0c0d224c:

    m "Make sure to come again soon, alright?"

translate english v01_youthcenter_evening_a67584e8:

    d "I had a great time today too."

translate english v01_youthcenter_evening_d05676b9:

    d "I’ll come more often."

translate english v01_youthcenter_evening_f1008634:

    d "(( Damn. ))"

translate english v01_youthcenter_evening_517698e4:

    d "(( I really love Mary’s scent. ))"

translate english v01_youthcenter_evening_517698e4_1:

    d "(( Damn, my dick's about to explode. ))"

translate english v01_youthcenter_evening_81e899c8:

    m "Ugh!!"

translate english v01_youthcenter_evening_f875ed99:

    m "(( Did I make a mistake? ))"

translate english v01_youthcenter_evening_139c7d5b:

    m "(( Did he turn his head? ))"

translate english v01_youthcenter_evening_1b825cee:

    m "(( !!!!!!!!!!!!!!!!!!! ))"

translate english v01_youthcenter_evening_992d43a0:

    m "(( Is he moving his tongue? ))"

translate english v01_youthcenter_evening_64d828c7:

    m "(( Oh my god ))"

translate english v01_youthcenter_evening_7d935156:

    m "(( Should I push him away? ))"

translate english v01_youthcenter_evening_ef9cbc7a:

    m "(( What if this hurts him? ))"

translate english v01_youthcenter_evening_5494c284:

    m "(( Ugh..!! ))"

translate english v01_youthcenter_evening_5939417e:

    n "Hesitating, she turned her head away as [d_name]'s tongue entered her mouth."

translate english v01_youthcenter_evening_9d3a9c7e:

    m "I’m sorry, [d_name]."

translate english v01_youthcenter_evening_6c5dcd26:

    m "I mis-aimed, hehe."

translate english v01_youthcenter_evening_e53a96e0:

    d "I’m sorry, Mary."

translate english v01_youthcenter_evening_8f5b93a8:

    d "Mary's scent was so good I couldn't help myself..."

translate english v01_youthcenter_evening_e5a1a10e:

    n "She was momentarily confused."

translate english v01_youthcenter_evening_e541c05b:

    n "She wanted to scold him for his rude behavior, but for some reason, she also felt like going along with him to some extent."

translate english v01_youthcenter_evening_5bbac03b:

    m "No, no. It’s alright."

translate english v01_youthcenter_evening_9354c7d2:

    m "I like you too, Honey."

translate english v01_youthcenter_evening_14857602:

    m "But save a kiss of love for your future girlfriend."

translate english v01_youthcenter_evening_9aa844cc:

    m "I’m not your girlfriend—I’m your teacher, okay?"

translate english v01_youthcenter_evening_4aacc384:

    d "................."

translate english v01_youthcenter_evening_7a8aa271:

    d "Even if we’re not in a relationship, we could still kiss if we like each other, right?"

translate english v01_youthcenter_evening_885cb622:

    m "What?"

translate english v01_youthcenter_evening_2f86ec9c:

    m "Haha, honey. Liking each other means in the context of a romantic relationship."

translate english v01_youthcenter_evening_54d17db0:

    m "I’m your teacher, [d_name]."

translate english v01_youthcenter_evening_0bc661cb:

    m "Just because we get closer doesn’t mean we can become lovers."

translate english v01_youthcenter_evening_c632a14e:

    d "But…"

translate english v01_youthcenter_evening_31e9d5ab:

    d "Mary mentioned it earlier too…"

translate english v01_youthcenter_evening_5fe51fd2:

    d "You told me you imagined caressing mine with your mouth."

translate english v01_youthcenter_evening_9e81208c:

    m "!!!!!!!!!"

translate english v01_youthcenter_evening_c63eb9c9:

    m "That was....."

translate english v01_youthcenter_evening_2ce68a57:

    m "Ha.......[d_name]."

translate english v01_youthcenter_evening_a317f437:

    m "That was just my imagination. But that doesn't mean we can kiss, right?"

translate english v01_youthcenter_evening_c632a14e_1:

    d "But....."

translate english v01_youthcenter_evening_5e3aec4e:

    d ".........."

translate english v01_youthcenter_evening_36bd000b:

    d "Then will you kiss my lips?"

translate english v01_youthcenter_evening_6c052d01:

    m "..............."

translate english v01_youthcenter_evening_b5fc80f7:

    m "Alright. Then let’s head home now, honey."

translate english v01_youthcenter_evening_79938fe1:

    m "It’s getting dark, and you’d be worried."

translate english v01_youthcenter_evening_c669e05c:

    n "She kissed the tip of [d_name]'s lips."

translate english v01_youthcenter_evening_2343b685:

    n "In that instant, she felt something stir deep within her."

translate english v01_youthcenter_evening_93f733b1:

    m "................."

translate english v01_youthcenter_evening_2de350a3:

    d "That was too short. Just once more."

translate english v01_youthcenter_evening_6c052d01_1:

    m "..............."

translate english v01_youthcenter_evening_fee68152_1:

    m "!!!!"

translate english v01_youthcenter_evening_0c3335b4:

    n "She kissed the edge of [d_name]'s lips."

translate english v01_youthcenter_evening_7504ec42:

    n "And once again, without either of them initiating it, they parted each other's lips."

translate english v01_youthcenter_evening_f358b65e:

    m "Honey..."

translate english v01_youthcenter_evening_c147ead5:

    m "We should go home quickly now. It’ll get dark soon."

translate english v01_youthcenter_evening_680bf6d6:

    m "........................"

translate english v01_youthcenter_evening_78a9383c:

    m "And could you let go of my ass?"

translate english v01_youthcenter_evening_061b1533:

    n "She felt his hand slide upward, as if brushing against her buttocks."

translate english v01_youthcenter_evening_171c6722:

    n "And when his hand lingered on her buttocks, she reached out and stopped him."

translate english v01_youthcenter_evening_690f5656:

    c "..........."

translate english v01_youthcenter_evening_d6ce8825:

    c "What are those two doing?"

translate english v01_youthcenter_evening_38dea55a:

    c "That’s some heavy physical contact."

translate english v01_youthcenter_evening_802bd32b:

    c "Did they usually do this much?........"

translate english v01_youthcenter_evening_4f49413b:

    m "Alright, [d_name]."

translate english v01_youthcenter_evening_f956d48d:

    m "Make sure to come again soon, okay?"

translate english v01_youthcenter_evening_36636fe3:

    c "Hmm......."

translate english v01_youthcenter_evening_0f6ff7fe:

    c "The atmosphere is a bit awkward."

translate english v01_youthcenter_evening_f707fb5d:

    c "..........................."

translate english v01_helendrunk_a94a95b4:

    d "Huh?"

translate english v01_helendrunk_359004ed:

    n "When he arrived, [h_name] was lying face down on the dining table in the living room."

translate english v01_helendrunk_307409b5:

    n "She was wearing pink sweatpants."

translate english v01_helendrunk_fac8215b:

    d "............"

translate english v01_helendrunk_d0b24e26:

    d "(( Is she drunk? ))"

translate english v01_helendrunk_c35185f5:

    d "(( Oh my... ))"

translate english v01_helendrunk_7c0a9214:

    d ".............."

translate english v01_helendrunk_754d0533:

    d "(( Sleeping without a care in the world.. ))"

translate english v01_helendrunk_e6078263:

    h "Yes?"

translate english v01_helendrunk_975f24cc:

    h "Is that Michael?"

translate english v01_helendrunk_be2540b6:

    h "Ah, sorry [d_name]."

translate english v01_helendrunk_0c984290:

    d "Are you okay, [h_name]?"

translate english v01_helendrunk_d7b0eb44:

    d "You look really tired."

translate english v01_helendrunk_5551fbe8:

    h "I’m fine."

translate english v01_helendrunk_58e2fe23:

    h "I just worked out and had a little whiskey."

translate english v01_helendrunk_0953ae4a:

    d "Oops!"

translate english v01_helendrunk_3c36926b:

    d "Are you alright?"

translate english v01_helendrunk_b820860e:

    d "I’ll help you to your room."

translate english v01_helendrunk_bcc8f3f7:

    h "No, I can go alone."

translate english v01_helendrunk_a8e5e205:

    h "Thank you, [d_name]."

translate english v01_helendrunk_ad668b65:

    h "I’ll go inside."

translate english v01_helendrunk_7ab45a8a:

    h "Good night."

translate english v01_helendrunk_a9861e1d:

    d "...................."

translate english v01_mcshower_dbce21a9:

    d "god...."

translate english v01_mcshower_88a96748:

    d "Ah Mary....."

translate english v01_mcshower_4a82db45:

    m "Oh, you sprayed it all over."

translate english v01_mcshower_87583e7d:

    m "It's so delicious darling."

translate english v01_mcroom05_b801dd8c:

    d "When I’m with Mary, it feels like I'm finally home..."

translate english v01_mcroom05_44a92def:

    d "Damn..."

translate english v01_mcroom05_53552647:

    d "She really is a beautiful woman..."

translate english v01_mcroom05_fac8215b:

    d "............"

translate english v01_mcroom05_fac8215b_1:

    d "............"

translate english v01_mcroom05_242bdb19:

    d "Mary....Mary....Mary...."

translate english v01_mcroom05_57545faa:

    d "I can't believe she actually thought about sucking my dick..."

translate english v01_mcroom05_d06a8972:

    d "I can’t believe she thought that too."

translate english v01_mcroom05_c1263c51:

    d "Sigh.......[d_name]."

translate english v01_mcroom05_edc4e9a9:

    d "Her breath....."

translate english v01_mcroom05_aa99d9bb:

    d "If we had kissed.............."

translate english v01_mcroom05_3af4c7a6:

    d "If she had allowed my tongue…"

translate english v01_mcroom05_1e886e5d:

    d ".........................."

translate english v01_mcroom05_e12291c7:

    d "If I had kissed her, would she have touched my cock?"

translate english v01_mcroom05_65a6b354:

    d "If that had happened, my relationship with her would have ended there."

translate english v01_mcroom05_317367b3:

    d "........................"

translate english v01_youthcenter_night_8429dd41:

    m "Ah, I’m so tired.."

translate english v01_youthcenter_night_9dffe92d:

    m "Did I walk too much today.."

translate english v01_youthcenter_night_1aefa8b4:

    m ".............."

translate english v01_youthcenter_night_1aefa8b4_1:

    m ".............."

translate english v01_youthcenter_night_86bdcbb9:

    m "Today was really a crazy day."

translate english v01_youthcenter_night_4e570b37:

    m "Ha........"

translate english v01_youthcenter_night_c6c1eee3:

    m "[d_name]."

translate english v01_youthcenter_night_d157c623:

    m "Did you really try to kiss me?"

translate english v01_youthcenter_night_5aebff17:

    m ".........."

translate english v01_youthcenter_night_5aebff17_1:

    m ".........."

translate english v01_youthcenter_night_93f733b1:

    m "................."

translate english v01_youthcenter_night_e695dcff:

    m "[d_name], you bastard."

translate english v01_youthcenter_night_bca5551f:

    m "You didn't study at college, but you learned some really great things."

translate english v01_youthcenter_night_454742b6:

    m "............"

translate english v01_youthcenter_night_99f8f372:

    m "She was a crazy witch."

translate english v01_youthcenter_night_67b06a2e:

    m "So you’ve got quite a fine thing, huh?"

translate english v01_youthcenter_night_b8fe7492:

    m "Yeah. I’ll give you that."

translate english v01_youthcenter_night_546dd187:

    m "Well, of course I didn’t see it myself today."

translate english v01_youthcenter_night_a8f8ed57:

    m "Hahaha"

translate english v01_youthcenter_night_bcaec50d:

    m "What? You actually thought about sucking [d_name]'s cock?"

translate english v01_youthcenter_night_a9e310ae:

    m "Mary, you crazy woman. Hahaha."

translate english v01_youthcenter_night_ada0737a:

    m "What on earth did I just say to him?"

translate english v01_youthcenter_night_8af6ecea:

    m "Sigh.........."

translate english v01_youthcenter_night_ec0ec96d:

    m "Why didn't you just tell him to fuck me roughly right now?"

translate english v01_youthcenter_night_83a594de:

    m "Fill me up right now. Huh?"

translate english v01_youthcenter_night_7f96dfb4:

    m "What on earth does [d_name] think of me...."

translate english v01_youthcenter_night_9886f1df:

    m "After saying something like that..."

translate english v01_youthcenter_night_05963d31:

    m "Will he come see me again?....."

translate english v01_youthcenter_night_344c80a2:

    n "She stared at her fingers for a moment, lost in thought."

translate english v01_youthcenter_night_c4ce4314:

    n "She couldn't shake the thought of what might have happened next if she'd kissed [d_name]."

translate english v01_youthcenter_night_80adb125:

    m "......................"

translate english v01_youthcenter_night_c0ced596:

    m "If I had kissed [d_name] today, how would I have felt..."

translate english v01_youthcenter_night_20c0f017:

    m "Did it feel like we were just messing around with each other?"

translate english v01_youthcenter_night_81f1d0a1:

    m "Or would my heart have ignited all of a sudden if we had done that?"

translate english v01_youthcenter_night_98840992:

    m "............................."

translate english v01_youthcenter_night_b85cdefe:

    m "If I had kissed him, how far would he have pushed me?"

translate english v01_youthcenter_night_faeefed2:

    m "He would have touched my breasts, of course... And then..."

translate english v01_youthcenter_night_f23211cc:

    m "Would he have unzipped his pants and asked me to suck him?"

translate english v01_youthcenter_night_f4950856:

    m "Or would he have suggested we go behind that tree where the couple was?"

translate english v01_youthcenter_night_f0121d22:

    m "And then would he have pulled down my panties?"

translate english v01_youthcenter_night_193076b4:

    m "Ah........."

translate english v01_youthcenter_night_5401af12:

    m "I can’t get it out of my head..."

translate english v01_marywakeup_18548549:

    m "..........."

translate english v01_marywakeup_9d5ec1b6:

    m "Come on, Mary, get a grip."

translate english v01_marywakeup_a500ccfd:

    m "What are you thinking right now?"

translate english v01_marywakeup_b09109ad:

    m "Are you having some kind of problem?"

translate english v01_marywakeup_daa2448e:

    n ""

translate english v01_marywakeup_8b17ddcc:

    m "Sigh....."

translate english v01_marywakeup_17fa0eab:

    m "Right."

translate english v01_marywakeup_f11e94db:

    m "I’m a bit late today. I’m leaving work now."

translate english v01_marywakeup_6003437c:

    m "Richard. Sorry, but handle dinner yourself tonight."

translate english v01_marywakeup_fa039228:

    m "You can do at least that, right?"

translate english v01_marywakeup_783b6208:

    m "Sigh....."

translate english v01_marywakeup_26014982:

    m "I’m really tired today."

translate english v01_marywakeup_a1b169ac:

    m "Please don’t talk like that."

translate english v01_marywakeup_e789909c:

    m "What do you mean by that?"

translate english v01_marywakeup_9a5aafae:

    m "Please don’t pressure me like that."

translate english v01_mcmary_phone_1b022507:

    n "She couldn't fall asleep even as midnight approached."

translate english v01_mcmary_phone_59098e06:

    n "Her mind was a jumble of emotions—palpitations, excitement, embarrassment, thirst, and more."

translate english v01_mcmary_phone_335baa5e:

    d "......................"

translate english v01_mcmary_phone_a9039faa:

    d "Damn..."

translate english v01_mcmary_phone_29faac99:

    d "What should I reply..."

translate english v01_mcmary_phone_cab741bb:

    d "My face photo? Hmm....."

translate english v01_mcmary_phone_df5f5a08:

    d "Why is she asking for a photo at this hour?"

translate english v01_mcmary_phone_838255e4:

    d "Hmm....."

translate english v01_mcmary_phone_92f21ed5:

    n "What should I do?"

translate english v01_mary_shock_80a02690:

    d "Damn, I can’t get what she said earlier today out of my head."

translate english v01_mary_shock_91738439:

    d "This is driving me crazy."

translate english v01_mary_shock_a797f6ce:

    d "............."

translate english v01_mary_shock_a6f63505:

    d "She said she imagined sucking my dick..."

translate english v01_mary_shock_77673f80:

    d "........."

translate english v01_mary_shock_b13e2a21:

    d "What would her reaction be if I showed her mine?"

translate english v01_mary_shock_71ab3056:

    d "Would she think I'm a pervert?"

translate english v01_mary_shock_17a56b6e:

    d "She clearly said she fantasizes too. It's just a picture, what's the big deal?"

translate english v01_mary_shock_6422c193:

    d "........................."

translate english v01_mary_shock_3cdc152e:

    d "Damn it... Whatever happens, happens."

translate english v01_mary_shock_9869740c:

    d "Mary's an adult and so am I..."

translate english v01_mary_shock_62190eb9:

    d "Are you really going to do this?"

translate english v01_mary_shock_af34239f:

    n "She was shocked by the photo [d_name] sent."

translate english v01_mary_shock_26bf5a06:

    n "The first shock was that it resembled something she'd only seen in pornography during her youth,"

translate english v01_mary_shock_a23a0197:

    n "and the second shock came from the thought that this might be [d_name]'s."

translate english v01_mary_shock_80086b98:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_mary_shock_a90459a8:

    m "What the hell is this?!"

translate english v01_mary_shock_f561e205:

    m "What the hell is he doing?"

translate english v01_mary_shock_ed914577:

    d "You crazy shit. What the hell are you doing?"

translate english v01_mary_shock_ce5b25da:

    d "Are you trying to end things with Mary today?"

translate english v01_mary_shock_00c76add:

    d "My heart is pounding like it's about to burst."

translate english v01_mary_shock_120e7da2:

    d "Damn. The damage is already done."

translate english v01_mary_shock_140e8cf2:

    d "I want to do it again."

translate english v01_mary_shock_2066d2bc:

    d "You idiot… what are you thinking?"

translate english v01_mary_shock_945c1be8:

    d "Let's sleep again."

translate english v01_mary_shock_03d16520:

    d "Again...."

translate english v01_mary_shock_9e0ae4cf:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_mary_shock_84390583:

    n "The second photo hit her with an even greater shock than the first."

translate english v01_mary_shock_b8014335:

    n "The composition of that photo, capturing both [d_name]'s cock and his face simultaneously, was even more explicit."

translate english v01_mary_shock_1ffc0b61:

    n "The visual impact was so intense it left her barely clinging to her sanity."

translate english v01_mary_shock_6552828f:

    m "Oh my god [d_name]!!"

translate english v01_mary_shock_939ff9bd:

    m "Again?"

translate english v01_mary_shock_7fd66729:

    d "What the hell did I do?"

translate english v01_mary_shock_ccfb1986:

    d "This is like exhibitionism."

translate english v01_mary_shock_64059ce1:

    m "Oh my god [d_name]."

translate english v01_mary_shock_c6018fb3:

    n "The shock of the photos was truly immense."

translate english v01_mary_shock_7725259e:

    n "She felt her pussy twitch and grow wet."

translate english v01_mary_shock_454742b6:

    m "............"

translate english v01_mary_shock_e86d97f0:

    m "You've really bulked up."

translate english v01_mary_shock_fb0a14c3:

    m "Oh my god.."

translate english v01_mary_shock_3dc8baae:

    n "She sat perched on the bed, rubbing her face to ease the shock."

translate english v01_mary_shock_9f09b050:

    m "Oh my god oh my god oh my god..."

translate english v01_mary_shock_3cda8ec9:

    m "What the hell is going on."

translate english v01_mary_shock_6e0b28e4:

    m "Oh no, oh no, oh no..."

translate english v01_mary_shock_91b71382:

    m "Oh my god oh my god oh my god..."

translate english v01_mary_shock_d266a19b:

    m "(( Damn you, [d_name]. ))"

translate english v01_mary_shock_6e5b0d08:

    m "(( What did you do to me? ))"

translate english v01_mary_shock_fb03f0fc:

    m "(( Was there a true nature hidden behind that innocent face? ))"

translate english v01_mary_shock_7336edab:

    m "(( Oh my god. ))"

translate english v01_mary_shock_766b8fff:

    m "(( Did my words today give him confidence? ))"

translate english v01_mary_shock_853c0fbc:

    n "She picked up the phone again and stared at the photo of his cock."

translate english v01_mary_shock_7ece3adb:

    n "This time she examined its shape, color, and veins more closely."

translate english v01_mary_shock_245aeca1:

    n "And she felt something flowing inside her thighs."

translate english v01_mary_shock_336c3e50:

    m "Oh my god, oh my god, oh my god..."

translate english v01_mary_shock_b27c39d7:

    m "............................"

translate english v01_mary_shock_c07df898:

    m "What am I supposed to do..."

translate english v01_mcroom06_234595b2:

    n "When [d_name] opened his eyes, a woman was sitting on the edge of the bed, doing something."

translate english v01_mcroom06_9b92d516:

    n "Who is she?"

translate english v01_mcroom06_ae569a38:

    n "Could she be [h_name]?"

translate english v01_mcroom06_89e241df:

    n "Why is she here in her underwear?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
