translate english ch06_orph01_d58e4db4:

    m "Gghk...."

translate english ch06_orph01_de702e6c:

    eve "Huh?"

translate english ch06_orph01_47a05c97:

    m "Gghk......."

translate english ch06_orph01_4357ebdf:

    eve "!!!!!!"

translate english ch06_orph01_bc8aaa63:

    eve "Who's there? Are you okay?..."

translate english ch06_orph01_d92eeb86:

    eve "......."

translate english ch06_orph01_47a05c97_1:

    m "Gghk......."

translate english ch06_orph01_8810a88b:

    eve "!!!"

translate english ch06_orph01_b40dbcd5:

    eve "Are you throwing up??"

translate english ch06_orph01_accf6b5c:

    m "It's me, Mary."

translate english ch06_orph01_de398525:

    eve "!!!!"

translate english ch06_orph01_b8a766e0:

    eve "Oh.....is something wrong?"

translate english ch06_orph01_83de7f4f:

    eve "**(What?)**"

translate english ch06_orph01_5b722f96:

    eve "**(Something's not right..)**"

translate english ch06_orph01_80e08958:

    eve "........."

translate english ch06_orph01_47a05c97_2:

    m "Gghk......."

translate english ch06_orph01_8810a88b_1:

    eve "!!!"

translate english ch06_orph01_1ce87f9a:

    eve "Are you okay, Mary??"

translate english ch06_orph01_7e882760:

    eve ".........."

translate english ch06_orph01_8a407386:

    eve "**(What the hell...)**"

translate english ch06_orph01_4357ebdf_1:

    eve "!!!!!!"

translate english ch06_orph01_80e08958_1:

    eve "........."

translate english ch06_orph01_c811353f:

    eve "**(Is something moving in there??)**"

translate english ch06_orph01_fc8d8670:

    m "**(Damn it, [d_name]!!!!!)**"

translate english ch06_orph01_aefe4cb6:

    m "**(There's someone right outside!!)**"

translate english ch06_orph01_1ddae0dc:

    m "**(Can't you hear her???!!!)**"

translate english ch06_orph01_c002a73a:

    n "Mary couldn't tell if [d_name] had noticed someone else nearby."

translate english ch06_orph01_5a061972:

    n "He acted like he didn't care at all."

translate english ch06_orph01_34a74286:

    n "At that moment, Mary couldn't trust him one bit."

translate english ch06_orph01_4291f940:

    n "Her entire career could be ruined in a matter of seconds."

translate english ch06_orph01_79b70afa:

    m "!!!!!!!"

translate english ch06_orph01_aa6b5650:

    m "**(Hey!!!!!!)**"

translate english ch06_orph01_aa4b364a:

    m "Gghk..."

translate english ch06_orph01_4357ebdf_2:

    eve "!!!!!!"

translate english ch06_orph01_b252fad9:

    eve "Are you sure you're okay, Mary?"

translate english ch06_orph01_86dbd4ae:

    eve "........"

translate english ch06_orph01_bde56903:

    eve "Shouldn't you go to the hospital?"

translate english ch06_orph01_5aebff17:

    m ".........."

translate english ch06_orph01_8d4c40cd:

    m "Nuh."

translate english ch06_orph01_1d95335a:

    m "I'm fihne."

translate english ch06_orph01_4c6af518:

    eve "What??!!"

translate english ch06_orph01_8452f4a5:

    eve "**(Something's definitely off.)**"

translate english ch06_orph01_80e08958_2:

    eve "........."

translate english ch06_orph01_0cb9b90d:

    eve "**(I'm sure there's someone else in there...)**"

translate english ch06_orph01_80e08958_3:

    eve "........."

translate english ch06_orph01_97f1dde6:

    m "Gghk... No."

translate english ch06_orph01_a32fd143:

    m "I took some medicine, so I'll be fine."

translate english ch06_orph01_11f2bb3f:

    m "Thanks, Eve."

translate english ch06_orph01_80e08958_4:

    eve "........."

translate english ch06_orph01_2b244313:

    eve "Okay... I understand."

translate english ch06_orph01_cdaf9b82:

    eve "Call me if you need any help."

translate english ch06_orph01_1f29a2dd:

    m "Yeah, I will."

translate english ch06_orph01_11f2bb3f_1:

    m "Thanks, Eve."

translate english ch06_orph01_a8bf74c2:

    d "**(God, that woman is so persistent!!!)**"

translate english ch06_orph01_72e656d1:

    eve "Ahem."

translate english ch06_orph01_9475504e:

    d "**(Please, just go away.....)**"

translate english ch06_orph01_ef6d92ed:

    m "........."

translate english ch06_orph01_11f2bb3f_2:

    m "Thanks, Eve."

translate english ch06_orph01_0e8c6f54:

    eve "Yeah...."

translate english ch06_orph01_80e08958_5:

    eve "........."

translate english ch06_orph01_5255e1a5:

    eve "**(Mary's been acting kind of strange lately....)**"

translate english ch06_orph01_c35f0786:

    eve "**(Hmm.......)**"

translate english ch06_orph01_e202583f:

    eve "**(Have other people noticed it too??)**"

translate english ch06_orph01_db0d14c8:

    eve "....."

translate english ch06_orph01_27f20dc3:

    eve "**(I should talk to Celine about this.)**"

translate english ch06_orph01_ebba24db:

    m "Haaah........."

translate english ch06_orph01_fd3af3e2:

    m "You little...!!"

translate english ch06_orph01_26cf6766:

    m "!!!!!!!!!!!!"

translate english ch06_orph01_2af1c974:

    n "Suddenly, she felt her lower body being pulled forward."

translate english ch06_orph01_30fcb0e2:

    n "Before she knew it, she was precariously leaning back over the toilet."

translate english ch06_orph01_acd88737:

    m "Hey!!"

translate english ch06_orph01_ef4b43d1:

    m "What are you doing, [d_name]!!!!!!"

translate english ch06_orph01_b97c6f0d:

    m "Aah!!!!!!!!!!!!!!"

translate english ch06_orph01_6752cdb3:

    m "[d_name]!!!!!"

translate english ch06_orph01_e970bb24:

    m "Ngh!!!!!!!"

translate english ch06_orph01_9835a02f:

    n "It was a pleasure she hadn't experienced in a very long time."

translate english ch06_orph01_8ecad7b7:

    n "His mouth gently enveloped her pussy."

translate english ch06_orph01_b3650d59:

    n "The sensation of [d_name]'s lips and tongue broke down yet another layer of her self-control."

translate english ch06_orph01_232b2a30:

    n "He could taste a subtle flavor on the tip of his tongue."

translate english ch06_orph01_756aa8b1:

    n "His tongue kept probing insistently at her vaginal opening."

translate english ch06_orph01_fa28efa4:

    n "He could feel her pussy twitch ever so slightly."

translate english ch06_orph01_625317f1:

    n "She was overwhelmed by the pleasure coursing through her body."

translate english ch06_orph01_2afcbb72:

    n "The only thing she could do was...."

translate english ch06_orph01_248ef4f8:

    m "Ah, [d_name]!!!!!!"

translate english ch06_orph01_d76fab35:

    d "!!!!!!"

translate english ch06_orph01_fb623621:

    d "Gah!!!!!!!"

translate english ch06_orph01_edbb7d05:

    d "........"

translate english ch06_orph01_bba73a03:

    d "Ow!!"

translate english ch06_orph01_26cf6766_1:

    m "!!!!!!!!!!!!"

translate english ch06_orph01_159d58c4:

    m "I'm sorry, I'm sorry!!"

translate english ch06_orph01_f32e5418:

    m "I didn't mean to hit you that hard.."

translate english ch06_orph01_f3169666:

    m "You just startled me so badly....."

translate english ch06_orph01_d1862dba:

    m "Are you hurt??!!"

translate english ch06_orph01_dd4f920a:

    d "Haha, I'm okay."

translate english ch06_orph01_1c141636:

    d "I deserved that, haha."

translate english ch06_orph01_44b33e41:

    d "**(That knee really got me good, hahaha...)**"

translate english ch06_orph01_f465d777:

    d "**(Did she do that on purpose and just pretend it was an accident?...)**"

translate english ch06_orph01_438de33f:

    m "Ugh...."

translate english ch06_orph01_c27891c3:

    m "What the hell......"

translate english ch06_orph01_b6bee028:

    m "Oh my God....."

translate english ch06_orph01_6da5bae3:

    m "You've really lost your mind...."

translate english ch06_orph01_f09ab91a:

    m "What the hell are you doing...."

translate english ch06_orph01_e5c36b54:

    d "..........."

translate english ch06_orph01_f922d640:

    m "Have you completely lost your mind....."

translate english ch06_orph01_203cc60b:

    d "......."

translate english ch06_orph01_30adbcbb:

    m "What the hell is going on in this bathroom....."

translate english ch06_orph01_1475b546:

    m "Phew........"

translate english ch06_orph01_a677ba8d:

    m "**(Oh my God........)**"

translate english ch06_orph01_74260c86:

    m "**(I can still feel his mouth down there.......)**"

translate english ch06_orph01_790b0cf7:

    m "Get out of here."

translate english ch06_orph01_4cd15d58:

    d "....."

translate english ch06_orph01_c61a5915:

    m "Go wait in my office."

translate english ch06_orph01_38de17bb:

    m "Check the hallway carefully, then run straight to my office."

translate english ch06_orph01_b301144b:

    m "Got it?"

translate english ch06_orph01_7c0a9214:

    d ".............."

translate english ch06_orph01_31b78666:

    d "Okay.."

translate english ch06_orph01_b7a0bfa4:

    d "I'm leaving now."

translate english ch06_orph01_7c0a9214_1:

    d ".............."

translate english ch06_orph01_c28a8e4f:

    d "Damn it......"

translate english ch06_orph01_29224e12:

    m "What??"

translate english strings:
    old "그녀와 몸을 밀착 시킨다."
    new "Press my body against hers."

translate english ch06_orph01_92f21ed5:

    n "What should I do?"

translate english ch06_orph01_db526d3c:

    m "!!!!!"

translate english ch06_orph01_fd646cf3:

    m "What are you doing???!!!"

translate english ch06_orph01_4ed15068:

    d "Ah... Mary...."

translate english ch06_orph01_5e3aec4e:

    d ".........."

translate english ch06_orph01_f1bff77c:

    m "........"

translate english ch06_orph01_b18717b9:

    d "You know something?.."

translate english ch06_orph01_66103281:

    m "Ugh..... What now??!!"

translate english ch06_orph01_1e01f2e4:

    m "What are you going to say this time?"

translate english ch06_orph01_5e3aec4e_1:

    d ".........."

translate english ch06_orph01_dfc1e955:

    d "Your ass is absolutely amazing...."

translate english ch06_orph01_71159fc3:

    m "......."

translate english ch06_orph01_a222e0f5:

    m "Sigh...."

translate english ch06_orph01_076effe4:

    d "How can it be so perfectly shaped....."

translate english ch06_orph01_2131128d:

    d "Did you know I always stared at your breasts and ass whenever I saw you?"

translate english ch06_orph01_71159fc3_1:

    m "......."

translate english ch06_orph01_24f504f0:

    d "Oh my God....."

translate english ch06_orph01_7c0a9214_2:

    d ".............."

translate english ch06_orph01_a9b45c9d:

    d "I can't believe I'm actually touching you like this....."

translate english ch06_orph01_b13eab46:

    m "Don't."

translate english ch06_orph01_37bd252b:

    m "I'm going to get angry."

translate english ch06_orph01_a4f92143:

    d "Not too big, not too small. Just the perfect size..."

translate english ch06_orph01_7c0a9214_3:

    d ".............."

translate english ch06_orph01_35659156:

    d "And your pussy, too..."

translate english ch06_orph01_4d64d97d:

    m "Seriously, stop it."

translate english ch06_orph01_bd5a1b57:

    m "Is this really the kind of person you are??"

translate english ch06_orph01_edbb7d05_1:

    d "........"

translate english ch06_orph01_cd482a67:

    m "You're starting to scare me.."

translate english ch06_orph01_dce96694:

    m "Do you understand what I'm saying?"

translate english ch06_orph01_0c83f565:

    d "Why?"

translate english ch06_orph01_52e23cf6:

    m "What do you mean, why?"

translate english ch06_orph01_afec38ce:

    m "Do you really have to ask?"

translate english ch06_orph01_8a3f5818:

    d "We've already been closer than this, haven't we?"

translate english ch06_orph01_5aebff17_1:

    m ".........."

translate english ch06_orph01_be4bfc12:

    d "I really like you, Mary."

translate english ch06_orph01_08ae6ee6:

    d "I love you, Mary."

translate english ch06_orph01_7c0a9214_4:

    d ".............."

translate english ch06_orph01_57a7210c:

    d "I want you to be mine..."

translate english ch06_orph01_cf4d1b40:

    m "............."

translate english ch06_orph01_e41de5cc:

    n "She could feel his hard cock between her butt cheeks."

translate english ch06_orph01_418c6c34:

    n "She felt him trying to press his cock as tightly against her pussy as possible."

translate english ch06_orph01_25dead3b:

    m "Stop it......"

translate english ch06_orph01_771fbf05:

    m "Not here..."

translate english ch06_orph01_2cc31ad1:

    m "This is where I work..."

translate english ch06_orph01_dd77ee46:

    d "Just let me stay like this for a little while......"

translate english ch06_orph01_2407bf99:

    m "Sigh............"

translate english ch06_orph01_18548549:

    m "..........."

translate english ch06_orph01_8e278043:

    d "Ah.... My cock feels like it's about to burst..."

translate english ch06_orph01_f1bff77c_1:

    m "........"

translate english ch06_orph01_60631b4b:

    d "Being like this makes me feel like you're mine...."

translate english ch06_orph01_d36bedd8:

    d "Like you've finally let me have you, Mary...."

translate english ch06_orph01_18548549_1:

    m "..........."

translate english ch06_orph01_267a3072:

    d "I'm the only one who gets to do this to you..."

translate english ch06_orph01_885cb622:

    m "What?"

translate english ch06_orph01_74bbc490:

    d "Well, Uncle Richard too...."

translate english ch06_orph01_3ac9b26a:

    m "Oh, for God's sake...."

translate english ch06_orph01_691ea635:

    m "What are you even talking about....."

translate english ch06_orph01_7cd063ae:

    m "That's enough now."

translate english ch06_orph01_2e253464:

    m "Go wait in my office, honey."

translate english ch06_orph01_2e687d64:

    m "!!!!!!!!!!"

translate english ch06_orph01_5e0d39fe:

    m "What are you doing??!!"

translate english ch06_orph01_a31540eb:

    d "Ah... Mary...."

translate english ch06_orph01_c452361a:

    d "You're my woman now, right??"

translate english ch06_orph01_962ae1cd:

    m "What do you mean by that??"

translate english ch06_orph01_cb0de31f:

    d "You sucked my cock...."

translate english ch06_orph01_a8c71bf6:

    d "And I sucked your pussy."

translate english ch06_orph01_6b1e8f75:

    d "So that means you're my woman now."

translate english ch06_orph01_7603a925:

    m "I'm your teacher! What are you talking about??!!"

translate english ch06_orph01_a31540eb_1:

    d "Ah... Mary...."

translate english ch06_orph01_5e3aec4e_2:

    d ".........."

translate english ch06_orph01_e939bdc2:

    d "What are you thinking about right now??...."

translate english ch06_orph01_71159fc3_2:

    m "......."

translate english ch06_orph01_048059f4:

    m "I'm not thinking about anything."

translate english ch06_orph01_f5832a7f:

    d "I'm imagining putting it inside you right now."

translate english ch06_orph01_5aebff17_2:

    m ".........."

translate english ch06_orph01_e3786177:

    d "Ah, damn it...."

translate english ch06_orph01_f849315e:

    m "Stop it!!"

translate english ch06_orph01_c43ca0cc:

    m "!!!!!!!!!!!"

translate english ch06_orph01_c43ca0cc_1:

    m "!!!!!!!!!!!"

translate english ch06_orph01_b6353d99:

    m "What are you doing?!!!!"

translate english ch06_orph01_9ee4e63d:

    d "Ah... Mary....."

translate english ch06_orph01_0323fb37:

    d "I want to know more about you, Mary..."

translate english ch06_orph01_88a9b2fe:

    d "I want to be your man.."

translate english ch06_orph01_2cf4ea13:

    d "I want to be your man instead of Uncle Richard."

translate english ch06_orph01_6dbe802d:

    m "What??!!!!"

translate english ch06_orph01_18548549_2:

    m "..........."

translate english ch06_orph01_38c825ca:

    m "Are you insane?"

translate english ch06_orph01_db47cb09:

    m "H-how could you say something like that about Richard and me........"

translate english ch06_orph01_3683232b:

    m "P-pull my panties back up."

translate english ch06_orph01_1769ca80:

    m "Now."

translate english ch06_orph01_926ce780:

    d "Haaah.........."

translate english ch06_orph01_d62a18d8:

    d "The day you gave me a blowjob...."

translate english ch06_orph01_5aebff17_3:

    m ".........."

translate english ch06_orph01_aa6a2845:

    d "Did you kiss Uncle Richard that night with the same mouth you used to suck me?"

translate english ch06_orph01_57110187:

    m "[d_name]!!!"

translate english ch06_orph01_ea2e0cd7:

    d "Did you have sex with Uncle Richard while thinking about my cock?"

translate english ch06_orph01_f849315e_1:

    m "Stop it!!"

translate english ch06_orph01_e5c36b54_1:

    d "..........."

translate english ch06_orph01_c65e2b0d:

    d "I'm sorry, Mary...."

translate english ch06_orph01_0c7a8870:

    d "I'm losing my mind too..."

translate english ch06_orph01_0a633a97:

    m "That's enough. Go wait in my office."

translate english ch06_orph01_5475c369:

    m "You're acting strange again, honey."

translate english ch06_orph01_926ce780_1:

    d "Haaah.........."

translate english ch06_orph01_f4cc7b3e:

    d "Okay....."

translate english ch06_orph01_80bd42cb:

    m "Good..."

translate english strings:
    old "그녀의 음부를 확인한다."
    new "Check her pussy."

translate english ch06_orph01_92f21ed5_1:

    n "What should I do?"

translate english ch06_orph01_14033452:

    m "!!!!!!!!!!!!!!!!"

translate english ch06_orph01_66be1f24:

    m "You crazy bastard!!"

translate english ch06_orph01_c06138fb:

    m "Haaah......."

translate english ch06_orph01_18548549_3:

    m "..........."

translate english ch06_orph01_3dcbd2bc:

    m "What on earth did I do to you back then......"

translate english ch06_orph01_8b70523f:

    m "This is all my fault, [d_name]..."

translate english ch06_orph01_a9bd4b57:

    m "Go wait in my office."

translate english ch06_orph01_abbdb196:

    d "Um.."

translate english ch06_orph01_fbe6fe19:

    m "Don't say another word."

translate english ch06_orph01_572c2d86:

    m "Do I have to spank you??!!"

translate english ch06_orph01_8c097a17:

    d "Okay."

translate english ch06_orph01_edbb7d05_2:

    d "........"

translate english ch06_orph01_fdc3bdd7:

    m "And make sure you check the hallway!!"

translate english ch06_orph01_77673f80:

    d "........."

translate english ch06_orph01_45bbaa2d:

    d "**(A spanking? Seriously?....)**"

translate english ch06_orph01_9ddb37f4:

    d "**(Does she think I'm some little boy?...)**"

translate english ch06_orph01_267ae52d:

    d "**(She saw my cock and still treats me like a child??)**"

translate english ch06_orph01_cf4d1b40_1:

    m "............."

translate english ch06_orph01_fdafaf95:

    m "Why did I make him do all these things?......."

translate english ch06_orph01_62acc983:

    m "I've completely failed as an adult....."

translate english ch06_orph01_d4ae49da:

    m "Do I even deserve to be the director of this place?......"

translate english ch06_orph01_9ca413ed:

    m "How am I any better than that crazy bitch I met at the park??....."

translate english ch06_orph01_e3b3bbf4:

    m "At least that woman was honest about it...."

translate english ch06_orph01_111c1278:

    d "??"

translate english ch06_orph01_a0c3a447:

    n "When he entered Mary's office, an unfamiliar woman was sitting there."

translate english ch06_orph01_9580ae64:

    n "He couldn't recognize her from her silhouette."

translate english ch06_orph01_111c1278_1:

    d "??"

translate english ch06_orph01_abee91be:

    unknown "??"

translate english ch06_orph01_b4d191c2:

    unknown "!!!!!!!!!!!!!!!!!!!"

translate english ch06_orph01_a67a3683:

    unknown "Y-you........."

translate english ch06_orph01_962e9ed7:

    d "Excuse me???"

translate english ch06_orph01_1fa397ab:

    d "**(Why is she so surprised??)**"

translate english ch06_orph01_9dcc0522:

    d "**(Does she know me?)**"

translate english ch06_orph01_94d4f0ad:

    d "Do you know me??"

translate english ch06_orph01_c8fe0810:

    unknown "Y-you........."

translate english ch06_orph01_0001a08f:

    d "??????"

translate english ch06_orph01_cf1835c0:

    unknown "At the beach the other day......"

translate english ch06_orph01_77673f80_1:

    d "........."

translate english ch06_orph01_4cd15d58_1:

    d "....."

translate english ch06_orph01_8663218b:

    d "Oh!!!!!!!!!!!!"

translate english ch06_orph01_0571313e:

    unknown "W-what are you doing here??"

translate english ch06_orph01_a72c2171:

    unknown "........"

translate english ch06_orph01_3ba9ba7f:

    unknown "Don't tell me......"

translate english ch06_orph01_a16ada69:

    unknown "Are you stalking me??!!"

translate english ch06_orph01_f7d77c9b:

    d "What are you talking about?"

translate english ch06_orph01_72cdce83:

    d "S-stalking??!!"

translate english ch06_orph01_06a06ad5:

    d "Of course not!!"

translate english ch06_orph01_d4c02fbd:

    unknown "Then what the hell are you doing here???!!"

translate english ch06_orph01_2c0c6d23:

    unknown "???"

translate english ch06_orph01_9f384fb4:

    d "Huh??"

translate english ch06_orph01_b3b7399b:

    d "Why am I here?? Well, that's..."

translate english ch06_orph01_0f3213bc:

    d "This is my..."

translate english ch06_orph01_b0196085:

    m "!!"

translate english ch06_orph01_07c3b1c9:

    m "Anna??"

translate english ch06_orph01_84a00748:

    m "When did you get here?"

translate english ch06_orph01_27891ddc:

    m "Why didn't you tell me you were coming?"

translate english ch06_orph01_a1319212:

    an "Hey, sis."

translate english ch06_orph01_9c9ff00d:

    d "!!!!!!!!!"

translate english ch06_orph01_4cd1eff2:

    d "**(Sis????!!!!!!!)**"

translate english ch06_orph01_a61aeaee:

    d "**(A...Anna?)**"

translate english ch06_orph01_fb4342b7:

    d "**(..........)**"

translate english ch06_orph01_e16367b5:

    d "**(I've heard that name a lot, haven't I?)**"

translate english ch06_orph01_0411797d:

    d "**(......)**"

translate english ch06_orph01_7ead4ecc:

    d "**(Ah.....It's right on the tip of my tongue.....)**"

translate english ch06_orph01_dc362724:

    an "Yeah, I was on my way to see Mom, so I thought I'd drop by."

translate english ch06_orph01_b8a771f1:

    an "How have you been?"

translate english ch06_orph01_15c10920:

    an "**(What's with the flowers??)**"

translate english ch06_orph01_cf13f697:

    an "**(...........)**"

translate english ch06_orph01_5d5c8709:

    an "**(Wait....)**"

translate english ch06_orph01_6e9c36cf:

    an "**(Did this kid actually bring Mary flowers??...)**"

translate english ch06_orph01_f5723982:

    m "Oh, I see."

translate english ch06_orph01_ad893dfa:

    d "......"

translate english ch06_orph01_caa71eda:

    m "Phew... I should visit Mom more often too, but I've been so busy lately..."

translate english ch06_orph01_474859ea:

    m "She must be so lonely living by herself since Dad passed away....."

translate english ch06_orph01_5f647add:

    m "So much for being a good daughter."

translate english ch06_orph01_8ff4cc0d:

    an "Can't be helped.."

translate english ch06_orph01_15915a1a:

    m "Oh, you've said hello to [d_name], right?"

translate english ch06_orph01_6423defe:

    an "!!!!!!!!!!!!!!!!!!"

translate english ch06_orph01_baf0c1bc:

    an "**([d_name]????!!)**"

translate english ch06_orph01_ec57f42c:

    an "Fuck!!!!"

translate english ch06_orph01_b0520d98:

    m "Watch your mouth, Anna..."

translate english ch06_orph01_3643568d:

    m "What's with the swearing?"

translate english ch06_orph01_bf917039:

    m "What's gotten into you all of a sudden?"

translate english ch06_orph01_f2feb65d:

    m "You look like you've seen a ghost."

translate english ch06_orph01_3262a12e:

    d "Um... well...."

translate english ch06_orph01_a7d6de3d:

    d "A...Anna....."

translate english ch06_orph01_e830d355:

    d "Haha... Hi, Anna...."

translate english ch06_orph01_377c1840:

    d "Well, this is awkward......"

translate english ch06_orph01_92034fa8:

    d "I...I didn't recognize you, haha."

translate english ch06_orph01_faa5f871:

    an "Yeah, haha. Of course."

translate english ch06_orph01_5436d495:

    an "I-it's been a while."

translate english ch06_orph01_3379a97c:

    an "What a small world, huh? Hahaha...."

translate english ch06_orph01_d333a5cc:

    m "Why are you two being so awkward?"

translate english ch06_orph01_f660dfe7:

    m "Has it just been too long?"

translate english ch06_orph01_7de1cac1:

    m "I guess that makes sense. It's been years, hasn't it?"

translate english ch06_orph01_78ca72ec:

    an "**(Oh my God...)**"

translate english ch06_orph01_b2b396d4:

    an "**(I think I'm gonna throw up......)**"

translate english ch06_orph01_62dcdadf:

    an "**(This is fucking insane..)**"

translate english ch06_orph01_95188f40:

    an "**(Is that really [d_name]???)**"

translate english ch06_orph01_144e3158:

    an "**(I fucked my sister's student??)**"

translate english ch06_orph01_1aefa8b4:

    m ".............."

translate english ch06_orph01_b4705763:

    m "Why are you just standing there?"

translate english ch06_orph01_8830176a:

    m "You're making me nervous. Sit down."

translate english ch06_orph01_3c4da9a4:

    m "Want some tea?"

translate english ch06_orph01_20c62553:

    an "No, I'm good."

translate english ch06_orph01_d4af2d84:

    an "I'm leaving soon anyway."

translate english ch06_orph01_13d07d28:

    an "Thanks."

translate english ch06_orph01_3a668ab5:

    an "Anyway, that's what happened."

translate english ch06_orph01_82e00240:

    an "Do you have any idea how ridiculous it sounded when I heard that?"

translate english ch06_orph01_0a73fea7:

    an "I just stood there, not knowing whether to laugh or get angry."

translate english ch06_orph01_77673f80_2:

    d "........."

translate english ch06_orph01_79b1bd3d:

    m "So what happened in the end?"

translate english ch06_orph01_886edf46:

    an "What do you think?"

translate english ch06_orph01_6d322e16:

    an "He slammed his bedroom door and shut himself in."

translate english ch06_orph01_5184ca5f:

    an "I was left standing in the living room for ages."

translate english ch06_orph01_a9c82d94:

    m "You have to be careful with things like that."

translate english ch06_orph01_74454ad0:

    m "Parents play an important role when kids start becoming sexually aware."

translate english ch06_orph01_44904924:

    an "He used to follow me around calling me Mommy all the time, and now I feel like I have to watch what I say to him."

translate english ch06_orph01_77a42f7d:

    an "I can't believe it."

translate english ch06_orph01_d5bf312d:

    an "I have no idea where he found that awful little brat."

translate english ch06_orph01_21145ea2:

    an "She's already acting like such a little slut at her age."

translate english ch06_orph01_bcdda25c:

    an "And she's developing so fast, too. Her ass and boobs are just..."

translate english ch06_orph01_4cd15d58_2:

    d "....."

translate english ch06_orph01_0a8f073e:

    m "What about Steve?"

translate english ch06_orph01_089c6677:

    an "That man always tells me to figure it out myself."

translate english ch06_orph01_c9a8503b:

    an "Every time he says that, I seriously want to punch him."

translate english ch06_orph01_77673f80_3:

    d "........."

translate english ch06_orph01_21c3d54c:

    m "Yeah. Well, what can you do? He's your son."

translate english ch06_orph01_dce9a148:

    m "That's why puberty is so difficult."

translate english ch06_orph01_31673f25:

    m "Yesterday a philosopher, today a poet, tomorrow a serial killer."

translate english ch06_orph01_2bf61f33:

    d "Hahaha."

translate english ch06_orph01_2753987d:

    an "Now that I'm going through it myself, it's really exhausting. Sigh...."

translate english ch06_orph01_ef7435de:

    m "Just don't get any ideas about dumping your kid here."

translate english ch06_orph01_8ad7a1dd:

    an "Hahaha. If things get bad enough, I just might."

translate english ch06_orph01_e6a78882:

    an "The director can raise him, right? I'll send child support."

translate english ch06_orph01_edbb7d05_3:

    d "........"

translate english ch06_orph01_bfb458d5:

    m "Ugh....."

translate english ch06_orph01_9ed8ed8f:

    m "I'm feeling a little chilly.."

translate english ch06_orph01_e9a58adc:

    an "Are you sick?"

translate english ch06_orph01_173e9e31:

    an "Did you catch a cold?"

translate english ch06_orph01_34cfb0fe:

    d "Are you okay, Mary?"

translate english ch06_orph01_5e3aec4e_3:

    d ".........."

translate english ch06_orph01_80e2c438:

    d "**(Maybe I shouldn't have come today..)**"

translate english ch06_orph01_942d1be6:

    d "**(I shouldn't have tried to surprise her without calling first..)**"

translate english ch06_orph01_abbec3c3:

    m "I was fine until this morning, but I suddenly started feeling like this after I got to work..."

translate english ch06_orph01_837819bd:

    d "Did you take any..."

translate english ch06_orph01_1eb0d9dc:

    an "Have you taken any medicine??"

translate english ch06_orph01_3d8e1bb5:

    d "**(Damn it, I was about to ask her that..)**"

translate english ch06_orph01_c5ea804c:

    m "I took some medicine, but the body aches are getting worse."

translate english ch06_orph01_0c612e0d:

    m "Maybe it's menopause. I seem to get sick all the time these days."

translate english ch06_orph01_aef31c4e:

    an "......."

translate english ch06_orph01_3ac57184:

    an "You really need to take care of yourself."

translate english ch06_orph01_807f6f00:

    an "I worry myself sick every time this happens to you."

translate english ch06_orph01_bf9f46f3:

    m "I know."

translate english ch06_orph01_aef31c4e_1:

    an "......."

translate english ch06_orph01_7eafd83d:

    an "Well, I'll stop by again sometime."

translate english ch06_orph01_bd9ea0b8:

    an "If you don't have anything important to do, lie down and rest."

translate english ch06_orph01_35270c59:

    an "You've been working late every day and pushing yourself so hard since becoming the director. Looks like it's finally catching up with you."

translate english ch06_orph01_2b14ee3e:

    an "Why don't you lie down for a while if there's nothing urgent?"

translate english ch06_orph01_fc4a546e:

    m "I think I will."

translate english ch06_orph01_9cbc9692:

    m "Anyway, make sure you visit Mom more often, okay?"

translate english ch06_orph01_13f94525:

    m "And take the kids to see her more often, too."

translate english ch06_orph01_7a84ace5:

    an "Okay."

translate english ch06_orph01_b5121c41:

    an "I'll visit more often, haha."

translate english ch06_orph01_d8561f57:

    an "Take care, [d_name]."

translate english ch06_orph01_68f2e820:

    an "See you again sometime."

translate english ch06_orph01_29ad72e7:

    d "Yeah, haha. Sure."

translate english ch06_orph01_f22a5a9c:

    d "See you, Anna....."

translate english ch06_orph01_5aa84542:

    d "It was nice seeing you."

translate english ch06_orph01_b866ed0f:

    an "Yeah, take care."

translate english ch06_orph01_bb14642f:

    an "And make sure you look after my sister, okay?"

translate english ch06_orph01_ab6ff56d:

    d "Of course, haha."

translate english ch06_orph01_6a62e484:

    an "**(Oh, fuck. My heart's pounding.)**"

translate english ch06_orph01_a4ae7370:

    an "**(This isn't going to cause any trouble, is it?....)**"

translate english ch06_orph01_b30c2c6f:

    an "**(Unbelievable... Just fucking unbelievable.)**"

translate english ch06_orph01_6ff74a01:

    an "**(I can't believe that was [d_name]....)**"

translate english ch06_orph01_96dc09af:

    d "**(Man, it really is a small town....)**"

translate english ch06_orph01_f3eca822:

    d "**(I knew she looked familiar back then.....)**"

translate english ch06_orph01_76995792:

    d "**(Anna obviously won't tell anyone what happened, right?.....)**"

translate english ch06_orph01_12499608:

    an "**(He's not going to tell anyone, is he??)**"

translate english ch06_orph01_82737a70:

    an "**(Ugh.... I'm a little worried..)**"

translate english ch06_orph01_5cbbf9b7:

    an "**(He seems like the type to run his mouth... Ah, fuck....)**"

translate english ch06_orph01_31736db3:

    m "**(...............)**"

translate english ch06_orph01_d817ba9c:

    m "**(What’s with that weird vibe...)**"

translate english ch06_orph01_6ea6e048:

    m "**(They've been acting so awkward this whole time..)**"

translate english ch06_orph02_18bb4bb5:

    m "Ugh..... I can't keep going like this.."

translate english ch06_orph02_4b97838f:

    m "I think I need to lie down for a while."

translate english ch06_orph02_1d2e482c:

    d "A-are you okay??!!"

translate english ch06_orph02_ccc6cd33:

    m "Everything's spinning.."

translate english ch06_orph02_9ee1123a:

    m "Maybe my blood pressure's low..."

translate english ch06_orph02_c2edfce1:

    d "Are you sure you're okay?"

translate english ch06_orph02_9975b7ac:

    d "Do you want me to take you to the hospital?"

translate english ch06_orph02_c522cf48:

    m "No, I'll be fine if I lie down for a bit."

translate english ch06_orph02_802c9d64:

    m "This happens sometimes."

translate english ch06_orph02_77673f80:

    d "........."

translate english ch06_orph02_95cb52f9:

    n "Mary stepped into the lounge attached to her office."

translate english ch06_orph02_22a56840:

    n "She wanted to get some uninterrupted rest so she could get back to work, but..."

translate english ch06_orph02_3445cfb1:

    n "She couldn't bring herself to tell [d_name] to leave."

translate english ch06_orph02_f492f8e6:

    n "[d_name] was worried about Mary, but he didn't leave her office either."

translate english ch06_orph02_337c0702:

    m "Phew......"

translate english ch06_orph02_58bdad9e:

    m "Ugh.."

translate english ch06_orph02_8782036a:

    m "I'm sorry, especially after you came all this way."

translate english ch06_orph02_77673f80_1:

    d "........."

translate english ch06_orph02_9d7de741:

    d "It's okay, Mary."

translate english ch06_orph02_0f38b637:

    m "I'm really not feeling well today."

translate english ch06_orph02_a0d72c1a:

    m "I keep taking it out on you."

translate english ch06_orph02_1c999b93:

    d "No, it's okay."

translate english ch06_orph02_4036c322:

    d "Just getting to see you is enough for me."

translate english ch06_orph02_77673f80_2:

    d "........."

translate english ch06_orph02_043932fb:

    d "But are you sure you don't need to go to the hospital?"

translate english ch06_orph02_f1bff77c:

    m "........"

translate english ch06_orph02_f30fbb6b:

    m "Maybe the medicine isn't working. My body aches are getting worse."

translate english ch06_orph02_4866a6dc:

    m "Getting sick in the middle of summer, seriously.."

translate english ch06_orph02_ef42e29f:

    m "I hope it's not COVID, haha."

translate english ch06_orph02_7fcccb31:

    d "**(Damn it..)**"

translate english ch06_orph02_9e09cdad:

    d "**(What the hell did I do to Mary when she's feeling so sick...)**"

translate english ch06_orph02_77673f80_3:

    d "........."

translate english ch06_orph02_c5d1ac69:

    d "**(I practically forced it into her mouth today....)**"

translate english ch06_orph02_7d99c443:

    m "Ugh......"

translate english ch06_orph02_77673f80_4:

    d "........."

translate english ch06_orph02_9508213d:

    d "**(Damn it, I feel terrible about this..)**"

translate english ch06_orph02_fac8215b:

    d "............"

translate english ch06_orph02_cd9a414b:

    d "**(Why did I even come here today?......)**"

translate english ch06_orph02_56b600f4:

    d "**(Was it because I wanted to see Mary, or just to satisfy my own lust?....)**"

translate english ch06_orph02_edbb7d05:

    d "........"

translate english ch06_orph02_579b6329:

    d "**(Is that any way for a gentleman to behave??!!)**"

translate english ch06_orph02_93a6c696:

    d "**(She's not some toy for me to use.......)**"

translate english ch06_orph02_51ffc6ac:

    d "**(I'm such a pathetic asshole...)**"

translate english ch06_orph02_41f4dfb8:

    n "A brief silence fell between them."

translate english ch06_orph02_96641d23:

    n "Mary just lay there without saying a word, and it made [d_name] uncomfortable."

translate english ch06_orph02_9b2f8a38:

    n "The only sound in the quiet room was Mary's breathing."

translate english ch06_orph02_ef6d92ed:

    m "........."

translate english ch06_orph02_c6c1eee3:

    m "[d_name]."

translate english ch06_orph02_8096b08a:

    d "Yes?"

translate english ch06_orph02_ef6d92ed_1:

    m "........."

translate english ch06_orph02_fe3845e8:

    m "What on earth am I doing?"

translate english ch06_orph02_fb0fcdbb:

    d "What do you mean?..."

translate english ch06_orph02_edbb7d05_1:

    d "........"

translate english ch06_orph02_a611deec:

    d "You haven't done anything wrong, Mary...."

translate english ch06_orph02_ef6d92ed_2:

    m "........."

translate english ch06_orph02_66cf1951:

    m "No, that's not what I mean.."

translate english ch06_orph02_43076c7b:

    m "I'm talking about you and me, [d_name]."

translate english ch06_orph02_a555757b:

    m "Do you even realize what we're doing?"

translate english ch06_orph02_5e3aec4e:

    d ".........."

translate english ch06_orph02_aeddd4d4:

    m "Talk to me like you did at the park the other day...."

translate english ch06_orph02_756bc1f9:

    m "Sometimes you're more mature than I am."

translate english ch06_orph02_4cd15d58:

    d "....."

translate english ch06_orph02_7d8606f2:

    m "Tell me what you think is going on between us this time.."

translate english ch06_orph02_57974387:

    d "You mean me being here in your room right now?"

translate english ch06_orph02_454742b6:

    m "............"

translate english ch06_orph02_82cea43e:

    m "You know what I'm talking about..."

translate english ch06_orph02_f3910eaf:

    m "I was your..."

translate english ch06_orph02_db506594:

    m "No, we did those things to each other with our mouths..."

translate english ch06_orph02_c5ea5789:

    m "Oh my God......"

translate english ch06_orph02_fc70c2be:

    m "I was using the bathroom, for God's sake.."

translate english ch06_orph02_203cc60b:

    d "......."

translate english ch06_orph02_7c8e4f5d:

    d "W-well, that...."

translate english ch06_orph02_d3595bc0:

    d "I don't really know either....."

translate english ch06_orph02_71159fc3:

    m "......."

translate english ch06_orph02_fc83bb85:

    d "It's just......"

translate english ch06_orph02_c7f6093c:

    d "One thing led to another....."

translate english ch06_orph02_203cc60b_1:

    d "......."

translate english ch06_orph02_5775bedf:

    d "I just love you, Mary, and I want to see you."

translate english ch06_orph02_8ff44d49:

    m "The way you're acting right now isn't love."

translate english ch06_orph02_ef6d92ed_3:

    m "........."

translate english ch06_orph02_efb963f2:

    m "Do you remember the promise you made me?"

translate english ch06_orph02_beb89374:

    d "Of course."

translate english ch06_orph02_7f3d23aa:

    d "Of course I remember."

translate english ch06_orph02_ef6d92ed_4:

    m "........."

translate english ch06_orph02_18a75e20:

    m "But you're lying to me right now."

translate english ch06_orph02_a291011d:

    m "I'm disappointed in you.."

translate english ch06_orph02_203cc60b_2:

    d "......."

translate english ch06_orph02_7f716a94:

    d "No."

translate english ch06_orph02_882dee90:

    d "That's not true."

translate english ch06_orph02_a07d33ba:

    d "I really came here because I love you and wanted to see you."

translate english ch06_orph02_39ca8582:

    d "I told you before."

translate english ch06_orph02_36f80475:

    d "You're all I think about all day, Mary."

translate english ch06_orph02_203cc60b_3:

    d "......."

translate english ch06_orph02_04cca888:

    d "Even when I'm sleeping."

translate english ch06_orph02_1a23c2c5:

    d "When I'm walking..."

translate english ch06_orph02_7411e604:

    d "When I'm taking a shower...."

translate english ch06_orph02_698e5b0a:

    d "Even when I'm masturbating...."

translate english ch06_orph02_f1bff77c_1:

    m "........"

translate english ch06_orph02_ef6d92ed_5:

    m "........."

translate english ch06_orph02_933fef00:

    m "When you masturbate, how do you imagine me?..."

translate english ch06_orph02_71530413:

    m "Do I look the way I normally do?"

translate english ch06_orph02_3e0b909d:

    d "Well....."

translate english ch06_orph02_9dc1d8b4:

    d "Haha, it's different every time.."

translate english ch06_orph02_f1bff77c_2:

    m "........"

translate english ch06_orph02_e53fb6a3:

    m "Just tell me."

translate english ch06_orph02_ad893dfa:

    d "......"

translate english ch06_orph02_e5abf4f9:

    d "You want all the dirty details?"

translate english ch06_orph02_deb06b8c:

    m "Yes."

translate english ch06_orph02_8e4a4249:

    m "Exactly how you imagine it."

translate english ch06_orph02_3e47e4e3:

    d "You washing my body..."

translate english ch06_orph02_4db34dd4:

    d "You calling me honey."

translate english ch06_orph02_fbe3002c:

    d "You sucking my cock all around the house.."

translate english ch06_orph02_ef6d92ed_6:

    m "........."

translate english ch06_orph02_41a1976b:

    d "You bending over and begging me to fuck you..."

translate english ch06_orph02_ef6d92ed_7:

    m "........."

translate english ch06_orph02_93aebcb2:

    d "You carrying my child."

translate english ch06_orph02_71159fc3_1:

    m "......."

translate english ch06_orph02_f4d75113:

    m "Oh my God, [d_name]....."

translate english ch06_orph02_d836baa2:

    m "That's just crazy....."

translate english ch06_orph02_88fb3d8b:

    m "I never even imagined that.."

translate english ch06_orph02_6c9560d5:

    d "You told me to be explicit...."

translate english ch06_orph02_782af1f8:

    m "No......"

translate english ch06_orph02_791090e8:

    m "I'm not scolding you."

translate english ch06_orph02_9a77c570:

    m "It's just your imagination, after all..."

translate english ch06_orph02_11d86949:

    m "Sorry, I'm going to take my skirt off."

translate english ch06_orph02_aeca342a:

    m "It's too tight and uncomfortable."

translate english ch06_orph02_e5c36b54:

    d "..........."

translate english ch06_orph02_e2c57224:

    m "Ugh, I'm so dizzy.."

translate english ch06_orph02_a8c325c0:

    m "I do feel a little better lying down, though."

translate english ch06_orph02_77673f80_5:

    d "........."

translate english ch06_orph02_3dbf4545:

    d "**(What's she doing??)**"

translate english ch06_orph02_c00df9cb:

    d "**(She's lying there looking so vulnerable, and she's the one lecturing me??)**"

translate english ch06_orph02_6058ecae:

    d "**(.........)**"

translate english ch06_orph02_ab5dc2a0:

    d "**(Oh my God, look at that ass.....)**"

translate english ch06_orph02_4cafbe0a:

    d "**(Is she begging me to fuck her??......)**"

translate english ch06_orph02_d75f5eba:

    d "Um.........."

translate english ch06_orph02_aaebfbdf:

    d "Can I ask you something, Mary?"

translate english ch06_orph02_92efc14c:

    m "Of course."

translate english ch06_orph02_16e5d21c:

    m "What do you want to know?"

translate english strings:
    old "메리는 몇 명과 잤어요?"
    new "How many people have you slept with, Mary?"

translate english ch06_orph02_92f21ed5:

    n "What should I do?"

translate english ch06_orph02_9d0cadb3:

    d "How many people have you slept with, Mary?"

translate english ch06_orph02_6e57a23f:

    d "I mean, in your entire life..."

translate english ch06_orph02_1aefa8b4:

    m ".............."

translate english ch06_orph02_e5001983:

    m "Oh my God, [d_name]."

translate english ch06_orph02_4968020e:

    m "Why would you ask me something like that..."

translate english ch06_orph02_061db91e:

    d "I'm just curious.."

translate english ch06_orph02_10c98191:

    m "I don't know."

translate english ch06_orph02_bb98cf74:

    d "Wait, really?"

translate english ch06_orph02_6eeddd1a:

    d "Are you going to break our rule?"

translate english ch06_orph02_1aefa8b4_1:

    m ".............."

translate english ch06_orph02_5d680c33:

    m "How many do you think?"

translate english ch06_orph02_2df22a6d:

    m "How many people do you think I've slept with?"

translate english ch06_orph02_3e0b909d_1:

    d "Hmm....."

translate english strings:
    old "1명?"
    new "One?"

translate english strings:
    old "5명?"
    new "Five?"

translate english strings:
    old "10명?"
    new "Ten?"

translate english strings:
    old "20명?"
    new "Twenty?"

translate english strings:
    old "셀수없을 만큼 많이."
    new "Too many to count."

translate english ch06_orph02_92f21ed5_1:

    n "What should I do?"

translate english ch06_orph02_48a41478:

    d "One?"

translate english ch06_orph02_4ac75c8c:

    d "Five?"

translate english ch06_orph02_a4378b1a:

    d "Ten?"

translate english ch06_orph02_b92a7baf:

    d "Twenty?"

translate english ch06_orph02_eb6839dc:

    d "Too many to count."

translate english ch06_orph02_1aefa8b4_2:

    m ".............."

translate english ch06_orph02_33c9211e:

    d "Am I right?"

translate english ch06_orph02_2e790b33:

    m "Oh, honestly......"

translate english ch06_orph02_6c54075f:

    m "That's right."

translate english ch06_orph02_c47841bd:

    m "I think it's around a hundred?"

translate english ch06_orph02_6a2bc055:

    m "No, wait."

translate english ch06_orph02_11d6e2d9:

    m "More like two hundred."

translate english ch06_orph02_7d7a3cae:

    d "!!!!!!!!"

translate english ch06_orph02_efb1c2f8:

    d "Seriously??!!!!"

translate english ch06_orph02_1aefa8b4_3:

    m ".............."

translate english ch06_orph02_40d2e8aa:

    m "Yep, you guessed exactly right."

translate english ch06_orph02_78c2c58b:

    d "Hah, so that's how you're going to dodge the question?"

translate english ch06_orph02_1aefa8b4_4:

    m ".............."

translate english ch06_orph02_15d463a5:

    d "Can't you just tell me?"

translate english ch06_orph02_1aefa8b4_5:

    m ".............."

translate english ch06_orph02_5167c111:

    m "I don't know. I can't remember."

translate english ch06_orph02_3c1f4660:

    m "Who keeps track of all that at my age...."

translate english ch06_orph02_743b0f0a:

    d "You just don't want to tell me, right?"

translate english ch06_orph02_f1bff77c_3:

    m "........"

translate english ch06_orph02_f6c37117:

    d "Right?"

translate english ch06_orph02_dc485487:

    d "You're worried I won't like you anymore if the number's too high, aren't you?"

translate english ch06_orph02_f1bff77c_4:

    m "........"

translate english ch06_orph02_547c0dd8:

    d "It's okay, Mary."

translate english ch06_orph02_f1bff77c_5:

    m "........"

translate english ch06_orph02_066f5a59:

    m "What are you talking about?"

translate english ch06_orph02_bbb7d93a:

    d "I love you, Mary, no matter what kind of past you have."

translate english ch06_orph02_885cb622:

    m "What?"

translate english ch06_orph02_e42c4c36:

    m "What business is it of yours how many people I've slept with?"

translate english ch06_orph02_6be65412:

    m "......"

translate english ch06_orph02_2e26ee1a:

    m "What, are you my husband or something..."

translate english strings:
    old "조용히 바지를 벗는다."
    new "Quietly take off my pants."

translate english ch06_orph02_92f21ed5_2:

    n "What should I do?"

translate english ch06_orph02_f20756b5:

    n "Despite his growing arousal, he quietly slipped off his pants, trying his best not to let Mary notice."

translate english ch06_orph02_f935a54e:

    n "Then he quietly climbed onto the bed."

translate english ch06_orph02_e678d202:

    m "What are you doing?"

translate english ch06_orph02_b0196085:

    m "!!"

translate english ch06_orph02_e5001983_1:

    m "Oh my God, [d_name]."

translate english ch06_orph02_1a30e1e4:

    m "You can't do this."

translate english ch06_orph02_55861c5f:

    m "Get off the bed. Now."

translate english ch06_orph02_08ae6ee6:

    d "I love you, Mary."

translate english ch06_orph02_edbb7d05_2:

    d "........"

translate english ch06_orph02_6d57ab1c:

    d "You're the person I care about most in the whole world."

translate english ch06_orph02_ab0c29ff:

    d "You know that, don't you?"

translate english ch06_orph02_5aebff17:

    m ".........."

translate english ch06_orph02_62488362:

    m "I know..."

translate english ch06_orph02_9d72a9e8:

    m "I love you too."

translate english ch06_orph02_91cef23b:

    m "But you've got no manners, young man......"

translate english ch06_orph02_0a8f979c:

    m "Do you have to keep shoving your dick at me every time you see me? Huh?"

translate english ch06_orph02_18548549:

    m "..........."

translate english ch06_orph02_99045f73:

    m "Am I your girlfriend? Or your wife?"

translate english ch06_orph02_7848c8d7:

    m "Did you act like that with your girlfriend at college, too?"

translate english ch06_orph02_77673f80_6:

    d "........."

translate english ch06_orph02_81565adb:

    d "I'm sorry about that."

translate english ch06_orph02_56bf299a:

    d "...."

translate english ch06_orph02_eecdb3e4:

    d "All I can think about is sex......"

translate english ch06_orph02_a368a461:

    d "All I can think about is having sex with you, Mary...."

translate english ch06_orph02_c48347c8:

    m "Oh my God, sweetheart...."

translate english ch06_orph02_5aebff17_1:

    m ".........."

translate english ch06_orph02_51597776:

    m "Get out of here before someone comes in."

translate english ch06_orph02_787a7af3:

    m "We'll be in serious trouble if someone catches us like this."

translate english ch06_orph02_e1b0c622:

    m "How can you be so casual about all this...."

translate english ch06_orph02_edbb7d05_3:

    d "........"

translate english ch06_orph02_9a65566e:

    d "I feel so comfortable like this. Just let me stay a little longer."

translate english ch06_orph02_12313aa9:

    d "Just five minutes...."

translate english ch06_orph02_3f1ed7ab:

    m "Sigh....."

translate english ch06_orph02_9f175048:

    m "Please, [d_name]....."

translate english ch06_orph02_4cd15d58_1:

    d "....."

translate english ch06_orph02_720f6732:

    d "I've always missed the warmth of your body, Mary."

translate english ch06_orph02_ef6d92ed_8:

    m "........."

translate english ch06_orph02_39f9fcd0:

    d "Even after I left the orphanage and went to live with Amanda......"

translate english ch06_orph02_ddd6e168:

    d "I thought about you every single day...."

translate english ch06_orph02_71159fc3_2:

    m "......."

translate english ch06_orph02_b21c75a5:

    d "The warmth of your hand when we held hands.."

translate english ch06_orph02_1ea3967e:

    d "The warmth of your body when we hugged..."

translate english ch06_orph02_c442b591:

    d "Your wonderful scent....."

translate english ch06_orph02_c259f6e6:

    d "Your soft, gentle voice.."

translate english ch06_orph02_edbb7d05_4:

    d "........"

translate english ch06_orph02_03f0070d:

    d "Don't you like the warmth of my body, too, Mary?........"

translate english ch06_orph02_4cd15d58_2:

    d "....."

translate english ch06_orph02_7aff8a4f:

    m "Sigh........"

translate english ch06_orph02_dbb10141:

    n "Mary knew his words were a mixture of truth and lies."

translate english ch06_orph02_b8c5ba33:

    n "But she didn't mind [d_name]'s sweet talk."

translate english ch06_orph02_a5907675:

    n "For years, her husband hadn't whispered a single sweet word to her or made any effort to make her feel loved and cherished as a woman."

translate english ch06_orph02_5a02cfcf:

    m "Just five minutes, honey.."

translate english ch06_orph02_bbc6b3b3:

    m "I need to get some sleep before I go back to work."

translate english ch06_orph02_8c097a17:

    d "Okay."

translate english ch06_orph02_7eaae2bf:

    d "Five minutes.."

translate english ch06_orph02_97a069c3:

    m "What?!!"

translate english ch06_orph02_8096b08a_1:

    d "Huh?"

translate english ch06_orph02_9c27f270:

    m "When did you even take your pants off..... Honestly...."

translate english ch06_orph02_55d31b26:

    d "Haha."

translate english ch06_orph02_c326cbd5:

    d "I wished really hard, and my pants disappeared, haha."

translate english ch06_orph02_b84bfe3b:

    m "What kind of nonsense is that? Haha."

translate english ch06_orph02_e300c074:

    m "You wished really hard, and your pants disappeared......"

translate english ch06_orph02_64ede9fc:

    m "Then can you make these body aches disappear, too? Haha."

translate english ch06_orph02_f390f6f8:

    m "Or better yet, can you make me twenty again?"

translate english ch06_orph02_70dca85e:

    d "You're more beautiful than any other woman, Mary."

translate english ch06_orph02_178f2c0a:

    d "The way you look right now is the most beautiful thing in the world to me."

translate english ch06_orph02_17f8f5f2:

    m "Mmm....."

translate english ch06_orph02_18548549_1:

    m "..........."

translate english ch06_orph02_7941a72e:

    m "Oh my God, what am I doing...."

translate english ch06_orph02_c3aad814:

    m "We shouldn't be doing this....."

translate english ch06_orph02_86bc29b6:

    d "Why shouldn't we??"

translate english ch06_orph02_71159fc3_3:

    m "......."

translate english ch06_orph02_1dace6c3:

    m "Since when did we start acting like this......"

translate english ch06_orph02_0fce31c6:

    d "Don't you like being with me?"

translate english ch06_orph02_18548549_2:

    m "..........."

translate english ch06_orph02_0766a0b3:

    m "No, I like being with you, too."

translate english ch06_orph02_cd3813c8:

    d "Then why....."

translate english ch06_orph02_18548549_3:

    m "..........."

translate english ch06_orph02_74d06332:

    m "But you know as well as I do..."

translate english ch06_orph02_de9056fc:

    m "What we're doing could put both of us in danger....."

translate english ch06_orph02_9a3102d3:

    d "No, that's not true."

translate english ch06_orph02_edbb7d05_5:

    d "........"

translate english ch06_orph02_aa9c2ad2:

    d "I just want you to enjoy being with me as much as I enjoy being with you....."

translate english ch06_orph02_2dc88746:

    d "I want you to see me as a man, Mary...."

translate english ch06_orph02_cdc36619:

    d "A man who can love you..."

translate english ch06_orph02_b0196085_1:

    m "!!"

translate english ch06_orph02_855fd1c9:

    m "Don't, honey...."

translate english ch06_orph02_f3f9cb25:

    d "Why?...."

translate english ch06_orph02_0f8ef6fb:

    d "Don't you like it when I do this?"

translate english ch06_orph02_f1bff77c_6:

    m "........"

translate english ch06_orph02_0ea36888:

    d "We've already done more than this...."

translate english ch06_orph02_b13c4141:

    d "You went down on me...."

translate english ch06_orph02_1bce06d8:

    d "And I licked your pussy..."

translate english ch06_orph02_c3c6bb86:

    m "That's different...."

translate english ch06_orph02_77673f80_7:

    d "........."

translate english ch06_orph02_327d0ed9:

    d "No, how is that different? Huh?"

translate english ch06_orph02_41bad57f:

    d "I really don't understand what you're saying, Mary..."

translate english ch06_orph02_1b73ca64:

    m "How do I put this... Those things just happened.."

translate english ch06_orph02_ad893dfa_1:

    d "......"

translate english ch06_orph02_894fcb4a:

    d "What do you mean by that?"

translate english ch06_orph02_20a9d298:

    m "Sigh... It's hard to explain."

translate english ch06_orph02_f1bff77c_7:

    m "........"

translate english ch06_orph02_ca3d6bb0:

    m "You know, they just happened."

translate english ch06_orph02_f75221a5:

    m "You begged me so much that one thing just led to another."

translate english ch06_orph02_1d8e97ce:

    m "Do you understand what I'm saying?"

translate english ch06_orph02_e2abba31:

    m "I just felt sorry for you and gave in to what you asked."

translate english ch06_orph02_a8f0e61d:

    d "You mean it was like a one-night stand or something?"

translate english ch06_orph02_e9ad214a:

    m "Oh my God........."

translate english ch06_orph02_77673f80_8:

    d "........."

translate english ch06_orph02_f2c0a460:

    d "I just want to make you happy, Mary."

translate english ch06_orph02_01325681:

    m "No.."

translate english ch06_orph02_7c05cae2:

    m "....."

translate english ch06_orph02_2c7538f5:

    m "My life is already happy enough as it is."

translate english ch06_orph02_d3997eee:

    d "Really?"

translate english ch06_orph02_f1bff77c_8:

    m "........"

translate english ch06_orph02_f358b65e:

    m "Honey..."

translate english ch06_orph02_f1bff77c_9:

    m "........"

translate english ch06_orph02_566c25f1:

    m "Don't talk about my family life."

translate english ch06_orph02_ab760e34:

    m "That's a line you must never cross."

translate english ch06_orph02_9800febf:

    n "He gently stroked Mary's upper arm."

translate english ch06_orph02_7f723870:

    n "Somehow, that simple gesture made Mary feel more loved than even a passionate kiss would have."

translate english ch06_orph02_29a4f6ab:

    m "!!!"

translate english strings:
    old "메리의 팬티를 벗긴다."
    new "Take off Mary's panties."

translate english ch06_orph02_92f21ed5_3:

    n "What should I do?"

translate english ch06_orph02_6427fa11:

    m "Hey!"

translate english ch06_orph02_52aee421:

    m "Don't make me angry, young man!!"

translate english ch06_orph02_70449bc3:

    m "We'll be in serious trouble if you do this here!!"

translate english ch06_orph02_7087858c:

    m "Why do you keep doing this when I've told you to stop?"

translate english ch06_orph02_7d310f90:

    d "I love you, Mary.."

translate english ch06_orph02_55202c59:

    d "I love you!!"

translate english ch06_orph02_9e81208c:

    m "!!!!!!!!!"

translate english ch06_orph02_0e9ef287:

    d "Being with you drives me crazy, Mary...."

translate english ch06_orph02_41df581a:

    d "Please accept my love!!"

translate english ch06_orph02_3c0f7ae4:

    m "What are you doing???!!"

translate english ch06_orph02_14033452:

    m "!!!!!!!!!!!!!!!!"

translate english ch06_orph02_23439267:

    m "Oh my God...."

translate english ch06_orph02_7c05cae2_1:

    m "....."

translate english ch06_orph02_ce535c0e:

    m "Are you really the [d_name] I know?"

translate english ch06_orph02_2cf4a606:

    m "Please, give me back my [d_name]..."

translate english ch06_orph02_7cd0e0a6:

    d "I am the [d_name] you've always known, Mary."

translate english ch06_orph02_7f41d5b1:

    d "It's just......"

translate english ch06_orph02_ab3438c4:

    d "I just want you to be mine, more than ever."

translate english ch06_orph02_23439267_1:

    m "Oh my God...."

translate english ch06_orph02_7c05cae2_2:

    m "....."

translate english ch06_orph02_752d7f8a:

    m "So what are you going to do now?........"

translate english ch06_orph02_7e2800fc:

    m "Are you really going to ruin our relationship today?"

translate english ch06_orph02_2e81ba0a:

    m "Mmm....."

translate english ch06_orph02_bacd3e3c:

    m "I-it tickles....."

translate english ch06_orph02_9a4e3067:

    n "As his mouth touched her thigh, goosebumps spread across her lower body."

translate english ch06_orph02_340b4bcc:

    n "She was sinking deeper and deeper into the trap [d_name] had drawn her into."

translate english ch06_orph02_329da3d9:

    m "We shouldn't be doing this...."

translate english ch06_orph02_199d751c:

    d "Don't say that, Mary."

translate english ch06_orph02_bd6b40f2:

    d "But it's okay for you to suck my cock??"

translate english ch06_orph02_ef6d92ed_9:

    m "........."

translate english ch06_orph02_381687a0:

    d "You did that for me, so now it's my turn."

translate english ch06_orph02_91d1f991:

    d "Just lie back and enjoy it."

translate english ch06_orph02_2f4a80fd:

    d "I'll make you feel good."

translate english ch06_orph02_17f8f5f2_1:

    m "Mmm....."

translate english ch06_orph02_daaee433:

    d "I love hearing your soft moans, Mary....."

translate english ch06_orph02_c18d0e6a:

    m "I-it tickles..."

translate english ch06_orph02_b6de913d:

    d "Yes, just like that..."

translate english ch06_orph02_fec7d259:

    d "Just enjoy the feeling."

translate english ch06_orph02_2e81ba0a_1:

    m "Mmm....."

translate english ch06_orph02_a222e0f5:

    m "Haaah...."

translate english ch06_orph02_cf911d32:

    m "I'm embarrassed.."

translate english ch06_orph02_093dd945:

    d "It's okay."

translate english ch06_orph02_bdaca365:

    d "Just relax and focus on what I'm doing to you.."

translate english ch06_orph02_abb8cda5:

    d "For this moment, I'm your lover, Mary."

translate english ch06_orph02_87b3ebd2:

    n "Before she knew it, she was doing as [d_name] told her."

translate english ch06_orph02_8e922572:

    n "It wasn't because he had any authority over her, but because of the pleasure she was feeling."

translate english ch06_orph02_67687dc6:

    d "Your pussy, Mary...."

translate english ch06_orph02_1ccd5e40:

    d "It's so smooth and clean."

translate english ch06_orph02_f721e84a:

    m "...."

translate english ch06_orph02_39d2be51:

    d "Do you get waxed regularly like Amanda does?"

translate english ch06_orph02_f1bff77c_10:

    m "........"

translate english ch06_orph02_81baeda9:

    m "A-Amanda?......"

translate english strings:
    old "메리의 항문을 빤다."
    new "Lick Mary's asshole."

translate english ch06_orph02_92f21ed5_4:

    n "What should I do?"

translate english ch06_orph02_14033452_1:

    m "!!!!!!!!!!!!!!!!"

translate english ch06_orph02_274c9b76:

    m "Aah!!!!!"

translate english ch06_orph02_cd9fc2a5:

    m "Ngh!!"

translate english ch06_orph02_e4f52bf1:

    m "Mmm........."

translate english ch06_orph02_78afb8dc:

    m "D-don't..."

translate english ch06_orph02_7b5e64c1:

    m "Aah.............."

translate english ch06_orph02_c80bcc95:

    d "Mary...."

translate english ch06_orph02_380e2f55:

    d "Do you know what I was thinking about on the bus ride home from college?..."

translate english ch06_orph02_18548549_4:

    m "..........."

translate english ch06_orph02_e7169baa:

    d "This exact moment....."

translate english ch06_orph02_645a387b:

    d "Me eating your ass like this."

translate english ch06_orph02_ef6d92ed_10:

    m "........."

translate english ch06_orph02_8e0a29e3:

    m "D-don't say things like that.."

translate english ch06_orph02_69785308:

    d "Did you ever imagine something like this would happen, Mary?"

translate english ch06_orph02_ef6d92ed_11:

    m "........."

translate english ch06_orph02_98942d7c:

    d "I'm so excited, my heart feels like it's about to burst...."

translate english ch06_orph02_e527daaa:

    d "I can't believe my fantasy is coming true....."

translate english ch06_orph02_504075ee:

    m "Ah.................."

translate english ch06_orph02_1c471b70:

    m "Aah......."

translate english ch06_orph02_56b7adff:

    d "Lift your ass a little higher, like this."

translate english ch06_orph02_29a4f6ab_1:

    m "!!!"

translate english ch06_orph02_5aebff17_2:

    m ".........."

translate english ch06_orph02_db7d4585:

    d "Damn it....."

translate english ch06_orph02_d3eafcb4:

    d "Your pussy and asshole are so beautiful, Mary..."

translate english ch06_orph02_54311315:

    m "Haaah......."

translate english ch06_orph02_d54499c6:

    m "Ngh!!"

translate english ch06_orph02_5e3aec4e_1:

    d ".........."

translate english ch06_orph02_29e77425:

    d "You're so wet right now, Mary...."

translate english ch06_orph02_2aa513be:

    d "I'm the one making you this wet.."

translate english ch06_orph02_8e0a29e3_1:

    m "D-don't say things like that.."

translate english ch06_orph02_54311315_1:

    m "Haaah......."

translate english ch06_orph02_24a7532b:

    m "I-it's just a natural bodily reaction....."

translate english ch06_orph02_353eeb8d:

    m "It's not because I'm enjoying this..."

translate english ch06_orph02_cd9fc2a5_1:

    m "Ngh!!"

translate english ch06_orph02_851020cf:

    m "This shouldn't be happening..."

translate english ch06_orph02_30863f0a:

    m "Stop it, honey..."

translate english ch06_orph02_26cf6766:

    m "!!!!!!!!!!!!"

translate english ch06_orph02_c2136cb9:

    m "Don't do that...."

translate english ch06_orph02_9ee4e63d:

    d "Ah... Mary....."

translate english ch06_orph02_64ad80fd:

    d "My teacher..."

translate english ch06_orph02_b9dd5273:

    n "As he spread Mary's pussy open, she could feel the air against her most intimate parts."

translate english ch06_orph02_6c3fa633:

    n "She was becoming overwhelmed by sexual arousal."

translate english ch06_orph02_712ddab9:

    n "Being handled however he pleased by a man so much younger than her was both thrilling and humiliating."

translate english ch06_orph02_565fc8e0:

    n "She tried to figure out why she had ended up doing these things with [d_name], but couldn't find an answer."

translate english strings:
    old "나의 팬티를 벗는다."
    new "Take off my underwear."

translate english ch06_orph02_92f21ed5_5:

    n "What should I do?"

translate english ch06_orph02_198f9820:

    n "Keeping his eyes fixed on her pussy, he carefully slipped off his underwear."

translate english ch06_orph02_e475a480:

    d "!!!!!!!!!!!!!!"

translate english ch06_orph02_2da910cb:

    m "Hi, honey."

translate english ch06_orph02_6be65412_1:

    m "......"

translate english ch06_orph02_8263be53:

    m "No, I'm in my office."

translate english ch06_orph02_f1bff77c_11:

    m "........"

translate english ch06_orph02_a6b1d804:

    m "Yeah. I'm sitting at my computer."

translate english ch06_orph02_4d282429:

    m "Okay, give me a second."

translate english ch06_orph02_b2fbb82a:

    m "**(Oh my God....)**"

translate english ch06_orph02_d3df631f:

    m "**(I almost had a heart attack......)**"

translate english ch06_orph02_6401da2a:

    m "I told you to wait a second. I'm trying to look at it right now."

translate english ch06_orph02_77673f80_9:

    d "........."

translate english ch06_orph02_cd84ea65:

    m "It looks fine on my computer."

translate english ch06_orph02_ef6d92ed_12:

    m "........."

translate english ch06_orph02_ff44a5df:

    m "Yes, I'm telling you, I can see it just fine."

translate english ch06_orph02_a797f6ce:

    d "............."

translate english ch06_orph02_eb2431d3:

    d "**(Oh my God, Mary....)**"

translate english ch06_orph02_c806717d:

    d "**(You're ready now..)**"

translate english ch06_orph02_58ca30ee:

    d "**(Do you know what that means?)**"

translate english ch06_orph02_fa8babfd:

    d "Haaah....."

translate english ch06_orph02_0789d1c7:

    d "**(You're ready to be my woman.)**"

translate english ch06_orph02_049af954:

    d "**(You’re going to belong to [d_name], the orphan from Milfheim, and no one else.)**"

translate english ch06_orph02_f67ec351:

    m "So I just need to buy this one, right?"

translate english ch06_orph02_bf9f46f3:

    m "Okay."

translate english ch06_orph02_acb9f61d:

    m "Then I'll order it."

translate english ch06_orph02_26cf6766_1:

    m "!!!!!!!!!!!!"

translate english ch06_orph02_6e7a4c4d:

    m "Aah......."

translate english ch06_orph02_2951352b:

    d "**(Damn it.)**"

translate english ch06_orph02_e6ea205c:

    d "**(I want to lick her pussy, but I can't get into the right position.)**"

translate english ch06_orph02_b0114534:

    m "Aaah!!!"

translate english ch06_orph02_74427435:

    m "N-no."

translate english ch06_orph02_90e0285a:

    m "A-a bug suddenly flew at me and startled me."

translate english ch06_orph02_e63641d5:

    m "What are you talking about? I'm working in my office right now?!!"

translate english ch06_orph02_c23e659c:

    m "Oh, stop talking nonsense!!"

translate english ch06_orph02_bcacab35:

    m "How many times do I have to tell you there aren't any male employees here?!!!"

translate english ch06_orph02_d6b9aab7:

    m "Yeah. Okay."

translate english ch06_orph02_f4ac43c8:

    m "See you tonight."

translate english ch06_orph02_dd2710f9:

    m "Love you."

translate english ch06_orph02_5aebff17_3:

    m ".........."

translate english ch06_orph02_ebb2ca11:

    m "Haaah.........."

translate english ch06_orph02_23e2697b:

    n "She felt a different kind of warmth against her pussy."

translate english ch06_orph02_71db2398:

    n "It wasn't the warmth of a finger or someone's face."

translate english ch06_orph02_d7abf1e7:

    n "Instinctively, she knew it was a man's cock."

translate english ch06_orph02_fb8f38c0:

    n "He carefully brought his cock to the entrance of her vagina."

translate english ch06_orph02_5aebff17_4:

    m ".........."

translate english ch06_orph02_12ee3027:

    m "You really..."

translate english ch06_orph02_2c3ada7a:

    m "What the hell is that?....."

translate english ch06_orph02_f721e84a_1:

    m "...."

translate english ch06_orph02_fd5dd243:

    m "Are you seriously trying to go all the way right here?"

translate english ch06_orph02_ef6d92ed_13:

    m "........."

translate english ch06_orph02_a3540d20:

    m "Oh my God, [d_name]..."

translate english ch06_orph02_8dda917b:

    m "Is that what you want??"

translate english ch06_orph02_9f384fb4:

    d "Huh??"

translate english ch06_orph02_cbf05bd7:

    m "Do you think sex is just some game where you shove it in and that's it??!!!"

translate english ch06_orph02_df9491e5:

    d "N-no......"

translate english ch06_orph02_d78e490a:

    m "What do you mean, no?!!!"

translate english ch06_orph02_d8c26132:

    m "That's exactly what you're doing right now."

translate english ch06_orph02_340ef623:

    m "Do you think I'm some street whore??!!!!"

translate english ch06_orph02_bab6a8e8:

    m "Am I a sex doll to you?!!!!"

translate english ch06_orph02_00370a05:

    d "N-no...."

translate english ch06_orph02_8af6ecea:

    m "Haaah.........."

translate english ch06_orph02_33969417:

    m "I can't take this anymore....."

translate english ch06_orph02_94ec9141:

    m "What am I supposed to do with you....."

translate english ch06_orph02_5b29dacc:

    m "Don't you think you're treating me terribly??"

translate english ch06_orph02_5aebff17_5:

    m ".........."

translate english ch06_orph02_0de0096d:

    m "Honey...."

translate english ch06_orph02_5b2fa9f6:

    d "Yes?..."

translate english ch06_orph02_429553bf:

    d "Y-you want me to lock the door?"

translate english ch06_orph02_97a069c3_1:

    m "What?!!"

translate english ch06_orph02_c32d5223:

    m "[d_name]!!!!!!!!!!!"

translate english ch06_orph02_5e3aec4e_2:

    d ".........."

translate english ch06_orph02_9989be99:

    m "Do you seriously think we can do this in a building full of employees?!!!"

translate english ch06_orph02_a222e0f5_1:

    m "Haaah...."

translate english ch06_orph02_b6f367c6:

    m "Are you trying to get me into trouble?!!!"

translate english ch06_orph02_c93224be:

    d "N-no, that's not what I meant...."

translate english ch06_orph02_faba83ef:

    d "But I......"

translate english ch06_orph02_5aebff17_6:

    m ".........."

translate english ch06_orph02_a1986173:

    d "I-I just wanted to make you feel good, Mary...."

translate english ch06_orph02_4800b1f1:

    m "Enough!!"

translate english ch06_orph02_f849315e:

    m "Stop it!!"

translate english ch06_orph02_23ad3e3c:

    m "I'm so sick of hearing you talk about making me feel good!!!!!"

translate english ch06_orph02_a1522821:

    m "Say one more word, and whatever we have between us is over for good."

translate english ch06_orph02_e5c36b54_1:

    d "..........."

translate english ch06_orph02_3c9200b0:

    m "Get dressed and leave. Now."

translate english ch06_orph02_fac8215b_1:

    d "............"

translate english ch06_orph02_1aefa8b4_6:

    m ".............."

translate english ch06_orph02_790b0cf7:

    m "Get out."

translate english ch06_orph02_fc73056e:

    d "Okay......"

translate english ch06_orph02_f86ba53d:

    m "A-and..."

translate english ch06_orph02_22075273:

    m "There's something else you should know."

translate english ch06_orph02_ed5e6cc2:

    d "What is it??"

translate english ch06_orph02_91cd9735:

    m "I'm going to have security cameras installed in this office, too."

translate english ch06_orph02_3b84a8ae:

    d "What??!!!"

translate english ch06_orph02_8aa362c6:

    d "Security cameras?"

translate english ch06_orph02_e0326c65:

    d "You're installing security cameras in here??!!"

translate english ch06_orph02_fae07c14:

    m "Why are you so surprised?"

translate english ch06_orph02_75b73cea:

    m "Were you planning to commit a crime in here or something?"

translate english ch06_orph02_5e9718cc:

    d "N-no..."

translate english ch06_orph02_e5015da7:

    d "It's not that..."

translate english ch06_orph02_c5c5d1ef:

    m "Celine said she's been seeing suspicious people around lately and suggested installing them."

translate english ch06_orph02_0bff3c97:

    m "I think it's a good idea, too."

translate english ch06_orph02_d4d9e65b:

    m "There's been a lot of crime around town lately."

translate english ch06_orph02_203cc60b_4:

    d "......."

translate english ch06_orph02_dc2af698:

    d "Y-yeah, that's true...."

translate english ch06_orph02_bf0a988a:

    d "I saw it on the news, too...."

translate english ch06_orph02_168681c1:

    d "**(Damn it, Celine.)**"

translate english ch06_orph02_bb587f9c:

    d "**(That was a clever move.....)**"

translate english ch06_orph02_9cbf0f1b:

    d "**(Did you really have to go this far??!!!!!!!)**"

translate english ch06_orph02_ee3f40b5:

    d "**(What am I, a fucking thief, bitch??!!!!)**"

translate english ch06_orph02_138cc70f:

    m "I'm going back in to lie down."

translate english ch06_orph02_a3b07d09:

    m "Now go."

translate english ch06_orph02_341f4a14:

    m "And text me."

translate english ch06_orph02_5af89467:

    m "If you send me another picture of your cock, I'm calling the police."

translate english ch06_orph02_77673f80_10:

    d "........."

translate english ch06_orph02_b0196085_2:

    m "!!"

translate english ch06_orph02_a8936dad:

    m "Honey....."

translate english ch06_orph02_5aebff17_7:

    m ".........."

translate english ch06_orph02_f94cb695:

    m "You really are a troublemaker..."

translate english ch06_orph02_08ae6ee6_1:

    d "I love you, Mary."

translate english ch06_orph02_04a56179:

    d "I'm not just saying that."

translate english ch06_orph02_739fe772:

    d "I truly love you."

translate english ch06_orph02_350d41ea:

    d "The reason I keep touching you like this is..."

translate english ch06_orph02_095a920a:

    d "Because you're such a beautiful woman, Mary."

translate english ch06_orph02_454742b6_1:

    m "............"

translate english ch06_orph02_f1bff77c_12:

    m "........"

translate english ch06_orph02_4c9870de:

    m "I'm sorry I got angry, sweetie....."

translate english ch06_orph02_df5a1c1a:

    m "I care about you, and I love you, too."

translate english ch06_orph02_f1bff77c_13:

    m "........"

translate english ch06_orph02_4e570b37:

    m "Haaah........"

translate english ch06_orph02_927bcffd:

    d "Ouch!!"

translate english ch06_orph02_f32cd7f9:

    m "You really are something....."

translate english ch06_orph02_3b9d5daa:

    m "Now get out."

translate english ch06_orph02_57d51322:

    m "I really need to get some rest."

translate english ch06_orph02_8c097a17_1:

    d "Okay."

translate english ch06_orph02_589dd8c5:

    d "I'm leaving."

translate english ch06_police01_22160ce6:

    unknownm "......."

translate english ch06_police01_99e12c54:

    unknownm "What's that...?"

translate english ch06_police01_cbc53004:

    unknownm "Looks like there's someone inside. Is he sleeping??"

translate english ch06_police01_22160ce6_1:

    unknownm "......."

translate english ch06_police01_40341312:

    unknownm "Is he sleeping with the AC on?"

translate english ch06_police01_cf6a5585:

    unknownm "Where did I put it...."

translate english ch06_police01_283f390a:

    unknownm "Ah, here it is."

translate english ch06_police01_6c602f7e:

    unknownm "Um, hello?"

translate english ch06_police01_18b31457:

    unknownm "Are you sleeping??"

translate english ch06_police01_24426074:

    unknownm "Is something wrong??"

translate english ch06_police01_48f066ed:

    unknownm "........."

translate english ch06_police01_8a2baaab:

    unknownm "Excuse me, sir."

translate english ch06_police01_5e789ba6:

    unknownm "....."

translate english ch06_police01_e2542d03:

    unknownm "Is he asleep?"

translate english ch06_police01_4ee78e60:

    unknownm "What the hell? Is he sleeping in there with all the windows rolled up?..."

translate english ch06_police01_81ab7d28:

    unknownm "Fuck!!!!!!"

translate english ch06_police01_22160ce6_2:

    unknownm "......."

translate english ch06_police01_73ab8c9a:

    unknownm "What the hell is this....."

translate english ch06_police01_c9d42b88:

    unknownm "Damn it."

translate english ch06_police01_5bc0e150:

    unknownm "........"

translate english ch06_police01_8d61b52d:

    unknownm "Shit, looks like it's gonna be one of those days......."

translate english ch06_police01_55326f78:

    n "A phone rang through the silence of Diana's room, breaking the stillness of the air."

translate english ch06_police01_4628428a:

    n "She woke up, having lost all sense of how much time had passed."

translate english ch06_police01_82e43c0c:

    di "Mmm....."

translate english ch06_police01_cbfd6b4f:

    di "Yes, this is Di—"

translate english ch06_police01_15c9995a:

    di "Yes, this is Diana....."

translate english ch06_police01_5deb00f3:

    n "The sounds of hurried voices and police sirens came through the phone."

translate english ch06_police01_f6227baf:

    n "Still half-asleep, she lay there listening to Ethan speak."

translate english ch06_police01_1e568755:

    di ".........."

translate english ch06_police01_b77ab21e:

    di "Got it."

translate english ch06_police01_c5b824bc:

    di "I'll be right there."

translate english ch06_police01_82e43c0c_1:

    di "Mmm....."

translate english ch06_police01_92c2ffd9:

    di "Damn it....."

translate english ch06_police01_d89a29aa:

    di "I was finally getting some decent sleep for once...."

translate english ch06_police01_b45af4d4:

    di "Haaah....."

translate english ch06_police01_cbfff03f:

    di "......."

translate english ch06_police01_1e568755_1:

    di ".........."

translate english ch06_police01_2d122cca:

    di "Come on, Diana. Get up...."

translate english ch06_police01_1e568755_2:

    di ".........."

translate english ch06_police01_2811d06f:

    di "Get up!!"

translate english ch06_police01_b3118bda:

    di "What time is it anyway...."

translate english ch06_police01_20b55495:

    eth "Morning, boss."

translate english ch06_police01_3d646de9:

    di "What's the situation?"

translate english ch06_police01_1bd63878:

    di "You ran the plates, right?"

translate english ch06_police01_b92b0a9a:

    eth "Yes, ma'am."

translate english ch06_police01_a9230120:

    di "Give me the rundown."

translate english ch06_police01_126acdbe:

    eth "First, the registered owner of the vehicle matches the deceased."

translate english ch06_police01_4f579c17:

    eth "The vehicle is properly registered."

translate english ch06_police01_26f9cffc:

    eth "The deceased is Daniel Reed, 62 years old. A geologist."

translate english ch06_police01_2d577f5f:

    di "A geologist?"

translate english ch06_police01_5ce42b39:

    eth "Yes."

translate english ch06_police01_c8b35bbb:

    eth "He was a university professor who retired last year."

translate english ch06_police01_62784df4:

    eth "From what we can see, he died from a gunshot wound to the head."

translate english ch06_police01_13363eeb:

    eth "There's also a gun and a suicide note inside the vehicle."

translate english ch06_police01_1bdaf2ef:

    eth "So far, it looks like a suicide."

translate english ch06_police01_f410874c:

    di "No signs of damage or a struggle?"

translate english ch06_police01_5ce42b39_1:

    eth "No, ma'am."

translate english ch06_police01_a210169e:

    eth "No signs that the vehicle was attacked or that the doors were forced open."

translate english ch06_police01_4c105f1b:

    eth "There's no visible damage to the windows or anywhere else, either."

translate english ch06_police01_f3bf555e:

    di "............"

translate english ch06_police01_f47207a6:

    di "Doesn't look too complicated."

translate english ch06_police01_9fb85787:

    eth "No, ma'am."

translate english ch06_police01_a1f2896f:

    di "I heard you haven't had a proper break in months..."

translate english ch06_police01_2484f348:

    di "And here you are, working your ass off before dawn again."

translate english ch06_police01_c87a35e2:

    eth "It's nothing, haha."

translate english ch06_police01_7a1184b6:

    eth "I'm fine."

translate english ch06_police01_438e9253:

    eth "It's my job, after all."

translate english ch06_police01_fa657d5d:

    di "Ahem..."

translate english ch06_police01_f3bf555e_1:

    di "............"

translate english ch06_police01_51f52bec:

    di "What about over there?"

translate english ch06_police01_31d9800a:

    di "Did you check that restroom?"

translate english ch06_police01_4bab29b5:

    eth "We didn't see anything unusual."

translate english ch06_police01_eec18e3a:

    eth "We've identified the company responsible for maintaining this place."

translate english ch06_police01_d7403afe:

    eth "Evan is going to get the surveillance footage from them once it's daylight."

translate english ch06_police01_9de4c3c9:

    di "Good."

translate english ch06_police01_46437f56:

    di "..........."

translate english ch06_police01_d4af26e1:

    di "Damn it..."

translate english ch06_police01_253076b0:

    di "**(I've seen this dozens of times, but I never get used to it...)**"

translate english ch06_police01_f3bf555e_2:

    di "............"

translate english ch06_police01_3c1266e3:

    di "**(Rest in peace, sir..)**"

translate english ch06_police01_82edd08a:

    di "**(We still need to find out what happened to you, though..)**"

translate english ch06_police01_b9101b58:

    n "She examined the crime scene just as she had been trained to do throughout her career."

translate english ch06_police01_f3bf555e_3:

    di "............"

translate english ch06_police01_d39149ee:

    n "She moved from one area to another with practiced ease, checking everything thoroughly."

translate english ch06_police01_53ea18fd:

    n "Any trace of sleepiness was gone, replaced by the sharp instincts of a seasoned detective."

translate english ch06_police01_ae1f6a2b:

    eth "......."

translate english ch06_police01_a9464cc0:

    di "The body's position hasn't been changed, right?"

translate english ch06_police01_c3335207:

    eth "The position?"

translate english ch06_police01_208579c8:

    di "The body's still exactly as the witness found it, right?"

translate english ch06_police01_45bc5fa2:

    eth "Oh......."

translate english ch06_police01_18db909c:

    eth "Yes, that's correct."

translate english ch06_police01_cbfff03f_1:

    di "......."

translate english ch06_police01_505d379d:

    eth "..........."

translate english ch06_police01_fd41e417:

    di "Have we identified the person who reported it?"

translate english ch06_police01_a0e47c79:

    eth "Huh?"

translate english ch06_police01_771edbae:

    eth "Oh... The person who called it in..."

translate english ch06_police01_5f2a2f61:

    eth "........."

translate english ch06_police01_5dacb85b:

    eth "The caller was a truck driver."

translate english ch06_police01_a40a191c:

    eth "Jake Hatfield, 52 years old."

translate english ch06_police01_99d5ecf3:

    eth "We questioned him, but nothing unusual came up."

translate english ch06_police01_8c340f5a:

    eth "He had deliveries to make, so we verified his identity, got his contact information, and let him go."

translate english ch06_police01_ce1329e6:

    di "Got it."

translate english ch06_police01_cbfff03f_2:

    di "......."

translate english ch06_police01_46437f56_1:

    di "..........."

translate english ch06_police01_d6bf537d:

    di "Hmm....."

translate english ch06_police01_e2cb8277:

    eth "Did you find something?"

translate english ch06_police01_d8a59272:

    eth "I didn't notice anything unusual."

translate english ch06_police01_b45b3713:

    eth ".........."

translate english ch06_police01_e7610330:

    eth "I wasn't going to bother you, but since this is your first case since coming to town, I figured I should give you a call."

translate english ch06_police01_260942b0:

    di "Something feels off."

translate english ch06_police01_5fbaefe4:

    eth "Huh??"

translate english ch06_police01_50cb3f79:

    eth "........"

translate english ch06_police01_71ad07c3:

    eth "Something feels off?"

translate english ch06_police01_1766a4d3:

    eth "Like what?"

translate english ch06_police01_46437f56_2:

    di "..........."

translate english ch06_police01_dc0cb6a3:

    di "The suicide note is facing toward the victim."

translate english ch06_police01_505d379d_1:

    eth "..........."

translate english ch06_police01_5f2a2f61_1:

    eth "........."

translate english ch06_police01_dab8b656:

    eth "Why is that strange?"

translate english ch06_police01_9be804b4:

    di "........."

translate english ch06_police01_426147b4:

    di "Think about it."

translate english ch06_police01_2d852e5f:

    di "If he'd looked at the note one last time before killing himself and tossed it onto the passenger seat..."

translate english ch06_police01_26825f9e:

    di "Wouldn't it be more natural for the top of the page to be facing away from him?"

translate english ch06_police01_1f6ac6eb:

    eth "Hmm......"

translate english ch06_police01_bca3a7d3:

    eth "Maybe he just tossed it there when he got into the car?"

translate english ch06_police01_1e568755_3:

    di ".........."

translate english ch06_police01_7995c1c9:

    di "That's possible, but I doubt he drove all the way here with it sitting like this."

translate english ch06_police01_f47fa7f7:

    di "If he'd tossed it onto the passenger side when he got in, it would've landed on the passenger seat."

translate english ch06_police01_0d56de3d:

    di "He wouldn't have driven with it sitting in such an awkward position."

translate english ch06_police01_72cf4292:

    di "And look at this."

translate english ch06_police01_5f3ba294:

    di "The suicide note is too close to the body."

translate english ch06_police01_5f2a2f61_2:

    eth "........."

translate english ch06_police01_0e56d8be:

    di "Considering the length of a person's arm, it's positioned far too close to him."

translate english ch06_police01_e4e86d2e:

    di "It looks too deliberate."

translate english ch06_police01_1d4d4415:

    di "Whether someone was sitting in the driver's seat or the passenger seat, the natural thing would be to put the paper down on the passenger seat."

translate english ch06_police01_6584d803:

    eth "Hmm... You're right."

translate english ch06_police01_f3b81481:

    di "It looks like someone sitting in the passenger seat read the note, put it down, and left."

translate english ch06_police01_6ba98003:

    di "And the fact that the window isn't broken suggests it was rolled up after the gun was fired."

translate english ch06_police01_faadde16:

    di "On a hot day like this, the killer and the victim probably spent quite some time talking inside the car with the windows down."

translate english ch06_police01_665ca333:

    di "And this location feels wrong, too."

translate english ch06_police01_595e5c94:

    di "Don't you think?"

translate english ch06_police01_6e899c3f:

    di "......"

translate english ch06_police01_50b494b7:

    eth "The location?"

translate english ch06_police01_ea258436:

    eth "......"

translate english ch06_police01_c64dc9f4:

    eth "It's pretty creepy. Seems like the perfect place to die...."

translate english ch06_police01_bd30b5b4:

    eth "Don't you think?"

translate english ch06_police01_e22a2ac1:

    di "This is a highway restroom."

translate english ch06_police01_4fb11e94:

    di "....."

translate english ch06_police01_0fb764df:

    di "Why would this man choose to kill himself here?"

translate english ch06_police01_6023c30a:

    eth ".............."

translate english ch06_police01_4db11a20:

    eth "Isn't that something only the victim would know?"

translate english ch06_police01_b225122f:

    di "That's exactly why it's strange."

translate english ch06_police01_c8e19b7d:

    di "This isn't so much a place to commit suicide as it is a place to meet someone discreetly."

translate english ch06_police01_59692f16:

    di "How should I put it..."

translate english ch06_police01_bef1deef:

    di "A place where you could arrange to meet someone without making them suspicious, unlike some completely deserted location."

translate english ch06_police01_69ff8896:

    di "Yet somewhere quiet enough that there are moments when you could kill someone without being seen."

translate english ch06_police01_dea6cae1:

    eth "Oh...."

translate english ch06_police01_37911fd6:

    di "Think about it."

translate english ch06_police01_9389abc7:

    di "When something feels unnatural, it usually means someone deliberately made it that way."

translate english ch06_police01_fa935614:

    eth "I was looking at the scene too simply."

translate english ch06_police01_f0f4e5b8:

    di "Ugh, my back hurts."

translate english ch06_police01_e730fb61:

    eth "....."

translate english ch06_police01_cbfff03f_3:

    di "......."

translate english ch06_police01_972df9a3:

    di "**(Oh my God.....)**"

translate english ch06_police01_cbfff03f_4:

    di "......."

translate english ch06_police01_63630d89:

    di "**(Seriously???)**"

translate english ch06_police01_049d8ab8:

    di "**(An erection at a time like this??)**"

translate english ch06_police01_93828ca2:

    di "**(Why?????)**"

translate english ch06_police01_9be804b4_1:

    di "........."

translate english ch06_police01_505d379d_2:

    eth "..........."

translate english ch06_police01_febf1733:

    di "........"

translate english ch06_police01_ebafa67b:

    eth "So we're officially treating this as a homicide?"

translate english ch06_police01_cb0a8c60:

    di "We'll know for sure once the fingerprints and autopsy results come back."

translate english ch06_police01_410a55b1:

    di "Let's head back to the station for now."

translate english ch06_police01_1e4dc161:

    di "We should write up our reports while everything's still fresh in our minds."

translate english ch06_police01_6d0184fa:

    eth "Yes, ma'am."

translate english ch06_company01_1e659cdc:

    d "Damn it."

translate english ch06_company01_ff7a7cf3:

    d "I'm so nervous about my first day of work..."

translate english ch06_company01_870e92ca:

    d "So this is the pressure of having a job, huh? It's pretty intense..."

translate english ch06_company01_738fed7b:

    d "If I'm this nervous as an intern, imagine what it'll be like when I become a full-time employee??"

translate english ch06_company01_c77b8c1b:

    d "Or maybe it'll get easier once I get used to it?..."

translate english ch06_company01_0e0c74df:

    d "Either way, I'm really nervous."

translate english ch06_company01_89928173:

    d "Good morning, [h_name]."

translate english ch06_company01_c602f7fc:

    h "!!!"

translate english ch06_company01_dfdf3ac0:

    d "It's my first day at work today, hahaha."

translate english ch06_company01_a8eacbb8:

    h "You're leaving already??"

translate english ch06_company01_210fe38f:

    d "Yeah, haha."

translate english ch06_company01_07a6ca70:

    d "I'm really nervous about my first day, hahaha."

translate english ch06_company01_28d07f98:

    h "You're going to work without eating breakfast??"

translate english ch06_company01_72dd1626:

    h "You're riding your bike, aren't you?"

translate english ch06_company01_8530181e:

    d "Yeah, I'm taking my bike."

translate english ch06_company01_b6e33d05:

    h "Then you'll be too hungry to work properly."

translate english ch06_company01_cff12c7b:

    d "Yeah, I guess so, haha."

translate english ch06_company01_1134c480:

    h "Starting tomorrow, I'm going to wake you up earlier!!"

translate english ch06_company01_4bb59dbf:

    d "What??!!"

translate english ch06_company01_27a13a73:

    d "Oh, you don't have to...."

translate english ch06_company01_aa3b462b:

    h "Come here a second."

translate english ch06_company01_02c11c9c:

    h "What do you mean, I don't have to?"

translate english ch06_company01_94e652d5:

    h "If I wake you up, you'll have no choice but to get up, haha."

translate english ch06_company01_a47d07a5:

    d "Hahaha."

translate english ch06_company01_b898b389:

    d "Then please wake me up gently."

translate english ch06_company01_b45ae0cf:

    d "!!!"

translate english ch06_company01_81f8cfd3:

    h "Here, eat this."

translate english ch06_company01_16e7be67:

    d "Mmph!!"

translate english ch06_company01_06897645:

    h "Hahaha."

translate english ch06_company01_0adf25f6:

    h "Why are you so startled?"

translate english ch06_company01_eebe150b:

    h "It's just a cherry, not poison."

translate english ch06_company01_b0450d16:

    d "**(Damn it....)**"

translate english ch06_company01_d8ad0688:

    d "**(This feels different somehow.....)**"

translate english ch06_company01_a1f4d595:

    d "**(It's almost like I'm her husband, hahaha.)**"

translate english ch06_company01_6239d40e:

    d "**(A wife seeing her husband off to work....)**"

translate english ch06_company01_661ac216:

    h "Hahaha."

translate english ch06_company01_d760e05d:

    h "This makes me feel like I'm [d_name]'s mother."

translate english ch06_company01_2f48c19a:

    d "Hmm..."

translate english ch06_company01_096bc929:

    d "When you feed me like this, [h_name], it feels like we’re married, haha."

translate english ch06_company01_05d308a9:

    h "**(Married???)**"

translate english ch06_company01_8a170408:

    h "**(Oh, come on... Married, really....)**"

translate english ch06_company01_cb07d405:

    h "**(He sure knows how to say the cheesiest things.)**"

translate english ch06_company01_f118f5f4:

    h "It's your first day, so don't be too nervous. You'll do great."

translate english ch06_company01_49973e29:

    h "And be careful riding your bike, okay?"

translate english ch06_company01_0d4d0ea7:

    d "Yes, ma'am."

translate english ch06_company01_d736ba47:

    n "They gazed at each other silently for a moment."

translate english ch06_company01_cdca3bd4:

    n "Each waited for the other to say something."

translate english ch06_company01_995fade6:

    n "Then, without even realizing it, [d_name] made the situation awkward."

translate english ch06_company01_9d1c1753:

    d "W-when a husband leaves for work..."

translate english ch06_company01_0082385b:

    d "I-isn't it normal for his wife to k-kiss him goodbye....."

translate english ch06_company01_5173390f:

    d "**(Damn it, what the hell am I saying!!!)**"

translate english ch06_company01_8b1582df:

    h "What??!!"

translate english ch06_company01_fbda59ed:

    h "K-kiss??..."

translate english ch06_company01_dc18d7e6:

    d "Yeah......"

translate english ch06_company01_c42a2439:

    d "Well, um......"

translate english ch06_company01_f8fa540b:

    d "I thought a kiss from you would give me a little boost, [h_name]...."

translate english ch06_company01_5b86a40c:

    h "Oh..........."

translate english ch06_company01_d2bf73f0:

    h "I-is that so?..."

translate english ch06_company01_e1d4868d:

    h "**(He thinks a kiss from me would give him more energy....)**"

translate english ch06_company01_de3bcb51:

    h "**(He's being so obvious about what he wants.)**"

translate english ch06_company01_d3f3b762:

    h "!!!!!"

translate english ch06_company01_a44bc721:

    h "**(Oh my God, what's this boy doing???)**"

translate english ch06_company01_fefe6139:

    h "**(What should I do???!!!!)**"

translate english ch06_company01_0671dce9:

    h "**(Ugh....)**"

translate english ch06_company01_451dd3e6:

    n "Gathering his courage, [d_name] moved closer to her."

translate english ch06_company01_72d853bc:

    n "His heart was pounding so hard it felt like it might burst out of his chest."

translate english strings:
    old "그녀의 입술에 키스한다."
    new "Kiss her on the lips."

translate english ch06_company01_92f21ed5:

    n "What should I do?"

translate english ch06_company01_9d045477:

    n "Mwah!"

translate english ch06_company01_8dafa8f7:

    h "O-oh my..."

translate english ch06_company01_661ac216_1:

    h "Hahaha."

translate english ch06_company01_62dd9e56:

    h "Have a good day at work, and s-see you tonight, haha."

translate english ch06_company01_326c154c:

    h "**(Phew........)**"

translate english strings:
    old "그녀의 입술에 다시 키스한다."
    new "Kiss her on the lips again."

translate english ch06_company01_92f21ed5_1:

    n "What should I do?"

translate english ch06_company01_f8e38a47:

    h "Mmph!!!"

translate english ch06_company01_ad4b7d98:

    n "When he slipped his tongue into her mouth, she didn't resist."

translate english ch06_company01_1a7d16a4:

    n "For the first time, the landlady’s saliva mingled with her tenant’s."

translate english ch06_company01_1580aad7:

    h "Haha, you should get going."

translate english ch06_company01_d17abac8:

    h "W-what was that...."

translate english ch06_company01_2292fe40:

    d "Okay...."

translate english ch06_company01_ef92d930:

    d "I-I'm sorry..."

translate english ch06_company01_17729cb2:

    d "I-I just couldn't help myself...."

translate english ch06_company01_c3123c92:

    d "**(What have I just done....)**"

translate english ch06_company01_fbdeaba0:

    h "Wait a second!!"

translate english ch06_company01_9f384fb4:

    d "Yes??"

translate english ch06_company01_a254b6d4:

    d "!!!!!"

translate english ch06_company01_f5d43874:

    h "Take this with you and eat it on the way, haha."

translate english ch06_company01_3a553aec:

    d "**(Oh my God.....)**"

translate english ch06_company01_7b8a472b:

    d "**(She's so incredibly adorable.....)**"

translate english ch06_company01_813e19ef:

    h "**(Are you proud of yourself, [h_name]??)**"

translate english ch06_company01_685b2577:

    h "**(Did you enjoy kissing a man that much younger than you, you bitch.....)**"

translate english ch06_company01_a9951257:

    h "**(How utterly shameful......)**"

translate english ch06_company01_92ad9932:

    h "............"

translate english ch06_company01_4ae73a4f:

    h "**(What's wrong with me?....)**"

translate english ch06_company01_df99ea8b:

    h "**(What the hell am I doing with a boy like him....)**"

translate english ch06_company01_5c5d4927:

    h "**(You're disgusting, [h_name]...)**"

translate english ch06_company01_521d56cd:

    d "Well, it's good exercise, but...."

translate english ch06_company01_eecc9166:

    d "Maybe it's time I learned how to drive?....."

translate english ch06_company01_a5397f11:

    d "Should I ask the landlady to teach me how to drive...."

translate english ch06_company01_69ee00fb:

    d "Hmm....."

translate english ch06_company01_80000cfb:

    d "I think I'll ask her to teach me."

translate english ch06_company01_09de2ef9:

    d "?????"

translate english ch06_company01_16343062:

    viv "Good morning."

translate english ch06_company01_63fb8674:

    d "O-oh, hello."

translate english ch06_company01_119ddc2e:

    viv "You're here early."

translate english ch06_company01_f318543d:

    d "Yeah, haha."

translate english ch06_company01_8d817553:

    d "It's my first day, so I guess I didn't get the timing right, haha."

translate english ch06_company01_95937ad8:

    viv "Haha, everyone's like that at first."

translate english ch06_company01_ee15ecf0:

    d "Honestly, my heart's pounding so hard it feels like it's about to jump out of my chest, haha."

translate english ch06_company01_9ca430f6:

    viv "Hahaha. I know exactly how that feels."

translate english ch06_company01_ebcd4426:

    viv "You're just starting out as an intern, and it's your first day, so don't worry too much."

translate english ch06_company01_64baa5b9:

    viv "Just think of it as a chance to learn."

translate english ch06_company01_c2b79ed8:

    d "Okay, haha."

translate english ch06_company01_e3159623:

    viv "All right."

translate english ch06_company01_955ada9b:

    viv "Come on, let's head inside."

translate english ch06_company01_c2b79ed8_1:

    d "Okay, haha."

translate english ch06_company01_79f37fdf:

    viv "............."

translate english ch06_company01_e7af3c2d:

    d "Ahem......"

translate english ch06_company01_98a125c5:

    n "Vivian and [d_name] stepped into the elevator together."

translate english ch06_company01_ab9e5780:

    d "**(Ah, this is awkward.....)**"

translate english ch06_company01_c9bb8ce7:

    n "He could smell her strong perfume."

translate english ch06_company01_a59eb16f:

    viv "........"

translate english ch06_company01_1dccabee:

    d "**(She's got a pretty nice ass..)**"

translate english ch06_company01_203cc60b:

    d "......."

translate english ch06_company01_7c02372a:

    d "**(I wonder how old she is?...)**"

translate english ch06_company01_e34aec7c:

    d "**(Huh?)**"

translate english ch06_company01_65b0db10:

    d "**(Isn't that a nightclub wristband?.....)**"

translate english ch06_company01_a70b2574:

    d "**(What's going on?....)**"

translate english ch06_company01_91ea2a2f:

    d "**(Why is she still wearing that???.....)**"

translate english ch06_company01_f8fe3469:

    d "**(....)**"

translate english ch06_company01_f4ac9ee5:

    d "**(Wait, did she spend the night somewhere and come straight to work?....)**"

translate english ch06_company01_03907743:

    d "**(I don't know who the lucky guy was, but I'm jealous...)**"

translate english ch06_company01_c830e581:

    viv "!!!!!!!!!!!!"

translate english ch06_company01_ea61452f:

    n "When he entered the office, Shakira was taking off her top."

translate english ch06_company01_57612cc8:

    sha "!!!!!!!!!!"

translate english ch06_company01_abd6420e:

    sha "Damn it!!!!"

translate english ch06_company01_0ffca05f:

    sha "Sorry!!"

translate english ch06_company01_48b9243d:

    sha "Sorry about the morning strip show, hahaha."

translate english ch06_company01_4a0c41ac:

    sha "........"

translate english ch06_company01_1c43986f:

    sha "You're here earlier than usual?"

translate english ch06_company01_cfe1604b:

    viv "Yeah."

translate english ch06_company01_4e4156c2:

    viv "I just happened to get here early."

translate english ch06_company01_def8b9e5:

    viv "......."

translate english ch06_company01_eb533fd0:

    d "The layout's changed?"

translate english ch06_company01_556168cb:

    d "I don't remember it looking like this during my interview.."

translate english ch06_company01_dfeccbe5:

    viv "Yeah."

translate english ch06_company01_7f9db60f:

    viv "We had some renovations done over the last two days."

translate english ch06_company01_09318be1:

    viv "A lot of people felt their workspaces were too exposed."

translate english ch06_company01_bb0bfe8e:

    d "Oh, I see."

translate english ch06_company01_335be2d3:

    ke "Good morning."

translate english ch06_company01_cc06ada7:

    sha "Good morning, everyone~~"

translate english ch06_company01_4445e515:

    ke "Monday has come around again, as it always does."

translate english ch06_company01_9ea59f5b:

    ke "But don't let that make you give up on life, everyone."

translate english ch06_company01_0cd7c618:

    d "Good morning!!"

translate english ch06_company01_45a34cfe:

    ch "Good morning."

translate english ch06_company01_89c18912:

    n "And so, his first day of work began."

translate english ch06_company01_ecb2b922:

    n "He tried his best to smile, but inside, he was a nervous wreck under the pressure of wanting to do well."

translate english ch06_company01_c204afe9:

    sha "Ahem..."

translate english ch06_company01_b45ae0cf_1:

    d "!!!"

translate english ch06_company01_2ad712ee:

    sha "Excuse me, [d_name]?"

translate english ch06_company01_9f384fb4_1:

    d "Yes??"

translate english ch06_company01_390bc9bb:

    sha "Ugh, this thing is heavy."

translate english ch06_company01_bd58da14:

    d "???"

translate english ch06_company01_21f46bc8:

    sha "This is the company manual. Give it a read."

translate english ch06_company01_24286dad:

    d "**(A manual???)**"

translate english ch06_company01_f449dea7:

    sha "We won't be assigning you any actual work for a while, so make sure you read it carefully."

translate english ch06_company01_15734c04:

    d "Yes, ma'am. Understood."

translate english ch06_company01_e63dee7e:

    d "Thank you."

translate english ch06_company01_01523768:

    sha "You're welcome, haha."

translate english ch06_company01_f2a806de:

    sha "Normally, full-time employees have to attend training sessions every day according to a set schedule."

translate english ch06_company01_96e96c70:

    sha "But since you're a college intern, [d_name], we'll start you off with the manual."

translate english ch06_company01_bb0bfe8e_1:

    d "Oh, I see."

translate english ch06_company01_1af13eec:

    d "I'll make sure to read it thoroughly!!"

translate english ch06_company01_9e982ee0:

    sha "Good."

translate english ch06_company01_7f7fcb28:

    sha ".........."

translate english ch06_company01_d1b0af3b:

    d "**(Everyone working here seems really nice..)**"

translate english ch06_company01_f5f8177d:

    d "**(Maybe there's not as much to worry about as I thought??)**"

translate english ch06_company01_85555ac8:

    d "**(Huh??)**"

translate english ch06_company01_93a21eb7:

    n "After Shakira walked away, Vivian was sitting there with her legs fully exposed."

translate english ch06_company01_2846fff9:

    n "Apparently thinking [d_name] couldn't see her, she proceeded to take off her panties."

translate english ch06_company01_c109c904:

    d "!!!!!!!!!!"

translate english ch06_company01_4c72cf9d:

    d "**(What the hell??)**"

translate english ch06_company01_054e69d7:

    d "**(Why is she changing her panties at work???!!)**"

translate english ch06_company01_6e8584d1:

    d "**(Does she think I can't see her??)**"

translate english ch06_company01_77673f80:

    d "........."

translate english ch06_company01_66417d29:

    d "**(Look at that.)**"

translate english ch06_company01_3efbbf3a:

    d "**(I knew it! She definitely spent the night somewhere and came straight to work!!)**"

translate english ch06_company01_4b910584:

    d "**(Holy shit!!)**"

translate english ch06_company01_1b1ce382:

    d "**(What the fuck........)**"

translate english ch06_company01_3c57a431:

    d "**(Wow, look at that ass.....)**"

translate english ch06_company01_9d3edcd5:

    d "**(That's insane......)**"

translate english ch06_company01_db6955f7:

    d "**(I want to bury my face in that ass....)**"

translate english ch06_company01_6c284914:

    viv "!!"

translate english ch06_company01_e3c92b81:

    d "!!!!!!!!!!!"

translate english ch06_company01_f46a3405:

    d "**(Oh, shit!!!!!!!!!!)**"

translate english ch06_company01_cbe0d368:

    d "**(I think we just made eye contact....)**"

translate english ch06_company01_5379a9da:

    d "**(Shit, shit, shit!!!!)**"

translate english ch06_company01_e8ccdc53:

    viv "**(Hehehe.)**"

translate english ch06_company01_949ce6cc:

    viv "**(What a cute little guy.)**"

translate english ch06_company01_0a13f808:

    mar "Is the team lead coming in today?"

translate english ch06_company01_f0cc7c33:

    al "What?"

translate english ch06_company01_0a13f808_1:

    mar "Is the team lead coming in today?"

translate english ch06_company01_16c6a6b6:

    mar "....."

translate english ch06_company01_eae096bf:

    mar "I've got something that needs her approval."

translate english ch06_company01_b84381f3:

    al "She is on vacation, remember?"

translate english ch06_company01_cfd06f10:

    mar "Oh, right."

translate english ch06_company01_dc5476a1:

    mar "The director's not here, and neither is the team leader. Great...."

translate english ch06_company01_b9436167:

    mar "The CEO's here today, right?"

translate english ch06_company01_de7d1138:

    al "I think she went on a business trip to the branch office over the weekend."

translate english ch06_company01_28964399:

    mar "What? So the CEO isn't here either??"

translate english ch06_company01_97915587:

    al "No."

translate english ch06_company01_527576ed:

    al "If she's following her usual schedule, she probably got back early this morning."

translate english ch06_company01_c452234e:

    mar "I have something that needs her approval right away."

translate english ch06_company01_0f03838b:

    mar "Hmm......"

translate english ch06_company01_9f16ff6f:

    mar "Hey, new guy!!"

translate english ch06_company01_7ab39cb0:

    d "!!!!"

translate english ch06_company01_4bb59dbf_1:

    d "Yes??!!"

translate english ch06_company01_157b28ef:

    d "**(That startled me...)**"

translate english ch06_company01_31644133:

    mar "Have you been upstairs yet?"

translate english ch06_company01_9eb5a468:

    d "Upstairs?"

translate english ch06_company01_b3c1bc28:

    d "**(Wait, there's another floor above us???)**"

translate english ch06_company01_44748b97:

    d "No, I haven't."

translate english ch06_company01_1a9f795a:

    mar "Then why don't you head upstairs and introduce yourself to the CEO?"

translate english ch06_company01_ed48a190:

    d "Oh, sure!!"

translate english ch06_company01_83e6cbb9:

    mar "Tell her I have some urgent documents waiting for her approval in the system."

translate english ch06_company01_d9401cd2:

    mar "She'll know what you mean."

translate english ch06_company01_1e401b3d:

    d "Oh, okay. Got it."

translate english ch06_company01_1a309fe0:

    d "I'll go right up."

translate english ch06_company01_431b384f:

    mar "The stairs behind you will take you up there."

translate english ch06_company01_5039e82b:

    d "Okay, thank you."

translate english ch06_company01_2490b6bb:

    d "**(........)**"

translate english ch06_company01_37e91ac1:

    d "**(So those stairs actually lead upstairs...)**"

translate english ch06_company01_86ccbb49:

    d "**(I thought that door led to a storage room.)**"

translate english ch06_company02_33948f20:

    d "I had no idea there was another floor up here.."

translate english ch06_company02_08fccd3c:

    d "I thought our office was on the top floor of this building.."

translate english ch06_company02_e384ad98:

    d "Are there other employees working upstairs???"

translate english ch06_company02_a64433ac:

    n "The door to the upper floor was firmly shut."

translate english ch06_company02_cde7fccc:

    n "Unlike the floor below, filled with the sounds of typing and people talking, the upper floor felt quiet and still."

translate english ch06_company02_05b27506:

    n "It was almost like a door leading to another dimension."

translate english ch06_company02_aa8e55c1:

    d "Ahem.."

translate english ch06_company02_9034cc7f:

    d "Ahem!!"

translate english ch06_company02_38ca1b70:

    d "Hmm......"

translate english ch06_company02_964867cb:

    d "Is this unlocked?"

translate english ch06_company02_f59dc126:

    d "Guess I'll just have to go in..."

translate english ch06_company02_b67278bf:

    d "Hello, ma'am!!"

translate english ch06_company02_a797f6ce:

    d "............."

translate english ch06_company02_77673f80:

    d "........."

translate english ch06_company02_b7777803:

    d "Is it okay to go in....."

translate english ch06_company02_8017203d:

    d "**(Think before you act...... Think....)**"

translate english ch06_company02_ead2240d:

    d "Of course...."

translate english ch06_company02_0c017eaa:

    d "Work comes first."

translate english ch06_company02_12e551ff:

    d "**(Wow, this looks just like someone's home.)**"

translate english ch06_company02_ad893dfa:

    d "......"

translate english ch06_company02_6ba3c7e1:

    d "**(It's nothing like downstairs.)**"

translate english ch06_company02_195d5fcf:

    d "**(Is this some kind of home office...)**"

translate english ch06_company02_dcf57f68:

    d "**(I'd love to live somewhere like this.)**"

translate english ch06_company02_5c7930eb:

    d "**(Oh, it smells nice in here.)**"

translate english ch06_company02_203cc60b:

    d "......."

translate english ch06_company02_23d0fb95:

    d "**(A woman's home always smells so good.....)**"

translate english ch06_company02_3c0300ef:

    d "**(Does Rose live here?)**"

translate english ch06_company02_4f8985d5:

    d "**(No, of course she probably has a bigger house somewhere.)**"

translate english ch06_company02_a254b6d4:

    d "!!!!!"

translate english ch06_company02_0f342c8d:

    d "**(Oh, there she is.)**"

translate english ch06_company02_547b6a5c:

    d "Hello, ma'am."

translate english ch06_company02_edbb7d05:

    d "........"

translate english ch06_company02_6ea4ef2c:

    d "Um....."

translate english ch06_company02_554f7f40:

    d "The staff downstairs, uh..."

translate english ch06_company02_b0a73dc5:

    d "They asked me to tell you there are documents in the system waiting for your approval."

translate english ch06_company02_a797f6ce_1:

    d "............."

translate english ch06_company02_ad893dfa_1:

    d "......"

translate english ch06_company02_4ea41c50:

    d "**(Why isn't she responding?....)**"

translate english ch06_company02_c267750d:

    n "Despite his pounding heart, he carefully approached her."

translate english ch06_company02_c057b523:

    d "**(Damn, why do I feel like I'm committing a crime?)**"

translate english ch06_company02_219dc258:

    d "**(I feel like I've broken into someone's home. This is so uncomfortable..)**"

translate english ch06_company02_d8a59382:

    d "**(Why do I always end up looking like a burglar wherever I go???)**"

translate english ch06_company02_da0f37c7:

    n "Then he deliberately greeted her in a bright, cheerful voice."

translate english ch06_company02_0cd7c618:

    d "Hello!!"

translate english ch06_company02_c109c904:

    d "!!!!!!!!!!"

translate english ch06_company02_6fd41539:

    d "**(Holy shit!!!!)**"

translate english ch06_company02_21afcf4b:

    n "She was fast asleep with her top completely off."

translate english ch06_company02_2f8341e3:

    n "She didn't react to his greeting at all."

translate english ch06_company02_e272d1b7:

    d "**(Holy.....)**"

translate english ch06_company02_7c37ffb6:

    d "**(Oh my God......)**"

translate english ch06_company02_9ad40378:

    d "**(They're just as big as Amanda's...)**"

translate english ch06_company02_0411797d:

    d "**(......)**"

translate english ch06_company02_5a39178e:

    d "**(They're barely sagging at all for her age.)**"

translate english ch06_company02_4b2cb8d4:

    d "**(Did she have some work done??.......)**"

translate english ch06_company02_2921abdb:

    d "**(Did she fall asleep while unpacking?....)**"

translate english ch06_company02_0411797d_1:

    d "**(......)**"

translate english ch06_company02_c7f30644:

    d "**(She must've been absolutely exhausted...)**"

translate english ch06_company02_1a0059df:

    d "**(..............)**"

translate english ch06_company02_0bb56730:

    d "**(.....)**"

translate english ch06_company02_4620160e:

    d "**(Rose is just an ordinary middle-aged woman, too.....)**"

translate english ch06_company02_fb094e12:

    d "**(Does she work so hard that she ends up falling asleep like this?....)**"

translate english ch06_company02_0411797d_2:

    d "**(......)**"

translate english strings:
    old "로즈의 사진을 찍는다."
    new "Take a photo of Rose."

translate english ch06_company02_92f21ed5:

    n "What should I do?"

translate english ch06_company02_ff2086be:

    d "**(I think I could finally beat Jason with this...)**"

translate english ch06_company02_faadf1fa:

    d "**(Damn, but is it really okay to do this?.....)**"

translate english ch06_company02_0bb56730_1:

    d "**(.....)**"

translate english ch06_company02_5671df79:

    d "**(But I can't let this opportunity slip away...)**"

translate english ch06_company02_c7fc33b6:

    d "**(Fuck, my heart's about to explode.....)**"

translate english ch06_company02_c84044c5:

    d "**(Haaah......)**"

translate english ch06_company02_78f0e8ba:

    d "**(I'm ashamed of myself...)**"

translate english ch06_company02_fb4342b7:

    d "**(..........)**"

translate english ch06_company02_3dd9a8e8:

    d "**(My hands are shaking..)**"

translate english ch06_company02_7de29c99:

    d "**(Isn't this a crime??!!)**"

translate english ch06_company02_2490b6bb:

    d "**(........)**"

translate english ch06_company02_5a43fe74:

    d "**(But....)**"

translate english ch06_company02_f67692be:

    d "**(I... want to put them in my mouth....)**"

translate english ch06_company02_89aa4df8:

    d "**(Damn it!)**"

translate english ch06_company02_3ef0ac50:

    d "**(She radiates authority even when she's asleep...)**"

translate english ch06_company02_2bacb9ac:

    d "**(Oh, wait!!!!)**"

translate english ch06_company02_8c00a870:

    d "**(I'd have to wake her up to give her the message??!!)**"

translate english ch06_company02_e5c36b54:

    d "..........."

translate english ch06_company02_dc406f0a:

    d "**(Should I leave a note and head back downstairs??)**"

translate english ch06_company02_20592945:

    d "**(No, then the other employees will think I'm a freak.)**"

translate english ch06_company02_761dd0bf:

    d "**(I wouldn't even be able to explain what happened up here.....)**"

translate english ch06_company02_fba49089:

    d "**(But if I wake her up like this, she'll know I've seen her breasts, won't she??)**"

translate english ch06_company02_7151789c:

    d "**(Ah, fuck.....)**"

translate english ch06_company02_f7cc0648:

    d "**(I'm practically a kid compared to her. Would she even care??!!)**"

translate english ch06_company02_2e9c6444:

    d "**(.......)**"

translate english ch06_company02_974edd45:

    d "**(Or maybe not??... What if she accuses me of sexual harassment???)**"

translate english ch06_company02_c47b7d29:

    d "**(Ah, fuck it!!!)**"

translate english strings:
    old "그녀를 만져서 깨운다."
    new "Wake her up by touching her."

translate english ch06_company02_92f21ed5_1:

    n "What should I do?"

translate english ch06_company02_b4467bc7:

    d "**(Damn it, I want to touch her!!)**"

translate english ch06_company02_fa622541:

    d "**(No!!)**"

translate english ch06_company02_dc3066f7:

    d "**(One wrong move and I'll be a total outcast in my hometown.....)**"

translate english ch06_company02_3af9bd19:

    n "He gently placed his hand on Rose's shoulder."

translate english ch06_company02_cfd74902:

    n "Her skin was even softer than he'd expected."

translate english ch06_company02_108b9259:

    d "Excuse me, ma'am!!"

translate english ch06_company02_ad893dfa_2:

    d "......"

translate english ch06_company02_3b163a00:

    d "Rose!!!!!"

translate english ch06_company02_4f79f20d:

    r "Mmm.........."

translate english ch06_company02_b91598b1:

    r "........"

translate english ch06_company02_f09d2c6e:

    r "You???!!!!"

translate english ch06_company02_4a519a77:

    r "......"

translate english ch06_company02_e46dfe87:

    d "O-oh, hello, Rose."

translate english ch06_company02_3dc19c17:

    r "Oh my God........"

translate english ch06_company02_ad893dfa_3:

    d "......"

translate english ch06_company02_7773479e:

    r "How long have I been asleep here....."

translate english ch06_company02_6ea4ef2c_1:

    d "Um, well....."

translate english ch06_company02_1b875526:

    d "The staff downstairs asked me to tell you there are some documents waiting for your approval......"

translate english ch06_company02_7b6b0472:

    d "It sounds like they're urgent."

translate english ch06_company02_db097791:

    r "All right, understood."

translate english ch06_company02_82daa5da:

    r "Please go downstairs and tell them I'll take a look right away."

translate english ch06_company02_0d4d0ea7:

    d "Yes, ma'am."

translate english ch06_company02_f8b309d0:

    r "**(.........)**"

translate english ch06_company02_d2608bf8:

    r "**(What's that....)**"

translate english ch06_company02_2c2d5aa8:

    r "**(Is that a crease in his pants??)**"

translate english ch06_company02_1a0c3598:

    r "Ugh........"

translate english ch06_company02_099dbc73:

    r "I should've gotten some proper sleep in bed..."

translate english ch06_company02_736a79c7:

    r "What was I thinking....."

translate english ch06_company02_c7e63850:

    r "!!!!!!!!!!!!!!!!!!!!!"

translate english ch06_company02_565d921d:

    r "Oh my God!!!!!!"

translate english ch06_company02_83e9bba4:

    d "Yes????"

translate english ch06_company02_e5cb1470:

    r "**(Oh my God..)**"

translate english ch06_company02_e3935dc1:

    r "**(How could I not have noticed this?!!)**"

translate english ch06_company02_edbb7d05_1:

    d "........"

translate english ch06_company02_e0552c38:

    r "Tell them I'll approve the documents within five minutes."

translate english ch06_company02_4df80317:

    d "Yes, I'll let them know."

translate english ch06_company02_1050e967:

    r "Thank you."

translate english ch06_company02_1d8d26ca:

    d "You're welcome, haha."

translate english ch06_company02_7fcccb31:

    d "**(Damn it..)**"

translate english ch06_company02_6ec862b6:

    d "**(Did I screw up......)**"

translate english ch06_company02_42a83975:

    d "**(Should I have just told them Rose was sound asleep....)**"

translate english ch06_company02_3b4d6e78:

    r "What the hell is wrong with this wheel??"

translate english ch06_company02_6110dead:

    d "????"

translate english ch06_company02_3a8d520b:

    r "That's strange.."

translate english ch06_company02_09749c14:

    r "It was fine when I brought it up here..."

translate english ch06_company02_6219635f:

    r "Ugh, it's heavy."

translate english ch06_company02_438b51ff:

    d "I'll carry it for you!!"

translate english ch06_company02_db5a087b:

    d "Hup!!!"

translate english ch06_company02_ee8eeb3b:

    d "Ngh!!"

translate english ch06_company02_e5a3a825:

    r "!!!"

translate english ch06_company02_4a519a77_1:

    r "......"

translate english ch06_company02_b24f9e29:

    n "Without thinking, he hoisted the suitcase up with all his strength."

translate english ch06_company02_b81d9745:

    n "But it was so heavy he could barely hold it up."

translate english ch06_company02_236a4526:

    d "**(Damn it!!!)**"

translate english ch06_company02_a2a260b2:

    d "**(What the hell is in this thing, a bunch of rocks???)**"

translate english ch06_company02_a10f7e99:

    d "**(It's heavy as fuck!!)**"

translate english ch06_company02_31c932c7:

    r "Hahahaha!"

translate english ch06_company02_6ab0d26b:

    r "You lifted it like a weightlifter."

translate english ch06_company02_2f9db4f7:

    d "Oh... Y-yeah..."

translate english ch06_company02_99c4dc20:

    d "Haha."

translate english ch06_company02_ee85b2ca:

    r "Sorry about that."

translate english ch06_company02_d6e91068:

    r "Could you put it down here?"

translate english ch06_company02_287db98d:

    d "Hup!!!!!!!"

translate english ch06_company02_b6e19d3e:

    r "...."

translate english ch06_company02_1050e967_1:

    r "Thank you."

translate english ch06_company02_1d8d26ca_1:

    d "No problem, haha."

translate english ch06_company02_4a519a77_2:

    r "......"

translate english ch06_company02_d7103fd0:

    d "I'll head back downstairs now."

translate english ch06_company02_b45a5a06:

    r "Wait a moment!"

translate english ch06_company02_9f384fb4:

    d "Yes??"

translate english ch06_company02_85577e09:

    n "As he turned around, she slowly approached him."

translate english ch06_company02_315f9b94:

    n "Then she reached for his tie."

translate english ch06_company02_b4e0901a:

    r "Your tie is crooked."

translate english ch06_company02_4bb59dbf:

    d "What??!!"

translate english ch06_company02_13a88aa4:

    d "Oh... My tie..."

translate english ch06_company02_60915de0:

    r "......."

translate english ch06_company02_bb3b94be:

    r "That's not how you're supposed to tie a necktie."

translate english ch06_company02_a99a4170:

    d "Oh, haha."

translate english ch06_company02_d41709db:

    d "I managed to get it right last night, haha."

translate english ch06_company02_b58da02e:

    r "You looked rather frail, but you're stronger than I expected."

translate english ch06_company02_bf77650d:

    d "Th-thank you."

translate english ch06_company02_4a519a77_3:

    r "......"

translate english ch06_company02_2b3c6b42:

    r "Even a slender man is in a completely different league from a woman when it comes to strength."

translate english ch06_company02_07e1fb9b:

    r "..........."

translate english ch06_company02_5d26c596:

    r "Sometimes men really do seem like a different species.."

translate english ch06_company02_2d9d5996:

    r "........."

translate english ch06_company02_13724a71:

    r "There."

translate english ch06_company02_401fc06f:

    r "You can go downstairs now."

translate english ch06_company02_eb2e7537:

    r "Good work."

translate english ch06_company02_0d4d0ea7_1:

    d "Yes, ma'am."

translate english ch06_company02_bd51e682:

    d "**(Phew..........)**"

translate english ch06_company02_0dd6c758:

    d "**(Man, I feel like I've just come back from outer space....)**"

translate english ch06_company02_edbb7d05_2:

    d "........"

translate english ch06_company02_fb8cc993:

    d "**(The pressure is unreal.....)**"

translate english ch06_company02_e8e9a959:

    d "**(What kind of man could possibly keep a woman like that under control?..)**"

translate english ch06_company02_e837c4d3:

    d "**(Could anyone actually make a woman like Rose submit?....)**"

translate english ch06_company02_98169206:

    d "**(So, making her do whatever I want??.......)**"

translate english ch06_company02_7f057461:

    d "**(Damn.......)**"

translate english ch06_company02_7dfcdd87:

    d "**(Just thinking about it drives me crazy....)**"

translate english ch06_company02_d2ea491f:

    r "Coffee, coffee, coffee.."

translate english ch06_company02_95840cb0:

    r "No matter how urgent things are, I need my coffee first.."

translate english ch06_hhouse01_20ba81d6:

    d "**(It's been three days since I started working here..)**"

translate english ch06_hhouse01_9b258624:

    d "**(Well, technically, I'm still just studying the company manual...)**"

translate english ch06_hhouse01_f0644808:

    d "**(Everyone's been really nice to me.)**"

translate english ch06_hhouse01_2490b6bb:

    d "**(........)**"

translate english ch06_hhouse01_9dd5827a:

    d "**(Hmm.... It's a little different from what I imagined working in an office would be like.)**"

translate english ch06_hhouse01_514a06ae:

    d "**(Maybe it's because this is a small-town company?)**"

translate english ch06_hhouse01_f04df2a4:

    d "**(Or maybe because there aren't many employees, the atmosphere isn't all that strict.)**"

translate english ch06_hhouse01_467daeaa:

    d "**(I heard the branch offices in bigger cities have a lot more people, but this place feels like a small, close-knit team.)**"

translate english ch06_hhouse01_7d40bbc4:

    d "**(I imagined people constantly making phone calls, shouting, and rushing around...)**"

translate english ch06_hhouse01_14e3d57c:

    d "**(But actually, I think this suits me better.)**"

translate english ch06_hhouse01_4b912820:

    d "**(I'm only scheduled to work three days a week.)**"

translate english ch06_hhouse01_ab3e7938:

    d "**(And apparently, I'll still get my regular pay.)**"

translate english ch06_hhouse01_ee7e2893:

    d "**(Rose arranged it that way so I'd have time for other activities as a college student.)**"

translate english ch06_hhouse01_20b34b79:

    d "**(I'm not sure whether that's a good thing for me or not, though.)**"

translate english ch06_hhouse01_5b7b09d6:

    d "**(Hmm....)**"

translate english ch06_hhouse01_5ace885b:

    d "**(Anyway, starting tomorrow, I've got a few days off.)**"

translate english ch06_hhouse01_bb31e635:

    d "**(And then there's Vivian....)**"

translate english ch06_hhouse01_6e1aa50d:

    d "**(She's a little cold, but sometimes she looks after me like I'm her little brother.)**"

translate english ch06_hhouse01_8aea8e83:

    d "**(Whenever I look at her..)**"

translate english ch06_hhouse01_032b5e0f:

    d "**(She strikes me as someone who's really got her life together....)**"

translate english ch06_hhouse01_2b5b27b8:

    d "**(How should I put it....)**"

translate english ch06_hhouse01_94d6a1fd:

    d "**(She's on a completely different level of maturity compared to college students....)**"

translate english ch06_hhouse01_7c3543a9:

    d "Anyway, it's not like I'm doing anything particularly impressive, but..."

translate english ch06_hhouse01_92b28647:

    d "So this is what freedom feels like!!!!!!"

translate english ch06_hhouse01_2ad3c34a:

    d "I can't help smiling, hahaha."

translate english ch06_hhouse01_b45ae0cf:

    d "!!!"

translate english ch06_hhouse01_40ffa0c2:

    d "Oh... Lena's here."

translate english ch06_hhouse01_64a9b43b:

    d "Huh??"

translate english ch06_hhouse01_203cc60b:

    d "......."

translate english ch06_hhouse01_2c60e870:

    d "That's the smell of meat!!"

translate english ch06_hhouse01_f87be26c:

    d "Is [h_name] grilling something?"

translate english ch06_hhouse01_cac65952:

    h "No, I'm telling you, I really don't remember."

translate english ch06_hhouse01_de19cc10:

    h "Of all things, that guy ordered my favorite drink."

translate english ch06_hhouse01_cf1be009:

    h "So I just kept knocking them back until I was completely wasted, haha."

translate english ch06_hhouse01_4551f106:

    l "So you basically drank yourself into that state, hahaha."

translate english ch06_hhouse01_35562e2d:

    l "I thought that guy had been hitting on you."

translate english ch06_hhouse01_8bcb77a8:

    d "Hey, hahaha."

translate english ch06_hhouse01_88047fc7:

    d "Something smells really good! Hahaha."

translate english ch06_hhouse01_6c9498a6:

    h "Just getting home from work?"

translate english ch06_hhouse01_ae6f2a7c:

    d "Yeah, I just got back."

translate english ch06_hhouse01_08872a07:

    h "Good thing you got here right on time."

translate english ch06_hhouse01_a47d07a5:

    d "Hahaha."

translate english ch06_hhouse01_998240b7:

    d "The smell of grilled meat practically dragged me over here."

translate english ch06_hhouse01_a254b6d4:

    d "!!!!!"

translate english ch06_hhouse01_6cacf8a8:

    l "Welcome home, big boy."

translate english ch06_hhouse01_2ca9f303:

    l "We've been seeing a lot of each other lately, haven't we?"

translate english ch06_hhouse01_6fa08a07:

    l "......."

translate english ch06_hhouse01_1982cff6:

    d "Oh... Hi, Lena."

translate english ch06_hhouse01_a67c1a9a:

    l "What? Why do you look so shocked to see me? That's kind of insulting."

translate english ch06_hhouse01_71faf9be:

    d "Huh? N-no, it's not that."

translate english ch06_hhouse01_bc0faa19:

    d "I'm s-sorry if I was rude."

translate english ch06_hhouse01_a5bade0a:

    h "We're having dinner out here tonight, nice and casual."

translate english ch06_hhouse01_531d5a57:

    h "Just a little party, haha."

translate english ch06_hhouse01_02f08e1d:

    h "Welcome to the ladies' barbecue joint, open for one night only! Hahaha."

translate english ch06_hhouse01_c99eb045:

    h "Go change into something comfortable and come back down."

translate english ch06_hhouse01_15734c04:

    d "Okay, got it."

translate english ch06_hhouse01_2649edce:

    l "You hear that?"

translate english ch06_hhouse01_79958677:

    l "She said wear something comfortable. Comfortable."

translate english ch06_hhouse01_9e69a7bd:

    l "You can even come down stark naked."

translate english ch06_hhouse01_193987c1:

    l "With your cock swinging around and everything."

translate english ch06_hhouse01_0d4d0ea7:

    d "Okay, got it."

translate english ch06_hhouse01_8bd19dac:

    d "I'll be right back."

translate english ch06_hhouse01_37e17dff:

    d "My mouth's already watering, hahaha."

translate english ch06_hhouse01_9d21a59d:

    l "Save that drooling for somewhere else."

translate english ch06_hhouse01_217bfd56:

    h "Lena..."

translate english ch06_hhouse01_ace2a1c5:

    h "Be nice to him."

translate english ch06_hhouse01_bb4770de:

    h "He's a genuinely good kid. You don't meet many like him."

translate english ch06_hhouse01_dd2aca4d:

    l "Hahaha, really?"

translate english ch06_hhouse01_d453203f:

    l "A genuinely good kid?"

translate english ch06_hhouse01_80cbb9e5:

    l "Are you sure he's such a good kid? Hahaha."

translate english ch06_hhouse01_d3ace596:

    l "Aha!!"

translate english ch06_hhouse01_338ddaf4:

    l "Well, I guess he does seem like a good boy."

translate english ch06_hhouse01_ef03a737:

    l "I bet he's really good at doing what women tell him."

translate english ch06_hhouse01_4e84757e:

    l "He's exactly the type older women would love."

translate english ch06_hhouse01_51cfbc87:

    l "You know the type, right?"

translate english ch06_hhouse01_15fc0875:

    l "A rich lady's little boy toy."

translate english ch06_hhouse01_05e31f70:

    h "Oh, don't say things like that..."

translate english ch06_hhouse01_b1b49694:

    n "The three of them spent a wonderful evening together in the backyard."

translate english ch06_hhouse01_5b0a4e67:

    n "As they ate, laughed, and talked, they got to know each other better and gradually grew closer."

translate english ch06_hhouse01_54e095bd:

    n "And the kiss a few days earlier had clearly made [h_name] feel closer to him."

translate english ch06_hhouse01_9800fa52:

    n "Just as [d_name] had hoped, he was gradually finding his way into their world."

translate english ch06_hhouse01_846f1577:

    l "........"

translate english ch06_hhouse01_c2ac2761:

    l "**(That little bastard's acting like nothing ever happened.)**"

translate english ch06_hhouse01_3ed3be18:

    l "**(Back in my day, when people did something like that, they at least showed some responsibility.)**"

translate english ch06_hhouse01_8aa739a0:

    l "**(.........)**"

translate english ch06_hhouse01_0bc22f5b:

    l "**(I may have started it, but you were the one enjoying it in the end, you little shit!!!)**"

translate english ch06_hhouse01_734ad6b8:

    l "**(Young guys really are clueless...)**"

translate english ch06_hhouse01_48c517fc:

    l "**(Or is that just how kids behave these days?)**"

translate english ch06_hhouse01_52f7c15f:

    h "So, how's work been these past few days?"

translate english ch06_hhouse01_0e85d5e3:

    h "Getting the hang of it?"

translate english ch06_hhouse01_81007f3c:

    d "Yeah, so far, so good."

translate english ch06_hhouse01_efca69fa:

    d "I'm just an intern, so I'm still studying the company manual."

translate english ch06_hhouse01_a791e950:

    h "Ah, I see."

translate english ch06_hhouse01_74f32242:

    h "That makes sense."

translate english ch06_hhouse01_cf24eb78:

    h "Do the people there seem nice?"

translate english ch06_hhouse01_d70c2a19:

    d "Yeah, everyone's been really friendly."

translate english ch06_hhouse01_d53fb227:

    d "Well... so far, at least, haha."

translate english ch06_hhouse01_4daa3f11:

    l "Ugh, it's hot again today."

translate english ch06_hhouse01_ccbc9cae:

    l "I'm all sticky.."

translate english ch06_hhouse01_451720b0:

    h "Right?"

translate english ch06_hhouse01_3d030335:

    h "I'm feeling really sticky, too."

translate english ch06_hhouse01_66999df4:

    h "And grilling meat in this heat makes it even worse."

translate english ch06_hhouse01_9c9ff00d:

    d "!!!!!!!!!"

translate english ch06_hhouse01_337813ab:

    d "**(Holy shit..)**"

translate english ch06_hhouse01_2e18bf72:

    h "Oh my God, Lena!!"

translate english ch06_hhouse01_c468dd9f:

    h "What are you doing in front of [d_name]??"

translate english ch06_hhouse01_90ea85cb:

    l "Ah, sweet freedom."

translate english ch06_hhouse01_e54abf9f:

    l "That feels so good, ah~~"

translate english ch06_hhouse01_8b35dee2:

    l "You should just take yours off, too."

translate english ch06_hhouse01_239441a2:

    h "What??"

translate english ch06_hhouse01_9ad04de7:

    l "What do you mean, what?"

translate english ch06_hhouse01_41c8c721:

    l "Who are we trying to impress here?"

translate english ch06_hhouse01_5573507f:

    l "Keep that on, and you'll be the one getting grilled instead of the meat."

translate english ch06_hhouse01_4338f07b:

    h "..........."

translate english ch06_hhouse01_36027c2e:

    n "[h_name] hesitated for a moment."

translate english ch06_hhouse01_216985d8:

    n "Then she remembered that she'd already shown him her bare breasts a few days earlier."

translate english ch06_hhouse01_467c82f1:

    h "Screw it! I'm taking mine off, too, Lena."

translate english ch06_hhouse01_23cf3847:

    h "I'm the owner of this house, so I can do whatever I want!!"

translate english ch06_hhouse01_8ca91381:

    l "Haha."

translate english ch06_hhouse01_9465d339:

    l "Come on, show me~"

translate english ch06_hhouse01_bb920e29:

    d "!!!!!!!"

translate english ch06_hhouse01_6dac308a:

    d "**(Wow, everyone's getting bold, huh??)**"

translate english ch06_hhouse01_618d3bc9:

    d "**(Maybe eating meat brings out their primal instincts? Haha.)**"

translate english ch06_hhouse01_5e3aec4e:

    d ".........."

translate english ch06_hhouse01_7c37ffb6:

    d "**(Oh my God......)**"

translate english ch06_hhouse01_e97bca4e:

    d "**(I wonder how Jason would react if he saw this....)**"

translate english ch06_hhouse01_f20f9761:

    d "**(He'd probably insist on moving into this house immediately, wouldn't he?)**"

translate english ch06_hhouse01_5e3aec4e_1:

    d ".........."

translate english ch06_hhouse01_106b7e72:

    h "Haaah...... That feels refreshing."

translate english ch06_hhouse01_87319490:

    d "**(Damn......)**"

translate english ch06_hhouse01_b0af7376:

    d "**(Two pairs of boobs...)**"

translate english ch06_hhouse01_2c63c595:

    d "**(This is the kind of thing you only see in movies....)**"

translate english ch06_hhouse01_8b571770:

    d "**(And usually, the next scene in those movies is everyone fucking like crazy....)**"

translate english ch06_hhouse01_7fdcaed5:

    d "**(Yeah.)**"

translate english ch06_hhouse01_9d6fd461:

    d "**(One guy and two women. That's a perfect setup for a porno, hahaha.)**"

translate english ch06_hhouse01_8b420275:

    l "Hehe."

translate english ch06_hhouse01_5d1942f7:

    h "!!!!"

translate english ch06_hhouse01_47f197da:

    h "What are you doing.."

translate english ch06_hhouse01_bd3d3ed3:

    h "Ugh, you're all sticky, haha."

translate english ch06_hhouse01_e69ed45d:

    h "Haha, sorry about that."

translate english ch06_hhouse01_5e877d3b:

    h "We're acting like a couple of shameless old ladies."

translate english ch06_hhouse01_8f64ed58:

    d "O-oh, not at all, haha."

translate english ch06_hhouse01_8d5d2eb8:

    h "Lena and I have a rather unusual relationship, haha."

translate english ch06_hhouse01_638fce14:

    d "O-oh, it's fine, haha."

translate english ch06_hhouse01_642e8006:

    d "Don't mind me."

translate english ch06_hhouse01_cf0b0ced:

    d "**(Yes, please don't mind me at all!!!!!)**"

translate english ch06_hhouse01_337813ab_1:

    d "**(Holy shit..)**"

translate english ch06_hhouse01_769def4e:

    n "Without paying him any attention, the two women kissed, their tongues meeting."

translate english ch06_hhouse01_f02fa6e4:

    n "Watching two middle-aged women passionately kiss right in front of him was quite a sight."

translate english ch06_hhouse01_5b62e8a4:

    n "The wet sounds of their kissing only heightened his arousal."

translate english ch06_hhouse01_2e9c6444:

    d "**(.......)**"

translate english ch06_hhouse01_dde68ee5:

    d "**(It feels like I'm watching porn....)**"

translate english ch06_hhouse01_75420788:

    d "**(Are they really that comfortable around me now??)**"

translate english ch06_hhouse01_bae55cd3:

    d "**(I'm not sure if that's a good thing or a bad thing for me....)**"

translate english ch06_hhouse01_2641c928:

    d "**(Damn, Lena....)**"

translate english ch06_hhouse01_ab320532:

    d "**(What if Lena really is a witch???....)**"

translate english ch06_hhouse01_0f8519ac:

    d "**(I don't even know if she's married, has kids, what she does for a living, or where she lives...)**"

translate english ch06_hhouse01_824a5674:

    d "**(I know absolutely nothing about her.)**"

translate english ch06_hhouse01_aa34b01a:

    h "!!"

translate english ch06_hhouse01_521da0a6:

    h "Lena, this is a little....."

translate english ch06_hhouse01_701bdc65:

    l "Shh!"

translate english ch06_hhouse01_ffab90f4:

    d "**(This is insane.....)**"

translate english ch06_hhouse01_6226c238:

    h "Oh, I'm sorry, haha."

translate english ch06_hhouse01_e7caee4d:

    h "This is getting ridiculous."

translate english ch06_hhouse01_cac127c0:

    h "Look at me, behaving like this in front of my tenant.."

translate english ch06_hhouse01_7ab39cb0:

    d "!!!!"

translate english ch06_hhouse01_80e9aefa:

    n "Lena, completely unconcerned, stripped naked."

translate english ch06_hhouse01_8c106d68:

    n "Then she headed straight for the hot tub."

translate english ch06_hhouse01_2cee7eb4:

    n "She moved as though she were showing off her figure."

translate english ch06_hhouse01_99872e72:

    n "To both the landlady and the tenant of this house."

translate english ch06_hhouse01_ed85f0f3:

    l "Hmm......"

translate english ch06_hhouse01_b8208332:

    l "Ah~~~"

translate english ch06_hhouse01_07eb53f2:

    l "That feels amazing~~"

translate english ch06_hhouse01_c1c0e44b:

    d "**(Ooooh.........)**"

translate english ch06_hhouse01_fbb2eb9e:

    d "**(Even the landlady!!!!!!!)**"

translate english ch06_hhouse02_a0093ed2:

    l "Hey, kid!"

translate english ch06_hhouse02_9f384fb4:

    d "Yes??"

translate english ch06_hhouse02_f68c76d4:

    l "Bring us our glasses."

translate english ch06_hhouse02_b5557dd6:

    d "O-okay."

translate english ch06_hhouse02_3b176801:

    h "Haha."

translate english ch06_hhouse02_5624561a:

    h "Come on in, [d_name]."

translate english ch06_hhouse02_e4ccb8ce:

    l "Yeah, hurry up and get in here, too."

translate english ch06_hhouse02_9c61f265:

    d "Okay, I'm coming."

translate english ch06_hhouse02_1ea53901:

    d "Here you go."

translate english ch06_hhouse02_8cb579b6:

    l "Hey, what are you doing?!"

translate english ch06_hhouse02_670bffba:

    h "Thank you."

translate english ch06_hhouse02_f220c716:

    l "You're supposed to take everything off before getting in."

translate english ch06_hhouse02_5b5357a9:

    l "You really have no manners, kid."

translate english ch06_hhouse02_c3f32304:

    l "Don't you know how many germs there are on people's clothes??"

translate english ch06_hhouse02_4bb59dbf:

    d "What??!!"

translate english ch06_hhouse02_91fccbec:

    d "Oh... I'm sorry."

translate english ch06_hhouse02_29e302a9:

    d "I-I'll take them off."

translate english ch06_hhouse02_7caf97d7:

    h "............."

translate english ch06_hhouse02_42a124e3:

    h "**(Oh my God......)**"

translate english ch06_hhouse02_935e9eec:

    h "**(This will be the second time since that studio shoot.....)**"

translate english ch06_hhouse02_b3a7806d:

    l "**(Come on, show me that magnificent cock of yours, haha.)**"

translate english ch06_hhouse02_8aa739a0:

    l "**(.........)**"

translate english ch06_hhouse02_3a7eaab6:

    l "**(Even when I set everything up for him, he's still so clueless...)**"

translate english ch06_hhouse02_b6b5e2b2:

    n "He stood naked in front of the two women."

translate english ch06_hhouse02_12ffece4:

    n "Before sitting down, he deliberately stood there for a moment, exposing his cock to them."

translate english ch06_hhouse02_71405e3e:

    h "**(I was fine at the studio, so why am I embarrassed now?.....)**"

translate english ch06_hhouse02_92ad9932:

    h "............"

translate english ch06_hhouse02_c9aab884:

    h "Ahem...."

translate english ch06_hhouse02_f7e0749d:

    l "**(Damn it..)**"

translate english ch06_hhouse02_9bbb3c77:

    l "**(Even seeing it again gets me excited...)**"

translate english ch06_hhouse02_2320bc87:

    d "You know something?"

translate english ch06_hhouse02_ed1d4791:

    h "??"

translate english ch06_hhouse02_d13c0f5a:

    l "Know what?"

translate english ch06_hhouse02_95b12bf9:

    d "This is actually my first time ever getting into a hot tub, haha."

translate english ch06_hhouse02_919ebcdf:

    l "What? Seriously?"

translate english ch06_hhouse02_c2b79ed8:

    d "Yeah, haha."

translate english ch06_hhouse02_fd617455:

    d "It feels different being in warm water outdoors, haha."

translate english ch06_hhouse02_8e44d9cb:

    h "........"

translate english ch06_hhouse02_1ed21e4e:

    l "Oh my God."

translate english ch06_hhouse02_be2f6f2b:

    l "He says it's his first time!"

translate english ch06_hhouse02_10ab437f:

    l "What, isn't access to the hot tub included in the rent he pays you??"

translate english ch06_hhouse02_ebc6a366:

    l "You need to take better care of this poor boy, [h_name]."

translate english ch06_hhouse02_4b3b1d96:

    l "He's really bringing out my maternal instincts!"

translate english ch06_hhouse02_3b176801_1:

    h "Haha."

translate english ch06_hhouse02_42582aeb:

    h "I may not be perfect, but I do take good care of him."

translate english ch06_hhouse02_85c2f5f5:

    h "Don't you know me by now?"

translate english ch06_hhouse02_94b46b88:

    l "Hahaha."

translate english ch06_hhouse02_c18b72ca:

    l "I never would've dreamed that guy was [d_name]."

translate english ch06_hhouse02_412008dd:

    l "Pulling out a camera and filming me on the bus like that."

translate english ch06_hhouse02_2bf61f33:

    d "Hahaha."

translate english ch06_hhouse02_d373f249:

    l "Come on, be honest with me."

translate english ch06_hhouse02_d6974442:

    l "You jerked off looking at my pictures, didn't you? Huh?"

translate english ch06_hhouse02_b7c536dd:

    l "You passed them around to your friends, too, didn't you?"

translate english ch06_hhouse02_8ffb4b0d:

    l "Did you or didn't you?"

translate english ch06_hhouse02_a47d07a5:

    d "Hahaha."

translate english ch06_hhouse02_7db721f7:

    d "That's a secret."

translate english ch06_hhouse02_7f50148c:

    d "Maybe I jerked off to them, maybe I didn't, hahaha."

translate english ch06_hhouse02_e398ffb9:

    l "You little pervert."

translate english ch06_hhouse02_bb381f0a:

    h "You're the pervert, Lena."

translate english ch06_hhouse02_fb85c594:

    h "He didn't do anything wrong."

translate english ch06_hhouse02_ad39c158:

    h "What kind of crazy woman takes her clothes off in the street?"

translate english ch06_hhouse02_c054df4d:

    h "Are you some kind of cavewoman?"

translate english ch06_hhouse02_babae156:

    l "Hahaha."

translate english ch06_hhouse02_6370ed94:

    l "........."

translate english ch06_hhouse02_e44891df:

    l "You don't have a girlfriend, do you?"

translate english ch06_hhouse02_99f0260c:

    d "No, I don't."

translate english ch06_hhouse02_cf0a2b4b:

    l "I knew it."

translate english ch06_hhouse02_b0c17738:

    l "No way a clueless guy like you could have a girlfriend."

translate english ch06_hhouse02_ad893dfa:

    d "......"

translate english ch06_hhouse02_314af17c:

    d "Well, actually, I did have one, but we broke up halfway through the semester."

translate english ch06_hhouse02_1dec75c4:

    l "Which means you don't have one now!!"

translate english ch06_hhouse02_217bfd56:

    h "Lena..."

translate english ch06_hhouse02_96de9146:

    h "Would you please leave him alone..."

translate english ch06_hhouse02_82489067:

    l "Poor thing."

translate english ch06_hhouse02_de401d9a:

    l "Such a shame, especially at your age, with all those hormones raging, haha."

translate english ch06_hhouse02_846f1577:

    l "........"

translate english ch06_hhouse02_920b0b0c:

    l "You must want to have sex every single day, huh? Hahaha."

translate english ch06_hhouse02_14497b87:

    h "Lena, please..."

translate english ch06_hhouse02_322c8d4a:

    d "W-well, yeah... Haha."

translate english ch06_hhouse02_6d244a6e:

    d "Sex...."

translate english ch06_hhouse02_0beeac88:

    d "**(Damn.....)**"

translate english ch06_hhouse02_1b024670:

    d "**(I haven't even had a drink, but I feel drunk..)**"

translate english ch06_hhouse02_fac8215b:

    d "............"

translate english ch06_hhouse02_0989f89b:

    h "You know something, Lena?"

translate english ch06_hhouse02_c81a6238:

    l "What?"

translate english ch06_hhouse02_c0aefff6:

    h "I kissed him the other day."

translate english ch06_hhouse02_f3e14c5a:

    l "??"

translate english ch06_hhouse02_d00b85ca:

    l "What??"

translate english ch06_hhouse02_1f822b22:

    l "You kissed this guy?"

translate english ch06_hhouse02_28c2d196:

    h "Mm-hmm."

translate english ch06_hhouse02_d62b3d42:

    l "How?"

translate english ch06_hhouse02_826208d2:

    l "I mean..."

translate english ch06_hhouse02_61e6c190:

    l "How did that happen?"

translate english ch06_hhouse02_5ecb6b16:

    h "Haha, I don't know."

translate english ch06_hhouse02_40c1a64a:

    h "It just kind of happened.."

translate english ch06_hhouse02_8b14a2c3:

    h "I guess you could call it a morning greeting? Haha."

translate english ch06_hhouse02_d5fee928:

    l "A morning greeting??"

translate english ch06_hhouse02_9ea82b0d:

    l "What the hell does that mean??"

translate english ch06_hhouse02_ebd6cb89:

    l "Since when do landladies kiss their tenants good morning?"

translate english ch06_hhouse02_06a0696b:

    l "Don't tell me you two slept together??!!"

translate english ch06_hhouse02_5b2c283d:

    h "Oh, stop talking crazy, Lena."

translate english ch06_hhouse02_381e84a3:

    h "Who said anything about sleeping together?"

translate english ch06_hhouse02_b5eab9e2:

    h "It was just a little incident between an older woman and her tenant."

translate english ch06_hhouse02_6ff86ce3:

    h "Like a little game of playing house."

translate english ch06_hhouse02_409858ee:

    l "Pfft!"

translate english ch06_hhouse02_33e9bd92:

    l "I can already picture it."

translate english ch06_hhouse02_beed8290:

    l "I bet you were both all shy and awkward, blushing like crazy."

translate english ch06_hhouse02_8dc3d5e8:

    h "We were not!"

translate english ch06_hhouse02_728be272:

    l "Did kissing a young college guy make you feel like you were back in college again?? Huh??"

translate english ch06_hhouse02_a75992a4:

    h "I shouldn't have said anything.."

translate english ch06_hhouse02_a0bc4003:

    h "I was just wishing him luck on his first day of work."

translate english ch06_hhouse02_29d81ce4:

    l "............"

translate english ch06_hhouse02_db259995:

    l "**(Come to think of it, I haven't even kissed this kid..)**"

translate english ch06_hhouse02_3226db5f:

    l "**(Not that I particularly wanted to kiss a little guy like him.....)**"

translate english ch06_hhouse02_a2fe362b:

    l "**(All I needed was that cock of his, anyway.)**"

translate english ch06_hhouse02_8aa739a0_1:

    l "**(.........)**"

translate english ch06_hhouse02_3c7efc12:

    l "**(Wait, does [h_name] actually have feelings for him????)**"

translate english ch06_hhouse02_ede550a1:

    l "**(Holy shit.......)**"

translate english ch06_hhouse02_b6c07206:

    l "**(Has she gotten attached to him already?? Not just sexually attracted to him???)**"

translate english ch06_hhouse02_18019da2:

    n "Lena paused for a moment, lost in thought."

translate english ch06_hhouse02_9ba51628:

    n "Then, as if she'd reached some kind of conclusion, she spoke."

translate english ch06_hhouse02_8fdba437:

    l "Come sit a little closer."

translate english ch06_hhouse02_8096b08a:

    d "Huh?"

translate english ch06_hhouse02_77867687:

    l "Don't sit over there by yourself. Go sit next to her."

translate english ch06_hhouse02_b4c090e1:

    l "You're distracting me, sitting there like that."

translate english ch06_hhouse02_e5c36b54:

    d "..........."

translate english ch06_hhouse02_33bf8f25:

    d "Okay, got it."

translate english ch06_hhouse02_9fa34c5e:

    n "He paused once again, deliberately exposing his cock to both women."

translate english ch06_hhouse02_ad4eaca6:

    n "Both [h_name] and Lena immediately understood what he was trying to do."

translate english ch06_hhouse02_bd56de61:

    d "**(Being this close to Lena keeps reminding me of what happened a few days ago.. Haha.)**"

translate english ch06_hhouse02_45206535:

    d "**(I wonder if I'll get another chance tonight?...)**"

translate english ch06_hhouse02_35005b35:

    l "No, you idiot. I meant sit next to [h_name]."

translate english ch06_hhouse02_65f3c9ac:

    d "Oh... Okay..."

translate english ch06_hhouse02_b3037d4b:

    d "I thought you meant I should sit next to you, Lena..."

translate english ch06_hhouse02_91ff9e46:

    h "**(Holy.....)**"

translate english ch06_hhouse02_8bc563d1:

    l "**(Yes... Just like that....)**"

translate english ch06_hhouse02_92f3b84f:

    l "**(Keep showing her that thing of yours.)**"

translate english ch06_hhouse02_5a586d43:

    n "He carefully sat down beside the landlady."

translate english ch06_hhouse02_c8d4444a:

    n "They had talked face-to-face many times before, but this was the first time they'd sat shoulder to shoulder like this."

translate english ch06_hhouse02_62a2b661:

    n "And now that all three were naked, the sexual tension between them began to rise."

translate english ch06_hhouse02_4338f07b:

    h "..........."

translate english ch06_hhouse02_7b86c36f:

    h "Hahaha."

translate english ch06_hhouse02_e10bcbba:

    h "You're looking at me like you're really worried."

translate english ch06_hhouse02_9f384fb4_1:

    d "Huh??"

translate english ch06_hhouse02_ca874abb:

    h "Don't worry."

translate english ch06_hhouse02_5cdb633e:

    h "I'm only having a little drink tonight, just enough to feel good."

translate english ch06_hhouse02_4d159096:

    h "You won't have to carry me in that weird position again tonight, hahaha."

translate english ch06_hhouse02_9d5f5d41:

    d "Oh, it's fine."

translate english ch06_hhouse02_7586f526:

    d "Don't worry about me, haha."

translate english ch06_hhouse02_846f1577_1:

    l "........"

translate english ch06_hhouse02_1708e739:

    d "You can relax and enjoy your drinks. I'm here, after all."

translate english ch06_hhouse02_97f13c2a:

    l "What's with that cheesy line, kid?"

translate english ch06_hhouse02_94c56789:

    l "Are you hitting on my girlfriend right now??"

translate english ch06_hhouse02_568f96bb:

    l "[h_name]."

translate english ch06_hhouse02_e6078263:

    h "Yeah?"

translate english ch06_hhouse02_fe341ef5:

    l "Look at that poor little guy."

translate english ch06_hhouse02_dcbdd965:

    l "He's practically dying to kiss you right now."

translate english ch06_hhouse02_1af4f089:

    h "Oh, stop saying things like that.."

translate english ch06_hhouse02_03677785:

    l "Since when did you get so uptight?"

translate english ch06_hhouse02_cc775ecd:

    l "Just look at his face."

translate english ch06_hhouse02_8e44d9cb_1:

    h "........"

translate english ch06_hhouse02_631f10ec:

    l "Why are you being so cold to him tonight, huh??"

translate english ch06_hhouse02_66c1a53f:

    l "He's practically dying of loneliness."

translate english ch06_hhouse02_d58de573:

    h "Well, what am I supposed to do about him being lonely?"

translate english ch06_hhouse02_0b06c55f:

    d "O-oh, it's not exactly like that...."

translate english ch06_hhouse02_8e44d9cb_2:

    h "........"

translate english ch06_hhouse02_91adc9fe:

    h "You...."

translate english ch06_hhouse02_9fd376a9:

    h "...."

translate english ch06_hhouse02_edbb7d05:

    d "........"

translate english ch06_hhouse02_3e678540:

    h "Are you lonely?"

translate english ch06_hhouse02_9f384fb4_2:

    d "Huh??"

translate english ch06_hhouse02_5d5b09ba:

    h "Do you feel lonely?"

translate english ch06_hhouse02_e946d84e:

    n "[h_name]'s unexpected question made him hesitate for a moment."

translate english ch06_hhouse02_edbb7d05_1:

    d "........"

translate english ch06_hhouse02_eba828d5:

    n "Her gentle voice stirred something deep inside his heart."

translate english ch06_hhouse02_97217b61:

    d "A... A little, hehe.."

translate english ch06_hhouse02_8e44d9cb_3:

    h "........"

translate english ch06_hhouse02_8e44d9cb_4:

    h "........"

translate english ch06_hhouse02_090a4622:

    h "You feel lonely even though you're living with me?"

translate english ch06_hhouse02_62b268ed:

    d "No, that's not what I mean...."

translate english ch06_hhouse02_3e0b909d:

    d "How should I put it....."

translate english ch06_hhouse02_8e44d9cb_5:

    h "........"

translate english ch06_hhouse02_8921cf82:

    d "It's a little different from that...."

translate english ch06_hhouse02_c2f581d3:

    d "Well, you know what I mean, haha."

translate english ch06_hhouse02_c2474b94:

    d "My family situation and all that..."

translate english ch06_hhouse02_8e44d9cb_6:

    h "........"

translate english ch06_hhouse02_7cb75b6e:

    d "But I guess everyone goes through things like that, right? Haha."

translate english ch06_hhouse02_218de310:

    d "What I'm trying to say is..."

translate english ch06_hhouse02_859fe774:

    d "Everyone has some kind of emptiness inside them."

translate english ch06_hhouse02_9b04f6e9:

    d "I mean...."

translate english ch06_hhouse02_00cb77f5:

    d "Because of the way I grew up, I think I tend to get a little too attached to people."

translate english ch06_hhouse02_63bf8708:

    d "Or, more specifically, I think I crave approval and attention from older women."

translate english ch06_hhouse02_fab07b13:

    d "Women like you and Lena, [h_name]......"

translate english ch06_hhouse02_8e44d9cb_7:

    h "........"

translate english ch06_hhouse02_b809e4ae:

    l "**(That was a good one, kid.)**"

translate english ch06_hhouse02_b8a64fff:

    l "**(If you weren't acting, I'd give you a round of applause, hahaha.)**"

translate english ch06_hhouse02_13b7d5a1:

    h "**(He really knows how to bring out my maternal instincts sometimes...)**"

translate english ch06_hhouse02_64571b98:

    h "**(He must have spent his whole life feeling lonely without a mother.......)**"

translate english ch06_hhouse02_09af6d45:

    h "**(I can't let him feel lonely while he's living here, too..)**"

translate english ch06_hhouse02_1369beb9:

    h "Come closer, honey."

translate english ch06_hhouse02_40eb6917:

    d "**(Damn.... Why does the mood feel so intense all of a sudden...)**"

translate english ch06_hhouse02_33af66ce:

    d "**(Why does just looking at the landlady make my cock feel like it's about to explode???)**"

translate english ch06_hhouse02_c8031764:

    d "**(It's like she's giving off pheromones just for me...)**"

translate english ch06_hhouse02_aea4b8e2:

    h "As long as you're living with me, I don't want to hear you say you're lonely, okay?"

translate english ch06_hhouse02_c00dd97d:

    d "Okay, I won't.... Hah..."

translate english ch06_hhouse02_8e44d9cb_8:

    h "........"

translate english ch06_hhouse02_dcc8a20b:

    l "**(Yes.... Yes....)**"

translate english ch06_hhouse02_74398762:

    l "**(Go on, comfort each other.)**"

translate english ch06_hhouse02_ca72298d:

    h "**(Haaah.......)**"

translate english ch06_hhouse02_ad8e4c28:

    h "**(What's wrong with me.... With someone so young...)**"

translate english ch06_hhouse02_26e46155:

    h "**(Is it the alcohol..)**"

translate english ch06_hhouse02_1befa7dd:

    h "Are you okay with this?..."

translate english ch06_hhouse02_14f3f66b:

    d "Oh... Yes..."

translate english ch06_hhouse02_9ab0fcf0:

    h "Then kiss me."

translate english ch06_hhouse02_8b659c6b:

    h "You have to forget about this when you wake up tomorrow. Got it?"

translate english strings:
    old "그녀에게 뜨겁게 키스한다."
    new "Kiss her passionately."

translate english ch06_hhouse02_92f21ed5:

    n "What should I do?"

translate english ch06_hhouse02_36668a1d:

    d "**(Oh my God.......)**"

translate english ch06_hhouse02_1a5bcf41:

    d "**(Ah......)**"

translate english ch06_hhouse02_ed8f86b8:

    d "**(My heart feels like it's about to explode.....)**"

translate english ch06_hhouse02_23ae3ea9:

    h "**(Mmm........)**"

translate english ch06_hhouse02_3c620046:

    h "**(What am I doing........)**"

translate english ch06_hhouse02_da1b8893:

    h "**(I can't believe I'm getting turned on kissing someone so young....)**"

translate english ch06_hhouse02_e818ee52:

    h "**(What are you, some high school cheerleader??!!!!)**"

translate english ch06_hhouse02_64b18db1:

    h "**(I'm so embarrassed to feel this kind of excitement.....)**"

translate english ch06_hhouse02_9e6c8ebe:

    h "**(What is this feeling???.......)**"

translate english ch06_hhouse02_f2d61048:

    h "**(I'm actually sexually attracted to this boy???)**"

translate english ch06_hhouse02_7b86c36f_1:

    h "Hahaha."

translate english ch06_hhouse02_cf43d57e:

    h "I must be drunk already, even though I've barely had anything, hahaha."

translate english ch06_hhouse02_23337c1f:

    l "Oh, you two are hopeless...."

translate english ch06_hhouse02_ebbe4571:

    l "What are you two doing?"

translate english ch06_hhouse02_4afa43c7:

    h "Don't say a word, Lena."

translate english ch06_hhouse02_956a3836:

    l "Hey, [d_name]!!"

translate english ch06_hhouse02_0aa3abd6:

    l "Come stand in front of us."

translate english ch06_hhouse02_9f384fb4_3:

    d "Huh??"

translate english ch06_hhouse02_152bf3a1:

    l "I said come over here and stand in front of us."

translate english ch06_hhouse02_ffb96364:

    d "But I'm completely naked right now."

translate english ch06_hhouse02_39013289:

    l "What?? Oh, come on..."

translate english ch06_hhouse02_cfd571a3:

    l "We're all naked here, you know?"

translate english ch06_hhouse02_5aafd9b5:

    h "Stop it, Lena."

translate english ch06_hhouse02_edbb7d05_2:

    d "........"

translate english ch06_hhouse02_2a7628f2:

    l "Oh, just hurry up and stand over here."

translate english ch06_hhouse02_64e3ee41:

    l "I'm not going to eat you alive."

translate english ch06_hhouse02_4ddd7d9f:

    d "Okay... Got it."

translate english strings:
    old "그녀들에게 나의 자지를 보여준다."
    new "Show them my cock."

translate english ch06_hhouse02_92f21ed5_1:

    n "What should I do?"

translate english ch06_hhouse02_7caf97d7_1:

    h "............."

translate english ch06_hhouse02_95793fde:

    n "He stood in front of Lena and [h_name]."

translate english ch06_hhouse02_97f7f942:

    n "Then he showed them his fully erect cock."

translate english ch06_hhouse02_79a304d1:

    h "**(Oh my God....)**"

translate english ch06_hhouse02_94253ada:

    h "....."

translate english ch06_hhouse02_de54cc8c:

    l "What do you think? Haha."

translate english ch06_hhouse02_ecfdd77c:

    l "This kid is naturally gifted."

translate english ch06_hhouse02_94253ada_1:

    h "....."

translate english ch06_hhouse02_3e16fa6e:

    l "I told you, didn't I?"

translate english ch06_hhouse02_600f642e:

    l "This boy is going to be loved by every older woman in the world, hehe."

translate english ch06_hhouse02_f460a096:

    l "Come a little closer."

translate english ch06_hhouse02_d4df6f60:

    h "Don't, Lena.."

translate english ch06_hhouse02_94ccc77d:

    l "What do you think, [h_name]?"

translate english ch06_hhouse02_ca4bea2a:

    h "M-my opinion..."

translate english ch06_hhouse02_88cf28b9:

    h "What do you mean?"

translate english ch06_hhouse02_aefacc9e:

    l "I mean, what do you think of this kid's cock?"

translate english ch06_hhouse02_ca2641e8:

    h "Oh...."

translate english ch06_hhouse02_a01f4f46:

    h ".........."

translate english ch06_hhouse02_692cf372:

    h "He's... healthy..."

translate english ch06_hhouse02_a01f4f46_1:

    h ".........."

translate english ch06_hhouse02_d8a0be8c:

    h "I said... he's healthy..."

translate english ch06_hhouse02_6077bace:

    l "Of course he's healthy. He's a young man, hahaha."

translate english ch06_hhouse02_90b5c09b:

    l "Is that all?"

translate english ch06_hhouse02_76262bc4:

    l "What's the matter, old lady? Too embarrassed to say it? Hahaha."

translate english ch06_hhouse02_98f14643:

    h "Who's embarrassed? I'm not embarrassed..."

translate english ch06_hhouse02_02ba9e0b:

    l "Bet he'd fill you up completely, huh? Hahaha."

translate english ch06_hhouse02_af3181c4:

    h "......"

translate english ch06_hhouse02_64d31871:

    l "A familiar sight, isn't it? Hahaha."

translate english ch06_hhouse02_77673f80:

    d "........."

translate english ch06_hhouse02_d08712db:

    d "Uh... Haha... Yeah..."

translate english ch06_hhouse02_8e44d9cb_9:

    h "........"

translate english ch06_hhouse02_dfe747d6:

    l "Want me to suck it?"

translate english ch06_hhouse02_61fe48a0:

    h "Lena!!!!!"

translate english ch06_hhouse02_5e3aec4e:

    d ".........."

translate english ch06_hhouse02_8b2e8641:

    l "Why aren't you answering?"

translate english ch06_hhouse02_90ee423c:

    l "Don't you want me to? Haha."

translate english ch06_hhouse02_7a21651a:

    l "Are you really going to let tonight end like this??"

translate english ch06_hhouse02_fd27f3df:

    l "With this kind of atmosphere, you must want to do something, too, right? Hahaha."

translate english ch06_hhouse02_f65cbba7:

    l "Don't you want to stick your cock into something right now?"

translate english ch06_hhouse02_bd6e976b:

    h "Lena!!!!!!!!"

translate english ch06_hhouse02_63819613:

    h "That's enough!!"

translate english ch06_hhouse02_744bb746:

    l "Am I right?"

translate english ch06_hhouse02_5e3aec4e_1:

    d ".........."

translate english ch06_hhouse02_00705fe9:

    d "Yeah, you are...."

translate english ch06_hhouse02_980d093f:

    h "[d_name]!!!!!"

translate english ch06_hhouse02_13893879:

    d "P-please... suck it.."

translate english ch06_hhouse02_6f81e916:

    h "What??!!"

translate english ch06_hhouse02_c756b039:

    h "Don't do that, [d_name]!!"

translate english ch06_hhouse02_26fde04c:

    h "What are you trying to do, Lena??!!"

translate english ch06_hhouse02_29da27a2:

    h "Stop teasing [d_name]!"

translate english ch06_hhouse02_edbf774a:

    l "I'm not teasing him."

translate english ch06_hhouse02_80349b3d:

    l "What woman would hold a cock like this just to play around?"

translate english ch06_hhouse02_64d56e05:

    h "!!!!!!!!!!!"

translate english ch06_hhouse02_95a8c5fe:

    h "Don't, Lena!!"

translate english ch06_hhouse02_558608d9:

    h "I'm seriously going to kick you out of this house!"

translate english ch06_hhouse02_6977058b:

    d "Ah...... Lena....."

translate english ch06_hhouse02_64d56e05_1:

    h "!!!!!!!!!!!"

translate english ch06_hhouse02_a60631cc:

    n "Ignoring [h_name]'s protests, Lena took his cock into her mouth."

translate english ch06_hhouse02_77b1784e:

    d "Ah......"

translate english ch06_hhouse02_46a9f4cc:

    d "Lena........."

translate english ch06_hhouse02_cfe9978a:

    l "Gghk..."

translate english ch06_hhouse02_b512ba49:

    n "[h_name] was speechless for a while as she watched her friend and lover perform oral sex on another man."

translate english ch06_hhouse02_f5dd236e:

    n "She lowered her eyes and listened to the splashing water and the sounds of Lena's mouth moving against [d_name]'s cock."

translate english ch06_hhouse02_ee11c8d0:

    h "Ah..... Now I understand...."

translate english ch06_hhouse02_c05ba393:

    h "It was you two that night..."

translate english ch06_hhouse02_8e44d9cb_10:

    h "........"

translate english ch06_hhouse02_d273aa7b:

    h "That wasn't a dream. It was you two..."

translate english ch06_hhouse02_d9c21222:

    n "[h_name] silently watched what they were doing."

translate english ch06_hhouse02_dd82d51a:

    n "Watching two people who both held a special place in her life engage in a sexual act stirred feelings she couldn't explain."

translate english ch06_hhouse02_245de561:

    d "Ah, Lena......."

translate english ch06_hhouse02_6a7a1a6a:

    d "Ah.... I-I'm sorry, [h_name]..."

translate english ch06_hhouse02_8e44d9cb_11:

    h "........"

translate english ch06_hhouse02_2564ac2f:

    h "**(Oh my God...)**"

translate english ch06_hhouse02_c4508115:

    h "**(I feel strange...)**"

translate english ch06_hhouse02_fd89a6d0:

    h "**(............)**"

translate english ch06_hhouse02_ac794f05:

    d "Aaaah.........."

translate english ch06_hhouse02_6caf7965:

    h "(Oh my God.....)"

translate english ch06_hhouse02_56cb3790:

    d "Ah... Lena....."

translate english ch06_hhouse02_8e44d9cb_12:

    h "........"

translate english ch06_hhouse02_0991c7a2:

    d "It... it feels so good.."

translate english ch06_hhouse02_69deea25:

    d "Ever since that night, I haven't been able to stop thinking about you, Lena...."

translate english ch06_hhouse02_2564ac2f_1:

    h "**(Oh my God...)**"

translate english ch06_hhouse02_1ac123cd:

    l "Gghk......"

translate english ch06_hhouse02_1742b4ae:

    h "**(I don't know what to do...)**"

translate english ch06_hhouse02_bfd6ffb5:

    h "**(Why does Lena seem so unfamiliar to me tonight....)**"

translate english ch06_hhouse02_f3828b8b:

    d "Ngh......."

translate english ch06_hhouse02_c28a8e4f:

    d "Damn it......"

translate english ch06_hhouse02_9fd376a9_1:

    h "...."

translate english ch06_hhouse02_2c7baa5a:

    d "Ah....... Lena......"

translate english ch06_hhouse02_346e03ba:

    d "Ah..........."

translate english ch06_hhouse02_8ed9da2b:

    l "Haaah......"

translate english ch06_hhouse02_8ed9da2b_1:

    l "Haaah......"

translate english ch06_hhouse02_81c7b6f3:

    l "His cock tastes so good, haha."

translate english ch06_hhouse02_00f066ea:

    h "......."

translate english ch06_hhouse02_a24c864f:

    l "I swear I could almost have an orgasm just from sucking it, haha."

translate english ch06_hhouse02_83261455:

    h "........."

translate english ch06_hhouse02_e4228e12:

    h "Wait... What are you...."

translate english ch06_hhouse02_eb4b68d3:

    l "Phew.."

translate english ch06_hhouse02_5f098476:

    l "Come here, kid."

translate english ch06_hhouse02_11839da5:

    l "Show me what you're good at."

translate english ch06_hhouse02_9f384fb4_4:

    d "Huh??"

translate english ch06_hhouse02_bec171c2:

    d "What do you mean by that....."

translate english ch06_hhouse02_c3081094:

    l "Hahaha."

translate english ch06_hhouse02_d914de80:

    l "Go ahead and do whatever you want."

translate english ch06_hhouse02_5780eeb6:

    h "Sorry."

translate english ch06_hhouse02_ad737856:

    h "I think I need to leave."

translate english ch06_hhouse02_b45ae0cf:

    d "!!!"

translate english ch06_hhouse02_9300e544:

    h "You two have fun."

translate english ch06_hhouse02_9e0d6431:

    l "Wait a second, honey."

translate english ch06_hhouse02_b54231c0:

    h "Let go of my hand!!"

translate english ch06_hhouse02_e5c36b54_1:

    d "..........."

translate english ch06_hhouse02_2d2fa03f:

    d "**(Oh my God....)**"

translate english ch06_hhouse02_25a4e7c5:

    d "**(Shit......)**"

translate english ch06_hhouse02_9705ffea:

    d "**(What the hell is she doing??......)**"

translate english ch06_hhouse02_ed92d390:

    d "**(What's she thinking?)**"

translate english ch06_hhouse02_3703ec21:

    d "**(D-does she want me to masturbate??)**"

translate english ch06_hhouse03_2ddbdb4d:

    d "Shit......"

translate english ch06_hhouse03_d8bff167:

    n "As if urging him to go faster, she pressed harder against his hips."

translate english ch06_hhouse03_2ddbdb4d_1:

    d "Shit......"

translate english ch06_hhouse03_34e22148:

    d "Ngh..."

translate english ch06_hhouse03_4467e1ef:

    d "Ah.... Lena...."

translate english ch06_hhouse03_e87ab4cf:

    d "Ah... [h_name]!!"

translate english ch06_hhouse03_4338f07b:

    h "..........."

translate english ch06_hhouse03_dc888569:

    d "Ah... Lena.."

translate english ch06_hhouse03_dd6093b2:

    d "I think I'm about to come. What should I do??...."

translate english ch06_hhouse03_2ddbdb4d_2:

    d "Shit......"

translate english ch06_hhouse03_9b8a3852:

    l "..........."

translate english ch06_hhouse03_3a821f63:

    l "You're a little quick tonight, huh??"

translate english ch06_hhouse03_5a968e97:

    l "Want to come on my face?"

translate english ch06_hhouse03_b2f0d44b:

    h "Don't do that, Lena!!"

translate english ch06_hhouse03_85fff566:

    h "What are you, some kind of whore?!!"

translate english ch06_hhouse03_eb21a180:

    d "Ahh.... W-wait a second!!!"

translate english ch06_hhouse03_1e0ece8e:

    d "Ah!!!!! Ladies!!!!!"

translate english ch06_hhouse03_7d5545f3:

    h "What???!!!!!!!!!!!"

translate english ch06_hhouse03_88e2681c:

    h "!!!!!!!!!!!!!!!!!!"

translate english ch06_hhouse03_6d7b7bcc:

    h "Ngh....."

translate english ch06_hhouse03_b52973b0:

    d "Oh, I'm sorry!!!!"

translate english ch06_hhouse03_c8c49963:

    d "Ah!!!!!!"

translate english ch06_hhouse03_9d24f2af:

    d "Ah, Lena........."

translate english ch06_hhouse03_f7d373d0:

    d "Gghk!!!!!"

translate english ch06_hhouse03_c4c2bc29:

    l "Gghk.."

translate english ch06_hhouse03_2319689c:

    l "**(Oh, there's so much of it.....)**"

translate english ch06_hhouse03_5188efd0:

    l "**(He's like a damn faucet.)**"

translate english ch06_hhouse03_69b50ddc:

    n "Gulp."

translate english ch06_hhouse03_8ed9da2b:

    l "Haaah......"

translate english ch06_hhouse03_27c231a4:

    l "That's a lot.."

translate english ch06_hhouse03_c9aaa6a4:

    d "Ah.............."

translate english ch06_hhouse03_e8ed8da5:

    h "!!!!!!!!!!!!!!"

translate english ch06_hhouse03_937fe9cc:

    n "Lena grabbed his cock and brought it to [h_name]'s mouth."

translate english ch06_hhouse03_90d45538:

    n "[h_name] immediately felt the warmth and texture of the head of his cock against her lips."

translate english ch06_hhouse03_20004022:

    h "Mmph!!!!"

translate english ch06_hhouse03_15ff5caf:

    l "Open your mouth. Come on.."

translate english ch06_hhouse03_dede07e5:

    l "Make sure this little guy doesn't feel lonely."

translate english ch06_hhouse03_430c2df1:

    h "Gghk!!!"

translate english ch06_hhouse03_f2003028:

    l "Show him the real [h_name], the warmhearted, beautiful woman you are."

translate english ch06_hhouse03_4a0c3f39:

    n "Instinctively, [d_name] thrust his hips forward."

translate english ch06_hhouse03_21b6e477:

    d "Aah!!!!!!"

translate english ch06_hhouse03_9b63dd16:

    d "Ahh..........."

translate english ch06_hhouse03_95ed66ac:

    h "!!!!!!!!!!!!!"

translate english ch06_hhouse03_7a9e7256:

    d "Ah.... [h_name]....."

translate english ch06_hhouse03_60051060:

    n "[h_name] felt a slippery, salty liquid inside her mouth."

translate english ch06_hhouse03_9b63dd16_1:

    d "Ahh..........."

translate english ch06_hhouse03_92ad9932:

    h "............"

translate english strings:
    old "자지를 그녀의 입으로 밀어넣는다."
    new "Push my cock into her mouth."

translate english ch06_hhouse03_92f21ed5:

    n "What should I do?"

translate english ch06_hhouse03_44003427:

    h "Gghk..."

translate english ch06_hhouse03_5560b24e:

    d "Mmm......."

translate english ch06_hhouse03_d5f6d24b:

    l "Ahh....."

translate english strings:
    old "자지를 그녀의 입으로 더 깊게 밀어넣는다."
    new "Push my cock deeper into her mouth."

translate english ch06_hhouse03_highlust_92f21ed5:

    n "What should I do?"

translate english ch06_hhouse03_highlust_ada1694e:

    h "Gghk..."

translate english ch06_hhouse03_highlust_ada1694e_1:

    h "Gghk..."

translate english ch06_hhouse03_highlust_a0156c54:

    n "His cock slid deeper into her mouth."

translate english ch06_hhouse03_highlust_131bc307:

    n "[h_name] was too stunned to react."

translate english ch06_hhouse03_highlust_800ecfbd:

    d "Aah.........."

translate english ch06_hhouse03_highlust_094bf8ea:

    d "[h_name]........"

translate english ch06_hhouse03_highlust_778d1c5e:

    n "Then more semen began flowing from his cock."

translate english ch06_hhouse03_highlust_c714f9fc:

    n "His semen flowed straight down her throat."

translate english ch06_hhouse03_highlust_ae12c94e:

    l "That's it, [h_name]..."

translate english ch06_hhouse03_highlust_885eea5e:

    l "That's exactly it."

translate english ch06_hhouse03_highlust_0746d7e6:

    l "Now that's my girl."

translate english ch06_hhouse03_highlust_9ed0e822:

    d "Ah.............. [h_name]...."

translate english ch06_hhouse03_highlust_a3e9bd7f:

    l "Come on, try some of this kid's anti-aging cream."

translate english ch06_hhouse03_highlust_322c45a2:

    h "[d_name]!!!!!!!!!!!!"

translate english ch06_hhouse03_lowlust_6a96730b:

    h "Lena!!!!!!!!!!!!!!!!!"

translate english ch06_hhouse04_9649ff9b:

    h "You sick fucking bitch!!!!!"

translate english ch06_hhouse04_0dbd7fe6:

    h "You're the fucking worst!!!!!!!!!"

translate english ch06_hhouse04_49987292:

    h "The absolute worst!!!"

translate english ch06_hhouse04_1d5b034b:

    h "All of you!!!!!"

translate english ch06_hhouse04_917c4c8d:

    h "How could you do this??!!!!"

translate english ch06_hhouse04_43a81dae:

    h "How the hell could you do something like this...."

translate english ch06_hhouse04_3819fcc2:

    d "**(Damn it......)**"

translate english ch06_hhouse04_f475faa6:

    d "**(What the hell have I just done?....)**"

translate english ch06_hhouse04_6794348a:

    d "**(I think I'm in serious trouble this time...)**"

translate english ch06_hhouse04_c711cd51:

    d "**(I pushed it in without even thinking.....)**"

translate english ch06_hhouse04_7937b980:

    d "Ah, I'm so fucked......"

translate english ch06_hhouse04_50823a8b:

    l "That's right."

translate english ch06_hhouse04_a517f84d:

    l "I think you're seriously fucked.."

translate english ch06_hhouse04_203cc60b:

    d "......."

translate english ch06_hhouse04_de6d2ba8:

    l "You might have to pack your bags tonight."

translate english ch06_hhouse04_b81be7d8:

    d "**(Lena's a witch.....)**"

translate english ch06_hhouse04_ddbaefa5:

    d "**(She's definitely a witch.......)**"

translate english ch06_hhouse04_1333d5f5:

    d "**(What if she actually has the power to control people?.....)**"

translate english ch06_hhouse04_2e9c6444:

    d "**(.......)**"

translate english ch06_hhouse04_74d77ed6:

    d "**(What the hell am I going to do now......)**"

translate english ch06_otable01_c1263c51:

    d "Haaah........."

translate english ch06_otable01_dd2d2470:

    d "The sky is so clear today."

translate english ch06_otable01_3d75355a:

    d "I never knew having a day off could feel this good.."

translate english ch06_otable01_291fc623:

    d "No wonder people look forward to the weekend so much..."

translate english ch06_otable01_44a92def:

    d "Damn it...."

translate english ch06_otable01_b1e4488b:

    d "My memory's pretty fuzzy......"

translate english ch06_otable01_203cc60b:

    d "......."

translate english ch06_otable01_b1c28a18:

    d "I can't remember exactly how my cock ended up in her mouth...."

translate english ch06_otable01_2445e188:

    d "Did I push it in myself?...."

translate english ch06_otable01_652daa75:

    d "Or did Lena grab it and push it in?......"

translate english ch06_otable01_990e485a:

    d "Or did [h_name] open her mouth?.... Sigh....."

translate english ch06_otable01_53f0bf09:

    d "What actually happened???"

translate english ch06_otable01_294aea43:

    d "I need to remember what happened so I can at least apologize properly...."

translate english ch06_otable01_4d421089:

    d "How am I supposed to face the landlady now....."

translate english ch06_otable01_4fcaa392:

    d "Haaah......."

translate english ch06_otable01_e8cc0cf7:

    n "His phone rang."

translate english ch06_otable01_172a7184:

    d "Huh? Who's calling?"

translate english ch06_otable01_ec9f0e6b:

    d "Hey, Ollie! Haha."

translate english ch06_otable01_17571bf8:

    d "How've you been?"

translate english ch06_otable01_05baf396:

    d "I was actually getting worried because you hadn't replied to my texts.."

translate english ch06_otable01_4d25cae7:

    d "Oh, I'm just hanging out near my place."

translate english ch06_otable01_edbb7d05:

    d "........"

translate english ch06_otable01_8f6b2e2b:

    d "Oh, no. I'm by myself."

translate english ch06_otable01_edbb7d05_1:

    d "........"

translate english ch06_otable01_1c8e4bae:

    d "Oh, really?"

translate english ch06_otable01_edbb7d05_2:

    d "........"

translate english ch06_otable01_8c097a17:

    d "Okay."

translate english ch06_otable01_fdb804e2:

    d "I'll be right there!"

translate english ch06_otable01_09d4d573:

    d "Phew......"

translate english ch06_otable01_b658d524:

    d "Guess I'll go see Ollie, haha."

translate english ch06_otable01_e8fe6855:

    d "Hey, Ollie."

translate english ch06_otable01_8a6568bf:

    o "Oh, you're here."

translate english ch06_otable01_73bd1645:

    o "That was quick."

translate english ch06_otable01_6862fe28:

    d "Oh, yeah......."

translate english ch06_otable01_fdd6e9fc:

    d "You know I'm always quick."

translate english ch06_otable01_ae01c526:

    o "Here's your order."

translate english ch06_otable01_679bc131:

    o "Enjoy your meal, haha."

translate english ch06_otable01_e5c36b54:

    d "..........."

translate english ch06_otable01_095fc964:

    o "Let me know if you need anything else."

translate english ch06_otable01_a7cf88a6:

    unknown "Sure, we will."

translate english ch06_otable01_e3e64a59:

    unknown "Thank you."

translate english ch06_otable01_d3f4d4a6:

    d "I'm here."

translate english ch06_otable01_fc3f3727:

    d "Busy today?"

translate english ch06_otable01_4352bc51:

    o "Phew......."

translate english ch06_otable01_c48318d6:

    o "It's not too busy, but something came up and Stella couldn't make it today."

translate english ch06_otable01_cb409cc9:

    o "I have to handle the cooking in the kitchen, so I need you to take care of serving the customers."

translate english ch06_otable01_46934df6:

    o "Sorry to spring this on you so suddenly."

translate english ch06_otable01_7f716a94:

    d "Not at all."

translate english ch06_otable01_5d49ec5b:

    d "Of course I'll help if you need me, Ollie."

translate english ch06_otable01_91b6c8c9:

    d "So what do you need me to do??"

translate english ch06_otable01_1d1ea0bf:

    o "When customers come in, give them water, and pour them beer if they ask for it."

translate english ch06_otable01_430d12bb:

    o "When you take an order, either text it to me or come tell me in the kitchen."

translate english ch06_otable01_df409644:

    o "Oh, and make sure you wear an apron!"

translate english ch06_otable01_11a8849c:

    o "Got it?"

translate english ch06_otable01_4f280d29:

    d "Yeah, I'll do that!!"

translate english ch06_otable01_77673f80:

    d "........."

translate english ch06_otable01_191914b5:

    o "And try to seat customers on the first floor whenever possible."

translate english ch06_otable01_cb0a4fa9:

    o "It'll make things easier for you, haha."

translate english ch06_otable01_c2b79ed8:

    d "Okay, haha."

translate english ch06_otable01_b1fccaa0:

    n "It was his first time ever waiting tables."

translate english ch06_otable01_3cf87564:

    n "He'd rushed over, excited to see Olivia, but forgot all about that once the work started."

translate english ch06_otable01_7fcccb31:

    d "**(Damn it..)**"

translate english ch06_otable01_a7d15d35:

    d "**(It's actually pretty busy!!)**"

translate english ch06_otable01_fb2bcbae:

    d "**(This is more nerve-racking than I expected!!!!)**"

translate english ch06_otable01_3b1c5024:

    d "**(Why do I feel like I'm about to screw something up??!!)**"

translate english ch06_otable01_633e5909:

    d "Hello."

translate english ch06_otable01_1ac4c39a:

    d "Um... I..."

translate english ch06_otable01_31d8273a:

    d "We met at the rooftop bar, didn't we? Haha...."

translate english ch06_otable01_e46167b6:

    o "Haaah........."

translate english ch06_otable01_20a32d03:

    o "Is everyone in town coming here today or what....."

translate english ch06_otable01_e5c36b54_1:

    d "..........."

translate english ch06_otable01_7f98bce4:

    d "Haaah........"

translate english ch06_otable01_88c221a7:

    d "Has the storm finally passed?..."

translate english ch06_otable01_0fc76766:

    d "At least I don't think I made any mistakes..."

translate english ch06_otable01_c3ae54e5:

    d "I hope I handled all the payments correctly... Sigh...."

translate english ch06_otable01_ab436b5a:

    o "Haaah..... I'm exhausted.."

translate english ch06_otable01_4e57b333:

    o "Making a living isn't easy.."

translate english ch06_otable01_90aee38c:

    o "I'm drenched in sweat..."

translate english ch06_otable01_5efdf768:

    o "Tired, huh? Haha."

translate english ch06_otable01_e4cd49ae:

    d "No, not at all. It wasn't too bad."

translate english ch06_otable01_1cbcc4fd:

    o "Felt like everyone in town showed up just to give you a hard time, didn't it?"

translate english ch06_otable01_f24c2282:

    d "Haha, that's what I thought at first, lol."

translate english ch06_otable01_12761fb8:

    d "I seriously thought you'd told everyone in town I was working here today."

translate english ch06_otable01_34433e57:

    o "Good work, haha."

translate english ch06_otable01_0b8f0816:

    o "Let's clean up quickly and have dinner together."

translate english ch06_otable01_1af7d964:

    o "I've already made some food in the kitchen, so we just need to heat it up."

translate english ch06_otable01_fad3b965:

    d "Yeah, sounds good."

translate english ch06_otable01_617b04fe:

    o "Finally, we're all done."

translate english ch06_otable01_a325e21a:

    o "Hungry?"

translate english ch06_otable01_c2b79ed8_1:

    d "Yeah, haha."

translate english ch06_otable01_29fe7283:

    o "Hey, stop grinning like that, hahaha."

translate english ch06_otable01_f26e6710:

    o "You look like an idiot when you smile like that."

translate english ch06_otable01_baac5892:

    o "What's going on in that head of yours?"

translate english ch06_otable01_1b8a2ded:

    o "We've got a backyard, you know?"

translate english ch06_otable01_5aa9e00d:

    o "We're having dinner out there, so go relax at the table."

translate english ch06_otable01_2a94760e:

    o "I'll be out in a minute."

translate english ch06_otable01_3c0da5c4:

    o "Lock the front door before you head outside."

translate english ch06_otable01_33bf8f25:

    d "Okay, got it."

translate english ch06_otable01_e2177ba1:

    d "Thanks for cooking!!"

translate english ch06_otable01_b6d2bad1:

    d "It looks delicious, haha."

translate english ch06_otable01_fc6e6dd3:

    d "I love that I've been getting to eat your cooking so often lately, Ollie."

translate english ch06_otable01_0341c7d1:

    o "You really saved my ass today, honey."

translate english ch06_otable01_c4e7318c:

    o "When Stella called, I was actually thinking about just closing for the day, haha."

translate english ch06_otable01_67d1bac4:

    o "I'll send you your pay later."

translate english ch06_otable01_bbb0e836:

    d "Haha, thank you."

translate english ch06_otable01_f5840723:

    d "It was more fun than I expected."

translate english ch06_otable01_db887842:

    o "You're not as clueless as I thought."

translate english ch06_otable01_8f4e57b2:

    o "I figured you'd grown up pretty sheltered, haha."

translate english ch06_otable01_5edc00bc:

    d "Sheltered? Come on."

translate english ch06_otable01_572f857e:

    d "I've been through my fair share of rough times, you know."

translate english ch06_otable01_f1b1cfc6:

    o "........."

translate english ch06_otable01_e07648f0:

    o "Anyway, it's nice seeing you so often."

translate english ch06_otable01_1f5e25e2:

    o "Come on, eat up."

translate english ch06_otable01_ced068c2:

    d "I like seeing you often, too, Ollie."

translate english ch06_otable01_77673f80_1:

    d "........."

translate english ch06_otable01_9b4d1abc:

    d "By the way, I texted you, but..."

translate english ch06_otable01_dba1bd43:

    o "Oh, that..."

translate english ch06_otable01_f96c0300:

    o "..........."

translate english ch06_otable01_9a67a7fd:

    o "I just never got around to replying."

translate english ch06_otable01_a6f7f003:

    d "Oh, really?"

translate english ch06_otable01_913d9004:

    o "Yeah."

translate english ch06_otable01_edbb7d05_3:

    d "........"

translate english ch06_otable01_fe93a88f:

    d "I thought maybe you were upset with me after what happened.."

translate english ch06_otable01_e6c3b814:

    d "So I was a little worried."

translate english ch06_otable01_e842596d:

    o "........"

translate english ch06_otable01_23c5635e:

    o "What happened?"

translate english ch06_otable01_8096b08a:

    d "Huh?"

translate english ch06_otable01_c1894055:

    d "Well... um..."

translate english ch06_otable01_3b78355d:

    d "Your hand... You know, when you used your hand on me..."

translate english ch06_otable01_e842596d_1:

    o "........"

translate english ch06_otable01_c86f3ab4:

    o "Oh, that?"

translate english ch06_otable01_fa8259f6:

    o "That was nothing."

translate english ch06_otable01_5ad20ed8:

    o "I think I've given guys handjobs more than five hundred times by now, hahaha."

translate english ch06_otable01_a254b6d4:

    d "!!!!!"

translate english ch06_otable01_5bf3702c:

    d "F-five hundred times??"

translate english ch06_otable01_913d9004_1:

    o "Yeah."

translate english ch06_otable01_87414698:

    o "Well, about half of those were probably for my husband."

translate english ch06_otable01_77673f80_2:

    d "........."

translate english ch06_otable01_2c2558c3:

    d "Wow...."

translate english ch06_otable01_457b3b92:

    d "Married women really are on a whole different level from younger girls.."

translate english ch06_otable01_d226b6b8:

    o ".........."

translate english ch06_otable01_65482612:

    o "Married women are on a whole different level from younger girls??"

translate english ch06_otable01_c1054cdf:

    o "What's that supposed to mean?"

translate english ch06_otable01_8096b08a_1:

    d "Huh?"

translate english ch06_otable01_7ebfbae8:

    o "I asked what you meant by that."

translate english ch06_otable01_a3267480:

    d "O-oh, no... I mean..."

translate english ch06_otable01_e111eb60:

    o "Are you saying married women are easy?"

translate english ch06_otable01_64543f93:

    d "No!! That's not what I meant..."

translate english ch06_otable01_aea14f94:

    o "That's a pretty insulting thing to say, you know?"

translate english ch06_otable01_7d14ab16:

    d "No......"

translate english ch06_otable01_5ec99855:

    d "I didn't mean it like that..."

translate english ch06_otable01_203cc60b_1:

    d "......."

translate english ch06_otable01_12e6ce56:

    d "I'm sorry, Ollie..."

translate english ch06_otable01_f96c0300_1:

    o "..........."

translate english ch06_otable01_5011ee4e:

    d "Please…."

translate english ch06_otable01_f98dc5a5:

    d "I'm sorry..."

translate english ch06_otable01_70ed8b6f:

    o "Hahahaha."

translate english ch06_otable01_2c5ad3b6:

    o "You fell for it again?"

translate english ch06_otable01_f6a1a86f:

    o "You really are young, [d_name]..."

translate english ch06_otable01_c54fd6bc:

    o "So young, hahaha."

translate english ch06_otable01_730d1084:

    d "Oh, come on, Ollie.... Please...."

translate english ch06_otable01_d7f95b4d:

    o "But there's something you need to understand."

translate english ch06_otable01_ec8f7eb5:

    o "What you just said was cutting it pretty close.."

translate english ch06_otable01_5c042bb8:

    o "It's a huge mistake to think older women are easy."

translate english ch06_otable01_3d782a2d:

    o "If a woman's easy when she's older, she was probably easy when she was younger, too."

translate english ch06_otable01_7594ef35:

    o "You know what I mean?"

translate english ch06_otable01_dc18d7e6:

    d "Yeah......"

translate english ch06_otable01_bf9a4624:

    d "I think I understand......"

translate english ch06_otable01_25101d85:

    o "Good......"

translate english ch06_otable01_82bb6c81:

    o "Because a woman is still a woman until the day she dies."

translate english ch06_otable01_84b22779:

    o "Think about it."

translate english ch06_otable01_d45345cc:

    o "Unless she's some sex-crazed slut, how many women do you think would suddenly beg you to fuck them just because you shoved your cock in their face?"

translate english ch06_otable01_811bca9d:

    o "Even actresses wouldn't go that far. Understand?"

translate english ch06_otable01_dc2af698:

    d "Y-yeah, that's true...."

translate english ch06_otable01_23fdea6e:

    o "That's why I keep telling you that women get swept up in the mood."

translate english ch06_otable01_f1b1cfc6_1:

    o "........."

translate english ch06_otable01_e2f827b9:

    d "Yeah, I remember."

translate english ch06_otable01_972df13d:

    o "Yeah."

translate english ch06_otable01_e842596d_2:

    o "........"

translate english ch06_otable01_f222740e:

    o "**(Did he actually understand what I said or not?..)**"

translate english ch06_otable01_58b420c2:

    o "**(He gets so clueless sometimes..)**"

translate english ch06_otable01_d7dd236d:

    o "**(Well, I guess knowing how to set the mood is something you're born with. I doubt anything I say will change that..)**"

translate english ch06_otable01_dbb93eb1:

    o "**(Still, some of it can be learned, so I should try to teach him....)**"

translate english ch06_otable01_20dcf103:

    o "Ah........"

translate english ch06_otable01_a5fc6371:

    o "I'm pretty full."

translate english ch06_otable01_e0030a8d:

    o "I usually can't eat much of my own cooking, but I really stuffed myself tonight."

translate english ch06_otable01_f5b14b09:

    d "I really enjoyed it."

translate english ch06_otable01_cead3132:

    d "It tastes a little like Amanda's cooking, but different. It's delicious, haha."

translate english ch06_otable01_203cc60b_2:

    d "......."

translate english ch06_otable01_4a8dc4eb:

    o "Why are you grinning like that?"

translate english ch06_otable01_c15b9a70:

    o "You know it makes you look like a little old man, right?"

translate english ch06_otable01_2bf61f33:

    d "Hahaha."

translate english ch06_otable01_febc94ff:

    d "There's something I've been wondering about."

translate english ch06_otable01_1bb17818:

    o "Something you're wondering about?"

translate english ch06_otable01_6225b646:

    d "Yeah."

translate english ch06_otable01_60461bc0:

    o "What is it?"

translate english ch06_otable01_203cc60b_3:

    d "......."

translate english ch06_otable01_6ea4ef2c:

    d "Well, um....."

translate english ch06_otable01_fb600654:

    d "What do you think of mine?"

translate english ch06_otable01_bcd5cf3b:

    o "Yours?"

translate english ch06_otable01_e842596d_3:

    o "........"

translate english ch06_otable01_9b04f6e9:

    d "I mean...."

translate english ch06_otable01_66dec2d7:

    d "My cock."

translate english ch06_otable01_f1b1cfc6_2:

    o "........."

translate english ch06_otable01_cd0b672f:

    o "Why would you ask me that? Hahaha."

translate english ch06_otable01_2e2909b1:

    o "It's impressive."

translate english ch06_otable01_c9e74566:

    o "....."

translate english ch06_otable01_203cc60b_4:

    d "......."

translate english ch06_otable01_55be83f6:

    d "Is that all?"

translate english ch06_otable01_f1b1cfc6_3:

    o "........."

translate english ch06_otable01_3f36dd69:

    d "Isn't it the biggest you've ever seen? Haha."

translate english ch06_otable01_f1b1cfc6_4:

    o "........."

translate english ch06_otable01_1c9205c5:

    o "No, it's not the biggest."

translate english ch06_otable01_cb49d504:

    d "Really??!!"

translate english ch06_otable01_913d9004_2:

    o "Yeah."

translate english ch06_otable01_8b0ea973:

    o "But it’d definitely make the top three."

translate english ch06_otable01_f1b1cfc6_5:

    o "........."

translate english ch06_otable01_51c03abd:

    d "Ollie....."

translate english ch06_otable01_2057ad40:

    d "Have you thought about having sex with me since then?"

translate english ch06_otable01_a151db34:

    o "......."

translate english ch06_otable01_2518939f:

    o "What a question...."

translate english ch06_otable01_70de16b9:

    o "I have.."

translate english ch06_otable01_c9e74566_1:

    o "....."

translate english ch06_otable01_17edb37c:

    o "What about you?"

translate english ch06_otable01_7aaffc44:

    d "I've thought about having sex with you, too, Ollie."

translate english ch06_otable01_203cc60b_5:

    d "......."

translate english ch06_otable01_6828f917:

    d "And I masturbated while thinking about it.."

translate english ch06_otable01_daa4fbdf:

    o "Pfft.."

translate english ch06_otable01_32f9d4d4:

    o "Oh... That's a little too much information, don't you think?.."

translate english ch06_otable01_9a104b70:

    o "............"

translate english ch06_otable01_f6890899:

    o "You want to have sex with me right now, don't you?"

translate english ch06_otable01_ad893dfa:

    d "......"

translate english ch06_otable01_86ecfb3f:

    d "W-well, that's..."

translate english ch06_otable01_3e56e4ed:

    o "It's written all over your face, kid, haha."

translate english ch06_otable01_1b794bf0:

    o "You're hoping I'll do something for you like I did at the cabin, aren't you?"

translate english ch06_otable01_90a47d0b:

    o "Am I right?"

translate english ch06_otable01_1afce67b:

    d "Haha."

translate english ch06_otable01_ad893dfa_1:

    d "......"

translate english strings:
    old "올리와 섹스하고 싶어요."
    new "I want to have sex with you, Ollie."

translate english strings:
    old "절 따먹어주세요."
    new "Please fuck me."

translate english ch06_otable01_c7a95006:

    n "What should I say?"

translate english ch06_otable01_ea2dad1c:

    d "I want to have sex with you, Ollie."

translate english ch06_otable01_f1b1cfc6_6:

    o "........."

translate english ch06_otable01_33919019:

    d "Please fuck me."

translate english ch06_otable01_dcc080ff:

    o "What??!!"

translate english ch06_otable01_70ed8b6f_1:

    o "Hahahaha."

translate english ch06_otable01_8a6d5c94:

    o "Wow, that's so direct I don't even know what to say."

translate english ch06_otable01_4b9bbf81:

    o "I don't think you'll ever be popular with women."

translate english ch06_otable01_757e3ef2:

    o "Yeah, I bet women just love hearing that, you idiot."

translate english ch06_otable01_ac3a14df:

    d "You never know, haha."

translate english ch06_otable01_68d22a41:

    d "I've actually got quite a few women around me, you know."

translate english ch06_otable01_6063f555:

    o "Oh, is that so, Mr. Ladies' Man?"

translate english ch06_otable01_fe503904:

    o "Get yourself a girlfriend before you start talking like that."

translate english ch06_otable01_9b686c75:

    d "Hahaha."

translate english ch06_otable01_61c1e9ec:

    o "Come here."

translate english ch06_otable01_8098c35a:

    o "Sit down next to me."

translate english ch06_otable01_f96c0300_2:

    o "..........."

translate english ch06_otable01_6a21657e:

    d "..............."

translate english ch06_otable01_92f21ed5:

    n "What should I do?"

translate english ch06_otable01_edbb7d05_4:

    d "........"

translate english ch06_otable01_25ba0e2f:

    o "......"

translate english ch06_otable01_580bfec1:

    o "What are we even doing right now? Haha."

translate english ch06_otable01_4053e6dd:

    o "I’m hardly normal myself, but you’re pretty unusual too."

translate english ch06_otable01_4576f50b:

    o "What am I going to do with you? Haha."

translate english ch06_otable01_72b5c6e0:

    o "Easy there, cowboy. Haha."

translate english ch06_otable01_07abc845:

    o "..."

translate english ch06_otable01_2317dcb0:

    o "I've still got food in my mouth, you know?"

translate english ch06_otable01_6d5aa8d6:

    o "Are you okay with that??"

translate english ch06_otable01_40d5b312:

    d "I don't care."

translate english ch06_otable01_7d034e80:

    d "I love everything about you, Ollie."

translate english ch06_otable01_0d33c84e:

    o "Hahaha."

translate english ch06_otable01_ce03e611:

    o "Ugh, you're so cheesy!!"

translate english ch06_otable01_40d5b312_1:

    d "I don't care."

translate english ch06_otable02_77673f80:

    d "........."

translate english ch06_otable02_f000db52:

    n "She was back to being the Olivia he knew, the Olivia he'd been hoping to see."

translate english ch06_otable02_7909f0cd:

    n "She was both predictable and unpredictable at the same time."

translate english ch06_otable02_a572af6d:

    n "She was a woman with an irresistibly seductive charm."

translate english ch06_otable02_4a66de6a:

    n "And her charm sparked a chemical reaction inside [d_name]'s body, sending a rush of arousal straight to the tip of his cock."

translate english ch06_otable02_e06dc7dd:

    o "I’m going to start hosting parties here, too."

translate english ch06_otable02_70bd59a3:

    o "I'm planning to set up a small stage."

translate english ch06_otable02_7444d1fa:

    o "And decorate the place to make it even cozier."

translate english ch06_otable02_fb547443:

    o "Maybe even host small weddings.."

translate english ch06_otable02_e00d4116:

    o "People laughing and having a good time.."

translate english ch06_otable02_cb69a9bd:

    d "I think that's a great idea."

translate english ch06_otable02_fa5b4d19:

    o "Right? Haha."

translate english ch06_otable02_a7fbd57a:

    o "I'm a little worried about being so close to the residential area, though...."

translate english ch06_otable02_d0e8ba1f:

    o "Well, I'll figure something out, haha."

translate english ch06_otable02_523fecbc:

    o "Either this place becomes the hottest spot in town, or I get kicked out...."

translate english ch06_otable02_ac622801:

    o "Or maybe I'll become so successful I'll buy up all the houses around here, haha."

translate english ch06_otable02_2c2bacfe:

    d "Oh, that's not a bad plan either! Hahaha."

translate english ch06_otable02_de1a8b69:

    o "Come here, sweetie."

translate english ch06_otable02_f81d516f:

    o "Come on."

translate english ch06_otable02_175bb13b:

    d "Why? Haha."

translate english ch06_otable02_8bf2d1e6:

    o "Haha."

translate english ch06_otable02_4f37c0e0:

    o "Let's dance, haha."

translate english ch06_otable02_6dc8023c:

    o "Ohohoho."

translate english ch06_otable02_a842cc76:

    o "Hey, you're not completely hopeless at dancing!"

translate english ch06_otable02_beb89374:

    d "Of course not."

translate english ch06_otable02_3d60be5d:

    d "What do you take me for?"

translate english ch06_otable02_66e5aae2:

    d "Are you going to keep underestimating me like that? Haha."

translate english ch06_otable02_1ad52b6e:

    o "I thought all you knew how to do was shove your cock at women."

translate english ch06_otable02_a7ee796b:

    d "Oh, come on, Ollie....."

translate english ch06_otable02_a9ade713:

    o "I haven't done this since my wedding, hahaha."

translate english ch06_otable02_7e9d8756:

    d "Really?"

translate english ch06_otable02_01e63145:

    d "How old was I back then? Hahaha."

translate english ch06_otable02_d4dfe339:

    o "Hey, putting it that way really brings me back to reality."

translate english ch06_otable02_4046efbf:

    o "You little brat."

translate english ch06_otable02_30cfc520:

    d "I keep telling you, I'm not a little kid."

translate english ch06_otable02_e8c9ec33:

    o "Hey!!"

translate english strings:
    old "그녀를 들어 안는다."
    new "Pick her up."

translate english ch06_otable02_92f21ed5:

    n "What should I do?"

translate english ch06_otable02_baea5bd4:

    o "!!!!!!"

translate english ch06_otable02_82fb57d0:

    o "What are you doing??!!"

translate english ch06_otable02_60f97b5c:

    o "I seriously hate this kind of thing, you know?"

translate english ch06_otable02_10d96bef:

    o "Put me down right now!!"

translate english ch06_otable02_58ae487e:

    d "Hahahaha."

translate english ch06_otable02_e30329ef:

    d "Should I carry you around the whole neighborhood like this?"

translate english ch06_otable02_28d9aba2:

    o "I'm seriously going to kill you??!!!"

translate english ch06_otable02_80866db1:

    o "Oh, put me down already!!!!!!"

translate english ch06_otable02_d247686b:

    d "Hahahahahaha."

translate english ch06_otable02_02d9973f:

    o "Now!!!!"

translate english ch06_otable02_20829155:

    d "I've got you now, Ollie."

translate english ch06_otable02_a47d07a5:

    d "Hahaha."

translate english ch06_otable02_6361d649:

    o "Put me down right now! I'm seriously getting angry, okay??"

translate english ch06_otable02_cedc0101:

    d "Okay, okay."

translate english ch06_otable02_43d3b093:

    d "Ugh.."

translate english ch06_otable02_d567f29a:

    o "Hahahaha."

translate english ch06_otable02_fb379818:

    o "What, you're already tired after carrying me for a few seconds?"

translate english ch06_otable02_cac88583:

    d "Hahaha, damn it.."

translate english ch06_otable02_2983c27b:

    o "Haaah......"

translate english ch06_otable02_af707b10:

    o "Sometimes doing crazy things like this is actually fun."

translate english ch06_otable02_e842596d:

    o "........"

translate english ch06_otable02_8f84fb8c:

    o "This feels like dating back when I was in high school."

translate english ch06_otable02_44ba0eba:

    d "You used to date like this in high school? Hahaha."

translate english ch06_otable02_1180eadb:

    o "Quiet, you little brat."

translate english ch06_otable02_92f21ed5_1:

    n "What should I do?"

translate english strings:
    old "그녀의 젖을 만진다."
    new "Touch her breasts."

translate english ch06_otable02_92f21ed5_2:

    n "What should I do?"

translate english ch06_otable02_1bd3045c:

    o "Mmm......"

translate english strings:
    old "그녀의 보지를 만진다."
    new "Touch her pussy."

translate english ch06_otable02_92f21ed5_3:

    n "What should I do?"

translate english ch06_otable02_7ab39cb0:

    d "!!!!"

translate english ch06_otable02_27e77e58:

    n "When his hand reached her pussy, what he felt wasn't fabric."

translate english ch06_otable02_83af953a:

    n "Beneath his fingertips, he felt the warmth of her skin and the coarse texture of her pubic hair."

translate english ch06_otable02_853bf2af:

    d "Y-you're not wearing panties?? Haha."

translate english ch06_otable02_25ba0e2f:

    o "......"

translate english ch06_otable02_1f6cc965:

    o "Hahaha."

translate english ch06_otable02_2f586335:

    o "Just like always.."

translate english ch06_otable02_236ea9ba:

    d "Oh....."

translate english ch06_otable02_ae55b0bc:

    d "D-damn it, Ollie..."

translate english ch06_otable02_7628ee7d:

    d "This feels strange..."

translate english ch06_otable02_6bc5b6b5:

    o "Back here again......"

translate english strings:
    old "손가락을 삽입한다."
    new "Slide a finger inside her."

translate english ch06_otable02_92f21ed5_4:

    n "What should I do?"

translate english ch06_otable02_99ceda6d:

    o "Haaah......"

translate english ch06_otable02_77b1784e:

    d "Ah......"

translate english strings:
    old "손가락을 더 깊히 삽입한다."
    new "Push my finger deeper inside her."

translate english ch06_otable02_92f21ed5_5:

    n "What should I do?"

translate english ch06_otable02_29dc8279:

    o "Mmm......"

translate english ch06_otable02_590c7dc1:

    d "Ah... Ollie...."

translate english ch06_otable02_56d6091b:

    d "Th-the way it feels...."

translate english ch06_otable02_9af8480d:

    o "Aah......."

translate english ch06_otable02_e635efd0:

    d "A-am I doing this right?"

translate english ch06_otable02_8b97cadb:

    o "Keep going."

translate english ch06_otable02_b6dbfd5e:

    o "That's good....."

translate english ch06_otable02_033a3aa7:

    d "O-okay.."

translate english ch06_otable02_c100df8f:

    o "Ohhh......."

translate english strings:
    old "속도를 올린다."
    new "Go faster."

translate english ch06_otable02_92f21ed5_6:

    n "What should I do?"

translate english ch06_otable02_560b7fa8:

    o "Oh my God........."

translate english ch06_otable02_d78904ab:

    o "Oh, baby......"

translate english ch06_otable02_c506436d:

    d "Ah, so this is what your pussy feels like, Ollie...."

translate english ch06_otable02_eaa7939b:

    o "Do you like it?...."

translate english ch06_otable02_bfb62885:

    d "Yeah....."

translate english ch06_otable02_baa11e09:

    o "Put three fingers in.... Haaah...."

translate english ch06_otable02_814dc4a2:

    d "Y-yes... Okay."

translate english ch06_otable02_c8fa2748:

    o "And move your hand slightly up and down."

translate english ch06_otable02_2292fe40:

    d "Okay...."

translate english strings:
    old "손가락 3개를 삽입한다."
    new "Slide three fingers inside her."

translate english ch06_otable02_92f21ed5_7:

    n "What should I do?"

translate english ch06_otable02_48aa11d1:

    o "Ah.............."

translate english ch06_otable02_39ac5948:

    o "Aaah!!!"

translate english ch06_otable02_dec10593:

    d "Does it hurt??"

translate english ch06_otable02_83a52a43:

    o "No, keep going!!"

translate english ch06_otable02_8cae4f7f:

    o "Yes, just like that!!"

translate english ch06_otable02_7d8bc3a3:

    o "Aah!!!"

translate english ch06_otable02_7b0a2c76:

    d "D-does it feel good??"

translate english ch06_otable02_edb5afa2:

    o "Shut up!!"

translate english ch06_otable02_9898f550:

    d "Oh my God, Ollie.."

translate english ch06_otable02_d1599f3b:

    d "Your pussy is twitching."

translate english ch06_otable02_edb5afa2_1:

    o "Shut up!!"

translate english ch06_otable02_2a59814e:

    o "Harder!!"

translate english ch06_otable02_07336f3f:

    o "Aah!!!!!!!!!!"

translate english ch06_otable02_686c0865:

    o "Oh my God, [d_name]!!!!!!!"

translate english ch06_otable02_c519b862:

    o "Fuck!!!!!"

translate english ch06_otable02_fab68504:

    a "................"

translate english ch06_otable02_57a768f0:

    o "Harder!!!!!!"

translate english ch06_otable02_d0e5666f:

    d "Okay!!!"

translate english strings:
    old "자지를 꺼낸다."
    new "Take my cock out."

translate english ch06_otable02_92f21ed5_8:

    n "What should I do?"

translate english ch06_otable02_94ebecde:

    o "Faster!!!!............."

translate english ch06_otable02_2714d2e8:

    d "**(Damn it!!)**"

translate english ch06_otable02_efddc7fb:

    d "**(She's squeezing my fingers!!!!)**"

translate english ch06_otable02_e6ec622e:

    d "**(Should I just put it in now?)**"

translate english ch06_otable02_7ebacde1:

    d "**(This seems like the perfect moment, doesn't it??)**"

translate english ch06_otable02_b7ba6a08:

    d "**(Is this what Ollie meant by getting caught up in the mood???)**"

translate english ch06_otable02_f0d3c137:

    o "Aah!!!!!!!!!!!!!!!"

translate english ch06_otable02_b42ff212:

    o "I'm about to come!!!!!!"

translate english ch06_otable02_5051fbdc:

    d "What????!!!!"

translate english ch06_otable02_3fe56131:

    o "I'm going to come!!!!"

translate english ch06_otable02_d2e321db:

    o "[d_name].............."

translate english ch06_otable02_89dc5bc5:

    o "Aaaaaah!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch06_otable02_b58a0786:

    o "Aaaah..... Wait!!!!!!!!!"

translate english ch06_otable02_2543890c:

    d "Why????!!"

translate english ch06_otable02_62cd57b0:

    d "Are you about to come??!!"

translate english ch06_otable02_4e3e8f38:

    o "Aaaaaah!!!!!!!!!!"

translate english ch06_otable02_497eb76e:

    o "Ahh.............."

translate english ch06_otable02_6eef67a1:

    d "Ah!!!!!!!!!"

translate english ch06_otable02_fc9f68dd:

    o "Ah........."

translate english ch06_otable02_fac8215b:

    d "............"

translate english ch06_otable02_9c3556db:

    d "Wow, Ollie....."

translate english ch06_otable02_1a8e36a0:

    d "I've never seen anything like that......"

translate english ch06_otable02_cf27fa4e:

    d "Are you okay, Ollie?...."

translate english ch06_otable02_46ba34b5:

    o "N-no....."

translate english ch06_otable02_c4dca3d5:

    d "Now it's my turn, haha."

translate english ch06_otable02_7188c7da:

    d "Now let's have sex..."

translate english ch06_otable02_94baf420:

    a "Ahem!!"

translate english ch06_otable02_fac8215b_1:

    d "............"

translate english ch06_otable02_bcecb754:

    a ".........."

translate english ch06_otable02_6cbd768a:

    o "..............."

translate english ch06_otable02_654a7fc0:

    a "Look at you two perverts."

translate english ch06_otable02_a884c1d1:

    a "What the hell are you doing? Huh?"

translate english ch06_otable02_bcecb754_1:

    a ".........."

translate english ch06_otable02_a6fd7c27:

    a "Do you want to get arrested for public indecency??!!!"

translate english ch06_otable02_ebac6b8e:

    a "There are houses all around us! What the hell is this filthy behavior!!"

translate english ch06_otable02_5e3aec4e:

    d ".........."

translate english ch06_otable02_2983c27b_1:

    o "Haaah......"

translate english ch06_otable02_2196eaad:

    o "I thought the door was locked. How did you get in?"

translate english ch06_otable02_7d7a3cae:

    d "!!!!!!!!"

translate english ch06_otable02_b34f4202:

    d "**(I must not have locked it properly... Sigh.....)**"

translate english ch06_otable02_695263f9:

    d "**(I knew it didn't feel like it had clicked into place.....)**"

translate english ch06_otable02_efdce647:

    a "The door opened just fine! What the hell do you mean it was locked, you bitch!!!"

translate english ch06_otable02_f4db63d4:

    a "Your car was here, but I couldn't find you, so I came all the way back here."

translate english ch06_otable02_6c191f2d:

    a "What the hell is this? You're an embarrassment to the whole neighborhood."

translate english ch06_otable02_b6903939:

    a "Even porn stars wouldn't behave like you."

translate english ch06_otable02_2983c27b_2:

    o "Haaah......"

translate english ch06_otable02_191046bf:

    o "Can't you even lock a damn door properly?....."

translate english ch06_otable02_e6e1ddef:

    d "I-I'm sorry, Ollie..."

translate english ch06_otable02_77673f80_1:

    d "........."

translate english ch06_otable02_f9106a8e:

    o "Anyway, what brings you here?"

translate english ch06_otable02_a6b0ea2e:

    o "You could've called me on your way."

translate english ch06_otable02_1fd6aeab:

    a "You think I didn't call you, bitch??!!"

translate english ch06_otable02_a3619ba9:

    o "Damn it, I left my phone in the kitchen.."

translate english ch06_otable02_ea1104f5:

    a "I came to talk to you, but what perfect timing."

translate english ch06_otable02_08d94b8e:

    a "Why don't you go ahead and squirt like a whale again?"

translate english ch06_otable02_98964dfd:

    a "You filthy fucking whore!!!"

translate english ch06_otable02_728edf9d:

    o "Shut up."

translate english ch06_otable02_859c808e:

    a "[d_name]!!"

translate english ch06_otable02_4bb59dbf:

    d "Yes??!!"

translate english ch06_otable02_6c670bf6:

    a "Come on, let's go for a drive."

translate english ch06_otable02_b509a417:

    a "Let Ollie get some rest."

translate english ch06_otable02_cb971996:

    d "O-okay... Sure."

translate english ch06_otable02_e66c3096:

    a "After squirting that much, she must need a rest."

translate english ch06_otable02_579d8b7d:

    a "Come on, get up!!"

translate english ch06_otable02_cb971996_1:

    d "O-okay... Sure."

translate english ch06_otable02_35267703:

    a "Listen here, Ollie, you bitch."

translate english ch06_otable02_02d82547:

    a "Go have fun with all those guys in your contacts, got it?"

translate english ch06_otable02_eed351cb:

    a "And leave [d_name] alone, you bitch."

translate english ch06_otable02_fcfbb2bc:

    o "Shut up, Amanda."

translate english ch06_otable02_db906198:

    o "Worry about your own damn business before lecturing me."

translate english ch06_otable02_3ae955e6:

    o "Ah!"

translate english ch06_otable02_b0dd8988:

    a "**(That bitch is going to get herself into serious trouble someday.)**"

translate english ch06_otable02_4d62a67b:

    a "**(It's a miracle she's made it this far without getting into serious trouble.)**"

translate english ch06_otable02_e5c36b54:

    d "..........."

translate english ch06_otable02_484b7574:

    o "Damn it.........."

translate english ch06_otable02_25ba0e2f_1:

    o "......"

translate english ch06_otable02_4386253e:

    o "I'm so embarrassed... So embarrassed..."

translate english ch06_otable02_71f921e6:

    o "What the hell just happened..."

translate english ch06_adrive01_0850e4bc:

    n "Amanda and [d_name] were driving along a mountain road at night."

translate english ch06_adrive01_f5db25ab:

    n "Amanda was furious, and as she led him farther along the unfamiliar road in the darkness, he began to feel increasingly uneasy."

translate english ch06_adrive01_d102715e:

    d "I'm sorry, Amanda...."

translate english ch06_adrive01_4cd15d58:

    d "....."

translate english ch06_adrive01_fac8215b:

    d "............"

translate english ch06_adrive01_64417d70:

    d "You've been silent for an entire hour now."

translate english ch06_adrive01_7b24e569:

    d "Amanda....."

translate english ch06_adrive01_5b6e4a64:

    d "Please, just say something."

translate english ch06_adrive01_ce9b8c46:

    a "You don't have to apologize to me."

translate english ch06_adrive01_fd56ab50:

    a "You and Ollie are both adults, after all."

translate english ch06_adrive01_0fe15347:

    a "It's just....."

translate english ch06_adrive01_4cd15d58_1:

    d "....."

translate english ch06_adrive01_8b94fc46:

    a "I'm a little shocked, that's all."

translate english ch06_adrive01_229a8ed6:

    a "You know."

translate english ch06_adrive01_230c07da:

    a "Even though I tell you what you should and shouldn't do with your life.."

translate english ch06_adrive01_62a4740a:

    a "I'm just a middle-aged woman you happened to live with for a few years."

translate english ch06_adrive01_5e3aec4e:

    d ".........."

translate english ch06_adrive01_72f1ed2c:

    a "What I'm trying to say is.."

translate english ch06_adrive01_98f99527:

    a "Your life will go in whatever direction you choose."

translate english ch06_adrive01_a7baf9c9:

    a "Every choice you make, good or bad, will have its own consequences."

translate english ch06_adrive01_f9b4991b:

    a "Do you understand what I'm saying?"

translate english ch06_adrive01_77673f80:

    d "........."

translate english ch06_adrive01_7e5ae947:

    d "Yes, Amanda. I understand what you mean..."

translate english ch06_adrive01_593f1973:

    a "Then don't do anything that'll ruin your life."

translate english ch06_adrive01_203cc60b:

    d "......."

translate english ch06_adrive01_48f09531:

    a "[d_name]..."

translate english ch06_adrive01_174f2fa1:

    a "Ollie is my little sister.... Oh my God."

translate english ch06_adrive01_052fb45e:

    a "She's my sister.."

translate english ch06_adrive01_e87384cd:

    a "And on top of that, she's still legally married."

translate english ch06_adrive01_8f17d5ab:

    d "I know, Amanda."

translate english ch06_adrive01_55c02367:

    a "......."

translate english ch06_adrive01_2954a802:

    d "Haaah.........."

translate english ch06_adrive01_b5ac82ff:

    a "The way I see it, you're like a young colt that's broken out of its pen and doesn't know where to run."

translate english ch06_adrive01_e9ca0b76:

    a "Do you understand what I mean?"

translate english ch06_adrive01_9a9eada1:

    a "You're a wild young colt, going crazy with your newfound freedom."

translate english ch06_adrive01_77673f80_1:

    d "........."

translate english ch06_adrive01_9343147b:

    d "That's quite a poetic way of putting it..."

translate english ch06_adrive01_732a8756:

    a "......"

translate english ch06_adrive01_b806a9aa:

    a "You and Ollie are playing with fire."

translate english ch06_adrive01_7e570cbf:

    a "Listen."

translate english ch06_adrive01_43d28e9f:

    a "I know guys your age think about sex from the moment they wake up until they fall asleep."

translate english ch06_adrive01_77673f80_2:

    d "........."

translate english ch06_adrive01_d623a19f:

    a "You can fuck as many other women as you want."

translate english ch06_adrive01_aa541b1e:

    a "I don't even care if you fuck that hot college professor of yours."

translate english ch06_adrive01_1dc5b89b:

    a "As long as she consents, of course. And...."

translate english ch06_adrive01_bf1fc421:

    a "And assuming you know how to protect yourself, of course."

translate english ch06_adrive01_5e3aec4e_1:

    d ".........."

translate english ch06_adrive01_80e04bef:

    d "You sound a lot like Ollie..."

translate english ch06_adrive01_31d796dc:

    a "...."

translate english ch06_adrive01_68b02572:

    a "If you keep doing those things with my little sister..."

translate english ch06_adrive01_4cd15d58_2:

    d "....."

translate english ch06_adrive01_3494a953:

    a "You'll eventually end up losing me forever, too."

translate english ch06_adrive01_836b4c54:

    a "You don't really want that, do you?"

translate english ch06_adrive01_7f43abb6:

    d "But you wanted it too, Amanda."

translate english ch06_adrive01_4bace820:

    a "What??"

translate english ch06_adrive01_a4d72727:

    a "What are you talking about?"

translate english ch06_adrive01_a610b1c8:

    a "I wanted it... Wanted what?"

translate english ch06_adrive01_d5694d57:

    a "Are you saying I wanted you to fuck Olivia??"

translate english ch06_adrive01_77673f80_3:

    d "........."

translate english ch06_adrive01_9f81a1bf:

    d "Back at home..."

translate english ch06_adrive01_906d6328:

    d "And at the beach, too.."

translate english ch06_adrive01_55c02367_1:

    a "......."

translate english ch06_adrive01_6c48fef4:

    d "When we were both naked, touching each other's bodies..."

translate english ch06_adrive01_55c02367_2:

    a "......."

translate english ch06_adrive01_9cb92dad:

    d "When I touched your..."

translate english ch06_adrive01_20fc1279:

    d "When I touched and caressed your pussy, you didn't tell me to stop."

translate english ch06_adrive01_3ff5ae99:

    d "In fact, you were moaning and enjoying it."

translate english ch06_adrive01_55c02367_3:

    a "......."

translate english ch06_adrive01_b595c43a:

    d "What was that about?"

translate english ch06_adrive01_56bf299a:

    d "...."

translate english ch06_adrive01_90f51ac1:

    d "Are you like Mary, only letting a man touch you when you need it?"

translate english ch06_adrive01_8c12ef38:

    a "Mary?"

translate english ch06_adrive01_cd78d049:

    d "Oh, that just slipped out. I didn't mean Mary..."

translate english ch06_adrive01_399db8e5:

    a "............"

translate english ch06_adrive01_7ac77a80:

    d "But it's true."

translate english ch06_adrive01_4d963a63:

    d "When you're aroused and enjoying my touch, your body responds to me."

translate english ch06_adrive01_edbb7d05:

    d "........"

translate english ch06_adrive01_fa1af8db:

    d "Isn't that enough?"

translate english ch06_adrive01_55c02367_4:

    a "......."

translate english ch06_adrive01_84ae94b7:

    a "Nothing like that is ever going to happen again."

translate english ch06_adrive01_425d6d3a:

    d "N-no, that's not what I meant.."

translate english ch06_adrive01_b3280c9c:

    a "And what does any of that have to do with you fooling around with Ollie?"

translate english ch06_adrive01_e5c36b54:

    d "..........."

translate english ch06_adrive01_2398a3e0:

    d "Haaah...... I don't know either...."

translate english ch06_adrive01_1e9926de:

    d "It just came out."

translate english ch06_adrive01_a79822de:

    a "........"

translate english ch06_adrive01_e3ba8d67:

    a "What the hell are you trying to say? Huh?"

translate english ch06_adrive01_07d8f666:

    a "Are you saying that because I let you touch me like that, you think it's okay to do the same with Ollie??"

translate english ch06_adrive01_5e3aec4e_2:

    d ".........."

translate english ch06_adrive01_12cf621e:

    d "What I'm trying to say is.."

translate english ch06_adrive01_b4c19bf9:

    d "Haaah..... I don't know."

translate english ch06_adrive01_93f4d4b9:

    d "Lately, all I can think about from the moment I wake up is sex......"

translate english ch06_adrive01_a79822de_1:

    a "........"

translate english ch06_adrive01_d102715e_1:

    d "I'm sorry, Amanda...."

translate english ch06_adrive01_5e3aec4e_3:

    d ".........."

translate english ch06_adrive01_a935bd16:

    d "But is something going on?"

translate english ch06_adrive01_f0be6f74:

    d "You seem like something's bothering you."

translate english ch06_adrive01_399db8e5_1:

    a "............"

translate english ch06_adrive01_503c3567:

    a "I just went to the restaurant to have a drink with Ollie."

translate english ch06_adrive01_5a9729bb:

    a "It's nothing serious."

translate english ch06_adrive01_55c02367_5:

    a "......."

translate english ch06_adrive01_884ab416:

    a "I just wanted to take my mind off things for a while..."

translate english ch06_adrive01_fe0810cb:

    d "I see......"

translate english ch06_adrive01_203cc60b_1:

    d "......."

translate english ch06_adrive01_be71ae33:

    d "By the way, where are we going?"

translate english ch06_adrive01_c05047e1:

    a "Somewhere only I know about."

translate english ch06_adrive01_55c02367_6:

    a "......."

translate english ch06_adrive01_ec54a81a:

    a "Well, actually, that damn Frank knows about it too."

translate english ch06_adrive01_5e3aec4e_4:

    d ".........."

translate english ch06_adrive01_a90dc2a1:

    d "I see....."

translate english ch06_adrive01_08bf2f30:

    a "We're here."

translate english ch06_adrive01_4ef70c31:

    a "Let's get out."

translate english ch06_adrive01_a5911b48:

    n "He quietly watched Amanda from behind."

translate english ch06_adrive01_002b259b:

    n "She looked sadder and lonelier than he'd ever seen her."

translate english ch06_adrive01_7968ef92:

    d "**(No, something's definitely happened.)**"

translate english ch06_adrive01_70274242:

    d "**(What the hell is going on?)**"

translate english ch06_adrive01_edbb7d05_1:

    d "........"

translate english ch06_adrive01_ad2304f4:

    d "Wow.."

translate english ch06_adrive01_4df0d189:

    d "I had no idea a place like this existed.."

translate english ch06_adrive01_f05cc0ac:

    d "Milfheim is actually a pretty beautiful place when you look at it like this."

translate english ch06_adrive01_5e3aec4e_5:

    d ".........."

translate english ch06_adrive01_8fcb1677:

    d "It looks so peaceful.."

translate english ch06_adrive01_c2e4ee76:

    a "It does, doesn't it?...."

translate english ch06_adrive01_e31d2b26:

    a "I'm sorry I snapped at you in the car earlier."

translate english ch06_adrive01_b2b821d1:

    a "........."

translate english ch06_adrive01_75e0cf00:

    a "I guess I was just a little shocked...."

translate english ch06_adrive01_71336360:

    a "You know."

translate english ch06_adrive01_2a8c4117:

    a "This is really embarrassing."

translate english ch06_adrive01_edbb7d05_2:

    d "........"

translate english ch06_adrive01_73eb0901:

    d "No.... I'm sorry too, Amanda.."

translate english strings:
    old "아만다를 껴안는다."
    new "Hug Amanda."

translate english ch06_adrive01_92f21ed5:

    n "What should I do?"

translate english ch06_adrive01_26b7d2f4:

    d "I love you, Amanda.."

translate english ch06_adrive01_a79822de_2:

    a "........"

translate english ch06_adrive01_7683f266:

    d "But I know you're hiding something from me right now.."

translate english ch06_adrive01_a79822de_3:

    a "........"

translate english ch06_adrive01_4dbce812:

    d "Tell me what's going on.."

translate english ch06_adrive01_3f1dc92f:

    d "Come on..."

translate english ch06_adrive01_ded16634:

    a "It's not something I need to tell you."

translate english ch06_adrive01_8e7225bf:

    d "No, don't say that."

translate english ch06_adrive01_18d5d8f1:

    d "I told you before."

translate english ch06_adrive01_ab3991fb:

    d "I'll always be on your side, Amanda."

translate english ch06_adrive01_7070dd97:

    d "Always."

translate english ch06_adrive01_fc89170a:

    a "................."

translate english ch06_adrive01_43fd69d1:

    tv "And now, in local news."

translate english ch06_adrive01_4edecdca:

    tv "Early yesterday morning, a 62-year-old man was found dead inside his vehicle at a highway rest stop in Milfheim County."

translate english ch06_adrive01_4a0dae09:

    tv "The deceased has been identified as Daniel Reed, a retired geology professor."

translate english ch06_adrive01_083af9d3:

    tv "According to police, Mr. Reed was discovered by a truck driver who stopped at the rest area early that morning."

translate english ch06_adrive01_1accbf56:

    tv "Police believe Mr. Reed died from a gunshot wound. A firearm and what appears to be a suicide note were also found inside the vehicle."

translate english ch06_adrive01_0f572cd0:

    tv "Investigators initially considered suicide the most likely explanation, but are now conducting further inquiries to determine the exact circumstances of his death."

translate english ch06_adrive01_d42b0a5c:

    tv "No suspects have been identified at this time, and police are continuing to gather information."

translate english ch06_adrive01_1900efe7:

    tv "In other news."

translate english ch06_adrive01_c90173e8:

    f "Man, I'm exhausted."

translate english ch06_adrive01_fde1447e:

    f "I'm home."

translate english ch06_adrive01_fff104d8:

    a "Long day, huh?"

translate english ch06_adrive01_ecee72e4:

    f "Something smells good."

translate english ch06_adrive01_130c5b55:

    f "What's for dinner?"

translate english ch06_adrive01_55c8a893:

    a "Tilapia steak."

translate english ch06_adrive01_085169e5:

    a "Go take a shower first."

translate english ch06_adrive01_01524bab:

    f "Oh... Yeah, I should."

translate english ch06_adrive01_b150bef3:

    f "I worked up quite a sweat today."

translate english ch06_adrive01_69882c93:

    f "I feel all sticky."

translate english ch06_adrive01_6824b4c9:

    a "!!!!!!!!!!!!!!"

translate english ch06_adrive01_b04f03fa:

    a "You crazy bastard!!!!!!!!!!"

translate english ch06_adrive01_e613151e:

    f "What??"

translate english ch06_adrive01_6b179dd3:

    f "What the hell was that for??!!"

translate english ch06_adrive01_5e84ebae:

    f "Why are you picking a fight with a man who's just come home exhausted from work, woman?!!!"

translate english ch06_adrive01_6c9063fc:

    a "Are you trying to let the whole damn neighborhood know about it now, huh??!!!!!!"

translate english ch06_adrive01_759d6f08:

    a "You crazy bastard! Are you really determined to push me to my breaking point?!!!!!!!!!!"

translate english ch06_adrive01_498427f8:

    f "Keep your voice down, woman!!!!"

translate english ch06_adrive01_eecdfa76:

    f "What the hell am I supposed to be telling the neighborhood?"

translate english ch06_adrive01_088ba8c5:

    f "Your husband comes home after working his ass off, and instead of helping him wash up, you start acting like a lunatic!!!!!!"

translate english ch06_adrive01_2d8c6500:

    f "What the hell is wrong with you all of a sudden??!!!"

translate english ch06_adrive01_63bbb2aa:

    a "Oh, my head........"

translate english ch06_adrive01_dfdcea59:

    a "Haaah......"

translate english ch06_adrive01_30a20691:

    a "Check your ass."

translate english ch06_adrive01_d083e681:

    f "What the hell are you talking about? My ass?!!!!"

translate english ch06_adrive01_060479f7:

    a "I said check your fucking ass!!!!!!!!"

translate english ch06_adrive01_3a1dbee3:

    f "!!!!!!!!!!!!!"

translate english ch06_adrive01_a2efc8d1:

    f "..........."

translate english ch06_adrive01_c75a02a1:

    a "Real nice, huh???!!!"

translate english ch06_adrive01_f405df9a:

    a "What, you wanted the whole neighborhood to see it, so you left it stuck there, you son of a bitch!!!!!!!!!"

translate english ch06_adrive01_b41353ac:

    f "Grrr...."

translate english ch06_adrive01_3fb6987b:

    f "That crazy bitch Emma........."

translate english ch06_adrive01_ac5f81d1:

    a "Emma??!!!!"

translate english ch06_adrive01_6e6c8f7f:

    a "Unbelievable."

translate english ch06_adrive01_1f709dff:

    a "Emma??????!!!!"

translate english ch06_adrive01_b5f6a7c3:

    a "You're not even trying to hide it anymore??!!!!"

translate english ch06_adrive01_d0b2c79a:

    a "I'm sick of this! So fucking sick of it!!!!!!!!!"

translate english ch06_adrive01_50d8e995:

    a "I'm leaving this goddamn house!!!!!!!"

translate english ch06_adrive01_ed64efb0:

    a "You and I are finished!!!!!!"

translate english ch06_adrive01_ccba50ae:

    f "Where the hell do you think you're going?!!!!!!"

translate english ch06_adrive01_c2eecae6:

    a "Let go of me!!!!!!!!"

translate english ch06_adrive01_1806aa36:

    f "Argh!!"

translate english ch06_adrive01_cf34c1a3:

    f "Y-you fucking bitch....."

translate english ch06_adrive01_f01d187f:

    a "Aaaaaah!!!!!!!!!!!!!"

translate english ch06_adrive01_fac8215b_1:

    d "............"

translate english ch06_adrive01_24aecdc6:

    d "Oh my God, Amanda......"

translate english ch06_adrive01_faf3d165:

    d "I'm so sorry....."

translate english ch06_adrive01_b45ae0cf:

    d "!!!"

translate english ch06_adrive01_1eb3882b:

    d "Oh my God......"

translate english ch06_adrive01_e51137be:

    a "See?"

translate english ch06_adrive01_49fdb535:

    a "That's what a man who's spent his entire life obsessed with sex looks like."

translate english ch06_adrive01_0a62d983:

    a "Frank, that fucking bastard."

translate english ch06_adrive01_a66dc56a:

    a "That's what a man who has never learned to control himself looks like."

translate english ch06_adrive01_fac8215b_2:

    d "............"

translate english ch06_adrive01_22462bb4:

    d "Oh my God........"

translate english ch06_adrive01_54abf602:

    d "God damn Frank....."

translate english ch06_adrive01_b2b821d1_1:

    a "........."

translate english ch06_adrive01_b9aa2f47:

    d "What are you going to do now?......"

translate english ch06_adrive01_052b2fdb:

    a "I'm thinking about it....."

translate english ch06_adrive01_55c02367_7:

    a "......."

translate english ch06_adrive01_d618a08b:

    a "That's why I went to talk to Ollie....."

translate english ch06_adrive01_5e3aec4e_6:

    d ".........."

translate english ch06_adrive01_14af421e:

    d "I see......"

translate english ch06_adrive01_1fd558b1:

    d "Man...."

translate english ch06_adrive01_871a10ef:

    d "Of all the times for that to happen......."

translate english ch06_adrive01_b2b821d1_2:

    a "........."

translate english ch06_adrive01_69e71bb1:

    a "Yeah."

translate english ch06_adrive01_0e7e4897:

    a "Your timing was just fucking perfect, kid."

translate english ch06_adrive01_77673f80_4:

    d "........."

translate english ch06_adrive01_6e5e6a32:

    a "One thing's for sure......."

translate english ch06_adrive01_08aa5fc2:

    a "I've reached the end of my patience."

translate english ch06_adrive01_3b276259:

    a "Fuck Frank."

translate english ch06_adrive01_17acc774:

    a "I'm done with Frank."

translate english ch06_adrive01_e5c36b54_1:

    d "..........."

translate english ch06_adrive01_5b881c0e:

    a "Why did I devote my entire life to a man like that....."

translate english ch06_adrive01_fec4837e:

    a "I'm so angry with myself... So damn angry....."

translate english ch06_adrive01_861c80d7:

    a "I've reached a turning point in my life....."

translate english ch06_adrive01_17659cc8:

    a ".............."

translate english ch06_adrive01_10c6b0d1:

    a "I'm at a turning point in my life now......."

translate english ch06_adrive01_c57712de:

    a "I'm going to take my life back."

translate english ch06_adrive01_55c02367_8:

    a "......."

translate english ch06_adrive01_e26366e9:

    a "I'm going to reclaim the life I've lost—my own life."

translate english ch06_adrive01_12e48815:

    a "I'm not going home tonight."

translate english ch06_adrive01_e5c36b54_2:

    d "..........."

translate english ch06_adrive01_a2020ee5:

    d "I'll stay with you, Amanda."

translate english ch06_adrive01_46ddc131:

    a "I'm not going home tomorrow, either."

translate english ch06_adrive01_02e6d643:

    a "I'm never going back."

translate english strings:
    old ""
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
