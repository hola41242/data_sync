translate english v01_mcmary_phone_fake_1b022507:

    n "She couldn't fall asleep even as midnight approached."

translate english v01_mcmary_phone_fake_59098e06:

    n "Her mind was tangled in a storm of emotions—racing heartbeat, excitement, embarrassment, and a restless yearning."

translate english v01_mcmary_phone_fake_335baa5e:

    d "......................"

translate english v01_mcmary_phone_fake_a9039faa:

    d "Damn..."

translate english v01_mcmary_phone_fake_29faac99:

    d "What should I reply..."

translate english v01_mcmary_phone_fake_df5f5a08:

    d "Why is she asking for a photo at this hour?"

translate english v01_mcmary_phone_fake_838255e4:

    d "Hmm....."

translate english v01_mcmary_phone_fake_80a02690:

    d "Damn… I can’t stop replaying what she said earlier."

translate english v01_mcmary_phone_fake_91738439:

    d "This is driving me crazy."

translate english v01_mcmary_phone_fake_a797f6ce:

    d "............."

translate english v01_mcmary_phone_fake_a6f63505:

    d "She said she imagined sucking my cock..."

translate english v01_mcmary_phone_fake_77673f80:

    d "........."

translate english v01_mcmary_phone_fake_b13e2a21:

    d "What would her reaction be if I showed her mine?"

translate english v01_mcmary_phone_fake_71ab3056:

    d "Would she think I'm a pervert?"

translate english v01_mcmary_phone_fake_17a56b6e:

    d "She clearly said she fantasizes too. It's just a picture, what's the big deal?"

translate english v01_mcmary_phone_fake_6422c193:

    d "........................."

translate english v01_mcmary_phone_fake_3cdc152e:

    d "Damn it... Whatever happens, happens."

translate english v01_mcmary_phone_fake_9869740c:

    d "Mary's an adult and so am I..."

translate english v01_mcmary_phone_fake_62190eb9:

    d "Are you really going to do this?"

translate english v01_mcmary_phone_fake_af34239f:

    n "She was shocked by the photo [d_name] sent."

translate english v01_mcmary_phone_fake_26bf5a06:

    n "The first shock was that it resembled something she'd only seen in pornography during her youth,"

translate english v01_mcmary_phone_fake_a23a0197:

    n "and the second shock came from the thought that this might be [d_name]'s."

translate english v01_mcmary_phone_fake_80086b98:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_mcmary_phone_fake_a90459a8:

    m "What the hell is this?!"

translate english v01_mcmary_phone_fake_f561e205:

    m "What the hell is he doing?"

translate english v01_mcmary_phone_fake_ed914577:

    d "You crazy shit. What the hell are you doing?"

translate english v01_mcmary_phone_fake_ce5b25da:

    d "Are you trying to end things with Mary today?"

translate english v01_mcmary_phone_fake_00c76add:

    d "............................."

translate english v01_mcmary_phone_fake_120e7da2:

    d "Oh my god. The damage is already done."

translate english v01_mcmary_phone_fake_140e8cf2:

    d "I want to do it again."

translate english v01_mcmary_phone_fake_03d16520:

    d "Again...."

translate english v01_mcmary_phone_fake_9e0ae4cf:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english v01_mcmary_phone_fake_84390583:

    n "The second photo hit her with an even greater shock than the first."

translate english v01_mcmary_phone_fake_b8014335:

    n "The composition of that photo, capturing both [d_name]'s cock and his face simultaneously, was even more explicit."

translate english v01_mcmary_phone_fake_1ffc0b61:

    n "The visual impact was so intense it left her barely clinging to her sanity."

translate english v01_mcmary_phone_fake_6552828f:

    m "Oh my god [d_name]!!"

translate english v01_mcmary_phone_fake_939ff9bd:

    m "Again?"

translate english v01_mcmary_phone_fake_7fd66729:

    d "What the hell did I do?"

translate english v01_mcmary_phone_fake_ccfb1986:

    d "This is like exhibitionism."

translate english v01_mcmary_phone_fake_64059ce1:

    m "Oh my god [d_name]."

translate english v01_mcmary_phone_fake_c6018fb3:

    n "The shock of the photos was truly immense."

translate english v01_mcmary_phone_fake_7725259e:

    n "She felt her pussy twitch and grow wet."

translate english v01_mcmary_phone_fake_454742b6:

    m "............"

translate english v01_mcmary_phone_fake_e86d97f0:

    m "You've really bulked up."

translate english v01_mcmary_phone_fake_fb0a14c3:

    m "Oh my god.."

translate english v01_mcmary_phone_fake_3dc8baae:

    n "She sat perched on the bed, rubbing her face to ease the shock."

translate english v01_mcmary_phone_fake_9f09b050:

    m "Oh my god oh my god oh my god..."

translate english v01_mcmary_phone_fake_3cda8ec9:

    m "What the hell is going on."

translate english v01_mcmary_phone_fake_6e0b28e4:

    m "Oh no."

translate english v01_mcmary_phone_fake_91b71382:

    m "What the hell is going on here?"

translate english v01_mcmary_phone_fake_d266a19b:

    m "(( Damn you, [d_name]. ))"

translate english v01_mcmary_phone_fake_6e5b0d08:

    m "(( What did you do to me? ))"

translate english v01_mcmary_phone_fake_fb03f0fc:

    m "(( Was there a true nature hidden behind that innocent face? ))"

translate english v01_mcmary_phone_fake_7336edab:

    m "(( Oh my god. ))"

translate english v01_mcmary_phone_fake_766b8fff:

    m "(( Did my words today give him confidence? ))"

translate english v01_mcmary_phone_fake_853c0fbc:

    n "She picked up the phone again and stared at the photo of his cock."

translate english v01_mcmary_phone_fake_7ece3adb:

    n "This time she examined its shape, color, and veins more closely."

translate english v01_mcmary_phone_fake_245aeca1:

    n "And she felt something flowing inside her thighs."

translate english v01_mcmary_phone_fake_336c3e50:

    m "Oh my god, oh my god, oh my god..."

translate english v01_mcmary_phone_fake_b27c39d7:

    m "............................"

translate english v01_mcmary_phone_fake_c07df898:

    m "What am I supposed to do..."

translate english ch02_cafe02_fake_264304ae:

    o "What are you two talking about that's so fun? Hehe."

translate english ch02_cafe02_fake_5d21c752:

    o "Let me join the conversation too."

translate english ch02_cafe02_fake_5b190d17:

    a "You know, conversations with a college freshman are pretty predictable, aren’t they?"

translate english ch02_cafe02_fake_18c74f3d:

    a "It’s this little guy’s love story. Classic stuff, absolutely classic, haha."

translate english ch02_cafe02_fake_97d76a78:

    o "Oh! That’s my specialty."

translate english ch02_cafe02_fake_e4143106:

    o "What kind of romantic trouble could our lovely [d_name] be having?"

translate english ch02_cafe02_fake_735fa177:

    o "Don’t tell me it’s something too embarrassing to tell me? Hehe."

translate english ch02_cafe02_fake_a1392911:

    d "(( Oh my God... ))"

translate english ch02_cafe02_fake_246e9570:

    d "(( Were her boobs always that big? ))"

translate english ch02_cafe02_fake_6c4ddfd4:

    d "(( .............. ))"

translate english ch02_cafe02_fake_69de5c76:

    d "(( They’re on par with Amanda’s... ))"

translate english ch02_cafe02_fake_1b39920b:

    o "(( Heh. ))"

translate english ch02_cafe02_fake_abf5731d:

    o "(( [d_name]… he’s gotten bold enough to stare now. ))"

translate english ch02_cafe02_fake_bf913b7f:

    o "(( He can’t even keep a poker face, just staring like an idiot. No wonder women don’t like that. ))"

translate english ch02_cafe02_fake_a37c1087:

    o "(( Alright. So you’re an adult now, is that it? ))"

translate english ch02_cafe02_fake_f816fca2:

    n "When she saw [d_name] again after a year, she felt that he had become more mature."

translate english ch02_cafe02_fake_1dba2dd2:

    n "And when she hugged him, she could feel that his body had grown firmer and broader."

translate english ch02_cafe02_fake_34df0344:

    n "In other words, it meant she could now put aside her guilty conscience and speak to [d_name] more comfortably."

translate english ch02_cafe02_fake_40fc782d:

    o "(( Then let’s have an adult conversation. Why is everyone beating around the bush like this? ))"

translate english ch02_cafe02_fake_806076cc:

    o "(( How long is Amanda going to keep treating [d_name] like a child? ))"

translate english ch02_cafe02_fake_96d3e87b:

    o "(( What boring people. ))"

translate english ch02_cafe02_fake_b9afe496:

    o "(( Hmm..... ))"

translate english ch02_cafe02_fake_b6c83faf:

    o "(( What are you plotting, Amanda? ))"

translate english ch02_cafe02_fake_99932ba7:

    o "(( You don’t actually want him to remain your [d_name] forever, do you? ))"

translate english ch02_cafe02_fake_8da3be8e:

    o "(( Are you afraid he’ll meet a woman and leave your side? ))"

translate english ch02_cafe02_fake_a49e9bec:

    o "What’s going on? Aren’t you going to tell me?"

translate english ch02_cafe02_fake_188c7611:

    a "Oh, it’s nothing."

translate english ch02_cafe02_fake_e924df6b:

    a "He broke up with his girlfriend not long before coming home."

translate english ch02_cafe02_fake_7dc15aca:

    a "So we were just talking trash about her together."

translate english ch02_cafe02_fake_a704a145:

    o "Haha, sis. Aren’t you taking [d_name]’s side a bit too much?"

translate english ch02_cafe02_fake_6e13db24:

    o "You should hear the girl’s side of the story too."

translate english ch02_cafe02_fake_15f848c2:

    o "Our prince might’ve screwed things up with her, you know."

translate english ch02_cafe02_fake_747020af:

    o "If you just keep siding with him because he seems pitiful, it might backfire."

translate english ch02_cafe02_fake_e755e72b:

    a "She started seeing another guy just a week after they broke up."

translate english ch02_cafe02_fake_2b784277:

    a "How could she do that? The world’s gone crazy."

translate english ch02_cafe02_fake_e14e822a:

    o "Goodness, Amanda."

translate english ch02_cafe02_fake_3123e31a:

    o "These days, a week almost makes her look modest."

translate english ch02_cafe02_fake_2e67596d:

    o "Plenty of people date two at once. How can you blame her for seeing someone else after they broke up?"

translate english ch02_cafe02_fake_859ebdcd:

    o "Right?"

translate english ch02_cafe02_fake_baafd6f2:

    o "[d_name] should date different women too. That’s how he’ll become more experienced."

translate english ch02_cafe02_fake_83d9ba67:

    o "There’s nothing wrong with that."

translate english ch02_cafe02_fake_d6d57322:

    a "Oh really? Please don’t include the two of us in that world of yours."

translate english ch02_cafe02_fake_a836f895:

    a "Our [d_name] is a rare romantic in this day and age."

translate english ch02_cafe02_fake_27283fab:

    a "He’ll meet one woman and become part of a legendary couple, like Romeo and Juliet."

translate english ch02_cafe02_fake_37442ace:

    n "Olivia felt grateful to Amanda for a moment."

translate english ch02_cafe02_fake_d20e7399:

    n "Because Amanda had followed along with the twisted direction of the conversation and set the stage for her to deliver the decisive line."

translate english ch02_cafe02_fake_23ac5f5d:

    o "Romeo and Juliet? Ha… what is this, the Middle Ages?"

translate english ch02_cafe02_fake_69aa9c44:

    o "How tragic."

translate english ch02_cafe02_fake_75365cc6:

    o "If you'd lived with me, you'd be fucking with every college girl around by now, ha ha ha."

translate english ch02_cafe02_fake_0da88778:

    d "(( ...... ))"

translate english ch02_cafe02_fake_ee89e95a:

    o "(( Of course you'll have sex with me too, hehe. ))"

translate english ch02_cafe02_fake_a909ef44:

    o "(( Until I'm sore every single day. ))"

translate english ch02_cafe02_fake_8e12dd1c:

    o "(( I could teach you the pleasures only a mature woman can give… ))"

translate english ch02_cafe02_fake_9485f3c8:

    a "What?! Goodness, Olivia. What are you talking about?"

translate english ch02_cafe02_fake_8e705f51:

    a "Do you think college is a place to go for dating?"

translate english ch02_cafe02_fake_bdc9debe:

    a "You haven’t seen [d_name] in a year, and that’s all you have to say?"

translate english ch02_cafe02_fake_7a287c63:

    a "Goodness. This is why I keep my distance from you."

translate english ch02_cafe02_fake_709db80d:

    a "I hate people whose heads are filled with nothing but sex."

translate english ch02_cafe02_fake_af2421a9:

    o "Haha, sis. Don’t judge me."

translate english ch02_cafe02_fake_1396a3ec:

    o "I’m just being honest."

translate english ch02_cafe02_fake_2d45c588:

    o "(( And your head is just as full of sex as mine. ))"

translate english ch02_cafe02_fake_95a131e8:

    o "I said it because I want [d_name] to become a more attractive man."

translate english ch02_cafe02_fake_880f71ab:

    o "Wouldn’t it be great to be loved by everyone, from young girls to middle-aged women?"

translate english ch02_cafe02_fake_30185867:

    o "(( It wouldn’t be bad for you either, sis. ))"

translate english ch02_cafe02_fake_c0864009:

    o "Hey, [d_name]."

translate english ch02_cafe02_fake_4f1b8dc1:

    o "Forget boring Amanda and go on a date with me instead."

translate english ch02_cafe02_fake_819c4034:

    o "How about being my cute boyfriend just for today?"

translate english ch02_cafe02_fake_ff945e04:

    n "He felt a little confused."

translate english ch02_cafe02_fake_041600b7:

    n "He had seen her from time to time, but he hadn’t known she was this kind of woman."

translate english ch02_cafe02_fake_eb805c52:

    n "And in that moment, he was completely caught in the web she had spun."

translate english ch02_cafe02_fake_e6b6e35a:

    a "Oh really? Seeing [d_name] just laughing, you two seem to get along very well."

translate english ch02_cafe02_fake_eefb3974:

    a "Going on a honeymoon next, are you?"

translate english ch02_cafe02_fake_4832b973:

    a "Have fun. I’m going to the restroom."

translate english ch02_cafe02_fake_49b3d461:

    a "Oh! And let me know once you decide on your child’s name."

translate english ch02_cafe02_fake_9887816e:

    o "(( Haha. See that? ))"

translate english ch02_cafe02_fake_e36884fd:

    o "(( The true nature hidden deep inside you is starting to squirm, isn’t it? ))"

translate english ch02_cafe02_fake_f4b2aeab:

    o "(( That’s what happens when you keep it all bottled up. You age faster. ))"

translate english ch02_cafe02_fake_9f514d57:

    a "(( That bitch never changes. ))"

translate english ch02_cafe02_fake_51cc4855:

    a "(( How can she stay the same no matter how old she gets? ))"

translate english ch02_cafe02_fake_187399cc:

    a "(( If it’s a man’s cock, she’ll jump up even in her sleep! ))"

translate english ch02_cafe02_fake_8a90017e:

    a "(( Ha! So you’re challenging your big sister, is that it? ))"

translate english ch02_cafe02_fake_1b811306:

    o "Hehehe."

translate english ch02_cafe02_fake_58b5c5fb:

    o "Think about it carefully, [d_name]."

translate english ch02_cafe02_fake_2ec73271:

    o "You can’t even go home because of Frank. How about staying at my place during the break?"

translate english ch02_cafe02_fake_d554fc0c:

    o "There’s no one like Frank to make your life miserable."

translate english ch02_cafe02_fake_c60ca29c:

    o "At my place, you can live freely without any rules. Hehe."

translate english ch02_cafe02_fake_48b3f4b0:

    o "Sleep late, stay up all night playing games—no one will say a word."

translate english ch02_cafe02_fake_a670b92c:

    o "I don’t even wear underwear around the house, hehe."

translate english ch02_cafe02_fake_498148da:

    d "(( !!!!!!!!!!!! ))"

translate english ch02_cafe02_fake_f180e2b0:

    o "You know I’m living separately from my husband right now."

translate english ch02_cafe02_fake_684ddb61:

    o "I’ve been so lonely lately..."

translate english ch02_cafe02_fake_8c1f642f:

    o "Wait a second..."

translate english ch02_cafe02_fake_a73b74fc:

    o "I’ll show you a picture of my house."

translate english ch02_cafe02_fake_4d026153:

    o "Ah, found it!"

translate english ch02_cafe02_fake_f7662ad8:

    o "Look. My house gets this fresh sunlight."

translate english ch02_cafe02_fake_e0a43b3a:

    o "Instead of gloomy Amanda’s neighborhood, stay with me during the break. Hehe."

translate english ch02_cafe02_fake_29273932:

    o "Don’t you feel like packing your bags and coming right away?"

translate english ch02_cafe02_fake_3714a68e:

    o "What do you think?"

translate english ch02_cafe02_fake_9d981008:

    d "This is really..."

translate english ch02_cafe02_fake_80d313ad:

    d "It’s the most beautiful thing I’ve ever seen..."

translate english ch02_cafe02_fake_a79edcd9:

    o "What do you mean is beautiful?"

translate english ch02_cafe02_fake_48afa514:

    o "My kitchen? Hahaha."

translate english ch02_cafe02_fake_8dd8ff22:

    o "This little guy is smoother than he looks."

translate english ch02_cafe02_fake_41e2589a:

    o ".............."

translate english ch02_cafe02_fake_00cfb994:

    o "Ah, that machine’s acting up right now."

translate english ch02_cafe02_fake_502c4edf:

    o "It’s working on and off."

translate english ch02_cafe02_fake_d0ac6e87:

    o "It’ll be fine in a second."

translate english ch02_cafe02_fake_4c266fc3:

    o "Put the cup up and pull the lever down."

translate english ch02_cafe02_fake_1c66fed3:

    d "!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_fake_f0b55ce9:

    d "(( What the fuck! ))"

translate english ch02_cafe02_fake_3ff0cc0f:

    n "In that instant, what entered his field of vision was.."

translate english ch02_cafe02_fake_2f8409b5:

    n "exactly what he had desired from the moment he woke up until he fell asleep."

translate english ch02_cafe02_fake_6675c7f8:

    d "(( What the fuck! ))"

translate english ch02_cafe02_fake_bbdcab55:

    d "(( Oh my God, Olivia!! ))"

translate english ch02_cafe02_fake_e199d506:

    o "(( I can feel exactly what you’re thinking right now. ))"

translate english ch02_cafe02_fake_8d2c45b1:

    o "(( Innocent boy. ))"

translate english ch02_cafe02_fake_59a95da2:

    a "Heh."

translate english ch02_cafe02_fake_b9f25030:

    a "So, did you succeed in seducing [d_name]?"

translate english ch02_cafe02_fake_85498ef0:

    a "!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_fake_92a127d7:

    a "(( What the hell is that crazy bitch! ))"

translate english ch02_cafe02_fake_3a6c19a8:

    a "(( She’s doing that on purpose!! ))"

translate english ch02_cafe02_fake_dad07d5a:

    a "(( What a slut!! ))"

translate english ch02_cafe02_fake_904d610d:

    a "(( How dare she shove that filthy ass in front of him!!!!! ))"

translate english ch02_cafe02_fake_40fbeac4:

    a "(( Bitch! ))"

translate english ch02_cafe02_fake_6801c254:

    o "Huh?!!!!!!!!!!"

translate english ch02_cafe02_fake_32000984:

    n "For a brief moment, Olivia was startled."

translate english ch02_cafe02_fake_869cbc8b:

    n "She thought it was [d_name] who had slapped her ass."

translate english ch02_cafe02_fake_98d69fbf:

    n "It lasted only a second, but she felt an indescribable thrill."

translate english ch02_cafe02_fake_e30a9d88:

    o "(( What was that? ))"

translate english ch02_cafe02_fake_fc89170a:

    a "................."

translate english ch02_cafe02_fake_e2dbddc5:

    a "Are you trying to mess with me right now?"

translate english ch02_cafe02_fake_7edebcb7:

    o "(( Damn!! ))"

translate english ch02_cafe02_fake_00b44be4:

    o "(( I knew that felt like a woman’s hand.. ))"

translate english ch02_cafe02_fake_6119e40f:

    o "(( That idiot wouldn’t dare be that bold. ))"

translate english ch02_cafe02_fake_8def7d90:

    a "Did you eat well, honey?"

translate english ch02_cafe02_fake_1cb915a0:

    a "Then let’s head home."

translate english ch02_cafe02_fake_d208c610:

    d "Ow."

translate english ch02_cafe02_fake_0849d446:

    d "Ah... okay."

translate english ch02_cafe02_fake_6e807fff:

    o "Your boobs are really soft."

translate english ch02_cafe02_fake_74f80aa0:

    o "Even [d_name] knows how soft they are, right?"

translate english ch02_cafe02_fake_5cac9569:

    o "You should hurry and teach him a woman’s pleasure. Otherwise, I might just seduce him and take him away."

translate english ch02_cafe02_fake_0aff2d12:

    a "You bitch!"

translate english ch02_cafe02_fake_5542f20b:

    a "Why didn’t you just open the whole jungle for him?"

translate english ch02_cafe02_fake_0dbaf260:

    a "Go ahead and try to seduce [d_name]."

translate english ch02_cafe02_fake_25ddc252:

    a "You filthy slut!"

translate english ch02_cafe02_fake_1b811306_1:

    o "Hahaha."

translate english ch02_cafe02_fake_370a1e93:

    o "So that means I have your permission now?"

translate english ch02_cafe02_fake_79047fce:

    o "That boy’s going to be thinking about my ass for the rest of his life."

translate english ch02_cafe02_fake_c0222b57:

    a "Oh really?"

translate english ch02_cafe02_fake_a20f1b87:

    a "By the end of today, your ass won’t even leave a trace in his mind."

translate english ch02_cafe02_fake_b1251b15:

    o "Hehe. We’ll see."

translate english ch02_cafe02_fake_7212a87b:

    n "Olivia pressed her body against [d_name] with all her strength."

translate english ch02_cafe02_fake_38ef8f55:

    n "Unlike when they first met, she could feel him pressing back just as firmly, and she sensed that he wanted her too."

translate english ch02_cafe02_fake_743e4364:

    o "Honey."

translate english ch02_cafe02_fake_117e8543:

    o "Next time, let’s meet just the two of us, okay?"

translate english ch02_cafe02_fake_cba1cc5a:

    o "Let that old lady play with Frank, and we’ll go on a date."

translate english ch02_cafe02_fake_743e4364_1:

    o "Honey."

translate english ch02_cafe02_fake_82a66c67:

    o "Women like men who take action."

translate english ch02_cafe02_fake_da5009da:

    o "Be more confident. Anytime."

translate english ch02_cafe02_fake_1565afe8:

    o "What’s the worst a woman can do? Slap you?"

translate english ch02_cafe02_fake_6cbd768a:

    o "..............."

translate english ch02_cafe02_fake_dff3c9dc:

    o "Kiss me."

translate english ch02_cafe02_fake_8c097a17:

    d "Okay."

translate english ch02_cafe02_fake_25851351:

    o "Idiot."

translate english ch02_cafe02_fake_c1958ee1:

    o "Open your mouth."

translate english ch02_cafe02_fake_d9b48000:

    d "!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_fake_6cbd768a_1:

    o "..............."

translate english ch02_cafe02_fake_13f591fa:

    o "Next time I see you, I hope you’ll be a real man with confidence, kid."

translate english ch02_cafe02_fake_f24ab54f:

    o "Send me a message, alright?"

translate english ch02_cafe02_fake_b4f1e6ac:

    a "Come on, honey."

translate english ch02_cafe02_fake_16697a9f:

    a "It’s getting dark. Let’s go."

translate english ch02_cafe02_fake_ff678d23:

    a "..........................."

translate english ch02_cafe02_fake_a797f6ce:

    d "............."

translate english ch02_cafe02_fake_762d2724:

    d "Haha, why are you looking at me like that?"

translate english ch02_cafe02_fake_0a60958f:

    a "You little rascal."

translate english ch02_cafe02_fake_20ca4802:

    a "Did you enjoy Olivia’s ass?"

translate english ch02_cafe02_fake_d72926e9:

    a "You were staring at it like you were hypnotized."

translate english ch02_cafe02_fake_5ff861d9:

    a "If it got that far, you should’ve done something!"

translate english ch02_cafe02_fake_aad23aa5:

    d "What?!"

translate english ch02_cafe02_fake_89e61127:

    d "No, I just froze up."

translate english ch02_cafe02_fake_27ce770d:

    d "And if I’d tried to pull down her skirt in that situation, my hand would’ve touched her ass."

translate english ch02_cafe02_fake_2083d759:

    d "If things went wrong, I’d be labeled a pervert."

translate english ch02_cafe02_fake_19a8a337:

    a "Ha! As if!"

translate english ch02_cafe02_fake_e3f7c4ba:

    a "If you’d gotten closer, she would’ve pushed her ass right toward you!!!"

translate english ch02_cafe02_fake_b80a910b:

    a "Do you know what I mean?!!"

translate english ch02_cafe02_fake_8e76dd25:

    a "Her ass against your c…"

translate english ch02_cafe02_fake_55c02367:

    a "......."

translate english ch02_cafe02_fake_e17aa140:

    a "Anyway, that filthy bitch!"

translate english ch02_cafe02_fake_85ea696a:

    a "Come here, you."

translate english ch02_cafe02_fake_94e1abfb:

    a "Mwah~"

translate english ch02_cafe02_fake_ea8ea6b4:

    a "I’m sulking."

translate english ch02_cafe02_fake_39b7b119:

    a "It feels like you love my sister more than me."

translate english ch02_cafe02_fake_506f2f51:

    a "How could you? After all the time we’ve spent together.."

translate english ch02_cafe02_fake_0cade13d:

    a "And you fell for that sly bitch!"

translate english ch02_cafe02_fake_6dd334c8:

    a "Hahaha."

translate english ch02_cafe02_fake_3f35183b:

    a "Let’s go home, darling. Hehe."

translate english ch02_cafe02_fake_77748d65:

    a "(( Let’s go back to our home sweet home. ))"

translate english ch02_droom01_10865b74:

    n "When [d_name] opened his eyes, a woman was sitting at the edge of his bed in her underwear."

translate english ch02_droom01_3d2e5f07:

    n "Caught completely off guard, he lingered between dream and reality."

translate english ch02_droom01_ed9af930:

    n "After a few moments passed, he realized this was real."

translate english ch02_droom01_fa5a23a5:

    d "Um..."

translate english ch02_droom01_4fb9df16:

    d "[h_name]?"

translate english ch02_droom01_b45ae0cf:

    d "!!!"

translate english ch02_droom01_fac8215b:

    d "............"

translate english ch02_droom01_5d80d1de:

    d "Excuse me... I’m sorry for startling you."

translate english ch02_droom01_bcc7867a:

    d "But..."

translate english ch02_droom01_3bea866c:

    d "I’m sorry, but who are you?"

translate english ch02_droom01_81e1b58c:

    unknownf "Oh, I’m sorry."

translate english ch02_droom01_e5eb2ea8:

    unknownf "My legs aren’t in good condition, so I had no choice but to sit down for a moment. I’ll get up."

translate english ch02_droom01_fac8215b_1:

    d "............"

translate english ch02_droom01_8b7a9440:

    n "He was dumbfounded, unable to process what was happening."

translate english ch02_droom01_095db04e:

    n "Instinctively, his eyes scanned her body."

translate english ch02_droom01_a9915bf9:

    n "And he immediately realized he was having a morning erection."

translate english ch02_droom01_b45ae0cf_1:

    d "!!!"

translate english ch02_droom01_ff39e542:

    d "(( Damn it. Not now! ))"

translate english ch02_droom01_80b6772d:

    d "(( What do I do?!! ))"

translate english ch02_droom01_e9d252aa:

    unknownf "(( shit ))"

translate english ch02_droom01_b518c44a:

    unknownf "(( sigh..... ))"

translate english ch02_droom01_e0fa4661:

    d "(( Holy!! ))"

translate english ch02_droom01_d37aae2f:

    unknownf "Ouch!"

translate english ch02_droom01_7d8e3c4e:

    d "Excuse me."

translate english ch02_droom01_b06f4379:

    d "I’ll help you."

translate english ch02_droom01_f69a7c0e:

    d "................"

translate english ch02_droom01_100cf69a:

    n "[d_name]’s mind was in chaos."

translate english ch02_droom01_9ae71155:

    n "A woman he had never seen before was sitting on his bed in her underwear,"

translate english ch02_droom01_c4e6d125:

    n "and in his effort to stay calm, he hadn’t even realized how little he was wearing."

translate english ch02_droom01_e70faa53:

    unknownf "Huh?!!!!!!!!!!!"

translate english ch02_droom01_729a431e:

    unknownf "Ahhh! Get away!"

translate english ch02_droom01_f235288d:

    d "What?!"

translate english ch02_droom01_05198049:

    d "Okay, okay!"

translate english ch02_droom01_4f180267:

    d "I was just..."

translate english ch02_droom01_ae682137:

    d "(( !!! ))"

translate english ch02_droom01_364bb3dd:

    unknownf "Ah..."

translate english ch02_droom01_45f33576:

    unknownf "......"

translate english ch02_droom01_d569416a:

    unknownf "What did you just do?!"

translate english ch02_droom01_8bb796f2:

    d "What? No, I was just..."

translate english ch02_droom01_46a36509:

    unknownf "........"

translate english ch02_droom01_3c36926b:

    d "Are you okay?"

translate english ch02_droom01_82123128:

    unknownf "No, I just..."

translate english ch02_droom01_b1ddc03e:

    unknownf "I was so startled that without realizing..."

translate english ch02_droom01_b9563f12:

    d "I’m sorry! I didn’t mean to push you......"

translate english ch02_droom01_9f69f753:

    d "I’m really sorry."

translate english ch02_droom01_c9aeed9f:

    d "Please, take my hand."

translate english ch02_droom01_41ac6570:

    unknownf "Thank you."

translate english ch02_droom01_c07bddab:

    d "Okay, that’s it."

translate english ch02_droom01_00d81533:

    unknownf "(( Ha.... how embarrassing. ))"

translate english ch02_droom01_0d3df210:

    d "Yes, just stand up slowly like that."

translate english ch02_droom01_6247c00b:

    unknownf "What the fuck!!!"

translate english ch02_droom01_c2731e22:

    d "What? What’s wrong?"

translate english ch02_droom01_44b18304:

    d "Huh??"

translate english ch02_droom01_55c50b58:

    d "(( shit!!!!!!! ))"

translate english ch02_droom01_dac4cb8b:

    d "(( shit! ))"

translate english ch02_droom01_417cb8c4:

    n "When he looked down, his dick was hanging out."

translate english ch02_droom01_60408f02:

    n "In that instant, a wave of unfamiliar emotions hit him."

translate english ch02_droom01_1429241f:

    n "In that brief moment, he felt excitement, fear, anxiety, and pleasure all at once."

translate english ch02_droom01_0c01b888:

    d "Damn it, why is this out..."

translate english ch02_droom01_3ec3f2b1:

    unknownf "Ahhh!"

translate english ch02_droom01_bfb82d5b:

    d "Damn it!"

translate english ch02_droom01_704451b0:

    d "Huh?"

translate english ch02_droom01_3c36926b_1:

    d "Are you okay?"

translate english ch02_droom01_8be0366a:

    d "I’m truly sorry. Ha......"

translate english ch02_droom01_746b0006:

    d "(( Ha...... what the hell am I doing first thing in the morning. ))"

translate english ch02_droom01_e2c60566:

    d "(( Wait, who is she anyway? ))"

translate english ch02_droom01_17512c6a:

    d "(( Who is she to be walking around this house so freely? ))"

translate english ch02_droom01_99e73a9b:

    d "(( Is she [h_name]’s daughter? ))"

translate english ch02_droom01_b217b12a:

    d "(( No, the age doesn’t match. ))"

translate english ch02_droom01_e26fd86f:

    d "(( Is she [h_name]’s younger sister? ))"

translate english ch02_droom01_d37aae2f_1:

    unknownf "Ouch!"

translate english ch02_droom01_cabf06a5:

    unknownf "shit!"

translate english ch02_droom01_4126183d:

    d "(( !!!!!!! ))"

translate english ch02_droom01_1d31906f:

    d "(( ................. ))"

translate english ch02_droom01_8c58cbd1:

    unknownf "..............."

translate english ch02_droom01_1d31906f_1:

    d "(( ................. ))"

translate english ch02_droom01_f2f40ab0:

    d "(( What is happening right now.. ))"

translate english ch02_droom01_81158918:

    d "(( Am I still asleep? ))"

translate english ch02_droom01_57d8ab3e:

    d "(( Is this a dream? ))"

translate english ch02_droom01_8c58cbd1_1:

    unknownf "..............."

translate english ch02_droom01_af54d426:

    unknownf "Ugh!!!"

translate english ch02_droom01_f4f9887f:

    unknownf "What are you doing?!!!"

translate english ch02_droom01_9a12e213:

    unknownf "What are you doing to me?......"

translate english ch02_droom01_ad349841:

    unknownf "(( Sob, sob ))"

translate english ch02_droom01_43ee82be:

    d "(( I’m screwed. ))"

translate english ch02_droom01_ad349841_1:

    unknownf "(( Sob, sob ))"

translate english ch02_droom01_c2531e0c:

    d "(( Ha......... ))"

translate english ch02_droom01_fa5a23a5_1:

    d "Um..."

translate english ch02_droom01_9f69f753_1:

    d "I’m truly sorry."

translate english ch02_droom01_bcc65567:

    d "I absolutely didn’t mean to.."

translate english ch02_droom01_edd3a98c:

    d "It was a mistake....."

translate english ch02_droom01_ac8dc685:

    n "Now fully awake, anxiety washed over him."

translate english ch02_droom01_854b3b0c:

    n "He assumed she must be [h_name]’s younger sister, and if she told [h_name], he might actually be kicked out."

translate english ch02_droom01_510a5999:

    d "Ha......"

translate english ch02_droom01_fa5a23a5_2:

    d "Um..."

translate english ch02_droom01_0f1c7646:

    d "Please accept my apology."

translate english ch02_droom01_0a17e047:

    d "Please don’t tell [h_name]. I’m begging you."

translate english ch02_droom01_5532ea58:

    d "I’m truly sorry.."

translate english ch02_droom01_7b893f0a:

    unknownf "It’s okay."

translate english ch02_droom01_ae31d4a9:

    unknownf "Don’t worry about it."

translate english ch02_droom01_eaf99fe6:

    unknownf "It was my fault."

translate english ch02_droom01_3391102d:

    unknownf "............"

translate english ch02_droom01_5e957fab:

    unknownf "I shouldn’t have come into this room."

translate english ch02_droom01_a98daf83:

    unknownf "It was insane of me to sit on a young man’s bed in my underwear."

translate english ch02_droom01_fac8215b_2:

    d "............"

translate english ch02_droom01_fac8215b_3:

    d "............"

translate english ch02_droom01_fa5a23a5_3:

    d "Um..."

translate english ch02_droom01_9f69f753_2:

    d "I’m truly sorry."

translate english ch02_droom01_4e1aa881:

    d "I didn’t intend it, nor did I deliberately dress like that..."

translate english ch02_droom01_c67e457c:

    d "And I absolutely didn’t mean to expose anything. Ha..."

translate english ch02_droom01_f4cda87e:

    unknownf ".............."

translate english ch02_droom01_5e3aec4e:

    d ".........."

translate english ch02_droom01_e73f1adf:

    unknownf "Ahem."

translate english ch02_droom01_c37e362e:

    unknownf "I apologize."

translate english ch02_droom01_8202aedc:

    unknownf "I hope you won’t feel uncomfortable."

translate english ch02_droom01_e175caf2:

    unknownf "I won’t tell [h_name]."

translate english ch02_droom01_d51f2793:

    unknownf "There’s no need to."

translate english ch02_droom01_23f4eecc:

    unknownf "Just think of it as something that never happened. I’ll forget it too."

translate english ch02_droom01_e8eb3909:

    unknownf "Please get some rest."

translate english ch02_droom01_7c0a9214:

    d ".............."

translate english ch02_droom01_02d13543:

    d "Damn.."

translate english ch02_droom01_a465dc12:

    d "So she’s the housekeeper [h_name] mentioned...."

translate english ch02_droom01_b3bbf535:

    d "I think I’ve caused a huge problem..."

translate english ch02_droom01_36af4721:

    d "Ha............."

translate english ch02_living01_824c6791:

    n "His heart was still racing."

translate english ch02_living01_8cd5be4e:

    n "And he resented himself for not being able to properly help her."

translate english ch02_living01_f1008634:

    d "(( Damn. ))"

translate english ch02_living01_4ba28572:

    d "(( This is really uncomfortable. ))"

translate english ch02_living01_4a133888:

    d "(( Why Beth’s lips...? ))"

translate english ch02_living01_651d4320:

    n "She was so flustered that she barely understood what she was doing."

translate english ch02_living01_05b4c0d2:

    n "From the moment she left the room, the thought of his erection wouldn’t leave her mind."

translate english ch02_living01_ed32baa0:

    n "The more she thought about it, the more excitement and shame wrapped around her at the same time."

translate english ch02_living01_72ef3bdf:

    unknownf "Ouch!"

translate english ch02_living01_3d92e20e:

    unknownf "Damn it."

translate english ch02_living01_d7f9f362:

    d "Excuse me."

translate english ch02_living01_3c36926b:

    d "Are you okay?"

translate english ch02_living01_77d89c42:

    d "You shouldn’t keep pushing yourself in that condition."

translate english ch02_living01_b06f4379:

    d "I’ll help you."

translate english ch02_living01_a45aee22:

    unknownf ".........................."

translate english ch02_living01_6a3083f0:

    unknownf "Thank you, but it’s okay."

translate english ch02_living01_3734092f:

    unknownf "This is my job, so you don’t have to worry."

translate english ch02_living01_b151c050:

    d "About earlier, that was my mistake."

translate english ch02_living01_9f69f753:

    d "I’m truly sorry."

translate english ch02_living01_51510d25:

    n "The door opened and [h_name] appeared."

translate english ch02_living01_be7324af:

    n "She was dressed in something that clearly showed off her figure."

translate english ch02_living01_b4754ac5:

    h "Oh, have you two already met?"

translate english ch02_living01_7bfc85bb:

    h "Beth! Why are you here?"

translate english ch02_living01_f2810d37:

    h "Are you really in any condition to work?"

translate english ch02_living01_f0e6fd4b:

    b "Good morning, [h_name]."

translate english ch02_living01_721fbabe:

    b "I’m much better now."

translate english ch02_living01_e4aad73d:

    b "I can move freely."

translate english ch02_living01_9b5f7a36:

    h "Really?"

translate english ch02_living01_8c13b876:

    h "Look, you haven’t even removed the bandages yet. I don’t think you should be working."

translate english ch02_living01_50941ccc:

    b "No, it’s okay. I can work."

translate english ch02_living01_271d1d71:

    b "If I wait until the bandages come off, it’ll take too long."

translate english ch02_living01_2038b86e:

    b "It might take over a month to fully recover."

translate english ch02_living01_e47659e1:

    b "The doctor said I could handle simple tasks."

translate english ch02_living01_130aa39d:

    b "And staying home without moving has been really suffocating."

translate english ch02_living01_a75d27a7:

    h "I don’t think that counts as simple work."

translate english ch02_living01_921ed001:

    h "If you do that, I’ll feel very uncomfortable."

translate english ch02_living01_b4996ba0:

    h "If you push yourself, your recovery will only be delayed."

translate english ch02_living01_e3eb0d07:

    h "I’ll handle the housework, so go home and focus on recovering."

translate english ch02_living01_ec52518d:

    h "No, Beth!"

translate english ch02_living01_8ac3a4aa:

    h "Then your recovery will be even more delayed—"

translate english ch02_living01_b45ae0cf:

    d "!!!"

translate english ch02_living01_db2c0337:

    b ".........."

translate english ch02_living01_c955a024:

    h "Oops!"

translate english ch02_living01_0ecda344:

    b "(( .......... ))"

translate english ch02_living01_eb78a2bf:

    n "No one knows why."

translate english ch02_living01_cc022c44:

    n "At that moment, Beth’s eyes unconsciously drifted to [d_name]’s crotch."

translate english ch02_living01_59353cb3:

    d "(( Shit! ))"

translate english ch02_living01_dd4f55a6:

    h "Anyway, Beth. Stop and go home to rest."

translate english ch02_living01_bd7ef992:

    h "I’m insisting."

translate english ch02_living01_08cb80cc:

    h "You might feel fine, but I’m not comfortable at all."

translate english ch02_living01_53768eb2:

    h "You absolutely cannot work in that condition."

translate english ch02_living01_b4eebec9:

    h "Understood?"

translate english ch02_living01_9528097e:

    b "...................."

translate english ch02_living01_5f87256b:

    b "Alright, [h_name]."

translate english ch02_living01_9e93cf52:

    b "I’ll do that."

translate english ch02_living01_853df116:

    b "Then I’ll at least start the washing machine before I go."

translate english ch02_living01_685d4ec1:

    b "That’s okay, right?"

translate english ch02_living01_170ddef7:

    h "Goodness, Beth."

translate english ch02_living01_5a1a40ae:

    h "I can never win against your stubbornness. Fine, do that."

translate english ch02_living01_564eb93c:

    n "As she went down to the first floor, a strange silence filled the living room."

translate english ch02_living01_3877ed3f:

    n "[d_name] quickly grabbed the cleaning tools and spoke."

translate english ch02_living01_f99b24fa:

    d "I’ll finish the rest."

translate english ch02_living01_953d550e:

    d "I’ve got too much energy—I need to move somehow."

translate english ch02_living01_eeb6ad13:

    h "Hehe. Then I won’t stop you."

translate english ch02_living01_54b592f8:

    h "I’ll be in the backyard, so tell me if you need anything."

translate english ch02_living01_9795f636:

    h "Don’t overdo it. I can finish it later, alright?"

translate english ch02_living01_49cdef74:

    h "I’ll make something delicious for lunch."

translate english ch02_living01_35d53090:

    d "(( Damn.......... ))"

translate english ch02_living01_f2103f3d:

    d "(( Her figure is unbelievably amazing for her age.. ))"

translate english ch02_living01_b93eca2f:

    d "(( Shit... ))"

translate english ch02_living01_e1d1ce6e:

    d "(( She’s still far too defenseless around me.... ))"

translate english ch02_living01_baa7c43c:

    d "(( What was that move? An invitation? ))"

translate english ch02_living01_795c5598:

    d "(( Is she really treating me like a child... ))"

translate english ch02_living01_9f01c5ed:

    d "(( Does she not see me as a man? ))"

translate english ch02_laundry01_ac5a838f:

    d "(( They stopped painting here. ))"

translate english ch02_laundry01_6f6b3a97:

    d "(( Was something urgent going on? ))"

translate english ch02_laundry01_548b157b:

    d "(( I guess I’ll have to paint it later. ))"

translate english ch02_laundry01_0b29ca51:

    n "[d_name] felt conflicted."

translate english ch02_laundry01_1c519fe8:

    n "He felt he should properly apologize to Beth,"

translate english ch02_laundry01_6026db76:

    n "he wanted to check if she was truly okay,"

translate english ch02_laundry01_9bd91ccd:

    n "and, caught in a strange excitement, he wanted to see her once more before she left."

translate english ch02_laundry01_7ab39cb0:

    d "!!!!"

translate english ch02_laundry01_b03240a2:

    d "(( Damn. I think coming in here was another mistake..... ))"

translate english ch02_laundry01_f9fb44c3:

    d "(( What do I do? Should I turn back? ))"

translate english ch02_laundry01_fde64845:

    d "(( No. She probably heard me anyway. ))"

translate english ch02_laundry01_ab95fc7a:

    d "Um… Beth."

translate english ch02_laundry01_e145c8c7:

    b "!!!!!!!!!!!!"

translate english ch02_laundry01_b643cd71:

    b "Ouch!"

translate english ch02_laundry01_a438b12d:

    d "((!!!!!!!!))"

translate english ch02_laundry01_a6efe251:

    b "Ah..."

translate english ch02_laundry01_daaca990:

    b "What the..."

translate english ch02_laundry01_261a6510:

    b "Why did you come in without making any noise?!"

translate english ch02_laundry01_c532219d:

    b "Ugh, that hurts..."

translate english ch02_laundry01_439a1c44:

    d "I’m sorry."

translate english ch02_laundry01_937d0dd9:

    d "Are you okay, Beth?"

translate english ch02_laundry01_1eb2e668:

    d "(( Ha... what is wrong with me.. ))"

translate english ch02_laundry01_973d82b6:

    b "Ha.........."

translate english ch02_laundry01_79c1dd8f:

    b "No, I’m not okay!"

translate english ch02_laundry01_f4b60bb2:

    b "At this rate, I might break my neck!"

translate english ch02_laundry01_7c6a2557:

    d "I’m sorry... since earlier..."

translate english ch02_laundry01_e0c875b2:

    d "I don’t know why this keeps happening..."

translate english ch02_laundry01_6b3ee47e:

    n "As the pain in her head subsided, Beth’s anger began to calm."

translate english ch02_laundry01_ac9a8df4:

    n "And when she looked at his face, she suddenly remembered what had been in front of her face earlier."

translate english ch02_laundry01_1d2ab34b:

    b "Why? Do you need something?"

translate english ch02_laundry01_dcd76b53:

    d "No, not exactly..."

translate english ch02_laundry01_dd09bc31:

    d "The timing kept being off, so I never got to introduce myself."

translate english ch02_laundry01_657e8b73:

    d "My name is [d_name]."

translate english ch02_laundry01_246684ce:

    d "I’m from around here."

translate english ch02_laundry01_8691ffe1:

    d "And I arrived here the other day... I’ll be staying in this house during the break."

translate english ch02_laundry01_d922b4c8:

    d "Nice to meet you."

translate english ch02_laundry01_0cfabd9c:

    b "I’m Beth."

translate english ch02_laundry01_e9364477:

    b "As you can see, I’m [h_name]’s housekeeper."

translate english ch02_laundry01_56c8ed05:

    d "Yes. [h_name] mentioned you, but I didn’t realize it was you."

translate english ch02_laundry01_1bf26cc1:

    d "And also..."

translate english ch02_laundry01_a062ad69:

    d "What happened earlier in the room was absolutely not intentional..."

translate english ch02_laundry01_726dc930:

    d "I hope you don’t see me as some kind of weirdo."

translate english ch02_laundry01_d75b431a:

    n "Beth couldn’t understand why he had come all the way down to the laundry room to bring that up again."

translate english ch02_laundry01_3db642d3:

    n "Yet at the same time, she realized she didn’t actually dislike that he had brought it up."

translate english ch02_laundry01_be206261:

    n "Even so, she couldn’t help but question his intentions."

translate english ch02_laundry01_14d1f989:

    b "It’s fine."

translate english ch02_laundry01_290d8111:

    b "That was my mistake."

translate english ch02_laundry01_f1d3a3ea:

    b "I shouldn’t have gone into the room where you were sleeping."

translate english ch02_laundry01_38798e6e:

    b "I just walked in out of routine without thinking."

translate english ch02_laundry01_48fd04da:

    b "[h_name] had allowed me to use that room whenever I needed."

translate english ch02_laundry01_55fb09b3:

    b "The women’s clothes in there are mine."

translate english ch02_laundry01_9528097e:

    b "...................."

translate english ch02_laundry01_6e4f673d:

    b "I can’t believe I walked into a room where a man was sleeping alone. Ha..."

translate english ch02_laundry01_67af961e:

    b "If [h_name] had seen it, she would have scolded me terribly."

translate english ch02_laundry01_1c2b3689:

    b "I’ll clear out my things tomorrow."

translate english ch02_laundry01_06852e3c:

    b "............"

translate english ch02_laundry01_f7edf092:

    b "There are some of my underwear in there too..."

translate english ch02_laundry01_c041573d:

    d "No, that’s not necessary."

translate english ch02_laundry01_c1f2d202:

    d "I’ll only be here during the break, so you don’t have to."

translate english ch02_laundry01_b20dc725:

    d "Since it was your room, Beth, I won’t take it over completely."

translate english ch02_laundry01_4afb8167:

    b "No, that wasn’t my room. It was [h_name]’s son’s room—"

translate english ch02_laundry01_e32ff1ac:

    d "(( Is she..? ))"

translate english ch02_laundry01_4cdf97a9:

    d "(( Is she looking at my dick right now? ))"

translate english ch02_laundry01_d8681087:

    b "............."

translate english ch02_laundry01_6541ba7c:

    b "How did you end up coming to this town?"

translate english ch02_laundry01_02210c73:

    b "And how do you know [h_name]?"

translate english ch02_laundry01_d9a19174:

    d "Oh, I don’t actually know [h_name] personally."

translate english ch02_laundry01_7fe3968a:

    d "I’m a student at Milfheim University, and I decided to stay here during the break."

translate english ch02_laundry01_830f0262:

    d "This is my hometown."

translate english ch02_laundry01_98c8069b:

    b "I see..."

translate english ch02_laundry01_9a7afd9e:

    b "That explains it. You don’t feel like a complete stranger, then."

translate english ch02_laundry01_19829de5:

    d "(( Shit! Doesn’t she realize her skirt has ridden up like that? ))"

translate english ch02_laundry01_98438ff6:

    d "(( Does everyone in this house have that much confidence in their ass? ))"

translate english ch02_laundry01_5f3d3c6a:

    d "(( ............................ ))"

translate english ch02_laundry01_489217d5:

    d "(( No. ))"

translate english ch02_laundry01_c97bf224:

    d "(( Maybe Beth still sees me as a kid. ))"

translate english ch02_laundry01_34ea11e1:

    d "(( Someone who doesn’t need to cover herself in front of me. ))"

translate english ch02_laundry01_1ea52a57:

    b "..............."

translate english ch02_laundry01_cf47d724:

    b "But if you’re from here, don’t you have family? Did you become independent early?"

translate english ch02_laundry01_0f9ad5b0:

    d "Well, I..."

translate english ch02_laundry01_a5f63f11:

    d "Actually, I’m an orphan."

translate english ch02_laundry01_5a4e4c45:

    d "I was placed in a facility when I was young, so I don’t know where my parents are."

translate english ch02_laundry01_c1c2a14a:

    b "(( !! ))"

translate english ch02_laundry01_d8681087_1:

    b "............."

translate english ch02_laundry01_e6144d99:

    b "Oh, I’m sorry. I didn’t know..."

translate english ch02_laundry01_16e06263:

    b "I shouldn’t have asked."

translate english ch02_laundry01_b406be70:

    d "It’s okay. The only thing I know about them are the names on the documents, so I don’t really feel anything."

translate english ch02_laundry01_4e8d7aba:

    d "In fact, because of my background, I’ve received an abundance of love from many people."

translate english ch02_laundry01_9d6ac89f:

    b "Hehe. You’re quite thoughtful for a student."

translate english ch02_laundry01_bcfa325b:

    b "In that situation, most people might resent their parents..."

translate english ch02_laundry01_16f84cf0:

    b "It’s admirable."

translate english ch02_laundry01_3fd24d8f:

    b "So how did you end up in [h_name]’s house?"

translate english ch02_laundry01_e0f28a04:

    b "Oh, I already asked that. I must be a bit distracted."

translate english ch02_laundry01_f5d78914:

    d "Ah, well..."

translate english ch02_laundry01_46bdc9f0:

    d "I saw [h_name]’s listing for a tenant through an app and contacted her."

translate english ch02_laundry01_9f466d18:

    d "It wasn’t far from where I used to live, so it seemed like a good place."

translate english ch02_laundry01_a7599a70:

    b "I see."

translate english ch02_laundry01_860e84c9:

    b "But this place is a bit on the outskirts. Don’t you get bored?"

translate english ch02_laundry01_b3ee1ad7:

    b "There’s nothing outside but mountains and trees."

translate english ch02_laundry01_f3e9051c:

    b "..................."

translate english ch02_laundry01_46c6433a:

    b "Isn’t it too quiet for a young man full of energy?"

translate english ch02_laundry01_b4c9e05f:

    d "Haha, I actually like this environment."

translate english ch02_laundry01_6a1cca69:

    d "I read a lot because of my major at school, and there’s no better place than this."

translate english ch02_laundry01_7e311bda:

    b "Oh. Then you and [h_name] will get along well in that regard."

translate english ch02_laundry01_1ea52a57_1:

    b "..............."

translate english ch02_laundry01_4c0fdceb:

    b "She likes a quiet environment too."

translate english ch02_laundry01_0b753b8e:

    b "..........................."

translate english ch02_laundry01_e5101864:

    b "By the way, thank you for offering to help earlier."

translate english ch02_laundry01_c843f7bc:

    b "Even if it was just something you said out of courtesy..."

translate english ch02_laundry01_b57992d5:

    d "No, I meant it."

translate english ch02_laundry01_f15482a8:

    d "Seeing your bandages now, it looks pretty serious."

translate english ch02_laundry01_026a02bf:

    d "Like [h_name] said, you seem to need rest."

translate english ch02_laundry01_95bc461a:

    n "For the first time since the shock of the morning, she felt relieved, as if things had returned to normal."

translate english ch02_laundry01_b56d667e:

    n "And although he seemed slightly meddlesome, she felt that he was genuinely worried about her."

translate english ch02_laundry01_c3830480:

    n "Hearing such concern from a man much younger than herself made her feel strangely shy."

translate english ch02_laundry01_adef7ef2:

    b "Sigh...."

translate english ch02_laundry01_13d1e84d:

    b "I think that about wraps it up."

translate english ch02_laundry01_940dfb07:

    b "Even though my body’s tired, I’m glad I came."

translate english ch02_laundry01_f7e9b56c:

    b "Doing this at least makes me feel a bit more at ease."

translate english ch02_laundry01_06b588bd:

    b "Hehe.."

translate english ch02_laundry01_e5c36b54:

    d "..........."

translate english ch02_laundry01_e5c36b54_1:

    d "..........."

translate english ch02_laundry01_c8b353c9:

    b "..........."

translate english ch02_laundry01_37790d91:

    b "Why are you staring at me like that? It’s embarrassing."

translate english ch02_laundry01_c8b353c9_1:

    b "..........."

translate english ch02_laundry01_b35b2487:

    d "Ah.. it’s nothing. I sometimes space out like this."

translate english ch02_laundry01_78f9fae1:

    d "It’s kind of... a bad habit."

translate english ch02_laundry01_6a545345:

    b "I see."

translate english ch02_laundry01_93499d5a:

    b "I wouldn’t go so far as to call it a bad habit."

translate english ch02_laundry01_f3e9051c_1:

    b "..................."

translate english ch02_laundry01_7ca981b1:

    b "Um..."

translate english ch02_laundry01_6fc40760:

    b "You came because of what happened in the room earlier, didn’t you?"

translate english ch02_laundry01_4126183d:

    d "(( !!!!!!! ))"

translate english ch02_laundry01_bd02e3d6:

    d "Ah, that..."

translate english ch02_laundry01_f3e9051c_2:

    b "..................."

translate english ch02_laundry01_fc0d2be6:

    b "Goodness......"

translate english ch02_laundry01_dfb34fd8:

    b "How could something like that even happen?"

translate english ch02_laundry01_f3e9051c_3:

    b "..................."

translate english ch02_laundry01_88240023:

    b "Who would even believe something like that?..."

translate english ch02_laundry01_c8b353c9_2:

    b "..........."

translate english ch02_laundry01_a9a2800d:

    b "(( Goodness.. ))"

translate english ch02_laundry01_68b81cf4:

    b "(( Would anyone believe this? ))"

translate english ch02_laundry01_7f518b51:

    b "(( That I was kneeling under the dick of a boy I’d never seen before, with my mouth open? ))"

translate english ch02_laundry01_055e0bab:

    b ".............."

translate english ch02_laundry01_f14ca06d:

    b "It’s okay. If you have something to say, just say it."

translate english ch02_laundry01_2a249802:

    b "I have to leave now."

translate english ch02_laundry01_b46dc86f:

    d "Ah, I..."

translate english ch02_laundry01_28a80b9f:

    d "Well..........."

translate english ch02_laundry01_b415d4f2:

    d "Um......my..."

translate english ch02_laundry01_055e0bab_1:

    b ".............."

translate english ch02_laundry01_a15cac56:

    b "(( Your what, you little boy. ))"

translate english ch02_laundry01_db75a353:

    b "(( Why are you hesitating like that? ))"

translate english ch02_laundry01_72680782:

    b "(( Isn’t this what you really want to say? ))"

translate english ch02_laundry01_233b739f:

    b "(( What do you think of my cock? ))"

translate english ch02_laundry01_abaa9bcb:

    b "(( Do you think it’s enough to satisfy you? ))"

translate english ch02_laundry01_2ff339dd:

    b "(( Come on, take a closer look. ))"

translate english ch02_laundry01_97c373ac:

    b "(( You saw mine, now it’s your turn. ))"

translate english ch02_laundry01_df71b938:

    b "(( .... ))"

translate english ch02_laundry01_3f132186:

    b "(( You’re just like the other men, looking for an excuse to pull off my panties. ))"

translate english ch02_laundry01_7c0a9214:

    d ".............."

translate english ch02_laundry01_937d0dd9_1:

    d "Are you okay, Beth?"

translate english ch02_laundry01_28b787cc:

    b "You know what?"

translate english ch02_laundry01_8096b08a:

    d "Yes?"

translate english ch02_laundry01_1ef5ec04:

    b "(( No matter how much men pretend to be gentlemen or act like they care about women, they’re all the same. ))"

translate english ch02_laundry01_89dc0300:

    b "(( Young or old, they all want just one thing. ))"

translate english ch02_laundry01_07069b10:

    b "(( All they ever think about is fucking from the moment they wake up. ))"

translate english ch02_laundry01_8fc5830c:

    b "(( Oh yeah? Want me to suck you off too? ))"

translate english ch02_laundry01_50ca1c72:

    b "(( Isn’t that why you followed me all the way here, even though you had nothing to say? ))"

translate english ch02_laundry01_7c6ce05e:

    b "(( You must think I’m an easy woman. ))"

translate english ch02_laundry01_76ef1061:

    b "(( You’ll look down at me, making the same pathetic noises as all the other men I’ve blown, won’t you? ))"

translate english ch02_laundry01_aa78773a:

    b "(( While patting the head of a woman old enough to be your aunt. ))"

translate english ch02_laundry01_45326f93:

    b "(( You want to see me take your cock into my mouth without any resistance, don’t you? ))"

translate english ch02_laundry01_990c0b16:

    b "(( Isn’t that what’s in your head right now? ))"

translate english ch02_laundry01_ead4833b:

    b "(( You want to see my face, wrapped around your thick cock, making a disgusting expression? ))"

translate english ch02_laundry01_22849a84:

    b "(( Watching me gasp for air, ))"

translate english ch02_laundry01_4a5b5b83:

    b "(( Then calling me a beautiful woman while stroking my hair. ))"

translate english ch02_laundry01_358df8d9:

    b "(( You’d call me a good girl, wouldn’t you? ))"

translate english ch02_laundry01_f5b76b08:

    b "(( ................. ))"

translate english ch02_laundry01_b3a89bfa:

    b "(( Dirty men. ))"

translate english ch02_laundry01_937d0dd9_2:

    d "Are you okay, Beth?"

translate english ch02_laundry01_3c36926b:

    d "Are you alright?"

translate english ch02_laundry01_055e0bab_2:

    b ".............."

translate english ch02_laundry01_0f9fa247:

    b "No. It’s nothing."

translate english ch02_laundry01_db35f9db:

    b "I must’ve gotten distracted for a moment."

translate english ch02_laundry01_055e0bab_3:

    b ".............."

translate english ch02_laundry01_9fc9e621:

    b "(( Damn it. Why am I fantasizing like this? ))"

translate english ch02_laundry01_11322e20:

    b "(( Sigh.... there’s something wrong with me. ))"

translate english ch02_laundry01_668c46f2:

    b "(( He seems like one of the rare pure ones in this town, and yet... ))"

translate english ch02_laundry01_f00641b8:

    d "(( Damn...... those beautiful armpits. ))"

translate english ch02_laundry01_8bf409ff:

    b "(( What kind of thoughts am I having about such a pure boy? ))"

translate english ch02_laundry01_035718a9:

    d "(( Shit! I want to lick them. ))"

translate english ch02_laundry01_f8d02ea5:

    d "(( They’re as beautiful as [h_name]’s. ))"

translate english ch02_laundry01_91363f2f:

    d "(( Look at that... ))"

translate english ch02_laundry01_5fe0d276:

    d "(( She has no guard up around me. ))"

translate english ch02_laundry01_6a2f6761:

    d "(( To her, I’m just a kid. ))"

translate english ch02_laundry01_f04e3086:

    d "(( If she wanted to impress a man, she wouldn’t show her armpits so openly like that. ))"

translate english ch02_laundry01_df3e812d:

    b "Well then, I should get going. See you later."

translate english ch02_laundry01_287628f7:

    d "Ah, wait..."

translate english ch02_laundry01_f15e0a1f:

    n "[d_name] wanted to talk to her a little longer."

translate english ch02_laundry01_41c1e195:

    n "He wanted to savor the erotic tension that had formed between them."

translate english ch02_laundry01_0e8ee6fd:

    n "And in this town that was still unfamiliar to him, it felt like he had found someone with whom he could share something secret."

translate english ch02_laundry01_828c5fac:

    n "Reluctant to see her leave, he said something even he didn’t fully understand."

translate english ch02_laundry01_24827fc1:

    d "I’ll borrow [h_name]’s car and give you a ride."

translate english ch02_laundry01_4d215683:

    b "What? Borrow [h_name]’s car?!!"

translate english ch02_laundry01_19f9cafb:

    b "You think she’d lend her car to you? Haha."

translate english ch02_laundry01_85720dc4:

    b "If you’re worried about what happened in the room, I’m really fine."

translate english ch02_laundry01_d4df97d0:

    b "And I have my motorcycle. I can just take that."

translate english ch02_laundry01_3af5dcfb:

    b "Thanks for caring."

translate english ch02_laundry01_598c0853:

    b "See you later."

translate english ch02_laundry01_a515914c:

    d "You idiot."

translate english ch02_laundry01_0f5c3cb7:

    d "Sometimes I speak without thinking first."

translate english ch02_laundry01_60e52525:

    d "Borrow her car? Seriously..."

translate english ch02_laundry01_f0fe9c1e:

    d "Now she’ll think I’m even more of a kid.."

translate english ch02_pool01_b286383e:

    d "(( The air in the village at the foot of the mountain is refreshing. ))"

translate english ch02_pool01_a45bbeb9:

    d "(( It feels like I’m getting healthier. ))"

translate english ch02_pool01_b56d798a:

    d "(( I hope I can live somewhere like this when I’m older.. ))"

translate english ch02_pool01_71130f3f:

    d "(( Goodness. ))"

translate english ch02_pool01_8c7d9fba:

    d "(( Were her boobs always that big?.. ))"

translate english ch02_pool01_89037691:

    n "He approached [h_name] to inform her of his schedule."

translate english ch02_pool01_c1e19b78:

    n "But the sight before his eyes reminded him of the day he had gotten erect in front of her, making him cautious."

translate english ch02_pool01_4aacc384:

    d "................."

translate english ch02_pool01_00a49bf0:

    d "Excuse me, [h_name]."

translate english ch02_pool01_4aacc384_1:

    d "................."

translate english ch02_pool01_00a49bf0_1:

    d "Excuse me, [h_name]."

translate english ch02_pool01_25f62f08:

    d "(( She doesn’t even realize I’m here. ))"

translate english ch02_pool01_64dfe632:

    d "(( What should I do?? I need to borrow a bicycle. ))"

translate english ch02_pool01_92f21ed5:

    n "What should I do?"

translate english ch02_pool01_d9080416:

    d "(( What if I shout and she gets startled because of me again? ))"

translate english ch02_pool01_eb8abbbe:

    d "(( Maybe it’s better to gently touch her?? Right?? ))"

translate english ch02_pool01_00a49bf0_2:

    d "Excuse me, [h_name]."

translate english ch02_pool01_637734fc:

    d "(( ..... ))"

translate english ch02_pool01_0532824f:

    d "[h_name]!"

translate english ch02_pool01_0532824f_1:

    d "[h_name]!"

translate english ch02_pool01_7fe2d270:

    d "(( She’ll hear me like this, right? ))"

translate english ch02_pool01_01ade554:

    d "Excuse me, [h_name]!!!!!!!!"

translate english ch02_pool01_f567451b:

    h "What?!!"

translate english ch02_pool01_ae682137:

    d "(( !!! ))"

translate english ch02_pool01_83261455:

    h "........."

translate english ch02_pool01_537e2341:

    d "(( Damn, did I mess up again? ))"

translate english ch02_pool01_ed9dfc9e:

    h "Oh, [d_name].."

translate english ch02_pool01_65be32fa:

    h "You really startled me."

translate english ch02_pool01_439a1c44:

    d "I’m sorry."

translate english ch02_pool01_7efe4747:

    d "I kept calling you, but you didn’t hear me."

translate english ch02_pool01_0972f285:

    h "Oh, I see."

translate english ch02_pool01_c1746933:

    h "So what’s going on?"

translate english ch02_pool01_3fff5735:

    d "Beth just left."

translate english ch02_pool01_eabe7fa3:

    d "She said she was heading home on her motorcycle."

translate english ch02_pool01_ac70ca4e:

    h "I see.."

translate english ch02_pool01_3635be51:

    h "Thank you for letting me know."

translate english ch02_pool01_46a2d3f5:

    h "She sometimes tries too hard to work."

translate english ch02_pool01_ce5a699c:

    h "I told her I’d be taking in a tenant soon, so maybe she felt responsible and came in on purpose."

translate english ch02_pool01_5e3aec4e:

    d ".........."

translate english ch02_pool01_70704f5b:

    d "I see."

translate english ch02_pool01_234b0eb5:

    d "Now I feel a bit bad for no reason."

translate english ch02_pool01_0445b27b:

    h "Hehe, it’s okay."

translate english ch02_pool01_057809d0:

    h "Today’s been a little hectic, but I’ll introduce you properly later."

translate english ch02_pool01_2ec91d91:

    h "You’ll be seeing each other for the next few months, so it’s better to get acquainted."

translate english ch02_pool01_c8535e55:

    h "(( Oh dear..... ))"

translate english ch02_pool01_831b2de1:

    h "(( I should pay more attention to what I wear from now on.. ))"

translate english ch02_pool01_e99f5a4f:

    n "In the middle of their conversation, she adjusted her posture."

translate english ch02_pool01_4126183d:

    d "(( !!!!!!! ))"

translate english ch02_pool01_db55be1e:

    h "Oh, and a friend of mine is coming over today."

translate english ch02_pool01_d7e99f47:

    h "It’s not Michael, so no need to worry, haha."

translate english ch02_pool01_2fc89db1:

    h "But this friend is very lively and full of energy—she can be a bit hard to handle, hehe."

translate english ch02_pool01_88501a41:

    h "So I’m sorry, but could you stay on the second floor today if possible?"

translate english ch02_pool01_43fb9a79:

    h "Sorry for the inconvenience."

translate english ch02_pool01_70704f5b_1:

    d "I see."

translate english ch02_pool01_6753c4ec:

    d "No need to worry. I’m actually going back to my old place today."

translate english ch02_pool01_a19d1459:

    d "I’ll stay the night and come back tomorrow."

translate english ch02_pool01_6646ef9a:

    h "Ah, I see."

translate english ch02_pool01_164df209:

    h "That sounds nice, hehe."

translate english ch02_pool01_323fd6da:

    h "(( …..................... ))"

translate english ch02_pool01_0ef6cfda:

    h "Then I’ll be at home with my friend today, so have a good trip."

translate english ch02_pool01_63552098:

    h "If you end up coming back tonight, please send me a text."

translate english ch02_pool01_987efd40:

    d "Yes, I will."

translate english ch02_pool01_f07b9c0e:

    d "Have a good time with your friend."

translate english ch02_pool01_469fbe12:

    h "Thank you, hehe."

translate english ch02_pool01_85841903:

    h "When we get closer, let’s sunbathe together."

translate english ch02_pool01_1b77aeb7:

    d "Sure, I’d like that, haha."

translate english ch02_pool01_ed31bf2e:

    d "(( I want to get closer to you too.. ))"

translate english ch02_pool01_c422f014:

    d "(( Even right now... ))"

translate english ch02_pool01_526c3a66:

    h "(( He doesn’t have to be that careful, but he seems overly cautious. ))"

translate english ch02_pool01_ff517dd3:

    h "(( Did I react too awkwardly when he got erect back then? ))"

translate english ch02_pool01_dca02ff0:

    h "(( Now I feel a little sorry. ))"

translate english ch02_pool01_c590f8f9:

    h "Huh?!!!!!!!!!!"

translate english ch02_pool01_443ef5e8:

    h "Goodness!"

translate english ch02_pool01_09d13895:

    n "Only then did she realize that a bit of her pubic hair was sticking out."

translate english ch02_pool01_301ba8c0:

    n "In that instant, along with humiliation, a subtle unfamiliar thrill wrapped around her body."

translate english ch02_pool01_932f26db:

    h "Oh my god! Was I talking to him like this the whole time?!!!"

translate english ch02_pool01_0676a67d:

    h "Goodness, [h_name]!"

translate english ch02_pool01_f5c8de3a:

    h "I definitely checked the mirror this morning... sigh..."

translate english ch02_pool01_e33a083e:

    h "Not even armpit hair, but pubic hair..."

translate english ch02_pool01_57bfd17d:

    h "He must think I’m such a sloppy middle-aged woman."

translate english ch02_pool01_d163dedc:

    h "Sigh... should I get waxed?"

translate english ch02_pool01_acabe7e4:

    h "Haha, you’re really the worst, [h_name]."

translate english ch02_pool01_823168aa:

    h "How could this happen..."

translate english ch02_pool01_148c4213:

    h "My face is burning."

translate english ch02_town01_a48c7073:

    d "This boring town hasn’t changed at all, haha."

translate english ch02_town01_14c9942e:

    d "Since I’m home, I should take a selfie."

translate english ch02_town01_d85b84d4:

    d "I’ll send it to Jason."

translate english ch02_town01_4ed1d26f:

    d "Ah, I should send one to Mary too."

translate english ch02_town01_510a5999:

    d "Sigh......"

translate english ch02_town01_ee2d524a:

    d "Ever since I sent that picture of my dick, Mary hasn’t sent me a single text..."

translate english ch02_town01_1bfd168f:

    d "Sigh... you crazy idiot."

translate english ch02_town01_8fc99f20:

    d "Why the hell did you do that to Mary..."

translate english ch02_town01_f8315c1d:

    d "I need to change the mood somehow.."

translate english ch02_town01_32a28c5f:

    d "You idiot."

translate english ch02_town01_f9afd676:

    d "Of all things, you had to do that twice..."

translate english ch02_town01_444ac815:

    d "How am I supposed to face Mary again.."

translate english ch02_town01_cb5cdd78:

    d "Huh?!"

translate english ch02_town01_f0f490a3:

    d "(( Shit!! ))"

translate english ch02_town01_4cd33ed0:

    d "(( Frank!!!!! ))"

translate english ch02_town01_441113c2:

    d "(( After a year away, the first person I run into is Frank.. ))"

translate english ch02_town01_eb60e055:

    d "(( Just my luck. ))"

translate english ch02_town01_f0da0a4b:

    d "(( But who’s that next to him?? ))"

translate english ch02_town01_ffe9ffd4:

    d "(( Who is she? I’ve never seen her before. ))"

translate english ch02_town01_61d2ee43:

    d "(( Is Frank cheating or something?! ))"

translate english ch02_town01_70d4346e:

    d "(( I should take a picture just in case. ))"

translate english ch02_town01_59353cb3:

    d "(( Shit! ))"

translate english ch02_town01_2dee3724:

    d "Hmm......"

translate english ch02_town01_6489ae42:

    d "I think he said he was going on a fishing trip with friends.."

translate english ch02_town01_b4970a48:

    d "What is he up to this time?"

translate english ch02_town01_5cdaba77:

    d "Hmm................"

translate english ch02_ahouse01_a47d07a5:

    d "Hahaha."

translate english ch02_ahouse01_2d61147d:

    d "Just being back home makes me smile."

translate english ch02_ahouse01_b4253139:

    a "I knew it was you!!"

translate english ch02_ahouse01_7f927681:

    a "My darling~"

translate english ch02_ahouse01_82c06368:

    d "I really missed you, Amanda."

translate english ch02_ahouse01_94e1abfb:

    a "Mwah~"

translate english ch02_ahouse01_9301b28a:

    d "Wow."

translate english ch02_ahouse01_2ddcccd0:

    d "You look even younger. You haven’t changed at all. Hehe."

translate english ch02_ahouse01_ec9ce37b:

    a "Hehe, saying that the moment we meet?"

translate english ch02_ahouse01_97a4f67f:

    a "Come on in, honey."

translate english ch02_ahouse01_91e8c0d8:

    a "Hahaha, [d_name]."

translate english ch02_ahouse01_ed3e7f3b:

    a "Your quirky side hasn’t disappeared even after going to college."

translate english ch02_ahouse01_9c535087:

    a "You were so excited about getting a girlfriend—what was that about?"

translate english ch02_ahouse01_1b21a194:

    a "That’s why I told you to be careful with alcohol, haha."

translate english ch02_ahouse01_285de6a0:

    d "Back then, Jason and I got competitive and drank too much."

translate english ch02_ahouse01_f9ac6362:

    d "I admit it was a stupid thing to do, haha."

translate english ch02_ahouse01_a6e0ff45:

    a "You competed in drinking with Jason in front of girls?!!"

translate english ch02_ahouse01_e9ba3794:

    a "Ha..... you two don’t deserve to have women, hahaha."

translate english ch02_ahouse01_b10b3faf:

    d "No, that’s a misunderstanding."

translate english ch02_ahouse01_b0583c86:

    d "The girls were egging us on."

translate english ch02_ahouse01_b2fb63ab:

    d "Then we both got so drunk we couldn’t even recognize our girlfriends and passed out, haha."

translate english ch02_ahouse01_949b20cc:

    a "Anyway, you need to take better care of what you eat."

translate english ch02_ahouse01_8d32c2d2:

    a "You should be at least twice this size."

translate english ch02_ahouse01_18ea54e2:

    a "At this rate, if a typhoon comes, you’ll get blown all the way to France."

translate english ch02_ahouse01_1df6a94f:

    d "Neither Jason nor I really care much about food, so we’re a bit skinny."

translate english ch02_ahouse01_1ae38811:

    d "But I’ve been working out at the gym consistently."

translate english ch02_ahouse01_cbf14094:

    a "You need to gain more weight. How are you going to lift girls up like that?"

translate english ch02_ahouse01_a86e1a74:

    n "Amanda’s seasoned dirty joke burst out."

translate english ch02_ahouse01_21d6915f:

    n "And she didn’t stop there."

translate english ch02_ahouse01_22e1c746:

    a "Got it, honey? If you’re strong, everything becomes easier. Especially your lower body and hips, hahaha."

translate english ch02_ahouse01_a2e06fa6:

    a "That’s how you’ll be able to handle any position you want."

translate english ch02_ahouse01_4f82fd6f:

    d "What did you say?!!"

translate english ch02_ahouse01_ff5c70a7:

    d "Ha... couldn’t you be a bit more careful with words like that?"

translate english ch02_ahouse01_96d7dbb2:

    d "Now it really feels like I’m back with Amanda, hahaha."

translate english ch02_ahouse01_50d67576:

    a "I’m not joking. You know that."

translate english ch02_ahouse01_c0475eab:

    a "Sex life is a big part of life."

translate english ch02_ahouse01_c5424190:

    a "Especially in college—there are so many cases where people lose control and ruin their lives with reckless sex."

translate english ch02_ahouse01_2dee3724:

    d "Hmm......"

translate english ch02_ahouse01_ee141f8b:

    d "That’s true, but..."

translate english ch02_ahouse01_180827d9:

    d "What does that have to do with being able to do different positions?"

translate english ch02_ahouse01_1a085710:

    a "If you’re too weak to do the position you want, nothing’s more humiliating than that, hahaha."

translate english ch02_ahouse01_6130045a:

    a "Anyway, you need to get physically stronger."

translate english ch02_ahouse01_d82d1f77:

    a "Not just for sex, but strong enough to protect yourself too, okay?"

translate english ch02_ahouse01_2dee3724_1:

    d "Hmm......"

translate english ch02_ahouse01_279a1d3b:

    d "You’re not wrong, but having this kind of conversation the moment we meet is a bit..."

translate english ch02_ahouse01_f17b11b6:

    d "Alright. I’ll work out harder, hehe."

translate english ch02_ahouse01_0cbf8657:

    d "I could probably hold you up for 30 minutes right now, Amanda."

translate english ch02_ahouse01_338b6f1a:

    d "Want to test it? Haha."

translate english ch02_ahouse01_9277b690:

    a "Haha."

translate english ch02_ahouse01_e342e0a1:

    a "In what position are you going to hold me?"

translate english ch02_ahouse01_6032a0c5:

    a "You know it doesn’t count if you’re just standing there holding me, right?"

translate english ch02_ahouse01_e5c36b54:

    d "..........."

translate english ch02_ahouse01_972113f4:

    d "(( In what position? Hmm......... ))"

translate english ch02_ahouse01_5e322de2:

    d "(( Damn... ))"

translate english ch02_ahouse01_020de141:

    d "(( Like this? ))"

translate english ch02_ahouse01_7044711f:

    d "(( To show Amanda my masculinity? ))"

translate english ch02_ahouse01_7ea85d44:

    d "(( Or like this? ))"

translate english ch02_ahouse01_ea03784c:

    d "(( To press tightly against Amanda? ))"

translate english ch02_ahouse01_6c4ddfd4:

    d "(( .............. ))"

translate english ch02_ahouse01_7ea85d44_1:

    d "(( Or maybe like this? ))"

translate english ch02_ahouse01_abf36089:

    d "(( To make Amanda feel tense? ))"

translate english ch02_ahouse01_f69c04fd:

    d "(( ................ ))"

translate english ch02_ahouse01_5f3de010:

    d "(( I’m fantasizing again. ))"

translate english ch02_ahouse01_981dd2f9:

    d "(( Just like I told Mary, it’s sex on my mind from the moment I wake up until I sleep. ))"

translate english ch02_ahouse01_dc50fb5e:

    d "(( Am I going to end up causing real trouble at this rate? ))"

translate english ch02_ahouse01_9ae3c991:

    a "I didn’t prepare lunch today, so let’s go eat at my sister’s place."

translate english ch02_ahouse01_7707121c:

    a "She’s been waiting to see you."

translate english ch02_ahouse01_0c15d5c8:

    d "Sounds good!"

translate english ch02_ahouse01_d0fbc2d9:

    d "I wanted to see Olivia too."

translate english ch02_ahouse01_f7a9d54e:

    a "Wait a second. I’ll get dressed and come out."

translate english ch02_ahouse01_5a870140:

    n "This was the version of her that [d_name] had missed."

translate english ch02_ahouse01_bab18086:

    n "Warm, yet throwing naughty jokes, always on the verge of crossing the line but never quite doing so."

translate english ch02_ahouse01_c317ce58:

    n "But now, she felt different to him."

translate english ch02_ahouse01_54271bbf:

    n "Now that he was an adult, Amanda was a female he could truly mate with."

translate english ch02_ahouse01_5e3aec4e:

    d ".........."

translate english ch02_ahouse01_5d295332:

    a "Honey."

translate english ch02_ahouse01_779c89de:

    a "Is there anything you want to eat?"

translate english ch02_ahouse01_27e06004:

    d "Uh....."

translate english ch02_ahouse01_6bae8b6c:

    d "Anything Italian is fine."

translate english ch02_ahouse01_9cd0ad77:

    d "Olivia’s place is an Italian restaurant anyway."

translate english ch02_ahouse01_daed6272:

    a "Hahaha."

translate english ch02_ahouse01_234aea7b:

    a "My simple, straightforward prince, hehe."

translate english ch02_ahouse01_efd6a7f8:

    a "The woman who marries you someday will have it easy."

translate english ch02_ahouse01_7f504cc4:

    d "Yes, that’s just how I am, haha."

translate english ch02_ahouse01_46d3682e:

    d "But I don’t know."

translate english ch02_ahouse01_53bfd164:

    d "Studying psychology makes me overthink things."

translate english ch02_ahouse01_474fbdef:

    d "I keep trying to analyze everything."

translate english ch02_ahouse01_a48f0a08:

    a "No, no."

translate english ch02_ahouse01_95f39808:

    a "You’ve always seemed simple, but you were picky underneath."

translate english ch02_ahouse01_f8dd4687:

    a "..............."

translate english ch02_ahouse01_d6fd8542:

    a "So, how does this outfit look?"

translate english ch02_ahouse01_7ab39cb0:

    d "!!!!"

translate english ch02_ahouse01_e134eaca:

    a "How do I look?"

translate english ch02_ahouse01_51dec36b:

    a "Is it too revealing? Hehe."

translate english ch02_ahouse01_32d58f97:

    d "No. It suits you well."

translate english ch02_ahouse01_23b3536c:

    d "You look good in anything you wear."

translate english ch02_ahouse01_8b15b03e:

    d "Amanda is the most beautiful woman in the world, hehe."

translate english ch02_ahouse01_42c65b1b:

    a "Come here, honey."

translate english ch02_ahouse01_6a1c6d9c:

    a "No matter what anyone says, you’re the best man to me."

translate english ch02_ahouse01_8ffffe02:

    a "I really, really missed you."

translate english ch02_ahouse01_093cf3ed:

    a "My prince."

translate english ch02_ahouse01_f3dc7070:

    d "Hehe. I missed you too."

translate english ch02_ahouse01_ba0bf4a0:

    d "I love you, Amanda."

translate english ch02_ahouse01_a632be3c:

    a "I love you too."

translate english ch02_ahouse01_a8911dc9:

    a "Muah~"

translate english ch02_acar01_64983089:

    a "Damn! I forgot my sunglasses."

translate english ch02_acar01_2d05477a:

    a "I can’t drive with my eyes closed, can I..."

translate english ch02_acar01_6816b12d:

    a "So..."

translate english ch02_acar01_2d24c3d4:

    a "How are your college classes? Are you keeping up alright?"

translate english ch02_acar01_b1334da1:

    a "Even though I said you were worrying over nothing, you were so anxious about whether the classes would be too hard."

translate english ch02_acar01_be0c5c07:

    d "Yes, overall it’s good."

translate english ch02_acar01_165c651f:

    d "I like the classes, and they’re not as difficult as I expected."

translate english ch02_acar01_81efe063:

    d "I especially like my professor."

translate english ch02_acar01_e3f5d932:

    d "She really tries to explain things in a way freshmen can understand."

translate english ch02_acar01_37aaa005:

    d "She’s quite highly regarded in the field of psychology."

translate english ch02_acar01_04598399:

    a "Wow."

translate english ch02_acar01_1fbf10dc:

    a "A professor who satisfies picky [d_name]’s intellectual thirst? That’s impressive."

translate english ch02_acar01_909df26b:

    a "You must feel even prouder since it was a major you chose with such care."

translate english ch02_acar01_002bfa48:

    d "Yes. I was worried I wouldn’t feel like I was learning or growing, but thankfully that’s not the case."

translate english ch02_acar01_791efaf4:

    d "It’s lucky to have such a capable professor at a university in a small city."

translate english ch02_acar01_f077189b:

    d "And that professor is, well..."

translate english ch02_acar01_17659cc8:

    a ".............."

translate english ch02_acar01_6ab6d105:

    a "What about her?"

translate english ch02_acar01_f8609ea7:

    a "Why are you hesitating?"

translate english ch02_acar01_b83aeb90:

    d "Hmm......"

translate english ch02_acar01_4895759f:

    d "Well...... one of the reasons she’s great is"

translate english ch02_acar01_be2faeae:

    d "She’s got an amazing figure too, hahaha."

translate english ch02_acar01_2f53747f:

    a "Hahahaha."

translate english ch02_acar01_1c74e534:

    a "What, you hesitated just to say that?"

translate english ch02_acar01_bd62280a:

    a "I thought you were going to confess you had a secret crush on her, hahaha."

translate english ch02_acar01_053a4af1:

    a "Or maybe I thought you’d say something more dramatic."

translate english ch02_acar01_3a0f073c:

    a "Hmm..... that’s a bit anticlimactic."

translate english ch02_acar01_be3f17c3:

    a "But I’m kind of jealous."

translate english ch02_acar01_db6c52fa:

    a "What kind of woman stole our [d_name]’s heart with that body of hers?"

translate english ch02_acar01_74c11af2:

    a "Be honest."

translate english ch02_acar01_70790381:

    a "Between me and that professor, whose figure do you think is better?"

translate english ch02_acar01_696989f4:

    d "(( ............ ))"

translate english ch02_acar01_1c31606a:

    d "(( Why would she ask that? ))"

translate english ch02_acar01_658fb69e:

    d "(( This feels like I need to answer carefully. ))"

translate english ch02_acar01_c2ee855d:

    d "Hahaha. Aren’t you asking something too obvious?"

translate english ch02_acar01_931fb4c5:

    d "Of course your figure is the best, Amanda."

translate english ch02_acar01_51167b42:

    d "Your figure is the treasure of our town."

translate english ch02_acar01_f4cc695c:

    a "What? The treasure of this town?"

translate english ch02_acar01_31c09108:

    d "No woman could ever compare to you."

translate english ch02_acar01_2f53747f_1:

    a "Hahahahaha."

translate english ch02_acar01_177b7b51:

    a "You little smooth talker, hehe."

translate english ch02_acar01_8a7ed859:

    a "I’ll admit you’ve at least got the basics down to date other girls."

translate english ch02_acar01_f78dc687:

    a "All my nagging before you left for college paid off."

translate english ch02_acar01_d3f68592:

    d "Hehe. Right....."

translate english ch02_acar01_dedd6219:

    d "I learned a lot from you, Amanda.."

translate english ch02_acar01_ecf048e0:

    d "(( Damn.... ))"

translate english ch02_acar01_a7915177:

    d "(( I’m getting hard at this timing?.... ha... ))"

translate english ch02_cafe01_157c064e:

    d "(( Damn.. ))"

translate english ch02_cafe01_4a81ad24:

    d "(( Her side boob is touching my arm.. ))"

translate english ch02_cafe01_40eb6489:

    d "(( It’s as soft as Mary’s was... ha... ))"

translate english ch02_cafe01_db6831d9:

    d "(( Is this what they mean when they say ‘melons’? ))"

translate english ch02_cafe01_f6bcca61:

    d "(( This is on a completely different level from freshman girls.. ))"

translate english ch02_cafe01_898e17d6:

    o "I’m telling you, that’s what he said to me!"

translate english ch02_cafe01_07202e6b:

    o "I couldn’t believe there was a man that crazy in this world."

translate english ch02_cafe01_b1e87084:

    o "(( Haha, they’re here!!! ))"

translate english ch02_cafe01_6950a2cb:

    o "(( Oh my... ))"

translate english ch02_cafe01_46367dee:

    o "(( Look at what she’s wearing.. ))"

translate english ch02_cafe01_8b043373:

    o "(( Her boobs are practically about to pop out. ))"

translate english ch02_cafe01_d2fb69d3:

    o "(( What a bitch! ))"

translate english ch02_cafe01_5a639886:

    d "Hello, Olivia!!"

translate english ch02_cafe01_2d32d387:

    o "Hey."

translate english ch02_cafe01_f5287b81:

    o "You guys are here!"

translate english ch02_cafe01_34e42851:

    o "Glad you came, sis."

translate english ch02_cafe01_89c80c19:

    a "Have you been well?"

translate english ch02_cafe01_0a783592:

    o "Hey, [d_name]!!"

translate english ch02_cafe01_ff7e3562:

    o "You think it’s okay to leave us alone for a whole year?!"

translate english ch02_cafe01_845a4599:

    o "You deserve to be scolded."

translate english ch02_cafe01_a612ef4c:

    o "Did you forget about us just because you went to college?"

translate english ch02_cafe01_49230f60:

    o "Do you know how much I adored you?!"

translate english ch02_cafe01_97d5f9db:

    o "You bad boy!"

translate english ch02_cafe01_fc7eb673:

    o "How many times did I tell you to come home more often, huh?"

translate english ch02_cafe01_412e4a35:

    d "I’m sorry, Olivia. You know how it is."

translate english ch02_cafe01_a3cb12c2:

    d "Because of Frank, I didn’t really have a choice. Hehe."

translate english ch02_cafe01_20db8706:

    o "Even so, if not you, who’s going to look after Amanda?"

translate english ch02_cafe01_dbf93972:

    o "Amanda spends lonely nights every day."

translate english ch02_cafe01_8353be67:

    o "When someone’s lonely, it even shortens their lifespan. Did you know that?"

translate english ch02_cafe01_9a4ff525:

    a "(( Bullshit. ))"

translate english ch02_cafe01_9dbda8fb:

    a "(( She’s the one rolling around with men every night and barely even calling, seriously. ))"

translate english ch02_cafe01_292c2ed7:

    a "(( Does she think I don’t know? ))"

translate english ch02_cafe01_850d3f8d:

    a "Enjoy your food, honey."

translate english ch02_cafe01_41979eb4:

    a "I’ll just have a taste. I’m dieting these days."

translate english ch02_cafe01_8cc0f4ae:

    a "You have to eat it all."

translate english ch02_cafe01_88f9891d:

    d "Haha, alright."

translate english ch02_cafe01_5ec47298:

    d "If I’m going to lift Amanda up, I need to eat more, hahaha."

translate english ch02_cafe01_0ec47bc0:

    a "Hahahaha. Oh really?"

translate english ch02_cafe01_e342e0a1:

    a "In what position are you going to lift me?"

translate english ch02_cafe01_2f547662:

    a "Don’t just talk—actually try it."

translate english ch02_cafe01_38ec0146:

    a "I like strong men, hehe."

translate english ch02_cafe01_33a4092f:

    a "By the way, honey."

translate english ch02_cafe01_575f8abf:

    a "After that incident, did you completely break up with your girlfriend?"

translate english ch02_cafe01_82b2874b:

    a "You know..."

translate english ch02_cafe01_31c87572:

    a "Even if people break up like that, they usually keep texting and don’t completely cut ties."

translate english ch02_cafe01_182df2b2:

    a "There must’ve been some attachment, and some time has passed too.."

translate english ch02_cafe01_794d5c3e:

    a "In your early twenties, people break up impulsively. It’s not usually to the point of never wanting to see each other again."

translate english ch02_cafe01_e5c36b54:

    d "..........."

translate english ch02_cafe01_33bfa616:

    d "Ha....."

translate english ch02_cafe01_7d05ac98:

    d "After that incident..."

translate english ch02_cafe01_7da31ef1:

    d "She started dating someone else just a week later."

translate english ch02_cafe01_c45e5258:

    a "What? A week?"

translate english ch02_cafe01_4c51f50d:

    a "What a bitch!"

translate english ch02_cafe01_7c550c92:

    a "So she was two-timing you while seeing you!"

translate english ch02_cafe01_59226960:

    a "How could she do that?"

translate english ch02_cafe01_b2a86b14:

    a "At that age, sure, people play around, but after dating for months, there should still be some attachment."

translate english ch02_cafe01_fc9a8b36:

    a "How can someone switch that easily without hesitation?"

translate english ch02_cafe01_4aa8fc1b:

    a "I really don’t understand young girls these days."

translate english ch02_cafe01_017d1675:

    a "If she keeps that up, she’ll be sleeping with dozens of men a year."

translate english ch02_cafe01_5160b9be:

    a "Isn’t that way too loose?"

translate english ch02_cafe01_6dc68014:

    a "She’ll ruin her life at that rate."

translate english ch02_cafe01_6a21657e:

    d "..............."

translate english ch02_cafe01_3b0a6eb5:

    d "Well, what can I do."

translate english ch02_cafe01_d971bb9d:

    d "It’s not like I can change it."

translate english ch02_cafe01_530d0fcf:

    a "Honey..."

translate english ch02_cafe01_da3c45c8:

    a "Sometimes you’re too nice for your own good."

translate english ch02_cafe01_f53a7b27:

    a "If someone did that to you, you should’ve paid her back the same way."

translate english ch02_cafe01_d2aa17ec:

    a "You should’ve shown up with another girl on your arm and let her see!"

translate english ch02_cafe01_8a66b2df:

    a "There’s nothing sweeter in this world than revenge."

translate english ch02_cafe01_952d0cd7:

    a "An eye for an eye."

translate english ch02_cafe01_a47d07a5:

    d "Hahaha."

translate english ch02_cafe01_ce8658ad:

    d "It’s already in the past."

translate english ch02_cafe01_3791983e:

    d "There must be someone better out there."

translate english ch02_cafe01_c47012b5:

    o "Is the food good?"

translate english ch02_cafe01_bf4d7a5a:

    d "Yes, it’s really delicious!!"

translate english ch02_cafe01_95db41af:

    o "Thank you, hehe."

translate english ch02_cafe01_6058bdea:

    o "But what are you two talking about so excitedly?"

translate english ch02_cafe01_5d21c752:

    o "Let me join the conversation."

translate english ch02_cafe01_5b8f15a5:

    o "It’s about your love life, right? Hehe."

translate english ch02_lake01_0a64fa8f:

    f "Damn it. Not a single bite today."

translate english ch02_lake01_4f919b55:

    f "I shouldn't have come out here just to go home empty-handed."

translate english ch02_lake01_bb9f2889:

    f "I caught one in the morning, and it's been nothing but bad luck since."

translate english ch02_lake01_f5e19bf5:

    f "Hey Emma!"

translate english ch02_lake01_cb314e80:

    f "Say a prayer or something to get the fish biting."

translate english ch02_lake01_5a7436e4:

    f "Don't just lie there so comfortably, do something helpful!"

translate english ch02_lake01_c9cde0c5:

    e ".........."

translate english ch02_lake01_c5f55437:

    e "That's not part of the arrangement, Daddy."

translate english ch02_lake01_c9cde0c5_1:

    e ".........."

translate english ch02_lake01_764139fe:

    e "My only duty is to be your companion and satisfy you."

translate english ch02_lake01_2f18c1fa:

    f "Ha! Is that so?!"

translate english ch02_lake01_607bfd95:

    f "What has this world come to..."

translate english ch02_lake01_098e8f42:

    f "Everything is about the damn business."

translate english ch02_lake01_b3b49515:

    f "Terms! Terms! Terms!"

translate english ch02_lake01_0860c143:

    e "No, Frank."

translate english ch02_lake01_4ffc5f68:

    e "This is about the promise we made. It's not just about the business."

translate english ch02_lake01_bbccfd66:

    f "Oh, really?"

translate english ch02_lake01_70a3224a:

    f "Fine, then I'll take what I'm owed from our deal!"

translate english ch02_lake01_93ed88c6:

    f "The 'special service' you promised in our agreement!"

translate english ch02_lake01_6a602310:

    f "Alright Emma, start now."

translate english ch02_lake01_3a041503:

    f "Show me the appreciation I've properly supported you for!!"

translate english ch02_lake01_e7b86129:

    e "Jesus, Frank."

translate english ch02_lake01_29fdad8c:

    e "Don't be so aggressive. I'll do my best to provide you with pleasure."

translate english ch02_lake01_5d6bae10:

    e "I'm even willing to put up with those ridiculous positions of yours. But..."

translate english ch02_lake01_e8c258c0:

    e "Look at your condition. You need to get yourself ready first."

translate english ch02_lake01_6be94ae8:

    f "................"

translate english ch02_lake01_325d70b1:

    f "Don't you try to brush me off."

translate english ch02_lake01_1be30871:

    f "Getting me in the mood is part of the agreement too!!"

translate english ch02_lake01_4e75d8b3:

    f "Damn it. Emma. Just start."

translate english ch02_lake01_91470cd4:

    f "Once you begin, I'll be ready!!"

translate english ch02_lake01_c788d0b7:

    e "Damn it."

translate english ch02_lake01_0db1b05a:

    e "I was crazy to agree to this..."

translate english ch02_lake01_1d8ebaa9:

    e ".................."

translate english ch02_lake01_5e58b267:

    f "Come on Emma. Hurry up."

translate english ch02_lake01_213d770b:

    e "(( shit. ))"

translate english ch02_lake01_a5acdbd0:

    e "Aright aright."

translate english ch02_lake01_358a8925:

    f "Damn it. Emma. You're the best."

translate english ch02_lake01_9ae28673:

    f "Damn it!!"

translate english ch02_lake01_d73bdc42:

    f "Emma, lie down now!"

translate english ch02_lake01_d9e05fb3:

    e "Ah!"

translate english ch02_lake01_91827771:

    e "You son of a..."

translate english ch02_lake01_d03c9346:

    e "Don't treat me like that!"

translate english ch02_lake01_6496761f:

    e "I'm not just some disposable object!"

translate english ch02_lake01_81b0323e:

    e "Look at yourself, Frank."

translate english ch02_lake01_a1cb1cd2:

    e "Look at your poor condition."

translate english ch02_lake01_e956e03d:

    f "What?"

translate english ch02_lake01_6be94ae8_1:

    f "................"

translate english ch02_lake01_ad2e9e75:

    f "Oh, for god's sake! You ruined the mood again."

translate english ch02_lake01_7b13934e:

    e "You think you can satisfy me with that?"

translate english ch02_lake01_a0f0a86f:

    e "Dream on, you pathetic man!"

translate english ch02_lake01_98341132:

    e "No woman would ever truly want to be with someone like you!"

translate english ch02_lake01_fccef6ca:

    f "Damn it."

translate english ch02_lake01_4d1988a1:

    e "Let's do this, Frank."

translate english ch02_lake01_d31d98f2:

    f "Yeah, that's what I'm talking about!"

translate english ch02_lake01_3e43206a:

    f "Show me everything!!"

translate english ch02_lake01_97a507e7:

    e "Come find me at my place when you're in better shape."

translate english ch02_lake01_734353f3:

    e "And today, I’ll just enjoy watching you fish like that—so I’m keeping the support money."

translate english ch02_lake01_f3d3cb76:

    e "How about that, Frank?"

translate english ch02_lake01_702f6bae:

    f "You sly woman."

translate english ch02_lake01_318b849c:

    f "You're going to keep my support for nothing?"

translate english ch02_lake01_1e557a74:

    f "You want me to just show you my body and be satisfied?!!"

translate english ch02_lake01_8aac5b1e:

    f "Don't even think about it, you witch!"

translate english ch02_lake01_31df6c75:

    e "Fine."

translate english ch02_lake01_1eb06d38:

    e "I'll return your support, so let's go back to town right now."

translate english ch02_lake01_2cea1901:

    e "Of course, I'll keep a portion for the 'service' I've already provided."

translate english ch02_lake01_c4e6e6b1:

    f "Fine. I'll visit you at the center when I'm feeling better."

translate english ch02_lake01_f1527e46:

    f "Next time, be more affectionate, like a real partner."

translate english ch02_lake01_bc95a90e:

    e "Alright, Daddy."

translate english ch02_lake01_79218b00:

    e "Come prepared next time."

translate english ch02_lake01_ee0547a7:

    e "I'll give you the warmest welcome possible."

translate english ch02_lake01_a1d01062:

    e "And I'll show you heaven."

translate english ch02_lake01_8fae4c43:

    f "Heaven......."

translate english ch02_lake01_e629fa22:

    f "..............."

translate english ch02_lake01_eb9603e8:

    f "Good lord....."

translate english ch02_cafe02_264304ae:

    o "What are you two talking about that's so fun? Hehe."

translate english ch02_cafe02_5d21c752:

    o "Let me join the conversation too."

translate english ch02_cafe02_5b190d17:

    a "You know, conversations with a college freshman are pretty predictable, aren’t they?"

translate english ch02_cafe02_18c74f3d:

    a "It’s this little guy’s love story. Classic stuff, absolutely classic, haha."

translate english ch02_cafe02_97d76a78:

    o "Oh! That’s my specialty."

translate english ch02_cafe02_e4143106:

    o "What kind of romantic trouble could our lovely [d_name] be having?"

translate english ch02_cafe02_735fa177:

    o "Don’t tell me it’s something too embarrassing to tell me? Hehe."

translate english ch02_cafe02_a1392911:

    d "(( Oh my God... ))"

translate english ch02_cafe02_246e9570:

    d "(( Were her boobs always that big? ))"

translate english ch02_cafe02_6c4ddfd4:

    d "(( .............. ))"

translate english ch02_cafe02_69de5c76:

    d "(( They’re on par with Amanda’s... ))"

translate english ch02_cafe02_1b39920b:

    o "(( Heh. ))"

translate english ch02_cafe02_abf5731d:

    o "(( [d_name]… he’s gotten bold enough to stare now. ))"

translate english ch02_cafe02_bf913b7f:

    o "(( He can’t even keep a poker face, just staring like an idiot. No wonder women don’t like that. ))"

translate english ch02_cafe02_a37c1087:

    o "(( Alright. So you’re an adult now, is that it? ))"

translate english ch02_cafe02_f816fca2:

    n "When she saw [d_name] again after a year, she felt that he had become more mature."

translate english ch02_cafe02_1dba2dd2:

    n "And when she hugged him, she could feel that his body had grown firmer and broader."

translate english ch02_cafe02_34df0344:

    n "In other words, it meant she could now put aside her guilty conscience and speak to [d_name] more comfortably."

translate english ch02_cafe02_40fc782d:

    o "(( Then let’s have an adult conversation. Why is everyone beating around the bush like this? ))"

translate english ch02_cafe02_806076cc:

    o "(( How long is Amanda going to keep treating [d_name] like a child? ))"

translate english ch02_cafe02_96d3e87b:

    o "(( What boring people. ))"

translate english ch02_cafe02_b9afe496:

    o "(( Hmm..... ))"

translate english ch02_cafe02_b6c83faf:

    o "(( What are you plotting, Amanda? ))"

translate english ch02_cafe02_99932ba7:

    o "(( You don’t actually want him to remain your [d_name] forever, do you? ))"

translate english ch02_cafe02_8da3be8e:

    o "(( Are you afraid he’ll meet a woman and leave your side? ))"

translate english ch02_cafe02_a49e9bec:

    o "What’s going on? Aren’t you going to tell me?"

translate english ch02_cafe02_188c7611:

    a "Oh, it’s nothing."

translate english ch02_cafe02_e924df6b:

    a "He broke up with his girlfriend not long before coming home."

translate english ch02_cafe02_d0b2f3ce:

    a "And that girl started dating another guy just a week later."

translate english ch02_cafe02_7dc15aca:

    a "So we were just talking trash about her together."

translate english ch02_cafe02_a704a145:

    o "Haha, sis. Aren’t you taking [d_name]’s side a bit too much?"

translate english ch02_cafe02_6e13db24:

    o "You should hear the girl’s side of the story too."

translate english ch02_cafe02_15f848c2:

    o "Our prince might’ve screwed things up with her, you know."

translate english ch02_cafe02_747020af:

    o "If you just keep siding with him because he seems pitiful, it might backfire."

translate english ch02_cafe02_a221eceb:

    a "She started seeing another guy just a week after they broke up. That says enough."

translate english ch02_cafe02_2b784277:

    a "How could she do that? The world’s gone crazy."

translate english ch02_cafe02_e14e822a:

    o "Goodness, Amanda."

translate english ch02_cafe02_3123e31a:

    o "These days, a week almost makes her look modest."

translate english ch02_cafe02_2e67596d:

    o "Plenty of people date two at once. How can you blame her for seeing someone else after they broke up?"

translate english ch02_cafe02_859ebdcd:

    o "Right?"

translate english ch02_cafe02_baafd6f2:

    o "[d_name] should date different women too. That’s how he’ll become more experienced."

translate english ch02_cafe02_83d9ba67:

    o "There’s nothing wrong with that."

translate english ch02_cafe02_d6d57322:

    a "Oh really? Please don’t include the two of us in that world of yours."

translate english ch02_cafe02_a836f895:

    a "Our [d_name] is a rare romantic in this day and age."

translate english ch02_cafe02_27283fab:

    a "He’ll meet one woman and become part of a legendary couple, like Romeo and Juliet."

translate english ch02_cafe02_37442ace:

    n "Olivia felt grateful to Amanda for a moment."

translate english ch02_cafe02_d20e7399:

    n "Because Amanda had followed along with the twisted direction of the conversation and set the stage for her to deliver the decisive line."

translate english ch02_cafe02_23ac5f5d:

    o "Romeo and Juliet? Ha… what is this, the Middle Ages?"

translate english ch02_cafe02_69aa9c44:

    o "How tragic."

translate english ch02_cafe02_75365cc6:

    o "If you’d lived with me, you’d be fucking every college girl on campus by now. Ha ha."

translate english ch02_cafe02_0da88778:

    d "(( ...... ))"

translate english ch02_cafe02_ee89e95a:

    o "(( Of course, you’d be fucking me too. Hehe. ))"

translate english ch02_cafe02_1bb8871c:

    o "(( Until I'm sore every single day. ))"

translate english ch02_cafe02_8e12dd1c:

    o "(( I could teach you pleasures only a mature woman can give… ))"

translate english ch02_cafe02_9485f3c8:

    a "What?! Goodness, Olivia. What are you talking about?"

translate english ch02_cafe02_8e705f51:

    a "Do you think college is a place to go for dating?"

translate english ch02_cafe02_bdc9debe:

    a "You haven’t seen [d_name] in a year, and that’s all you have to say?"

translate english ch02_cafe02_7a287c63:

    a "Goodness. This is why I keep my distance from you."

translate english ch02_cafe02_709db80d:

    a "I hate people whose heads are filled with nothing but sex."

translate english ch02_cafe02_af2421a9:

    o "Haha, sis. Don’t judge me like that."

translate english ch02_cafe02_1396a3ec:

    o "I’m just being honest."

translate english ch02_cafe02_2d45c588:

    o "(( And your head is just as full of sex as mine. ))"

translate english ch02_cafe02_95a131e8:

    o "I said it because I want [d_name] to become a more attractive man."

translate english ch02_cafe02_880f71ab:

    o "Wouldn’t it be great to be loved by everyone, from young girls to middle-aged women?"

translate english ch02_cafe02_30185867:

    o "(( It wouldn’t be bad for you either, sis. ))"

translate english ch02_cafe02_c0864009:

    o "Hey, [d_name]."

translate english ch02_cafe02_4f1b8dc1:

    o "Forget boring Amanda and go on a date with me instead."

translate english ch02_cafe02_819c4034:

    o "How about being my cute boyfriend just for today?"

translate english ch02_cafe02_ff945e04:

    n "He felt a little confused."

translate english ch02_cafe02_041600b7:

    n "He had seen her from time to time, but he hadn’t known she was this kind of woman."

translate english ch02_cafe02_eb805c52:

    n "And in that moment, he was completely caught in the web she had spun."

translate english ch02_cafe02_e6b6e35a:

    a "Oh really? Seeing [d_name] just laughing, you two seem to get along very well."

translate english ch02_cafe02_eefb3974:

    a "Going on a honeymoon next, are you?"

translate english ch02_cafe02_4832b973:

    a "Have fun. I’m going to the restroom."

translate english ch02_cafe02_49b3d461:

    a "Oh! And let me know once you decide on your child’s name."

translate english ch02_cafe02_9887816e:

    o "(( Haha. See that? ))"

translate english ch02_cafe02_e36884fd:

    o "(( The true nature hidden deep inside you is starting to squirm, isn’t it? ))"

translate english ch02_cafe02_f4b2aeab:

    o "(( That’s what happens when you keep it all bottled up. You age faster. ))"

translate english ch02_cafe02_9f514d57:

    a "(( That bitch never changes. ))"

translate english ch02_cafe02_51cc4855:

    a "(( How can she stay the same no matter how old she gets? ))"

translate english ch02_cafe02_187399cc:

    a "(( If it’s a man’s cock, she’ll jump up even in her sleep! ))"

translate english ch02_cafe02_8a90017e:

    a "(( Ha! So you’re challenging your big sister, is that it? ))"

translate english ch02_cafe02_1b811306:

    o "Hehehe."

translate english ch02_cafe02_58b5c5fb:

    o "Think about it carefully, [d_name]."

translate english ch02_cafe02_2ec73271:

    o "You can’t even go home because of Frank. How about staying at my place during the break?"

translate english ch02_cafe02_d554fc0c:

    o "There’s no one like Frank to make your life miserable."

translate english ch02_cafe02_c60ca29c:

    o "At my place, you can live freely without any rules. Hehe."

translate english ch02_cafe02_48b3f4b0:

    o "Sleep late, stay up all night playing games—no one will say a word."

translate english ch02_cafe02_a670b92c:

    o "I don’t even wear underwear around the house, hehe."

translate english ch02_cafe02_498148da:

    d "(( !!!!!!!!!!!! ))"

translate english ch02_cafe02_f180e2b0:

    o "You know I’m living separately from my husband right now."

translate english ch02_cafe02_684ddb61:

    o "I’ve been so lonely lately..."

translate english ch02_cafe02_8c1f642f:

    o "Wait a second..."

translate english ch02_cafe02_a73b74fc:

    o "I’ll show you a picture of my house."

translate english ch02_cafe02_4d026153:

    o "Ah, found it!"

translate english ch02_cafe02_f7662ad8:

    o "Look. My house gets this fresh sunlight."

translate english ch02_cafe02_e0a43b3a:

    o "Instead of gloomy Amanda’s neighborhood, stay with me during the break. Hehe."

translate english ch02_cafe02_29273932:

    o "Don’t you feel like packing your bags and coming right away?"

translate english ch02_cafe02_3714a68e:

    o "What do you think?"

translate english ch02_cafe02_9d981008:

    d "This is really..."

translate english ch02_cafe02_80d313ad:

    d "It’s the most beautiful thing I’ve ever seen..."

translate english ch02_cafe02_a79edcd9:

    o "What do you mean is beautiful?"

translate english ch02_cafe02_48afa514:

    o "My kitchen? Hahaha."

translate english ch02_cafe02_8dd8ff22:

    o "This little guy is smoother than he looks."

translate english ch02_cafe02_41e2589a:

    o ".............."

translate english ch02_cafe02_00cfb994:

    o "Ah, that machine’s acting up right now."

translate english ch02_cafe02_502c4edf:

    o "It’s working on and off."

translate english ch02_cafe02_d0ac6e87:

    o "It’ll be fine in a second."

translate english ch02_cafe02_4c266fc3:

    o "Put the cup up and pull the lever down."

translate english ch02_cafe02_1c66fed3:

    d "!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_f0b55ce9:

    d "(( What the fuck! ))"

translate english ch02_cafe02_3ff0cc0f:

    n "In that instant, what entered his field of vision was.."

translate english ch02_cafe02_2f8409b5:

    n "exactly what he had desired from the moment he woke up until he fell asleep."

translate english ch02_cafe02_6675c7f8:

    d "(( What the fuck! ))"

translate english ch02_cafe02_bbdcab55:

    d "(( Oh my God, Olivia!! ))"

translate english ch02_cafe02_e199d506:

    o "(( I can feel exactly what you’re thinking right now. ))"

translate english ch02_cafe02_8d2c45b1:

    o "(( Innocent boy. ))"

translate english ch02_cafe02_59a95da2:

    a "Heh."

translate english ch02_cafe02_b9f25030:

    a "So, did you succeed in seducing [d_name]?"

translate english ch02_cafe02_85498ef0:

    a "!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_92a127d7:

    a "(( What the hell is that crazy bitch! ))"

translate english ch02_cafe02_3a6c19a8:

    a "(( She’s doing that on purpose!! ))"

translate english ch02_cafe02_dad07d5a:

    a "(( What a slut!! ))"

translate english ch02_cafe02_904d610d:

    a "(( How dare she shove that filthy ass in front of him!!!!! ))"

translate english ch02_cafe02_40fbeac4:

    a "(( Bitch! ))"

translate english ch02_cafe02_6801c254:

    o "Huh?!!!!!!!!!!"

translate english ch02_cafe02_32000984:

    n "For a brief moment, Olivia was startled."

translate english ch02_cafe02_869cbc8b:

    n "She thought it was [d_name] who had slapped her ass."

translate english ch02_cafe02_98d69fbf:

    n "It lasted only a second, but she felt an indescribable thrill."

translate english ch02_cafe02_e30a9d88:

    o "(( What was that? ))"

translate english ch02_cafe02_fc89170a:

    a "................."

translate english ch02_cafe02_e2dbddc5:

    a "Are you trying to mess with me right now?"

translate english ch02_cafe02_7edebcb7:

    o "(( Damn!! ))"

translate english ch02_cafe02_00b44be4:

    o "(( I knew that felt like a woman’s hand.. ))"

translate english ch02_cafe02_6119e40f:

    o "(( That idiot wouldn’t dare be that bold. ))"

translate english ch02_cafe02_8def7d90:

    a "Did you eat well, honey?"

translate english ch02_cafe02_1cb915a0:

    a "Then let’s head home."

translate english ch02_cafe02_d208c610:

    d "Ow."

translate english ch02_cafe02_0849d446:

    d "Ah... okay."

translate english ch02_cafe02_6e807fff:

    o "Your boobs are really soft."

translate english ch02_cafe02_74f80aa0:

    o "Even [d_name] knows how soft they are, right?"

translate english ch02_cafe02_5cac9569:

    o "You should hurry and teach him a woman’s pleasure. Otherwise, I might just seduce him and take him away."

translate english ch02_cafe02_0aff2d12:

    a "You bitch!"

translate english ch02_cafe02_5542f20b:

    a "Why didn't you just show him your asshole too?"

translate english ch02_cafe02_0dbaf260:

    a "Go ahead and try to seduce [d_name]."

translate english ch02_cafe02_25ddc252:

    a "You dirty slut!"

translate english ch02_cafe02_1b811306_1:

    o "Hahaha."

translate english ch02_cafe02_370a1e93:

    o "So that means I have your permission now?"

translate english ch02_cafe02_79047fce:

    o "That boy’s going to be thinking about my ass for the rest of his life."

translate english ch02_cafe02_c0222b57:

    a "Oh really?"

translate english ch02_cafe02_a20f1b87:

    a "By the end of today, your ass won’t even leave a trace in his mind."

translate english ch02_cafe02_b1251b15:

    o "Hehe. We’ll see."

translate english ch02_cafe02_7212a87b:

    n "Olivia pressed her body against [d_name] with all her strength."

translate english ch02_cafe02_38ef8f55:

    n "Unlike when they first met, she could feel him pressing back just as firmly, and she sensed that he wanted her too."

translate english ch02_cafe02_743e4364:

    o "Honey."

translate english ch02_cafe02_117e8543:

    o "Next time, let’s meet just the two of us, okay?"

translate english ch02_cafe02_cba1cc5a:

    o "Let that old lady play with Frank, and we’ll go on a date."

translate english ch02_cafe02_743e4364_1:

    o "Honey."

translate english ch02_cafe02_82a66c67:

    o "Women like men who actually take action."

translate english ch02_cafe02_da5009da:

    o "Be more confident. Anytime."

translate english ch02_cafe02_1565afe8:

    o "What’s the worst she can do? Slap you?"

translate english ch02_cafe02_6cbd768a:

    o "..............."

translate english ch02_cafe02_dff3c9dc:

    o "Kiss me."

translate english ch02_cafe02_8c097a17:

    d "Okay."

translate english ch02_cafe02_25851351:

    o "You fool."

translate english ch02_cafe02_c1958ee1:

    o "Open your mouth."

translate english ch02_cafe02_d9b48000:

    d "!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_cafe02_6cbd768a_1:

    o "..............."

translate english ch02_cafe02_13f591fa:

    o "Next time I see you, I hope you’ll be a real man—one with confidence, kid."

translate english ch02_cafe02_f24ab54f:

    o "Send me a message, alright?"

translate english ch02_cafe02_b4f1e6ac:

    a "Come on, honey."

translate english ch02_cafe02_16697a9f:

    a "It’s getting dark. Let’s go."

translate english ch02_cafe02_ff678d23:

    a "..........................."

translate english ch02_cafe02_a797f6ce:

    d "............."

translate english ch02_cafe02_762d2724:

    d "Haha, why are you looking at me like that?"

translate english ch02_cafe02_0a60958f:

    a "You little rascal."

translate english ch02_cafe02_20ca4802:

    a "Did you enjoy staring at Olivia’s ass?"

translate english ch02_cafe02_d72926e9:

    a "You were staring at it like you were hypnotized."

translate english ch02_cafe02_5ff861d9:

    a "If it got that far, you should’ve done something!"

translate english ch02_cafe02_aad23aa5:

    d "What?!"

translate english ch02_cafe02_89e61127:

    d "No, I just froze up."

translate english ch02_cafe02_27ce770d:

    d "And if I’d tried to pull down her skirt in that situation, my hand would’ve touched her ass."

translate english ch02_cafe02_2083d759:

    d "If things went wrong, I’d be labeled a pervert."

translate english ch02_cafe02_19a8a337:

    a "Ha! As if!"

translate english ch02_cafe02_e3f7c4ba:

    a "If you’d gotten any closer, she would’ve shoved her ass right at you!!!"

translate english ch02_cafe02_b80a910b:

    a "Do you know what I mean?!!"

translate english ch02_cafe02_8e76dd25:

    a "Her ass pressed against your c…!!"

translate english ch02_cafe02_55c02367:

    a "......."

translate english ch02_cafe02_e17aa140:

    a "Anyway, that dirty bitch!"

translate english ch02_cafe02_7e53be0e:

    a "She’s always like that!!"

translate english ch02_cafe02_85ea696a:

    a "Come here, you!"

translate english ch02_cafe02_94e1abfb:

    a "Mwah~"

translate english ch02_cafe02_ea8ea6b4:

    a "I’m sulking."

translate english ch02_cafe02_39b7b119:

    a "It feels like you like my younger sister more than me."

translate english ch02_cafe02_506f2f51:

    a "How could you? After all the time we’ve spent together.."

translate english ch02_cafe02_0cade13d:

    a "And you fell for that sly bitch!"

translate english ch02_cafe02_31968e34:

    a "Do I have to show you my ass too? Huh?"

translate english ch02_cafe02_6dd334c8:

    a "Hahaha."

translate english ch02_cafe02_3f35183b:

    a "Let’s go home, darling. Hehe."

translate english ch02_cafe02_77748d65:

    a "(( Let’s go back to our home sweet home. ))"

translate english ch02_ahouse02_5d295332:

    a "Honey."

translate english ch02_ahouse02_50bab430:

    a "Since Frank isn’t there, how about we watch a movie together in the living room? Just the two of us."

translate english ch02_ahouse02_34c19590:

    d "Just like old times? Hehe."

translate english ch02_ahouse02_d36529aa:

    a "Just like old times.."

translate english ch02_ahouse02_776d5515:

    a "Except we watch what I want to watch. Hehe."

translate english ch02_ahouse02_0c15d5c8:

    d "Sounds good!"

translate english ch02_ahouse02_38dfa0e3:

    d "I like any movie, hehe."

translate english ch02_ahouse02_b543daa1:

    a "Alright, then take a shower and meet me here in 30 minutes."

translate english ch02_ahouse02_8c097a17:

    d "Okay."

translate english ch02_ahouse02_48fb6438:

    a "(( Just like old times.. ))"

translate english ch02_ahouse02_2417ca73:

    a "(( That’s right. Just like old times.. ))"

translate english ch02_ahouse02_59ef63d8:

    a "..................."

translate english ch02_ahouse02_608e8a36:

    n "Without realizing it, she washed her vagina more carefully than usual."

translate english ch02_ahouse02_40e3e977:

    n "Her actions stemmed from her subconscious."

translate english ch02_ahouse02_2a373169:

    n "Like someone obsessively preparing for something that might never happen..."

translate english ch02_ahouse02_36dd714f:

    a "Damn, these heavy boobs are making my shoulders ache."

translate english ch02_ahouse02_e552adbd:

    a "(( What are they even this big for... ))"

translate english ch02_ahouse02_0cb87cee:

    n "She lifted her large breasts."

translate english ch02_ahouse02_2a8ea727:

    n "As the drowsy freshness after the shower eased the weight she had felt from her chest,"

translate english ch02_ahouse02_0f6263bf:

    n "she felt a small, subtle pleasure."

translate english ch02_ahouse02_a24d63fd:

    a "Ah......."

translate english ch02_ahouse02_da7b62ba:

    a "I should’ve worn a bra today."

translate english ch02_ahouse02_c29c0a96:

    a "I tried to dress up for nothing, and now my shoulders just hurt."

translate english ch02_ahouse02_bb920e29:

    d "!!!!!!!"

translate english ch02_ahouse02_444c7380:

    d "Ah, you startled me."

translate english ch02_ahouse02_20e1f764:

    d "What are you doing there, Amanda?"

translate english ch02_ahouse02_f32014a2:

    a "I’m wearing the slip I usually sleep in, and I felt a little embarrassed, haha."

translate english ch02_ahouse02_32574ceb:

    d "Ha, is that why you’re hiding there?"

translate english ch02_ahouse02_83acd77d:

    d "There’s nothing to be embarrassed about between us. Come out already."

translate english ch02_ahouse02_2c9eb809:

    a "Alright then."

translate english ch02_ahouse02_8d279401:

    a "No teasing or nagging, okay? Got it?"

translate english ch02_ahouse02_1059562a:

    d "Got it. I promise."

translate english ch02_ahouse02_d9615a18:

    d "As if I’d nag you about your paja—"

translate english ch02_ahouse02_f6b90bd0:

    d "!!!!!!!!!!!!!!!!!!!"

translate english ch02_ahouse02_ad406586:

    a "What? Why? Hehe."

translate english ch02_ahouse02_a34d072d:

    a "Is it too bold?"

translate english ch02_ahouse02_69c9c3d7:

    a "No, I’ve worn even more revealing things before, hehe."

translate english ch02_ahouse02_7c0a9214:

    d ".............."

translate english ch02_ahouse02_9575f3b7:

    d "N-no."

translate english ch02_ahouse02_738537f1:

    d "You look very sexy, Amanda."

translate english ch02_ahouse02_410cb3b1:

    a "Sexy? Hahaha."

translate english ch02_ahouse02_a4108efb:

    a "Then I’d say it’s a success, hehe."

translate english ch02_ahouse02_f05557de:

    a "(( I’m sexier than that Olivia. ))"

translate english ch02_ahouse02_b6392490:

    a "(( She just shows off. She could never match the kind of natural sexiness I have. ))"

translate english ch02_ahouse02_4d0eca94:

    a "But why are you only wearing your underwear?"

translate english ch02_ahouse02_ff3ad953:

    a "That’s why Frank gets mad when you walk around like that at home, haha."

translate english ch02_ahouse02_a435953e:

    a "(( But... ))"

translate english ch02_ahouse02_622178bc:

    a "(( Frank gets mad because of you, Amanda. Hehe. ))"

translate english ch02_ahouse02_d1a3ad1c:

    a "(( So what? If the homeowner wants to dress comfortably, who can say anything? ))"

translate english ch02_ahouse02_89887c2e:

    a "(( It’s my freedom whether I walk around naked or put on a strip show, hahaha. ))"

translate english ch02_ahouse02_4b814f6e:

    a "Wait. I’ll grab some snacks."

translate english ch02_ahouse02_a7e14b3d:

    d "O-okay."

translate english ch02_ahouse02_0a23a1d1:

    d "(( .... ))"

translate english ch02_ahouse02_8b731b59:

    d "(( Damn, look at that ass... ))"

translate english ch02_ahouse02_7d79fa40:

    d "(( I didn’t realize Amanda’s figure was that beautiful... ))"

translate english ch02_ahouse02_48cb01c7:

    d "(( Oh my God..... ))"

translate english ch02_ahouse02_06b3964a:

    d "(( ........... ))"

translate english ch02_ahouse02_3d5f8c67:

    n "In truth, [d_name] had seen Amanda naked before while living with her."

translate english ch02_ahouse02_b39b9222:

    n "But now, the air between them felt different."

translate english ch02_ahouse02_d97b39e3:

    n "The memory of being abandoned by his birth mother had created an obsessive need to be acknowledged by Amanda."

translate english ch02_ahouse02_b603e756:

    n "And he began to develop a twisted thought—that the way to earn her recognition was to prove his masculinity, to show he was a man she could rely on."

translate english ch02_ahouse02_66b95d86:

    n "He wanted to become a man she could depend on."

translate english ch02_ahouse02_2f782393:

    n "A man she could lean on emotionally."

translate english ch02_ahouse02_177b3c6f:

    n "A man she could rely on physically."

translate english ch02_ahouse02_2c4ca137:

    n "He wanted to make her happy."

translate english ch02_ahouse02_0c2d61f9:

    a "Alright, ready. Hehe."

translate english ch02_ahouse02_5297e33a:

    a "Tonight’s movie is a romantic comedy I like."

translate english ch02_ahouse02_f9073d1c:

    a "My friend recommended it as a good movie to watch without thinking too much."

translate english ch02_ahouse02_1388a671:

    a "This feels like the perfect time for that kind of movie."

translate english ch02_ahouse02_0296d783:

    d "I like it too, hehe."

translate english ch02_ahouse02_7869f19a:

    d "(( Huh?? ))"

translate english ch02_ahouse02_9ff61029:

    d "“My Pen Is Huge?”"

translate english ch02_ahouse02_2c7bf6d9:

    d "(( Is that really the title of a romantic comedy? ))"

translate english ch02_ahouse02_6f812d89:

    d "(( .......... ))"

translate english ch02_ahouse02_c7680872:

    a "Hahahahahahaha."

translate english ch02_ahouse02_16565ceb:

    d "I knew that guy would do something like that."

translate english ch02_ahouse02_706d7911:

    a "He just flipped the whole table like that?"

translate english ch02_ahouse02_e513fc8a:

    d "Hahahahaha."

translate english ch02_ahouse02_887b9991:

    a "He’s the worst kind of guy, haha."

translate english ch02_ahouse02_405e2f21:

    a "If you act like that, you’ll get dumped by women, [d_name]."

translate english ch02_ahouse02_3d9f4160:

    a "Remember this: whether young or older, women like gentlemen."

translate english ch02_ahouse02_1af8458b:

    a "Only a tiny minority like bad boys."

translate english ch02_ahouse02_6d6d605b:

    d "Why are you talking about me? I wouldn’t act that strangely."

translate english ch02_ahouse02_b60c0ce0:

    d "And I was born a gentleman, haha."

translate english ch02_ahouse02_3da2b6df:

    a "Oh really? Hahaha."

translate english ch02_ahouse02_6a21657e:

    d "..............."

translate english ch02_ahouse02_ecf048e0:

    d "(( Damn.... ))"

translate english ch02_ahouse02_571e950c:

    d "(( She seems especially flushed tonight.. ))"

translate english ch02_ahouse02_d58ae727:

    d "(( Is it the wine?? ))"

translate english ch02_ahouse02_27d4c53e:

    d "(( Hmm..... ))"

translate english ch02_ahouse02_7282bf49:

    d "(( Her body temperature feels warm.. ))"

translate english ch02_ahouse02_65301e8e:

    d "(( Is it the wine? I can feel her blood pumping. ))"

translate english ch02_ahouse02_5d295332_1:

    a "Honey."

translate english ch02_ahouse02_8096b08a:

    d "Yes?"

translate english ch02_ahouse02_75d78ccd:

    a "Let’s change positions."

translate english ch02_ahouse02_0cdb73a3:

    a "I’ll lean on you."

translate english ch02_ahouse02_42090614:

    a "My back’s starting to hurt from sitting like this."

translate english ch02_ahouse02_4fcaa50b:

    a "You’re a fine young man now, so you should hold a lady, hehe."

translate english ch02_ahouse02_6f3e1287:

    d "Oh, sure!"

translate english ch02_ahouse02_c747389b:

    d "Come into the arms of this gentleman, haha."

translate english ch02_ahouse02_3f83b36d:

    n "They pressed their bodies close together."

translate english ch02_ahouse02_f0f28ff8:

    n "Without the slightest hesitation, she let her full weight rest on him."

translate english ch02_ahouse02_e5dcfbcf:

    d "(( Her shampoo smells so fresh. ))"

translate english ch02_ahouse02_56c42331:

    d "(( Damn. Her skin is so soft. ))"

translate english ch02_ahouse02_1a6f5aac:

    a "(( !!!!!!!!!!! ))"

translate english ch02_ahouse02_feb47d4f:

    a "What are you doing?"

translate english ch02_ahouse02_31431624:

    a "Don’t you think your hand is in the wrong place?"

translate english ch02_ahouse02_d0fbc5df:

    d "Hehe. Your skin is so soft, Amanda, I ended up stroking it without realizing."

translate english ch02_ahouse02_843a5a5e:

    a "Haha. What? That’s no different from the guy in that movie just now."

translate english ch02_ahouse02_f1008634:

    d "(( Damn. ))"

translate english ch02_ahouse02_d409f179:

    d "(( This is driving me crazy. Her breasts are so soft. ))"

translate english ch02_ahouse02_940e3247:

    d "(( It’s like silk. ))"

translate english ch02_ahouse02_188581f8:

    d "(( What should I do? ))"

translate english ch02_ahouse02_92f21ed5:

    n "What should I do?"

translate english ch02_ahouse02_efb6f69e:

    d "(( Damn. I can’t help it. ))"

translate english ch02_ahouse02_d1bcf42b:

    d "(( It’s just a sign of affection. ))"

translate english ch02_ahouse02_8db47039:

    d "(( She was the one who wanted to sit this close. ))"

translate english ch02_ahouse02_35b4464d:

    a "(( !!!!!!!!!!!!!!!!!!!!! ))"

translate english ch02_ahouse02_51eac91f:

    d "(( Damn… it’s really soft. ))"

translate english ch02_ahouse02_5562a3ba:

    a "(( ................. ))"

translate english ch02_ahouse02_f6503417:

    d "(( Let’s not ruin Amanda’s mood for no reason.... ))"

translate english ch02_ahouse02_80c14fb3:

    d "(( We just met after a while. I shouldn’t do anything weird too.. ))"

translate english ch02_ahouse02_dd8b7b46:

    a "I’m going to have a banana. Want one?"

translate english ch02_ahouse02_45d1445f:

    d "I’m fine."

translate english ch02_ahouse02_da1b4b57:

    a "Alright."

translate english ch02_ahouse02_5b65d6a8:

    d "(( Cough... ))"

translate english ch02_ahouse02_637734fc:

    d "(( ..... ))"

translate english ch02_ahouse02_33999bba:

    d "(( ........ ))"

translate english ch02_ahouse02_7ac8ed36:

    d "(( .................. ))"

translate english ch02_ahouse02_4f48da8a:

    d "(( Oh my God................ ))"

translate english ch02_ahouse02_418e5e46:

    a "Hehe."

translate english ch02_ahouse02_f0f490a3:

    d "(( Shit!! ))"

translate english ch02_ahouse02_516489fa:

    d "Ha, Amanda… please…"

translate english ch02_ahouse02_8cd05177:

    a "Hahahaha. Okay, okay."

translate english ch02_ahouse02_5c7c72b1:

    a "I won’t tease you."

translate english ch02_ahouse02_d5243d06:

    a "The banana just looked so good, I couldn’t help it, haha."

translate english ch02_ahouse02_3ecd6b26:

    a "I was licking the outside first to savor it."

translate english ch02_ahouse02_6a0b2e15:

    n "His dick remained hard."

translate english ch02_ahouse02_4bbb4743:

    n "And it was positioned precisely between Amanda’s buttocks."

translate english ch02_ahouse02_9311f39b:

    d "(( Damn… here we go again. ))"

translate english ch02_ahouse02_9a7759e9:

    d "(( It feels like it’s going to burst.... ))"

translate english ch02_ahouse02_a4f51b51:

    d "(( Why is she teasing me like this? ))"

translate english ch02_ahouse02_d38d8da7:

    d "(( Isn’t she worried about how I might react? ))"

translate english ch02_ahouse02_fb9d459e:

    d "Haha, are you trying to provoke me right now?"

translate english ch02_ahouse02_cc83fb17:

    d "Don’t you know every action has consequences?"

translate english ch02_ahouse02_86f4a8a0:

    a "What? Consequences?"

translate english ch02_ahouse02_d32631ea:

    a "I have to pay a price just for eating a banana?"

translate english ch02_ahouse02_92f21ed5_1:

    n "What should I do?"

translate english ch02_ahouse02_4e6c3b4a:

    d "Then how about this?"

translate english ch02_ahouse02_4bace820:

    a "What??"

translate english ch02_ahouse02_3350b588:

    a "!!!!!!!!!!!!!!!"

translate english ch02_ahouse02_e3a9205f:

    a "(( .................. ))"

translate english ch02_ahouse02_e39b8127:

    a "What are you doing?"

translate english ch02_ahouse02_5daad653:

    a "Do you want to get kicked out of this house?"

translate english ch02_ahouse02_a797f6ce:

    d "............."

translate english ch02_ahouse02_9d9f50c7:

    a "And is that all you call a consequence? I’m disappointed."

translate english ch02_ahouse02_ca445403:

    a "And at least make it subtle like I do. That was way too direct."

translate english ch02_ahouse02_c7429b70:

    a "Remember this. If you do it like that, you’re not handling a woman—you’re gambling."

translate english ch02_ahouse02_ff7404d3:

    d "Oh really?"

translate english ch02_ahouse02_4e6c3b4a_1:

    d "Then how about this?"

translate english ch02_ahouse02_dbdab605:

    a "What?"

translate english ch02_ahouse02_92f21ed5_2:

    n "What should I do?"

translate english ch02_ahouse02_9b0b4e54:

    a "!!!!!!!!!!!"

translate english ch02_ahouse02_023f5bbc:

    a "(( Ah!!.. ))"

translate english ch02_ahouse02_6c236861:

    a "(( Ahng.. ))"

translate english ch02_ahouse02_964ef157:

    a "(( Ahng... ))"

translate english ch02_ahouse02_43b42801:

    a "What are you doing, honey?"

translate english ch02_ahouse02_e6526cf4:

    a "Don’t you think that crossed the line a bit?"

translate english ch02_ahouse02_8a827314:

    d "You started teasing me first, haha."

translate english ch02_ahouse02_72146f4e:

    d "I was just trying to balance things out."

translate english ch02_ahouse02_bdeefa62:

    a "Balance… ha.."

translate english ch02_ahouse02_bbe55b5e:

    a "That went way too far."

translate english ch02_ahouse02_95651a31:

    a "You little pervert."

translate english ch02_ahouse02_fac8215b:

    d "............"

translate english ch02_ahouse02_ba0bf4a0:

    d "I love you, Amanda."

translate english ch02_ahouse02_21faec74:

    a "Don’t try to dodge it."

translate english ch02_ahouse02_71acc438:

    a "You shouldn’t tease a woman like that."

translate english ch02_ahouse02_6e5ee28f:

    a "It’s fine now because the mood is good, but that was close."

translate english ch02_ahouse02_f8dd4687:

    a "..............."

translate english ch02_ahouse02_350abf36:

    a "(( Huh! Was this an adult-rated movie.. ))"

translate english ch02_ahouse02_156400fd:

    a "(( The timing is kind of embarrassing.. ))"

translate english ch02_ahouse02_5920ff9d:

    a "(( What kind of movie is this? ))"

translate english ch02_ahouse02_df1a1c82:

    a "(( It’s not even an indie art film and they’re showing their genitals?! ))"

translate english ch02_ahouse02_9333a8d8:

    a "(( Did Amanda know?? ))"

translate english ch02_ahouse02_b00ad13b:

    a "............."

translate english ch02_ahouse02_e5b21689:

    a "Come here."

translate english ch02_ahouse02_8882635b:

    a "I wish time would stop right now. I’m so happy."

translate english ch02_ahouse02_33dd0fc6:

    a "Aren’t you?"

translate english ch02_ahouse02_94e1abfb:

    a "Mwah~"

translate english ch02_ahouse02_3f928c33:

    d "(( Damn it. My dick's gonna explode. ))"

translate english ch02_ahouse02_9f8ac810:

    d "(( Her butt is pressing down on it. I think I need to adjust it… ))"

translate english ch02_ahouse02_b942d6e0:

    d "(( Damn! That means I’d have to put my hand in. ))"

translate english ch02_ahouse02_3dbc3c5a:

    d "(( Is it going to snap at this rate?!!! ))"

translate english ch02_ahouse02_90fc4874:

    d "(( Damn it, Amanda... ))"

translate english ch02_ahouse02_394421b2:

    d "(( You’re torturing me right now. ))"

translate english ch02_ahouse02_f64618d8:

    a "What’s wrong, honey?"

translate english ch02_ahouse02_1bd24b6f:

    a "Are you okay?"

translate english ch02_ahouse02_bbcf0e66:

    d "Ah, yes… I’m fine.."

translate english ch02_ahouse02_c0df6564:

    d "I think I got a cramp from sitting in one position too long."

translate english ch02_ahouse02_ef327d11:

    a "Oh, I see."

translate english ch02_ahouse02_f11965b6:

    a "Ahh~"

translate english ch02_ahouse02_1c51f180:

    a "I feel a little tipsy and pleasantly drowsy. It feels nice."

translate english ch02_ahouse02_881e8211:

    a "Was the movie good?"

translate english ch02_ahouse02_6d1d98a8:

    d "Yes. It was fun, hehe."

translate english ch02_ahouse02_1c197329:

    d "I was a little surprised when it got pretty explicit at the end—but considering the title, I guess that makes sense, haha."

translate english ch02_ahouse02_9277b690:

    a "Haha."

translate english ch02_ahouse02_c50da5ac:

    a "But it wasn’t exactly big enough to deserve a title like that, was it? Hehe."

translate english ch02_ahouse02_d5db5f84:

    a "Time feels like it’s flying by."

translate english ch02_ahouse02_33dea7db:

    a "It’s already bedtime."

translate english ch02_ahouse02_f37e177a:

    a "It’s a shame, but give me a goodnight kiss now."

translate english ch02_ahouse02_5fa0f058:

    n "With Frank gone, the house felt free..."

translate english ch02_ahouse02_e6683da7:

    n "Their physical intimacy was growing bolder."

translate english ch02_ahouse02_41d89fe5:

    n "And this time, without either of them making the first move, their lips met as if drawn together by magnets."

translate english ch02_ahouse02_418e5e46_1:

    a "Hehe."

translate english ch02_ahouse02_99e42be6:

    a "Is a kiss on the lips your idea of a goodnight kiss?"

translate english ch02_ahouse02_a7c8231a:

    a "Mmm.... I feel drowsy."

translate english ch02_ahouse02_e2d6b4a6:

    a "The wine is making me sleepy."

translate english ch02_ahouse02_a60ebd0e:

    a "You must be tired too, so go upstairs and sleep."

translate english ch02_ahouse02_38404df8:

    a "I think I’ll pass out the moment I hit the bed."

translate english ch02_ahouse02_b0e17700:

    a "See you in the morning~"

translate english ch02_ahouse02_962adbe4:

    d "Good night, Amanda."

translate english ch02_ahouse03_f52c21d7:

    d "Ah, this feels comfortable...."

translate english ch02_ahouse03_e772399f:

    d "No matter what, my room really is the best."

translate english ch02_ahouse03_2483e1e7:

    d "Without Frank here, this feels like heaven."

translate english ch02_ahouse03_f4e8b44d:

    n "He remembered the woman he had seen with Frank earlier that day."

translate english ch02_ahouse03_32c88ee4:

    n "He had wanted to tell Amanda all along, but he didn’t want to ruin their good time together."

translate english ch02_ahouse03_a295037f:

    d "Ha.... I think Frank’s up to something suspicious.."

translate english ch02_ahouse03_89828719:

    d "Does Amanda know?"

translate english ch02_ahouse03_986f67aa:

    d "If it’s her, she’s probably already sensed something."

translate english ch02_ahouse03_223637e5:

    d "That Frank is doing something shady."

translate english ch02_ahouse03_2954a802:

    d "Ha.........."

translate english ch02_ahouse03_1e659cdc:

    d "Damn it."

translate english ch02_ahouse03_c144edab:

    d "Amanda deserves so much better."

translate english ch02_ahouse03_a7d5053e:

    d "She’s not a woman who should devote herself to someone like Frank."

translate english ch02_ahouse03_6a21657e:

    d "..............."

translate english ch02_ahouse03_f2fa4a91:

    d "If it weren’t for Amanda, this house would’ve fallen apart long ago."

translate english ch02_ahouse03_da6035cd:

    d "Ha.................."

translate english ch02_ahouse03_8fba4944:

    d "Damn Frank. What kind of trouble is he planning this time?"

translate english ch02_ahouse03_c23b653c:

    d "Is there still more ways for him to hurt Amanda?"

translate english ch02_ahouse03_ca025090:

    d "I have to do it."

translate english ch02_ahouse03_a35728b0:

    d "I have to take care of Amanda."

translate english ch02_ahouse03_9d000991:

    n "He created his own justification that he needed to take care of Amanda in Frank’s place."

translate english ch02_ahouse03_81a234d1:

    n "But that wasn’t the only reason he was going to her."

translate english ch02_ahouse03_34ddfcd7:

    n "With Frank gone, he wanted to imprint his masculinity—his existence—on Amanda."

translate english ch02_ahouse03_75c4ec64:

    n "And"

translate english ch02_ahouse03_24a95219:

    n "he wanted to feel again the warmth and scent of Amanda when she had been in his arms."

translate english ch02_ahouse03_f69a7c0e:

    d "................"

translate english ch02_ahouse03_779969ec:

    d "(( Damn. Look at her curves... ))"

translate english ch02_ahouse03_92f21ed5:

    n "What should I do?"

translate english ch02_ahouse03_07750947:

    a "!!"

translate english ch02_ahouse03_c9bfaf97:

    a "What? What are you doing here?"

translate english ch02_ahouse03_1a1859d8:

    a "I thought I was the one who drank the wine, mister?"

translate english ch02_ahouse03_792b164c:

    d "Hehe."

translate english ch02_ahouse03_7c741c94:

    d "I didn’t want Amanda to sleep alone feeling lonely."

translate english ch02_ahouse03_2df8224e:

    a "Wow... where did you learn lines like that?"

translate english ch02_ahouse03_7dedb05c:

    a "I’m so touched I could almost cry."

translate english ch02_ahouse03_792b164c_1:

    d "Hehe."

translate english ch02_ahouse03_e55915f2:

    a "Why is your body so cold?"

translate english ch02_ahouse03_7f716a94:

    d "No."

translate english ch02_ahouse03_df8eebc4:

    d "I think your body feels hot right now, Amanda."

translate english ch02_ahouse03_fd2a6683:

    a "Well, I did drink wine."

translate english ch02_ahouse03_4487107c:

    d "Haha. Then please share some of your warmth with me."

translate english ch02_ahouse03_ac914009:

    a "What? What do you mean by that?"

translate english ch02_ahouse03_0a5e42cd:

    a "How are you going to “share warmth”?"

translate english ch02_ahouse03_4179968f:

    d "Uh........."

translate english ch02_ahouse03_adeba868:

    d "If we sleep holding each other tight, won’t our body temperatures even out?"

translate english ch02_ahouse03_405390a8:

    a "Hehe. I see."

translate english ch02_ahouse03_ad9c6493:

    a "Isn’t there a faster way?"

translate english ch02_ahouse03_866b6de3:

    d "So you’re saying there’s another way besides just hugging?"

translate english ch02_ahouse03_178eddd0:

    a "What? Are you seriously asking?"

translate english ch02_ahouse03_1a91e0a8:

    a "Ha! You almost fooled me."

translate english ch02_ahouse03_4432cc45:

    a "Oh! So studying psychology’s made you pretty quick with comebacks now, huh?"

translate english ch02_ahouse03_d270e0cf:

    d "What? I honestly have no idea what you’re talking about."

translate english ch02_ahouse03_51fe5fb8:

    a "Alright, alright. Let’s say that’s true, haha."

translate english ch02_ahouse03_0c645dea:

    a "You sly boy."

translate english ch02_ahouse03_59ef63d8:

    a "..................."

translate english ch02_ahouse03_bcecb754:

    a ".........."

translate english ch02_ahouse03_dc58be7d:

    a "Honey...."

translate english ch02_ahouse03_f68b1118:

    d "Yes, I’m right here."

translate english ch02_ahouse03_bcecb754_1:

    a ".........."

translate english ch02_ahouse03_891c17bd:

    a "You..."

translate english ch02_ahouse03_b6573f86:

    a "How did you spend that year away at college?"

translate english ch02_ahouse03_b7de7a0b:

    a ".................."

translate english ch02_ahouse03_9bf4f3ab:

    a "Weren’t you lonely?"

translate english ch02_ahouse03_5e3aec4e:

    d ".........."

translate english ch02_ahouse03_972897ff:

    d "Well.. I..."

translate english ch02_ahouse03_3ec32a9d:

    d "I wasn’t lonely. I had Jason.."

translate english ch02_ahouse03_30b4861a:

    d "You know how noisy and lively college is."

translate english ch02_ahouse03_bcecb754_2:

    a ".........."

translate english ch02_ahouse03_a4823b8f:

    a "Didn’t you miss me?"

translate english ch02_ahouse03_0223f37d:

    d "Of course I missed you."

translate english ch02_ahouse03_1631776c:

    d "I thought about you every night before I went to sleep."

translate english ch02_ahouse03_bcecb754_3:

    a ".........."

translate english ch02_ahouse03_633ad26e:

    a "Really?"

translate english ch02_ahouse03_beb89374:

    d "Of course."

translate english ch02_ahouse03_bcecb754_4:

    a ".........."

translate english ch02_ahouse03_7125c7b1:

    a "Sniff.."

translate english ch02_ahouse03_f8312f74:

    d "(( !!!! ))"

translate english ch02_ahouse03_5e3aec4e_1:

    d ".........."

translate english ch02_ahouse03_f87ca0a8:

    d "Ah.. Amanda.. are you crying? What’s wrong?"

translate english ch02_ahouse03_8b0645f1:

    d "Did something happen?"

translate english ch02_ahouse03_7125c7b1_1:

    a "Sniff.."

translate english ch02_ahouse03_ac48d631:

    a "Ha........"

translate english ch02_ahouse03_15a541da:

    a "I don’t know.."

translate english ch02_ahouse03_d5d5cbee:

    a "Maybe I’m going through menopause or something. I feel like I’ve been crying more lately."

translate english ch02_ahouse03_5e3aec4e_2:

    d ".........."

translate english ch02_ahouse03_90ac0fb4:

    d "Is something going on?"

translate english ch02_ahouse03_f6c37117:

    d "There is, right?"

translate english ch02_ahouse03_3c454118:

    d "Tell me. What’s the problem?"

translate english ch02_ahouse03_66c40133:

    a "Ha.........."

translate english ch02_ahouse03_54bb1af2:

    a "You see.."

translate english ch02_ahouse03_10aed208:

    a "...................."

translate english ch02_ahouse03_b182b61b:

    a "Frank’s been acting strange lately."

translate english ch02_ahouse03_ae682137:

    d "(( !!! ))"

translate english ch02_ahouse03_eabc3ebe:

    d "(( Damn. I knew it. ))"

translate english ch02_ahouse03_22ef2d0a:

    d "(( Someone as sharp as Amanda wouldn’t miss it. ))"

translate english ch02_ahouse03_a916cf17:

    d "(( Should I tell her I saw Frank earlier today? ))"

translate english ch02_ahouse03_61a188c0:

    d "(( No, let’s hear her out first. ))"

translate english ch02_ahouse03_5bdb0c86:

    d "What do you mean by strange?"

translate english ch02_ahouse03_bcecb754_5:

    a ".........."

translate english ch02_ahouse03_eda3e723:

    a "I’m sorry. I shouldn’t have said that."

translate english ch02_ahouse03_bac22a20:

    a "It has nothing to do with you.."

translate english ch02_ahouse03_1d31906f:

    d "(( ................. ))"

translate english ch02_ahouse03_c3956351:

    d "Amanda."

translate english ch02_ahouse03_88b06e80:

    a "Yes, honey?"

translate english ch02_ahouse03_7d2cff5c:

    d "I love you."

translate english ch02_ahouse03_34c878fa:

    d "You’re the person I love most in this world."

translate english ch02_ahouse03_9294c7f7:

    d "I’ll stay by your side forever."

translate english ch02_ahouse03_d1ae9eef:

    d "I’m going to marry you and live with you."

translate english ch02_ahouse03_672ef141:

    a "Marry me? Hehe."

translate english ch02_ahouse03_9c066eb7:

    a "I’m really, really touched, honey."

translate english ch02_ahouse03_55c02367:

    a "......."

translate english ch02_ahouse03_d9572f93:

    a "I love you, honey."

translate english ch02_ahouse03_9907cd8a:

    a "(( But..... ))"

translate english ch02_ahouse03_c3261ec6:

    a "(( What is this? ))"

translate english ch02_ahouse03_294ba109:

    a "(( Is that his dick? ))"

translate english ch02_ahouse03_4b1c189e:

    a "(( Oh my God!! ))"

translate english ch02_ahouse03_e1c0e7f8:

    a "(( I should’ve worn underwear. ))"

translate english ch02_ahouse03_226bd2f4:

    a "(( Mm... ))"

translate english ch02_ahouse03_4797b9aa:

    a "(( Really? He was hard the whole time during the movie and now again? ))"

translate english ch02_ahouse03_7b4bb4b8:

    a "(( Wow. His girlfriend must’ve had a hard time with that. ))"

translate english ch02_ahouse03_108e6ec4:

    a "(( ........... ))"

translate english ch02_ahouse03_21fb8bf9:

    a "(( Oh my God. ))"

translate english ch02_ahouse03_da590e69:

    a "(( This is a little confusing.. ))"

translate english ch02_ahouse03_5c9d4960:

    a "(( Ha...... ))"

translate english ch02_ahouse03_8828a194:

    a "(( Should I get up and put something on? ))"

translate english ch02_ahouse03_b4f456df:

    a "(( No, no.. he might think that’s strange. It could make things more awkward. ))"

translate english ch02_ahouse03_432c81d2:

    a "(( It feels so warm and pleasant right now... ))"

translate english ch02_ahouse03_c368e938:

    a "(( .............. ))"

translate english ch02_ahouse03_a9dd8a41:

    a "(( !!!!!!!! ))"

translate english ch02_ahouse03_b8425d43:

    a "(( Nope! This is too much. ))"

translate english ch02_ahouse03_0ac848ea:

    a "(( At this rate, he might lose control, haha. ))"

translate english ch02_ahouse03_053b57e6:

    a "Hey! What are you doing?"

translate english ch02_ahouse03_6b21dab0:

    a "Are you trying to share your body heat with me? Haha."

translate english ch02_ahouse03_e8dda7df:

    a "You’ve shared enough. It’s getting hot, so maybe we should move apart a little, honey."

translate english ch02_ahouse03_657d84eb:

    a "What are you doing?"

translate english ch02_ahouse03_edbb7d05:

    d "........"

translate english ch02_ahouse03_ba0bf4a0:

    d "I love you, Amanda."

translate english ch02_ahouse03_af6f7210:

    d "I mean it."

translate english ch02_ahouse03_7cff0fa4:

    d "I’ll always be by your side."

translate english ch02_ahouse03_5d295332:

    a "Honey."

translate english ch02_ahouse03_c657606f:

    a "If Frank sees us, he’ll kill us both."

translate english ch02_ahouse03_7eb58b27:

    d "I don’t care."

translate english ch02_ahouse03_3101fde3:

    d "I’ll protect you. I’m a healthy adult now."

translate english ch02_ahouse03_b21b37a1:

    a "I know. Hehe."

translate english ch02_ahouse03_3b7053bf:

    a "[d_name] is my brave prince now."

translate english ch02_ahouse03_aac863d5:

    d "Then Amanda is my queen, hehe."

translate english ch02_ahouse03_9f844833:

    a "Oh really? Then make your queen even more moved."

translate english ch02_ahouse03_2f9ee1ed:

    a "Queens tend to sulk easily."

translate english ch02_ahouse03_229d0b4d:

    d "Then come here, hehe."

translate english ch02_ahouse03_da4c9385:

    a "Ha......"

translate english ch02_ahouse03_7881cafe:

    d "Ah.. your skin is so soft."

translate english ch02_ahouse03_92af87b3:

    d "And you smell wonderful."

translate english ch02_ahouse03_97cf5621:

    a "Hehe, really?"

translate english ch02_ahouse03_59604247:

    d "Yes. It feels like I’m holding a lilac tree."

translate english ch02_ahouse03_c11e1b6a:

    a "A lilac tree?"

translate english ch02_ahouse03_ff1e2da4:

    a "I’ve never heard such a poetic expression, hehe."

translate english ch02_ahouse03_670379dc:

    a "Ah....."

translate english ch02_ahouse03_601a4f6e:

    a "It’s so cozy."

translate english ch02_ahouse03_2fa6c6bd:

    a "Watching a movie and drinking wine with you..."

translate english ch02_ahouse03_a334b6e7:

    a "And being able to sleep in the same bed like this.."

translate english ch02_ahouse03_b0d9783c:

    a "Ah... how happy would I be if every day were like this? Hehe."

translate english ch02_ahouse03_4e0d8344:

    n "For a moment, they looked at each other in silence."

translate english ch02_ahouse03_7b1f1d75:

    n "In her eyes, [d_name] had become a dependable man she barely recognized."

translate english ch02_ahouse03_5be54be0:

    n "In his eyes, Amanda was an attractive woman."

translate english ch02_ahouse03_632635a4:

    n "And both of them felt that this was a turning point in their relationship."

translate english ch02_ahouse03_967f95c1:

    n "It came to them as both excitement and fear."

translate english ch02_ahouse03_d561aa8b:

    d "Why are you looking at me like that without saying anything?"

translate english ch02_ahouse03_f252f3b3:

    d "Did I do something wrong again?"

translate english ch02_ahouse03_50d5ba97:

    a "No, no. You didn’t do anything wrong, honey."

translate english ch02_ahouse03_063df9fc:

    a "I just wanted this moment to last forever, so my mind went blank for a second."

translate english ch02_ahouse03_b104ace7:

    a "I wonder when we’ll have time like this again..."

translate english ch02_ahouse03_59ef63d8_1:

    a "..................."

translate english ch02_ahouse03_027c17fb:

    a "Honey?"

translate english ch02_ahouse03_8096b08a:

    d "Yes?"

translate english ch02_ahouse03_59ef63d8_2:

    a "..................."

translate english ch02_ahouse03_9ec93def:

    a "Give your queen a goodnight kiss."

translate english ch02_ahouse03_f1008634:

    d "(( Damn. ))"

translate english ch02_ahouse03_2dfbad56:

    n "The moment his tongue touched Amanda’s lips, she ended the kiss."

translate english ch02_ahouse03_1ed229fe:

    n "Whether the timing was coincidence or intentional on her part was unclear."

translate english ch02_ahouse03_b2b821d1:

    a "........."

translate english ch02_ahouse03_20fc8b8b:

    a "Let’s go to sleep with good feelings."

translate english ch02_ahouse03_909cf01a:

    a "Naughty boy......."

translate english ch02_ahouse03_276f83c7:

    d "Oh really? Then I’ll give Amanda a new nickname too."

translate english ch02_ahouse03_c0222b57:

    a "Oh really?"

translate english ch02_ahouse03_b0777ab0:

    a "Use what you learned in psychology this past year and come up with one for me."

translate english ch02_ahouse03_bbd66bc0:

    d "Hehe. Alright."

translate english ch02_ahouse03_dcf72f38:

    d "Amanda is..."

translate english ch02_ahouse03_d9ab2bfa:

    d "Amanda is an ass slapper."

translate english ch02_ahouse03_dbdab605:

    a "What?"

translate english ch02_ahouse03_c3605823:

    a "An ass slapper? Hahaha… do you want to get your ass slapped too?"

translate english ch02_ahouse03_f6ca111e:

    d "Amanda is a banana sucker."

translate english ch02_ahouse03_dbdab605_1:

    a "What?"

translate english ch02_ahouse03_383a1bcc:

    a "Banana sucker? Hahaha..."

translate english ch02_ahouse03_f255a845:

    d "Amanda is an exhibitionist."

translate english ch02_ahouse03_dbdab605_2:

    a "What?"

translate english ch02_ahouse03_7feb4960:

    a "An exhibitionist..... hmm..."

translate english ch02_ahouse03_dffbc397:

    d "Amanda is a sexy MILF."

translate english ch02_ahouse03_dbdab605_3:

    a "What?"

translate english ch02_ahouse03_d35d28bf:

    a "A sexy MILF..... hmm..."

translate english ch02_ahouse03_8189bbc1:

    d "Amanda is a naughty MILF."

translate english ch02_ahouse03_dbdab605_4:

    a "What?"

translate english ch02_ahouse03_23d23e95:

    a "A naughty MILF..... hmm..."

translate english ch02_ahouse03_8ddc62ee:

    d "Amanda is a bombshell."

translate english ch02_ahouse03_dbdab605_5:

    a "What?"

translate english ch02_ahouse03_cabfc687:

    a "A bombshell? Hahaha..."

translate english ch02_ahouse03_1e3a54cc:

    d "Amanda is a juicy melon."

translate english ch02_ahouse03_dbdab605_6:

    a "What?"

translate english ch02_ahouse03_dfbb8f75:

    a "Oh my God, what? Juicy melon? Hahaha..."

translate english ch02_ahouse03_a49f017e:

    a "Ha! Compared to “naughty boy,” that’s practically a compliment."

translate english ch02_ahouse03_339254e1:

    a "Fine, then I’ll come up with another nickname for you and text it to you."

translate english ch02_ahouse03_45bf87dd:

    a "Now let’s sleep......."

translate english ch02_ahouse04_c184d2ea:

    f "You little shit...."

translate english ch02_ahouse04_9b9eec7b:

    f "You take my place while I’m gone?!!"

translate english ch02_ahouse04_c8700e30:

    f "You ungrateful son of bitch!! Repaying kindness with betrayal?!!"

translate english ch02_ahouse04_f011acbc:

    f "Testing the limits of my patience?!!"

translate english ch02_ahouse04_5a7e9c64:

    f "Where’s Amanda?!!!!!"

translate english ch02_ahouse04_8395d3d5:

    f "Nothing’s going right these days—this world is driving me crazy!!!"

translate english ch02_ahouse04_5e79f6d2:

    f "You worthless brat!!"

translate english ch02_ahouse04_739fa947:

    d "(( What the fuck!! ))"

translate english ch02_ahouse04_521f100c:

    d "(( Ha....... ))"

translate english ch02_ahouse04_d3a14061:

    d "(( It was a dream. ))"

translate english ch02_ahouse04_64d773d0:

    d "(( Was it really a dream? ))"

translate english ch02_ahouse04_e1c3db47:

    d "(( ............... ))"

translate english ch02_ahouse04_cf8d7a42:

    d "(( Ha..... what a ridiculous dream. ))"

translate english ch02_ahouse04_50defe58:

    d "(( Yeah.. ))"

translate english ch02_ahouse04_788f4882:

    d "(( I survived another day and woke up to a new morning. ))"

translate english ch02_ahouse04_a179de0a:

    d "(( Huh? ))"

translate english ch02_ahouse04_59e77076:

    d "(( Damn... ))"

translate english ch02_ahouse04_ac9b89c3:

    d "(( There used to be a shower curtain. Why is it gone? ))"

translate english ch02_ahouse04_685912df:

    d "(( Did Frank take it down? ))"

translate english ch02_ahouse04_ad358f28:

    d "Amanda?"

translate english ch02_ahouse04_f410541d:

    d "I think I should get going now."

translate english ch02_ahouse04_1a11c330:

    d "....................."

translate english ch02_ahouse04_55c02367:

    a "......."

translate english ch02_ahouse04_fac8215b:

    d "............"

translate english ch02_ahouse04_faf842e1:

    d "Isn’t it about time Frank comes back??"

translate english ch02_ahouse04_120f2c5d:

    a "Ha......."

translate english ch02_ahouse04_e040587c:

    a "Last night felt so unreal that I forgot about Frank."

translate english ch02_ahouse04_2ead97da:

    a "Why does time pass so fast?"

translate english ch02_ahouse04_6f3d1290:

    a "Sob, sob...."

translate english ch02_ahouse04_932e8852:

    a "I feel like I might cry just thinking about it ending."

translate english ch02_ahouse04_c01325f3:

    a "Should we just run away together?"

translate english ch02_ahouse04_6b7bbbdf:

    a "Come here, big boy!"

translate english ch02_ahouse04_f235288d:

    d "What?!!"

translate english ch02_ahouse04_92bbd7c3:

    d "Ah!!"

translate english ch02_ahouse04_8832dad9:

    a "Hahahahaha."

translate english ch02_ahouse04_0796b970:

    a "Where do you think you’re rushing off to?!"

translate english ch02_ahouse04_96a8f355:

    d "Ah, Amanda!! I have to leave soon, and now my underwear’s soaked."

translate english ch02_ahouse04_8832dad9_1:

    a "Hahahahaha."

translate english ch02_ahouse04_899bdd84:

    a "If you don’t have underwear, just walk around without any."

translate english ch02_ahouse04_e079b163:

    a "You need to wash up too."

translate english ch02_ahouse04_cb5b4ce4:

    a "Frank will be back soon, so we have to hurry and wash up together!"

translate english ch02_ahouse04_7476632d:

    a "I’ve got plenty of underwear, so hurry up and take yours off."

translate english ch02_ahouse04_f235288d_1:

    d "What?!!"

translate english ch02_ahouse04_da4f115a:

    a "Why are you so shocked?"

translate english ch02_ahouse04_6851d0f3:

    d "No, Amanda!! No!!"

translate english ch02_ahouse04_704a276d:

    n "When she saw [d_name]’s dick, she was left speechless."

translate english ch02_ahouse04_ae72ea06:

    n "And it was completely different from what she had felt between her buttocks the night before."

translate english ch02_ahouse04_0fcd7019:

    n "In that instant, guilt and an unfamiliar embarrassment washed over her."

translate english ch02_ahouse04_22688bef:

    a "........................"

translate english ch02_ahouse04_ab689ed6:

    d "I’m sorry, Amanda."

translate english ch02_ahouse04_9ac9991e:

    d "Ha.... this is happening again...."

translate english ch02_ahouse04_df3a5063:

    a "Huh? Again?"

translate english ch02_ahouse04_6825128f:

    a "This....."

translate english ch02_ahouse04_6333ed1c:

    a "I... I think this is the first time for me?"

translate english ch02_ahouse04_17659cc8:

    a ".............."

translate english ch02_ahouse04_e39b8127:

    a "What are you doing right now?"

translate english ch02_ahouse04_f45753f5:

    a "Why is it moving like that.."

translate english ch02_ahouse04_e0409f14:

    a "I’m really, really sorry, honey."

translate english ch02_ahouse04_7099bdd7:

    a "I’ll finish quickly. Just give me five minutes, okay?"

translate english ch02_ahouse04_8bed9dcb:

    d "What?"

translate english ch02_ahouse04_a23883b0:

    d "You expect me to just stand here and wait?"

translate english ch02_ahouse04_3b932a62:

    d "(( ......................... ))"

translate english ch02_ahouse04_243e5950:

    d "(( The mood shifted completely all of a sudden. ))"

translate english ch02_ashower01_92f21ed5:

    n "What should I do?"

translate english ch02_ashower01_39d45f44:

    d "(( It’s the same pattern. ))"

translate english ch02_ashower01_e4a9b59c:

    d "(( She starts it and then pulls away. ))"

translate english ch02_ashower01_9d514758:

    d "(( Hmm.... ))"

translate english ch02_ashower01_491b6873:

    d "(( I should return it to the Queen of Teasing. You started this. ))"

translate english ch02_ashower01_10584543:

    d "(( This time you may have started it, but I’ll be the one to finish it, hahaha. ))"

translate english ch02_ashower01_3ecc798d:

    d "You know what?"

translate english ch02_ashower01_4f8e8a09:

    a "What?"

translate english ch02_ashower01_e94292f6:

    a "Ah!!!"

translate english ch02_ashower01_9b0b4e54:

    a "!!!!!!!!!!!"

translate english ch02_ashower01_a4cd76d0:

    a "What are you doing?!!"

translate english ch02_ashower01_3e9075b8:

    d "You know I wash up really fast."

translate english ch02_ashower01_7391dd70:

    d "I just need to get a little wet, hahaha."

translate english ch02_ashower01_e7c202dd:

    a "[d_name]!!!!!!!!!!!"

translate english ch02_ashower01_30d7ab5c:

    a "Get out right now!! This can’t happen!!"

translate english ch02_ashower01_59ef63d8:

    a "..................."

translate english ch02_ashower01_f85c6d9f:

    n "They had stepped into unknown territory."

translate english ch02_ashower01_16ec0bbd:

    n "Naked, they pressed their bodies against each other."

translate english ch02_ashower01_5aef04b5:

    n "She could feel his cock slowly pushing its way between her ass."

translate english ch02_ashower01_676a568e:

    a "Please..."

translate english ch02_ashower01_59345bd3:

    a "Fine, you win, so can you let me go now?"

translate english ch02_ashower01_ff678d23:

    a "..........................."

translate english ch02_ashower01_4a2d4427:

    n "Amanda may have said something, but she didn’t resist or push him away."

translate english ch02_ashower01_e5d3afb8:

    n "The warmth of a man’s naked body she hadn’t felt in a long time,"

translate english ch02_ashower01_1a54cb44:

    n "and a faint sense of humiliation swept her into an indescribable emotion."

translate english ch02_ashower01_29543f12:

    n "But she couldn’t bear the last fragment of her reason being washed away by the steam and that unfamiliar arousal."

translate english ch02_ashower01_d8926ae7:

    n "In reality, her role was restraining her instincts."

translate english ch02_ashower01_2db928e6:

    n "For now..."

translate english ch02_ashower01_2a9597df:

    n "In that brief moment, caught between her feelings as a woman and her sense of responsibility, she finally spoke."

translate english ch02_ashower01_54cf77b0:

    a "Honey..."

translate english ch02_ashower01_294bf42e:

    a "I’m sorry. I didn’t mean to tease you..."

translate english ch02_ashower01_ea650c16:

    a "I’ll be done showering in three minutes, so could you give me a little time?"

translate english ch02_ashower01_028ea31f:

    a "And that of yours..."

translate english ch02_ashower01_6308b758:

    a "Anyway, I’m sorry, but just wait a moment, okay?"

translate english ch02_ashower01_0ed0a004:

    d "Why? We’re already this close."

translate english ch02_ashower01_63b71ec6:

    d "I want to wash together."

translate english ch02_ashower01_ab03b1fd:

    a "No, that’s not it..."

translate english ch02_ashower01_58a931bf:

    a "This is too much, honey."

translate english ch02_ashower01_ed606197:

    a "This should never happen between us."

translate english ch02_ashower01_86bae2a3:

    a "I’ll finish quickly and come out, so please step outside for now. Okay, honey?"

translate english ch02_ashower01_d119543e:

    d "I don’t want to."

translate english ch02_ashower01_5e7735e1:

    d "I’ll wash you."

translate english ch02_ashower01_5456d8f8:

    a "(( !!! ))"

translate english ch02_ashower01_27059f73:

    a "Come on, [d_name]!!"

translate english ch02_ashower01_60e86b12:

    a "Why won’t you listen!!!"

translate english ch02_ashower01_e1ff151f:

    d "..................."

translate english ch02_ashower01_73da2658:

    d "Okay. I’m sorry."

translate english ch02_ashower01_2396ba44:

    a "Come on, honey."

translate english ch02_ashower01_611416da:

    a "I’m sorry. Frank will be home soon, so I’ll hurry and finish."

translate english ch02_ashower01_399db8e5:

    a "............"

translate english ch02_ashower01_f0f1e8f7:

    d "Okay. I’ll step out."

translate english ch02_ashower01_d71a6f39:

    d "I’ll step out, I’ll step out."

translate english ch02_ashower01_cb098f74:

    a "Ha............"

translate english ch02_ashower01_c8bbf1cd:

    d "Hmm........."

translate english ch02_ashower01_e0409f14:

    a "I’m really, really sorry, honey."

translate english ch02_ashower01_7099bdd7:

    a "I’ll be done soon. Just give me five minutes. Okay?"

translate english ch02_ahouse05_2394867a:

    a "Ah… when will we ever have time like this again?"

translate english ch02_ahouse05_99847603:

    a "It feels like we just met, but time flies."

translate english ch02_ahouse05_17cceea3:

    a "Is this what they call relativity?"

translate english ch02_ahouse05_99c4dc20:

    d "Haha."

translate english ch02_ahouse05_0e057f19:

    a "Should I just kill Frank? Hahaha."

translate english ch02_ahouse05_4cb112a5:

    a "Drag him to the mountain behind the village and tie him to a tree?"

translate english ch02_ahouse05_b2b02957:

    a "Or push him off the back of a fishing boat?"

translate english ch02_ahouse05_18e7813a:

    d "Hahaha, Amanda. Should I do it?"

translate english ch02_ahouse05_fe0d1dea:

    d "I’ll erase all the evidence and pack my bags and come back here."

translate english ch02_ahouse05_f87726a7:

    a "Hahaha. Don’t say such terrible things."

translate english ch02_ahouse05_698584c4:

    a "Frank disappears and the two of us live together?"

translate english ch02_ahouse05_11e8e714:

    a "Then human history would have to be rewritten."

translate english ch02_ahouse05_279a7abc:

    a "Anyway, even if it’s outside, let’s see each other often, honey."

translate english ch02_ahouse05_6a283de3:

    a "Why have a phone if you’re not going to use it? Even nonsense is fine—just contact me often."

translate english ch02_ahouse05_b908831e:

    d "I will, hehe."

translate english ch02_ahouse05_912cdb48:

    d "I’ll call you, my queen."

translate english ch02_ahouse05_a7aab7c7:

    a "Haha. Alright, my prince."

translate english ch02_ahouse05_1e8a5e67:

    a "I’ll look into how much a contract killing costs."

translate english ch02_ahouse05_9bb9e4fa:

    d "Hahahaha. I’ll look into it too."

translate english ch02_ahouse05_620853a9:

    d "We’ll have to handle it discreetly."

translate english ch02_ahouse05_b00ad13b:

    a "............."

translate english ch02_ahouse05_8e0787bb:

    a "You smooth talker, hehe."

translate english ch02_ahouse05_3b4428b2:

    a "See you soon."

translate english ch02_ahouse05_ff674af3:

    a "Big boy."

translate english ch02_ahouse05_cb965fb3:

    a "My big boy."

translate english ch02_pool02_ae682137:

    d "(( !!! ))"

translate english ch02_pool02_bc6853d9:

    d "(( What’s with that license plate? ))"

translate english ch02_pool02_a24da77c:

    d "(( Hahaha. Did Olivia come here? ))"

translate english ch02_pool02_f73e62a7:

    unknownf "Hahahahahaha."

translate english ch02_pool02_ed817d81:

    h "Goodness."

translate english ch02_pool02_2f0da9c0:

    h "I’m human too."

translate english ch02_pool02_f193d4f0:

    h "I have desires just like any other woman my age."

translate english ch02_pool02_4209ef6f:

    h "I just don’t flaunt it like you do."

translate english ch02_pool02_29e23915:

    h "Well..."

translate english ch02_pool02_dc1714dd:

    h "No, I’ve known you since kindergarten, and you still don’t know me?"

translate english ch02_pool02_01308c67:

    h "Though people do say I’m hard to read."

translate english ch02_pool02_ac40475f:

    h "It’s not like I’m hiding anything in particular."

translate english ch02_pool02_6c09aede:

    h "(( Hi, [d_name]!! ))"

translate english ch02_pool02_f88389c9:

    unknownf "(( !! ))"

translate english ch02_pool02_0c64e3c1:

    d "Good morning, [h_name]."

translate english ch02_pool02_5b389ebb:

    d "I just got back."

translate english ch02_pool02_b4b2d124:

    h "Did you have a good time at home?"

translate english ch02_pool02_ea103976:

    h "Without you, the house already feels empty."

translate english ch02_pool02_092d098a:

    h "I’ll be here, so call or text me if you need anything."

translate english ch02_pool02_532571e4:

    d "Yes, I will. Thank you."

translate english ch02_pool02_089d8df0:

    unknownf "Hey, kid!"

translate english ch02_pool02_8096b08a:

    d "Yes?"

translate english ch02_pool02_990618d8:

    unknownf "Why aren’t you introducing me?"

translate english ch02_pool02_cd178690:

    unknownf "That’s pretty bad manners, you know?"

translate english ch02_pool02_cf96a09c:

    h "Ha.... I was wondering why you were being so quiet."

translate english ch02_pool02_25b1e1c5:

    h "Ah, [d_name]."

translate english ch02_pool02_b3429802:

    h "This is Lena."

translate english ch02_pool02_5838b713:

    h "Um... she’s my best friend."

translate english ch02_pool02_2796832f:

    l "Hi, kid. I’m Lena."

translate english ch02_pool02_e575e4e3:

    l "We’ll be seeing each other often."

translate english ch02_pool02_2a8ee3a7:

    d "Nice to meet you. I’m [d_name]."

translate english ch02_pool02_fbf0c51a:

    d "I moved in here a few days ago as a tenant."

translate english ch02_pool02_7fc380b7:

    d "I’m a college student, and I came here for the break."

translate english ch02_pool02_bb483d6f:

    d "(( Have I seen her somewhere before? ))"

translate english ch02_pool02_5b9a76f7:

    d "(( Or am I imagining things? ))"

translate english ch02_pool02_6c378f15:

    l "(( Hmm..... why does this kid look so familiar? ))"

translate english ch02_pool02_1db6977b:

    l "(( Was he the one at that party? ))"

translate english ch02_pool02_5aace5d7:

    d "I’ll head upstairs."

translate english ch02_pool02_741a214b:

    d "Have a good time."

translate english ch02_pool02_d2c4e6d7:

    h "Alright. There are snacks in the kitchen, help yourself."

translate english ch02_pool02_c3081094:

    l "Hahaha."

translate english ch02_pool02_93c4f536:

    l "You even made snacks for him?"

translate english ch02_pool02_0bfcfb16:

    l "He tells us to have a good time? Hehe."

translate english ch02_pool02_f43d6f58:

    l "What kind of “good time” is he talking about?"

translate english ch02_pool02_bfb975c3:

    h "Come on, Lena."

translate english ch02_pool02_53c1b767:

    h "He’s a rare kind of good kid these days."

translate english ch02_pool02_57e3b904:

    h "Stop teasing him like that."

translate english ch02_pool02_0526eb31:

    l "Oh really?"

translate english ch02_pool02_d7485d36:

    l "You introduced me as just a friend because you’re conscious of that kid, right?? Huh?"

translate english ch02_pool02_ec421f0e:

    l "You brought such a cute boy into your house so you could keep him all to yourself, didn’t you?"

translate english ch02_pool02_9dc16e32:

    l "‘With you gone, the house already feels empty.’ Hahaha."

translate english ch02_pool02_51415508:

    h "Jesus.. Lena.."

translate english ch02_pool02_95479531:

    h "It’s not like that. That’s just unnecessary TMI for [d_name].."

translate english ch02_pool02_bc2f4d18:

    h "Ha......"

translate english ch02_pool02_75f710b2:

    l "Hehehe."

translate english ch02_pool02_15821924:

    l "That kid is seriously adorable."

translate english ch02_pool02_fdabdc76:

    l "I’ll be coming over more often, sweetheart."

translate english ch02_pool02_ed1f68e0:

    h "Don’t even dream about it."

translate english ch02_pool02_a0bdc273:

    h "If I sense anything like that, you’re banned from this house from that day on."

translate english ch02_pool02_9df73300:

    l "Hmm......."

translate english ch02_pool02_7a00eb12:

    l "Aren’t you overreacting a bit?..."

translate english ch02_pool02_a6284aa0:

    l "You like that kid, don’t you? Hehehe."

translate english ch02_pool02_781f9fd3:

    h "................"

translate english ch02_hhouse01_b7a1c307:

    d "What a crazy day again.."

translate english ch02_hhouse01_f69a7c0e:

    d "................"

translate english ch02_hhouse01_632107cd:

    d "Why do things like this keep happening?"

translate english ch02_hhouse01_267ceb9b:

    d "It feels like I’m the lead in some adult drama..."

translate english ch02_hhouse01_7e668ce3:

    d "Damn. Lately I keep ending up in awkward situations."

translate english ch02_hhouse01_0ff128d8:

    d "Did I change after a year away, or did this town change?"

translate english ch02_hhouse01_ade6a7eb:

    d "Did my dick grow a mind of its own and keep trying to pop out?"

translate english ch02_hhouse01_9aec8129:

    d "I need some cold water right now."

translate english ch02_hhouse01_27baec28:

    n "Hahahahahaha"

translate english ch02_hhouse01_704451b0:

    d "Huh?"

translate english ch02_hhouse01_ee3a4a32:

    d "(( They must be downstairs.. ))"

translate english ch02_hhouse01_a6e1e6e5:

    d "(( A sweet time between two middle-aged women.... ))"

translate english ch02_hhouse01_73ce265e:

    d "(( Sounds kind of romantic. ))"

translate english ch02_hhouse01_f0447efd:

    d "(( Are they watching a movie? ))"

translate english ch02_hhouse01_bc24a506:

    d "(( Damn, but now I’m curious what they’re doing. ))"

translate english ch02_hhouse01_74eb537b:

    d "(( It’s kind of thrilling that it’s just me and two women in this house. ))"

translate english ch02_hhouse01_9f6ceffe:

    d "(( Are they still wearing swimsuits? ))"

translate english ch02_hhouse01_62dd4ae8:

    d "(( What the hell am I thinking. ))"

translate english ch02_hhouse01_92f21ed5:

    n "What should I do?"

translate english ch02_hhouse01_58e7dba4:

    d "(( Damn. Am I turning into a voyeur now? ))"

translate english ch02_hhouse01_59a5bbe1:

    n "In the first-floor living room, they were sitting close together watching a movie."

translate english ch02_hhouse01_0b9af92f:

    n "They sat shoulder to shoulder, as if continuing the bond of best friends who shared everything since girlhood."

translate english ch02_hhouse01_10bc6a61:

    l "So what’s your plan, [h_name]?"

translate english ch02_hhouse01_bae921ab:

    h "Huh? What plan?"

translate english ch02_hhouse01_4b59c3ff:

    l "What, are you pretending not to know?"

translate english ch02_hhouse01_4e464c6e:

    l "Is it me, or is it that kid?"

translate english ch02_hhouse01_8b786946:

    h "Ha... Lena.."

translate english ch02_hhouse01_8e6b1610:

    h "It’s not like that. Do I look like some crazy woman?"

translate english ch02_hhouse01_f08c2568:

    h "He’s over twenty years younger than me. How could I see him as a man?"

translate english ch02_hhouse01_c6bea0c7:

    h "The fact that I even have to explain this is ridiculous."

translate english ch02_hhouse01_813d4c89:

    l "Oooh~ my darling secretly took in a cute young guy as a tenant?"

translate english ch02_hhouse01_58105bc0:

    l "If you’d wanted to, you could’ve taken in girls too, you know?"

translate english ch02_hhouse01_a2d89839:

    l "Now that I think about it, maybe you’re more superficial than I am."

translate english ch02_hhouse01_bb815d62:

    h "Think whatever you want."

translate english ch02_hhouse01_18ea51af:

    h "And if you say one more thing about [d_name], we’re done."

translate english ch02_hhouse01_d2c0c313:

    l "Baby.."

translate english ch02_hhouse01_40fd67b4:

    l "If you’re okay, I’m okay."

translate english ch02_hhouse01_f2080262:

    l "Whoever you meet, whoever you flirt with, I don’t care."

translate english ch02_hhouse01_2a87b694:

    l "You understood my lifestyle too. I was really grateful for that."

translate english ch02_hhouse01_d74e6aa9:

    l "But.."

translate english ch02_hhouse01_46b4dd66:

    l "You felt it too, right? His cock looked pretty solid."

translate english ch02_hhouse01_40308036:

    h "What?!!!!"

translate english ch02_hhouse01_626630b9:

    l "You’re at the point where you need a real cock now."

translate english ch02_hhouse01_3fe8f18b:

    l "Didn’t you bring in a young guy like that because you needed a young cock?"

translate english ch02_hhouse01_285958cc:

    l "A young cock that can fill you completely."

translate english ch02_hhouse01_8f2ca7bf:

    l "The kind that could leave you unable to even stand properly."

translate english ch02_hhouse01_06b3964a:

    d "(( ........... ))"

translate english ch02_hhouse01_71130f3f:

    d "(( Oh my God. ))"

translate english ch02_hhouse01_7c4ef27c:

    d "(( It feels like a tornado of filthy sentences just swept through. ))"

translate english ch02_hhouse01_3fd62c1b:

    d "(( Middle-aged women really don’t hold back with their words.. ))"

translate english ch02_hhouse01_98376a62:

    h "Stop it!"

translate english ch02_hhouse01_012328ad:

    h "Have you lost your mind?"

translate english ch02_hhouse01_569df7f8:

    l "No, I’m perfectly sane."

translate english ch02_hhouse01_923edb39:

    l "I’m saying this for your sake."

translate english ch02_hhouse01_17683840:

    l "You know it too."

translate english ch02_hhouse01_cea5dbf6:

    l "This isn’t the time for some plastic stick—you need a real thing."

translate english ch02_hhouse01_b40b246d:

    l "And that kind of cock is within arm’s reach now, isn’t it?"

translate english ch02_hhouse01_608e3a36:

    l "I’m actually happy you made that decision, baby."

translate english ch02_hhouse01_5745ce32:

    d "(( Holy.... ))"

translate english ch02_hhouse01_3a69f1f9:

    d "(( Is she right? ))"

translate english ch02_hhouse01_759396f9:

    d "(( Did my landlady really take me in for that reason???? ))"

translate english ch02_hhouse01_d6ad01bd:

    d "(( No way.. ))"

translate english ch02_hhouse01_c8c6135f:

    d "(( It’s only been a few days, but I didn’t sense anything like that.. ))"

translate english ch02_hhouse01_f1a47e67:

    l "I’ve always told you. If it’s good for you, I’m automatically on board."

translate english ch02_hhouse01_2eef447e:

    l "Which means..."

translate english ch02_hhouse01_0b7e2568:

    l "If it’s good for me, it should be good for you too, hahaha."

translate english ch02_hhouse01_e9fc9406:

    d "(( !!!!!!!!!!!!!!!!!!!!!!! ))"

translate english ch02_hhouse01_26a9a492:

    d "(( I remember now!!! ))"

translate english ch02_hhouse01_714a9502:

    d "(( She’s the woman I saw at the bus stop!! ))"

translate english ch02_hhouse01_02111dfe:

    d "(( Damn!! ))"

translate english ch02_hhouse01_87503203:

    d "(( No wonder she looked familiar!! ))"

translate english ch02_hhouse01_3e81b930:

    h "What? What do you mean by that?"

translate english ch02_hhouse01_4512036c:

    h "What are you plotting?"

translate english ch02_hhouse01_033afef7:

    h "What do you mean by something being good?"

translate english ch02_hhouse01_48d6619e:

    l "Hehe, we’ll talk about that later."

translate english ch02_hhouse01_c62a037f:

    l "Right now, I need you, darling!"

translate english ch02_hhouse01_44e178ea:

    d "(( Damn! That was close. ))"

translate english ch02_hhouse01_244d9260:

    d "(( What am I even doing right now.. ))"

translate english ch02_hhouse01_3f74dc20:

    l "Come here, darling~"

translate english ch02_hhouse01_0fb5e038:

    l "Hold me."

translate english ch02_hhouse01_1225d495:

    l "I love you, [h_name]."

translate english ch02_hhouse01_d186a818:

    l "Whether you date an old man or a young boy, I’m fine with it."

translate english ch02_hhouse01_07825048:

    l "Because I love you."

translate english ch02_hhouse01_8c06d1ee:

    l "Seeing the person I love live happily—that’s my true happiness."

translate english ch02_hhouse01_39882e7a:

    d "(( Jesus.... ))"

translate english ch02_hhouse01_68c6b6e0:

    d "(( Damn... she’s on par with Olivia... ))"

translate english ch02_hhouse01_1d6b6cc7:

    d "(( But if Olivia has elegant sexiness, this woman feels spicier. ))"

translate english ch02_hhouse01_fc572184:

    d "(( What do I do? Damn, I’m dying of curiosity... ))"

translate english ch02_hhouse01_1afa2d59:

    d "(( .................... ))"

translate english ch02_hhouse01_25f3f369:

    d "(( Right!! The window outside!! ))"

translate english ch02_house02_92f21ed5:

    n "What should I do?"

translate english ch02_house02_fdaf12a4:

    d "(( Right!! ))"

translate english ch02_house02_7fa50d7d:

    d "(( I think there was a big window outside! ))"

translate english ch02_house02_73af58c1:

    d "(( Damn it, [d_name].. ))"

translate english ch02_house02_016efdf7:

    d "(( Is this really all you are?! ))"

translate english ch02_house02_22982957:

    d "(( What if they catch you?? ))"

translate english ch02_house02_849b5080:

    d "(( Sneaking and spying.. this self-loathing is intense.. ))"

translate english ch02_house02_652b51e0:

    d "(( But I can’t stop being curious.. ))"

translate english ch02_house02_f7b21af2:

    d "(( Damn, my heart’s racing. ))"

translate english ch02_house02_e3831cf9:

    d "(( It’s like becoming a criminal who knows it’s wrong but can’t stop. ))"

translate english ch02_house02_7255e293:

    n "Mwah, mwah. Chu, chu."

translate english ch02_house02_ed784eba:

    d "(( Damn. What are they doing?.. ))"

translate english ch02_house02_fce115ca:

    d "(( Shit! That scared me!! ))"

translate english ch02_house02_01825d84:

    d "(( Damn it! ))"

translate english ch02_house02_9bb920d3:

    d "(( You little brat!! ))"

translate english ch02_house02_45a447c7:

    d "(( Get lost! ))"

translate english ch02_house02_6361fafe:

    d "(( Where the hell did that thing come from? ))"

translate english ch02_house02_b084de7b:

    d "(( Is it [h_name]’s cat? ))"

translate english ch02_house02_84f0aef7:

    d "(( My heart’s about to explode. ))"

translate english ch02_house02_5a25ab89:

    d "!!!!!!!!!!!!!!!"

translate english ch02_house02_52da5a07:

    d "(( [h_name]..... ))"

translate english ch02_house02_7c0a9214:

    d ".............."

translate english ch02_house02_8db0ac2a:

    h "What’s wrong?"

translate english ch02_house02_441eae63:

    l "Ah, I thought I heard something."

translate english ch02_house02_ff914cde:

    l "I’ll just check for a second."

translate english ch02_house02_24ce229a:

    d "(( Damn!!!!!!!!! ))"

translate english ch02_house02_36076c56:

    l "Huh??"

translate english ch02_house02_06f22660:

    l "Hehe. It was you."

translate english ch02_house02_52b3abfd:

    l "Where have you been all day?"

translate english ch02_house02_a83155ee:

    n "Meow"

translate english ch02_house02_6168472f:

    l "You can’t come in right now."

translate english ch02_house02_d02510ae:

    l "Come back later, okay?"

translate english ch02_house02_b5fa3e0b:

    l "Sorry."

translate english ch02_house02_dd5c8bb9:

    l ".............."

translate english ch02_house02_77f7a76d:

    d "!!!!!!!!!!!!!!!!!!!!!!"

translate english ch02_house02_52ed23f3:

    d "(( Oh my God... ))"

translate english ch02_house02_913ff84d:

    d "(( She really has no sense of embarrassment!! ))"

translate english ch02_house02_44940732:

    d "(( Damn... I already like her. ))"

translate english ch02_house02_ccc9ad1e:

    d "(( She feels like a woman who can embrace everything in this world... ha... ))"

translate english ch02_house02_df91341c:

    d "(( I love you, Lena!!!!! ))"

translate english ch02_house02_1bb3a5f1:

    h "What are you doing?"

translate english ch02_house02_ad5cd409:

    l "Ah, I thought something moved outside, but it was just the cat."

translate english ch02_house02_1beb0687:

    l "(( You sly little thing. ))"

translate english ch02_house02_427f3585:

    l "(( How dare you spy on your landlady’s private life?! ))"

translate english ch02_house02_9eed5c6e:

    l "(( How about this? ))"

translate english ch02_house02_50f487d8:

    l "(( Do you like it? ))"

translate english ch02_house02_78aaba0f:

    l "(( You’re dying to put it in here, aren’t you? Hahaha. ))"

translate english ch02_house02_243b5277:

    l "(( It’d probably fit your cock perfectly, don’t you think? ))"

translate english ch02_house02_43453896:

    l "(( Feels like it would wrap around your cock tight and warm, right? ))"

translate english ch02_house02_00983488:

    l "(( Ha.......... ))"

translate english ch02_house02_aeb18fd5:

    l "(( Too bad, not tonight. ))"

translate english ch02_house02_5bd042fb:

    l "(( You shouldn’t get a woman that easily. ))"

translate english ch02_house02_c5d54eed:

    l "(( If you want inside me, you’ll have to prove yourself first. ))"

translate english ch02_house02_50e759d0:

    l "(( And it seems your partner in this house is someone else, isn’t it? ))"

translate english ch02_house02_6c4ddfd4:

    d "(( .............. ))"

translate english ch02_house02_58596916:

    d "(( Damn..... ))"

translate english ch02_house02_b6067c0d:

    d "(( My heart feels like it’s going to explode.... ))"

translate english ch02_house02_6c4ddfd4_1:

    d "(( .............. ))"

translate english ch02_house02_e1c3db47:

    d "(( ............... ))"

translate english ch02_house02_5379f14a:

    d "(( I love you, Lena. ))"

translate english ch02_house02_9357f0ae:

    d "(( I love you, [h_name]. ))"

translate english ch02_house02_c40c11a1:

    d "(( I want to be part of your world too. ))"

translate english ch02_house02_562e60c4:

    d "(( I’m an adult too. ))"

translate english ch02_droom02_601f9e58:

    n "Fap fap fap"

translate english ch02_droom02_601f9e58_1:

    n "Fap fap fap"

translate english ch02_droom02_60b0a580:

    d "Ahh"

translate english ch02_droom02_6bbd9581:

    d "Damn!!"

translate english ch02_droom02_89c31175:

    d "Lena!!"

translate english ch02_droom02_08b83949:

    d "[h_name]!! Lena!! Come sit on top of me!!"

translate english ch02_droom02_79b2d46a:

    d "Use my cock!"

translate english ch02_droom02_9bdead9b:

    d "I’m a man who can satisfy you!!!"

translate english ch02_droom02_601f9e58_2:

    n "Fap fap fap"

translate english ch02_droom02_16824a1b:

    l "Ha... I’m sleepy."

translate english ch02_droom02_82c40130:

    l "I guess I’m getting older."

translate english ch02_droom02_dfecc8a4:

    l "After driving for hours, I’m exhausted at night."

translate english ch02_droom02_c07194c2:

    l "That boy....."

translate english ch02_droom02_fc527fea:

    l "He looks innocent, but he acts like a pervert."

translate english ch02_droom02_594f386f:

    l "Though usually, guys with innocent faces are the ones with big dick!"

translate english ch02_droom02_e15dddfb:

    l "Maybe it’s nature’s way of balancing things?"

translate english ch02_droom02_7ffbe664:

    l "Spying on his landlady’s private life and all.."

translate english ch02_droom02_447e7d3c:

    l ".................."

translate english ch02_droom02_232de8a6:

    l "A middle-aged female landlady and a young male tenant.."

translate english ch02_droom02_173bba7b:

    l "It’s humanity’s classic, dating back to ancient Greece, haha."

translate english ch02_droom02_5fe76c0f:

    l "But those classics always seemed to end in tragedy."

translate english ch02_droom02_e6b6c422:

    l "There were never stories where a middle-aged woman and a young man lived happily ever after."

translate english ch02_droom02_f75de85c:

    l "The middle-aged woman would always collapse under guilt,"

translate english ch02_droom02_f4c03572:

    l "and the young man would grow disappointed with her aging body and return to a young woman who could match his desire."

translate english ch02_droom02_8f4b366f:

    l "And if the husband showed up, it would end in bloodshed.."

translate english ch02_droom02_5e0b4928:

    l "......................."

translate english ch02_droom02_723182b5:

    l "Damn...."

translate english ch02_droom02_c0ee6f12:

    l "Still, it’s been quite a while since either [h_name] or I felt a real cock.."

translate english ch02_droom02_baa0a3c7:

    l "..................."

translate english ch02_droom02_0be76513:

    l "It’s not like we ever had a rule against meeting men.."

translate english ch02_droom02_5e0b4928_1:

    l "......................."

translate english ch02_droom02_659609a0:

    l "The two of us were enough, but somehow..."

translate english ch02_droom02_8166cd2e:

    l "Even without saying it, we both knew there’s something only a real man can provide..."

translate english ch02_droom02_6103ab61:

    l "After I started sleeping with [h_name], I actually found myself craving a man more than ever.."

translate english ch02_droom02_45d50b7f:

    l "Ha.............."

translate english ch02_droom02_2c10a4b2:

    l "I need to find out whether that guy deserves to live under the same roof as our [h_name]."

translate english ch02_droom02_459c7b48:

    l "In a secluded place like this, if a man really wanted to, he could do anything…"

translate english ch02_droom02_93740f55:

    l "(( Is this outfit too revealing? ))"

translate english ch02_droom02_40527616:

    l "(( So what. I’ll wear what I want. ))"

translate english ch02_droom02_7d845a6d:

    l "(( I’m just talking to a kid for a moment. ))"

translate english ch02_droom02_29aba278:

    l "Are you there, mister?"

translate english ch02_droom02_7de01cf0:

    n "Ugh!!"

translate english ch02_droom02_36076c56:

    l "Huh??"

translate english ch02_droom02_d4a9a727:

    l "What was that sound?"

translate english ch02_droom02_6d23007c:

    l "!!!!!!!!!!!!!!!!"

translate english ch02_droom02_08d084e6:

    l "(( Oh my God... ))"

translate english ch02_droom02_d735f4ee:

    l "..............."

translate english ch02_droom02_16e60edd:

    d "Ah, [h_name]!!"

translate english ch02_droom02_649b9e9e:

    l "(( Oh boy... ))"

translate english ch02_droom02_aa007d0d:

    d "Ah, Lena!!"

translate english ch02_droom02_902552f1:

    l "(( Yes! I’m right here!! ))"

translate english ch02_droom02_6ad99af4:

    l "(( Damn, two cocks for one hole? ))"

translate english ch02_droom02_e3262482:

    l "(( Is that your taste? ))"

translate english ch02_droom02_d07a3cc3:

    l "(( Look how fast those hands move.. ))"

translate english ch02_droom02_2370fbd7:

    l "(( Oh my God.. ))"

translate english ch02_droom02_70d12a5e:

    l "(( !!!!!!!!!!! ))"

translate english ch02_droom02_cb9e1a55:

    l "(( I remember!!!!! That boy!!! ))"

translate english ch02_droom02_63423290:

    l "(( He was that kid on the bus!! ))"

translate english ch02_droom02_c249ff38:

    l "(( The one who took my picture. ))"

translate english ch02_droom02_04496d09:

    l "(( Can coincidences like this really happen!! ))"

translate english ch02_droom02_60bde154:

    l "(( .................... ))"

translate english ch02_droom02_912e582c:

    l "(( Look at those veins.... ))"

translate english ch02_droom02_6fa3fb2b:

    l "(( It’s the most aggressive-looking cock I’ve seen in a while. ))"

translate english ch02_droom02_ef68c3c3:

    l "(( [h_name], you sly girl... ))"

translate english ch02_droom02_b4ce5e69:

    l "(( Is that luck, or did you suddenly gain x-ray vision? ))"

translate english ch02_droom02_fc48c36c:

    l "(( How did you pick something like that? ))"

translate english ch02_droom02_94b928b5:

    l "(( Did you hold auditions for tenants? ))"

translate english ch02_droom02_0cee96d4:

    l "(( The world is still fair after all. ))"

translate english ch02_droom02_97a439e1:

    l "(( Living modestly like [h_name] really brings blessings. ))"

translate english ch02_droom02_123218ee:

    h "(( Where did she go? ))"

translate english ch02_droom02_02fa0530:

    h "(( Where did she disappear to at this hour? ))"

translate english ch02_droom02_b3ec46bd:

    h "(( Huh? ))"

translate english ch02_droom02_61596695:

    l "(( That’s what I really want.. ))"

translate english ch02_droom02_86f17803:

    l "(( A cock that could make me surrender completely in just one thrust.. ))"

translate english ch02_droom02_52ef8ab3:

    l "(( A cock that could awaken the submissive instinct inside me... ))"

translate english ch02_droom02_186d456d:

    l "(( ............ ))"

translate english ch02_droom02_f7a492e0:

    l "Ha... just looking at it makes my pussy twitch."

translate english ch02_droom02_ccb2672d:

    h "(( What? ))"

translate english ch02_droom02_128c1625:

    h "(( My pussy is twitching?? ))"

translate english ch02_droom02_2dc89fb6:

    h "Lena! What are you doing there?"

translate english ch02_droom02_2baa13c3:

    l "(( !!!!!!!!!!!!!!!!!!!!!!!!!!!! ))"

translate english ch02_droom02_29ba9056:

    h "Why are you opening [d_name]’s door? What are you doing?"

translate english ch02_droom02_f53763aa:

    d "Ah, Lena!!!!"

translate english ch02_droom02_1358f47b:

    d "Ah, [h_name]!!!!"

translate english ch02_droom02_0a1786d0:

    d "Your pussy is so tight and hot!!!!"

translate english ch02_droom02_25a18a1d:

    l "(( Shut up, you idiot!!!!!!!!! ))"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
