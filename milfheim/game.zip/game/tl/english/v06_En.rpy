
translate english strings:


    old "{#weekday}Monday"
    new "{#weekday}Monday"


    old "{#weekday}Tuesday"
    new "{#weekday}Tuesday"


    old "{#weekday}Wednesday"
    new "{#weekday}Wednesday"


    old "{#weekday}Thursday"
    new "{#weekday}Thursday"


    old "{#weekday}Friday"
    new "{#weekday}Friday"


    old "{#weekday}Saturday"
    new "{#weekday}Saturday"


    old "{#weekday}Sunday"
    new "{#weekday}Sunday"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Mon"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Tue"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Wed"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Thu"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Fri"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sat"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Sun"


    old "{#month}January"
    new "{#month}January"


    old "{#month}February"
    new "{#month}February"


    old "{#month}March"
    new "{#month}March"


    old "{#month}April"
    new "{#month}April"


    old "{#month}May"
    new "{#month}May"


    old "{#month}June"
    new "{#month}June"


    old "{#month}July"
    new "{#month}July"


    old "{#month}August"
    new "{#month}August"


    old "{#month}September"
    new "{#month}September"


    old "{#month}October"
    new "{#month}October"


    old "{#month}November"
    new "{#month}November"


    old "{#month}December"
    new "{#month}December"


    old "{#month_short}Jan"
    new "{#month_short}Jan"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Apr"


    old "{#month_short}May"
    new "{#month_short}May"


    old "{#month_short}Jun"
    new "{#month_short}Jun"


    old "{#month_short}Jul"
    new "{#month_short}Jul"


    old "{#month_short}Aug"
    new "{#month_short}Aug"


    old "{#month_short}Sep"
    new "{#month_short}Sep"


    old "{#month_short}Oct"
    new "{#month_short}Oct"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dec"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Page {}"
    new "Page {}"


    old "Automatic saves"
    new "Automatic saves"


    old "Quick saves"
    new "Quick saves"


    old "Quick save complete."
    new "Quick save complete."


    old "Are you sure?"
    new "Are you sure?"


    old "Are you sure you want to delete this save?"
    new "Are you sure you want to delete this save?"


    old "Are you sure you want to overwrite your save?"
    new "Are you sure you want to overwrite your save?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Loading will lose unsaved progress.\nAre you sure you want to do this?"


    old "Are you sure you want to quit?"
    new "Are you sure you want to quit?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."


    old "Are you sure you want to end the replay?"
    new "Are you sure you want to end the replay?"


    old "Are you sure you want to begin skipping?"
    new "Are you sure you want to begin skipping?"


    old "Are you sure you want to skip to the next choice?"
    new "Are you sure you want to skip to the next choice?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Are you sure you want to skip unseen dialogue to the next choice?"


    old "Saved screenshot as %s."
    new "Saved screenshot as %s."


    old "Self-voicing disabled."
    new "Self-voicing disabled."


    old "Clipboard voicing enabled. "
    new "Clipboard voicing enabled. "


    old "Self-voicing enabled. "
    new "Self-voicing enabled. "


    old "Skip Mode"
    new "Skip Mode"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Clipboard voicing enabled. Press 'shift+C' to disable."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Self-voicing enabled. Press 'v' to disable."


    old "Contacting App Store\nPlease Wait..."
    new "Contacting App Store\nPlease Wait..."


    old "The Ren'Py Updater is not supported on mobile devices."
    new "The Ren'Py Updater is not supported on mobile devices."


    old "An error is being simulated."
    new "An error is being simulated."


    old "Either this project does not support updating, or the update status file was deleted."
    new "Either this project does not support updating, or the update status file was deleted."


    old "This account does not have permission to perform an update."
    new "This account does not have permission to perform an update."


    old "This account does not have permission to write the update log."
    new "This account does not have permission to write the update log."


    old "Could not verify update signature."
    new "Could not verify update signature."


    old "The update file was not downloaded."
    new "The update file was not downloaded."


    old "The update file does not have the correct digest - it may have been corrupted."
    new "The update file does not have the correct digest - it may have been corrupted."


    old "While unpacking {}, unknown type {}."
    new "While unpacking {}, unknown type {}."


    old "Updater"
    new "Updater"


    old "An error has occured:"
    new "An error has occured:"


    old "Checking for updates."
    new "Checking for updates."


    old "This program is up to date."
    new "This program is up to date."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] is available. Do you want to install it?"


    old "Preparing to download the updates."
    new "Preparing to download the updates."


    old "Downloading the updates."
    new "Downloading the updates."


    old "Unpacking the updates."
    new "Unpacking the updates."


    old "Finishing up."
    new "Finishing up."


    old "The updates have been installed. The program will restart."
    new "The updates have been installed. The program will restart."


    old "The updates have been installed."
    new "The updates have been installed."


    old "The updates were cancelled."
    new "The updates were cancelled."


    old "Proceed"
    new "Proceed"


    old "Cancel"
    new "Cancel"


    old "Fullscreen"
    new "Fullscreen"


    old "Image [index] of [count] locked."
    new "Image [index] of [count] locked."


    old "prev"
    new "prev"


    old "next"
    new "next"


    old "slideshow"
    new "slideshow"


    old "return"
    new "return"


    old "Graphics Acceleration"
    new "Graphics Acceleration"


    old "Automatically Choose"
    new "Automatically Choose"


    old "Force Angle/DirectX Renderer"
    new "Force Angle/DirectX Renderer"


    old "Force OpenGL Renderer"
    new "Force OpenGL Renderer"


    old "Force Software Renderer"
    new "Force Software Renderer"


    old "Gamepad"
    new "Gamepad"


    old "Enable"
    new "Enable"


    old "Disable"
    new "Disable"


    old "Calibrate"
    new "Calibrate"


    old "Changes will take effect the next time this program is run."
    new "Changes will take effect the next time this program is run."


    old "Quit"
    new "Quit"


    old "Return"
    new "Return"


    old "Performance Warning"
    new "Performance Warning"


    old "This computer is using software rendering."
    new "This computer is using software rendering."


    old "This computer is not using shaders."
    new "This computer is not using shaders."


    old "This computer is displaying graphics slowly."
    new "This computer is displaying graphics slowly."


    old "This computer has a problem displaying graphics: [problem]."
    new "This computer has a problem displaying graphics: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display. Updating DirectX could fix this problem."
    new "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display. Updating DirectX could fix this problem."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."


    old "Update DirectX"
    new "Update DirectX"


    old "Continue, Show this warning again"
    new "Continue, Show this warning again"


    old "Continue, Don't show warning again"
    new "Continue, Don't show warning again"


    old "Updating DirectX."
    new "Updating DirectX."


    old "DirectX web setup has been started. It may start minimized in the taskbar. Please follow the prompts to install DirectX."
    new "DirectX web setup has been started. It may start minimized in the taskbar. Please follow the prompts to install DirectX."


    old "{b}Note:{/b} Microsoft's DirectX web setup program will, by default, install the Bing toolbar. If you do not want this toolbar, uncheck the appropriate box."
    new "{b}Note:{/b} Microsoft's DirectX web setup program will, by default, install the Bing toolbar. If you do not want this toolbar, uncheck the appropriate box."


    old "When setup finishes, please click below to restart this program."
    new "When setup finishes, please click below to restart this program."


    old "Restart"
    new "Restart"


    old "Select Gamepad to Calibrate"
    new "Select Gamepad to Calibrate"


    old "No Gamepads Available"
    new "No Gamepads Available"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrating [name] ([i]/[total])"


    old "Press or move the [control!r] [kind]."
    new "Press or move the [control!r] [kind]."


    old "Skip (A)"
    new "Skip (A)"


    old "Back (B)"
    new "Back (B)"


    old "Open"
    new "Open"


    old "Opens the traceback.txt file in a text editor."
    new "Opens the traceback.txt file in a text editor."


    old "Copy"
    new "Copy"


    old "Copies the traceback.txt file to the clipboard."
    new "Copies the traceback.txt file to the clipboard."


    old "An exception has occurred."
    new "An exception has occurred."


    old "Rollback"
    new "Rollback"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Attempts a roll back to a prior time, allowing you to save or choose a different choice."


    old "Ignore"
    new "Ignore"


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignores the exception, allowing you to continue. This often leads to additional errors."


    old "Reload"
    new "Reload"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Reloads the game from disk, saving and restoring game state if possible."


    old "Console"
    new "Console"


    old "Opens a console to allow debugging the problem."
    new "Opens a console to allow debugging the problem."


    old "Quits the game."
    new "Quits the game."


    old "Parsing the script failed."
    new "Parsing the script failed."


    old "Opens the errors.txt file in a text editor."
    new "Opens the errors.txt file in a text editor."


    old "Copies the errors.txt file to the clipboard."
    new "Copies the errors.txt file to the clipboard."


    old "Developer Menu"
    new "Developer Menu"


    old "Reload Game (Shift+R)"
    new "Reload Game (Shift+R)"


    old "Console (Shift+O)"
    new "Console (Shift+O)"


    old "Variable Viewer"
    new "Variable Viewer"


    old "Theme Test"
    new "Theme Test"


    old "Image Location Picker"
    new "Image Location Picker"


    old "Filename List"
    new "Filename List"


    old "Show Image Load Log"
    new "Show Image Load Log"


    old "Hide Image Load Log"
    new "Hide Image Load Log"


    old "Nothing to inspect."
    new "Nothing to inspect."


    old "Return to the developer menu"
    new "Return to the developer menu"


    old "Rectangle: %r"
    new "Rectangle: %r"


    old "Mouse position: %r"
    new "Mouse position: %r"


    old "Right-click or escape to quit."
    new "Right-click or escape to quit."


    old "Rectangle copied to clipboard."
    new "Rectangle copied to clipboard."


    old "Position copied to clipboard."
    new "Position copied to clipboard."


    old "✔ "
    new "✔ "


    old "✘ "
    new "✘ "


    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"


    old "Displayable Inspector"
    new "Displayable Inspector"


    old "Size"
    new "Size"


    old "Style"
    new "Style"


    old "Location"
    new "Location"


    old "Inspecting Styles of [displayable_name!q]"
    new "Inspecting Styles of [displayable_name!q]"


    old "displayable:"
    new "displayable:"


    old "        (no properties affect the displayable)"
    new "        (no properties affect the displayable)"


    old "        (default properties omitted)"
    new "        (default properties omitted)"


    old "<repr() failed>"
    new "<repr() failed>"


    old "Press <esc> to exit console. Type help for help.\n"
    new "Press <esc> to exit console. Type help for help.\n"


    old "Ren'Py script enabled."
    new "Ren'Py script enabled."


    old "Ren'Py script disabled."
    new "Ren'Py script disabled."


    old "help: show this help"
    new "help: show this help"


    old "commands:\n"
    new "commands:\n"


    old " <renpy script statement>: run the statement\n"
    new " <renpy script statement>: run the statement\n"


    old " <python expression or statement>: run the expression or statement"
    new " <python expression or statement>: run the expression or statement"


    old "clear: clear the console history"
    new "clear: clear the console history"


    old "exit: exit the console"
    new "exit: exit the console"


    old "load <slot>: loads the game from slot"
    new "load <slot>: loads the game from slot"


    old "save <slot>: saves the game in slot"
    new "save <slot>: saves the game in slot"


    old "reload: reloads the game, refreshing the scripts"
    new "reload: reloads the game, refreshing the scripts"


    old "watch <expression>: watch a python expression"
    new "watch <expression>: watch a python expression"


    old "unwatch <expression>: stop watching an expression"
    new "unwatch <expression>: stop watching an expression"


    old "unwatchall: stop watching all expressions"
    new "unwatchall: stop watching all expressions"


    old "jump <label>: jumps to label"
    new "jump <label>: jumps to label"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
