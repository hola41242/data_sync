translate english ch03_droom01_fd6a5aa6:

    h "**(Where is she…?)**"

translate english ch03_droom01_672cbbcf:

    h "**(Where did she go at this hour…?)**"

translate english ch03_droom01_34080e78:

    h "**(Huh?)**"

translate english ch03_droom01_74744245:

    l "**(That's what I'm truly after...)**"

translate english ch03_droom01_f7a492e0:

    l "Ha... just watching this makes me throb down there."

translate english ch03_droom01_3842efff:

    h "**(What?)**"

translate english ch03_droom01_99503a84:

    h "**(Throb down where??)**"

translate english ch03_droom01_2dc89fb6:

    h "Lena! What the hell are you doing here?"

translate english ch03_droom01_ade27f66:

    l "**(!!!!!!!!!!!!!!!!!!!!!!!!!!!!)**"

translate english ch03_droom01_29ba9056:

    h "Why are you opening [d_name]’s door??"

translate english ch03_droom01_f53763aa:

    d "Ah, Lena!!!!"

translate english ch03_droom01_1358f47b:

    d "Ah, [h_name]!!!!"

translate english ch03_droom01_0a1786d0:

    d "Your pussy is so incredibly tight!!"

translate english ch03_droom01_fd43aed4:

    l "**(Shut up, you idiot!!!!!!!!!)**"

translate english ch03_droom01_a7662e87:

    n "For a moment, [h_name] doubted her ears."

translate english ch03_droom01_ba3bca07:

    n "The sounds from the porn and [d_name]’s voice were mixed together, making it hard to tell what was what,"

translate english ch03_droom01_9d70c0b4:

    n "but through the silence, what she could clearly hear were the faint moans coming from [d_name]."

translate english ch03_droom01_bda0fbce:

    l "Ah, haha…"

translate english ch03_droom01_08316cab:

    h "What on earth were you doing?"

translate english ch03_droom01_b984d0d3:

    l "Don't get the wrong idea, baby."

translate english ch03_droom01_e49b0cc4:

    l "The door was slightly open, so I just took a peek while passing by."

translate english ch03_droom01_d6b9cb0d:

    h "………………"

translate english ch03_droom01_34080e78_1:

    h "**(Huh?)**"

translate english ch03_droom01_a2b2d346:

    h "!!!!!!!!!!!!!!!!!!!"

translate english ch03_droom01_910f05e4:

    d "Ah, [h_name]!!!!!!"

translate english ch03_droom01_7ab1135c:

    d "Yes, just like that, tighter!!!!"

translate english ch03_droom01_dfd55fbb:

    d "I knew it the moment I saw you!!"

translate english ch03_droom01_9b4ac25b:

    d "You're dying to feel my cock, aren't you!!"

translate english ch03_droom01_035b880b:

    d "I’m going to fill you up!!"

translate english ch03_droom01_56eafa3d:

    h "**(What did he just say?!!!!)**"

translate english ch03_droom01_d735f4ee:

    l "………………"

translate english ch03_droom01_519bc03e:

    l "Ha………"

translate english ch03_droom01_8218ae14:

    l "Perfect. Absolutely perfect."

translate english ch03_droom01_fd6e26de:

    h "………………"

translate english ch03_droom01_822454d4:

    h "**(Oh my god……)**"

translate english ch03_droom01_fd6e26de_1:

    h "………………"

translate english ch03_droom01_89a4a257:

    d "Huh?!!!!!!!!!!!"

translate english ch03_droom01_6bbd9581:

    d "Shit!!"

translate english ch03_droom01_0a1c8a97:

    d "**(What was that?)**"

translate english ch03_droom01_ea144941:

    d "**(………………)**"

translate english ch03_droom01_5a1fc122:

    d "**(Was someone there?!!!!)**"

translate english ch03_droom01_6a21657e:

    d "………………"

translate english ch03_droom01_ac31b9ac:

    d "Is anyone there?!!"

translate english ch03_droom01_6a21657e_1:

    d "………………"

translate english ch03_droom01_ce897e06:

    d "**(I’m sure I heard a voice just now...)**"

translate english ch03_droom01_6a21657e_2:

    d "………………"

translate english ch03_droom01_2c2894e1:

    d "**(Or not… was I imagining it?)**"

translate english ch03_droom01_d3b6e7ad:

    n "Once [h_name] realized what was happening, she wasn't shocked, nor was she angry at Lena."

translate english ch03_droom01_184fe310:

    n "She only felt a deep sense of guilt for unintentionally invading [d_name]’s privacy."

translate english ch03_droom01_5d6508e4:

    n "She didn't even care that he was using her as a fantasy for his masturbation."

translate english ch03_droom01_f9889c53:

    h "Ha………"

translate english ch03_droom01_71f87339:

    h "Lena, what are you even thinking...."

translate english ch03_droom01_1151fcab:

    h "Ha…………"

translate english ch03_droom01_cd85b91e:

    h "I can't believe this is happening..."

translate english ch03_droom01_2ed08bc1:

    l "Don't overreact like that..."

translate english ch03_droom01_9e5cabbc:

    l "It’s no big deal."

translate english ch03_droom01_8154c70d:

    h "Come over here, Lena..."

translate english ch03_droom01_a3c1d472:

    h "Ha, Lena…"

translate english ch03_droom01_ac222981:

    h "Why the hell were you spying on his room?"

translate english ch03_droom01_795a1cba:

    h "I told you clearly before..."

translate english ch03_droom01_73b92946:

    h "The moment you show any hidden motives toward him, you're banned from this house!!"

translate english ch03_droom01_f3fa63a4:

    l "………………"

translate english ch03_droom01_4c650d94:

    l "You've got it all wrong, [h_name]. Do I look crazy? Why would I be interested in a kid like him?"

translate english ch03_droom01_46225f57:

    l "I have plenty of men around me."

translate english ch03_droom01_8c9992a2:

    l "Why would I ever bother seducing someone like that!"

translate english ch03_droom01_a3c1d472_1:

    h "Ha, Lena…"

translate english ch03_droom01_071bdfe9:

    h "That’s a lie. I know you too well."

translate english ch03_droom01_10fd62db:

    h "This is just you being you, isn't it?"

translate english ch03_droom01_545e7200:

    h "You came here specifically to try something with [d_name]."

translate english ch03_droom01_fd0be024:

    h "How could you do that to my tenant?"

translate english ch03_droom01_34ffa1ff:

    l "That’s not it! I told you, I’m not interested in that kid."

translate english ch03_droom01_69dfec9c:

    l "I was just doing it for your sake......."

translate english ch03_droom01_41cfc2b4:

    l "………………"

translate english ch03_droom01_a12ad2e5:

    l "I just wanted to see if he's actually a decent guy..."

translate english ch03_droom01_9b8a3852:

    l "………"

translate english ch03_droom01_3d06eebe:

    l "I wanted to find out if he's the kind of person you should be living with."

translate english ch03_droom01_bcdbe24d:

    l "So I just came up here to talk for a bit."

translate english ch03_droom01_bc286b6a:

    h "What?"

translate english ch03_droom01_88cf28b9:

    h "What do you mean?"

translate english ch03_droom01_e0a4076f:

    h "How is that supposed to be for my sake?"

translate english ch03_droom01_8aeba26b:

    h "Who’s going to believe you just came to talk, dressed like that?"

translate english ch03_droom01_255ae72a:

    h "How is snooping on someone’s privacy supposed to be for my sake?!!"

translate english ch03_droom01_eb959906:

    d "………………"

translate english ch03_droom01_83e44693:

    d "**(She was spying on me… for [h_name]’s sake??)**"

translate english ch03_droom01_ebc54c5e:

    d "**(What does that even mean…?)**"

translate english ch03_droom01_91f15a27:

    d "**(Does she think I’m some kind of weirdo or something?))**"

translate english ch03_droom01_2490b6bb:

    d "**(………)**"

translate english ch03_droom01_59cc9b36:

    d "**(This actually feels pretty insulting...)**"

translate english ch03_droom01_fa89653f:

    l "I told you…"

translate english ch03_droom01_1c459394:

    l "I wanted to see if he’s worthy of living under the same roof as you."

translate english ch03_droom01_60b17267:

    l "I think I at least have the right to check that."

translate english ch03_droom01_97ff2a08:

    l "And I really did just come to talk, that’s all."

translate english ch03_droom01_852b473b:

    l "But then I heard those noises and thought something was wrong."

translate english ch03_droom01_3f041ac0:

    l "So I just opened the door a little to check."

translate english ch03_droom01_da75aad4:

    l "I knocked first, of course…"

translate english ch03_droom01_7caf97d7:

    h "………………"

translate english ch03_droom01_238597ab:

    h "I have no idea what you’re even talking about, Lena…"

translate english ch03_droom01_bd167ed7:

    l "Hehe… so here’s what I think."

translate english ch03_droom01_f457b201:

    l "I didn’t actually talk to him, but I could tell enough just from that."

translate english ch03_droom01_863ad3e1:

    l "First of all, I think he could bring some new energy into your life."

translate english ch03_droom01_1ab44933:

    l "You saw it too, didn’t you?"

translate english ch03_droom01_7caf97d7_1:

    h "………………"

translate english ch03_droom01_b207853b:

    h "Energy?"

translate english ch03_droom01_d9ba30be:

    h "What are you talking about?"

translate english ch03_droom01_ce6bdb11:

    l "That kid's impressive cock, of course."

translate english ch03_droom01_64d56e05:

    h "!!!!!!!!!!!"

translate english ch03_droom01_53598f7d:

    l "You saw it too, didn’t you? hehe."

translate english ch03_droom01_96364373:

    h "Lena… why are you even saying that right now?"

translate english ch03_droom01_7eda9bca:

    h "Stop talking crazy!!"

translate english ch03_droom01_0f96a207:

    l "Hehe. Look at you. You're turning bright red."

translate english ch03_droom01_ab49b4c6:

    l "You look like a teenage girl, haha."

translate english ch03_droom01_de28ec16:

    l "So, how is it? Makes you feel all warm and fuzzy inside, right? Like life's finally looking up."

translate english ch03_droom01_5c364dd7:

    l "Feels like your life just got a sudden thrill, right? haha."

translate english ch03_droom01_b3ef1551:

    h "Stop it."

translate english ch03_droom01_92b633a0:

    h "Say one more word and you’re sleeping in your car tonight!!"

translate english ch03_droom01_788fabdf:

    h "Ha…"

translate english ch03_droom01_b702562e:

    d "…………………"

translate english ch03_droom01_71318923:

    d "**(One thing’s for sure.)**"

translate english ch03_droom01_3ed95476:

    d "**(It’s not me. There’s definitely something wrong with this neighborhood…)**"

translate english ch03_droom01_6058ecae:

    d "**(………)**"

translate english ch03_droom01_a26d5698:

    d "**(I really picked the worst time to show up here...)**"

translate english ch03_monologue01_47eda320:

    d "**(It’s been a few days since [h_name] and Lena saw me masturbating…)**"

translate english ch03_monologue01_2a25e6cb:

    d "**(Ha………………)**"

translate english ch03_monologue01_3ba6edf8:

    d "**(Since then, it feels like [h_name] has been avoiding me a little.)**"

translate english ch03_monologue01_0cb49b0a:

    d "**(Or more accurately… she’s been acting a bit awkward around me…)**"

translate english ch03_monologue01_ea144941:

    d "**(………………)**"

translate english ch03_monologue01_d572b4b3:

    d "**(But as time passed, she gradually went back to normal.)**"

translate english ch03_monologue01_ae10865f:

    d "**(We started eating together, cleaning, sharing everyday life.)**"

translate english ch03_monologue01_dc9ddce9:

    d "**(The awkwardness that had wedged itself between us without any chance to grow closer was suffocating.)**"

translate english ch03_monologue01_87771378:

    d "**(But as we shared small daily moments, that awkwardness slowly began to fade.)**"

translate english ch03_monologue01_3ec13dc1:

    d "**(Little by little, we both grew more comfortable, and each other’s presence started to feel natural.)**"

translate english ch03_monologue01_8934bd62:

    d "**(As if I had always been part of this house.)**"

translate english ch03_monologue01_a8d59569:

    d "**(She has this strange charm—she can make me nervous, but also at ease.)**"

translate english ch03_monologue01_d165d669:

    d "**(Our conversations grew deeper day by day.)**"

translate english ch03_monologue01_a8d74e08:

    d "**(From simple greetings and check-ins to sharing interests, preferences, and)**"

translate english ch03_monologue01_e95cf940:

    d "**(trying to understand each other’s feelings, even letting those feelings affect our lives.)**"

translate english ch03_monologue01_44ef7fbe:

    d "**(But our relationship can only go as far as landlady and tenant allows.)**"

translate english ch03_monologue01_808d9335:

    d "**(That’s only natural.)**"

translate english ch03_monologue01_770c8068:

    d "**(Like Lena said, there’s no way she took me in with any sexual motives.)**"

translate english ch03_monologue01_28d51a5c:

    d "**(I’ve never felt anything like that from the day I moved in until now.)**"

translate english ch03_monologue01_c123cbd6:

    d "**(Of course, [h_name] sometimes dresses a bit revealing, but that’s natural.)**"

translate english ch03_monologue01_f365e569:

    d "**(This is her home, and I wouldn’t want her to feel uncomfortable because of me.)**"

translate english ch03_monologue01_229b63c0:

    d "**(And there’s a big enough age gap that she wouldn’t even need to worry about that around me…)**"

translate english ch03_monologue01_907f4ab8:

    d "**(But one thing still bothers me—ever since that night, she’s been acting normal on the surface…)**"

translate english ch03_monologue01_dca8fcd2:

    d "**(but sometimes her expression looks slightly unnatural.)**"

translate english ch03_monologue01_f6fab95b:

    d "**(Or more precisely… it feels like she’s become aware of me—no, of my dick.)**"

translate english ch03_monologue01_a5b96a76:

    d "**(Now when she sees my face, she probably thinks of that automatically.)**"

translate english ch03_monologue01_d5b6c2cb:

    d "**(Right?)**"

translate english ch03_monologue01_96de4b5a:

    d "**(This is what they call classical conditioning. I learned it in psychology.)**"

translate english ch03_monologue01_5eed2133:

    d "**(Like Pavlov’s dog—she sees my face, and that association kicks in.)**"

translate english ch03_monologue01_aade0e04:

    d "**(Regardless of her own will.)**"

translate english ch03_monologue01_d850981d:

    d "**(I guess… it’ll probably be like that for a while.)**"

translate english ch03_monologue01_1a14bc9c:

    d "**(Of course, I can’t know what she’s really thinking.)**"

translate english ch03_monologue01_97221561:

    d "**(This could all just be in my head.)**"

translate english ch03_monologue01_0a3c8ca7:

    d "**(She’s pretty laid-back, and she’s a mother—she might not care about it at all…)**"

translate english ch03_monologue01_9dd8cc97:

    d "**(But one thing is certain…)**"

translate english ch03_monologue01_4f036241:

    d "**(Whenever she’s near me, her face flushes more often.)**"

translate english ch03_monologue01_7ef905cb:

    d "**(Ha…………)**"

translate english ch03_monologue01_43093781:

    d "**(“Yes, just like that, tighter!!!!”)**"

translate english ch03_monologue01_713d3297:

    d "**(“I knew it the moment I saw you!!”)**"

translate english ch03_monologue01_f6e7e867:

    d "**(“You want to feel my cock, don’t you!!”)**"

translate english ch03_monologue01_1a0059df:

    d "**(………………)**"

translate english ch03_monologue01_1951ee76:

    d "**(After saying things like that, it’s no wonder she reacts this way…)**"

translate english ch03_monologue01_a667bbd2:

    d "**(But she seems to be trying to act normal so I won’t feel uncomfortable.)**"

translate english ch03_monologue01_b0b4c8b3:

    d "**(Damn… I want to tell her she doesn’t have to do that…)**"

translate english ch03_monologue01_b0b91fc5:

    d "**(but saying anything would only make that moment more vivid again…)**"

translate english ch03_monologue01_b6457b8a:

    d "**(What was that called again…)**"

translate english ch03_monologue01_862255be:

    d "**(Right—ironic process theory… Daniel Wegner.)**"

translate english ch03_monologue01_6113f910:

    d "**(It’s better for her if I just say nothing.)**"

translate english ch03_monologue01_45924045:

    d "**(Damn… this is frustrating..)**"

translate english ch03_monologue01_f660666e:

    d "**(It’s not like there’s anything I can do… or even anything I should be doing…)**"

translate english ch03_monologue01_2ca1a4b2:

    d "**(But it feels like I’m trying to breathe with an empty tank.)**"

translate english ch03_monologue01_ae8a591c:

    d "**(If someone else were here… maybe it wouldn’t feel this suffocating…)**"

translate english ch03_monologue01_bdcd82af:

    d "**(………………)**"

translate english ch03_monologue01_3863eb84:

    d "**(Should I do something… or just wait for it to fade away?)**"

translate english ch03_monologue01_da58aed0:

    d "**(Shit…………)**"

translate english ch03_gym01_2c4f06ef:

    h "…………………"

translate english ch03_gym01_2c4f06ef_1:

    h "…………………"

translate english ch03_gym01_6507b915:

    h "Hmm……"

translate english ch03_gym01_a398eb40:

    h "How do models manage to hold these awkward poses all day long?"

translate english ch03_gym01_f70c5688:

    h "Ugh~~~"

translate english ch03_gym01_5d23c583:

    h "Are you a desirable woman, [h_name]?"

translate english ch03_gym01_8e44d9cb:

    h "………"

translate english ch03_gym01_33fca7d4:

    h "Or are you just... plain? A total nobody?"

translate english ch03_gym01_8e44d9cb_1:

    h "………"

translate english ch03_gym01_171eb235:

    h "Hello. I'm [h_name]... and I'm irresistible."

translate english ch03_gym01_8b01ea47:

    h "Once I have you, there's no turning back."

translate english ch03_gym01_8e44d9cb_2:

    h "………"

translate english ch03_gym01_781f9fd3:

    h "…………"

translate english ch03_gym01_ced6d7c1:

    h "…………………"

translate english ch03_gym01_58ff383b:

    h "What are you doing, [h_name]?"

translate english ch03_gym01_049ebc77:

    h "Just stalling because I don't want to work out, huh?"

translate english ch03_gym01_c4c3ff61:

    h "Has it really been almost a month?"

translate english ch03_gym01_40511c87:

    h "Ha... I'm worried about how much my stamina has tanked in the meantime."

translate english ch03_gym01_f230f242:

    h "I can already hear Ivy's nagging ringing in my ears."

translate english ch03_gym01_cd68bb60:

    h "I should drag [d_name] out here with me next time. Hehe."

translate english ch03_gym01_03bc697c:

    h "He seems to have a pretty good frame."

translate english ch03_gym01_3d582f97:

    h "I bet he'd look great with just a little bit of working out."

translate english ch03_gym01_3e6a3329:

    n "The major events in [h_name]'s life over the past few years had brought many changes to her world."

translate english ch03_gym01_bcc28107:

    n "Those incidents had drained her so much that she struggled to even look after herself."

translate english ch03_gym01_5d716408:

    n "Only after a long time has she finally managed to get her life back on track."

translate english ch03_gym01_cc8e55b1:

    h "Oh my god... is this mirror making me look wider?"

translate english ch03_gym01_432bd356:

    h "Did I put on some fat?"

translate english ch03_gym01_4d19f5dc:

    h "Ha……"

translate english ch03_gym01_af3c8db8:

    h "This is serious.."

translate english ch03_gym01_02edacc4:

    h "Lena doesn't even seem to work out, so how does she stay so slim? It's a mystery."

translate english ch03_gym01_5409e4a3:

    n "It was only a year ago that she finally returned to her former life."

translate english ch03_gym01_1379525b:

    n "She went back to work, started paying off the mortgage, and began taking care of her body again as a woman."

translate english ch03_gym01_660558ad:

    n "As time passed, her life began to regain its old normalcy,"

translate english ch03_gym01_d59a1047:

    n "and taking [d_name] in as a tenant signaled that her life was fully recovering its original shape."

translate english ch03_gym01_f7f1daf4:

    n "Because it meant she was now able to take care of someone else, not just herself."

translate english ch03_gym01_b3d4593b:

    i "Hey [h_name]! How've you been?"

translate english ch03_gym01_30b7f2a5:

    h "Ivy~~~"

translate english ch03_gym01_24ace766:

    i "I haven't seen you in ages, I missed you! Haha."

translate english ch03_gym01_002e9bb0:

    i "Weren't you even worried about my nagging?"

translate english ch03_gym01_42c9ef0a:

    h "Haha, I was worried about it every single day."

translate english ch03_gym01_4e927ee1:

    h "It was on my mind even when I was trying to sleep. Hahaha."

translate english ch03_gym01_56363ca0:

    h "I was busy with some stuff at home. Time to get back to the grind. Hehe."

translate english ch03_gym01_cca535ae:

    h "A few things piled up, so I had to take care of them.."

translate english ch03_gym01_50a4d975:

    i "I thought I'd lost another member for good. Haha."

translate english ch03_gym01_cabd53a4:

    i "All the guys here looked so gloomy without you around. Hahaha."

translate english ch03_gym01_60ac35fb:

    h "Haha, don’t say things like that."

translate english ch03_gym01_42998b3b:

    i "Try to show up more often so we can work out together."

translate english ch03_gym01_e0859162:

    h "Alright. I'll come by more often now."

translate english ch03_gym01_2d27fe13:

    h "I'm going to work out at least once every two days."

translate english ch03_gym01_df33298b:

    i "That's the spirit, [h_name]! That's exactly what I want to hear!"

translate english ch03_gym01_bff2028f:

    h "Wow, I totally forgot how to use this, haha."

translate english ch03_gym01_12f63002:

    h "Was it like this??"

translate english ch03_gym01_dfaf93d3:

    h "Oh, there it goes."

translate english ch03_gym01_3efa2ae6:

    h "Huff… guess it’s time for Ivy to start nagging me"

translate english ch03_gym01_5c874c30:

    h "Huff… don’t hold back, just say it."

translate english ch03_gym01_baa958ae:

    i "………………"

translate english ch03_gym01_053a63cc:

    h "Huff…"

translate english ch03_gym01_c1d377f7:

    h "If you’re not going to say anything, can you just move aside?"

translate english ch03_gym01_55128e13:

    i "See, [h_name]?"

translate english ch03_gym01_e7cc7796:

    i "Your running form is totally shot because you took a break."

translate english ch03_gym01_f461553a:

    i "Did your hips get bigger?"

translate english ch03_gym01_d48c1726:

    i "Your boobs looks bigger too."

translate english ch03_gym01_7b0afd84:

    h "Shut up."

translate english ch03_gym01_3ab1aa42:

    h "Huff… I know. I know, alright… huff."

translate english ch03_gym01_eb2ef90c:

    h "It wasn’t this hard the last time I ran… huff."

translate english ch03_gym01_2a519398:

    i "That's just how the body works. Hahaha."

translate english ch03_gym01_b47e32fe:

    i "The human body was designed to be in constant motion."

translate english ch03_gym01_2e506f7a:

    i "The heart is a muscle, too."

translate english ch03_gym01_f4bb1563:

    i "If you don’t keep it working consistently and strongly, it gets weak."

translate english ch03_gym01_74adac70:

    i "Your lifespan just shortened by exactly the amount of time you skipped the gym."

translate english ch03_gym01_248c9611:

    h "Wow, that really stings."

translate english ch03_gym01_4e38ca5e:

    h "But can you save the lecture for later?"

translate english ch03_gym01_93c693a6:

    h "Haah… haah…"

translate english ch03_gym01_09da1cc7:

    h "Maybe it’s because I didn’t eat breakfast… the ceiling’s spinning."

translate english ch03_gym01_7afc402a:

    i "Hahaha."

translate english ch03_gym01_db0d00f9:

    i "Don’t you want to be like this?"

translate english ch03_gym01_fc2521c7:

    i "These days, only the strong survive."

translate english ch03_gym01_5fa02377:

    i "You need a body strong enough to protect yourself."

translate english ch03_gym01_1febb409:

    h "What? Haha. Thanks, but I’ll pass."

translate english ch03_gym01_d0aeb5b7:

    h "I’m satisfied with my body as it is, hehe."

translate english ch03_gym01_35cada0b:

    h "Well… maybe if I lost a little fat, it’d be perfect."

translate english ch03_gym01_dc8a772a:

    h "I don’t know… I’ll just have the man I love protect me, hehe."

translate english ch03_gym01_3c5bf834:

    i "Hahaha, don’t say stuff like that."

translate english ch03_gym01_fc4ae05c:

    i "Ahem!"

translate english ch03_gym01_c2f1e767:

    i "Anyway, today we’re focusing on glutes."

translate english ch03_gym01_edfc04da:

    i "You worked arms last time, so today’s all about your hips."

translate english ch03_gym01_6704133f:

    h "Oh my god, you remember what I did last time?"

translate english ch03_gym01_81de3300:

    i "I didn’t remember—I wrote it down in your workout log."

translate english ch03_gym01_4169e90e:

    h "Ha… glutes?"

translate english ch03_gym01_1a768bac:

    h "I just came back after a week, so I’m only going to warm up today."

translate english ch03_gym01_806b1f2a:

    h "If I overdo it after a break, it’ll be rough…"

translate english ch03_gym01_d575d51f:

    i "Oh really?"

translate english ch03_gym01_4166588b:

    i "You’re the one who told me to nag you whenever you start talking weak like that!!"

translate english ch03_gym01_9b0d9f94:

    i "Take it up with your past self."

translate english ch03_gym01_d89b10b0:

    i "If I let you off easy, I’m not doing my job."

translate english ch03_gym01_ed817d81:

    h "Oh my god."

translate english ch03_gym01_4c3cb413:

    h "Did I really say that?"

translate english ch03_gym01_dedc5e3a:

    h "Now I’m actually getting annoyed at my past self, haha."

translate english ch03_gym01_e6288a6c:

    i "Look, [h_name]."

translate english ch03_gym01_816fe76a:

    i "This is what proper glutes look like."

translate english ch03_gym01_1c6e2648:

    i "Doesn’t it motivate you? hahaha."

translate english ch03_gym01_86b59a61:

    h "Haha, alright, alright!!"

translate english ch03_gym01_7e2e9117:

    h "I’ll give you “Best Ass in Milfheim” this year, haha."

translate english ch03_gym01_0c404787:

    h "Lucky you, Ivy."

translate english ch03_gym01_485a710d:

    i "More, more… sit so your calves and thighs are vertical!"

translate english ch03_gym01_d65a8697:

    i "Don’t bounce your hips like that!!"

translate english ch03_gym01_cbdfa14a:

    i "That’s not sexy at all, you know?"

translate english ch03_gym01_d64183b2:

    h "Haah…………"

translate english ch03_gym01_a0e715b4:

    i "That’s it, [h_name]!! One more set!!"

translate english ch03_gym01_73ab3d30:

    h "What?!! Oh come on…"

translate english ch03_gym01_780b9abd:

    i "Don’t be weak!"

translate english ch03_gym01_378ed9ff:

    i "Don’t spring up like that!!"

translate english ch03_gym01_be8bd586:

    i "Feel your thighs supporting your weight."

translate english ch03_gym01_f94f87f0:

    h "Haah… haah…"

translate english ch03_gym01_a9a56b82:

    h "My thighs are burning."

translate english ch03_gym01_0e31827a:

    i "That’s what happens after a month off, haha."

translate english ch03_gym01_dc568320:

    i "Don’t complain."

translate english ch03_gym01_e5168962:

    h "Ah… my legs are shaking…"

translate english ch03_gym01_acf61f73:

    h "Damn it, Ivy.."

translate english ch03_gym01_491818ed:

    h "You're merciless…"

translate english ch03_gym01_4338f07b:

    h "………"

translate english ch03_gym01_67e62c59:

    h "Still… it feels good after working out, hehe."

translate english ch03_gym01_a2121dc2:

    h "I should come more often."

translate english ch03_gym01_cfdb0947:

    h "Next time, I’ll bring [d_name] too."

translate english ch03_gym01_bc2f4d18:

    h "Ha……"

translate english ch03_gym01_6d420c33:

    h "Feels refreshing…"

translate english ch03_gym01_549e4714:

    h "Still, it feels good to be working out again after so long."

translate english ch03_gym01_2bd4007e:

    h "I should be grateful that I’m healthy enough to do this…"

translate english ch03_gym01_919b902e:

    h "Yeah…"

translate english ch03_gym01_6a02135a:

    h "Just being alive and able to work out like this is a miracle…"

translate english ch03_gym01_eb543d19:

    i "Oh, [h_name], you were in the shower?"

translate english ch03_gym01_5d9ec814:

    h "Yeah. It’s the one thing I’m actually good at here…"

translate english ch03_gym01_b763a59c:

    h "I always feel better after a shower, haha."

translate english ch03_gym01_ff783e82:

    h "Are you showering too?"

translate english ch03_gym01_48a2fdbc:

    i "Yeah. I’ve got somewhere to be."

translate english ch03_gym01_2305522b:

    i "And by the way…"

translate english ch03_gym01_286df9e0:

    i "Maybe try putting that same energy into your workouts, haha."

translate english ch03_gym01_a0773db6:

    i "Nothing helps you take control of your life like working out does."

translate english ch03_gym01_cd3654bd:

    i "It’s great."

translate english ch03_gym01_96a2838d:

    i "You get healthier, and your confidence goes up."

translate english ch03_gym01_803aab01:

    i "And men notice right away, whether they admit it or not—whether a woman works out or not."

translate english ch03_gym01_023f8ec3:

    i "If your thighs are thick, they think you’ll have a strong grip."

translate english ch03_gym01_d2beb2ff:

    h "What?"

translate english ch03_gym01_765e7825:

    i "My boyfriend said he was really looking forward to how tight it’d feel the first time we slept together."

translate english ch03_gym01_1ef274b9:

    h "Hahaha, oh my god."

translate english ch03_gym01_d1b651cf:

    h "That’s… actually kind of something."

translate english ch03_gym01_6a2489a8:

    h "Ivy… did you change how you motivate me or something?"

translate english ch03_gym01_01f88af2:

    h "I don’t know if I should be grateful or annoyed at how much you care, haha."

translate english ch03_gym01_3fb7b7d7:

    h "I’m perfectly satisfied with how tight I am."

translate english ch03_gym01_f3b212e6:

    i "Hahaha, really? That’s what guys say too?"

translate english ch03_gym01_0aa988eb:

    h "Shut up."

translate english ch03_gym01_d6842a3f:

    i "Relax, relax…"

translate english ch03_gym01_57864901:

    i "I just care more because you’re my friend."

translate english ch03_gym01_7caf97d7:

    h "………………"

translate english ch03_gym01_977fde0f:

    h "I just wish there was a man who’d actually love me."

translate english ch03_gym01_897f48e2:

    h "It’s not easy meeting someone new in a small town like this."

translate english ch03_gym01_76355f5e:

    h "The older guys are too busy getting by, and the younger ones just want to sleep with you once."

translate english ch03_gym01_29e22178:

    i "Hahaha, I feel exactly the same."

translate english ch03_gym01_0a7799e8:

    i "I’m so sick of younger guys flirting."

translate english ch03_gym01_fa16902c:

    i "They sign up at the gym, hit on me nonstop, and disappear the next day—there are tons of them."

translate english ch03_gym01_b0d4242c:

    i "I don’t know if they’re just shameless these days or if they just try their luck with any woman."

translate english ch03_gym01_b7bc3b37:

    i "………………"

translate english ch03_gym01_039ccde7:

    i "But men have always been like that."

translate english ch03_gym01_353861a0:

    i "Which means, if you want, you can take advantage of them."

translate english ch03_gym01_cd3cdca3:

    h "Hmm……"

translate english ch03_gym01_305e38df:

    h "Use them how?"

translate english ch03_gym01_37b88aaa:

    i "Think of it simply. You’re the center of your own world."

translate english ch03_gym01_4c6f227b:

    i "If you want sex, pick someone you like and go for it."

translate english ch03_gym01_c44549b6:

    i "If someone comes along that you want to love, then love them."

translate english ch03_gym01_413d599a:

    i "“What is this? Is this love?” No—it’s just physical attraction."

translate english ch03_gym01_1c671c56:

    i "If you keep overthinking like that, you just waste time."

translate english ch03_gym01_494509ba:

    i "Look at us, [h_name]."

translate english ch03_gym01_ab6d3414:

    i "We’ve already lived more than half our lives."

translate english ch03_gym01_d840a7d7:

    i "Keep hesitating, and you’ll be old before you know it."

translate english ch03_gym01_d709a714:

    h "Wow, Ivy. Today you sound more like a mentor than a friend."

translate english ch03_gym01_92ad9932:

    h "………………"

translate english ch03_gym01_5ca28746:

    h "I’ll keep that in mind, haha."

translate english ch03_gym01_b48dfd33:

    i "Hey..."

translate english ch03_gym01_01ea4feb:

    i "Want to meet someone?"

translate english ch03_gym01_22adbcaf:

    i "There’s a guy at the gym who seems decent."

translate english ch03_gym01_ff7c4dbd:

    i "He’s divorced now."

translate english ch03_gym01_b6b41581:

    i "Seems to have his life together."

translate english ch03_gym01_0c9a4aa9:

    i "What do you think? Interested?"

translate english ch03_gym01_92ad9932_1:

    h "………………"

translate english ch03_gym01_0081e639:

    h "I don’t know, Ivy…"

translate english ch03_gym01_91fec69b:

    h "I’m not sure I’m ready to start something new with someone."

translate english ch03_gym01_1295de33:

    h "I’ll think about it. Thanks."

translate english ch03_gym01_9d31b2f3:

    i "Yeah, think it over and let me know."

translate english ch03_gym01_7df370c4:

    h "I will. Thanks, Ivy."

translate english ch03_gym01_0280f845:

    i "No problem."

translate english ch03_gym01_ad451e38:

    i "And don’t forget."

translate english ch03_gym01_48d0985a:

    h "Don’t forget what?"

translate english ch03_gym01_baa958ae_1:

    i "………………"

translate english ch03_gym01_d5a3e02e:

    i "Guys are curious about how tight you are."

translate english ch03_gym01_7b0afd84_1:

    h "Shut up."

translate english ch03_hstudio01_02d3e39b:

    d "Ah, this is the life~~"

translate english ch03_hstudio01_bcbe0670:

    d "This is pure bliss, haha."

translate english ch03_hstudio01_d5eaa5ad:

    d "Man… I wish I could just live here forever…"

translate english ch03_hstudio01_133689a0:

    d "With [h_name] by my side forever... haha."

translate english ch03_hstudio01_e8cc0cf7:

    n "The phone rings."

translate english ch03_hstudio01_55c37d54:

    d "Oh, [h_name]."

translate english ch03_hstudio01_bfcb15f3:

    d "What is it?"

translate english ch03_hstudio01_696b3bc6:

    h "Hey, [d_name]."

translate english ch03_hstudio01_b8b0da16:

    h "Are you home right now?"

translate english ch03_hstudio01_90b6008e:

    d "Yeah, I’m in the backyard."

translate english ch03_hstudio01_c8f56432:

    h "I’m sorry, but… could you help me just this once?"

translate english ch03_hstudio01_f4cc82f7:

    d "Of course. What is it?"

translate english ch03_hstudio01_93a7d72b:

    h "I left an SD card in my room, but I can’t leave the studio right now."

translate english ch03_hstudio01_e623125f:

    h "I’m really sorry, but if you have time, could you bring it here?"

translate english ch03_hstudio01_9348a1c5:

    d "Of course. It’s not like I’m busy or anything, haha."

translate english ch03_hstudio01_642d968c:

    d "I'm on my way."

translate english ch03_hstudio01_5efa40fa:

    h "Thank you so much, [d_name]."

translate english ch03_hstudio01_bd7aa6e5:

    h "No need to rush. Be careful."

translate english ch03_hstudio01_8c8b81cc:

    d "Got it. See you in a bit."

translate english ch03_hstudio01_c138eae1:

    d "Huh?!!"

translate english ch03_hstudio01_88f1d318:

    d "Wait... are you kidding me? No clean boxers?"

translate english ch03_hstudio01_700b5e08:

    d "Ah, damn, right—I put my last pair in the wash yesterday…"

translate english ch03_hstudio01_fba7768b:

    d "Guess I have no choice… going commando today."

translate english ch03_hstudio01_7ec09f75:

    d "Hahaha. Going commando makes me think of Amanda."

translate english ch03_hstudio01_dff7c546:

    d "How's my sweet ride doing today?"

translate english ch03_hstudio01_eb451bfd:

    d "Let’s hit the road together again today. Take good care of me."

translate english ch03_hstudio01_6086f976:

    d "Today's quest: the witch's castle, where Queen [h_name] is held captive."

translate english ch03_hstudio01_2e42c678:

    d "I’m the knight of justice going to rescue her."

translate english ch03_hstudio01_2edf2c36:

    d "Woohoo~"

translate english ch03_hstudio01_dd90619a:

    d "It’s my first time going to [h_name]’s studio…"

translate english ch03_hstudio01_c3b5cc96:

    d "I wonder what her professional side is like."

translate english ch03_hstudio01_22486389:

    d "Haha. I wanna get there already."

translate english ch03_hstudio01_681094bd:

    d "[h_name] [h_name] [h_name]…"

translate english ch03_hstudio01_96ec246f:

    d "The prince on his white horse has arrived."

translate english ch03_hstudio01_f8c2d906:

    d "Please welcome me looking your most beautiful."

translate english ch03_hstudio01_9f391ba0:

    d "Give your prince a passionate kiss."

translate english ch03_hstudio01_f69a7c0e:

    d "………………"

translate english ch03_hstudio01_4200475b:

    d "Ha… what am I even thinking…"

translate english ch03_hstudio01_8e2571ef:

    d "I think I'm losing it... the delusions are getting out of hand."

translate english ch03_hstudio01_8c0125c8:

    d "If Jason heard this, he’d think I’m pathetic, haha."

translate english ch03_hstudio01_dd973840:

    d "This should be the place, right?"

translate english ch03_hstudio01_da34c33b:

    d "Address is right..."

translate english ch03_hstudio01_d4f71737:

    d "Ah, this must be the door."

translate english ch03_hstudio01_b187cc51:

    d "The Luminous Studio…"

translate english ch03_hstudio01_5c1bf059:

    d "Is this the castle where Princess [h_name] resides?"

translate english ch03_hstudio01_ba4f5656:

    n "The door soon opened, and [h_name] greeted him with a smile."

translate english ch03_hstudio01_696b3bc6_1:

    h "Hey, [d_name]."

translate english ch03_hstudio01_23e54235:

    h "You got here fast, hehe."

translate english ch03_hstudio01_e6a707e8:

    h "Sorry for making you come all the way here in this heat."

translate english ch03_hstudio01_765e512d:

    h "I'm such a klutz, haha."

translate english ch03_hstudio01_a649750a:

    h "I really owe you one."

translate english ch03_hstudio01_cd9de02f:

    d "Not at all."

translate english ch03_hstudio01_a528bc82:

    d "I’m just happy I could help, haha."

translate english ch03_hstudio01_45ef8c83:

    d "Ask me anytime!"

translate english ch03_hstudio01_236ae689:

    h "Haha, okay. You brought the SD card, right??"

translate english ch03_hstudio01_af6b7766:

    d "Ah, one second."

translate english ch03_hstudio01_1ea53901:

    d "Here it is."

translate english ch03_hstudio01_b819b5dc:

    d "Escorted it here personally, with extra care."

translate english ch03_hstudio01_c940fa31:

    h "Haha, thank you."

translate english ch03_hstudio01_af7fe6fc:

    d "No problem, hehe."

translate english ch03_hstudio01_f69a7c0e_1:

    d "………………"

translate english ch03_hstudio01_e788e34c:

    n "When [d_name] peeked inside the studio, a woman in her underwear was standing there."

translate english ch03_hstudio01_47fffbcc:

    d "**(!!!!!!!)**"

translate english ch03_hstudio01_2d2fa03f:

    d "**(Holy… )**"

translate english ch03_hstudio01_5c176d8d:

    d "**(Is [h_name] involved in some kind of photography or filming?)**"

translate english ch03_hstudio01_4ec21847:

    h "Oh, thank goodness~~"

translate english ch03_hstudio01_ff5dac07:

    h "You saved me, [d_name]."

translate english ch03_hstudio01_6a70b112:

    h "If this didn’t work, I would’ve had to go all the way to the mall."

translate english ch03_hstudio01_bbc59c50:

    d "Glad it worked out."

translate english ch03_hstudio01_d615f849:

    d "Now I'm glad I made the trip."

translate english ch03_hstudio01_6c6a1239:

    d "Think I should just sign on as your full-time assistant?"

translate english ch03_hstudio01_a68dc4c4:

    h "Haha, want to?"

translate english ch03_hstudio01_670bffba:

    h "Thanks."

translate english ch03_hstudio01_4c0bc9dc:

    d "!!"

translate english ch03_hstudio01_11878f5c:

    n "Mwah!"

translate english ch03_hstudio01_4d3ac60a:

    n "[h_name] kissed him on the cheek."

translate english ch03_hstudio01_a841afed:

    n "Whether it was gratitude or just teasing, only she knew,"

translate english ch03_hstudio01_f6006962:

    n "but that single gesture set his heart on fire."

translate english ch03_hstudio01_275226b0:

    n "And in that moment, the awkwardness lingering since that incident quietly disappeared."

translate english ch03_hstudio01_2490b6bb:

    d "**(………)**"

translate english ch03_hstudio01_64d56e05:

    h "!!!!!!!!!!!"

translate english ch03_hstudio01_954a5009:

    h "**(Oh boy…)**"

translate english ch03_hstudio01_d2a101b2:

    h "Sorry, but I need to get back to work."

translate english ch03_hstudio01_f676edbc:

    h "I'd at least offer you some water, but we're in the middle of a shoot."

translate english ch03_hstudio01_c9301c84:

    d "It’s okay, don’t worry, hehe."

translate english ch03_hstudio01_8ca383e4:

    d "Since I’m out, I’ll just ride my bike a bit before heading home."

translate english ch03_hstudio01_ee226d8a:

    h "Alright, hehe."

translate english ch03_hstudio01_de165c2b:

    h "See you at home later."

translate english ch03_hstudio01_3d474fe3:

    d "Ah, um…"

translate english ch03_hstudio01_e6078263:

    h "Yeah?"

translate english ch03_hstudio01_c6c7804f:

    d "I…"

translate english ch03_hstudio01_50ea8f26:

    d "I’m curious what kind of work you do—would it be okay if I take a quick look?"

translate english ch03_hstudio01_ec173839:

    h "!!!!!!!!"

translate english ch03_hstudio01_84e8b6a1:

    h "Watch me work?"

translate english ch03_hstudio01_1a0cd8cd:

    h "Ah… um…"

translate english ch03_hstudio01_e69aef82:

    h "Maybe next time?"

translate english ch03_hstudio01_9d3e233c:

    h "Haha… you’ll get a chance next time…"

translate english ch03_hstudio01_d1999a76:

    h "Hehe, sorry. See you tonight."

translate english ch03_hstudio01_6adb8ea8:

    h "Be careful on your way, okay?"

translate english ch03_hstudio01_2dee3724:

    d "Hmm…"

translate english ch03_hstudio01_b27ab520:

    d "I probably shouldn't have pushed it."

translate english ch03_hstudio01_a797f6ce:

    d "………………"

translate english ch03_orph01_c97b5750:

    unknownf "Yeah, I think something was off with that part of the form."

translate english ch03_orph01_5b3df45e:

    unknownf "So I went ahead and fixed it myself."

translate english ch03_orph01_6b9347a5:

    c "Why would the agency make it like this…"

translate english ch03_orph01_ca2b780c:

    c "Looks like the person in charge made a mistake."

translate english ch03_orph01_6ff797fd:

    unknownf "Mary told us to check carefully when these come in—good thing we did."

translate english ch03_orph01_6191ad34:

    c "Phew… glad you caught it first."

translate english ch03_orph01_4e6521cd:

    c "If this had been submitted as-is, a lot of people would’ve been in trouble."

translate english ch03_orph01_3fee679f:

    c "You just saved our asses."

translate english ch03_orph01_f866ff1b:

    unknownf "Hahaha. Then you owe this hero a drink!"

translate english ch03_orph01_46d1bf99:

    unknownf "Or introduce me to a guy!!"

translate english ch03_orph01_1eb14311:

    c "Deal! I’ll treat our hero right, haha."

translate english ch03_orph01_a8444d2b:

    c "Looking forward to it, hehe."

translate english ch03_orph01_245e363a:

    unknownf "Then this hero’s heading back to work."

translate english ch03_orph01_607bcae1:

    c "Got it~ see you after work~"

translate english ch03_orph01_82946f36:

    c "……"

translate english ch03_orph01_51d8f599:

    c "Feels kinda humid today… maybe it’s gonna rain."

translate english ch03_orph01_0436a16b:

    c "I should clean up the director’s office.."

translate english ch03_orph01_018e12e5:

    n "Knock knock!"

translate english ch03_orph01_91cbbcd1:

    c "Is Mary not in the office…?"

translate english ch03_orph01_99ccb5d6:

    c "It’s kind of damp in here too."

translate english ch03_orph01_783e19b4:

    c "Hmm……"

translate english ch03_orph01_337b05a7:

    c "Something’s been off with Mary lately…"

translate english ch03_orph01_10f0d89d:

    c "I’m sure something happened with [d_name] that day."

translate english ch03_orph01_ce9e4c6e:

    c "I bet they were getting all handsy with each other..."

translate english ch03_orph01_c042d825:

    c "I’m certain."

translate english ch03_orph01_b971ee92:

    c "My gut is never wrong!"

translate english ch03_orph01_bcff35fb:

    c "Phew….."

translate english ch03_orph01_40eb8cb0:

    c "Really?...."

translate english ch03_orph01_da0dfe6e:

    c "What the fuck!!!!!!!!!!!!!!!"

translate english ch03_orph01_95e0f35f:

    c "What is this?"

translate english ch03_orph01_410c21b2:

    c "Oh my god, what is this!!"

translate english ch03_orph01_98072fb3:

    c "Is Mary really into this kind of stuff?"

translate english ch03_orph01_430cee5c:

    c "No, but still—how can she be looking at photos like this while working!!"

translate english ch03_orph01_f8e60475:

    c "Please tell me that's not Richard's.."

translate english ch03_orph01_274183ab:

    c "Ugh……"

translate english ch03_orph01_ff360cd9:

    c "I think I’m gonna throw up…"

translate english ch03_orph01_8940a541:

    c "My god, Mary…"

translate english ch03_orph01_f57467f2:

    c "You’ve been looking at this stuff at work?"

translate english ch03_orph01_85459249:

    c "What is this picture…"

translate english ch03_orph01_dedb043f:

    c "Sorry for snooping, Mary."

translate english ch03_orph01_31c11187:

    c "Ahhh!!!!!!!!!!!!!!!!!!"

translate english ch03_orph01_6fd5b57c:

    c "[d_name]???!!!!!"

translate english ch03_orph01_05255838:

    n "As Celine swiped, she was met with a photo of [d_name]—rock hard."

translate english ch03_orph01_1fb50712:

    n "The image was so shocking that she couldn’t even process it as real."

translate english ch03_orph01_b781f440:

    c "Oh my god."

translate english ch03_orph01_63ad5a36:

    c "What the hell are you doing there?"

translate english ch03_orph01_fc909186:

    c "Holy…"

translate english ch03_orph01_eb926c3b:

    c "What is going on?"

translate english ch03_orph01_8296ec35:

    c "My god, so that was it?"

translate english ch03_orph01_c3ab2f30:

    c "Ha… Mary…"

translate english ch03_orph01_f5e6338b:

    c "Ha… [d_name]…"

translate english ch03_orph01_a0a195c2:

    c "You guys were actually trading pics like this?"

translate english ch03_orph01_90e9baf9:

    c "Since when has this been going on…"

translate english ch03_orph01_cd08ffc5:

    c "…"

translate english ch03_orph01_df55e80c:

    c "……"

translate english ch03_orph01_690f5656:

    c "………"

translate english ch03_orph01_4911708a:

    c "Ugh, I feel sick…"

translate english ch03_orph01_8927b725:

    c "Ah!…"

translate english ch03_orph01_99e473fc:

    c "Ugh!!!"

translate english ch03_orph01_9130745f:

    c "Ouch!"

translate english ch03_orph01_f6f52f3e:

    c "Ahh………………"

translate english ch03_orph01_09acd5aa:

    c "Oh my god……"

translate english ch03_orph01_2d1b6167:

    c "How is that even possible? How can he be packing that much?"

translate english ch03_orph01_7f3f3b0e:

    c "Can something like that actually fit inside someone?"

translate english ch03_orph01_348880f5:

    c "Does it just look bigger because it was taken on a phone camera?"

translate english ch03_orph01_b237ee4f:

    c "It doesn't fit his face at all."

translate english ch03_orph01_2b552bc4:

    c "Was it AI-generated? These days anyone can make images…"

translate english ch03_orph01_b2c758cc:

    c "Dear god…"

translate english ch03_orph01_154e4fc5:

    c "………"

translate english ch03_orph01_8b376d95:

    c "How can someone with such an innocent face be hiding... THAT?"

translate english ch03_orph01_cc41487c:

    c "!!!!!!!!!!!!!!!!!!!!!!"

translate english ch03_orph01_7a2cbac6:

    m "Hey, Celine~"

translate english ch03_orph01_1230bc60:

    m "Oh, you’re cleaning up. Thank you."

translate english ch03_orph01_aa39261e:

    c "Ah, haha, yeah…"

translate english ch03_orph01_cdd913b8:

    c "I’m almost done."

translate english ch03_orph01_10113c75:

    c "I was just about to head out."

translate english ch03_orph01_e779f71b:

    c "It’s pretty humid today, haha."

translate english ch03_orph01_9ed0bbe1:

    c "**(Damn, this is bad.)**"

translate english ch03_orph01_3f7839dc:

    c "**(What do I do?!!)**"

translate english ch03_orph01_13f7f581:

    c "**(What do I do!!!!!)**"

translate english ch03_orph01_87a66035:

    c "**(Damn it!!)**"

translate english ch03_orph01_d43f5da1:

    c "**(Should I turn off the monitor? Where’s the power button?!!!!)**"

translate english ch03_orph01_ba5b7c06:

    c "**(Please just turn off already……)**"

translate english ch03_orph01_24c67c6c:

    c "**(Damn it, damn it!!)**"

translate english ch03_orph01_387380b4:

    m "You're the only one who takes care of me around here, Celine."

translate english ch03_orph01_4b1ab41d:

    m "Thank you."

translate english ch03_orph01_25f29761:

    c "Oh, and someone from the Milfheim Herald is coming to interview tomorrow."

translate english ch03_orph01_ad01a4fc:

    c "I’ll bring you the list of questions."

translate english ch03_orph01_61429d4f:

    c "And I’ll remind you again tomorrow morning."

translate english ch03_orph01_a5d009db:

    m "Ah, thanks. I almost forgot."

translate english ch03_orph01_076ea0c6:

    m "I need to nail this interview if I want to secure the funding."

translate english ch03_orph01_89fac563:

    m "They said my photo’s going in too—kind of embarrassing, haha."

translate english ch03_orph01_2a205d51:

    c "Yeah, hehe. Let me know if you need anything to prepare."

translate english ch03_orph01_c99871db:

    m "Will do."

translate english ch03_orph01_60f0b7f5:

    m "Thanks, Celine."

translate english ch03_orph01_bf6af0dc:

    c "Oh, and… nothing unusual going on lately, right?"

translate english ch03_orph01_ee35104c:

    m "Hm?"

translate english ch03_orph01_c44735df:

    c "Ah… you don’t seem to be in the best mood these days."

translate english ch03_orph01_da7d868b:

    m "Oh, really?"

translate english ch03_orph01_9500d4db:

    m "Maybe I’m just tired, haha."

translate english ch03_orph01_586321d7:

    m "Thanks for asking."

translate english ch03_orph01_70e84552:

    c "No problem."

translate english ch03_orph01_7969b79a:

    c "I’ll get going then."

translate english ch03_orph01_493515b8:

    m "Alright."

translate english ch03_orph01_949b9b42:

    c "**(Damn it, damn it, damn it)**"

translate english ch03_orph01_0529ace4:

    c "**(Did the monitor turn off??)**"

translate english ch03_orph01_949b9b42_1:

    c "**(Shit..shit..shit….)**"

translate english ch03_orph01_9e81208c:

    m "!!!!!!!!!"

translate english ch03_orph01_79578f1f:

    m "Oh my gosh... Ha..."

translate english ch03_orph01_0f53b249:

    m "My god……"

translate english ch03_orph01_ebf3e5fe:

    m "………………"

translate english ch03_orph01_6dd585b6:

    m "I’ve looked at these a dozen times, and I’m still not over it."

translate english ch03_orph01_2407bf99:

    m "Ha………"

translate english ch03_orph01_5f948287:

    m "What am I even doing looking at this in my office…"

translate english ch03_orph01_37bcb761:

    m "How am I supposed to prepare for the interview like this…"

translate english ch03_orph01_ec33384f:

    m "Since when did I become like this…"

translate english ch03_orph01_2407bf99_1:

    m "Ha………"

translate english ch03_orph01_c2764fba:

    m "[d_name], you naughty boy."

translate english ch03_orph01_88f6858c:

    m "What is he trying to do to me?"

translate english ch03_orph01_454742b6:

    m "…………"

translate english ch03_orph01_fe98de27:

    m "Something is happening to me…"

translate english ch03_orph01_78289683:

    m "I just can’t calm down..."

translate english ch03_orph01_06b5123e:

    c "………………"

translate english ch03_orph01_1dfb6520:

    c "Damn… did the monitor turn off?"

translate english ch03_orph01_d1d0932f:

    c "What do I even say if Mary asks?…"

translate english ch03_orph01_22ffc531:

    c "Should I just play dumb?"

translate english ch03_orph01_06b5123e_1:

    c "………………"

translate english ch03_police01_6236e1df:

    n "The phone rings."

translate english ch03_police01_8865cb81:

    unknownf "Yes, Chief."

translate english ch03_police01_4ff11e5d:

    unknownf "………………"

translate english ch03_police01_fae56461:

    unknownf "Yes, I’ve finished moving and stepped out for a bit."

translate english ch03_police01_4ff11e5d_1:

    unknownf "………………"

translate english ch03_police01_42ba234e:

    unknownf "But I’m not in uniform right now—I’m in workout clothes."

translate english ch03_police01_44fa9770:

    unknownf "Will that be alright?"

translate english ch03_police01_4ff11e5d_2:

    unknownf "………………"

translate english ch03_police01_f79cffc8:

    unknownf "Yes, understood."

translate english ch03_police01_5091b900:

    unknownf "I’ll see you shortly."

translate english ch03_police01_8c58cbd1:

    unknownf "………………"

translate english ch03_police01_e9ff7751:

    unknownf "Hmm…"

translate english ch03_police01_430b342f:

    unknownf "Hmph…"

translate english ch03_police01_b41ca9a4:

    unknownf "I’ve had a few days off, and now this—kind of annoying…"

translate english ch03_police01_7a1f7c2b:

    unknownf "Haven’t even officially started yet, and already… tch."

translate english ch03_police01_17eea6a4:

    unknownf "………………"

translate english ch03_police01_3845aad2:

    unknownf "Still, first time heading into the office dressed like this."

translate english ch03_police01_8287f611:

    unknownf "**(Hmm……)**"

translate english ch03_police01_27ba3c4c:

    unknownf "**(The station’s bigger than I expected…)**"

translate english ch03_police01_9ce53a3f:

    unknownf "**(But where’s the chief’s office?)**"

translate english ch03_police01_bbd12690:

    unknownf "Thank you."

translate english ch03_police01_5a5c9fec:

    n "Knock knock."

translate english ch03_police01_d2e2b190:

    chi "Come in."

translate english ch03_police01_e73f1adf:

    unknownf "Ahem."

translate english ch03_police01_9ec12103:

    unknownf "Good afternoon, Chief."

translate english ch03_police01_47b8f823:

    unknownf "It’s a pleasure to meet you."

translate english ch03_police01_a1d17b58:

    chi "Ah, come in."

translate english ch03_police01_c86b5eaf:

    chi "Thanks for coming on such short notice."

translate english ch03_police01_fa02ad56:

    unknownf "The pleasure is mine, sir."

translate english ch03_police01_5fc378ac:

    chi "Sorry for calling you in on your day off, Lieutenant Morgan."

translate english ch03_police01_2f497e32:

    chi "I’ll be away starting tomorrow, so I had to meet you today."

translate english ch03_police01_961588bf:

    n "As the chief greeted Diana, he suddenly paused."

translate english ch03_police01_7c10e03f:

    n "His gaze drifted toward her breasts."

translate english ch03_police01_46437f56:

    di "………"

translate english ch03_police01_7665e6e4:

    di "**(You’ve got to be kidding me…)**"

translate english ch03_police01_5a30a847:

    di "**(Seriously… when are these old-school cops going to learn some manners…)**"

translate english ch03_police01_06290d78:

    di "Apologies for my attire."

translate english ch03_police01_138bc734:

    chi "No, no. Don’t worry about it."

translate english ch03_police01_73cf16b4:

    chi "Have a seat."

translate english ch03_police01_8529014d:

    di "Thank you."

translate english ch03_police01_9cb8474a:

    n "The chief looked through the documents in front of her."

translate english ch03_police01_39705de4:

    n "After an uncomfortably long silence, he finally spoke."

translate english ch03_police01_80d1e5e3:

    chi "Your record with the Rosenford Violent Crimes Unit is quite impressive."

translate english ch03_police01_db59204d:

    chi "It’s impressive that you’ve closed nearly every case assigned to you."

translate english ch03_police01_54a82a54:

    chi "We don’t have many detectives that driven out here."

translate english ch03_police01_9c15b7f6:

    di "Thank you, sir."

translate english ch03_police01_951b1753:

    di "But most of those results were a team effort."

translate english ch03_police01_ded3943a:

    di "And honestly, I had a fair bit of luck on my side for a few of those cases."

translate english ch03_police01_cd7a43a0:

    chi "Is that so?"

translate english ch03_police01_86567897:

    chi "Hmm……"

translate english ch03_police01_20acab9a:

    chi "This isn’t a job interview, so feel free to speak openly."

translate english ch03_police01_7d9cfe40:

    chi "Well…"

translate english ch03_police01_7302aaf1:

    chi "As you may have heard, violent crime in this area has been rising sharply."

translate english ch03_police01_07589f71:

    chi "At an almost insane rate."

translate english ch03_police01_a11e42ca:

    chi "Frankly, we just don’t have the manpower to keep up."

translate english ch03_police01_ee3b528c:

    chi "As a result, public dissatisfaction is growing."

translate english ch03_police01_8839fdcb:

    chi "Your predecessor… had some mental difficulties and left the force rather suddenly."

translate english ch03_police01_ebe081ff:

    chi "So I personally requested help from the Rosenford chief—an old friend of mine."

translate english ch03_police01_ae352b4f:

    chi "That’s why you and several others were sent here."

translate english ch03_police01_7458f30a:

    chi "Don’t hold it against me."

translate english ch03_police01_a928e528:

    chi "In return, once your term as team lead ends, I’ll make sure you get a better posting."

translate english ch03_police01_8cc3e705:

    di "I see."

translate english ch03_police01_2cbd44f0:

    di "………………"

translate english ch03_police01_d8df8f8a:

    di "That puts a lot on my shoulders."

translate english ch03_police01_a5483ead:

    chi "Sorry for putting it like that right away."

translate english ch03_police01_a784a2bd:

    chi "Please share your experience and investigative skills with the detectives here—don’t take it as pressure."

translate english ch03_police01_aebced92:

    di "Not at all. It’s fine."

translate english ch03_police01_96e31a56:

    di "I’ll do my best."

translate english ch03_police01_d93cc07f:

    di "I’ll focus on carrying out the responsibilities given to me."

translate english ch03_police01_72c1a68d:

    chi "………………"

translate english ch03_police01_fe5c50f7:

    chi "Good. Do your best for the citizens here."

translate english ch03_police01_1c5109a0:

    di "**(Sigh………………)**"

translate english ch03_police01_1a0a0725:

    di "**(Men are really something.)**"

translate english ch03_police01_41549101:

    di "**(Talking about rising crime one second, staring at my breasts the next?)**"

translate english ch03_police01_d87f1b5d:

    di "**(Think I wouldn’t notice just because they keep a straight face?)**"

translate english ch03_police01_4fb11e94:

    di "……"

translate english ch03_police01_65e23f24:

    di "Ahem…"

translate english ch03_police01_cc4dc87a:

    chi "Oh, and I hear you live alone?"

translate english ch03_police01_7c0a6601:

    di "………………"

translate english ch03_police01_9280e502:

    di "Yes, that’s correct."

translate english ch03_police01_36d1bd3e:

    chi "If you don’t mind me asking—are you divorced?"

translate english ch03_police01_c96f5c39:

    chi "May I ask why?"

translate english ch03_police01_2cd6aaa4:

    chi "It’s work-related, so I hope you understand."

translate english ch03_police01_a5a7d299:

    di "Well…"

translate english ch03_police01_7a3efca6:

    di "I got married early in my career, but I couldn’t balance both police work and family life."

translate english ch03_police01_2ecc3ba3:

    di "Living alone has allowed me to focus better on the job."

translate english ch03_police01_97bd6038:

    di "………………"

translate english ch03_police01_9c08ec77:

    chi "I see."

translate english ch03_police01_8aa7154c:

    chi "Your sense of duty is admirable."

translate english ch03_police01_6d73d04e:

    chi "I can’t imagine how difficult it must have been to stay in Major Crimes as a woman."

translate english ch03_police01_f02e66b2:

    chi "In any case, while you’re here, treat this city like your hometown and give it your all."

translate english ch03_police01_baf6d916:

    di "Understood."

translate english ch03_police01_d0603fa4:

    chi "Then shall we head over?"

translate english ch03_police01_ea85cbc8:

    chi "I’ll show you your office."

translate english ch03_police01_276e876b:

    chi "Your predecessor didn’t have a private office, but I arranged one especially for you."

translate english ch03_police01_61d85b14:

    di "Thank you. I appreciate it."

translate english ch03_police01_2f25ea7b:

    n "Diana was used to being surrounded by male colleagues."

translate english ch03_police01_4ff227a5:

    n "Throughout her career, she had fought not only crime, but also the stares and dismissive attitudes of fellow officers."

translate english ch03_police01_7e8ecd15:

    n "That environment only pushed her to focus more intensely on her work."

translate english ch03_police01_ce41cb0d:

    n "Whether the chief stared at her body or not didn’t matter—all that mattered to her was solving cases."

translate english ch03_police01_84f5d0c9:

    di "**(Damn… I’m way too conscious of these clothes.)**"

translate english ch03_police01_bb5af471:

    di "**(Anyone seeing me would think I got arrested.)**"

translate english ch03_police01_b2dbb5b1:

    di "**(Hmm… is this my office?)**"

translate english ch03_police01_cbd6d3a0:

    chi "This is it."

translate english ch03_police01_89485d5f:

    chi "This is where you’ll be working from now on."

translate english ch03_police01_419c0b59:

    n "The chief’s tone and demeanor had noticeably softened compared to when they first met 20 minutes ago."

translate english ch03_police01_831c7d54:

    chi "Well, police offices are bleak no matter where you go, haha."

translate english ch03_police01_bbf3e919:

    di "I’m used to it now, haha."

translate english ch03_police01_d925e04e:

    di "Still, it’s cleaner than I expected."

translate english ch03_police01_e725bf67:

    chi "I’ll be away for a few days starting tomorrow for a conference, so I had no choice but to call you in today."

translate english ch03_police01_7b00f3d4:

    chi "Ah—guess I already mentioned that."

translate english ch03_police01_73d8c34f:

    chi "Anyway, sorry again for bringing you in on your day off."

translate english ch03_police01_c1e7481e:

    chi "I’ll be heading out now, so take a look around and make yourself familiar."

translate english ch03_police01_baf6d916_1:

    di "Yes, understood."

translate english ch03_police01_08d06086:

    di "I’ll report to you when you return."

translate english ch03_police01_5f55c258:

    di "Thank you for showing me around personally."

translate english ch03_police01_9376b04a:

    chi "Good."

translate english ch03_police01_1e568755:

    di "………"

translate english ch03_police01_4f2540f0:

    chi "Feels reassuring to have such a capable subordinate."

translate english ch03_police01_064c16e9:

    chi "We’ll talk again once I’m back."

translate english ch03_police01_1e568755_1:

    di "………"

translate english ch03_police01_e74bba22:

    di "“A capable subordinate,” huh…"

translate english ch03_police01_7ad3e910:

    n "She had been assigned here from the state capital, Rosenford, with no real say in the matter."

translate english ch03_police01_b89add24:

    n "Unable to accept it at first, Diana even considered leaving the force, but eventually came to terms with it."

translate english ch03_police01_4e3c84be:

    n "As long as she was a cop, where she lived didn’t matter."

translate english ch03_police01_71a740c3:

    n "Her sense of justice and drive for investigation weren’t something even she could suppress."

translate english ch03_police01_3d21835a:

    n "Touching the desk that would now be hers, she steadied her resolve."

translate english ch03_police01_f3bf555e:

    di "………"

translate english ch03_police01_b8f939ca:

    di "So this is my place now…"

translate english ch03_police01_473c5295:

    di "Hmm…"

translate english ch03_police01_5d650bec:

    di "Not bad for a rural town."

translate english ch03_police01_94a7c649:

    di "There’s a station and a gym—that’s good enough."

translate english ch03_police01_433e4434:

    di "What’s in here?"

translate english ch03_police01_e8d52cd3:

    di "Nothing, huh."

translate english ch03_police01_3a911f58:

    di "But my instincts tell me there’s something here."

translate english ch03_police01_73555774:

    di "!!"

translate english ch03_police01_2b63cd22:

    di "Bingo!"

translate english ch03_police01_187de950:

    di "Huh? What kind of file is this?"

translate english ch03_police01_81ea6b25:

    di "What is it? A case file?"

translate english ch03_police01_473c5295_1:

    di "Hmm…"

translate english ch03_police01_d8f055ba:

    n "Inside her desk drawer, a single file had been left behind."

translate english ch03_police01_31824766:

    di "What is this document?"

translate english ch03_police01_21b93175:

    di "Did the previous team lead drop this and forget it?"

translate english ch03_police01_6e553f03:

    n "Inside were several documents, a two-dollar bill, and a handwritten note."

translate english ch03_police01_27999aed:

    di "What is this…"

translate english ch03_police01_168751d3:

    di "“To Detective Edward?”"

translate english ch03_police01_46437f56_1:

    di "………"

translate english ch03_police01_4fb11e94_1:

    di "…"

translate english ch03_police01_b298cd17:

    di "Looks like some kind of report—was the investigation never done?"

translate english ch03_police01_ac1ede5b:

    di "Hmm…………"

translate english ch03_police01_23888dfa:

    di "Is this some new way to screw over the new team leader?"

translate english ch03_police01_e90e2b06:

    di "Hmm………"

translate english ch03_police01_307bbc55:

    di "AAAE?"

translate english ch03_police01_7f6720cb:

    di "This looks like financial records—why is this in Major Crimes?"

translate english ch03_police01_0a52e6ce:

    di "………………"

translate english ch03_hhouse01_ada422ca:

    h "Haha, can you believe that?"

translate english ch03_hhouse01_916d51ae:

    h "That guy must be so embarrassed."

translate english ch03_hhouse01_5a9c2b4d:

    d "Right?"

translate english ch03_hhouse01_e39588ab:

    d "If that were me, I'd have hauled ass out of there and never looked back, haha."

translate english ch03_hhouse01_9241e403:

    d "Oh, I think my phone’s ringing."

translate english ch03_hhouse01_4358220b:

    d "**(Damn, why now…)**"

translate english ch03_hhouse01_6f5bddc1:

    d "**(The mood was so perfect, too..)**"

translate english ch03_hhouse01_a4dd6c4f:

    d "Who is it? Jason?"

translate english ch03_hhouse01_5659593d:

    d "Oh—it’s Mary!"

translate english ch03_hhouse01_31b37dad:

    d "Hello, Mary."

translate english ch03_hhouse01_5eb469aa:

    d "How have you been? haha."

translate english ch03_hhouse01_e984c19c:

    m "I’ve been well."

translate english ch03_hhouse01_361d8a0f:

    m "How've you been? Are you eating okay?"

translate english ch03_hhouse01_92f9b07b:

    d "Yes, I’ve been eating well, haha."

translate english ch03_hhouse01_4135345c:

    d "I’ve been doing fine."

translate english ch03_hhouse01_2a8b4f6f:

    d "I’m finally settling in. Getting the hang of the neighborhood and my new place."

translate english ch03_hhouse01_82091250:

    m "That’s good to hear."

translate english ch03_hhouse01_c8dbf7fd:

    m "You sound full of energy!"

translate english ch03_hhouse01_bfe1e4ea:

    n "After a brief pause, Mary spoke again, her voice slightly subdued."

translate english ch03_hhouse01_cfd88d97:

    m "Um… you know…"

translate english ch03_hhouse01_5a25f253:

    m "Do you have some time tomorrow morning?"

translate english ch03_hhouse01_0a14a862:

    m "I wanted to talk about that internship we discussed."

translate english ch03_hhouse01_80adb125:

    m "………………"

translate english ch03_hhouse01_49b468f2:

    m "I’d like you to come by the center."

translate english ch03_hhouse01_ce49a1c2:

    d "Of course! I can definitely come."

translate english ch03_hhouse01_c6c2afde:

    m "Good, that’s great!"

translate english ch03_hhouse01_462eda2a:

    m "And…"

translate english ch03_hhouse01_9dfba753:

    m "Well…"

translate english ch03_hhouse01_643d278e:

    m "We have that... other thing to talk about too, don't we?"

translate english ch03_hhouse01_08d8b3ee:

    n "The moment [d_name] had been waiting for—and at the same time dreading—was approaching."

translate english ch03_hhouse01_1a3c7a64:

    n "Memories of what he’d done came flooding back."

translate english ch03_hhouse01_7c0a9214:

    d "………………"

translate english ch03_hhouse01_193f19d5:

    d "Yes, Mary. I remember."

translate english ch03_hhouse01_2bebcc34:

    m "Alright…"

translate english ch03_hhouse01_d1d93bfb:

    m "Then come by the center tomorrow morning, honey."

translate english ch03_hhouse01_9c80e7d1:

    d "Yes, I will. I’ll be there in the morning."

translate english ch03_hhouse01_1f29a2dd:

    m "Okay."

translate english ch03_hhouse01_1d30377c:

    m "See you tomorrow."

translate english ch03_hhouse01_5d7e331d:

    d "Have a good night."

translate english ch03_hhouse01_48506fd0:

    d "Bye."

translate english ch03_hhouse01_1aefa8b4:

    m "………………"

translate english ch03_hhouse01_8af6ecea:

    m "Ha………"

translate english ch03_hhouse01_510a5999:

    d "Ha…"

translate english ch03_hhouse01_8bf3accd:

    d "Should I be terrified or excited?"

translate english ch03_hhouse01_a342b9fd:

    d "Now that I'm actually facing the music, the nerves are kicking in."

translate english ch03_hhouse01_9dcbc9b8:

    n "When he stepped into the living room after the call, [h_name] was gone."

translate english ch03_hhouse01_ef3f5b8c:

    d "**(Did she go to her room?)**"

translate english ch03_hhouse01_98c438d3:

    d "**(She was drinking… maybe she got tired and went in.)**"

translate english ch03_hhouse01_48cdaa05:

    d "**(That’s a shame… I was hoping to catch more of that show with her.)**"

translate english ch03_hhouse01_f11d7c4c:

    d "**(Damn... am I becoming a total voyeur or what?)**"

translate english ch03_hhouse01_6fc84faa:

    d "**(Was one of my ancestors a cat burglar?… why do I keep doing this…)**"

translate english ch03_hhouse01_4c0bc9dc:

    d "!!"

translate english ch03_hhouse01_fdc5deee:

    n "When he peeked into [h_name]’s room, she was standing by the window, staring out at the rain."

translate english ch03_hhouse01_a5413c70:

    n "It was a stark contrast to the cheerful [h_name] from just moments ago when they were watching TV together."

translate english ch03_hhouse01_50fc2eaa:

    h "Ha………"

translate english ch03_hhouse01_897a3944:

    h "The rain’s really coming down…"

translate english ch03_hhouse01_3f9a24db:

    h "………………"

translate english ch03_hhouse01_ea984093:

    h "I wish this rain could just clear my head."

translate english ch03_hhouse01_f46e5e1a:

    h "All the things cluttering my mind…"

translate english ch03_hhouse01_f9ad8e76:

    h "Why have I been thinking so much lately…"

translate english ch03_hhouse01_781f9fd3:

    h "………"

translate english ch03_hhouse01_aa72e519:

    h "Is this just midlife crisis hitting early, or what?"

translate english ch03_hcar01_e5c36b54:

    d "………"

translate english ch03_hcar01_89928173:

    d "Morning, [h_name]."

translate english ch03_hcar01_b212af6a:

    h "Good morning, [d_name]."

translate english ch03_hcar01_0129d72c:

    h "Heading out today?"

translate english ch03_hcar01_cef02cc4:

    d "Yeah, I’ve got something to take care of, so I’m heading to the youth center."

translate english ch03_hcar01_5ab7eca5:

    h "Really? In this rain?"

translate english ch03_hcar01_428f9d00:

    h "You think you’ll be okay?"

translate english ch03_hcar01_175b6b78:

    d "I don’t really have a choice."

translate english ch03_hcar01_ab056197:

    d "I'll just grab an umbrella, or maybe call a cab."

translate english ch03_hcar01_781f9fd3:

    h "…………"

translate english ch03_hcar01_0fade7df:

    h "No… a bike’s definitely not an option…"

translate english ch03_hcar01_3f3eec62:

    h "Besides, good luck getting a cab out here. It’ll take an hour, at least."

translate english ch03_hcar01_75121f1e:

    h "Hmm…"

translate english ch03_hcar01_8507f73b:

    h "Alright. I’ll give you a ride."

translate english ch03_hcar01_59a62b40:

    h "It’s not that far, so let’s take my car."

translate english ch03_hcar01_6986c7ff:

    d "Oh, really…?"

translate english ch03_hcar01_94caef26:

    d "I don't want to be a bother..."

translate english ch03_hcar01_5551fbe8:

    h "It’s fine."

translate english ch03_hcar01_d0470717:

    h "Come on."

translate english ch03_hcar01_56cd93f9:

    d "Thank you so much!!"

translate english ch03_hcar01_0f5dccb5:

    h "Don’t mention it."

translate english ch03_hcar01_9cae4c67:

    d "Thanks for the lift. I really owe you one, especially with this weather."

translate english ch03_hcar01_23c1e70f:

    h "Haha, it’s nothing."

translate english ch03_hcar01_081ca1df:

    h "No one goes out in weather like this without a ride, haha."

translate english ch03_hcar01_22ec06d2:

    h "Come to think of it, this is our first time going somewhere together like this."

translate english ch03_hcar01_13d92891:

    d "Haha, yeah."

translate english ch03_hcar01_cfcbd30a:

    h "Let’s grab a meal together sometime."

translate english ch03_hcar01_d869127c:

    h "I’m getting a little sick of my own cooking, to be honest, haha."

translate english ch03_hcar01_690b3563:

    d "Sounds great!!"

translate english ch03_hcar01_5951775e:

    d "I really enjoy your cooking, [h_name], haha."

translate english ch03_hcar01_8a3d597b:

    d "I think I’ve been eating better than ever lately."

translate english ch03_hcar01_4571109b:

    h "Stop, you're making me blush."

translate english ch03_hcar01_97d86295:

    h "My kids used to beg to eat out every day, haha."

translate english ch03_hcar01_8691fd11:

    d "………….."

translate english ch03_hcar01_f0768f32:

    h "…………"

translate english ch03_hcar01_45238507:

    d "Hey, [h_name]…"

translate english ch03_hcar01_c4e343e6:

    d "Can I ask you something?"

translate english ch03_hcar01_c28c1f11:

    h "Of course."

translate english ch03_hcar01_327f7d59:

    h "I thought we were past the point of having to ask permission, haha."

translate english ch03_hcar01_880d2657:

    h "What is it?"

translate english ch03_hcar01_3f9ecd42:

    d "Um…"

translate english ch03_hcar01_9097d142:

    d "About that photo by the front door…"

translate english ch03_hcar01_5e0e21b7:

    d "The one of you and that young guy…"

translate english ch03_hcar01_c93886dd:

    d "Is he your son?"

translate english ch03_hcar01_aa34b01a:

    h "!!"

translate english ch03_hcar01_d930f0f5:

    n "The question caught her completely off guard."

translate english ch03_hcar01_9c81f920:

    n "For a moment, it felt like a sharp pang of emotion struck her deep in her chest."

translate english ch03_hcar01_fd587bab:

    h "…………"

translate english ch03_hcar01_a91f1ca2:

    h "Yeah. He’s my son."

translate english ch03_hcar01_bb0bfe8e:

    d "I see."

translate english ch03_hcar01_cf114d19:

    d "Then when does he come home?"

translate english ch03_hcar01_5e3aec4e:

    d "………"

translate english ch03_hcar01_b09e7b13:

    h "Well…"

translate english ch03_hcar01_516e4ded:

    h "He studied abroad and ended up staying there."

translate english ch03_hcar01_19d62004:

    h "It’s been a few years since I last saw him."

translate english ch03_hcar01_fac8215b:

    d "…………"

translate english ch03_hcar01_33e46275:

    d "I see…"

translate english ch03_hcar01_6bb600d1:

    d "You must miss him a lot."

translate english ch03_hcar01_bbb2807e:

    h "Heh…"

translate english ch03_hcar01_774764c4:

    h "Of course. What kind of mother wouldn’t miss her son?"

translate english ch03_hcar01_12cd8daf:

    d "Um…"

translate english ch03_hcar01_341acc45:

    d "This might come off a bit weird..."

translate english ch03_hcar01_102c5913:

    d "**(Shit... maybe I should just keep my mouth shut.)**"

translate english ch03_hcar01_a38cbe68:

    d "**(What if this comes out wrong again…)**"

translate english ch03_hcar01_a9861e1d:

    d "……………."

translate english ch03_hcar01_c47885a4:

    d "It’s just... sometimes when I see you alone, you have this look on your face. Like you're lonely."

translate english ch03_hcar01_73e74603:

    d "I mean… well… never mind, haha."

translate english ch03_hcar01_fce15775:

    d "It’s nothing serious—just how it feels to me, so don’t take it too seriously, haha."

translate english ch03_hcar01_7caf97d7:

    h "…………"

translate english ch03_hcar01_f0af7cbb:

    d "I’m sorry…"

translate english ch03_hcar01_2545b046:

    d "I shouldn’t have said that. It was just how I felt."

translate english ch03_hcar01_bddce7f7:

    d "I didn’t mean to overstep. I’m sorry."

translate english ch03_hcar01_5551fbe8_1:

    h "It’s okay."

translate english ch03_hcar01_864f5f28:

    h "Don’t worry about it."

translate english ch03_hcar01_2621f598:

    h "I didn’t realize you were watching me that closely, [d_name], haha."

translate english ch03_hcar01_eaafb03c:

    h "I guess I’ll have to watch my step around you, hehe."

translate english ch03_hcar01_1fbb49b9:

    d "You don’t have to do that because of me."

translate english ch03_hcar01_ea7438a3:

    d "I just… well…"

translate english ch03_hcar01_c072b6a6:

    d "This might sound strange…"

translate english ch03_hcar01_8b13da87:

    d "We haven’t known each other that long, but the fact that we're living together like this... I feel like it's fate."

translate english ch03_hcar01_ca437682:

    d "You know….."

translate english ch03_hcar01_924f5e73:

    d "How big the world is… how many people there are…"

translate english ch03_hcar01_03393c29:

    d "So what I'm trying to say…."

translate english ch03_hcar01_e851ab50:

    d "I just want to be someone you can lean on, even if it's just a little bit."

translate english ch03_hcar01_74d4c020:

    d "I think that would make me happy…"

translate english ch03_hcar01_5ba00dc4:

    n "She found what he said kind of cute."

translate english ch03_hcar01_0636f610:

    n "She sometimes thought he said things like that just to lift her mood,"

translate english ch03_hcar01_e3dee732:

    n "But this time, his words felt like a gentle knock on the door to her heart."

translate english ch03_hcar01_b3968dea:

    h "Hmm…"

translate english ch03_hcar01_80922ef8:

    h "I’m not exactly sure what you mean by that…"

translate english ch03_hcar01_1422cb28:

    h "but you’re already a big help to me."

translate english ch03_hcar01_fd318357:

    h "Really, you are. You’ve helped me a lot already."

translate english ch03_hcar01_b9d88584:

    h "I had second thoughts about renting out the room."

translate english ch03_hcar01_424d1ffb:

    h "but now I think it was the right decision."

translate english ch03_orph02_37222bb8:

    h "Oh, so this is the place."

translate english ch03_orph02_f318543d:

    d "Yeah, haha."

translate english ch03_orph02_4b6748ac:

    d "Thank you again for the ride."

translate english ch03_orph02_e3cec93b:

    d "Drive safe—it’s really pouring out there."

translate english ch03_orph02_184be849:

    h "Yeah, hehe, thanks."

translate english ch03_orph02_8df164e8:

    h "Take care."

translate english ch03_orph02_fda5bc47:

    h "And on your way back, I’ll give you some money, so just take a taxi, okay?"

translate english ch03_orph02_30c7412f:

    d "No, it’s fine. You don’t have to do that, haha."

translate english ch03_orph02_5c073508:

    d "I’ll make it back on my own."

translate english ch03_orph02_6e12afe6:

    h "Alright, do whatever you’re comfortable with."

translate english ch03_orph02_a7639de9:

    h "If anything happens, call me."

translate english ch03_orph02_da309b8b:

    h "And don't go acting all tough just to impress me, okay?"

translate english ch03_orph02_f14c2af7:

    d "Yeah, I will. Thank you."

translate english ch03_orph02_e5c36b54:

    d "………"

translate english ch03_orph02_152b786f:

    d "You’re an incredible woman, [h_name]."

translate english ch03_orph02_ddccd99e:

    d "And…"

translate english ch03_orph02_15aab929:

    d "**(No, damn it… stop with the pathetic delusions...)**"

translate english ch03_orph02_4ee52a24:

    d "Hey, Celine."

translate english ch03_orph02_e61aff80:

    c "!!!!!!!"

translate english ch03_orph02_1f0d7ccf:

    d "Hey, how’ve you been?"

translate english ch03_orph02_ffa96798:

    c "Oh… hi, [d_name]."

translate english ch03_orph02_cdcfa620:

    c "That was kinda… sudden, haha."

translate english ch03_orph02_55f0b476:

    d "Sudden? What, am I banned from the premises or something?"

translate english ch03_orph02_89e006fa:

    d "Since when did you get so bashful around me?"

translate english ch03_orph02_e162d6af:

    c "Um… have you been well?"

translate english ch03_orph02_b77ee41a:

    c "………"

translate english ch03_orph02_6a21657e:

    d "…………"

translate english ch03_orph02_1a40d8a7:

    d "Are you okay, Celine?"

translate english ch03_orph02_f24b3cf5:

    d "You don’t look so good."

translate english ch03_orph02_2afb20d2:

    d "Your face looks kinda red."

translate english ch03_orph02_cf59a287:

    c "Ah… no, it’s nothing…"

translate english ch03_orph02_1407fef1:

    c "It's just the humidity... I'm a bit flushed, haha."

translate english ch03_orph02_4357fa63:

    c "You should go see Mary."

translate english ch03_orph02_f285396c:

    c "She’s probably waiting for you."

translate english ch03_orph02_fbec1391:

    c "She was really worried since she asked you to come out in this rain."

translate english ch03_orph02_e5c36b54_1:

    d "………"

translate english ch03_orph02_9ece09c9:

    d "Alright, got it. See you later."

translate english ch03_orph02_fe13be21:

    c "Ha…………"

translate english ch03_orph02_09faaf90:

    c "Damn it, what do I do?"

translate english ch03_orph02_69325475:

    c "I can’t get it out of my head!!"

translate english ch03_orph02_8962033d:

    d "Celine’s acting weird… why is she being so awkward with me?"

translate english ch03_orph02_74616a36:

    d "Hmm……"

translate english ch03_orph02_1c597f9d:

    d "Even that text the other day felt off… something’s weird…"

translate english ch03_orph02_e8885bcd:

    d "I mean, we're practically family. Why the cold shoulder?"

translate english ch03_orph02_add4998f:

    n "Knock knock."

translate english ch03_orph02_85fc347d:

    d "Morning, Mary."

translate english ch03_orph02_ec11fd40:

    m "Morning, honey."

translate english ch03_orph02_b9d75c3a:

    m "Sorry—I wouldn’t have called you in if I knew it’d rain this hard."

translate english ch03_orph02_3dd279f4:

    d "Ah… no, it’s fine. My landlady gave me a ride."

translate english ch03_orph02_5a2cebf5:

    n "When the door opened, Mary was wearing a top that left very little to the imagination."

translate english ch03_orph02_74e10822:

    n "It was the first time [d_name] had seen her like that."

translate english ch03_orph02_07cc5ad1:

    c "………"

translate english ch03_orph02_8796aae0:

    c "Ha……"

translate english ch03_orph02_7b65f654:

    c "Is my period starting…? I feel so heavy today…"

translate english ch03_orph02_07cc5ad1_1:

    c "………"

translate english ch03_orph02_bd623111:

    m "The interview’s been scheduled—it’s in two days."

translate english ch03_orph02_0a1b601e:

    m "You’ll get a call later today, or tomorrow at the latest."

translate english ch03_orph02_cb40fca8:

    m "Even if it’s from an unknown number, make sure you answer, okay?"

translate english ch03_orph02_128467d9:

    d "Yes, understood. Thank you, Mary."

translate english ch03_orph02_7594098d:

    d "I won't make you look bad. I'll nail that interview."

translate english ch03_orph02_25051320:

    m "Yeah…"

translate english ch03_orph02_afbdd17f:

    m "If I had to give you a hint, the job’s about reviewing customer feedback and market reactions, then figuring out what needs improvement."

translate english ch03_orph02_09c4b710:

    m "Since you’re studying psychology, it should suit you well."

translate english ch03_orph02_13f4dd4c:

    d "Oh, then I might actually be good at it."

translate english ch03_orph02_a3a45f70:

    d "I’m looking forward to it."

translate english ch03_orph02_112fb23f:

    m "Yeah…"

translate english ch03_orph02_4b86e838:

    m "Don't get a big head, now, haha."

translate english ch03_orph02_18548549:

    m "………"

translate english ch03_orph02_82fedef2:

    d "Got it."

translate english ch03_orph02_fa1c4b06:

    d "You probably had to go out of your way to help me, so I'll give it my all."

translate english ch03_orph02_d1c91243:

    m "Good, that makes me feel better."

translate english ch03_orph02_b7b4e0b6:

    m "Another tip—the interviewer… hmm…"

translate english ch03_orph02_69a560d5:

    m "She can be a bit intense at first, but it's just a front."

translate english ch03_orph02_8c06c713:

    m "Just think of it like you’re talking to me and speak naturally about yourself."

translate english ch03_orph02_d9b03462:

    m "Being honest and genuine is the most important thing in an interview."

translate english ch03_orph02_42033618:

    d "Haha, I’ll do that."

translate english ch03_orph02_2537a267:

    n "[d_name] sat across from Mary, but none of her voice was just background noise to him."

translate english ch03_orph02_8c9c4d92:

    n "His mind was stuck on images of her, completely undressed."

translate english ch03_orph02_d9a0ae4c:

    d "By the way, it’s kinda hot in here, isn’t it?"

translate english ch03_orph02_8ee367dd:

    m "Right? The AC isn’t great."

translate english ch03_orph02_8caada33:

    m "I’m a bit hot too."

translate english ch03_orph02_659850ce:

    m "I’ll take my jacket off."

translate english ch03_orph02_a254b6d4:

    d "!!!!!"

translate english ch03_orph02_1368db53:

    d "Wow… Mary…"

translate english ch03_orph02_c2ca3cc3:

    d "I’ve never seen you dressed like that before…"

translate english ch03_orph02_de8c9c36:

    m "Hahaha."

translate english ch03_orph02_47aea857:

    m "What do you think? Does it look good?"

translate english ch03_orph02_2292fe40:

    d "Yeah…"

translate english ch03_orph02_79994cf5:

    d "You… you look beautiful, Mary."

translate english ch03_orph02_ac3b245e:

    m "Haha, thanks, [d_name]."

translate english ch03_orph02_3c95fb0f:

    m "Richard was giving me a hard time, asking who I was trying to impress, haha."

translate english ch03_orph02_40037183:

    m "Ahem…"

translate english ch03_orph02_353278e2:

    m "Anyway…"

translate english ch03_orph02_5e3aec4e:

    d "………"

translate english ch03_orph02_1d794087:

    m "………………"

translate english ch03_orph02_89a6eb71:

    n "An awkward silence fell between them again."

translate english ch03_orph02_c91f7f95:

    n "They both knew what they wanted to say, but neither of them spoke."

translate english ch03_orph02_5e3aec4e_1:

    d "………"

translate english ch03_orph02_ebf3e5fe:

    m "…………"

translate english ch03_orph02_ec0fff4b:

    d "Hey, Mary…"

translate english ch03_orph02_17426ef1:

    d "About those... junk shots I sent you."

translate english ch03_orph02_3b2dce22:

    d "You know… those pictures of my dick…."

translate english ch03_orph02_29a4f6ab:

    m "!!!"

translate english ch03_orph02_d2cd6414:

    m "Ha…………"

translate english ch03_orph02_08c6a40b:

    n "Mary stared out the window in silence for a long time."

translate english ch03_orph02_501f8766:

    n "An awkward silence filled her office."

translate english ch03_orph02_42622613:

    n "After a long pause, she finally spoke."

translate english ch03_orph02_a153444b:

    m "Why would you do something like that, [d_name]…"

translate english ch03_orph02_e34687c2:

    m "What did you expect me to do after seeing that?"

translate english ch03_orph02_64379c54:

    m "Do you have any idea how shocked I was?"

translate english ch03_orph02_bff31cc9:

    m "Richard was right there with me."

translate english ch03_orph02_4d8b50ce:

    m "God…"

translate english ch03_orph02_f802d487:

    m "………………"

translate english ch03_orph02_77873a85:

    m "I can't believe you had the balls to..."

translate english ch03_orph02_edbb7d05:

    d "……"

translate english ch03_orph02_81cd8613:

    d "I’m sorry, Mary."

translate english ch03_orph02_37d9c684:

    d "That night… I just... lost my head that night."

translate english ch03_orph02_8691fd11:

    d "………………"

translate english ch03_orph02_2e42abc1:

    d "After everything we talked about that night, I thought… maybe we were close enough for that kind of thing."

translate english ch03_orph02_71aec424:

    d "The way we hugged… the way we touched…"

translate english ch03_orph02_922f6cfc:

    d "I thought that meant we’d gotten closer than before."

translate english ch03_orph02_5e3aec4e_2:

    d "………"

translate english ch03_orph02_6703c94c:

    m "………………"

translate english ch03_orph02_1f50e07c:

    m "No, honey. You've got it all wrong."

translate english ch03_orph02_95e66379:

    m "Even people in relationships don't cross that line so easily."

translate english ch03_orph02_50b73330:

    m "And you and I… God…"

translate english ch03_orph02_092071b1:

    m "I went along with it because I didn’t want to make things awkward for you."

translate english ch03_orph02_ebf3e5fe_1:

    m "…………"

translate english ch03_orph02_95158d14:

    m "Do you know how upsetting it was, seeing you act like all those years… all those memories between us didn’t matter?"

translate english ch03_orph02_5d2b8b74:

    m "The way you acted that day…"

translate english ch03_orph02_26b0385d:

    m "You were no different from every other guy trying to get in my pants."

translate english ch03_orph02_3ccd87ec:

    d "I’m really sorry, Mary…"

translate english ch03_orph02_7c0a9214:

    d "………………"

translate english ch03_orph02_8029d8af:

    d "But…"

translate english ch03_orph02_1b7e0b88:

    d "I want to be closer to you…"

translate english ch03_orph02_75d695f5:

    m "What do you mean by “closer”?"

translate english ch03_orph02_cf4d1b40:

    m "……………"

translate english ch03_orph02_38439212:

    m "Sweetheart…"

translate english ch03_orph02_2963c6f7:

    m "You and I are already as close as we can be."

translate english ch03_orph02_caf7f585:

    m "Do you understand that?"

translate english ch03_orph02_448937f8:

    m "Close enough that other people would think it’s strange."

translate english ch03_orph02_ad893dfa:

    d "……"

translate english ch03_orph02_7c0a9214_1:

    d "………………"

translate english strings:
    old "전 메리를 사랑해요."
    new "I love you, Mary."

translate english ch03_orph02_9f2f41fa:

    d "I love you, Mary."

translate english ch03_orph02_7ece8151:

    d "I told you before."

translate english ch03_orph02_75006d25:

    d "To me, you’re someone I can rely on… and a beautiful woman."

translate english ch03_orph02_c6deca81:

    d "I spend every waking moment imagining what it would be like to kiss you."

translate english ch03_orph02_ebfe72a5:

    m "Oh my god, [d_name]…"

translate english strings:
    old "메리 옆으로 다가간다."
    new "Step closer to Mary."

translate english ch03_orph02_92f21ed5:

    n "What should I do?"

translate english ch03_orph02_b4bc53e4:

    d "Why did you ask me to come today?"

translate english ch03_orph02_885cb622:

    m "What?"

translate english ch03_orph02_b0196085:

    m "!!"

translate english ch03_orph03_b0795d16:

    d "Why the silence, Mary?"

translate english ch03_orph03_6b2b54c5:

    d "There’s something you want to tell me, isn’t there?"

translate english ch03_orph03_97a069c3:

    m "What?!!"

translate english ch03_orph03_2302fece:

    d "Right?"

translate english ch03_orph03_055536fa:

    d "You've been playing out scenarios in your head with me too, haven't you?"

translate english ch03_orph03_18548549:

    m "…………"

translate english ch03_orph03_0ffb6a18:

    d "In fact, you're picturing it right this second, aren't you?"

translate english ch03_orph03_4818f347:

    m "Stop."

translate english ch03_orph03_94a71176:

    d "Don’t you really love me, Mary?"

translate english ch03_orph03_443b9f30:

    d "All you ever do is lecture me and keep me at arm's length."

translate english ch03_orph03_338a320b:

    d "Am I really just another charity case to you? Just one of the many you've 'taken care of'?"

translate english ch03_orph03_fe132c66:

    d "Were those things you said back at the park just a cruel joke to you?"

translate english ch03_orph03_5e3aec4e:

    d "………"

translate english ch03_orph03_65d4cb16:

    d "You're the one who told me you imagine taking my cock in your mouth."

translate english ch03_orph03_3edb81bf:

    m "Oh my god…"

translate english ch03_orph03_454742b6:

    m "…………"

translate english ch03_orph03_e4eb7435:

    d "When those thoughts take over, suddenly I'm useful to you..."

translate english ch03_orph03_a797f6ce:

    d "……………"

translate english ch03_orph03_b1d56e76:

    d "But the moment you regain your composure, I'm back to being nobody?"

translate english ch03_orph03_8bd76cd1:

    d "You're just playing with my head, Mary."

translate english ch03_orph03_fbdc0413:

    m "Ha… [d_name]…"

translate english ch03_orph03_14d3f004:

    m "Don’t do this to me…"

translate english ch03_orph03_4fd30f8e:

    m "What are you even saying right now…"

translate english ch03_orph03_ac4844ec:

    m "There hasn’t been a single moment where you didn’t matter to me."

translate english ch03_orph03_e7a41b77:

    m "And…"

translate english ch03_orph03_58dfbc76:

    m "I love you, truly, but you know exactly what kind of love a guardian should have."

translate english ch03_orph03_7f274ee8:

    m "Do you understand what I mean?"

translate english ch03_orph03_90a0e9c4:

    m "I truly love you, but you know what kind of love that is."

translate english ch03_orph03_c0afad3e:

    m "Even having this conversation... it's a mistake."

translate english ch03_orph03_e70754c5:

    d "I know what you mean, Mary."

translate english ch03_orph03_82a9b7e6:

    d "I really do."

translate english ch03_orph03_9a77716c:

    d "I know exactly what you're trying to say, Mary..."

translate english ch03_orph03_3b6e6b72:

    d "And I love you in that way too, I really do."

translate english ch03_orph03_f69a7c0e:

    d "…………"

translate english ch03_orph03_45908ea4:

    d "But I think about you all the time."

translate english ch03_orph03_448f32a0:

    d "But my heart starts pounding the moment I think of you, and my…"

translate english ch03_orph03_3a3e2d4e:

    d "My c…......"

translate english ch03_orph03_6262b6d7:

    d "What I mean is... my body reacts to you. Every time."

translate english ch03_orph03_5aebff17:

    m "………"

translate english ch03_orph03_74cdf1eb:

    m "I’m so confused right now… I don’t even know what to say…"

translate english ch03_orph03_85b899f2:

    m "Are you... are you actually professing your love to me right now?"

translate english ch03_orph03_dcaa0056:

    m "To me… the one who’s been like your teacher?"

translate english ch03_orph03_7bde612c:

    m "You’re the one trying to erase everything we’ve shared."

translate english ch03_orph03_5aebff17_1:

    m "………"

translate english ch03_orph03_58fec412:

    m "You're speaking as if you don't care if we cross a line we can never come back from."

translate english ch03_orph03_8a7f8d2e:

    m "Are you really okay with that?"

translate english ch03_orph03_f358b65e:

    m "Honey…"

translate english ch03_orph03_6908e7a7:

    m "The bloom is off the rose for me, honey. My time has passed."

translate english ch03_orph03_ee58788d:

    m "I’m a married, middle-aged woman."

translate english ch03_orph03_4b3d4c25:

    m "And yet you’re saying your heart races when you think of me…"

translate english ch03_orph03_dccdd9e8:

    m "How can you say something so life-altering with such ease?"

translate english strings:
    old "뭔가 해봐!!"
    new "Do something!!"

translate english ch03_orph03_92f21ed5:

    n "What should I do?"

translate english ch03_orph03_2e687d64:

    m "!!!!!!!!!!"

translate english ch03_orph03_a389a54a:

    m "**(Oh my god……)**"

translate english ch03_orph03_8a4c0d12:

    m "Mmph!"

translate english ch03_orph03_02997f93:

    n "His actions didn’t give Mary any time to react."

translate english ch03_orph03_9c0cf20e:

    n "No—it was more like she had lost the will to resist."

translate english ch03_orph03_213df6a0:

    n "Their lips pressed together."

translate english ch03_orph03_ef000c2c:

    n "All the blame and conversations they’d been having just moments ago, trying to make sense of things,"

translate english ch03_orph03_26c45898:

    n "vanished as if none of it had ever happened."

translate english ch03_orph03_1b1fa556:

    n "All they could feel in that moment was the pleasure spreading from their lips."

translate english ch03_orph03_d6b521c1:

    n "And as their excitement surged, they moved on without hesitation."

translate english ch03_orph03_bc026c0b:

    n "Without either of them taking the lead, their tongues met."

translate english ch03_orph03_8d6ebf57:

    n "The wet sounds of their breaths and saliva filled the room."

translate english ch03_orph03_dd06aca6:

    n "[d_name] knocked on the door of Mary’s secret garden, a place that had been locked away for years."

translate english ch03_orph03_3385bc4e:

    n "And when he stepped inside,"

translate english ch03_orph03_2e20a4fa:

    n "He found the girl who still remembered her most beautiful days."

translate english ch03_orph03_e4689711:

    n "His mind went blank—he barely understood what he was doing anymore."

translate english ch03_orph03_a6d23ae0:

    n "His body just moved on instinct."

translate english ch03_orph03_c43ca0cc:

    m "!!!!!!!!!!!"

translate english ch03_orph03_1db2db8b:

    m "Mmph! Mmph!"

translate english ch03_orph03_d091dc98:

    d "Ha… Mary…"

translate english ch03_orph03_c43ca0cc_1:

    m "!!!!!!!!!!!"

translate english ch03_orph03_ab8df84b:

    m "Stop!!!!!!!"

translate english ch03_orph03_0f6f8dd4:

    d "What’s wrong?"

translate english ch03_orph03_c342bb56:

    d "Did I do something wrong?"

translate english ch03_orph03_cf4d1b40:

    m "……………"

translate english ch03_orph03_d781dc21:

    m "This is wrong... we're making a terrible mistake..."

translate english ch03_orph03_e475a480:

    d "!!!!!!!!!!!!!!"

translate english ch03_orph03_04894d97:

    d "It’s okay, Mary…"

translate english ch03_orph03_c349db8a:

    d "You look so beautiful right now…"

translate english ch03_orph03_4aacc384:

    d "…………………"

translate english ch03_orph03_53963dbb:

    d "Do you remember our promise?"

translate english ch03_orph03_ebf3e5fe:

    m "……………"

translate english ch03_orph03_2dfde38a:

    d "I just want us to be honest with ourselves, like we promised."

translate english ch03_orph03_b702562e:

    d "…………………"

translate english ch03_orph03_a38b4430:

    d "We promised we wouldn’t lie to each other."

translate english ch03_orph03_cf4d1b40_1:

    m "……………"

translate english strings:
    old "내 자지를 보고싶죠?"
    new "You're dying to see it, aren't you?"

translate english strings:
    old "지금 메리가 뭘 생각하고 있는지 알아요."
    new "I know what you’re thinking right now."

translate english ch03_orph03_7040b9f2:

    d "You're dying to see it, aren't you?"

translate english ch03_orph03_2e4224aa:

    d "I know what you’re thinking right now."

translate english ch03_orph03_97a069c3_1:

    m "What?!!"

translate english ch03_orph03_a010efd7:

    d "My cock."

translate english ch03_orph03_a809e5ba:

    m "!!!!!!!!!!!!!!!!!!"

translate english ch03_orph03_4aacc384_1:

    d "…………………"

translate english ch03_orph03_056da12f:

    d "You want to see it, don’t you?"

translate english ch03_orph03_3c6fcaac:

    d "That's the real reason you called me here in this downpour."

translate english ch03_orph03_0fe1561d:

    d "And why you're wearing that dress that shows off your chest."

translate english ch03_orph03_1c2aacc7:

    m "Ha… [d_name]…"

translate english ch03_orph03_f59c01cf:

    m "What are you even saying…"

translate english ch03_orph03_5f83f241:

    m "Why would you say something like that to me?"

translate english ch03_orph03_3f10f8d6:

    m "Yes! We kissed like lovers, okay?"

translate english ch03_orph03_e4579ce7:

    m "Fine. Let’s say that’s our little secret. But…"

translate english ch03_orph03_c056ee2a:

    m "I... I won't deny it felt g-good..."

translate english ch03_orph03_ef4d5197:

    m "But your… your… penis?"

translate english ch03_orph03_761a429e:

    m "That's something that would never happen in a million years!"

translate english ch03_orph03_a797f6ce_1:

    d "……………"

translate english ch03_orph03_2f962f41:

    d "Really, Mary?"

translate english ch03_orph03_f57fe7e8:

    d "Then what about those pictures on the monitor?"

translate english ch03_orph03_79b70afa:

    m "!!!!!!!"

translate english ch03_orph03_07dffc37:

    m "Th… those…"

translate english ch03_orph03_6787079d:

    m "I… I just connected my phone to delete them and they popped up on the screen!"

translate english ch03_orph03_dc8c2814:

    d "Really? Is that really it?"

translate english ch03_orph03_4aacc384_2:

    d "…………………"

translate english ch03_orph03_6a2009ff:

    d "You really don’t want to see it?"

translate english ch03_orph03_d3997eee:

    d "Really?"

translate english ch03_orph03_2759f9bb:

    n "[d_name] pressed her, acting as if a different, more primal version of himself had taken control."

translate english ch03_orph03_3d5aee55:

    n "To him now, Mary was just a female to him, a mate to pair with."

translate english ch03_orph03_f27872a0:

    d "Then should I just leave?"

translate english ch03_orph03_2276deaa:

    d "Do you really want me to walk away?"

translate english ch03_orph03_454742b6_1:

    m "…………"

translate english ch03_orph03_cee4c322:

    d "All you have to do is say the word."

translate english ch03_orph03_089f576a:

    d "Don’t worry. No matter what you say or do, I won’t be surprised."

translate english ch03_orph03_454742b6_2:

    m "…………"

translate english ch03_orph03_1ea84172:

    d "You want to see it, don’t you?"

translate english ch03_orph03_516b52c3:

    d "You've been playing it over in your head since that day at the park, haven't you?"

translate english ch03_orph03_4aacc384_3:

    d "…………………"

translate english ch03_orph03_19d067f8:

    d "Just like I think about having you every single day."

translate english ch03_orph03_b3eb4b5b:

    d "Be honest with me, Mary."

translate english ch03_orph03_3b0925fd:

    d "No matter what you say, it won’t change anything between us."

translate english ch03_orph03_3f1ed7ab:

    m "Ha…"

translate english ch03_orph03_ef6d92ed:

    m "………"

translate english ch03_orph03_1aefa8b4:

    m "…………"

translate english ch03_orph03_4ff7074c:

    m "…………………"

translate english ch03_orph03_deb06b8c:

    m "Yes…."

translate english ch03_orph03_fd349216:

    m "I want to see it."

translate english ch03_orph03_c0107b81:

    m "I want to see your cock…"

translate english ch03_orph03_9c9ff00d:

    d "!!!!!!!!!"

translate english ch03_orph03_f448026a:

    n "Just those words sent a jolt through his entire body."

translate english strings:
    old "지퍼를 내리고 고추를 꺼낸다."
    new "Unzip and take it out."

translate english ch03_orph03_92f21ed5_1:

    n "What should I do?"

translate english ch03_orph03_5671c7c7:

    c "……"

translate english ch03_orph03_f00ef908:

    c "There’s an interview from the press today… does Mary remember?"

translate english ch03_orph03_10ff431c:

    c "I should remind her again."

translate english ch03_orph03_96f7b638:

    m "Ha…"

translate english ch03_orph03_c767ad78:

    m "Oh my god... [d_name]..."

translate english ch03_orph03_80a1b6c4:

    m "You... you actually went and did it!!"

translate english ch03_orph03_ebfc8f0e:

    d "What do you think?"

translate english ch03_orph03_77673f80:

    d "………"

translate english ch03_orph03_21d79eda:

    d "Does the reality live up to the photos you saw?"

translate english ch03_orph03_18548549_1:

    m "………"

translate english ch03_orph03_b13629ed:

    n "She stared at his erection in silence."

translate english ch03_orph03_c08b7351:

    n "Staring at him, she was swept up in a storm of emotions she couldn't begin to name."

translate english ch03_orph03_26e423ec:

    n "What she saw before her was the one thing that could fill the void she'd carried for years."

translate english ch03_orph03_8e8e30cf:

    n "that hollow she had carried for so long."

translate english ch03_orph03_6a981d52:

    n "Not as the head of a youth center, not as someone’s wife or mother,"

translate english ch03_orph03_b3c5436f:

    n "but as a woman—something that could satisfy a longing she had never been able to fulfill."

translate english ch03_orph03_f9c5115f:

    d "I’m curious, Mary."

translate english strings:
    old "그 날 이후로도 나의 자지를 빨아주는 생각을 했었어요?"
    new "Been craving my cock since that day?"

translate english strings:
    old "그 날 이후로 메리가 저의 여자가 되는 상상을 했어요."
    new "I keep imagining you as my woman."

translate english ch03_orph03_9c770b22:

    d "Been craving my cock since that day?"

translate english ch03_orph03_141151e7:

    d "I keep imagining you as my woman."

translate english ch03_orph03_1fc9d61b:

    m "What?!!!!!!!!!!!!!!"

translate english ch03_orph03_0ae8af5d:

    m "[d_name]…"

translate english ch03_orph03_6c052d01:

    m "………………"

translate english ch03_orph03_203cc60b:

    d "……"

translate english strings:
    old "지금 해보는거 어때요?"
    new "What if we just try it, right here, right now?"

translate english ch03_orph03_74fcb1c9:

    d "What if we just try it, right here, right now?"

translate english ch03_orph03_1fc9d61b_1:

    m "What?!!!!!!!!!!!!!!"

translate english ch03_orph03_18d5d8f1:

    d "I told you before."

translate english ch03_orph03_73397298:

    d "I just want you to feel good, Mary."

translate english ch03_orph03_2eda3250:

    d "If this is what you want, and if it'll make you feel as good as I think it will, then I'm all in."

translate english ch03_orph03_1c2aacc7_1:

    m "Ha… [d_name]."

translate english ch03_orph03_1654378e:

    m "That's... that's such a dangerous way to look at it..."

translate english ch03_orph03_f9d415e6:

    m "You shouldn't try to pull my strings like that."

translate english ch03_orph03_6c052d01_1:

    m "………………"

translate english strings:
    old "그녀에게 더 가까이 다가간다."
    new "Move closer to her."

translate english ch03_orph03_92f21ed5_2:

    n "What should I do?"

translate english ch03_orph03_c43ca0cc_2:

    m "!!!!!!!!!!!"

translate english ch03_orph03_41fbdaf0:

    m "What are you doing right now?!"

translate english ch03_orph03_79d9fef6:

    d "Just let go for once, Mary."

translate english ch03_orph03_5fc69c23:

    d "I just want us to be closer."

translate english ch03_orph03_5f742081:

    d "Let's share a secret that no one else in the world knows."

translate english ch03_orph03_b045c597:

    d "Start with something small… like a kiss, Mary…"

translate english ch03_orph03_ef6d92ed_1:

    m "………"

translate english ch03_orph03_0b62605c:

    d "Mary…"

translate english ch03_orph03_439d01b6:

    d "I want to feel your lips."

translate english ch03_orph03_8d8b3636:

    d "I want to make this a day neither of us will ever forget."

translate english ch03_orph03_ef6d92ed_2:

    m "………"

translate english ch03_orph03_d42def6a:

    n "Mary slowly brought her hand down to him."

translate english ch03_orph03_f2fa1aa7:

    n "And then she wrapped her hand around his penis."

translate english ch03_orph03_0a41d61e:

    n "She could feel the heat of him in her palm."

translate english ch03_orph03_e3e28a5e:

    n "Having spent her life bound to one man, the sheer size of him in her hand left her completely breathless."

translate english ch03_orph03_8b7a5c2b:

    d "Ah…"

translate english ch03_orph03_0b62605c_1:

    d "Mary…"

translate english ch03_orph03_6ab7a17b:

    m "**(I'm going to burn in hell for this...)**"

translate english ch03_orph03_e45e74b7:

    m "**(Mary... are you really going to go through with this?)**"

translate english ch03_orph03_ba70900e:

    m "**(How could I put his dick in my mouth…)**"

translate english ch03_orph03_ec5ea4f1:

    m "**(Why is my body so desperate to do this?!)**"

translate english ch03_orph03_7ee64a0a:

    d "Ugh…"

translate english ch03_orph03_2eef6f3b:

    d "Ah…"

translate english ch03_orph03_5fd1a1ad:

    n "As she wrapped her lips around his glans, he could feel the warmth and slickness spreading from the tip."

translate english ch03_orph03_eec0ea20:

    d "God… Mary…"

translate english ch03_orph03_143b3bf8:

    d "Take it all the way in."

translate english ch03_orph03_8c27ff6b:

    d "Ah, Mary…"

translate english ch03_orph03_51021182:

    d "The way your mouth feels... I'm losing my mind..."

translate english ch03_orph03_3acaed66:

    d "Deeper!!"

translate english ch03_orph03_ebf3e5fe_1:

    m "………………"

translate english ch03_orph03_b2cdd07d:

    d "Ah, Mary!!!!!"

translate english ch03_orph03_63591332:

    m "Ghk…"

translate english ch03_orph03_ac48b757:

    m "Ack…"

translate english ch03_orph03_81afbe33:

    n "Even in this, Mary's nurturing side came through."

translate english ch03_orph03_8bb61a35:

    n "She took him in as if she were trying to soothe his entire soul with her body."

translate english ch03_orph03_468a244a:

    n "As if she were trying to care for him entirely as a person."

translate english ch03_orph03_dc0139cc:

    d "Ah, Mary—that’s it!!"

translate english ch03_orph03_346e03ba:

    d "Ah…"

translate english ch03_orph03_1873013c:

    d "Now... please... move for me."

translate english ch03_orph03_b753d1b7:

    m "Ugh…"

translate english ch03_orph03_81378e3f:

    m "Ugh…"

translate english ch03_orph03_bc86fafd:

    m "Ghk…"

translate english ch03_orph03_ac843af5:

    m "Ugh…"

translate english ch03_orph03_a196314a:

    n "As she took him to her absolute limit,"

translate english ch03_orph03_e0a55d41:

    n "He felt himself hit the very back of her throat."

translate english ch03_orph03_6856c508:

    d "Ah, Mary!!!!!!!!"

translate english ch03_orph03_00c2600d:

    m "Haah!!!!!"

translate english ch03_orph03_41de31af:

    m "Haah… haah…"

translate english ch03_orph03_41de31af_1:

    m "Haah… haah…"

translate english ch03_orph03_a55504d5:

    m "It's... it's so big"

translate english ch03_orph03_50a95f3b:

    d "Your mouth is absolute heaven."

translate english ch03_orph03_e8bf53d0:

    d "You’re so beautiful…"

translate english ch03_orph03_8e15887d:

    d "Did you know that?"

translate english ch03_orph03_1aefa8b4_1:

    m "………………"

translate english strings:
    old "그녀의 입에 손가락을 넣는다."
    new "Put your fingers in her mouth."

translate english ch03_orph03_8aac3847:

    m "**(!!!!)**"

translate english ch03_orph03_a7b7db9b:

    m "**(What am I even doing right now??)**"

translate english ch03_orph03_47a43369:

    n "As if entranced, she no longer felt any shame or hesitation in anything he asked of her."

translate english ch03_orph03_93d269d9:

    n "She could only look into his eyes."

translate english ch03_orph03_ddc60400:

    d "Don't stop now, Mary."

translate english ch03_orph03_9d069065:

    d "Put it back in."

translate english ch03_orph03_3e349db3:

    d "My god, Mary…"

translate english ch03_orph03_9c5ba01a:

    d "Your lips are doing incredible things to me..."

translate english ch03_orph03_917f6b77:

    m "Ghk…"

translate english ch03_orph03_ac843af5_1:

    m "Ugh…"

translate english ch03_orph03_5a5c9fec:

    n "Knock knock"

translate english ch03_orph03_c43ca0cc_3:

    m "!!!!!!!!!!!"

translate english ch03_orph03_d76fab35:

    d "!!!!!!"

translate english ch03_orph03_f42b91b0:

    c "Mary, are you in there?"

translate english ch03_orph03_690f5656:

    c "………"

translate english ch03_orph03_fc792352:

    c "Um… Mary?"

translate english ch03_orph03_959fbbcd:

    m "Yes, Celine? What is it?"

translate english ch03_orph03_f6259d4f:

    c "**(Oh my god, Mary!)**"

translate english ch03_orph03_4da98cab:

    c "**(What is she wearing right now?)**"

translate english ch03_orph03_39ee795e:

    c "**(Is she dressed for some kind of party?…)**"

translate english ch03_orph03_6632a151:

    c "**(……………)**"

translate english ch03_orph03_4e1c849b:

    c "You remember the interview with the press later, right?"

translate english ch03_orph03_146fec86:

    c "Just wanted to make sure."

translate english ch03_orph03_54b8c495:

    m "Ah, thanks. I remembered."

translate english ch03_orph03_1f72d558:

    m "Oh... [d_name] was just... helping me rehearse for the interview, haha."

translate english ch03_orph03_96fed19b:

    c "Oh, I see."

translate english ch03_orph03_216604b5:

    c "If you need anything, just let me know."

translate english ch03_orph03_b838f91c:

    c "They said they’d call about ten minutes before they arrive, so I’ll let you know when they do."

translate english ch03_orph03_4fe843a3:

    m "Alright."

translate english ch03_orph03_4b1ab41d:

    m "Thank you."

translate english ch03_orph03_a06205d8:

    c "No problem, hehe."

translate english ch03_orph03_2e58b9ba:

    c "What was that…?"

translate english ch03_orph03_75bca0a3:

    c "Did I see that wrong?"

translate english ch03_orph03_690f5656_1:

    c "………"

translate english ch03_orph03_2d401b20:

    c "No way…"

translate english ch03_orph03_ddb8a08b:

    c "Wait... are they actually doing what I think they're doing?!!!"

translate english ch03_orph03_7748c447:

    c "Oh my god……"

translate english ch03_orph03_c93d71b3:

    m "Ha…………"

translate english ch03_orph03_41e27ce0:

    m "I thought my heart was going to leap out of my chest..."

translate english ch03_orph03_d41256aa:

    m "Oh my god…"

translate english ch03_orph03_391e762a:

    m "[d_name]…"

translate english ch03_orph03_465ae600:

    m "You really should get going, honey."

translate english ch03_orph03_f04af9d9:

    m "Make sure you're ready for that call from the company."

translate english ch03_orph03_edbb7d05:

    d "……"

translate english ch03_orph03_d1f71dce:

    d "Okay…"

translate english ch03_orph03_77673f80_1:

    d "………"

translate english ch03_orph03_1aefa8b4_2:

    m "…………"

translate english ch03_orph03_b082be02:

    n "They couldn’t say anything for a while."

translate english ch03_orph03_342e0013:

    n "The moment reality came crashing back in, she was nearly drowned by a wave of regret."

translate english ch03_orph03_3081b872:

    m "My God... what did we just let happen?"

translate english ch03_orph03_84d76d74:

    m "What have we done?"

translate english ch03_orph03_b66ed048:

    m "I’m sorry, honey…"

translate english ch03_orph03_e632131d:

    m "How could I have let myself do that..."

translate english ch03_orph03_6a21657e:

    d "………………"

translate english ch03_orph03_dca09abd:

    d "Don't say that, Mary... it was incredible."

translate english ch03_orph03_5098eaf2:

    d "It's just something that happens when two people care about each other as much as we do."

translate english ch03_orph03_5aebff17_2:

    m "………"

translate english ch03_orph03_0e0f627f:

    m "You really think that?"

translate english ch03_orph03_3e5d2cda:

    m "You're much more composed about this than I am, sweetheart."

translate english ch03_orph03_7d310f90:

    d "I love you, Mary…"

translate english ch03_orph03_4ccd0b83:

    d "We love each other. That's the only truth that matters."

translate english ch03_orph03_ac05bf59:

    d "You love me too, don't you, Mary?"

translate english ch03_orph03_c3f1fcaf:

    m "Yeah. I love you so much."

translate english ch03_orph03_a7990a19:

    d "Would you still love me even if I did something like this?"

translate english ch03_orph03_653b74a8:

    m "What do you mean, “did this”?"

translate english strings:
    old "메리의 엉덩이를 만진다."
    new "Touch Mary’s ass."

translate english ch03_orph03_92f21ed5_3:

    n "What should I do?"

translate english ch03_orph03_cf4d1b40_2:

    m "……………"

translate english ch03_orph03_fcf4a0b4:

    n "She wasn’t as shocked as the last time he touched her."

translate english ch03_orph03_9c937055:

    n "Without even realizing it, she was slowly yielding her body to him, bit by bit."

translate english ch03_orph03_24105013:

    m "[d_name]… just go…"

translate english ch03_orph03_3263adb2:

    m "We can’t do this here…"

translate english ch03_orph03_04b2bf41:

    d "I just want to feel you, Mary..."

translate english ch03_orph03_cf4d1b40_3:

    m "……………"

translate english strings:
    old "한 발 더 나아간다."
    new "Take it a step further."

translate english ch03_orph03_acd88737:

    m "Hey!!"

translate english ch03_orph03_0cf870c7:

    m "Mm…"

translate english ch03_orph03_d68972ea:

    n "[d_name] grabbed Mary’s ass."

translate english ch03_orph03_2e0344df:

    n "His touch sent a jolt of pleasure through her, tangled with a sharp sting of shame."

translate english ch03_orph03_9dcfe756:

    m "!!!!!!"

translate english ch03_orph03_fbea35d4:

    m "Oh my god, [d_name]…"

translate english ch03_orph03_7fd9be41:

    m "What are you trying to do…"

translate english ch03_orph03_bc0e07de:

    m "We can’t do this…"

translate english ch03_orph03_b75209fd:

    m "We're in so much trouble. You bad, bad boy..."

translate english ch03_orph03_77673f80_2:

    d "………"

translate english ch03_orph03_fce162ac:

    m "Just go…"

translate english ch03_orph03_8c097a17:

    d "Alright."

translate english ch03_orph03_8dbc1b51:

    d "Goodbye."

translate english ch03_orph03_deb06b8c_1:

    m "Okay."

translate english ch03_orph03_17af075d:

    m "Call me once your interview is over, okay?"

translate english ch03_orph03_8ddda1dd:

    d "Yes, I will."

translate english ch03_orph03_12be634e:

    m "Ha………………"

translate english ch03_orph03_c22ecef5:

    m "We've really crossed the line this time."

translate english ch03_orph03_cf4d1b40_4:

    m "……………"

translate english ch03_orph03_32582291:

    m "We're in deep trouble, honey... we really are."

translate english ch03_orph03_80adb125:

    m "…………………"

translate english ch03_orph03_5012beb0:

    m "Ha... Mary, you absolute fool..."

translate english ch03_orph03_7dcdc56f:

    m "Ha... you've lost your mind, you crazy woman..."

translate english ch03_orph03_af6b09d0:

    m "What on earth have I done to him?"

translate english ch03_orph03_c16a0adf:

    m "I should have watched what I said... it actually happened."

translate english ch03_orph03_6c052d01_2:

    m "……………"

translate english ch03_orph03_889a259c:

    m "My own words came back to haunt me..."

translate english ch03_diner01_78425423:

    tv "And now, for the next update."

translate english ch03_diner01_2d48971d:

    tv "Recently, organized crime has been noticeably increasing in small towns across Milfheim State."

translate english ch03_diner01_676292fe:

    tv "Especially in outlying areas, illegal gambling rings and drug distribution networks have been rapidly expanding."

translate english ch03_diner01_a9950477:

    tv "Authorities say there are signs that the same organization is involved in multiple incidents across different cities."

translate english ch03_diner01_fc9a1e03:

    tv "Unlike existing crime groups, this one appears to be multinational, with members of various nationalities."

translate english ch03_diner01_cf90d9f0:

    tv "Over the past month, more than ten people have been arrested, but key figures are still at large."

translate english ch03_diner01_4ef0e69a:

    tv "In some areas, late-night shootings and arson incidents have further heightened public anxiety."

translate english ch03_diner01_cb478b02:

    tv "Officials say this organization is laundering money and expanding its influence in ways unlike traditional crime groups."

translate english ch03_diner01_0dde0b7f:

    tv "The state bureau plans to deploy additional personnel to smaller towns to accelerate the investigation."

translate english ch03_diner01_a63c20b0:

    tv "The governor has also announced emergency public safety measures and additional funding for each county."

translate english ch03_diner01_a43cf5dc:

    tv "Residents are urged to report any suspicious activity immediately."

translate english ch03_diner01_0ee2c4ef:

    unknownf "Hello, welcome!"

translate english ch03_diner01_09bfcf7d:

    do "Over here, Detective Diana."

translate english ch03_diner01_0b8bb338:

    di "What? Detective Diana?"

translate english ch03_diner01_9ae08342:

    di "Is that what you call me after all this time?"

translate english ch03_diner01_71af8b36:

    di "Ouch. A bit formal, don't you think? Haha."

translate english ch03_diner01_9be804b4:

    di "………"

translate english ch03_diner01_8a1fc21a:

    do "…………"

translate english ch03_diner01_9580f326:

    do "Seriously, what the hell are you wearing?"

translate english ch03_diner01_dab59b1d:

    do "Did you just give up on looking decent because you're in the sticks now?"

translate english ch03_diner01_e2d23293:

    do "Even the locals out here have standards, you know."

translate english ch03_diner01_e5e55d75:

    di "Oh, cut it out. I came straight from working out."

translate english ch03_diner01_8960b1da:

    di "I went to the station dressed even more revealing yesterday, what’s the big deal now?"

translate english ch03_diner01_f9d72b28:

    do "What did you say?!!"

translate english ch03_diner01_39fc4cb3:

    do "You went to the station dressed like that?!!"

translate english ch03_diner01_d4d14829:

    di "I told you, I did."

translate english ch03_diner01_41ddd92b:

    di "The chief's eyes were practically popping out of his skull."

translate english ch03_diner01_b1c38760:

    di "The way he kept staring…"

translate english ch03_diner01_cf2e3987:

    di "I felt like he was undressing me with his eyes."

translate english ch03_diner01_ec743473:

    di "And that’s all you’ve got to say to your boss after a year?"

translate english ch03_diner01_ec7766ea:

    do "Boss?"

translate english ch03_diner01_4c1358bd:

    do "I’m Vice now. I’m not in violent crimes anymore."

translate english ch03_diner01_ef87c49b:

    di "Same thing."

translate english ch03_diner01_0a52e6ce:

    di "………………"

translate english ch03_diner01_9512fdd5:

    do "So when did you get here?"

translate english ch03_diner01_b7ad7584:

    do "Honestly, I’m a little hurt. You came all the way here and didn’t even call me."

translate english ch03_diner01_22bd7880:

    do "Did I even cross your mind once?"

translate english ch03_diner01_9230ef6e:

    di "Well, we’re seeing each other now, aren’t we?"

translate english ch03_diner01_689c7bd7:

    do "From what I saw on the news, you’re not the only detective sent out here."

translate english ch03_diner01_9691df73:

    do "So how is it?"

translate english ch03_diner01_99d62291:

    do "Bored to tears out here in the middle of nowhere, right?"

translate english ch03_diner01_a7c5252b:

    di "The scenery’s great. Air’s clean too."

translate english ch03_diner01_080a0845:

    di "People are more relaxed, friendlier than in the city…"

translate english ch03_diner01_80536583:

    di "Hard to believe organized crime’s actually increasing in a place like this."

translate english ch03_diner01_ff128568:

    di "Though it kinda looks like I followed you out to Milfheim Hills, which I’m not a fan of, haha."

translate english ch03_diner01_a4bf7f4d:

    di "When I first heard I was being sent here, I thought you pulled some strings."

translate english ch03_diner01_56fc762d:

    do "What? What do you mean by that?"

translate english ch03_diner01_86545ab4:

    do "You didn’t request this posting because you missed me??!!"

translate english ch03_diner01_6989bc7b:

    do "That’s what I thought this whole time."

translate english ch03_diner01_a2d91771:

    di "Shut it."

translate english ch03_diner01_89a81eb1:

    di "Your mom actually asked me to keep an eye on you and make sure you're not causing trouble."

translate english ch03_diner01_e68ff540:

    do "Hahahahahahaha."

translate english ch03_diner01_e57ff185:

    do "………"

translate english ch03_diner01_e8798e09:

    do "So why did you want to meet?"

translate english ch03_diner01_c937170e:

    do "It's not like you called me out here to ask for a second chance at a date..."

translate english ch03_diner01_5382cc40:

    do "If you’re the one asking to meet, it’s probably something important…"

translate english ch03_diner01_c21f0030:

    n "Diana took a sip of her beer without saying anything."

translate english ch03_diner01_76e681e5:

    n "After a brief pause, she spoke."

translate english ch03_diner01_4194910a:

    di "Have you ever heard of a group called AAAE?"

translate english ch03_diner01_fe381e92:

    di "AAAE."

translate english ch03_diner01_a7bc6c24:

    do "AAAE?"

translate english ch03_diner01_25768982:

    di "Mm-hmm."

translate english ch03_diner01_acb06336:

    do "AAAE…"

translate english ch03_diner01_c83ff285:

    do "No clue, but it sounds like a support group for overachievers obsessed with straight A’s."

translate english ch03_diner01_febf1733:

    di "………"

translate english ch03_diner01_f002dabb:

    di "Is that the best a professional detective can come up with?"

translate english ch03_diner01_35a53ab4:

    do "Is it tied to some kind of crime?"

translate english ch03_diner01_64b91bb7:

    di "No."

translate english ch03_diner01_a0a47353:

    di "I just saw it somewhere and figured I’d ask in case you knew."

translate english ch03_diner01_0434e609:

    do "………………"

translate english ch03_diner01_32c28246:

    do "Boss, you’re a terrible liar."

translate english ch03_diner01_0d67f279:

    do "You can't even fake an orgasm."

translate english ch03_diner01_07f56676:

    do "How are you always so blunt?"

translate english ch03_diner01_d409689b:

    do "You’ve hurt my feelings plenty of times, you know."

translate english ch03_diner01_572c4a25:

    di "Jesus, keep your voice down…"

translate english ch03_diner01_f2a4ff5d:

    di "Ha…"

translate english ch03_diner01_b414721a:

    di "And for your information, I’m very good at faking it."

translate english ch03_diner01_f3bf555e:

    di "…………"

translate english ch03_diner01_ba96df13:

    di "Actually, there was a file under the desk drawer I’m using."

translate english ch03_diner01_a1390598:

    di "I opened it and found a case file with a two-dollar bill tucked inside."

translate english ch03_diner01_a8d9d956:

    do "A two-dollar bill?"

translate english ch03_diner01_9bb3baa8:

    di "Yeah. A two-dollar bill."

translate english ch03_diner01_ffe840dc:

    di "The report was about some organization called AAAE."

translate english ch03_diner01_abe18812:

    do "Was it an investigation report?"

translate english ch03_diner01_37df3500:

    di "No, more like a report suggesting an investigation was needed."

translate english ch03_diner01_86114c6b:

    di "I can’t go into detail, but it definitely caught my interest."

translate english ch03_diner01_70daf327:

    do "Hmm…………"

translate english ch03_diner01_2cebb7ed:

    di "So, who was the previous violent crimes team leader here?"

translate english ch03_diner01_4fd73490:

    do "Hmm…"

translate english ch03_diner01_f63c8acf:

    do "That would be Edward."

translate english ch03_diner01_0a329ccd:

    do "I don’t know all the details, but he just quit out of the blue and vanished from town."

translate english ch03_diner01_1c358780:

    di "What do you mean he left the force?"

translate english ch03_diner01_3aac4650:

    di "Like, he retired completely?"

translate english ch03_diner01_7df54938:

    do "Yeah. That’s what I heard. Nobody knows the exact reason…"

translate english ch03_diner01_cf5a7656:

    do "He didn't even say goodbye—just left his badge and resignation letter and ghosted."

translate english ch03_diner01_cbfff03f:

    di "………"

translate english ch03_diner01_328a586b:

    di "Hmm………"

translate english ch03_diner01_1dacf4e3:

    wait "Hi."

translate english ch03_diner01_8b17f391:

    wait "I don’t think I’ve seen you before. Am I right?"

translate english ch03_diner01_726c9ce4:

    di "Yeah, that’s right."

translate english ch03_diner01_e43f49d8:

    wait "The snacks are on the house."

translate english ch03_diner01_03e6c503:

    di "Thank you, hehe."

translate english ch03_diner01_12eb2d74:

    di "I’ll enjoy them."

translate english ch03_diner01_d394ad0d:

    wait "Are you a police officer too, like Owen?"

translate english ch03_diner01_2e2c20fd:

    wait "Are you his superior?"

translate english ch03_diner01_7611170d:

    di "Yeah, something like that, haha."

translate english ch03_diner01_1e100fcc:

    di "I just got assigned here, so it’s my first time around."

translate english ch03_diner01_13b0e1a9:

    wait "I see."

translate english ch03_diner01_c6a91294:

    wait "I usually remember faces well, so I figured something was off…"

translate english ch03_diner01_25bd485f:

    wait "You should come by more often."

translate english ch03_diner01_41a9c923:

    wait "I’ll hook you up with plenty of extras, haha."

translate english ch03_diner01_6aa8ed3c:

    di "I will, haha. Thanks."

translate english ch03_diner01_330e9242:

    di "**(What was that…?)**"

translate english ch03_diner01_283cb32b:

    di "**(Was she just checking me out? Sizing me up?)**"

translate english ch03_diner01_a76b83fc:

    di "**(Seriously… unbelievable.)**"

translate english ch03_diner01_aa15e1e8:

    di "**(I don’t need it, so you can have it all.)**"

translate english ch03_diner01_84e8e71b:

    di "Dammit, Owen! Are you talking to my tits right now?"

translate english ch03_diner01_65672f64:

    di "If you're going to stare that hard, at least act like a detective and be subtle about it."

translate english ch03_diner01_19dd3870:

    di "Or wear some sunglasses or something."

translate english ch03_diner01_92c771bb:

    do "Ah, sorry, haha."

translate english ch03_diner01_4e13ca87:

    do "My eyes just… moved on their own, haha."

translate english ch03_diner01_16fc4004:

    di "What? So you’re saying your eyes weren’t moving because I’m beautiful, but just some male instinct?"

translate english ch03_diner01_ff66884c:

    di "That’s exactly why women don’t like you—you’re way too blunt."

translate english ch03_diner01_74ebcff5:

    di "Still, at least you’re honest. Not the worst, I guess."

translate english ch03_diner01_7f1c1918:

    do "Nope! You’re wrong."

translate english ch03_diner01_8aa70162:

    do "The first reason women leave me is because I’m a cop,"

translate english ch03_diner01_3413b7ca:

    do "And second, they just can't keep up with my stamina."

translate english ch03_diner01_c0546a80:

    do "You know that."

translate english ch03_diner01_3ef774ad:

    do "I go all night until the sun comes up."

translate english ch03_diner01_144d7536:

    do "Don’t you remember?"

translate english ch03_diner01_f9e6f598:

    do "That's the real reason you left me, isn't it? You couldn't handle it."

translate english ch03_diner01_bc1db9da:

    di "What?!!"

translate english ch03_diner01_46437f56:

    di "………"

translate english ch03_diner01_103ef8ff:

    di "Hahahaha… Owen…"

translate english ch03_diner01_d66f4380:

    di "Oh my god…"

translate english ch03_diner01_b11ae45b:

    di "What, did you start writing erotic fiction on the side?"

translate english ch03_diner01_cc49dc35:

    di "Nice try. You almost had me for a split second."

translate english ch03_diner01_27154b30:

    do "Hahahahahaha."

translate english ch03_diner01_9aec1e3b:

    di "Man, I’m getting a little tipsy."

translate english ch03_diner01_cd043d08:

    di "Great… thanks to you, my whole workout’s gone to waste."

translate english ch03_diner01_b4866e81:

    di "You jerk…"

translate english ch03_diner01_f9ef212f:

    di "I should call a cab and head out."

translate english ch03_diner01_39227fa3:

    do "A cab?"

translate english ch03_diner01_6f068128:

    do "No way. Around here, you’re waiting at least an hour."

translate english ch03_diner01_32a2bbf8:

    do "I’ll drive you. You can pick up your car tomorrow."

translate english ch03_diner01_b271f858:

    di "…………………"

translate english ch03_diner01_ce1329e6:

    di "Alright."

translate english ch03_diner01_cc0a70ab:

    di "Ugh… I feel sluggish…"

translate english ch03_diner01_a33869ba:

    n "They drove down a rainy countryside road."

translate english ch03_diner01_cec6680f:

    n "Between the alcohol, the rain, and seeing each other after so long, a strange silence filled the car."

translate english ch03_diner01_bc8365a5:

    n "The sound of tires on wet pavement and rain hitting the windows went on, until Diana spoke."

translate english ch03_diner01_f2fc7bae:

    di "Had a few drinks, it’s raining… kinda perfect atmosphere."

translate english ch03_diner01_7837a0b4:

    do "Right? Haha."

translate english ch03_diner01_d109076a:

    do "That’s the charm of a country drive."

translate english ch03_diner01_68380413:

    do "Feels good seeing you again after so long, grabbing a meal together—brings back memories."

translate english ch03_diner01_2abf73da:

    di "Hmm……"

translate english ch03_diner01_07dc434b:

    di "It would've been a perfect night if anyone else was behind the wheel. Such a shame."

translate english ch03_diner01_4e3c4dde:

    do "Hahahaha."

translate english ch03_diner01_cb1f4ebd:

    do "There's comfort in the familiar... you get what I'm saying?"

translate english ch03_diner01_48f29647:

    do "If you spend your whole life chasing thrills, you end up missing what actually matters."

translate english ch03_diner01_d02745ea:

    di "What are you even talking about? I’ve never chased thrills."

translate english ch03_diner01_10cbe99e:

    di "I just get bored fast."

translate english ch03_diner01_4d20cdfd:

    do "Same thing."

translate english ch03_diner01_7d64cead:

    di "What, are you saying I’m something that matters to you?"

translate english ch03_diner01_4e3c4dde_1:

    do "Hahahaha."

translate english ch03_diner01_cfccf2d3:

    do "I am important to you, aren’t I? Or not?"

translate english ch03_diner01_39d821f9:

    di "A year ago, sure."

translate english ch03_diner01_4868f773:

    di "Now? Not that important."

translate english ch03_diner01_25e3e0f3:

    do "Figures. You haven’t changed at all…"

translate english ch03_diner01_e78b01bd:

    di "Hahaha. Think whatever you want."

translate english ch03_diner01_9509c8ff:

    di "Thanks for the ride."

translate english ch03_diner01_46437f56_1:

    di "………"

translate english ch03_diner01_25ced96f:

    di "See you at the office."

translate english ch03_diner01_3d978e10:

    do "…………"

translate english ch03_diner01_0b61ae82:

    do "Uh, boss…"

translate english ch03_diner01_b4de5424:

    di "Huh?"

translate english ch03_diner01_72b6231f:

    di "Why are you calling me like that?"

translate english ch03_diner01_d056f5b3:

    do "Well…"

translate english ch03_diner01_486ba371:

    do "It’s raining…"

translate english ch03_diner01_bb4f51b8:

    do "and it’s been a while…"

translate english ch03_diner01_bcb571e8:

    do "Can I come over to your place?"

translate english ch03_diner01_eeb235fd:

    do "………"

translate english ch03_diner01_61f953a6:

    do "We could talk… maybe have another drink…"

translate english ch03_diner01_9be804b4_1:

    di "………"

translate english ch03_diner01_be1c45fe:

    di "What are you trying to say?"

translate english ch03_diner01_bcddd208:

    di "…"

translate english ch03_diner01_e5050be2:

    di "Are you asking me out again?"

translate english ch03_diner01_48925be4:

    do "It’s just…"

translate english ch03_diner01_2d95e758:

    di "I don't sleep with coworkers anymore."

translate english ch03_diner01_2ebe15d4:

    di "And there are a lot of cops around here, so be careful."

translate english ch03_diner01_cd1a76d2:

    di "It’s pouring—stop messing around and go home."

translate english ch03_diner01_dc6c6240:

    di "See you at the office. Bye."

translate english ch03_diner01_1eb22839:

    do "Alright. See you later."

translate english ch03_diner01_72772146:

    do "You must be tired, get some rest."

translate english ch03_diner01_15a8e1c9:

    do "………"

translate english ch03_diner01_187226ff:

    di "Yeah. Drive safe."

translate english ch03_diner01_fb942c21:

    do "Damn it… I shouldn’t have said anything…"

translate english ch03_diner01_7ef3bf57:

    do "Ha… idiot…"

translate english ch03_diner01_fc3574e3:

    do "Haven’t seen her in a year and that’s all I had to say…"

translate english ch03_range01_552f437e:

    n "Bang! Bang!"

translate english ch03_range01_11577bde:

    n "Bang! Bang! Bang!"

translate english ch03_range01_552f437e_1:

    n "Bang! Bang!"

translate english ch03_range01_552f437e_2:

    n "Bang! Bang!"

translate english ch03_range01_11577bde_1:

    n "Bang! Bang! Bang!"

translate english ch03_range01_11577bde_2:

    n "Bang! Bang! Bang!"

translate english ch03_range01_11577bde_3:

    n "Bang! Bang! Bang!"

translate english ch03_range01_95a18de4:

    mi "…………"

translate english ch03_range01_95a18de4_1:

    mi "…………"

translate english ch03_range01_5e552bdf:

    mi "Hello."

translate english ch03_range01_922859b0:

    unknownm "Hey, Michael. Been well?"

translate english ch03_range01_0c67fd06:

    mi "Yeah. I have. Why are you calling?"

translate english ch03_range01_e92a3078:

    unknownm "What do you mean “why”?"

translate english ch03_range01_7aa509cf:

    unknownm "Am I the kind of person who only calls when he needs something?"

translate english ch03_range01_8599da02:

    mi "……………"

translate english ch03_range01_19fd5865:

    unknownm "……………"

translate english ch03_range01_5fc872de:

    unknownm "Hahaha, Michael, I’m kidding."

translate english ch03_range01_2e56d86f:

    unknownm "Damn, you're still as stiff as ever."

translate english ch03_range01_4092650b:

    unknownm "Been at the range again today?"

translate english ch03_range01_f60ce8b2:

    mi "Yeah. I train regularly."

translate english ch03_range01_34aae235:

    mi "You know that."

translate english ch03_range01_4902713f:

    unknownm "I see. Occupational habit?"

translate english ch03_range01_d61e6e12:

    unknownm "Just hearing that makes my skin crawl."

translate english ch03_range01_ad7c2b74:

    unknownm "It makes me proud to be a citizen, knowing guys like you are still out there running ops."

translate english ch03_range01_a2a5922c:

    mi "………………"

translate english ch03_range01_43b93012:

    mi "Get to the point."

translate english ch03_range01_93143551:

    unknownm "Hmm…"

translate english ch03_range01_c59b858d:

    unknownm "Have you talked to [h_name]?"

translate english ch03_range01_48b20e7d:

    mi "I’m in the middle of it."

translate english ch03_range01_a2141b26:

    mi "Something came up while we were talking about it, so I couldn’t come to a clear conclusion."

translate english ch03_range01_c1db744d:

    unknownm "Hmm… I see…"

translate english ch03_range01_aa9084c6:

    unknownm "Hey, Michael…"

translate english ch03_range01_c2568f7b:

    unknownm "I'm your friend. And…"

translate english ch03_range01_e5c8df26:

    unknownm "You are my friend, right?"

translate english ch03_range01_d3987f99:

    unknownm "………………"

translate english ch03_range01_adba3c93:

    unknownm "I’ve always liked the way you handled things."

translate english ch03_range01_78f7193b:

    unknownm "You always found solutions that satisfied everyone."

translate english ch03_range01_5aa36c19:

    unknownm "That’s why I left things here in your hands even after all that chaos."

translate english ch03_range01_09e90959:

    unknownm "Thanks to that, my position here has improved a lot. I really appreciate that."

translate english ch03_range01_2da443e0:

    unknownm "You listening, Michael?"

translate english ch03_range01_734cf024:

    mi "I’m listening. Go on."

translate english ch03_range01_b1d116d6:

    unknownm "But this time, I’m a bit disappointed."

translate english ch03_range01_1d67082e:

    unknownm "Don't make things difficult for me, Michael."

translate english ch03_range01_377dbb88:

    unknownm "Please."

translate english ch03_range01_fb3ae5ad:

    unknownm "If my neck is on the line here, yours is next..."

translate english ch03_range01_d47d2269:

    unknownm "And then…"

translate english ch03_range01_cb42c91b:

    unknownm "Eventually, she’ll be in trouble as well."

translate english ch03_range01_7e8efde9:

    unknownm "Don't forget where your loyalties lie."

translate english ch03_range01_52023f83:

    mi "…………"

translate english ch03_range01_5b3ff5bb:

    mi "Loyalty…"

translate english ch03_range01_24f36978:

    mi "So all the loyalty I've shown you so far isn't enough?"

translate english ch03_range01_2c6fd248:

    unknownm "No, I’m saying this because I’m genuinely concerned about you."

translate english ch03_range01_23e7a029:

    unknownm "If you don't handle this, I'll have to step in myself. Think about what that means."

translate english ch03_range01_d3987f99_1:

    unknownm "………………"

translate english ch03_range01_75eb0b1f:

    mi "Are you threatening me?"

translate english ch03_range01_3fc7d7df:

    unknownm "Threatening you?"

translate english ch03_range01_58fe6b5c:

    unknownm "Do you really think a threat from me would actually scare you?"

translate english ch03_range01_06062db8:

    unknownm "I just want her to make a small adjustment to what she’s doing."

translate english ch03_range01_eaa8a11d:

    unknownm "That way, [h_name], you, and I all make more money."

translate english ch03_range01_ac0d7f1e:

    unknownm "Everyone wins here—so what the hell is the hold-up?"

translate english ch03_range01_19922f15:

    unknownm "She’s done this before, so why not now? It’s not even a crime."

translate english ch03_range01_02039c3e:

    unknownm "Look, you know how much trouble I went through convincing people here"

translate english ch03_range01_413554dd:

    unknownm "to tie what she does into a legitimate business."

translate english ch03_range01_48f066ed:

    unknownm "………"

translate english ch03_range01_5833da7c:

    unknownm "I'm telling you, it's time to return the favor."

translate english ch03_range01_13247773:

    mi "You already know."

translate english ch03_range01_7c87929b:

    mi "How she works is her decision."

translate english ch03_range01_33496893:

    mi "And she’s the one in charge—not you or me."

translate english ch03_range01_5a0afb39:

    mi "She’s been doing this long before either of us knew her."

translate english ch03_range01_37b5b432:

    mi "And there are plenty of bigger studios out there—why are you so fixated on her?"

translate english ch03_range01_71d56539:

    mi "Just get off her back already."

translate english ch03_range01_869635e9:

    unknownm "…………………"

translate english ch03_range01_6c7fae17:

    unknownm "Don't make me regret calling you a friend."

translate english ch03_range01_d2a779b6:

    unknownm "The pay is at least three times higher than what she’s getting now. Try to persuade her with that."

translate english ch03_range01_982ed745:

    unknownm "………………"

translate english ch03_range01_00864d0c:

    unknownm "And wrap this up with her as fast as you pull that trigger."

translate english ch03_range01_bade93bd:

    unknownm "If someone else has to step in, things are going to get very ugly, very fast."

translate english ch03_range01_dd504f41:

    unknownm "If some suit who knows nothing about this business gets involved, it'll be a total bloodbath."

translate english ch03_range01_2da443e0_1:

    unknownm "You listening, Michael?"

translate english ch03_range01_54b658b1:

    mi "I am."

translate english ch03_range01_5f11a854:

    unknownm "Good."

translate english ch03_range01_4481acf2:

    unknownm "I’ll send a woman over—enjoy yourself tonight and go see [h_name] tomorrow."

translate english ch03_range01_1217f827:

    unknownm "I've got a girl who has a real thing for soldiers. You're going to love her."

translate english ch03_range01_84939a0e:

    unknownm "You should see women more often. It’ll change your life."

translate english ch03_range01_cb773966:

    unknownm "How long are you going to stay holed up there, just rotting away with your guns?"

translate english ch03_range01_c1fd06e9:

    unknownm "And let’s grab a drink sometime soon, alright?"

translate english ch03_range01_a2a5922c_1:

    mi "………………"

translate english ch03_range01_1d9a6c9b:

    mi "I don’t need a woman."

translate english ch03_range01_5d995662:

    mi "And I used to be in the military. Now I’m a civilian."

translate english ch03_range01_f33a4500:

    mi "I’ll talk to her again and call you."

translate english ch03_range01_61bce9a9:

    unknownm "Alright. Talk to you later."

translate english ch03_range01_a2a5922c_2:

    mi "………………"

translate english ch03_range01_174000f0:

    mi "If someone else steps in, everything will fall apart?"

translate english ch03_range01_8e3d7272:

    mi "People who’ve never seen a real disaster sure love to run their mouths."

translate english ch03_hstudio02_78bd2606:

    x "**(It’s been a while since a shoot.)**"

translate english ch03_hstudio02_11898b7f:

    x "**(Almost two months?)**"

translate english ch03_hstudio02_d98c5c2d:

    x "**(Look at this.)**"

translate english ch03_hstudio02_4dc42d25:

    x "**(I've gotten a bit lazy since I haven't been shooting—I think I've put on a little weight around the waist.)**"

translate english ch03_hstudio02_3c16d742:

    x "**(Not good.)**"

translate english ch03_hstudio02_ccdcf50d:

    x "………"

translate english ch03_hstudio02_263f9460:

    x "**(I should ask [h_name] to schedule more shoots.)**"

translate english ch03_hstudio02_ab75b5fe:

    x "**(It’s far, so when I come, I’d rather do more at once.)**"

translate english ch03_hstudio02_45ebd27c:

    x "**(That’d probably be better for her too.)**"

translate english ch03_hstudio02_834351d5:

    x "Hmm……"

translate english ch03_hstudio02_de73c5f1:

    h "Ma’am."

translate english ch03_hstudio02_1daa4443:

    h "Are you ready over there?"

translate english ch03_hstudio02_1c5aa70a:

    h "We’re about to start shooting."

translate english ch03_hstudio02_c99c2226:

    x "Yes, I’m ready."

translate english ch03_hstudio02_d9bb82ca:

    x "How do I look?"

translate english ch03_hstudio02_5f676f1c:

    x "Does it match the reference the client sent?"

translate english ch03_hstudio02_5f98d6a9:

    h "Wow, ma’am."

translate english ch03_hstudio02_44bdac6c:

    h "If the client sees this, they’ll probably ask to sign you as an exclusive model."

translate english ch03_hstudio02_57dd4394:

    h "You’re the most beautiful woman on earth."

translate english ch03_hstudio02_b0b0894e:

    x "Haha, no, don’t say that."

translate english ch03_hstudio02_9384db24:

    x "The most beautiful woman is you, [h_name], hehe."

translate english ch03_hstudio02_469fbe12:

    h "Thank you, hehe."

translate english ch03_hstudio02_ec8e0a0a:

    h "Alright, let’s go over today’s scenes one more time."

translate english ch03_hstudio02_8f8aa0ca:

    x "This brand’s designs are getting bolder by the day, haha."

translate english ch03_hstudio02_7b10b946:

    h "Right?"

translate english ch03_hstudio02_9ad4bb99:

    h "The designer here specifically insisted that it had to be you, ma'am."

translate english ch03_hstudio02_4f563c23:

    h "You’ve practically become the face of this brand at this point, haha."

translate english ch03_hstudio02_2fb6eea8:

    h "I wouldn’t be surprised if they offer you a contract soon."

translate english ch03_hstudio02_c95b7bea:

    x "Wow, that’d be amazing, haha."

translate english ch03_hstudio02_aa0e8646:

    x "I like it too. The designs really match my image."

translate english ch03_hstudio02_a1b75871:

    h "And like we discussed, tomorrow’s shoot is scheduled with a male model."

translate english ch03_hstudio02_15d9d385:

    h "It’s a lingerie brand, but they’ve requested semi-nude shots, so there will be some nudity involved."

translate english ch03_hstudio02_e59d2dbe:

    x "Yes, I remember."

translate english ch03_hstudio02_adc2b5f0:

    x "It’s the first nude couple shoot of my career, so I’m actually a little nervous, haha."

translate english ch03_hstudio02_07782579:

    h "You’re a professional, Madam. I know you’ll do great. Just do what you always do."

translate english ch03_hstudio02_25146628:

    h "I’ll keep the male model in check, so you don’t have to worry about a thing."

translate english ch03_hstudio02_a8707140:

    h "And of course, the pay will be higher."

translate english ch03_hstudio02_f913d113:

    x "Haha, don’t worry about the money. You and I go back too far to be fussing over things like that."

translate english ch03_hstudio02_e1d94b40:

    x "I’m just happy that working as a model has helped me stay in shape and become healthier."

translate english ch03_hstudio02_00c65fb1:

    x "And you’re the one who built my modeling career, [h_name]."

translate english ch03_hstudio02_c7e932a4:

    x "So don’t worry about things like that."

translate english ch03_hstudio02_672c7cfc:

    h "Alright, haha."

translate english ch03_hstudio02_203a5da5:

    h "Then shall we begin?"

translate english ch03_hstudio02_058667db:

    n "Click!"

translate english ch03_hstudio02_058667db_1:

    n "Click!"

translate english ch03_hstudio02_94fdaf49:

    h "Good."

translate english ch03_hstudio02_058667db_2:

    n "Click!"

translate english ch03_hstudio02_058667db_3:

    n "Click!"

translate english ch03_hstudio02_1f89b0b2:

    h "Very nice, ma’am."

translate english ch03_hstudio02_df92eb5a:

    h "Give me a slightly more confident pose."

translate english ch03_hstudio02_058667db_4:

    n "Click!"

translate english ch03_hstudio02_058667db_5:

    n "Click!"

translate english ch03_hstudio02_c73d0fd8:

    h "Very good."

translate english ch03_hstudio02_058667db_6:

    n "Click!"

translate english ch03_hstudio02_058667db_7:

    n "Click!"

translate english ch03_hstudio02_058667db_8:

    n "Click!"

translate english ch03_hstudio02_3eb94934:

    h "Excellent."

translate english ch03_hstudio02_058667db_9:

    n "Click!"

translate english ch03_hstudio02_7257ded3:

    h "Good. Now, let’s go for a chic, stoic look."

translate english ch03_hstudio02_058667db_10:

    n "Click!"

translate english ch03_hstudio02_1067e9f4:

    h "Good. That’s it."

translate english ch03_hstudio02_058667db_11:

    n "Click!"

translate english ch03_hstudio02_e9bb6feb:

    h "Let’s emphasize the hips."

translate english ch03_hstudio02_058667db_12:

    n "Click!"

translate english ch03_hstudio02_5c41cd8b:

    h "Good. Very sensual."

translate english ch03_hstudio02_59ea07b8:

    h "With a model like you, the product really stands out, hehe."

translate english ch03_hstudio02_058667db_13:

    n "Click!"

translate english ch03_hstudio02_c73d0fd8_1:

    h "Very nice."

translate english ch03_hstudio02_5918b132:

    h "It’s a shame we put so much effort into each pose, yet only one or two shots get used."

translate english ch03_hstudio02_21da6b26:

    x "I agree. I’ve actually thought about putting together a photo book later on."

translate english ch03_hstudio02_2ae229b6:

    h "Alright, let’s change into the lavender set."

translate english ch03_hstudio02_058667db_14:

    n "Click!"

translate english ch03_hstudio02_81f4fe29:

    h "This time, emphasize the chest a bit."

translate english ch03_hstudio02_058667db_15:

    n "Click!"

translate english ch03_hstudio02_b8be8c80:

    h "Amazing, ma’am!"

translate english ch03_hstudio02_058667db_16:

    n "Click!"

translate english ch03_hstudio02_058667db_17:

    n "Click!"

translate english ch03_hstudio02_058667db_18:

    n "Click!"

translate english ch03_hstudio02_0cabbc24:

    h "Good. Feel free to pose naturally."

translate english ch03_hstudio02_058667db_19:

    n "Click!"

translate english ch03_hstudio02_058667db_20:

    n "Click!"

translate english ch03_hstudio02_058667db_21:

    n "Click!"

translate english ch03_hstudio02_058667db_22:

    n "Click!"

translate english ch03_hstudio02_058667db_23:

    n "Click!"

translate english ch03_hstudio02_058667db_24:

    n "Click!"

translate english ch03_hstudio02_e04db9c9:

    h "You look absolutely beautiful, ma’am."

translate english ch03_hstudio02_058667db_25:

    n "Click!"

translate english ch03_hstudio02_d4d77bb5:

    n "Madam X and [h_name], as always, devoted themselves fully to their roles."

translate english ch03_hstudio02_2d6e3ca6:

    n "Amid the rising heat, the shoot progressed smoothly."

translate english ch03_hstudio02_4b75bc19:

    n "That was excellent, ma’am."

translate english ch03_hstudio02_3963b81c:

    n "Now let’s switch to set B and move to the chair pose."

translate english ch03_hstudio02_4443ebc5:

    x "Alright."

translate english ch03_hstudio02_03b4f37f:

    x "Maybe because it’s been a while, I’m putting in even more effort."

translate english ch03_hstudio02_058667db_26:

    n "Click!"

translate english ch03_hstudio02_b5a2c5c8:

    h "Very good!"

translate english ch03_hstudio02_058667db_27:

    n "Click!"

translate english ch03_hstudio02_058667db_28:

    n "Click!"

translate english ch03_hstudio02_c5faf790:

    h "Let’s lift your hips just a bit more."

translate english ch03_hstudio02_a3575fe4:

    h "That line looks really nice right now."

translate english ch03_hstudio02_058667db_29:

    n "Click!"

translate english ch03_hstudio02_058667db_30:

    n "Click!"

translate english ch03_hstudio02_b5a2c5c8_1:

    h "Very good!"

translate english ch03_hstudio02_058667db_31:

    n "Click!"

translate english ch03_hstudio02_62a1f3eb:

    h "Good, your expression is perfect—hold that."

translate english ch03_hstudio02_058667db_32:

    n "Click!"

translate english ch03_hstudio02_bc42b629:

    h "Let’s go a bit bolder."

translate english ch03_hstudio02_eb83251a:

    h "Fantastic!"

translate english ch03_hstudio02_058667db_33:

    n "Click!"

translate english ch03_hstudio02_058667db_34:

    n "Click!"

translate english ch03_hstudio02_058667db_35:

    n "Click!"

translate english ch03_hstudio02_058667db_36:

    n "Click!"

translate english ch03_hstudio02_058667db_37:

    n "Click!"

translate english ch03_hstudio02_058667db_38:

    n "Click!"

translate english ch03_hstudio02_b7a88b68:

    h "So sexy. Let’s wrap it up with this mood."

translate english ch03_hstudio02_7e39a0c2:

    h "Can you give me a look like you’re looking down on a man?"

translate english ch03_hstudio02_10185a89:

    x "Haha, sure."

translate english ch03_hstudio02_058667db_39:

    n "Click!"

translate english ch03_hstudio02_058667db_40:

    n "Click!"

translate english ch03_hstudio02_f3897df1:

    h "The mood was great today—this is the last shot."

translate english ch03_hstudio02_058667db_41:

    n "Click!"

translate english ch03_hstudio02_ded0a2f6:

    h "Good. That’s a wrap for today."

translate english ch03_hstudio02_9679e67a:

    h "That was a great shoot, X."

translate english ch03_hstudio02_5b89b255:

    x "Haha, great work, [h_name]."

translate english ch03_hstudio02_bae4b892:

    x "Thanks to your direction, I enjoyed this shoot again."

translate english ch03_hstudio02_b96f5ff8:

    x "I’ll go get changed."

translate english ch03_hstudio02_dceeb191:

    n "The phone rings."

translate english ch03_hstudio02_94253ada:

    h "….."

translate english ch03_hstudio02_67aca949:

    mi "Hey, [h_name], how’ve you been?"

translate english ch03_hstudio02_29d1c9b8:

    h "Oh, Michael. I was actually about to call you…"

translate english ch03_hstudio02_9d8ffc03:

    h "Everything alright?"

translate english ch03_hstudio02_7d8f0a1d:

    mi "I got another call from Ronald."

translate english ch03_hstudio02_e2abd98a:

    mi "He brought it up again."

translate english ch03_hstudio02_518ae386:

    mi "………"

translate english ch03_hstudio02_85c6e8d2:

    mi "He was a bit more aggressive this time."

translate english ch03_hstudio02_f0768f32:

    h "………………"

translate english ch03_hstudio02_a7c788ae:

    h "Oh no…"

translate english ch03_hstudio02_0a8a3e21:

    h "Same demand again?"

translate english ch03_hstudio02_bc7f5bd5:

    mi "Yeah. The same one I told you about last time."

translate english ch03_hstudio02_af3181c4:

    h "……"

translate english ch03_hstudio02_b08c80aa:

    mi "I’m sorry for asking you this, [h_name]."

translate english ch03_hstudio02_e5463b9e:

    h "Ha… this is difficult."

translate english ch03_hstudio02_6ad3ebe8:

    h "So they said the same thing again…"

translate english ch03_hstudio02_7bb4b28e:

    h "What am I supposed to do…"

translate english ch03_hstudio02_7f0ac34c:

    h "Ha… Michael…"

translate english ch03_hstudio02_3ea0a18d:

    h "I’m not doing it."

translate english ch03_hstudio02_70b2200e:

    h "You know I don’t shoot that kind of stuff anymore."

translate english ch03_hstudio02_b569a6f0:

    h "I made my position clear, so why are they asking again?"

translate english ch03_hstudio02_63f7dd6a:

    h "Oh my god. And what now? Video?"

translate english ch03_hstudio02_75582974:

    h "What, do they think I'm some kind of porn director?"

translate english ch03_hstudio02_b9e12893:

    mi "I know, [h_name]."

translate english ch03_hstudio02_211e7f00:

    mi "But you know what they’re like."

translate english ch03_hstudio02_b0d7a6a5:

    mi "If you don't take this, I'm afraid things might spiral out of control."

translate english ch03_hstudio02_ef1585f4:

    mi "Could you just do this one shoot?"

translate english ch03_hstudio02_29a2ba51:

    mi "I’ll try to talk them down next time."

translate english ch03_hstudio02_cc7d165c:

    mi "You know we're stuck taking their jobs until we can secure another distributor."

translate english ch03_hstudio02_10092c42:

    h "Ha… Michael!!"

translate english ch03_hstudio02_1b4014ed:

    h "The shoot is tomorrow! How am I supposed to convince both Madam X and the male model on such short notice?!"

translate english ch03_hstudio02_aa2e947a:

    h "Oh my god, Michael…"

translate english ch03_hstudio02_5b09d480:

    h "Explicit shots with actual exposure..."

translate english ch03_hstudio02_be5b6899:

    h "If I do this, it’s like I’m just falling back into the same old trap..."

translate english ch03_hstudio02_7f254ec5:

    h "Ha………………"

translate english ch03_hstudio02_c23be412:

    h "Sorry for raising my voice, Michael."

translate english ch03_hstudio02_f0768f32_1:

    h "………………"

translate english ch03_hstudio02_12084ce6:

    h "So there’s really no choice, right?"

translate english ch03_hstudio02_a2a5922c:

    mi "………………"

translate english ch03_hstudio02_c5c68f25:

    mi "Right now… no."

translate english ch03_hstudio02_f0d2a50c:

    mi "I think it’s better to avoid a major conflict for now."

translate english ch03_hstudio02_d8bf4645:

    mi "I’ll talk to Ronald and try to raise the rate for this job."

translate english ch03_hstudio02_bb02f241:

    mi "He’s the kind of guy who’ll listen to that much."

translate english ch03_hstudio02_4a8a031f:

    h "No, it’s fine. I don’t want to put you in a difficult spot."

translate english ch03_hstudio02_2a01c13d:

    h "I’ll talk to the models and call you back."

translate english ch03_hstudio02_0fa3cdb2:

    h "I think it’s finally time we found a new client."

translate english ch03_hstudio02_2f08bb2e:

    mi "Yeah, I agree."

translate english ch03_hstudio02_ef829db7:

    h "Ha………"

translate english ch03_hstudio02_a5d315fe:

    x "Did something happen?"

translate english ch03_hstudio02_7caf97d7:

    h "………………"

translate english ch03_hstudio02_0bda5aac:

    h "Uh… ma’am…"

translate english ch03_hstudio02_e42822b6:

    h "Something came up…"

translate english ch03_hstudio02_33978d3d:

    x "Something came up?"

translate english ch03_hstudio02_d3b60413:

    h "Yeah…"

translate english ch03_hstudio02_8103aa64:

    h "The nature of tomorrow’s shoot has changed a bit."

translate english ch03_hstudio02_9ab58bb3:

    h "Actually… it’s changed quite a lot…"

translate english ch03_hstudio02_e2d26f58:

    x "Changed how? What do you mean?"

translate english ch03_hstudio02_85be9a1e:

    h "Tomorrow, it looks like we’ll have to do a full nude shoot with the male model."

translate english ch03_hstudio02_a802ae3d:

    x "!!"

translate english ch03_hstudio02_3b4b5a75:

    h "And there will be some simulated sexual content."

translate english ch03_hstudio02_adccce65:

    x "Sexual content?!!!!!!!!!"

translate english ch03_hstudio02_0fe00e9a:

    x "Wasn’t this supposed to be a lingerie brand?"

translate english ch03_hstudio02_ac5a1433:

    h "I’m sorry."

translate english ch03_hstudio02_6e34017b:

    h "It’s a request from the entertainment company that owns the brand…"

translate english ch03_hstudio02_ccdcf50d_1:

    x "………………"

translate english ch03_hstudio02_f6094b41:

    x "Even so, how can they suddenly change it the day before?"

translate english ch03_hstudio02_06276b11:

    h "I know…"

translate english ch03_hstudio02_ccdcf50d_2:

    x "………………"

translate english ch03_hstudio02_a73d8f49:

    x "You mean actual sex?"

translate english ch03_hstudio02_e1854397:

    h "No, absolutely not."

translate english ch03_hstudio02_aa11d905:

    h "If that were the case, I would’ve refused immediately."

translate english ch03_hstudio02_06744d1b:

    h "It’s not real—just some simulated intimacy and suggestive actions."

translate english ch03_hstudio02_b0a9643b:

    h "I’ll control the camera angles so it looks real."

translate english ch03_hstudio02_5432a2f5:

    h "It’s for an adult magazine, but they don’t show explicit penetration."

translate english ch03_hstudio02_f240c5ab:

    x "I see…"

translate english ch03_hstudio02_6537724c:

    h "I’m really sorry. You don’t have to do it if you’re not comfortable."

translate english ch03_hstudio02_81e46331:

    h "I’m not forcing you at all."

translate english ch03_hstudio02_4657cb05:

    x "Do you know where the photos will be published?"

translate english ch03_hstudio02_2aa4e5e2:

    h "They’ll probably be featured in Velvet Society…"

translate english ch03_hstudio02_86a91c2a:

    x "!!!!!!!!!!!!!"

translate english ch03_hstudio02_34ca9f53:

    x "Oh my god… Velvet Society?"

translate english ch03_hstudio02_e84bdc13:

    h "Yes."

translate english ch03_hstudio02_fbe2605c:

    x "Wow…"

translate english ch03_hstudio02_43015add:

    x "Phew..."

translate english ch03_hstudio02_3aa6bbeb:

    x "This is a tough decision…"

translate english ch03_hstudio02_3e869fa6:

    x "Velvet Society…"

translate english ch03_hstudio02_e35d5540:

    x "………………"

translate english ch03_hstudio02_3139e3c5:

    x "Alright, I’ll do it."

translate english ch03_hstudio02_db31d782:

    x "It’s not showing my face, and it’s not real sex—what’s the problem, haha."

translate english ch03_hstudio02_ad9a59c2:

    h "Ha… thank you so much."

translate english ch03_hstudio02_f82a750f:

    h "I’ll increase your pay for this shoot."

translate english ch03_hstudio02_e5c3bdac:

    h "I’m really, really sorry for asking this."

translate english ch03_hstudio02_edcc08c1:

    x "Haha, you don’t have to say that."

translate english ch03_hstudio02_07bf35c6:

    x "You’re the one who built my modeling career, [h_name], so of course I’ll do it."

translate english ch03_hstudio02_431b671d:

    x "And honestly, it sounds kind of exciting."

translate english ch03_hstudio02_6277ffaa:

    x "What model would turn down being featured in Velvet Society, haha."

translate english ch03_hstudio02_bc863f14:

    x "Feels like a new challenge for me."

translate english ch03_hstudio02_40b91128:

    h "Ha… thank you."

translate english ch03_hstudio02_b0628ea7:

    h "I’ll invite you to my place sometime. Let’s have dinner together."

translate english ch03_hstudio02_9bb28ee2:

    x "Haha, sure. I’ll look forward to it."

translate english ch03_hstudio02_73282546:

    x "You better invite me, haha."

translate english ch03_hstudio02_9e35bbbc:

    n "Late in the evening, with heavy rain pouring down,"

translate english ch03_hstudio02_0ac26ed4:

    n "[h_name] stood by the window, anxiously on the phone."

translate english ch03_hstudio02_89ecd44a:

    h "Ha… okay. You don’t have to apologize."

translate english ch03_hstudio02_0514d88c:

    h "It was an unreasonable request from the start."

translate english ch03_hstudio02_88b5e067:

    h "I’m honestly embarrassed that I even asked you that…"

translate english ch03_hstudio02_92ad9932:

    h "………"

translate english ch03_hstudio02_b2a4858d:

    h "Thank you so much for understanding."

translate english ch03_hstudio02_6acff1e0:

    h "I’ll reach out when the next schedule is set."

translate english ch03_hstudio02_fb6abed6:

    h "Take care."

translate english ch03_hstudio02_f50e08a4:

    h "Ha… I knew this would happen."

translate english ch03_hstudio02_77a3fb22:

    h "I had a bit of hope, but figures."

translate english ch03_hstudio02_7efff1c6:

    h "If I changed the shoot like this, I’d refuse too…"

translate english ch03_hstudio02_367bc29c:

    h "Ha………"

translate english ch03_hstudio02_69774c8a:

    h "Where the hell am I going to find a male model with 'adult magazine' specs at this hour..."

translate english ch03_hstudio02_cc5df66a:

    h "This is driving me crazy…"

translate english ch03_hstudio02_ac0eb614:

    h "Should I call Lena?"

translate english ch03_hstudio02_7549b788:

    h "She might know someone like that…"

translate english ch03_hstudio02_93690af8:

    h "No… ha…"

translate english ch03_hstudio02_34d18ada:

    h "It’s too far, and it’s way too late…"

translate english ch03_hstudio02_b35262b6:

    h "Ha, this is insane…"

translate english ch03_hstudio02_c1824178:

    h "Should I just tell Michael I can’t do it? Ha…"

translate english ch03_hstudio02_295b6236:

    h "No… then they’ll probably cut everything off…"

translate english ch03_hstudio02_b1b94bb8:

    d "Oh, [h_name], you’re here."

translate english ch03_hstudio02_3c36926b:

    d "Are you okay?"

translate english ch03_hstudio02_77673f80:

    d "………"

translate english ch03_hstudio02_faf7d35f:

    d "Did something happen?"

translate english ch03_hstudio02_1a422914:

    h "Oh, [d_name], you were home."

translate english ch03_hstudio02_b2698ebd:

    h "Sorry I didn’t even take care of dinner."

translate english ch03_hstudio02_dc5b4607:

    h "Something came up and I’m a bit out of it right now."

translate english ch03_hstudio02_ad862e00:

    d "No, it’s fine."

translate english ch03_hstudio02_61e764e0:

    d "It’s pouring outside and it was so quiet in here, I was actually just about to call and check on you."

translate english ch03_hstudio02_e0050995:

    h "Oh, I see… thank you."

translate english ch03_hstudio02_80c7f35c:

    d "Are you okay, [h_name]?"

translate english ch03_hstudio02_a50e42b9:

    d "You don’t look so well."

translate english ch03_hstudio02_00ab0aff:

    h "Ah, haha, it’s nothing…"

translate english ch03_hstudio02_0ca02f76:

    h "It’s really nothing…"

translate english ch03_hstudio02_e5c36b54:

    d "………"

translate english ch03_hstudio02_7f254ec5_1:

    h "Ha………………"

translate english ch03_hstudio02_2f45f202:

    h "Actually… it’s not nothing…"

translate english ch03_hstudio02_dcb4db6f:

    d "What’s wrong?…"

translate english ch03_hstudio02_1e640609:

    d "Is it something I can help with?"

translate english ch03_hstudio02_aa309a7b:

    h "Haha, something you can help with?"

translate english ch03_hstudio02_92ad9932_1:

    h "…………"

translate english ch03_hstudio02_c00016ff:

    n "Without thinking, her gaze reflexively dropped toward [d_name]’s crotch"

translate english ch03_hstudio02_7caf97d7_1:

    h "…………"

translate english ch03_hstudio02_c8f5196b:

    h "**(What am I even thinking right now… am I insane…)**"

translate english ch03_hstudio02_cc91ba84:

    h "Hey, [d_name]…"

translate english ch03_hstudio02_6225b646:

    d "Yes."

translate english ch03_hstudio02_156b30f1:

    h "Ha… no, it’s nothing…"

translate english ch03_hstudio02_c863e247:

    d "Hey, [h_name]…"

translate english ch03_hstudio02_e5a95238:

    d "I don’t know what’s going on, but you can tell me."

translate english ch03_hstudio02_3d4d41f5:

    d "Maybe it’s something I can help with."

translate english ch03_hstudio02_4338f07b:

    h "………"

translate english ch03_hstudio02_cc91ba84_1:

    h "Hey, [d_name]…"

translate english ch03_hstudio02_2cf6997d:

    h "I… have a problem…"

translate english ch03_hstudio02_c11c5e8f:

    d "A problem?"

translate english ch03_hstudio02_d9817c6e:

    h "I’m really sorry, but… could you help me just this once?"

translate english ch03_hstudio02_1f8103ad:

    d "Of course I’ll help."

translate english ch03_hstudio02_20c3100e:

    d "What is it?"

translate english ch03_hstudio02_8fa59540:

    h "It’s just…"

translate english ch03_hstudio02_2c4f06ef:

    h "…………………"

translate english ch03_hstudio02_1c350ddb:

    h "The thing is... I need you to take off your clothes..."

translate english ch03_hstudio02_fd587bab:

    h "…………"

translate english ch03_hstudio02_6a43b6a4:

    h "Every last stitch..."

translate english ch03_hstudio02_56c83770:

    d "You mean completely naked??!!!!"

translate english ch03_hstudio02_a5019034:

    h "I’m so sorry."

translate english ch03_hstudio02_001ded5f:

    h "I can’t believe I’m the kind of landlady who asks her own tenant for a favor like this..."

translate english ch03_hstudio02_b0199386:

    h "I think I must have lost my mind for a second."

translate english ch03_hstudio02_a5984c4c:

    h "Ha………"

translate english ch03_hstudio02_5a2991f8:

    d "Haha, no, it’s okay. Don’t worry."

translate english ch03_hstudio02_8ff08b7e:

    d "Honestly, it sounds kind of fun, haha."

translate english ch03_hstudio02_773b9435:

    d "If this goes well, I’ll probably be bragging about it to my friends for the rest of my life."

translate english ch03_hstudio02_291a88c6:

    d "It’s a unique experience during break,"

translate english ch03_hstudio02_2dde09c3:

    d "And more than anything, I’m just happy I can be of help to you, [h_name]."

translate english ch03_hstudio02_f30d3e6d:

    d "And since I’ll be wearing a mask, there’s no reason not to."

translate english ch03_hstudio02_a5596c6e:

    d "Of course, if you’re okay with it, haha."

translate english ch03_hstudio02_db15032b:

    h "Ah… well…"

translate english ch03_hstudio02_b47998b4:

    h "I don’t know if this is the right way to say it, but I’m okay with it."

translate english ch03_hstudio02_ff44f262:

    h "Ha………"

translate english ch03_hstudio02_7e90f34b:

    h "Thank you so much, [d_name]…"

translate english ch03_hstudio02_e8867974:

    h "No… I’m sorry…"

translate english strings:
    old "그녀의 곁으로 간다."
    new "Go to her side."

translate english ch03_hstudio02_92f21ed5:

    n "What should I do?"

translate english ch03_hstudio02_a89486db:

    d "Hey, [h_name]…"

translate english strings:
    old "그녀를 위로 한다."
    new "Comfort her."

translate english ch03_hstudio02_92f21ed5_1:

    n "What should I do?"

translate english ch03_hstudio02_9ffabee7:

    d "I'm really fine, so please don't beat yourself up over it"

translate english ch03_hstudio02_41ca37ab:

    d "Actually, I’m glad I can help you."

translate english ch03_hstudio02_aa34b01a:

    h "!!"

translate english ch03_hstudio02_ff1b97bd:

    d "Hey, [h_name]…"

translate english ch03_hstudio02_6fb272f8:

    d "Don’t worry. I’m really fine."

translate english ch03_hstudio02_649851cb:

    d "Just trust me."

translate english ch03_hstudio02_d168caf6:

    d "I'm already good to go."

translate english ch03_hstudio02_83261455:

    h "………"

translate english ch03_hstudio02_77673f80_1:

    d "………"

translate english ch03_hstudio02_670bffba:

    h "Thank you."

translate english ch03_hstudio02_15d061d9:

    h "I really owe you one, [d_name]."

translate english ch03_hstudio02_a0c84f1e:

    d "Haha, I’m actually really looking forward to this."

translate english ch03_hstudio02_ad7ab1c8:

    d "I’m a bit nervous too."

translate english ch03_hstudio02_7c0a9214:

    d "………………"

translate english ch03_hstudio02_e01abcd0:

    d "A nude shoot?!!"

translate english ch03_hstudio02_ef259e97:

    d "With my landlady?!!"

translate english ch03_hstudio02_89d279a5:

    d "Hahaha. So that means I’m putting it all out there."

translate english ch03_hstudio02_7c0a9214_1:

    d "………………"

translate english ch03_hstudio02_db0eb343:

    d "But I’ve never seen [h_name] looking that distressed before..."

translate english ch03_hstudio02_bbe593ed:

    d "It’s just a few photos—why is she having such a hard time asking me?"

translate english ch03_hstudio02_7c0a9214_2:

    d "………………"

translate english ch03_hstudio02_92c4eeeb:

    d "Is she that worried about seeing my dick again?"

translate english ch03_hstudio02_c8bbf1cd:

    d "Hmm………"

translate english ch03_hstudio02_ff44f262_1:

    h "Ha………"

translate english ch03_hstudio02_3a4abba5:

    h "Is this really the right thing to do?"

translate english ch03_hstudio02_d6b9cb0d:

    h "………………"

translate english ch03_hstudio02_00932829:

    h "Should I even be asking [d_name] to do something like this...?."

translate english ch03_hstudio02_ef829db7_1:

    h "Ha………"

translate english ch03_hstudio02_f22d892f:

    h "I don't know anymore... [h_name]."

translate english ch03_hstudio02_2ba077b7:

    h "I really don’t know…"

translate english ch03_hstudio02_ccd12750:

    h "Dammit, dammit, dammit."

translate english ch03_hstudio03_5b741aea:

    h "Oh, you're already here, ma'am."

translate english ch03_hstudio03_5372283b:

    h "It’s really pouring out there."

translate english ch03_hstudio03_8361e152:

    x "Good morning, [h_name]."

translate english ch03_hstudio03_a57232d6:

    x "I was just reading to settle my nerves a bit."

translate english ch03_hstudio03_0792ca2a:

    d "Hello, I’m [d_name]."

translate english ch03_hstudio03_b59f765e:

    d "Nice to meet you."

translate english ch03_hstudio03_01efce3f:

    d "**(So this is [h_name]’s studio, hehe.)**"

translate english ch03_hstudio03_0e78b4a9:

    x "!!!!!!!!!!!"

translate english ch03_hstudio03_f8ab224f:

    x "**([d_name]???)**"

translate english ch03_hstudio03_b1fa8ddb:

    n "When Sophia lifted her head, she saw her student [d_name] smiling brightly."

translate english ch03_hstudio03_ebb2ff67:

    n "For a brief moment, she thought he might be [h_name]’s family,"

translate english ch03_hstudio03_60e238b8:

    n "but when she realized he was the male model for today’s shoot, she felt overwhelming despair."

translate english ch03_hstudio03_d85fcb74:

    x "Ah… [h_name]."

translate english ch03_hstudio03_382461fa:

    x "Could I speak with you privately for a moment?"

translate english ch03_hstudio03_981c5451:

    h "Of course."

translate english ch03_hstudio03_4338f07b:

    h "…………"

translate english ch03_hstudio03_64f91cb7:

    h "What’s wrong, ma’am?"

translate english ch03_hstudio03_f7872401:

    h "Is there a problem?"

translate english ch03_hstudio03_a2ec806d:

    x "Is that young man the model for today?"

translate english ch03_hstudio03_b4b1626e:

    x "He’s not, right?"

translate english ch03_hstudio03_6c9ac422:

    x "………………"

translate english ch03_hstudio03_2ad7e781:

    x "He’s just someone you know, isn't he?"

translate english ch03_hstudio03_5ac74789:

    h "Well………"

translate english ch03_hstudio03_a539f034:

    h "He’s not exactly a model, actually…"

translate english ch03_hstudio03_087a64b9:

    h "Actually... he’s my boyfriend."

translate english ch03_hstudio03_92a90223:

    x "………………"

translate english ch03_hstudio03_178fd2c2:

    x "Y..your boyfriend?"

translate english ch03_hstudio03_b5843f07:

    h "Yes…"

translate english ch03_hstudio03_915fe019:

    h "He said he really wanted to see me work, so he came along."

translate english ch03_hstudio03_8e1d3ee2:

    h "It does look like there’s quite an age gap, doesn’t it?"

translate english ch03_hstudio03_92a90223_1:

    x "………………"

translate english ch03_hstudio03_a9e347d1:

    h "Haha, just kidding."

translate english ch03_hstudio03_f119baa4:

    h "He’s the male model for today’s shoot."

translate english ch03_hstudio03_d2041336:

    h "He’s a bit young, right? Haha, sorry—the model had to be changed suddenly."

translate english ch03_hstudio03_155e2ebe:

    h "The original model backed out, saying he couldn't handle the updated script, so I had no choice."

translate english ch03_hstudio03_ef09ff4a:

    h "I’m really sorry. This one’s on me."

translate english ch03_hstudio03_4e947528:

    x "Ah…"

translate english ch03_hstudio03_49fd02d5:

    x "No, it’s okay, [h_name]."

translate english ch03_hstudio03_89f2d1fc:

    x "Age doesn’t matter…"

translate english ch03_hstudio03_243131db:

    x "Um…"

translate english ch03_hstudio03_6eb7d972:

    x "Is he your son or a relative?"

translate english ch03_hstudio03_0589c9a2:

    h "No, he’s not."

translate english ch03_hstudio03_d9dbf637:

    h "Well…"

translate english ch03_hstudio03_e602a245:

    h "He’s a model introduced by a friend."

translate english ch03_hstudio03_a1d7704d:

    h "Why, would you feel uncomfortable shooting with him?"

translate english ch03_hstudio03_cb0632a4:

    x "No…"

translate english ch03_hstudio03_92a90223_2:

    x "………………"

translate english ch03_hstudio03_4cb9d279:

    x "I guess I got a little nervous."

translate english ch03_hstudio03_3efada8d:

    x "Oh, and my throat isn’t great today, so I’ll try not to speak much if possible."

translate english ch03_hstudio03_16f5a370:

    x "Is that okay?"

translate english ch03_hstudio03_08f0b760:

    h "Of course, that’s no problem at all, ma’am."

translate english ch03_hstudio03_ce0cf70c:

    h "We’ll adjust everything to you today."

translate english ch03_hstudio03_b1ddf386:

    h "If anything feels uncomfortable, just give me a signal. I’ll stop right away."

translate english ch03_hstudio03_d9e6e570:

    x "Alright. Thank you."

translate english ch03_hstudio03_78059be0:

    x "I’ll go change."

translate english ch03_hstudio03_e311f180:

    n "Before the shoot, they reviewed the script again."

translate english ch03_hstudio03_9dccf75c:

    d "Wow... these poses are intense..."

translate english ch03_hstudio03_7d9ebb3d:

    h "R-right? Haha…"

translate english ch03_hstudio03_6089a08b:

    h "The posing might feel awkward, but just follow my directions."

translate english ch03_hstudio03_245ad572:

    d "Okay, I’ll remember!"

translate english ch03_hstudio03_f358cc0b:

    x "Alright then, shall we begin?"

translate english ch03_hstudio03_a254b6d4:

    d "!!!!!"

translate english ch03_hstudio03_92a90223_3:

    x "………………"

translate english ch03_hstudio03_5d53b996:

    h "Um… ma’am…"

translate english ch03_hstudio03_241d4162:

    h "If you’re uncomfortable, should I have the male model wait out of sight for now?"

translate english ch03_hstudio03_603aa0f7:

    n "At [h_name]’s words, Sophia replied in a soft voice."

translate english ch03_hstudio03_028d03fe:

    x "It’s okay."

translate english ch03_hstudio03_a44aee9f:

    x "We’re all professionals here, right?"

translate english ch03_hstudio03_40389547:

    x "He needs to get used to the atmosphere too, so it’s better if he watches everything."

translate english ch03_hstudio03_16467479:

    h "Alright, got it."

translate english ch03_hstudio03_dad40644:

    h "Just a moment, ma’am—I’ll go talk to him as well."

translate english ch03_hstudio03_8c683eea:

    n "Before the shoot, [h_name] wanted to confirm his intentions one more time."

translate english ch03_hstudio03_ed30cd8c:

    n "The poses in the script were clearly a lot for everyone involved."

translate english ch03_hstudio03_dcf0e4f3:

    h "Can we talk for a second?"

translate english ch03_hstudio03_ccdcf50d:

    x "………………"

translate english ch03_hstudio03_933a9ebc:

    x "Exposing my naked body to my own student?..."

translate english ch03_hstudio03_8d74c144:

    x "How on earth am I supposed to act out a sex scene with [d_name]?..."

translate english ch03_hstudio03_53c1bc21:

    x "Ha… how did this even happen…"

translate english ch03_hstudio03_3aec31a2:

    x "Calm down, Sophia… calm down…"

translate english ch03_hstudio03_635cac66:

    x "They’re just photos… just a shoot between two people…"

translate english ch03_hstudio03_903b55ec:

    h "Um…"

translate english ch03_hstudio03_caf869b4:

    h "I’ll ask one last time."

translate english ch03_hstudio03_9a4aaf1a:

    h "Are you really okay with this, [d_name]?"

translate english strings:
    old "남자는 한입으로 두 말 하지 않는다."
    new "A man never goes back on his word."

translate english ch03_hstudio03_92f21ed5:

    n "What should I do?"

translate english ch03_hstudio03_1b8a211c:

    d "Haha, you don’t have to keep asking."

translate english ch03_hstudio03_fe52c999:

    d "A man never goes back on his word."

translate english ch03_hstudio03_3ad8afa2:

    d "I’m really fine."

translate english ch03_hstudio03_0ce5e89a:

    d "I’m actually excited to tell my friends about this later, haha."

translate english ch03_hstudio03_19c5a31d:

    d "I feel like I was born for this, haha."

translate english ch03_hstudio03_72a5edb3:

    h "Haha, what do you mean by that?"

translate english ch03_hstudio03_e79f1e59:

    d "A fun break, a paying side job, and two beautiful women."

translate english ch03_hstudio03_e08de18d:

    d "No problem at all!"

translate english ch03_hstudio03_12e2dc69:

    h "What?!!"

translate english ch03_hstudio03_02773723:

    h "Haha, I forgot how smooth a talker you are, [d_name]."

translate english ch03_hstudio03_f5ea69d8:

    h "Haha, alright then, let’s head in."

translate english ch03_hstudio03_83dadccd:

    n "[d_name] stepped into a whirlwind of conflicting emotions."

translate english ch03_hstudio03_8bbe65e5:

    n "By acting confident, he wanted to reassure [h_name], who was worried about him,"

translate english ch03_hstudio03_a589ff5b:

    n "and at the same time show her that he was someone she could rely on."

translate english ch03_hstudio03_741a08ce:

    n "He wanted to earn clear points with [h_name]."

translate english ch03_hstudio03_ce3b6cb6:

    n "And he also wanted to show the mysterious female model that he was a confident, leading man."

translate english ch03_hstudio03_5c9df0d6:

    n "As a result, he ended up making an unintended mistake."

translate english strings:
    old "그녀의 허리를 안는다."
    new "Wrap an arm around her waist."

translate english ch03_hstudio03_616cac37:

    n "As they walked back into the studio, [d_name]’s hand settled around her waist."

translate english ch03_hstudio03_41aa9d30:

    n "She was startled, but she didn't react."

translate english ch03_hstudio03_2a7d95c7:

    n "Or rather, she didn't want to create an awkward atmosphere before the shoot."

translate english ch03_hstudio03_aa34b01a:

    h "!!"

translate english ch03_hstudio03_a01f4f46:

    h "………"

translate english ch03_hstudio03_8547999a:

    x "Oh boy…"

translate english ch03_hstudio03_c8f1395c:

    x "**(He just put his hand on [h_name]’s waist??)**"

translate english ch03_hstudio03_8e1a4f1a:

    x "**(Are they actually dating??)**"

translate english ch03_hstudio03_1c53af99:

    x "**(………………)**"

translate english ch03_hstudio03_058667db:

    n "Click!"

translate english ch03_hstudio03_e64417ba:

    n "Sophia and [h_name], as always, smoothly began their work."

translate english ch03_hstudio03_bd41a93e:

    n "Sophia, as if completely unfazed by [d_name], struck bold and elegant poses."

translate english ch03_hstudio03_058667db_1:

    n "Click!"

translate english ch03_hstudio03_058667db_2:

    n "Click!"

translate english ch03_hstudio03_b40b8d74:

    n "As the shoot went on, a quiet tension filled the studio."

translate english ch03_hstudio03_737e4340:

    n "The only sounds were the rain hitting the window and the camera shutter."

translate english ch03_hstudio03_058667db_3:

    n "Click!"

translate english ch03_hstudio03_058667db_4:

    n "Click!"

translate english ch03_hstudio03_058667db_5:

    n "Click!"

translate english ch03_hstudio03_058667db_6:

    n "Click!"

translate english ch03_hstudio03_d77c3db2:

    n "With the presence of a third party adding a subtle tension,"

translate english ch03_hstudio03_4e46c339:

    n "the shoot progressed quickly and smoothly."

translate english ch03_hstudio03_2f394d8d:

    n "But as it continued, Sophia’s nude segment drew closer,"

translate english ch03_hstudio03_058667db_7:

    n "Click!"

translate english ch03_hstudio03_42d2a933:

    n "and deep within her, an unfamiliar emotion began to surge."

translate english ch03_hstudio03_5d87ca8f:

    n "The fact that even her knowledge of psychology couldn’t explain it only confused her more."

translate english ch03_hstudio03_058667db_8:

    n "Click!"

translate english ch03_hstudio03_058667db_9:

    n "Click!"

translate english ch03_hstudio03_b922e473:

    n "The sound of [h_name]’s shutter echoed repeatedly through the studio."

translate english ch03_hstudio03_e65efa7b:

    n "Sophia, as if forgetting the earlier shock, focused on her usual confident poses."

translate english ch03_hstudio03_191506c4:

    n "After some time passed, the first half of the shoot came to an end."

translate english ch03_hstudio03_76fcc7e3:

    h "Great work, ma’am!"

translate english ch03_hstudio03_09cf2a10:

    h "Let’s take a short break, then we’ll start the nude shoot!"

translate english ch03_hstudio03_bb920e29:

    d "!!!!!!!"

translate english ch03_hstudio03_76fbe299:

    x "Phew………"

translate english ch03_hstudio03_ab5f95f3:

    n "They took a short break."

translate english ch03_hstudio03_c2b1e7d0:

    n "[h_name] reviewed the photos, while [d_name] kept taking deep breaths, trying to steady himself."

translate english ch03_hstudio03_e3c92b81:

    d "!!!!!!!!!!!"

translate english ch03_hstudio03_7c0a9214:

    d "………………"

translate english ch03_hstudio03_b01c1b10:

    h "Alright… let’s s-start the shoot…"

translate english ch03_hstudio03_3f9a24db:

    h "………………"

translate english ch03_hstudio03_568c6c20:

    n "Sophia kept calming herself to maintain her composure."

translate english ch03_hstudio03_18011dfd:

    n "But exposing herself in front of her own student, [d_name], wasn’t easy."

translate english ch03_hstudio03_3dd33ebb:

    n "She could only hope he wouldn’t fully recognize her."

translate english ch03_hstudio03_14964dc1:

    n "Amid the tense atmosphere, the shoot resumed."

translate english ch03_hstudio03_058667db_10:

    n "Click!"

translate english ch03_hstudio03_058667db_11:

    n "Click!"

translate english ch03_hstudio03_058667db_12:

    n "Click!"

translate english ch03_hstudio03_ece42a43:

    h "You look beautiful, ma’am! Just relax your shoulders a bit."

translate english ch03_hstudio03_dc66d364:

    d "**(Wow… both [h_name] and that model are total pros…)**"

translate english ch03_hstudio03_2e985903:

    d "**(The energy in this studio is intense…)**"

translate english ch03_hstudio03_058667db_13:

    n "Click!"

translate english ch03_hstudio03_534ca24b:

    n "[d_name] began to worry whether he could keep up with her."

translate english ch03_hstudio03_99b01227:

    n "That was how professional Sophia’s performance was."

translate english ch03_hstudio03_91587a7d:

    n "In front of her own student, she completed the first shoot with bold poses."

translate english ch03_hstudio03_eee2ee7e:

    h "Great job, ma’am. Now let’s change into the second outfit."

translate english ch03_hstudio03_6f26c497:

    h "Hold on, I’ll take a few test shots."

translate english ch03_hstudio03_058667db_14:

    n "Click!"

translate english ch03_hstudio03_058667db_15:

    n "Click!"

translate english ch03_hstudio03_037e35ea:

    h "Your waistline looks great—hold that."

translate english ch03_hstudio03_058667db_16:

    n "Click!"

translate english ch03_hstudio03_aea258e5:

    n "Sophia revealed her body in front of her student."

translate english ch03_hstudio03_555bbc5d:

    n "Whether [d_name] recognized her face no longer mattered."

translate english ch03_hstudio03_c9357193:

    n "The shame… and resentment toward herself for making this choice…"

translate english ch03_hstudio03_058667db_17:

    n "Click!"

translate english ch03_hstudio03_d6797747:

    n "For the first time, she felt ashamed of her own lewd body."

translate english ch03_hstudio03_b1f7c420:

    n "She wanted to cover herself immediately, especially her nipples reacting against her will."

translate english ch03_hstudio03_1725cd87:

    n "This experience began to create small cracks in the fortress of her narcissism."

translate english ch03_hstudio03_058667db_18:

    n "Click!"

translate english ch03_hstudio03_232a49a1:

    h "Wow, that expression just now was amazing."

translate english ch03_hstudio03_058667db_19:

    n "Click!"

translate english ch03_hstudio03_91e9b1aa:

    n "And those cracks began to grow faster than she expected."

translate english ch03_hstudio03_058667db_20:

    n "Click!"

translate english ch03_hstudio03_3bd14ee8:

    h "!!!!!!!"

translate english ch03_hstudio03_058667db_21:

    n "Click!"

translate english ch03_hstudio03_a7e5d9d4:

    n "With every change in pose, she glanced at [d_name]’s expression."

translate english ch03_hstudio03_02a6e185:

    n "As she took on more provocative poses than the script required, her shame slowly turned into a strange excitement."

translate english ch03_hstudio03_058667db_22:

    n "Click!"

translate english ch03_hstudio03_630f90c0:

    d "**(Holy shit!!!!)**"

translate english ch03_hstudio03_ac8566aa:

    n "But what was collapsing wasn’t her narcissism."

translate english ch03_hstudio03_7fdc0f66:

    n "By showing her body to [d_name], she was, in a way, completing it."

translate english ch03_hstudio03_058667db_23:

    n "Click!"

translate english ch03_hstudio03_e29fc1d3:

    n "The more he stared at her in a daze, the more pleasure washed over her."

translate english ch03_hstudio03_9b45d2b4:

    n "And with it, her private area flushed deeper with arousal."

translate english ch03_hstudio03_058667db_24:

    n "Click!"

translate english ch03_hstudio03_058667db_25:

    n "Click!"

translate english ch03_hstudio03_e5c36b54:

    d "………"

translate english ch03_hstudio03_058667db_26:

    n "Click!"

translate english ch03_hstudio03_d01fea2e:

    h "Let’s go a bit bolder."

translate english ch03_hstudio03_058667db_27:

    n "Click!"

translate english ch03_hstudio03_89f1de81:

    h "Don’t be conscious of the camera—just show your natural self."

translate english ch03_hstudio03_058667db_28:

    n "Click!"

translate english ch03_hstudio03_9eecdcb4:

    h "Good. Imagine you’re showing yourself to the man you love!!"

translate english ch03_hstudio03_058667db_29:

    n "Click!"

translate english ch03_hstudio03_89b33729:

    h "Fantastic!!"

translate english ch03_hstudio03_058667db_30:

    n "Click!"

translate english ch03_hstudio03_60323ec1:

    n "The shoot continued smoothly."

translate english ch03_hstudio03_32c6a694:

    n "Unlike usual, both Sophia and [h_name] could feel the heat in the studio rising."

translate english ch03_hstudio03_8d92fcee:

    h "Phew…!"

translate english ch03_hstudio03_698c1014:

    h "Excellent, ma’am!"

translate english ch03_hstudio03_8446dd25:

    h "Let’s take a short break, then move on to the couple shoot."

translate english ch03_hstudio03_ddaba251:

    h "Great work. It feels especially humid today."

translate english ch03_hstudio03_e94a1c84:

    h "You’re truly beautiful, haha."

translate english ch03_hstudio03_5d7d96f6:

    h "How are your breasts so perfectly shaped? Hehe."

translate english ch03_hstudio03_47a3edfe:

    x "Haha, don’t say things like that."

translate english ch03_hstudio03_f91d7fde:

    x "It’s embarrassing."

translate english ch03_hstudio03_30368f26:

    x "At my age, doing a nude shoot... isn't it a bit unseemly?"

translate english ch03_hstudio03_eb9844c2:

    h "Not at all! You’re a femme fatale right now."

translate english ch03_hstudio03_e64d0de9:

    x "Hahaha, hearing that makes me shy."

translate english ch03_hstudio03_92a90223_4:

    x "………………"

translate english ch03_hstudio03_b11d1fee:

    x "**(Oh my god……)**"

translate english ch03_hstudio03_072521ae:

    x "**(Am I really about to shoot with [d_name] now?…)**"

translate english ch03_hstudio03_8ba8a1a9:

    x "**(What kind of professor in their right mind stages a sex scene with her own student?...)**"

translate english ch03_hstudio03_116675e4:

    x "**(This is insane…)**"

translate english ch03_hstudio03_b1d42b04:

    h "Alright, let’s move on to the couple shoot."

translate english ch03_hstudio03_f6bc3f0a:

    h "**(I shouldn’t have worn long sleeves. It’s so humid and hot today…)**"

translate english ch03_hstudio03_db0301be:

    h "Hey, [d_name]…"

translate english ch03_hstudio03_6b7a648b:

    d "Yes!"

translate english ch03_hstudio03_f9bcef80:

    h "Go change into the underwear prepared in the dressing room."

translate english ch03_hstudio03_15734c04:

    d "Okay, got it."

translate english ch03_hstudio03_e2bdf0e5:

    h "If there’s any problem, call me. Alright?"

translate english ch03_hstudio03_0d4d0ea7:

    d "Yes, understood."

translate english ch03_hstudio03_71a1dda4:

    d "**(Now that it’s actually starting, my heart’s racing…)**"

translate english ch03_hstudio03_3c740ab3:

    d "I’m all set!!"

translate english ch03_hstudio03_1a2a92d8:

    x "………"

translate english ch03_hstudio03_19525034:

    h "Alright, both of you, please come over here."

translate english ch03_hstudio03_a5d6de40:

    d "Um…"

translate english ch03_hstudio03_b59f765e_1:

    d "Nice to meet you."

translate english ch03_hstudio03_fda0f185:

    h "Haha, alright. Both of you, don’t be nervous—just act naturally."

translate english ch03_hstudio03_ac8a2392:

    x "………"

translate english ch03_hstudio03_4a75764b:

    h "Okay, let’s begin."

translate english ch03_hstudio03_5c2173ff:

    h "To start…"

translate english ch03_hstudio03_c5d3ade1:

    h "Place your hand casually on her shoulder."

translate english ch03_hstudio03_058667db_31:

    n "Click!"

translate english ch03_hstudio03_9427fb1f:

    h "It’s a bit stiff right now—both of you, try to pose more freely."

translate english ch03_hstudio03_76b39fe9:

    h "Imagine you’re lovers seeing each other again after a long time—build that emotion."

translate english ch03_hstudio03_ca3fdf3a:

    h "[d_name], don’t be too tense."

translate english ch03_hstudio03_ce6226b4:

    h "Just think of it as having a bit of fun with your partner."

translate english ch03_hstudio03_f677b99a:

    d "Ah... I understand!!"

translate english ch03_hstudio03_5615fb3b:

    d "Having fun with a partner…"

translate english ch03_hstudio03_058667db_32:

    n "Click!"

translate english ch03_hstudio03_5f384aa8:

    h "Good!"

translate english ch03_hstudio03_afe541c5:

    d "**(Phew… phew… phew…)**"

translate english ch03_hstudio03_29a5bc65:

    d "**(Her skin feels like silk…)**"

translate english ch03_hstudio03_058667db_33:

    n "Click!"

translate english ch03_hstudio03_68896c27:

    h "[d_name], could you embrace her from behind?"

translate english ch03_hstudio03_058667db_34:

    n "Click!"

translate english ch03_hstudio03_318f7aba:

    h "Pretend the camera isn't there—you're just looking into a mirror with the one you love!"

translate english ch03_hstudio03_cb67df61:

    x "**(Hey!!)**"

translate english ch03_hstudio03_e3f70da7:

    x "**(Calm down, calm down!! You’re actually rubbing against me!!)**"

translate english ch03_hstudio03_690e6c21:

    x "**(It's so frustrating that I can't say a word.)**"

translate english ch03_hstudio03_48b03305:

    x "**(Oh my god, [d_name]!! Calm down!)**"

translate english ch03_hstudio03_c408c295:

    x "**(Get a hold of yourself!!)**"

translate english ch03_hstudio03_425161f1:

    x "**(Control yourself!!)**"

translate english ch03_hstudio03_058667db_35:

    n "Click!"

translate english ch03_hstudio03_8ba165f3:

    h "Good! [d_name], show her more affection!"

translate english ch03_hstudio03_058667db_36:

    n "Click!"

translate english ch03_hstudio03_b572d2b4:

    x "**(Show her affection??)**"

translate english ch03_hstudio03_c8d2589b:

    d "**(Damn…)**"

translate english ch03_hstudio03_058667db_37:

    n "Click!"

translate english ch03_hstudio03_058667db_38:

    n "Click!"

translate english ch03_hstudio03_781b75e8:

    h "Good, let’s go even bolder."

translate english ch03_hstudio03_651f3ec0:

    s "**(Phew... this is escalating more than I expected...)**"

translate english ch03_hstudio03_8e4a5e84:

    d "**(How do I go bolder than this??)**"

translate english ch03_hstudio03_7b3cdd79:

    d "**(Should I go for some foreplay? No, that can't be it..)**"

translate english ch03_hstudio03_058667db_39:

    n "Click!"

translate english ch03_hstudio03_ee969888:

    x "**(My god…)**"

translate english ch03_hstudio03_058667db_40:

    n "Click!"

translate english ch03_hstudio03_b3fdf419:

    x "**(His body is really firm...)**"

translate english ch03_hstudio03_611c64be:

    x "**(Ah…[d_name]!!)**"

translate english ch03_hstudio03_058667db_41:

    n "Click!"

translate english ch03_hstudio03_2531ce94:

    h "Press your groins even closer together."

translate english ch03_hstudio03_83e4a2b7:

    h "Remember, you're lovers reuniting after a long time!"

translate english ch03_hstudio03_ce0ebd52:

    n "As the shoot went on, Sophia was being swept away by [d_name]’s boldness."

translate english ch03_hstudio03_5e15b39b:

    n "What now took precedence over her dominant instinct as a professor was..."

translate english ch03_hstudio03_9be4a144:

    n "the mysterious sensation of being touched by her student..."

translate english ch03_hstudio03_161d06ee:

    n "and the lust that had been buried deep within her for so long."

translate english ch03_hstudio03_058667db_42:

    n "Click!"

translate english ch03_hstudio03_5198f474:

    n "The studio began to simmer with an intense heat as the shoot continued."

translate english ch03_hstudio03_cb28ab22:

    n "Though each was focused on their role,"

translate english ch03_hstudio03_718b3f23:

    n "All three felt something swelling slowly from the depths of their hearts."

translate english ch03_hstudio03_058667db_43:

    n "Click!"

translate english ch03_hstudio03_e2b1980c:

    h "Good! Ma’am!"

translate english ch03_hstudio03_2bd88655:

    h "You're being handled roughly by your boyfriend!"

translate english ch03_hstudio03_058667db_44:

    n "Click!"

translate english ch03_hstudio03_7c3a2599:

    h "[d_name]! Ravish her however you want!!"

translate english ch03_hstudio03_e0a77ffd:

    x "**(What?!!)**"

translate english ch03_hstudio03_8587be6e:

    d "**(What?!! Do they usually direct shoots with those kinds of words?...)**"

translate english ch03_hstudio03_cbb15023:

    d "**(That's quite an expression!..)**"

translate english ch03_hstudio03_d9622ebf:

    h "**(Phew... it’s really steaming in here today.)**"

translate english ch03_hstudio03_c577a9ab:

    h "**(Is the AC acting up?..)**"

translate english ch03_hstudio03_64efc18a:

    x "**(Ah… ngh…)**"

translate english ch03_hstudio03_058667db_45:

    n "Click!"

translate english ch03_hstudio03_fbfac38b:

    h "That’s right, show her your affection."

translate english ch03_hstudio03_058667db_46:

    n "Click!"

translate english ch03_hstudio03_058667db_47:

    n "Click!"

translate english ch03_hstudio03_5f384aa8_1:

    h "Good!"

translate english ch03_hstudio03_058667db_48:

    n "Click!"

translate english ch03_hstudio03_001ccd1f:

    n "[d_name] pressed his shaft firmly against her mound."

translate english ch03_hstudio03_924256f4:

    n "Obsessed with nailing his role, he was engaging in more contact than necessary."

translate english ch03_hstudio03_058667db_49:

    n "Click!"

translate english ch03_hstudio03_96b755d2:

    x "**(Don’t grind like that, [d_name]…)**"

translate english ch03_hstudio03_51666b4a:

    x "**(You don't have to touch me that much, you brat!!)**"

translate english ch03_hstudio03_8f79e639:

    x "**(The camera’s in front of us, not behind!!)**"

translate english ch03_hstudio03_636ff2cc:

    n "Sophia remained silent, desperate not to reveal her identity."

translate english ch03_hstudio03_09492696:

    n "And those very conditions were stirring an inexplicable arousal within her."

translate english ch03_hstudio03_1bfce6b6:

    n "The thought of being a professor whose core was being rubbed by her own student dragged her into a pit of shame."

translate english ch03_hstudio03_058667db_50:

    n "Click!"

translate english ch03_hstudio03_4988332b:

    x "**(Oh my god… ngh…)**"

translate english ch03_hstudio03_70ee8039:

    h "This is your own private space. Imagine it's just the two of you."

translate english ch03_hstudio03_7ef0668b:

    h "Now… ma’am…"

translate english ch03_hstudio03_29cd9aa2:

    h "Sit in front of him and slowly take hold of his underwear."

translate english ch03_hstudio03_655d43b1:

    h "Can you strike the most erotic pose possible as you sit?"

translate english ch03_hstudio03_ccdcf50d_1:

    x "………"

translate english ch03_hstudio03_ca8f86a4:

    x "**(Ha…………)**"

translate english ch03_hstudio03_be48bcdf:

    x "**(What on earth is happening right now...)**"

translate english ch03_hstudio03_c72f0666:

    n "Sophia spread her legs and sat before [d_name], gripping his underwear."

translate english ch03_hstudio03_94fdaf49:

    h "Excellent."

translate english ch03_hstudio03_48f3959c:

    h "**(Oh my god… can I really be doing this…?)**"

translate english ch03_hstudio03_92ad9932:

    h "………"

translate english ch03_hstudio03_ff3c810d:

    h "**(Is it alright for me, the photographer, to be so uncertain during a shoot?)**"

translate english ch03_hstudio03_5c0316e9:

    h "Now, slowly... lower his u...underwear."

translate english ch03_hstudio03_85489bc9:

    d "**(Ugh……)**"

translate english ch03_hstudio03_a56f9796:

    d "**(I'm about to expose my dick to a stranger and [h_name]...)**"

translate english ch03_hstudio03_049d9257:

    n "A heavy silence fell over the studio."

translate english ch03_hstudio03_497a0d56:

    n "Only the sound of rain drumming against the glass remained."

translate english ch03_hstudio03_058667db_51:

    n "Click!"

translate english ch03_hstudio03_058667db_52:

    n "Click!"

translate english ch03_hstudio03_78a8e21e:

    x "!!!!!!!!!"

translate english ch03_hstudio03_7bd9802d:

    x "**(Haah... haah...)**"

translate english ch03_hstudio03_fad01e7b:

    n "[d_name]’s scent hit Sophia all at once."

translate english ch03_hstudio03_c259741d:

    h "Hold it right there with them halfway down. Perfect."

translate english ch03_hstudio03_058667db_53:

    n "Click!"

translate english ch03_hstudio03_582f459a:

    h "**(Ha… it’s too hot, I can’t take this.)**"

translate english ch03_hstudio03_7977908a:

    h "Both of you, just a moment."

translate english ch03_hstudio03_131afde3:

    h "I'm sorry for pausing the shoot."

translate english ch03_hstudio03_db1afbd0:

    n "A strange tension gripped the studio at [h_name]’s sudden interruption."

translate english ch03_hstudio03_da491e1c:

    n "While the heat and humidity triggered this choice..."

translate english ch03_hstudio03_f616d8e9:

    n "it was also a way for her to find some liberation by joining them in their exposed state."

translate english ch03_hstudio03_4f77ac87:

    h "Haa... I can finally breathe."

translate english ch03_hstudio03_d957c0be:

    h "Sorry for stopping the shoot out of nowhere."

translate english ch03_hstudio03_92a90223_5:

    x "………"

translate english ch03_hstudio03_5e13fb4b:

    h "I truly apologize for breaking the flow."

translate english ch03_hstudio03_a09a9b93:

    h "If it were up to me, I'd take everything off too..."

translate english ch03_hstudio03_426dd94b:

    h "but I'm not the model, hehe."

translate english ch03_hstudio03_967252d1:

    h "Alright, let's get back to it."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
