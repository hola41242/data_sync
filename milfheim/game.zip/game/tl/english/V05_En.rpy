translate english ch05_cabin01_da390837:

    n "She turned her head at the faint sound of footsteps echoing in the distance."

translate english ch05_cabin01_f1b1cfc6:

    o "........."

translate english ch05_cabin01_203cc60b:

    d "......."

translate english ch05_cabin01_f1b1cfc6_1:

    o "........."

translate english ch05_cabin01_7a07b4e0:

    o "Why are you out of bed?"

translate english ch05_cabin01_d226b6b8:

    o ".........."

translate english ch05_cabin01_7bea0127:

    o "Can't sleep either?"

translate english ch05_cabin01_31595f45:

    d "Yeah, heh. Just..."

translate english ch05_cabin01_b2ebc08c:

    d "I'm feeling a little restless."

translate english ch05_cabin01_f1b1cfc6_2:

    o "........."

translate english ch05_cabin01_d8513413:

    o "Feeling restless, huh..."

translate english ch05_cabin01_f1b1cfc6_3:

    o "........."

translate english ch05_cabin01_1f21bbb4:

    o "Hmm....."

translate english ch05_cabin01_09736086:

    n "An awkward tension hung between them."

translate english ch05_cabin01_6b16a4e7:

    n "Olivia was much more clear-headed than she had been a few hours ago."

translate english ch05_cabin01_0311fb14:

    n "The alcohol had worn off, and she was almost completely sober."

translate english ch05_cabin01_deb30ad0:

    n "But the one thing she couldn't get out of her mind was his erect penis."

translate english ch05_cabin01_77673f80:

    d "........."

translate english ch05_cabin01_a151db34:

    o "......."

translate english ch05_cabin01_0d342c37:

    o "Have you seen this movie before?"

translate english ch05_cabin01_4e591628:

    d "This movie??"

translate english ch05_cabin01_69ee00fb:

    d "Hmm....."

translate english ch05_cabin01_09ff2b50:

    d "No. I don't remember seeing it."

translate english ch05_cabin01_007917aa:

    o "That's a shame."

translate english ch05_cabin01_21dd5a4a:

    o "It's my favorite movie."

translate english ch05_cabin01_5d2f9863:

    o "And don't get your hopes up—it's not a dirty movie."

translate english ch05_cabin01_1afce67b:

    d "Heh."

translate english ch05_cabin01_edbb7d05:

    d "........"

translate english ch05_cabin01_a151db34_1:

    o "......."

translate english ch05_cabin01_c81d1be8:

    o "Why? Is there something you want to say?"

translate english ch05_cabin01_b84d0ef6:

    d "No, it's just..."

translate english ch05_cabin01_7e0cb251:

    d "I was looking at you.."

translate english ch05_cabin01_575710f7:

    d "Just..."

translate english ch05_cabin01_b07bd1ec:

    d "I was wondering what was on your mind. Heh..."

translate english ch05_cabin01_ad83d3d9:

    o "What?"

translate english ch05_cabin01_e7f4520e:

    o "You think staring at me like that is going to help you figure out what I'm thinking?"

translate english ch05_cabin01_a151db34_2:

    o "......."

translate english ch05_cabin01_c03f7ade:

    o "Idiot."

translate english ch05_cabin01_170e480b:

    o "Come here, idiot."

translate english ch05_cabin01_2bf61f33:

    d "Hahaha."

translate english ch05_cabin01_77673f80_1:

    d "........."

translate english ch05_cabin01_a151db34_3:

    o "......."

translate english ch05_cabin01_a151db34_4:

    o "......."

translate english ch05_cabin01_e876d31c:

    o "You..."

translate english ch05_cabin01_e688836c:

    o "Do you love me?"

translate english ch05_cabin01_beb89374:

    d "Of course."

translate english ch05_cabin01_bb97c1b8:

    d "I love you, Ollie."

translate english ch05_cabin01_c11c3e2a:

    d "Are we really at the point where we have to ask each other that? Heh."

translate english ch05_cabin01_a151db34_5:

    o "......."

translate english ch05_cabin01_eef413a6:

    o "Then what about Amanda?"

translate english ch05_cabin01_8096b08a:

    d "Huh?"

translate english ch05_cabin01_666b1768:

    d "Ah... Of course I love Amanda too."

translate english ch05_cabin01_8fc80126:

    d "Why would you ask that...?"

translate english ch05_cabin01_e73ae2eb:

    o "You're no fun..."

translate english ch05_cabin01_82bb94e2:

    d "No fun? Heh."

translate english ch05_cabin01_1d23f378:

    d "Amanda and Ollie are both special to me."

translate english ch05_cabin01_950dd2ca:

    d "The three of us are going to be together for the rest of our lives, aren't we?"

translate english ch05_cabin01_e842596d:

    o "........"

translate english ch05_cabin01_a5e72691:

    o "Hmm......."

translate english ch05_cabin01_9f932f4f:

    o "So because we're special to you, that's why you shoved your penis in both our faces?"

translate english ch05_cabin01_b0450d16:

    d "**(Damn....)**"

translate english ch05_cabin01_486ba886:

    d "I...I mean... heh."

translate english ch05_cabin01_3e0b909d:

    d "How should I put it....."

translate english ch05_cabin01_c9e74566:

    o "....."

translate english ch05_cabin01_833dc2a9:

    d "I wasn't drinking, but I guess I was drunk anyway. Haha."

translate english ch05_cabin01_e842596d_1:

    o "........"

translate english ch05_cabin01_5608e89e:

    o "Can I ask you a completely random question?"

translate english ch05_cabin01_6225b646:

    d "Sure."

translate english ch05_cabin01_c9e74566_1:

    o "....."

translate english ch05_cabin01_4c9bb806:

    o "If we were a couple, what would you want to do right now?"

translate english ch05_cabin01_8096b08a_1:

    d "Huh?"

translate english ch05_cabin01_894fcb4a:

    d "What do you mean?"

translate english ch05_cabin01_e8389c84:

    o "You heard me."

translate english ch05_cabin01_649407d6:

    o "If we were a couple, what would you want to do right now?"

translate english ch05_cabin01_ddc86e51:

    d "Hmm......I don't know...."

translate english ch05_cabin01_e5c36b54:

    d "..........."

translate english ch05_cabin01_11efafb2:

    d "I don't know. Heh."

translate english ch05_cabin01_3f59f2ce:

    d "If we were a couple, I'd probably be doing whatever you wanted, Ollie. Haha."

translate english ch05_cabin01_6223fdd9:

    o "Really?"

translate english ch05_cabin01_e842596d_2:

    o "........"

translate english ch05_cabin01_fc7c0657:

    o "Whatever I wanted....."

translate english ch05_cabin01_aceefa14:

    o "I want to have sex."

translate english ch05_cabin01_77b4f560:

    o "Right now."

translate english ch05_cabin01_d76fab35:

    d "!!!!!!"

translate english ch05_cabin01_fac8215b:

    d "............"

translate english ch05_cabin01_1886f8dd:

    o "Ha................."

translate english ch05_cabin01_7fb448ef:

    o "This crisp mountain air and cool breeze...."

translate english ch05_cabin01_f4e51997:

    o "............."

translate english ch05_cabin01_40fb589b:

    o "This pleasant buzz.."

translate english ch05_cabin01_f1b1cfc6_4:

    o "........."

translate english ch05_cabin01_923b54de:

    o "And there's a big, hard cock right next to me..."

translate english ch05_cabin01_d13ae0b7:

    d "O...Ollie..."

translate english ch05_cabin01_f4e51997_1:

    o "............."

translate english ch05_cabin01_516e4a46:

    o "Could there be a more perfect situation for fucking?"

translate english ch05_cabin01_859ebdcd:

    o "Don't you think?"

translate english ch05_cabin01_b7df60dd:

    o "When I fuck in a situation like this, I usually have an orgasm..."

translate english ch05_cabin01_5e3aec4e:

    d ".........."

translate english ch05_cabin01_673985e3:

    d "An...an orgasm?..."

translate english ch05_cabin01_972df13d:

    o "Yeah."

translate english ch05_cabin01_aa5804e1:

    o "I told you, kid."

translate english ch05_cabin01_a6c93244:

    o "It's all about the mood."

translate english ch05_cabin01_f1b1cfc6_5:

    o "........."

translate english ch05_cabin01_e1d00fd3:

    o "But right now, I......"

translate english ch05_cabin01_875cfa2e:

    n "[d_name] listened to Olivia more intently than ever before."

translate english ch05_cabin01_2390cae0:

    n "At that moment, he desperately wished for it."

translate english ch05_cabin01_22416311:

    n "He wanted to hear Olivia say the very words he'd been thinking…"

translate english ch05_cabin01_5e3aec4e_1:

    d ".........."

translate english ch05_cabin01_e1d00fd3_1:

    o "But right now, I......"

translate english ch05_cabin01_b9270e76:

    o "I want comfort more than sex...."

translate english ch05_cabin01_2e1d2294:

    d "**(What???)**"

translate english ch05_cabin01_baf276f9:

    d "**(Comfort more than sex??....)**"

translate english ch05_cabin01_4f52b0b1:

    d "**(............)**"

translate english ch05_cabin01_31cf08f7:

    d "C...comfort??.."

translate english ch05_cabin01_d09a9865:

    d "**(This conversation is getting heavy again.......)**"

translate english ch05_cabin01_5d75a027:

    d "**(What am I supposed to do.....)**"

translate english strings:
    old "분위기를 이어가기 위해 그녀의 몸을 만진다."
    new "Touch her to keep the mood going."

translate english ch05_cabin01_92f21ed5:

    n "What should I do?"

translate english ch05_cabin01_188124f5:

    n "[d_name] moved his hand closer to her vulva, trying to maintain the sexual tension."

translate english ch05_cabin01_50479320:

    n "Olivia immediately realized what he was trying to do."

translate english ch05_cabin01_25817952:

    o "Damn. Just you touching me is giving me goosebumps."

translate english ch05_cabin01_f4e51997_2:

    o "............."

translate english ch05_cabin01_4f52b0b1_1:

    d "**(............)**"

translate english ch05_cabin01_c9435fa1:

    d "R...really?.."

translate english ch05_cabin01_5a7e583a:

    d "I'm getting hard right n…......."

translate english ch05_cabin01_e46167b6:

    o "Haa........."

translate english ch05_cabin01_f1b1cfc6_6:

    o "........."

translate english ch05_cabin01_16d6f184:

    o "I'm just exhausted by everything going on around me right now....."

translate english ch05_cabin01_a797f6ce:

    d "............."

translate english ch05_cabin01_969a9cc0:

    o "The divorce proceedings with my husband....."

translate english ch05_cabin01_a9501fe6:

    o "Running the restaurant....."

translate english ch05_cabin01_73e94c03:

    o "All the other things stressing me out..."

translate english ch05_cabin01_e842596d_3:

    o "........"

translate english ch05_cabin01_b0a073ff:

    o "I think I'm burned out."

translate english ch05_cabin01_78e986d5:

    o "Whew........."

translate english ch05_cabin01_f9db2e50:

    d "O...Ollie..."

translate english ch05_cabin01_3c36926b:

    d "Are you okay?"

translate english ch05_cabin01_712825c4:

    n "His hand moved even closer to Olivia's vulva."

translate english ch05_cabin01_0279c10b:

    n "He wanted to turn their conversation into something more sexual."

translate english ch05_cabin01_762607ac:

    n "He wanted to see how Ollie would respond to his touch."

translate english ch05_cabin01_25ba0e2f:

    o "......"

translate english ch05_cabin01_6e8dabf9:

    o "Just hold me, honey.."

translate english ch05_cabin01_b45ae0cf:

    d "!!!"

translate english ch05_cabin01_ea20450a:

    d "O...okay."

translate english ch05_cabin01_cecce2b9:

    o "Skin against skin..."

translate english ch05_cabin01_7ab39cb0:

    d "!!!!"

translate english ch05_cabin01_d1a0a026:

    o "I feel at ease when I'm close to a man."

translate english ch05_cabin01_bda03f2c:

    o "Like a little girl would…"

translate english ch05_cabin01_e842596d_4:

    o "........"

translate english ch05_cabin01_5e3aec4e_2:

    d ".........."

translate english ch05_cabin01_3c43cbf5:

    d "O...okay."

translate english ch05_cabin01_a6a34689:

    d "Of course I will."

translate english ch05_cabin01_e2506019:

    d "I could hold you until tomorrow morning, if you want.."

translate english ch05_cabin01_a4b476da:

    d "**(Damn...)**"

translate english ch05_cabin01_53ec54ed:

    d "**(My heart's pounding so hard I feel like it's going to burst....)**"

translate english ch05_cabin01_91313f64:

    d "**(Why does my heart beat so damn fast whenever I hold a woman?)**"

translate english ch05_cabin01_2490b6bb:

    d "**(........)**"

translate english ch05_cabin01_0e286f23:

    d "**(No........)**"

translate english ch05_cabin01_4b0f35d1:

    d "**(Maybe it's because what I'm doing feels like I'm breaking some kind of taboo......)**"

translate english ch05_cabin01_e842596d_5:

    o "........"

translate english ch05_cabin01_a7438a76:

    d "Are you okay, Ollie?"

translate english ch05_cabin01_968eb69a:

    d "Is this position uncomfortable?"

translate english ch05_cabin01_7109d761:

    o "No, I'm fine."

translate english ch05_cabin01_d5313fff:

    o "It feels so good....."

translate english ch05_cabin01_9dd34d54:

    o "It's comfortable....."

translate english ch05_cabin01_f96c0300:

    o "..........."

translate english ch05_cabin01_a1dfdd83:

    o "I missed the warmth of another person...."

translate english ch05_cabin01_0802e766:

    d "I...I see..."

translate english ch05_cabin01_42739c34:

    o "Why is it so comforting to be held by a man..."

translate english ch05_cabin01_ca865cf3:

    d "R...really?..."

translate english ch05_cabin01_f1b1cfc6_7:

    o "........."

translate english ch05_cabin01_9d26d8c8:

    o "Am I some kind of temptress?"

translate english ch05_cabin01_bfa306c3:

    d "No..of course not..."

translate english ch05_cabin01_66401791:

    d "I feel at ease too.."

translate english ch05_cabin01_2d6a1a3d:

    d "**(Damn, actually I'm just thinking about all the different positions I could try with Ollie!!!!)**"

translate english ch05_cabin01_8bf2d1e6:

    o "Heh."

translate english ch05_cabin01_0ad7a360:

    o "I never thought you and I would end up like this...."

translate english ch05_cabin01_e5cceece:

    o "Amanda would probably kill me if she saw us."

translate english ch05_cabin01_5e3aec4e_3:

    d ".........."

translate english ch05_cabin01_857573df:

    o "I don't care."

translate english ch05_cabin01_d7f4655d:

    o "Amanda definitely told me to seduce you as much as I wanted, so..."

translate english ch05_cabin01_b51bad6d:

    d "Heh. She did?..."

translate english ch05_cabin01_9b035708:

    o "Haa......."

translate english ch05_cabin01_5dd7ef78:

    o "Amanda and I... both of us have failed at marriage....."

translate english ch05_cabin01_25ba0e2f_1:

    o "......"

translate english ch05_cabin01_edbb7d05_1:

    d "........"

translate english ch05_cabin01_f0ff9c5e:

    d "I'm sorry, Ollie......"

translate english ch05_cabin01_25ba0e2f_2:

    o "......"

translate english ch05_cabin01_fd5c36eb:

    o "You know what?"

translate english ch05_cabin01_b4670267:

    d "Know what?........"

translate english ch05_cabin01_25ba0e2f_3:

    o "......"

translate english ch05_cabin01_c08fac2c:

    o "Amanda's having a really hard time holding it together..."

translate english ch05_cabin01_edbb7d05_2:

    d "........"

translate english ch05_cabin01_bbc38921:

    o "You know..."

translate english ch05_cabin01_5e6577c0:

    o "Frank seems to be getting worse and worse, acting like a complete asshole."

translate english ch05_cabin01_a151db34_6:

    o "......."

translate english ch05_cabin01_b40081d6:

    o "I think he even threatened to hit Amanda not long ago."

translate english ch05_cabin01_362e57c5:

    o "And....."

translate english ch05_cabin01_f38b8900:

    o "I'm on the verge of losing my family.."

translate english ch05_cabin01_9a104b70:

    o "............"

translate english ch05_cabin01_8ca74512:

    o "Living alone means you're free?"

translate english ch05_cabin01_1a223304:

    o "That's all bullshit."

translate english ch05_cabin01_edbb7d05_3:

    d "........"

translate english ch05_cabin01_274e816e:

    o "It's only like that while I'm still young and healthy..."

translate english ch05_cabin01_aeb39092:

    o "Only while I still have everyone's attention.."

translate english ch05_cabin01_edbb7d05_4:

    d "........"

translate english ch05_cabin01_56f1f69c:

    d "I...I guess so.."

translate english ch05_cabin01_1f973a81:

    o "Yeah..."

translate english ch05_cabin01_9e623920:

    o "You're perceptive, so you'll understand what I'm saying.."

translate english ch05_cabin01_edbb7d05_5:

    d "........"

translate english ch05_cabin01_3819fcc2:

    d "**(Damn......)**"

translate english ch05_cabin01_c3cd0c4d:

    d "**(Why is she touching me there while we're having such a serious conversation?...)**"

translate english ch05_cabin01_a5469e32:

    o "Damn, I want to have sex with you."

translate english ch05_cabin01_bb920e29:

    d "!!!!!!!"

translate english ch05_cabin01_d226b6b8_1:

    o ".........."

translate english ch05_cabin01_7c07a3a6:

    d "I...uh..."

translate english ch05_cabin01_b2b789a3:

    o "No...maybe I just need a man?..."

translate english ch05_cabin01_9509d907:

    o "I want to be fucked by a nice, hard cock."

translate english ch05_cabin01_77ec1d67:

    o "Until I can't even stand anymore."

translate english ch05_cabin01_f3560758:

    d "Until you can't even stand anymore?....."

translate english ch05_cabin01_77673f80_2:

    d "........."

translate english ch05_cabin01_d226b6b8_2:

    o ".........."

translate english ch05_cabin01_684e3899:

    o "But if I do that with you, I'll lose my sister too."

translate english ch05_cabin01_25ba0e2f_4:

    o "......"

translate english ch05_cabin01_4e2f63e6:

    o "Everyone in this damn little town will turn against me....."

translate english ch05_cabin01_edbb7d05_6:

    d "........"

translate english ch05_cabin01_6febd3fc:

    o "This damn town full of people who can't mind their own business...."

translate english ch05_cabin01_051e1964:

    o "There are no secrets that stay hidden forever."

translate english ch05_cabin01_77673f80_3:

    d "........."

translate english ch05_cabin01_f1f7c31e:

    d "**(I want to say something, but I honestly have no idea what to say.........)**"

translate english ch05_cabin01_a797f6ce_1:

    d "............."

translate english ch05_cabin01_b58d01dc:

    d "**(Haa....I just want to tell her to forget about everything and fuck...)**"

translate english ch05_cabin01_bd21d16c:

    d "**(But if I said that, I'd be a piece of shit.)**"

translate english ch05_cabin01_5e035fba:

    d "**(Why is sex the only thing on my mind even now????)**"

translate english ch05_cabin01_a797f6ce_2:

    d "............."

translate english ch05_cabin01_27f1f830:

    d "**(Is this just because I'm holding a woman...or am I actually obsessed with sex??..)**"

translate english ch05_cabin01_4e67f95c:

    d "**(Do I really need to see a doctor about this...)**"

translate english ch05_cabin01_5e3aec4e_4:

    d ".........."

translate english ch05_cabin01_d1bf3807:

    d "I'll stay by your side forever, Olivia..."

translate english ch05_cabin01_9e8ce269:

    d "I'll be with you forever, Olivia."

translate english ch05_cabin01_d700d00d:

    o "Haha. Really?"

translate english ch05_cabin01_1be86730:

    d "Of course!"

translate english ch05_cabin01_11bb567e:

    d "I don't joke about things like that."

translate english ch05_cabin01_d226b6b8_3:

    o ".........."

translate english ch05_cabin01_8937032d:

    o "Even if you don't mean it, thank you."

translate english ch05_cabin01_580ea938:

    o "That's the sweetest thing anyone's said to me in a long time."

translate english ch05_cabin01_45657238:

    o "Wait, that's almost exactly what my husband said when he proposed to me. Hahaha."

translate english ch05_cabin01_5e3aec4e_5:

    d ".........."

translate english ch05_cabin01_aeefd8f1:

    d "I'll stay by your side and Amanda's."

translate english ch05_cabin01_7e8887dc:

    d "I won't get married. The three of us will just live together."

translate english ch05_cabin01_d226b6b8_4:

    o ".........."

translate english ch05_cabin01_b48dc9a1:

    o "That's ridiculously sweet. Heh."

translate english ch05_cabin01_d226b6b8_5:

    o ".........."

translate english ch05_cabin01_be20bbab:

    o "Though I'm sure you'd run off with some woman the moment one came along."

translate english ch05_cabin01_d226b6b8_6:

    o ".........."

translate english ch05_cabin01_83f9aacd:

    o "But even if you don't mean it, thank you...."

translate english ch05_cabin01_a151db34_7:

    o "......."

translate english ch05_cabin01_d4602369:

    o "You..."

translate english ch05_cabin01_8096b08a_2:

    d "Yeah?"

translate english ch05_cabin01_a151db34_8:

    o "......."

translate english ch05_cabin01_d4602369_1:

    o "You..."

translate english ch05_cabin01_d2379bab:

    o "Do you find me attractive as a woman?"

translate english ch05_cabin01_edbb7d05_7:

    d "........"

translate english ch05_cabin01_3fd344b8:

    d "Y-you mean, sexually??"

translate english ch05_cabin01_fc74a477:

    o "Mm-hmm."

translate english ch05_cabin01_c580b6ef:

    d "I...I do."

translate english strings:
    old "올리는 매력적인 여자에요...."
    new "Ollie, you're an attractive woman...."

translate english strings:
    old "올리는 이 세상에서 제일 섹시해요."
    new "Ollie, you're the sexiest woman in the world."

translate english ch05_cabin01_92f21ed5_1:

    n "What should I do?"

translate english ch05_cabin01_ce51427f:

    d "Ollie, you're an attractive woman...."

translate english ch05_cabin01_c9e74566_2:

    o "....."

translate english ch05_cabin01_95f5ed71:

    o "An attractive woman, huh....."

translate english ch05_cabin01_36b89956:

    d "Ollie, you're the sexiest woman in the world."

translate english ch05_cabin01_c9e74566_3:

    o "....."

translate english ch05_cabin01_d9f18d54:

    o "Haha. I didn't expect that answer."

translate english ch05_cabin01_9d045477:

    n "Mwah!"

translate english ch05_cabin01_47532148:

    d "**(!!!!!)**"

translate english ch05_cabin01_8d139866:

    n "She gently kissed [d_name]'s nipple."

translate english ch05_cabin01_28af4e56:

    n "The moment her lips touched his body, a pleasant shiver ran through him."

translate english ch05_cabin01_d1995e28:

    d "**(Shit.......)**"

translate english ch05_cabin01_57b07527:

    d "O...Ollie....."

translate english ch05_cabin01_f38afd9b:

    d "Th...there..."

translate english ch05_cabin01_053ff2ee:

    d "It feels so good....."

translate english ch05_cabin01_d226b6b8_7:

    o ".........."

translate english ch05_cabin01_adcf4c4d:

    n "Mwah, mwah."

translate english ch05_cabin01_ecfa2717:

    d "**(My God......)**"

translate english ch05_cabin01_647085af:

    d "O...Ollie......"

translate english ch05_cabin01_d226b6b8_8:

    o ".........."

translate english ch05_cabin01_db6a2d06:

    d "**(Why does a woman's mouth feel so damn good....)**"

translate english ch05_cabin01_c109c904:

    d "!!!!!!!!!!"

translate english ch05_cabin01_00bd2646:

    d "Mmm..........."

translate english ch05_cabin01_8225f230:

    d "Ah......."

translate english ch05_cabin01_66ee537b:

    d "Ha...Ollie...."

translate english ch05_cabin01_61ace046:

    o "**(.......)**"

translate english ch05_cabin01_764e4139:

    d "It feels so good....."

translate english ch05_cabin01_24f504f0:

    d "Oh my God....."

translate english ch05_cabin01_f96c0300_1:

    o "..........."

translate english ch05_cabin01_1beb7ba6:

    n "She showed her femininity to the man who had shown a willingness to take care of her."

translate english ch05_cabin01_fe4ed171:

    n "And this was one of the surest ways she could lead that man toward having sex with her."

translate english ch05_cabin01_67d59e6b:

    n "But she reminded herself that getting intimate with [d_name] was a line she shouldn't cross."

translate english ch05_cabin01_37484e58:

    o "**(What am I doing to [d_name] right now?)**"

translate english ch05_cabin01_33c1ddc4:

    o "**(...........)**"

translate english ch05_cabin01_d8c0f204:

    o "**(What am I doing with this kid...)**"

translate english ch05_cabin01_4cd15d58:

    d "....."

translate english ch05_cabin01_f800bdd8:

    d "Ollie....."

translate english ch05_cabin01_ca76b0d6:

    d "I love you, Ollie."

translate english ch05_cabin01_421d3373:

    d "I can't hold myself back anymore.."

translate english ch05_cabin01_a891ab84:

    o "What?"

translate english ch05_cabin01_c1fb4b43:

    d "I want you... I want you so badly..."

translate english ch05_cabin01_d6e552f2:

    o "You want me??..."

translate english ch05_cabin01_91fbc9a6:

    n "He stopped caressing her and grabbed the back of Olivia's head as she struggled with her feelings."

translate english ch05_cabin01_6617d24a:

    n "Then he pulled her head toward him."

translate english strings:
    old "그녀에게 키스를 한다."
    new "Kiss her."

translate english ch05_cabin01_92f21ed5_2:

    n "What should I do?"

translate english ch05_cabin01_ffc308e0:

    o "!!!!"

translate english ch05_cabin01_f6958ee9:

    n "He was aroused, but he wondered if what he'd just done had ruined his relationship with her."

translate english ch05_cabin01_c17c8bab:

    n "But when Olivia's tongue met his, he felt relieved."

translate english ch05_cabin01_ce23c354:

    n "They shared the deepest kiss they'd ever had."

translate english ch05_cabin01_407fec02:

    n "As if they were trying to suck each other's very existence into their mouths..."

translate english ch05_cabin01_0eb04939:

    n "With that kiss, Olivia crossed several lines she never thought she'd cross."

translate english ch05_cabin01_0e7000ea:

    n "Kissing a man so much younger than herself was an entirely new sexual experience for her."

translate english ch05_cabin01_41fa87da:

    n "She felt both excited and embarrassed at the same time."

translate english ch05_cabin01_c3775e95:

    n "Kissing [d_name] made her feel as if she'd been transported back to her high school days."

translate english ch05_cabin01_8effb8a9:

    n "They kissed as if time itself had stopped."

translate english ch05_cabin01_9fc44da0:

    n "And [d_name] felt that he needed to take things to the next level."

translate english ch05_cabin01_9adcadfb:

    o "!!!!!"

translate english ch05_cabin01_8bf2d1e6_1:

    o "Heh heh."

translate english ch05_cabin01_edbb7d05_8:

    d "........"

translate english ch05_cabin01_eded97d1:

    d "Wh-why are you doing that.."

translate english ch05_cabin01_c342bb56:

    d "Did I do something wrong?"

translate english ch05_cabin01_29dc8279:

    o "Mmm......"

translate english ch05_cabin01_698784c6:

    o "Phew.........."

translate english ch05_cabin01_69837966:

    o "**(Good job, Olivia....good job...)**"

translate english ch05_cabin01_0f8fc94a:

    o "**(This is so embarrassing....)**"

translate english ch05_cabin01_b8a2d8e4:

    d "I...I'm sorry...."

translate english ch05_cabin01_e19aa99e:

    d "I...I just moved too fast…"

translate english ch05_cabin01_5af80a47:

    o "No, it's okay."

translate english ch05_cabin01_8d1404d7:

    o "It felt really good."

translate english ch05_cabin01_e842596d_6:

    o "........"

translate english ch05_cabin01_a4459a10:

    o "You didn't do anything wrong."

translate english ch05_cabin01_99d187a6:

    d "B-but why did you suddenly..."

translate english ch05_cabin01_edbb7d05_9:

    d "........"

translate english ch05_cabin01_a4db5e69:

    d "Are you going to go b-back in again?"

translate english ch05_cabin01_edbb7d05_10:

    d "........"

translate english ch05_cabin01_5abf574b:

    d "Are you going to leave me here and go back in again?..."

translate english ch05_cabin01_e842596d_7:

    o "........"

translate english ch05_cabin01_ff31f899:

    o "I'm sorry, honey."

translate english ch05_cabin01_e842596d_8:

    o "........"

translate english ch05_cabin01_c2f50c7c:

    o "It's just...."

translate english ch05_cabin01_7698bd80:

    o "I didn't know I'd feel this way....."

translate english ch05_cabin01_25ba0e2f_5:

    o "......"

translate english ch05_cabin01_f1d3b06e:

    o "And then there's the relationship between you, me, and Amanda..."

translate english ch05_cabin01_fcb91909:

    o "Go inside and get some sleep."

translate english ch05_cabin01_7a553579:

    o "We'll talk later."

translate english ch05_cabin01_b0450d16_1:

    d "**(Damn....)**"

translate english ch05_cabin01_37ff3b67:

    d "**(Did I push her too hard...)**"

translate english ch05_cabin01_2e9c6444:

    d "**(.......)**"

translate english ch05_cabin01_66c4b975:

    d "**(No, should I have pulled out my cock instead of touching her breasts?)**"

translate english ch05_cabin01_36c4e915:

    n "Olivia stopped as she was about to go back inside."

translate english ch05_cabin01_8ea79956:

    n "She stood there for a moment, thinking about something in silence."

translate english ch05_cabin01_6110dead:

    d "????"

translate english ch05_cabin01_2e4232ba:

    n "She looked at [d_name]'s face for a moment."

translate english ch05_cabin01_e7aa1d6b:

    n "Then she finally spoke."

translate english ch05_cabin01_228b9088:

    o "Stand up."

translate english ch05_cabin01_8096b08a_3:

    d "Huh?"

translate english ch05_cabin01_e8389c84_1:

    o "You heard me."

translate english ch05_cabin01_5fc05b52:

    o "I said stand up."

translate english ch05_cabin01_bd58da14:

    d "???"

translate english ch05_cabin01_111c1278:

    d "??"

translate english ch05_cabin01_12b8d3c5:

    d "What are you doing?"

translate english ch05_cabin01_edbb7d05_11:

    d "........"

translate english ch05_cabin01_190555d1:

    d "Wh...what are you doing??"

translate english ch05_cabin01_b97877b7:

    d "O...Ollie..."

translate english ch05_cabin01_8bf2d1e6_2:

    o "Heh."

translate english ch05_cabin01_2bffc05d:

    o "I'm not going inside and leaving you here..."

translate english ch05_cabin01_c086a0e4:

    o "You know what I mean?"

translate english ch05_cabin01_a151db34_9:

    o "......."

translate english ch05_cabin01_39619716:

    n "Mwah"

translate english ch05_cabin01_7de2ec43:

    d "Oh my God, Ollie......"

translate english ch05_cabin01_c719bf29:

    d "You're teasing me right now, aren't you?......"

translate english ch05_cabin01_0dc97dc0:

    d "You're going to stop again all of a sudden, aren't you? Right?"

translate english ch05_cabin01_77673f80_4:

    d "........."

translate english ch05_cabin01_b8deb064:

    d "If we're going to do this, we might as well go to the couch..."

translate english ch05_cabin01_9c9ff00d:

    d "!!!!!!!!!"

translate english ch05_cabin01_df3d6445:

    n "A cool mountain breeze brushed against his crotch."

translate english ch05_cabin01_eefb0e89:

    n "A rush of arousal, relief, and desire for Olivia washed over him all at once."

translate english ch05_cabin01_a254b6d4:

    d "!!!!!"

translate english ch05_cabin01_c054c251:

    d "Shit....Ollie..."

translate english ch05_cabin01_05954e74:

    o "Were you worried I'd just go inside and leave you hanging, Prince Charming?"

translate english ch05_cabin01_f039ebd7:

    o "Damn....."

translate english ch05_cabin01_374c37c0:

    o "What woman could look at a cock like this and still fall asleep?"

translate english ch05_cabin01_25ba0e2f_6:

    o "......"

translate english ch05_cabin01_0d66441d:

    o "You were really going to shove this straight into Amanda's ass?"

translate english ch05_cabin01_5e1a9695:

    d "N...no, that's not what I..."

translate english ch05_cabin01_10ce392a:

    o "You idiot!"

translate english ch05_cabin01_c1022d8a:

    d "Oh, Ollie......"

translate english ch05_cabin01_02d13543:

    d "Damn.."

translate english ch05_cabin01_1826f202:

    o "That's right, kid."

translate english ch05_cabin01_74d18307:

    o "You're dying to put it in my pussy, aren't you?"

translate english ch05_cabin01_69c4c3e0:

    d "Huh?...."

translate english ch05_cabin01_dd5f36d4:

    o "You want to add me to your collection, don't you??"

translate english ch05_cabin01_edbb7d05_12:

    d "........"

translate english ch05_cabin01_0e5063df:

    o "No?"

translate english ch05_cabin01_ac98bddf:

    d "I...I do."

translate english ch05_cabin01_ad83d3d9_1:

    o "What?"

translate english ch05_cabin01_083c0281:

    o "What did you say? I couldn't hear you."

translate english ch05_cabin01_6cbb67ee:

    d "I...I want to put it in your pu...pussy, Ollie."

translate english ch05_cabin01_01b73983:

    o "My God......"

translate english ch05_cabin01_87b1c885:

    o "You're the reason I'm wet right now.."

translate english ch05_cabin01_7187ebb4:

    o "I wish my husband could see this right now…"

translate english ch05_cabin01_7d74fcfd:

    o "He probably would've come running with a shotgun."

translate english ch05_cabin01_4bb59dbf:

    d "What??!!"

translate english ch05_cabin01_5e258130:

    o "Haa........."

translate english ch05_cabin01_9bfa01ec:

    d "Shit!!!!"

translate english ch05_cabin01_a99ced11:

    o "That's right, honey...."

translate english ch05_cabin01_bab8eaa3:

    o "You've got an impressive cock..."

translate english ch05_cabin01_a151db34_10:

    o "......."

translate english ch05_cabin01_d21c3325:

    o "I can feel it in my hand...."

translate english ch05_cabin01_07e558d4:

    d "**(Shit.....)**"

translate english ch05_cabin01_a41ee801:

    d "**(How is she gripping it with exactly the amount of pressure I like??)**"

translate english ch05_cabin01_91e01e6b:

    d "**(Is this the power of a MILF...ah....)**"

translate english ch05_cabin01_25ba0e2f_7:

    o "......"

translate english ch05_cabin01_ea63dcdd:

    o "My God......"

translate english ch05_cabin01_fb751f4a:

    o "Who would've thought things would turn out like this when you first came into our family...?"

translate english ch05_cabin01_8b7a5c2b:

    d "Ah....."

translate english ch05_cabin01_15ee2e3c:

    o "It's twitching, isn't it?"

translate english ch05_cabin01_bfb62885:

    d "Yeah....."

translate english ch05_cabin01_d522e576:

    o "My God..."

translate english ch05_cabin01_80291ee0:

    o "Your cock is hard as a rock... like a fucking rock..."

translate english ch05_cabin01_4c0bc9dc:

    d "!!"

translate english ch05_cabin01_0975b73a:

    o "My husband used to love having me touch him right here..."

translate english ch05_cabin01_e6725bbc:

    o "He loved it when I'd roll it around in my mouth like candy. Heh."

translate english ch05_cabin01_7eaec85f:

    d "Damn, Ollie...."

translate english ch05_cabin01_72022ea7:

    d "Ah.....Ollie...."

translate english ch05_cabin01_edbb7d05_13:

    d "........"

translate english ch05_cabin01_a08de463:

    d "I want to have sex with you, Ollie...."

translate english ch05_cabin01_9a104b70_1:

    o "............"

translate english ch05_cabin01_346e03ba:

    d "Ah..........."

translate english ch05_cabin01_4e01220d:

    o "You want to have sex with me?"

translate english ch05_cabin01_dc18d7e6:

    d "Yes......"

translate english ch05_cabin01_346e03ba_1:

    d "Ah..........."

translate english ch05_cabin01_61c24920:

    o "Could you really never see Amanda again?"

translate english ch05_cabin01_edbb7d05_14:

    d "........"

translate english ch05_cabin01_ce66aa70:

    o "Why can't you answer me?"

translate english ch05_cabin01_86ecfb3f:

    d "I...I can't..."

translate english ch05_cabin01_cbe90d27:

    o "You want to eat me without having to give anything up?"

translate english ch05_cabin01_5e3aec4e_6:

    d ".........."

translate english ch05_cabin01_cc9296fc:

    o "You want to fuck Amanda and fuck me too? Huh?"

translate english ch05_cabin01_5e3aec4e_7:

    d ".........."

translate english ch05_cabin01_57bcd80c:

    o "You want to fuck both sisters??!!"

translate english ch05_cabin01_a809357b:

    o "What are you, some kind of king?"

translate english ch05_cabin01_c28a8e4f:

    d "Damn......"

translate english ch05_cabin01_346e03ba_2:

    d "Ah..........."

translate english ch05_cabin01_c28a8e4f_1:

    d "Damn......"

translate english ch05_cabin01_66248ac0:

    o "Yeah....."

translate english ch05_cabin01_28abeb20:

    o "Haa......."

translate english ch05_cabin01_433fa59a:

    o "Maybe you really can fuck both Amanda and me...."

translate english ch05_cabin01_77b1784e:

    d "Ah......"

translate english ch05_cabin01_920ea839:

    o "That depends on what you do.."

translate english ch05_cabin01_c7623406:

    o "Women don't just let you have your way because you want it."

translate english ch05_cabin01_25ba0e2f_8:

    o "......"

translate english ch05_cabin01_f039ebd7_1:

    o "Damn....."

translate english ch05_cabin01_19d9451e:

    o "Damn, my arm hurts...."

translate english ch05_cabin01_ffc308e0_1:

    o "!!!!"

translate english ch05_cabin01_5dd9dadc:

    o "You're about to cum, aren't you?"

translate english ch05_cabin01_346e03ba_3:

    d "Ah..........."

translate english ch05_cabin01_346e03ba_4:

    d "Ah..........."

translate english ch05_cabin01_fd70e38b:

    d "I'm gonna cum!!"

translate english ch05_cabin01_40ce378e:

    o "Yeah!!!"

translate english ch05_cabin01_5e1e09df:

    o "Cum for me baby !!!"

translate english ch05_cabin01_f17ff209:

    d "Ah....damn!!!!!"

translate english ch05_cabin01_bb786213:

    d "Ah!!!"

translate english ch05_cabin01_8ddf746e:

    o "Wow...."

translate english ch05_cabin01_f40ec79c:

    o "This is fucking crazy....."

translate english ch05_cabin01_5311e6bd:

    o "Damn, you came a lot.."

translate english ch05_cabin01_75fbcc24:

    d "Ah....Ollie...."

translate english ch05_cabin01_c1263c51:

    d "Haa........."

translate english ch05_cabin01_50647449:

    o "Did you enjoy that?"

translate english ch05_cabin01_dc18d7e6_1:

    d "Yeah......"

translate english ch05_cabin01_25ba0e2f_9:

    o "......"

translate english ch05_cabin01_310c9cf9:

    o "You sound pretty disappointed. Heh."

translate english ch05_cabin01_078c40bc:

    o "What did you want me to do, idiot?"

translate english ch05_cabin01_e5c36b54_1:

    d "..........."

translate english ch05_cabin01_5b555ed4:

    o "Now go inside and get some sleep...."

translate english ch05_cabin01_b611e8bb:

    o "And don't go to Amanda's room, okay?"

translate english ch05_cabin01_30474734:

    d "Yeah, I understand...."

translate english ch05_cabin01_9a104b70_2:

    o "............"

translate english ch05_cabin01_77673f80_5:

    d "........."

translate english ch05_cabin01_52d0749d:

    d "Good night, Ollie..."

translate english ch05_cabin01_77673f80_6:

    d "........."

translate english ch05_cabin01_c0537414:

    d "Shit....."

translate english ch05_cabin01_f8d6691c:

    d "What the hell...."

translate english ch05_cabin01_a2ca65be:

    d "Did she do that because she felt sorry for me, or...."

translate english ch05_cabin01_57b1c260:

    d "Was she just showing off what she could do...."

translate english ch05_cabin01_ad893dfa:

    d "......"

translate english ch05_cabin01_461829a0:

    d "I just can't figure her out...."

translate english ch05_acar02_5e3aec4e:

    d ".........."

translate english ch05_acar02_e842596d:

    o "........"

translate english ch05_acar02_94dbb8f5:

    a "Ugh, my head feels like it's going to split open..."

translate english ch05_acar02_3c36926b:

    d "Are you okay?"

translate english ch05_acar02_2d834607:

    a "Why did I drink so damn much..."

translate english ch05_acar02_c45b8541:

    a "Did she drink a lot last night too?"

translate english ch05_acar02_5c4c3197:

    a "She looks completely out of it."

translate english ch05_acar02_b86f83eb:

    d "I...I think so..."

translate english ch05_acar02_edbb7d05:

    d "........"

translate english ch05_acar02_a0527d22:

    a "Good grief, that crazy bitch."

translate english ch05_acar02_a8a054af:

    a "Couldn't she at least button up her shirt? Look at her."

translate english ch05_acar02_d1b1ed94:

    a "She's a mountain witch."

translate english ch05_acar02_7511422d:

    a "I'm telling you, she's a mountain witch."

translate english ch05_acar02_49e39781:

    d "Ahem....."

translate english ch05_acar02_5e3aec4e_1:

    d ".........."

translate english ch05_acar02_f96c0300:

    o "..........."

translate english ch05_acar02_5c8daf0a:

    o "I can hear you. Amanda."

translate english ch05_acar02_f96c0300_1:

    o "..........."

translate english ch05_acar02_46480122:

    o "I know exactly what you two are up to...."

translate english ch05_acar02_0d03b11f:

    o "You two are such a pair of perverts..."

translate english ch05_acar02_5761791e:

    o "La la la la~~~"

translate english ch05_acar02_a151db34:

    o "......."

translate english ch05_acar02_464f8141:

    a "Haa....maybe I'm getting old."

translate english ch05_acar02_27818d3a:

    a "A little bit of alcohol and I was completely knocked out."

translate english ch05_acar02_b2b821d1:

    a "........."

translate english ch05_acar02_b8437301:

    a "I didn't say anything weird last night, did I?"

translate english ch05_acar02_c8cbfed1:

    d "Haha, no. Nothing much happened."

translate english ch05_acar02_77363ea9:

    d "It's just that...."

translate english ch05_acar02_5981f1a7:

    d "You were kind of cute, that's all. Hahaha."

translate english ch05_acar02_f357339c:

    a "What is that supposed to mean?"

translate english ch05_acar02_a79822de:

    a "........"

translate english ch05_acar02_87b20e46:

    a "You're making it sound like I did something last night."

translate english ch05_acar02_7f716a94:

    d "No, you didn't."

translate english ch05_acar02_6e5ace7e:

    d "You just got tired while drinking and went inside."

translate english ch05_acar02_2efa4073:

    d "You and Olivia did drink quite a bit, though. Both of you."

translate english ch05_acar02_399db8e5:

    a "............"

translate english ch05_acar02_20f6670c:

    a "Hmm....."

translate english ch05_acar02_0c83f565:

    d "Why?"

translate english ch05_acar02_235c90d3:

    d "You think I'm lying?"

translate english ch05_acar02_b5e95b48:

    a "Haha, no."

translate english ch05_acar02_ed25279c:

    a "Don't worry about it."

translate english ch05_acar02_ad893dfa:

    d "......"

translate english ch05_acar02_2998ac51:

    a "Oh, is this the place?"

translate english ch05_acar02_a1b27a8e:

    d "Yeah. Heh."

translate english ch05_acar02_453cf5e6:

    a "Nice place."

translate english ch05_acar02_771f1f88:

    a "I didn't know there was a neighborhood like this in Milfheim."

translate english ch05_acar02_720a4c4a:

    d "It's a little far from downtown, but it's quiet, so I like it."

translate english ch05_acar02_86ace65e:

    d "It's a good place for an old soul like me to live. Hahaha."

translate english ch05_acar02_303f453e:

    a "You're not spending all day cooped up in your room playing games, are you?"

translate english ch05_acar02_219bf574:

    d "Haha, no."

translate english ch05_acar02_2fd3cacc:

    d "I've actually got plenty of things to do."

translate english ch05_acar02_3bbe2bad:

    a "Okay, got it. Heh."

translate english ch05_acar02_b00ad13b:

    a "............."

translate english ch05_acar02_b2b821d1_1:

    a "........."

translate english ch05_acar02_edbb7d05_1:

    d "........"

translate english ch05_acar02_b2b821d1_2:

    a "........."

translate english ch05_acar02_3874d6a6:

    a "Why?"

translate english ch05_acar02_c948435e:

    a "Why are you looking at me like that?"

translate english ch05_acar02_6d6d4c3b:

    a "Do you have something to say?"

translate english ch05_acar02_8b974a07:

    a "Do you need some spending money?"

translate english ch05_acar02_27e06004:

    d "Uh....."

translate english ch05_acar02_e8a0134e:

    d "N...nothing."

translate english ch05_acar02_b2b821d1_3:

    a "........."

translate english ch05_acar02_9324d5ab:

    n "Amanda and [d_name] kissed each other almost simultaneously."

translate english ch05_acar02_8dc43007:

    n "They both knew that their relationship could never be anything more than platonic,"

translate english ch05_acar02_3a869eb4:

    n "but after what happened at the beach, they had become a little more open and honest about exploring each other's bodies."

translate english ch05_acar02_fd66426c:

    a "Stop fooling around and get inside, kid."

translate english ch05_acar02_d1e85cb4:

    a "Are we a couple or something? Heh."

translate english ch05_acar02_19253ea5:

    d "Ah...okay..."

translate english ch05_acar02_bf07f87d:

    d "Want to come inside with me?"

translate english ch05_acar02_d4df066f:

    a "What? Hahaha."

translate english ch05_acar02_850eca0a:

    d "Why not? What's the harm?"

translate english ch05_acar02_171171f6:

    d "Come rest in my room for a bit before you go."

translate english ch05_acar02_f2a1e32f:

    d "Your head must be killing you right now too, huh?"

translate english ch05_acar02_5ffff6cd:

    d "I'll give you a massage."

translate english ch05_acar02_511195cb:

    a "You want me to rest in your room?"

translate english ch05_acar02_b2b821d1_4:

    a "........."

translate english ch05_acar02_5e5633e8:

    a "No."

translate english ch05_acar02_e1b16735:

    a "Maybe after I talk to your landlady and get to know her a little better. Then we'll see."

translate english ch05_acar02_3051f0b4:

    a "And I know exactly what kind of massage you're talking about, okay?"

translate english ch05_acar02_3b4a32e9:

    a "Am I your girlfriend?"

translate english ch05_acar02_640143e0:

    d "Heh. Okay."

translate english ch05_acar02_77673f80:

    d "........."

translate english ch05_acar02_5e3aec4e_2:

    d ".........."

translate english ch05_acar02_4cd15d58:

    d "....."

translate english ch05_acar02_9dde30cb:

    d "Why do I suddenly feel worried whenever I look at Amanda??...."

translate english ch05_acar02_53998eb1:

    d "I have this weird feeling like something's going to happen."

translate english ch05_acar02_02d13543:

    d "Damn.."

translate english ch05_acar02_869ff51b:

    d "Am I starting to develop anxiety or something.."

translate english ch05_acar02_154797aa:

    d "I haven't even done anything wrong, but I can't help feeling anxious...."

translate english ch05_acar02_9670333a:

    d "I mean, showing my cock to both sisters was pretty fucking crazy, hehehe......"

translate english ch05_acar02_800c383f:

    d "They might secretly think I'm a pervert....."

translate english ch05_acar02_97245ffa:

    d "Maybe they're just hiding it because they don't want things to get awkward..."

translate english ch05_hhouse00_7ab39cb0:

    d "!!!!"

translate english ch05_hhouse00_d8c3dcb3:

    b "!!!!"

translate english ch05_hhouse00_ab4346e1:

    d "Ah...."

translate english ch05_hhouse00_84dc4a16:

    d "Hi, Beth."

translate english ch05_hhouse00_ae60a433:

    b "H-hi, [d_name]."

translate english ch05_hhouse00_324436db:

    b "......"

translate english ch05_hhouse00_ab88aff3:

    b "Looks like you just got back from somewhere?"

translate english ch05_hhouse00_77673f80:

    d "........."

translate english ch05_hhouse00_db2c0337:

    b ".........."

translate english ch05_hhouse00_c8e2c724:

    d "Ah, yeah....."

translate english ch05_hhouse00_06f4315d:

    d "I took a short trip..."

translate english ch05_hhouse00_2ebbc033:

    b "I see..."

translate english ch05_hhouse00_3231ec21:

    b "Sounds like you had fun. Heh."

translate english ch05_hhouse00_1bf70aab:

    b "....."

translate english ch05_hhouse00_eb69d486:

    b "Oh, and I put your clothes away in your room."

translate english ch05_hhouse00_0f5997eb:

    d "Oh, thanks."

translate english ch05_hhouse00_a015eb55:

    d "I could've done that myself...."

translate english ch05_hhouse00_fc6933cd:

    b "It's okay. It's my job."

translate english ch05_hhouse00_a4983560:

    d "You got your cast off??"

translate english ch05_hhouse00_ad893dfa:

    d "......"

translate english ch05_hhouse00_ff457c5d:

    b "Ah, yeah, that's right.."

translate english ch05_hhouse00_a5a1392e:

    b "I kept bugging the doctor because it was so uncomfortable, and he finally let me take it off. Haha."

translate english ch05_hhouse00_2ec41115:

    b "I seriously feel like I've been reborn."

translate english ch05_hhouse00_0284f2a2:

    d "Haha, just don't overdo it."

translate english ch05_hhouse00_1b556179:

    b "Don't go and give yourself a reason to get another cast, okay? Haha."

translate english ch05_hhouse00_479550c6:

    d "Yeah, got it. Haha."

translate english ch05_hhouse00_13488e71:

    b "Well....."

translate english ch05_hhouse00_02e37133:

    b "If you need anything, just text me."

translate english ch05_hhouse00_80cc7042:

    d "Yeah, will do. Heh."

translate english ch05_hhouse00_77673f80_1:

    d "........."

translate english ch05_hhouse00_d76fab35:

    d "!!!!!!"

translate english ch05_hhouse00_4ae571cf:

    h "Oh...[d_name], you're back?"

translate english ch05_hhouse00_dacc5b28:

    d "Yeah......."

translate english ch05_hhouse00_3a86e589:

    d "I...I just got back."

translate english ch05_hhouse00_e5c36b54:

    d "..........."

translate english ch05_hhouse00_2d2fa03f:

    d "**(My God....)**"

translate english ch05_hhouse00_a66887c5:

    d "**(She's acting a little strange...)**"

translate english ch05_hhouse00_fd8f1c83:

    b "......."

translate english ch05_hhouse00_06897645:

    h "Hahaha."

translate english ch05_hhouse00_b3f917b3:

    h "So, am I covering my breasts or not?"

translate english ch05_hhouse00_9f384fb4:

    d "Huh??"

translate english ch05_hhouse00_673386b9:

    d "Ah...I...I'm sorry."

translate english ch05_hhouse00_b45ae0cf:

    d "!!!"

translate english ch05_hhouse00_72bd340a:

    h "Sorry. Hahaha."

translate english ch05_hhouse00_6fdce43d:

    h "I'm just going to be comfortable in my own home."

translate english ch05_hhouse00_7e1360cf:

    h "I'm not some little girl, so I don't know why I'm making such a big deal out of this...."

translate english ch05_hhouse00_c8b353c9:

    b "..........."

translate english ch05_hhouse00_c79b38a4:

    n "Beth was somewhat surprised by [h_name]'s behavior."

translate english ch05_hhouse00_b5421b50:

    n "She knew [h_name] well, but was still surprised to see her openly bare her breasts in front of him."

translate english ch05_hhouse00_9f384fb4_1:

    d "Huh??"

translate english ch05_hhouse00_99a9042f:

    d "Ah...y-yeah. Exactly."

translate english ch05_hhouse00_d3dfb249:

    d "I think I just came down here and interrupted you for no reason."

translate english ch05_hhouse00_f6ece601:

    d "Take it easy. I'll head upstairs."

translate english ch05_hhouse00_203cc60b:

    d "......."

translate english ch05_hhouse00_06557f79:

    h "Hey, [d_name]!!"

translate english ch05_hhouse00_9f384fb4_2:

    d "Yeah??"

translate english ch05_hhouse00_7ab39cb0_1:

    d "!!!!"

translate english ch05_hhouse00_9b772b28:

    h "There's plenty of room here. Why don't you hang out with us for a while?"

translate english ch05_hhouse00_4bb59dbf:

    d "Huh??!!"

translate english ch05_hhouse00_4cd15d58:

    d "....."

translate english ch05_hhouse00_9259fdd7:

    h "Don't worry about Beth and me. Just relax and spend some time here."

translate english ch05_hhouse00_af7a80c4:

    h "You don't have to worry about what you wear. No one's going to say anything."

translate english ch05_hhouse00_e0b6a1ec:

    h "I mean, I'm old enough to be your mom, and Beth is old enough to be your aunt, so I feel bad that you're so tense around us."

translate english ch05_hhouse00_ed22ee8e:

    h "You shouldn't feel uncomfortable in your own home."

translate english ch05_hhouse00_4cd15d58_1:

    d "....."

translate english ch05_hhouse00_937d5c67:

    d "Ah...I..."

translate english ch05_hhouse00_514aca7a:

    d "I didn't sleep last night, so I'm pretty tired. I think I'll just lie down on my bed for a while..."

translate english ch05_hhouse00_0e8f802c:

    d "I'll relax here with you guys next time. Haha."

translate english ch05_hhouse00_51f71d99:

    h "Heh, okay then."

translate english ch05_hhouse00_212e669c:

    h "Well, I'm going to work out later, so I'll see you at dinner."

translate english ch05_hhouse00_af4efa9e:

    d "Ah, yeah. Got it."

translate english ch05_hhouse00_203cc60b_1:

    d "......."

translate english ch05_hhouse00_f3bf3007:

    d "Take care."

translate english ch05_hhouse00_91b2a25d:

    h "Ah......."

translate english ch05_hhouse00_a6bf90c9:

    h "If this whiskey were a man, I'd give him my whole body....."

translate english ch05_hhouse00_2e94818d:

    h "I'd give him every hole I've got.."

translate english ch05_hhouse00_d5c76ebc:

    b "Hahahaha, oh my God, [h_name]...."

translate english ch05_hhouse00_59fa2063:

    b "Where did all this talk about holes come from all of a sudden!!"

translate english ch05_hhouse00_d612b2f7:

    b "You need to see a doctor."

translate english ch05_hhouse00_c3f25bd4:

    b "Seriously, I'm not even joking."

translate english ch05_hhouse00_4719cb6b:

    h "Shut up. Hahaha."

translate english ch05_hhouse00_762fa53b:

    h "Was that a little too vulgar??"

translate english ch05_hhouse00_aa6ca3c6:

    h "What the hell is wrong with me lately? I must be sexually frustrated or something.."

translate english ch05_gym01_b09294ee:

    h "Ugh...."

translate english ch05_gym01_3a72dbee:

    h "I came here to get healthier, so why does everything feel so heavy?"

translate english ch05_gym01_dde398a8:

    h "Maybe I'll just call it a workout and go home..."

translate english ch05_gym01_884b1276:

    h "!!!!!!"

translate english ch05_gym01_aa34b01a:

    h "!!"

translate english ch05_gym01_8e323b04:

    unknownm "Ugh...."

translate english ch05_gym01_83261455:

    h "........."

translate english ch05_gym01_a1cc2724:

    unknownm "Working out really is great."

translate english ch05_gym01_e27abca3:

    unknownm "I bet I could even take on Hector and win!!"

translate english ch05_gym01_72c2be87:

    unknownm "My ancestor must've been Achilles."

translate english ch05_gym01_cf2f4708:

    unknownm "This beast of a body definitely came from Achilles."

translate english ch05_gym01_8e44d9cb:

    h "........"

translate english ch05_gym01_21bc1224:

    h "What's with that guy.."

translate english ch05_gym01_a35afc9a:

    h "How does he say things like that about himself..."

translate english ch05_gym01_8e44d9cb_1:

    h "........"

translate english ch05_gym01_a49e0d71:

    h "I kind of feel bad for [d_name]..."

translate english ch05_gym01_4555f102:

    h "Why does he treat me like I'm so intimidating....."

translate english ch05_gym01_6b54c618:

    h "Hmm....."

translate english ch05_gym01_4aa2edc6:

    h "Maybe I should give him a really deep kiss."

translate english ch05_gym01_51392875:

    h "**(What's the workout today?....)**"

translate english ch05_gym01_508ad886:

    h "**(We did legs last time, so upper body today?.. )**"

translate english ch05_gym01_3fd4bd2d:

    h "**(Should I just ask Ivy to do some squeezing exercises with me?....)**"

translate english ch05_gym01_505b606b:

    h "**(..........)**"

translate english ch05_gym01_83e24aef:

    h "**(Do you really think jokes like that are funny, [h_name]...)**"

translate english ch05_gym01_5d1942f7:

    h "!!!!"

translate english ch05_gym01_266137f8:

    h "**(Wow......)**"

translate english ch05_gym01_451162c0:

    h "**(She hasn't gained much weight, but her breasts are that big...)**"

translate english ch05_gym01_c3fac04d:

    h "**(That woman's shoulders must really hurt.)**"

translate english ch05_gym01_c6c5fec4:

    i "No!"

translate english ch05_gym01_be01d8f6:

    i "Your form is wrong!"

translate english ch05_gym01_4338f07b:

    h "..........."

translate english ch05_gym01_5721d91d:

    i "Focus on your lower body and fix your posture!!"

translate english ch05_gym01_9da35275:

    i "If your lower body is shaking, you're not getting any benefit from the exercise!!"

translate english ch05_gym01_6c23160b:

    i "The calories you're burning right now are basically your currency."

translate english ch05_gym01_7390564b:

    i "You need to move with proper form to turn those calories into muscle efficiently."

translate english ch05_gym01_577cca90:

    i "Keep that in mind."

translate english ch05_gym01_de6a83e8:

    i "With exercise, efficiency is what matters most."

translate english ch05_gym01_328fee52:

    unknownm "Ah...yes, ma'am!!"

translate english ch05_gym01_8a2ffd02:

    unknownm "..........."

translate english ch05_gym01_b1e733e1:

    unknownm "**(Damn, look at that body...)**"

translate english ch05_gym01_086f8df1:

    unknownm "**(I want to be pinned underneath her in bed.)**"

translate english ch05_gym01_e074dab6:

    unknownm "**(Damn....)**"

translate english ch05_gym01_eab3835a:

    unknownm "**(A woman like her could probably make even a man's man like me enjoy the pleasure of submission..)**"

translate english ch05_gym01_4963d6b4:

    unknownm "**(She might even fuck my cock right out of me!!)**"

translate english ch05_gym01_bd05998b:

    i "........"

translate english ch05_gym01_4483d266:

    i "Hey, [h_name]~"

translate english ch05_gym01_13a618fd:

    i "You haven't been coming every day, but you came back a lot sooner than last time. Haha."

translate english ch05_gym01_86c694c6:

    i "That's a good sign."

translate english ch05_gym01_d30a29bb:

    h "Haha."

translate english ch05_gym01_39fa1253:

    h "I could hear your nagging voice in my head, so I came."

translate english ch05_gym01_bea23ff0:

    i "Good. Excellent."

translate english ch05_gym01_f32d4ccd:

    i "You need someone to nag you if you want to keep working out."

translate english ch05_gym01_2abe92df:

    h "Who says otherwise?"

translate english ch05_gym01_06b1bf1a:

    h "I hate the nagging, but I'm still grateful to you. Haha."

translate english ch05_gym01_3865785b:

    h "Now that I've started working out again, I definitely feel like I have more energy in my life."

translate english ch05_gym01_8db1d663:

    i "Of course!"

translate english ch05_gym01_9cdc78a3:

    i "All right, today we're doing arms and abs."

translate english ch05_gym01_fa5ff87d:

    i "Normally we'd work on one muscle group at a time, but who knows when you'll come back, so we'll do both today."

translate english ch05_gym01_d18c3476:

    h "I knew you'd say that."

translate english ch05_gym01_761ceeeb:

    h "Ah.... At least upper-body workouts are better than leg day."

translate english ch05_gym01_49ee01e7:

    h "Leg day is torture..."

translate english ch05_gym01_7066335c:

    i "Aren't you jealous of my ass?"

translate english ch05_gym01_d99cec28:

    i "Be honest. You want to do legs today, don't you?"

translate english ch05_gym01_0aa988eb:

    h "Shut up."

translate english ch05_gym01_5b239f11:

    h "Shall we start the workout, Coach?"

translate english ch05_gym01_7afc402a:

    i "Hahahaha."

translate english ch05_gym01_8bc88ec3:

    i "One, two, one, two!!"

translate english ch05_gym01_1f77c545:

    i "Don't bend your back!!"

translate english ch05_gym01_58396ee7:

    i "Hey, you're gonna drop the dumbbell! Grip it tight!!"

translate english ch05_gym01_2487ca07:

    h "O...okay. Haa..."

translate english ch05_gym01_80de312f:

    i "Good, [h_name]!!"

translate english ch05_gym01_cb9d401f:

    i "Don't just bounce the weight up. Feel every part of the movement!"

translate english ch05_gym01_e0ad82ba:

    h "Got it."

translate english ch05_gym01_a3d09618:

    i "That's it!"

translate english ch05_gym01_194602db:

    i "Engage your core!!"

translate english ch05_gym01_9befe707:

    i "Don't let your shoulders rotate!!"

translate english ch05_gym01_69a17dcd:

    i "Use only your arm muscles to lift it."

translate english ch05_gym01_80de312f_1:

    i "Good, [h_name]!!"

translate english ch05_gym01_64990f26:

    i "One more set!"

translate english ch05_gym01_ac9d3418:

    h "I...I think I'm gonna die, Ivy..."

translate english ch05_gym01_2d8011ff:

    h "Haa......."

translate english ch05_gym01_0cfb3d3f:

    h "What's the point of all this...."

translate english ch05_gym01_581f01cd:

    i ".........."

translate english ch05_gym01_f52a6a69:

    h "Haa, haa...."

translate english ch05_gym01_11b7177c:

    h "Wow, I really went hard today..."

translate english ch05_gym01_162dfb92:

    i "All right, now we're doing abs."

translate english ch05_gym01_2d6cb374:

    h "Fuck...."

translate english ch05_gym01_ca252e17:

    i "Good, [h_name]."

translate english ch05_gym01_a6881016:

    i "You're focusing even more than last time."

translate english ch05_gym01_e8a12352:

    i "You seem more motivated too, am I right?"

translate english ch05_gym01_e346b9ad:

    h "Haa haa..."

translate english ch05_gym01_9085ad82:

    h "Does it look that way?"

translate english ch05_gym01_ee2e2aac:

    h "Maybe it's because I have another person in the family now??"

translate english ch05_gym01_592ed88a:

    i "Family??"

translate english ch05_gym01_9d56c061:

    i "What, did you bring a man home?"

translate english ch05_gym01_5380e53c:

    i "What, did you bring a man home???????"

translate english ch05_gym01_0237a0fb:

    h "No."

translate english ch05_gym01_bb35bef3:

    i "Then what is it?"

translate english ch05_gym01_3bba143a:

    i "..........."

translate english ch05_gym01_f3109af9:

    i "Are you pregnant?"

translate english ch05_gym01_cf1b3928:

    h "Yeah, that's right."

translate english ch05_gym01_6850f373:

    h "I'm pregnant."

translate english ch05_gym01_bf2abc00:

    i "Hahaha. Congratulations, [h_name]."

translate english ch05_gym01_3063fc25:

    h "Thanks."

translate english ch05_gym01_93c693a6:

    h "Haa haa......"

translate english ch05_gym01_e25c4ac2:

    h "Is it finally over?....."

translate english ch05_gym01_10ca8929:

    i "Are you disappointed it's over?"

translate english ch05_gym01_c6aecb95:

    i "Want to keep going? Hahaha."

translate english ch05_gym01_c35b54cb:

    h "That's the most pointless joke I've ever heard from you, Ivy."

translate english ch05_gym01_7afc402a_1:

    i "Hahaha."

translate english ch05_gym01_b2478b0b:

    i "I wasn't joking."

translate english ch05_gym01_d106d4b5:

    h "I really can't figure out your timing when it comes to jokes...."

translate english ch05_gym01_7c6ebc1a:

    i "Oh, and [h_name]."

translate english ch05_gym01_26047239:

    i "There's something important I need to tell you."

translate english ch05_gym01_0a0a22e5:

    i "Come by my office for a minute before you leave."

translate english ch05_gym01_6dc60f26:

    i "It's nothing serious. There's just something I want to talk to you about."

translate english ch05_gym01_70acac1c:

    h "Why? What is it?"

translate english ch05_gym01_fdbdef43:

    h "Can't you just tell me here?"

translate english ch05_gym01_2e00284a:

    i "I said it's important."

translate english ch05_gym01_5fdd94ac:

    h "Okay, fine."

translate english ch05_gym01_8ff55f2a:

    h "See you later."

translate english ch05_gym01_e03f5ae7:

    h "Phew........"

translate english ch05_gym01_7d92d2d8:

    h "I wish [d_name] would come and carry me home."

translate english ch05_gym01_b3ebfb2f:

    h "Then I'd spoil him rotten."

translate english ch05_gym01_7606a1dc:

    h "I could even give him a really passionate kiss"

translate english ch05_gym01_fd6f26a4:

    h "**(What could be so important that she wants me to come all the way to her office..)**"

translate english ch05_gym01_cf6ee34f:

    h "**(Now I'm getting nervous for no reason.)**"

translate english ch05_gym02_aa34b01a:

    h "!!"

translate english ch05_gym02_1bc668f7:

    h "Oh, sorry."

translate english ch05_gym02_7b75f3e5:

    h "Should I come back later?"

translate english ch05_gym02_936fe6e3:

    i "No, it's okay. Haha."

translate english ch05_gym02_6a230d65:

    i "I was just cooling down a little. Come on in."

translate english ch05_gym02_81ec808d:

    h "Okay.."

translate english ch05_gym02_437f2e60:

    h "Ugh...my arms hurt.."

translate english ch05_gym02_d02a287f:

    i "Haha."

translate english ch05_gym02_4754aa40:

    i "Make sure you're getting enough protein."

translate english ch05_gym02_a79960b6:

    h "I'm stopping by the grocery store later to pick up some chicken."

translate english ch05_gym02_407fd1e3:

    h "When I don't feel like cooking, chicken is the way to go."

translate english ch05_gym02_9afbef54:

    h "So, what did you want to talk about?"

translate english ch05_gym02_823c0487:

    h "You're not about to confess your love to me, are you?"

translate english ch05_gym02_dde2a38e:

    i "Hahahaha."

translate english ch05_gym02_b9891a23:

    i "How did you know?"

translate english ch05_gym02_c06160e1:

    i "I actually fell in love with you the moment I first saw you."

translate english ch05_gym02_5c9ad689:

    h "Pfft...."

translate english ch05_gym02_cea2e9f5:

    h "If you want to date me, you'll have to get in line."

translate english ch05_gym02_b24ba08f:

    h "I've got about ten guys waiting already."

translate english ch05_gym02_45776b85:

    h "From young boys to old geezers."

translate english ch05_gym02_581f01cd:

    i ".........."

translate english ch05_gym02_16e97a86:

    i "Well....what I wanted to tell you is..."

translate english ch05_gym02_58a8722b:

    i "You remember that guy I mentioned while we were in the shower last time, right?"

translate english ch05_gym02_54a422b1:

    i "The guy who comes here to work out sometimes."

translate english ch05_gym02_4338f07b:

    h "..........."

translate english ch05_gym02_0a5acd1e:

    h "Yeah, I remember him."

translate english ch05_gym02_72ed181a:

    h "Why? What about him?"

translate english ch05_gym02_581f01cd_1:

    i ".........."

translate english ch05_gym02_42f792a5:

    i "I want to introduce you to him."

translate english ch05_gym02_a3c940bd:

    i "He's agreed to it."

translate english ch05_gym02_b9d69c05:

    h "What?!!!"

translate english ch05_gym02_aa3e21fa:

    h "Y-you're serious??"

translate english ch05_gym02_4338f07b_1:

    h "..........."

translate english ch05_gym02_84a78a27:

    h "I told you I'd think about it."

translate english ch05_gym02_b4cb5256:

    h "Why are you suddenly making this decision on your own??"

translate english ch05_gym02_34171a6b:

    i "Whoa, whoa, calm down."

translate english ch05_gym02_eb96e933:

    i "I'm just saying you two should at least get in touch."

translate english ch05_gym02_1926a666:

    i "Who's asking you to get married right now?"

translate english ch05_gym02_a14bf011:

    h "No, I know, but...."

translate english ch05_gym02_c0c17c83:

    h "It's just....so sudden."

translate english ch05_gym02_0280f845:

    i "It's okay."

translate english ch05_gym02_fe1f18ed:

    i "Don't you trust me?"

translate english ch05_gym02_32b5f3cb:

    i "He's so straight-laced he's almost boring."

translate english ch05_gym02_2ed28d8b:

    i "If he were some kind of creep, I wouldn't have even brought him up."

translate english ch05_gym02_a01f4f46:

    h ".........."

translate english ch05_gym02_c2ff6150:

    h "Well, that's true.."

translate english ch05_gym02_2e49f313:

    i "He's a really good guy."

translate english ch05_gym02_dcf33fbc:

    i "He's easygoing and has good manners.."

translate english ch05_gym02_758cfee7:

    i "He's just the right kind of guy. Nothing lacking, nothing over the top."

translate english ch05_gym02_f0768f32:

    h "..............."

translate english ch05_gym02_5f90d90e:

    i "Are you going to pretend to think about it again??...."

translate english ch05_gym02_ca551a52:

    i "Please, [h_name]...."

translate english ch05_gym02_3bba143a:

    i "..........."

translate english ch05_gym02_ba001471:

    i "Honey..."

translate english ch05_gym02_dd5e7526:

    i "You've been living alone for quite a while now, haven't you?"

translate english ch05_gym02_83261455:

    h "........."

translate english ch05_gym02_d816d20a:

    i "You can't get too comfortable living alone."

translate english ch05_gym02_ff7ae9e6:

    i "It's time to meet someone good and start over."

translate english ch05_gym02_2b42c983:

    i "Otherwise, you'll blink and suddenly you'll be in your fifties and completely worn out."

translate english ch05_gym02_a01f4f46_1:

    h ".........."

translate english ch05_gym02_64d56e05:

    h "!!!!!!!!!!!"

translate english ch05_gym02_6911f309:

    n "While they were talking, the office door opened without a knock."

translate english ch05_gym02_145580df:

    n "A middle-aged man who looked like he had a bit of an attitude walked in."

translate english ch05_gym02_4338f07b_2:

    h "!!!!!!!!!!!!!!!!"

translate english ch05_gym02_5efaff24:

    unknownm "Ah, sorry to interrupt."

translate english ch05_gym02_48f066ed:

    unknownm "........."

translate english ch05_gym02_c8ded4af:

    unknownm "I didn't realize you had a visitor."

translate english ch05_gym02_12beca97:

    h "**(C-could it be...)**"

translate english ch05_gym02_9a5ef390:

    h "**(Is that him?!!)**"

translate english ch05_gym02_c7a84146:

    h "**(Oh, shit....)**"

translate english ch05_gym02_62707499:

    h "**(He looks like a domestic abuser???)**"

translate english ch05_gym02_d3f3b762:

    h "!!!!!"

translate english ch05_gym02_ff804a6e:

    n "Mwah."

translate english ch05_gym02_bd5df328:

    unknownm "I'm sorry."

translate english ch05_gym02_eb2a76aa:

    unknownm "I apologize for barging in like that when we're meeting for the first time."

translate english ch05_gym02_4c2654e5:

    unknownm "I guess I don't get embarrassed as easily as I used to. Haha."

translate english ch05_gym02_0a85bef0:

    unknownm "Don't worry, I'm not some weirdo."

translate english ch05_gym02_0c06425a:

    h "Oh, okay...."

translate english ch05_gym02_0d31c030:

    unknownm "I'll be working out."

translate english ch05_gym02_760d41cf:

    unknownm "See you later."

translate english ch05_gym02_d85d5a45:

    i "See you later, Teddy Bear. Hehe."

translate english ch05_gym02_7caf97d7:

    h "............."

translate english ch05_gym02_3a78541e:

    h "**(Teddy Bear....)**"

translate english ch05_gym02_00f066ea:

    h "......."

translate english ch05_gym02_1742743c:

    i "What? Hahaha."

translate english ch05_gym02_ad420720:

    i "Sorry for making you uncomfortable."

translate english ch05_gym02_d792ddb7:

    h "Ah...no."

translate english ch05_gym02_73440d8d:

    h "You don't need to apologize for something like that....."

translate english ch05_gym02_c30ba0ca:

    i "Listen, [h_name]."

translate english ch05_gym02_e0f72f6c:

    i "You've worked really hard all these years."

translate english ch05_gym02_823f0b46:

    i "I've watched you closely all these years."

translate english ch05_gym02_00f066ea_1:

    h "......."

translate english ch05_gym02_ab662389:

    i "I really want you to meet a decent man now."

translate english ch05_gym02_3bba143a_1:

    i "..........."

translate english ch05_gym02_beece366:

    i "You know what I mean, right?"

translate english ch05_gym02_9eb480e8:

    i "Someone who's easygoing and understanding.."

translate english ch05_gym02_b9b87643:

    i "Someone who makes a normal living."

translate english ch05_gym02_0c4d182f:

    i "Someone who takes reasonably good care of himself.."

translate english ch05_gym02_a56fe697:

    i "Someone you can spend the second half of your life with."

translate english ch05_gym02_4338f07b_3:

    h "..........."

translate english ch05_gym02_fe774988:

    i "If you just want to have fun with one guy after another, then that's your business....."

translate english ch05_gym02_3bba143a_2:

    i "..........."

translate english ch05_gym02_2ac4108d:

    i "But that's not what you're doing, is it?.."

translate english ch05_gym02_1ad63484:

    i "At our age, are you really going to sit around fretting like some teenage girl?"

translate english ch05_gym02_4338f07b_4:

    h "..........."

translate english ch05_gym02_af3181c4:

    h "......"

translate english ch05_gym02_c672e7e5:

    i "What do you think?"

translate english ch05_gym02_e0ad82ba:

    h "Okay."

translate english ch05_gym02_8e44d9cb:

    h "........"

translate english ch05_gym02_fa0770e1:

    h "I'll meet him."

translate english ch05_gym02_017976d9:

    i "Good. I think you're making the right choice."

translate english ch05_gym02_595fa25c:

    i "Just take it easy and meet him first. Get to know what kind of person he is."

translate english ch05_gym02_2bb435e8:

    i "And don't go following him home just because you like him. Hahaha."

translate english ch05_gym02_8e44d9cb_1:

    h "........"

translate english ch05_gym02_e9afbf06:

    i "Men our age tend to pull their cocks out the moment they think the mood is right, so be careful. Hahaha."

translate english ch05_gym02_cc13eccf:

    i "Don't just grab it because the mood feels good."

translate english ch05_gym02_551fca3d:

    h "Ugh...."

translate english ch05_gym02_b4cef601:

    h "That’s never going to happen."

translate english ch05_gym02_6d4e075d:

    i "Then I’ll give that guy your contact info."

translate english ch05_gym02_d0aa5eea:

    i "He’ll text you later."

translate english ch05_gym02_5fdd94ac:

    h "Okay, got it."

translate english ch05_gym02_113e9995:

    h "Thanks for thinking of me, Ivy."

translate english ch05_gym02_f33ee18b:

    i "You’re welcome."

translate english ch05_gym02_90728d26:

    i "I hope it works out."

translate english ch05_gym02_260dc016:

    i "If it does, you can buy me dinner sometime. Haha."

translate english ch05_gym02_d73ffc89:

    h "Alright. Haha."

translate english ch05_gym02_d4a56a17:

    i "You should probably make sure your skills haven’t gotten rusty, too."

translate english ch05_gym02_780e32c1:

    i "Maybe dig some sexy lingerie out of the closet."

translate english ch05_gym02_7b0afd84:

    h "Shut up."

translate english ch05_gym02_03c4255c:

    h "See you later."

translate english ch05_gym02_9bea906e:

    i "Yeah, you know you shouldn’t go more than two days without working out, right?"

translate english ch05_gym02_1de825c0:

    h "Haha, got it."

translate english ch05_gym02_ef829db7:

    h "Haa........"

translate english ch05_gym02_3ab7fc0c:

    h "I don’t know........"

translate english ch05_gym02_12edf108:

    h "I mean, having a friend in the neighborhood would be nice.."

translate english ch05_gym02_3c7f6e1f:

    h "What’s the worst that could happen?"

translate english ch05_hhouse01_02d13543:

    d "Damn.."

translate english ch05_hhouse01_e5c36b54:

    d "..........."

translate english ch05_hhouse01_acab4357:

    d "I should’ve read through my textbooks a little. It’s already getting fuzzy."

translate english ch05_hhouse01_38ca1b70:

    d "Hmm......"

translate english ch05_hhouse01_8a40c6ad:

    d "People [d_name] has met."

translate english ch05_hhouse01_b642b647:

    d "Rose..."

translate english ch05_hhouse01_c5936ed8:

    d "The situation: a marketing company internship interview..."

translate english ch05_hhouse01_eed86307:

    d "The title......"

translate english ch05_hhouse01_68c7c6b1:

    d "A Psychological Analysis of First Impressions and Interpersonal Perception."

translate english ch05_hhouse01_203cc60b:

    d "......."

translate english ch05_hhouse01_ebcc8c32:

    d "Damn... that’s good..."

translate english ch05_hhouse01_0730eb4f:

    d "Sounds like the title of a doctoral dissertation or something."

translate english ch05_hhouse01_78078ba7:

    h "[d_name]~~"

translate english ch05_hhouse01_061946b8:

    h "Can you come out for a second?"

translate english ch05_hhouse01_cfd4c060:

    d "Ah...just a second!!"

translate english ch05_hhouse01_e453a341:

    h "What did you say??"

translate english ch05_hhouse01_2bb7853e:

    d "So this is where this part goes..."

translate english ch05_hhouse01_e475a480:

    d "!!!!!!!!!!!!!!"

translate english ch05_hhouse01_4cd15d58:

    d "....."

translate english ch05_hhouse01_3b76ae77:

    n "[d_name]’s door opened, and [h_name] stepped inside with a shy smile."

translate english ch05_hhouse01_4662ffb9:

    n "She was wearing makeup and was all dressed up."

translate english ch05_hhouse01_85fc5fbe:

    d "Ah........"

translate english ch05_hhouse01_923a7afd:

    d "I was so caught up in my school assignment that I didn’t notice...."

translate english ch05_hhouse01_0972f285:

    h "Oh, I see."

translate english ch05_hhouse01_66dbe334:

    h "I hope I’m not interrupting you."

translate english ch05_hhouse01_d1f7d73e:

    d "No, not at all. I’m fine."

translate english ch05_hhouse01_3b176801:

    h "Hehe."

translate english ch05_hhouse01_2ced59e4:

    h "How do I look?"

translate english ch05_hhouse01_203cc60b_1:

    d "......."

translate english ch05_hhouse01_6348fac3:

    h "What’s with that reaction?....."

translate english ch05_hhouse01_af3181c4:

    h "......"

translate english ch05_hhouse01_a4215f9a:

    h "Do I look weird?"

translate english ch05_hhouse01_f48948bf:

    d "Ah... no, that's not it."

translate english ch05_hhouse01_0cc320b1:

    d "You're absolutely beautiful, Landlady....."

translate english strings:
    old "한 명의 여신 같아요."
    new "You look like a goddess."

translate english strings:
    old "제가 지금껏 본 가장 아름다운 여자에요."
    new "You're the most beautiful woman I've ever seen."

translate english ch05_hhouse01_92f21ed5:

    n "What should I do?"

translate english ch05_hhouse01_e9143ba7:

    d "You look like a... a goddess....."

translate english ch05_hhouse01_e453a341_1:

    h "What did you say??"

translate english ch05_hhouse01_199e9536:

    h "A goddess? Haha."

translate english ch05_hhouse01_4431ec3a:

    h "I wasn't expecting you to go that far.."

translate english ch05_hhouse01_f326474c:

    h "That's quite a reaction. Don't you think?"

translate english ch05_hhouse01_e6826eec:

    h "Hmm..."

translate english ch05_hhouse01_38c5a6c1:

    h "I mean, my name is that of a Greek goddess, after all. Haha."

translate english ch05_hhouse01_90bb537b:

    d "You're the most b... beautiful woman I've ever seen..."

translate english ch05_hhouse01_e453a341_2:

    h "What did you say??"

translate english ch05_hhouse01_cc05953c:

    h "You really think so??"

translate english ch05_hhouse01_4431ec3a_1:

    h "I wasn't expecting you to compliment me that much.."

translate english ch05_hhouse01_f326474c_1:

    h "That's quite a reaction. Don't you think?"

translate english ch05_hhouse01_99a9042f:

    d "Ah... I... I guess you're right."

translate english ch05_hhouse01_edbb7d05:

    d "........"

translate english ch05_hhouse01_a043714b:

    d "But why are you dressed up like this at this hour?"

translate english ch05_hhouse01_13a76dde:

    h "I was just about to head out. I have plans."

translate english ch05_hhouse01_a01f4f46:

    h ".........."

translate english ch05_hhouse01_73d69169:

    h "I just wanted a man's opinion, so I thought I'd ask [d_name]. Hehe."

translate english ch05_hhouse01_da14b19c:

    d "A... a man's opinion??"

translate english ch05_hhouse01_e90e57dc:

    d "**(A man's opinion???)**"

translate english ch05_hhouse01_d98121f6:

    h "To be honest...."

translate english ch05_hhouse01_41d5fa02:

    h "I got set up with a guy, so I'm going to meet him."

translate english ch05_hhouse01_7bd44d88:

    d "What?!!!!!!!!"

translate english ch05_hhouse01_2a374256:

    d "You're meeting a guy?!!!"

translate english ch05_hhouse01_52c02e47:

    d "But why... why are you meeting a guy..."

translate english ch05_hhouse01_8e44d9cb:

    h "........"

translate english ch05_hhouse01_dc0b23ef:

    h "Why are you so surprised??"

translate english ch05_hhouse01_47c081cf:

    h "What's wrong with me meeting a guy??"

translate english ch05_hhouse01_f19a78ae:

    d "Ah... hahaha."

translate english ch05_hhouse01_203cc60b_2:

    d "......."

translate english ch05_hhouse01_75530b5b:

    d "Sorry. I got a little carried away."

translate english ch05_hhouse01_2ca69766:

    d "I'm sorry."

translate english ch05_hhouse01_3ec22036:

    h "Haha, it's okay."

translate english ch05_hhouse01_8df07d0e:

    h "I guess I just caught you off guard with that."

translate english ch05_hhouse01_1259c890:

    h "I've got some food set out in the kitchen, so go eat dinner."

translate english ch05_hhouse01_b38c3edb:

    h "Okay? Don't skip dinner."

translate english ch05_hhouse01_69d0c2a1:

    d "Y-yes... I'll do that."

translate english ch05_hhouse01_e63dee7e:

    d "Thank you."

translate english ch05_hhouse01_06897645:

    h "Hahaha."

translate english ch05_hhouse01_343fad75:

    h "Are you really going to follow me all the way out?"

translate english ch05_hhouse01_a754aa7d:

    d "Ah.. haha."

translate english ch05_hhouse01_bade0426:

    h "Come on, go inside."

translate english ch05_hhouse01_b770b95b:

    h "At this rate, you'd think I was leaving for an overseas trip. Haha."

translate english ch05_hhouse01_802543e1:

    d "Yeah, haha. I'll head inside."

translate english ch05_hhouse01_5ae3d8ff:

    d "I'm just going to get some fresh air..."

translate english ch05_hhouse01_b45ae0cf:

    d "!!!"

translate english ch05_hhouse01_76194139:

    n "When he looked toward the road, a middle-aged man was standing there awkwardly."

translate english ch05_hhouse01_f321c29b:

    n "[d_name] instinctively felt wary of the man."

translate english ch05_hhouse01_153fc174:

    n "The closer [h_name] got to the man, the more [d_name]'s wariness turned into tension and anger."

translate english ch05_hhouse01_e5c36b54_1:

    d "..........."

translate english ch05_hhouse01_c8d2589b:

    d "**(Damn.....)**"

translate english ch05_hhouse01_8ff89597:

    d "**(This is her life....)**"

translate english ch05_hhouse01_e5c36b54_2:

    d "..........."

translate english ch05_hhouse01_1c3cbc61:

    d "**(Why does this bother me so much?....)**"

translate english ch05_hhouse01_8c4d5e2d:

    d "**(It's not like I mean anything to [h_name] anyway..)**"

translate english ch05_hhouse01_44a92def:

    d "Damn...."

translate english ch05_hhouse01_4cd15d58_1:

    d "....."

translate english ch05_hhouse01_a8adb9dd:

    d "Why do I feel like my landlady just dumped me......."

translate english ch05_hhouse01_77673f80:

    d "........."

translate english ch05_hhouse01_0e23a91b:

    d "I'm an adult, yet I'm still such a kid..."

translate english ch05_hhouse01_1d56d1d4:

    d "She's not even my mother...."

translate english ch05_hhouse02_77673f80:

    d "........."

translate english ch05_hhouse02_5bd7941e:

    d "How long has it been?....."

translate english ch05_hhouse02_ad893dfa:

    d "......"

translate english ch05_hhouse02_376fdbfa:

    d "Three hours??"

translate english ch05_hhouse02_3eddf074:

    d "Four hours??"

translate english ch05_hhouse02_7dee83fb:

    n "The sound of a car engine"

translate english ch05_hhouse02_4c0bc9dc:

    d "!!"

translate english ch05_hhouse02_5e72fb5b:

    d "**(Huh???!!!!!)**"

translate english ch05_hhouse02_4f8f83fa:

    d "[h_name]!!"

translate english ch05_hhouse02_84989bf6:

    unknownm "H-hello."

translate english ch05_hhouse02_02d13543:

    d "Damn.."

translate english ch05_hhouse02_e7c819ce:

    d "What did you do to her??!!"

translate english ch05_hhouse02_21673025:

    unknownm "No, I didn't do anything to her."

translate english ch05_hhouse02_1ada9401:

    unknownm "Sh-she'd had a little too much to drink.."

translate english ch05_hhouse02_e0798d4c:

    d "I'll help her."

translate english ch05_hhouse02_5375319d:

    unknownm "B-be careful."

translate english ch05_hhouse02_8a0217cf:

    d "Damn it, [h_name].."

translate english ch05_hhouse02_d1c084d9:

    unknownm "You must be her son."

translate english ch05_hhouse02_930fb8b4:

    unknownm "I'm really sorry things turned out like this."

translate english ch05_hhouse02_a51913fe:

    unknownm "But I didn't make her drink."

translate english ch05_hhouse02_7f4522e3:

    unknownm "I swear."

translate english ch05_hhouse02_48f066ed:

    unknownm "........."

translate english ch05_hhouse02_bdb961f7:

    unknownm "It seems like she's got a lot on her mind."

translate english ch05_hhouse02_3fc01ed3:

    unknownm "I guess I reached out to her at the worst possible time."

translate english ch05_hhouse02_6b54c618:

    h "Hmm....."

translate english ch05_hhouse02_5e3aec4e:

    d ".........."

translate english ch05_hhouse02_75564987:

    d "Thanks for bringing her home."

translate english ch05_hhouse02_6ed83e70:

    d "I'll take care of her from here, so you can go now."

translate english ch05_hhouse02_e63dee7e:

    d "Thank you."

translate english ch05_hhouse02_48f066ed_1:

    unknownm "........."

translate english ch05_hhouse02_d8bc412f:

    unknownm "Damn..."

translate english ch05_hhouse02_48f066ed_2:

    unknownm "........."

translate english ch05_hhouse02_19655aba:

    unknownm "Guess I'm never going to see her again, huh?......"

translate english ch05_hhouse02_22160ce6:

    unknownm "......."

translate english ch05_hhouse02_009266fd:

    unknownm "Ah.... I really liked her..."

translate english ch05_hhouse02_af291f67:

    h "Let go of me, you idiot.."

translate english ch05_hhouse02_80c7f35c:

    d "Are you okay, [h_name]?"

translate english ch05_hhouse02_9ee3ba87:

    h "Did you drag me to a motel?"

translate english ch05_hhouse02_b032d22c:

    d "We’re home. You’re safe now."

translate english ch05_hhouse02_fb4fc0f4:

    h "Tell this house to go fuck itself."

translate english ch05_hhouse02_3debc41c:

    d "What?!!"

translate english ch05_hhouse02_92f334fd:

    h "This isn’t my house. It belongs to the bank!!"

translate english ch05_hhouse02_fbc26343:

    d "Oh... I-I see."

translate english ch05_hhouse02_5092078a:

    h "Ow!!!"

translate english ch05_hhouse02_a18e58a8:

    d "Shit!!"

translate english ch05_hhouse02_0d7e822a:

    d "[h_name]!!!!!"

translate english ch05_hhouse02_34eec736:

    d "Holy....."

translate english ch05_hhouse02_ad893dfa_1:

    d "......"

translate english ch05_hhouse02_d52b516b:

    n "She tripped over her own legs and fell face-first onto the couch."

translate english ch05_hhouse02_9d0c936a:

    n "She was in exactly the position most people would want to see her in."

translate english ch05_hhouse02_f000c349:

    d "**(Damn.......)**"

translate english ch05_hhouse02_f49bac2f:

    h "Phew........."

translate english ch05_hhouse02_f67e6195:

    h "Take my panties off."

translate english ch05_hhouse02_1d383945:

    d "What??!!!!!!"

translate english ch05_hhouse02_1086662f:

    h "I like this position, hehe."

translate english ch05_hhouse02_6bbd9581:

    d "Damn!!"

translate english ch05_hhouse02_15f21a7c:

    n "[d_name]'s mind went completely blank when he heard [h_name] ask him to take off her panties."

translate english ch05_hhouse02_cf06c551:

    n "For a moment, he couldn't form a single coherent thought."

translate english ch05_hhouse02_68115412:

    n "He could only stand there behind [h_name], who was sticking her ass up in the air."

translate english ch05_hhouse02_7d9c5046:

    n "He stared at the curves of his landlady's ass for quite some time."

translate english ch05_hhouse02_0e383631:

    n "Then, setting his conscience aside, he decided to do as she was asked."

translate english ch05_hhouse02_033a3aa7:

    d "O-okay.."

translate english ch05_hhouse02_8a9ad1f3:

    d "I'll take your panties off...."

translate english strings:
    old "그녀의 치마를 들춘다."
    new "Lift her skirt."

translate english ch05_hhouse02_92f21ed5:

    n "What should I do?"

translate english ch05_hhouse02_e54e6164:

    h "Mmm....."

translate english ch05_hhouse02_8e1e4da5:

    n "He lifted the hem of his landlady's dress."

translate english ch05_hhouse02_01562f60:

    n "His heart was pounding like it was about to burst out of his chest."

translate english strings:
    old "그녀의 팬티를 벗긴다."
    new "Take off her panties."

translate english ch05_hhouse02_92f21ed5_1:

    n "What should I do?"

translate english ch05_hhouse02_0755ca25:

    h "Mmm........"

translate english ch05_hhouse02_caad7c1d:

    h "That..."

translate english ch05_hhouse02_3b84a8ae:

    d "What??!!!"

translate english ch05_hhouse02_01b500b6:

    h "Hoo......"

translate english ch05_hhouse02_d76f807d:

    h "That's..... that's not..... how you take them off.."

translate english ch05_hhouse02_a3d60c9c:

    d "Oh, I... I guess you're right.."

translate english ch05_hhouse02_08d97d3c:

    h "Ugh!!"

translate english ch05_hhouse02_18d03455:

    h "I think I'm gonna throw up."

translate english ch05_hhouse02_7d7a3cae:

    d "!!!!!!!!"

translate english ch05_hhouse02_3f67410d:

    d "You're gonna throw up?!!"

translate english ch05_hhouse02_50da30d0:

    h "Yeah, I think I'm gonna throw up."

translate english ch05_hhouse02_d87697d2:

    d "Damn it, [h_name]."

translate english ch05_hhouse02_53f736f8:

    d "You can't throw up on the couch!!"

translate english ch05_hhouse02_83e29b0a:

    d "Are you okay??"

translate english ch05_hhouse02_e0798d4c_1:

    d "I'll help you."

translate english ch05_hhouse02_617883f0:

    h "Yeah, fuck me hard."

translate english ch05_hhouse02_56275b25:

    d "Holy...[h_name]..."

translate english ch05_hhouse02_1dab91d3:

    d "I-I'll help you to the bedroom."

translate english ch05_hhouse02_b5b07adc:

    h "Here is.... fine too...."

translate english ch05_hhouse02_993c4bb7:

    h "Ugh......"

translate english ch05_hhouse02_5dc38b00:

    d "Damn!! Are you okay?"

translate english ch05_hhouse02_9795fc33:

    h "I'm fine.. I'm fine..."

translate english ch05_hhouse02_36156260:

    d "Ow!!"

translate english ch05_hhouse02_36156260_1:

    d "Shit!!!!!!!"

translate english ch05_hhouse02_041992ee:

    d "Ow, my ass!!"

translate english ch05_hhouse02_5b9072fc:

    h "Mmm....."

translate english ch05_hhouse02_296c82eb:

    h "So you like this position, huh, mister...."

translate english ch05_hhouse02_9c6c2728:

    h "You've got some force behind you, mister.."

translate english ch05_hhouse02_6bbd9581_1:

    d "Damn!!"

translate english ch05_hhouse02_c622f5a3:

    d "Wake up, [h_name]!!"

translate english ch05_hhouse02_5b9072fc_1:

    h "Mmm....."

translate english ch05_hhouse02_6eb80d63:

    h "What...... are you doing?......"

translate english ch05_hhouse02_3debc41c_1:

    d "Huh?!!"

translate english ch05_hhouse02_56d31319:

    d "I-I fell because you lost your balance..."

translate english ch05_hhouse02_fd75fc26:

    h "I'm waiting for you..."

translate english ch05_hhouse02_d9c7b3e3:

    d "What?????!!"

translate english ch05_hhouse02_6bbd9581_2:

    d "Damn!!"

translate english ch05_hhouse02_55f635d9:

    d "I'm sorry, [h_name]."

translate english ch05_hhouse02_fac00983:

    d "I'll help you up!!"

translate english ch05_hhouse02_2714d2e8:

    d "**(Damn!!)**"

translate english ch05_hhouse02_53fdf06b:

    d "**(Why are drunk people always so damn heavy??!!)**"

translate english ch05_hhouse02_c0180cea:

    d "**(Damn, I can't even get her up.)**"

translate english ch05_hhouse02_1e916d5f:

    d "**(So this is why Amanda kept telling me to work out!!)**"

translate english ch05_hhouse02_a9c201f9:

    d "Huff, huff...."

translate english ch05_hhouse02_fe998cd2:

    d "Y-you're heavier than you look, [h_name].."

translate english ch05_hhouse02_4338f07b:

    h "..........."

translate english ch05_hhouse02_a18e58a8_1:

    d "Shit!!"

translate english ch05_hhouse02_5645b33e:

    h "Th-this position..... isn't bad either...."

translate english ch05_hhouse02_2db91b79:

    d "I-it's not like that!!"

translate english ch05_hhouse02_6bbd9581_3:

    d "Damn!!"

translate english ch05_hhouse02_b8d5cec5:

    d "Fuck!!!"

translate english ch05_hhouse02_5ac7d8d6:

    h "Yes........."

translate english ch05_hhouse02_ce6bc08a:

    h "Fuck me....."

translate english ch05_hhouse02_6bbd9581_4:

    d "Damn!!"

translate english ch05_hhouse02_bd030031:

    d "This is not good!!"

translate english ch05_hhouse02_c01c3d87:

    h "Yeah.. this....... is not good...."

translate english ch05_hhouse02_d1c606ae:

    h "I'm....... going to get up.."

translate english ch05_hhouse02_c3a597f8:

    h "I can get up.... I can...."

translate english ch05_hhouse02_3319f843:

    d "Are you okay, [h_name]?"

translate english ch05_hhouse02_5003c9d1:

    d "Put some weight on your legs!!"

translate english ch05_hhouse02_64363e17:

    d "**(Damn, am I really going to have to carry her?)**"

translate english ch05_hhouse02_7a526740:

    h "My feet hurt."

translate english ch05_hhouse02_ea546bfb:

    h "My feet hurt, darling~~"

translate english ch05_hhouse02_f9c1a2e4:

    h "I'm taking my shoes off."

translate english ch05_hhouse02_9c11ea53:

    h "I'll be less sexy without them, though...."

translate english ch05_hhouse02_06c923b8:

    d "Ah...[h_name]!"

translate english ch05_hhouse02_327a9aa3:

    d "Fuck!!!"

translate english ch05_hhouse02_d5545e34:

    d "Don't lift both legs!!!!"

translate english ch05_hhouse02_a4d03d23:

    d "Ah.. you're going to fall again!!!"

translate english ch05_hhouse02_f0831dfa:

    l "!!!!!!!"

translate english ch05_hhouse02_fac8215b:

    d "............"

translate english ch05_hhouse02_3e8bee64:

    d "**(Who could that be at this hour??)**"

translate english ch05_hhouse02_9e6788df:

    d "**(Damn!!!!!)**"

translate english ch05_hhouse02_759902cb:

    d "Wh-who is it?!!"

translate english ch05_hhouse02_44a92def:

    d "Damn...."

translate english ch05_hhouse02_9b8a3852:

    l "..........."

translate english ch05_hhouse02_c0662739:

    l "What.."

translate english ch05_hhouse02_f03f2c91:

    l "What the.."

translate english ch05_hhouse02_e2db5e29:

    l "What the fuck.."

translate english ch05_hhouse02_5e1d008e:

    l "......"

translate english ch05_hhouse02_478e7fac:

    l "What the hell are you doing???....."

translate english ch05_hhouse02_b6fc6486:

    l "Holy......"

translate english ch05_hhouse02_c07f86bb:

    l "You little brat!!"

translate english ch05_hhouse02_fcec3aa6:

    l "So this is who you really are!!"

translate english ch05_hhouse02_5439d316:

    n "Click!!"

translate english ch05_hhouse02_fac8215b_1:

    d "............"

translate english ch05_hhouse02_0a7cb8c2:

    d "Le...Lena...."

translate english ch05_hhouse02_4d9a2d78:

    d "H-hello."

translate english ch05_hhouse02_cfe53a31:

    h "This is really awkward."

translate english ch05_hhouse02_3debc41c_2:

    d "Huh?!!"

translate english ch05_hhouse02_0d811acb:

    d "Awkward?"

translate english ch05_hhouse02_e992465a:

    h "I've never had a threesome before."

translate english ch05_hhouse02_fac8215b_2:

    d "............"

translate english ch05_hhouse03_08eacfaa:

    n "Lena laid the drunk and unconscious [h_name] down on the bed."

translate english ch05_hhouse03_5c3c19dd:

    n "Then she undressed her completely so she could sleep comfortably."

translate english ch05_hhouse03_6370ed94:

    l "........."

translate english ch05_hhouse03_6370ed94_1:

    l "........."

translate english ch05_hhouse03_9e70f005:

    l "You're so beautiful, [h_name]..."

translate english ch05_hhouse03_c764be51:

    l "You were the most beautiful girl even when you were little."

translate english ch05_hhouse03_9b31f540:

    l "And that beauty hasn't faded at all with age."

translate english ch05_hhouse03_9fff8a55:

    n "Lena put [h_name]'s nipple in her mouth."

translate english ch05_hhouse03_a7eae4bf:

    n "She savored [h_name]'s nipple for a while."

translate english ch05_hhouse03_e9c20971:

    l "I never thought I'd find you drunk and passed out like this."

translate english ch05_hhouse03_319c4a35:

    l "I should've called you before coming over.."

translate english ch05_hhouse03_6fa08a07:

    l "......."

translate english ch05_hhouse03_aa83072b:

    l "Get some good rest, baby."

translate english ch05_hhouse03_53b7d503:

    n "In the living room, [d_name] sat there nervously."

translate english ch05_hhouse03_4c0bc9dc:

    d "!!"

translate english ch05_hhouse03_c8d2589b:

    d "**(Damn.....)**"

translate english ch05_hhouse03_8ced1cbe:

    d "**(She doesn't look too happy...)**"

translate english ch05_hhouse03_5195afca:

    n "They sat there in silence for a while."

translate english ch05_hhouse03_1c3311aa:

    n "Although [d_name] was nervous as a tenant,"

translate english ch05_hhouse03_04ea9ad5:

    n "Lena was trying hard to hold back a delighted smile."

translate english ch05_hhouse03_5e3aec4e:

    d ".........."

translate english ch05_hhouse03_5e1d008e:

    l "......"

translate english ch05_hhouse03_e7af3c2d:

    d "Ahem......"

translate english ch05_hhouse03_c38dfeb6:

    d "Um.... well..."

translate english ch05_hhouse03_5e1d008e_1:

    l "......"

translate english ch05_hhouse03_8a767c24:

    d "It was an accident....."

translate english ch05_hhouse03_5e3aec4e_1:

    d ".........."

translate english ch05_hhouse03_0dcd132c:

    d "It's not what you think, Ma'am.."

translate english ch05_hhouse03_5e1d008e_2:

    l "......"

translate english ch05_hhouse03_403f398e:

    d "It's not like I undressed my landlady because I had ulterior motives or anything....."

translate english ch05_hhouse03_5e3aec4e_2:

    d ".........."

translate english ch05_hhouse03_00cb7e7e:

    d "And I didn't have my dick... I mean, my thing, hanging out like that on purpose....."

translate english ch05_hhouse03_20f4619a:

    d "**(Damn, that scared me..)**"

translate english ch05_hhouse03_3c7a7f55:

    d "**(...........)**"

translate english ch05_hhouse03_b4e0bd75:

    d "**(Damn, her not saying anything is making me even more nervous.)**"

translate english ch05_hhouse03_047395ba:

    d "**(I can't tell if she believes me or not.)**"

translate english ch05_hhouse03_6fb2aaa4:

    l "You......"

translate english ch05_hhouse03_aa7b2326:

    l "What were you trying to do to [h_name]?"

translate english ch05_hhouse03_ca742c69:

    l "You pervert."

translate english ch05_hhouse03_fb2305da:

    d "Th-that wasn't it.."

translate english ch05_hhouse03_8bd47d78:

    l "What wasn't it??!!"

translate english ch05_hhouse03_2368fa3e:

    l "You dumbass."

translate english ch05_hhouse03_625ded25:

    l "Holding a drunk woman like that and acting vulgar!!"

translate english ch05_hhouse03_358e5802:

    l "You moved into this house for this, didn't you??"

translate english ch05_hhouse03_3debc41c:

    d "What?!!"

translate english ch05_hhouse03_e8eb22cd:

    l ".........."

translate english ch05_hhouse03_14dc4d52:

    l "You knew you were moving into a house where a woman lived alone, didn't you??!!"

translate english ch05_hhouse03_6abf4f0c:

    d "No, I didn't!!"

translate english ch05_hhouse03_1a3f4868:

    d "It was never like that."

translate english ch05_hhouse03_e674927f:

    d "I... well..."

translate english ch05_hhouse03_7c0a9214:

    d ".............."

translate english ch05_hhouse03_e0d20253:

    d "[h_name] is my landlady, not some woman I'm interested in."

translate english ch05_hhouse03_c52e2eed:

    d "How could I possibly think of her as a woman...."

translate english ch05_hhouse03_ce97126e:

    l "What?"

translate english ch05_hhouse03_6370ed94_2:

    l "........."

translate english ch05_hhouse03_b0253468:

    l "What the hell is that supposed to mean?"

translate english ch05_hhouse03_ad2e14ef:

    l "Are you saying [h_name] isn't attractive as a woman?!!"

translate english ch05_hhouse03_025e7dcc:

    l "Are you saying she and I are just a couple of old ladies??!!!"

translate english ch05_hhouse03_4bb59dbf:

    d "What??!!"

translate english ch05_hhouse03_edbb7d05:

    d "........"

translate english ch05_hhouse03_271306d9:

    d "Ah... that's not what I meant..."

translate english ch05_hhouse03_0af354d2:

    d "Of course she's a really sexy woman."

translate english ch05_hhouse03_b2543e73:

    d "I-I mean, she really is sexy."

translate english ch05_hhouse03_335bb1b5:

    l "What? Sexy??!!!"

translate english ch05_hhouse03_fb128341:

    d "Ah... n-no, that's not what I meant.."

translate english ch05_hhouse03_75b54b1c:

    l "What isn't?"

translate english ch05_hhouse03_3cadfcee:

    l "So you've been watching [h_name] all this time thinking about her like that, haven't you???!!"

translate english ch05_hhouse03_86fe55ce:

    l "So this is your true nature, you dirty little pervert!!"

translate english ch05_hhouse03_4bb59dbf_1:

    d "What??!!"

translate english ch05_hhouse03_510a5999:

    d "Hah......"

translate english ch05_hhouse03_e8eb22cd_1:

    l ".........."

translate english ch05_hhouse03_ad893dfa:

    d "......"

translate english ch05_hhouse03_3c306b7e:

    l "What about me?"

translate english ch05_hhouse03_e8eb22cd_2:

    l ".........."

translate english ch05_hhouse03_ad893dfa_1:

    d "......"

translate english ch05_hhouse03_edc59b17:

    l "I'm asking if you think I'm sexy too."

translate english ch05_hhouse03_203cc60b:

    d "......."

translate english ch05_hhouse03_e5c36b54:

    d "..........."

translate english ch05_hhouse03_def4c900:

    d "Yes..... you're right.."

translate english ch05_hhouse03_6107b613:

    d "Lena's sexy too..."

translate english ch05_hhouse03_77673f80:

    d "........."

translate english ch05_hhouse03_ba4a41af:

    d "Really fucking sexy.."

translate english ch05_hhouse03_846f1577:

    l "........"

translate english ch05_hhouse03_6e8b4f76:

    l "You..."

translate english ch05_hhouse03_339f38d4:

    l "....."

translate english ch05_hhouse03_c665243f:

    l "You're thinking about having sex with me right now, aren't you?"

translate english ch05_hhouse03_5051fbdc:

    d "What????!!!!"

translate english ch05_hhouse03_edbb7d05_1:

    d "........"

translate english ch05_hhouse03_cc40e61b:

    l "Tell me the truth."

translate english ch05_hhouse03_203cc60b_1:

    d "......."

translate english ch05_hhouse03_bbd065e3:

    d "Yes, you're right..."

translate english ch05_hhouse03_0680a600:

    d "I've imagined having sex with you...."

translate english ch05_hhouse03_d5b72f46:

    l "You little shit."

translate english ch05_hhouse03_7b7ccb83:

    l "Getting turned on by a woman old enough to be his mother...."

translate english ch05_hhouse03_846f1577_1:

    l "........"

translate english ch05_hhouse03_f6e7d3bf:

    l "You wanna fuck [h_name] too, don't you?"

translate english ch05_hhouse03_203cc60b_2:

    d "......."

translate english ch05_hhouse03_4cd15d58:

    d "....."

translate english ch05_hhouse03_d6969fa0:

    l "Just tell me the damn truth."

translate english ch05_hhouse03_cd836256:

    l "If I hadn't shown up, you were gonna fuck [h_name] tonight, weren't you..."

translate english ch05_hhouse03_03b1ca17:

    l "Or at least get off by getting her to use her mouth on you, right??"

translate english ch05_hhouse03_ad893dfa_2:

    d "......"

translate english ch05_hhouse03_0417f03a:

    l "No?"

translate english ch05_hhouse03_5e3aec4e_3:

    d ".........."

translate english ch05_hhouse03_6370ed94_3:

    l "........."

translate english ch05_hhouse03_c45fc407:

    l "No??????"

translate english ch05_hhouse03_72fdffce:

    d "Yes, I did."

translate english ch05_hhouse03_846f1577_2:

    l "........"

translate english ch05_hhouse03_d061a18a:

    l "You dirty little pervert."

translate english ch05_hhouse03_3a013078:

    l "How dare you get turned on by women old enough to be your mother??!!"

translate english ch05_hhouse03_3ac3991c:

    d "I'm sorry..."

translate english ch05_hhouse03_846f1577_3:

    l "........"

translate english ch05_hhouse03_26ad7f08:

    l "Stand up."

translate english ch05_hhouse03_9f384fb4:

    d "What??"

translate english ch05_hhouse03_592887b2:

    l "I said stand up."

translate english ch05_hhouse03_ad893dfa_3:

    d "......"

translate english ch05_hhouse03_f6649110:

    d "Wh-why?..."

translate english ch05_hhouse03_d518644c:

    l "Aww, just stand up for me, honey."

translate english ch05_hhouse03_ad893dfa_4:

    d "......"

translate english ch05_hhouse03_584e88f2:

    l "Prove it."

translate english ch05_hhouse03_9f384fb4_1:

    d "What??"

translate english ch05_hhouse03_88fbe7e8:

    l "Don't pretend you don't know what I mean."

translate english ch05_hhouse03_eacdd496:

    l "Prove it."

translate english ch05_hhouse03_fdf4c5fc:

    d "Prove what??"

translate english ch05_hhouse03_ad893dfa_5:

    d "......"

translate english ch05_hhouse03_cdba8674:

    d "What exactly am I supposed to prove...."

translate english ch05_hhouse03_09d51823:

    l "Show me you're man enough to fuck both [h_name] and me."

translate english ch05_hhouse03_d76fab35:

    d "!!!!!!"

translate english ch05_hhouse03_99151c4d:

    l "Come on."

translate english ch05_hhouse03_edbb7d05_2:

    d "........"

translate english ch05_hhouse03_b308496d:

    d "Y-yes.... O-okay.."

translate english ch05_hhouse03_7c6b9dc6:

    n "[d_name] pulled down his pants and underwear."

translate english ch05_hhouse03_169be9f1:

    n "He was becoming increasingly comfortable exposing his penis to women."

translate english ch05_hhouse03_a6f844e7:

    n "And he was starting to get swept up in the excitement of exposing his penis to women."

translate english ch05_hhouse03_6ccefc5e:

    l "My God......"

translate english ch05_hhouse03_6a4e9231:

    l "Oh, God..."

translate english ch05_hhouse03_b6fc6486:

    l "Holy......"

translate english ch05_hhouse03_a037fa40:

    l "**(Hah.....)**"

translate english ch05_hhouse03_383d24b0:

    l "**(Just looking at it is making my pussy twitch again...)**"

translate english ch05_hhouse03_6fa08a07_1:

    l "......."

translate english ch05_hhouse03_c58f319e:

    l "Want me to touch it?"

translate english ch05_hhouse03_ad893dfa_6:

    d "......"

translate english ch05_hhouse03_dc18d7e6:

    d "Yes......"

translate english ch05_hhouse03_0217ab96:

    l "Haha, yes?"

translate english ch05_hhouse03_ad893dfa_7:

    d "......"

translate english ch05_hhouse03_b828a80f:

    l "You dirty little boy....."

translate english ch05_hhouse03_3a220c85:

    l "Are all guys your age this shameless these days?...."

translate english ch05_hhouse03_b45ae0cf:

    d "!!!"

translate english ch05_hhouse03_07e558d4:

    d "**(Shit.....)**"

translate english ch05_hhouse03_91e69933:

    l "**(At this point, shouldn't he be a porn star??....)**"

translate english ch05_hhouse03_032fb556:

    l "**(......)**"

translate english ch05_hhouse03_2c517d27:

    l "**(My God....)**"

translate english ch05_hhouse03_0aef535b:

    l "**(I can feel how hard he is just from touching it....)**"

translate english ch05_hhouse03_fa9a548e:

    l "**(Damn....)**"

translate english ch05_hhouse03_f48a1c08:

    l "**(I want him to shove his cock inside me.)**"

translate english ch05_hhouse03_b358430d:

    l "You........"

translate english ch05_hhouse03_8c9cf82d:

    l "Have you ever had sex with an older woman?"

translate english ch05_hhouse03_cb6e6845:

    l "I mean...."

translate english ch05_hhouse03_c94e8030:

    l "What do you think about having sex with a mature woman?"

translate english ch05_hhouse03_85fc5fbe:

    d "Ah........"

translate english ch05_hhouse03_84b9ec92:

    d "No, honestly...."

translate english ch05_hhouse03_31a383db:

    d "I don't really know.."

translate english ch05_hhouse03_ee7607c1:

    l "What's with the I don't really know.."

translate english ch05_hhouse03_1e9bb9dd:

    l "**(I'm getting wet...)**"

translate english ch05_hhouse03_c8937c21:

    l "**(.....)**"

translate english ch05_hhouse03_8795b52f:

    l "**(If he fucked me with that, I don't think I'd think about sex for days afterward...)**"

translate english ch05_hhouse03_e29b4e16:

    n "She quietly brought her face close to his penis."

translate english ch05_hhouse03_a254b6d4:

    d "!!!!!"

translate english ch05_hhouse03_9b4355b5:

    d "**(Is this really happening?!!)**"

translate english ch05_hhouse03_adf9ea40:

    d "**(Is Lena really going to suck me off???)**"

translate english ch05_hhouse03_066974f2:

    l "................."

translate english ch05_hhouse03_4c0bc9dc_1:

    d "!!"

translate english ch05_hhouse03_f5e95159:

    l "I don't hide anything from [h_name]."

translate english ch05_hhouse03_3debc41c_1:

    d "What?!!"

translate english ch05_hhouse03_edbb7d05_3:

    d "........"

translate english ch05_hhouse03_72218c22:

    d "W-what do you mean, you don't hide anything from her?"

translate english ch05_hhouse03_a6d06750:

    n "She stopped just before putting [d_name]'s glans in her mouth and suddenly stood up."

translate english ch05_hhouse03_5bd886ae:

    n "Then she took his hand and led him to the room where [h_name] was sleeping."

translate english ch05_hhouse03_f7b4a73e:

    l "Come with me."

translate english ch05_hhouse03_cb7a4df4:

    d "What?!!"

translate english ch05_hhouse03_9b86ab3f:

    d "Lena, what are you doing??"

translate english ch05_hhouse03_118eb1b2:

    d "Th-this room has my la...landlady in it, doesn't it??!!"

translate english ch05_hhouse03_b66e0693:

    l "Just follow me."

translate english ch05_hhouse03_bba983ee:

    d "**(!!!!!!!!!!!!!!!!)**"

translate english ch05_hhouse03_bba983ee_1:

    d "**(!!!!!!!!!!!!!!!!)**"

translate english ch05_hhouse03_eeaa05a5:

    n "[d_name] couldn't believe what he was seeing before his eyes."

translate english ch05_hhouse03_0a2307de:

    n "His naked landlady was lying right in front of him."

translate english ch05_hhouse03_65ea4794:

    d "**(My God......[h_name]....)**"

translate english ch05_hhouse03_26a21894:

    d "**(What the hell is she planning to do right now??!!)**"

translate english ch05_hhouse03_0c2edf74:

    d "**(Su...surely not...)**"

translate english ch05_hhouse03_f0ca7d06:

    d "**(Is...is something really going to happen between my landlady and me???!!!!)**"

translate english ch05_hhouse03_5107321a:

    d "**(Holy shit.......)**"

translate english ch05_hhouse03_6bdcb253:

    d "**(Look at her......)**"

translate english ch05_hhouse03_070a7787:

    d "**(I want to climb on top of her right now....)**"

translate english ch05_hhouse03_cec2df53:

    d "**(Hah........)**"

translate english ch05_hhouse03_9daf266b:

    d "**(I feel like I could cum just from holding her and sleeping beside her.......)**"

translate english ch05_hhouse03_3a553aec:

    d "**(My God.....)**"

translate english ch05_hhouse03_42d07452:

    d "Wh-why did you bring me in here?....."

translate english ch05_hhouse03_203cc60b_3:

    d "......."

translate english ch05_hhouse03_6d3b798f:

    d "Sh..should I get into bed?"

translate english ch05_hhouse03_29d81ce4:

    l "............"

translate english ch05_hhouse03_5e3aec4e_4:

    d ".........."

translate english ch05_hhouse03_77b1784e:

    d "Ah......"

translate english ch05_hhouse03_a435557b:

    d "Mmm..........."

translate english ch05_hhouse03_31542171:

    n "He felt the familiar sensation he'd experienced recently against his penis."

translate english ch05_hhouse03_bd11d7b7:

    n "The warm, wet feeling of a woman's mouth gently wrapping around the head of his penis....."

translate english ch05_hhouse03_b6b182a6:

    n "Lena's tongue began moving softly inside."

translate english ch05_hhouse03_73611978:

    n "[d_name] had recently started gaining experience from receiving blowjobs from women."

translate english ch05_hhouse03_3c6ed61e:

    n "He could now tell from the sensation of a woman's mouth whether she was experienced or not."

translate english ch05_hhouse03_2846779a:

    n "And judging by what he felt with his penis, Lena was clearly skilled at giving blowjobs."

translate english ch05_hhouse03_c95ad7f7:

    d "Ahh........"

translate english ch05_hhouse03_f0e02339:

    n "Little by little, Lena took more and more of [d_name]'s penis into her mouth."

translate english ch05_hhouse03_b0c7ace0:

    l "Gag...."

translate english ch05_hhouse03_33822063:

    l "**(Damn!!)**"

translate english ch05_hhouse03_742f8994:

    l "**(It's hard to breathe with it just in my mouth..)**"

translate english ch05_hhouse03_4467e1ef:

    d "Ah.... Lena...."

translate english ch05_hhouse03_9160a511:

    d "It feels.... so fucking good....."

translate english ch05_hhouse03_b27c90ac:

    d "Mmm......."

translate english ch05_hhouse03_3a553aec_1:

    d "**(My God.....)**"

translate english ch05_hhouse03_b05aaeba:

    d "**(This feels so fucking good... ah....)**"

translate english ch05_hhouse03_7093771b:

    d "Mmm........."

translate english ch05_hhouse03_b27c90ac_1:

    d "Mgh......."

translate english ch05_hhouse03_f000c349:

    d "**(Damn.......)**"

translate english ch05_hhouse03_b6e9a881:

    l "Gag......."

translate english ch05_hhouse03_7f89045e:

    l "**(My mouth already hurts.....)**"

translate english ch05_hhouse03_730eb03c:

    l "**(At this rate, I don't think I can suck him for even five minutes...)**"

translate english ch05_hhouse03_b0c7ace0_1:

    l "Gag...."

translate english ch05_hhouse03_a510c48c:

    l "**(Haa.. haa....)**"

translate english ch05_hhouse03_604d681f:

    l "**(This little guy is something else..)**"

translate english ch05_hhouse03_dfefc257:

    l "**(I'd put him in my top three out of all the men I've been with.)**"

translate english ch05_hhouse03_b27c90ac_2:

    d "Mmm......."

translate english ch05_hhouse03_599c71f3:

    d "Haa......"

translate english ch05_hhouse03_07a59037:

    d "Oh, Lena......"

translate english ch05_hhouse03_722a0411:

    l "Gag.... gag...."

translate english ch05_hhouse03_b27c90ac_3:

    d "Mmm......."

translate english ch05_hhouse03_35af862b:

    d "**(She's so warm.....)**"

translate english ch05_hhouse03_7d4a95a0:

    d "**(Ah, damn.......)**"

translate english ch05_hhouse03_167f3e1f:

    d "**(Wasn't she a lesbian......)**"

translate english ch05_hhouse03_fdb7b6c5:

    d "**(What the hell is going on.......)**"

translate english ch05_hhouse03_33fde00c:

    d "**(What exactly is the relationship between my landlady and her?.....)**"

translate english ch05_hhouse03_b8d5c6e3:

    d "**(Who cares about that right now...)**"

translate english ch05_hhouse03_5eea63a0:

    d "**(Damn, this feels so fucking good..... ah....)**"

translate english ch05_hhouse03_49d9573d:

    d "**(Shit...)**"

translate english ch05_hhouse03_5773b9c0:

    d "**(This is fucking crazy....)**"

translate english ch05_hhouse03_64473c6e:

    l "Haa...."

translate english ch05_hhouse03_a8ccf5b8:

    l "Haa... haa...."

translate english ch05_hhouse03_f4e67370:

    d "Lena......"

translate english ch05_hhouse03_15b95fb3:

    d "Th-this is fucking amazing..."

translate english ch05_hhouse03_b7b3b291:

    l "Feels good?"

translate english ch05_hhouse03_3af521f7:

    l "Feels good when an older woman sucks you off, huh? Hehe."

translate english ch05_hhouse03_782f0570:

    l "It's different from young girls, isn't it??"

translate english ch05_hhouse03_dacc5b28:

    d "Yeah......."

translate english ch05_hhouse03_9066bf46:

    d "It feels so fucking good, Lena....."

translate english ch05_hhouse03_c65ec981:

    l "Hehe."

translate english ch05_hhouse03_b260832e:

    l "You're cute.."

translate english ch05_hhouse03_89be3ee5:

    l "I like how honest you are."

translate english ch05_hhouse03_d01bbe13:

    l "Good, then now..."

translate english ch05_hhouse03_e3bc091b:

    l "Use me."

translate english ch05_hhouse03_7e9ed6ee:

    l "What??"

translate english ch05_hhouse03_9dedd780:

    l "Grab my head and use me."

translate english ch05_hhouse03_463a682e:

    l "Pretend my mouth is a pussy and fuck it...."

translate english ch05_hhouse03_7d7a3cae:

    d "!!!!!!!!"

translate english ch05_hhouse03_9f384fb4_2:

    d "What??"

translate english ch05_hhouse03_77673f80_1:

    d "........."

translate english ch05_hhouse03_1367047d:

    d "Pretend your mouth is a pussy....."

translate english ch05_hhouse03_aef1c38c:

    d "**(What does that even mean???)**"

translate english ch05_hhouse03_cdbfdfed:

    l "Never done it before?"

translate english ch05_hhouse03_0a6e3c8f:

    d "I just don't really understand...."

translate english ch05_hhouse03_d7bcb7d3:

    l "It's not complicated."

translate english ch05_hhouse03_edb3de17:

    l "Grab my head and fuck my mouth like you're having sex with me."

translate english ch05_hhouse03_77673f80_2:

    d "........."

translate english ch05_hhouse03_19253ea5:

    d "Ah... I-I understand..."

translate english ch05_hhouse03_a714a7db:

    d "I'll try..."

translate english ch05_hhouse03_3ff2e1e5:

    l "That's it, baby...."

translate english ch05_hhouse03_133348f9:

    l "Think of me like a whore and fuck my mouth."

translate english ch05_hhouse03_570710c6:

    l "Do whatever you want."

translate english ch05_hhouse03_d8edc38d:

    d "Damn... Lena...."

translate english ch05_hhouse03_8a9545c4:

    l "Gag..."

translate english ch05_hhouse03_b0450d16:

    d "**(Damn....)**"

translate english ch05_hhouse03_1012a1b1:

    d "**(I've never done anything like this before....)**"

translate english ch05_hhouse03_c2f34263:

    l "Gag...."

translate english ch05_hhouse03_15e9d9f4:

    l "Gck!!!!"

translate english ch05_hhouse03_32c23566:

    l "Ugh....."

translate english ch05_hhouse03_37f57a9e:

    d "Ngh........"

translate english ch05_hhouse03_2f28f627:

    d "**(D-damn...)**"

translate english ch05_hhouse03_1b7eba0f:

    l "**(Yes.....)**"

translate english ch05_hhouse03_6594b19c:

    d "**(F-feels so good....)**"

translate english ch05_hhouse03_4488a84c:

    l "Gag...."

translate english ch05_hhouse03_be018cca:

    l "Gag... gag....."

translate english ch05_hhouse03_92ad9932:

    h "............"

translate english ch05_hhouse03_6e10e5f5:

    l "Ghk...."

translate english ch05_hhouse03_b4e0294a:

    l "Gag.........."

translate english ch05_hhouse03_5188a25a:

    l "Gck......"

translate english ch05_hhouse03_77673f80_3:

    d "........."

translate english ch05_hhouse03_3e2964ed:

    d "A-are you okay?"

translate english ch05_hhouse03_68d6b8cb:

    l "Huff... huff..."

translate english ch05_hhouse03_2e3dc61c:

    l "...."

translate english ch05_hhouse03_69bcbad4:

    l "Fuck me harder, baby."

translate english ch05_hhouse03_069fcb6e:

    l "Harder.."

translate english ch05_hhouse03_77673f80_4:

    d "........."

translate english ch05_hhouse03_6e10e5f5_1:

    l "Ugh...."

translate english ch05_hhouse03_b6e9a881_1:

    l "Gag......."

translate english ch05_hhouse03_be018cca_1:

    l "Gag... gag....."

translate english ch05_hhouse03_7d435d21:

    d "Ahh, Lena!!!!!"

translate english ch05_hhouse03_95db0dd5:

    d "Ahh......."

translate english ch05_hhouse03_0d2aceb9:

    l "Huff....."

translate english ch05_hhouse03_1a6a669c:

    d "**(Damn!!!!)**"

translate english ch05_hhouse03_10393d20:

    d "**(It feels good in a completely different way from a pussy...)**"

translate english ch05_hhouse03_6743194e:

    l "Gag...... gag....."

translate english ch05_hhouse03_5188a25a_1:

    l "Gck......"

translate english ch05_hhouse03_0d2aceb9_1:

    l "Huff....."

translate english ch05_hhouse03_4d219427:

    l "Haa... haa..."

translate english ch05_hhouse03_5156fab4:

    l "Let's take a second to catch our breath...."

translate english ch05_hhouse03_02_14f3f66b:

    d "Ah... okay..."

translate english ch05_hhouse03_02_203cc60b:

    d "......."

translate english ch05_hhouse03_02_1790e632:

    n "While Lena caught her breath beside him, his eyes fell on another woman."

translate english ch05_hhouse03_02_53cd66b4:

    n "She lay there completely defenseless, like a sleeping princess."

translate english ch05_hhouse03_02_fd204ac7:

    n "[d_name] walked over to [h_name]."

translate english ch05_hhouse03_02_51efdcc9:

    l "Haa.... haa...."

translate english strings:
    old "당신의 성기를 [h_name]의 입에 넣는다."
    new "Put your cock in [h_name]'s mouth."

translate english ch05_hhouse03_02_92f21ed5:

    n "What should I do?"

translate english ch05_hhouse03_02_a8ccf5b8:

    l "Haa... haa...."

translate english ch05_hhouse03_03_736d8272:

    d "I'm... sorry.."

translate english ch05_hhouse03_03_203cc60b:

    d "......."

translate english ch05_hhouse03_03_a8ccf5b8:

    l "Haa... haa...."

translate english strings:
    old "당신의 성기를 레나의 입에 넣는다."
    new "Put your cock in Lena's mouth."

translate english ch05_hhouse03_03_92f21ed5:

    n "What should I do?"

translate english ch05_hhouse03_03_d0a5c9e1:

    l "Just a second...."

translate english ch05_hhouse03_03_0943366f:

    l "Let's rest a little longer.."

translate english ch05_hhouse03_03_11a2886d:

    l "My jaw feels like it's about to fall off."

translate english ch05_hhouse03_03_f80fe58b:

    l "J-just a second.."

translate english ch05_hhouse03_03_f4114955:

    l "Ghk!!"

translate english ch05_hhouse03_03_0d2aceb9:

    l "Huff....."

translate english ch05_hhouse03_03_1792c791:

    d "Ahh..."

translate english ch05_hhouse03_03_7e7e96d4:

    l "Gag..... gag....."

translate english ch05_hhouse03_03_4cc41f3f:

    l "**(H-he's getting more and more aggressive....)**"

translate english ch05_hhouse03_03_892f23ff:

    l "**(How dare this... this young boy treat me like this...)**"

translate english ch05_hhouse03_03_320cdd97:

    l "**(........)**"

translate english ch05_hhouse03_03_d187225b:

    n "He slowly began to discover the pleasure of using Lena's mouth."

translate english ch05_hhouse03_03_2931b10d:

    n "This wasn't about sharing pleasure with each other.."

translate english ch05_hhouse03_03_ca496394:

    n "He was solely focused on reaching his climax."

translate english ch05_hhouse03_03_a870ca09:

    n "He was using Lena's mouth as nothing more than a tool."

translate english ch05_hhouse03_03_0d2aceb9_1:

    l "Huff....."

translate english ch05_hhouse03_03_6ce5f42b:

    l "Gag... gag....."

translate english ch05_hhouse03_03_af62134d:

    l "**(Ah, being handled like this by a young guy is driving me fucking crazy!!!!)**"

translate english ch05_hhouse03_03_fc328593:

    l "**(Gah......)**"

translate english ch05_hhouse03_03_0d2aceb9_2:

    l "Huff....."

translate english ch05_hhouse03_03_e9f483d3:

    l "Gag..... gag....."

translate english ch05_hhouse03_03_0d2aceb9_3:

    l "Huff....."

translate english ch05_hhouse03_03_3be3590e:

    l "Ghk..... ghk....."

translate english ch05_hhouse03_03_9342f30e:

    d "Ahhh!!!!!!"

translate english ch05_hhouse03_03_4900fc2f:

    d "**(Ugh... I'm gonna cum......)**"

translate english ch05_hhouse03_03_85fc5fbe:

    d "Ah........"

translate english ch05_hhouse03_03_72539bad:

    l "Gack..."

translate english ch05_hhouse03_03_0daec7a2:

    l "Gag....."

translate english ch05_hhouse03_03_ea3c48bc:

    d "**(Aah...........)**"

translate english ch05_hhouse03_03_d1ae79b3:

    d "**(Ah!!!!!!!!!)**"

translate english ch05_hhouse03_03_4fcaa392:

    d "Hah......."

translate english ch05_hhouse03_03_2a880ba7:

    d "M-my God....."

translate english ch05_hhouse03_03_30db53c9:

    l "Haa....haa....haa....."

translate english ch05_hhouse03_03_3a553aec:

    d "**(My God.....)**"

translate english ch05_hhouse03_03_c0d2e6d8:

    d "**(What the hell did I just do??....)**"

translate english ch05_hhouse03_03_4d2e472d:

    d "**(She's my landlady's lover....)**"

translate english ch05_hhouse03_03_0825f167:

    l "Phew......"

translate english ch05_hhouse03_03_ae742efd:

    d "Are you okay, Lena?..."

translate english ch05_hhouse03_03_a9074fee:

    l "Haa...haa....."

translate english ch05_hhouse03_03_343054a5:

    l "My God..."

translate english ch05_hhouse03_03_2a90b378:

    l "You really came a lot.."

translate english ch05_hhouse03_03_213d3c3d:

    l "Phew........"

translate english ch05_hhouse03_03_ae742efd_1:

    d "Are you okay, Lena?..."

translate english ch05_hhouse03_03_c9d4536b:

    d "I-I'm sorry."

translate english ch05_hhouse03_03_e2825105:

    d "I got so carried away...."

translate english ch05_hhouse03_03_91cbb9df:

    l "I'm fine."

translate english ch05_hhouse03_03_339f38d4:

    l "....."

translate english ch05_hhouse03_03_072b88eb:

    l "Get out of here."

translate english ch05_hhouse03_03_c1026bc4:

    l "Go get some rest."

translate english ch05_hhouse03_03_2dc761c2:

    l "You've got talent."

translate english ch05_hhouse03_03_ad893dfa:

    d "......"

translate english ch05_hhouse03_03_072b88eb_1:

    l "Get out of here."

translate english ch05_hhouse03_03_ccac870f:

    l "I'm going to take a shower and go to bed too."

translate english ch05_hhouse03_03_cfa908a8:

    d "Yes..... I will.."

translate english ch05_hhouse03_03_c8d2589b:

    d "**(Damn.....)**"

translate english ch05_hhouse03_03_600f4609:

    d "**(I never should've gone into that room.....)**"

translate english ch05_hhouse03_03_a9473dbf:

    d "**(What the hell did I just do...)**"

translate english ch05_hhouse03_03_ee2d3f09:

    l "I love you, baby."

translate english ch05_police01_a4eb1da0:

    tv "And now for the next news story."

translate english ch05_police01_4d47b9d3:

    tv "Residents are growing increasingly concerned as a string of mysterious organized crimes has occurred recently in the Milfheim area."

translate english ch05_police01_7653c404:

    tv "Over the past few weeks, violent crimes using similar methods have occurred across multiple areas,"

translate english ch05_police01_c62e7d62:

    tv "and police are expanding their investigation as they suspect the incidents may be connected to an organized criminal network."

translate english ch05_police01_77553a98:

    tv "So far, police have not identified the organization behind the crimes or determined its size."

translate english ch05_police01_2688dad2:

    tv "Investigators are tracking the group behind the crimes based on the methods used and the movements of those involved."

translate english ch05_police01_98f5666b:

    tv "In a phone interview this morning, the Milfheim police chief said that, in response to the incidents,"

translate english ch05_police01_c053d5a4:

    tv "additional personnel had been brought in from outside agencies, including those in neighboring areas."

translate english ch05_police01_540b8f91:

    tv "The chief said that every available officer has been assigned to the investigation,"

translate english ch05_police01_f694fd65:

    tv "and emphasized that they would do everything in their power to uncover the truth behind the cases."

translate english ch05_police01_d52ae045:

    tv "Despite the police response, however, the crime rate has not declined, leaving residents increasingly concerned."

translate english ch05_police01_f3bf555e:

    di "............"

translate english ch05_police01_65591ad1:

    tv "Police are urging residents to immediately report any suspicious activity or information related to the crimes."

translate english ch05_police01_34788402:

    tv "And now for our next story."

translate english ch05_police01_daf66224:

    di "Good morning, everyone."

translate english ch05_police01_4a8a2dc9:

    unknownm "Good morning, ma'am."

translate english ch05_police01_9736d7e0:

    eth "............"

translate english ch05_police01_4a8a2dc9_1:

    eth "Good morning, ma'am."

translate english ch05_police01_e8ab9a1f:

    di "Good morning."

translate english ch05_police01_4a7691af:

    di "I'm the new team leader. I look forward to working with all of you."

translate english ch05_police01_6b9499f9:

    eth "Nice to meet you."

translate english ch05_police01_62ffde41:

    eth "It's a pleasure to work with you."

translate english ch05_police01_588b2101:

    n "She was organizing some paperwork when an officer approached and knocked on the door."

translate english ch05_police01_fcd5a082:

    ev "Um... Captain?"

translate english ch05_police01_be94eaaa:

    di "Yes?"

translate english ch05_police01_e6a8333e:

    di "What can I do for you?"

translate english ch05_police01_29212aed:

    ev "Well..."

translate english ch05_police01_8e6ac87f:

    ev "The chief said he's going to give us the briefing himself."

translate english ch05_police01_e8bab5eb:

    ev "He's ordered at least one person from each department to attend, except for those out in the field."

translate english ch05_police01_8f020146:

    di "Oh, really?"

translate english ch05_police01_0740a75b:

    ev "Yes. I'll show you the way. Let's head to the briefing room together."

translate english ch05_police01_3c08d3ab:

    di "Oh, I see."

translate english ch05_police01_58fa317c:

    di "Thank you."

translate english ch05_police01_cc888fea:

    ev "Hehe, you're welcome."

translate english ch05_police01_726f4a1c:

    di "............."

translate english ch05_police01_91dbb193:

    di "**(Hmm......)**"

translate english ch05_police01_31088673:

    chi "Good morning."

translate english ch05_police01_318127b9:

    chi "Everyone, listen up."

translate english ch05_police01_546439f9:

    chi "............"

translate english ch05_police01_bc3391a1:

    chi "Over the past few months, organized crime in Milfheim Hills has grown far beyond anything we anticipated."

translate english ch05_police01_90970476:

    chi "Illegal drug trafficking, gunrunning, extortion, money laundering—you name it."

translate english ch05_police01_d1801588:

    chi "Criminal organizations are rapidly expanding their influence throughout the city."

translate english ch05_police01_df2a821a:

    chi "As you all know, that's not our only problem."

translate english ch05_police01_a1c9cf4b:

    chi "We still have a string of unsolved murders on our hands,"

translate english ch05_police01_72cd8ba8:

    chi "and we haven't been able to make any arrests in the recent shootings either."

translate english ch05_police01_f255e21a:

    chi "The public's trust is shaken, and the media and City Hall are demanding results."

translate english ch05_police01_138207eb:

    chi "..........."

translate english ch05_police01_d3671930:

    chi "It means we're not doing our jobs well enough."

translate english ch05_police01_00115f43:

    chi "That's why we've brought in additional personnel to this department."

translate english ch05_police01_51614363:

    chi "And starting today, we're going to approach this organized crime problem from a different angle."

translate english ch05_police01_3f01b59f:

    chi "As of today, we're no longer treating these cases as isolated incidents."

translate english ch05_police01_2479f1ed:

    chi "We're going to investigate them under the assumption that one massive organization could be pulling the strings from behind the scenes."

translate english ch05_police01_9be804b4:

    di "........."

translate english ch05_police01_e10c74d8:

    chi "We'll also be actively coordinating with federal investigators."

translate english ch05_police01_998329f9:

    chi "Put your pride aside and focus solely on solving these cases."

translate english ch05_police01_acccbcbb:

    chi "Share whatever information is needed, and ask for whatever support you need."

translate english ch05_police01_0e2960f3:

    chi "And from now on, this entire department needs to operate as one."

translate english ch05_police01_1deb330f:

    chi "What that means is..."

translate english ch05_police01_d5db1575:

    chi "There will be no more distinctions between Vice, Homicide, and Intelligence."

translate english ch05_police01_9a80b077:

    chi "Homicide, robbery, theft, drugs, financial crimes, cybercrime, missing persons—we all share everything now."

translate english ch05_police01_d6b89f99:

    chi "That means the violent crimes happening across Milfheim right now are all connected."

translate english ch05_police01_18f7c1be:

    chi "So starting today, we're all operating as one task force."

translate english ch05_police01_e5708ad6:

    chi "Use every person and every resource we have to find the people at the top orchestrating all of this."

translate english ch05_police01_546439f9_1:

    chi "............"

translate english ch05_police01_0496029e:

    chi "But never forget one thing."

translate english ch05_police01_a049ac60:

    chi "Evidence is what matters most."

translate english ch05_police01_890e7bac:

    chi "Guesswork, hunches, rumors—none of that means anything in court."

translate english ch05_police01_2fbcc82e:

    chi "Once we make an arrest, the only thing that can put these people away for good is evidence."

translate english ch05_police01_3128bab2:

    chi "Follow the money, pull communication records, collect CCTV footage, interview witnesses, conduct digital forensics. Get whatever you can."

translate english ch05_police01_ceca4970:

    chi "You all know that even a single statement from a local resident can sometimes be the key to solving a case."

translate english ch05_police01_8ff3922f:

    chi "Don't dismiss anything. Gather it all and share it with everyone."

translate english ch05_police01_434c700a:

    chi "The goal of this operation isn't to arrest a few criminals."

translate english ch05_police01_a79ec77d:

    chi "It's to cut off the head of the organization pulling the strings behind Milfheim Hills."

translate english ch05_police01_a4afe01f:

    chi ".........."

translate english ch05_police01_7869179f:

    chi "We have absolutely no idea what kind of organization we're dealing with."

translate english ch05_police01_d13c68ce:

    chi "Keep in mind that they're unlike any organization we've encountered before."

translate english ch05_police01_434c700a_1:

    chi "Serve this city with the resolve to lay down your life for it."

translate english ch05_police01_f0dccb28:

    chi "Instead, I'll personally make sure you have every kind of support you need, both tangible and otherwise."

translate english ch05_police01_0d7c4080:

    chi "That's how much is at stake here. We have to put everything on the line."

translate english ch05_police01_37653e2e:

    chi "Any questions?"

translate english ch05_police01_36b384c3:

    n "When the chief finished speaking, silence fell over the briefing room."

translate english ch05_police01_da4113fc:

    n "The defeated mood in the room reflected the state of the Milfheim Police Department itself, worn down by complaints from local residents."

translate english ch05_police01_e7ab2abd:

    n "They were demoralized."

translate english ch05_police01_cf39ac21:

    n "The place felt like a ship drifting aimlessly at sea without a captain."

translate english ch05_police01_81db6341:

    n "More than anything, they needed something that could change the mood."

translate english ch05_police01_863a90a1:

    n "They needed a bolt of lightning to reignite both their lives and their investigation."

translate english ch05_police01_febf1733:

    di "........"

translate english ch05_police01_9376b04a:

    chi "All right."

translate english ch05_police01_97e66499:

    chi "Let's get to work, everyone."

translate english ch05_police01_31e2a29a:

    chi "Detective Diana."

translate english ch05_police01_66c26835:

    chi "I need to talk to you for a moment."

translate english ch05_police01_baf6d916:

    di "Yes, sir."

translate english ch05_police01_3910a218:

    chi "Good to see you."

translate english ch05_police01_1e6bc5dd:

    di "Good morning, Chief."

translate english ch05_police01_c787e93a:

    di "Is this about the case?"

translate english ch05_police01_ed5c7b83:

    di "**(..........)**"

translate english ch05_police01_7c7e6507:

    di "**(Damn, he's not even trying to hide it anymore.)**"

translate english ch05_police01_6c0f1cee:

    di "**(Surely he's not doing it on purpose, right??)**"

translate english ch05_police01_ed5c7b83_1:

    di "**(..........)**"

translate english ch05_police01_9e796d5a:

    di "**(Is he trying to show me just how much power he has?... )**"

translate english ch05_police01_63347906:

    di "**(If I got paid every time one of the cops here stared at my tits, I could buy a house in this town.)**"

translate english ch05_police01_f9b7f7a2:

    di "**(Hah.... I feel naked again.)**"

translate english ch05_police01_d73c4b6e:

    chi "Have you had a chance to meet the rest of the team?"

translate english ch05_police01_cdd008d6:

    di "I've met a few of them."

translate english ch05_police01_22114cc5:

    di "We're planning to grab a quick meal together after work today."

translate english ch05_police01_66383631:

    chi "I see."

translate english ch05_police01_34631444:

    chi "Good idea."

translate english ch05_police01_ade9bc2c:

    chi "Don't treat them like mere coworkers."

translate english ch05_police01_9956f87f:

    chi "As long as you're working here, they're your brothers in arms."

translate english ch05_police01_72f60efc:

    chi "You've been through enough in this job to know there's no such thing as a victory you achieve alone."

translate english ch05_police01_23626c67:

    di "Yes, sir. I'll keep that in mind."

translate english ch05_police01_c7bd0d09:

    chi "They're a good team."

translate english ch05_police01_d3649f45:

    chi "It's just...."

translate english ch05_police01_3c973305:

    chi "The problem is, they've been stuck on this case for too long."

translate english ch05_police01_3c675d88:

    chi "In other words, they've fallen into a rut."

translate english ch05_police01_c3be1ac1:

    chi "And so have I..."

translate english ch05_police01_2a7fe15c:

    chi "As a result, morale is low. They're losing their motivation, too."

translate english ch05_police01_84883013:

    chi "We arrest them, they get released... We arrest them, they get released..."

translate english ch05_police01_9e706502:

    chi "Damn judges."

translate english ch05_police01_16fb3400:

    chi "......."

translate english ch05_police01_17fecb63:

    chi "Someone needs to lead them and pick up the pace."

translate english ch05_police01_e3460f08:

    chi "If they don't want to end up leaving their families with nothing."

translate english ch05_police01_cc484d43:

    chi "If things keep going this way, I’m going to lose my job."

translate english ch05_police01_801c2341:

    di "I'll make sure I do my part."

translate english ch05_police01_b01dc60c:

    chi "Good."

translate english ch05_police01_23f77b26:

    chi "This organized crime case isn't just an MPD matter anymore."

translate english ch05_police01_bded010b:

    chi "It's caught the attention of politicians, too."

translate english ch05_police01_d7dfdf46:

    chi "I'm telling you, it's becoming a national issue."

translate english ch05_police01_8f5eb83c:

    chi "And I'm sure you'll handle things just fine, but..."

translate english ch05_police01_c5922a98:

    chi "Don't let this job throw you off your own pace."

translate english ch05_police01_16fb3400_1:

    chi "......."

translate english ch05_police01_b55ea302:

    chi "You know what I mean, right?"

translate english ch05_police01_6a97c9c3:

    chi "The work we do is the kind where if one side of your life falls apart, the other comes crashing down with it."

translate english ch05_police01_8623e195:

    chi "Trust me."

translate english ch05_police01_378e6917:

    chi "I've never seen anyone stay whole when either their personal life or their work falls apart."

translate english ch05_police01_fac43171:

    di "Yes, sir. I'll keep that in mind."

translate english ch05_police01_b1f7c9b5:

    chi "Good. I trust you."

translate english ch05_police01_72c9f0df:

    chi "........."

translate english ch05_police01_165fd83c:

    chi "And there's going to be a press conference in a week."

translate english ch05_police01_1e568755:

    di ".........."

translate english ch05_police01_57338907:

    chi "It probably won't be a simple press conference. It'll feel more like a hearing designed to put pressure on us."

translate english ch05_police01_5f32e2e0:

    chi "A reporter I know gave me a heads-up."

translate english ch05_police01_fb8b7464:

    chi "I need to give them something to chew on."

translate english ch05_police01_c2fab1df:

    chi "You know what I mean?"

translate english ch05_police01_8ecbb848:

    di "Yes, I know what you mean."

translate english ch05_police01_9376b04a_1:

    chi "Good."

translate english ch05_police01_fbaea816:

    n "The chief casually walked over to her and placed a hand on her waist."

translate english ch05_police01_7dd032a4:

    chi "By the way, how are you settling into your new place?"

translate english ch05_police01_def7fc9f:

    di "It's pretty comfortable so far."

translate english ch05_police01_1c437fe3:

    chi "It feels a little bare since there's nothing around, doesn't it?"

translate english ch05_police01_4a4a1259:

    di "I actually like the quiet, so I prefer it that way."

translate english ch05_police01_e8acd9a0:

    di "And there are some great jogging trails nearby, which I really like."

translate english ch05_police01_15a0f89e:

    chi "Good to hear."

translate english ch05_police01_c7abee7b:

    chi "In a small town like this, it can get exhausting just going back and forth between your house and the police station."

translate english ch05_police01_04492cc3:

    chi "You need something of your own to help you forget the stress and pressure."

translate english ch05_police01_95ac4fa9:

    di "Yes, you're right."

translate english ch05_police01_542a1a96:

    chi "As you know, someone of your rank is directly connected to me, the chief, and a few other people higher up the chain."

translate english ch05_police01_e34c4529:

    chi "Your success is my success."

translate english ch05_police01_2c474cab:

    chi "That means you and I are tied together whether we like it or not."

translate english ch05_police01_cbfff03f:

    di "......."

translate english ch05_police01_cc463ed0:

    chi "So sometimes we need to share everything as closely as friends, and sometimes almost like a married couple."

translate english ch05_police01_0a52e6ce:

    di "..............."

translate english ch05_police01_b3fa2ff0:

    di "**(Like a married couple.... My God....)**"

translate english ch05_police01_9b1e39a7:

    chi "If you ever have a problem or there's something you want to discuss, come to me anytime."

translate english ch05_police01_c65017a1:

    chi "Whether it's work-related or personal."

translate english ch05_police01_4fb11e94:

    di "....."

translate english ch05_police01_9a165165:

    di "Yes, I will."

translate english ch05_police01_794a5820:

    chi "Anyway, I've got more experience than you, both in life and in the police force,"

translate english ch05_police01_6782b6f9:

    chi "so I hope I can make your life here a little easier."

translate english ch05_police01_1a16cf3b:

    chi "If we get the chance, I'll show you a beautiful spot I used to visit all the time when I first came here."

translate english ch05_police01_100265a2:

    chi "It's the perfect place to get away and relax in nature by yourself."

translate english ch05_police01_dce6547c:

    chi "There's an incredible mountain reservoir tucked away in the mountains."

translate english ch05_police01_fabfbddf:

    chi "It's so secluded you could swim there naked all day and never see another person."

translate english ch05_police01_baf6d916_1:

    di "Yes, sir."

translate english ch05_police01_a20382d8:

    di "I'd really like to see what kind of place it is, haha."

translate english ch05_police01_61d85b14:

    di "Thank you for looking out for me."

translate english ch05_police01_950b1eb2:

    chi "All right. Official business starts now, so get to work."

translate english ch05_police01_de4be250:

    chi "If anything comes up, come see me or give me a call anytime."

translate english ch05_police01_2fa64ebd:

    chi "Don't feel like you have to be so formal just because I'm the chief, all right?"

translate english ch05_police01_fefbc5cd:

    di "Y-yes, sir. I understand."

translate english ch05_police01_9be804b4_1:

    di "........."

translate english ch05_police01_441a0f31:

    di "**(Phew.......)**"

translate english ch05_police01_722290e4:

    di "**(I don't want to judge him this quickly, but.....)**"

translate english ch05_police01_bcf2ee85:

    di "**(He's so damn sleazy....)**"

translate english ch05_police01_a9a7c848:

    di "**(This is going to be really difficult....)**"

translate english ch05_police01_fac16014:

    n "She returned to her office and sat down at her desk."

translate english ch05_police01_85543a32:

    n "But her mind was filled with the files she had found last time."

translate english ch05_police01_335e6ab8:

    n "She pulled the files out again and spread them across the desk."

translate english ch05_police01_4857abca:

    n "Then she picked up the small note that had been bothering her the most."

translate english ch05_police01_1e568755_1:

    di ".........."

translate english ch05_police01_ec4630e9:

    di "Detective Edward....."

translate english ch05_police01_473c5295:

    di "Hmm......"

translate english ch05_police01_b40c01da:

    n "Our family is in danger."

translate english ch05_police01_78b0f7a5:

    n "Even my son is at risk"

translate english ch05_police01_4eb86898:

    n "My husband and I are leaving him at the orphanage."

translate english ch05_police01_e59c741f:

    n "It’s the only way to keep him safe."

translate english ch05_police01_6d04c1e6:

    n "This city is far more dangerous than you can imagine."

translate english ch05_police01_745b38de:

    n "Please, watch over him while you're in Milfheim."

translate english ch05_police01_2450418c:

    n "I’m sorry for asking. His name is [d_name]."

translate english ch05_police01_e6de7c33:

    di "Hmm........."

translate english ch05_police01_c5d8be4d:

    di "What the hell happened all those years ago..."

translate english ch05_police01_802d1a4d:

    di "Why did Detective Edward leave these files behind?"

translate english ch05_police01_3ca79949:

    di "Was this a case that was already closed, or one that never even got started?"

translate english ch05_police01_d283768e:

    di "Why has no one found these files until now?...."

translate english ch05_police01_f3bf555e_1:

    di "............"

translate english ch05_police01_9c45ae5a:

    di "An orphanage?......"

translate english ch05_police01_febf1733_1:

    di "........"

translate english ch05_police01_e6ed6766:

    di "[d_name].."

translate english ch05_police01_3a1576a1:

    di "I can't make heads or tails of this...."

translate english ch05_police01_c97ffe68:

    di "Ugh, fuck!!"

translate english ch05_police01_e5df3c34:

    di "I still feel like someone's touching my ass."

translate english ch05_police01_b255a9aa:

    di "Damn........"

translate english ch05_police01_efd2b777:

    di "What if the chief suddenly shows up at my apartment?..."

translate english ch05_police01_9be804b4_2:

    di "........."

translate english ch05_police01_9a6efc84:

    di "Living here isn't going to be as easy as I thought....."

translate english ch05_diner01_99614053:

    do "Oh, fuck!!!"

translate english ch05_diner01_ce0b5987:

    unknown "Ahh..!!"

translate english ch05_diner01_6865c517:

    unknown "Yes, yes!!"

translate english ch05_diner01_44930257:

    unknown "Ahh..."

translate english ch05_diner01_0e50f7bc:

    do "Shit.."

translate english ch05_diner01_2e2c7438:

    do "Isabella!!"

translate english ch05_diner01_aa764466:

    do "Your ass feels fucking amazing."

translate english ch05_diner01_86839efc:

    isa "Don't say things like that. It's embarrassing...."

translate english ch05_diner01_664b2f10:

    isa "Ahh....."

translate english ch05_diner01_b9be1de3:

    do "My God....."

translate english ch05_diner01_92915488:

    do "I can't leave you because of that ass."

translate english ch05_diner01_71cad683:

    do "I think about it all damn day."

translate english ch05_diner01_9f8f745c:

    do "It's the best fucking ass in the world."

translate english ch05_diner01_c3c6ccaf:

    isa "..........."

translate english ch05_diner01_24fbd356:

    do "You like it, Isabel?"

translate english ch05_diner01_904bd0e3:

    isa "Ah........."

translate english ch05_diner01_5ea9dba2:

    isa "I-I do."

translate english ch05_diner01_9ad18989:

    do "Are you going to let some other guy put his cock in here?"

translate english ch05_diner01_52ee5d4f:

    isa ".........."

translate english ch05_diner01_e07bea73:

    isa "N-no. Of course not."

translate english ch05_diner01_7d80982d:

    do "You don't sound so sure."

translate english ch05_diner01_f8e06123:

    isa "My a-ass is only Owen's."

translate english ch05_diner01_1526c873:

    do "What about your pussy?"

translate english ch05_diner01_8f3239e0:

    isa "My pussy belongs to Owen too. Haa...."

translate english ch05_diner01_c2baee12:

    do "Ah........"

translate english ch05_diner01_7a188aea:

    isa "Ah!!!!!!!!!!!!!!!"

translate english ch05_diner01_5000cf12:

    isa "Owen!!!!!"

translate english ch05_diner01_c2baee12_1:

    do "Ah........"

translate english ch05_diner01_5ba5a2c6:

    do "I want to do it while looking at your face."

translate english ch05_diner01_5982581c:

    do "Come on, Isabella."

translate english ch05_diner01_5381c774:

    isa "Haa....haa....."

translate english ch05_diner01_99573c3c:

    isa "You need to cum soon."

translate english ch05_diner01_970f1a99:

    isa "I can't leave the counter unattended for too long."

translate english ch05_diner01_ba829dab:

    do "Yeah, okay."

translate english ch05_diner01_69fbdb2b:

    do "I'll finish quickly."

translate english ch05_diner01_0f801049:

    do "Turn over."

translate english ch05_diner01_e7e5d844:

    do "Fuck, Isabel...."

translate english ch05_diner01_ea7c2097:

    do "You've got such a fucking sexy body."

translate english ch05_diner01_120f06e1:

    isa "Mmm....."

translate english ch05_diner01_ee8a78ab:

    do "Damn....."

translate english ch05_diner01_665d3455:

    do "No. I want to do it in your pussy."

translate english ch05_diner01_664b2f10_1:

    isa "Ahh....."

translate english ch05_diner01_c2baee12_2:

    do "Ah........"

translate english ch05_diner01_664b2f10_2:

    isa "Ahh....."

translate english ch05_diner01_fbd00eef:

    do "You taste so fucking good..."

translate english ch05_diner01_bf78ed2d:

    do "Does my cock taste good too?"

translate english ch05_diner01_9ab6abef:

    isa "Haa...haa...."

translate english ch05_diner01_7f3a06b6:

    isa "Owen's cock tastes so good..."

translate english ch05_diner01_4a6522c9:

    isa "Ahh............."

translate english ch05_diner01_2bb9c7e4:

    do "Oh, Isabella...."

translate english ch05_diner01_0e50f7bc_1:

    do "Ah......"

translate english ch05_diner01_3549dbc9:

    isa "Oh, Owen........"

translate english ch05_diner01_cf37738a:

    isa "Ah, I can feel you throbbing inside me.."

translate english ch05_diner01_483b8f48:

    do "I'm gonna cum..."

translate english ch05_diner01_664b2f10_3:

    isa "Ahh....."

translate english ch05_diner01_a9a2bd02:

    isa "Cum inside me!!"

translate english ch05_diner01_74a36d5b:

    do "Ugh......."

translate english ch05_diner01_82fe8a92:

    do "Ah!!!!!!!!!"

translate english ch05_diner01_9ab6abef_1:

    isa "Haa...haa...."

translate english ch05_diner01_a9368c9d:

    isa "Ahh......"

translate english ch05_diner01_306d86b8:

    do "Ah...Isabella...."

translate english ch05_diner01_52ee5d4f_1:

    isa ".........."

translate english ch05_diner01_e328fbba:

    isa "Haa........"

translate english ch05_diner01_52efedd7:

    isa "I think you came more than usual.."

translate english ch05_diner01_64230fb5:

    do "Shit....."

translate english ch05_diner01_a29465ed:

    do "Your pussy is always fucking amazing...."

translate english ch05_diner01_a0b0b941:

    do "I gotta go now."

translate english ch05_diner01_fb8a10f9:

    isa "........."

translate english ch05_diner01_02995fa7:

    do "I'm sorry, but I don't have much time."

translate english ch05_diner01_db9f6a90:

    do "I'm gonna be busy for a while."

translate english ch05_diner01_b061de56:

    do "The chief seems to have gotten a wild hair and is gonna be riding the cops' asses for a while."

translate english ch05_diner01_88bfa4f0:

    do "I barely managed to sneak away as it is."

translate english ch05_diner01_52ee5d4f_2:

    isa ".........."

translate english ch05_diner01_3b4b4f0d:

    do "...."

translate english ch05_diner01_92c4571a:

    do "What?"

translate english ch05_diner01_c2219f81:

    do "Is there something you want to say?"

translate english ch05_diner01_52ee5d4f_3:

    isa ".........."

translate english ch05_diner01_764e438e:

    isa "No.."

translate english ch05_diner01_963ccd8a:

    isa "I guess it can't be helped. You're busy."

translate english ch05_diner01_cae2a77a:

    do "I'll call you."

translate english ch05_diner01_b8293e77:

    do "I love you."

translate english ch05_diner01_fb8a10f9_1:

    isa "........."

translate english ch05_diner01_08414970:

    isa "......."

translate english ch05_diner01_d9595fce:

    isa "What am I to him?..."

translate english ch05_diner01_ed131ac7:

    isa "Just a way for him to satisfy his sexual urges?...."

translate english ch05_hhouse04_7d551180:

    d "**(What happened last night should never have happened.....)**"

translate english ch05_hhouse04_cec2df53:

    d "**(Haa........)**"

translate english ch05_hhouse04_2cf566f8:

    d "**(My God....)**"

translate english ch05_hhouse04_1f77497b:

    d "**(That scene was really something...)**"

translate english ch05_hhouse04_c84044c5:

    d "**(Hah......)**"

translate english ch05_hhouse04_0373c3c1:

    d "**(I wanted to bury my face between her ass cheeks.....)**"

translate english ch05_hhouse04_dbc30725:

    d "**(And then Lena made her move.....)**"

translate english ch05_hhouse04_857310a5:

    d "**(I thought I was gonna get chewed out when she was grilling me....)**"

translate english ch05_hhouse04_ada2f455:

    d "**(She....... )**"

translate english ch05_hhouse04_5626614a:

    d "**(Hah.....)**"

translate english ch05_hhouse04_4c1bcbec:

    d "**(That was on a whole different level from anything I'd ever experienced in my life....)**"

translate english ch05_hhouse04_ff5c8187:

    d "**(I guess you could call it the boldness of a mature woman.....)**"

translate english ch05_hhouse04_9a8dc85b:

    d "**(Will I ever get another chance to do that?)**"

translate english ch05_hhouse04_0e6b0ebf:

    d "**(Will she let me do it again?.....)**"

translate english ch05_hhouse04_6a29d19d:

    d "**(I wonder if the landlady got up okay the next morning?)**"

translate english ch05_hhouse04_e6de568d:

    d "**(I wanted to sleep in the same bed with them..)**"

translate english ch05_hhouse04_aabbe797:

    d "**(Just feeling each other's body heat...)**"

translate english ch05_hhouse04_3819fcc2:

    d "**(Damn......)**"

translate english ch05_hhouse04_0c34fbc7:

    d "**(I can't get enough of these milfs.....)**"

translate english ch05_hhouse04_fb4342b7:

    d "**(..........)**"

translate english ch05_hhouse04_140625e5:

    d "**(Or maybe I just like women in general?...)**"

translate english ch05_hhouse04_da1eecfb:

    d "**(Yeah......)**"

translate english ch05_hhouse04_67342287:

    d "**([h_name] couldn't possibly be okay after all that...)**"

translate english ch05_hhouse04_fb4342b7_1:

    d "**(..........)**"

translate english ch05_hhouse04_0115f942:

    d "**(I wish she'd let me give her a massage too...)**"

translate english ch05_hhouse04_6d263753:

    d "**(But Lena really is.....)**"

translate english ch05_hhouse04_90873beb:

    d "**(She's the most mysterious woman I've ever met....)**"

translate english ch05_hhouse04_9d5774b5:

    d "**(How do I put it.....)**"

translate english ch05_hhouse04_01a2d8ce:

    d "**(Like an adult who never completely grew out of her innocence...)**"

translate english ch05_hhouse04_f702eeed:

    d "**(Or maybe like a woman who's completely driven by her instincts...)**"

translate english ch05_hhouse04_b785d128:

    d "**(But she also comes across as pretty damn smart...)**"

translate english ch05_hhouse04_6e90a7ec:

    d "**(The landlady will never know what happened..)**"

translate english ch05_hhouse04_ee14d770:

    d "**(She's probably gonna be suffering from a hell of a hangover for a while..)**"

translate english ch05_hhouse04_7be7a5b0:

    d "**(But Lena, in the middle of all that....)**"

translate english ch05_hhouse04_280e6e50:

    d "**(She was messing around like that in the middle of all that, haha..)**"

translate english ch05_hhouse04_04a4c85e:

    d "**(But damn, I like women who are as horny as Lena....)**"

translate english ch05_hhouse04_fa111027:

    d "**(I love you!!!)**"

translate english ch05_hhouse04_056f0f4d:

    d "**(You hear me, Lena??)**"

translate english ch05_hhouse04_3819fcc2_1:

    d "**(Damn......)**"

translate english ch05_hhouse04_3c554a1b:

    d "**(Anyway, I promised Celine I'd go out for dinner tonight....)**"

translate english ch05_hhouse04_2490b6bb:

    d "**(........)**"

translate english ch05_hhouse04_c4e1894e:

    d "**(It's been a while since I've had dinner alone with her..)**"

translate english ch05_hhouse04_eae9be4e:

    d "**(But.....)**"

translate english ch05_hhouse04_992a5763:

    d "**(Celine's been acting kind of weird lately..)**"

translate english ch05_hhouse04_d306a067:

    d "**(It's almost like she's hiding something...)**"

translate english ch05_hhouse04_025d7594:

    d "**(There's something awkward about the way she looks at me....)**"

translate english ch05_hhouse04_6058ecae:

    d "**(.........)**"

translate english ch05_hhouse04_acbfbe39:

    d "I guess I'll find out when I see her."

translate english ch05_hhouse04_e5c36b54:

    d "..........."

translate english ch05_hhouse04_2d1e9b1e:

    d "Huh??!!!!"

translate english ch05_hhouse04_57619fa1:

    d "Wow, Celine....."

translate english ch05_hhouse04_9294137b:

    d "You look different."

translate english ch05_hhouse04_cca218aa:

    c "You look like you've seen a ghost."

translate english ch05_hhouse04_3f0a952e:

    c "Come on, I'm hungry."

translate english ch05_hhouse04_3817868a:

    c "What are you waiting for?"

translate english ch05_hhouse04_7f0a030a:

    c "Get in."

translate english ch05_hhouse04_a3749ae2:

    d "Got it, My Queen."

translate english ch05_hhouse04_088fb1f3:

    c "Shut up."

translate english ch05_bar01_a506d38a:

    d "Did I eat too much tonight?"

translate english ch05_bar01_64aa29f3:

    d "I'm stuffed."

translate english ch05_bar01_879881fc:

    c "Yeah, you're kind of surprising me tonight."

translate english ch05_bar01_3b27b0c4:

    c "You never really ate much for a guy."

translate english ch05_bar01_81a021b6:

    d "The food was so good, I actually ate a lot for once."

translate english ch05_bar01_b47c0e26:

    d "Amanda's always telling me to eat more whenever she sees me, but I just can't seem to."

translate english ch05_bar01_ecd42319:

    c "How's Aunt Amanda doing?"

translate english ch05_bar01_a2410055:

    c "I really should go see her sometime. I feel bad I haven't even called to check in."

translate english ch05_bar01_9aec63e7:

    d "It's okay."

translate english ch05_bar01_699e3f72:

    d "She's doing great. She's as healthy as ever."

translate english ch05_bar01_9c9354a9:

    d "She said she misses you."

translate english ch05_bar01_bfe69863:

    d "I'll give her your regards."

translate english ch05_bar01_caeaddd8:

    c "When I was little, I wanted to grow up to be like Amanda...."

translate english ch05_bar01_80d316b8:

    d "What? Haha."

translate english ch05_bar01_0e5949c6:

    c "There are things about being a woman that men will never understand."

translate english ch05_bar01_c03a15da:

    c "Amanda's a really fascinating woman."

translate english ch05_bar01_1cd471e8:

    d "Hmm......."

translate english ch05_bar01_77673f80:

    d "........."

translate english ch05_bar01_d7aa0ab2:

    d "So, how's married life?"

translate english ch05_bar01_b53068cf:

    d "It's been a few months already, right?"

translate english ch05_bar01_82946f36:

    c "........"

translate english ch05_bar01_7ead6ec5:

    n "She paused at [d_name]'s question about her marriage."

translate english ch05_bar01_2fd03c38:

    n "After sitting in silence for a while, she finally continued."

translate english ch05_bar01_39221102:

    c "What do you think?"

translate english ch05_bar01_32f20f62:

    d "You're asking me?"

translate english ch05_bar01_74616a36:

    d "Hmm......."

translate english ch05_bar01_a8139b25:

    d "I mean.... I don't really notice anything in particular."

translate english ch05_bar01_5e08f0fc:

    c "It's okay."

translate english ch05_bar01_ed11e4fb:

    c "You can just tell me whatever comes to mind."

translate english ch05_bar01_69ee00fb:

    d "Hmm....."

translate english ch05_bar01_f4054451:

    d "You seem happy."

translate english ch05_bar01_789f94de:

    d "Your husband lets you have dinner with a male friend? He must be pretty understanding."

translate english ch05_bar01_c4a26417:

    c "Oh, come on!!"

translate english ch05_bar01_308897b8:

    c "Just because you're married doesn't mean you have to stay home all the time!!"

translate english ch05_bar01_c7a462b3:

    c "What, do you think married couples just cuddle all day?"

translate english ch05_bar01_69ee00fb_1:

    d "Hmm....."

translate english ch05_bar01_56bf299a:

    d "...."

translate english ch05_bar01_22f6a83c:

    d "But you do seem like you've had a lot on your mind lately?..."

translate english ch05_bar01_02aec46c:

    c "I seem like I've got a lot on my mind?"

translate english ch05_bar01_1739a634:

    d "Yeah."

translate english ch05_bar01_ac0debfd:

    d "Like something's been bothering you."

translate english ch05_bar01_82946f36_1:

    c "........"

translate english ch05_bar01_ad893dfa:

    d "......"

translate english ch05_bar01_129c952a:

    c "You seem to understand me better than my own husband...."

translate english ch05_bar01_4b78c52a:

    d "What?"

translate english ch05_bar01_a47d07a5:

    d "Hahaha."

translate english ch05_bar01_b63ed0d8:

    d "You must've been underestimating me."

translate english ch05_bar01_61f11502:

    d "I did major in psychology, you know."

translate english ch05_bar01_4bb2b57a:

    d "I'm actually pretty good at reading people."

translate english ch05_bar01_61e3d5c9:

    c "Oh~~"

translate english ch05_bar01_e412a3d5:

    c "I see, Professor."

translate english ch05_bar01_200d0ec8:

    d "We've known each other for years. You think I don't know you?"

translate english ch05_bar01_2495e1d2:

    d "We're practically like siblings."

translate english ch05_bar01_d1eaf42f:

    d "We can practically read each other's minds."

translate english ch05_bar01_da194f13:

    d "We've known each other since we were kids, almost twenty years. Don't give me that."

translate english ch05_bar01_82946f36_2:

    c "........"

translate english ch05_bar01_0fe32a00:

    c "I guess you're right.."

translate english ch05_bar01_ffb66380:

    c "We've seen each other at our best and worst growing up...."

translate english ch05_bar01_8e1c4fcb:

    c "Phew......."

translate english ch05_bar01_3ef70da0:

    d "What's wrong?"

translate english ch05_bar01_e1238f4c:

    d "What's going on?"

translate english ch05_bar01_82946f36_3:

    c "........"

translate english ch05_bar01_b769d463:

    c "I thought every day of being newlyweds would be all sunshine and rainbows....."

translate english ch05_bar01_154e4fc5:

    c "........."

translate english ch05_bar01_b7e6e633:

    c "But reality isn't like that."

translate english ch05_bar01_ad893dfa_1:

    d "......"

translate english ch05_bar01_663c6cda:

    d "What? Is something wrong?"

translate english ch05_bar01_df55e80c:

    c "......."

translate english ch05_bar01_50424bee:

    c "No, it's not like there's any real problem...."

translate english ch05_bar01_d19f855d:

    c "..."

translate english ch05_bar01_002276c3:

    c "It's just...."

translate english ch05_bar01_5e3aec4e:

    d ".........."

translate english ch05_bar01_7c3c5a27:

    c "It's kind of different from what I expected..."

translate english ch05_bar01_215efd09:

    c "I mean, not what I expected exactly. It's just not the married life I imagined."

translate english ch05_bar01_812e5e5b:

    c "...But honestly, I didn't care whether it was all sunshine and rainbows. I was just happy."

translate english ch05_bar01_154e4fc5_1:

    c "........."

translate english ch05_bar01_85ec17ba:

    c "Having someone waiting for me."

translate english ch05_bar01_5f44d274:

    c "Knowing someone would be there when I got home."

translate english ch05_bar01_ad893dfa_2:

    d "......"

translate english ch05_bar01_23cc05f9:

    c "You know."

translate english ch05_bar01_226267e2:

    c "We grew up like that."

translate english ch05_bar01_154e4fc5_2:

    c "........."

translate english ch05_bar01_a248e7d9:

    c "When they turned off the lights at the orphanage and we lay down..."

translate english ch05_bar01_ed1fa98a:

    c "It felt like everyone else had somewhere to go, and we were the only ones left behind."

translate english ch05_bar01_edbb7d05:

    d "........"

translate english ch05_bar01_5f2f301d:

    c "I hated that feeling."

translate english ch05_bar01_09428cb3:

    c "Being alone."

translate english ch05_bar01_c6310077:

    c "Having to fall asleep hugging a stuffed animal instead of being held by a mother.."

translate english ch05_bar01_915e283a:

    d "I didn't even have a stuffed ani...."

translate english ch05_bar01_05e4100f:

    c "Even the family that adopted me......"

translate english ch05_bar01_6540c6f6:

    c "You know. My adoptive father wasn't any better than Frank......"

translate english ch05_bar01_1669e236:

    d "I know......"

translate english ch05_bar01_b77ee41a:

    c ".........."

translate english ch05_bar01_7600b60a:

    c "So I guess I just wanted to build a family of my own as soon as I could.."

translate english ch05_bar01_a31549dc:

    c "That's why when I said I was getting married, everyone kept asking why I was rushing it....."

translate english ch05_bar01_a6221a01:

    c "They were worried about the age difference and whether I'd be okay with it...."

translate english ch05_bar01_d14dadbd:

    c "But that wasn't what mattered to me."

translate english ch05_bar01_edbb7d05_1:

    d "........"

translate english ch05_bar01_bc618d6f:

    c "What mattered was hearing him tell me I wasn't alone anymore."

translate english ch05_bar01_ab501061:

    c "That was his proposal, after all..."

translate english ch05_bar01_e0f39d58:

    c "Heh....."

translate english ch05_bar01_ad893dfa_3:

    d "......"

translate english ch05_bar01_e7911727:

    c "Why are you looking at me like that? Haha."

translate english ch05_bar01_755cbe53:

    c "Didn't expect me to say that?"

translate english ch05_bar01_b89728aa:

    c "Surprised to hear me talking about this when I'm newly married?"

translate english ch05_bar01_919f3341:

    d "No..."

translate english ch05_bar01_52db8993:

    d "Just...."

translate english ch05_bar01_fddb9000:

    d "I was listening."

translate english ch05_bar01_72edef5d:

    d "I really had no idea you felt that way.."

translate english ch05_bar01_445fd129:

    c "......"

translate english ch05_bar01_a86dc18e:

    c "I guess even childhood friends have things they've never told each other.."

translate english ch05_bar01_74d97ece:

    c "Phew.........."

translate english ch05_bar01_445fd129_1:

    c "......"

translate english ch05_bar01_ac97b1f4:

    c "But he's a good man. He really is..."

translate english ch05_bar01_f6cdc01b:

    c "He's a really good man."

translate english ch05_bar01_6140126c:

    d "I didn't even say anything, you know?"

translate english ch05_bar01_ddf12d46:

    d "Hmm...."

translate english ch05_bar01_59211928:

    d "Of course he's a good man. He's the guy you chose over me."

translate english ch05_bar01_a7c6da09:

    c "Hey, mister."

translate english ch05_bar01_2900957f:

    c "You've never been a man to me. Not even once."

translate english ch05_bar01_6149e771:

    c "You're still just a little punk..."

translate english ch05_bar01_d34280b9:

    d "Heh..."

translate english ch05_bar01_f66ea9cd:

    n "They spent some much-needed time alone together, enjoying a long conversation."

translate english ch05_bar01_f19854f9:

    n "They talked with the ease and openness of sisters, without any formalities or pretenses..."

translate english ch05_bar01_55c0a17f:

    n "Both [d_name] and Celine were able to let go of their stress by sharing things they could only ever talk about with each other."

translate english ch05_bar01_60f87707:

    n "And their time together stretched on longer than either of them had expected....."

translate english ch05_bar01_d8c80d1f:

    c "Hahaha."

translate english ch05_bar01_58d7f10e:

    c "That's right, that really happened."

translate english ch05_bar01_79212a05:

    c "That was the first time I'd ever seen them like that."

translate english ch05_bar01_e0053892:

    c "I'd never seen the teachers that angry before."

translate english ch05_bar01_c49a123b:

    c "I didn't know Mary could be that scary."

translate english ch05_bar01_01d3690b:

    d "Anyone would've been pissed about that."

translate english ch05_bar01_f25e1305:

    d "Those little brats were trying to set the orphanage on fire because their room was cold, haha."

translate english ch05_bar01_b86b558e:

    c "Hahahahaha."

translate english ch05_bar01_b32d0d89:

    c "How the hell did you even come up with something like that as a kid?"

translate english ch05_bar01_de76f7be:

    c "You're an arsonist. That's what you are."

translate english ch05_bar01_bbbb3f60:

    c "Hahahaha. I remember now."

translate english ch05_bar01_00d529c9:

    c "You got stripped naked and punished for that, remember?"

translate english ch05_bar01_bb920e29:

    d "!!!!!!!"

translate english ch05_bar01_68cf6c13:

    d "I did?"

translate english ch05_bar01_3580c6fe:

    d "Hmm........"

translate english ch05_bar01_e2dbfadd:

    d "Were they even allowed to punish kids like that back then?"

translate english ch05_bar01_82946f36_4:

    c "........"

translate english ch05_bar01_ee9bc989:

    c "We were really just little kids back then...."

translate english ch05_bar01_e30c00eb:

    c "And now..."

translate english ch05_bar01_e488f9b6:

    c "You're a college student, and I'm a married woman...."

translate english ch05_bar01_d707bb82:

    c "Ahem...."

translate english ch05_bar01_a5761c9a:

    c "We've gotten older...."

translate english ch05_bar01_c4a9bc08:

    c "And our bodies have grown, too...."

translate english ch05_bar01_3db9fff4:

    d "Yeah..."

translate english ch05_bar01_28b11bcd:

    d "Time really does fly."

translate english ch05_bar01_6b231948:

    d "I guess I'll be busy trying to find a job soon, too."

translate english ch05_bar01_40294d69:

    mo "You two make a cute couple. Haha."

translate english ch05_bar01_88220464:

    mo "Are you two on a date?"

translate english ch05_bar01_97acf802:

    d "D..date??!!?"

translate english ch05_bar01_1a356732:

    c "What?!!!!"

translate english ch05_bar01_f8bacf5a:

    c "No!!"

translate english ch05_bar01_f9ac7763:

    c "We're childhood friends. Haha."

translate english ch05_bar01_f2dc87fc:

    mo "Oh, I'm really sorry."

translate english ch05_bar01_d2aa406f:

    mo "That was really inappropriate of me."

translate english ch05_bar01_cb25e673:

    c "Oh, it's okay. Haha."

translate english ch05_bar01_b8332af6:

    c "It happens."

translate english ch05_bar01_7bb1189d:

    c "We get all kinds of comments when we're together."

translate english ch05_bar01_4c141582:

    c "People ask if we're siblings, a couple, married, or just friends."

translate english ch05_bar01_f24f3b50:

    mo "Oh, haha."

translate english ch05_bar01_dbd98e48:

    mo "Well, I guess I'm not the worst one."

translate english ch05_bar01_cccb135f:

    mo "I'm usually pretty good at guessing, but I definitely got this one wrong, haha."

translate english ch05_bar01_5423e2df:

    mo "If you need anything, just let me know."

translate english ch05_bar01_38cecea5:

    mo "I'll give it to you on the house to make up for my mistake."

translate english ch05_bar01_dbda7e67:

    c "Thank you. Haha."

translate english ch05_bar01_4282fc33:

    d "**(What I need right now is.....)**"

translate english ch05_bar01_2334d216:

    d "**(Your ass, ma'am.....)**"

translate english ch05_bar01_e5c36b54:

    d "..........."

translate english ch05_bar01_23de2bf5:

    d "Hahahaha."

translate english ch05_bar01_2426edbf:

    d "Just imagining you and me as a couple makes me wanna puke."

translate english ch05_bar01_45acde4c:

    d "Aww, I love you, baby~"

translate english ch05_bar01_f38d1305:

    d "You're all mine tonight~"

translate english ch05_bar01_e5337b18:

    c "Wanna die?!!"

translate english ch05_bar01_58ae487e:

    d "Hahahaha."

translate english ch05_bar01_0b5019e9:

    d "Honestly...."

translate english ch05_bar01_e9f6badd:

    d "I still can't believe you're a married woman now."

translate english ch05_bar01_34cad9b2:

    d "Maybe it's because I didn't get to see the wedding, but it still feels like nothing's changed..."

translate english ch05_bar01_fa395d2b:

    c "............."

translate english ch05_bar01_29fec08c:

    d "You know, when we were kids.."

translate english ch05_bar01_937efc93:

    d "I always assumed I'd marry you someday."

translate english ch05_bar01_360b2105:

    d "You were the only woman in the world as far as I was concerned.."

translate english ch05_bar01_954171b2:

    c "Don't give me that bullshit, you fucking hypocrite."

translate english ch05_bar01_4b78c52a_1:

    d "What?"

translate english ch05_bar01_3329d626:

    d "What the hell are you talking about?"

translate english ch05_bar01_4c2623ac:

    d "Why am I a hypocrite?"

translate english ch05_bar01_f312a129:

    c "How could you do that to me?"

translate english ch05_bar01_e0c3971f:

    c "You fucking pervert."

translate english ch05_bar01_82910222:

    d "What the hell? Where did that come from all of a sudden?"

translate english ch05_bar01_2b7087eb:

    d "Are you drunk?"

translate english ch05_bar01_37bba514:

    d "I'm a pervert?..."

translate english ch05_bar01_8424c5d2:

    d "I was just sitting here drinking orange juice."

translate english ch05_bar01_fa395d2b_1:

    c "............."

translate english ch05_bar01_7f0fbcd6:

    c "Why are men all like this?.."

translate english ch05_bar01_e3e01b8a:

    d "What the hell is that supposed to mean?"

translate english ch05_bar01_f3e25e23:

    d "Stop making me play twenty questions and just tell me."

translate english ch05_bar01_fa395d2b_2:

    c "............."

translate english ch05_bar01_a75b7dfc:

    c "I saw it."

translate english ch05_bar01_4b78c52a_2:

    d "What?"

translate english ch05_bar01_edbb7d05_2:

    d "........"

translate english ch05_bar01_5163d76d:

    d "What do you mean, you saw it?"

translate english ch05_bar01_690f5656:

    c "..........."

translate english ch05_bar01_89cea4ea:

    c "**(Shit..)**"

translate english ch05_bar01_ef5e0221:

    c "**(Is this really the right choice, Celine?)**"

translate english ch05_bar01_fd0c0e62:

    c "**(Should I just pretend I never saw anything and let it go?.....)**"

translate english ch05_bar01_6e56e063:

    n "She picked up her phone and thought for a moment."

translate english ch05_bar01_a7debfa5:

    n "Then, as if she'd made up her mind, she placed her phone on the table."

translate english ch05_bar01_e475a480:

    d "!!!!!!!!!!!!!!"

translate english ch05_bar01_2857fe6b:

    d "How could this possibly........"

translate english ch05_bar01_1eb3882b:

    d "My God......"

translate english ch05_bar01_e958ef68:

    n "[d_name]'s heart pounded as if it were about to burst out of his chest."

translate english ch05_bar01_42e8c443:

    n "There was no excitement at all from Celine having seen him with an erection;"

translate english ch05_bar01_99e53cec:

    n "instead, he was overcome with despair, like a criminal caught red-handed."

translate english ch05_bar01_40edc816:

    c "You........"

translate english ch05_bar01_edbb7d05_3:

    d "........"

translate english ch05_bar01_bfe6c3a7:

    c "Last time, when you were in Mary's office on that rainy day...."

translate english ch05_bar01_a465f8db:

    c "You had that thing out next to Mary then too, didn't you?"

translate english ch05_bar01_4560dd5b:

    d "What?..........."

translate english ch05_bar01_8e445e90:

    d "N-no...."

translate english ch05_bar01_99d3f1af:

    d "W-what are you talking about?"

translate english ch05_bar01_9510b2cd:

    d "**(How the hell did Celine know about that?)**"

translate english ch05_bar01_3d7ca898:

    d "**(Did she see everything I did??!!)**"

translate english ch05_bar01_33dfd5fb:

    d "**(Oh, shit....)**"

translate english ch05_bar01_ab8d41fa:

    d "**(Could I really not hear the door opening over the sound of the rain???)**"

translate english ch05_bar01_07cc5ad1:

    c "............"

translate english ch05_bar01_aeb3cbbc:

    c "You fucking bastard...."

translate english ch05_bar01_445fd129_2:

    c "......"

translate english ch05_bar01_8f220007:

    c "What the hell did you do to Mary?"

translate english ch05_bar01_b77ee41a_1:

    c ".........."

translate english ch05_bar01_3b528533:

    c "Did you sleep with Mary?"

translate english ch05_bar01_c2730bcc:

    d "What??!!"

translate english ch05_bar01_0283af0b:

    d "Absolutely not!! How could I ever do something like that with Mary..."

translate english ch05_bar01_95b65050:

    d "Don't go making crazy accusations like that, Celine."

translate english ch05_bar01_9462bc0c:

    d "Do you have any idea what Mary means to me? There's no way I'd do something like that with her..."

translate english ch05_bar01_82946f36_5:

    c "........"

translate english ch05_bar01_7ae9ae94:

    c "I can't believe a fucking pervert like you was my friend..."

translate english ch05_bar01_97899ee4:

    d "W-what the hell..."

translate english ch05_bar01_c333aed5:

    c "Did you seduce Mary with that big c….penis??!!"

translate english ch05_bar01_fc729291:

    d "What?!!!!!!"

translate english ch05_bar01_03d011b5:

    d "**(Shit, I'm totally caught......)**"

translate english ch05_bar01_c8de7037:

    d "**(Fuck....... )**"

translate english ch05_bar01_35d1f7f6:

    d "**(This is scary....)**"

translate english ch05_bar01_4833a169:

    c "Are you saying you impressed Mary with that big penis?"

translate english ch05_bar01_55253cd8:

    c "What did she say?"

translate english ch05_bar01_cb697400:

    c "Did she say it felt like you filled her up inside?"

translate english ch05_bar01_edbb7d05_4:

    d "........"

translate english ch05_bar01_9a254d4d:

    d "S-sorry, but could you... c-can you back off a little?"

translate english ch05_bar01_66453e62:

    d "You're kind of scaring me right now...."

translate english ch05_bar01_95ed6fd1:

    d "What's this about filling her up...."

translate english ch05_bar01_3a6e89a6:

    d "It's not like that."

translate english ch05_bar01_7ea49de8:

    c "Pervert."

translate english ch05_bar01_20060924:

    c "How many years apart are you two, anyway...?"

translate english ch05_bar01_f0d2b70d:

    d "It's not like that..."

translate english ch05_bar01_fa395d2b_3:

    c "............."

translate english ch05_bar01_9cbf707a:

    c "You always looked like the most well-behaved kid, but somehow you were always the one getting into the biggest trouble."

translate english ch05_bar01_8e7651ce:

    c "When you were little, you were just a dumb kid, and that was kind of cute..."

translate english ch05_bar01_445fd129_3:

    c "......"

translate english ch05_bar01_4a11d334:

    c "But now you're disgusting."

translate english ch05_bar01_1d24fe52:

    d "It's not what you think."

translate english ch05_bar01_77673f80_1:

    d "........."

translate english ch05_bar01_e0043d85:

    d "You've got it completely wrong."

translate english ch05_bar01_8739317a:

    c "Don't say another word."

translate english ch05_bar01_91df4a6f:

    c "If you say one more thing, I'm cutting you out of my life for good."

translate english ch05_bar01_07cc5ad1_1:

    c "............"

translate english ch05_bar01_848c4fb7:

    c "Show me."

translate english ch05_bar01_edbb7d05_5:

    d "........"

translate english ch05_bar01_ac282630:

    d "Sh-show you what?"

translate english ch05_bar01_4038674d:

    c "Don't play innocent."

translate english ch05_bar01_47feb820:

    c "What do you think? Your penis."

translate english ch05_bar01_5a25ab89:

    d "!!!!!!!!!!!!!!!"

translate english ch05_bar01_edbb7d05_6:

    d "........"

translate english ch05_bar01_337eee95:

    d "N-now??"

translate english ch05_bar01_fab6b05a:

    d "H-here?"

translate english ch05_bar01_2790f744:

    c "Yeah."

translate english ch05_bar01_ff8b702e:

    c "I need to see if you really photoshopped it and tried to scam Mary."

translate english ch05_bar01_e0bd5755:

    c "I'm going to find out if you've been messing with Mary!!"

translate english ch05_bar01_edbb7d05_7:

    d "........"

translate english ch05_bar01_7bbd37f7:

    d "I-it wasn't a scam.."

translate english ch05_bar01_38713c50:

    d "It's not photoshopped."

translate english ch05_bar01_203cc60b:

    d "......."

translate english ch05_bar01_3b9969ab:

    d "It's really mine.."

translate english ch05_bar01_7ebacf10:

    c "Ha! Gotcha."

translate english ch05_bar01_ba733415:

    c "You sick bastard!!"

translate english ch05_bar01_db7d4585:

    d "Shit....."

translate english ch05_bar01_09142e8c:

    n "He reached for his zipper in a daze."

translate english ch05_bar01_b365ce39:

    n "Then he unzipped his pants and pulled out his already erect penis."

translate english ch05_bar01_bb99be67:

    c "!!!!!!!!!!!"

translate english ch05_bar01_c30f82da:

    c "What the fuck!!!!!!!!!!"

translate english ch05_bar01_2aafb57e:

    c "Oh my God, [d_name]!!!!!!"

translate english ch05_bar01_b35802cf:

    c "Y-you idiot, why would you actually pull it out!!!!!"

translate english ch05_bar01_e138e6dc:

    d "You told me to pull it out!!"

translate english ch05_bar01_2eaf2869:

    c "Are you fucking crazy??!!!"

translate english ch05_bar01_3be152e2:

    c "What the hell..."

translate english ch05_bar01_09acd5aa:

    c "Oh my God........"

translate english ch05_bar01_154e4fc5_3:

    c "........."

translate english ch05_bar01_fac8215b:

    d "............"

translate english ch05_bar01_df55e80c_1:

    c "......."

translate english ch05_bar01_45c7e4ae:

    n "Celine was stunned when she saw [d_name]'s erect penis."

translate english ch05_bar01_2a1e3bd2:

    n "It was truly an overwhelming experience for her."

translate english ch05_bar01_37922256:

    n "Seeing the penis of [d_name], her childhood friend, was a shock that was difficult to process as a friend."

translate english ch05_bar01_c0537414:

    d "Shit....."

translate english ch05_bar01_26259a43:

    c "Holy......"

translate english ch05_bar01_6236e1df:

    n "The phone rings."

translate english ch05_bar01_5f1dd38d:

    c "**(Shit...)**"

translate english ch05_bar01_2945f1ad:

    c "Hey, honey."

translate english ch05_bar01_82946f36_6:

    c "........"

translate english ch05_bar01_5e144044:

    c "Yeah, I'm at a bar with a friend right now."

translate english ch05_bar01_0f8e330a:

    c "Yeah, that rooftop bar."

translate english ch05_bar01_82946f36_7:

    c "........"

translate english ch05_bar01_a9aa65ab:

    c "Yeah, okay."

translate english ch05_bar01_e5cea060:

    c "See you later, honey."

translate english ch05_bar01_896ab113:

    c "Love you."

translate english ch05_bar01_77673f80_2:

    d "........."

translate english ch05_bar01_f159de96:

    d "Is that your husband?"

translate english ch05_bar01_df55e80c_2:

    c "......."

translate english ch05_bar01_16032c5c:

    c "Yeah."

translate english ch05_bar01_8e714511:

    c "He's coming to pick me up."

translate english ch05_bar01_77673f80_3:

    d "........."

translate english ch05_bar01_7f9f4281:

    c "Oh my God....."

translate english ch05_bar01_27753106:

    c "Now put it away already!!!"

translate english ch05_bar01_852c5feb:

    c "What the hell are you doing, you idiot?"

translate english ch05_bar01_b77ee41a_2:

    c ".........."

translate english ch05_bar01_2a66ce84:

    c "You were so cute when you were little....."

translate english ch05_bar01_926a6bf9:

    c "But this feels like......"

translate english ch05_bar01_0b383da2:

    c "Like you've betrayed me somehow...."

translate english ch05_bar01_4cd15d58:

    d "....."

translate english ch05_bar01_0ab6cffa:

    unknownm "Celine!"

translate english ch05_bar01_4c0bc9dc:

    d "!!"

translate english ch05_bar01_4b320ec8:

    c "Hey, honey."

translate english ch05_bar01_0708e870:

    c "You've permanently changed the way I see Mary."

translate english ch05_bar01_f235288d:

    d "What?!!"

translate english ch05_bar01_4cc71fbc:

    c "Now every time I see Mary, I'm going to think about a picture of your penis."

translate english ch05_bar01_203cc60b_1:

    d "......."

translate english ch05_bar01_7e0f5035:

    c "See you around."

translate english ch05_bar01_2829dfc3:

    c "You better not go flashing that thing around to other married women, or you're going to get yourself into serious trouble."

translate english ch05_bar01_4b0ac84e:

    c "Get your head straight, kid."

translate english ch05_bar01_df28914a:

    c "I don't care how much you love sex, you really want to make enemies out of all their husbands in this tiny town?"

translate english ch05_bar01_b939ad9e:

    c "Find someone your own age. Someone your own age."

translate english ch05_bar01_4c0bc9dc_1:

    d "!!"

translate english ch05_bar01_48746e73:

    unknownm "It's getting pretty late, little kitty."

translate english ch05_bar01_dd5d2de0:

    c "I'm sorry. I didn't get a chance to call you beforehand."

translate english ch05_bar01_b483bab3:

    d "**(Little kitty…....)**"

translate english ch05_bar01_3dd522bf:

    unknownm "Hi."

translate english ch05_bar01_2dc543c5:

    unknownm "I'm Celine's husband, Larry."

translate english ch05_bar01_63fb8674:

    d "N-nice to meet you."

translate english ch05_bar01_64a429c0:

    d "I'm [d_name]."

translate english ch05_bar01_6de27b2d:

    d "We're friends from the same orphanage."

translate english ch05_bar01_e43537d6:

    la "Oh, yes. I know you."

translate english ch05_bar01_545252c4:

    la "She's told me about you."

translate english ch05_bar01_7be3f7d7:

    la "If we get the chance, let's grab a meal together sometime."

translate english ch05_bar01_4130faa4:

    d "Oh... yeah, I'd like that."

translate english ch05_bar01_a569bb24:

    la "Well then, we'll be heading out now."

translate english ch05_bar01_77673f80_4:

    d "........."

translate english ch05_bar01_beac53b0:

    d "**(I don't think Celine got to say what she wanted to.....)**"

translate english ch05_bar01_3ea294b5:

    d "Hmm.........."

translate english ch05_bar01_24f504f0:

    d "My God....."

translate english ch05_bar01_5df7977f:

    d "I can't think straight right now...."

translate english ch05_bar01_a70e084b:

    mo "**(Heh...What interesting kids...)**"

translate english ch05_bar01_21678060:

    mo "**(......)**"

translate english ch05_orph01_d76fab35:

    d "!!!!!!"

translate english ch05_orph01_58917dcd:

    h "**(Shit.....)**"

translate english ch05_orph01_766d0e42:

    d "G-good morning, [h_name]."

translate english ch05_orph01_b919f84b:

    h "Good morning, [d_name]."

translate english ch05_orph01_83261455:

    h "........."

translate english ch05_orph01_d2d6d149:

    h "It's been quite a while since we've seen each other, haha."

translate english ch05_orph01_3e74f747:

    d "Yeah, it has. Haha."

translate english ch05_orph01_ad893dfa:

    d "......"

translate english ch05_orph01_ab447d3d:

    d "Are you feeling any better?"

translate english ch05_orph01_f5c3168a:

    h "Yeah, I'm fine."

translate english ch05_orph01_bd737623:

    h "Thanks to Lena staying with me...."

translate english ch05_orph01_667077a5:

    d "Oh, Lena...."

translate english ch05_orph01_ad893dfa_1:

    d "......"

translate english ch05_orph01_91297245:

    d "I'm glad you're feeling better."

translate english ch05_orph01_ef829db7:

    h "Hah........"

translate english ch05_orph01_35286232:

    h "This is embarrassing..."

translate english ch05_orph01_797ac21c:

    h "After showing you that side of me...."

translate english ch05_orph01_ae721df1:

    h "I can't believe I drank that much at my age....."

translate english ch05_orph01_1569d91e:

    d "Haha, there's nothing to be embarrassed about."

translate english ch05_orph01_4b7c9295:

    d "You have days like that every now and then."

translate english ch05_orph01_d1d7ab32:

    d "Don't worry about it too much."

translate english ch05_orph01_e09c14a4:

    h "Yeah...."

translate english ch05_orph01_d1ab0d17:

    h "Oh, by the way..."

translate english ch05_orph01_2d0089e8:

    h "There's something I wanted to ask you.."

translate english ch05_orph01_8096b08a:

    d "Yes?"

translate english ch05_orph01_f8fe9fa8:

    d "What is it?"

translate english ch05_orph01_8e44d9cb:

    h "........"

translate english ch05_orph01_a855d4a4:

    h "By any chance......"

translate english ch05_orph01_3be44f7d:

    h "The night I came home drunk..."

translate english ch05_orph01_e5c36b54:

    d "..........."

translate english ch05_orph01_a855d4a4_1:

    h "By any chance......"

translate english ch05_orph01_2d81741f:

    h "Did I go into [d_name]'s room?"

translate english ch05_orph01_4bb59dbf:

    d "What??!!"

translate english ch05_orph01_edbb7d05:

    d "........"

translate english ch05_orph01_0ed611c5:

    d "You mean, you went into my room?!!"

translate english ch05_orph01_e5c36b54_1:

    d "..........."

translate english ch05_orph01_50fc2eaa:

    h "Hah..........."

translate english ch05_orph01_f41ccccf:

    h "My memory of that night is pretty hazy....."

translate english ch05_orph01_8e44d9cb_1:

    h "........"

translate english ch05_orph01_2bb57489:

    h "I don't even remember how I ended up in bed....."

translate english ch05_orph01_efb516b7:

    h "And I don't even know when Lena got there..."

translate english ch05_orph01_4338f07b:

    h "..........."

translate english ch05_orph01_6bf2fda2:

    h "I feel like I might have....."

translate english ch05_orph01_af3181c4:

    h "......"

translate english ch05_orph01_3115fb96:

    h "I feel like I might have done something with you…."

translate english ch05_orph01_77673f80:

    d "........."

translate english ch05_orph01_a4b476da:

    d "**(Shit...)**"

translate english ch05_orph01_f82e5932:

    d "**(It looks like she saw something that night??!!)**"

translate english ch05_orph01_e7f23d76:

    d "**(Is she trying to ask me without coming right out and saying it?)**"

translate english ch05_orph01_dff5d164:

    d "**(What if she saw everything I did with Lena??)**"

translate english ch05_orph01_7aada550:

    h "What if....."

translate english ch05_orph01_f8107be5:

    h "I didn't do something to you that night, did I?"

translate english ch05_orph01_8096b08a_1:

    d "Huh?"

translate english ch05_orph01_14d21ab1:

    d "W-what are you talking about?"

translate english ch05_orph01_edbb7d05_1:

    d "........"

translate english ch05_orph01_78294de6:

    d "What do you mean? What did you do to me?..."

translate english ch05_orph01_bff97dba:

    h "**(Damn....)**"

translate english ch05_orph01_6440be4d:

    h "**(Since he's not denying it, something really must have happened. Sigh........)**"

translate english ch05_orph01_822a20bf:

    h "**(Maybe I should just keep my mouth shut?.....)**"

translate english ch05_orph01_6aa498df:

    h "**(Maybe it really was just a dream?)**"

translate english ch05_orph01_66bc178c:

    h "**(I'm dying to know....)**"

translate english ch05_orph01_9b93e592:

    h "Did I give you a blowjob that night?"

translate english ch05_orph01_030ac45a:

    d "!!!!!!!!!!!!!!!!!!!!!"

translate english ch05_orph01_09053909:

    d "What did you just say????!!!"

translate english ch05_orph01_edbb7d05_2:

    d "........"

translate english ch05_orph01_e2ed6d0d:

    d "A-a blowjob??"

translate english ch05_orph01_83261455_1:

    h "........."

translate english ch05_orph01_43496474:

    h "I didn't, right?...."

translate english ch05_orph01_7b10b946:

    h "Right?"

translate english ch05_orph01_9fd376a9:

    h "...."

translate english ch05_orph01_6e0054f3:

    h "It just feels so real......"

translate english ch05_orph01_502b8417:

    h "I remember you grabbing my head and going rough........"

translate english ch05_orph01_5e3aec4e:

    d ".........."

translate english ch05_orph01_9bce6c15:

    d "N-no... That's..."

translate english ch05_orph01_96171efd:

    d "It wasn't [h_name], it was Le..!!!"

translate english ch05_orph01_e9e5c1c9:

    d "N-no, nothing like that happened."

translate english ch05_orph01_f17e13ff:

    h "A-are you sure?"

translate english ch05_orph01_5e3aec4e_1:

    d ".........."

translate english ch05_orph01_21921c86:

    d "I-if something like that had happened..."

translate english strings:
    old "제가 지금 [h_name]을 끌어안고 키스를 하고있지않을까요?"
    new "Wouldn't I be holding [h_name] in my arms and kissing you right now?"

translate english strings:
    old "아.....그런 일은 없었어요."
    new "Ah..... No, nothing like that happened."

translate english ch05_orph01_92f21ed5:

    n "What should I do?"

translate english ch05_orph01_21921c86_1:

    d "I-if something like that had happened..."

translate english ch05_orph01_3b681183:

    d "Wouldn't I be holding [h_name] in my arms and kissing you right now?"

translate english ch05_orph01_ab7428d5:

    d "**(Damn, that was a pretty smooth line.)**"

translate english ch05_orph01_21921c86_2:

    d "I-if something like that had happened..."

translate english ch05_orph01_3fffd860:

    d "Ah..... No, nothing like that happened."

translate english ch05_orph01_203cc60b:

    d "......."

translate english ch05_orph01_64b36e54:

    h "Phew......"

translate english ch05_orph01_d514fc02:

    h "Well, that's a relief...."

translate english ch05_orph01_3a440fbb:

    h "I guess it was all just a dream."

translate english ch05_orph01_06897645:

    h "Hahaha."

translate english ch05_orph01_bebf5d5b:

    h "I'm too old to be acting like this."

translate english ch05_orph01_f1375233:

    h "To have a dream like that..."

translate english ch05_orph01_7d32a70f:

    h "Sorry for saying something so outrageous first thing in the morning, haha."

translate english ch05_orph01_c23c032c:

    h "A blowjob? Oh my God..."

translate english ch05_orph01_9640983c:

    h "Just think of it as me talking nonsense and forget about it, okay?"

translate english ch05_orph01_e78a70f1:

    d "Oh, yeah......"

translate english ch05_orph01_80304bb4:

    d "I will."

translate english ch05_orph01_313de9c9:

    h "We didn't, like, have sex or anything, did we??"

translate english ch05_orph01_21a1e5c8:

    d "What?!!!!!!!"

translate english ch05_orph01_09d79caf:

    d "S-sex?!!!!!!!"

translate english ch05_orph01_3343aac8:

    h "You're not just saying that because you're worried I'll be embarrassed, are you??"

translate english ch05_orph01_874259e9:

    h "Oh, I'm sorry."

translate english ch05_orph01_583ceb40:

    h "I'm being ridiculous."

translate english ch05_orph01_fea4be40:

    h "Just forget I said anything."

translate english ch05_orph01_ef4aff49:

    h "Is today your first day at work?"

translate english ch05_orph01_94ec3afe:

    d "Oh, no, haha."

translate english ch05_orph01_a916df3b:

    d "I don't start until tomorrow. I'm just going to stop by and see Ms. Mary for a bit."

translate english ch05_orph01_e3a17861:

    h "Oh, I see."

translate english ch05_orph01_cd0e0131:

    h "Want me to give you a ride?"

translate english ch05_orph01_9d5f5d41:

    d "No, I'm fine."

translate english ch05_orph01_102124cd:

    d "I'll ride my bike. I could use the exercise anyway."

translate english ch05_orph01_acbcd17f:

    d "A man's gotta keep his legs in shape, haha."

translate english ch05_orph01_ddd96a2d:

    h "**(What the hell was that?...)**"

translate english ch05_orph01_9ca44a6b:

    h "**(Wait, did something really happen??!!)**"

translate english ch05_orph01_a70d556c:

    h "All right, then."

translate english ch05_orph01_152fc637:

    h "Do whatever's comfortable for you."

translate english ch05_orph01_fa7fd1d5:

    h "See you tonight."

translate english ch05_orph01_15734c04:

    d "Yep, got it."

translate english ch05_orph01_f5f24d77:

    d "I'll see you later."

translate english ch05_orph01_7036deb2:

    h "There's definitely something going on between [d_name] and Lena that they're keeping from me...."

translate english ch05_orph01_ef829db7_1:

    h "Sigh........"

translate english ch05_orph01_7caf97d7:

    h "............."

translate english ch05_orph01_caf2cc82:

    h "Ugh... you crazy bitch...."

translate english ch05_orph01_763defbc:

    h "How the hell did this even happen...."

translate english ch05_orph01_8690e783:

    h "What the hell were they even doing......"

translate english ch05_orph01_8e44d9cb_2:

    h "........"

translate english ch05_orph01_2ef3bc9d:

    h "What was that?... Were they about to have sex?..."

translate english ch05_orph01_b5e2243f:

    h "But she's still wearing her panties....."

translate english ch05_orph01_85a2341c:

    h "Sigh......."

translate english ch05_orph01_62fb49f9:

    h "And how the hell did Lena even take this picture.... Sigh..."

translate english ch05_orph01_a01f4f46:

    h ".........."

translate english ch05_orph01_db7e0e28:

    h "This is driving me crazy..."

translate english ch05_orph01_2067e5af:

    h "Are Lena and [d_name] both keeping quiet about it for my sake??"

translate english ch05_orph01_9a898893:

    h "Sigh........... seriously...."

translate english ch05_orph01_07d8b9d5:

    h "Alcohol is the damn culprit... It's always the alcohol...."

translate english ch05_orph01_23ec9819:

    h "How am I ever going to face Ivy after this...."

translate english ch05_orph01_c2d1d563:

    n "[d_name] came to the orphanage to see Mary."

translate english ch05_orph01_de052594:

    n "But after his conversation with Celine yesterday, he started having a hard time seeing Mary."

translate english ch05_orph01_19882675:

    n "Even a normal meeting with Mary now meant avoiding Celine's eyes."

translate english ch05_orph01_edbb7d05_3:

    d "........"

translate english ch05_orph01_2077753e:

    d "**(There's no way Celine isn't here.....)**"

translate english ch05_orph01_8d279454:

    d "**(What the fuck, Celine..)**"

translate english ch05_orph01_fd428def:

    d "**(Does she think this place is some kind of club?)**"

translate english ch05_orph01_2a44e654:

    d "**(What the hell's gotten into her since yesterday?..)**"

translate english ch05_orph01_3be8e062:

    d "**(My God.....)**"

translate english ch05_orph01_2773d33a:

    d "**(Her ass is practically hanging out.)**"

translate english ch05_orph01_7cdbd1f8:

    d "**(Mary's going to lose her shit if she sees this.)**"

translate english ch05_orph01_24fb40db:

    d "**(She's going to kick her out if she keeps dressing like that..)**"

translate english ch05_orph01_4b910584:

    d "**(Holy shit!!)**"

translate english ch05_orph01_2490b6bb:

    d "**(........)**"

translate english ch05_orph01_5db59cf7:

    eve "What's that guy doing?"

translate english ch05_orph01_e412a17f:

    eve "......"

translate english ch05_orph01_8357d9f1:

    eve "Why is he acting like that?"

translate english ch05_orph01_379da592:

    eve "Is he spying on Celine?"

translate english ch05_orph01_e412a17f_1:

    eve "......"

translate english ch05_orph01_c7255cbf:

    eve "Is that a flower?"

translate english ch05_orph01_25dd4dee:

    eve "Holy shit......"

translate english ch05_orph01_cecbb84c:

    eve "No way. Is that guy trying to confess his feelings to Celine??!!!"

translate english ch05_orph01_5e29b52f:

    eve "........"

translate english ch05_orph01_75efb1b4:

    eve "Is he a thief?"

translate english ch05_orph01_5e29b52f_1:

    eve "........"

translate english ch05_orph01_170b3f39:

    eve "!!!!!!!!!!!!!"

translate english ch05_orph01_19d1c234:

    eve "Oh my God!!"

translate english ch05_orph01_9563c129:

    eve "What do I do?"

translate english ch05_orph01_97b69bc7:

    eve "Should I call the police??!!"

translate english ch05_orph01_41bd1827:

    eve "How did he even know that door was there??"

translate english ch05_orph01_dbce21a9:

    d "Damn it."

translate english ch05_orph01_40e4b46b:

    d "Sneaking into a place that's practically my own home...."

translate english ch05_orph01_864c9ead:

    d "There must be a thief somewhere in the family tree…"

translate english ch05_orph01_448e4dcc:

    d "Sigh.... Do I have to watch Celine's reaction every time I come here now?.."

translate english ch05_orph01_02d13543:

    d "Damn it.."

translate english ch05_orph01_6d34e791:

    d "Where's Mary?"

translate english ch05_orph01_91e7c67c:

    d "The lights are on, so I guess she's at work...."

translate english ch05_orph01_8e6f2fb4:

    d "Shit, my heart's pounding for no reason because I'm worried Celine's gonna catch me.."

translate english ch05_orph01_7d7a3cae:

    d "!!!!!!!!"

translate english ch05_orph01_71b75a09:

    d "**(Shit!!)**"

translate english ch05_orph01_0581c572:

    d "**(That was fucking close....)**"

translate english ch05_orph01_a8cf659b:

    d "Cough!!"

translate english ch05_orph01_541dbcfd:

    m "!!!!!!!!"

translate english ch05_orph01_360bd280:

    m "**(What the hell? Why is there a man's voice??)**"

translate english ch05_orph01_9e81208c:

    m "!!!!!!!!!"

translate english ch05_orph01_64e4c6c4:

    m "**(What the hell is this guy doing?!!!!)**"

translate english ch05_orph01_6341ae68:

    m "**(Is he some kind of pervert???)**"

translate english ch05_orph01_ac6caae4:

    d "Shit!!!"

translate english ch05_orph01_4be5bbef:

    d "What the hell is that woman doing here? Is she an employee?!!"

translate english ch05_orph01_8c6e4a2b:

    d "She's really walking around all over the place!!!"

translate english ch05_orph01_8fccc288:

    n "[d_name] opened the bathroom door that was already ajar, hoping to get out of sight."

translate english ch05_orph01_8320fce2:

    n "But there was a woman in the stall, and he immediately realized he was fucked."

translate english ch05_orph01_03144ff5:

    n "Then he caught sight of her silhouette and hair and realized it was Mary."

translate english ch05_orph01_a81e51c2:

    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

translate english ch05_orph01_bf5d9cbe:

    m "[d_name]!!!!!!"

translate english ch05_orph01_d96ff8ff:

    m "What..... are you doing right now..."

translate english ch05_orph01_88616f0c:

    eve "I thought I heard something..."

translate english ch05_orph01_e83190f2:

    eve "Maybe not...."

translate english ch05_orph01_6c052d01:

    m "..............."

translate english ch05_orph01_edbb7d05_4:

    d "........"

translate english ch05_orph01_f5dc2e15:

    n "The two of them had things they wanted to say to each other, but neither could say a word."

translate english ch05_orph01_ba070cc2:

    n "They could only stare at each other."

translate english ch05_orph01_fac8215b:

    d "............"

translate english ch05_orph01_5aebff17:

    m ".........."

translate english ch05_orph01_dd85fe09:

    m "What are you doing?.."

translate english ch05_orph01_5e3aec4e_2:

    d ".........."

translate english ch05_orph01_193dfa5f:

    d "**(I love you, Mary.)**"

translate english ch05_orph01_8aac3847:

    m "**(!!!!)**"

translate english ch05_orph01_2ed03d0e:

    m "**(What's with the rose.....)**"

translate english ch05_orph01_8def10bf:

    m "**(What is he doing????)**"

translate english ch05_orph01_e9310241:

    d "**(I love you, Mary.....)**"

translate english ch05_orph01_b1b0bcf1:

    d "**(Mary's petals haven't fallen yet.)**"

translate english ch05_orph01_c853ade2:

    d "**(Mary is like a single rose.)**"

translate english ch05_orph01_97b99cf8:

    n "Mary was too overwhelmed by the situation to react properly."

translate english ch05_orph01_a247ebd8:

    n "She was so confused that she'd forgotten she was completely naked from the waist down."

translate english strings:
    old "그녀에게 키스한다."
    new "Kiss her."

translate english ch05_orph01_92f21ed5_1:

    n "What should I do?"

translate english ch05_orph01_9dcaf3e7:

    m "Mmph!!!!!!!"

translate english ch05_orph01_f113446c:

    n "Their tongues met."

translate english ch05_orph01_e5476317:

    n "They continued kissing, doing their best not to make a sound."

translate english ch05_orph01_911ee614:

    n "Mary no longer resisted his tongue."

translate english ch05_orph01_95771357:

    eve "Mmmh....."

translate english ch05_orph01_04b33f4f:

    eve "Have I gained a little weight?...."

translate english ch05_orph01_8a9ce39a:

    eve ".........."

translate english ch05_orph01_3e380359:

    eve "Hmm......"

translate english ch05_orph01_aad9bebe:

    eve "Have my breasts gotten a little bigger??"

translate english ch05_orph01_c43ca0cc:

    m "!!!!!!!!!!!"

translate english ch05_orph01_acd88737:

    m "Hey!!"

translate english ch05_orph01_c43ca0cc_1:

    m "!!!!!!!!!!!"

translate english ch05_orph01_5883a429:

    m "Ugh!!!!!!"

translate english ch05_orph01_5b3fbdb7:

    m "**(!!!!!!!!!!!)**"

translate english ch05_orph01_d58e4db4:

    m "Ghk...."

translate english ch05_orph01_21e64b10:

    eve "Huh?"

translate english ch05_orph01_47a05c97:

    m "Ghk......."

translate english ch05_orph01_7b7440ad:

    eve "!!!!!!"

translate english ch05_orph01_b7695aed:

    eve "Who's there? Are you okay?..."

translate english ch05_orph01_3b763749:

    eve "......."

translate english ch05_orph01_47a05c97_1:

    m "Ghk......."

translate english ch05_orph01_2c03061c:

    eve "Are you throwing up??"

translate english ch05_orph01_0359b73b:

    eve "Is something wrong?"

translate english ch05_orph01_6028f799:

    eve "........."

translate english ch05_orph01_4a2deebf:

    eve "!!!"

translate english ch05_orph01_7b7440ad_1:

    eve "!!!!!!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
