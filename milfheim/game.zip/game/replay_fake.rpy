
label v01_mcmary_phone_fake:
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Shortly after midnight" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night02.mp3"
    scene 01lecture_389 with Dissolve(2.0)
    pause
    scene 01lecture_390 with Dissolve(2.0)
    pause
    scene 01lecture_391 with dissolve
    pause
    scene 01lecture_392 at hand_camera with Dissolve(0.8)
    pause
    scene 01lecture_393 at hand_camera with Dissolve(0.8)
    n "그녀는 자정이 다 된 시각까지도 잠에 들 수 없었다."
    n "그녀의 머릿속엔 두근거림,흥분,부끄러움,갈증 등 많은 감정들이 뒤섞여 있었다."
    scene 01lecture_236-01 with Dissolve(2.0)
    pause
    play sound "audio/ambi/phonetext.mp3"
    scene 01lecture_236-02 at hand_camera with dissolve
    pause
    scene 01lecture_236-03 at hand_camera with dissolve
    pause
    scene 01lecture_236-04 at hand_camera with Dissolve(0.8)
    pause
    d "......................"
    d "Damn..."
    d "What should I reply..."
    d "Why is she asking for a photo at this hour?"
    d "Hmm....."
    scene 01lecture_236-06 at hand_camera with Dissolve(0.8)
    d "Damn, I can’t get what she said earlier today out of my head."
    d "This is driving me crazy."
    scene 01lecture_236-10 at hand_camera with Dissolve(0.8)
    d "............."
    d "She said she imagined sucking my cock..."
    d "........."
    d "What would her reaction be if I showed her mine?"
    d "Would she think I'm a pervert?"
    d "She clearly said she fantasizes too. It's just a picture, what's the big deal?"
    d "........................."
    scene 01lecture_236-11 at hand_camera with Dissolve(0.8)
    d "Damn it... Whatever happens, happens."
    d "Mary's an adult and so am I..."
    scene 01lecture_236-12 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/camera.mp3"
    d "Are you really going to do this?"
    play voice_f "audio/voices/fshock01.mp3"
    play music "audio/bgm/erotic03.mp3"
    scene 01lecture_398 at hand_camera with Dissolve(0.8)
    n "그녀는 [d_name]이 전송한 사진을 보고 충격에 빠졌다."
    n "첫 번째 충격은 그녀가 젊은 시절 보았던 포르노에서나 보던 모양이었고,"
    n "두 번째 충격은 이 것이 [d_name]의 것일지 모른다는 생각 때문이었다."
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    m "What the hell is this?!"
    m "What the hell is he doing?"
    scene 01lecture_236-09 at hand_camera with Dissolve(0.8)
    d "You crazy shit. What the hell are you doing?"
    d "Are you trying to end things with Mary today?"
    d "............................."
    d "Oh my god. The damage is already done."
    d "I want to do it again."
    scene 01lecture_236-13 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/camera.mp3"
    d "Again...."
    play voice_f "audio/voices/fshock01.mp3"
    scene 01lecture_399 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    n "두 번째 사진은 그녀에게 처음 보다 더 큰 충격으로 다가왔다."
    n "그 사진의 구도는 [d_name]의 고추와 그의 얼굴이 동시에 담겨있어 보다 더 적나라했다."
    n "시각적 임팩트는 그녀가 그녀의 이성의 끈을 간신히 잡고있게 만들 정도였다."
    m "Oh my god [d_name]!!"
    m "Again?"
    play music "audio/bgm/night02.mp3"
    scene 01lecture_236-09 at hand_camera with dissolve
    pause
    scene 01lecture_236-10 at hand_camera with dissolve
    pause
    d "What the hell did I do?"
    d "This is like exhibitionism."
    scene 01lecture_398 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_400 at hand_camera with Dissolve(2.0)
    m "Oh my god [d_name]."
    n "사진들의 충격은 실로 엄청났다."
    n "그녀는 자신의 보지가 움찔거리고 젖어오는 것을 느꼈다."
    m "............"
    m "You've really bulked up."
    scene 01lecture_399 at hand_camera with Dissolve(2.0)
    m "Oh my god.."
    scene 01lecture_401 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_403 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_405 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_406 at hand_camera with Dissolve(2.0)
    n "그녀는 침대에 걸터 앉아 충격을 덜어내려 얼굴을 문질렀다."
    m "Oh my god oh my god oh my god..."
    m "What the hell is going on."
    scene 01lecture_407 at hand_camera with Dissolve(2.0)
    m "Oh no."
    scene 01lecture_408 at hand_camera with Dissolve(2.0)
    m "What the hell is going on here?"
    scene 01lecture_409 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_410 at hand_camera with Dissolve(2.0)
    pause
    scene 01lecture_411 at hand_camera with Dissolve(2.0)
    m "(Damn you, [d_name].)"
    m "(What did you do to me?)"
    scene 01lecture_412 at hand_camera with Dissolve(2.0)
    m "(Was there a true nature hidden behind that innocent face?)"
    scene 01lecture_413 at hand_camera with Dissolve(2.0)
    m "(Oh my god.)"
    m "(Did my words today give him confidence?)"
    scene 01lecture_414 at hand_camera with Dissolve(2.0)
    n "그녀는 다시 폰을 들고 그의 자지 사진을 들여다 보았다."
    n "이번엔 그것의 모양과 색깔, 힘줄 등을 더 자세히 관찰했다."
    n "그리고 자신의 허벅지 안쪽으로 무엇인가 흐르는것을 느꼈다."
    m "Oh my god, oh my god, oh my god..."
    m "............................"
    m "What am I supposed to do..."
    if in_replay:
        return


label ch02_cafe02_fake:
    if not in_replay:
        $ persistent.unlock_ch02_cafe02_fake = True
    play music "audio/bgm/normal05.mp3"
    scene ch02_cafe01_29 with Dissolve(2.0)
    pause       
    scene ch02_cafe01_30 at hand_camera with Dissolve(0.8)
    o "무슨 얘기들을 그렇게 재미있게 하는거야? 헤헤."
    o "나도 좀 이야기에 끼워줘."
    scene ch02_cafe02_01 at hand_camera with Dissolve(0.8)
    a "있잖아 대학교 신입생과 하는 대화 뻔하지 않겠어?"
    a "이 꼬마녀석의 러브 스토리야. 클래식이지 클래식 하하."
    scene ch02_cafe02_02 at hand_camera with Dissolve(0.8)
    o "오! 그건 내 전공이잖아."
    o "사랑스러운 우리 [d_name]에게 어떤 연애 문제가 있을까?"
    scene ch02_cafe02_03 with Dissolve(1.5)
    o "설마 나에게 말하기 부끄러운 이야기 일까나? 헤헤."
    scene ch02_cafe02_04 with dissolve
    pause  
    scene ch02_cafe02_05 at hand_camera with Dissolve(0.8)
    d "(맙소사..)"
    d "(그녀 가슴이 이렇게 컸었나?)"
    d "(..............)"
    d "(아만다와 막상막하야..)"
    scene ch02_cafe02_04 at hand_camera with Dissolve(0.8)
    o "(후훗.)"
    scene ch02_cafe02_07 at hand_camera with Dissolve(0.8)
    o "([d_name]이 녀석 이제는 과감하게 쳐다 보네.)"
    o "(포커페이스도 못하고 저렇게 얼빵하게 쳐다보니 여자들이 싫어하지.)"
    o "(좋아. 이젠 너도 성인이라 이거지?)"
    n "그녀는 [d_name]을 1년 만에 봤을 때 그가 더 어른스러워 졌다고 느꼈다."
    n "그리고 그와 포옹했을 때 그의 몸이 더 단단해지고 커졌다는 것을 느꼈다."
    n "말인 즉슨, 이젠 자신의 양심의 가책을 내려놓고 더 편하게 [d_name]과 대화할 수 있다는 뜻이었다."
    scene ch02_cafe02_08 at hand_camera with Dissolve(0.8)
    o "(그럼 어른의 대화를 해야지. 뭐야 이게 간지럽게 빙빙 돌려서들 말하고 말이야.)"
    o "(아만다는 대체 언제까지 [d_name]을 애 취급할거지?)"
    o "(재미 없는 인간들 같으니.)"
    scene ch02_cafe02_08-02 at hand_camera with Dissolve(0.8)
    o "(흠.....)"
    o "(무슨 꿍꿍이니 아만다?)"
    o "(설마 그가 영원히 너만의 [d_name]으로 남길 바라는거야?)"
    o "(그가 여자를 만나서 너의 곁을 떠나는게 두려운거니?)"
    scene ch02_cafe02_09 at hand_camera with Dissolve(0.8)
    o "무슨 일인데 그래? 나한테는 얘기 안할거야?"
    scene ch02_cafe02_10 at hand_camera with Dissolve(0.8)
    a "아 별거 아냐."
    a "그는 집에 오기 얼마전에 여자친구와 헤어졌데."
    a "그래서 같이 그년 욕을 해주고 있었어."
    scene ch02_cafe02_11 at hand_camera with Dissolve(0.8)
    o "하하하 언니. 너무 [d_name]편만 드는거 아니야?"
    o "그건 여자쪽 이야기도 들어봐야 한다고."
    scene ch02_cafe02_12 at hand_camera with Dissolve(0.8)
    o "우리 왕자님이 그 여자애를 잘못 다뤘을수도 있잖아."
    o "애처롭다고 마냥 편들어주면 오히려 역효과 생긴다고."
    scene ch02_cafe02_13 at hand_camera with Dissolve(0.8)
    a "그년이 헤어지고 일주일만에 딴 놈을 만났데."
    a "어쩌면 그럴 수 있니? 말세야 말세."
    scene ch02_cafe02_14 at hand_camera with Dissolve(0.8)
    o "맙소사 아만다."
    o "요즘 시대에 일주일이면 오히려 정숙한 여자라고."
    o "양다리 걸치는 사람들이 수두룩 한데 헤어지고 딴 놈 만난걸 어떻게 원망하겠어."
    o "안그래?"
    o "[d_name]도 이 여자 저 여자 만나고 다녀야 점점 능숙해 질거라고."
    o "전혀 나쁜게 아냐."
    scene ch02_cafe02_15 at hand_camera with Dissolve(0.8)
    a "하 그래?! 우리 둘을 부디 너의 세상에 포함하지 말아줘."
    a "우리 [d_name]은 요즘 시대에 보기 드문 순정남이라고."
    a "로미오와 줄리엣 처럼 한 여자를 만나서 역사에 남을 커플이 될거야."
    scene ch02_cafe02_16 at hand_camera with Dissolve(0.8)
    n "올리비아는 순간 아만다에게 고마웠다."
    n "자신이 비튼 대화의 방향으로 잘 따라와 줬고 자신이 결정적인 말을 날릴 수 있는 판을 깔아주었기 때문이다."
    scene ch02_cafe02_16-02 at hand_camera with Dissolve(0.8)
    o "로미오와 줄리엣? 하....지금이 무슨 중세시대니?"
    o "안타깝다 정말."
    o "니가 나와 같이 살았으면 지금 모든 여대생들을 다 따먹고 다녔을텐데 하하하."
    scene ch02_cafe02_16-04 at hand_camera with Dissolve(0.8)
    d "(......)"
    scene ch02_cafe02_16-03 at hand_camera with Dissolve(0.8)
    o "(물론 나도 따먹고 말이지.헤헤.)"
    o "(매일 매일 욱신거릴 정도로.)"
    o "(중년 여성만이 줄 수 있는 즐거움을 제대로 알려줄수 있는데..)"
    scene ch02_cafe02_17 at hand_camera with Dissolve(0.8)
    a "뭐?! 맙소사 올리비아. 지금 무슨 말을 하는거야?"
    a "대학교가 연애하러 가는 곳인줄 아니?"
    a "1년만에 [d_name]을 만났는데 할 말이 그런거 밖에 없니?"
    scene ch02_cafe02_18 at hand_camera with Dissolve(0.8)
    a "맙소사. 이러니까 내가 널 멀리하는거야."
    a "난 너 처럼 머리에 섹스만 가득찬 사람들이 제일 싫어."
    scene ch02_cafe02_19 at hand_camera with Dissolve(0.8)
    play sound "audio/voices/flaugh04.mp3"
    o "하하하 언니. 나를 그렇게 평가 하지마."
    o "난 그저 솔찍하게 말할 뿐이야."
    o "(그리고 나못지않게 너의 머리속에도 섹스로 가득차있잖아.)"
    o "[d_name]이 더 매력적인 남자가 되길 바라는 마음에서 한 말이라고."
    o "어린 여자부터 중년 여성들까지 모두에게 사랑 받는 남자 얼마나 좋아 안그래?"
    o "(언니에게도 나쁠거 없을텐데?)"
    scene ch02_cafe02_20 at hand_camera with Dissolve(0.8)
    o "헤이 [d_name]."
    o "재미없는 아만다 말고 나랑 데이트나 하러가자."
    o "오늘만 내 귀여운 남자친구가 되주는거 어때?"
    scene ch02_cafe02_20-02 at hand_camera with Dissolve(0.8)
    n "그는 약간 혼란스러웠다."
    n "그녀를 종종 보긴 했지만 그녀가 이런 캐릭터를 가진 여성인줄 모르고 있었다."
    n "그리고 그 순간 그녀가 친 거미줄에 완전히 걸려들었다."
    scene ch02_cafe02_21 at hand_camera with Dissolve(0.8)
    a "오 그래? 데미안도 웃기만 하는거 보니까 둘이 아주 죽이 잘 맞네."
    a "그러다 신혼여행 가겠다?"
    scene ch02_cafe02_22 at hand_camera with Dissolve(0.8)
    a "잘들 해봐. 난 화장실 다녀온다."
    a "오! 그리고 2세 이름은 뭘로 할건지 정하면 알려줘."
    o "(하하. 저봐.)"
    o "(니 마음속 깊은 곳에 숨어있는 본성이 꿈틀거리기 시작하지?)"
    o "(그런걸 숨기고 사니까 늙는거라고.)"
    scene ch02_cafe02_23 at hand_camera with Dissolve(0.8)
    a "(저 쌍년 저거 버릇 어디 안가네.)"
    a "(어떻게 쟤는 나이를 먹어도 변하질 않네.)"
    a "(남자 자지라면 자다가도 벌떡벌떡 일어나는 년!)"
    a "(하! 니가 이 언니에게 도전한다 이거니?)"
    scene ch02_cafe02_24 at hand_camera with Dissolve(0.8)
    o "후후후."
    o "잘 생각해봐 [d_name]."
    o "프랭크 때문에 집에 가지도 못하는데 방학 동안 내 집에서 지내는거 어때?"
    o "프랭크 처럼 못살게 구는 사람도 없고."
    o "내 집에선 아무 규칙 없이 자유롭게 지낼 수 있어. 헤헤."
    o "늦게 자도, 밤새 게임해도 아무도 뭐라 안해."
    pause
    o "난 속옷도 안입고 다닌다고 헤헤헤."
    d "(!!!!!!!!!!!!)"
    scene ch02_cafe02_24-02 at hand_camera with Dissolve(0.8)
    o "너도 알잖아. 나 지금 남편하고 별거하고 있어."
    play sound "audio/voices/Fsigh01.mp3"
    o "나 요즘 너무 외로워..."
    scene ch02_cafe02_24-03 at hand_camera with Dissolve(0.8)
    o "잠깐만...."
    o "내가 사는 집 사진을 보여줄게."
    pause
    o "아 찾았다!"
    scene ch02_cafe02_24-03-02 at hand_camera with Dissolve(0.8)
    o "자 봐. 내 집은 이렇게 싱그러운 햇빛이 든다고."
    o "칙칙한 아만다네 동네 말고 방학 동안 나랑 지내자 헤헤."


    $ phone_start()
    show screen phone_ui
    $ switch_channel_view("olivia_dm")

    $ send_phone_message("Olivia", "images/phone/media/ch02_olivia01.jpg", "olivia_dm", 2, summary_alt="olivia Photo", do_pause=False)
    $ npc_type_and_send("Olivia", "어때? 당장 내 집으로 오고 싶지 않아?(하트이모지)", "olivia_dm", typing_time=3)
    pause
    o "당장 짐싸들고 오고싶지 않아?"
    o "어떻게 생각해?"







    hide screen phone_ui
    scene ch02_cafe02_24-04 with dissolve
    pause
    scene ch02_cafe02_20-02 at hand_camera with Dissolve(0.8)
    d "이건 정말이지....."
    d "제가 본 것 중에 가장 아름다워요.."
    scene ch02_cafe02_24-05 at hand_camera with Dissolve(0.8)
    o "뭐가 아름답다는 거야?"
    play sound "audio/voices/flaugh04.mp3"
    o "내 주방이? 하하하."
    o "이 꼬마 녀석 생각보다 능글 맞네."
    scene ch02_cafe02_25 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_26 at hand_camera with Dissolve(0.8)
    o ".............."
    scene ch02_cafe02_27 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_28 at hand_camera with Dissolve(0.8)
    o "아 그거 기계가 지금 좀 이상해."
    scene ch02_cafe02_29 at hand_camera with Dissolve(0.8)
    o "지금 되다 안되다 그러네."
    o "이제 금방 될거야."
    o "컵 올리고 레버를 내려봐."
    scene ch02_cafe02_30 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    d "(웟더뻑!)"
    n "순간 그의 시야에 들어온 것은.."
    scene ch02_cafe02_30-02 at hand_camera with Dissolve(0.8)
    n "그가 아침에 일어나 잠에 들 때 까지 원하는 바로 그것이었다."
    scene ch02_cafe02_31 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_cafe02_31-02 at hand_camera_zoom with vpunch
    play music "audio/bgm/erotic02.mp3"
    d "(웟 더 퍽!)"
    scene ch02_cafe02_31-03 at hand_camera with Dissolve(0.8)
    d "(맙소사 올리!!)"
    scene ch02_cafe02_31-04 at hand_camera with Dissolve(0.8)
    play sound "audio/voices/flaugh03.wav"
    o "(니가 지금 무슨 생각하는지 다 느껴져.)"
    o "(순진한 녀석.)"
    scene ch02_cafe02_32 at hand_camera with Dissolve(0.8)
    a "후후."
    scene ch02_cafe02_33 at hand_camera with Dissolve(0.8)
    a "그래서 [d_name]을 꼬시는데 성공한거야?"
    scene ch02_cafe02_34 at hand_camera with Dissolve(0.8)
    a "!!!!!!!!!!!!!!!!!!!!!!!!"
    scene ch02_cafe02_35 at hand_camera with Dissolve(0.8)
    a "(뭐야 저 미친년!!!!!!!)"
    a "(저 미친년 저거 일부러 저러는거야!!)"
    scene ch02_cafe02_35-02 with dissolve
    pause
    scene ch02_cafe02_36 at hand_camera with Dissolve(0.8)
    a "(이 걸레 같은 년!!)"
    a "(감히 누구에게 이 더러운 엉덩이를 들이대는거야!!!!!)"
    scene ch02_cafe02_30 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_37 with dissolve
    a "(썅년!)"
    scene ch02_cafe02_37-02 with vpunch
    play sound "audio/ambi/slap01.mp3"
    pause
    scene ch02_cafe02_38
    play sound "audio/voices/fhurt07.mp3"
    o "허?!!!!!!!!!!"
    n "순간 올리비아는 깜짝 놀랐다."
    n "자신의 엉덩이를 때린것이 [d_name]이라고 생각했기 때문이다."
    n "아주 짧은 순간이었지만 그녀는 설명하기 힘든 흥분을 느꼈다."
    o "(뭐야 이거?)"
    scene ch02_cafe02_39 at hand_camera with Dissolve(0.8)
    a "................."
    a "너 지금 나랑 해보자는거야?"
    scene ch02_cafe02_39-02 at hand_camera with Dissolve(0.8)
    o "(젠장!!)"
    o "(어쩐지 여자손 같더라..)"
    o "(저 바보 녀석이 이렇게 과감할리가 없지.)"
    scene ch02_cafe02_40 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/normal05.mp3"
    a "배부르게 먹었니 허니?"
    a "그럼 어서 집으로 가자."
    scene ch02_cafe02_41 at hand_camera with Dissolve(0.8)
    d "아야."
    d "아... 알겠어요."
    scene ch02_cafe02_42 with Dissolve(2.0)
    pause
    scene ch02_cafe02_43 at hand_camera with Dissolve(0.8)
    o "언니 가슴은 참 부드러워."
    o "[d_name]도 언니 가슴이 얼마나 부드러운지 알지?"
    o "저 녀석에게 빨리 여자의 즐거움을 알려줘. 안그럼 내가 쟤 꼬셔서 가져가버린다."
    scene ch02_cafe02_44 at hand_camera with Dissolve(0.8)
    a "너 이년아."
    a "왜 문을 활짝 열고 정글의 동굴까지 보여주지 그랬냐?"
    a "얼마든지 [d_name]을 꼬셔봐."
    a "머리에 자지만 가득찬 이 더러운 년!"
    scene ch02_cafe02_44-02 at hand_camera with Dissolve(0.8)
    o "후후후."
    o "그럼 공식적으로 너에게 허락을 받은거네? 하하하."
    o "저 녀석은 이제 죽을때 까지 내 엉덩이 생각 뿐일걸?"
    scene ch02_cafe02_44 at hand_camera with Dissolve(0.8)
    a "오 그래?"
    a "오늘이 지나면 그의 머릿속에서 너의 엉덩이 따위는 흔적도 없이 사라질거야."
    o "헤헤. 두고보면 알겠지."
    scene ch02_cafe02_45 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_46 at hand_camera with Dissolve(0.8)
    n "올리비아는 모든 힘을 다해 [d_name]과 몸을 밀착 시켰다."
    n "아까 처음 만났을때와 다르게 [d_name]도 몸을 밀착시키는 것을 보고 그도 자신을 원한다는 것을 느꼈다."
    pause
    scene ch02_cafe02_47 at hand_camera with Dissolve(0.8)
    o "허니."
    o "다음 번엔 우리 둘만 만나자 알겠지?"
    o "저 늙은 아줌마는 프랭크랑 놀라고 하고 우리끼리 데이트하자고."
    scene ch02_cafe02_48 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch02_cafe02_49 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_47 at hand_camera with Dissolve(0.8)
    o "허니."
    o "여자는 행동하는 남자를 좋아해."
    o "더 자신있게 행동하라고 언제든지."
    o "여자가 할 수 있는게 싸대기 밖에 더 있겠어?"
    scene ch02_cafe02_49-02 with dissolve
    o "..............."
    scene ch02_cafe02_49-03 with dissolve
    pause
    scene ch02_cafe02_47 with dissolve
    o "키스미"
    d "알겠어요."
    scene ch02_cafe02_49-04 at hand_camera with Dissolve(2.0)
    play sound "audio/sex/kissshort03.mp3"
    pause
    scene ch02_cafe02_47 with Dissolve(1.0)
    o "바보야."
    o "입벌려 봐."
    scene ch02_cafe02_49-05 with dissolve
    pause
    scene ch02_cafe02_49-02 with dissolve
    scene ch02_cafe02_49-06 with dissolve
    pause
    scene ch02_cafe02_49-07 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    d "!!!!!!!!!!!!!!!!!!!!!!!!!"
    scene ch02_cafe02_49-08 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    pause
    scene ch02_cafe02_49-09 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_49-10 at hand_camera with Dissolve(0.8)
    pause
    scene ch02_cafe02_49-11 at hand_camera with Dissolve(2.0)
    pause
    scene ch02_cafe02_49-02 with dissolve
    o "..............."
    scene ch02_cafe02_47 with dissolve
    pause
    scene ch02_cafe02_50 with dissolve
    o "다음에 볼땐 더 확신에 찬 진짜 남자가 돼 있길 바래. 꼬맹아."
    o "메세지 보내. 알았지?"
    scene ch02_cafe02_51 at hand_camera with Dissolve(0.8)
    a "컴온 허니."
    a "어두워 지려고 한다. 어서 가자."
    scene ch02_cafe02_52 at hand_camera with Dissolve(2.0)
    pause
    play music "audio/bgm/normal11.mp3"
    scene ch02_cafe02_53 at hand_camera with Dissolve(2.0)
    a "..........................."
    scene ch02_cafe02_54 at hand_camera with Dissolve(0.8)
    d "............."
    d "하하 왜 그렇게 쳐다봐요?"
    scene ch02_cafe02_55 at hand_camera with Dissolve(0.8)
    a "너 이 녀석."
    a "올리의 엉덩이 잘 감상 했어?"
    a "아주 넋놓고 쳐다보더만."
    a "그렇게 됐으면 니가 뭔가 조치를 했어야지!"
    scene ch02_cafe02_56 at hand_camera with Dissolve(0.8)
    d "뭐?!"
    d "아니에요. 나도 그냥 몸이 얼었던거에요."
    d "그리고 제가 그 상황에서 스커트를 내리려면 그녀의 엉덩이에 손이 닿을수 밖에 없는걸요?"
    d "잘못하면 제가 변태로 몰린다구요."
    scene ch02_cafe02_57 at hand_camera with Dissolve(0.8)
    a "하! 퍽이나!"
    a "그년은 니가 가까이 오면 오히려 엉덩이를 너에게 내밀었을걸?!!!"
    a "무슨 말인지 알아?!!"
    a "그녀의 엉덩이를 너의 자.....!!"
    a "......."
    a "아무튼 그 더러운 년!"
    scene ch02_cafe02_58 at hand_camera with Dissolve(0.8)
    a "이리와 이녀석!"
    scene ch02_cafe02_59 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/kissshort03.mp3"
    a "Mwah~"
    scene ch02_cafe02_60 at hand_camera with Dissolve(0.8)
    a "나 삐졌어."
    a "니가 나보다 내 여동생을 더 좋아하는거 같아."
    a "어떻게 그럴수 있니? 그 오랜 시간을 나와 함께 했는데.."
    a "그 요망한 년에게 그렇게 금방 빠져버리다니.."
    scene ch02_cafe02_61 at hand_camera with Dissolve(0.8)
    pause  
    scene ch02_cafe02_62 at hand_camera with Dissolve(0.8)
    play sound "audio/voices/flaugh06.mp3"
    a "하하하."
    a "어서 집에 가자 달링. 헤헤."
    scene ch02_cafe02_63 at hand_camera with Dissolve(0.8)
    a "(우리의 홈스윗홈으로 가자.)"
    if in_replay:
        return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
