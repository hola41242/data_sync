



init python:
    def update_anim_speed(value):
        store.anim_speed = value
        return None

init python:
    def v01_mary_bj01(trans, st, at):
        if store.last_anim_speed != store.anim_speed:
            current_progress = (st - store.start_time) / store.last_anim_speed
            store.start_time = st - (current_progress * store.anim_speed)
            store.last_anim_speed = store.anim_speed
        elapsed_time = st - store.start_time
        store.frame_num = int(elapsed_time / store.anim_speed) % 40 + 100
        if store.frame_num > 139:
            store.frame_num = 100
        trans.set_child("v01_mary_bj{:04d}".format(store.frame_num))
        return store.anim_speed

init python:
    def v01_mary_bj02(trans, st, at):
        if store.last_anim_speed != store.anim_speed:
            current_progress = (st - store.start_time) / store.last_anim_speed
            store.start_time = st - (current_progress * store.anim_speed)
            store.last_anim_speed = store.anim_speed
        elapsed_time = st - store.start_time
        frame_count = 39
        idx = int(elapsed_time / store.anim_speed) % frame_count
        file_num = 200 + idx
        trans.set_child("v01_mary_bj{:04d}".format(file_num))
        return store.anim_speed

init python:
    def v03_mary_bj01(trans, st, at):
        if store.last_anim_speed != store.anim_speed:
            current_progress = (st - store.start_time) / store.last_anim_speed
            store.start_time = st - (current_progress * store.anim_speed)
            store.last_anim_speed = store.anim_speed
        
        elapsed_time = st - store.start_time
        frame_count = 44
        idx = int(elapsed_time / store.anim_speed) % frame_count
        
        file_num = idx + 1
        trans.set_child("v03_mary_bj01 ({})".format(file_num))
        
        return store.anim_speed


init python:
    def v03_mary_bj02(trans, st, at):
        if store.last_anim_speed != store.anim_speed:
            current_progress = (st - store.start_time) / store.last_anim_speed
            store.start_time = st - (current_progress * store.anim_speed)
            store.last_anim_speed = store.anim_speed
        
        elapsed_time = st - store.start_time
        frame_count = 45
        idx = int(elapsed_time / store.anim_speed) % frame_count
        
        file_num = idx + 1
        trans.set_child("v03_mary_bj02 ({})".format(file_num))
        
        return store.anim_speed

screen v01_mary_bj01:
    vbox:
        xalign 0.99
        yalign 0.8
        spacing 4
        textbutton "Slow" action SetVariable("anim_speed", 0.05) style "textbutton_choice"
        textbutton "Normal" action SetVariable("anim_speed", 0.033) style "textbutton_choice"
        textbutton "Fast" action SetVariable("anim_speed", 0.015) style "textbutton_choice"
    hbox:
        yalign 0.95
        xalign 0.99
        textbutton "Continue" action Return() style "textbutton_choice"

screen v01_mary_bj02:
    vbox:
        xalign 0.99
        yalign 0.8
        spacing 4
        textbutton "Slow" action SetVariable("anim_speed", 0.05) style "textbutton_choice"
        textbutton "Normal" action SetVariable("anim_speed", 0.033) style "textbutton_choice"
        textbutton "Fast" action SetVariable("anim_speed", 0.015) style "textbutton_choice"
    hbox:
        yalign 0.95
        xalign 0.99
        textbutton "Continue" action Return() style "textbutton_choice"

screen v03_mary_bj01:
    vbox:
        xalign 0.99
        yalign 0.8
        spacing 4
        textbutton "Slow" action SetVariable("anim_speed", 0.05) style "textbutton_choice"
        textbutton "Normal" action SetVariable("anim_speed", 0.033) style "textbutton_choice"
        textbutton "Fast" action SetVariable("anim_speed", 0.015) style "textbutton_choice"
    hbox:
        yalign 0.95
        xalign 0.99
        textbutton "Continue" action Return() style "textbutton_choice"

screen v03_mary_bj02:
    vbox:
        xalign 0.99
        yalign 0.8
        spacing 4
        textbutton "Slow" action SetVariable("anim_speed", 0.05) style "textbutton_choice"
        textbutton "Normal" action SetVariable("anim_speed", 0.033) style "textbutton_choice"
        textbutton "Fast" action SetVariable("anim_speed", 0.015) style "textbutton_choice"
    hbox:
        yalign 0.95
        xalign 0.99
        textbutton "Continue" action Return() style "textbutton_choice"





init python:
    store.manual_frame = 100


    def mary_bj01_interactive(event_type):
        if event_type == "up":      
            store.manual_frame += 1
            if store.manual_frame > 139:
                store.manual_frame = 139
        elif event_type == "down":  
            store.manual_frame -= 1
            if store.manual_frame < 100:
                store.manual_frame = 100
        return None


    def v01_mary_bj01_manual(trans, st, at):
        trans.set_child("v01_mary_bj{:04d}".format(store.manual_frame))
        return 0.01


screen v01_mary_bj01_manual:
    modal True


    key "mousedown_4" action [Function(mary_bj01_interactive, "up"), renpy.restart_interaction]
    key "mousedown_5" action [Function(mary_bj01_interactive, "down"), renpy.restart_interaction]
    key "mouseup_4" action [Function(mary_bj01_interactive, "up"), renpy.restart_interaction]
    key "mouseup_5" action [Function(mary_bj01_interactive, "down"), renpy.restart_interaction]


    key "rollback" action NullAction()
    key "skip" action NullAction()


    add "gui/mwheel.png" align (0.99, 0.8)


    frame:
        align (0.99, 0.95)
        has hbox
        spacing 10
        textbutton "Next" action Return() style "textbutton_choice"





init python:
    store.manual_frame_02 = 200  


    def mary_bj02_interactive(event_type):
        if event_type == "up":      
            store.manual_frame_02 += 1
            if store.manual_frame_02 > 239:
                store.manual_frame_02 = 239
        elif event_type == "down":  
            store.manual_frame_02 -= 1
            if store.manual_frame_02 < 200:
                store.manual_frame_02 = 200
        return None


    def v01_mary_bj02_manual(trans, st, at):
        trans.set_child("v01_mary_bj{:04d}".format(store.manual_frame_02))
        return 0.01





screen v01_mary_bj02_manual:
    modal True



    key "mousedown_4" action [Function(mary_bj02_interactive, "up"), renpy.restart_interaction]
    key "mousedown_5" action [Function(mary_bj02_interactive, "down"), renpy.restart_interaction]
    key "mouseup_4" action [Function(mary_bj02_interactive, "up"), renpy.restart_interaction]
    key "mouseup_5" action [Function(mary_bj02_interactive, "down"), renpy.restart_interaction]

    key "rollback" action NullAction()
    key "K_PAGEUP" action NullAction()
    key "K_PAGEDOWN" action NullAction()

    key "skip" action NullAction()

    add "gui/mwheel.png" align (0.99, 0.8)

    frame:
        align (0.99, 0.95)
        has hbox
        spacing 10

        textbutton "Next" action Return() style "button_text"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
