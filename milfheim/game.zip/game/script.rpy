default ch06_started = False

label ch06_orph01:
    $ ch06_started = True
    if not in_replay:
        $ persistent.unlock_ch06_orph01 = True
    show screen top_ui_buttons
    play music "audio/bgm/erotic07.mp3"
    scene chapter06_start01 with Dissolve(2.0)
    pause
    scene chapter06_start02 with Dissolve(2.0)
    pause
    scene ch05_orph01_80 at hand_camera with Dissolve(0.8)
    m "꺼헉...."
    scene ch05_orph01_81 at hand_camera with Dissolve(0.8)
    eve "응?"
    play voice_f "audio/sex/gag03.wav" volume 2.0
    m "꺼헉......."
    eve "!!!!!!"
    scene ch05_orph01_81-02 at hand_camera with Dissolve(0.8)
    eve "누구에요? 괜찮아요?..."
    pause
    eve "......."
    m "꺼헉......."
    play voice_f "audio/sex/gag03.wav" volume 2.0
    eve "!!!"
    eve "토하는 거에요??"
    $ renpy.pause(3.0, hard=True)
    m "나 메리야."
    eve "!!!!"
    eve "아.....혹시 문제있어요?"
    pause
    pause
    eve "**(뭐지?)**"
    eve "**(좀 이상한데..)**"
    eve "........."
    scene ch05_orph01_81-03 at hand_camera with Dissolve(0.8)
    pause
    m "꺼헉......."
    play voice_f "audio/sex/gag01.mp3"
    eve "!!!"
    eve "괜찮아요 메리??"
    scene ch05_orph01_82 at hand_camera with Dissolve(0.8)
    eve ".........."
    pause
    eve "**(뭐야 대체...)**"
    scene ch05_orph01_83 at hand_camera with Dissolve(0.8)
    eve "!!!!!!"
    scene ch06_orph01_0 at hand_camera with Dissolve(0.8)
    eve "........."
    eve "**(뭐가 움직이는거 같은데??)**"
    scene ch06_orph01_00 at hand_camera with Dissolve(0.8)
    m "**(젠장 [d_name]!!!!!)**"
    m "**(누가 여기 있잖아!!)**"
    m "**(안들려???!!!)**"
    n "메리는 [d_name]이 다른 사람의 인기척을 느꼈는지 알 수 없었다."
    n "그는 전혀 아랑곳하지 않는거 처럼 행동했다."
    n "그 순간 메리는 그를 전혀 신뢰할 수 없었다."
    pause
    n "그녀 자신의 커리어가 몇 초만에 끝날 수 있는 절체절명의 순간이었다."
    scene ch06_orph01_01 at hand_camera with Dissolve(0.4)
    m "!!!!!!!"
    m "**(헤이!!!!!!)**"
    play voice_f "audio/sex/liquid01.mp3"
    scene ch06_orph01_02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag03.wav"
    m "커헉..."
    eve "!!!!!!"
    scene ch06_orph01_03 at hand_camera with Dissolve(0.8)
    eve "정말 괜찮아요 메리?"
    pause
    eve "........"
    eve "병원에 가봐야 하는거 아니에요?"
    m ".........."
    scene ch06_orph01_04 at hand_camera with Dissolve(0.8)
    m "아니햐.(입에 뭐가 들어가서 제대로 발음되지 않는 표현.)"
    pause
    m "괘한하.(입에 뭐가 들어가서 제대로 발음되지 않는 표현.)"
    eve "네??!!"
    scene ch06_orph01_05 at hand_camera with Dissolve(0.8)
    eve "**(뭔가 이상한데?)**"
    eve "........."
    eve "**(분명 누가 또 있는거 같은데...)**"
    eve "........."
    scene ch06_orph01_06 at hand_camera with Dissolve(0.8)
    m "커헉 아니야."
    m "약 먹었으니 괜찮아 질거야."
    m "고마워 이브."
    scene ch06_orph01_07 at hand_camera with Dissolve(0.8)
    eve "........."
    eve "네...알겠어요."
    eve "혹시 도움필요하면 전화하세요."
    m "그래 알겠어."
    m "고마워 이브."
    d "**(아 그 여자 정말 집요하네!!!)**"
    scene ch06_orph01_08 at hand_camera with Dissolve(0.8)
    eve "크흠."
    d "**(제발 좀 저리가주세요.....)**"
    m "........."
    m "고마워 이브."
    play sound "audio/ambi/dooropen.mp3"
    scene ch06_orph01_09 at hand_camera with Dissolve(0.8)
    eve "네...."
    eve "........."
    pause
    eve "**(메리가 요즘 좀 이상하네....)**"
    eve "**(흐음.......)**"
    eve "**(다른 사람들도 느끼고 있나??)**"
    eve "....."
    eve "**(셀린과 얘기를 좀 해봐야겠다.)**"
    scene ch06_orph01_10 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/doorclose.mp3"
    scene ch06_orph01_11 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    m "하아........."
    m "너 정말!!"
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_orph01_12 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!"
    n "그녀는 갑자기 자신의 하체가 앞으로 당겨지는 느낌을 받았다."
    pause
    n "그리고 그녀는 곧 변기위에 아슬아슬하게 기대어 누워있는 자세가 되었다."
    play music "audio/bgm/erotic04.mp3"
    scene ch06_orph01_13 at hand_camera with Dissolve(0.8)
    m "헤이!!"
    m "뭐하는거야 [d_name]!!!!!!"
    scene ch06_orph01_14 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
    m "아아!!!!!!!!!!!!!!"
    m "[d_name]!!!!!"
    scene ch06_orph01_15 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/fmoanshort05.mp3"
    m "하윽!!!!!!!"
    scene ch06_orph01_16 at hand_camera with Dissolve(0.8)
    pause
    n "그것은 그녀에게 실로 오랜만에 느껴보는 쾌감이었다."
    play voice_f  "audio/sex/fmoanshort04.mp3"
    pause
    n "그의 입이 그녀의 음부를 부드럽게 감쌌다."
    n "[d_name]의 입술과 혀의 감촉은 그녀의 또다른 이성의 막을 허물었다."
    play voice_f  "audio/sex/fmoanlong03.mp3"
    scene ch06_orph01_15 at hand_camera with Dissolve(0.8)
    n "그의 혀끝에 미묘한 맛이 느껴졌다."
    pause
    n "그의 혀 끝이 그녀의 질입구를 집요하게 파고 들었다."
    n "그리고 그녀의 음부가 미묘하게 움찔거리는 것이 느껴졌다."
    scene ch06_orph01_16-02 at hand_camera with Dissolve(0.8)
    n "그녀는 자신의 몸을 휘감는 쾌감에 어찌할바를 몰랐다."
    pause
    n "그녀는 할 수 있는 유일한 반응은...."
    stop voice_f fadeout 1.0
    scene ch06_orph01_17 at hand_camera with Dissolve(0.8)
    m "아 [d_name]!!!!!!"
    d "!!!!!!"
    d "컥!!!!!!!"
    scene ch06_orph01_18 at hand_camera with Dissolve(0.8)
    d "........"
    play sound "audio/ambi/hit01.mp3"
    scene ch06_orph01_19 at hand_camera with Dissolve(0.3)
    d "아얏!!"
    m "!!!!!!!!!!!!"
    m "미안해 미안해!!"
    scene ch06_orph01_20 at hand_camera with Dissolve(0.8)
    m "미안해 그렇게 때리려던건 아니었어.."
    m "너무 깜짝놀라서 그만....."
    m "안다쳤니??!!"
    scene ch06_orph01_21 at hand_camera with Dissolve(0.8)
    d "하하 괜찮아요."
    pause
    d "제가 맞을 짓을 했어요 하하."
    d "**(니킥을 제대로 맞았네 하하하...)**"
    d "**(일부러 해놓고 실수인척 하는거 아냐?...)**"
    scene ch06_orph01_21-01 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_21-02 at hand_camera with Dissolve(0.8)
    m "아우...."
    m "대체 이게 무슨......"
    scene ch06_orph01_21-03 at hand_camera with Dissolve(1.2)
    m "맙소사....."
    m "너 정말 미쳤구나...."
    pause
    m "무슨 짓이야 이게...."
    play music "audio/bgm/normal13.mp3"
    scene ch06_orph01_22 at hand_camera with Dissolve(1.2)
    d "..........."
    m "너 정말 제정신이니....."
    d "......."
    m "이게 대체 화장실에서 무슨일이야....."
    scene ch06_orph01_23 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/fsigh06.mp3"
    m "퓨........"
    scene ch06_orph01_23-02 at hand_camera with Dissolve(1.2)
    m "**(맙소사........)**"
    m "**(그의 입이 아직도 내 밑에 붙어있는거 같아.......)**"
    scene ch06_orph01_24 at hand_camera with Dissolve(0.8)
    pause
    m "어서 나가."
    d "....."
    m "내 사무실에 가 있어."
    m "복도 잘 살피고 바로 내 사무실로 바로 뛰어가."
    m "알겠지?"
    scene ch06_orph01_26 at hand_camera with Dissolve(0.8)
    d ".............."
    d "알겠어요.."
    d "지금 나갈게요."
    scene ch06_orph01_27 at hand_camera with Dissolve(0.8)
    d ".............."
    scene ch06_orph01_28 at hand_camera with Dissolve(1.3)
    pause
    d "젠장......"
    m "뭐??"
    scene ch06_orph01_28-02 at hand_camera with Dissolve(1.3)
    pause
    scene ch06_orph01_28 at hand_camera with Dissolve(1.3)
    pause
    menu:
        n "What should I do?"
        "그녀와 몸을 밀착 시킨다.":
            play sound "audio/ambi/fabric04.mp3" volume 1.8 
            scene ch06_orph01_29 at hand_camera with Dissolve(0.8)
            m "!!!!!"
            m "뭐해???!!!"
            d "아...메리...."
    scene ch06_orph01_30 at hand_camera with Dissolve(0.8)
    d ".........."
    m "........"
    pause
    d "그거 알아요?.."
    m "하.....뭐가 또??!!"
    m "또 무슨 말하려고?"
    pause
    d ".........."
    d "당신의 엉덩이는 정말 최고에요...."
    pause
    m "......."
    m "하아...."
    d "어떻게 이렇게 완벽한 형태인지....."
    d "메리를 볼때마다 가슴과 엉덩이만 봤던거 알아요?"
    m "......."
    pause
    d "맙소사....."
    d ".............."
    d "근데 제가 이렇게 메리를 만지고 있다는게 믿기지가 않아요....."
    scene ch06_orph01_31 at hand_camera with Dissolve(0.8)
    m "하지마."
    m "나 화낸다."
    d "너무 크지도 작지도 않고 딱 좋은 크기..."
    pause
    d ".............."
    d "메리의 보지도"
    m "정말 하지마."
    m "너 이거 밖에 안되는 사람이었어??"
    d "........"
    m "나 니가 점점 무서워지려고하잖아.."
    m "무슨 말인지 알겠어?"
    scene ch06_orph01_32 at hand_camera with Dissolve(0.8)
    d "왜요?"
    m "왜라니?"
    m "몰라서 물어?"
    d "우린 이미 이거보다 더 가까워졌잖아요?"
    m ".........."
    d "전 정말 메리가 너무 좋아요."
    d "사랑해요 메리."
    pause
    d ".............."
    d "메리를 가지고 싶어요..."
    scene ch06_orph01_33 at hand_camera with Dissolve(0.8)
    m "............."
    n "그녀는 자신의 엉덩이골 사이로 그의 발기한 고추를 느낄 수 있었다."
    pause
    n "그녀는 그가 가능한 그의 고추를 그녀의 음부에 밀착하려 힘을 주는 것을 느꼈다."
    scene ch06_orph01_34 at hand_camera with Dissolve(0.8)
    m "그만해......"
    pause
    m "여기선 안돼..."
    m "여긴 내 직장이잖아..."
    d "잠시만 이렇게 있을게요......"
    play voice_f "audio/voices/fsigh06.mp3"
    m "하............"
    pause
    m "..........."
    d "하....자지가 터질거 같아요..."
    m "........"
    pause
    d "이렇게 있으니까 메리를 가진거 같은 느낌이 들어요...."
    d "메리라는 여자가 절 허락한 느낌이 든다구요...."
    m "..........."
    pause
    d "저만이 메리에게 이렇게 할수 있는거잖아요..."
    m "뭐?"
    d "아니 리차드 아저씨도...."
    m "하...정말...."
    m "지금 무슨 소릴 하는거니....."
    scene ch06_orph01_33 at hand_camera with Dissolve(0.8)
    m "그만해 이제."
    pause
    m "사무실로 가 있어 허니."
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph01_35 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!"
    m "뭐하는거야??!!"
    scene ch06_orph01_36 at hand_camera with Dissolve(0.8)
    d "하..메리...."
    d "메리는 이제 저의 여자인거죠??"
    m "그게 무슨 말이야??"
    scene ch06_orph01_35 at hand_camera with Dissolve(0.8)
    d "메리가 저의 자지를 빨아줬고...."
    d "전 메리의 보지를 빨았잖아요."
    d "그러니까 메리는 이제 저의 여자인거에요."
    m "난 너의 선생님이잖아 무슨 소리 하는거야??!!"
    scene ch06_orph01_36 at hand_camera with Dissolve(0.8)
    d "하..메리...."
    pause
    d ".........."
    d "지금 무슨 생각해요??...."
    m "......."
    pause
    m "아무 생각도 안해."
    pause
    d "전 메리에게 넣는 상상하고 있어요 지금."
    m ".........."
    pause
    d "아 젠장...."
    scene ch06_orph01_35 at hand_camera with Dissolve(0.8)
    m "그만해!!"
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph01_37 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    scene ch06_orph01_37-02 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!"
    scene ch06_orph01_38 at hand_camera with Dissolve(0.8)
    m "뭐하는거야?!!!!"
    d "하...메리....."
    d "난 더 메리를 알고싶어요..."
    d "메리의 남자가 되고 싶다구요.."
    pause
    d "리처드 아저씨 말고 제가 메리의 남자가 되고 싶다구요."
    m "뭐??!!!!"
    scene ch06_orph01_39 at hand_camera with Dissolve(0.8)
    m "..........."
    m "너 미쳤어?"
    pause
    m "어...어떻게 나와 리차드에게 그런 말을........"
    pause
    m "패..팬티 다시 올려."
    m "어서."
    scene ch06_orph01_38 at hand_camera with Dissolve(0.8)
    d "하아.........."
    d "메리가 저의 자지를 빨아준 날...."
    m ".........."
    d "밤에 리차드 아저씨와 날 빨아준 입으로 키스했어요?"
    m "[d_name]!!!"
    d "저의 자지를 생각하며 리차드 아저씨와 섹스했어요?"
    m "그만해!!"
    scene ch06_orph01_39 at hand_camera with Dissolve(0.8)
    d "..........."
    d "미안해요 메리...."
    d "저도 미치겠어요..."
    m "그만하고 어서 사무실로 가있어."
    m "너 또 이상해졌잖아 허니."
    scene ch06_orph01_38 at hand_camera with Dissolve(0.8)
    d "하아.........."
    d "알겠어요....."
    m "그래..."
    menu:
        n "What should I do?"
        "그녀의 음부를 확인한다.":
            play sound "audio/ambi/touch02.mp3"
            scene ch06_orph01_40 at hand_camera with Dissolve(0.8)
            m "!!!!!!!!!!!!!!!!"
            m "이 미친놈!!"
    scene ch06_orph01_42 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/fsigh06.mp3"
    m "하......."
    m "..........."
    pause
    m "내가 그때 너에게 무슨 짓을 한걸까......"
    m "모든 건 내 책임이야 [d_name]..."
    scene ch06_orph01_43 at hand_camera with Dissolve(0.8)
    m "사무실에 가 있어."
    d "저기.."
    m "아무말도 하지마."
    m "내가 매라도 들어야겠니??!!"
    scene ch06_orph01_44 at hand_camera with Dissolve(0.8)
    d "알겠어요."
    d "........"
    m "복도 잘 살피고!!"
    play sound "audio/ambi/dooropen03.mp3"
    scene ch06_orph01_45 at hand_camera with Dissolve(0.8)
    d "........."
    d "**(참나...매라니....)**"
    d "**(내가 무슨 어린애인줄아나?...)**"
    d "**(내 자지를 보고도 날 애 취급하는거야??)**"
    play sound "audio/ambi/doorclose.mp3"
    scene ch06_orph01_46 at hand_camera with Dissolve(0.8)
    m "............."
    $ renpy.pause(3.0, hard=True)
    m "내가 왜 그에게 이런것들을 하게 만든거지?......."
    scene ch06_orph01_46-02 at hand_camera with Dissolve(0.8)
    m "난 어른으로서 실격이다 정말....."
    m "내가 이 곳 원장 자격이 있나?......"
    pause
    m "내가 공원에서 만났던 그 미친년 보다 나은게 뭐지??....."
    pause
    m "그 여자는 최소한 솔찍하기라도 했잖아...."
    scene ch06_orph01_47 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_orph01_48 at hand_camera with Dissolve(0.8)
    d "??"
    scene ch06_orph01_49 at hand_camera with Dissolve(0.8)
    pause
    n "그가 메리의 집무실에 들어왔을때 낯선 여성이 앉아 있었다."
    pause
    n "그는 그녀의 실루엣으로 그녀를 알아볼 수 없었다."
    scene ch06_orph01_48 at hand_camera with Dissolve(0.8)
    d "??"
    scene ch06_orph01_50 at hand_camera with Dissolve(0.8)
    unknown "??"
    play music "audio/bgm/normal04.mp3"
    scene ch06_orph01_51 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_52 at hand_camera with Dissolve(0.8)
    unknown "!!!!!!!!!!!!!!!!!!!"
    unknown "너....너는........."
    scene ch06_orph01_53 at hand_camera with Dissolve(0.8)
    d "네???"
    d "**(왜 놀라지??)**"
    d "**(그녀가 날 아나?)**"
    d "절 아세요??"
    scene ch06_orph01_52 at hand_camera with Dissolve(0.8)
    unknown "너..너는........."
    d "??????"
    unknown "얼마전에 해변에서......"
    d "........."
    d "....."
    pause
    d "앗!!!!!!!!!!!!"
    scene ch06_orph01_54 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_54-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_55 at hand_camera with Dissolve(0.8)
    unknown "니...니가 왜 여기에??"
    unknown "........"
    unknown "너 설마......"
    pause
    unknown "나 스토킹 하니??!!"
    if not in_replay:
        $ add_point("sus_anna", 1, "sus_anna")
    scene ch06_orph01_56 at hand_camera with Dissolve(0.8)
    d "그게 무슨말이에요?"
    d "스...스토킹이요??!!"
    d "전혀 아니에요!!"
    scene ch06_orph01_55 at hand_camera with Dissolve(0.8)
    unknown "그럼 니가 여기 왜 왔어???!!"
    unknown "???"
    d "네??"
    d "여기에 왜 왔냐구요?? 아니 그게..."
    d "여기는 저의..."
    scene ch06_orph01_57 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_58 at hand_camera with Dissolve(0.8)
    m "!!"
    m "아니 애나??"
    m "언제 온거야?"
    m "왜 말도 없이 왔어?"
    an "안녕 언니."
    scene ch06_orph01_59 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!"
    d "**(언니????!!!!!!!)**"
    d "**(애.....애나?)**"
    d "**(..........)**"
    d "**(많이 들어본 이름인데?)**"
    d "**(......)**"
    d "**(아.....기억 날듯말듯한데.....)**"
    scene ch06_orph01_60 at hand_camera with Dissolve(0.8)
    an "응 엄마 보러가는 길에 그냥 와봤어."
    an "잘 지냈지?"
    scene ch06_orph01_60-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph01_60-03 at hand_camera with Dissolve(0.8)
    pause
    an "**(왠 꽃??)**"
    an "**(...........)**"
    an "**(뭐야....)**"
    an "**(설마 이 꼬맹이가 메리에게 꽃을 준거야??...)**"
    scene ch06_orph01_61 at hand_camera with Dissolve(0.8)
    m "아 그랬구나."
    d "......"
    m "휴...나도 엄마 집에 자주 가야하는데 요즘 바쁘네..."
    m "아버지 돌아가시고 엄마 혼자 쓸쓸할텐데....."
    m "난 효녀되긴 글렀어."
    an "어쩔수 없지.."
    m "아 여기 [d_name]하고는 인사 했지?"
    scene ch06_orph01_62 at hand_camera with Dissolve(0.8)
    an "!!!!!!!!!!!!!!!!!!"
    an "**([d_name]????!!)**"
    scene ch06_orph01_63 at hand_camera with Dissolve(0.8)
    an "fuck!!!!"
    if not in_replay:
        $ add_point("lust_anna", 10, "lust_anna")
    m "입좀 조심해라 애나..."
    m "왜 욕을하고 그래."
    scene ch06_orph01_64 at hand_camera with Dissolve(0.8)
    m "갑자기 왜 그래?"
    m "귀신이라도 본거야?"
    d "저... 저기...."
    scene ch06_orph01_65 at hand_camera with Dissolve(0.8)
    d "애.....애나....."
    d "하하...안녕하세요 애나...."
    d "이거 참......"
    d "제가 모...못알아봤어요 하하."
    scene ch06_orph01_66 at hand_camera with Dissolve(0.8)
    an "응 ㅎㅎ 그렇지?"
    an "오...오랜만이네."
    an "이렇게 만나다니 세상에 참 하하하...."
    m "왜그리 둘이 어색해?"
    m "너무 오랜만에 봤나?"
    m "그럴만 하네. 몇 년도 더 됐지 그치?"
    scene ch06_orph01_66-02 at hand_camera with Dissolve(0.8)
    an "**(맙소사...)**"
    an "**(갑자기 토할거 같아......)**"
    an "**(미쳤다 진짜..)**"
    pause
    an "**(쟤가 진짜 [d_name]이야???)**"
    an "**(내 언니 학생이랑 떡친거야??)**"
    scene ch06_orph01_67 at hand_camera with Dissolve(0.8)
    m ".............."
    m "왜 그러고 서있어?"
    pause
    m "정신 사나워. 의자에 앉아라."
    m "차 마실래?"
    an "아냐 괜찮아."
    an "어짜피 금방 갈거야."
    an "고마워."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch06_orph01_68 at hand_camera with Dissolve(0.8)
    an "암튼 뭐 그런 일이 있었다는거야."
    an "내가 그 얘기 듣고 얼마나 어이가 없었는지 알아?"
    an "화를 내야 되나 웃어야 되나 한참 멍하니 서 있었다니까."
    d "........."
    m "그래서 결국 어떻게 됐는데?"
    an "어떻게 되긴."
    an "방문 쾅 닫고 들어가 버렸지."
    an "나 혼자 거실에서 한 참을 서 있었다니까."
    m "그런건 조심해야 돼."
    scene ch06_orph01_68-02 at hand_camera with Dissolve(0.8)
    m "애들이 성에 눈을 뜨기 시작할때 부모 역할이 중요하다고."
    an "예전엔 엄마, 엄마 하면서 졸졸 따라다니더니 이젠 말 한마디 걸기도 눈치 보여."
    an "믿어지지가 않아."
    scene ch06_orph01_68-03 at hand_camera with Dissolve(0.8)
    an "어디서 그런 지같은 못난 여자애를 만났는지."
    an "어린애가 벌써부터 발랑 까져가지고."
    an "발육은 또 얼마나 빠른지 엉덩이랑 가슴이 아주그냥.."
    d "....."
    m "스티브는?"
    an "그 인간은 맨날 내가 알아서 잘 하라는 소리만 해."
    an "그 말 들을 때마다 진짜 확 한 대 때려주고 싶어."
    d "........."
    scene ch06_orph01_69 at hand_camera with Dissolve(0.8)
    m "그래. 그래도 어쩌겠어 니 자식인데."
    m "사춘기는 그래서 힘들어."
    m "어제는 철학자, 오늘은 시인, 내일은 연쇄살인마라니까."
    d "ㅎㅎㅎ"
    pause
    an "나도 겪으니까 힘들다 정말. 하...."
    m "아무리 그래도 여기다 니 자식 버릴 생각은 하지말고."
    an "하하하. 여차하면 여기다 버릴거야."
    an "원장님이 키워주면 되잖아? 양육비는 보낼게."
    d "........"
    scene ch06_orph01_70 at hand_camera with Dissolve(0.8)
    m "아우....."
    m "몸이 좀 으슬으슬하네.."
    pause
    an "어디 아파?"
    an "감기 걸렸어?"
    scene ch06_orph01_71 at hand_camera with Dissolve(0.8)
    d "괜찮아요 메리?"
    d ".........."
    pause
    d "**(오늘 괜히 왔나..)**"
    d "**(서프라이즈 한다고 괜히 연락도 안했네..)**"
    scene ch06_orph01_72 at hand_camera with Dissolve(0.8)
    pause
    m "오늘 아침까지만 해도 괜찮았는데 일시작 하고나서부터 갑자기 이러네..."
    d "약은.."
    an "약은 먹었고??"
    d "**(젠장 내가 먼저 물어보려고 했는데..)**"
    m "약 먹었는데 몸살 기운이 더 심해지네."
    m "갱년기라 그런가 요즘 툭하면 몸살이야."
    scene ch06_orph01_73 at hand_camera with Dissolve(0.8)
    an "......."
    pause
    an "몸 잘 챙겨."
    an "언니가 그럴때마다 내가 신경쓰여 죽겠다니까."
    m "알겠어."
    pause
    an "......."
    scene ch06_orph01_74 at hand_camera with Dissolve(0.8)
    an "그럼 다음에 또 들를게."
    an "중요한 일 없으면 좀 누워있어."
    an "여기 원장 되고 매일 야근하고 엄청 무리했다더니 드디어 탈나는구나."
    scene ch06_orph01_74-02 at hand_camera with Dissolve(0.8)
    an "중요한 일 없으면 좀 누워있는게 어때?"
    pause
    m "그래야겠다."
    m "아무튼 엄마 집에 자주좀 들러. 알았니?"
    m "조카들도 좀 엄마 집에 자주 데리고가."
    scene ch06_orph01_75 at hand_camera with Dissolve(0.8)
    an "알겠어."
    an "자주 들를게 ㅎㅎ."
    scene ch06_orph01_76 at hand_camera with Dissolve(1.2)
    if not in_replay:
        $ add_point("lust_anna", 1, "lust_anna")
        $ add_point("love_anna", 1, "love_anna")
    an "잘 있어 [d_name]."
    an "나중에 또보자."
    scene ch06_orph01_77 at hand_camera with Dissolve(0.8)
    d "네 ㅎㅎ 알겠어요."
    d "또 봐요 애나....."
    d "만나서 반가웠어요."
    an "그래 잘 지내고."
    an "언니도 니가 잘 챙겨줘야 해 알았니?"
    d "네 그럼요 ㅎㅎ"
    scene ch06_orph01_78 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/dooropen03.mp3"
    scene ch06_orph01_79 at hand_camera with Dissolve(0.8)
    pause
    an "**(아우 썅 심장이 벌렁거리네.)**"
    scene ch06_orph01_80 at hand_camera with Dissolve(0.8)
    pause
    an "**(이거 별 탈 없겠지?....)**"
    an "**(진짜 기가막히다...기가막혀.)**"
    pause
    an "**(쟤가 [d_name]이었다니....)**"
    scene ch06_orph01_81 at hand_camera with Dissolve(0.8)
    d "**(진짜 이 동네 좁네....)**"
    d "**(아 그때 어디서 본 사람 같긴 했는데.....)**"
    pause
    d "**(애나는 그때 일 당연히 발설안하겠지?.....)**"
    an "**(쟤 설마 아무에게도 얘기 안하겠지??)**"
    an "**(하....쫌 불안한데..)**"
    pause
    an "**(떠벌리고 다니는 타입 같은데...아..썅....)**"
    scene ch06_orph01_82 at hand_camera with Dissolve(0.8)
    m "**(...............)**"
    play sound "audio/ambi/doorclose.mp3"
    m "**(뭐야 저 분위기는...)**"
    m "**(아까부터 엄청 부자연스럽네..)**"
    scene ch06_orph01_83 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_orph01_84 at hand_camera with Dissolve(1.2)
    pause
    jump ch06_orph02

label ch06_orph02:
    if not in_replay:
        $ persistent.unlock_ch06_orph02 = True
    play music "audio/bgm/normal11.mp3"    
    scene ch06_orph02_01 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/fsigh06.mp3"
    m "휴.....안되겠다.."
    m "나 좀 누워있어야 겠어."
    d "괘..괜찮아요??!!"
    m "핑핑돈다.."
    m "저혈압인가..."
    scene ch06_orph02_02 at hand_camera with Dissolve(0.8)
    d "괜찮은거에요?"
    d "같이 병원 가볼래요?"
    m "아니야 조금만 누워있으면 돼."
    m "가끔 이래."
    d "........."
    n "메리는 자신의 집무실에 있는 휴게실로 들어섰다."
    scene ch06_orph02_02-02 at hand_camera with Dissolve(0.8)
    n "그녀는 해야 할 업무를 위해 방해받지 않고 온전히 쉬고 싶었지만..."
    pause
    n "그녀는 [d_name]에게 떠나라고 말할 수 없었다."
    n "[d_name]역시 아픈 메리를 걱정했지만 그녀의 집무실을 떠나지 않았다."
    scene ch06_orph02_03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_orph02_03-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_orph02_04 at hand_camera with Dissolve(0.8)
    m "휴......"
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_05 at hand_camera with Dissolve(0.8)
    m "끄응.."
    m "이렇게 왔는데 미안하구나."
    d "........."
    d "아니에요 메리."
    m "내가 오늘 컨디션이 너무 안좋아."
    pause
    m "자꾸 너한테 짜증내게 되네."
    scene ch06_orph02_06 at hand_camera with Dissolve(0.8)
    d "아니에요 괜찮아요."
    pause
    d "이렇게 메리 봤으면 된거에요."
    d "........."
    d "근데 정말 병원안가도 괜찮아요?"
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_07 at hand_camera with Dissolve(0.8)
    m "........"
    m "약이 안듣는건지 몸살 기운이 심해지네."
    m "한 여름에 몸살이라니 참.."
    m "설마 코로나는 아니겠지? ㅎㅎ"
    scene ch06_orph02_08 at hand_camera with Dissolve(0.8)
    pause
    d "**(젠장..)**"
    pause
    d "**(아픈 메리에게 내가 무슨 짓을 한거지...)**"
    pause
    d "........."
    scene ch06_orph02_09 at hand_camera with Dissolve(0.8)
    d "**(오늘은 거의 강제로 그녀 입에 쑤셔 넣었잖아....)"
    pause
    m "끄응......"
    d "........."
    d "**(젠장 맘이 불편하네..)**"
    scene ch06_orph02_10 at hand_camera with Dissolve(0.8)
    pause
    d "............"
    d "**(난 오늘 여기 왜 온거지?......)**"
    pause
    d "**(메리가 보고싶었던거야 아님 내 성욕 때문이야....)**"
    d "........"
    pause
    d "**(이게 신사다운 남자의 모습이냐??!!)**"
    scene ch06_orph02_11 at hand_camera with Dissolve(1.2)
    pause
    d "**(그녀는 내 도구가 아니잖아.......)**"
    pause
    d "**(한심한 놈같으니...)**"
    scene ch06_orph02_12 at hand_camera with Dissolve(1.2)
    pause
    n "둘 사이에 짧은 정적이 흘렀다."
    pause
    n "메리는 말 없이 누워있을 뿐이었고 그게 [d_name]을 불편하게 했다."
    pause
    n "고요한 방에 메리의 숨소리만이 울리고 있었다."
    scene ch06_orph02_13 at hand_camera with Dissolve(0.8)
    m "........."
    pause
    m "[d_name]."
    d "네?"
    pause
    m "........."
    pause
    m "내가 무슨 짓을 벌이고 있는거지?"
    scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
    pause
    d "그게 무슨 말이에요?..."
    d "........"
    pause
    d "메리는 아무짓도 안했잖아요?...."
    scene ch06_orph02_13 at hand_camera with Dissolve(0.8)
    m "........."
    m "아니 그게 아니라.."
    $ renpy.pause(2.0, hard=True)
    m "[d_name] 너와 말이야."
    m "우린 지금 무슨 짓을 벌이고 있는지 넌 아니?"
    d ".........."
    pause
    m "얼마전에 그 공원에서 처럼 나에게 말해봐...."
    pause
    m "넌 때때로 나보다 더 어른스럽잖아."
    d "....."
    m "이번에도 니가 이게 대체 무슨 상황인지 설명해줘.. "
    d "제가 지금 메리의 방에 있는거요?"
    m "............"
    pause
    m "내가 무슨 말 하는지 알잖아..."
    pause
    m "내가 너의..."
    m "아니 우리가 서로에게 입으로 했잖아..."
    m "맙소사......"
    pause
    m "나 화장실에서 볼 일 보고 있었다고.."
    scene ch06_orph02_15 at hand_camera with Dissolve(0.8)
    d "......."
    d "그..그건...."
    pause
    pause
    d "저도 잘 모르겠어요....."
    m "......."
    d "그냥......"
    pause
    d "어쩌다 보니....."
    scene ch06_orph02_15-02 at hand_camera with Dissolve(0.8)
    d "......."
    d "전 그냥 메리를 사랑하고 메리를 보고싶을 뿐이에요."
    scene ch06_orph02_16-02 at hand_camera with Dissolve(0.8)
    pause
    m "지금 니 행동은 날 사랑하는게 아니야."
    m "........."
    m "너 나와 한 약속 기억하니?"
    scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
    pause
    d "그럼요."
    d "당연히 기억하고 있어요."
    scene ch06_orph02_16-02 at hand_camera with Dissolve(0.8)
    m "........."
    m "근데 넌 지금 거짓말을 하고 있구나."
    pause
    m "실망이야.."
    scene ch06_orph02_15 at hand_camera with Dissolve(0.8)
    d "......."
    d "아니에요."
    d "그렇지 않아요."
    pause
    d "전 정말로 메리를 사랑하고 보고싶어서 여기 온거에요."
    pause
    d "지난번에도 말했잖아."
    pause
    d "전 하루종일 메리 생각 뿐이에요."
    d "......."
    pause
    d "잘 때도."
    d "걸을 때도..."
    pause
    d "샤워할때도...."
    pause
    d "자위할때도요...."
    m "........"
    scene ch06_orph02_16 at hand_camera with Dissolve(0.8)
    pause
    m "........."
    m "자위 할때 상상하는 나는 어떻게 등장하니?..."
    pause
    m "평소의 내 모습이야?"
    scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
    pause
    d "뭐랄까....."
    pause
    d "ㅎㅎ 그건 매번 달라요.."
    m "........"
    m "그냥 말해봐."
    d "......"
    d "적나라 하게요?"
    m "그래."
    m "니가 상상하는 그대로."
    scene ch06_orph02_15 at hand_camera with Dissolve(0.8)
    pause
    d "절 씻겨주는 메리..."
    pause
    d "저를 여보라고 부르는 메리."
    pause
    pause
    d "집안 여기저기서 저의 자지를 빨아주는 메리.."
    m "........."
    scene ch06_orph02_16 at hand_camera with Dissolve(0.8)
    pause
    d "저에게 엉덩이를 내밀고 박아달라고 사정하는 메리..."
    m "........."
    d "저의 아이를 가진 메리."
    m "......."
    m "맙소사 [d_name]....."
    pause
    m "미쳤다 정말....."
    pause
    m "그건 생각도 못했다.."
    pause
    d "적나라하게 말하라면서요...."
    m "아냐......"
    pause
    m "나무라는건 아냐."
    pause
    m "니 상상일 뿐인걸 뭐..."
    scene ch06_orph02_17 at hand_camera with Dissolve(0.8)
    m "미안 치마 좀 벗을게."
    m "너무 꽉 끼어서 불편하네."
    scene ch06_orph02_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_19 at hand_camera with Dissolve(0.8)
    pause
    d "..........."
    scene ch06_orph02_18 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_20 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_22 at hand_camera with Dissolve(1.0)
    m "아우 어지러워.."
    pause
    m "그래도 누워있으니 좀 낫다."
    scene ch06_orph02_23 at hand_camera with Dissolve(0.8)
    pause
    d "........."
    pause
    d "**(뭐지 저건??)**"
    pause
    d "**(자기는 저렇게 무방비여가지고선 나를 나무란거야??)**"
    pause
    d "**(.........)**"
    d "**(맙소사 저 엉덩이좀 봐.....)**"
    pause
    d "**(박아달라고 애원하는건가??......)**"
    pause
    d "저.........."
    pause
    d "메리에게 뭐 하나 물어봐도 돼요?"
    pause
    m "그럼."
    m "뭐가 궁금해?"
    menu:
        n "What should I do?"
        "메리는 몇 명과 잤어요?":
            scene ch06_orph02_23-02 at hand_camera with Dissolve(0.8)
            pause
            d "메리는 몇 명이랑 잤어요?"
            pause
            d "그러니까 지금까지 살면서..."
    scene ch06_orph02_23-03 at hand_camera with Dissolve(0.8)
    m ".............."
    m "맙소사 [d_name]."
    m "왜 그런걸 묻고그래..."
    scene ch06_orph02_23-02 at hand_camera with Dissolve(0.8)
    pause
    d "그냥 궁금해서요.."
    m "나도 몰라."
    pause
    d "어 정말이요?"
    pause
    d "우리 규칙 어길거에요?"
    scene ch06_orph02_23-03 at hand_camera with Dissolve(0.8)
    m ".............."
    pause
    m "몇 명일거 같은데?"
    pause
    m "니가 볼때 난 몇명이랑 잤을거 같니?"
    scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
    pause
    d "뭐랄까....."
    menu:
        n "What should I do?"
        "1명?":
            scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
            d "1명?"
            if not in_replay:
                $ add_point("love_mary", 1, "love_mary")
        "5명?":
            scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
            d "5명?"
        "10명?":
            scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
            d "10명?"
        "20명?":
            scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
            d "20명?"
        "셀수없을 만큼 많이.":
            scene ch06_orph02_14 at hand_camera with Dissolve(0.8)
            d "셀수없을 만큼 많이."
            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            m ".............."
            pause
            d "맞아요?"
            m "참......"
            pause
            m "맞아."
            m "한 100명 정도 되는거 같은데?"
            m "아니다."
            m "200명 정도 되는거 같다."
            d "!!!!!!!!"
            d "진짜요??!!!!"
    scene ch06_orph02_23-03 at hand_camera with Dissolve(0.8)
    m ".............."
    pause
    m "응 니가 정확히 맞췄어."
    d "하 그렇게 넘어가는거에요?"
    m ".............."
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_orph02_24 at hand_camera with Dissolve(1.2)
    pause
    d "그냥 말해주면 안돼요?"
    m ".............."
    m "몰라 기억안나."
    pause
    m "그런걸 다 기억하는 사람이 어딨니 내 나이에...."
    scene ch06_orph02_25 at hand_camera with Dissolve(0.8)
    pause
    d "나에게 말해주기 싫은거죠?"
    m "........"
    pause
    d "그쵸?"
    d "너무 많으면 제가 메리를 싫어할까봐 신경쓰이는거죠?"
    m "........"
    scene ch06_orph02_25-02 at hand_camera with Dissolve(0.8)
    d "괜찮아요 메리."
    m "........"
    pause
    m "무슨 말이야?"
    pause
    d "전 메리가 어떤 과거가 있든 상관없이 메리를 사랑해요."
    m "뭐?"
    pause
    m "내가 지금까지 몇명이랑 잤든 그게 너와 무슨 상관인데?"
    pause
    m "......"
    m "니가 내 남편이니..."
    menu:
        n "What should I do?"
        "조용히 바지를 벗는다.":
            scene ch06_orph02_26 at hand_camera with Dissolve(1.2)
            pause
            n "그는 커져가는 흥분을 뒤로하고 가능한 메리가 알아차리지 못하도록 조용히 바지를 벗었다."
            pause
            n "그리곤 조용히 침대위로 올라갔다."
    scene ch06_orph02_27 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_28 at hand_camera with Dissolve(0.8)
    m "뭐하는거야?"
    play sound "audio/ambi/fabric05.mp3"
    scene ch06_orph02_29 at hand_camera with Dissolve(0.8)
    m "!!"
    m "맙소사 [d_name]."
    m "이러면 안돼."
    m "어서 내려가."
    scene ch06_orph02_30 at hand_camera with Dissolve(0.8)
    d "사랑해요 메리."
    d "........"
    d "내가 이 세상에서 제일 아끼는 사람은 메리에요."
    d "메리도 알잖아요?"
    scene ch06_orph02_31 at hand_camera with Dissolve(0.8)
    m ".........."
    m "알아..."
    m "나도 널 사랑해."
    scene ch06_orph02_32 at hand_camera with Dissolve(0.8)
    m "근데 너의 매너는 영아니야 아저씨......"
    m "볼 때마다 그렇게 고추를 들이미니?? 허?"
    m "..........."
    m "내가 너의 여자친구야? 아님 너의 아내야?"
    m "니 대학교 여친에게도 그렇게 들이밀었었어?"
    scene ch06_orph02_30 at hand_camera with Dissolve(0.8)
    d "........."
    d "그건 사과할게요."
    d "...."
    d "제 머릿속에 섹스 생각뿐이라......"
    pause
    d "메리와 섹스하는 생각뿐이라...."
    scene ch06_orph02_31 at hand_camera with Dissolve(0.8)
    m "맙소사 스윗하트...."
    m ".........."
    m "누가 들어오기 전에 어서 나가."
    m "이러고 있다가 진짜 큰일 나."
    m "어떻게 이렇게 태연하니 넌...."
    scene ch06_orph02_33 at hand_camera with Dissolve(1.2)
    d "........"
    d "지금 너무 편하고 좋은데 잠시만 이러고 있을게요."
    d "딱 5분만요...."
    m "하아....."
    m "제발 [d_name]....."
    scene ch06_orph02_34 at hand_camera with Dissolve(0.8)
    d "....."
    d "난 항상 메리의 체온이 그리웠어요."
    m "........."
    d "제가 보육원을 떠나 아만다의 집에서 살게 됐어도......"
    pause
    d "매일 메리 생각뿐이었다구요...."
    scene ch06_orph02_31 at hand_camera with Dissolve(0.8)
    m "......."
    pause
    d "메리와 손을 잡을 때 그 체온.."
    pause
    d "메리와 포옹 할 때 그 체온..."
    pause
    d "메리의 좋은 향기....."
    pause
    d "나긋나긋한 메리의 목소리.."
    scene ch06_orph02_35 at hand_camera with Dissolve(0.8)
    d "........"
    d "메리도 저의 체온이 좋지 않아요?........"
    d "....."
    m "휴........"
    scene ch06_orph02_31 at hand_camera with Dissolve(0.8)
    n "메리는 그의 말이 진실과 거짓이 섞여 있다는것을 알았다."
    pause
    n "하지만 그녀는 [d_name]의 사탕발림들이 싫지 않았다."
    n "몇년간 그녀는 그녀의 남편으로 부터 그 어떤 달콤한 속삭임이나 그녀를 여자로서 행복을 느끼게할 어떠한 노력도 보지 못했기 때문이다."
    scene ch06_orph02_36 at hand_camera with Dissolve(0.8)
    m "5분만이야 허니.."
    m "난 조금만 자고 일어나서 다시 일해야 해."
    play sound "audio/ambi/fabric05.mp3"
    scene ch06_orph02_37 at hand_camera with Dissolve(0.8)
    d "알겠어요."
    d "5분.."
    scene ch06_orph02_38 at hand_camera with Dissolve(0.8)
    m "뭐?!!"
    d "네?"
    m "바지는 또 언제 벗었데.....참...."
    d "하하"
    d "간절히 원했더니 바지가 사라졌어요 하하."
    scene ch06_orph02_39 at hand_camera with Dissolve(0.8)
    m "그런 바보같은 소리는 뭐야 ㅎㅎ."
    m "간절히 원했더니 바지가 사라졌다니......"
    m "그럼 내 몸살도 사라지게 해줄래? ㅎㅎ"
    pause
    m "아니 내가 20대가 되게 해줄래?"
    scene ch06_orph02_40 at hand_camera with Dissolve(1.2)
    pause
    d "메리는 그 어떤 여자보다도 아름다워요."
    pause
    d "지금 메리 모습이 이 세상에서 제일 아름다워요."
    scene ch06_orph02_41 at hand_camera with Dissolve(1.2)
    pause
    play voice_f "audio/sex/kissshort01.mp3"
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
        $ add_point("love_mary", 1, "love_mary")
    scene ch06_orph02_42 at hand_camera with Dissolve(0.8)
    m "으음....."
    scene ch06_orph02_43 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_44 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_orph02_44-02 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/kissshort02.mp3"
    scene ch06_orph02_44-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_45 at hand_camera with Dissolve(1.0)
    m "..........."
    m "맙소사 나 지금 뭐하는거지...."
    pause
    m "우린 이러면 안돼....."
    d "왜 안된다는거에요??"
    m "......."
    m "우리가 언제부터 이랬다고......"
    scene ch06_orph02_46 at hand_camera with Dissolve(0.8)
    pause
    d "나와 같이 있는게 좋지 않은거에요?"
    m "..........."
    m "아니 나도 너와 같이 있는게 좋아."
    d "그런데 왜....."
    scene ch06_orph02_45 at hand_camera with Dissolve(0.8)
    m "..........."
    m "근데 너도 알잖아..."
    m "이건 너와 나 다 위험해지는 짓들이야....."
    d "아니 그렇지 않아요."
    scene ch06_orph02_46 at hand_camera with Dissolve(0.8)
    d "........"
    d "내가 좋은거 처럼 메리도 저와 함께 있는게 좋았으면 해요....."
    d "메리가 절 남자로 봐줬으면 해요...."
    d "메리를 사랑해줄 남자로 말이에요..."
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_orph02_48 at hand_camera with Dissolve(0.8)
    m "!!"
    scene ch06_orph02_49 at hand_camera with Dissolve(0.8)
    m "하지마 허니...."
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_orph02_49-02 at hand_camera with Dissolve(0.8)
    pause
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_orph02_50 at hand_camera with Dissolve(0.8)
    d "왜요?...."
    d "이렇게 하면 싫어요?"
    pause
    m "........"
    pause
    d "이보다 더 한 것도 했잖아요...."
    pause
    d "메리는 날 입으로 해줬잖아요...."
    d "난 메리의 보지를..."
    scene ch06_orph02_52 at hand_camera with Dissolve(0.8)
    m "그거랑은 달라...."
    d "........."
    d "아니 뭐가 다르다는거에요? 네?"
    pause
    d "전 정말 메리의 말들이 이해가 안되요..."
    pause
    m "뭐랄까 그것들은 그냥 해프닝이었어.."
    d "......"
    d "그게 무슨 말이에요?"
    m "하...설명하기 힘들어."
    m "........"
    m "너도 알잖아 그냥 일어난 일이야."
    pause
    m "니가 너무 애원해서 어쩌다보니 일어난 일이라고."
    m "무슨 말인지 알아?"
    pause
    m "그냥 니가 안쓰러워서 니 부타을 들어준거 뿐이야."
    d "원나잇 같은 뭐 그런거였다는거에요?"
    pause
    m "맙소사........."
    scene ch06_orph02_50 at hand_camera with Dissolve(0.8)
    d "........."
    pause
    d "전 그저 메리를 행복하게 해주고 싶을 뿐이에요."
    scene ch06_orph02_52 at hand_camera with Dissolve(0.8)
    m "아니야.."
    m "....."
    m "내 삶은 지금도 충분히 행복해."
    pause
    d "정말이에요?"
    scene ch06_orph02_46 at hand_camera with Dissolve(0.8)
    m "........"
    m "허니..."
    pause
    m "........"
    m "나의 가정에 대한 이야기는 하지마."
    pause
    m "그건 넘지 말아야 할 선이야."
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_orph02_53 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_54 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_55 at hand_camera with Dissolve(0.8)
    pause
    image ch06_orph02_thigh01:
        "ch06_orph02_54" with dissolve
        0.9
        "ch06_orph02_55" with dissolve
        0.9
        repeat
    scene ch06_orph02_thigh01 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_mary", 1, "love_mary")
    n "그는 메리의 팔뚝을 부드럽게 쓰다듬었다."
    pause
    n "이 행위는 오히려 열정적인 키스보다 메리가 그에게 사랑받고 있다는 감정이 싹트게 만들었다."
    scene ch06_orph02_56 at hand_camera with Dissolve(0.8)
    m "!!!"
    menu:
        n "What should I do?"
        "메리의 팬티를 벗긴다.":
            scene ch06_orph02_57 at hand_camera with Dissolve(0.8)
            pause
            scene ch06_orph02_58 at hand_camera with Dissolve(0.8)
            m "헤이!"
    scene ch06_orph02_59 at hand_camera with Dissolve(0.8)
    m "나 화낸다 아저씨?!!"
    m "여기서 이러면 진짜 큰 일 나!!"
    m "내가 하지말라는데 왜 자꾸 그래?"
    play sound "audio/ambi/fabric05.mp3"
    scene ch06_orph02_60 at hand_camera with Dissolve(0.8)
    d "사랑해요 메리.."
    d "사랑한다구요!!"
    scene ch06_orph02_60-02 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!"
    d "메리와 같이 있으면 미칠거 같아요...."
    pause
    d "내 사랑을 받아주세요!!"
    m "뭐 하는거야???!!"
    scene ch06_orph02_60-03 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_orph02_61 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!!!!!"
    scene ch06_orph02_62 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
    scene ch06_orph02_63 at hand_camera with Dissolve(0.8)
    m "맙소사...."
    m "....."
    m "너 정말 내가 아는 그 [d_name]맞니?"
    m "어서 내 [d_name]을 돌려줘..."
    scene ch06_orph02_64 at hand_camera with Dissolve(0.8)
    d "전 메리가 아는 그 [d_name] 맞아요."
    pause
    d "단지......"
    pause
    d "단지 이제 조금 더 메리를 내 여자로 만들고 싶을 뿐이에요."
    scene ch06_orph02_65 at hand_camera with Dissolve(0.8)
    m "맙소사...."
    m "....."
    m "그래서 이제 뭐 어쩔려고?........"
    $ renpy.pause(3.0, hard=True)
    m "오늘 정말 나와 관계를 망칠 생각이야?"
    scene ch06_orph02_66 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort02.mp3"
    pause
    scene ch06_orph02_66-02 at hand_camera with Dissolve(0.8)
    m "흐응....."
    scene ch06_orph02_67 at hand_camera with Dissolve(0.8)
    m "가...간지러워....."
    n "그의 입이 그녀의 허벅지에 닿자 그녀의 하체에 닭살이 돋았다."
    pause
    n "그녀는 점점 [d_name]이 만든 수렁에 빠져들고 있었다."
    scene ch06_orph02_68 at hand_camera with Dissolve(0.8)
    m "우리는 이러면 안돼...."
    d "그런 말 하지말아요 메리."
    d "메리가 나의 자지를 빠는건 되구요??"
    m "........."
    d "메리가 저에게 해줬으니 이제 제 차례에요."
    scene ch06_orph02_69 at hand_camera with Dissolve(0.8)
    d "그냥 편히 누워서 느끼세요."
    d "내가 기분좋게 해줄게요."
    play music "audio/bgm/erotic10.mp3" volume 1.5
    scene ch06_orph02_70 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    m "으음....."
    play voice_f  "audio/sex/fmoanshort07.mp3"
    pause
    d "메리의 얕은 신음소리가 듣기 좋아요....."
    m "가...간지러워..."
    d "네 그렇게..."
    d "그냥 느끼기기만 해요."
    scene ch06_orph02_71 at hand_camera with Dissolve(0.8)
    m "흐응....."
    scene ch06_orph02_70 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_71 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_72 at hand_camera with Dissolve(0.8)
    m "하아...."
    m "부끄러워.."
    d "괜찮아요."
    d "그냥 편히 누워서 제가 뭘하는지만 느끼면 돼요.."
    pause
    d "이 순간은 제가 메리의 연인이에요."
    scene ch06_orph02_73 at hand_camera with Dissolve(0.8)
    n "그녀는 어느샌가 자신도 모르게 [d_name]의 말에 따르고 있었다."
    pause
    n "그것은 그의 말의 권위 때문이 아니라 그녀가 느끼는 몸의 쾌감 때문이었다."
    scene ch06_orph02_74 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_75 at hand_camera with Dissolve(0.8)
    pause
    d "메리의 보지...."
    pause
    d "깨끗하네요?"
    m "...."
    d "메리도 아만다처럼 주기적으로 왁싱하는거에요?"
    m "........"
    m "아...아만다?......"
    menu:
        n "What should I do?"
        "메리의 항문을 빤다.":
            play sound "audio/sex/liquid01.mp3"
            scene ch06_orph02_78 at hand_camera with Dissolve(0.8)
            if not in_replay:
                $ add_point("lust_mary", 1, "lust_mary")
            m "!!!!!!!!!!!!!!!!"
            m "아학!!!!!"
    scene ch06_orph02_77 at hand_camera with Dissolve(0.8)
    play voice_f  "audio/sex/fmoanshort04.mp3"
    m "흐윽!!"
    scene ch06_orph02_79 at hand_camera with Dissolve(0.8)
    m "음........."
    m "하...하지마..."
    m "아아.............."
    scene ch06_orph02_80 at hand_camera with Dissolve(0.8)
    d "메리...."
    pause
    d "제가 대학교에서 고향으로 오는 버스에 무슨 생각한줄 알아요?..."
    scene ch06_orph02_81 at hand_camera with Dissolve(0.8)
    m "..........."
    pause
    d "바로 이 모습이에요....."
    d "제가 이렇게 메리의 항문을 먹는 모습이요."
    m "........."
    m "그...그런말 하지마.."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_82 at hand_camera with Dissolve(0.8)
    d "메리는 이런 일이 일어날줄 단 한번이라도 생각한적있어요?"
    m "........."
    d "너무 흥분돼서 심장이 터질거 같아요...."
    pause
    d "저의 상상이 현실이 되다니....."
    image ch06_orph02_lick01:
        "ch06_orph02_80" with dissolve
        0.7
        "ch06_orph02_81" with dissolve
        0.7
        "ch06_orph02_80" with dissolve
        0.7
        "ch06_orph02_81" with dissolve
        0.7
        "ch06_orph02_82" with dissolve
        0.7
        "ch06_orph02_81" with dissolve
        0.7
        repeat
    play voice_f  "audio/sex/fmoanlong03.mp3"
    scene ch06_orph02_lick01 at hand_camera with Dissolve(0.8)
    m "아.................."
    pause
    m "아학......."
    stop voice_f fadeout 1.0
    scene ch06_orph02_83 at hand_camera with Dissolve(0.8)
    d "이렇게 엉덩이를 더 들어봐요."
    m "!!!"
    pause
    m ".........."
    scene ch06_orph02_84 at hand_camera with Dissolve(0.8)
    pause
    d "젠장....."
    pause
    d "메리의 보지와 항문은 정말 아름다워요..."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_85 at hand_camera with Dissolve(0.8)
    m "하아......."
    m "흑!!"
    d ".........."
    d "메리 지금 엄청 젖었어요...."
    d "저때문에 메리가 젖었다구요.."
    m "그...그런말 하지마.."
    m "하아......."
    scene ch06_orph02_86 at hand_camera with Dissolve(0.8)
    m "그...그냥 생리 현상이야....."
    pause
    m "기분 좋아서 이렇게 된게 아니라고..."
    m "흐윽!!"
    pause
    m "이건 일어나선 안되는 일이야..."
    m "그만해 허니..."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_86-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_mary", 1, "lust_mary")
    m "!!!!!!!!!!!!"
    m "그렇게 하지마...."
    d "하...메리....."
    pause
    d "나의 선생님..."
    scene ch06_orph02_86-03 at hand_camera with Dissolve(0.8)
    n "그가 메리의 음부를 벌리자 그녀의 음부 안으로 공기의 흐름이 느껴졌다."
    n "그녀는 성적인 흥분에 강하게 휩쌓여 갔다."
    scene ch06_orph02_86-04 at hand_camera with Dissolve(0.8)
    n "자신보다 한찬 어린 남성에게 마음대로 다뤄지는 것은 흥분이자 치욕이었다."
    pause
    n "그녀는 [d_name]과 이런 행위를 하게된 근본적인 이유를 찾으려 생각했지만 찾을 수 없었다."
    menu:
        n "What should I do?"
        "나의 팬티를 벗는다.":
            scene ch06_orph02_87 at hand_camera with Dissolve(0.8)
            pause
            n "그는 자신의 시선을 그녀의 음부에 고정한채 조심히 그의 팬티를 벗었다."
    scene ch06_orph02_88 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_89 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/phonevib.mp3"
    scene ch06_orph02_90 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!!!!!"
    stop sound
    scene ch06_orph02_91 at hand_camera with Dissolve(0.8)
    m "안녕 여보(전화통화)."
    m "......"
    pause
    scene ch06_orph02_91-02 at hand_camera with Dissolve(0.8)
    m "아니 사무실에 있어."
    m "........"
    m "응. 컴퓨터 앞이지."
    pause
    m "그래 잠깐만."
    scene ch06_orph02_92 at hand_camera with Dissolve(0.8)
    m "**(맙소사....)**"
    m "**(심장마비걸리는줄......)**"
    play sound "audio/ambi/dooropen.mp3"
    scene ch06_orph02_93 at hand_camera with Dissolve(0.8)
    m "아 좀 잠깐 기다리라니까 지금 보려고 하잖아."
    d "........."
    scene ch06_orph02_94 at hand_camera with Dissolve(0.8)
    pause
    m "내 컴에선 정상적으로 보여."
    pause
    m "........."
    m "응 제대로 보인다니까."
    scene ch06_orph02_95 at hand_camera with Dissolve(0.8)
    d "............."
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_96 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_97 at hand_camera with Dissolve(0.8)
    d "**(맙소사 메리....)**"
    pause
    d "**(당신은 지금 준비 돼 있어요..)**"
    pause
    d "**(무슨 말인지 알아요?)**"
    scene ch06_orph02_97-02 at hand_camera with Dissolve(0.8)
    d "하아....."
    d "**(내 여자가 될 준비가 돼 있다구요.)**"
    d "**(이 밀프하임 출신 고아인 [d_name]만의 여자가 될거라구요.)**"
    scene ch06_orph02_98 at hand_camera with Dissolve(0.8)
    m "그럼 이거 사면 되는거지?"
    pause
    m "알겠어."
    m "그럼 내가 주문할게."
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_99 at hand_camera with Dissolve(0.8)
    m "!!!!!!!!!!!!"
    scene ch06_orph02_100 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/erotic01.mp3"
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_101 at hand_camera with Dissolve(0.8)
    m "아흥......."
    d "**(젠장.)**"
    pause
    d "**(그녀의 보지를 빨고 싶은데 각이 안나오네.)**"
    play voice_f "audio/sex/fmoanshort05.mp3"
    m "하앙!!!"
    scene ch06_orph02_102 at hand_camera with Dissolve(0.8)
    m "아..아니야."
    m "가..갑자기 벌레가 날아들어서 놀라서 그랬어."
    pause
    pause
    m "아니 지금 사무실에서 일하고 있는데 무슨 소리야 그게?!!"
    pause
    m "아 미친소리좀 하지마!!"
    m "여기 남자 직원 없다고 내가 몇번을 말해!!!"
    scene ch06_orph02_103 at hand_camera with Dissolve(0.8)
    pause
    m "그래. 알겠어."
    pause
    m "저녁에 봐."
    pause
    m "사랑해."
    scene ch06_orph02_104 at hand_camera with Dissolve(0.8)
    m ".........."
    play voice_f "audio/voices/fsigh06.mp3"
    m "하아.........."
    pause
    n "그녀의 성기에 지금까지와는 다른 열기가 느껴졌다."
    pause
    n "그것은 손가락도, 사람의 얼굴에서 나오는 열기가 아니었다."
    play sound "audio/ambi/touch02.mp3"
    scene ch06_orph02_105 at hand_camera with Dissolve(0.8)
    pause
    n "그녀는 본능적으로 그것이 남성의 성기라는 것을 알수 있었다."
    pause
    n "그는 자신의 성기를 조심스럽게 그녀의 질 입구로 가져다대었다."
    scene ch06_orph02_106 at hand_camera with Dissolve(0.8)
    m ".........."
    pause
    m "너 진짜..."
    scene ch06_orph02_107 at hand_camera with Dissolve(0.8)
    m "뭐야 그게?....."
    m "...."
    pause
    m "지금 여기서 그렇게 끝장을 보려는거야?"
    scene ch06_orph02_108 at hand_camera with Dissolve(0.8)
    m "........."
    m "맙소사 [d_name]..."
    m "그런거야??"
    d "네??"
    pause
    m "너에게 섹스가 그저 한낱 들이밀고 넣으면 끝인 게임이니??!!!"
    scene ch06_orph02_109 at hand_camera with Dissolve(0.8)
    d "아...아니......"
    m "아니긴 뭐가 아니야!!!"
    m "니가 지금 그러고 있잖아."
    pause
    m "내가 길거리 창녀아??!!!!"
    m "내가 섹스인형이냐고?!!!!"
    scene ch06_orph02_109-02 at hand_camera with Dissolve(0.8)
    d "아..아니요...."
    play voice_f "audio/voices/fsigh06.mp3"
    m "하.........."
    pause
    m "미치겠다 정말....."
    scene ch06_orph02_109-03 at hand_camera with Dissolve(0.8)
    m "널 정말 어떻게 해야할까....."
    pause
    m "너 정말 나에게 너무한다고 생각안하니??"
    scene ch06_orph02_106 at hand_camera with Dissolve(0.8)
    m ".........."
    m "허니...."
    scene ch06_orph02_110 at hand_camera with Dissolve(0.8)
    d "네?..."
    scene ch06_orph02_111 at hand_camera with Dissolve(0.8)
    d "무..문 잠그라고요?"
    m "뭐?!!"
    scene ch06_orph02_112 at hand_camera with Dissolve(0.8)
    m "[d_name]!!!!!!!!!!!"
    pause
    d ".........."
    m "너 정말 직원들 다 있는 이 건물에서 이게 가능하다고 생각해?!!!"
    m "하아...."
    m "날 곤란에 처하게 하고 싶은거야?!!!"
    scene ch06_orph02_113 at hand_camera with Dissolve(0.8)
    d "아..아니에요 그건...."
    pause
    d "하지만 전......"
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_114 at hand_camera with Dissolve(0.8)
    m ".........."
    d "메..메리의 기분을 좋게 해주고...."
    m "그만!!"
    scene ch06_orph02_115 at hand_camera with Dissolve(0.8)
    m "그만해!!"
    m "그놈에 기분 타령 정말!!!!!"
    m "한 마디만 더 하면 영원히 우리 관계는 끝이야."
    d "..........."
    m "어서 옷 입고 나가."
    scene ch06_orph02_115-02 at hand_camera with Dissolve(0.8)
    d "............"
    pause
    m ".............."
    m "어서 나가."
    play music "audio/bgm/normal13.mp3"
    scene ch06_orph02_116 at hand_camera with Dissolve(1.2)
    pause
    d "알겠어요......"
    scene ch06_orph02_117 at hand_camera with Dissolve(0.8)
    m "그...그리고..."
    m "한가지 알려줄게 있어."
    scene ch06_orph02_118 at hand_camera with Dissolve(0.8)
    d "어떤거요??"
    m "이제 여기 집무실에도 보안카메라 설치할거야."
    d "네??!!!"
    pause
    d "보안 카메라요?"
    scene ch06_orph02_119 at hand_camera with Dissolve(0.8)
    d "여기에 보안카메라를 설치한다고요??!!"
    m "왜 놀라는거야?"
    m "여기에서 범죄라도 저지를 생각이었어?"
    d "아..아니..."
    d "그건 아니지만..."
    scene ch06_orph02_117 at hand_camera with Dissolve(0.8)
    m "셀린이 요즘 주변에 수상한 사람이 보인다고 설치하자고 했어."
    m "내 생각도 그게 나을거 같아."
    m "요즘 동네에 범죄도 많이 일어나잖아."
    d "......."
    d "그...그렇죠...."
    d "저도 뉴스 봤어요...."
    scene ch06_orph02_120 at hand_camera with Dissolve(0.8)
    d "**(젠장 셀린.)**"
    d "**(절묘한 한 수 구나.....)**"
    d "**(꼭 이렇게 해야 속이 시원하냐??!!!!!!!)**"
    d "**(내가 도둑이냐 이년아??!!!!)**"
    scene ch06_orph02_121 at hand_camera with Dissolve(0.8)
    m "나 들어가서 누워 있을거야."
    m "어서 가."
    m "문자 하고."
    m "또 그 고추 사진 보내면 경찰에 신고할거야."
    scene ch06_orph02_122 at hand_camera with Dissolve(0.8)
    d "........."
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_123 at hand_camera with Dissolve(0.8)
    m "!!"
    scene ch06_orph02_124 at hand_camera with Dissolve(0.8)
    m "허니....."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_orph02_125 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_126 at hand_camera with Dissolve(0.8)
    m ".........."
    m "넌 정말 말썽꾸러기구나..."
    scene ch06_orph02_127 at hand_camera with Dissolve(0.8)
    d "사랑해요 메리."
    pause
    d "그냥 하는 말이 아니에요."
    d "전 진심으로 메리를 사랑해요."
    pause
    d "제가 메리를 이렇게 계속 만지는 이유는..."
    pause
    d "메리가 너무 아름다운 여자이기 때문이에요."
    scene ch06_orph02_127-02 at hand_camera with Dissolve(0.8)
    pause
    m "............"
    scene ch06_orph02_128 at hand_camera with Dissolve(0.8)
    m "........"
    pause
    m "화내서 미안해 스위티....."
    pause
    m "나도 널 아끼고 사랑해."
    scene ch06_orph02_129 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_mary", 1, "love_mary")
    play voice_f "audio/sex/kissshort02.mp3"
    pause
    scene ch06_orph02_130 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_orph02_131 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/touch03.mp3"
    scene ch06_orph02_132 at hand_camera with Dissolve(0.8)
    pause
    image ch06_orph02_hug01:
        "ch06_orph02_131" with dissolve
        0.7
        "ch06_orph02_132" with dissolve
        0.7
        repeat
    play sound ["audio/ambi/touch03.mp3", "<silence 0.9>"] loop
    scene ch06_orph02_hug01 at hand_camera with Dissolve(0.8)
    m "........"
    pause
    m "하........"
    stop sound
    scene ch06_orph02_133 at hand_camera with Dissolve(0.8)
    d "아야!!"
    m "넌 정말....."
    scene ch06_orph02_134 at hand_camera with Dissolve(0.8)
    m "어서 나가"
    m "나 진짜 좀 쉬어야 해."
    d "알겠어요."
    d "나간다구요."
    scene ch06_orph02_135 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_orph02_136 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    jump ch06_police01

label ch06_police01:
    if not in_replay:
        $ persistent.unlock_ch06_police01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The Next Dawn" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play sound "audio/ambi/carpass.mp3"


    if not in_replay:
        $ send_phone_message("System", "", "sophia_dm", message_kind=5, do_pause=False)
        $ send_phone_message("sophia", "How've you been?", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Hello, Professor! I've been doing well.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "Good! Enjoying your break? You're not just goofing off, are you?", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Haha. A little bit of both.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I've been having fun and studying, too.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I actually landed an internship at a company and just started working there.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "Oh, that's impressive! What kind of company?", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "A marketing company.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "Well, I imagine your major comes in handy there, doesn't it?", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yeah, haha.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "I already miss my students.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "You should stop by campus sometime.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "I see Jason around every now and then. I guess he's staying in the dorms.", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yeah, he'll be on campus the whole break.", "sophia_dm", do_pause=False)
        $ send_phone_message("sophia", "I see. Anyway, take care of yourself. See you soon!", "sophia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Will do! Thanks for checking in, Professor!", "sophia_dm", do_pause=False)

        $ send_phone_message("System", "", "olivia_dm", message_kind=5, do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "What are you up to?", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "??", "olivia_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "You busy?", "olivia_dm", do_pause=False)

        $ send_phone_message("System", "", "amanda_dm", message_kind=5, do_pause=False)
        $ send_phone_message("Amanda", "images/phone/media/V06_amanda01.jpg", "amanda_dm", 2, summary_alt="amanda Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "OH MY GOD!!!! What's this?!", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "😂", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "Kate and I are picking out some lingerie! Hahaha.", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "Sorry for giving you a heart attack.", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Oh my God.", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "Want more pictures?", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "YES!!!! SHOW ME MORE!!!!", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "images/phone/media/V06_amanda02.jpg", "amanda_dm", 2, summary_alt="amanda Photo", do_pause=False)
        $ send_phone_message("Amanda", "images/phone/media/V06_amanda03.jpg", "amanda_dm", 2, summary_alt="amanda Photo", do_pause=False)
        $ send_phone_message("Amanda", "Wanna see some nudes?", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "YES!!!!!!!!!!!!!!", "amanda_dm", do_pause=False)
        $ send_phone_message("Amanda", "In your dreams.", "amanda_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "😭", "amanda_dm", do_pause=False)

        $ send_phone_message("System", "", "beth_dm", message_kind=5, do_pause=False)
        $ send_phone_message("Beth", "I quit that job ages ago! Why the hell are you asking me to do that? Just leave me alone!", "beth_dm", do_pause=False)
        $ send_phone_message("Beth", "I only got my cast off recently, and I'm still having trouble getting around.", "beth_dm", do_pause=False)
        $ send_phone_message("Beth", "Please stop bringing up the past!!!!!", "beth_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "????", "beth_dm", do_pause=False)
        $ send_phone_message("Beth", "Oh my God, I'm so sorry!!!", "beth_dm", do_pause=False)
        $ send_phone_message("Beth", "Wrong person! I'm so sorry.", "beth_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "It's okay!! Don't worry about it!", "beth_dm", do_pause=False)

        $ send_phone_message("System", "", "celine_dm", message_kind=5, do_pause=False)
        $ send_phone_message("Celine", "Fucking pervert.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "What the hell is your problem now?", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "A fucking pervert with an innocent face.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Ha! Keep it up and I'm gonna spank your ass.", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "Go ahead and spank me, you fucking pervert.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "You've seen my big stick, right? You're gonna regret it.", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "What big stick are you talking about, you fucking pervert?", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "images/phone/media/V06_celine01.jpg", "celine_dm", 2, summary_alt="Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "You've seen my big stick, right? You're gonna regret it.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Shit, I'm sorry.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Please delete that picture.", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "????", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "Are you fucking insane?!!!!", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "WTF is wrong with you, asshole?!!!!", "celine_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "I'm sorry. I got way too carried away.", "celine_dm", do_pause=False)
        $ send_phone_message("Celine", "Go to hell.", "celine_dm", do_pause=False)

        $ send_phone_message("System", "", "jason_dm", message_kind=5, do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/V06_jason01.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message("Jason", "images/phone/media/V06_jason02.jpg", "jason_dm", 2, summary_alt="jason Photo", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "You're with them???!!!", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Just so you know, I'm about to have a great time with these two lovely ladies.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "You know my dick could handle both of these women at once, right?", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Yeah, fucking right. LMAO.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Shit. I ran into the professors on campus, and now I'm about to get dragged into a debate.", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Should've just stayed in my dorm playing video games.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Hahaha. Have fun with the ladies!", "jason_dm", do_pause=False)
        $ send_phone_message("Jason", "Bro, come hang out here. I'm bored as fuck.", "jason_dm", do_pause=False)
        $ send_phone_message(phone_config["phone_player_name"], "Alright, I'll be there soon.", "jason_dm", do_pause=False)

    scene ch06_police01_01 at hand_camera with Dissolve(1.2)
    pause
    play ambient "audio/ambi/city04.mp3" loop
    scene ch06_police01_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_05 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_05-02 at hand_camera with Dissolve(0.8)
    unknownm "......."
    unknownm "뭐야 저거..."
    pause
    unknownm "사람이 보이는거 같은데 자는건가??"
    scene ch06_police01_06 at hand_camera with Dissolve(0.8)
    pause
    unknownm "......."
    unknownm "에어컨 키고 자고있는거 아냐?"
    scene ch06_police01_07 at hand_camera with Dissolve(1.2)
    unknownm "어디다 뒀었나...."
    pause
    unknownm "여기있구나."
    play music "audio/bgm/sus08.mp3"
    scene ch06_police01_08 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_09 at hand_camera with Dissolve(0.8)
    unknownm "저기 안녕하세요."
    pause
    unknownm "자는 거에요??"
    scene ch06_police01_10 at hand_camera with Dissolve(0.8)
    unknownm "무슨 문제 있어요??"
    pause
    unknownm "........."
    scene ch06_police01_11 at hand_camera with Dissolve(0.8)
    unknownm "저기 아저씨."
    unknownm "....."
    unknownm "자고있는건가?"
    scene ch06_police01_11-02 at hand_camera with Dissolve(0.8)
    pause
    unknownm "뭐야 문 다 닫아놓고 자는거야?..."
    pause
    scene ch06_police01_12 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/hit02.mp3"
    unknownm "Fuck!!!!!!"
    scene ch06_police01_13 at hand_camera with Dissolve(0.8)
    unknownm "......."
    unknownm "뭐야이거....."
    unknownm "젠장."
    scene ch06_police01_14 at hand_camera with Dissolve(0.8)
    unknownm "........"
    unknownm "젠장 오늘 일진 사납겠네......."
    stop ambient fadeout 1.0
    play music "audio/ambi/clock01.mp3"
    scene ch06_police01_15 at hand_camera with Dissolve(1.5)
    pause
    scene ch06_police01_16 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_17 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_18 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_18-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_19 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/phonering02.mp3" loop
    scene ch06_police01_19-02 at hand_camera with Dissolve(0.8)
    pause
    n "정적이 흐르는 다이애나의 방에 정체된 공기를 흔드는 전화벨 소리가 울렸다."
    scene ch06_police01_20 at hand_camera with Dissolve(0.8)
    n "그녀는 시간의 흐름을 인지하지 못한채 잠에서 깨어났다."
    pause
    scene ch06_police01_21 at hand_camera with Dissolve(0.8)
    di "흐응....."
    stop sound
    scene ch06_police01_22 at hand_camera with Dissolve(0.8)
    di "네 다이...."
    pause
    di "네 다이애나입니다....."
    scene ch06_police01_23 at hand_camera with Dissolve(0.8)
    pause
    n "전화기에선 분주히 말하는 사람들 목소리와 경찰차의 사이렌 소리가 들려왔다."
    scene ch06_police01_24 at hand_camera with Dissolve(0.8)
    pause
    n "그녀는 잠에 취해 누워서 전화기에서 나오는 에단의 말을 듣고 있었다."
    scene ch06_police01_24-02 at hand_camera with Dissolve(0.8)
    di ".........."
    di "알겠어요."
    pause
    di "바로 갈게요."
    scene ch06_police01_24 at hand_camera with Dissolve(0.8)
    pause
    di "흐응....."
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_police01_25 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_26 at hand_camera with Dissolve(0.8)
    di "젠장....."
    di "간만에 꿀잠자고 있었는데...."
    di "하아....."
    scene ch06_police01_27 at hand_camera with Dissolve(0.8)
    di "......."
    pause
    di ".........."
    di "일어나자 다이애나...."
    pause
    di ".........."
    pause
    di "일어나자!!"
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_police01_28 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_29 at hand_camera with Dissolve(0.8)
    di "몇시야 지금...."
    stop music
    scene ch06_police01_30 at hand_camera with Fade(0.8, 1.0, 1.8)
    play ambient "audio/ambi/city04.mp3" loop
    pause
    scene ch06_police01_31 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_32 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_33 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_34 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/cararrival.mp3"
    scene ch06_police01_35 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_35-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_36 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/cardooropen.mp3"
    scene ch06_police01_37 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/cardoorclose.mp3"
    scene ch06_police01_37-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_38 at hand_camera with Dissolve(0.8)
    eth "안녕하세요 팀장님(새벽시간)."
    di "지금 상황이 어때?"
    di "차량 조회 했지?"
    eth "네 했습니다."
    di "보고 해."
    scene ch06_police01_39 at hand_camera with Dissolve(0.8)
    eth "일단 차량 주인과 사망자는 일치합니다."
    eth "정식 등록 된 차량이고요."
    eth "사망자는 다니엘 리드, 62세. 지질학자 입니다."
    scene ch06_police01_40 at hand_camera with Dissolve(0.8)
    di "지질학자?"
    eth "네."
    eth "대학교 교수 였고 작년에 은퇴했다고 합니다."
    scene ch06_police01_41 at hand_camera with Dissolve(0.8)
    eth "일단 보이는 걸로는 머리에 총상으로 인한 사망입니다."
    eth "차안에 총기와 유서도 있고요."
    eth "지금까지는 자살로 보입니다."
    di "파손이나 싸움의 흔적도 없고?"
    eth "네."
    eth "차량이 습격을 받거나 강제로 문이 열린 흔적도 없고요."
    eth "유리나 다른 곳에 눈에 띄는 파손 흔적도 없습니다."
    scene ch06_police01_42 at hand_camera with Dissolve(0.8)
    di "............"
    di "복잡한건 없어보이네."
    eth "네 그렇습니다."
    scene ch06_police01_43 at hand_camera with Dissolve(1.2)
    di "몇 달째 제대로 쉬지 못했다고 들었는데..."
    di "새벽부터 또 고생하네."
    eth "아닙니다ㅎㅎ."
    eth "괜찮습니다."
    eth "이게 제 일이니까요."
    scene ch06_police01_44 at hand_camera with Dissolve(1.2)
    di "크음..."
    scene ch06_police01_45 at hand_camera with Dissolve(1.2)
    di "............"
    scene ch06_police01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_47 at hand_camera with Dissolve(0.8)
    di "저기는?"
    di "저 화장실 확인 해봤어?"
    scene ch06_police01_48 at hand_camera with Dissolve(0.8)
    eth "육안으로는 별다른 특이한건 없었습니다."
    eth "이 곳 관리 업체는 파악했습니다."
    eth "날 밝는대로 Evan이 업체에서 영상 받기로 했습니다."
    di "그래 좋아."
    scene ch06_police01_49 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_police01_50 at hand_camera with Dissolve(0.8)
    di "..........."
    pause
    di "젠장..."
    scene ch06_police01_51 at hand_camera with Dissolve(0.8)
    di "**(이런건 수십번을 봐도 적응이 안되네...)**"
    di "............"
    di "**(명복을 빕니다 아저씨..)**"
    pause
    di "**(무슨 일이 있었는지는 이제부터 알아봐야 겠지만..)**"
    scene ch06_police01_52 at hand_camera with Dissolve(0.8)
    n "그녀는 그녀가 평생을 익히고 배워왔던대로 사건 현장을 조사했다."
    scene ch06_police01_53 at hand_camera with Dissolve(0.8)
    di "............"
    n "그녀는 막힘 없이, 그리고 능숙하게 곳곳을 확인했다."
    scene ch06_police01_54 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_55 at hand_camera with Dissolve(0.8)
    n "그녀의 잠기운은 온데간데 없었고 날카로운 형사의 모습으로 바뀌어 있었다."
    scene ch06_police01_56 at hand_camera with Dissolve(1.1)
    pause
    scene ch06_police01_57 at hand_camera with Dissolve(0.8)
    pause
    eth "......."
    di "자세가 바뀐건 아니지?"
    pause
    eth "자세라니요?"
    di "시신은 목격자가 발견했을 때 그대로지?"
    scene ch06_police01_58 at hand_camera with Dissolve(0.8)
    eth "아......."
    pause
    eth "네 맞습니다."
    di "......."
    scene ch06_police01_57 at hand_camera with Dissolve(0.8)
    eth "..........."
    scene ch06_police01_58-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_57 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_58-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_58-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_59 at hand_camera with Dissolve(0.8)
    di "신고자 신원은?"
    eth "네?"
    pause
    eth "아....신고자는..."
    scene ch06_police01_60 at hand_camera with Dissolve(0.8)
    eth "........."
    pause
    eth "신고자는 트럭 운전수 입니다."
    eth "52세,제이크 햇필드."
    eth "심문했고 별다른건 없었습니다."
    eth "배송일정도 있고 해서 일단 신분확인하고 연락처 받고 보냈습니다."
    di "알겠어."
    scene ch06_police01_61 at hand_camera with Dissolve(0.8)
    di "......."
    scene ch06_police01_62 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_63 at hand_camera with Dissolve(0.8)
    pause
    di "..........."
    scene ch06_police01_64 at hand_camera with Dissolve(0.8)
    di "흐음....."
    scene ch06_police01_65 at hand_camera with Dissolve(1.2)
    eth "뭔가 찾으셨어요?"
    eth "제가 봤을땐 특별한건 없었어요."
    eth ".........."
    eth "그래서 팀장님에게 연락 안하려다 이 동네 오시고 첫 사건이기도 해서 그냥 연락드린겁니다."
    scene ch06_police01_66 at hand_camera with Dissolve(0.8)
    di "뭔가 부자연스러워."
    eth "네??"
    eth "........"
    eth "부자연스럽다고요?"
    pause
    eth "어떤게요?"
    scene ch06_police01_67 at hand_camera with Dissolve(0.8)
    pause
    di "..........."
    scene ch06_police01_68 at hand_camera with Dissolve(0.8)
    di "유서 종이의 방향이 사망자 쪽이야."
    scene ch06_police01_57 at hand_camera with Dissolve(0.8)
    eth "..........."
    scene ch06_police01_69 at hand_camera with Dissolve(0.8)
    eth "........."
    eth "그게 왜 이상하다는거에요?"
    di "........."
    di "생각해봐."
    scene ch06_police01_71 at hand_camera with Dissolve(0.8)
    di "죽기전에 마지막으로 유서를 보고 조수석에 던져놨다면..."
    pause
    di "문서의 머리 부분이 바깥을 향하는게 자연스럽지 않겠어?"
    scene ch06_police01_72 at hand_camera with Dissolve(0.8)
    eth "흐음......"
    eth "그냥 차에 타면서 대강 던져 놓은거 아닐까요?"
    di ".........."
    scene ch06_police01_73 at hand_camera with Dissolve(0.8)
    di "그럴수도 있지만 이렇게 올려놓고 여기까지 운전해 오진 않았을거야."
    di "차에 타면서 조수석에서 던져놨다면 조주석위에 올려놨겠지."
    di "이렇게 불편하고 두고 운전하진 않았겠지."
    pause
    di "그리고 이걸 봐."
    di "유서의 위치가 시신과 너무 가까워."
    eth "........."
    pause
    di "사람의 팔길이를 감안하면 너무 자신의 몸과 가깝잖아."
    di "너무 인위적이야."
    di "그러니까 조수석에서든 운전석에서든 이 종이를 내려놓을때 모두 조수석에 내려놓는게 자연스러워."
    eth "음...정말 그러네요."
    di "이건 누군가 조수석에서 유서를 확인하고 올려놓고 떠난거 같아."
    pause
    di "창문이 깨지지 않은것도 총이 발사 된 후 창문이 올라간걸로 보이고."
    di "이 더운 날씨에 창문을 열어놓고 장시간 차안에서 범인과 피해자가 대화했을거야 아마."
    scene ch06_police01_74 at hand_camera with Dissolve(0.8)
    di "그리고 이 장소도 부자연스러워."
    di "그렇지 않아?"
    pause
    di "......"
    scene ch06_police01_75 at hand_camera with Dissolve(0.8)
    eth "이 장소가요?"
    eth "......"
    scene ch06_police01_75-02 at hand_camera with Dissolve(1.3)
    eth "음침한게 사람죽기 딱 좋은 장소 같은데...."
    eth "그렇지 않아요?"
    scene ch06_police01_75-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_police01_76 at hand_camera with Dissolve(0.8)
    di "여긴 고속도로 화장실이잖아."
    di "....."
    di "이 사람이 여기에서 자살해야 할 이유가 있었을까?"
    scene ch06_police01_77 at hand_camera with Dissolve(0.8)
    eth ".............."
    eth "그건 사망자만이 아는거 아닐까요?"
    scene ch06_police01_78 at hand_camera with Dissolve(0.8)
    di "그러니까 이상한거라는 거야."
    di "여긴 자살하기 좋은 장소라기보다 누군가 은밀히 만날 수 있는 장소지."
    di "뭐랄까..."
    di "사람 하나 없는 곳보다 피해자를 안심시키고 불러낼 수 있는 장소."
    di "하지만 사람을 죽여도 될 만큼 사람이 없는 순간이 있는 장소."
    scene ch06_police01_79 at hand_camera with Dissolve(0.8)
    pause
    eth "아...."
    di "잘 생각해봐."
    pause
    di "뭔가 부자연스럽다면 그건 인위적인거란 얘기지."
    eth "제가 현장을 너무 단순하게 봤습니다."
    scene ch06_police01_80 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/fsigh06.mp3"
    di "아 허리 아파."
    eth "....."
    scene ch06_police01_80-02 at hand_camera with Dissolve(0.8)
    di "......."
    di "**(맙소사.....)**"
    scene ch06_police01_80-03 at hand_camera with Dissolve(0.8)
    pause
    di "......."
    di "**(진짜???)**"
    pause
    di "**(이 순간에 발기를 한다고??)**"
    di "**(왜?????)**"
    di "........."
    scene ch06_police01_81 at hand_camera with Dissolve(0.8)
    eth "..........."
    di "........"
    scene ch06_police01_82 at hand_camera with Dissolve(0.8)
    eth "공식적으로 살인사건으로 정하신거죠?"
    di "지문이랑 부검 결과 나오면 뭐 확실해지겠지."
    pause
    di "일단 사무실로 가자."
    di "기억이 가장 생생할때 보고서 써야지."
    eth "네 알겠습니다."
    scene ch06_police01_83 at hand_camera with Dissolve(1.3)
    stop ambient fadeout 1.0
    pause
    jump ch06_company01

label ch06_company01:
    if not in_replay:
        $ persistent.unlock_ch06_company01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    scene ch06_company01_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_02 at hand_camera with Dissolve(1.2)
    d "젠장."
    d "첫 출근 엄청 긴장되네..."
    scene ch06_company01_03 at hand_camera with Dissolve(0.8)
    d "이게 직장인의 압박감이라는건지 엄청나네..."
    d "인턴인데 이 정도면 정직원이 되면 엄청나겠는데??"
    pause
    d "아닌가? 익숙해지면 할만하려나?..."
    d "아무튼 엄청 떨리네."
    scene ch06_company01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_05 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_07 at hand_camera with Dissolve(0.8)
    d "굿모닝 [h_name]."
    h "!!!"
    d "저 오늘 첫 출근 합니다 하하하."
    scene ch06_company01_08 at hand_camera with Dissolve(0.8)
    h "지금 나간다구요??"
    d "네ㅎㅎ"
    d "첫 출근이라 엄청 떨려요 하하하."
    scene ch06_company01_09 at hand_camera with Dissolve(0.8)
    h "아침도 안먹고 일하러 가는거에요??"
    h "자전거 타고갈거 아니에요?"
    d "네 자전거타고 가야죠."
    h "그럼 배고파서 일하기 힘들어요."
    d "네 뭐 그렇죠 ㅎㅎ"
    scene ch06_company01_10 at hand_camera with Dissolve(0.8)
    h "내일 부턴 내가 더 일찍 깨울거에요!!"
    d "네??!!"
    d "아니 안그러셔도...."
    h "잠깐 이리 와봐요."
    scene ch06_company01_11 at hand_camera with Dissolve(0.8)
    h "안그러셔도 되긴 뭐가 돼."
    h "내가 깨우면 일어나야지 별수 있어요? 하하."
    scene ch06_company01_11-02 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "그럼 살살 깨워주세요."
    scene ch06_company01_12 at hand_camera with Dissolve(0.8)
    d "!!!"
    h "자 먹어요."
    scene ch06_company01_12-02 at hand_camera with Dissolve(0.8)
    d "우웁!!"
    play voice_f "audio/voices/flaugh02.mp3"
    h "하하하."
    h "왜 그렇게 놀라고 그래요."
    h "독 들어있는게 아니고 체리일 뿐이에요."
    scene ch06_company01_13 at hand_camera with Dissolve(0.8)
    d "**(젠장....)**"
    d "**(이거 느낌 새롭네.....)**"
    d "**(내가 마치 그녀의 남편이 된 기분이야 ㅎㅎㅎ)**"
    d "**(남편의 출근을 챙겨주는 아내....)**"
    scene ch06_company01_14 at hand_camera with Dissolve(0.8)
    h "ㅎㅎㅎ"
    h "이러니까 내가 [d_name]의 엄마가 된거 같네요."
    scene ch06_company01_15 at hand_camera with Dissolve(0.8)
    d "흐음..."
    d "전 [h_name]이 먹여주니 부부가 된거 같은데요? ㅎㅎㅎ"
    scene ch06_company01_16 at hand_camera with Dissolve(0.8)
    h "**(부부???)**"
    h "**(하 참..부부라니....)**"
    h "**(이런 오글거리는 소릴 잘도 하네.)**"
    scene ch06_company01_17 at hand_camera with Dissolve(0.8)
    h "첫 출근인데 너무 긴장하지 말고 잘해요."
    h "자전거 조심히 타구요. 알았죠?"
    scene ch06_company01_17-02 at hand_camera with Dissolve(0.8)
    d "네 알겠습니다."
    scene ch06_company01_18 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_19 at hand_camera with Dissolve(1.2)
    pause
    n "그들은 잠시 서로를 말 없이 바라보았다."
    pause
    n "그들은 서로가 무언가 말하길 기다렸다."
    n "그리고 [d_name]은 자신도 모르게 상황을 어색하게 끌고가버렸다."
    play music "audio/bgm/sus01.mp3"
    scene ch06_company01_20 at hand_camera with Dissolve(0.8)
    d "추...출근하는 남편에게..."
    d "키...키스 해주는게 이...일반적인....."
    d "**(젠장 나 지금 무슨소리 하는거냐!!!)**"
    scene ch06_company01_21 at hand_camera with Dissolve(0.8)
    h "네??!!"
    h "키..키스??..."
    scene ch06_company01_20 at hand_camera with Dissolve(0.8)
    d "네......"
    d "그 저......"
    pause
    d "[h_name]이 키스해주면 더 힘이 날거 같아서요...."
    scene ch06_company01_22 at hand_camera with Dissolve(0.8)
    h "아..........."
    h "그...그래요?..."
    h "**(내가 키스해주면 더 힘이 날거 같다니....)**"
    h "**(너무 속보이는 말이잖아.)**"
    scene ch06_company01_23 at hand_camera with Dissolve(0.8)
    h "!!!!!"
    scene ch06_company01_24 at hand_camera with Dissolve(0.8)
    h "**(맙소사 이 애 뭐하는거야???)**"
    h "**(어떡하지???!!!!)**"
    scene ch06_company01_25 at hand_camera with Dissolve(0.8)
    h "**(으으....)**"
    n "[d_name]은 용기를 내어 그녀에게 가까이 다가갔다."
    n "그의 심장은 밖으로 튀어나올 정도로 쿵쾅거렸다."
    menu:
        n "What should I do?"
        "그녀의 입술에 키스한다.":
            scene ch06_company01_26 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/kissshort02.mp3"
            n "쪽!(키스하는 의성어)"
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
                $ add_point("love_helen", 1, "love_helen")
    scene ch06_company01_27 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic06.mp3" volume 0.6
    pause
    scene ch06_company01_28 at hand_camera with Dissolve(0.8)
    h "이..이런..."
    h "ㅎㅎㅎ"
    h "일 잘하고 저...저녁에 봐요 ㅎㅎㅎ"
    scene ch06_company01_29 at hand_camera with Dissolve(0.8)
    pause
    h "**(퓨........)**"
    menu:
        n "What should I do?"
        "그녀의 입술에 다시 키스한다.":
            scene ch06_company01_30 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/kissshort01.mp3"
            h "읍!!!"
            scene ch06_company01_31 at hand_camera with Dissolve(0.8)
            pause
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
    scene ch06_company01_32 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_33 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    n "그가 그녀의 입에 혀를 밀어넣었을 때 그녀는 거부하지 않았다."
    pause
    n "처음으로 랜드레이디와 세입자의 타액이 섞여들어갔다."
    scene ch06_company01_34 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_35 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_36 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ 어서가요."
    h "이...이게 무슨...."
    scene ch06_company01_37 at hand_camera with Dissolve(0.8)
    d "네...."
    d "미..미안합니다..."
    d "저...저도 모르게 그만...."
    scene ch06_company01_38 at hand_camera with Dissolve(0.8)
    d "**(나 지금 무슨 짓을 한거지....)***"
    pause
    h "잠깐만요!!"
    scene ch06_company01_39 at hand_camera with Dissolve(0.8)
    d "네??"
    scene ch06_company01_40 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    scene ch06_company01_41 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_42 at hand_camera with Dissolve(0.8)
    h "먹으면서 가요 ㅎㅎ"
    scene ch06_company01_43 at hand_camera with Dissolve(0.8)
    d "**(맙소사.....)**"
    d "**(그녀는 너무나 사랑스러워.....)**"
    scene ch06_company01_44 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/dooropen.mp3"
    pause
    h "**(자랑스럽냐 [h_name]??)**"
    play sound "audio/ambi/doorclose.mp3"
    h "**(저렇게 어린 남자와 키스해서 좋냐고 이 년아.....)**"
    h "**(세상 부끄럽게......)**"
    scene ch06_company01_44-02 at hand_camera with Dissolve(0.8)
    h "............"
    pause
    h "**(뭐지 나는?....)**"
    pause
    h "**(지금 대체 뭐하는거야 저런 애를 상대로....)**"
    pause
    h "**(너 정말 역겹다 [h_name]...)**"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal05.mp3"
    scene ch06_company01_45 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_46-02 at hand_camera with Dissolve(1.2)
    d "운동 돼서 좋긴한데...."
    d "이제 운전을 배워야 하지 않을까?....."
    scene ch06_company01_46 at hand_camera with Dissolve(1.2)
    d "랜드레이디에게 운전좀 알려달라고 해볼까...."
    d "음....."
    d "그녀에게 운전좀 알려달라고 해야겠다."
    scene ch06_company01_47 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_48 at hand_camera with Dissolve(0.8)
    d "?????"
    scene ch06_company01_49 at hand_camera with Dissolve(0.8)
    viv "좋은 아침이에요."
    d "아..안녕하세요."
    scene ch06_company01_50 at hand_camera with Dissolve(0.8)
    viv "일찍 왔네요?"
    d "네 ㅎㅎ."
    d "처음이라 그런가 시간을 못맞춰서요 ㅎㅎ"
    viv "ㅎㅎ 처음엔 다 그렇죠."
    scene ch06_company01_50-02 at hand_camera with Dissolve(0.8)
    d "사실 지금 심장이 두근거려서 밖으로 튀어나오려고 합니다 ㅎㅎ"
    play voice_f "audio/voices/milflaugh13.mp3"
    viv "하하하. 어떤 건지 저도 알아요."
    viv "이제 인턴이고 첫 출근이니까 너무 걱정하지말아요."
    viv "배운다는 마음으로 하면돼요."
    d "네 ㅎㅎ"
    scene ch06_company01_50-03 at hand_camera with Dissolve(0.8)
    viv "자."
    viv "어서 들어가요."
    d "네 ㅎㅎ"
    play music "audio/bgm/normal08.mp3" volume 1.5
    scene ch06_company01_51 at hand_camera with Dissolve(1.2)
    viv "............."
    d "크흠......"
    scene ch06_company01_52 at hand_camera with Dissolve(1.3)
    n "vivian과 [d_name]은 나란히 엘레베이터에 탑승했다."
    d "**(아 어색하네.....)**"
    n "그는 그녀의 진한 향수 냄새를 느낄 수 있었다."
    scene ch06_company01_53 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_54 at hand_camera with Dissolve(1.2)
    viv "........"
    d "**(꽤 훌륭한 엉덩이네..)**"
    d "......."
    d "**(이 사람은 몇살일까?...)**"
    scene ch06_company01_55 at hand_camera with Dissolve(0.8)
    d "**(허?)**"
    pause
    d "**(저거 클럽 팔찌 아닌가?.....)**"
    scene ch06_company01_53 at hand_camera with Dissolve(0.8)
    d "**(뭐지?....)**"
    d "**(왜 저걸 아직 차고 있는거지???.....)**"
    scene ch06_company01_55 at hand_camera with Dissolve(0.8)
    d "**(....)**"
    d "**(뭐야 밖에서 자고 바로 출근한거야 설마?....)**"
    d "**(어떤 놈인지 모르겠지만 부러운걸?...)**"
    scene ch06_company01_55-02 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    scene ch06_company01_56 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_57 at hand_camera with Dissolve(0.8)
    viv "!!!!!!!!!!!!"
    scene ch06_company01_57-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_58 at hand_camera with Dissolve(0.8)
    n "그가 사무실에 들어섰을 때 shakira가 상의를 탈의하고 있었다."
    play voice_f "audio/voices/fshock01.mp3"
    sha "!!!!!!!!!!"
    scene ch06_company01_59 at hand_camera with Dissolve(0.8)
    sha "젠장!!!!"
    scene ch06_company01_60 at hand_camera with Dissolve(0.8)
    sha "미안해."
    sha "아침부터 스트립쇼 해서 미안해 하하하."
    sha "........"
    sha "평소보다 일찍 왔네?"
    scene ch06_company01_61 at hand_camera with Dissolve(0.8)
    viv "응."
    viv "어쩌다보니 일찍 왔네."
    viv "......."
    scene ch06_company01_62 at hand_camera with Dissolve(0.8)
    d "구조가 바뀌었네요?"
    d "면접땐 이렇지 않았던거 같은데.."
    scene ch06_company01_63 at hand_camera with Dissolve(0.8)
    viv "네."
    viv "이틀 동안 공사가 있었어요."
    viv "직원들 업무공간이 너무 오픈 돼 있다는 의견이 많아서."
    d "아 그렇군요."
    scene ch06_company01_64 at hand_camera with Dissolve(0.8)
    ke "좋은 아침이에요."
    sha "모두들 좋은 아침~~"
    scene ch06_company01_64-02 at hand_camera with Dissolve(0.8)
    ke "월요일은 어김없이 찾아왔습니다."
    ke "모두들 그렇다고 삶을 포기하면 안돼요."
    scene ch06_company01_65 at hand_camera with Dissolve(0.8)
    d "안녕하세요!!"
    scene ch06_company01_66 at hand_camera with Dissolve(0.8)
    ch "안녕하세요."
    scene ch06_company01_67 at hand_camera with Dissolve(0.8)
    n "그렇게 이 곳에서의 첫 업무가 시작 되었다."
    pause
    n "그는 애써 웃고 있었지만 그의 마음은 잘해야 한다는 압박감에 좌불안석이었다."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal03.mp3"
    scene ch06_company01_67-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_68 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_68-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_69 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_70 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fahem02.mp3"
    sha "크흠..."
    d "!!!"
    scene ch06_company01_71 at hand_camera with Dissolve(0.8)
    sha "저기 [d_name]?"
    d "네??"
    scene ch06_company01_72 at hand_camera with Dissolve(0.8)
    sha "아우 이거 무겁네."
    d "???"
    scene ch06_company01_73 at hand_camera with Dissolve(0.8)
    sha "이거 회사 매뉴얼이니 읽어봐요."
    d "**(매뉴얼???)**"
    sha "당분간은 실무는 시키지 않을테니 주의깊게 읽어보세요."
    scene ch06_company01_74 at hand_camera with Dissolve(0.8)
    d "넵 알겠습니다."
    d "감사합니다."
    scene ch06_company01_73 at hand_camera with Dissolve(0.8)
    sha "천만에요 ㅎㅎ"
    sha "원래 정규직원이면 정해진 교육 과정대로 매일 교육을 들어야 하지만,"
    sha "[d_name]은 대학생 인턴이니 우선 매뉴얼 부터 시작을 할거에요."
    scene ch06_company01_74 at hand_camera with Dissolve(0.8)
    d "아 그렇군요."
    d "꼼꼼히 읽어보겠습니다!!"
    scene ch06_company01_75 at hand_camera with Dissolve(0.8)
    sha "그래요."
    scene ch06_company01_75-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_73 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_75-03 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("lust_shakira", 1, "lust_shakira")
        $ add_point("love_shakira", 1, "love_shakira")
    scene ch06_company01_75-04 at hand_camera with Dissolve(0.8)
    sha ".........."
    scene ch06_company01_76 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_77 at hand_camera with Dissolve(0.8)
    d "**(여긴 다들 좋은 사람들만 일하고 있는거 같아..)**"
    pause
    d "**(생각보다 걱정할건 없는거 같은데??)**"
    scene ch06_company01_78 at hand_camera with Dissolve(0.8)
    d "**(응??)**"
    scene ch06_company01_79 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_80 at hand_camera with Dissolve(0.8)
    n "Shakira가 지나가고 나자 vivian이 자신의 다리를 훤히 드러내고 있었다."
    pause
    n "그녀는 [d_name]이 자신을 보지못한다고 생각하는 듯 이어 팬티를 벗었다."
    d "!!!!!!!!!!"
    scene ch06_company01_81 at hand_camera with Dissolve(0.8)
    d "**(뭐지??)**"
    d "**(왜 회사에서 팬티를 갈아입는거야???!!)**"
    pause
    d "**(나에게 그녀 자신이 안보인다고 생각하는건가??)**"
    d "........."
    scene ch06_company01_82 at hand_camera with Dissolve(0.8)
    d "**(저거봐.)**"
    d "**(분명 저 여자 밖에서 자고 바로 출근했다니까!!)**"
    scene ch06_company01_83 at hand_camera with Dissolve(0.8)
    stop music fadeout 1.0
    d "**(홀리쉣!!)**"
    play music "audio/bgm/erotic07.mp3"
    scene ch06_company01_84 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_85 at hand_camera with Dissolve(0.8)
    d "**(웟더퍽........)**"
    pause
    d "**(와 저 엉덩이봐.....)**"
    pause
    d "**(미쳤다......)**"
    d "**(저 엉덩이에 파묻히고 싶다....)**"
    scene ch06_company01_86 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company01_86-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_86-04 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_87 at hand_camera with Dissolve(0.8)
    viv "!!"
    d "!!!!!!!!!!!"
    scene ch06_company01_88 at hand_camera with Dissolve(0.8)
    d "**(젠장!!!!!!!!!!)**"
    d "**(그녀와 눈이 마주친거 같은데....)**"
    d "**(젠장 젠장 젠장!!!!)**"
    scene ch06_company01_89 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_vivian", 1, "lust_vivian")
        $ add_point("love_vivian", 1, "love_vivian")
    viv "**(ㅎㅎㅎ)**"
    pause
    viv "**(귀엽네 짜식.)**"
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal13.mp3"
    scene ch06_company01_89-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_89-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_company01_89-04 at hand_camera with Dissolve(0.8)
    pause
    mar "오늘 팀장님 출근안하나?"
    scene ch06_company01_89-05 at hand_camera with Dissolve(0.8)
    al "뭐라고?"
    scene ch06_company01_90 at hand_camera with Dissolve(1.2)
    mar "오늘 팀장님 출근안하나?"
    mar "....."
    mar "결재 받을게 있는데."
    scene ch06_company01_91 at hand_camera with Dissolve(0.8)
    al "애나 팀장님은 휴가중이잖아."
    mar "아 맞다."
    mar "이사님도 없고 팀장님도 없고 참...."
    scene ch06_company01_90 at hand_camera with Dissolve(0.8)
    mar "대표님은 출근 했겠지?"
    scene ch06_company01_91 at hand_camera with Dissolve(0.8)
    al "주말에 지사 출장가셨을걸."
    mar "뭐야 그럼 대표님도 없다는거야??"
    al "아냐."
    al "평소대로면 아마 오늘 새벽에 오셨을거야."
    scene ch06_company01_92 at hand_camera with Dissolve(0.8)
    mar "빨리 결재 하셔야 할게 있는데."
    pause
    mar "흐음......"
    scene ch06_company01_93 at hand_camera with Dissolve(0.8)
    mar "오 신입!!"
    d "!!!!"
    scene ch06_company01_94 at hand_camera with Dissolve(0.8)
    d "네??!!"
    d "**(깜짝놀랐네...)**"
    scene ch06_company01_95 at hand_camera with Dissolve(0.8)
    mar "혹시 위층에 가봤어요?"
    scene ch06_company01_96 at hand_camera with Dissolve(0.8)
    d "위층이요?"
    d "**(여기 위층이 있었어???)**"
    d "아니요. 못가봤습니다."
    scene ch06_company01_95 at hand_camera with Dissolve(0.8)
    mar "그럼 대표님에게 인사도 할겸 위층 올라가볼래요?"
    d "아 네!!"
    mar "대표님에게 급한건이 있어서 시스템에서 서류좀 봐달라고 말해주세요."
    mar "그렇게만 말하면 아실거에요."
    scene ch06_company01_96 at hand_camera with Dissolve(0.8)
    d "아 네. 알겠습니다."
    d "바로 올라갈게요."
    scene ch06_company01_97 at hand_camera with Dissolve(0.8)
    mar "너의 뒤에 저기가 올라가는 계단이에요."
    d "넵 감사합니다."
    play sound "audio/ambi/dooropen03.mp3"
    scene ch06_company01_98 at hand_camera with Dissolve(0.8)
    d "**(........)**"
    d "**(이게 위층으로 가는 계단이었다니...)**"
    d "**(창고인줄 알았네.)**"
    scene ch06_company01_99 at hand_camera with Dissolve(1.2)
    pause
    jump ch06_company02

label ch06_company02:
    if not in_replay:
        $ persistent.unlock_ch06_company02 = True
    scene ch06_company02_01 at hand_camera with Dissolve(1.2)
    d "여기 위층이 있을거라곤 꿈에도 몰랐네.."
    d "사무실이 이 건물 꼭데기층인줄 알았는데.."
    d "위층에도 직원들이 있는건가???"
    scene ch06_company02_02 at hand_camera with Dissolve(0.8)
    pause
    stop music fadeout 1.0
    scene ch06_company02_03 at hand_camera with Dissolve(1.2)
    pause
    n "위층 문은 굳건히 닫혀있었다."
    pause
    n "키보드 소리와 사람들의 말소리가 흐르는 아래층과 다르게 윗층은 고요하고 정적인 느낌이었다."
    pause
    n "그것은 마치 다른 차원으로 통하는 문 같았다."
    scene ch06_company02_04 at hand_camera with Dissolve(0.8)
    d "크흠.."
    image ch06_company02_knock01:
        "ch06_company02_05" with dissolve
        0.3
        "ch06_company02_06" with dissolve
        0.3
        repeat
    play sound "audio/ambi/knock.mp3" loop
    scene ch06_company02_knock01 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch06_company02_07 at hand_camera with Dissolve(0.8)
    d "크흠!!"
    play sound "audio/ambi/knock.mp3" loop
    scene ch06_company02_knock01 at hand_camera with Dissolve(0.8)
    pause
    stop sound
    scene ch06_company02_08 at hand_camera with Dissolve(0.8)
    d "흐음......"
    d "이거 열려있나?"
    pause
    d "그냥 들어가야 겠는걸..."
    scene ch06_company02_09 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/dooropen02.mp3"
    scene ch06_company02_10 at hand_camera with Dissolve(0.8)
    d "안녕하세요 대표님!!"
    pause
    d "............."
    scene ch06_company02_11 at hand_camera with Dissolve(0.8)
    d "........."
    d "들어가도 되나....."
    d "**(행동하기 전에 생각하자......생각하자....)**"
    pause
    d "당연히...."
    pause
    d "해야할 일이 먼저다."
    play music "audio/bgm/normal11.mp3"
    scene ch06_company02_12 at hand_camera with Dissolve(0.8)
    pause
    d "**(와 여기는 그냥 가정집 같은걸?)**"
    d "......"
    d "**(아래층이랑은 딴판이네.)**"
    scene ch06_company02_13 at hand_camera with Dissolve(0.8)
    d "**(여기는 홈오피스 같은 건가...)**"
    d "**(이런데서 살고싶은걸)**."
    pause
    d "**(오 좋은 향기가 나네.)**"
    d "......."
    d "**(역시 여자가 사는 곳은 좋은 냄새가 나.....)**"
    scene ch06_company02_13-02 at hand_camera with Dissolve(0.8)
    pause
    d "**(로즈는 여기서 사는건가?)**"
    pause
    d "**(아니 당연히 더 큰 집이 있겠지.)**"
    scene ch06_company02_13-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_14 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    scene ch06_company02_15 at hand_camera with Dissolve(0.8)
    d "**(아 저기 앉아 계시네.)**"
    scene ch06_company02_16 at hand_camera with Dissolve(0.8)
    d "안녕하세요 대표님."
    d "........"
    d "그 저....."
    scene ch06_company02_17 at hand_camera with Dissolve(0.8)
    d "직원분들이 그 뭐냐..."
    pause
    d "시스템에서 결재를 기다리고 있는 서류들을 봐달라고 요청했습니다."
    pause
    d "............."
    pause
    scene ch06_company02_18 at hand_camera with Dissolve(0.8)
    pause
    d "......"
    d "**(왜 반응이 없지?....)**"
    scene ch06_company02_19 at hand_camera with Dissolve(0.8)
    n "그는 두근 거리는 마음을 뒤로 하고 조심스럽게 그녀에게 다가갔다."
    d "**(젠장 왜 범죄를 저지르는 기분이지?)**"
    d "**(남의 가정집에 침입한거 같아서 진짜 불편하네..)**"
    d "**(왜 항상 가는곳 마다 이렇게 도둑 처럼 보여야 하는거지???)**"
    n "그리고 의식적으로 그녀에게 밝은 목소리로 인사했다."
    scene ch06_company02_20 at hand_camera with Dissolve(0.8)
    d "안녕하세요!!"
    scene ch06_company02_21 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!!"
    scene ch06_company02_21-02 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/erotic06.mp3" volume 0.6
    scene ch06_company02_22 at hand_camera with Dissolve(0.8)
    d "**(이런 미친!!!!)**"
    n "그녀는 상의를 모두 벗은채 깊은 잠에 빠져 있었다."
    pause
    n "그녀는 그의 인사소리에도 전혀 반응하지 않았다."
    d "**(홀리.....)**"
    scene ch06_company02_23 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_23-02 at hand_camera with Dissolve(0.8)
    d "**(맙소사......)**"
    d "**(아만다랑 막상막하의 크기인걸...)**"
    d "**(......)**"
    d "**(그녀의 나이치고 처지지 않은 모양이잖아.)**"
    pause
    d "**(수술한건가??.......)**"
    scene ch06_company02_24 at hand_camera with Dissolve(0.8)
    pause
    d "**(여기 짐풀다가 잠든건가?....)**"
    d "**(......)**"
    d "**(여간 피곤한게 아니었나보네...)**"
    scene ch06_company02_24-01 at hand_camera with Dissolve(0.8)
    d "**(..............)**"
    scene ch06_company02_24-02 at hand_camera with Dissolve(0.8)
    d "**(.....)**"
    d "**(로즈도 평범한 중년 여성이군.....)**"
    d "**(이렇게 잠들 정도로 힘들게 일하는건가....)**"
    scene ch06_company02_23 at hand_camera with Dissolve(0.8)
    d "**(......)**"
    scene ch06_company02_25 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "로즈의 사진을 찍는다.":
            scene ch06_company02_26 at hand_camera with Dissolve(0.8)
            d "**(이거면 제이슨을 이길 수 있을거 같은데...)**"
            d "**(젠장 근데 이래도 되나?.....)**"
            d "**(.....)**"
            d "**(근데 이 기회를 놓칠순 없지...)**"
    scene ch06_company02_26-00 at hand_camera with Dissolve(0.8)
    d "**(시발 심장이 터질거같아.....)**"
    play sound "audio/ambi/camera.mp3"

    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/32_Thumb.jpg",
            "phone": "images/phone/shots/32.jpg",
        })
    scene ch06_company02_26-01 at hand_camera with Dissolve(0.8)
    d "**(하......)**"
    d "**(나 자신이 부끄럽다...)**"
    scene ch06_company02_26-02 at hand_camera with Dissolve(0.8)
    d "**(..........)**"
    d "**(손이 떨리네..)**"
    play sound "audio/ambi/camera.mp3"
    if not in_replay:
        $ gallery_images.append({
            "thumb": "images/phone/shots/33_thumb.jpg",
            "phone": "images/phone/shots/33.jpg",
        })
    scene ch06_company02_26-03 at hand_camera with Dissolve(0.8)
    d "**(이거 범죄 아닌가??!!)**"
    d "**(........)**"
    scene ch06_company02_26-04 at hand_camera with Dissolve(0.8)
    d "**(하지만....)**"
    d "**(이...입에 넣고 싶다....)**"
    scene ch06_company02_27 at hand_camera with Dissolve(0.8)
    d "**(젠장!)**"
    d "**(그녀는 자고있는데도 카리스마가 뿜어져나오네...)**"
    scene ch06_company02_28 at hand_camera with Dissolve(0.8)
    d "**(아 잠깐만!!!!)**"
    pause
    d "**(그녀에게 말을 전하려면 깨워야 하잖아??!!)**"
    d "..........."
    d "**(쪽지를 남겨 놓고 내려갈까??)**"
    pause
    d "**(아냐 그럼 다른 직원들이 날 또라이로 볼거아냐.)**"
    d "**(여기서 무슨일이 있었는지 설명할수도 없을거 같은데.....)**"
    pause
    d "**(근데 이 상태로 깨우면 내가 그녀의 가슴을 본걸 그녀가 알거아냐??)**"
    pause
    d "**(아 시발.....)**"
    scene ch06_company02_29 at hand_camera with Dissolve(0.8)
    d "**(난 그녀에 비하면 애기인데 그녀가 신경이나 쓰겠어??!!)**"
    d "**(.......)**"
    d "**(아닌가??...혹시 성추행으로 몰리는거아냐???)**"
    scene ch06_company02_29-02 at hand_camera with Dissolve(0.8)
    d "**(아 썅 모르겠다!!!)**"
    menu:
        n "What should I do?"
        "그녀를 만져서 깨운다.":
            scene ch06_company02_29-03 at hand_camera with Dissolve(0.8)
            d "**(젠장 그녀를 만지고 싶다!!)**"
            pause
            d "**(안돼!!)**"
            d "**(잘못하면 고향에서 매장당한다.....)**"
    scene ch06_company02_30 at hand_camera with Dissolve(0.8)
    n "그는 살며시 로즈의 어깨에 손을 올렸다."
    n "그녀의 피부는 그의 예상보다 더 부드러웠다."
    scene ch06_company02_30-02 at hand_camera with Dissolve(0.8)
    d "저기 대표님!!"
    d "......"
    d "로즈!!!!!"
    stop music fadeout 1.0
    scene ch06_company02_31 at hand_camera with Dissolve(0.8)
    r "으음.........."
    pause
    r "........"
    scene ch06_company02_32 at hand_camera with Dissolve(0.8)
    r "너는???!!!!"
    r "......"
    d "아..안녕하세요 로즈."
    scene ch06_company02_33 at hand_camera with Dissolve(0.8)
    r "맙소사........"
    d "......"
    r "나 여기서 얼마나 잔거야....."
    scene ch06_company02_34 at hand_camera with Dissolve(0.8)
    d "그 저....."
    d "직원분들이 결재 서류들을 봐달라고 요청해서요......"
    pause
    d "급한일이 있나봅니다."
    scene ch06_company02_35 at hand_camera with Dissolve(0.8)
    pause
    r "그래요 알겠어요."
    pause
    r "바로 본다고 내려가서 얘기해주세요."
    d "네 알겠습니다."
    scene ch06_company02_36 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_37 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("sus_rose", 1, "sus_rose")
    r "**(.........)**"
    r "**(뭐야 저거....)**"
    pause
    r "**(옷 주름인가??)**"
    scene ch06_company02_38 at hand_camera with Dissolve(0.8)
    r "아우........"
    r "침대에서 편하게 잤어야 했는데..."
    r "바보 같이 이게 뭐람....."
    scene ch06_company02_39 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fgrunt03.mp3"
    r "!!!!!!!!!!!!!!!!!!!!!"
    if not in_replay:
        $ add_point("lust_rose", 1, "lust_rose")
    r "맙소사!!!!!!"
    scene ch06_company02_40 at hand_camera with Dissolve(0.8)
    d "네????"
    scene ch06_company02_41 at hand_camera with Dissolve(0.8)
    r "**(맙소사..)**"
    r "**(어떻게 이것도 모르고 있었지?!!)**"
    scene ch06_company02_41-02 at hand_camera with Dissolve(0.8)
    d "........"
    scene ch06_company02_42 at hand_camera with Dissolve(0.8)
    r "5분 내로 결재한다고 전해주세요."
    d "네 그렇게 하겠습니다."
    r "고마워요."
    scene ch06_company02_43 at hand_camera with Dissolve(0.8)
    d "아닙니다 ㅎㅎ"
    scene ch06_company02_44 at hand_camera with Dissolve(0.8)
    d "**(젠장..)**"
    d "**(이거 내가 실수한건가......)**"
    d "**(그냥 로즈가 골아떨어졌다고 전해줬어야 했나....)**"
    r "아니 바퀴가 왜 이래??"
    scene ch06_company02_45 at hand_camera with Dissolve(0.8)
    d "????"
    scene ch06_company02_46 at hand_camera with Dissolve(0.8)
    r "이상하네.."
    r "여기 들고 올때만해도 괜찮았는데..."
    scene ch06_company02_47 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_48 at hand_camera with Dissolve(0.8)
    r "아우 무거워."
    scene ch06_company02_49 at hand_camera with Dissolve(0.8)
    d "제가 들게요!!"
    scene ch06_company02_50 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_50-02 at hand_camera with Dissolve(0.8)
    d "흡!!!(힘 주면서 기합주는 소리)"
    play sound "audio/ambi/fabric04.mp3" volume 1.8
    scene ch06_company02_51 at hand_camera with Dissolve(0.8)
    d "흐윽!!"
    r "!!!"
    scene ch06_company02_52 at hand_camera with Dissolve(0.8)
    r "......"
    scene ch06_company02_53 at hand_camera with Dissolve(0.8)
    n "그는 자신도 모르게 캐리어 가방을 힘껏 들어올렸다."
    pause
    n "하지만 그 무게는 간신히 지탱할 만큼 무거웠다."
    d "**(젠장!!!)**"
    d "**(이거 뭔 돌덩이를 넣었나???)**"
    d "**(드럽게 무겁네!!)**"
    play voice_f "audio/voices/flaugh08.mp3"
    scene ch06_company02_54 at hand_camera with Dissolve(0.8)
    r "하하하하"
    r "역도 하듯이 들었네요."
    scene ch06_company02_54-02 at hand_camera with Dissolve(0.8)
    d "아..그...그렇죠..."
    d "하하."
    scene ch06_company02_55 at hand_camera with Dissolve(0.8)
    r "미안해요."
    r "여기다 놔 줄래요?"
    scene ch06_company02_56 at hand_camera with Dissolve(0.8)
    d "흐압!!!!!!!"
    r "...."
    scene ch06_company02_57 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/hit01.mp3"
    pause
    scene ch06_company02_58 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_company02_59 at hand_camera with Dissolve(0.8)
    r "고마워요."
    d "아닙니다 ㅎㅎ"
    r "......"
    d "내려가겠습니다."
    scene ch06_company02_60 at hand_camera with Dissolve(0.8)
    r "잠깐만요!"
    scene ch06_company02_61 at hand_camera with Dissolve(0.8)
    d "네??"
    scene ch06_company02_62 at hand_camera with Dissolve(0.8)
    n "그가 돌아보자 그녀가 천천히 그에게 다다갔다."
    play music "audio/bgm/erotic12.mp3"
    scene ch06_company02_63 at hand_camera with Dissolve(0.8)
    pause
    n "그리고 그녀는 그의 넥타이에 손을 가져다 대었다."
    scene ch06_company02_64 at hand_camera with Dissolve(0.8)
    r "이게 삐뚤어졌네요."
    d "네??!!"
    scene ch06_company02_65 at hand_camera with Dissolve(0.8)
    d "아..넥타이요..."
    r "......."
    r "넥타이 이렇게 매는거 아닌데."
    d "아 ㅎㅎ"
    d "어제 밤엔 잘 됐었는데 ㅎㅎ."
    scene ch06_company02_66 at hand_camera with Dissolve(0.8)
    pause
    r "허약해 보였는데 생각보다 힘이 세네요."
    d "가...감사합니다."
    pause
    r "......"
    scene ch06_company02_66-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_rose", 1, "lust_rose")
    r "확실히 남자는 왜소해 보여도 여자랑 차원이 다르네."
    r "..........."
    pause
    r "참 다른 생물체 같아 가끔 남자들은.."
    scene ch06_company02_67 at hand_camera with Dissolve(0.8)
    pause
    r "........."
    scene ch06_company02_68 at hand_camera with Dissolve(0.8)
    r "됐어요."
    r "이제 내려가도 돼요."
    r "수고했어요."
    d "네 알겠습니다."
    scene ch06_company02_69 at hand_camera with Dissolve(1.2)
    d "**(퓨..........)**"
    d "**(이거 뭐 우주라도 다녀온 느낌이야....)**"
    d "........"
    d "**(엄청난 압박감이야.....)**"
    pause
    d "**(저런 여자를 컨트롤 할 수 있는 남자는 대체 어떤 사람들일까..)**"
    scene ch06_company02_70 at hand_camera with Dissolve(1.2)
    pause
    d "**(로즈 같은 여자를 복종하게 할 수 있을까....)**"
    pause
    d "**(그러니까 내가 원하는대로 하도록??.......)**"
    pause
    d "**(뎀.......)**"
    d "**(생각만해도 미칠거 같네....)**"
    scene ch06_company02_71 at hand_camera with Dissolve(0.8)
    r "커피 커피 커피.."
    pause
    r "아무리 급해도 커피는 마시면서 해야지.."
    jump ch06_hhouse01

label ch06_hhouse01:
    if not in_replay:
        $ persistent.unlock_ch06_hhouse01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "Two days later" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"  
    scene ch06_hhouse01_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_03 at hand_camera with Dissolve(0.8)
    d "**(내가 여기서 일한지 3일이 지났다..)**"
    pause
    d "**(아니 더 정확히 말하자면 아직 매뉴얼을 보고 공부하는 중이긴 하지만...)**"
    scene ch06_hhouse01_04 at hand_camera with Dissolve(0.8)
    d "**(다들 나에게 친절히 대해준다.)**"
    d "**(........)**"
    scene ch06_hhouse01_05 at hand_camera with Dissolve(0.8)
    d "**(음....내가 생각했던 직장생활과 좀 다르긴 하지만.)**"
    d "**(소도시 회사라 그런가?)**"
    d "**(아님 사람이 많지 않아서 그런지 그렇게 엄한 분위기도 없다.)**"
    d "**(큰 도시의 지사엔 사람들이 많다고 하던데 여긴 뭐랄까 소수정예 느낌이야.)**"
    pause
    d "**(쉴세없이 통화하고 사람들이 소리지르고 왔다갔다 하는걸 상상했는데...)**"
    d "**(근데 오히려 이게 나와 잘 맞는거 같아.)**"
    scene ch06_hhouse01_06 at hand_camera with Dissolve(0.8)
    d "**(난 3일만 출근하기로 했다.)**"
    d "**(물론 급여는 정상적으로 준다고 한다.)**"
    d "**(대학생으로 다양한 활동을 할 시간을 준다는 로즈의 배려였다.)**"
    scene ch06_hhouse01_07 at hand_camera with Dissolve(0.8)
    d "**(그게 나에게 좋은건지 아닌지는 모르겠지만 말이다.)**"
    d "**(흐음....)**"
    d "**(어쨌든 내일 부터 며칠간 자유다.)**"
    scene ch06_hhouse01_07-02 at hand_camera with Dissolve(1.2)
    d "**(그리고 Vivian....)**"
    pause
    d "**(그녀는 차갑지만 때때로 날 남동생 처럼 잘 챙겨준다.)**"
    scene ch06_hhouse01_07-03 at hand_camera with Dissolve(1.2)
    d "**(그녀를 보고있으면..)**"
    d "**(단단한 어른이라는 생각이 들어....)**"
    d "**(뭐랄까....)**"
    pause
    d "**(대학생들하고는 차원이 다른 어른스러움이랄까....)**"
    scene ch06_hhouse01_08 at hand_camera with Dissolve(1.5)
    play sound "audio/ambi/bicycle01.mp3"
    d "아무튼 내가 뭔가 대단한 일을 하고 있는건 아니지만..."
    scene ch06_hhouse01_09 at hand_camera with Dissolve(0.8)
    d "이것이 자유의 맛이구나!!!!!!"
    d "절로 웃음이 나네 하하하하."
    scene ch06_hhouse01_10 at hand_camera with Dissolve(1.2)
    pause
    d "!!!"
    d "레..레나가 왔구나."
    play sound "audio/ambi/dooropen.mp3"
    scene ch06_hhouse01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_12 at hand_camera with Dissolve(0.8)
    d "응??"
    d "......."
    d "고기 냄새다 이건!!"
    scene ch06_hhouse01_13 at hand_camera with Dissolve(0.8)
    d "[h_name]이 고기 굽고 있나?"
    scene ch06_hhouse01_14 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_14-02 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/normal04.mp3"  
    scene ch06_hhouse01_15 at hand_camera with Dissolve(0.8)
    h "아니 나도 정말 기억이 안난다니까."
    h "하필 그 남자가 내가 제일 좋아하는 술을 시키더라고."
    pause
    h "그래서 정신 놓고 퍼마셨지 ㅎㅎ."
    l "결국 니 스스로 그렇게 꽐라될정도로 마신거네 그럼 ㅋㅋ"
    pause
    l "난 그 남자가 너에게 작업친줄 알았네."
    d "안녕하세요 ㅎㅎ"
    d "고기 냄새가 너무 좋은데요? 하하하."
    scene ch06_hhouse01_16 at hand_camera with Dissolve(0.8)
    h "퇴근하고 오는거에요?"
    d "네 방금 왔어요."
    h "다행히 시간맞춰 왔네요."
    scene ch06_hhouse01_16-02 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "고기 냄새에 이끌려서 자동으로 이리로 왔습니다."
    scene ch06_hhouse01_16-03 at hand_camera with Dissolve(0.8)
    d "!!!!!"
    scene ch06_hhouse01_17 at hand_camera with Dissolve(0.8)
    l "어서와 빅보이."
    l "요즘 자주 보네?"
    l "......."
    d "아...안녕하세요 레나."
    l "뭐야? 왜 날 보고 그렇게 놀라는거야 기분 나쁘게."
    scene ch06_hhouse01_16-03 at hand_camera with Dissolve(0.8)
    d "네? 아..아니에요."
    d "무례했다면 미..미안합니다."
    scene ch06_hhouse01_18 at hand_camera with Dissolve(0.8)
    h "오늘 저녁은 여기서 자유롭게 먹을거에요."
    h "소소하게 파티하면서 ㅎㅎ"
    h "오늘만 운영하는 아줌마들의 고기집이에요 하하."
    h "어서 편하게 입고 내려와요."
    d "넵 알겠습니다."
    scene ch06_hhouse01_18-02 at hand_camera with Dissolve(0.8)
    l "알아들었어?"
    l "편하게 입으라고. 편하게."
    pause
    l "빨개벗고 와도 돼."
    l "고추 덜렁덜렁하면서 말이야."
    scene ch06_hhouse01_19 at hand_camera with Dissolve(0.8)
    d "네 알겠습니다."
    d "금방 돌아올게요."
    d "벌써 입에 침이고이네요 하하."
    l "침은 다른데다 흘리라고."
    scene ch06_hhouse01_19-02 at hand_camera with Dissolve(0.8)
    h "레나..."
    pause
    h "그에게 상냥하게 대해."
    h "그는 정말 보기드문 착한 학생이라고."
    l "하하하 그래?"
    scene ch06_hhouse01_19-03 at hand_camera with Dissolve(0.8)
    l "보기드문 착한 학생?"
    play voice_f "audio/voices/milflaugh06.mp3"
    l "보기드문 착한 학생 맞아? 하하하."
    l "아하!!"
    l "착한거 같긴 해."
    l "여자 말을 참 잘 들을거야."
    l "아줌마들에게 인기있을 타입이라고."
    pause
    l "너도 알지?"
    l "부잣집 아줌마들의 소년 장난감."
    scene ch06_hhouse01_19-04 at hand_camera with Dissolve(0.8)
    h "무슨 그런 소릴..."
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"  
    scene ch06_hhouse01_20 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_20-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_21 at hand_camera with Dissolve(1.2)
    n "세 사람은 뒷마당에서 즐거운 시간을 보냈다."
    pause
    n "먹고 웃고 떠들며 서로에 대해 더 알아가고 조금씩 더 친밀해지고 있었다."
    scene ch06_hhouse01_22 at hand_camera with Dissolve(1.2)
    n "그리고 분명 [h_name]은 며칠전의 키스로 그와 더 가까워진 느낌이었다."
    pause
    n "[d_name]이 원하는대로 그는 조금씩 그녀들의 세계에 발을 들이고 있었다."
    scene ch06_hhouse01_23 at hand_camera with Dissolve(0.8)
    l "........"
    l "**(저녀석 아무일 없었다는 듯 연기 잘하네.)**"
    l "**(우리 땐 그런짓을 벌이면 서로 최소한의 책임감은 보여줬는데 말이야.)**"
    l "**(.........)**"
    l "**(시작은 나였어도 마지막에 즐긴건 너 잖아 이녀석!!!)**"
    l "**(역시 어린 남자는 어설프네...)**"
    pause
    l "**(아니 요즘 애들은 그냥 그런식인건가?)**"
    h "며칠 일 해보니까 어때요?"
    h "할만해요?"
    scene ch06_hhouse01_23-02 at hand_camera with Dissolve(0.8)
    d "네 아직까지는 할만합니다."
    d "전 인턴이어서 아직은 매뉴얼을 보고 공부하는 중이에요."
    h "아하."
    h "그렇군요."
    h "사람들은 괜찮아 보여요?"
    d "네 다들 친절합니다."
    d "그러니까...아직까지는요 ㅎㅎ"
    scene ch06_hhouse01_24 at hand_camera with Dissolve(0.8)
    l "아 오늘도 역시 덥네."
    l "끈적거려.."
    scene ch06_hhouse01_24-02 at hand_camera with Dissolve(0.8)
    h "그치?"
    h "나도 엄청 끈적거리네."
    h "더운데 고기 까지 구우니 더 그래."
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_hhouse01_25 at hand_camera with Dissolve(0.8)
    d "!!!!!!!!!"
    scene ch06_hhouse01_25-02 at hand_camera with Dissolve(0.8)
    d "**(홀리 쉣..)**"
    scene ch06_hhouse01_26 at hand_camera with Dissolve(0.8)
    h "맙소사 레나!!"
    h "[d_name] 앞에서 뭐하는거야??"
    play voice_f "audio/voices/fsigh02.mp3"
    scene ch06_hhouse01_27 at hand_camera with Dissolve(0.8)
    l "아 이 해방감."
    l "상쾌하다 아~~"
    scene ch06_hhouse01_28 at hand_camera with Dissolve(0.8)
    l "너도 그냥 벗어."
    h "뭐??"
    l "뭐긴 뭐야."
    l "여기 체면차릴 사람 누가 있다고?"
    l "그러고 있으면 고기가 아니라 니가 익어버릴걸?"
    scene ch06_hhouse01_29 at hand_camera with Dissolve(0.8)
    h "..........."
    pause
    n "[h_name]은 잠시 고민했다."
    n "그리고 며칠전 그에게 이미 그에게 자신의 맨 가슴을 보여줬던 일을 기억했다."
    scene ch06_hhouse01_29-02 at hand_camera with Dissolve(0.8)
    h "젠장! 나도 벗는다 레나."
    h "난 이 집 주인이니까 내 맘대로 하는거야!!"
    l "하하."
    l "어서 보여줘~"
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_hhouse01_30 at hand_camera with Dissolve(0.8)
    d "!!!!!!!"
    d "**(다들 용감해지는데??)**"
    d "**(고기를 먹어서 원초적 본능이 올라오는건가? ㅎㅎ)**"
    scene ch06_hhouse01_31 at hand_camera with Dissolve(0.8)
    d ".........."
    d "**(맙소사......)**"
    pause
    d "**(이 광경을 제이슨이 보면 어떤 반응일까....)**"
    d "**(당장이라도 이 집으로 이사한다고 난리겠지?)**"
    scene ch06_hhouse01_32 at hand_camera with Dissolve(0.8)
    d ".........."
    h "하아......상쾌하네."
    d "**(Damn......)**"
    scene ch06_hhouse01_32-02 at hand_camera with Dissolve(0.8)
    d "**(가슴이 두 쌍이라니...)**"
    d "**(영화에서나 보던거잖아....)**"
    pause
    d "**(보통 영화에서 이 다음 장면은 신나게 떡치는건데....)**"
    d "**(그래.)**"
    d "**(남자 하나, 여자 둘이면 딱 야동 각이네 하하하.)**"
    scene ch06_hhouse01_32-03 at hand_camera with Dissolve(1.2)
    pause
    l "헤헤."
    play sound "audio/ambi/touch02.mp3"
    scene ch06_hhouse01_33 at hand_camera with Dissolve(0.8)
    play music "audio/bgm/erotic06.mp3" volume 0.6
    h "!!!!"
    scene ch06_hhouse01_34 at hand_camera with Dissolve(0.8)
    h "뭐하는거야.."
    h "아우 끈적여 ㅎㅎ"
    scene ch06_hhouse01_35 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ 미안해요."
    h "아줌마들이 주책이네요."
    d "아...아닙니다 ㅎㅎ"
    h "레나랑 나는 좀 특이한 관계라 ㅎㅎ"
    scene ch06_hhouse01_36 at hand_camera with Dissolve(0.8)
    d "아..아닙니다 ㅎㅎ"
    d "저는 신경쓰지마세요."
    d "**(네 절대 절 신경쓰지마세요!!!!!)**"
    scene ch06_hhouse01_37 at hand_camera with Dissolve(0.8)
    d "**(홀리 쉣..)**"
    scene ch06_hhouse01_38 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
        $ add_point("lust_helen", 1, "lust_helen")
    n "그녀들은 그를 아랑곳하지 않고 서로의 혀를 접촉했다."
    n "그의 눈앞에서 중년의 여성 두명이 뜨거운 키스를 하는 모습은 정말 인상적이었다."
    n "그녀들의 침이 섞이는 소리는 그의 자극을 배가시켰다."
    scene ch06_hhouse01_37 at hand_camera with Dissolve(0.8)
    d "**(.......)**"
    d "**(뭔가 야동을 보는 느낌이야....)**"
    pause
    d "**(그녀들은 이젠 날 편하게 생각하는건가??)**"
    d "**(그게 나에게 좋은건지 나쁜건지....)**"
    play sound "audio/sex/liquid01.mp3"
    scene ch06_hhouse01_37-02 at hand_camera with Dissolve(0.8)
    d "**(젠장 레나....)**"
    d "**(레나는 혹시 진짜 마녀가 아닐까???....)**"
    d "**(그녀는 남편이 있는지, 자식이 있는지, 직업이 뭔지, 어디에 사는지...)**"
    d "**(도무지 알수가 없어.)**"
    scene ch06_hhouse01_39 at hand_camera with Dissolve(0.8)
    h "!!"
    scene ch06_hhouse01_39-02 at hand_camera with Dissolve(0.8)
    h "레나 이건 좀....."
    l "쉿!"
    scene ch06_hhouse01_40 at hand_camera with Dissolve(0.8)
    d "**(미쳤다 이건.....)**"
    scene ch06_hhouse01_41 at hand_camera with Dissolve(0.8)
    h "아우 미안해요 ㅎㅎ"
    play voice_f "audio/voices/milflaugh04.mp3"
    h "미치겠다 정말."
    h "세입자 앞에서 이게 무슨 추태인지.."
    scene ch06_hhouse01_42 at hand_camera with Dissolve(0.8)
    d "!!!!"
    scene ch06_hhouse01_43 at hand_camera with Dissolve(0.8)
    n "레나는 아랑곳 하지 않고 나체가 되었다."
    pause
    n "그리고 곧장 자쿠지로 향했다."
    scene ch06_hhouse01_43-02 at hand_camera with Dissolve(0.8)
    n "그녀의 몸 동작은 그녀의 몸매를 과시하듯 움직였다."
    pause
    n "이 집의 랜드레이디와 세입자 모두에게 말이다."
    scene ch06_hhouse01_44 at hand_camera with Dissolve(0.8)
    l "흐음......"
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_45 at hand_camera with Dissolve(0.8)
    l "아~~~"
    l "좋다~~"
    scene ch06_hhouse01_46 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_47 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_42 at hand_camera with Dissolve(0.8)
    d "**(오오오.........)**"
    d "**(랜드레이디 까지!!!!!!!)**"
    scene ch06_hhouse01_49 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_49-02 at hand_camera with Dissolve(0.8)
    pause
    play ambient "audio/ambi/water01.mp3" loop
    scene ch06_hhouse01_49-03 at hand_camera with Dissolve(0.8)
    pause
    jump ch06_hhouse02

label ch06_hhouse02:
    if not in_replay:
        $ persistent.unlock_ch06_hhouse02 = True
    scene ch06_hhouse01_50 at hand_camera with Dissolve(0.8)
    l "헤이 꼬맹아!"
    d "네??"
    l "우리 술잔 가지고 와."
    d "아...알겠습니다."
    scene ch06_hhouse01_51 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ"
    h "[d_name]도 들어와요."
    l "그래. 너도 어서 들어와."
    scene ch06_hhouse01_52 at hand_camera with Dissolve(0.8)
    d "네 지금 갑니다."
    scene ch06_hhouse01_53 at hand_camera with Dissolve(0.8)
    d "여기 있습니다."
    scene ch06_hhouse01_54 at hand_camera with Dissolve(0.8)
    l "야 뭐하는거야?!"
    h "고마워요."
    l "다 벗고 들어와야지."
    l "매너 없는 꼬맹이 같으니."
    l "사람 옷에 세균이 얼마나 많은지 모르니??"
    d "네??!!"
    scene ch06_hhouse01_55 at hand_camera with Dissolve(0.8)
    d "아...미안합니다."
    d "버..벗을게요."
    scene ch06_hhouse01_56 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_56-02 at hand_camera with Dissolve(0.8)
    pause
    h "............."
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_hhouse01_56-03 at hand_camera with Dissolve(0.8)
    h "**(맙소사......)**"
    pause
    h "**(스튜디오에서 촬영 후로 두번째네.....)**"
    scene ch06_hhouse01_57 at hand_camera with Dissolve(0.8)
    l "**(너의 훌륭한 물건을 어서 내놓으라고 ㅎㅎ)**"
    l "**(.........)**"
    l "**(판을 깔아줘도 어리버리하게 참..)**"
    scene ch06_hhouse01_58 at hand_camera with Dissolve(0.8)
    n "그는 나체로 그녀들의 앞에 섰다."
    pause
    n "그는 앉기전 의도적으로 잠시 서서 자신의 성기를 그녀들에게 노출시켰다."
    if not in_replay:
        $ add_point("lust_lena", 1, "lust_lena")
        $ add_point("lust_helen", 1, "lust_helen")
    scene ch06_hhouse01_59 at hand_camera with Dissolve(0.8)
    pause
    h "**(스튜디오에선 괜찮았는데 왜 지금은 부끄럽지?.....)**"
    h "............"
    h "크흠...."
    scene ch06_hhouse01_59-02 at hand_camera with Dissolve(0.8)
    l "**(젠장..)**"
    l "**(다시 봐도 흥분되네...)**"
    play sound "audio/ambi/water02.mp3"
    scene ch06_hhouse01_60 at hand_camera with Dissolve(0.8)
    d "그거아세요?"
    h "??"
    l "아냐니 뭘?"
    d "태어나서 처음으로 자쿠지에 들어온거에요 ㅎㅎ"
    l "뭐? 진짜로?"
    scene ch06_hhouse01_61 at hand_camera with Dissolve(0.8)
    d "네 ㅎㅎ"
    d "야외에서 따뜻한 물에 들어오니까 느낌이 색다릅니다 ㅎㅎ"
    h "........"
    scene ch06_hhouse01_62 at hand_camera with Dissolve(0.8)
    l "맙소사."
    l "태어나서 처음이라잖아!"
    l "이 녀석이 내는 방세에 자쿠지는 포함 안된거야??"
    l "저 불쌍한 녀석 좀 잘 챙겨주라고 [h_name]."
    l "모성애를 마구 자극하잖아!"
    scene ch06_hhouse01_63 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ"
    h "최고는 아니지만 그래도 신경 써주고 있어."
    h "아직도 날 모르니?"
    scene ch06_hhouse01_64 at hand_camera with Dissolve(1.5)
    pause
    scene ch06_hhouse01_64-02 at hand_camera with Dissolve(1.5)
    pause
    scene ch06_hhouse01_64-03 at hand_camera with Dissolve(1.5)
    pause
    scene ch06_hhouse01_64-04 at hand_camera with Dissolve(1.5)
    pause
    play music "audio/bgm/erotic07.mp3"
    scene ch06_hhouse01_65 at hand_camera with Dissolve(1.2)
    l "하하하"
    l "난 그놈이 [d_name]인줄 꿈에도 몰랐다니까."
    l "버스안에서 카메라를 꺼내서 날 촬영하다니."
    d "ㅎㅎㅎ"
    scene ch06_hhouse01_66 at hand_camera with Dissolve(0.8)
    l "너 솔직히 말해봐."
    l "내 사진보고 딸쳤지? 어?"
    l "니 친구들과 막 돌려보고 그랬지?"
    l "그랬어 안그랬어?"
    scene ch06_hhouse01_67 at hand_camera with Dissolve(0.8)
    d "하하하."
    d "비밀이에요."
    d "딸 쳤을수도 있고 아닐수도 있어요 하하하."
    scene ch06_hhouse01_68 at hand_camera with Dissolve(0.8)
    l "어린놈이 변태 같이 말이야."
    h "변태는 너야 레나."
    h "그는 아무 잘못 없어."
    h "세상에 어떤 미친 여자가 길거리에서 옷을 벗냐고."
    h "무슨 원시인이야?"
    l "ㅎㅎㅎ"
    scene ch06_hhouse01_69 at hand_camera with Dissolve(0.8)
    l "........."
    pause
    scene ch06_hhouse01_69-02 at hand_camera with Dissolve(0.8)
    l "너 여자친구 없지?"
    scene ch06_hhouse01_70 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_71 at hand_camera with Dissolve(0.8)
    d "네 없어요."
    l "그럴줄 알았다."
    l "너 같이 어리숙한 놈에게 여친이 있을리가."
    d "......"
    d "아니 실은 있었는데 학기 중간에 헤어졌어요."
    l "그게 없는거란 말이잖아!!"
    h "레나..."
    h "그를 좀 가만히 나둬..."
    scene ch06_hhouse01_72 at hand_camera with Dissolve(0.8)
    l "안쓰러워라."
    l "한참 혈기왕성한 나이인데 안타깝네 ㅎㅎ."
    l "........"
    l "매일 섹스하고 싶을거 아냐? 하하하."
    h "레나 제발좀..."
    scene ch06_hhouse01_73 at hand_camera with Dissolve(0.8)
    d "그....그렇죠..ㅎㅎ"
    d "섹스...."
    scene ch06_hhouse01_73-01 at hand_camera with Dissolve(0.8)
    d "**(damn.....)**"
    d "**(난 술마시지도 않았는데 취한 느낌이야..)**"
    scene ch06_hhouse01_73-02 at hand_camera with Dissolve(0.8)
    d "............"
    h "그거 알아 레나?"
    l "어떤거?"
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_74 at hand_camera with Dissolve(0.8)
    h "엊그제 그와 키스 했었어."
    l "??"
    l "뭐라고??"
    scene ch06_hhouse01_75 at hand_camera with Dissolve(0.8)
    l "이 녀석과 키스 했었다고?"
    h "으흥."
    l "어떻게?"
    l "그러니까 내 말은..."
    l "무슨 상황이었는데?"
    play sound "audio/ambi/water02.mp3"
    scene ch06_hhouse01_76 at hand_camera with Dissolve(0.8)
    h "ㅎㅎ 몰라."
    h "어쩌다 보니.."
    h "뭐 아침 인사였달까? 하하."
    scene ch06_hhouse01_76-01 at hand_camera with Dissolve(0.8)
    l "아침 인사??"
    l "무슨 말이야 그게??"
    l "랜드레이디와 세입자가 아침 인사로 키스를 누가해?"
    l "설마 둘이 잔거아냐??!!"
    scene ch06_hhouse01_76-02 at hand_camera with Dissolve(0.8)
    h "아 미친 소리좀 하지마 레나."
    h "자긴 누가 누구랑 자."
    h "그냥 아줌마와 세입자의 작은 에피소드였다니까."
    h "소꿉장난같은거 였다고."
    scene ch06_hhouse01_77 at hand_camera with Dissolve(0.8)
    l "푸!"
    l "안봐도 뻔하다."
    l "삐쭛삐쭛 아주 둘이 얼굴 빨개지고 난리도 아니었겠지."
    h "안그랬거든?"
    l "어린 대학생이랑 키스하니까 너도 대학교로 돌아간거 갔드나?? 허??"
    h "내가 말을 말아야지.."
    h "그냥 첫출근 응원해준거야."
    scene ch06_hhouse01_77-02 at hand_camera with Dissolve(0.8)
    l "............"
    l "**(그러고보니 난 얘랑 키스도 안했잖아..)**"
    pause
    l "**(아니 저런 꼬맹이와 키스는 딱히 하고싶진 않았지.....)**"
    l "**(뭐 저 꼬마의 자지만 있었으면 됐으니까.)**"
    l "**(.........)**"
    l "**(뭐야 [h_name]은 얘를 마음에 두고있는거야????)**"
    l "**(헐.......)**"
    l "**(그새 정이 든건가?? 성욕이 아니라???)**"
    scene ch06_hhouse01_78 at hand_camera with Dissolve(0.8)
    n "레나는 잠시 무언가 생각했다."
    pause
    n "그리고 무언가 결론이 난 듯 입을 열었다."
    stop music fadeout 1.0
    scene ch06_hhouse01_79 at hand_camera with Dissolve(0.8)
    l "옆에 가까이 와서 앉아."
    scene ch06_hhouse01_80 at hand_camera with Dissolve(0.8)
    d "네?"
    scene ch06_hhouse01_79 at hand_camera with Dissolve(0.8)
    l "거기 혼자 있지 말고 옆에 가서 앉으라고."
    l "거기 그러고 있으니까 시야가 거슬리잖아."
    scene ch06_hhouse01_80 at hand_camera with Dissolve(0.8)
    d "..........."
    d "네 알겠어요."
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_81 at hand_camera with Dissolve(1.2)
    play music "audio/bgm/night05.mp3"
    pause
    scene ch06_hhouse01_82 at hand_camera with Dissolve(0.8)
    n "그는 다시한번 잠시 동작을 멈추고 의도적으로 자신의 성기를 노출시켰다."
    pause
    n "[h_name]과 레나 모두 그의 의도를 바로 알수 있었다."
    scene ch06_hhouse01_82-02 at hand_camera with Dissolve(1.2)
    d "**(이렇게 레나와 가까이 있으니까 며칠 전 일이 계속 생각나네..ㅎㅎ)"
    d "**(혹시 오늘도 기회가 있진 않을까?...)"
    play sound "audio/ambi/water02.mp3"
    scene ch06_hhouse01_83 at hand_camera with Dissolve(0.8)
    l "아니 바보야 [h_name]옆에 앉으라고."
    d "아..네..."
    d "전 레나 옆에 앉으라는줄 알았어요..."
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_84 at hand_camera with Dissolve(0.8)
    h "**(홀리.....)**"
    l "**(그래...그렇게....)**"
    l "**(그녀에게 너의 물건을 계속 보여주란말이야.)**"
    scene ch06_hhouse01_85 at hand_camera with Dissolve(1.2)
    n "그는 조심히 랜드레이디의 옆에 앉았다."
    pause
    n "그녀와 같이 마주보고 대화한적은 많았지만 이 처럼 어깨를 나란히 하고 앉은 것은 처음이었다."
    scene ch06_hhouse01_86 at hand_camera with Dissolve(1.2)
    n "그리고 모두가 나체가 된 지금 세 사람의 성적인 긴장감은 올라가기 시작했다."
    h "..........."
    scene ch06_hhouse01_87 at hand_camera with Dissolve(1.0)
    pause
    scene ch06_hhouse01_88 at hand_camera with Dissolve(0.8)
    h "하하하"
    h "날 엄청 걱정스럽게 쳐다보네."
    d "네??"
    h "걱정하지 마요."
    h "오늘은 그냥 기분좋으려고 살짝만 마시는거에요."
    h "그 이상한 자세로 날 들지 않아도 돼요 오늘은 하하하."
    scene ch06_hhouse01_89 at hand_camera with Dissolve(0.8)
    d "아 괜찮습니다."
    d "전 신경쓰지마세요 ㅎㅎ"
    l "........"
    d "편하게 마셔도 됩니다 제가 있으니까요."
    l "뭐야 이 녀석 그 느끼한 말은."
    l "내 여자친구에게 작업치는거야 지금??"
    play voice_f "audio/sex/kissshort02.mp3"
    scene ch06_hhouse01_90 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_91 at hand_camera with Dissolve(0.8)
    l "[h_name]."
    h "응?"
    l "저 처량한 꼬마를 봐."
    pause
    l "지금 너와 키스하고 싶어서 미칠려고 하잖아."
    h "뭐래 자꾸.."
    l "아니 너 언제부터 그렇게 까칠했어?"
    l "녀석의 얼굴을 보라니까."
    scene ch06_hhouse01_92 at hand_camera with Dissolve(0.8)
    pause
    h "........"
    l "오늘은 왜 그렇게 매정한거야 허??"
    scene ch06_hhouse01_91 at hand_camera with Dissolve(0.8)
    l "외로워서 미칠려고 하잖아."
    h "아니 그가 외로운데 나보고 뭘 어쩌라고.."
    d "아..아니 꼭 그런건...."
    scene ch06_hhouse01_92 at hand_camera with Dissolve(0.8)
    pause
    h "........"
    scene ch06_hhouse01_93 at hand_camera with Dissolve(0.8)
    h "너...."
    h "...."
    d "........"
    h "너 외롭니??"
    d "네??"
    stop music fadeout 1.0
    pause
    h "외로운거야?"
    play music "audio/bgm/night04.mp3"
    scene ch06_hhouse01_94 at hand_camera with Dissolve(0.8)
    n "[h_name]의 예상치 못한 질문에 그는 잠시 머뭇거렸다."
    d "........"
    n "그는 그녀의 부드러운 목소리가 자신의 가슴을 후벼 파는 듯한 깊은 감정을 느꼈다."
    pause
    d "조....조금요 헤헤.."
    h "........"
    scene ch06_hhouse01_93 at hand_camera with Dissolve(0.8)
    h "........"
    h "나랑 같이 사는데 외로워?"
    d "아뇨 그건아닌데...."
    d "뭐랄까....."
    h "........"
    scene ch06_hhouse01_94 at hand_camera with Dissolve(0.8)
    d "그런거랑은 좀 다르긴한데...."
    pause
    d "뭐 아시잖아요 제가 어떤 말을 하는지 ㅎㅎ"
    pause
    d "제 가정사 뭐 그런것들이요..."
    h "........"
    d "근데 뭐 다들 그러고 사는거 아닐까요? ㅎㅎ"
    pause
    d "그러니까 제 말은..."
    pause
    d "뭐 누구나 다 자기안에 공허한 부분들이 있잖아요."
    d "그러니까...."
    pause
    d "제 경우엔 제 성장 배경이 그렇다보니 인간관계에 집착하는 면이 있는거 같아요."
    pause
    d "아니 더 정확히 말하면 연상의 여성에게 인정받거나 관심받고 싶은게 있어요."
    pause
    d "[h_name]이나 레나 같은......"
    scene ch06_hhouse01_93 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_helen", 1, "love_helen")
    h "........"
    l "**(이번 건 좋았다 꼬마야.)**"
    pause
    l "**(연기가 아니었다면 박수를 쳐주고 싶네 ㅎㅎㅎ)**"
    pause
    h "**(그는 가끔 이렇게 내 모성애를 자극한다니까...)**"
    h "**(평생을 엄마 없이 쓸쓸하게 살았을텐데.......)**"
    pause
    h "**(하숙집에서도 쓸쓸하면 안되지..)**"
    scene ch06_hhouse01_94-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_94-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_93 at hand_camera with Dissolve(0.8)
    h "이리 가까이와 허니."
    scene ch06_hhouse01_95 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_96 at hand_camera with Dissolve(0.8)
    d "**(젠장....뭐지 이 분위기는...)**"
    d "**(왜 랜드레이디를 보는것 만으로 자지가 터질거같지???)"
    d "**(마치 나한테 페로몬을 뿜어내는거 같아... )"
    scene ch06_hhouse01_96-02 at hand_camera with Dissolve(1.2)
    pause
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_hhouse01_97 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_98 at hand_camera with Dissolve(0.8)
    h "나랑 지내는 동안은 외롭다는 말 하지마 알겠지?"
    d "네 그럴게요....하..."
    play voice_f "audio/sex/kissshort01.mp3"
    scene ch06_hhouse01_97 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_98 at hand_camera with Dissolve(0.8)
    h "........"
    scene ch06_hhouse01_98-01 at hand_camera with Dissolve(0.8)
    l "**(예스....예스....)**"
    l "**(서로를 위로해주라고.)**"
    scene ch06_hhouse01_98-02 at hand_camera with Dissolve(0.8)
    h "**(하아.......)**"
    h "**(나 왜이러지....이런 어린애하고...)**"
    h "**(술 때문인가..)**"
    h "괜찮겠니?..."
    d "아...네..."
    h "그럼 나에게 키스해."
    h "내일 일어나면 잊어버려야 해. 알았지?"
    menu:
        n "What should I do?"
        "그녀에게 뜨겁게 키스한다.":
            play voice_f "audio/sex/kisslong01.mp3" loop
            scene ch06_hhouse01_99 at hand_camera with Dissolve(0.8)
            d "**(맙소사.......)**"
            if not in_replay:
                $ add_point("lust_helen", 1, "lust_helen")
                $ add_point("lust_lena", 1, "lust_lena")
            d "**(아......)**"
            d "**(심장이 터질거 같아.....)**"
    scene ch06_hhouse01_100 at hand_camera with Dissolve(0.8)
    h "**(흐응........)**"
    pause
    h "**(지금 뭐하는거지........)**"
    h "**(이런 어린애와 키스하면서 흥분하다니....)**"
    scene ch06_hhouse01_101 at hand_camera with Dissolve(0.8)
    h "**(니가 무슨 고등학교 치어리더냐??!!!!)**"
    h "**(이런 떨림이 너무 부끄러워.....)**"
    scene ch06_hhouse01_99 at hand_camera with Dissolve(0.8)
    h "**(이게 뭐지???.......)**"
    h "**(얘를 상대로 성욕을 느낀다고???)**"
    stop voice_f
    scene ch06_hhouse01_102 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh14.mp3"
    h "하하하"
    h "술도 얼마 안마셨는데 취했나봐요 하하하."
    scene ch06_hhouse01_103 at hand_camera with Dissolve(0.8)
    l "참 애처롭다 애처로워...."
    l "뭐하는거야 둘이?"
    h "아무말 하지마 레나."
    l "야 [d_name]!!"
    l "이리와서 우리 앞에 서봐."
    scene ch06_hhouse01_104 at hand_camera with Dissolve(0.8)
    d "네??"
    l "이리와서 우리 앞에 서보라고."
    pause
    d "저 지금 다 벗었잖아요."
    l "뭐?? 참나..."
    scene ch06_hhouse01_105 at hand_camera with Dissolve(0.8)
    l "여기 전부다 다 지금 나체거든?"
    h "그만해 레나."
    d "........"
    l "아 그냥 빨리와서 서봐."
    l "내가 잡아먹냐?"
    d "네...알겠어요."
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_106 at hand_camera with Dissolve(1.2)
    pause
    menu:
        n "What should I do?"
        "그녀들에게 나의 자지를 보여준다.":
            play music "audio/bgm/erotic12.mp3"
            scene ch06_hhouse01_107 at hand_camera with Dissolve(0.8)
            h "............."
    scene ch06_hhouse01_108 at hand_camera with Dissolve(1.2)
    n "그는 레나와 [h_name]앞에 섰다."
    pause
    n "그리고 한껏 발기한 자신의 고추를 그녀들에게 보여주었다."
    scene ch06_hhouse01_109 at hand_camera with Dissolve(1.2)
    h "**(맙소사....)**"
    h "....."
    scene ch06_hhouse01_110 at hand_camera with Dissolve(0.8)
    l "어때? ㅎㅎ"
    l "이 녀석은 타고났다고."
    h "....."
    l "내가 얘기 했잖아."
    l "이 녀석은 이 세상의 모든 아줌마들에게 사랑받을 녀석이야 헤헷."
    scene ch06_hhouse01_110-02 at hand_camera with Dissolve(0.8)
    l "조금 더 가까이 와봐."
    h "하지마 레나.."
    scene ch06_hhouse01_110-03 at hand_camera with Dissolve(0.8)
    l "니 생각은 어때 [h_name]?"
    h "내 새..생각이라니..."
    h "그게 무슨 말이야?"
    l "아니 이 녀셕의 자지가 어떄 보이냐고."
    scene ch06_hhouse01_111 at hand_camera with Dissolve(0.8)
    h "아...."
    h ".........."
    pause
    h "그는... 건강해..."
    h ".........."
    pause
    h "그는... 건강해다고..."
    scene ch06_hhouse01_112 at hand_camera with Dissolve(0.8)
    l "어린 남자니 당연히 건강하겠지 하하."
    l "그게 전부야?"
    pause
    l "왜 말하기 부끄러워 아줌마? 하하하."
    h "부끄럽긴 누가 부끄럽다고..."
    l "엄청 꽉찰거 같지? 하하하."
    h "......"
    scene ch06_hhouse01_113 at hand_camera with Dissolve(0.8)
    l "익숙한 풍경이지? 하하하."
    d "........."
    d "아...하하...네..."
    h "........"
    l "빨아줄까?"
    h "레나!!!!!"
    scene ch06_hhouse01_114 at hand_camera with Dissolve(0.8)
    d ".........."
    l "왜 대답이 없어?"
    scene ch06_hhouse01_113 at hand_camera with Dissolve(0.8)
    l "싫어?ㅎㅎ"
    l "오늘 밤을 이대로 끝낼거야??"
    l "이 분위기에서 너도 지금 뭔가 하고싶잖아? 하하하."
    pause
    l "당장이라도 너의 자지를 어딘가에 집어넣고 싶지않아?"
    h "레나!!!!!!!!"
    h "적당히 해!!"
    l "맞지?"
    scene ch06_hhouse01_114 at hand_camera with Dissolve(0.8)
    d ".........."
    d "네 맞아요...."
    h "[d_name]!!!!!"
    d "빠..빨아주세요.."
    play voice_f "audio/voices/mwhat03.mp3"
    h "뭐??!!"
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_115 at hand_camera with Dissolve(0.8)
    h "그러지마 [d_name]!!"
    pause
    h "뭐하려는거야 레나??!!"
    h "[d_name]에게 장난하지마!"
    scene ch06_hhouse01_116 at hand_camera with Dissolve(0.8)
    l "장난 하는거 아닌데?"
    l "어떤 여자가 이런 자지를 잡고 장난을 하겠어?"
    h "!!!!!!!!!!!"
    h "하지마 레나!!"
    scene ch06_hhouse01_117 at hand_camera with Dissolve(0.8)
    h "정말 이 집에서 쫓아낼거야!"
    play music "audio/bgm/erotic10.mp3"
    scene ch06_hhouse01_117-02 at hand_camera with Dissolve(0.8)
    d "아......레나....."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_hhouse01_118 at hand_camera with Dissolve(0.8)
    h "!!!!!!!!!!!"
    n "레나는 [h_name]의 만류도 아랑곳 하지 않고 그의 고추를 입에 넣었다."
    d "아......"
    d "레나........."
    play voice_f "audio/sex/gag03.wav" volume 2.0
    l "꺼억..."
    scene ch06_hhouse01_119 at hand_camera with Dissolve(0.8)
    n "[h_name]은 자신의 친구이자 연인이 다른 남성과 오랄섹스를 하는 모습을 보고 한동안 말문이 막혔다."
    pause
    scene ch06_hhouse01_120 at hand_camera with Dissolve(1.2)
    n "그녀는 눈을 떨구고 한동안 찰랑거리는 물소리와 레나의 입과 [d_name]의 성기가 만나 만들어내는 소리를 듣고 있었다."
    scene ch06_hhouse01_121 at hand_camera with Dissolve(1.1)
    h "하.....이제 알겠다...."
    pause
    h "그날밤에 너희들이였구나..."
    h "........"
    h "그건 내 꿈이 아니라 너희들이었어..."
    scene ch06_hhouse01_122 at hand_camera with Dissolve(0.8)
    n "[h_name]은 말 없이 그들의 행위를 지켜 보았다."
    pause
    n "자신에게 특별한 의미를 가진 남녀의 성행위를 보는것은 설명할 수 없는 감정을 불러일으켰다."
    image ch06_hhouse01_bj01:
        "ch06_hhouse01_123" with dissolve
        0.1
        "ch06_hhouse01_124" with dissolve
        0.1
        "ch06_hhouse01_125" with dissolve
        0.1
        "ch06_hhouse01_126" with dissolve
        0.1
        "ch06_hhouse01_127" with dissolve
        0.1
        "ch06_hhouse01_128" with dissolve
        0.1
        "ch06_hhouse01_127" with dissolve
        0.1
        "ch06_hhouse01_126" with dissolve
        0.1
        "ch06_hhouse01_125" with dissolve
        0.1
        "ch06_hhouse01_124" with dissolve
        0.1
        repeat
    play voice_f "audio/sex/oral03.mp3" volume 1.7 loop
    scene ch06_hhouse01_bj01 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
        $ add_point("lust_lena", 1, "lust_lena")
    d "아 레나......."
    pause
    d "아....미..미안해요 [h_name]..."
    h "........"
    h "**(맙소사...)**"
    pause
    pause
    h "**(기분이 이상해...)**"
    scene ch06_hhouse01_129 at hand_camera with Dissolve(0.8)
    h "**(............)**"
    scene ch06_hhouse01_bj01 at hand_camera with Dissolve(0.8)
    d "아아아.........."
    pause
    h "(마이갓.....)"
    scene ch06_hhouse01_130 at hand_camera with Dissolve(0.8)
    d "아...레나....."
    h "........"
    d "너..너무 좋아요.."
    d "그 날밤 이후로 계속 레나만을 생각했어요...."
    scene ch06_hhouse01_130-02 at hand_camera with Dissolve(0.8)
    h "**(맙소사...)**"
    l "커헉......"
    h "**(뭘 어떻게 해야 할지 모르겠네...)**"
    h "**(오늘따라 레나가 왜 이리 낯설지....)**"
    image ch06_hhouse01_bj02:
        "ch06_hhouse01_131" with dissolve
        0.13
        "ch06_hhouse01_132" with dissolve
        0.13
        "ch06_hhouse01_133" with dissolve
        0.13
        "ch06_hhouse01_134" with dissolve
        0.13
        "ch06_hhouse01_135" with dissolve
        0.13
        "ch06_hhouse01_136" with dissolve
        0.13
        "ch06_hhouse01_135" with dissolve
        0.13
        "ch06_hhouse01_134" with dissolve
        0.13
        "ch06_hhouse01_133" with dissolve
        0.13
        "ch06_hhouse01_132" with dissolve
        0.13
        repeat
    scene ch06_hhouse01_bj02 at hand_camera with Dissolve(0.8)
    d "으으......."
    pause
    d "젠장......"
    h "...."
    image ch06_hhouse01_bj03:
        "ch06_hhouse01_b01" with dissolve
        0.1
        "ch06_hhouse01_b02" with dissolve
        0.1
        "ch06_hhouse01_b03" with dissolve
        0.1
        "ch06_hhouse01_b04" with dissolve
        0.1
        "ch06_hhouse01_b05" with dissolve
        0.1
        "ch06_hhouse01_b06" with dissolve
        0.1
        "ch06_hhouse01_b05" with dissolve
        0.1
        "ch06_hhouse01_b04" with dissolve
        0.1
        "ch06_hhouse01_b03" with dissolve
        0.1
        "ch06_hhouse01_b02" with dissolve
        0.1
        repeat
    scene ch06_hhouse01_bj03 at hand_camera with Dissolve(0.8)
    d "아.......레나......"
    pause
    d "아..........."
    play voice_f "audio/voices/fsigh03.wav"
    scene ch06_hhouse01_136-01 at hand_camera with Dissolve(0.8)
    l "하아......"
    scene ch06_hhouse01_136-02 at hand_camera with Dissolve(0.8)
    l "하아......"
    l "그의 자지가 정말 맛있어 ㅎㅎ"
    h "......."
    l "빠는것만으로 나도 오르가즘을 느낄수도 있을거 같다니까 ㅎㅎ"
    h "........."
    h "아니...그게 무슨...."
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_136-03 at hand_camera with Dissolve(1.2)
    pause
    l "후우.."
    scene ch06_hhouse01_136-04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_136-05 at hand_camera with Dissolve(0.8)
    l "이리와 꼬마야."
    l "니가 뭘 잘하는지 나에게 보여줘."
    d "네??"
    d "그게 무슨말인지....."
    play voice_f "audio/voices/milflaugh15.mp3"
    l "하하하."
    l "니 하고싶은거 해보라고."
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_136-06 at hand_camera with Dissolve(0.8)
    h "미안."
    h "난 나가야겠어."
    d "!!!"
    h "둘이 잘 놀아."
    scene ch06_hhouse01_136-07 at hand_camera with Dissolve(0.8)
    l "잠깐만 자기야."
    h "내 손놔!!"
    scene ch06_hhouse01_136-08 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_136-09 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_136-10 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_136-11 at hand_camera with Dissolve(0.8)
    d "..........."
    d "**(마이갓....)**"
    scene ch06_hhouse01_137 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_138 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_139 at hand_camera with Dissolve(0.8)
    pause
    image ch06_hhouse01_hj01:
        "ch06_hhouse01_138" with dissolve
        0.7
        "ch06_hhouse01_139" with dissolve
        0.7
        repeat
    scene ch06_hhouse01_hj01 at hand_camera with Dissolve(0.8)
    d "**(쉣......)**"
    pause
    d "**(뭐하는 거지??......)**"
    scene ch06_hhouse01_140 at hand_camera with Dissolve(0.8)
    d "**(그녀가 무슨 생각이지?)**"
    pause
    d "**(자....자위를 하란건가??)**"
    scene ch06_hhouse01_141 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/touch01.mp3"
    jump ch06_hhouse03

label ch06_hhouse03:
    if not in_replay:
        $ persistent.unlock_ch06_hhouse03 = True
    scene ch06_hhouse01_142 at hand_camera with Dissolve(0.8)
    pause
    image ch06_hhouse01_hj02:
        "ch06_hhouse01_143" with dissolve
        0.07
        "ch06_hhouse01_144" with dissolve
        0.07
        "ch06_hhouse01_145" with dissolve
        0.07
        "ch06_hhouse01_146" with dissolve
        0.07
        "ch06_hhouse01_147" with dissolve
        0.07
        "ch06_hhouse01_148" with dissolve
        0.07
        "ch06_hhouse01_147" with dissolve
        0.07
        "ch06_hhouse01_146" with dissolve
        0.07
        "ch06_hhouse01_145" with dissolve
        0.07
        "ch06_hhouse01_144" with dissolve
        0.07
        repeat
    scene ch06_hhouse01_hj02 at hand_camera with Dissolve(0.8)
    d "쉣......"
    scene ch06_hhouse01_142 at hand_camera with Dissolve(0.8)
    pause
    n "그녀는 속도를 올리라는 듯 그의 엉덩이를 더 압박했다."
    image ch06_hhouse01_hj03:
        "ch06_hhouse01_143" with dissolve
        0.04
        "ch06_hhouse01_144" with dissolve
        0.04
        "ch06_hhouse01_145" with dissolve
        0.04
        "ch06_hhouse01_146" with dissolve
        0.04
        "ch06_hhouse01_147" with dissolve
        0.04
        "ch06_hhouse01_148" with dissolve
        0.04
        "ch06_hhouse01_147" with dissolve
        0.04
        "ch06_hhouse01_146" with dissolve
        0.04
        "ch06_hhouse01_145" with dissolve
        0.04
        "ch06_hhouse01_144" with dissolve
        0.04
        repeat
    scene ch06_hhouse01_hj03 at hand_camera with Dissolve(0.8)
    d "쉣......"
    pause
    d "윽..."
    scene ch06_hhouse01_149 at hand_camera with Dissolve(0.8)
    d "아....레나...."
    d "아...[h_name]!!"
    h "..........."
    scene ch06_hhouse01_150 at hand_camera with Dissolve(0.8)
    d "아..레나.."
    d "저 금방 사정할거 같은데 어떻게 하죠??...."
    d "쉣......"
    scene ch06_hhouse01_151 at hand_camera with Dissolve(0.8)
    l "..........."
    scene ch06_hhouse01_152 at hand_camera with Dissolve(0.8)
    l "오늘은 좀 빠르네??"
    l "내 얼굴에 사정할래?"
    scene ch06_hhouse01_153 at hand_camera with Dissolve(0.8)
    h "그러지마 레나!!"
    h "니가 무슨 창녀야?!!"
    d "아아....저..저기 잠깐만!!!"
    scene ch06_hhouse01_154 at hand_camera with Dissolve(0.8)
    d "악!!!!! 숙녀 분들!!!!!"
    h "뭐???!!!!!!!!!!!"
    play voice_f "audio/sex/cum01.mp3"
    scene ch06_hhouse01_155 at hand_camera with Dissolve(0.8)
    pause
    play music "audio/bgm/erotic03.mp3"
    scene ch06_hhouse01_156 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fhurt07.mp3"
    h "!!!!!!!!!!!!!!!!!!"
    h "흐윽....."
    d "아 미안합니다!!!!"
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
        $ add_point("sus_helen", 1, "sus_helen")
    scene ch06_hhouse01_157 at hand_camera with Dissolve(0.8)
    d "아!!!!!!"
    scene ch06_hhouse01_158 at hand_camera with Dissolve(0.8)
    d "아 레나........."
    scene ch06_hhouse01_159 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/cum01.mp3"
    d "우욱!!!!!"
    scene ch06_hhouse01_159-02 at hand_camera with Dissolve(1.2)
    l "우욱.."
    play voice_f "audio/sex/cum01.mp3"
    l "**(아 많이도 나오네.....)**"
    l "**(완전 수도꼭지네 이거.)**"
    scene ch06_hhouse01_160 at hand_camera with Dissolve(0.8)
    n "꿀꺽(의성어)"
    l "하아......"
    l "많이도 나오네.."
    d "아.............."
    scene ch06_hhouse01_161 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_162 at hand_camera with Dissolve(0.8)
    h "!!!!!!!!!!!!!!"
    stop music fadeout 1.0
    scene ch06_hhouse01_163 at hand_camera with Dissolve(0.8)
    pause
    n "레나는 그의 성기를 붙잡고 [h_name]의 입에 가져다대었다."
    pause
    n "[h_name]은 즉시 자신의 입술로 그의 귀두의 촉감과 따뜻한 온도를 느꼈다."
    h "으읍!!!!"
    scene ch06_hhouse01_164 at hand_camera with Dissolve(0.8)
    l "입 벌려봐 어서.."
    l "이 꼬맹이가 외롭지 않게 해줘."
    h "우욱!!!"
    l "그 마음 따뜻하고 아름다운 [h_name]의 본 모습을 보여달라고."
    n "[d_name]은 본능적으로 자신의 허리를 앞으로 전진시켰다."
    scene ch06_hhouse01_154 at hand_camera with Dissolve(0.8)
    d "아앗!!!!!!"
    play sound "audio/sex/liquid01.mp3"
    scene ch06_hhouse01_164-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_helen", 1, "lust_helen")
    d "아으..........."
    h "!!!!!!!!!!!!!"
    pause
    d "아....[h_name]....."
    n "[h_name]의 입안에 미끌거리고 짭짜름한 액체가 느껴졌다."
    scene ch06_hhouse01_164-03 at hand_camera with Dissolve(0.8)
    d "아으..........."
    h "............"
    menu:
        n "What should I do?"
        "자지를 그녀의 입으로 밀어넣는다.":
            play sound "audio/sex/liquid01.mp3"
            scene ch06_hhouse01_164-04 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/gag03.wav" volume 2.0
            h "커억..."
            d "응(신음)......."
            l "아으....."

            jump ch06_hhouse03_branch

label ch06_hhouse03_branch:
    if lust_helen >= 49:
        jump ch06_hhouse03_highlust
    else:
        jump ch06_hhouse03_lowlust

label ch06_hhouse03_highlust:
    if not in_replay:
        $ persistent.unlock_ch06_hhouse03_highlust = True
    menu:
        n "What should I do?"
        "자지를 그녀의 입으로 더 깊게 밀어넣는다.":
            play voice_f "audio/sex/gag03.wav" volume 2.0    
            scene ch06_hhouse01_164-05 at hand_camera with Dissolve(0.8)
            h "꺼헉..."
    play voice_f "audio/sex/gag03.wav" volume 2.0    
    scene ch06_hhouse01_164-05 at hand_camera with Dissolve(0.8)
    h "꺼헉..."
    n "그녀 입으로 그의 자지가 더 깊이 들어왔다."
    pause
    n "[h_name]은 충격으로인해 아무런 반응도 할 수 없었다."
    d "으아.........."
    d "[h_name]........"
    scene ch06_hhouse01_164-05 at hand_camera with Dissolve(0.8)
    n "그러자 곧 그의 자지에서 정액이 더 흘러나왔다."
    pause
    n "그의 정액은 곧장 그녀의 후두로 흘러들어갔다."
    scene ch06_hhouse01_164-06 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/gag02.wav" volume 2.0   
    l "이거야 [h_name]..."
    l "바로 이거라고."
    l "이게 내 여자지."
    d "아..............[h_name]...."
    l "이녀석이 주는 젊음의 크림을 먹으라고."
    scene ch06_hhouse01_164-05 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_164-07 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fcough04.mp3"
    pause
    pause
    h "[d_name]!!!!!!!!!!!!"
    jump ch06_hhouse04

label ch06_hhouse03_lowlust:
    scene ch06_hhouse01_165 at hand_camera with Dissolve(0.8)
    h "레나!!!!!!!!!!!!!!!!!"
    play music "audio/bgm/night05.mp3"
    jump ch06_hhouse04

label ch06_hhouse04:
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_166 at hand_camera with Dissolve(0.8)
    h "(여자가 할 수 있는 쌍욕.)"
    h "넌 진짜 최악이야!!!!!!!!!"
    h "최악이라고!!!"
    scene ch06_hhouse01_167 at hand_camera with Dissolve(0.8)
    h "너희 들 모두다!!!!!"
    h "어떻게 이럴수 있어??!!!!"
    pause
    h "세상에 어떻게 이런 짓을...."
    play sound "audio/ambi/water02.mp3"
    scene ch06_hhouse01_168 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_hhouse01_168-02 at hand_camera with Dissolve(1.2)
    d "**(젠장......)**"
    pause
    d "**(내가 지금 무슨 짓을 저지른거지?....)**"
    d "**(이번건 진짜 큰 일인거 같은데...)**"
    pause
    d "**(나도 모르게 밀어넣었다.....)**"
    scene ch06_hhouse01_169 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_170 at hand_camera with Dissolve(1.2)
    d "아 좆됐다......"
    scene ch06_hhouse01_171 at hand_camera with Dissolve(0.8)
    l "맞아."
    pause
    l "너 좆된거 같아 정말로.."
    d "......."
    pause
    l "오늘 짐싸야 할거 같은데?"
    scene ch06_hhouse01_172 at hand_camera with Dissolve(0.8)
    d "**(레나는 마녀야.....)**"
    d "**(레나는 마녀라고.......)**"
    d "**(혹시 사람을 조종하는 능력이 있는거 아닐까.....)**"
    d "**(.......)**"
    d "**(이제 진짜 어떡하지......)**"
    scene ch06_hhouse01_173 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_174 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/ambi/water03.mp3" volume 1.7
    scene ch06_hhouse01_170 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_hhouse01_175 at hand_camera with Dissolve(1.3)
    pause
    scene ch06_hhouse01_176 at hand_camera with Dissolve(1.2)
    pause
    stop ambient fadeout 1.0
    jump ch06_otable01

label ch06_otable01:
    if not in_replay:
        $ persistent.unlock_ch06_otable01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "The next morning" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal02.mp3"
    play ambient "audio/ambi/park01.mp3" loop
    scene ch06_otable01_01 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_05 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_06 at hand_camera with Dissolve(1.2)
    d "하........."
    pause
    scene ch06_otable01_07 at hand_camera with Dissolve(1.2)
    d "진짜 하늘이 맑다."
    pause
    d "휴일이 이렇게 행복한거라니.."
    d "이래서 사람들이 주말주말 하는거고만..."
    scene ch06_otable01_08 at hand_camera with Dissolve(0.8)
    d "젠장...."
    d "기억이 가물가물해......"
    d "......."
    scene ch06_otable01_09 at hand_camera with Dissolve(0.8)
    d "그녀의 입에 내 고추가 어떻게 들어간건지 기억이 안나네...."
    d "내가 밀어넣었었나...."
    pause
    d "아니면 레나가 잡고 밀어넣었었나?......"
    pause
    d "아님 [h_name]이 입을 벌렸었나....하....."
    d "뭐였지???"
    d "기억이 나야 어떻게 사과라도 하는데 참...."
    scene ch06_otable01_08 at hand_camera with Dissolve(0.8)
    d "랜드레이디의 얼굴을 이제 어떻게 보지....."
    pause
    d "하......."
    scene ch06_otable01_08-02 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/phonering02.mp3" loop
    n "폰이 울린다."
    d "응? 누구지?"
    stop sound
    scene ch06_otable01_10 at hand_camera with Dissolve(1.2)
    d "안녕하세요 올리 ㅎㅎ"
    d "잘 지냈어요?"
    pause
    d "안그래도 문자 답장이 없어서 왜그런가 걱정했었어요.."
    pause
    d "아 전 그냥 집근처에서 놀고 있어요."
    pause
    d "........"
    d "아 아뇨. 저 혼자있죠."
    scene ch06_otable01_11 at hand_camera with Dissolve(0.8)
    d "........"
    pause
    d "아 그래요?"
    d "........"
    d "알겠어요."
    d "바로 갈게요!"
    scene ch06_otable01_12 at hand_camera with Dissolve(1.2)
    d "아우......"
    scene ch06_otable01_13 at hand_camera with Dissolve(1.2)
    pause
    d "올리를 만나러 가볼까 ㅎㅎ"
    play sound "audio/ambi/bicycle01.mp3"
    scene ch06_otable01_14 at hand_camera with Dissolve(0.8)
    stop ambient fadeout 1.0
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal04.mp3"
    scene ch06_otable01_15 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_16 at hand_camera with Dissolve(1.2)
    d "안녕하세요 올리."
    o "아 왔구나."
    o "금방왔네?"
    d "아 네......."
    d "전 언제나 빠르잖아요."
    scene ch06_otable01_17 at hand_camera with Dissolve(0.8)
    o "주문하신 음식 나왔습니다."
    o "맛있게 드세요 ㅎㅎ."
    d "..........."
    scene ch06_otable01_18 at hand_camera with Dissolve(0.8)
    o "필요하신거 있으시면 얘기해주세요."
    unknown "네 그럴게요."
    unknown "감사합니다."
    scene ch06_otable01_19 at hand_camera with Dissolve(0.8)
    d "저 왔어요."
    d "오늘 바빠요?"
    scene ch06_otable01_19-02 at hand_camera with Dissolve(0.8)
    o "휴......."
    o "많이 바쁜건 아닌데 오늘 스텔라가 일이 생겨서 못나와."
    o "난 주방에서 요리해야 하니까 니가좀 서빙을 맡아줘."
    o "갑자기 이렇게 부탁해서 미안해."
    scene ch06_otable01_19 at hand_camera with Dissolve(0.8)
    d "아니에요."
    d "올리가 부탁하는데 당연히 도와야죠."
    d "그럼 제가 뭘 하면 돼요??"
    scene ch06_otable01_21 at hand_camera with Dissolve(0.8)
    o "손님들 오면 물주고 맥주달라면 따라줘."
    o "주문 받으면 나에게 문자 보내던가 아님 주방에 와서 말해주던가."
    o "아 앞치마 꼭하고!"
    o "알겠지?"
    scene ch06_otable01_22 at hand_camera with Dissolve(0.8)
    d "네 그렇게 할게요!!"
    d "........."
    o "그리고 되도록이면 손님들 자리는 1층에 잡아."
    o "그래야 니가 편해 ㅎㅎ."
    d "네 ㅎㅎ"
    scene ch06_otable01_23 at hand_camera with Fade(0.8, 1.0, 1.8)
    play music "audio/bgm/normal10.mp3" volume 0.5
    n "그는 난생 처음 서빙을 했다."
    n "올리비아를 만난다는 생각에 한달음에 달려 왔지만 그런 기대감은 일을 시작하자 완전히 잊혀졌다."
    d "**(젠장..)**"
    d "**(은근히 바쁘네!!)**"
    scene ch06_otable01_24 at hand_camera with Dissolve(1.2)
    d "**(이거 생각보다 긴장되잖아!!!!)**"
    pause
    d "**(이거 왜 일저지르는 느낌이지??!!)**"
    scene ch06_otable01_25 at hand_camera with Dissolve(1.2)
    pause
    d "안녕하세요."
    scene ch06_otable01_25-02 at hand_camera with Dissolve(1.2)
    d "저...그...."
    d "루프탑 바에서 뵜었죠 ㅎㅎ...."
    scene ch06_otable01_25-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_26 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_27 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_26 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_28 at hand_camera with Dissolve(1.2)
    o "하아........."
    o "오늘 이 동네 사람 다 몰려드나....."
    d "..........."
    scene ch06_otable01_29 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30-04 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30-05 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_30-06 at hand_camera with Dissolve(1.2)
    pause
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal11.mp3"
    scene ch06_otable01_31 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_31-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_32 at hand_camera with Dissolve(1.2)
    d "하........"
    pause
    d "폭풍이 지나갔나..."
    d "그래도 다행히 실수한건 없는거 같아..."
    pause
    d "돈 계산은 제대로 했나 모르겠네...하...."
    scene ch06_otable01_33 at hand_camera with Dissolve(1.2)
    play voice_f "audio/voices/fsigh06.mp3"
    o "하.....힘들다.."
    o "먹고살기 힘드네.."
    o "땀에 쩔었어..."
    scene ch06_otable01_34 at hand_camera with Dissolve(0.8)
    o "힘들지? 하하"
    d "아니에요. 할만했어요."
    o "마을사람들이 다 널 괴롭히려고 온거같지?"
    scene ch06_otable01_35 at hand_camera with Dissolve(0.8)
    d "하하 처음엔 그렇게 생각했었죠 ㅋㅋ"
    d "오늘 제가 일한다고 올리가 다 소문낸줄 알았다니까요."
    scene ch06_otable01_36 at hand_camera with Dissolve(0.8)
    o "고생했어 ㅎㅎ"
    o "빨리 대강 청소하고 같이 저녁먹자."
    o "주방에 음식 해놨으니 덥히기만 하면돼."
    d "네 좋아요."
    play sound "audio/ambi/vacuum01.mp3"
    scene ch06_otable01_37 at hand_camera with Dissolve(1.2)
    pause
    stop sound
    scene ch06_otable01_38 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_38-02 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_39 at hand_camera with Fade(0.8, 1.0, 1.8)
    pause
    o "드디어 다 끝났다."
    pause
    o "배고프지?"
    scene ch06_otable01_39-02 at hand_camera with Dissolve(1.2)
    d "네 ㅎㅎ"
    pause
    scene ch06_otable01_39-03 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    o "야 그렇게 느끼하게 웃지마 하하하."
    o "그렇게 웃으니까 멍청해 보이잖아."
    pause
    o "머릿속에 뭐가 들어있는거야."
    scene ch06_otable01_40 at hand_camera with Dissolve(0.8)
    o "뒤뜰 있거든?"
    o "저녁 거기서 먹을거니까 밖에 테이블에서 쉬고 있어."
    o "금방 나갈게."
    o "가게 정문은 잠그고 밖으로 나와."
    d "네 알겠어요."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night05.mp3"
    scene ch06_otable01_41 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_42 at hand_camera with Dissolve(1.2)
    d "잘먹겠습니다!!"
    d "엄청 먹음직스러워 보여요 ㅎㅎ"
    d "요즘 올리가 한 음식 자주 먹어서 좋아요."
    scene ch06_otable01_43 at hand_camera with Dissolve(0.8)
    o "오늘 네 덕분에 살았다 허니."
    o "스텔라에게 연락 왔을 때 그냥 하루 문닫을까 했었는데 ㅎㅎ"
    o "알바비는 이따 보내줄게."
    scene ch06_otable01_44 at hand_camera with Dissolve(0.8)
    d "ㅎㅎ 감사합니다."
    d "생각보다 재미있었어요."
    scene ch06_otable01_43 at hand_camera with Dissolve(0.8)
    o "생각보다 어리버리하진 않네."
    o "온실속에 화초처럼 자란줄 알았는데 ㅎㅎ."
    d "온실속에 화초라뇨."
    d "저 나름 거칠게 여기 저기 구른 남자라구요."
    o "........."
    o "암튼 자주봐서 좋네."
    o "어서 먹어."
    scene ch06_otable01_45 at hand_camera with Dissolve(0.8)
    pause
    d "저도 올리랑 자주봐서 좋아요."
    pause
    d "........."
    d "근데 내가 문자 보냈었는데..."
    scene ch06_otable01_46 at hand_camera with Dissolve(0.8)
    o "아 그거..."
    o "..........."
    pause
    o "그냥 어쩌다 보니 답장 못했어."
    scene ch06_otable01_47 at hand_camera with Dissolve(0.8)
    d "아 그랬어요?"
    pause
    o "응."
    d "........"
    d "전 그 일 이후로 올리가 좀 기분이 언짢은가 했어요.."
    d "그래서 좀 걱정했었다구요."
    scene ch06_otable01_48 at hand_camera with Dissolve(0.8)
    o "........"
    o "그일이라니?"
    scene ch06_otable01_49 at hand_camera with Dissolve(0.8)
    d "네?"
    pause
    d "그...저.."
    d "손...그.... 손으로 저에게..."
    scene ch06_otable01_48 at hand_camera with Dissolve(0.8)
    o "........"
    o "아 그거?"
    pause
    o "그건 아무것도 아닌데?"
    scene ch06_otable01_50 at hand_camera with Dissolve(0.8)
    o "내가 남자에게 손으로 해준건 지금까지 500번도 더 될거 같은데? 하하하."
    d "!!!!!"
    d "오...오백번이요??"
    o "응."
    o "그 중에 절반은 뭐 내 남편에게 해준거겠지."
    scene ch06_otable01_51 at hand_camera with Dissolve(0.8)
    d "........."
    d "와우...."
    d "역시 유부녀는 어린 여자들과 차원이 다르네요.."
    stop music fadeout 1.0
    scene ch06_otable01_52 at hand_camera with Dissolve(0.8)
    o ".........."
    pause
    o "역시 유부녀는 어린 여자들과 차원이 다르네요??"
    scene ch06_otable01_52-02 at hand_camera with Dissolve(0.8)
    o "그게 무슨 말이야?"
    d "네?"
    o "그게 무슨 말이냐고."
    d "아..아니...그러니까.."
    o "유부녀는 쉽다는 말이야?"
    d "아뇨!! 그게아니라..."
    o "그 말은 좀 기분 나쁜데?"
    scene ch06_otable01_53 at hand_camera with Dissolve(0.8)
    d "아니......"
    d "그런건 아니었는데..."
    d "......."
    d "미안해요 올리..."
    scene ch06_otable01_52 at hand_camera with Dissolve(0.8)
    o "..........."
    pause
    d "젠장 올리....."
    d "미안해요..."
    scene ch06_otable01_53-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh04.mp3"
    o "하하하하."
    o "또 속냐?"
    o "역시 어리구나 [d_name]..."
    o "어려 어려 ㅎㅎㅎ"
    d "하.....올리....제발...."
    play music "audio/bgm/night05.mp3"
    scene ch06_otable01_53-03 at hand_camera with Dissolve(1.2)
    o "근데 너도 잘 알아야해."
    o "방금 그 말은 아슬아슬했다.."
    pause
    o "나이든 여자들이 쉽다는건 절대 오해야."
    pause
    o "나이들어서 쉬운 여자면 어렸을 때도 쉬운 여자였을거라고."
    o "무슨 말인지 알아?"
    scene ch06_otable01_53-04 at hand_camera with Dissolve(0.8)
    pause
    d "네......"
    d "무슨 말인지 알거 같아요......"
    pause
    o "그래......"
    scene ch06_otable01_53-05 at hand_camera with Dissolve(0.8)
    o "여자는 죽을때까지도 여자거든."
    pause
    o "생각해봐."
    o "성욕에 미친년이 아니고서야 자지만 들이민다고 갑자기 날 따먹어주세요 할 여자가 얼마나 되겠어?"
    o "영화배우들도 그렇게는 못해. 알아?"
    scene ch06_otable01_53-04 at hand_camera with Dissolve(0.8)
    d "그...그렇죠...."
    o "그러니까 내가 여자는 분위기에 압도된다고 하는거야."
    pause
    o "........."
    d "네 기억하고 있어요."
    o "그래."
    scene ch06_otable01_53-06 at hand_camera with Dissolve(0.8)
    o "........"
    o "**(알아들은거야 뭐야..)**"
    o "**(얘는 가끔 이렇게 얼탈때가 있다니까..)**"
    pause
    o "**(하긴 뭐 분위기 잘 만드는건 타고나는 영역이니 내가 말한다고 뭐 나아질리가 없지..)**"
    pause
    o "**(만들어지는 부분도 있으니 잘 알려줘야겠지 그래도....)**"
    scene ch06_otable01_54 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_55 at hand_camera with Dissolve(1.2)
    o "아........"
    o "좀 배부르네."
    pause
    o "내가 만든 음식은 많이 못먹겠던데 오늘은 배부르게 먹었다."
    d "전 엄청 맛있게 먹었어요."
    d "아만다 맛과 비슷하면서 다른데 맛있어요 ㅎㅎ"
    scene ch06_otable01_56 at hand_camera with Dissolve(0.8)
    d "......."
    scene ch06_otable01_57 at hand_camera with Dissolve(0.8)
    o "왜 그렇게 실실 웃는거야?"
    o "너 그러면 애늙은이 같은거 알지?"
    d "ㅎㅎㅎ"
    scene ch06_otable01_58 at hand_camera with Dissolve(0.8)
    d "저 궁금한게 있어요."
    o "궁금한거?"
    d "네."
    scene ch06_otable01_57 at hand_camera with Dissolve(0.8)
    o "궁금한게 뭔데?"
    scene ch06_otable01_56 at hand_camera with Dissolve(0.8)
    d "......."
    scene ch06_otable01_58 at hand_camera with Dissolve(0.8)
    d "그 저....."
    d "제거 어떤거 같아요?"
    pause
    o "니거?"
    o "........"
    d "그러니까...."
    d "저의 고추요."
    scene ch06_otable01_59 at hand_camera with Dissolve(0.8)
    o "........."
    o "뭘 그런걸 물어봐ㅎㅎㅎ."
    pause
    pause
    o "인상적이야."
    pause
    o "....."
    scene ch06_otable01_56 at hand_camera with Dissolve(0.8)
    d "......."
    scene ch06_otable01_58 at hand_camera with Dissolve(0.8)
    d "그게 전부에요?"
    o "........."
    pause
    d "제일 크진 않아요? ㅎㅎ"
    scene ch06_otable01_59 at hand_camera with Dissolve(0.8)
    o "........."
    o "제일 크진않아."
    d "진짜요??!!"
    pause
    o "응."
    pause
    o "하지만 시상대에 올라갈만해."
    scene ch06_otable01_60 at hand_camera with Dissolve(0.8)
    o "........."
    d "올리는....."
    pause
    d "그뒤로 저와 섹스하는 생각했어요?"
    scene ch06_otable01_61 at hand_camera with Dissolve(0.8)
    o "......."
    o "질문이 참...."
    pause
    o "했어.."
    o "....."
    o "넌?"
    scene ch06_otable01_62 at hand_camera with Dissolve(0.8)
    d "저도 올리와 섹스하는 생각했어요."
    d "......."
    d "그러면서 자위 했어요.."
    scene ch06_otable01_63 at hand_camera with Dissolve(0.8)
    o "푸훕.."
    pause
    o "아...그건 너무 과하게 자세한 정보인데?.."
    pause
    o "............"
    scene ch06_otable01_64 at hand_camera with Dissolve(0.8)
    o "너 지금 나랑 섹스하고싶지?"
    d "......"
    d "그...그건..."
    o "마빡에 써있다 임마 ㅎㅎ."
    pause
    o "산장에서 처럼 내가 뭔가 해주길 바라잖아?"
    pause
    o "맞지?"
    scene ch06_otable01_65 at hand_camera with Dissolve(0.8)
    d "ㅎㅎ"
    d "......"
    menu:
        n "What should I say?"
        "올리와 섹스하고 싶어요.":
            scene ch06_otable01_65 at hand_camera with Dissolve(0.8)
            d "올리와 섹스하고 싶어요."
            o "........."
        "절 따먹어주세요.":

            scene ch06_otable01_65 at hand_camera with Dissolve(0.8)
            d "절 따먹어 주세요."
            o "뭐??!!"

    scene ch06_otable01_66 at hand_camera with Dissolve(0.8)
    o "하하하하."
    o "너무 돌직구라 어이가 없네."
    pause
    o "넌 여자들에게 인기 없을거 같다 평생."
    o "그렇게 말하면 여자들이 퍽이나 좋아하겠다 멍청아."
    scene ch06_otable01_67 at hand_camera with Dissolve(0.8)
    d "그건 모르는거죠 ㅎㅎ"
    pause
    d "저 나름 주변에 여자들 많아다구요."
    scene ch06_otable01_66 at hand_camera with Dissolve(0.8)
    o "아 그러세요 아저씨?"
    o "여자친구나 만들고 그런 소릴하세요."
    scene ch06_otable01_67 at hand_camera with Dissolve(0.8)
    d "ㅎㅎㅎㅎ"
    scene ch06_otable01_68 at hand_camera with Dissolve(1.2)
    o "일로와"
    pause
    o "여기 옆에 앉아봐."
    scene ch06_otable01_69 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_70 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_71 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_72 at hand_camera with Dissolve(0.8)
    o "..........."
    d "..............."
    scene ch06_otable01_73 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "그녀에게 키스한다.":
            play music "audio/bgm/erotic06.mp3" volume 0.6
            scene ch06_otable01_73-02 at hand_camera with Dissolve(0.8)
            pause
    scene ch06_otable01_73-02 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/sex/liquid01.mp3"
    scene ch06_otable01_73-03 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_73-04 at hand_camera with Dissolve(0.8)
    pause
    image ch06_otable01_kiss01:
        "ch06_otable01_73-03" with dissolve
        0.9
        "ch06_otable01_73-04" with dissolve
        0.9
        repeat
    scene ch06_otable01_kiss01 at hand_camera with Dissolve(0.8)
    pause
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
        $ add_point("lust_olivia", 1, "lust_olivia")
    scene ch06_otable01_74 at hand_camera with Dissolve(1.2)
    d "........"
    o "......"
    scene ch06_otable01_75 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/milflaugh03.mp3"
    o "우리 지금 뭐하는거지? ㅎㅎ"
    o "나도 나지만 너도 참 일반적이진 않다."
    o "널 어떡해야 할까?ㅎㅎ."
    scene ch06_otable01_76 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_77 at hand_camera with Dissolve(0.8)
    o "진정해 카우보이 ㅎㅎ"
    o "..."
    o "아직 입에 음식 있는데?"
    o "괜찮겠어??"
    scene ch06_otable01_78 at hand_camera with Dissolve(0.8)
    d "상관없어요."
    d "난 올리의 모든게 좋아요."
    o "ㅎㅎㅎ"
    o "아우 느끼해!!"
    scene ch06_otable01_78-02 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/kissshort01.mp3"
    d "상관없어요."
    scene ch06_otable01_79 at hand_camera with Dissolve(1.2)
    pause
    jump ch06_otable02

label ch06_otable02:
    if not in_replay:
        $ persistent.unlock_ch06_otable02 = True
    scene ch06_otable01_80 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_81 at hand_camera with Dissolve(0.8)
    d "........."
    n "그녀는 그가 알던, 그가 기대했던 올리비아의 모습으로 돌아왔다."
    pause
    n "예측하기 쉽고, 동시에 예측하기 힘든,"
    n "마성의 매력을 지닌 그런 여성의 모습이었다."
    n "그리고 그녀의 매력은 [d_name]의 몸에서 화학 반응을 일으켜 그의 성기 끝으로 흘러들었다."
    scene ch06_otable01_82 at hand_camera with Dissolve(0.8)
    o "여기서 이제 파티 손님들도 받을거야."
    o "작은 무대도 설치할거거든."
    o "더 아기자기하게 꾸미고."
    scene ch06_otable01_83 at hand_camera with Dissolve(0.8)
    o "작은 결혼식도 하고.."
    pause
    o "사람들이 즐겁게 웃고 떠들고.."
    scene ch06_otable01_84 at hand_camera with Dissolve(0.8)
    d "좋은 생각인거 같아요."
    o "그치? ㅎㅎ"
    scene ch06_otable01_85 at hand_camera with Dissolve(0.8)
    o "근데 주택가와 너무 가까운게 걱정이긴 하지만...."
    o "뭐 어떻게든 되겠지 ㅎㅎ."
    pause
    o "동네 핫플이 되느냐,쫓겨나느냐...."
    pause
    o "성공해서 이 주변 집들을 모두 사들이느냐 ㅎㅎ"
    d "오 그것도 괜찮은 계획인데요? ㅎㅎㅎ"
    scene ch06_otable01_86 at hand_camera with Dissolve(0.8)
    o "이리와 스위티."
    o "어서."
    scene ch06_otable01_87 at hand_camera with Dissolve(0.8)
    d "왜요? ㅎㅎ"
    o "ㅎㅎ"
    o "춤추자고 ㅎㅎ"
    scene ch06_otable01_88 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_88-02 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_otable01_89 at hand_camera with Dissolve(1.2)
    pause
    o "오호호호."
    o "완전 몸치는 아니네?"
    d "그럼요."
    d "절 뭘로보고."
    d "자꾸 그렇게 절 하찮게 볼거에요? 하하."
    o "이러저리 자지만 들이미는것만 아는줄 알았는데."
    d "하 올리....."
    scene ch06_otable01_90 at hand_camera with Dissolve(0.8)
    o "난 결혼할때 이후로 처음이네 하하."
    d "그래요?"
    pause
    d "난 그때 몇살이었지? 하하."
    scene ch06_otable01_90-02 at hand_camera with Dissolve(0.8)
    o "뭐야 그렇게 말하니까 갑자기 정신이 확 들잖아."
    o "이 꼬맹이야."
    scene ch06_otable01_91 at hand_camera with Dissolve(0.8)
    d "난 꼬맹이 아니라니까요."
    o "헤이!!"
    menu:
        n "What should I do?"
        "그녀를 들어 안는다.":
            play sound "audio/ambi/fabric04.mp3" volume 1.8
            scene ch06_otable01_92 at hand_camera with Dissolve(0.8)
            o "!!!!!!"
    scene ch06_otable01_93 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("love_olivia", 1, "love_olivia")
    o "뭐하는거야??!!"
    o "나 이런거 진짜 싫어하거든?"
    o "날 빨리 내려놔!!"
    d "하하하하."
    d "이러고 동네방네 돌아다닐까요?"
    o "너 진짜 죽는다??!!!"
    scene ch06_otable01_93-02 at hand_camera with Dissolve(0.8)
    o "아 빨리 내려놓으라고!!!!!!"
    d "하하하하하하하."
    o "빨리!!!!"
    d "올리는 이제 저에게 잡힌거에요."
    scene ch06_otable01_94 at hand_camera with Dissolve(0.8)
    d "하하하."
    o "빨리 내려놔 나 화낸다 진짜??"
    d "알겠어요 알겠어요."
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_otable01_95 at hand_camera with Dissolve(0.8)
    d "끄응.."
    play voice_f "audio/voices/milflaugh16.mp3"
    o "하하하하"
    o "그거 조금 들고 벌써 지친거야?"
    d "하하하 젠장.."
    scene ch06_otable01_96 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fsigh06.mp3"
    o "하아......"
    o "가끔 이런 미친짓도 재미있네."
    o "........"
    o "고딩때 연애하는 기분이야."
    scene ch06_otable01_96-02 at hand_camera with Dissolve(0.8)
    d "고딩때 이런 연애를 했었어요? ㅎㅎㅎ"
    o "조용히 꼬맹이야."
    menu:
        n "What should I do?"
        "그녀에게 키스한다.":
            scene ch06_otable01_97 at hand_camera with Dissolve(0.8)
            play voice_f "audio/sex/kissshort01.mp3"
            pause
    scene ch06_otable01_98 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "그녀의 젖을 만진다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch06_otable01_99 at hand_camera with Dissolve(0.8)
            pause
    scene ch06_otable01_100 at hand_camera with Dissolve(0.8)
    o "아흥......"
    play sound "audio/sex/liquid01.mp3"
    scene ch06_otable01_101 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_102 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "그녀의 보지를 만진다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch06_otable01_103 at hand_camera with Dissolve(0.8)
            play music "audio/bgm/erotic03.mp3"
            d "!!!!"
            n "그의 손이 그녀의 음부에 도달했을때 그의 손에 느껴진 것은 원단이 아니었다."
            pause
            n "그의 손 끝에 느껴진 것은 따뜻한 여성의 피부와 까슬까슬한 그녀의 음모였다."
    scene ch06_otable01_104 at hand_camera with Dissolve(0.8)
    d "패..팬티를 안입었네요?? ㅎㅎ"
    o "......"
    scene ch06_otable01_105 at hand_camera with Dissolve(0.8)
    o "ㅎㅎㅎㅎ"
    o "언제나 그렇듯.."
    play sound "audio/sex/liquid01.mp3"
    scene ch06_otable01_106 at hand_camera with Dissolve(0.8)
    d "앗....."
    pause
    d "제....젠장 올리..."
    d "느낌이 이상해요..."
    play sound "audio/ambi/fabric01.mp3"
    scene ch06_otable01_107 at hand_camera with Dissolve(0.8)
    o "다시 여기로......"
    menu:
        n "What should I do?"
        "손가락을 삽입한다.":
            scene ch06_otable01_107-02 at hand_camera with Dissolve(0.8)
            play voice_f  "audio/sex/fmoanshort04.mp3"
            o "하......"
    scene ch06_otable01_107-03 at hand_camera with Dissolve(0.8)
    pause
    d "아......"
    scene ch06_otable01_108 at hand_camera with Dissolve(0.8)
    pause
    menu:
        n "What should I do?"
        "손가락을 더 깊히 삽입한다.":
            play sound "audio/sex/liquid01.mp3"
            if not in_replay:
                $ add_point("lust_olivia", 1, "lust_olivia")
            scene ch06_otable01_109 at hand_camera with Dissolve(0.8)
            o "흐응......"
    scene ch06_otable01_110 at hand_camera with Dissolve(0.8)
    d "아...올리...."
    d "가...감촉이...."
    image ch06_otable01_finger01:
        "ch06_otable01_108" with dissolve
        0.7
        "ch06_otable01_109" with dissolve
        0.7
        repeat
    play sound "audio/sex/penet04.mp3" loop volume 2.0
    scene ch06_otable01_finger01 at hand_camera with Dissolve(0.8)
    o "으음......."
    pause
    d "이..이렇게 하는거 맞나요?"
    stop sound
    scene ch06_otable01_111 at hand_camera with Dissolve(0.8)
    o "계속해."
    o "좋아....."
    d "아...알겠어요.."
    play sound "audio/sex/penet04.mp3" loop
    scene ch06_otable01_finger01 at hand_camera with Dissolve(0.8)
    o "어우......."
    image ch06_otable01_finger02:
        "ch06_otable01_108" with dissolve
        0.4
        "ch06_otable01_109" with dissolve
        0.4
        repeat
    menu:
        n "What should I do?"
        "속도를 올린다.":
            scene ch06_otable01_finger02 at hand_camera with Dissolve(0.8)
            o "마이갓........."
            image ch06_otable01_finger03:
                "ch06_otable01_111" with dissolve
                0.4
                "ch06_otable01_111-02" with dissolve
                0.4
                repeat
            scene ch06_otable01_finger03 at hand_camera with Dissolve(0.8)
            o "아 베이비......"
            d "아 이게 올리의 보지에요...."
            o "맘에 들어?...."
            d "네....."
            stop sound
    scene ch06_otable01_112 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fmoanshort07.mp3"
    o "손가락 3개 넣어....하아...."
    d "네...네 알겠어요."
    o "그리고 손을 약간 위아래로 움직여줘."
    d "네...."
    menu:
        n "What should I do?"
        "손가락 3개를 삽입한다.":
            play voice_f "audio/sex/fmoanshort07.mp3"
            scene ch06_otable01_112-02 at hand_camera with Dissolve(0.8)
            o "아.............."
    scene ch06_otable01_113 at hand_camera with Dissolve(0.8)
    play sound "audio/sex/liquid01.mp3"
    o "아아!!!"
    d "아파요??"
    o "아니야 계속해!!"
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    scene ch06_otable01_114 at hand_camera with Dissolve(0.8)
    pause
    play sound "audio/sex/liquid01.mp3"
    scene ch06_otable01_115 at hand_camera with Dissolve(0.8)
    o "그래 그렇게!!"
    image ch06_otable01_finger04:
        "ch06_otable01_114" with dissolve
        0.08
        "ch06_otable01_114-02" with dissolve
        0.08
        "ch06_otable01_114-03" with dissolve
        0.08
        "ch06_otable01_115" with dissolve
        0.08
        "ch06_otable01_114-03" with dissolve
        0.08
        "ch06_otable01_114-02" with dissolve
        0.08
        repeat
    play sound "audio/sex/penet04.mp3" loop volume 2.0
    scene ch06_otable01_finger04 at hand_camera with Dissolve(0.8)
    o "아흑!!!"
    d "조..좋아요??"
    o "시끄러워!!"
    scene ch06_otable01_116 at hand_camera with Dissolve(0.8)
    d "맙소사 올리.."
    d "올리의 보지가 움찔거려요."
    o "시끄러워!!"
    o "더 강하게!!"
    image ch06_otable01_finger05:
        "ch06_otable01_114" with dissolve
        0.05
        "ch06_otable01_114-02" with dissolve
        0.05
        "ch06_otable01_114-03" with dissolve
        0.05
        "ch06_otable01_115" with dissolve
        0.05
        "ch06_otable01_114-03" with dissolve
        0.05
        "ch06_otable01_114-02" with dissolve
        0.05
        repeat
    scene ch06_otable01_finger05 at hand_camera with Dissolve(0.8)
    o "아!!!!!!!!!!"
    o "맙소사 [d_name]!!!!!!!"
    pause
    o "퍽!!!!!"
    stop music fadeout 1.0
    stop sound
    scene ch06_otable01_116-01 at hand_camera with Dissolve(1.5)
    pause
    play sound "audio/ambi/dooropen.mp3"
    scene ch06_otable01_116-02 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_116-03 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_116-04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_116-05 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_116-06 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_116-07 at hand_camera with Dissolve(1.2)
    a "................"
    play music "audio/bgm/erotic03.mp3"
    scene ch06_otable01_112-02 at hand_camera with Dissolve(0.8)
    o "더 강하게!!!!!!"
    d "알겠어요!!!"
    play sound "audio/sex/penet04.mp3" loop volume 2.0
    scene ch06_otable01_117 at hand_camera with Dissolve(1.2)
    pause
    menu:
        n "What should I do?"
        "자지를 꺼낸다.":
            scene ch06_otable01_118 at hand_camera with Dissolve(0.8)
            o "더 빠르게!!!!............."
    scene ch06_otable01_119 at hand_camera with Dissolve(0.8)
    d "**(젠장!!)**"
    d "**(손가락을 쪼인다!!!!)**"
    pause
    d "**(그냥 지금 삽입할까?)**"
    d "**(딱 타이밍인거 같은데??)**"
    pause
    d "**(지금이 올리가 말하는 그 분위기 좋은 순간인거 같은데???)**"
    scene ch06_otable01_120 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fmoanshort05.mp3"
    o "아!!!!!!!!!!!!!!!"
    o "나 쌀거같아!!!!!!"
    d "네????!!!!"
    o "느낄거 같다고!!!!"
    scene ch06_otable01_121 at hand_camera with Dissolve(0.8)
    o "[d_name].............."
    scene ch06_otable01_122 at hand_camera with Dissolve(0.8)
    play voice_f "audio/voices/fscream02.mp3"
    o "으아!!!!!!!!!!!!!!!!!!!!!!!"
    stop music fadeout 1.0
    scene ch06_otable01_123 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_124 at hand_camera with Dissolve(0.8)
    o "아아아아.....잠깐!!!!!!!!!"
    d "왜요????!!"
    d "갈거 같아요??!!"
    scene ch06_otable01_121 at hand_camera with Dissolve(0.8)
    play voice_f "audio/sex/fmoanshort02.wav"
    o "아아아아악악!!!!!!!!!!"
    stop sound
    scene ch06_otable01_125 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_olivia", 1, "lust_olivia")
    play voice_f "audio/sex/cum01.mp3"
    o "아흑.............."
    d "앗!!!!!!!!!"
    scene ch06_otable01_125-02 at hand_camera with Dissolve(0.8)
    if not in_replay:
        $ add_point("lust_amanda", 1, "lust_amanda")
    o "아........."
    scene ch06_otable01_126 at hand_camera with Dissolve(0.8)
    d "............"
    scene ch06_otable01_127 at hand_camera with Dissolve(0.8)
    d "와우 올리....."
    pause
    d "이런건 처음 봤어요......"
    scene ch06_otable01_128 at hand_camera with Dissolve(0.8)
    d "괜찮아요 올리?...."
    o "아...아니....."
    scene ch06_otable01_129 at hand_camera with Dissolve(0.8)
    d "이젠 제 차례에요 ㅎㅎ"
    d "이제 섹스..."
    play voice_f "audio/voices/fahem02.mp3"
    a "크흠!!"
    scene ch06_otable01_130 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_otable01_131 at hand_camera with Dissolve(1.3)
    pause
    scene ch06_otable01_132 at hand_camera with Dissolve(0.8)
    d "............"
    a ".........."
    o "..............."
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/normal08.mp3" volume 1.3
    scene ch06_otable01_133 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_134 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_otable01_135 at hand_camera with Dissolve(0.8)
    a "잘하는 짓이다 이 변태들."
    a "이게 대체 뭐하는 짓이야? 허?"
    pause
    a ".........."
    a "공공장소 음란행위로 잡혀가고 싶어??!!!"
    a "사방이 집들인데 이게 대체 무슨 추잡한 짓이야!!"
    d ".........."
    scene ch06_otable01_136 at hand_camera with Dissolve(0.8)
    o "하아......"
    pause
    o "문잠겨있었을텐데 어떻게 들어온거야?"
    d "!!!!!!!!"
    d "**(내가 잘못 잠궜나보다...하아.....)**"
    pause
    d "**(어쩐지 뭔가 잠기는 느낌이 안난다 했다.....)**"
    scene ch06_otable01_137 at hand_camera with Dissolve(0.8)
    a "문 잘만 열리던데 잠기긴 뭐가 잠겨 이년아!!!"
    a "니 차는 있는데 사람은 없으니까 여기까지 온거지."
    a "대체 이게 뭔 짓이야 동네 창피하게."
    a "야동 배우도 너 처럼은 안하겠다."
    scene ch06_otable01_136 at hand_camera with Dissolve(0.8)
    o "하아......"
    o "넌 문 하나도 제대로 못 잠그니?....."
    scene ch06_otable01_137-02 at hand_camera with Dissolve(0.8)
    d "미...미안해요 올리..."
    pause
    d "........."
    scene ch06_otable01_138 at hand_camera with Dissolve(0.8)
    o "근데 무슨일로 온거야?"
    o "오면서 전화라도 했어야지."
    a "내가 전화 안했겠냐 이년아??!!"
    scene ch06_otable01_138-02 at hand_camera with Dissolve(0.8)
    o "젠장 폰 주방에 뒀구나.."
    scene ch06_otable01_139 at hand_camera with Dissolve(0.8)
    a "너하고 얘기좀 하러 왔는데 타이밍 죽이네."
    a "왜 다시 또 고래처럼 뿜어보지그래?"
    a "이 더러운 창녀 같은년!!!"
    o "닥쳐."
    scene ch06_otable01_140 at hand_camera with Dissolve(0.8)
    a "[d_name]!!"
    d "네??!!"
    scene ch06_otable01_141 at hand_camera with Dissolve(0.8)
    a "너 나하고 드라이브나 하자."
    a "올리는 쉬라고 해."
    d "네...아..알겠어요."
    a "저년은 엄청 뿜어댔으니 쉬어야지."
    scene ch06_otable01_142 at hand_camera with Dissolve(0.8)
    a "어서 일어서!!"
    d "네...아..알겠어요."
    scene ch06_otable01_143 at hand_camera with Dissolve(0.8)
    a "올리 이년아."
    a "니 폰에 저장된 남자들하고 놀아라 알았냐?"
    a "[d_name]건들지 말고 이년아."
    o "닥쳐 아만다."
    o "남말 하지말고 언니 앞가림이나 잘해."
    scene ch06_otable01_143-02 at hand_camera with Dissolve(0.8)
    o "아!"
    scene ch06_otable01_144 at hand_camera with Dissolve(0.8)
    a "**(저년은 저거 저러다 대형 사고 치지.)**"
    a "**(여태 멀쩡히 살아있는게 기적이다.)**"
    play sound "audio/ambi/doorclose.mp3"
    scene ch06_otable01_145 at hand_camera with Dissolve(0.8)
    d "..........."
    scene ch06_otable01_146 at hand_camera with Dissolve(0.8)
    o "젠장.........."
    o "......"
    pause
    o "부끄럽다..부끄러워..."
    pause
    o "이게 대체 무슨 일이야..."
    jump ch06_adrive01

label ch06_adrive01:
    if not in_replay:
        $ persistent.unlock_ch06_adrive01 = True
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night04.mp3"  
    scene ch06_adrive01_01 at hand_camera with Dissolve(1.2)
    pause
    play sound "audio/ambi/carengine02.mp3" loop
    scene ch06_adrive01_02 at hand_camera with Dissolve(1.2)
    pause
    stop sound fadeout 1.0
    scene ch06_adrive01_03 at hand_camera with Dissolve(1.2)
    play ambient "audio/ambi/carinside01.mp3" loop
    n "아만다와 [d_name]은 산속의 밤길을 달리고 있었다."
    pause
    n "아만다는 화가 나 있었고 알수 없는 밤길을 아만다에 이끌려 계속 나아가며 그는 불안감을 느끼기 시작했다."
    scene ch06_adrive01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_05 at hand_camera with Dissolve(0.8)
    d "미안해요 아만다...."
    d "....."
    d "............"
    scene ch06_adrive01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_07 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_05 at hand_camera with Dissolve(0.8)
    d "지금 말 없이 1시간 째에요."
    pause
    d "아만다....."
    d "제발 무슨 말이라도 좀 해봐요."
    scene ch06_adrive01_06-02 at hand_camera with Dissolve(0.8)
    a "나한테 사과 할거 없어."
    pause
    a "너희 둘은 둘다 성인이니까."
    scene ch06_adrive01_07 at hand_camera with Dissolve(0.8)
    a "다만....."
    d "....."
    a "약간 충격을 받았을 뿐이야."
    scene ch06_adrive01_04 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_03 at hand_camera with Dissolve(1.2)
    a "알잖니."
    a "내가 너의 인생에 대해 이래라 저래라 말은 해도.."
    pause
    a "난 너와 몇 년 같이 살았던 아줌마에 불과해."
    scene ch06_adrive01_08 at hand_camera with Dissolve(0.8)
    d ".........."
    a "그러니까 내말은.."
    a "너의 인생은 니가 결정하는데로 흘러가는거야."
    scene ch06_adrive01_09 at hand_camera with Dissolve(0.8)
    a "좋은 선택도 나쁜 선택도 다 저마다의 결과가 기다리고 있을거야."
    pause
    a "무슨 말인지 아니?"
    scene ch06_adrive01_03 at hand_camera with Dissolve(0.8)
    d "........."
    pause
    d "네 아만다의 말이 무슨 말인지 알아요..."
    scene ch06_adrive01_06 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_10 at hand_camera with Dissolve(1.2)
    a "그러니까 너의 인생을 망칠 일은 하지마."
    d "......."
    a "[d_name]..."
    a "올리는 내 동생이야....맙소사.."
    a "내 동생이라고.."
    scene ch06_adrive01_11 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_12 at hand_camera with Dissolve(0.8)
    a "더군다나 그녀는 법적으로 아직은 결혼한 유부녀라고."
    d "알아요 아만다."
    a "......."
    d "하.........."
    scene ch06_adrive01_13 at hand_camera with Dissolve(0.8)
    a "내가 볼때 넌 울타리가 무너졌는데 어디로 뛰어갈지 몰라 날뛰는 망아지야."
    a "무슨 말인지 알아?"
    a "자유에 미쳐서 날뛰는 망아지라고."
    d "........."
    d "꽤나 문학적인 표현이네요..."
    a "......"
    a "너와 올리는 불장난을 하고 있어."
    scene ch06_adrive01_14 at hand_camera with Dissolve(0.8)
    a "있잖아."
    pause
    a "너의 나이 남자들은 눈뜨고 잘때까지 섹스생각 뿐이라는거 잘알아."
    d "........."
    a "다른 여자들과는 얼마든지 떡쳐도 돼."
    a "니 그 몸매 좋다는 대학 교수랑 떡쳐도 상관안해."
    a "물론 그 여자가 동의한다면 말이지. 그리고...."
    a "그리고 물론 니 스스로 너의 몸을 지킬수 있다는 가정하에 말이지."
    scene ch06_adrive01_15 at hand_camera with Dissolve(0.8)
    pause
    d ".........."
    d "올리와 비슷한 얘길 하네요..."
    a "...."
    scene ch06_adrive01_16 at hand_camera with Dissolve(0.8)
    a "니가 내 여동생과 그 짓을 이어간다면..."
    d "....."
    a "결국 나와도 영원히 멀어지게 될거야."
    pause
    a "정말 그렇게 되고 싶은건 아니잖아."
    scene ch06_adrive01_15 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_17 at hand_camera with Dissolve(0.8)
    d "아만다도 원했잖아요."
    a "뭐??"
    scene ch06_adrive01_16 at hand_camera with Dissolve(0.8)
    pause
    a "그게 무슨 말이야?"
    a "내가 원했다니...뭘?"
    a "내가 니가 올리비아와 떡치길 바랬다는거야??"
    scene ch06_adrive01_15 at hand_camera with Dissolve(0.8)
    d "........."
    d "집에서도 그랬고..."
    scene ch06_adrive01_11 at hand_camera with Dissolve(0.8)
    d "해변에서도.."
    a "......."
    d "그렇게 우리 둘이 벗고 서로 몸을 만지면서..."
    scene ch06_adrive01_12 at hand_camera with Dissolve(0.8)
    a "......."
    d "제가 아만다의..."
    d "제가 아만다의 음부를 만지고 애무해도 뭐라 안했잖아요."
    d "아니 오히려 신음을 내고 좋아했잖아요."
    scene ch06_adrive01_18 at hand_camera with Dissolve(0.8)
    a "......."
    d "그건 뭐에요?"
    d "...."
    d "아만다도 메리 처럼 남자의 손길이 필요한 순간만 허락하는거에요?"
    a "메리?"
    d "아 말이 헛나왔어요. 메리가 아니라.."
    scene ch06_adrive01_10 at hand_camera with Dissolve(0.8)
    a "............"
    d "그렇잖아요."
    d "흥분하고 내 손길이 좋을땐 아만다의 몸이 반응하잖아요."
    d "........"
    d "그럼 된거아니에요?"
    scene ch06_adrive01_18 at hand_camera with Dissolve(0.8)
    a "......."
    a "이제 절대 두번다시 그런일은 안일어날거야."
    d "아...아니 그게 아니라.."
    a "그리고 그게 올리와 너랑 그짓거리를 하는거아 무슨 관련인데?"
    d "..........."
    scene ch06_adrive01_15 at hand_camera with Dissolve(0.8)
    pause
    d "하......저도 모르겠어요...."
    pause
    d "그냥 말이 나왔어요."
    scene ch06_adrive01_18-02 at hand_camera with Dissolve(0.8)
    a "........"
    a "대체 무슨 말이 하고싶은건데? 허?"
    a "내가 너와 그런 스킨십을 하니까 올리랑도 해도 된다고 생각한다는거야??"
    scene ch06_adrive01_18-03 at hand_camera with Dissolve(0.8)
    d ".........."
    d "그러니까 내말은.."
    scene ch06_adrive01_08 at hand_camera with Dissolve(1.2)
    d "하.....모르겠어요."
    pause
    d "요즘 눈만 뜨면 섹스 생각 뿐이에요......"
    a "........"
    d "미안해요 아만다...."
    scene ch06_adrive01_16 at hand_camera with Dissolve(0.8)
    pause
    stop ambient fadeout 1.0
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    play music "audio/bgm/night02.mp3"  
    scene ch06_adrive01_19 at hand_camera with Dissolve(1.2)
    play ambient "audio/ambi/carinside01.mp3"
    pause
    stop sound fadeout 1.0
    scene ch06_adrive01_20 at hand_camera with Dissolve(1.2)
    pause
    d ".........."
    d "근데 무슨 일 있어요?"
    pause
    d "무슨 일 있는 눈치인데요?"
    scene ch06_adrive01_21 at hand_camera with Dissolve(0.8)
    a "............"
    a "그냥 올리와 한잔하려고 가게로 갔던거야."
    a "뭐 별일은 없어."
    a "......."
    a "그냥 좀 기분 전환좀 하고 싶었던 거지..."
    scene ch06_adrive01_22 at hand_camera with Dissolve(0.8)
    d "그렇군요......"
    pause
    d "......."
    d "근데 지금 어디로 가는거에요?"
    scene ch06_adrive01_21 at hand_camera with Dissolve(0.8)
    pause
    a "나만 아는 곳으로."
    a "......."
    scene ch06_adrive01_22 at hand_camera with Dissolve(0.8)
    a "아니 망할 프랭크도 아는 곳이네."
    d ".........."
    d "그렇군요....."
    stop ambient fadeout 1.0
    scene black with dissolve
    $ _skipping = False
    $ renpy.choice_for_skipping()
    show text "After a while" at truecenter with Dissolve(2.0)
    $ _skipping = True
    scene ch06_adrive01_23 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_24 at hand_camera with Dissolve(1.5)
    a "다 왔어."
    a "내리자."
    scene ch06_adrive01_25 at hand_camera with Dissolve(1.2)
    play sound "audio/ambi/cardoorclose.mp3"
    pause
    scene ch06_adrive01_26 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_27 at hand_camera with Dissolve(0.8)
    n "그는 아만다의 뒷 모습을 가만히 지켜보았다."
    pause
    n "그녀의 모습은 그가 지금까지 본 모습중에 가장 우울하고 쓸쓸해 보였다."
    scene ch06_adrive01_27-02 at hand_camera with Dissolve(0.8)
    d "**(아니 분명 무슨일이 있잖아.)**"
    pause
    d "**(아 대체 무슨일인거야.)**"
    d "........"
    scene ch06_adrive01_28 at hand_camera with Dissolve(1.5)
    pause
    scene ch06_adrive01_29 at hand_camera with Dissolve(0.8)
    pause
    d "와우.."
    d "이런 곳이 있었다니.."
    play music "audio/bgm/normal11.mp3"  
    scene ch06_adrive01_30 at hand_camera with Dissolve(1.3)
    pause
    scene ch06_adrive01_31 at hand_camera with Dissolve(0.8)
    d "이렇게 보니까 밀프하임도 꽤 아름다운 곳이네요."
    d ".........."
    pause
    d "평화로워 보여요.."
    scene ch06_adrive01_32 at hand_camera with Dissolve(1.2)
    a "그치?...."
    scene ch06_adrive01_33 at hand_camera with Dissolve(1.2)
    a "아까 차에서 짜증내서 미안했어."
    a "........."
    a "사실 좀 충격이었다 해야하나...."
    a "알잖아."
    pause
    a "참 민망하네."
    scene ch06_adrive01_34 at hand_camera with Dissolve(0.8)
    d "........"
    d "아니에요....저도 미안해요 아만다.."
    menu:
        n "What should I do?"
        "아만다를 껴안는다.":
            play sound "audio/ambi/fabric01.mp3"
            scene ch06_adrive01_36 at hand_camera with Dissolve(1.3)
            pause
            d "사랑해요 아만다.."
            a "........"
            pause
            pause
            d "근데 아만다는 지금 뭔가 숨기고 있다는거 알아요.."
            a "........"
            d "무슨 일인지 말해봐요.."
            d "어서요..."
    scene ch06_adrive01_37 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_38 at hand_camera with Dissolve(0.8)
    a "너에겐 굳이 말하지 않아도 되는 일이야."
    d "아니 그런거 없어요."
    scene ch06_adrive01_39 at hand_camera with Dissolve(0.8)
    d "내가 말했잖아요."
    d "난 영원히 아만다 편이라구요."
    d "영원히요."
    scene ch06_adrive01_40 at hand_camera with Dissolve(1.2)
    a "................."
    scene ch06_adrive01_41 at hand_camera with Dissolve(1.2)
    pause
    stop music fadeout 1.0
    scene ch06_adrive01_42 at hand_camera with Dissolve(1.3)
    pause
    scene ch06_adrive01_43 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_adrive01_44 at hand_camera with Dissolve(0.8)
    tv "지역 소식입니다."
    tv "어제 새벽, 밀프하임 카운티의 한 고속도로 휴게소에서 62세 남성이 자신의 차량 안에서 숨진 채 발견됐습니다."
    scene ch06_adrive01_45 at hand_camera with Dissolve(0.8)
    tv "사망자는 은퇴한 지질학 교수 다니엘 리드 씨로 확인됐습니다."
    tv "경찰에 따르면 리드 씨는 오늘 새벽 휴게소에 들른 한 트럭 운전기사에 의해 발견됐습니다."
    tv "경찰은 리드 씨가 총상을 입고 사망한 것으로 보고 있으며, 차량 안에서는 총기와 유서로 보이는 문서도 발견됐습니다."
    scene ch06_adrive01_46 at hand_camera with Dissolve(0.8)
    tv "당초 경찰은 자살 가능성에 무게를 두었지만, 현재 정확한 사망 경위를 확인하기 위해 추가 조사를 진행하고 있습니다."
    tv "현재까지 용의자는 특정되지 않았으며, 경찰은 추가적인 정보를 확인하고 있습니다."
    tv "다음 소식입니다."
    play sound "audio/ambi/dooropen03.mp3"
    scene ch06_adrive01_47 at hand_camera with Dissolve(0.8)
    f "아 피곤하구만."
    f "나 왔어."
    a "수고했어."
    play sound "audio/ambi/doorclose.mp3"
    scene ch06_adrive01_48 at hand_camera with Dissolve(0.8)
    f "맛있는 냄새 나네?"
    f "저녁 메뉴는 뭐야?"
    scene ch06_adrive01_49 at hand_camera with Dissolve(0.8)
    a "틸라피아 스테이크야."
    a "샤워 부터 해."
    f "아..그래야지."
    f "오늘도 땀 많이 흘렸네."
    f "찝찝해."
    scene ch06_adrive01_50 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_51 at hand_camera with Dissolve(0.8)
    a "!!!!!!!!!!!!!!"
    scene ch06_adrive01_52 at hand_camera with Dissolve(0.8)
    a "야이 미친 인간아!!!!!!!!!!"
    f "뭐??"
    scene ch06_adrive01_53 at hand_camera with Dissolve(0.8)
    f "뭐야 갑자기??!!"
    f "왜 일하고 피곤한 사람한테 시비거는거야 이 여편네야!!!"
    scene ch06_adrive01_54 at hand_camera with Dissolve(0.8)
    a "이제 동네방네 다 소문내고 다니려고 작정한거야 허??!!!!!!"
    a "이 미친인간이 기어이 나하고 끝장으로 가보려는거지?!!!!!!!!!!"
    scene ch06_adrive01_55 at hand_camera with Dissolve(0.8)
    f "조용히 해 이 여자야!!!!"
    f "동네방네 뭘 소문내?"
    f "남편이 열심히 일하고 들어왔으면 씻겨줘도 모자를판에 이 여자가 미쳤나!!!!!!"
    scene ch06_adrive01_56 at hand_camera with Dissolve(0.8)
    f "뭔데 갑자기??!!!"
    a "아 머리야........"
    a "하아......"
    pause
    a "니 엉덩이 확인해봐."
    scene ch06_adrive01_57 at hand_camera with Dissolve(0.8)
    f "엉덩이 라니 무슨 그게 뚱딴지 같은 소리야?!!!!"
    a "니 엉덩이 확인해보라고!!!!!!!!"
    scene ch06_adrive01_58 at hand_camera with Dissolve(0.8)
    f "!!!!!!!!!!!!!"
    scene ch06_adrive01_59 at hand_camera with Dissolve(0.8)
    pause
    scene ch06_adrive01_60 at hand_camera with Dissolve(0.8)
    f "..........."
    a "좋지 아주???!!!"
    pause
    a "거 동네 사람들이 다 알아줬음 해서 거기 달고 다니는거지 이 개새끼야!!!!!!!!!"
    scene ch06_adrive01_61 at hand_camera with Dissolve(0.8)
    f "이익....(화나서 내는 소리)"
    f "엠마 이 미친년이........."
    scene ch06_adrive01_62 at hand_camera with Dissolve(0.8)
    a "엠마??!!!!"
    a "어이가 없네."
    a "엠마??????!!!!"
    a "이젠 숨기지도 않네??!!!!"
    scene ch06_adrive01_63 at hand_camera with Dissolve(0.8)
    a "지겹다 지겨워!!!!!!!!!"
    a "난 이 빌어먹을 집구석을 떠날거야!!!!!!!"
    a "당신이랑은 이제 끝이라고!!!!!!"
    scene ch06_adrive01_64 at hand_camera with Dissolve(0.8)
    f "어딜가는거야?!!!!!!"
    scene ch06_adrive01_65 at hand_camera with Dissolve(0.8)
    a "이거 놔!!!!!!!!"
    f "악!!(맞아서 내는 소리)"
    scene ch06_adrive01_66 at hand_camera with Dissolve(0.8)
    f "이...이 쌍년이....."
    scene ch06_adrive01_67 at hand_camera with Dissolve(0.8)
    play sound "audio/ambi/hit01.mp3"
    a "꺄악!!!!!!!!!!!!!(맞아서 내는 비명)"
    play music "audio/bgm/normal11.mp3"  
    scene ch06_adrive01_68 at hand_camera with Dissolve(1.5)
    d "............"
    d "맙소사 아만다......"
    pause
    d "미안해요 정말....."
    scene ch06_adrive01_69 at hand_camera with Dissolve(1.2)
    pause
    scene ch06_adrive01_69-02 at hand_camera with Dissolve(1.2)
    d "!!!"
    pause
    d "맙소사......"
    scene ch06_adrive01_70 at hand_camera with Dissolve(0.8)
    a "봤지?"
    a "이게 평생 성욕에 미쳐 산 남자의 모습이야."
    a "프랭크 이 씨발새끼."
    a "이게 평생 자신을 컨트롤하지 못한 남자의 모습이라고."
    scene ch06_adrive01_71 at hand_camera with Dissolve(1.2)
    d "............"
    d "맙소사........"
    pause
    d "망할 프랭크....."
    a "........."
    scene ch06_adrive01_72 at hand_camera with Dissolve(0.8)
    d "이제 어떡할거에요?......"
    pause
    a "생각중이야....."
    a "......."
    a "올리와 상의하려고 찾아갔던거야....."
    scene ch06_adrive01_73 at hand_camera with Dissolve(0.8)
    d ".........."
    d "그랬군요......"
    d "하 참...."
    d "하필 그 타이밍에......."
    a "........."
    a "그래."
    a "타이밍 아주 죽여줬다고 이 녀석아."
    stop music fadeout 1.0
    d "........."
    play music "audio/bgm/normal12.mp3"
    scene ch06_adrive01_74 at hand_camera with Dissolve(0.8)
    a "하나 확실한건......."
    a "내 인내심은 이제 바닥이야."
    pause
    a "프랭크 좆까라 그래."
    a "이제 프랭크랑은 끝났어."
    scene ch06_adrive01_75 at hand_camera with Dissolve(0.8)
    d "..........."
    a "내가 왜 그런 놈을 위해 평생을 헌신했을까....."
    pause
    a "진짜 나 자신이 원망스럽다...원망스러워...."
    scene ch06_adrive01_76 at hand_camera with Dissolve(0.8)
    a "이제 내 인생에 전환점에 왔어....."
    a ".............."
    a "이제 내 인생에 전환점에 왔다고......."
    pause
    a "내 삶을 찾을거야."
    pause
    a "......."
    a "잃어버린 이 아만다의 삶을 찾을거라고."
    scene ch06_adrive01_77 at hand_camera with Dissolve(0.8)
    a "나 오늘 집에 안들어갈거야."
    d "..........."
    d "제가 아만다와 함께 있을게요."
    pause
    a "내일도 안들어갈거야."
    pause
    a "영원히 안들어갈거야."
    jump v06_ends

label v06_ends:
    call screen chapter_end_screen with Dissolve(1.5)
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
