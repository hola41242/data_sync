init offset = -1





screen temporary_message_screen(duration):
    modal True
    timer duration action Return()




default selected_character_info = "Character Info"

default map_x = 0

default point_popup_count = 0

transform point_popup(pos=0):
    alpha 0.0
    xalign 0.02




    yalign 0.09 + (pos * 0.16)

    linear 0.2 alpha 1.0 zoom 0.55
    pause 2.5
    linear 0.3 alpha 0.0

init python:
    files = renpy.list_files()

    for file in files:
        if file.startswith("images/point/") and file.endswith(".png"):
            name = file.split("/")[-1].replace(".png", "")
            renpy.image(name, file)

init python:
    import time

    def add_point(point_var, amount, image_name):
        
        globals()[point_var] += amount
        renpy.music.play("audio/phone/point.mp3", channel="sfx")
        
        now = time.time()
        
        if not hasattr(store, "last_point_time"):
            store.last_point_time = 0
        
        if now - store.last_point_time > 0.3:
            store.point_popup_count = 0
        
        current_pos = store.point_popup_count
        
        store.point_popup_count += 1
        store.last_point_time = now
        
        popup_tag = "popup_" + str(current_pos)
        
        renpy.show_screen("point_popup_screen", 
                          image_name=image_name, 
                          pos=current_pos, 
                          _tag=popup_tag)


screen point_popup_screen(image_name, pos=0):
    zorder 999

    add image_name at point_popup(pos=pos)


    timer 3.0 action Hide("point_popup_screen")




transform hand_camera:
    subpixel True
    xalign 0.5
    yalign 0.5

    parallel:
        ease 1.0 zoom 1.01

    parallel:
        align (0.5, 0.5)
        around (0.501, 0.5)
        linear 4.0 counterclockwise circles 1
        around (0.499, 0.5)
        linear 4.0 clockwise circles 1
        repeat

transform hand_camera_zoom:
    subpixel True
    xalign 0.5
    yalign 0.5

    parallel:
        ease 1.0 zoom 1.3

    parallel:
        align (0.5, 0.5)
        around (0.501, 0.5)
        linear 4.0 counterclockwise circles 1
        around (0.499, 0.5)
        linear 4.0 clockwise circles 1
        repeat

transform hand_camera_zoominout:
    subpixel True
    xalign 0.5
    yalign 0.5

    parallel:
        ease 1.0 zoom 1.3
        ease 1.0 zoom 1.1

    parallel:
        align (0.5, 0.5)
        around (0.501, 0.5)
        linear 4.0 counterclockwise circles 1
        around (0.499, 0.5)
        linear 4.0 clockwise circles 1
        repeat

transform hand_camera_rotate:
    subpixel True
    xalign 0.5
    yalign 0.5

    parallel:
        zoom 1.03
        rotate 1.5
        linear 4.0 rotate -1.01
        linear 4.0 rotate 1.01
        repeat





style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)






















screen say(who, what):
    window:
        id "window"

        if who is not None:
            window:
                id "namebox"
                style "namebox"
                text who id "who"

        text what id "what"

    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0


transform android_ui_scale:
    zoom (1.5 if renpy.variant("small") else 1.0)

screen top_ui_buttons():
    if not persistent.in_replay:

        if show_info_button:

            fixed:
                at android_ui_scale

                imagebutton:
                    idle "gui/info_idle.png"
                    hover "gui/info_hover.png"
                    xpos 10
                    ypos 10
                    action Show("character_info")

                imagebutton:
                    idle "gui/phone_icon_idle.png"
                    hover "gui/phone_icon_hover.png"
                    xpos 20
                    ypos 20
                    action [
                        SetVariable("current_phone_view", None),
                        Show("phone_ui")
                    ]

                imagebutton:
                    idle "gui/map_icon_idle.png"
                    hover "gui/map_icon_hover.png"
                    xpos 170
                    ypos 0
                    at Transform(zoom=0.9)
                    action Show("map_screen")


                add "gui/music_vol.png":
                    xpos 300
                    ypos 20

                bar:
                    style "slider"
                    value Preference("music volume")
                    xpos 300
                    ypos 56
                    xsize 210

                add "gui/sound_vol.png":
                    xpos 545
                    ypos 20

                bar:
                    style "slider"
                    value Preference("sound volume")
                    xpos 545
                    ypos 56
                    xsize 210

                add "gui/voice_vol.png":
                    xpos 790
                    ypos 20

                bar:
                    style "slider"
                    value Preference("voice volume")
                    xpos 790
                    ypos 56
                    xsize 210

                imagebutton:
                    idle "gui/save_icon_idle.png"
                    hover "gui/save_icon_hover.png"
                    xpos 1025
                    ypos 25
                    at Transform(zoom=0.65)
                    action ShowMenu("save")

                imagebutton:
                    idle "gui/load_icon_idle.png"
                    hover "gui/load_icon_hover.png"
                    xpos 1170
                    ypos 25
                    at Transform(zoom=0.65)
                    action ShowMenu("load")



            if any(channel_notifs.values()):
                add "phone/notif.png" xpos 70 ypos 20 zoom 0.5



    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0





screen map_screen():
    tag menu

    modal True

    add "gui/map.jpg" xpos map_x ypos 0


    if map_x == 0:

        imagebutton:
            idle "gui/map_arrow_right.png"
            hover "gui/map_arrow_right_hover.png"
            action SetVariable("map_x", -1776)
            xalign 0.97
            yalign 0.5
            at Transform(zoom=0.9)


    elif map_x == -1776:

        imagebutton:
            idle "gui/map_arrow_left.png"
            hover "gui/map_arrow_left_hover.png"
            action SetVariable("map_x", 0)
            xalign 0.03
            yalign 0.5
            at Transform(zoom=0.9)

        imagebutton:
            idle "gui/map_arrow_right.png"
            hover "gui/map_arrow_right_hover.png"
            action SetVariable("map_x", -3521)
            xalign 0.97
            yalign 0.5
            at Transform(zoom=0.9)


    elif map_x == -3521:

        imagebutton:
            idle "gui/map_arrow_left.png"
            hover "gui/map_arrow_left_hover.png"
            action SetVariable("map_x", -1776)
            xalign 0.03
            yalign 0.5
            at Transform(zoom=0.9)


    vbox:
        xalign 0.97
        yalign 0.05
        yoffset -30

        textbutton "Return to Game":
            action Hide("map_screen")

screen character_info():
    tag menu

    modal True


    on "show" action If(selected_location not in ("Amanda's House", 'Diner', 'Emma’s Parlor', 'Gym', "Mary's Youth center", "Ollie's Table", 'Police Station', 'Rooftop Bar', "Rose's Company", 'University', 'Unknown', 'boarding_house'), SetVariable("selected_location", "boarding_house"), NullAction())

    key "mousedown_4" action NullAction()
    key "mousedown_5" action NullAction()

    add "gui/bio/charater_bg.jpg"


    viewport:
        xpos 0
        ypos 180
        xsize 312
        ysize 763

        mousewheel True
        draggable True
        scrollbars "vertical"

        has fixed
        xsize 312
        ysize 840







        $ location_icon_row_order = (0, 7, 2, 4, 1, 3, 5, 6, 8, 9, 10, 11)
        for display_row in range(12):
            add Transform("gui/bio/location_scroll.png", crop=(0, location_icon_row_order[display_row] * 70, 312, 70)):
                xpos 0
                ypos display_row * 70

        textbutton "Boarding House":
            xpos 75
            ypos -8
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "boarding_house")

        textbutton "Amanda's House":
            xpos 75
            ypos 70
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Amanda's House")

        textbutton "Mary's Youth center":
            xpos 75
            ypos 136
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Mary's Youth center")

        textbutton "University":
            xpos 75
            ypos 206
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "University")

        textbutton "Rose's Company":
            xpos 75
            ypos 274
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Rose's Company")

        textbutton "Gym":
            xpos 75
            ypos 345
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Gym")

        textbutton "Police Station":
            xpos 75
            ypos 417
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Police Station")

        textbutton "Diner":
            xpos 75
            ypos 487
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Diner")

        textbutton "Ollie's Table":
            xpos 75
            ypos 563
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Ollie's Table")

        textbutton "Rooftop Bar":
            xpos 75
            ypos 626
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Rooftop Bar")

        textbutton "Emma’s Parlor":
            xpos 75
            ypos 704
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Emma’s Parlor")

        textbutton "Unknown":
            xpos 75
            ypos 767
            text_size 20
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action SetVariable("selected_location", "Unknown")

    $ location_names = {
        "boarding_house": "Boarding House",
        "Amanda's House": "Amanda's House",
        "Mary's Youth center": "Mary's Youth center",
        "University": "University",
        "Rose's Company": "Rose's Company",
        "Gym": "Gym",
        "Police Station": "Police Station",
        "Diner": "Diner",
        "Ollie's Table": "Ollie's Table",
        "Rooftop Bar": "Rooftop Bar",
        "Emma’s Parlor": "Emma’s Parlor",
        "Unknown": "Unknown"
    }

    text location_names.get(selected_location, ""):
        xpos 400
        ypos 220
        size 30
        color "#c61f19"

    vbox:
        spacing 20
        xalign 0.55
        yalign 0.85

        textbutton "Return to Game":
            action Hide("character_info")

    on "hide" action Show("top_ui_buttons")

    if selected_location == "boarding_house":

        if getattr(store, "bio_helen", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/helen_icon.png"
                action [Hide("character_info"), Show("character_detail", character="helen")]

            $ helen_data = character_data["helen"]

            textbutton getattr(store, helen_data["name"]):
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="helen")]

            text helen_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_lena", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/lena_icon.png"
                action [Hide("character_info"), Show("character_detail", character="lena")]

            $ lena_data = character_data["lena"]

            textbutton lena_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="lena")]

            text lena_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Rose's Company":

        if getattr(store, "bio_rose", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/rose_icon.png"
                action [Hide("character_info"), Show("character_detail", character="rose")]

            $ rose_data = character_data["rose"]

            textbutton rose_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="rose")]

            text rose_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_alessia", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/alessia_icon.png"
                action [Hide("character_info"), Show("character_detail", character="alessia")]

            $ alessia_data = character_data["alessia"]

            textbutton alessia_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="alessia")]

            text alessia_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_chloe", False):

            imagebutton:
                xpos 1200
                ypos 295
                idle "images/character_bio/chloe_icon.png"
                action [Hide("character_info"), Show("character_detail", character="chloe")]

            $ chloe_data = character_data["chloe"]

            textbutton chloe_data["name"]:
                xpos 1335
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="chloe")]

            text chloe_data["job"]:
                xpos 1340
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_kevin", False):

            imagebutton:
                xpos 400
                ypos 445
                idle "images/character_bio/kevin_icon.png"
                action [Hide("character_info"), Show("character_detail", character="kevin")]

            $ kevin_data = character_data["kevin"]

            textbutton kevin_data["name"]:
                xpos 532
                ypos 450
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="kevin")]

            text kevin_data["job"]:
                xpos 540
                ypos 495
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_marcus", False):

            imagebutton:
                xpos 800
                ypos 445
                idle "images/character_bio/marcus_icon.png"
                action [Hide("character_info"), Show("character_detail", character="marcus")]

            $ marcus_data = character_data["marcus"]

            textbutton marcus_data["name"]:
                xpos 940
                ypos 450
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="marcus")]

            text marcus_data["job"]:
                xpos 948
                ypos 495
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_shakira", False):

            imagebutton:
                xpos 1200
                ypos 445
                idle "images/character_bio/shakira_icon.png"
                action [Hide("character_info"), Show("character_detail", character="shakira")]

            $ shakira_data = character_data["shakira"]

            textbutton shakira_data["name"]:
                xpos 1335
                ypos 450
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="shakira")]

            text shakira_data["job"]:
                xpos 1340
                ypos 495
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_vivian", False):

            imagebutton:
                xpos 400
                ypos 595
                idle "images/character_bio/vivian_icon.png"
                action [Hide("character_info"), Show("character_detail", character="vivian")]

            $ vivian_data = character_data["vivian"]

            textbutton vivian_data["name"]:
                xpos 532
                ypos 600
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="vivian")]

            text vivian_data["job"]:
                xpos 540
                ypos 645
                size 22
                color "#CCCCCC"
    if selected_location == "Mary's Youth center":

        if getattr(store, "bio_mary", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/mary_icon.png"
                action [Hide("character_info"), Show("character_detail", character="mary")]

            $ mary_data = character_data["mary"]

            textbutton mary_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="mary")]

            text mary_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_celine", False):

            imagebutton:
                xpos 830
                ypos 295
                idle "images/character_bio/celine_icon.png"
                action [Hide("character_info"), Show("character_detail", character="celine")]

            $ celine_data = character_data["celine"]

            textbutton celine_data["name"]:
                xpos 960
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="celine")]

            text celine_data["job"]:
                xpos 970
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_evelyn", False):

            imagebutton:
                xpos 1270
                ypos 295
                idle "images/character_bio/evelyn_icon.png"
                action [Hide("character_info"), Show("character_detail", character="evelyn")]

            $ evelyn_data = character_data["evelyn"]

            textbutton evelyn_data["name"]:
                xpos 1400
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="evelyn")]

            text evelyn_data["job"]:
                xpos 1405
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Gym":

        if getattr(store, "bio_ivy", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/ivy_icon.png"
                action [Hide("character_info"), Show("character_detail", character="ivy")]

            $ ivy_data = character_data["ivy"]

            textbutton ivy_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="ivy")]

            text ivy_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "University":

        if getattr(store, "bio_jason", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/jason_icon.png"
                action [Hide("character_info"), Show("character_detail", character="jason")]

            $ jason_data = character_data["jason"]

            textbutton jason_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="jason")]

            text jason_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_sophia", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/sophia_icon.png"
                action [Hide("character_info"), Show("character_detail", character="sophia")]

            $ sophia_data = character_data["sophia"]

            textbutton sophia_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="sophia")]

            text sophia_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_rebecca", False):

            imagebutton:
                xpos 1200
                ypos 295
                idle "images/character_bio/rebecca_icon.png"
                action [Hide("character_info"), Show("character_detail", character="rebecca")]

            $ rebecca_data = character_data["rebecca"]

            textbutton rebecca_data["name"]:
                xpos 1335
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="rebecca")]

            text rebecca_data["job"]:
                xpos 1340
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Police Station":

        if getattr(store, "bio_diana", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/diana_icon.png"
                action [Hide("character_info"), Show("character_detail", character="diana")]

            $ diana_data = character_data["diana"]

            textbutton diana_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="diana")]

            text diana_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_harold", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/harold_icon.png"
                action [Hide("character_info"), Show("character_detail", character="harold")]

            $ harold_data = character_data["harold"]

            textbutton harold_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="harold")]

            text harold_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_ethan", False):

            imagebutton:
                xpos 1200
                ypos 295
                idle "images/character_bio/ethan_icon.png"
                action [Hide("character_info"), Show("character_detail", character="ethan")]

            $ ethan_data = character_data["ethan"]

            textbutton ethan_data["name"]:
                xpos 1340
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="ethan")]

            text ethan_data["job"]:
                xpos 1340
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_evan", False):

            imagebutton:
                xpos 400
                ypos 445
                idle "images/character_bio/evan_icon.png"
                action [Hide("character_info"), Show("character_detail", character="evan")]

            $ evan_data = character_data["evan"]

            textbutton evan_data["name"]:
                xpos 532
                ypos 450
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="evan")]

            text evan_data["job"]:
                xpos 540
                ypos 495
                size 22
                color "#CCCCCC"

    if selected_location == "Diner":

        if getattr(store, "bio_isabella", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/isabella_icon.png"
                action [Hide("character_info"), Show("character_detail", character="isabella")]

            $ isabella_data = character_data["isabella"]

            textbutton isabella_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="isabella")]

            text isabella_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Amanda's House":

        if getattr(store, "bio_amanda", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/amanda_icon.png"
                action [Hide("character_info"), Show("character_detail", character="amanda")]

            $ amanda_data = character_data["amanda"]

            textbutton amanda_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="amanda")]

            text amanda_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_frank", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/frank_icon.png"
                action [Hide("character_info"), Show("character_detail", character="frank")]

            $ frank_data = character_data["frank"]

            textbutton frank_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="frank")]

            text frank_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Ollie's Table":

        if getattr(store, "bio_olivia", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/olivia_icon.png"
                action [Hide("character_info"), Show("character_detail", character="olivia")]

            $ olivia_data = character_data["olivia"]

            textbutton olivia_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="olivia")]

            text olivia_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"

        if getattr(store, "bio_stella", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/stella_icon.png"
                action [Hide("character_info"), Show("character_detail", character="stella")]

            $ stella_data = character_data["stella"]

            textbutton stella_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="stella")]

            text stella_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Rooftop Bar":

        if getattr(store, "bio_monica", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/monica_icon.png"
                action [Hide("character_info"), Show("character_detail", character="monica")]

            $ monica_data = character_data["monica"]

            textbutton monica_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="monica")]

            text monica_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


        if getattr(store, "bio_leila", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/leila_icon.png"
                action [Hide("character_info"), Show("character_detail", character="leila")]

            $ leila_data = character_data["leila"]

            textbutton leila_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="leila")]

            text leila_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"

    if selected_location == "Emma’s Parlor":

        if getattr(store, "bio_emma", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/emma_icon.png"
                action [Hide("character_info"), Show("character_detail", character="emma")]

            $ emma_data = character_data["emma"]

            textbutton emma_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="emma")]

            text emma_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"


    if selected_location == "Unknown":

        if getattr(store, "bio_michael", False):

            imagebutton:
                xpos 400
                ypos 295
                idle "images/character_bio/michael_icon.png"
                action [Hide("character_info"), Show("character_detail", character="michael")]

            $ michael_data = character_data["michael"]

            textbutton michael_data["name"]:
                xpos 532
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="michael")]

            text michael_data["job"]:
                xpos 540
                ypos 340
                size 22
                color "#CCCCCC"

        if getattr(store, "bio_veronica", False):

            imagebutton:
                xpos 800
                ypos 295
                idle "images/character_bio/veronica_icon.png"
                action [Hide("character_info"), Show("character_detail", character="veronica")]

            $ veronica_data = character_data["veronica"]

            textbutton veronica_data["name"]:
                xpos 940
                ypos 295
                text_size 30
                text_idle_color "#FFFFFF"
                text_hover_color "#ee4037"
                action [Hide("character_info"), Show("character_detail", character="veronica")]

            text veronica_data["job"]:
                xpos 948
                ypos 340
                size 22
                color "#CCCCCC"











init python:

    BIO_REL_HEADING_FONT = "IMFellDWPica-Regular.ttf"
    for _bio_font in renpy.list_files():
        if _bio_font.replace("\\", "/").rsplit("/", 1)[-1].lower() == "imfelldwpica-regular.ttf":
            BIO_REL_HEADING_FONT = _bio_font
            break


screen body_png_asset(path, px, py, width, height):
    if renpy.loadable(path):
        add path:
            xpos px
            ypos py
            xysize (width, height)


screen body_stat_row(label, value, label_x, value_x, row_y, value_width, font_size=20, right_align=False):
    fixed:
        xpos label_x
        ypos row_y
        xsize (value_x - label_x + value_width)
        ysize 30
        text label:
            xpos 0
            yalign 0.5
            xsize (value_x - label_x - 6)
            size font_size
            color "#E4DADB"
        text value:
            xpos (value_x - label_x)
            yalign 0.5
            xsize value_width
            text_align (1.0 if right_align else 0.0)
            size font_size
            color "#FFFFFF"


screen sexual_scaled_asset(path, cx, cy, scale=1.0):
    if renpy.loadable(path):
        add path:
            xpos cx
            ypos cy
            xanchor 0.5
            yanchor 0.5
            zoom scale


screen bio_relationship_card(bx, by, mini_png, char_name, relationship, note, tag_png):
    use body_png_asset("gui/bio/relation_box_bottom_child.png", bx, by, 344, 207)
    use body_png_asset(mini_png, bx + 9, by + 8, 139, 186)
    text char_name:
        xpos (bx + 157)
        ypos (by + 14)
        xsize 173
        font BIO_REL_HEADING_FONT
        size 24
        bold False
        italic False
        color "#FFD0DB"
    text relationship:
        xpos (bx + 157)
        ypos (by + 48)
        xsize 171
        size 19
        bold True
        color "#F3E8E9"
    if note:
        text note:
            xpos (bx + 157)
            ypos (by + 89)
            xsize 173
            size 18
            line_spacing 1
            color "#F3E8E9"

    if renpy.loadable(tag_png):
        add tag_png:
            xpos (bx + 157)
            ypos (by + 145)
            xysize (173, 42)
            fit "scale-down"


screen bio_sexual_partner(mini_y, mini_png, char_name, relationship, heart_png=""):


    if renpy.loadable(mini_png):
        add mini_png:
            xpos 850
            ypos mini_y
            xysize (107, 141)
            fit "contain"
    text char_name:
        xpos 974
        ypos (mini_y + 13)
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        color "#FDE2E9"
    text relationship:
        xpos 974
        ypos (mini_y + 46)
        xsize 175
        size 18
        color "#E7D6DA"
    if heart_png:
        use sexual_scaled_asset(heart_png, 1150, mini_y + 70, 0.50)


screen bio_sexual_slot(png_path, caption, cell_x, center_y):
    use sexual_scaled_asset(png_path, cell_x + 25, center_y, 0.22)
    text caption:
        xpos (cell_x + 52)
        ypos (center_y - 12)
        xsize 80
        size 16
        color "#F8E5EB"




screen body_profile_content(character, data):
    if character == "helen":
        use bio_body_helen()
    elif character == "lena":
        use bio_body_lena()
    else:
        text "Body profile details are coming in a future update.":
            xpos 820
            ypos 478
            size 24
            color "#FFFFFF"

screen bio_body_helen():

    use body_png_asset("gui/bio/box_top.png", 831, 214, 1078, 303)
    use body_png_asset("gui/bio/box_middle.png", 831, 528, 540, 222)
    use body_png_asset("gui/bio/box_middle.png", 1382, 528, 527, 222)
    use body_png_asset("gui/bio/box_bottom.png", 831, 762, 540, 208)
    use body_png_asset("gui/bio/box_bottom.png", 1382, 762, 527, 208)

    use body_png_asset("gui/bio/landlady/landlady_body_portrait.png", 339, 169, 457, 795)
    use body_png_asset("gui/bio/landlady/box_portrait.png", 337, 167, 461, 799)
    use body_png_asset("gui/bio/landlady/box_traits.png", 1382, 762, 527, 208)

    use body_png_asset("gui/bio/landlady/landlady_body_front.png", 1253, 223, 209, 282)
    use body_png_asset("gui/bio/landlady/landlady_body_side.png", 1472, 223, 209, 282)
    use body_png_asset("gui/bio/landlady/landlady_body_back.png", 1691, 223, 207, 282)
    use body_png_asset("gui/bio/landlady/landlady_body_tits.png", 1156, 540, 203, 199)
    use body_png_asset("gui/bio/landlady/landlady_body_ass.png", 1693, 540, 202, 199)
    use body_png_asset("gui/bio/landlady/landlady_body_pussy.png", 1156, 772, 203, 187)

    text 'Body':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her physical features and intimate details.':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Helen":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"


    text 'Measurements':
        xpos 860
        ypos 231
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Height", "168 cm", 863, 1003, 284, 212, font_size=21, right_align=True)
    use body_stat_row("Weight", "64 kg", 863, 1003, 324, 212, font_size=21, right_align=True)
    use body_stat_row("Bust", "98 cm (38.6\")", 863, 1003, 364, 212, font_size=21, right_align=True)
    use body_stat_row("Waist", "74 cm (29.1\")", 863, 1003, 404, 212, font_size=21, right_align=True)
    use body_stat_row("Hip", "104 cm (40.9\")", 863, 1003, 444, 212, font_size=21, right_align=True)

    text 'Breasts':
        xpos 860
        ypos 546
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Size", "E-Cup", 864, 1006, 588, 147, font_size=20)
    use body_stat_row("Shape", "Round / Full", 864, 1006, 624, 147, font_size=20)
    use body_stat_row("Nipples", "Medium", 864, 1006, 660, 147, font_size=20)
    use body_stat_row("Areola", "Medium, Pinkish", 864, 1006, 696, 147, font_size=20)

    text 'Hips & Ass':
        xpos 1414
        ypos 546
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Size", "104 cm", 1414, 1545, 588, 140, font_size=20)
    use body_stat_row("Shape", "Rounded / Full", 1414, 1545, 624, 140, font_size=20)
    use body_stat_row("Firmness", "Soft / Natural", 1414, 1545, 660, 140, font_size=20)

    text 'Genital Features':
        xpos 860
        ypos 777
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Appearance", "Natural", 864, 1019, 827, 134, font_size=19)
    use body_stat_row("Skin Tone", "Soft Pink", 864, 1019, 865, 134, font_size=19)
    use body_stat_row("Grooming", "Trimmed", 864, 1019, 903, 134, font_size=19)

    text 'Other Traits':
        xpos 1413
        ypos 777
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"

    text "Mature Figure":
        xpos 1418
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Soft Skin":
        xpos 1573
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Full Bust":
        xpos 1728
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Curvy Hips":
        xpos 1418
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Well-Groomed":
        xpos 1573
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Experienced Genitals":
        xpos 1728
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"




screen bio_body_lena():

    use body_png_asset("gui/bio/box_top.png", 831, 214, 1078, 303)
    use body_png_asset("gui/bio/box_middle.png", 831, 528, 540, 222)
    use body_png_asset("gui/bio/box_middle.png", 1382, 528, 527, 222)
    use body_png_asset("gui/bio/box_bottom.png", 831, 762, 540, 208)
    use body_png_asset("gui/bio/box_bottom.png", 1382, 762, 527, 208)

    use body_png_asset("gui/bio/lena/lena_body_portrait.png", 339, 169, 457, 795)

    use body_png_asset("gui/bio/lena/lena_body_front.png", 1253, 223, 209, 282)
    use body_png_asset("gui/bio/lena/lena_body_side.png", 1472, 223, 209, 282)
    use body_png_asset("gui/bio/lena/lena_body_back.png", 1691, 223, 207, 282)
    use body_png_asset("gui/bio/lena/lena_body_tits.png", 1156, 540, 203, 199)
    use body_png_asset("gui/bio/lena/lena_body_ass.png", 1693, 540, 202, 199)
    use body_png_asset("gui/bio/lena/lena_body_pussy.png", 1156, 772, 203, 187)

    text 'Body':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her physical features and intimate details.':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Lena":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"


    text 'Measurements':
        xpos 860
        ypos 231
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Height", "167 cm", 863, 1003, 284, 212, font_size=21, right_align=True)
    use body_stat_row("Weight", "59 kg", 863, 1003, 324, 212, font_size=21, right_align=True)
    use body_stat_row("Bust", "96 cm (37.8\")", 863, 1003, 364, 212, font_size=21, right_align=True)
    use body_stat_row("Waist", "70 cm (27.6\")", 863, 1003, 404, 212, font_size=21, right_align=True)
    use body_stat_row("Hip", "102 cm (40.2\")", 863, 1003, 444, 212, font_size=21, right_align=True)
    use body_stat_row("Type", "Toned, curvy hourglass", 863, 1003, 478, 230, font_size=17)

    text 'Breasts':
        xpos 860
        ypos 546
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Size", "Full", 864, 1006, 588, 147, font_size=20)
    use body_stat_row("Shape", "Natural / Full", 864, 1006, 624, 147, font_size=20)
    use body_stat_row("Nipples", "Medium", 864, 1006, 660, 147, font_size=20)
    use body_stat_row("Areola", "Medium, Pinkish", 864, 1006, 696, 147, font_size=20)

    text 'Hips & Ass':
        xpos 1414
        ypos 546
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Size", "102 cm", 1414, 1545, 588, 140, font_size=20)
    use body_stat_row("Shape", "Curvy / Rounded", 1414, 1545, 624, 140, font_size=20)
    use body_stat_row("Firmness", "Toned", 1414, 1545, 660, 140, font_size=20)

    text 'Genital Features':
        xpos 860
        ypos 777
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"
    use body_stat_row("Appearance", "Natural", 864, 1019, 827, 134, font_size=19)
    use body_stat_row("Skin Tone", "Soft Pink", 864, 1019, 865, 134, font_size=19)
    use body_stat_row("Grooming", "Trimmed", 864, 1019, 903, 134, font_size=19)

    text 'Other Traits':
        xpos 1413
        ypos 777
        font BIO_REL_HEADING_FONT
        size 28
        bold False
        italic False
        color "#F6BEC9"

    text "Toned Figure":
        xpos 1418
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Soft Skin":
        xpos 1573
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Full Bust":
        xpos 1728
        ypos 835
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Curvy Hips":
        xpos 1418
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Hourglass Build":
        xpos 1573
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"
    text "Experienced Genitals":
        xpos 1728
        ypos 891
        xsize 145
        text_align 0.5
        size 18
        color "#F7D3DB"




screen relationship_profile_content(character, data):
    if character == "helen":
        use bio_relationship_helen(data)
    elif character == "lena":
        use bio_relationship_lena(data)
    else:
        text "Relationship details are coming in a future update.":
            xpos 820
            ypos 478
            size 24
            color "#FFFFFF"

screen bio_relationship_helen(data):

    use body_png_asset("gui/bio/box_top.png", 831, 214, 1078, 303)

    if renpy.loadable("gui/bio/landlady/landlay_portrait.png"):
        use body_png_asset("gui/bio/landlady/landlay_portrait.png", 339, 169, 457, 795)
    else:
        use body_png_asset("gui/bio/landlady/landlady_body_portrait.png", 339, 169, 457, 795)
    use body_png_asset("gui/bio/box_portrait.png", 337, 167, 461, 799)
    use body_png_asset("gui/bio/relation_box_bottom.png", 831, 528, 1078, 442)
    text 'Relationship':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her bonds with the people in her life.':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Helen":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"


    use body_png_asset("gui/bio/landlady/landlady_mini.png", 867, 225, 203, 205)
    use body_png_asset("gui/bio/mc_mini.png", 1162, 225, 205, 205)
    use body_png_asset("gui/bio/heart02.png", 1080, 291, 72, 72)

    text "Love: [getattr(store, data['love'])]":
        xpos 1384
        ypos 259
        size 21
        color "#FFB4C6"
    text "Lust: [getattr(store, data['lust'])]":
        xpos 1546
        ypos 259
        size 21
        color "#FF97B0"
    text "Suspicion: [getattr(store, data['sus'])]":
        xpos 1711
        ypos 259
        size 21
        color "#CBC4C6"

    text "Little by little, they are finding their way into each other's lives.":
        xpos 1379
        ypos 325
        xsize 489
        size 22
        line_spacing 6
        color "#F7E9EB"
    add "gui/bio/horizontal_line01.png":
        xpos 848
        ypos 438
    text 'Current Status':
        xpos 890
        ypos 460
        font BIO_REL_HEADING_FONT
        size 22
        bold False
        italic False
        color "#FFD0DB"


    if renpy.loadable("gui/bio/friendly.png"):
        add "gui/bio/friendly.png":
            xpos 1075
            ypos 453
            xysize (242, 49)
            fit "scale-down"
    if renpy.loadable("gui/bio/mixed Feelings.png"):
        add "gui/bio/mixed Feelings.png":
            xpos 1331
            ypos 453
            xysize (242, 49)
            fit "scale-down"
    if renpy.loadable("gui/bio/unknown.png"):
        add "gui/bio/unknown.png":
            xpos 1587
            ypos 453
            xysize (242, 49)
            fit "scale-down"

    use bio_relationship_card(846, 540, "gui/bio/lena_npc_mini.png", "Lena", "Soulmate", "Best friend, lover,\nbusiness partner.", "gui/bio/sexually Involved.png")
    use bio_relationship_card(1197, 540, "gui/bio/ivy_npc_mini.png", "Ivy", "Friend", "Her fitness coach.", "gui/bio/friendly.png")
    use bio_relationship_card(1548, 540, "gui/bio/sophia_npc_mini.png", "Sophia", "Her Model", "They feel oddly drawn\nto each other.", "gui/bio/Colleague.png")
    use bio_relationship_card(846, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(1197, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(1548, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")




screen bio_relationship_lena(data):

    use body_png_asset("gui/bio/box_top.png", 831, 214, 1078, 303)

    use body_png_asset("gui/bio/lena/lena_body_portrait.png", 339, 169, 457, 795)
    use body_png_asset("gui/bio/box_portrait.png", 337, 167, 461, 799)
    use body_png_asset("gui/bio/relation_box_bottom.png", 831, 528, 1078, 442)
    text 'Relationship':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her bonds with the people in her life.':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Lena":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"


    use body_png_asset("gui/bio/lena/lena_mini.png", 867, 225, 203, 205)
    use body_png_asset("gui/bio/mc_mini.png", 1162, 225, 205, 205)
    use body_png_asset("gui/bio/heart02.png", 1080, 291, 72, 72)

    text "Love: [getattr(store, data['love'])]":
        xpos 1384
        ypos 259
        size 21
        color "#FFB4C6"
    text "Lust: [getattr(store, data['lust'])]":
        xpos 1546
        ypos 259
        size 21
        color "#FF97B0"
    text "Suspicion: [getattr(store, data['sus'])]":
        xpos 1711
        ypos 259
        size 21
        color "#CBC4C6"

    text "Will [d_name] be her trophy, or will she become [d_name]'s trophy?":
        xpos 1379
        ypos 325
        xsize 489
        size 22
        line_spacing 6
        color "#F7E9EB"
    add "gui/bio/horizontal_line01.png":
        xpos 848
        ypos 438
    text 'Current Status':
        xpos 890
        ypos 460
        font BIO_REL_HEADING_FONT
        size 22
        bold False
        italic False
        color "#FFD0DB"


    if renpy.loadable("gui/bio/friendly.png"):
        add "gui/bio/friendly.png":
            xpos 1075
            ypos 453
            xysize (242, 49)
            fit "scale-down"
    if renpy.loadable("gui/bio/flirting.png"):
        add "gui/bio/flirting.png":
            xpos 1331
            ypos 453
            xysize (242, 49)
            fit "scale-down"
    if renpy.loadable("gui/bio/unknown.png"):
        add "gui/bio/unknown.png":
            xpos 1587
            ypos 453
            xysize (242, 49)
            fit "scale-down"

    use bio_relationship_card(846, 540, "gui/bio/landlady_npc_mini.png", "Helen", "Soulmate", "Soulmate and lover.", "gui/bio/sexually Involved.png")
    use bio_relationship_card(1197, 540, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(1548, 540, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(846, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(1197, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")
    use bio_relationship_card(1548, 756, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "", "gui/bio/unknown.png")




screen sexual_relationship_profile_content(character, data):
    if character == "helen":
        use bio_sexual_helen()
    elif character == "lena":
        use bio_sexual_lena()
    else:
        text "Intimate relationship details are coming in a future update.":
            xpos 820
            ypos 478
            size 24
            color "#FFFFFF"

screen bio_sexual_helen():

    if renpy.loadable("gui/bio/landlady/landlay_portrait.png"):
        use body_png_asset("gui/bio/landlady/landlay_portrait.png", 339, 169, 457, 795)
    else:
        use body_png_asset("gui/bio/landlady/landlady_body_portrait.png", 339, 169, 457, 795)
    use body_png_asset("gui/bio/box_portrait.png", 337, 167, 461, 799)
    use body_png_asset("gui/bio/sex_box_top.png", 831, 214, 1078, 200)
    use body_png_asset("gui/bio/sex_box_left.png", 831, 426, 365, 531)
    text 'Sexual Relationship':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her intimate relationship with [d_name].':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Helen":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"

    text 'Relationship with [d_name] (You)':
        xpos 859
        ypos 227
        font BIO_REL_HEADING_FONT
        size 24
        bold False
        italic False
        color "#FFD0DB"
    use body_png_asset("gui/bio/heart.png", 861, 278, 133, 117)

    text "Lv. 3":
        xpos 927
        ypos 310
        xanchor 0.5
        size 25
        bold False
        italic False
        color "#FFE8EE"
    text 'Suddenly, You Look Different':
        xpos 1042
        ypos 277
        font BIO_REL_HEADING_FONT
        size 27
        bold False
        italic False
        color "#FFD0DB"

    text "She witnessed you masturbating while calling out her name. From time to time, she finds herself thinking about your penis.":
        xpos 1042
        ypos 318
        xsize 814
        size 20
        line_spacing 3
        color "#F3E5E8"
    text 'Other Sexual Partners':
        xpos 852
        ypos 439
        font BIO_REL_HEADING_FONT
        size 22
        bold False
        italic False
        color "#FFD0DB"

    use bio_sexual_partner(481, "gui/bio/lena_npc_mini.png", "Lena", "Lover (Current)", "gui/bio/heart08.png")
    use bio_sexual_partner(627, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "")
    use bio_sexual_partner(773, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "")



    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 426, 700, 170)
    text 'Intimate Actions':
        xpos 1231
        ypos 434
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/undress.png", "Undress", 1223, 492)
    use bio_sexual_slot("gui/bio/embrace.png", "Embrace", 1360, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 549)


    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 606, 700, 170)
    text 'Positions':
        xpos 1231
        ypos 614
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 729)


    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 786, 700, 170)
    text 'Threesome':
        xpos 1231
        ypos 794
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 909)




screen bio_sexual_lena():

    use body_png_asset("gui/bio/lena/lena_body_portrait.png", 339, 169, 457, 795)
    use body_png_asset("gui/bio/box_portrait.png", 337, 167, 461, 799)
    use body_png_asset("gui/bio/sex_box_top.png", 831, 214, 1078, 200)
    use body_png_asset("gui/bio/sex_box_left.png", 831, 426, 365, 531)
    text 'Sexual Relationship':
        xpos 830
        ypos 160
        font BIO_REL_HEADING_FONT
        size 34
        bold False
        italic False
        color "#FFD0DB"

    text 'Her intimate relationship with [d_name].':
        xpos 1875
        ypos 170
        xanchor 1.0
        size 19
        italic False
        color "#BEB1B2"

    text "Lena":
        xpos 1894
        ypos 39
        xanchor 1.0
        size 40
        italic False
        color "#F7EEEE"

    text 'Relationship with [d_name] (You)':
        xpos 859
        ypos 227
        font BIO_REL_HEADING_FONT
        size 24
        bold False
        italic False
        color "#FFD0DB"
    use body_png_asset("gui/bio/heart.png", 861, 278, 133, 117)

    text "Lv. 5":
        xpos 927
        ypos 310
        xanchor 0.5
        size 25
        bold False
        italic False
        color "#FFE8EE"
    text "Well, I've Seen for Myself":
        xpos 1042
        ypos 277
        font BIO_REL_HEADING_FONT
        size 27
        bold False
        italic False
        color "#FFD0DB"

    text "She tasted [d_name]'s cock once. It left a lasting impression on her.":
        xpos 1042
        ypos 318
        xsize 814
        size 20
        line_spacing 3
        color "#F3E5E8"
    text 'Other Sexual Partners':
        xpos 852
        ypos 439
        font BIO_REL_HEADING_FONT
        size 22
        bold False
        italic False
        color "#FFD0DB"

    use bio_sexual_partner(481, "gui/bio/landlady_npc_mini.png", "Helen", "Lover (Current)", "gui/bio/heart08.png")
    use bio_sexual_partner(627, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "")
    use bio_sexual_partner(773, "gui/bio/unkown_npc_mini.png", "Unknown", "Unknown", "")



    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 426, 700, 170)
    text 'Intimate Actions':
        xpos 1231
        ypos 434
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/undress.png", "Undress", 1223, 492)
    use bio_sexual_slot("gui/bio/embrace.png", "Embrace", 1360, 492)
    use bio_sexual_slot("gui/bio/oral.png", "Oral Sex", 1497, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 492)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 549)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 549)


    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 606, 700, 170)
    text 'Positions':
        xpos 1231
        ypos 614
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 672)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 729)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 729)


    use body_png_asset("gui/bio/sex_box_bottom.png", 1209, 786, 700, 170)
    text 'Threesome':
        xpos 1231
        ypos 794
        font BIO_REL_HEADING_FONT
        size 23
        bold False
        italic False
        color "#FFD0DB"
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 852)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1223, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1360, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1497, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1634, 909)
    use bio_sexual_slot("gui/bio/sex_unknown.png", "???", 1771, 909)

screen character_detail(character=""):
    tag menu

    modal True

    key "mousedown_4" action NullAction()
    key "mousedown_5" action NullAction()



    $ data = character_data[character] if selected_character_info in ("Character Info", "Relationship") else None


    if selected_character_info == "Character Info":
        add "gui/bio/charaterinfo_bg.jpg"

    elif selected_character_info == "Body":


        add "gui/bio/charaterinfo_bg.jpg"

    elif selected_character_info == "Relationship":

        add "gui/bio/charaterinfo_bg.jpg"

    elif selected_character_info == "Sexual Relationship":
        add "gui/bio/charaterinfo_bg.jpg"


    add "gui/bio/characinfo_scroll.png" xpos 0 ypos 180


    textbutton "Character Info":
        xpos 75
        ypos 170
        text_size 20
        text_idle_color "#FFFFFF"
        text_hover_color "#ee4037"
        action SetVariable("selected_character_info", "Character Info")

    textbutton "Body":
        xpos 75
        ypos 247
        text_size 20
        text_idle_color "#FFFFFF"
        text_hover_color "#ee4037"
        action SetVariable("selected_character_info", "Body")

    textbutton "Relationship":
        xpos 75
        ypos 320
        text_size 20
        text_idle_color "#FFFFFF"
        text_hover_color "#ee4037"
        action SetVariable("selected_character_info", "Relationship")

    textbutton "Sexual Relationship":
        xpos 75
        ypos 390
        text_size 20
        text_idle_color "#FFFFFF"
        text_hover_color "#ee4037"
        action SetVariable("selected_character_info", "Sexual Relationship")






    if selected_character_info == "Character Info":


        add "images/character_bio/[character].jpg":
            xpos 400
            ypos 250
            size (636, 636)



        frame:
            background None
            xpos 1120
            ypos 220
            xsize 700
            ysize 600

            has vbox
            spacing 10


            fixed:
                xsize 630
                ysize 42

                text "Name: [getattr(store, data['name'], data['name'])]":
                    xpos 0
                    ypos 0
                    size 30
                    color "#FFFFFF"

                if data["status_type"] == "female":
                    hbox:
                        xpos 250
                        ypos 6
                        spacing 16

                        text "Lust: [getattr(store, data['lust'])]":
                            size 22
                            color "#FF66AA"

                        text "Love: [getattr(store, data['love'])]":
                            size 22
                            color "#FF0000"

                        text "Sus: [getattr(store, data['sus'])]":
                            size 22
                            color "#808080"

                elif data["status_type"] == "male":
                    hbox:
                        xpos 250
                        ypos 7
                        spacing 13

                        text "Friendship: [getattr(store, data['friendship'])]":
                            size 19
                            color "#4CAF50"

                        text "Respect: [getattr(store, data['respect'])]":
                            size 19
                            color "#2196F3"

                        text "Rivalry: [getattr(store, data['rivalry'])]":
                            size 19
                            color "#FF0000"

            text "Age: [data['age']]":
                size 24
                color "#DDDDDD"

            text "Job: [data['job']]":
                size 24
                color "#CCCCCC"


            viewport:
                xsize 630
                ysize 420
                mousewheel True
                draggable True
                scrollbars "vertical"

                has vbox
                spacing 10

                for entry in data["info"]:
                    if entry["condition"] is None:
                        text entry["text"]:
                            xsize 575
                            size 18
                            color "#FFFFFF"

                    elif getattr(store, entry["condition"], False):
                        text entry["text"]:
                            xsize 575
                            size 18
                            color "#FFFFFF"

                text data["continuation"]:
                    xsize 575
                    size 24
                    color "#FFFFFF"





        if character == "helen":
            fixed:
                xpos 1190
                ypos 795
                xsize 630
                ysize 150

                text "Key Traits":
                    xpos 0
                    ypos 0
                    font BIO_REL_HEADING_FONT
                    size 26
                    bold False
                    italic False
                    color "#FFD0DB"


                text "Kind":
                    xpos 0
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Independent":
                    xpos 195
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Emotional":
                    xpos 390
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"


                text "Sensitive Body":
                    xpos 0
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "High Libido":
                    xpos 195
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Big Dick Lover":
                    xpos 390
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

        elif character == "lena":
            fixed:
                xpos 1190
                ypos 795
                xsize 630
                ysize 150

                text "Key Traits":
                    xpos 0
                    ypos 0
                    font BIO_REL_HEADING_FONT
                    size 26
                    bold False
                    italic False
                    color "#FFD0DB"


                text "Cynical":
                    xpos 0
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Quirky":
                    xpos 195
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Emotional":
                    xpos 390
                    ypos 51
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"


                text "Nymphomaniac":
                    xpos 0
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Younger Man Lover":
                    xpos 195
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"

                text "Big Dick Lover":
                    xpos 390
                    ypos 97
                    xsize 178
                    text_align 0.5
                    size 19
                    color "#FFFFFF"






    elif selected_character_info == "Body":

        use body_profile_content(character, data)





    elif selected_character_info == "Relationship":

        use relationship_profile_content(character, data)






    elif selected_character_info == "Sexual Relationship":

        use sexual_relationship_profile_content(character, data)





    hbox:
        spacing 40
        xalign 0.56
        ypos 970

        textbutton "Return to Character List":
            text_size 26
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action [Hide("character_detail"), Show("character_info")]

        textbutton "Return to Game":
            text_size 26
            text_idle_color "#FFFFFF"
            text_hover_color "#ee4037"
            action Hide("character_detail")

    on "hide" action Show("top_ui_buttons")


init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos

    adjust_spacing False











screen input(prompt):
    style_prefix "input"

    window:

        has vbox
        xanchor gui.dialogue_text_xalign
        xpos gui.dialogue_xpos
        xsize gui.dialogue_width
        ypos gui.dialogue_ypos

        text prompt style "input_prompt"
        input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width










screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            textbutton i.caption action i.action


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 405
    yanchor 0.5

    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")

style choice_button_text is default:
    properties gui.text_properties("choice_button")







screen quick_menu():


    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("History") action ShowMenu('history')
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Save") action ShowMenu('save')
            textbutton _("Q.Save") action QuickSave()
            textbutton _("Q.Load") action QuickLoad()
            textbutton _("Prefs") action ShowMenu('preferences')




init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.text_properties("quick_button")











screen navigation():
    frame:
        background "gui/menu_background.png"
        yalign 0.95
        xalign 0.0
        ysize 104
        padding (0,0)
        xfill True

        has hbox
        style_prefix "navigation"




        yalign 0.5
        xalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            textbutton _("Start") action Start()

        else:

            textbutton _("History") action ShowMenu("history")

            textbutton _("Save") action ShowMenu("save")

        textbutton _("Load") action ShowMenu("load")

        if main_menu:
            textbutton _("Replay") action ShowMenu("replay_menu")

        textbutton _("Preferences") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("End Replay") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("Main Menu") action MainMenu()

        textbutton _("About") action ShowMenu("about")


        textbutton _("Council") action ShowMenu("council")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):


            textbutton _("Help") action ShowMenu("help")

        if renpy.variant("pc"):



            textbutton _("Quit") action Quit(confirm=not main_menu)

style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    properties gui.text_properties("navigation_button")








screen main_menu():
    tag menu


    add gui.main_menu_background at hand_camera


    frame:
        xysize (1920, 1080)
        background "#0000"
        modal True
        null height 0 width 0


    frame:
        style "main_menu_frame"

    add "images/intro/milfheim_logo.png" xpos 0.5 ypos 0.5 anchor (0.5, 0.5) alpha 0.1
    add "images/intro/milfheim_logo.png" zoom 0.4 align (0.0, 1.0) offset (20,-50)
    imagebutton:
        idle "gui/patreon_icon.png"
        hover "gui/patreon_icon_hover.png"
        xpos 0.92
        ypos 0.906
        anchor (0.5, 0.5)
        action OpenURL("https://patreon.com/Bittersweet3D")
    imagebutton:
        idle "gui/discord_icon.png"
        hover "gui/discord_icon_hover.png"
        xpos 0.96
        ypos 0.906
        anchor (0.5, 0.5)
        action OpenURL("https://discord.gg/UGQgKVfxYn")


    use navigation

    if gui.show_name:
        vbox:
            style "main_menu_vbox"

            text "[config.name!t]":
                style "main_menu_title"

            text "[config.version]":
                style "main_menu_version"


screen phone_gallery_thumbs():
    tag phone_gallery

    modal True
    zorder 101

    window:
        at phone_position(phone_zoom, phone_x, phone_y)
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 1000

        add "images/phone/base.png"


        viewport:
            xsize 478
            ysize 777
            xpos 75
            ypos 60
            draggable True
            mousewheel True
            scrollbars "vertical"

            has vbox
            spacing 10


            null height 100

            for row in range(0, len(gallery_images), 3):
                hbox:
                    spacing 5
                    for i in range(3):
                        $ idx = row + i
                        if idx < len(gallery_images):
                            imagebutton:
                                idle im.Scale(gallery_images[idx]["thumb"], 150, 100)
                                action Show("gallery_image_fullscreen", image_path=gallery_images[idx]["phone"])


    imagebutton:
        idle "images/phone/back.png"
        hover "images/phone/back.png"
        xalign 0.4
        yalign 0.16
        action [Hide("phone_gallery_thumbs"), Show("phone_ui")]


screen gallery_image_fullscreen(image_path=""):
    tag gallery_image
    modal True
    zorder 999


    add Solid("#000F")

    add image_path:
        fit "contain"
        xalign 0.5
        yalign 0.5

    key "mouseup_1" action Hide("gallery_image_fullscreen")
    key "K_ESCAPE" action Hide("gallery_image_fullscreen")

style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 420
    yfill True

    background "gui/overlay/main_menu.png"

style main_menu_vbox:
    xalign 1.0
    xoffset -30
    xmaximum 1200
    yalign 1.0
    yoffset -30

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")











screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    if main_menu:
        add gui.main_menu_background at truecenter
    else:
        add gui.game_menu_background at truecenter

    frame:
        style "game_menu_outer_frame"

        has hbox


        frame:
            style "game_menu_navigation_frame"

        frame:
            style "game_menu_content_frame"

            if scroll == "viewport":

                viewport:
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    has vbox
                    spacing spacing

                    transclude

            elif scroll == "vpgrid":

                vpgrid:
                    cols 1
                    yinitial yinitial

                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    spacing spacing

                    transclude

            else:

                transclude

    use navigation

    textbutton _("Return"):
        style "return_button"

        action Return()

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 45
    top_padding 180

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 420
    yfill True

style game_menu_content_frame:
    left_margin 60
    right_margin 30
    top_margin 15

style game_menu_viewport:
    xsize 1380

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label:
    xpos 75
    ysize 180

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -45














define council_mayor_names = [
    "Kima",
    "Tom Modeen",
    "Nicholas McRavion",
    "Harry White",
    "WhistlingDeath",
    "Silent-One",
    "Jacob Neyer",
    "Fawkyoself",
    "domtrodde",
    "Floriano Paper",
]

define council_local_leader_names = [
    "ALucard",
    "Turtle",
    "Felix 02",
    "Mattywhooo",
    "aabb",
    "Raminita",
    "Ciro Scognamiglio",
    "Kyle Manson",
    "potato420",
    "Brownsugar",
    "Bobet Caballes",
    "Andrew",
    "D",
    "Alberto Storelli",
    "hillbillyjo",
    "Morbid Views",
    "Anton Fo",
]

screen council():
    tag menu


    use game_menu(_("Council")):

        fixed:

            add "gui/council_bg.jpg":
                pos (0, -195)


            for i, nickname in enumerate(council_mayor_names[:20]):
                text nickname:
                    xpos 666 + (i % 4) * 162
                    ypos 253 + (i // 4) * 32
                    xsize 152
                    ysize 25
                    font gui.text_font
                    size 18
                    color "#F0F0ED"
                    bold False
                    layout "nobreak"


            for i, nickname in enumerate(council_local_leader_names[:20]):
                text nickname:
                    xpos 666 + (i % 4) * 162
                    ypos 549 + (i // 4) * 32
                    xsize 152
                    ysize 25
                    font gui.text_font
                    size 18
                    color "#F0F0ED"
                    bold False
                    layout "nobreak"


screen about():
    tag menu





    use game_menu(_("About"), scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("Version [config.version!t]\n")

            if gui.about:
                text "[gui.about!t]\n"
            text _("Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]")


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size











screen save():
    tag menu


    use file_slots(_("Save"))


screen load():
    tag menu


    use file_slots(_("Load"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("Page {}"), auto=_("Automatic saves"), quick=_("Quick saves"))

    use game_menu(title):

        fixed:



            order_reverse True


            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value


            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        action FileAction(slot)

                        has vbox

                        add FileScreenshot(slot) xalign 0.5

                        text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("empty slot")):
                            style "slot_time_text"

                        text FileSaveName(slot):
                            style "slot_name_text"

                        key "save_delete" action FileDelete(slot)


            vbox:
                style_prefix "page"

                xalign 0.5


                yalign 0.0

                if renpy.variant("small"):
                    yoffset 40

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}A") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}Q") action FilePage("quick")


                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                if config.has_sync:
                    if CurrentScreenName() == "save":
                        textbutton _("Upload Sync"):
                            action UploadSync()
                            xalign 0.5
                    else:
                        textbutton _("Download Sync"):
                            action DownloadSync()

                            if renpy.variant("small"):
                                xpos 1.55
                                xanchor 1.0
                            else:
                                xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 75
    ypadding 5

style page_label_text:
    textalign 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")









screen preferences():
    tag menu


    use game_menu(_("Preferences"), scroll="viewport"):

        vbox:

            hbox:
                box_wrap True

                if renpy.variant("pc") or renpy.variant("web"):

                    vbox:
                        style_prefix "radio"
                        label _("Display")
                        textbutton _("Window") action Preference("display", "window")
                        textbutton _("Fullscreen") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "check"
                    label _("Skip")
                    textbutton _("Unseen Text") action Preference("skip", "toggle")
                    textbutton _("After Choices") action Preference("after choices", "toggle")
                    textbutton _("Transitions") action InvertSelected(Preference("transitions", "toggle"))




            null height (4 * gui.pref_spacing)

            hbox:
                style_prefix "slider"
                box_wrap True

                vbox:

                    label _("Text Speed")

                    bar value Preference("text speed")

                    label _("Auto-Forward Time")

                    bar value Preference("auto-forward time")

                vbox:

                    if config.has_music:
                        label _("Music Volume")

                        hbox:
                            bar value Preference("music volume")

                    if config.has_sound:

                        label _("Sound Volume")

                        hbox:
                            bar value Preference("sound volume")

                            if config.sample_sound:
                                textbutton _("Test") action Play("sound", config.sample_sound)


                    if config.has_voice:
                        label _("Voice Volume")

                        hbox:
                            bar value Preference("voice volume")

                            if config.sample_voice:
                                textbutton _("Test") action Play("voice", config.sample_voice)

                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing

                        textbutton _("Mute All"):
                            action Preference("all mute", "toggle")
                            style "mute_all_button"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 675










screen history():
    tag menu



    predict False

    use game_menu(_("History"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:


                has fixed
                yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False



                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("The dialogue history is empty.")




define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5








screen help():
    tag menu


    default device = "keyboard"

    use game_menu(_("Help"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 23

            hbox:

                textbutton _("Keyboard") action SetScreenVariable("device", "keyboard")
                textbutton _("Mouse") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("Gamepad") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("Enter")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Space")
        text _("Advances dialogue without selecting choices.")

    hbox:
        label _("Arrow Keys")
        text _("Navigate the interface.")

    hbox:
        label _("Escape")
        text _("Accesses the game menu.")

    hbox:
        label _("Ctrl")
        text _("Skips dialogue while held down.")

    hbox:
        label _("Tab")
        text _("Toggles dialogue skipping.")

    hbox:
        label _("Page Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Page Down")
        text _("Rolls forward to later dialogue.")

    hbox:
        label "H"
        text _("Hides the user interface.")

    hbox:
        label "S"
        text _("Takes a screenshot.")

    hbox:
        label "V"
        text _("Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}.")

    hbox:
        label "Shift+A"
        text _("Opens the accessibility menu.")


screen mouse_help():

    hbox:
        label _("Left Click")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Middle Click")
        text _("Hides the user interface.")

    hbox:
        label _("Right Click")
        text _("Accesses the game menu.")

    hbox:
        label _("Mouse Wheel Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Mouse Wheel Down")
        text _("Rolls forward to later dialogue.")


screen gamepad_help():

    hbox:
        label _("Right Trigger\nA/Bottom Button")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Left Trigger\nLeft Shoulder")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Right Shoulder")
        text _("Rolls forward to later dialogue.")

    hbox:
        label _("D-Pad, Sticks")
        text _("Navigate the interface.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("Accesses the game menu.")

    hbox:
        label _("Y/Top Button")
        text _("Hides the user interface.")

    textbutton _("Calibrate") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0















screen confirm(message, yes_action, no_action):


    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        has vbox
        xalign .5
        yalign .5
        spacing 45

        label _(message):
            style "confirm_prompt"
            xalign 0.5

        hbox:
            xalign 0.5
            spacing 150

            textbutton _("Yes") action yes_action
            textbutton _("No") action no_action


    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    textalign 0.5
    layout "subtitle"

style confirm_button:
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    properties gui.text_properties("confirm_button")









screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        has hbox
        spacing 9

        text _("Skipping")

        text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"



transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:


    font "DejaVuSans.ttf"









screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")









screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox
        spacing gui.nvl_spacing


        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)



        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            has fixed
            yfit gui.nvl_height is None

            if d.who is not None:

                text d.who:
                    id d.who_id

            text d.what:
                id d.what_id




define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")











screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}







style pref_vbox:
    variant "medium"
    xsize 675



screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Menu") action ShowMenu()


style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background None

style game_menu_outer_frame:
    variant "small"
    background None

style game_menu_navigation_frame:
    variant "small"
    xsize 510

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 600

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 900



screen wait_and_continue(delay=1.0):
    timer delay action Return()

screen phone_wait_click():
    tag phone_click_gate
    modal True
    zorder 1001


    button:
        background None
        xfill True
        yfill True
        action Return()


    key "mouseup_1" action Return()
    key "K_RETURN" action Return()
    key "K_SPACE" action Return()


screen phone_dialogue_gate():
    modal True
    zorder 1001
    button:
        background None
        xfill True
        yfill True
        action Return()






screen replay_menu(page=0, selected_chapter="chapter01"):
    tag menu
    default replay_hovered = None


    key "game_menu" action NullAction()

    add "gui/overlay/game_menu.png"


    frame:
        xysize (1920, 1080)
        background "#0000"
        modal True


    $ filtered_scenes = [item for item in replay_scenes if item.get("chapter_id") == selected_chapter]
    $ chapter_unlocked, chapter_total = replay_ui_unlock_counts(filtered_scenes)
    $ overall_unlocked, overall_total = replay_ui_unlock_counts(replay_scenes)
    $ active_chapter_name = replay_ui_chapter_name(selected_chapter)
    $ per_page = 16
    $ total_pages = max(1, (len(filtered_scenes) + per_page - 1) // per_page)
    $ current_page = max(0, min(page, total_pages - 1))
    $ start_idx = current_page * per_page
    $ end_idx = min(start_idx + per_page, len(filtered_scenes))


    textbutton "Return":
        action Return()
        xalign 0.02
        yalign 0.02




    frame:
        xalign 0.0
        yalign 0.5
        xsize 350
        ysize 900
        xoffset 100
        yoffset 80
        background None

        add "gui/replaybox.png" yoffset -200

        vbox:
            xalign 0.5
            yalign 0.0
            spacing 20

            for chapter in replay_chapters:
                $ chapter_name = chapter["name"]
                $ chapter_id = chapter["id"]

                textbutton chapter_name:
                    text_style ("chapter_selected_text_style"
                                if chapter_id == selected_chapter
                                else "chapter_unselected_text_style")
                    action (NullAction()
                            if chapter_id == selected_chapter
                            else ShowMenu("replay_menu", page=0, selected_chapter=chapter_id))


        fixed:
            xpos 55
            ypos 540
            xysize (240, 98)

            text "MEMORY COLLECTION":
                xpos 0
                ypos 0
                size 17
                bold True
                color "#BEBEBE"

            text ("%d / %d" % (overall_unlocked, overall_total)):
                xpos 0
                ypos 27
                size 27
                color "#F4F4F4"

            text ("%d%%" % (int(100.0 * overall_unlocked / overall_total) if overall_total else 0)):
                xalign 1.0
                ypos 36
                size 17
                color "#F04B45"

            add Solid("#55555580"):
                xpos 0
                ypos 76
                xysize (240, 5)

            if overall_total and overall_unlocked:
                add Solid("#F04B45"):
                    xpos 0
                    ypos 76
                    xysize (max(2, int(240.0 * overall_unlocked / overall_total)), 5)




    frame:
        xalign 0.65
        yalign 0.48
        xoffset 40
        yoffset 40
        xsize 1100
        ysize 900
        background "#0000"


        fixed:
            xsize 1030
            ysize 71

            text active_chapter_name:
                xpos 0
                ypos 0
                font BIO_REL_HEADING_FONT
                size 36
                color "#F3F3F3"

            text "REPLAY ARCHIVE":
                xpos 250
                ypos 20
                size 16
                bold True
                color "#AAAAAA"

            if chapter_total and chapter_unlocked == chapter_total:
                text "CHAPTER COMPLETE":
                    xalign 1.0
                    ypos 19
                    size 19
                    bold True
                    color "#F04B45"
            else:
                text ("%d / %d UNLOCKED" % (chapter_unlocked, chapter_total)):
                    xalign 1.0
                    ypos 19
                    size 18
                    color "#DEDEDE"

            add Solid("#FFFFFF45"):
                xpos 0
                ypos 61
                xysize (1030, 2)

            if chapter_total and chapter_unlocked:
                add Solid("#EF4C44"):
                    xpos 0
                    ypos 61
                    xysize (max(2, int(1030.0 * chapter_unlocked / chapter_total)), 2)


        grid 4 4:
            xpos 0
            ypos 84
            spacing 10

            for i in range(start_idx, end_idx):
                $ item = filtered_scenes[i]
                $ unlocked = getattr(persistent, item["unlock"], False)

                fixed:
                    xysize (250, 140)

                    if unlocked:
                        imagebutton:
                            idle Transform(item["thumb"], size=(250, 140))
                            hover Transform(item["thumb"], size=(250, 140))
                            xsize 250
                            ysize 140
                            action Call("replay_wrapper", item["label"], item.get("sequence", None), selected_chapter, current_page)
                            hovered SetScreenVariable("replay_hovered", item["label"])
                            unhovered SetScreenVariable("replay_hovered", None)

                        if replay_hovered == item["label"]:

                            add Solid("#05050777") xysize (250, 140)
                            add Solid("#F04B45") xpos 0 ypos 0 xysize (250, 3)
                            add Solid("#F04B45") xpos 0 ypos 137 xysize (250, 3)
                            add Solid("#F04B45") xpos 0 ypos 0 xysize (3, 140)
                            add Solid("#F04B45") xpos 247 ypos 0 xysize (3, 140)

                            frame:
                                xalign 0.5
                                yalign 0.5
                                padding (16, 8)
                                background Solid("#C63C36F0")
                                text "▶  PLAY":
                                    font "DejaVuSans.ttf"
                                    color "#FFFFFF"
                                    size 17
                                    bold True
                        else:

                            add Solid("#06060677") xpos 0 ypos 118 xysize (44, 22)
                            text ("%02d" % (i + 1)):
                                xpos 12
                                ypos 119
                                size 15
                                color "#F5F5F5"

                    else:

                        add Transform(item["thumb_locked"], size=(250, 140))
                        add Solid("#00000033") xysize (250, 140)
                        add Solid("#080808A0") xpos 0 ypos 118 xysize (250, 22)
                        text ("%02d" % (i + 1)):
                            xpos 12
                            ypos 119
                            size 15
                            color "#9B9B9B"
                        text "LOCKED":
                            xalign 1.0
                            xoffset -10
                            ypos 120
                            size 13
                            bold True
                            color "#C0C0C0"


            for _ in range(per_page - (end_idx - start_idx)):
                null width 250 height 140


        if total_pages > 1:
            hbox:
                xalign 0.5
                ypos 766
                spacing 25

                if current_page > 0:
                    textbutton "‹  PREV":
                        action ShowMenu("replay_menu", page=current_page - 1, selected_chapter=selected_chapter)
                        text_size 19
                        text_color "#E5E5E5"
                        text_hover_color "#F04B45"
                else:
                    text "‹  PREV" size 19 color "#686868"

                text ("%02d / %02d" % (current_page + 1, total_pages)):
                    size 22
                    bold True
                    color "#F04B45"

                if current_page < total_pages - 1:
                    textbutton "NEXT  ›":
                        action ShowMenu("replay_menu", page=current_page + 1, selected_chapter=selected_chapter)
                        text_size 19
                        text_color "#E5E5E5"
                        text_hover_color "#F04B45"
                else:
                    text "NEXT  ›" size 19 color "#686868"

screen replay_header(return_chapter="chapter01", return_page=0):
    tag replay

    textbutton _("Replay Menu") xalign 0.02 yalign 0.02:
        action [
            
            Function(renpy.music.stop, channel="music", fadeout=0.5), 
            
            
            Function(renpy.sound.stop, channel="sound"), 

            
            Function(renpy.music.play,
                ["audio/bgm/title01.mp3", "audio/bgm/title02.mp3", "audio/bgm/title03.mp3"],
                channel="music",
                fadein=1.0,
                loop=True,
            ),

            
            ShowMenu("replay_menu", page=return_page, selected_chapter=return_chapter)
        ]

screen chapter_end_screen():

    add "chapter_ends"

    imagebutton:
        idle "phone/patreon_icon.png"
        hover "phone/patreon_icon_hover.png"
        xpos 920
        ypos 790
        action OpenURL("https://www.patreon.com/c/Bittersweet3D")

    imagebutton:
        idle "phone/discord_icon.png"
        hover "phone/discord_icon_hover.png"
        xpos 1060
        ypos 790
        action OpenURL("https://discord.gg/UGQgKVfxYn")

    textbutton "Return":
        xpos 20
        ypos 20
        action Return()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
