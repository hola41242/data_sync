















define config.name = _("Milfheim")
define config.language = "english"




define gui.show_name = False




define config.version = "0.6"





define gui.about = _p("""
Milfheim is an adult mystery visual novel.
Created by Bittersweet3D, 2026.
All characters are 18+.

Music Credits:
swarajthegreat, rusted music studio, AlexGrohl, Elijah_K, BackgroundMusicForVideos, monume, REDproductions, JourinHannah,restumanoush,Toucanmusic
""")






define build.name = "Milfheim"








define config.has_sound = True
define config.has_music = True
define config.has_voice = True
























init -999 python:

    dissolve_nonskip = Dissolve(0.5)
    fade_nonskip = Fade(0.5, 0.0, 0.5)

    dissolve_nonskip.can_be_skipped = False
    fade_nonskip.can_be_skipped = False
    fade_nonskip.interruptible = False

    dissolve = dissolve_nonskip
    fade = fade_nonskip

    config.fix_rollback_without_choice = True
    config.dismiss_blocking_transitions = False

    _dismiss_pause = False

    original_pause = renpy.pause

    def smart_pause(*args, **kwargs):
        global _dismiss_pause
        old_dismiss = _dismiss_pause
        _dismiss_pause = True  
        result = original_pause(*args, **kwargs)
        _dismiss_pause = old_dismiss 
        return result

    renpy.pause = smart_pause

define config.enter_transition = dissolve
define config.exit_transition = dissolve



define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)







default preferences.text_cps = 0





default preferences.afm_time = 15
















define config.save_directory = "Milfheim-19820706892892"






define config.window_icon = "gui/favicon.ico"
define build.windows_icon = "icon.ico"
define build.mac_icon = "icon.icns"






init python:




















    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)
    build.classify("game/cache/**", None)



    build.classify('game/**.png', 'archive')
    build.classify('game/**.jpg', 'archive')
    build.classify('game/**.webp', 'archive')




    build.documentation('*.html')
    build.documentation('*.txt')














init python:
    def block_rollback_during_phone():
        if renpy.get_screen("phone_ui"):
            renpy.block_rollback()

    config.overlay_functions.append(block_rollback_during_phone)

init python:
    renpy.music.register_channel("voice", "voice", loop=False)

init python:


    renpy.music.register_channel("voice_m", "voice", loop=False, stop_on_mute=True, tight=True)
    renpy.music.register_channel("voice_f", "voice", loop=False, stop_on_mute=True, tight=True)


init python:
    import random

label main_menu:

    $ main_menu_start_index = random.randrange(len(main_menu_images))


    $ bgm_list = [
        "audio/bgm/title01.mp3",
        "audio/bgm/title02.mp3",
        "audio/bgm/title03.mp3"
    ]


    $ random.shuffle(bgm_list)


    stop music fadeout 1.0



    play music bgm_list fadein 1.0


    call screen main_menu
    return


init python:

    if not hasattr(persistent, "in_replay"):
        persistent.in_replay = False

init python:

    config.layers = [ 'master', 'monologue', 'transient', 'screens', 'overlay' ]        

init python:
    renpy.music.register_channel("sfx", mixer="sound", loop=False)    

init python:


    renpy.music.register_channel("ambient", mixer="music", tight=True)    
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
