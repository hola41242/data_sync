
# Exclamation variables ########################################################

# Scarlett
default persistent.scarlett1 = False
default persistent.scarlett2 = False
default persistent.scarlett3 = False
default persistent.scarlett4 = False
default persistent.scarlett5 = False
default persistent.scarlett6 = False
default persistent.scarlett7 = False
default persistent.scarlett8 = False
default persistent.scarlett9 = False
default persistent.scarlett10 = False
default persistent.scarlett11 = False
default persistent.scarlett12 = False
default persistent.scarlett13 = False
default persistent.scarlett14 = False

default persistent.scarlett_list = [
    persistent.scarlett1,
    persistent.scarlett2,
    persistent.scarlett3,
    persistent.scarlett4,
    persistent.scarlett5,
    persistent.scarlett6,
    persistent.scarlett7,
    persistent.scarlett8,
    persistent.scarlett9,
    persistent.scarlett10,
    persistent.scarlett11,
    persistent.scarlett12,
    persistent.scarlett13,
    persistent.scarlett14
]

default persistent.scarlett_list = []

init python:
    def update_scarlett_list():
        persistent.scarlett_list = [
            persistent.scarlett1,
            persistent.scarlett2,
            persistent.scarlett3,
            persistent.scarlett4,
            persistent.scarlett5,
            persistent.scarlett6,
            persistent.scarlett7,
            persistent.scarlett8,
            persistent.scarlett9,
            persistent.scarlett10,
            persistent.scarlett11,
            persistent.scarlett12,
            persistent.scarlett13,
            persistent.scarlett14
        ]

# Cleo
default persistent.cleo1 = False
default persistent.cleo2 = False
default persistent.cleo3 = False
default persistent.cleo4 = False
default persistent.cleo5 = False
default persistent.cleo6 = False
default persistent.cleo7 = False
default persistent.cleo8 = False
default persistent.cleo9 = False
default persistent.cleo10 = False
default persistent.cleo11 = False
default persistent.cleo12 = False
default persistent.cleo13 = False
default persistent.cleo14 = False
default persistent.cleo15 = False
default persistent.cleo16 = False

default persistent.cleo_list = [
    persistent.cleo1,
    persistent.cleo2,
    persistent.cleo3,
    persistent.cleo4,
    persistent.cleo5,
    persistent.cleo6,
    persistent.cleo7,
    persistent.cleo8,
    persistent.cleo9,
    persistent.cleo10,
    persistent.cleo11,
    persistent.cleo12,
    persistent.cleo13,
    persistent.cleo14,
    persistent.cleo15,
    persistent.cleo16
]

default persistent.cleo_list = []

init python:
    def update_cleo_list():
        persistent.cleo_list = [
            persistent.cleo1,
            persistent.cleo2,
            persistent.cleo3,
            persistent.cleo4,
            persistent.cleo5,
            persistent.cleo6,
            persistent.cleo7,
            persistent.cleo8,
            persistent.cleo9,
            persistent.cleo10,
            persistent.cleo11,
            persistent.cleo12,
            persistent.cleo13,
            persistent.cleo14,
            persistent.cleo15,
            persistent.cleo16
        ]

# Tracy
default persistent.tracy1 = False
default persistent.tracy2 = False
default persistent.tracy3 = False
default persistent.tracy4 = False
default persistent.tracy5 = False
default persistent.tracy6 = False
default persistent.tracy7 = False
default persistent.tracy8 = False
default persistent.tracy9 = False
default persistent.tracy10 = False
default persistent.tracy11 = False
default persistent.tracy12 = False
default persistent.tracy13 = False
default persistent.tracy14 = False
default persistent.tracy15 = False
default persistent.tracy16 = False

default persistent.tracy_list = [
    persistent.tracy1,
    persistent.tracy2,
    persistent.tracy3,
    persistent.tracy4,
    persistent.tracy5,
    persistent.tracy6,
    persistent.tracy7,
    persistent.tracy8,
    persistent.tracy9,
    persistent.tracy10,
    persistent.tracy11,
    persistent.tracy12,
    persistent.tracy13,
    persistent.tracy14,
    persistent.tracy15,
    persistent.tracy16
]

default persistent.tracy_list = []

init python:
    def update_tracy_list():
        persistent.tracy_list = [
            persistent.tracy1,
            persistent.tracy2,
            persistent.tracy3,
            persistent.tracy4,
            persistent.tracy5,
            persistent.tracy6,
            persistent.tracy7,
            persistent.tracy8,
            persistent.tracy9,
            persistent.tracy10,
            persistent.tracy11,
            persistent.tracy12,
            persistent.tracy13,
            persistent.tracy14,
            persistent.tracy15,
            persistent.tracy16
        ]

# Sadie
default persistent.sadie1 = False
default persistent.sadie2 = False
default persistent.sadie3 = False
default persistent.sadie4 = False
default persistent.sadie5 = False
default persistent.sadie6 = False
default persistent.sadie7 = False
default persistent.sadie8 = False
default persistent.sadie9 = False
default persistent.sadie10 = False
default persistent.sadie11 = False
default persistent.sadie12 = False
default persistent.sadie13 = False
default persistent.sadie14 = False
default persistent.sadie15 = False
default persistent.sadie16 = False

default persistent.sadie_list = [
    persistent.sadie1,
    persistent.sadie2,
    persistent.sadie3,
    persistent.sadie4,
    persistent.sadie5,
    persistent.sadie6,
    persistent.sadie7,
    persistent.sadie8,
    persistent.sadie9,
    persistent.sadie10,
    persistent.sadie11,
    persistent.sadie12,
    persistent.sadie13,
    persistent.sadie14,
    persistent.sadie15,
    persistent.sadie16
]

default persistent.sadie_list = []

init python:
    def update_sadie_list():
        persistent.sadie_list = [
            persistent.sadie1,
            persistent.sadie2,
            persistent.sadie3,
            persistent.sadie4,
            persistent.sadie5,
            persistent.sadie6,
            persistent.sadie7,
            persistent.sadie8,
            persistent.sadie9,
            persistent.sadie10,
            persistent.sadie11,
            persistent.sadie12,
            persistent.sadie13,
            persistent.sadie14,
            persistent.sadie15,
            persistent.sadie16
        ]

# Francesca
default persistent.francesca1 = False
default persistent.francesca2 = False
default persistent.francesca3 = False
default persistent.francesca4 = False
default persistent.francesca5 = False
default persistent.francesca6 = False
default persistent.francesca7 = False
default persistent.francesca8 = False
default persistent.francesca9 = False
default persistent.francesca10 = False
default persistent.francesca11 = False
default persistent.francesca12 = False
default persistent.francesca13 = False

default persistent.francesca_list = [
    persistent.francesca1,
    persistent.francesca2,
    persistent.francesca3,
    persistent.francesca4,
    persistent.francesca5,
    persistent.francesca6,
    persistent.francesca7,
    persistent.francesca8,
    persistent.francesca9,
    persistent.francesca10,
    persistent.francesca11,
    persistent.francesca12,
    persistent.francesca13
]

default persistent.francesca_list = []

init python:
    def update_francesca_list():
        persistent.francesca_list = [
            persistent.francesca1,
            persistent.francesca2,
            persistent.francesca3,
            persistent.francesca4,
            persistent.francesca5,
            persistent.francesca6,
            persistent.francesca7,
            persistent.francesca8,
            persistent.francesca9,
            persistent.francesca10,
            persistent.francesca11,
            persistent.francesca12,
            persistent.francesca13
        ]

# Tiffany
default persistent.tiffany1 = False
default persistent.tiffany2 = False
default persistent.tiffany3 = False
default persistent.tiffany4 = False
default persistent.tiffany5 = False
default persistent.tiffany6 = False
default persistent.tiffany7 = False
default persistent.tiffany8 = False
default persistent.tiffany9 = False

default persistent.tiffany_list = [
    persistent.tiffany1,
    persistent.tiffany2,
    persistent.tiffany3,
    persistent.tiffany4,
    persistent.tiffany5,
    persistent.tiffany6,
    persistent.tiffany7,
    persistent.tiffany8,
    persistent.tiffany9
]

default persistent.tiffany_list = []

init python:
    def update_tiffany_list():
        persistent.tiffany_list = [
            persistent.tiffany1,
            persistent.tiffany2,
            persistent.tiffany3,
            persistent.tiffany4,
            persistent.tiffany5,
            persistent.tiffany6,
            persistent.tiffany7,
            persistent.tiffany8,
            persistent.tiffany9
        ]

# Evelyn
default persistent.evelyn1 = False
default persistent.evelyn2 = False
default persistent.evelyn3 = False
default persistent.evelyn4 = False
default persistent.evelyn5 = False
default persistent.evelyn6 = False
default persistent.evelyn7 = False
default persistent.evelyn8 = False

default persistent.evelyn_list = [
    persistent.evelyn1,
    persistent.evelyn2,
    persistent.evelyn3,
    persistent.evelyn4,
    persistent.evelyn5,
    persistent.evelyn6,
    persistent.evelyn7,
    persistent.evelyn8
]

default persistent.evelyn_list = []

init python:
    def update_evelyn_list():
        persistent.evelyn_list = [
            persistent.evelyn1,
            persistent.evelyn2,
            persistent.evelyn3,
            persistent.evelyn4,
            persistent.evelyn5,
            persistent.evelyn6,
            persistent.evelyn7,
            persistent.evelyn8
        ]

# Mixed
default persistent.mixed1 = False
default persistent.mixed2 = False
default persistent.mixed3 = False
default persistent.mixed4 = False
default persistent.mixed5 = False
default persistent.mixed6 = False
default persistent.mixed7 = False
default persistent.mixed8 = False
default persistent.mixed9 = False
default persistent.mixed10 = False
default persistent.mixed11 = False
default persistent.mixed12 = False
default persistent.mixed13 = False
default persistent.mixed14 = False
default persistent.mixed15 = False
default persistent.mixed16 = False
default persistent.mixed17 = False

default persistent.mixed_list = [
    persistent.mixed1,
    persistent.mixed2,
    persistent.mixed3,
    persistent.mixed4,
    persistent.mixed5,
    persistent.mixed6,
    persistent.mixed7,
    persistent.mixed8,
    persistent.mixed9,
    persistent.mixed10,
    persistent.mixed11,
    persistent.mixed12,
    persistent.mixed13,
    persistent.mixed14,
    persistent.mixed15,
    persistent.mixed16,
    persistent.mixed17
]

default persistent.mixed_list = []

init python:
    def update_mixed_list():
        persistent.mixed_list = [
            persistent.mixed1,
            persistent.mixed2,
            persistent.mixed3,
            persistent.mixed4,
            persistent.mixed5,
            persistent.mixed6,
            persistent.mixed7,
            persistent.mixed8,
            persistent.mixed9,
            persistent.mixed10,
            persistent.mixed11,
            persistent.mixed12,
            persistent.mixed13,
            persistent.mixed14,
            persistent.mixed15,
            persistent.mixed16,
            persistent.mixed17
        ]
