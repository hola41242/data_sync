
# Episode 2 Variables ##########################################################

# E2S0
default e2s0_fight = False

# E2S1
default e2s1_cleo_sad = False

# E2F1
default e2f1_alice_note = 0
default persistent.e2f1_daydream = 0

# E2S3
default e2s3_hangout = False

# E2S6
default e2s6_talk = False
default e2s6_sadie_romance = False
default e2s6_sadie_friends = False
default e2s6_sadie_fwb = False

# E2F2
default e2f2_sdtr_interested = False

default e2f2_tiffany_sex = False
default e2f2_tiffany_refuse = False

default e2f2_tracy_sex = False
default e2f2_tracy_refuse = False

default persistent.e2f2_tracy_sex = False

# E2S9
default e2s9_francesca_lie = False

# E2S10
default e2s10_francesca = False
default e2s10_sadie = False
default e2s10_jon = False

# interest = 0 means no interest
# interest = 1 means interested
default e2s10_br_interest = 0
default e2s10_seduce = False
default e2s10_no_money = False
default e2s10_br_number = False

default persistent.e2s10_lap_dance = 0
default e2s10_lap_dance = 0

default e2s10_sadie_sex = False

# E2S12
default e2s12_fight = False
default e2s12_fight_win = False

default e2s12_lie = False

default e2s12_gift = False

default e2s12_cleo_dress = False
