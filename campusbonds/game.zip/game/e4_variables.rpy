
# Episode 4 Variables ##########################################################

# E4S1
default e4s1_joke = False

# E4S2
default e4s2_greet = False

# E4S3
default e4s3_kiss = False

default e4s3_confide = False

# E4S4
default e4s4_hangout = False

# E4S5
default e4s5_pass = False

default e4s5_sadie_mad = False
default e4s5_sadie_path_throw = False
default e4s5_date = False

default e4s5_tracy_mad = False
default e4s5_tracy_path_throw = False

# E4F1
default e4f1_tracy_partner = False
default e4f1_sadie_partner = False
default e4f1_bridget_partner = False
default e4f1_lyla_partner = False

default e4f1_trsd_partners = False

# E4S6
default e4s6_ask = False
default e4s6_scarlett_dance = False

default e4s6_doubt = False

# E4S7
default e4s7_therapy_open = False

# E4S8
default e4s8_alice_practice = False
default e4s8_confess_alice = False

default e4s8_text = False

default e4s8_evelyn_practice = False

# E4S9
default e4s9_memory = False
default e4s9_past = False
default e4s9_stay = False

# E4S10
default e4s10_comfort = False

# E4F2
default e4f2_stripper_offer = False

# E4S11
default e4s11_tell = False
default e4s11_confess = False
default e4s11_reassure = False
default e4s11_help = False

# E4S12
default e4s12_mock = False

# E4S13
default e4s13_cleo_hangout = False

# E4S14
default e4s14_defend = False
default e4s14_stay = False

default e4s14_forgive = False

# E4S15
default e4s15_confide = False

# E4S16
default e4s16_lie = False
default e4s16_try = False

# E4S18
default e4s18_ask_option = 0

default e4s18_sadie_introvert = False
default e4s18_sadie_extrovert = False

# E4S19
default e4s19_qte1 = False
default e4s19_fail = False

# E4S21
default e4s21_answer = False
default e4s21_keep_it = False

default e4s21_use_phone = 0

# E4S22
default e4s22_tiffany_path = False

default e4s22_tiffany_lie = False

# E4S23
default e4s23_tracy_hangout = False
default e4s23_tracy_lewd = False
# change 0 = Believe in change
# change 1 = Unsure
# change 2 = Don't believe in change
default e4s23_tracy_change = 0

default e4s23_stay = False
default e4s23_leave = False

default e4s23_francesca_lie = False
default e4s23_francesca_truth = False
default e4s23_francesca_lewd = 0
default persistent.e4s23_francesca_lewd = 0

# E4S26
default e4s26_darryl_leave = False

# E4S27
default e4s27_listen = False
default e4s27_believe = False

default e4s27_amber_lewd = False
default e4s27_evelyn_excite = False

default e4s27_dom = False
default e4s27_dom2 = False

# E4S28
default e4s28_tell_her = False
default e4s28_defensive = False

# E4S29
default e4s29_sweet = False
default e4s29_olivia_path = False

# E4S31
default e4s31_fail = False

default e4s31_fight = False
default e4s31_fight_outcome = False

# E4S32
default e4s32_option = 0

# E4S33
default e4s33_sadie_place = False
default e4s33_pink_dress = False
default e4s33_lingerie = False

# E4S34
default e4s34_sadie_refuse = False

default persistent.e4s34_sadie_refuse = False
default persistent.e4s34_table_lewd = False

default e4s34_blowjob = False

default e4s34_table_lewd = False
default e4s34_bathroom_lewd = False
