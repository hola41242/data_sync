
default time_start = 0
default time_max = 1.0
default interval = 0.01
default qte_pos_count = 0
default qte_neg_count = 0
default qte_stop = False

default base_damage = 1
default bonus_damage = 0
default total_damage = 0

init python:
    time_start = 0

label qte:
    $ renpy.block_rollback()
    $ qte = False

    $ cont = 0 #continue variable
    $ arr_keys = ["x", "c", "e", "q", "w"] #list of keyboard inputs to be selected from. See https://www.pygame.org/docs/ref/key.html for more keys

    if persistent.fight_difficulty == 0:
        call qte_setup(1.80, 1.7, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup
        # "Function Call" - see label qte_setup for detail on "function"
        # in the above, I randomly select a key from a previously defined set of keys (arr_keys), and randomise the location

        while cont == 1:
            call qte_setup(1.80, 1.7, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup_1
            # to repeat the qte events until it is missed
    if persistent.fight_difficulty == 1:
        call qte_setup(1.10, 1.0, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup
        # "Function Call" - see label qte_setup for detail on "function"
        # in the above, I randomly select a key from a previously defined set of keys (arr_keys), and randomise the location

        while cont == 1:
            call qte_setup(1.10, 1.0, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup_1
            # to repeat the qte events until it is missed
    if persistent.fight_difficulty == 2:
        call qte_setup(0.70, 0.6, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup
        # "Function Call" - see label qte_setup for detail on "function"
        # in the above, I randomly select a key from a previously defined set of keys (arr_keys), and randomise the location

        while cont == 1:
            call qte_setup(0.70, 0.6, 0.01, renpy.random.choice(arr_keys), renpy.random.randint(1, 9) * 0.1, renpy.random.randint(1, 9) * 0.1) from _call_qte_setup_1
            # to repeat the qte events until it is missed

return

transform qte_fade:
    on show:
        anchor (0.5, 0.5)
        zoom 1.0 alpha 0.0
        ease 0.5 alpha 1.0 zoom 0.95
        ease 2.0 zoom 0.85 alpha 0.35
    on hide:
        xanchor 0.5 yanchor 0.5 matrixcolor TintMatrix("#FFA8A7")
        zoom 1.0 alpha 1.0 rotate 0.0

        ease (0.20 if qte_hit else 0.15) zoom (1.15 if qte_hit else 0.85) xanchor (0.5 if qte_hit else 0.35) alpha (0.75 if qte_hit else 0.6) matrixcolor TintMatrix("#00FF21" if qte_hit else "#FF0000") rotate (20.0 if qte_hit else 0)

        linear (0.50 if qte_hit else 0.15) zoom (0.0 if qte_hit else 0.85) xanchor (0.5 if qte_hit else 0.65) alpha (-1.0 if qte_hit else 0.3) matrixcolor TintMatrix("#FFA8A7") rotate (50.0 if qte_hit else 0.0)

        ease 0.15 anchor (0.5, 0.5) alpha 0.0 matrixcolor TintMatrix("#FFA8A7")

transform miss_anim:
    alpha 0.0
    ease 0.25 alpha 0.25
    ease 0.25 alpha 0.0

image miss_screen = im.Scale("images/red_overlay.png", 1920, 1080)

#########################################
#FUNCTION
#########################################
'''
"Function"/pseudo-function
calls the qte screen
parameters are:
    - amount of time given
    - total amount of time (is usually the same as above)
    - timer decreasing interval
    - the key/keyboard input to hit in the quick time event
    - the x alignment of the bar/box
    - the y alignment of the bar/box
'''
label qte_setup(time_start, time_max, interval, trigger_key, x_align, y_align):
    $ qte_hit = False

    if strength <= 6:
        $ bonus_damage = strength // 2
    else:
        $ bonus_damage = (6 // 2) + ((strength - 6) // 4)  # slower gain past 6

    $ total_damage = base_damage + bonus_damage

    $ time_start = time_start
    $ time_max = time_max
    $ interval = interval
    $ trigger_key = trigger_key
    $ x_align = x_align
    $ y_align = y_align

    call screen qte_simple
    # can change to call screen qte_button to switch to button mode

    $ cont = _return
    # 1 if key was hit in time, 0 if key not

    return

label cooldown:
    $ renpy.block_rollback()
    $ qte = True
    $ renpy.hide_screen("qte_simple")
return

init python:
    def handle_number_key(pressed):
        global qte_pos_count, qte_neg_count
        if pressed == store.trigger_key:
            qte_pos_count += 1
            store.qte_hit = True
            renpy.jump("cooldown")
        else:
            qte_neg_count += 1
            store.qte_hit = False

############################################
#SCREEN
############################################
screen qte_simple:

    #key input qte

    timer interval repeat True action If(time_start > 0.0, true=SetVariable('time_start', time_start - interval), false=[Return(0), Hide('qte_simple')])
    # timer, using variables from label qte_setup
    # false is the condition if the timer runs out - and this will be reached if the user doesn't get hit the key on time

    if persistent.fight_input == 1:
        pass
    else:
        for arr_keys in ["x", "c", "e", "q", "w"]:
            key arr_keys action [Function(handle_number_key, arr_keys), SetVariable("time_start", 0)]
    # the "key detector" (ends qte_event by returning 1)

    if persistent.fight_input == 1:
        vbox:
            at qte_fade
            xalign x_align
            yalign y_align
            spacing 25

            imagebutton:
                idle "gui/circle_button_idle.png"
                hover "gui/circle_button_hover.png"
                action [Function(handle_number_key, trigger_key), SetVariable("time_start", 0)]
                ypos 175
                xalign 0.0
                focus_mask True

            bar:
                left_bar "gui/left.png"
                right_bar "gui/right.png"
                xsize 150
                ysize 150
                value time_start
                range time_max
                xalign 0.5
                if time_start < (time_max * 0.25):
                    pass
    else:
        vbox:
            at qte_fade
            xalign x_align
            yalign y_align
            spacing 25
            # vbox arrangement

            bar:
                left_bar "gui/left.png"
                right_bar "gui/right.png"
                xsize 150
                ysize 150
                value time_start
                range time_max
                xalign 0.5
                if time_start < (time_max * 0.25):
                    pass
                    #left_bar "#FF69B4"
                    # this is the part that changes the colour to red if the time reaches less than 25%

            text trigger_key.upper():
                ypos -130
                xalign 0.5
                color "#FF69B4"
                size 50
                outlines [ (3,"#000000",0,0) ]
                # text showing the key to press
