
# Episode 3 Variables ##########################################################

# E3S4
default e3s4_fight = True

# E3S8
default e3s8_tiffany_hangout = False
default e3s8_candance = False

# E3F3
default e3f3_claire_drink = False
default e3f3_tracy_sex = False
default e3f3_scarlett_angry = False

default e3f3_mia_seduce = False
default e3f3_help_mia = False
default e3f3_pickup = 0

# E3S9
default e3s9_tiffany_sex = False

default e3s9_fight = False
default e3s9_intervene = False

# E3S10
default e3s10_cleo_hangout = False

default e3s10_sadie_feet = False

# E3S11
default e3s11_photo = False

default e3s11_phone_left = False
default e3s11_phone_right = False

default e3s11_toy = False

default e3s11_return = False
default e3s11_nothing = False
default e3s11_ask = False

# E3S13
default e3s13_tiffany_hangout = False

# E3F1
default e3f1_option = 0

default e3f1_penny_eva = False
default e3f1_drum = False

# E3S15
default e3s15_truth = False

# E3S19
default e3s19_amber_lewd = False

# E3S21
default e3s21_mad = False

# E3S22
default e3s22_guitar = False

# E3S23
default e3s23_tracy_feelings = False
default e3s23_sadie_feelings = False

# E3S24
default e3s24_cleo_path = False
default e3s24_francesca_lewd = False

# E3S26
default e3s26_candance_lewd = False
default e3s26_anal = False
default persistent.e3s26_anal = False

default e3s26_chocolate = False
default e3s26_vanilla = False

# E3S29
default e3s29_hate = False
