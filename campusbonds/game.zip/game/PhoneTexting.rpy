# NVL characters are used for the phone texting
define n_nvl = Character("Nighten", kind=nvl, image="nighten", callback=Phone_SendSound)
define cl_nvl = Character("Cleo", kind=nvl, callback=Phone_ReceiveSound)
define sd_nvl = Character("Sadie", kind=nvl, callback=Phone_ReceiveSound)
define fr_nvl = Character("Francesca", kind=nvl, callback=Phone_ReceiveSound)
define ke_nvl = Character("Ken", kind=nvl, callback=Phone_ReceiveSound)
define un_nvl = Character("Unknown", kind=nvl, callback=Phone_ReceiveSound)
define tf_nvl = Character("Tiffany", kind=nvl, callback=Phone_ReceiveSound)
define ca_nvl = Character("Candance", kind=nvl, callback=Phone_ReceiveSound)
define jn_nvl = Character("Jon", kind=nvl, callback=Phone_ReceiveSound)
define tr_nvl = Character("Tracy", kind=nvl, callback=Phone_ReceiveSound)
define al_nvl = Character("Alice", kind=nvl, callback=Phone_ReceiveSound)
define sc_nvl = Character("Scarlett", kind=nvl, callback=Phone_ReceiveSound)

define config.adv_nvl_transition = None
define config.nvl_adv_transition = Dissolve(0.3)

# Here's the code for the phone!

define nvl_mode = "phone"  ##Allow the NVL mode to become a phone conversation
define MC_Name = "Nighten" ##The name of the main character, used to place them on the screen
define cleo = "Cleo"
define sadie = "Sadie"
define francesca = "Francesca"
define ken = "Ken"
define Unknown = "Unknown"
define tiffany = "Tiffany"
define candance = "Candance"
define jonathan = "Jon"
define tracy = "Tracy"
define alice = "Alice"
define scarlett = "Scarlett"

init -1 python:
    phone_position_x = 0.2
    phone_position_y = 0.5

    def Phone_ReceiveSound(event, interact=True, **kwargs):
        if event == "show_done":
            renpy.sound.play("audio/ReceiveText.ogg")
    def Phone_SendSound(event, interact=True, **kwargs):
        if event == "show_done":
            renpy.sound.play("audio/SendText.ogg")

transform phone_transform(pXalign=0.5, pYalign=0.5):
    xcenter pXalign
    yalign pYalign

transform phone_appear(pXalign=0.5, pYalign=0.5): #Used only when the dialogue have one element
    xcenter pXalign
    yalign pYalign

    on show:
        yoffset 1080
        easein_back 1.0 yoffset 0


transform message_appear(pDirection):
    alpha 0.0
    xoffset 50 * pDirection
    parallel:
        ease 0.5 alpha 1.0
    parallel:
        easein_back 0.5 xoffset 0

transform message_appear_icon():
    zoom 0.0
    easein_back 0.5 zoom 1.0


transform message_narrator:
    alpha 0.0
    yoffset -50

    parallel:
        ease 0.5 alpha 1.0
    parallel:
        easein_back 0.5 yoffset 0

screen PhoneDialogue(dialogue, items=None):

    style_prefix "phoneFrame"
    frame at phone_transform(phone_position_x, phone_position_y):
        # if len(dialogue) == 1:
            # at phone_appear(phone_position_x, phone_position_y)
        viewport:
            draggable True
            mousewheel True
            # cols 1
            yinitial 1.0
            # scrollbars "vertical"
            vbox:
                null height 20
                use nvl_phonetext(dialogue, items)
                null height 100

                if len(items)>0: #Checks if you used a NVL Menu in the phone dialogue
                    vbox: #Create a vbox and menu items to display the choices
                        text "Choose a response:":
                            at message_appear(1)
                            italic True
                            style "choose_text"
                        for i in items: #For loop goes through the dialogue choices(items)
                            $ message_frame = "phone_choice_frame.png"
                            frame:
                                at message_narrator
                                padding (20,20)

                                background Frame(message_frame, 23,23,23,23)
                                xsize 475
                                ysize 75

                                textbutton i.caption: #And displays those choices as a button
                                    xalign 0.5
                                    yalign 0.5
                                    action i.action #i.action is the action in the menu
                                    style "nvl_button"
style choose_text:
    outlines [ ( 1.25, "#000", 1.5, 1.75) ]

screen nvl_phonetext(dialogue, items):
    style_prefix None

    $ previous_d_who = None
    for id_d, d in enumerate(dialogue):
        if d.who == None: # Narrator
            text d.what:
                    xpos -335
                    ypos 0.0
                    xsize 350
                    text_align 0.5
                    italic True
                    size 28
                    slow_cps False
                    id d.what_id
                    if d.current and len(items)==0:
                        at message_narrator
        else:
            if d.who == MC_Name:
                $ message_frame = "phone_send_frame.png"
            else:
                $ message_frame = "phone_received_frame.png"

            hbox:
                spacing 10
                if d.who == MC_Name:
                    box_reverse True

                #If this is the first message of the character, show an icon
                if previous_d_who != d.who:
                    if d.who == MC_Name:
                        $ message_icon = "phone_send_icon.png"
                    elif d.who == cleo:
                        $ message_icon = "phone_cleo_icon.png"
                    elif d.who == sadie:
                        $ message_icon = "phone_sadie_icon.png"
                    elif d.who == francesca:
                        $ message_icon = "phone_francesca_icon.png"
                    elif d.who == Unknown:
                        $ message_icon = "phone_unknown_icon.png"
                    elif d.who == ken:
                        $ message_icon = "phone_ken_icon.png"
                    elif d.who == tiffany:
                        $ message_icon = "phone_tiffany_icon.png"
                    elif d.who == candance:
                        $ message_icon = "phone_candance_icon.png"
                    elif d.who == jonathan:
                        $ message_icon = "phone_jonathan_icon.png"
                    elif d.who == tracy:
                        $ message_icon = "phone_tracy_icon.png"
                    elif d.who == alice:
                        $ message_icon = "phone_alice_icon.png"
                    elif d.who == scarlett:
                        $ message_icon = "phone_scarlett_icon.png"
                    else:
                        $ message_icon = "phone_received_icon.png"

                    add message_icon:
                        if d.current and len(items)==0:
                            at message_appear_icon()

                else:
                    null width 107

                vbox:
                    yalign 1.0
                    if d.who != MC_Name and previous_d_who != d.who:
                        text d.who:
                            style "choose_text"

                    frame:
                        padding (20,20)


                        background Frame(message_frame, 23,23,23,23)
                        xsize 350

                        if d.what.startswith("image:"):
                            ysize 218
                        else:
                            pass

                        if d.current and len(items)==0:
                            if d.who == MC_Name:
                                at message_appear(1)
                            else:
                                at message_appear(-1)

                        if d.what.startswith("image:"):  # If the message contains an image
                            $ image_path = d.what.replace("image:", "").strip()  # Extract image filename

                            text d.what:
                                id d.what_id

                            imagebutton:
                                idle Transform(image_path, size=(308,173))  # Thumbnail
                                action [SetVariable("persistent.fullscreen_image_path", image_path), Show("fullscreen_image")]
                        else:
                            text d.what:
                                pos (0,0)
                                xsize 350
                                slow_cps False


                                if d.who == MC_Name :
                                    color "#FFF"
                                    text_align 1.0
                                    xpos -580
                                else:
                                    color "#FFF"


                                id d.what_id
        $ previous_d_who = d.who

screen fullscreen_image():
    $ renpy.transition(Dissolve(0.2))
    modal True  # Prevents interactions with other UI elements
    add "#0008"  # Semi-transparent black overlay

    if persistent.fullscreen_image_path:  # Ensure an image is set
        imagebutton:
            idle persistent.fullscreen_image_path
            action Hide("fullscreen_image")
            at truecenter

style phoneFrame is default

style phoneFrame_frame:
    background Transform("phone_underground.png",xalign=0.2,yalign=0.5)
    foreground Transform(xcenter=0.5,yalign=0.5)

    ysize 815
    xsize 495

style phoneFrame_viewport:
    yfill True
    xfill True

    yoffset -20

style phoneFrame_vbox:
    spacing 10
    xfill True
