# Characters

# male
define jn = Character("Jonathan",color="#FFB300")
define jon = Character("Jon",color="#FFB300")
define bmc = Character("MC", who_prefix="{color=[mc_color]}", who_suffix="{/color}")
define jo = Character("Joel", color="#B2BABB")
define ke = Character("Ken", color="#7FB3D5")
define jd = Character("Jordan", color="#3e1c00")
define ro = Character("Roman", color="#ff0000")
define sp = Character("Spencer", color="#00FFFF")
define kv = Character("Kevin", color="#566573")
define nt = Character("Nate", color="#ffffff")
define nath = Character("Nathan", color="#ffffff")
define da = Character("Darryl", color="#562b00")
define bo = Character("Bouncer", color="#FFFFFF")
define ba = Character("Bartender", color="#FFA500")
define no = Character("Noah", color="#ff0000")
define mi = Character("Mike", color="#880808")
define dj = Character("DJ", color="#7F00FF")

define ju = Character("Junior", color="#00FFFF")

# female
define se = Character("Secretary", color="#5a2a2d")
define br = Character("Bridget", color="#8E44AD")
define ar = Character("Arielle", color="#F1948A")
define rv = Character("Raven", color="353535")
define ca = Character("Candance", color="6495ED")
define am = Character("Amber", color="#630330")
define ch = Character("Charlie", color="#AAFF00")
define ci = Character("Claire", color="#D70040")
define mia = Character("Mia", color="#9F2B68")
define el = Character("Ellie", color="#E4D00A")
define hl = Character("Hailey", color="#ADD8E6")
define eva = Character("Eva", color="#191970")
define pe = Character("Penny", color="#CC5500")
define ov = Character("Olivia", color="FFE770")
define al = Character("Alice", color="7FFFFF")
define ly = Character("Lyla", color="#EDC2D0")
define lo = Character("Lola", color="#EDC2D0")
define ru = Character("Ruby", color="#EDC2D0")

define brb = Character("Barbara", color="7FFFFF")

# MCs mom
define aml = Character("Amalia", color="#FA8072")

# Main Girls ###################################################################
define ev = Character("Evelyn", color="#F3CFC6")
define tf = Character("Tiffany", color="371F76")
define cl = Character("Cleo", color="FF8787")
define fr = Character("Francesca", color="C97CC9")
define sc = Character("Scarlett", color="#355E3B")
define sd = Character("Sadie", color="FF0000")
define tr = Character("Tracy", color="FF6A00")

# Neutrals
define unknown = Character("???", color="#FDFEFE")
define ref = Character("Referee", color="#ffffff")
define wa = Character("Waiter", color="#ffffff")

define ge = Character("Gertrude")
define ab = Character("Abel")

# Main Character ##############################################################
default mc = Character('persistent.mcname', dynamic = True, who_prefix="{color=[mc_color]}", who_suffix="{/color}")

default mc_color = '#AA8C8C'
default persistent.mc_color = False

# Variable Checks
label color_check:
    if persistent.mc_color == False:
        if affinity_spectrum >= 1:
            $ mc_color = '#FF3A37'
        if affinity_spectrum == 0:
            $ mc_color = '#AA8C8C'
        if affinity_spectrum <= -1:
            $ mc_color = '#2572C4'
    else:
        $ mc_color = '#AA8C8C'
return

#
label extrovert_affinity_check:
    if affinity_spectrum == 0:
        $ affinity_spectrum += 3
        $ extrovert += 1
        $ previous_affinity = 0
    else:
        $ extrovert += 1
        if affinity_spectrum == -1:
            $ previous_affinity = 1
        if affinity_spectrum < 10 and affinity_spectrum > -10:
            $ affinity_spectrum += 1
return

#
label introvert_affinity_check:
    if affinity_spectrum == 0:
        $ affinity_spectrum -= 3
        $ introvert += 1
        $ previous_affinity = 0
    else:
        $ introvert += 1
        if affinity_spectrum == 1:
            $ previous_affinity = -1
        if affinity_spectrum < 10 and affinity_spectrum > -10:
            $ affinity_spectrum -= 1
return

default previous_affinity = 0
