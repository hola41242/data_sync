
# Episode 5 Variables ##########################################################

# E5S2
default e5s2_movie = False

# E5S3
default e5s3_stay = False

# E5S4
default e5s4_talk = False

# E5S5
default e5s5_kiss = False

# E5S7
default e5s7_text = False

default e5s7_hey = False
default e5s7_ask = False
default e5s7_sorry = False

# E5S8
default e5s8_shelter_cleo = False

# E5F1
default e5f1_bed = False
default e5f1_tracy = False
default e5f1_jordan = False

# E5S9
default e5s9_talk = False

# E5S10
default e5s10_fwb = False
default e5s10_breakup = False

# E5F2
default e5f2_nate_mind = False
default e5f2_cleo_activity = False

default e5f2_scarlett = False
default e5f2_cleo_lewd = False

# E5S13
default e5s13_believe_amber = False

default e5s13_amber_lewd = False

# E5S14
default e5s14_qte = False

# E5S16
default e5s16_tiffany_lewd = False

default e5s16_tiffany_kiss = False

# E5S19
default e5s19_college_rock = False
default e5s19_party_ragers = False

# E5S20
default e5s20_cheerleader_lewd = False

# E5S22
default e5s22_evelyn_lewd = False

# E5S25
default e5s25_college_rock = False
default e5s25_party_ragers = False

default e5s25_talk = False
default e5s25_francesca_lewd = False

# E5F3
default e5f3_stripper_offer = False

default e5f3_roman_prank = False
default e5f3_tracy_choice = False
default e5f3_ruby_choice = False

# E5S26
default e5s26_defend_nate = False
