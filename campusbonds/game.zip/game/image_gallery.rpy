
init python:
    g = Gallery()
    g.transition = dissolve

    # Scarlett #################################################################

    g.button("scarlett_gallery")
    g.image("sc_gallery_1")
    g.condition("persistent.sc_gallery_1_unlocked")
    g.image("sc_gallery_2")
    g.condition("persistent.sc_gallery_2_unlocked")
    g.image("sc_gallery_3")
    g.condition("persistent.sc_gallery_3_unlocked")
    g.image("sc_gallery_4")
    g.condition("persistent.sc_gallery_4_unlocked")
    g.image("sc_gallery_5")
    g.condition("persistent.sc_gallery_5_unlocked")
    g.image("sc_gallery_6")
    g.condition("persistent.sc_gallery_6_unlocked")
    g.image("sc_gallery_7")
    g.condition("persistent.sc_gallery_7_unlocked")
    g.image("sc_gallery_8")
    g.condition("persistent.sc_gallery_8_unlocked")
    g.image("sc_gallery_9")
    g.condition("persistent.sc_gallery_9_unlocked")
    g.image("sc_gallery_10")
    g.condition("persistent.sc_gallery_10_unlocked")
    g.image("sc_gallery_11")
    g.condition("persistent.sc_gallery_11_unlocked")
    g.image("sc_gallery_12")
    g.condition("persistent.sc_gallery_12_unlocked")
    g.image("sc_gallery_13")
    g.condition("persistent.sc_gallery_13_unlocked")
    g.image("sc_gallery_14")
    g.condition("persistent.sc_gallery_14_unlocked")

    g.button("scarlett_gallery_1")
    g.image("sc_gallery_1")
    g.condition("persistent.sc_gallery_1_unlocked")

    g.button("scarlett_gallery_2")
    g.image("sc_gallery_2")
    g.condition("persistent.sc_gallery_2_unlocked")

    g.button("scarlett_gallery_3")
    g.image("sc_gallery_3")
    g.condition("persistent.sc_gallery_3_unlocked")

    g.button("scarlett_gallery_4")
    g.image("sc_gallery_4")
    g.condition("persistent.sc_gallery_4_unlocked")

    g.button("scarlett_gallery_5")
    g.image("sc_gallery_5")
    g.condition("persistent.sc_gallery_5_unlocked")

    g.button("scarlett_gallery_6")
    g.image("sc_gallery_6")
    g.condition("persistent.sc_gallery_6_unlocked")

    g.button("scarlett_gallery_7")
    g.image("sc_gallery_7")
    g.condition("persistent.sc_gallery_7_unlocked")

    g.button("scarlett_gallery_8")
    g.image("sc_gallery_8")
    g.condition("persistent.sc_gallery_8_unlocked")

    g.button("scarlett_gallery_9")
    g.image("sc_gallery_9")
    g.condition("persistent.sc_gallery_9_unlocked")

    g.button("scarlett_gallery_10")
    g.image("sc_gallery_10")
    g.condition("persistent.sc_gallery_10_unlocked")

    g.button("scarlett_gallery_11")
    g.image("sc_gallery_11")
    g.condition("persistent.sc_gallery_11_unlocked")

    g.button("scarlett_gallery_12")
    g.image("sc_gallery_12")
    g.condition("persistent.sc_gallery_12_unlocked")

    g.button("scarlett_gallery_13")
    g.image("sc_gallery_13")
    g.condition("persistent.sc_gallery_13_unlocked")

    g.button("scarlett_gallery_14")
    g.image("sc_gallery_14")
    g.condition("persistent.sc_gallery_14_unlocked")

    # Cleo #####################################################################

    g.button("cleo_gallery")
    g.image("cl_gallery_1")
    g.condition("persistent.cl_gallery_1_unlocked")
    g.image("cl_gallery_2")
    g.condition("persistent.cl_gallery_2_unlocked")
    g.image("cl_gallery_3")
    g.condition("persistent.cl_gallery_3_unlocked")
    g.image("cl_gallery_4")
    g.condition("persistent.cl_gallery_4_unlocked")
    g.image("cl_gallery_5")
    g.condition("persistent.cl_gallery_5_unlocked")
    g.image("cl_gallery_6")
    g.condition("persistent.cl_gallery_6_unlocked")
    g.image("cl_gallery_7")
    g.condition("persistent.cl_gallery_7_unlocked")
    g.image("cl_gallery_8")
    g.condition("persistent.cl_gallery_8_unlocked")
    g.image("cl_gallery_9")
    g.condition("persistent.cl_gallery_9_unlocked")
    g.image("cl_gallery_10")
    g.condition("persistent.cl_gallery_10_unlocked")
    g.image("cl_gallery_11")
    g.condition("persistent.cl_gallery_11_unlocked")
    g.image("cl_gallery_12")
    g.condition("persistent.cl_gallery_12_unlocked")
    g.image("cl_gallery_13")
    g.condition("persistent.cl_gallery_13_unlocked")
    g.image("cl_gallery_14")
    g.condition("persistent.cl_gallery_14_unlocked")
    g.image("cl_gallery_15")
    g.condition("persistent.cl_gallery_15_unlocked")
    g.image("cl_gallery_16")
    g.condition("persistent.cl_gallery_16_unlocked")

    g.button("cleo_gallery_1")
    g.image("cl_gallery_1")
    g.condition("persistent.cl_gallery_1_unlocked")

    g.button("cleo_gallery_2")
    g.image("cl_gallery_2")
    g.condition("persistent.cl_gallery_2_unlocked")

    g.button("cleo_gallery_3")
    g.image("cl_gallery_3")
    g.condition("persistent.cl_gallery_3_unlocked")

    g.button("cleo_gallery_4")
    g.image("cl_gallery_4")
    g.condition("persistent.cl_gallery_4_unlocked")

    g.button("cleo_gallery_5")
    g.image("cl_gallery_5")
    g.condition("persistent.cl_gallery_5_unlocked")

    g.button("cleo_gallery_6")
    g.image("cl_gallery_6")
    g.condition("persistent.cl_gallery_6_unlocked")

    g.button("cleo_gallery_7")
    g.image("cl_gallery_7")
    g.condition("persistent.cl_gallery_7_unlocked")

    g.button("cleo_gallery_8")
    g.image("cl_gallery_8")
    g.condition("persistent.cl_gallery_8_unlocked")

    g.button("cleo_gallery_9")
    g.image("cl_gallery_9")
    g.condition("persistent.cl_gallery_9_unlocked")

    g.button("cleo_gallery_10")
    g.image("cl_gallery_10")
    g.condition("persistent.cl_gallery_10_unlocked")

    g.button("cleo_gallery_11")
    g.image("cl_gallery_11")
    g.condition("persistent.cl_gallery_11_unlocked")

    g.button("cleo_gallery_12")
    g.image("cl_gallery_12")
    g.condition("persistent.cl_gallery_12_unlocked")

    g.button("cleo_gallery_13")
    g.image("cl_gallery_13")
    g.condition("persistent.cl_gallery_13_unlocked")

    g.button("cleo_gallery_14")
    g.image("cl_gallery_14")
    g.condition("persistent.cl_gallery_14_unlocked")

    g.button("cleo_gallery_15")
    g.image("cl_gallery_15")
    g.condition("persistent.cl_gallery_15_unlocked")

    g.button("cleo_gallery_16")
    g.image("cl_gallery_16")
    g.condition("persistent.cl_gallery_16_unlocked")

    # Tracy ####################################################################

    g.button("tracy_gallery")
    g.image("tr_gallery_1")
    g.condition("persistent.tr_gallery_1_unlocked")
    g.image("tr_gallery_2")
    g.condition("persistent.tr_gallery_2_unlocked")
    g.image("tr_gallery_3")
    g.condition("persistent.tr_gallery_3_unlocked")
    g.image("tr_gallery_4")
    g.condition("persistent.tr_gallery_4_unlocked")
    g.image("tr_gallery_5")
    g.condition("persistent.tr_gallery_5_unlocked")
    g.image("tr_gallery_6")
    g.condition("persistent.tr_gallery_6_unlocked")
    g.image("tr_gallery_7")
    g.condition("persistent.tr_gallery_7_unlocked")
    g.image("tr_gallery_8")
    g.condition("persistent.tr_gallery_8_unlocked")
    g.image("tr_gallery_9")
    g.condition("persistent.tr_gallery_9_unlocked")
    g.image("tr_gallery_10")
    g.condition("persistent.tr_gallery_10_unlocked")
    g.image("tr_gallery_11")
    g.condition("persistent.tr_gallery_11_unlocked")
    g.image("tr_gallery_12")
    g.condition("persistent.tr_gallery_12_unlocked")
    g.image("tr_gallery_13")
    g.condition("persistent.tr_gallery_13_unlocked")
    g.image("tr_gallery_14")
    g.condition("persistent.tr_gallery_14_unlocked")
    g.image("tr_gallery_15")
    g.condition("persistent.tr_gallery_15_unlocked")
    g.image("tr_gallery_16")
    g.condition("persistent.tr_gallery_16_unlocked")

    g.button("tracy_gallery_1")
    g.image("tr_gallery_1")
    g.condition("persistent.tr_gallery_1_unlocked")

    g.button("tracy_gallery_2")
    g.image("tr_gallery_2")
    g.condition("persistent.tr_gallery_2_unlocked")

    g.button("tracy_gallery_3")
    g.image("tr_gallery_3")
    g.condition("persistent.tr_gallery_3_unlocked")

    g.button("tracy_gallery_4")
    g.image("tr_gallery_4")
    g.condition("persistent.tr_gallery_4_unlocked")

    g.button("tracy_gallery_5")
    g.image("tr_gallery_5")
    g.condition("persistent.tr_gallery_5_unlocked")

    g.button("tracy_gallery_6")
    g.image("tr_gallery_6")
    g.condition("persistent.tr_gallery_6_unlocked")

    g.button("tracy_gallery_7")
    g.image("tr_gallery_7")
    g.condition("persistent.tr_gallery_7_unlocked")

    g.button("tracy_gallery_8")
    g.image("tr_gallery_8")
    g.condition("persistent.tr_gallery_8_unlocked")

    g.button("tracy_gallery_9")
    g.image("tr_gallery_9")
    g.condition("persistent.tr_gallery_9_unlocked")

    g.button("tracy_gallery_10")
    g.image("tr_gallery_10")
    g.condition("persistent.tr_gallery_10_unlocked")

    g.button("tracy_gallery_11")
    g.image("tr_gallery_11")
    g.condition("persistent.tr_gallery_11_unlocked")

    g.button("tracy_gallery_12")
    g.image("tr_gallery_12")
    g.condition("persistent.tr_gallery_12_unlocked")

    g.button("tracy_gallery_13")
    g.image("tr_gallery_13")
    g.condition("persistent.tr_gallery_13_unlocked")

    g.button("tracy_gallery_14")
    g.image("tr_gallery_14")
    g.condition("persistent.tr_gallery_14_unlocked")

    g.button("tracy_gallery_15")
    g.image("tr_gallery_15")
    g.condition("persistent.tr_gallery_15_unlocked")

    g.button("tracy_gallery_16")
    g.image("tr_gallery_16")
    g.condition("persistent.tr_gallery_16_unlocked")

    # Sadie ####################################################################

    g.button("sadie_gallery")
    g.image("sd_gallery_1")
    g.condition("persistent.sd_gallery_1_unlocked")
    g.image("sd_gallery_2")
    g.condition("persistent.sd_gallery_2_unlocked")
    g.image("sd_gallery_3")
    g.condition("persistent.sd_gallery_3_unlocked")
    g.image("sd_gallery_4")
    g.condition("persistent.sd_gallery_4_unlocked")
    g.image("sd_gallery_5")
    g.condition("persistent.sd_gallery_5_unlocked")
    g.image("sd_gallery_6")
    g.condition("persistent.sd_gallery_6_unlocked")
    g.image("sd_gallery_7")
    g.condition("persistent.sd_gallery_7_unlocked")
    g.image("sd_gallery_8")
    g.condition("persistent.sd_gallery_8_unlocked")
    g.image("sd_gallery_9")
    g.condition("persistent.sd_gallery_9_unlocked")
    g.image("sd_gallery_10")
    g.condition("persistent.sd_gallery_10_unlocked")
    g.image("sd_gallery_11")
    g.condition("persistent.sd_gallery_11_unlocked")
    g.image("sd_gallery_12")
    g.condition("persistent.sd_gallery_12_unlocked")
    g.image("sd_gallery_13")
    g.condition("persistent.sd_gallery_13_unlocked")
    g.image("sd_gallery_14")
    g.condition("persistent.sd_gallery_14_unlocked")
    g.image("sd_gallery_15")
    g.condition("persistent.sd_gallery_15_unlocked")
    g.image("sd_gallery_16")
    g.condition("persistent.sd_gallery_16_unlocked")

    g.button("sadie_gallery_1")
    g.image("sd_gallery_1")
    g.condition("persistent.sd_gallery_1_unlocked")

    g.button("sadie_gallery_2")
    g.image("sd_gallery_2")
    g.condition("persistent.sd_gallery_2_unlocked")

    g.button("sadie_gallery_3")
    g.image("sd_gallery_3")
    g.condition("persistent.sd_gallery_3_unlocked")

    g.button("sadie_gallery_4")
    g.image("sd_gallery_4")
    g.condition("persistent.sd_gallery_4_unlocked")

    g.button("sadie_gallery_5")
    g.image("sd_gallery_5")
    g.condition("persistent.sd_gallery_5_unlocked")

    g.button("sadie_gallery_6")
    g.image("sd_gallery_6")
    g.condition("persistent.sd_gallery_6_unlocked")

    g.button("sadie_gallery_7")
    g.image("sd_gallery_7")
    g.condition("persistent.sd_gallery_7_unlocked")

    g.button("sadie_gallery_8")
    g.image("sd_gallery_8")
    g.condition("persistent.sd_gallery_8_unlocked")

    g.button("sadie_gallery_9")
    g.image("sd_gallery_9")
    g.condition("persistent.sd_gallery_9_unlocked")

    g.button("sadie_gallery_10")
    g.image("sd_gallery_10")
    g.condition("persistent.sd_gallery_10_unlocked")

    g.button("sadie_gallery_11")
    g.image("sd_gallery_11")
    g.condition("persistent.sd_gallery_11_unlocked")

    g.button("sadie_gallery_12")
    g.image("sd_gallery_12")
    g.condition("persistent.sd_gallery_12_unlocked")

    g.button("sadie_gallery_13")
    g.image("sd_gallery_13")
    g.condition("persistent.sd_gallery_13_unlocked")

    g.button("sadie_gallery_14")
    g.image("sd_gallery_14")
    g.condition("persistent.sd_gallery_14_unlocked")

    g.button("sadie_gallery_15")
    g.image("sd_gallery_15")
    g.condition("persistent.sd_gallery_15_unlocked")

    g.button("sadie_gallery_16")
    g.image("sd_gallery_16")
    g.condition("persistent.sd_gallery_16_unlocked")

    # Francesca ################################################################

    g.button("francesca_gallery")
    g.image("fr_gallery_1")
    g.condition("persistent.fr_gallery_1_unlocked")
    g.image("fr_gallery_2")
    g.condition("persistent.fr_gallery_2_unlocked")
    g.image("fr_gallery_3")
    g.condition("persistent.fr_gallery_3_unlocked")
    g.image("fr_gallery_4")
    g.condition("persistent.fr_gallery_4_unlocked")
    g.image("fr_gallery_5")
    g.condition("persistent.fr_gallery_5_unlocked")
    g.image("fr_gallery_6")
    g.condition("persistent.fr_gallery_6_unlocked")
    g.image("fr_gallery_7")
    g.condition("persistent.fr_gallery_7_unlocked")
    g.image("fr_gallery_8")
    g.condition("persistent.fr_gallery_8_unlocked")
    g.image("fr_gallery_9")
    g.condition("persistent.fr_gallery_9_unlocked")
    g.image("fr_gallery_10")
    g.condition("persistent.fr_gallery_10_unlocked")
    g.image("fr_gallery_11")
    g.condition("persistent.fr_gallery_11_unlocked")
    g.image("fr_gallery_12")
    g.condition("persistent.fr_gallery_12_unlocked")
    g.image("fr_gallery_13")
    g.condition("persistent.fr_gallery_13_unlocked")

    g.button("francesca_gallery_1")
    g.image("fr_gallery_1")
    g.condition("persistent.fr_gallery_1_unlocked")

    g.button("francesca_gallery_2")
    g.image("fr_gallery_2")
    g.condition("persistent.fr_gallery_2_unlocked")

    g.button("francesca_gallery_3")
    g.image("fr_gallery_3")
    g.condition("persistent.fr_gallery_3_unlocked")

    g.button("francesca_gallery_4")
    g.image("fr_gallery_4")
    g.condition("persistent.fr_gallery_4_unlocked")

    g.button("francesca_gallery_5")
    g.image("fr_gallery_5")
    g.condition("persistent.fr_gallery_5_unlocked")

    g.button("francesca_gallery_6")
    g.image("fr_gallery_6")
    g.condition("persistent.fr_gallery_6_unlocked")

    g.button("francesca_gallery_7")
    g.image("fr_gallery_7")
    g.condition("persistent.fr_gallery_7_unlocked")

    g.button("francesca_gallery_8")
    g.image("fr_gallery_8")
    g.condition("persistent.fr_gallery_8_unlocked")

    g.button("francesca_gallery_9")
    g.image("fr_gallery_9")
    g.condition("persistent.fr_gallery_9_unlocked")

    g.button("francesca_gallery_10")
    g.image("fr_gallery_10")
    g.condition("persistent.fr_gallery_10_unlocked")

    g.button("francesca_gallery_11")
    g.image("fr_gallery_11")
    g.condition("persistent.fr_gallery_11_unlocked")

    g.button("francesca_gallery_12")
    g.image("fr_gallery_12")
    g.condition("persistent.fr_gallery_12_unlocked")

    g.button("francesca_gallery_13")
    g.image("fr_gallery_13")
    g.condition("persistent.fr_gallery_13_unlocked")

    # Tiffany ###################################################################

    g.button("tiffany_gallery")
    g.image("tf_gallery_1")
    g.condition("persistent.tf_gallery_1_unlocked")
    g.image("tf_gallery_2")
    g.condition("persistent.tf_gallery_2_unlocked")
    g.image("tf_gallery_3")
    g.condition("persistent.tf_gallery_3_unlocked")
    g.image("tf_gallery_4")
    g.condition("persistent.tf_gallery_4_unlocked")
    g.image("tf_gallery_5")
    g.condition("persistent.tf_gallery_5_unlocked")
    g.image("tf_gallery_6")
    g.condition("persistent.tf_gallery_6_unlocked")
    g.image("tf_gallery_7")
    g.condition("persistent.tf_gallery_7_unlocked")
    g.image("tf_gallery_8")
    g.condition("persistent.tf_gallery_8_unlocked")
    g.image("tf_gallery_9")
    g.condition("persistent.tf_gallery_9_unlocked")

    g.button("tiffany_gallery_1")
    g.image("tf_gallery_1")
    g.condition("persistent.tf_gallery_1_unlocked")

    g.button("tiffany_gallery_2")
    g.image("tf_gallery_2")
    g.condition("persistent.tf_gallery_2_unlocked")

    g.button("tiffany_gallery_3")
    g.image("tf_gallery_3")
    g.condition("persistent.tf_gallery_3_unlocked")

    g.button("tiffany_gallery_4")
    g.image("tf_gallery_4")
    g.condition("persistent.tf_gallery_4_unlocked")

    g.button("tiffany_gallery_5")
    g.image("tf_gallery_5")
    g.condition("persistent.tf_gallery_5_unlocked")

    g.button("tiffany_gallery_6")
    g.image("tf_gallery_6")
    g.condition("persistent.tf_gallery_6_unlocked")

    g.button("tiffany_gallery_7")
    g.image("tf_gallery_7")
    g.condition("persistent.tf_gallery_7_unlocked")

    g.button("tiffany_gallery_8")
    g.image("tf_gallery_8")
    g.condition("persistent.tf_gallery_8_unlocked")

    g.button("tiffany_gallery_9")
    g.image("tf_gallery_9")
    g.condition("persistent.tf_gallery_9_unlocked")

    # Evelyn ###################################################################

    g.button("evelyn_gallery")
    g.image("ev_gallery_1")
    g.condition("persistent.ev_gallery_1_unlocked")
    g.image("ev_gallery_2")
    g.condition("persistent.ev_gallery_2_unlocked")
    g.image("ev_gallery_3")
    g.condition("persistent.ev_gallery_3_unlocked")
    g.image("ev_gallery_4")
    g.condition("persistent.ev_gallery_4_unlocked")
    g.image("ev_gallery_5")
    g.condition("persistent.ev_gallery_5_unlocked")
    g.image("ev_gallery_6")
    g.condition("persistent.ev_gallery_6_unlocked")
    g.image("ev_gallery_7")
    g.condition("persistent.ev_gallery_7_unlocked")
    g.image("ev_gallery_8")
    g.condition("persistent.ev_gallery_8_unlocked")

    g.button("evelyn_gallery_1")
    g.image("ev_gallery_1")
    g.condition("persistent.ev_gallery_1_unlocked")

    g.button("evelyn_gallery_2")
    g.image("ev_gallery_2")
    g.condition("persistent.ev_gallery_2_unlocked")

    g.button("evelyn_gallery_3")
    g.image("ev_gallery_3")
    g.condition("persistent.ev_gallery_3_unlocked")

    g.button("evelyn_gallery_4")
    g.image("ev_gallery_4")
    g.condition("persistent.ev_gallery_4_unlocked")

    g.button("evelyn_gallery_5")
    g.image("ev_gallery_5")
    g.condition("persistent.ev_gallery_5_unlocked")

    g.button("evelyn_gallery_6")
    g.image("ev_gallery_6")
    g.condition("persistent.ev_gallery_6_unlocked")

    g.button("evelyn_gallery_7")
    g.image("ev_gallery_7")
    g.condition("persistent.ev_gallery_7_unlocked")

    g.button("evelyn_gallery_8")
    g.image("ev_gallery_8")
    g.condition("persistent.ev_gallery_8_unlocked")

    # Mixed ###################################################################

    g.button("mixed_gallery")
    g.image("mixed_gallery_1")
    g.condition("persistent.mixed_gallery_1_unlocked")
    g.image("mixed_gallery_2")
    g.condition("persistent.mixed_gallery_2_unlocked")
    g.image("mixed_gallery_3")
    g.condition("persistent.mixed_gallery_3_unlocked")
    g.image("mixed_gallery_4")
    g.condition("persistent.mixed_gallery_4_unlocked")
    g.image("mixed_gallery_5")
    g.condition("persistent.mixed_gallery_5_unlocked")
    g.image("mixed_gallery_6")
    g.condition("persistent.mixed_gallery_6_unlocked")
    g.image("mixed_gallery_7")
    g.condition("persistent.mixed_gallery_7_unlocked")
    g.image("mixed_gallery_8")
    g.condition("persistent.mixed_gallery_8_unlocked")
    g.image("mixed_gallery_9")
    g.condition("persistent.mixed_gallery_9_unlocked")
    g.image("mixed_gallery_10")
    g.condition("persistent.mixed_gallery_10_unlocked")
    g.image("mixed_gallery_11")
    g.condition("persistent.mixed_gallery_11_unlocked")
    g.image("mixed_gallery_12")
    g.condition("persistent.mixed_gallery_12_unlocked")
    g.image("mixed_gallery_13")
    g.condition("persistent.mixed_gallery_13_unlocked")
    g.image("mixed_gallery_14")
    g.condition("persistent.mixed_gallery_14_unlocked")
    g.image("mixed_gallery_15")
    g.condition("persistent.mixed_gallery_15_unlocked")
    g.image("mixed_gallery_16")
    g.condition("persistent.mixed_gallery_16_unlocked")
    g.image("mixed_gallery_17")
    g.condition("persistent.mixed_gallery_17_unlocked")

    g.button("mixed_gallery_1")
    g.image("mixed_gallery_1")
    g.condition("persistent.mixed_gallery_1_unlocked")

    g.button("mixed_gallery_2")
    g.image("mixed_gallery_2")
    g.condition("persistent.mixed_gallery_2_unlocked")

    g.button("mixed_gallery_3")
    g.image("mixed_gallery_3")
    g.condition("persistent.mixed_gallery_3_unlocked")

    g.button("mixed_gallery_4")
    g.image("mixed_gallery_4")
    g.condition("persistent.mixed_gallery_4_unlocked")

    g.button("mixed_gallery_5")
    g.image("mixed_gallery_5")
    g.condition("persistent.mixed_gallery_5_unlocked")

    g.button("mixed_gallery_6")
    g.image("mixed_gallery_6")
    g.condition("persistent.mixed_gallery_6_unlocked")

    g.button("mixed_gallery_7")
    g.image("mixed_gallery_7")
    g.condition("persistent.mixed_gallery_7_unlocked")

    g.button("mixed_gallery_8")
    g.image("mixed_gallery_8")
    g.condition("persistent.mixed_gallery_8_unlocked")

    g.button("mixed_gallery_9")
    g.image("mixed_gallery_9")
    g.condition("persistent.mixed_gallery_9_unlocked")

    g.button("mixed_gallery_10")
    g.image("mixed_gallery_10")
    g.condition("persistent.mixed_gallery_10_unlocked")

    g.button("mixed_gallery_11")
    g.image("mixed_gallery_11")
    g.condition("persistent.mixed_gallery_11_unlocked")

    g.button("mixed_gallery_12")
    g.image("mixed_gallery_12")
    g.condition("persistent.mixed_gallery_12_unlocked")

    g.button("mixed_gallery_13")
    g.image("mixed_gallery_13")
    g.condition("persistent.mixed_gallery_13_unlocked")

    g.button("mixed_gallery_14")
    g.image("mixed_gallery_14")
    g.condition("persistent.mixed_gallery_14_unlocked")

    g.button("mixed_gallery_15")
    g.image("mixed_gallery_15")
    g.condition("persistent.mixed_gallery_15_unlocked")

    g.button("mixed_gallery_16")
    g.image("mixed_gallery_16")
    g.condition("persistent.mixed_gallery_16_unlocked")

    g.button("mixed_gallery_17")
    g.image("mixed_gallery_17")
    g.condition("persistent.mixed_gallery_17_unlocked")

    ############################################################################
    # Censored #################################################################
    ############################################################################

    # Scarlett #################################################################

    g.button("scarlett_gallery_3_cen")
    g.image("sc_gallery_3_cen")
    g.condition("persistent.sc_gallery_3_unlocked")

    g.button("scarlett_gallery_6_cen")
    g.image("sc_gallery_6_cen")
    g.condition("persistent.sc_gallery_6_unlocked")

    g.button("scarlett_gallery_7_cen")
    g.image("sc_gallery_7_cen")
    g.condition("persistent.sc_gallery_7_unlocked")

    g.button("scarlett_gallery_8_cen")
    g.image("sc_gallery_8_cen")
    g.condition("persistent.sc_gallery_8_unlocked")

    g.button("scarlett_gallery_11_cen")
    g.image("sc_gallery_11_cen")
    g.condition("persistent.sc_gallery_11_unlocked")

    # Cleo #####################################################################

    g.button("cleo_gallery_8_cen")
    g.image("cl_gallery_8_cen")
    g.condition("persistent.cl_gallery_8_unlocked")

    # Tracy ####################################################################

    g.button("tracy_gallery_2_cen")
    g.image("tr_gallery_2_cen")
    g.condition("persistent.tr_gallery_2_unlocked")

    g.button("tracy_gallery_3_cen")
    g.image("tr_gallery_3_cen")
    g.condition("persistent.tr_gallery_3_unlocked")

    g.button("tracy_gallery_5_cen")
    g.image("tr_gallery_5_cen")
    g.condition("persistent.tr_gallery_5_unlocked")

    g.button("tracy_gallery_6_cen")
    g.image("tr_gallery_6_cen")
    g.condition("persistent.tr_gallery_6_unlocked")

    g.button("tracy_gallery_7_cen")
    g.image("tr_gallery_7_cen")
    g.condition("persistent.tr_gallery_7_unlocked")

    g.button("tracy_gallery_8_cen")
    g.image("tr_gallery_8_cen")
    g.condition("persistent.tr_gallery_8_unlocked")

    g.button("tracy_gallery_10_cen")
    g.image("tr_gallery_10_cen")
    g.condition("persistent.tr_gallery_10_unlocked")

    g.button("tracy_gallery_11_cen")
    g.image("tr_gallery_11_cen")
    g.condition("persistent.tr_gallery_11_unlocked")

    # Sadie ####################################################################

    g.button("sadie_gallery_3_cen")
    g.image("sd_gallery_3_cen")
    g.condition("persistent.sd_gallery_3_unlocked")

    g.button("sadie_gallery_8_cen")
    g.image("sd_gallery_8_cen")
    g.condition("persistent.sd_gallery_8_unlocked")

    g.button("sadie_gallery_9_cen")
    g.image("sd_gallery_9_cen")
    g.condition("persistent.sd_gallery_9_unlocked")

    g.button("sadie_gallery_11_cen")
    g.image("sd_gallery_11_cen")
    g.condition("persistent.sd_gallery_11_unlocked")

    g.button("sadie_gallery_12_cen")
    g.image("sd_gallery_12_cen")
    g.condition("persistent.sd_gallery_12_unlocked")

    # Francesca ################################################################

    g.button("francesca_gallery_6_cen")
    g.image("fr_gallery_6_cen")
    g.condition("persistent.fr_gallery_6_unlocked")

    g.button("francesca_gallery_7_cen")
    g.image("fr_gallery_7_cen")
    g.condition("persistent.fr_gallery_7_unlocked")

    g.button("francesca_gallery_9_cen")
    g.image("fr_gallery_9_cen")
    g.condition("persistent.fr_gallery_9_unlocked")

    g.button("francesca_gallery_10_cen")
    g.image("fr_gallery_10_cen")
    g.condition("persistent.fr_gallery_10_unlocked")

    g.button("francesca_gallery_12_cen")
    g.image("fr_gallery_12_cen")
    g.condition("persistent.fr_gallery_12_unlocked")

    g.button("francesca_gallery_13_cen")
    g.image("fr_gallery_13_cen")
    g.condition("persistent.fr_gallery_13_unlocked")

    # Tiffany ###################################################################

    g.button("tiffany_gallery_4_cen")
    g.image("tf_gallery_4_cen")
    g.condition("persistent.tf_gallery_4_unlocked")

    g.button("tiffany_gallery_8_cen")
    g.image("tf_gallery_8_cen")
    g.condition("persistent.tf_gallery_8_unlocked")

    # Evelyn ###################################################################

    g.button("evelyn_gallery_3_cen")
    g.image("ev_gallery_3_cen")
    g.condition("persistent.ev_gallery_3_unlocked")

    g.button("evelyn_gallery_4_cen")
    g.image("ev_gallery_4_cen")
    g.condition("persistent.ev_gallery_4_unlocked")

    g.button("evelyn_gallery_8_cen")
    g.image("ev_gallery_8_cen")
    g.condition("persistent.ev_gallery_8_unlocked")

    # Mixed ################################################################

    g.button("mixed_gallery_10_cen")
    g.image("mixed_gallery_10_cen")
    g.condition("persistent.mixed_gallery_10_unlocked")

    g.button("mixed_gallery_13_cen")
    g.image("mixed_gallery_13_cen")
    g.condition("persistent.mixed_gallery_13_unlocked")

    g.button("mixed_gallery_14_cen")
    g.image("mixed_gallery_14_cen")
    g.condition("persistent.mixed_gallery_14_unlocked")

    g.button("mixed_gallery_17_cen")
    g.image("mixed_gallery_17_cen")
    g.condition("persistent.mixed_gallery_17_unlocked")

# Scarlett #
default persistent.sc_gallery_1_unlocked = False
default persistent.sc_gallery_2_unlocked = False
default persistent.sc_gallery_3_unlocked = False
default persistent.sc_gallery_4_unlocked = False
default persistent.sc_gallery_5_unlocked = False
default persistent.sc_gallery_6_unlocked = False
default persistent.sc_gallery_7_unlocked = False
default persistent.sc_gallery_8_unlocked = False
default persistent.sc_gallery_9_unlocked = False
default persistent.sc_gallery_10_unlocked = False
default persistent.sc_gallery_11_unlocked = False
default persistent.sc_gallery_12_unlocked = False
default persistent.sc_gallery_13_unlocked = False
default persistent.sc_gallery_14_unlocked = False

# Cleo #
default persistent.cl_gallery_1_unlocked = False
default persistent.cl_gallery_2_unlocked = False
default persistent.cl_gallery_3_unlocked = False
default persistent.cl_gallery_4_unlocked = False
default persistent.cl_gallery_5_unlocked = False
default persistent.cl_gallery_6_unlocked = False
default persistent.cl_gallery_7_unlocked = False
default persistent.cl_gallery_8_unlocked = False
default persistent.cl_gallery_9_unlocked = False
default persistent.cl_gallery_10_unlocked = False
default persistent.cl_gallery_11_unlocked = False
default persistent.cl_gallery_12_unlocked = False
default persistent.cl_gallery_13_unlocked = False
default persistent.cl_gallery_14_unlocked = False
default persistent.cl_gallery_15_unlocked = False
default persistent.cl_gallery_16_unlocked = False

# Tracy #
default persistent.tr_gallery_1_unlocked = False
default persistent.tr_gallery_2_unlocked = False
default persistent.tr_gallery_3_unlocked = False
default persistent.tr_gallery_4_unlocked = False
default persistent.tr_gallery_5_unlocked = False
default persistent.tr_gallery_6_unlocked = False
default persistent.tr_gallery_7_unlocked = False
default persistent.tr_gallery_8_unlocked = False
default persistent.tr_gallery_9_unlocked = False
default persistent.tr_gallery_10_unlocked = False
default persistent.tr_gallery_11_unlocked = False
default persistent.tr_gallery_12_unlocked = False
default persistent.tr_gallery_13_unlocked = False
default persistent.tr_gallery_14_unlocked = False
default persistent.tr_gallery_15_unlocked = False
default persistent.tr_gallery_16_unlocked = False

# Sadie #
default persistent.sd_gallery_1_unlocked = False
default persistent.sd_gallery_2_unlocked = False
default persistent.sd_gallery_3_unlocked = False
default persistent.sd_gallery_4_unlocked = False
default persistent.sd_gallery_5_unlocked = False
default persistent.sd_gallery_6_unlocked = False
default persistent.sd_gallery_7_unlocked = False
default persistent.sd_gallery_8_unlocked = False
default persistent.sd_gallery_9_unlocked = False
default persistent.sd_gallery_10_unlocked = False
default persistent.sd_gallery_11_unlocked = False
default persistent.sd_gallery_12_unlocked = False
default persistent.sd_gallery_13_unlocked = False
default persistent.sd_gallery_14_unlocked = False
default persistent.sd_gallery_15_unlocked = False
default persistent.sd_gallery_16_unlocked = False

# Francesca #
default persistent.fr_gallery_1_unlocked = False
default persistent.fr_gallery_2_unlocked = False
default persistent.fr_gallery_3_unlocked = False
default persistent.fr_gallery_4_unlocked = False
default persistent.fr_gallery_5_unlocked = False
default persistent.fr_gallery_6_unlocked = False
default persistent.fr_gallery_7_unlocked = False
default persistent.fr_gallery_8_unlocked = False
default persistent.fr_gallery_9_unlocked = False
default persistent.fr_gallery_10_unlocked = False
default persistent.fr_gallery_11_unlocked = False
default persistent.fr_gallery_12_unlocked = False
default persistent.fr_gallery_13_unlocked = False

# Tiffany #
default persistent.tf_gallery_1_unlocked = False
default persistent.tf_gallery_2_unlocked = False
default persistent.tf_gallery_3_unlocked = False
default persistent.tf_gallery_4_unlocked = False
default persistent.tf_gallery_5_unlocked = False
default persistent.tf_gallery_6_unlocked = False
default persistent.tf_gallery_7_unlocked = False
default persistent.tf_gallery_8_unlocked = False
default persistent.tf_gallery_9_unlocked = False

# Evelyn #
default persistent.ev_gallery_1_unlocked = False
default persistent.ev_gallery_2_unlocked = False
default persistent.ev_gallery_3_unlocked = False
default persistent.ev_gallery_4_unlocked = False
default persistent.ev_gallery_5_unlocked = False
default persistent.ev_gallery_6_unlocked = False
default persistent.ev_gallery_7_unlocked = False
default persistent.ev_gallery_8_unlocked = False

# Mixed #
default persistent.mixed_gallery_1_unlocked = False
default persistent.mixed_gallery_2_unlocked = False
default persistent.mixed_gallery_3_unlocked = False
default persistent.mixed_gallery_4_unlocked = False
default persistent.mixed_gallery_5_unlocked = False
default persistent.mixed_gallery_6_unlocked = False
default persistent.mixed_gallery_7_unlocked = False
default persistent.mixed_gallery_8_unlocked = False
default persistent.mixed_gallery_9_unlocked = False
default persistent.mixed_gallery_10_unlocked = False
default persistent.mixed_gallery_11_unlocked = False
default persistent.mixed_gallery_12_unlocked = False
default persistent.mixed_gallery_13_unlocked = False
default persistent.mixed_gallery_14_unlocked = False
default persistent.mixed_gallery_15_unlocked = False
default persistent.mixed_gallery_16_unlocked = False
default persistent.mixed_gallery_17_unlocked = False
