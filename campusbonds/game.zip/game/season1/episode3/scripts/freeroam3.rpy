
# Variables
default e3f3_dj = False
default e3f3_tracy = 0
default e3f3_claire = 0
default e3f3_charlie = False
default e3f3_ken_roman = False
default e3f3_scarlett = False
default e3f3_guys = False

default e3f3_explore = 0

# Freeroam Collected Photos #

default persistent.e3f3_collected_p = 0
default persistent.e3f3_collected_tp = 6

# Freeroam 3 ###################################################################
label e3f3:
    define e3f3_tracks = ["party/i_wont_fall_in_love.ogg", "party/galaxies.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/piano.ogg", "party/instrumentals/rock_this_house.ogg", "party/instrumentals/turn_up.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/random_drop.ogg", "party/instrumentals/2010_pop.ogg", "party/instrumentals/encryption.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/dance_tonight.ogg", "party/instrumentals/love_you.ogg"]
    $ renpy.random.shuffle(e3f3_tracks)
    $ renpy.music.queue (e3f3_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")

    scene e3f3-06 with dissolve
    call screen e3f3_bar
    hide e3f3-06
return

# Map ##########################################################################

# Couch ###
label e3f3_couch:
    if e3f3_claire > 0 and e3f3_dj == True and e3f3_tracy > 0 and e3f3_charlie == True and e3f3_ken_roman == True and e3f3_scarlett == True:
        if e3f3_guys == False:
            scene e3f3-01_1
        else:
            scene e3f3-01_2
    else:
        scene e3f3-01
    call screen e3f3_couch with dissolve
return

label e3f3_claire:
    if e3f3_claire == 0:
        scene e3f3-ci_01 with dissolve
        unknown "Hey, who's there?"

        scene e3f3-ci_02 with dissolve
        pause

        scene e3f3-ci_03 with dissolve
        menu:
            "Check her out":
                call extrovert_affinity_check from _call_extrovert_affinity_check_42
                call color_check from _call_color_check_81

                scene e3f3-ci_04 with dissolve
                if affinity_spectrum > 0:
                    mc "*Yum!*"
                else:
                    pass

            "Don't check her out":
                call introvert_affinity_check from _call_introvert_affinity_check_36
                call color_check from _call_color_check_82
                mc "*I better not risk it.*"

        mc "Uh... [mc]?"

        scene e3f3-ci_05 with dissolve
        unknown "[mc] who?"

        scene e3f3-ci_03 with dissolve
        mc "Wait, do I even know you?"

        scene e3f3-ci_06 with dissolve
        unknown "Of course you know me."
        unknown "Who doesn't know me?"

        scene e3f3-ci_07 with dissolve
        unknown "I'm [ci]."

        scene e3f3-ci_03 with dissolve
        mc "Hmm... nope, doesn't ring any bells."

        scene e3f3-ci_05 with dissolve
        ci "Yeah, anyways."

        scene e3f3-ci_08 with dissolve
        ci "Could you be so kind and bring me a drink?"

        scene e3f3-ci_03 with dissolve
        mc "*This girl is wasted, do I really want to give her another drink?*"
        mc "*She might even puke on someone.*"
        $ renpy.show_screen("money_notify_pers")
        menu:
            "Get her another drink {color=#f00}(-$1){/color}" if money > 0:
                $ money -= 1
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")

                mc "*Hah, that would be pretty funny!*"
                mc "Alright, what do you want?"

                scene e3f3-ci_11 with dissolve
                ci "Just some tequila please."

                $ e3f3_explore += 1

                if e3f3_explore == 6:
                    $ current_quests.remove("Interact with people.")
                    $ current_quests.append("Talk to the guys.")

                $ optional_quests.append("Get Claire a tequila shot.")

                $ e3f3_claire = 1

                scene e3f3-ci_03 with dissolve
                mc "Not a problem!"

            "Refuse":
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")

                mc "I... think you've had enough drinks for the night."

                scene e3f3-ci_06 with dissolve
                ci "No I haven't, what are you talking about?"

                scene e3f3-ci_07 with dissolve
                ci "I'm perfectly fine."

                scene e3f3-ci_03 with dissolve
                mc "Then can you walk in a straight line for me?"

                scene e3f3-ci_09 with dissolve
                ci "Of course I can..."

                scene e3f3-ci_10 with dissolve
                ci "It's just that I don't want to."

                scene e3f3-ci_03 with dissolve
                mc "Alright?"
                ci "..."
                mc "[ci]?"

                scene e3f3-ci_05 with dissolve
                ci "Huh? Who's calling me?"

                $ e3f3_explore += 1

                if e3f3_explore == 6:
                    $ current_quests.remove("Interact with people.")
                    $ current_quests.append("Talk to the guys.")

                $ e3f3_claire = 3

                scene e3f3-ci_03 with dissolve
                mc "No one."
                mc "*I'm starting to think she's not only drunk, but high as well.*"

        jump e3f3_couch
    if e3f3_claire == 1:
        scene e3f3-ci_12 with dissolve
        pause

        scene e3f3-ci_13 with dissolve
        mc "Hey!"

        scene e3f3-ci_14 with dissolve
        pause

        scene e3f3-ci_15 with dissolve
        pause

        if e3f3_mia_seduce == True:
            scene e3f3-ci_17 with dissolve
            mia "Are you here to seduce me again?"

            scene e3f3-ci_16 with dissolve
            mc "Haha, no."
            mc "I'd just like a tequila."
        else:
            scene e3f3-ci_19 with dissolve
            mia "Hello, what may I get you?"

            scene e3f3-ci_18 with dissolve
            mc "Just a tequila, please."

        scene e3f3-ci_20 with dissolve
        mia "Alright, coming right up."

        scene e3f3-ci_21 with dissolve
        pause

        scene e3f3-ci_22 with dissolve
        mia "Here's your glass of tequila."

        scene e3f3-ci_23 with dissolve
        mc "Thanks."

        $ optional_quests.remove("Get Claire a tequila shot.")
        $ optional_quests.append("Give Claire the tequila shot.")

        $ e3f3_claire = 2

        scene e3f3-ci_21 with dissolve
        mc "*Now... let's give this to [ci].*"

        jump e3f3_bar
    if e3f3_claire == 2:
        scene e3f3-ci_03 with dissolve
        mc "Hey [ci]!"

        scene e3f3-ci_05 with dissolve
        ci "Huh? Who's calling me?"

        scene e3f3-ci_03 with dissolve
        mc "It's me, your friend, [mc]!"
        mc "I'm back with your drink."

        scene e3f3-ci_25 with dissolve
        ci "Oh... my drink!"

        scene e3f3-ci_24 with dissolve
        mc "Sure, tequila just like you asked."

        scene e3f3-ci_25 with dissolve
        ci "Thank you whatever your name was!"
        ci "I was really thirsty, damn."

        scene e3f3-ci_26 with dissolve
        mc "Don't drink it all in one sip."

        scene e3f3-ci_27 with dissolve
        pause

        scene e3f3-ci_28 with dissolve
        ci "{i}Gulp, gulp{/i}!"

        scene e3f3-ci_29 with vpunch
        pause

        scene e3f3-ci_30 with dissolve
        ci "Oh, fuck!"
        ci "That was so good."

        scene e3f3-ci_31 with dissolve
        pause

        scene e3f3-ci_03 with dissolve
        pause

        $ optional_quests.remove("Give Claire the tequila shot.")

        $ e3f3_claire = 3
        $ e3f3_claire_drink = True

        scene e3f3-ci_02 with dissolve
        mc "*Did I just create a time bomb?*"
        mc "*I certainly hope not, haha!*"

    jump e3f3_couch
return

label e3f3_guys:
    scene e3f3-gu_02 with dissolve
    jon "I'm telling you guys, it has been the shit for me."
    jon "Totally one of the coolest inventions of all time."

    scene e3f3-gu_01 with dissolve
    pause

    scene e3f3-gu_03 with dissolve
    jon "What's up [mc]?"

    scene e3f3-gu_04 with dissolve
    mc "Just wandering around."
    mc "Enjoying the party."

    scene e3f3-gu_05 with dissolve
    jon "That's what I like to hear!"

    scene e3f3-gu_06 with dissolve
    jon "I was just telling the guys how an automatic vacuum cleaner really changed my life."

    scene e3f3-gu_04 with dissolve
    mc "Oh... alright."
    mc "Yeah... really great stuff I guess."
    mc "Real interesting..."

    scene e3f3-gu_02 with dissolve
    jon "Anyways, just found it funny the other day hearing a bunch of students joining some no-name club."
    jon "The party ragers has pretty much no competition."
    jon "We've been at the top of the chain for a very long time."
    jon "While the other groups are struggling to make ends meet."

    play sound phone_buzz
    scene e3f3-gu_07 with dissolve
    pause

    scene e3f3-gu_08 with dissolve
    jd "Hey guys, sorry, I really gotta take this."

    scene e3f3-gu_02 with dissolve
    jon "Don't worry about it."

    scene e3f3-gu_09 with dissolve
    jd "Thanks!"

    scene e3f3-gu_10 with dissolve
    pause

    scene e3f3-gu_11 with dissolve
    ke "So, what are you gonna do after this?"

    scene e3f3-gu_12 with dissolve
    jon "I don't know to be honest."
    jon "Probably just chillax at my place."
    jon "Maybe I'm gonna call someone if I feel like it."

    scene e3f3-gu_13 with dissolve
    ke "Talk about life."

    scene e3f3-gu_14 with dissolve
    mc "*Shit, I've really got to pee.*"

    scene e3f3-gu_15 with dissolve
    mc "I'm gonna take a piss guys, be right back."

    $ current_quests.remove("Talk to the guys.")
    $ current_quests.append("Find the bathroom.")

    $ e3f3_guys = True

    scene e3f3-gu_16 with dissolve
    jon "Alright!"

    jump e3f3_couch
return

# Dj ###
label e3f3_dj:
    scene e3f3-02
    call screen e3f3_dj with dissolve
return

label e3f3_dj_npc:
    scene e3f3-dj_01 with dissolve
    mc "Yo!"

    scene e3f3-dj_03 with dissolve
    unknown "What's up?"

    scene e3f3-dj_02 with dissolve
    mc "Nice tunes tonight."

    scene e3f3-dj_04 with dissolve
    unknown "Thanks!"

    scene e3f3-dj_05 with dissolve
    unknown "I'm a newbie, just learning some basic stuff."

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "I see!"
    mc "I'm [mc]."

    scene e3f3-dj_07 with dissolve
    hide e3f3_dj_dj_blink1
    unknown "I'm [dj]."

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "[dj]?"
    mc "Like that's your actual real name?"

    scene e3f3-dj_05 with dissolve
    hide e3f3_dj_dj_blink1
    dj "Yeah... it's like I was made for this or something."

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "Yeah, I'd say so."
    mc "So... how are you enjoying this place so far?"

    scene e3f3-dj_08 with dissolve
    hide e3f3_dj_dj_blink1
    dj "Honestly, it's pretty chill."

    scene e3f3-dj_05 with dissolve
    dj "I've heard some bad rumors about it but I fail to see the truth in them."

    scene e3f3-dj_09 with dissolve
    dj "Or maybe it's because I'm the DJ, who knows?"

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "What do you mean bad rumors?"

    scene e3f3-dj_03 with dissolve
    hide e3f3_dj_dj_blink1
    dj "Word was spreading that the club is boring and nothing actually happens."

    scene e3f3-dj_05 with dissolve
    dj "I actually wanted to see it for myself because I don't really put my trust in rumors."

    scene e3f3-dj_03 with dissolve
    dj "I know that competition will always try to drag others down."

    scene e3f3-dj_02 with dissolve
    mc "Yeah, you're right in that regard."
    mc "Do you happen to know who was spreading that?"

    scene e3f3-dj_09 with dissolve
    dj "I don't know where it came from."
    dj "Just heard some friends talk about that."
    dj "But people are always talking, right?"

    scene e3f3-dj_02 with dissolve
    mc "Right..."
    mc "Anyways, I'll leave you to it."
    mc "It was nice meeting you, [dj]."

    scene e3f3-dj_07 with dissolve
    dj "Likewise [mc]!"

    scene e3f3-dj_04 with dissolve
    dj "Also, are you some sort of organiser here?"

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "Haha, no, why?"

    scene e3f3-dj_07 with dissolve
    hide e3f3_dj_dj_blink1
    dj "It felt like that from the way you asked me about this place."

    scene e3f3-dj_04 with dissolve
    dj "But good to know that people care about this club!"
    dj "It's definitely not like in the rumors."

    scene e3f3-dj_06 with dissolve
    show e3f3_dj_dj_blink1
    mc "Haha, I see!"
    mc "Alright, have a good one!"

    scene e3f3-dj_04 with dissolve
    hide e3f3_dj_dj_blink1
    dj "You too!"

    $ e3f3_explore += 1

    if e3f3_explore == 6:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Talk to the guys.")

    $ e3f3_dj = True

    scene e3f3-dj_10 with dissolve
    pause

    jump e3f3_dj
return

# Vending ###
label e3f3_vending:
    if e3f3_ken_roman == False:
        if e3f3_tracy == 0 or e3f3_tracy == 2:
            scene e3f3-03
        else:
            scene e3f3-03_1
    else:
        if e3f3_tracy == 0 or e3f3_tracy == 2:
            scene e3f3-03_2
        else:
            scene e3f3-03_3

    call screen e3f3_vending with dissolve
return

label e3f3_tracy:
    if e3f3_tracy == 0:
        scene e3f3-tr_01 with dissolve
        mc "What's up [tr]?"

        scene e3f3-tr_04 with dissolve
        tr "Hi!"

        scene e3f3-tr_03 with dissolve
        tr "Just getting a drink and waiting for [sd] to show up, what about you?"

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Enjoying the party."
        mc "Have you been to the bar yet?"
        mc "I haven't seen you there."

        scene e3f3-tr_04 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "Haha, yeah, because I haven't yet."

        scene e3f3-tr_05 with dissolve
        tr "I'm cutting it back a little."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Why?"

        scene e3f3-tr_03 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "It's personal."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Oh... I understand."
        mc "Do you want to get a drink with me?"
        mc "If that's ok by you?"

        scene e3f3-tr_05 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "Hmm... sure, I guess."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Great, let's go!"

        scene e3f3-tr_06 with dissolve
        hide e3f3_tr_tracy_blink1
        pause

        scene e3f3-tr_07 with wipeleft
        mc "And then I tell him:"
        mc "No, you can't have that!"
        mc "Gotta respect the boundaries."

        scene e3f3-tr_08 with dissolve
        tr "What did he do after that?"

        scene e3f3-tr_07 with dissolve
        mc "He did in fact not respect the boundaries."
        mc "But it was fine because I escorted him out."
        mc "Held a grudge against me for over a year."

        scene e3f3-tr_09 with dissolve
        tr "Damn, talk about dedication!"

        scene e3f3-tr_07 with dissolve
        mc "I would call it addiction, but yeah!"

        if tracy_trust > 3 and affinity_spectrum > 0:
            scene e3f3-tr_10 with dissolve
            tr "Hey, have you ever thought about doing something crazy?"

            scene e3f3-tr_11 with dissolve
            mc "What do you mean?"

            scene e3f3-tr_12 with dissolve
            tr "I don't know."
            tr "Like... maybe skydiving."
            tr "Or ziplining over a volcano."

            scene e3f3-tr_13 with dissolve
            tr "Or maybe just having sex in a classroom?"

            scene e3f3-tr_11 with dissolve
            mc "Haha, what?"

            scene e3f3-tr_14 with dissolve
            tr "Come on... don't tell me you've never given it a thought."

            scene e3f3-tr_11 with dissolve
            menu:
                "Gave a thought":
                    $ tracy_trust += 1
                    mc "I guess I have given it a thought."

                    scene e3f3-tr_10 with dissolve
                    tr "That's my boy!"

                "Didn't give a thought.":
                    mc "Hmm... nope, can't say I have."

                    scene e3f3-tr_12 with dissolve
                    tr "Damn... you're too innocent."

                    scene e3f3-tr_14 with dissolve
                    tr "Or maybe you're just fucking with me, which is equally as bad."

            scene e3f3-tr_11 with dissolve
            mc "So... what's your point?"

            scene e3f3-tr_15 with dissolve
            tr "My point is... to ask you if you wanna get out of here."

            scene e3f3-tr_12 with dissolve
            tr "You know, just to explore the place a bit."

            scene e3f3-tr_13 with dissolve
            tr "Get to know each other."

            scene e3f3-tr_11 with dissolve
            menu:
                "Go with her":
                    call extrovert_affinity_check from _call_extrovert_affinity_check_43
                    call color_check from _call_color_check_83
                    $ e3f3_tracy_sex = True
                    $ tracy_trust += 1
                    $ e3f3_tracy = 2
                    mc "You know, that's not a bad idea at all."
                    mc "I could use a little ‘exploration' of the place."

                    scene e3f3-tr_10 with dissolve
                    tr "Haha, that's the spirit!"
                    tr "Let's go."

                    stop music fadeout 2.0
                    scene e3f3-tr_17 with dissolve
                    pause

                    jump e3f3_tracy_sex

                "Stay at the party":
                    call introvert_affinity_check from _call_introvert_affinity_check_37
                    call color_check from _call_color_check_84
                    $ tracy_trust -= 1
                    mc "Actually, I'm sorry."
                    mc "I'd like to stay at the party for now."
                    mc "I'm not really in the mood."

                    scene e3f3-tr_16 with dissolve
                    tr "Alright, fine."

                    scene e3f3-tr_07 with dissolve
        else:
            scene e3f3-tr_18 with dissolve
            tr "Thanks for the drink [mc]."
            tr "Feels nice to have a friend to talk to."

            scene e3f3-tr_07 with dissolve
            mc "No problem [tr]!"

        mc "I wonder where [sd] is."

        scene e3f3-tr_19 with dissolve
        tr "Yeah, me too."

        scene e3f3-tr_20 with dissolve
        tr "Let me give her a call."

        $ e3f3_tracy = 1

        $ e3f3_explore += 1

        if e3f3_explore == 6:
            $ current_quests.remove("Interact with people.")
            $ current_quests.append("Talk to the guys.")

        scene e3f3-tr_21 with dissolve
        pause

        jump e3f3_bar

    if e3f3_tracy == 2:
        scene e3f3-tr_01 with dissolve
        mc "Hey, I got a question."

        scene e3f3-tr_03 with dissolve
        tr "Yeah, shoot!"

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "How come you didn't tell [sd] about what we did?"

        scene e3f3-tr_05 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "[mc]... come on."

        scene e3f3-tr_03 with dissolve
        tr "I don't kiss and tell."

        scene e3f3-tr_05 with dissolve
        tr "Whoever I'm involved with is whoever I'm involved with."
        tr "I don't go running around at [sd] telling her who I fuck."
        tr "The same way she doesn't do that with me."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "But I thought all you girls talk about is boys when you hang out all the time."

        scene e3f3-tr_04 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "Surprise surprise, not every stereotype is right."

        scene e3f3-tr_05 with dissolve
        tr "We tend to start talking about guys when we have something serious going on with them."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Is that like a friendship rule?"

        scene e3f3-tr_04 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "It's more like from a moral standpoint."

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "I see."

        scene e3f3-tr_04 with dissolve
        hide e3f3_tr_tracy_blink1
        tr "So, shall we get back to the party?"

        $ e3f3_tracy = 3

        $ optional_quests.remove("Ask Tracy about Sadie.")

        scene e3f3-tr_02 with dissolve
        show e3f3_tr_tracy_blink1
        mc "Sure!"

        hide e3f3_tr_tracy_blink1

        jump e3f3_vending
return

label e3f3_tracy_sex:
    scene e3f3-tr_22 with wipeleft
    play music inhale
    pause

    scene e3f3-tr_23 with dissolve
    mc "I gotta say..."

    scene e3f3-tr_24 with dissolve
    mc "These hallways look a bit different during the night."

    scene e3f3-tr_25 with dissolve
    tr "Haha, I know right?"

    scene e3f3-tr_26 with dissolve
    tr "I wonder if there's really any classrooms unlocked at this hour."

    scene e3f3-tr_27 with dissolve
    mc "It would be pretty inconvenient I'm not gonna lie."
    mc "But of course there's always options in case that happens."

    scene e3f3-tr_28 with dissolve
    tr "Haha, I like that!"

    scene e3f3-tr_29 with dissolve
    mc "Here, let's try this door."

    play sound door_open
    scene e3f3-tr_30 with dissolve
    mc "Bingo!"

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e3f3-tr_31 with dissolve
        pause

        scene e3f3-tr_32 with dissolve
        tr "Do you think we'll get caught?"

        if persistent.disable_nsfw == True:
            scene e3f3-tr_33 with dissolve
            mc "I kind of hope we don't."

            scene e3f3-tr_34 with dissolve
            mc "What? Are you in for some risky sex?"

            scene e3f3-tr_35 with dissolve
            tr "Risky? Maybe."
            tr "Getting caught? Of course not."
            tr "I'd not risk my scholarship for anything in this world."

            scene e3f3-tr_36 with dissolve
            tr "It's all I have left after all."

            scene e3f3-tr_37 with dissolve
            mc "Fair enough I guess."

            scene e3f3-tr_38 with dissolve
            pause

            scene e3f3-tr_42 with dissolve
            pause

            scene e3f3-tr_39 with dissolve
            pause

            scene e3f3-tr_40 with dissolve
            pause

            scene e3f3-tr_41 with dissolve
            pause

            scene e3f3-tr_43 with dissolve
            mc "You know, I've actually eyeballed your tits the entire night."

            scene e3f3-tr_44 with dissolve
            tr "Really now?"

            scene e3f3-tr_45 with dissolve
            tr "Who would have thought..."

            scene e3f3-tr_46 with dissolve
            pause

            # Missionary
            scene e3f3-tr_48 with dissolve
            tr "Here, let me help you."

            scene e3f3-tr_47 with dissolve
            pause

            scene e3f3-missionary1 with dissolve
            tr "Oh my God..."

            scene e3f3-tr_49 with dissolve
            tr "I always tend to forget how big you are."

            scene e3f3-missionary2 with dissolve
            tr "Fuck!"

            scene e3f3-tr_50 with dissolve
            mc "I always underestimate how fucking tight you are, damn."

            scene e3f3-tr_51 with dissolve
            mc "It's like your pussy is sucking me right in."

            scene e3f3-missionary2 with dissolve
            tr "Ah... fuck!"
            tr "Take me [mc]."

            scene e3f3-missionary1 with dissolve
            pause

            scene e3f3-missionary3 with dissolve
            tr "Fuck...!"
            tr "Yeah, like that [mc]!"

            scene e3f3-missionary1 with dissolve
            pause

            scene e3f3-missionary2 with dissolve
            pause

            scene e3f3-missionary3 with dissolve
            pause

            scene e3f3-tr_51 with dissolve
            mc "Your tits are way hotter out of that dress."

            scene e3f3-tr_48 with dissolve
            tr "How about you show me what you mean by that?"

            # Faceoff
            scene e3f3-faceoff1 with dissolve
            tr "Oh... yeah [mc]!"
            tr "Stick it in me."

            scene e3f3-faceoff2 with dissolve
            tr "Ah... your face looks so hot buried deep between my tits."

            scene e3f3-faceoff3 with dissolve
            pause

            scene e3f3-faceoff4 with dissolve
            pause

            scene e3f3-tr_52 with dissolve
            tr "Yeah [mc], keep sucking on them!"
            tr "Fuck... that feels so good!"

            scene e3f3-tr_53 with dissolve
            mc "Ah... I love your tits [tr]."
            mc "They're so big and soft."
            mc "It's like I'm eating a cloud."
            mc "You're so hot [tr]."

            scene e3f3-faceoff5 with dissolve
            tr "Fuck me [mc]!"

            scene e3f3-faceoff6 with dissolve
            pause

            scene e3f3-faceoff1 with dissolve
            pause

            scene e3f3-faceoff2 with dissolve
            tr "Oh my God... yeah!"

            scene e3f3-faceoff3 with dissolve
            pause

            scene e3f3-faceoff4 with dissolve
            pause

            scene e3f3-faceoff5 with dissolve
            pause

            scene e3f3-faceoff6 with dissolve
            tr "Ah... [mc]...!"

            # Doggy
            scene e3f3-doggy1 with dissolve
            pause

            scene e3f3-doggy2 with dissolve
            tr "Holy shit..."

            scene e3f3-tr_54 with dissolve
            tr "You always go so deep in this position."

            scene e3f3-tr_55 with dissolve
            tr "You're tearing my insides apart."

            scene e3f3-doggy2 with dissolve
            mc "Tell your pussy to stop sucking me in then."
            mc "It's so warm and tight."
            tr "Fuck... go faster [mc]."
            mc "Your wish is my command."

            scene e3f3-doggy3 with dissolve
            tr "Ah... holy shit!"
            tr "Fuck [mc]... I'm not gonna walk straight after this."

            scene e3f3-doggy4 with dissolve
            mc "It's always nice hearing your work is appreciated."

            scene e3f3-doggy5 with dissolve
            tr "Oh my God... I love that dick so much."

            scene e3f3-doggy1 with dissolve
            pause

            scene e3f3-doggy2 with dissolve
            tr "Fuck..."

            scene e3f3-doggy3 with dissolve
            pause

            scene e3f3-doggy4 with dissolve
            pause

            scene e3f3-doggy5 with dissolve
            pause
            tr "Let me know when you want to cum alright?"
            mc "Sure [tr]."
        else:
            if persistent.type_nsfw == False:
                scene e3f3-tr_33_cen with dissolve
                mc "I kind of hope we don't."

                scene e3f3-tr_34_cen with dissolve
                mc "What? Are you in for some risky sex?"

                scene e3f3-tr_35_cen with dissolve
                tr "Risky? Maybe."
                tr "Getting caught? Of course not."
                tr "I'd not risk my scholarship for anything in this world."

                scene e3f3-tr_36_cen with dissolve
                tr "It's all I have left after all."

                scene e3f3-tr_37_cen with dissolve
                mc "Fair enough I guess."

                scene e3f3-tr_38_cen with dissolve
                pause

                scene e3f3-tr_42 with dissolve
                pause

                scene e3f3-tr_39 with dissolve
                pause

                scene e3f3-tr_40 with dissolve
                pause

                scene e3f3-tr_41_cen with dissolve
                pause

                scene e3f3-tr_43 with dissolve
                mc "You know, I've actually eyeballed your tits the entire night."

                scene e3f3-tr_44_cen with dissolve
                tr "Really now?"

                scene e3f3-tr_45 with dissolve
                tr "Who would have thought..."

                scene e3f3-tr_46_cen with dissolve
                pause

                # Missionary
                scene e3f3-tr_48_cen with dissolve
                tr "Here, let me help you."

                scene e3f3-tr_47_cen with dissolve
                pause

                scene e3f3-missionary1_cen with dissolve
                tr "Oh my God..."

                scene e3f3-tr_49_cen with dissolve
                tr "I always tend to forget how big you are."

                scene e3f3-missionary2_cen with dissolve
                tr "Fuck!"

                scene e3f3-tr_50_cen with dissolve
                mc "I always underestimate how fucking tight you are, damn."

                scene e3f3-tr_51_cen with dissolve
                mc "It's like your pussy is sucking me right in."

                scene e3f3-missionary2_cen with dissolve
                tr "Ah... fuck!"
                tr "Take me [mc]."

                scene e3f3-missionary1_cen with dissolve
                pause

                scene e3f3-missionary3_cen with dissolve
                tr "Fuck...!"
                tr "Yeah, like that [mc]!"

                scene e3f3-missionary1_cen with dissolve
                pause

                scene e3f3-missionary2_cen with dissolve
                pause

                scene e3f3-missionary3_cen with dissolve
                pause

                scene e3f3-tr_51_cen with dissolve
                mc "Your tits are way hotter out of that dress."

                scene e3f3-tr_48_cen with dissolve
                tr "How about you show me what you mean by that?"

                # Faceoff
                scene e3f3-faceoff1_cen with dissolve
                tr "Oh... yeah [mc]!"
                tr "Stick it in me."

                scene e3f3-faceoff2_cen with dissolve
                tr "Ah... your face looks so hot buried deep between my tits."

                scene e3f3-faceoff3_cen with dissolve
                pause

                scene e3f3-faceoff4_cen with dissolve
                pause

                scene e3f3-tr_52_cen with dissolve
                tr "Yeah [mc], keep sucking on them!"
                tr "Fuck... that feels so good!"

                scene e3f3-tr_53_cen with dissolve
                mc "Ah... I love your tits [tr]."
                mc "They're so big and soft."
                mc "It's like I'm eating a cloud."
                mc "You're so hot [tr]."

                scene e3f3-faceoff5_cen with dissolve
                tr "Fuck me [mc]!"

                scene e3f3-faceoff6_cen with dissolve
                pause

                scene e3f3-faceoff1_cen with dissolve
                pause

                scene e3f3-faceoff2_cen with dissolve
                tr "Oh my God... yeah!"

                scene e3f3-faceoff3_cen with dissolve
                pause

                scene e3f3-faceoff4_cen with dissolve
                pause

                scene e3f3-faceoff5_cen with dissolve
                pause

                scene e3f3-faceoff6_cen with dissolve
                tr "Ah... [mc]...!"

                # Doggy
                scene e3f3-doggy1_cen with dissolve
                pause

                scene e3f3-doggy2_cen with dissolve
                tr "Holy shit..."

                scene e3f3-tr_54_cen with dissolve
                tr "You always go so deep in this position."

                scene e3f3-tr_55_cen with dissolve
                tr "You're tearing my insides apart."

                scene e3f3-doggy2_cen with dissolve
                mc "Tell your pussy to stop sucking me in then."
                mc "It's so warm and tight."
                tr "Fuck... go faster [mc]."
                mc "Your wish is my command."

                scene e3f3-doggy3_cen with dissolve
                tr "Ah... holy shit!"
                tr "Fuck [mc]... I'm not gonna walk straight after this."

                scene e3f3-doggy4_cen with dissolve
                mc "It's always nice hearing your work is appreciated."

                scene e3f3-doggy5_cen with dissolve
                tr "Oh my God... I love that dick so much."

                scene e3f3-doggy1_cen with dissolve
                pause

                scene e3f3-doggy2_cen with dissolve
                tr "Fuck..."

                scene e3f3-doggy3_cen with dissolve
                pause

                scene e3f3-doggy4_cen with dissolve
                pause

                scene e3f3-doggy5_cen with dissolve
                pause
                tr "Let me know when you want to cum alright?"
                mc "Sure [tr]."

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Missionary":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3f3-missionary1 with dissolve
                        tr "Oh my God..."

                        scene e3f3-tr_49 with dissolve
                        tr "I always tend to forget how big you are."

                        scene e3f3-missionary2 with dissolve
                        tr "Fuck!"

                        scene e3f3-tr_50 with dissolve
                        mc "I always underestimate how fucking tight you are, damn."

                        scene e3f3-tr_51 with dissolve
                        mc "It's like your pussy is sucking me right in."

                        scene e3f3-missionary2 with dissolve
                        tr "Ah... fuck!"
                        tr "Take me [mc]."

                        scene e3f3-missionary1 with dissolve
                        pause

                        scene e3f3-missionary3 with dissolve
                        tr "Fuck...!"
                        tr "Yeah, like that [mc]!"

                        scene e3f3-missionary1 with dissolve
                        pause

                        scene e3f3-missionary2 with dissolve
                        pause

                        scene e3f3-missionary3 with dissolve
                        pause

                        scene e3f3-tr_51 with dissolve
                        mc "Your tits are way hotter out of that dress."

                        scene e3f3-missionary1 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3f3-missionary1_cen with dissolve
                            tr "Oh my God..."

                            scene e3f3-tr_49_cen with dissolve
                            tr "I always tend to forget how big you are."

                            scene e3f3-missionary2_cen with dissolve
                            tr "Fuck!"

                            scene e3f3-tr_50_cen with dissolve
                            mc "I always underestimate how fucking tight you are, damn."

                            scene e3f3-tr_51_cen with dissolve
                            mc "It's like your pussy is sucking me right in."

                            scene e3f3-missionary2_cen with dissolve
                            tr "Ah... fuck!"
                            tr "Take me [mc]."

                            scene e3f3-missionary1_cen with dissolve
                            pause

                            scene e3f3-missionary3_cen with dissolve
                            tr "Fuck...!"
                            tr "Yeah, like that [mc]!"

                            scene e3f3-missionary1_cen with dissolve
                            pause

                            scene e3f3-missionary2_cen with dissolve
                            pause

                            scene e3f3-missionary3_cen with dissolve
                            pause

                            scene e3f3-tr_51_cen with dissolve
                            mc "Your tits are way hotter out of that dress."

                            scene e3f3-missionary1_cen with dissolve
                            pause
                "Faceoff":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3f3-faceoff1 with dissolve
                        tr "Oh... yeah [mc]!"
                        tr "Stick it in me."

                        scene e3f3-faceoff2 with dissolve
                        tr "Ah... your face looks so hot buried deep between my tits."

                        scene e3f3-faceoff3 with dissolve
                        pause

                        scene e3f3-faceoff4 with dissolve
                        pause

                        scene e3f3-tr_52 with dissolve
                        tr "Yeah [mc], keep sucking on them!"
                        tr "Fuck... that feels so good!"

                        scene e3f3-tr_53 with dissolve
                        mc "Ah... I love your tits [tr]."
                        mc "They're so big and soft."
                        mc "It's like I'm eating a cloud."
                        mc "You're so hot [tr]."

                        scene e3f3-faceoff5 with dissolve
                        tr "Fuck me [mc]!"

                        scene e3f3-faceoff6 with dissolve
                        pause

                        scene e3f3-faceoff1 with dissolve
                        pause

                        scene e3f3-faceoff2 with dissolve
                        tr "Oh my God... yeah!"

                        scene e3f3-faceoff3 with dissolve
                        pause

                        scene e3f3-faceoff4 with dissolve
                        pause

                        scene e3f3-faceoff5 with dissolve
                        pause

                        scene e3f3-faceoff6 with dissolve
                        tr "Ah... [mc]...!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e3f3-faceoff1_cen with dissolve
                            tr "Oh... yeah [mc]!"
                            tr "Stick it in me."

                            scene e3f3-faceoff2_cen with dissolve
                            tr "Ah... your face looks so hot buried deep between my tits."

                            scene e3f3-faceoff3_cen with dissolve
                            pause

                            scene e3f3-faceoff4_cen with dissolve
                            pause

                            scene e3f3-tr_52_cen with dissolve
                            tr "Yeah [mc], keep sucking on them!"
                            tr "Fuck... that feels so good!"

                            scene e3f3-tr_53_cen with dissolve
                            mc "Ah... I love your tits [tr]."
                            mc "They're so big and soft."
                            mc "It's like I'm eating a cloud."
                            mc "You're so hot [tr]."

                            scene e3f3-faceoff5_cen with dissolve
                            tr "Fuck me [mc]!"

                            scene e3f3-faceoff6_cen with dissolve
                            pause

                            scene e3f3-faceoff1_cen with dissolve
                            pause

                            scene e3f3-faceoff2_cen with dissolve
                            tr "Oh my God... yeah!"

                            scene e3f3-faceoff3_cen with dissolve
                            pause

                            scene e3f3-faceoff4_cen with dissolve
                            pause

                            scene e3f3-faceoff5_cen with dissolve
                            pause

                            scene e3f3-faceoff6_cen with dissolve
                            tr "Ah... [mc]...!"
                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3f3-doggy1 with dissolve
                        pause

                        scene e3f3-doggy2 with dissolve
                        tr "Holy shit..."

                        scene e3f3-tr_54 with dissolve
                        tr "You always go so deep in this position."

                        scene e3f3-tr_55 with dissolve
                        tr "You're tearing my insides apart."

                        scene e3f3-doggy2 with dissolve
                        mc "Tell your pussy to stop sucking me in then."
                        mc "It's so warm and tight."
                        tr "Fuck... go faster [mc]."
                        mc "Your wish is my command."

                        scene e3f3-doggy3 with dissolve
                        tr "Ah... holy shit!"
                        tr "Fuck [mc]... I'm not gonna walk straight after this."

                        scene e3f3-doggy4 with dissolve
                        mc "It's always nice hearing your work is appreciated."

                        scene e3f3-doggy5 with dissolve
                        tr "Oh my God... I love that dick so much."

                        scene e3f3-doggy1 with dissolve
                        pause

                        scene e3f3-doggy2 with dissolve
                        tr "Fuck..."

                        scene e3f3-doggy3 with dissolve
                        pause

                        scene e3f3-doggy4 with dissolve
                        pause

                        scene e3f3-doggy5 with dissolve
                        pause
                        tr "Let me know when you want to cum alright?"
                        mc "Sure [tr]."
                    else:
                        if persistent.type_nsfw == False:
                            scene e3f3-doggy1_cen with dissolve
                            pause

                            scene e3f3-doggy2_cen with dissolve
                            tr "Holy shit..."

                            scene e3f3-tr_54_cen with dissolve
                            tr "You always go so deep in this position."

                            scene e3f3-tr_55_cen with dissolve
                            tr "You're tearing my insides apart."

                            scene e3f3-doggy2_cen with dissolve
                            mc "Tell your pussy to stop sucking me in then."
                            mc "It's so warm and tight."
                            tr "Fuck... go faster [mc]."
                            mc "Your wish is my command."

                            scene e3f3-doggy3_cen with dissolve
                            tr "Ah... holy shit!"
                            tr "Fuck [mc]... I'm not gonna walk straight after this."

                            scene e3f3-doggy4_cen with dissolve
                            mc "It's always nice hearing your work is appreciated."

                            scene e3f3-doggy5_cen with dissolve
                            tr "Oh my God... I love that dick so much."

                            scene e3f3-doggy1_cen with dissolve
                            pause

                            scene e3f3-doggy2_cen with dissolve
                            tr "Fuck..."

                            scene e3f3-doggy3_cen with dissolve
                            pause

                            scene e3f3-doggy4_cen with dissolve
                            pause

                            scene e3f3-doggy5_cen with dissolve
                            pause
                            tr "Let me know when you want to cum alright?"
                            mc "Sure [tr]."
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        mc "[tr], I'm about to cum."
                        tr "Get down."

                        scene e3f3-handjob1 with dissolve
                        mc "Ah... fuck!"

                        scene e3f3-handjob2 with dissolve
                        mc "You look so hot down there [tr]."

                        scene e3f3-handjob3 with dissolve
                        mc "I'm gonna bust on your face."
                        tr "Aghfhhh..."

                        scene e3f3-handjob2 with dissolve
                        mc "What was that?"

                        scene e3f3-tr_56 with dissolve
                        tr "Do it [mc]!"
                        tr "Cum in my mouth."

                        scene e3f3-handjob1 with dissolve
                        mc "Fuck... I'm cumming!"

                        scene e3f3-tr_57 with dissolve
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e3f3-tr_58 with dissolve
                        mc "Oh shit [tr], you drained me completely."
                        mc "Fuck... I'm so wasted."

                        scene e3f3-tr_59 with dissolve
                        tr "Holy fuck dude, how long have you been saving that one?"
                        tr "Where does it even store?"

                        scene e3f3-tr_58 with dissolve
                        mc "In my balls, or so I've heard."

                        scene e3f3-tr_60 with dissolve
                        pause(0.25)

                        scene e3f3-tr_61
                        pause(0.25)

                        scene e3f3-tr_60 with dissolve
                        pause(0.25)

                        scene e3f3-tr_61
                        pause(0.25)

                        scene e3f3-tr_60 with dissolve
                        pause(0.25)

                        scene e3f3-tr_61
                        pause(0.25)

                        scene e3f3-tr_60 with dissolve
                        pause(0.25)

                        mc "Oh... fuck!"
                        mc "Clean me up [tr]."

                        scene e3f3-tr_62 with dissolve
                        tr "Don't cum a second time dude!"
                        tr "I'm not even sure there will be any place left for it to go."

                        scene e3f3-tr_63 with dissolve
                        mc "Don't worry, you've drained me completely."
                        mc "Even if I wanted to, there probably wouldn't be any left."

                        scene e3f3-tr_64 with dissolve
                        pause

                        scene e3f3-tr_65 with dissolve
                        mc "Here, let me help you clean up."

                        scene e3f3-tr_66 with dissolve
                        tr "Don't worry, I got it."

                        scene e3f3-tr_67 with dissolve
                        mc "No, seriously, I've got some tissues."

                        scene e3f3-tr_68 with dissolve
                        tr "I've said I got it."

                        scene e3f3-tr_69 with dissolve
                        mc "Okay, okay."

                        scene e3f3-tr_70 with dissolve
                        tr "Shall we return to the party?"

                        scene e3f3-tr_69 with dissolve
                        mc "Sure."

                        stop music fadeout 2.0
                        scene e3f3-tr_71 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            mc "[tr], I'm about to cum."
                            tr "Get down."

                            scene e3f3-handjob1_cen with dissolve
                            mc "Ah... fuck!"

                            scene e3f3-handjob2_cen with dissolve
                            mc "You look so hot down there [tr]."

                            scene e3f3-handjob3_cen with dissolve
                            mc "I'm gonna bust on your face."
                            tr "Aghfhhh..."

                            scene e3f3-handjob2_cen with dissolve
                            mc "What was that?"

                            scene e3f3-tr_56_cen with dissolve
                            tr "Do it [mc]!"
                            tr "Cum in my mouth."

                            scene e3f3-handjob1_cen with dissolve
                            mc "Fuck... I'm cumming!"

                            scene e3f3-tr_57_cen with dissolve
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3f3-tr_58_cen with dissolve
                            mc "Oh shit [tr], you drained me completely."
                            mc "Fuck... I'm so wasted."

                            scene e3f3-tr_59_cen with dissolve
                            tr "Holy fuck dude, how long have you been saving that one?"
                            tr "Where does it even store?"

                            scene e3f3-tr_58_cen with dissolve
                            mc "In my balls, or so I've heard."

                            scene e3f3-tr_60_cen with dissolve
                            pause(0.25)

                            scene e3f3-tr_61_cen
                            pause(0.25)

                            scene e3f3-tr_60_cen with dissolve
                            pause(0.25)

                            scene e3f3-tr_61_cen
                            pause(0.25)

                            scene e3f3-tr_60_cen with dissolve
                            pause(0.25)

                            scene e3f3-tr_61_cen
                            pause(0.25)

                            scene e3f3-tr_60_cen with dissolve
                            pause(0.25)

                            mc "Oh... fuck!"
                            mc "Clean me up [tr]."

                            scene e3f3-tr_62_cen with dissolve
                            tr "Don't cum a second time dude!"
                            tr "I'm not even sure there will be any place left for it to go."

                            scene e3f3-tr_63_cen with dissolve
                            mc "Don't worry, you've drained me completely."
                            mc "Even if I wanted to, there probably wouldn't be any left."

                            scene e3f3-tr_64_cen with dissolve
                            pause

                            scene e3f3-tr_65_cen with dissolve
                            mc "Here, let me help you clean up."

                            scene e3f3-tr_66_cen with dissolve
                            tr "Don't worry, I got it."

                            scene e3f3-tr_67_cen with dissolve
                            mc "No, seriously, I've got some tissues."

                            scene e3f3-tr_68_cen with dissolve
                            tr "I've said I got it."

                            scene e3f3-tr_69 with dissolve
                            mc "Okay, okay."

                            scene e3f3-tr_70_cen with dissolve
                            tr "Shall we return to the party?"

                            scene e3f3-tr_69 with dissolve
                            mc "Sure."

                            stop music fadeout 2.0
                            scene e3f3-tr_71_cen with dissolve
                            pause

                    $ GameRunning = False

    $ renpy.end_replay()

    scene e3f3-tr_73 with dissolve
    $ renpy.random.shuffle(e3f3_tracks)
    $ renpy.music.queue (e3f3_tracks, loop=True)
    pause

    scene e3f3-tr_72 with dissolve
    mc "Oh, hi [sd]!"

    scene e3f3-tr_74 with dissolve
    tr "[sd]!"
    tr "You finally got here."

    if e2s6_sadie_romance == True:
        scene e3f3-tr_76 with dissolve
        sd "Hey guys."

        scene e3f3-tr_77 with dissolve
        sd "Where... were you?"

        scene e3f3-tr_75 with dissolve
        mc "Oh, well..."

        scene e3f3-tr_78 with dissolve
        tr "I went outside to get some air and met [mc] along the way."
        tr "He just came here."
    else:
        scene e3f3-tr_76 with dissolve
        sd "Hi guys!"

        scene e3f3-tr_77 with dissolve
        sd "Sorry for running a little late, I was caught up with something."

        scene e3f3-tr_78 with dissolve
        tr "It's okay, don't worry."

        scene e3f3-tr_76 with dissolve
        sd "I see you also got here a little late."

        scene e3f3-tr_78 with dissolve
        tr "Yeah, we met along the way and decided to come together."

    scene e3f3-tr_76 with dissolve
    sd "I see."

    scene e3f3-tr_79 with dissolve
    sd "So, who's ready to party?"

    $ e3f3_explore += 1

    if e3f3_explore == 6:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Talk to the guys.")

    $ optional_quests.append("Ask Tracy about Sadie.")

    scene e3f3-tr_78 with dissolve
    tr "Haha, that's the spirit!"

    jump e3f3_bar
return

# Pool ###
label e3f3_pool:
    scene e3f3-04
    call screen e3f3_pool with dissolve
return

label e3f3_charlie:
    scene e3f3-ch_01 with dissolve
    pause

    scene e3f3-ch_02 with dissolve
    pause

    scene e3f3-ch_04 with dissolve
    unknown "Oh, hi!"
    unknown "Sorry, I didn't see you."

    scene e3f3-ch_05 with dissolve
    unknown "I'm assuming you'd like to play pool, right?"

    scene e3f3-ch_03 with dissolve
    mc "Nah, don't worry."
    mc "I was just wandering around the place."
    mc "I don't even know how to play pool for that matter."

    scene e3f3-ch_06 with dissolve
    unknown "Haha, what?"

    scene e3f3-ch_07 with dissolve
    mc "Yeah, I've never touched it in my life."

    scene e3f3-ch_08 with dissolve
    unknown "That sounds hard to believe."

    scene e3f3-ch_09 with dissolve
    unknown "Hold this in your hand."

    scene e3f3-ch_10 with dissolve
    mc "Damn... alright?"

    scene e3f3-ch_11 with dissolve
    unknown "Hmm..."

    scene e3f3-ch_12 with dissolve
    unknown "Now try and hit a ball with it."

    scene e3f3-ch_13 with dissolve
    mc "Is that really necessary?"

    scene e3f3-ch_14 with dissolve
    unknown "Alright... you don't have to hit a ball with it."

    scene e3f3-ch_12 with dissolve
    unknown "I guess your stance says everything."

    scene e3f3-ch_13 with dissolve
    mc "How does one have a pool stance?"

    scene e3f3-ch_14 with dissolve
    unknown "Haha, he doesn't, I was just messing with you."

    scene e3f3-ch_15 with dissolve
    unknown "I'm [ch]."

    scene e3f3-ch_17 with dissolve
    ch "I was just waiting for my friend to show up so we can play together."

    scene e3f3-ch_07 with dissolve
    mc "Ah, I see."
    mc "My name's [mc]."
    mc "Nice to meet you."

    scene e3f3-ch_16 with dissolve
    ch "Nice to meet you too!"

    scene e3f3-ch_17 with dissolve
    ch "If you ever want to learn pool, I'm your girl!"

    scene e3f3-ch_07 with dissolve
    mc "Sure... that sounds like a plan for the future."

    scene e3f3-ch_18 with dissolve
    ch "Great!"
    ch "It was nice talking to you [mc]."

    scene e3f3-ch_07 with dissolve
    mc "Nice talking to you too!"
    mc "See you around."

    scene e3f3-ch_16 with dissolve
    ch "Bye!"

    $ e3f3_explore += 1

    if e3f3_explore == 6:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Talk to the guys.")

    $ e3f3_charlie = True

    if affinity_spectrum > 0:
        scene e3f3-ch_19 with dissolve
        mc "*I don't have that much interest for pool but damn she is hot.*"
        mc "*Playing pool just became 10 times more interesting.*"

    jump e3f3_pool
return

# Staff ###
label e3f3_staff:
    scene e3f3-05
    call screen e3f3_staff with dissolve
return

label e3f3_jordan:

    $ collected_p = persistent.e3f3_collected_p
    $ collected_tp = persistent.e3f3_collected_tp
    $ renpy.show_screen("render_count_notify_pers")

    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            scene e3f3-jd_13 with dissolve
            mc "*Staff only.*"
            mc "*I guess this is the only door that I can go through.*"

            scene e3f3-jd_14 with dissolve
            mc "*Wow...*"
            mc "*I'm sure this is gonna confuse some people.*"

            scene e3f3-jd_01 with dissolve
            nt "*Holy shit... this place is huge!*"
            nt "*I didn't think they would do such a great job organising this.*"

            scene e3f3-jd_02 with dissolve
            pause

            scene e3f3-jd_06 with dissolve
            sc "Hey guys, look who's here, haha!"

            scene e3f3-jd_03 with dissolve
            sc "What's up Joey?"

            scene e3f3-jd_04 with dissolve
            sc "Enjoying the party?"

            scene e3f3-jd_05 with dissolve
            nt "What the hell are you doing here?"
            nt "And stop calling me Joey."

            scene e3f3-jd_08 with dissolve
            sc "Haven't you heard the news? I'm the president now!"

            scene e3f3-jd_07 with dissolve
            sc "That means you can't snoop around our parties anymore because I won't let you."

            scene e3f3-jd_05 with dissolve
            nt "What have I ever done to you?"

            scene e3f3-jd_07 with dissolve
            sc "Honestly, I don't really care to try and remember."
            sc "So, you can walk your sorry ass out of here before I try to remember and make a fool of you."

            scene e3f3-jd_09 with dissolve
            nt "..."

            scene e3f3-jd_10 with dissolve
            pause

            scene e3f3-jd_11 with dissolve
            sc "It was nice seeing you Joey!"

            scene e3f3-jd_12 with dissolve
            sc "*I'm surrounded by losers...*"

            scene black with dissolve
            pause

            if e3f3_claire_drink == True:
                sc "Huh?"

                scene black with vpunch
                sc "WHAT THE FUCK?"

            scene e3f3-jd_15 with dissolve
            pause

            stop music fadeout 2.0
            scene e3f3-jd_16 with dissolve
            pause

            play music dances_and_dames
            scene e3f3-jd_17 with dissolve
            unknown "Look... [sp]..."
            unknown "I've got you a new deal!"
            unknown "Trust me, it's so much better than the one you lost."
            unknown "I've got your bag of dope for almost half the price."
            unknown "It will be like you never lost it in the first place!"
            sp "Alright..."
            sp "Just, don't mess this thing up as well, alright?"
            unknown "I won't let you down."

            stop music
            scene e3f3-jd_18 with dissolve
            mc "[sp]?"

            scene e3f3-jd_19 with dissolve
            mc "Is that the same [sp] I'm thinking of?"

            scene e3f3-jd_20 with dissolve
            jd "[mc]...?"

            play music odesa
            scene e3f3-jd_21 with dissolve
            jd "Look bro, this is not what it seems..."

            scene e3f3-jd_22 with dissolve
            mc "Really [jd]?"
            mc "Out of all the people, you chose to get involved with [sp]?"

            scene e3f3-jd_23 with dissolve
            jd "I know bro, I was stupid..."

            scene e3f3-jd_24 with dissolve
            jd "Just hear me out, okay?"

            scene e3f3-jd_22 with dissolve
            mc "We're done."

            scene e3f3-jd_25 with dissolve
            pause

            scene e3f3-jd_26 with dissolve
            jd "Please bro, just don't tell the guys about it..."

            play sound door_close
            stop music fadeout 2.0
            scene e3f3-jd_27 with vpunch
            pause

            scene e3f3-jd_28 with dissolve
            pause

            scene e3f3-jd_29 with dissolve
            pause

            scene e3f3-jd_30 with dissolve
            jon "Woah, what's up [mc]?"

            scene e3f3-jd_31 with dissolve
            jon "You look like you've seen a ghost."

            scene e3f3-jd_32 with dissolve
            mc "I'm sorry [jon], I have to go."

            scene e3f3-jd_33 with dissolve
            jon "Wait, you're not gonna stay for the surprise?"

            scene e3f3-jd_34 with dissolve
            mc "Uh... no."
            mc "I just remembered that I have to do something so I'll be on my way."

            scene e3f3-jd_35 with dissolve
            jon "But it's 10 PM."

            scene e3f3-jd_34 with dissolve
            mc "As I said, I have to take care of something."

            scene e3f3-jd_36 with dissolve
            pause

            scene e3f3-jd_37 with dissolve
            jon "*What's gotten into him?*"

            return

        "Explore more":

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            call e3f3_staff from _call_e3f3_staff
return

# Bar ###
label e3f3_bar:
    if e3f3_ken_roman == False:
        scene e3f3-06
    else:
        if e3f3_scarlett_angry == False:
            scene e3f3-06_1
        else:
            scene e3f3-06_2

    call screen e3f3_bar with dissolve
return

label e3f3_ken_roman:
    scene e3f3-kr_01 with dissolve
    pause

    scene e3f3-kr_02 with dissolve
    mc "Hey guys, what are you doing?"

    scene e3f3-kr_03 with dissolve
    ro "Hi [mc]!"

    scene e3f3-kr_04 with dissolve
    ro "We're trying to seduce the bartender."

    scene e3f3-kr_05 with dissolve
    mc "Seduce the bartender?"
    mc "How so?"

    scene e3f3-kr_06 with dissolve
    ro "Basically, she said that if we can come up with some good pick up lines she'll give us free drinks."

    scene e3f3-kr_07 with dissolve
    mc "Is that what [ke]'s doing now?"

    scene e3f3-kr_08 with dissolve
    ro "Pretty much, yeah."

    scene e3f3-kr_09 with dissolve
    ro "I've had my shot and I couldn't really do much with it."

    scene e3f3-kr_05 with dissolve
    mc "I see."

    scene e3f3-kr_06 with dissolve
    ro "Wanna give it a try?"

    scene e3f3-kr_05 with dissolve
    menu:
        "Give it a try" if affinity_spectrum >= 0:
            call extrovert_affinity_check from _call_extrovert_affinity_check_44
            call color_check from _call_color_check_85

            $ e3f3_mia_seduce = True

            mc "Hmm... sure."
            mc "I could give it a try."

            scene e3f3-kr_10 with dissolve
            ro "Alright!"
        "Not for me":
            call introvert_affinity_check from _call_introvert_affinity_check_38
            call color_check from _call_color_check_86

            mc "Nah, sorry."
            mc "I don't think I'm cut out for it."

            scene e3f3-kr_11 with dissolve
            ro "It's alright I understand."

    scene e3f3-kr_13 with dissolve
    ke "Damn..."

    scene e3f3-kr_12 with dissolve
    pause

    scene e3f3-kr_14 with dissolve
    ro "She rejected you too?"

    scene e3f3-kr_15 with dissolve
    ke "Yeah, she had me pay for the drink."

    scene e3f3-kr_16 with dissolve
    mc "How would you guys know she doesn't just do that so you pay up?"

    scene e3f3-kr_17 with dissolve
    ro "Well, we're not exactly the best out there in terms of pick up lines."

    scene e3f3-kr_18 with dissolve
    ro "We don't really contest her decision because we know we're just ass."

    scene e3f3-kr_19 with dissolve
    ke "Yeah, it's mostly just laughs anyways."

    if e3f3_mia_seduce == True:
        scene e3f3-kr_20 with dissolve
        ro "Oh, also, [mc] here wants to give it a try as well."

        scene e3f3-kr_21 with dissolve
        ke "Haha, that's gotta be fun!"

        scene e3f3-kr_22 with dissolve
        mc "*Hmm... let's see how am I gonna approach her?*"

        menu:
            "Joke pick up":
                call extrovert_affinity_check from _call_extrovert_affinity_check_45
                call color_check from _call_color_check_87
                $ mia_trust -= 1

                $ e3f3_pickup = 1

                scene e3f3-kr_23 with dissolve
                mc "*Alright, I'm not gonna take this seriously.*"

                scene e3f3-kr_16 with dissolve
                mc "Guys, I'm going in."

                scene e3f3-kr_19 with dissolve
                ke "Alright bro, have fun!"

                scene e3f3-kr_10 with dissolve
                ro "Let us know what the outcome is."

                scene e3f3-kr_25 with dissolve
                pause

                scene e3f3-kr_26 with dissolve
                pause

                scene e3f3-kr_27 with dissolve
                pause

                scene e3f3-kr_28 with dissolve
                menu:
                    "Check her out":
                        scene e3f3-kr_29 with dissolve
                        mc "*Nice!*"

                        scene e3f3-kr_28 with dissolve
                    "Don't check her out":
                        pass

                mc "Hey, are you by any chance a jellyfish sting?"

                scene e3f3-kr_30 with dissolve
                pause

                scene e3f3-kr_32 with dissolve
                unknown "No... why?"

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Because I want to pee on you!"

                scene e3f3-kr_33 with dissolve
                hide e3f3_kr_mia_blink1
                unknown "No like..."

                scene e3f3-kr_34 with dissolve
                unknown "How the fuck does someone respond to this?"

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Just say you like the idea and leave the details to me."

                scene e3f3-kr_33 with dissolve
                hide e3f3_kr_mia_blink1
                unknown "Oh my God..."

                scene e3f3-kr_36 with dissolve
                mc "I'm [mc]."
            "Sexual pick up":
                call extrovert_affinity_check from _call_extrovert_affinity_check_46
                call color_check from _call_color_check_88
                $ scarlett_trust += 1

                $ e3f3_pickup = 2

                scene e3f3-kr_24 with dissolve
                mc "*Hehe, better make this fun while I'm at it.*"

                scene e3f3-kr_16 with dissolve
                mc "Guys, I'm going in."

                scene e3f3-kr_19 with dissolve
                ke "Alright bro, have fun!"

                scene e3f3-kr_10 with dissolve
                ro "Let us know what the outcome is."

                scene e3f3-kr_25 with dissolve
                pause

                scene e3f3-kr_26 with dissolve
                pause

                scene e3f3-kr_27 with dissolve
                pause

                scene e3f3-kr_28 with dissolve
                menu:
                    "Check her out":
                        scene e3f3-kr_29 with dissolve
                        mc "*Nice!*"

                        scene e3f3-kr_28 with dissolve
                    "Don't check her out":
                        pass

                mc "Hey, can you tell me how many planets we have in our solar system?"

                scene e3f3-kr_30 with dissolve
                pause

                scene e3f3-kr_32 with dissolve
                unknown "Uhh, 8?"

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Yeah and no."

                scene e3f3-kr_32 with dissolve
                hide e3f3_kr_mia_blink1
                unknown "What do you mean?"

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Well, there'll only be 7 planets after I destroy Uranus."

                scene e3f3-kr_36 with dissolve
                hide e3f3_kr_mia_blink1
                unknown "..."

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Sorry... had to get it out of my..."
                mc "{b}System!{/b}"
                unknown "..."
                mc "My name's [mc]."

                scene e3f3-kr_33 with dissolve
                hide e3f3_kr_mia_blink1
                unknown "I don't think I'd like to get to know you after that joke."

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "That's too bad because you did either way."
                mc "So what's your name while we're still at it?"
            "Bad pick up":
                call introvert_affinity_check from _call_introvert_affinity_check_39
                call color_check from _call_color_check_89

                $ e3f3_pickup = 3

                scene e3f3-kr_16 with dissolve
                mc "Alright, does anyone have a pen?"

                scene e3f3-kr_37 with dissolve
                ro "The fuck you need a pen for?"

                scene e3f3-kr_38 with dissolve
                mc "Just watch..."

                scene e3f3-kr_39 with dissolve
                pause

                scene e3f3-kr_25 with dissolve
                pause

                scene e3f3-kr_26 with dissolve
                pause

                scene e3f3-kr_27 with dissolve
                pause

                scene e3f3-kr_28 with dissolve
                menu:
                    "Check her out":
                        scene e3f3-kr_29 with dissolve
                        mc "*Nice!*"

                        scene e3f3-kr_28 with dissolve
                    "Don't check her out":
                        pass

                mc "Hey, can I show you something?"

                scene e3f3-kr_30 with dissolve
                pause

                scene e3f3-kr_32 with dissolve
                unknown "Sure, what's up?"

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "Do you have a napkin?"

                scene e3f3-kr_40 with dissolve
                hide e3f3_kr_mia_blink1
                pause

                scene e3f3-kr_41 with dissolve
                pause

                scene e3f3-kr_42 with dissolve
                pause

                scene e3f3-kr_43 with dissolve
                pause

                scene e3f3-kr_44 with dissolve
                unknown "What's this?"

                scene e3f3-kr_45 with dissolve
                mc "A pick up line!"

                scene e3f3-kr_46 with dissolve
                unknown "Oh my God..."

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "The name's [mc]!"

        scene e3f3-kr_47 with dissolve
        hide e3f3_kr_mia_blink1
        unknown "[mia]."

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "Nice to meet you, [mia]!"
        mc "Nice name by the way."
        mc "Reminds me of someone..."

        scene e3f3-kr_32 with dissolve
        hide e3f3_kr_mia_blink1
        mia "Of who?"

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "You wouldn't get it..."
        mc "Anyways, how's your night so far?"

        scene e3f3-kr_55 with dissolve
        hide e3f3_kr_mia_blink1
        mia "Had better."

        scene e3f3-kr_56 with dissolve
        mia "I'm supposed to wear this outfit which makes every guy here hit on me."

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "I guess I'm guilty of this one!"

        scene e3f3-kr_32 with dissolve
        hide e3f3_kr_mia_blink1
        mia "Hmm... I guess you are."

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "Did it work though?"

        scene e3f3-kr_32 with dissolve
        hide e3f3_kr_mia_blink1
        mia "Did what work?"

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "My pick up line!"
        mc "Is it enough to get me a free drink or should I try harder?"

        scene e3f3-kr_33 with dissolve
        hide e3f3_kr_mia_blink1
        mia "What... the actual fuck."

        scene e3f3-kr_34 with dissolve
        mia "Where did everyone get the idea that I'm giving away free drinks if you come up with a good pick up line?"

        scene e3f3-kr_57 with dissolve
        mc "That's not the deal?"

        scene e3f3-kr_34 with dissolve
        mia "Of course not!"

        scene e3f3-kr_33 with dissolve
        mia "I've been wondering why every guy here comes with a pick up line."
        mia "Some worse than others."

        scene e3f3-kr_58 with dissolve
        mia "And also what's the fucking logic?"

        scene e3f3-kr_34 with dissolve
        mia "I pay out of my own pocket for their stupid pick up lines?"
        mia "What do I even get out of this?"

        scene e3f3-kr_33 with dissolve
        mia "I swear to God, if I knew this would happen I wouldn't have dressed up like this."
        mia "Much less shown up in here."

        scene e3f3-kr_36 with dissolve
        mc "Oh... well... I'm sorry to hear that."

        scene e3f3-kr_59 with dissolve
        mia "Sorry for my rant, I just couldn't take it anymore."

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "I understand, I'd be pissed off too if I were in your shoes."

        menu:
            "Help her out":
                $ mia_trust += 1
                $ e3f3_help_mia = True

                mc "Look, I will try to get this sorted out, alright?"
                mc "I can't take back what happened but I can stop it from happening again."

                scene e3f3-kr_47 with dissolve
                hide e3f3_kr_mia_blink1
                mia "Thank you!"
                mia "I really appreciate that."

                scene e3f3-kr_31 with dissolve
                show e3f3_kr_mia_blink1
                mc "No problem."

            "Let it be":
                scene e3f3-kr_33 with dissolve
                hide e3f3_kr_mia_blink1
                mia "Yeah... anyways."

        scene e3f3-kr_35 with dissolve
        hide e3f3_kr_mia_blink1
        mia "Do you wanna like get something to drink or?"

        scene e3f3-kr_31 with dissolve
        show e3f3_kr_mia_blink1
        mc "Nah... I'm fine."
        mc "Thanks anyways."

        scene e3f3-kr_55 with dissolve
        mia "Yeah..."

        scene e3f3-kr_60 with dissolve
        pause

        if e3f3_pickup == 2:
            scene e3f3-kr_48 with dissolve
            sc "Destroy your anus?"

            scene e3f3-kr_50 with dissolve
            sc "Really?"

            scene e3f3-kr_49 with dissolve
            mc "You know, that was just a joke but we can make it happen if that's all you're gonna be talking about."

            scene e3f3-kr_51 with dissolve
            sc "You're not getting anywhere near my butt."

            scene e3f3-kr_49 with dissolve
            mc "Then what are you doing here?"

            scene e3f3-kr_52 with dissolve
            sc "Can't a lady grab something to drink?"

            scene e3f3-kr_49 with dissolve
            mc "You?"
            mc "Lady?"
            mc "My ass..."

            scene e3f3-kr_53 with dissolve
            sc "That won't open any legs."

            scene e3f3-kr_49 with dissolve
            mc "Your legs are probably the last ones I'd hope to open."

            scene e3f3-kr_51 with dissolve
            sc "Your loss nerd."

        scene e3f3-kr_27 with dissolve
        pause

        scene e3f3-kr_54 with dissolve
        pause

        scene e3f3-kr_61 with dissolve
        ro "So... how did it go?"

        scene e3f3-kr_62 with dissolve
        mc "You guys are assholes."

        scene e3f3-kr_63 with dissolve
        ro "Haha, I told you it would work!"

        scene e3f3-kr_64 with dissolve
        ke "I can't believe you got the idea on the fly dude."
        ke "You had me fooled as well."

        scene e3f3-kr_65 with dissolve
        ro "Did you really try to get a free drink?"

        scene e3f3-kr_67 with dissolve
        mc "That was the bet, wasn't it?"

        scene e3f3-kr_66 with dissolve
        ro "Haha, yeah, it was!"

        scene e3f3-kr_68 with dissolve
        ke "So... how was the drink dude?"

        scene e3f3-kr_67 with dissolve
        mc "I actually didn't get one."

        scene e3f3-kr_69 with dissolve
        ke "Oh... damn."
        ke "And here I was thinking you would get it and then try to talk her into giving it for free."

        scene e3f3-kr_67 with dissolve
        mc "I'm not as stupid as you guys think I am."

        scene e3f3-kr_70 with dissolve
        ro "*Chuckles!*"

        scene e3f3-kr_18 with dissolve
        ro "Hey bro, don't be upset alright?"
        ro "It was just a prank."

        scene e3f3-kr_67 with dissolve
        mc "Yeah, sure."
        mc "You owe me a drink by the way."
        mc "Make it double because you are two bastards."

        scene e3f3-kr_72 with dissolve
        ke "You can't be serious."

        scene e3f3-kr_71 with dissolve
        mc "I mean it!"

        scene e3f3-kr_73 with dissolve
        pause

        if e3f3_help_mia == True:
            scene e3f3-kr_71 with dissolve
            mc "Also, leave the poor girl alone!"
            mc "I think she's had enough of your games."
            mc "It's not fun anymore."
            mc "Of course, if you want her to come back here."

            scene e3f3-kr_18 with dissolve
            ro "Alright, alright, we'll stop."
    else:
        scene e3f3-kr_16 with dissolve
        mc "I see."
        mc "Well, I'll see you around, I'm gonna go meet some other people."

        scene e3f3-kr_19 with dissolve
        ke "Alright bro, have fun!"

    $ e3f3_explore += 1

    if e3f3_explore == 6:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Talk to the guys.")

    $ e3f3_ken_roman = True

    scene e3f3-kr_25 with dissolve
    pause

    jump e3f3_bar
return

label e3f3_scarlett:
    scene e3f3-sc_01 with dissolve
    pause

    scene e3f3-sc_02 with dissolve
    pause

    scene e3f3-sc_03 with dissolve
    pause

    scene e3f3-sc_04 with dissolve
    pause
    mc "So... nice party tonight."

    scene e3f3-sc_05 with dissolve
    sc "What?"

    scene e3f3-sc_07 with dissolve
    sc "You're here to kiss my ass?"

    scene e3f3-sc_06 with dissolve
    if affinity_spectrum > 0:
        mc "Don't act like you wouldn't like that."

    mc "I just came to put in a good word."

    scene e3f3-sc_07 with dissolve
    sc "Well, you know where to shove that word."

    scene e3f3-sc_08 with dissolve
    pause

    scene e3f3-sc_06 with dissolve
    mc "I can tell by the fact that you're sitting alone at this bar how much people must really enjoy your presence."

    if affinity_spectrum > 0:
        mc "I mean... it's your party after all right?"
        mc "It's like you're throwing your birthday party and everyone just hangs out with the neighbour's kid instead."
        mc "At your own party."

    scene e3f3-sc_09 with dissolve
    sc "And if you wanted to leave a good word you could have ended it at that."

    scene e3f3-sc_10 with dissolve
    sc "You didn't have to start making remarks about the fact that I'm sitting here all by myself."

    scene e3f3-sc_11 with dissolve
    if affinity_spectrum > 0:

        $ scarlett_trust += 1

        mc "Oh... what?"
        mc "You're butthurt now?"

        scene e3f3-sc_12 with dissolve
        sc "Idiot."

        scene e3f3-sc_06 with dissolve
        mc "Don't worry [sc], I'm sure you'll make some friends."

        scene e3f3-sc_13 with dissolve
        pause

        $ e3f3_scarlett_angry = False
    else:
        mc "You're right, I'm sorry."
        mc "Have a good night."

        scene e3f3-sc_09 with dissolve
        sc "You really suck the fun out of everything, don't you?"

        scene e3f3-sc_14 with dissolve
        pause

        $ e3f3_scarlett_angry = True

    $ e3f3_explore += 1

    if e3f3_explore == 6:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Talk to the guys.")

    $ e3f3_scarlett = True

    if e3f3_ken_roman == False:
        scene e3f3-06 with dissolve
    else:
        if e3f3_scarlett_angry == False:
            scene e3f3-06_1 with dissolve
        else:
            scene e3f3-06_2 with dissolve

    jump e3f3_bar
return

# Pool couch ###
label e3f3_pool_couch:
    scene e3f3-07
    call screen e3f3_pool_couch with dissolve
return

# Vending table ###
label e3f3_vending_table:
    scene e3f3-08
    call screen e3f3_vending_table with dissolve
return
