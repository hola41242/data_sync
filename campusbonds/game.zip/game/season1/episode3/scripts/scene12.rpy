
# Scene 12 - A not so great date ###############################################

label e3s12:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s12-01 with Dissolve(2.0)
    play music hollow_grove
    pause

    scene e3s12-02 with dissolve
    cl "Hey!"

    scene e3s12-03 with dissolve
    mc "Hey!"
    mc "So, are we ready to go?"

    scene e3s12-04 with dissolve
    cl "Yup, all good!"

    stop music fadeout 2.0
    scene e3s12-05 with dissolve
    pause

    scene e3s12-06 with wipeleft
    play music mpause
    pause

    scene e3s12-07 with dissolve
    cl "So, where are you taking me [mc]?"
    cl "It's been on my mind all day now."

    scene e3s12-08 with dissolve
    mc "Haha, we're almost there!"
    mc "I don't want to spoil it."

    scene e3s12-10 with dissolve
    cl "Ugh... fine."

    scene e3s12-09 with dissolve
    cl "So, how was your day then?"

    scene e3s12-11 with dissolve
    mc "Haha, you're trying to get your mind off of it?"

    scene e3s12-12 with dissolve
    cl "What am I supposed to do?"

    scene e3s12-13 with dissolve
    mc "My day was fine."
    mc "I had some annoying classes, but nothing I couldn't handle."
    mc "What about you?"

    scene e3s12-14 with dissolve
    cl "I would say the same, but it's not the classes that are the problem."

    scene e3s12-15 with dissolve
    mc "Don't tell me that scumbag [da] is causing you problems."

    scene e3s12-16 with dissolve
    cl "No, no!"
    cl "It's not that."

    scene e3s12-09 with dissolve
    cl "The clients are the problem."
    cl "You wouldn't believe how entitled most of them are."

    scene e3s12-17 with dissolve
    cl "They think that if I'm the waiter I have to also be their slave."
    cl "I'm a human being like everybody else and I've also got other things to do."
    cl "Most of them just complain about shit that isn't even my fault."

    scene e3s12-18 with dissolve
    mc "I'm sorry you have to go through this."

    if e1s15_help == True:
        mc "My offer is still on the table, you know?"
        mc "I can still talk to [jon] about getting you a new job."

        scene e3s12-19 with dissolve
        cl "Thank you [mc]!"
        cl "If I ever need it I will let you know."

        scene e3s12-18 with dissolve
        mc "Alright!"

    scene e3s12-20 with wipeleft
    pause

    stop music fadeout 2.0
    scene e3s12-33 with dissolve
    mc "Well, we're finally here!"

    play music college_rock
    scene e3s12-21 with dissolve
    cl "Oh. my. God..."

    scene e3s12-22 with dissolve
    cl "[mc], I love this!!"

    scene e3s12-23 with dissolve
    cl "Oh my God, I've been meaning to go to bumper cars for a while now."
    cl "You don't know how happy this makes me feel!"

    scene e3s12-24 with dissolve
    mc "Haha, I'm glad!"

    scene e3s12-25 with dissolve
    mc "I had a feeling you might like it."

    scene e3s12-21 with dissolve
    cl "My God, it's been so long."
    cl "I remember the last time I was here it was with-"

    stop music fadeout 1.0
    scene e3s12-26 with dissolve
    cl "..."

    scene e3s12-27 with dissolve
    mc "[cl]?"
    mc "What's wrong?"

    scene e3s12-28 with dissolve
    cl "Nothing, it's just..."
    cl "I'm sorry!"

    scene e3s12-29 with dissolve
    mc "[cl] wait!"

    scene e3s12-30 with dissolve
    mc "What did I do wrong?"

    scene e3s12-31 with dissolve
    pause

    scene e3s12-32 with dissolve
    pause

    jump e3s13
return
