
# Scene 19 - Princess charming (Friday) ########################################

label e3s19:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s19-02 with Dissolve(2.0)
    pause

    scene e3s19-01 with dissolve
    pause

    scene e3s19-03 with dissolve
    mc "*Damn... I'm one hour early.*"
    mc "*No wonder, without my phone it's a bit hard to tell the time.*"
    mc "*Maybe I should get a watch...*"

    play sound door_close
    scene e3s19-04 with dissolve
    play music ariana_grande_synthet
    pause

    scene e3s19-05 with dissolve
    am "Hey, looks like we got the place to ourselves!"

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Hey, what are you doing here?"

    scene e3s19-09 with dissolve
    hide e3s19_amber_blink1
    am "I could ask you the same question."

    scene e3s19-08 with dissolve
    am "You're here early."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Yeah... so?"
    mc "I wanted to practice."

    scene e3s19-07 with dissolve
    hide e3s19_amber_blink1
    am "With what instruments?"

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Uh... with my guitar?"

    scene e3s19-09 with dissolve
    hide e3s19_amber_blink1
    am "Where is it?"

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Alright, I miscalculated the time and now I'm here early, so what?"

    scene e3s19-09 with dissolve
    hide e3s19_amber_blink1
    am "Oh, nothing."

    scene e3s19-08 with dissolve
    am "I was just saying."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Now it's you who hasn't answered the question."
    mc "What are you doing here?"

    scene e3s19-10 with dissolve
    hide e3s19_amber_blink1
    am "Can't an old member visit her old club?"

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Not when she was kicked out."

    scene e3s19-07 with dissolve
    hide e3s19_amber_blink1
    am "Oh, so she's got you up to date, good!"

    scene e3s19-08 with dissolve
    am "Although, you might have to review some of those facts."

    scene e3s19-09 with dissolve
    am "I wasn't... exactly kicked out."

    scene e3s19-07 with dissolve
    am "I just chose to leave on my own."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "I wouldn't expect someone like you to tell the truth."

    scene e3s19-08 with dissolve
    hide e3s19_amber_blink1
    am "Think whatever you want to think, dear."
    am "I have no reason to lie to you."

    scene e3s19-09 with dissolve
    am "But maybe there's another side to the story that you haven't heard."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Yeah?"
    mc "So what's that?"

    scene e3s19-09 with dissolve
    hide e3s19_amber_blink1
    am "Jeez, not so fast, take me to dinner first."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Are you for real?"

    scene e3s19-08 with dissolve
    hide e3s19_amber_blink1
    am "Oh, well..."
    am "Maybe some other day then."

    scene e3s19-06 with dissolve
    show e3s19_amber_blink1
    mc "Wait, what other side?"

    scene e3s19-11 with dissolve
    hide e3s19_amber_blink1
    pause

    stop music fadeout 2.0
    scene e3s19-12 with dissolve
    mc "*What's with all these people?*"

    scene e3s19-13 with dissolve
    mc "*I gotta take a leak.*"

    jump e3s19_amber
return

label e3s19_amber:
    play sound pants_zip
    scene e3s19-14 with wipeleft
    pause

    play sound door_open
    scene e3s19-15 with dissolve
    play music killer_rabbit
    am "Hey, what do we have here?"
    mc "Huh?"

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            if affinity_spectrum > 0:
                scene e3s19-16 with dissolve
                mc "What the fuck are you doing in here?"
            else:
                scene e3s19-17 with dissolve
                mc "What the hell are you doing here?"

            scene e3s19-18 with dissolve
            am "Damn, you're packing I'll give you that."
            am "My assumptions were right."
            am "I see now why [fr] likes you."

            scene e3s19-19 with dissolve
            menu:
                "Get angry":
                    $ francesca_trust += 1

                    scene e3s19-20 with vpunch
                    mc "What did you just say?"

                    scene e3s19-21 with dissolve
                    am "Oh... struck a ‘chord', didn't I?"
                    am "Hahaha!"

                    scene e3s19-22 with dissolve
                    am "Your thing is even poking me!"
                    mc "*Shit.*"

                "Let it go":
                    mc "Whatever."

            if affinity_spectrum < 0:
                scene e3s19-17 with dissolve
                mc "Can you just get out, please?"
            else:
                scene e3s19-16 with dissolve
                mc "Can you just let me pee in peace?"
                mc "I've got enough on my mind already."

            am "Sure, sweetie!"
            am "Just wanted to check up on you, see if you're doing alright."

            scene e3s19-14 with dissolve
            mc "Thanks, but no thanks."

            scene e3s19-23 with dissolve
            mc "I don't need your worries."

            scene e3s19-24 with vpunch
            pause

            scene e3s19-28 with dissolve
            am "I wouldn't want anything happening to this big gem here."
            menu:
                "Let her continue":
                    $ persistent.e3s19_amber_lewd = True
                    $ e3s19_amber_lewd = True
                    $ amber_trust += 1

                    stop music fadeout 2.0

                "Storm out" if not _in_replay:
                    $ amber_trust -= 1
                    scene e3s19-58 with dissolve
                    mc "What the fuck are you doing?"

                    scene e3s19-59 with dissolve
                    mc "Get the hell out!"
                    mc "You're lucky you're not knocked on the floor by now!"

                    scene e3s19-60 with dissolve
                    am "Jeez, alright tough ass."

                    scene e3s19-61 with dissolve
                    am "Thought we could have a little fun, but I guess not."

                    scene e3s19-62 with dissolve
                    am "Tell [fr] I said hi, alright?"

                    scene e3s19-63 with dissolve
                    am "Such a lucky girl."

                    play sound door_close
                    scene e3s19-64 with dissolve
                    mc "*Crazy ass bitch.*"
                    mc "*She won't even let me pee, for fuck's sake.*"

                    stop music fadeout 2.0
                    scene e3s19-14 with dissolve
                    pause

                    jump e3s20

            play music blues_of_t
            scene e3s19-26 with dissolve
            mc "..."

            scene e3s19-25 with dissolve
            am "Damn, no comeback?"
            am "You must be really enjoying this one then."
            am "Don't worry, I'll make it worth your while."

            scene e3s19-27 with dissolve
            am "I'll just... move my hand up and down."

            # Standing
            scene e3s19-handjob1 with dissolve
            pause

            scene e3s19-handjob2 with dissolve
            mc "Ah..."

            scene e3s19-29 with dissolve
            am "Are those little moans I'm hearing"

            scene e3s19-handjob1 with dissolve
            mc "Of course not."

            scene e3s19-handjob2 with dissolve
            am "Don't worry sweetheart, you can let them out."
            am "Just enjoy this moment, don't even think about anything else."
            am "Feel my soft hands rubbing on your shaft."

            scene e3s19-handjob3 with dissolve
            mc "*Damn, her talking game is good.*"
            mc "*It's really turning me on.*"

            scene e3s19-handjob1 with dissolve
            mc "Oh my God..."
            am "Yeah, just like that."

            scene e3s19-29 with dissolve
            am "This could be our dirty little secret, you know?"
            am "You like to get dirty, don't you?"

            scene e3s19-handjob2 with dissolve
            mc "Fuck..."

            scene e3s19-30 with vpunch
            pause

            scene e3s19-31 with dissolve
            mc "Dam-"

            scene e3s19-32 with dissolve
            am "Shhh!"

            scene e3s19-33 with dissolve
            pause

            # Tit groping
            scene e3s19-34 with dissolve
            mc "Damn, your tits are so hot."

            scene e3s19-35 with dissolve
            am "You like them?"

            scene e3s19-37 with dissolve
            am "Here, have a little touch."

            scene e3s19-38 with dissolve
            mc "They're so soft..."

            scene e3s19-39 with dissolve
            am "They're yours, pretty!"
            am "Give them a good squeeze."

            scene e3s19-38 with dissolve
            am "Ah..."
            mc "Look who's moaning now!"
            am "What can I say..."

            scene e3s19-39 with dissolve
            am "A gentleman knows his touch."
            am "You're doing such a great job."
            am "It's turning me on even more!"

            scene e3s19-36 with dissolve
            am "Let me try something."

            scene e3s19-40 with dissolve
            pause

            scene e3s19-41 with dissolve
            pause

            scene e3s19-42 with dissolve
            mc "Hey do you seriously want to-"

            scene e3s19-43 with dissolve
            mc "Ah… fuck!"

            # Sitting
            scene e3s19-blowjob1 with dissolve
            pause

            scene e3s19-blowjob2 with dissolve
            mc "Fuck [am], keep going!"
            mc "That feels so good."

            scene e3s19-44 with dissolve
            am "Damn, I love how your shaft is just sliding into my pretty little mouth."

            scene e3s19-45 with dissolve
            am "Just the thought of your semen busting in there..."

            scene e3s19-46 with dissolve
            am "God, I'm very wet down there."

            scene e3s19-47 with dissolve
            pause

            scene e3s19-handjob4 with dissolve
            mc "Can I touch?"

            scene e3s19-44 with dissolve
            am "Not yet [mc], gradually you'll get access to everything."
            am "Right now, let's just focus on this pretty shaft!"

            scene e3s19-blowjob3 with dissolve
            pause

            scene e3s19-blowjob1 with dissolve
            mc "Oh my God, I'm in heaven!"

            scene e3s19-blowjob2 with dissolve
            pause

            scene e3s19-44 with dissolve
            am "Just tell me when you want to cum, alright?"

            scene e3s19-45 with dissolve
            am "I wouldn't want any of that good semen wasted."

            scene e3s19-blowjob3 with dissolve
            mc "If you keep this up, it won't take much longer."

            scene e3s19-blowjob4 with dissolve
            am "Guh guh..."

            scene e3s19-blowjob5 with dissolve
            mc "Fuck [am]..."

            scene e3s19-blowjob4 with dissolve
            pause

            scene e3s19-handjob4 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                if affinity_spectrum > 0:
                    scene e3s19-16 with dissolve
                    mc "What the fuck are you doing in here?"
                else:
                    scene e3s19-17 with dissolve
                    mc "What the hell are you doing here?"

                scene e3s19-18 with dissolve
                am "Damn, you're packing I'll give you that."
                am "My assumptions were right."
                am "I see now why [fr] likes you."

                scene e3s19-19 with dissolve
                menu:
                    "Get angry":
                        $ francesca_trust += 1

                        scene e3s19-20 with vpunch
                        mc "What did you just say?"

                        scene e3s19-21_cen with dissolve
                        am "Oh... struck a ‘chord', didn't I?"
                        am "Hahaha!"

                        scene e3s19-22_cen with dissolve
                        am "Your thing is even poking me!"
                        mc "*Shit.*"

                    "Let it go":
                        mc "Whatever."

                if affinity_spectrum < 0:
                    scene e3s19-17 with dissolve
                    mc "Can you just get out, please?"
                else:
                    scene e3s19-16 with dissolve
                    mc "Can you just let me pee in peace?"
                    mc "I've got enough on my mind already."

                am "Sure, sweetie!"
                am "Just wanted to check up on you, see if you're doing alright."

                scene e3s19-14 with dissolve
                mc "Thanks, but no thanks."

                scene e3s19-23 with dissolve
                mc "I don't need your worries."

                scene e3s19-24_cen with vpunch
                pause

                scene e3s19-28_cen with dissolve
                am "I wouldn't want anything happening to this big gem here."
                menu:
                    "Let her continue":
                        $ e3s19_amber_lewd = True
                        $ amber_trust += 1

                        stop music fadeout 2.0

                    "Storm out" if not _in_replay:
                        $ amber_trust -= 1
                        scene e3s19-58 with dissolve
                        mc "What the fuck are you doing?"

                        scene e3s19-59 with dissolve
                        mc "Get the hell out!"
                        mc "You're lucky you're not knocked on the floor by now!"

                        scene e3s19-60 with dissolve
                        am "Jeez, alright tough ass."

                        scene e3s19-61 with dissolve
                        am "Thought we could have a little fun, but I guess not."

                        scene e3s19-62 with dissolve
                        am "Tell [fr] I said hi, alright?"

                        scene e3s19-63 with dissolve
                        am "Such a lucky girl."

                        play sound door_close
                        scene e3s19-64 with dissolve
                        mc "*Crazy ass bitch.*"
                        mc "*She won't even let me pee, for fuck's sake.*"

                        stop music fadeout 2.0
                        scene e3s19-14 with dissolve
                        pause

                        jump e3s20

                play music blues_of_t
                scene e3s19-26 with dissolve
                mc "..."

                scene e3s19-25 with dissolve
                am "Damn, no comeback?"
                am "You must be really enjoying this one then."
                am "Don't worry, I'll make it worth your while."

                scene e3s19-27 with dissolve
                am "I'll just... move my hand up and down."

                # Standing
                scene e3s19-handjob1_cen with dissolve
                pause

                scene e3s19-handjob2_cen with dissolve
                mc "Ah..."

                scene e3s19-29 with dissolve
                am "Are those little moans I'm hearing"

                scene e3s19-handjob1_cen with dissolve
                mc "Of course not."

                scene e3s19-handjob2_cen with dissolve
                am "Don't worry sweetheart, you can let them out."
                am "Just enjoy this moment, don't even think about anything else."
                am "Feel my soft hands rubbing on your shaft."

                scene e3s19-handjob3 with dissolve
                mc "*Damn, her talking game is good.*"
                mc "*It's really turning me on.*"

                scene e3s19-handjob1_cen with dissolve
                mc "Oh my God..."
                am "Yeah, just like that."

                scene e3s19-29 with dissolve
                am "This could be our dirty little secret, you know?"
                am "You like to get dirty, don't you?"

                scene e3s19-handjob2_cen with dissolve
                mc "Fuck..."

                scene e3s19-30 with vpunch
                pause

                scene e3s19-31 with dissolve
                mc "Dam-"

                scene e3s19-32 with dissolve
                am "Shhh!"

                scene e3s19-33 with dissolve
                pause

                # Tit groping
                scene e3s19-34_cen with dissolve
                mc "Damn, your tits are so hot."

                scene e3s19-35_cen with dissolve
                am "You like them?"

                scene e3s19-37_cen with dissolve
                am "Here, have a little touch."

                scene e3s19-38_cen with dissolve
                mc "They're so soft..."

                scene e3s19-39 with dissolve
                am "They're yours, pretty!"
                am "Give them a good squeeze."

                scene e3s19-38_cen with dissolve
                am "Ah..."
                mc "Look who's moaning now!"
                am "What can I say..."

                scene e3s19-39 with dissolve
                am "A gentleman knows his touch."
                am "You're doing such a great job."
                am "It's turning me on even more!"

                scene e3s19-36_cen with dissolve
                am "Let me try something."

                scene e3s19-40 with dissolve
                pause

                scene e3s19-41_cen with dissolve
                pause

                scene e3s19-42 with dissolve
                mc "Hey do you seriously want to-"

                scene e3s19-43 with dissolve
                mc "Ah… fuck!"

                # Sitting
                scene e3s19-blowjob1_cen with dissolve
                pause

                scene e3s19-blowjob2_cen with dissolve
                mc "Fuck [am], keep going!"
                mc "That feels so good."

                scene e3s19-44_cen with dissolve
                am "Damn, I love how your shaft is just sliding into my pretty little mouth."

                scene e3s19-45_cen with dissolve
                am "Just the thought of your semen busting in there..."

                scene e3s19-46_cen with dissolve
                am "God, I'm very wet down there."

                scene e3s19-47 with dissolve
                pause

                scene e3s19-handjob4_cen with dissolve
                mc "Can I touch?"

                scene e3s19-44_cen with dissolve
                am "Not yet [mc], gradually you'll get access to everything."
                am "Right now, let's just focus on this pretty shaft!"

                scene e3s19-blowjob3_cen with dissolve
                pause

                scene e3s19-blowjob1_cen with dissolve
                mc "Oh my God, I'm in heaven!"

                scene e3s19-blowjob2_cen with dissolve
                pause

                scene e3s19-44_cen with dissolve
                am "Just tell me when you want to cum, alright?"

                scene e3s19-45_cen with dissolve
                am "I wouldn't want any of that good semen wasted."

                scene e3s19-blowjob3_cen with dissolve
                mc "If you keep this up, it won't take much longer."

                scene e3s19-blowjob4_cen with dissolve
                am "Guh guh..."

                scene e3s19-blowjob5_cen with dissolve
                mc "Fuck [am]..."

                scene e3s19-blowjob4_cen with dissolve
                pause

                scene e3s19-handjob4_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Standing":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s19-handjob1 with dissolve
                        pause

                        scene e3s19-handjob2 with dissolve
                        mc "Ah..."

                        scene e3s19-29 with dissolve
                        am "Are those little moans I'm hearing"

                        scene e3s19-handjob1 with dissolve
                        mc "Of course not."

                        scene e3s19-handjob2 with dissolve
                        am "Don't worry sweetheart, you can let them out."
                        am "Just enjoy this moment, don't even think about anything else."
                        am "Feel my soft hands rubbing on your shaft."

                        scene e3s19-handjob3 with dissolve
                        mc "*Damn, her talking game is good.*"
                        mc "*It's really turning me on.*"

                        scene e3s19-handjob1 with dissolve
                        mc "Oh my God..."
                        am "Yeah, just like that."

                        scene e3s19-29 with dissolve
                        am "This could be our dirty little secret, you know?"
                        am "You like to get dirty, don't you?"

                        scene e3s19-handjob2 with dissolve
                        mc "Fuck..."
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s19-handjob1_cen with dissolve
                            pause

                            scene e3s19-handjob2_cen with dissolve
                            mc "Ah..."

                            scene e3s19-29 with dissolve
                            am "Are those little moans I'm hearing"

                            scene e3s19-handjob1_cen with dissolve
                            mc "Of course not."

                            scene e3s19-handjob2_cen with dissolve
                            am "Don't worry sweetheart, you can let them out."
                            am "Just enjoy this moment, don't even think about anything else."
                            am "Feel my soft hands rubbing on your shaft."

                            scene e3s19-handjob3 with dissolve
                            mc "*Damn, her talking game is good.*"
                            mc "*It's really turning me on.*"

                            scene e3s19-handjob1_cen with dissolve
                            mc "Oh my God..."
                            am "Yeah, just like that."

                            scene e3s19-29 with dissolve
                            am "This could be our dirty little secret, you know?"
                            am "You like to get dirty, don't you?"

                            scene e3s19-handjob2_cen with dissolve
                            mc "Fuck..."
                "Tit groping":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s19-34 with dissolve
                        mc "Damn, your tits are so hot."

                        scene e3s19-35 with dissolve
                        am "You like them?"

                        scene e3s19-37 with dissolve
                        am "Here, have a little touch."

                        scene e3s19-38 with dissolve
                        mc "They're so soft..."

                        scene e3s19-39 with dissolve
                        am "They're yours, pretty!"
                        am "Give them a good squeeze."

                        scene e3s19-38 with dissolve
                        am "Ah..."
                        mc "Look who's moaning now!"
                        am "What can I say..."

                        scene e3s19-39 with dissolve
                        am "A gentleman knows his touch."
                        am "You're doing such a great job."
                        am "It's turning me on even more!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s19-34_cen with dissolve
                            mc "Damn, your tits are so hot."

                            scene e3s19-35_cen with dissolve
                            am "You like them?"

                            scene e3s19-37_cen with dissolve
                            am "Here, have a little touch."

                            scene e3s19-38_cen with dissolve
                            mc "They're so soft..."

                            scene e3s19-39 with dissolve
                            am "They're yours, pretty!"
                            am "Give them a good squeeze."

                            scene e3s19-38_cen with dissolve
                            am "Ah..."
                            mc "Look who's moaning now!"
                            am "What can I say..."

                            scene e3s19-39 with dissolve
                            am "A gentleman knows his touch."
                            am "You're doing such a great job."
                            am "It's turning me on even more!"
                "Sitting":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s19-blowjob1 with dissolve
                        pause

                        scene e3s19-blowjob2 with dissolve
                        mc "Fuck [am], keep going!"
                        mc "That feels so good."

                        scene e3s19-44 with dissolve
                        am "Damn, I love how your shaft is just sliding into my pretty little mouth."

                        scene e3s19-45 with dissolve
                        am "Just the thought of your semen busting in there..."

                        scene e3s19-46 with dissolve
                        am "God, I'm very wet down there."

                        scene e3s19-handjob4 with dissolve
                        mc "Can I touch?"

                        scene e3s19-44 with dissolve
                        am "Not yet [mc], gradually you'll get access to everything."
                        am "Right now, let's just focus on this pretty shaft!"

                        scene e3s19-blowjob3 with dissolve
                        pause

                        scene e3s19-blowjob1 with dissolve
                        mc "Oh my God, I'm in heaven!"

                        scene e3s19-blowjob2 with dissolve
                        pause

                        scene e3s19-44 with dissolve
                        am "Just tell me when you want to cum, alright?"

                        scene e3s19-45 with dissolve
                        am "I wouldn't want any of that good semen wasted."

                        scene e3s19-blowjob3 with dissolve
                        mc "If you keep this up, it won't take much longer."

                        scene e3s19-blowjob4 with dissolve
                        am "Guh guh..."

                        scene e3s19-blowjob5 with dissolve
                        mc "Fuck [am]..."

                        scene e3s19-blowjob4 with dissolve
                        pause

                        scene e3s19-handjob4 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s19-blowjob1_cen with dissolve
                            pause

                            scene e3s19-blowjob2_cen with dissolve
                            mc "Fuck [am], keep going!"
                            mc "That feels so good."

                            scene e3s19-44_cen with dissolve
                            am "Damn, I love how your shaft is just sliding into my pretty little mouth."

                            scene e3s19-45_cen with dissolve
                            am "Just the thought of your semen busting in there..."

                            scene e3s19-46_cen with dissolve
                            am "God, I'm very wet down there."

                            scene e3s19-handjob4_cen with dissolve
                            mc "Can I touch?"

                            scene e3s19-44_cen with dissolve
                            am "Not yet [mc], gradually you'll get access to everything."
                            am "Right now, let's just focus on this pretty shaft!"

                            scene e3s19-blowjob3_cen with dissolve
                            pause

                            scene e3s19-blowjob1_cen with dissolve
                            mc "Oh my God, I'm in heaven!"

                            scene e3s19-blowjob2_cen with dissolve
                            pause

                            scene e3s19-44_cen with dissolve
                            am "Just tell me when you want to cum, alright?"

                            scene e3s19-45_cen with dissolve
                            am "I wouldn't want any of that good semen wasted."

                            scene e3s19-blowjob3_cen with dissolve
                            mc "If you keep this up, it won't take much longer."

                            scene e3s19-blowjob4_cen with dissolve
                            am "Guh guh..."

                            scene e3s19-blowjob5_cen with dissolve
                            mc "Fuck [am]..."

                            scene e3s19-blowjob4_cen with dissolve
                            pause

                            scene e3s19-handjob4_cen with dissolve
                            pause
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        mc "[am]... I'm going to cum!"
                        am "Alright, sweetie!"

                        scene e3s19-handjob5 with dissolve
                        am "Come on, let it all out."
                        am "Cum on my pretty little face."
                        mc "Ah... shit!"

                        scene e3s19-48 with dissolve
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e3s19-49 with dissolve
                        am "Damn, a big loader too!"
                        am "I really wonder what you have left to show me, [mc]."

                        scene e3s19-50 with dissolve
                        mc "Damn... I'm wasted."
                        mc "Am I even gonna have energy for..."
                        mc "Holy shit, college rock!"

                        scene e3s19-49 with dissolve
                        am "Relax [mc], you're fine."

                        scene e3s19-51 with dissolve
                        am "We haven't been in here for an hour."

                        scene e3s19-52 with dissolve
                        mc "Listen, [am], you can't tell anyone about this."

                        scene e3s19-53 with dissolve
                        am "Sure [mc]!"
                        am "Don't worry, as I've said..."

                        scene e3s19-54 with dissolve
                        am "This will be our dirty little secret!"

                        scene e3s19-53 with dissolve
                        am "I'm gonna go now, we've probably already attracted too much attention."

                        scene e3s19-55 with dissolve
                        mc "Haha, you're right."

                        scene e3s19-53 with dissolve
                        am "Get cleaned up honey!"

                        scene e3s19-56 with dissolve
                        am "Looking forward to seeing you again soon."

                        stop music fadeout 2.0
                        scene e3s19-57 with dissolve
                        mc "*Damn... what was that?*"
                        mc "*Fuck... I better hurry.*"
                    else:
                        if persistent.type_nsfw == False:
                            mc "[am]... I'm going to cum!"
                            am "Alright, sweetie!"

                            scene e3s19-handjob5_cen with dissolve
                            am "Come on, let it all out."
                            am "Cum on my pretty little face."
                            mc "Ah... shit!"

                            scene e3s19-48_cen with dissolve
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3s19-49_cen with dissolve
                            am "Damn, a big loader too!"
                            am "I really wonder what you have left to show me, [mc]."

                            scene e3s19-50_cen with dissolve
                            mc "Damn... I'm wasted."
                            mc "Am I even gonna have energy for..."
                            mc "Holy shit, college rock!"

                            scene e3s19-49_cen with dissolve
                            am "Relax [mc], you're fine."

                            scene e3s19-51_cen with dissolve
                            am "We haven't been in here for an hour."

                            scene e3s19-52_cen with dissolve
                            mc "Listen, [am], you can't tell anyone about this."

                            scene e3s19-53_cen with dissolve
                            am "Sure [mc]!"
                            am "Don't worry, as I've said..."

                            scene e3s19-54_cen with dissolve
                            am "This will be our dirty little secret!"

                            scene e3s19-53_cen with dissolve
                            am "I'm gonna go now, we've probably already attracted too much attention."

                            scene e3s19-55 with dissolve
                            mc "Haha, you're right."

                            scene e3s19-53_cen with dissolve
                            am "Get cleaned up honey!"

                            scene e3s19-56_cen with dissolve
                            am "Looking forward to seeing you again soon."

                            stop music fadeout 2.0
                            scene e3s19-57 with dissolve
                            mc "*Damn... what was that?*"
                            mc "*Fuck... I better hurry.*"

                    $ GameRunning = False

    $ renpy.end_replay()

    stop music fadeout 2.0

    jump e3s20
return
