
# Scene 25 - Cleo's confession #################################################

label e3s25:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s25-01 with Dissolve(2.0)
    play music beautiful_piano_melodies
    pause

    scene e3s25-02 with dissolve
    pause

    scene e3s25-03 with dissolve
    pause

    scene e3s25-04 with dissolve
    pause

    scene e3s25-05 with dissolve
    pause

    scene e3s25-06 with dissolve
    pause

    scene e3s25-07 with dissolve
    mc "Hey [cl]!"

    scene e3s25-08 with dissolve
    mc "I got your letter."

    scene e3s25-09 with dissolve
    cl "[mc]..."

    scene e3s25-10 with dissolve
    pause

    scene e3s25-11 with dissolve
    pause

    scene e3s25-12 with dissolve
    pause

    scene e3s25-14 with dissolve
    cl "I wasn't sure you'd come."

    scene e3s25-13 with dissolve
    mc "Are you alright?"

    scene e3s25-09 with dissolve
    cl "To be honest... not really."

    scene e3s25-15 with dissolve
    cl "Sit down."

    scene e3s25-13 with dissolve
    mc "Alright."

    scene e3s25-16 with dissolve
    pause

    scene e3s25-17 with dissolve
    show e3s25_cleo_blink2
    mc "If it's something I did I want you to know that I'm sorry."

    scene e3s25-18 with dissolve
    hide e3s25_cleo_blink2
    cl "No... it's not something that you did."

    scene e3s25-19 with dissolve
    cl "I'm really sorry for storming away like that."

    scene e3s25-20 with dissolve
    cl "Your gesture was amazing, I can't remember the last time someone did something like that for me."

    scene e3s25-17 with dissolve
    show e3s25_cleo_blink2
    mc "Then, what's wrong?"
    mc "I'm here for you just so you know."

    scene e3s25-21 with dissolve
    hide e3s25_cleo_blink2
    cl "I appreciate that [mc]."

    scene e3s25-22 with dissolve
    cl "It's a really deep issue for me that has haunted me for a very long time."

    scene e3s25-23 with dissolve
    cl "And I've been really afraid to talk about it to anyone."
    cl "And I'm still afraid of talking about it."

    scene e3s25-18 with dissolve
    cl "Every time I think about it..."

    scene e3s25-19 with dissolve
    cl "It feels like I'm reliving that same exact moment."

    scene e3s25-17 with dissolve
    show e3s25_cleo_blink2
    mc "Not talking about it won't make it go away unfortunately..."

    scene e3s25-20 with dissolve
    hide e3s25_cleo_blink2
    cl "You know, it did for a while."

    scene e3s25-19 with dissolve
    cl "I learned to forget, I learned to move on."

    scene e3s25-23 with dissolve
    cl "But the bumper cars triggered hard buried feelings from deep inside."

    scene e3s25-17 with dissolve
    show e3s25_cleo_blink2
    mc "What happened [cl]?"

    scene e3s25-24 with dissolve
    hide e3s25_cleo_blink2
    cl "..."

    scene e3s25-18 with dissolve
    cl "It's about my parents..."
    cl "They were killed in a car accident."

    scene e3s25-17 with dissolve
    show e3s25_cleo_blink2
    mc "Oh my God..."
    mc "I'm so sorry to hear that!"

    scene e3s25-22 with dissolve
    hide e3s25_cleo_blink2
    cl "My father died instantly and my mother lived for a couple more days."
    cl "Before..."

    scene e3s25-25 with dissolve
    cl "Before also passing away."

    scene e3s25-26 with dissolve
    cl "I can still remember her face in the hospital..."

    scene e3s25-27 with dissolve
    mc "Hey, hey..."
    mc "I'm here, don't worry."

    scene e3s25-28 with dissolve
    pause

    scene e3s25-29 with dissolve
    cl "They used to take me to the bumper cars every weekend."

    scene e3s25-30 with dissolve
    cl "We would have so much fun, I remember this one time my father let me drive a car alone."

    scene e3s25-31 with dissolve
    cl "I basically only targeted him before teaming up and crushing everyone else."

    scene e3s25-32 with dissolve
    cl "I miss them so much."

    scene e3s25-33 with dissolve
    cl "Why did they have to go away, [mc]?"

    scene e3s25-34 with dissolve
    mc "I'm so sorry [cl], I didn't know."
    mc "I'm sure they're in a better place now."
    mc "I wouldn't have taken you there if I'd known."

    scene e3s25-35 with dissolve
    cl "No, it's not your fault."
    cl "You couldn't have known."

    scene e3s25-36 with dissolve
    show e3s25_cleo_blink3
    cl "..."

    scene e3s25-29 with dissolve
    hide e3s25_cleo_blink3
    cl "And since then, it's been really really hard for me to get close to people."
    cl "I've pushed everyone away and become cold."

    scene e3s25-30 with dissolve
    cl "I didn't want people leaving anymore."

    scene e3s25-31 with dissolve
    cl "I've only kept things on the surface."

    scene e3s25-35 with dissolve
    cl "But then you came into my life... and you somehow made my walls come down."
    cl "I felt like shit when I ran away."

    scene e3s25-28 with dissolve
    cl "But I didn't want you to see me like this."

    scene e3s25-30 with dissolve
    cl "I couldn't... let you see me like this."

    scene e3s25-29 with dissolve
    cl "I hate being vulnerable and I hate opening up."

    scene e3s25-35 with dissolve
    cl "But you had to know, these past couple of days I've been building up the courage to tell you this."

    scene e3s25-36 with dissolve
    show e3s25_cleo_blink3
    mc "Thank you so much for telling me [cl]."
    mc "I want you to know that I'm going to be by your side."
    mc "And I'm glad you trusted me enough to tell me all of this."
    mc "I can understand how hard it must be for you."

    scene e3s25-35 with dissolve
    hide e3s25_cleo_blink3
    cl "It is..."

    scene e3s25-34 with dissolve
    cl "..."

    scene e3s25-28 with dissolve
    cl "You know... things were so much better as a kid."

    scene e3s25-29 with dissolve
    cl "No worries, no nothing."

    scene e3s25-30 with dissolve
    cl "I've had to learn to take care of myself all alone."
    cl "And I was barely a teenager."

    scene e3s25-28 with dissolve
    mc "I don't know if this helps but you didn't give me any coldness vibes."

    scene e3s25-36 with dissolve
    show e3s25_cleo_blink3
    mc "I remember you being kind to me from the first day we met."
    mc "I can still remember your smile on the train."

    scene e3s25-37 with dissolve
    hide e3s25_cleo_blink3
    pause

    scene e3s25-38 with dissolve
    pause

    scene e3s25-39 with dissolve
    pause

    scene e3s25-kiss1 with dissolve
    pause

    scene e3s25-kiss2 with dissolve
    pause

    scene e3s25-40 with dissolve
    pause

    scene e3s25-41 with dissolve
    cl "Wow... uh..."

    scene e3s25-42 with dissolve
    cl "I don't know what to say..."

    scene e3s25-43 with dissolve
    mc "You don't have to say anything [cl]."
    mc "We can just enjoy the landscape."
    mc "And the silence of the night."

    scene e3s25-44 with dissolve
    cl "..."

    scene e3s25-45 with dissolve
    cl "I haven't kissed anybody else before..."

    scene e3s25-46 with dissolve
    mc "You're a good kisser, [cl]!"

    scene e3s25-47 with dissolve
    pause

    scene e3s25-48 with dissolve
    pause

    if e3s9_intervene == True:
        jump e3s26
    else:
        jump e3s27
return
