
# Scene 3 - Asking a friend out ################################################

label e3s3:
    play music laurel_breeze
    scene e3s3-01 with wipeleft
    pause

    scene e3s3-02 with dissolve
    mc "Hello [fr]!"

    scene e3s3-04 with dissolve
    fr "[mc], hi!"
    fr "What's up?"

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    if e2s10_francesca == False:
        if e2s3_hangout == True:
            mc "Well, first of all, I'd like to apologise again for not being able to make it to our date."

            scene e3s3-05 with dissolve
            hide e3s3_francesca_blink1
            fr "[mc], it's fine, don't worry."

            scene e3s3-06 with dissolve
            fr "I get it, you had something else on your plate."

            scene e3s3-03 with dissolve
            show e3s3_francesca_blink1
            mc "Thank you."

    mc "I was wondering..."
    mc "If you're taking business classes, I assume you're good at them, right?"

    scene e3s3-06 with dissolve
    hide e3s3_francesca_blink1
    fr "Well, it depends."

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    mc "Great, because I need some help with a class of mine."

    scene e3s3-07 with dissolve
    hide e3s3_francesca_blink1
    fr "What do you need help with?"

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    mc "The teacher assigned us some tasks and to be honest I have no idea how to complete them."

    scene e3s3-08 with dissolve
    hide e3s3_francesca_blink1
    fr "Have you consulted with the first year's text book?"

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    mc "That's the thing, I don't need theory."
    mc "I need practical stuff."

    scene e3s3-09 with dissolve
    hide e3s3_francesca_blink1
    fr "I see."

    scene e3s3-08 with dissolve
    fr "Well, I'll be happy to help."

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    mc "Great, see you at the library after classes?"

    scene e3s3-06 with dissolve
    hide e3s3_francesca_blink1
    fr "I can't tonight."

    scene e3s3-10 with dissolve
    fr "How about tomorrow morning before classes?"

    scene e3s3-03 with dissolve
    show e3s3_francesca_blink1
    mc "Alright, see you then!"

    stop music fadeout 2.0
    scene e3s3-11 with dissolve
    hide e3s3_francesca_blink1
    pause

    jump e3s4

return
