
# Scene 13 - No one nothing ####################################################

label e3s13:
    if e2f2_tiffany_refuse == False:
        if e3s10_cleo_hangout == True:
            scene e3s13-14 with wipeleft
            pause
        else:
            scene black with Dissolve(2.0)
            pause(1.0)

            scene e3s13-14 with Dissolve(2.0)
            pause

        play music inertia
        scene e3s13-34 with dissolve
        tf "Hey there!"

        scene e3s13-35 with dissolve
        show e3s13_tiffany_blink1
        mc "Hello [tf]."

        scene e3s13-36 with dissolve
        hide e3s13_tiffany_blink1
        tf "Is this a bad time?"

        scene e3s13-35 with dissolve
        show e3s13_tiffany_blink1
        mc "No, I was just going back to my dorm."

        scene e3s13-37 with dissolve
        hide e3s13_tiffany_blink1
        tf "You went out?"

        scene e3s13-35 with dissolve
        show e3s13_tiffany_blink1
        if e3s10_cleo_hangout == True:
            mc "Yeah, but I didn't hang out for long."
        else:
            mc "Usual classes."

        scene e3s13-38 with dissolve
        hide e3s13_tiffany_blink1
        tf "I see."

        scene e3s13-39 with dissolve
        tf "Would you like to make up for the lost time by coming over to my dorm?"

        scene e3s13-37 with dissolve
        tf "We can order some food and watch a movie or something."

        scene e3s13-35 with dissolve
        show e3s13_tiffany_blink1
        mc "*Damn [tf], the timing of this is not ideal.*"
        mc "*What should I tell her?*"
        menu:
            "Hang out with her":
                $ tiffany_trust += 1
                $ e3s13_tiffany_hangout = True

                mc "*You know what?*"
                mc "*Maybe it will help me take my mind off things for a bit.*"
                mc "Alright [tf], I'll come over."

                scene e3s13-37 with dissolve
                hide e3s13_tiffany_blink1
                tf "Perfect!"

                scene e3s13-39 with dissolve
                tf "What would you like us to have?"

                scene e3s13-38 with dissolve
                tf "I'd personally get some Chinese food since it's been a long time since I ate some."

                scene e3s13-36 with dissolve
                tf "But I'll be fine with whatever you'd like."

                scene e3s13-35 with dissolve
                show e3s13_tiffany_blink1
                mc "Just order whatever you think is best alright?"
                mc "I'll choose the movie."

                scene e3s13-37 with dissolve
                hide e3s13_tiffany_blink1
                tf "Alright, perfect!"

                if e3s8_tiffany_hangout == False:
                    tf "See you at my dorm!"

                    scene e3s13-36 with dissolve
                    tf "I live at dorm number 10."

                    scene e3s13-35 with dissolve
                    show e3s13_tiffany_blink1
                    mc "Okay, got it!"
                    mc "See you then."
                else:
                    tf "You remember where my dorm is, right?"

                    scene e3s13-35 with dissolve
                    show e3s13_tiffany_blink1
                    mc "Yeah, I got it right on my-"
                    mc "Phone...?"

                    scene e3s13-41 with dissolve
                    hide e3s13_tiffany_blink1
                    tf "What's wrong?"

                    scene e3s13-40 with dissolve
                    mc "I don't know, my phone's not in my pocket anymore."

                    scene e3s13-43 with dissolve
                    tf "Did you leave it somewhere?"

                    scene e3s13-42 with dissolve
                    mc "Not that I remember."
                    mc "The last time I used it was when..."
                    mc "*Oh shit.*"

                    scene e3s13-43 with dissolve
                    tf "When what?"

                    scene e3s13-42 with dissolve
                    mc "You know what?"
                    mc "I just remembered where I left it."
                    mc "You go ahead and order the food and I'll come with the movie, alright?"

                    scene e3s13-41 with dissolve
                    tf "Okay then, I'll be waiting for you."

                    scene e3s13-42 with dissolve
                    mc "Okay."

            "Not tonight":
                mc "I'm sorry [tf], not tonight."

                scene e3s13-37 with dissolve
                hide e3s13_tiffany_blink1
                tf "It's alright [mc]."
                tf "Have a good night!"

                scene e3s13-35 with dissolve
                show e3s13_tiffany_blink1
                mc "You too!"

        stop music fadeout 2.0
        scene e3s13-44 with dissolve
        pause

    play music iwnlylmd
    scene e3s13-01 with wipeleft
    pause

    scene e3s13-02 with dissolve
    mc "Hi [nt]."
    mc "Are you sleeping?"

    scene e3s13-03 with dissolve
    nt "Hey [mc]."

    scene e3s13-04 with dissolve
    nt "Nah, I'm just lying in bed."

    if e3s10_cleo_hangout == True:
        scene e3s13-05 with dissolve
        nt "What's up dude?"
        nt "You look beat up."

        scene e3s13-06 with dissolve
        mc "I'm okay."

    scene e3s13-07 with dissolve
    nt "I've been invited to some party tonight."

    scene e3s13-08 with dissolve
    nt "I was wondering if you'd like to come."

    scene e3s13-09 with dissolve
    mc "Nah, I'm okay."
    mc "You can go ahead and have fun."

    scene e3s13-10 with dissolve
    nt "Are you sure?"
    nt "You're not one to miss parties."

    scene e3s13-11 with dissolve
    mc "Well, I've got some things to think about tonight."

    scene e3s13-12 with dissolve
    nt "Alright bro, you do you!"
    nt "I hope you get through whatever shit you got."

    scene e3s13-11 with dissolve
    mc "Thanks!"

    scene e3s13-13 with dissolve
    pause

    if e3s13_tiffany_hangout == False or e3s13_tiffany_hangout == True and e3s8_tiffany_hangout == False:
        scene e3s13-45 with dissolve
        pause
        mc "*Huh?*"

        scene e3s13-46 with dissolve
        mc "*Where is that damn phone.*"

        scene e3s13-45 with dissolve
        pause

        scene e3s13-46 with dissolve
        mc "*You can't be serious.*"

        scene e3s13-15 with dissolve
        mc "*Where did I leave it?*"
        mc "*I remember the last time I've used it was when-*"

        scene e3s13-47 with dissolve
        mc "*God damn it, I left it at the librarian's desk didn't I?*"
        mc "*How can I be so stupid?*"

        scene e3s13-15 with dissolve
        mc "*She almost caught me twice, I can't sneak into her office yet again.*"
        mc "*Fuck, I'll see what I can do about it tomorrow.*"

    if e3s13_tiffany_hangout == True:
        call e3s13_hangout from _call_e3s13_hangout

    jump e3s14
return

label e3s13_hangout:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s13-16 with Dissolve(2.0)
    play music border_blaster
    tf "[mc], come on in!"

    scene e3s13-17 with dissolve
    mc "I see you got the food."
    tf "Yup!"

    scene e3s13-18 with dissolve
    tf "I told you that I'd really like some Chinese food."

    scene e3s13-19 with dissolve
    mc "Fine by me."

    scene e3s13-20 with dissolve
    tf "So, what are we watching?"

    scene e3s13-21 with dissolve
    mc "Well, me and my father are going to watch the new sequel to Killer in Action this weekend."

    scene e3s13-19 with dissolve
    mc "And I thought I should refresh my memory by watching the previous one."
    mc "If that's alright with you."

    scene e3s13-18 with dissolve
    tf "Yeah, it's fine."

    scene e3s13-20 with dissolve
    tf "Sounds nice to hear that you're still making time for your father."

    scene e3s13-21 with dissolve
    mc "Yeah, we're pretty close."

    scene e3s13-19 with dissolve
    mc "He's the only family I have left."

    scene e3s13-18 with dissolve
    tf "What about your mom?"

    scene e3s13-19 with dissolve
    mc "..."

    scene e3s13-22 with dissolve
    tf "Oh... I'm sorry."
    tf "I didn't want to strike a chord."

    scene e3s13-23 with dissolve
    mc "No, it's alright."
    mc "You couldn't have known."

    scene e3s13-24 with dissolve
    tf "I'm here if you'd like to talk."

    scene e3s13-23 with dissolve
    mc "Thank you [tf]!"

    scene e3s13-25 with wipeleft
    pause

    scene e3s13-26 with dissolve
    mc "About my mother..."

    scene e3s13-27 with dissolve
    mc "She left me when I was younger."

    scene e3s13-28 with dissolve
    tf "What?"
    tf "Why did she do that?"

    scene e3s13-29 with dissolve
    mc "I don't know to be honest."
    mc "It's something that's been on my mind for a very long time."
    mc "But Dad simply refuses to talk about that."

    scene e3s13-28 with dissolve
    tf "Do you think he has something to do with it?"

    scene e3s13-29 with dissolve
    mc "Huh?"

    scene e3s13-28 with dissolve
    tf "Maybe he's ashamed of something."

    scene e3s13-29 with dissolve
    mc "What would he be ashamed of?"

    scene e3s13-30 with dissolve
    tf "I don't know... people hold secrets all the time."

    scene e3s13-28 with dissolve
    tf "I'm not trying to sound disrespectful but maybe he did something to push her away."

    scene e3s13-29 with dissolve
    mc "Alright, listen."
    mc "I decided to open up about my mom to you because I wanted to trust you."
    mc "But I didn't think you'd judge my dad for something he didn't even do."

    scene e3s13-31 with dissolve
    tf "[mc], I'm sorry, I didn't want to come off as judging."

    scene e3s13-28 with dissolve
    tf "I just wanted to tell you that maybe there's something more to the story than meets the eye."

    scene e3s13-29 with dissolve
    mc "You know what [tf]?"
    mc "I know my family well enough to know that there's not anything more to the story than what has been already told."
    mc "Thanks for the food."

    scene e3s13-31 with dissolve
    tf "Wait, you're leaving?"

    scene e3s13-32 with dissolve
    mc "I need some air."

    scene e3s13-33 with dissolve
    tf "..."
return
