
# Scene 10 - A new opportunity (again). (Wednesday) ############################

label e3s10:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s10-01 with Dissolve(2.0)
    play music one_fine_day
    pause

    scene e3s10-02 with dissolve
    pause

    scene e3s10-05 with dissolve
    fr "Hey [mc], what's up?"

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    menu:
        "Check her out":
            $ francesca_trust -= 1
            scene e3s10-04 with dissolve
            hide e3s10_francesca_blink1
            mc "Nothing much..."
            fr "Uh... [mc]?"

            scene e3s10-03 with dissolve
            show e3s10_francesca_blink1
            mc "Shit, sorry."

        "Don't risk it":
            mc "Nothing much."

    mc "Hey, I was wondering..."
    mc "How come we have this class together?"

    scene e3s10-05 with dissolve
    hide e3s10_francesca_blink1
    fr "What do you mean?"

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    mc "I remember last week when I approached you, we were in the same class."
    mc "But never had the chance to ask why."

    scene e3s10-06 with dissolve
    hide e3s10_francesca_blink1
    fr "Well... I've put this class off."

    scene e3s10-07 with dissolve
    fr "Didn't want to deal with it in the first year so I've gotta deal with it now."

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    mc "I understand."
    mc "Hey, about your group..."

    scene e3s10-08 with dissolve
    hide e3s10_francesca_blink1
    fr "Don't worry [mc], I understand."

    scene e3s10-09 with dissolve
    fr "You've already promised [jon] you'd join his club."
    fr "No need to apologize."

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    mc "I was actually wondering if you could give me a tour."

    scene e3s10-07 with dissolve
    hide e3s10_francesca_blink1
    fr "Did something happen?"

    scene e3s10-09 with dissolve
    fr "What happened to [jon]'s proposal?"

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    mc "Well... I've been thinking about it."
    mc "And I'd like to explore more options, not just his."

    scene e3s10-06 with dissolve
    hide e3s10_francesca_blink1
    fr "Oh, alright, fair enough."

    scene e3s10-10 with dissolve
    fr "I'll give you a tour then."
    fr "I really hope you're gonna like it."

    stop music fadeout 2.0
    scene e3s10-11 with dissolve
    mc "Haha, yeah!"

    if affinity_spectrum <= 0:
        scene e3s10-12 with dissolve
        mc "*Me too...*"

    scene e3s10-13 with wipeleft
    fr "[mc]..."
    fr "I present to you... College Rock!"

    scene e3s10-14 with dissolve
    if affinity_spectrum < 0:
        mc "My God..."
    else:
        mc "Holy shit..."

    scene e3s10-15 with dissolve
    if affinity_spectrum < 0:
        mc "You guys got a full-on studio going on here!"
    else:
        mc "You guys got a whole-ass studio going on here!"

    mc "Damn..."

    scene e3s10-17 with dissolve
    fr "Haha, so I get you like it?"

    scene e3s10-16 with dissolve
    mc "As far as looks go, this place 'rocks'."

    scene e3s10-17 with dissolve
    fr "Haha, yeah!"

    scene e3s10-18 with dissolve
    fr "Alright, let's start with the tour, this won't take long."

    scene e3s10-19 with wipeleft
    fr "And these are the instruments we're gonna play with."

    scene e3s10-21 with dissolve
    mc "I thought this group would be a little more populated."

    scene e3s10-22 with dissolve
    fr "Yeah, well, we had our repetition today."
    fr "Tomorrow is our next one, you're gonna meet everyone then."

    scene e3s10-20 with dissolve
    mc "Alright, awesome!"

    play sound door_close
    play music hi_as_hats
    scene e3s10-23 with dissolve
    unknown "Damn, are you really gonna keep him all to yourself?"

    scene e3s10-24 with dissolve
    unknown "I didn't know you girls took boys to classes as well."

    scene e3s10-25 with dissolve
    fr "Well, we don't really do that."
    fr "And by the way, you're not allowed to be here until the competition starts."

    scene e3s10-26 with dissolve
    unknown "It's fine, I'm not here to steal any of your compositions."
    unknown "And you're not doing any repetitions whatsoever so it doesn't matter."

    scene e3s10-27 with dissolve
    mc "Who's she?"

    scene e3s10-28 with dissolve
    unknown "[am]."
    am "Nice to meet you pretty!"

    scene e3s10-29 with dissolve
    am "Mind if I ask your name as well?"

    scene e3s10-30 with dissolve
    mc "I'm [mc]."

    scene e3s10-31 with dissolve
    am "Sorry [fr], couldn't stop myself."

    scene e3s10-32 with dissolve
    am "When I saw you entering this room with a guy this good looking..."

    scene e3s10-33 with dissolve
    am "I couldn't help but get the wrong idea, you know?"

    scene e3s10-34 with dissolve
    am "I thought that... you know, I could perhaps join in on the fun."

    scene e3s10-35 with dissolve
    am "Anyways, it doesn't matter what I think, or what anyone else thinks for that matter."

    scene e3s10-36 with dissolve
    am "Good luck at the competition, you're gonna need it!"

    scene e3s10-37 with dissolve
    pause

    scene e3s10-38 with dissolve
    mc "O...kay?"

    stop music fadeout 2.0
    scene e3s10-39 with dissolve
    fr "Bitch..."

    play music bloom
    if affinity_spectrum > 0:
        scene e3s10-40 with dissolve
        show e3s10_francesca_blink2
        mc "Damn... I didn't think you had this in you."

    scene e3s10-44 with dissolve
    hide e3s10_francesca_blink2
    fr "Sorry, I really can't stand her."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "I can tell why."
    mc "So, what's up with her?"

    scene e3s10-42 with dissolve
    hide e3s10_francesca_blink2
    pause

    scene e3s10-41 with dissolve
    fr "She's our opposition."

    scene e3s10-43 with dissolve
    fr "We used to be friends."

    scene e3s10-44 with dissolve
    fr "Until she started coming after everything I had and being a bitch about it too."

    scene e3s10-41 with dissolve
    fr "She used to be a part of this club as well right up until she was kicked out."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "Why was she kicked out?"

    scene e3s10-43 with dissolve
    hide e3s10_francesca_blink2
    fr "Doing what she just did now."
    fr "Coming in here unsupervised, stealing ideas and giving them away to the competition."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "I understand."
    mc "Why does she do this?"

    scene e3s10-45 with dissolve
    hide e3s10_francesca_blink2
    fr "I don't know, we were really good friends back then."

    scene e3s10-43 with dissolve
    fr "She just became really envious of me."

    scene e3s10-44 with dissolve
    fr "She thought I had it too good and didn't have to work for it."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "That sucks."
    mc "I'm sorry [fr]."

    scene e3s10-45 with dissolve
    hide e3s10_francesca_blink2
    fr "It's alright [mc]."
    fr "I've moved on."

    scene e3s10-41 with dissolve
    fr "Anyways, if you don't have questions regarding college rock I guess this concludes our tour."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "Thanks [fr], this club seems interesting!"

    scene e3s10-46 with dissolve
    hide e3s10_francesca_blink2
    fr "Well then, I'll be seeing you tomorrow for your first repetition."

    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "About that... just so you know, I really suck at playing instruments."

    scene e3s10-46 with dissolve
    hide e3s10_francesca_blink2
    fr "Haha, don't worry, we'll walk you through it."

    stop music fadeout 2.0
    scene e3s10-40 with dissolve
    show e3s10_francesca_blink2
    mc "Thanks!"

    scene e3s10-47 with wipeleft
    hide e3s10_francesca_blink2
    pause

    play music heartless_man
    scene e3s10-48 with dissolve
    pause

    scene e3s10-49 with dissolve
    mc "Hi [cl]!"

    scene e3s10-51 with dissolve
    cl "Hey [mc]."

    scene e3s10-50 with dissolve
    show e3s10_cleo_blink1
    mc "Sorry... about the other day, for storming out like that."

    scene e3s10-52 with dissolve
    hide e3s10_cleo_blink1
    cl "It's okay."
    cl "I get that you had important stuff to do."

    scene e3s10-50 with dissolve
    show e3s10_cleo_blink1
    mc "Yeah... something like that."

    scene e3s10-53 with dissolve
    hide e3s10_cleo_blink1
    cl "So... are you alright now?"

    scene e3s10-50 with dissolve
    show e3s10_cleo_blink1
    menu:
        "Lie to her":
            mc "Yeah, I'm fine."
            mc "It was just a misunderstanding."

            scene e3s10-53 with dissolve
            hide e3s10_cleo_blink1
            cl "I see!"

            scene e3s10-54 with dissolve
            cl "I'm glad you got it fixed then."

            scene e3s10-50 with dissolve
            show e3s10_cleo_blink1
            mc "Yeah..."
            mc "It was nice talking to you Cleo but I've gotta get going to my class."

            scene e3s10-51 with dissolve
            hide e3s10_cleo_blink1
            cl "Alright then, see you later."

            scene e3s10-50 with dissolve
            show e3s10_cleo_blink1
            mc "Bye!"
        "Tell her the truth":
            $ cleo_trust += 1
            $ e3s10_cleo_hangout = True

            mc "Truth be told... I'm not really okay now."
            mc "A lot of shit has gone down in the last couple of days and I don't even know what to make of everything."
            mc "I've been left with a lot of questions and not a lot of answers."

            scene e3s10-56 with dissolve
            hide e3s10_cleo_blink1
            cl "What happened?"

            scene e3s10-57 with dissolve
            show e3s10_cleo_blink2
            mc "Hey, wanna hang out later to talk about this?"
            mc "I'm in a bit of a hurry right now to get to class."
            mc "I can make it up to you for yesterday."

            scene e3s10-58 with dissolve
            hide e3s10_cleo_blink2
            cl "You don't have to worry about making it up to me."
            cl "I understand you're going through some hard things now."

            scene e3s10-59 with dissolve
            cl "And yeah, we can hang out later."
            cl "Do you have something in mind?"

            scene e3s10-50 with dissolve
            show e3s10_cleo_blink1
            mc "Yup, I do, and I want it to be a surprise."
            mc "So... meet me after college and I'll take you there, alright?"

            scene e3s10-60 with dissolve
            hide e3s10_cleo_blink1
            cl "Haha, okay!"
            cl "I'm looking forward to it!"

            scene e3s10-50 with dissolve
            show e3s10_cleo_blink1
            mc "Okay then, it's a date!"
            mc "See you later [cl]!"

            scene e3s10-51 with dissolve
            hide e3s10_cleo_blink1
            cl "Bye [mc]!"

    stop music fadeout 2.0
    scene e3s10-55 with dissolve
    hide e3s10_cleo_blink1
    pause

    scene e3s10-61 with wipeleft
    pause

    scene e3s10-62 with dissolve
    pause

    play music onfire
    scene e3s10-63 with dissolve
    mc "What's up [sd]?"

    scene e3s10-64 with dissolve
    show e3s10_sadie_blink1
    mc "Where's [tr]?"

    scene e3s10-65 with dissolve
    hide e3s10_sadie_blink1
    sd "She called in sick today."

    scene e3s10-66 with dissolve
    sd "It's just me here."

    scene e3s10-64 with dissolve
    show e3s10_sadie_blink1
    mc "I can tell."
    mc "So, how have you been?"

    scene e3s10-67 with dissolve
    hide e3s10_sadie_blink1
    sd "Fine, what about you?"

    scene e3s10-64 with dissolve
    show e3s10_sadie_blink1
    mc "Fine as well."

    if sadie_trust >= 6:
        if e2s6_sadie_romance == True or e2s6_sadie_fwb == True:
            scene e3s10-65 with dissolve
            hide e3s10_sadie_blink1
            sd "I think you've got a habit of leaving parties early."

            scene e3s10-64 with dissolve
            show e3s10_sadie_blink1
            mc "Haha, what do you mean?"

            scene e3s10-68 with dissolve
            hide e3s10_sadie_blink1
            sd "You left last night's party."
            sd "And Cabanna's."

            scene e3s10-69 with dissolve
            mc "And you also left the house party early."

            scene e3s10-67 with dissolve
            sd "Alright, fair enough, I guess we're both early birds."

            scene e3s10-70 with dissolve
            sd "Ahem... even though I had a pretty legit reason, we'll have it your way."

            scene e3s10-71 with dissolve
            sd "Listen, I'd like to ask for a favour."

            scene e3s10-72 with dissolve
            show e3s10_sadie_blink2
            mc "With those pointed at me, I feel like I have no other option but to help you!"
            mc "What's up?"
    else:
        scene e3s10-71 with dissolve
        sd "Hey, can you help me with something?"

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "Sure, what's up?"

    scene e3s10-73 with dissolve
    hide e3s10_sadie_blink2
    sd "The librarian has confiscated my phone."

    scene e3s10-74 with dissolve
    sd "I got a phone call and I forgot to mute my phone while I was studying in the library..."

    scene e3s10-73 with dissolve
    sd "And now she took it away."

    scene e3s10-75 with dissolve
    sd "So, I'd like to know if you could help me get it back by sneaking in her office and taking it from there."

    scene e3s10-72 with dissolve
    show e3s10_sadie_blink2
    if sadie_trust >= 6 and e2s6_sadie_romance == True:
        mc "Oh, so that's why you're not mad at me for not texting you?"

        scene e3s10-76 with dissolve
        hide e3s10_sadie_blink2
        sd "You what?"

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "You know what? Nevermind."
        mc "I'll get you that phone."
        mc "Forget I ever said that."

        scene e3s10-75 with dissolve
        hide e3s10_sadie_blink2
        sd "I'd have you kiss my feet if it weren't for this favour."

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "Who says I wouldn't have liked it?"

        scene e3s10-75 with dissolve
        hide e3s10_sadie_blink2
        sd "You didn't strike me as a feet guy."

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        menu:
            "Feet guy":
                $ e3s10_sadie_feet = True
                mc "The more you know, right?"

                scene e3s10-77 with dissolve
                hide e3s10_sadie_blink2
                sd "Weirdo."

                scene e3s10-75 with dissolve
                sd "You're lucky I like you."

                scene e3s10-71 with dissolve
                sd "This means that I can apply the things I've had in mind with you."

                scene e3s10-72 with dissolve
                show e3s10_sadie_blink2
                mc "Haha, you've had things in mind with me?"
                mc "And what kind of things?"

            "Not a feet guy":
                mc "You know, I wouldn't really call myself a feet guy."
                mc "But what I wouldn't do for your feet."

                scene e3s10-78 with dissolve
                hide e3s10_sadie_blink2
                sd "Haha, that's so corny, stop!"

                scene e3s10-75 with dissolve
                sd "I do appreciate the gesture though."

                scene e3s10-77 with dissolve
                sd "Duly noted, not a feet guy."

                scene e3s10-79 with dissolve
                sd "Damn it, and I had some things planned..."

                scene e3s10-72 with dissolve
                show e3s10_sadie_blink2
                mc "You're gonna have to plan some other exciting things then."
                mc "Because I am into exploring stuff."

                scene e3s10-78 with dissolve
                hide e3s10_sadie_blink2
                sd "Damn, I like that about you!"

                scene e3s10-71 with dissolve
                sd "I also love exploring."

                scene e3s10-72 with dissolve
                show e3s10_sadie_blink2
                mc "What kind of exploring are you thinking about?"

        scene e3s10-71 with dissolve
        hide e3s10_sadie_blink2
        sd "You know what?"
        sd "How about you bring me that phone and I will let you in on it."
        sd "Alright?"

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "And now she's making me work for it."

        scene e3s10-78 with dissolve
        hide e3s10_sadie_blink2
        sd "You're catching on fast, nice job!"

        scene e3s10-71 with dissolve
        sd "Might have to reward you for it if you do a good job."

        if affinity_spectrum > 0:
            scene e3s10-72 with dissolve
            show e3s10_sadie_blink2
            mc "And I might have to dominate you if I don't."

            scene e3s10-71 with dissolve
            hide e3s10_sadie_blink2
            sd "Look who's got a voice!"

            scene e3s10-75 with dissolve
            sd "We'll see the outcome then."

            scene e3s10-72 with dissolve
            show e3s10_sadie_blink2
            mc "Sure we will!"
    else:
        mc "I don't know if that's such a great idea [sd]."
        mc "If I get caught it's a whole lot worse than getting a phone confiscated."

        scene e3s10-71 with dissolve
        hide e3s10_sadie_blink2
        sd "That's why you make sure not to get caught, you know?"

        scene e3s10-80 with dissolve
        sd "Come on, pretty please?"

        scene e3s10-76 with dissolve
        sd "I really need it, I can't do any kind of college work without it."

        scene e3s10-74 with dissolve
        sd "I have everything in there."

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "Why didn't you tell that to the librarian?"

        scene e3s10-80 with dissolve
        hide e3s10_sadie_blink2
        sd "I really tried to reason with her but she wouldn't hear me out."
        sd "Please [mc]?"

        if e2s6_sadie_fwb == True:
            scene e3s10-78 with dissolve
            sd "I'll make it worth your while."

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "Alright, alright, I'll see what I can do."

        scene e3s10-78 with dissolve
        hide e3s10_sadie_blink2
        sd "Thanks, you're the best!"

        scene e3s10-72 with dissolve
        show e3s10_sadie_blink2
        mc "But if I get caught, you're the one who gets the blame."

        scene e3s10-75 with dissolve
        hide e3s10_sadie_blink2
        sd "Yeah, for sure!"

    scene e3s10-81 with dissolve
    hide e3s10_sadie_blink2
    pause

    jump e3s11
return
