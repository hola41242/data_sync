
# Scene 2 - Monday Morning (Monday) ############################################

label e3s2:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s2-01 with Dissolve(2.0)
    play music invisible_light
    pause

    scene e3s2-02 with dissolve
    pause

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Hey son!"
    jo "What's going on?"

    scene e3s2-04 with dissolve
    hide e3s2_mc_blink1
    mc "Hey Dad!"
    mc "Just woke up."

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Oh, long night?"

    scene e3s2-05 with dissolve
    hide e3s2_mc_blink1
    mc "Yeah, I went to a friend's birthday party."

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "I'm glad to hear you're making friends and having fun."

    scene e3s2-06 with dissolve
    hide e3s2_mc_blink1
    mc "Yeah..."

    scene e3s2-05 with dissolve
    mc "How have you been?"

    scene e3s2-04 with dissolve
    mc "I'm sorry I didn't call home."

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Don't worry son."
    jo "You're in college!"
    jo "I was expecting you to be partying this weekend, that's why I didn't really call."

    scene e3s2-05 with dissolve
    hide e3s2_mc_blink1
    mc "So... what's up?"

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Well, just got a ticket to the new Killer in Action movie in theatres."

    scene e3s2-07 with dissolve
    hide e3s2_mc_blink1
    mc "No way!"
    mc "It actually came out?"

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Haha, yeah, it did!"
    jo "It's on this saturday, I was wondering if you'd come home to watch it with me."

    scene e3s2-06 with dissolve
    hide e3s2_mc_blink1
    mc "Damn Dad, I wasn't expecting this."

    scene e3s2-05 with dissolve
    mc "Yeah, I think I will come home to watch it with you."

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "It's all set then!"

    scene e3s2-04 with dissolve
    hide e3s2_mc_blink1
    mc "How's the weather back there?"

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Oh, it's been sunny!"
    jo "I think I heard on the TV that it's probably going to rain next week."

    scene e3s2-06 with dissolve
    hide e3s2_mc_blink1
    mc "I see."

    scene e3s2-08 with dissolve
    pause

    scene e3s2-06 with dissolve
    mc "Hey Dad, talk to you later, alright?"

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Sure son, I'm one phone call away if you need to talk."

    scene e3s2-04 with dissolve
    hide e3s2_mc_blink1
    mc "Thanks Dad, bye!"

    scene e3s2-03 with dissolve
    show e3s2_mc_blink1
    jo "Good bye son."

    scene e3s2-09 with dissolve
    hide e3s2_mc_blink1
    pause

    scene e3s2-10 with dissolve
    mc "Hey [nt], how's it going?"

    scene e3s2-11 with dissolve
    nt "Hey dude!"
    nt "Just got back from home."

    scene e3s2-12 with dissolve
    mc "I see you got a new haircut."

    scene e3s2-13 with dissolve
    nt "Yeah, what do you think?"
    nt "Does it suit me?"

    scene e3s2-10 with dissolve
    menu:
        "Suits him":
            call extrovert_affinity_check from _call_extrovert_affinity_check_53
            call color_check from _call_color_check_101

            scene e3s2-12 with dissolve
            mc "I think it really suits you."

            scene e3s2-13 with dissolve
            nt "Really?"

            scene e3s2-12 with dissolve
            mc "Yeah."
            mc "The one you've had beforehand was a little weird."

            scene e3s2-11 with dissolve
            nt "Haha, I understand."
        "Doesn't suit him":
            call introvert_affinity_check from _call_introvert_affinity_check_45
            call color_check from _call_color_check_102

            scene e3s2-14 with dissolve
            mc "Eh... I don't know bro."
            mc "I don't think it's really your style."

            scene e3s2-13 with dissolve
            nt "I get it."
            nt "Guess I'll have to wear a cap for the next few months."

            scene e3s2-12 with dissolve
            mc "Haha, it's not *that* bad."
            mc "Don't worry."

    scene e3s2-15 with dissolve
    pause

    scene e3s2-16 with dissolve
    nt "So, what happened while I was away?"

    scene e3s2-17 with dissolve
    mc "Well..."

    stop music fadeout 2.0
    scene e3s2-18 with dissolve
    pause

    if e2f2_tiffany_refuse == False:
        scene e3s2-19 with wipeleft
        play music sun_sets_on_a_protagonist
        pause

        scene e3s2-20 with dissolve
        tf "Hey there!"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "Oh, hi Tiffany!"

        scene e3s2-22 with dissolve
        hide e3s2_tiffany_blink1
        tf "How are you?"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "Well, I'm pretty fine."
        mc "Just grabbing a book for my next class."
        mc "What's up with you?"

        scene e3s2-23 with dissolve
        hide e3s2_tiffany_blink1
        tf "Just hung out with a friend and now I'm also going to class."

        scene e3s2-22 with dissolve
        tf "What do you have?"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "English I think."
        mc "You?"

        scene e3s2-24 with dissolve
        hide e3s2_tiffany_blink1
        tf "Math."

        scene e3s2-23 with dissolve
        tf "I'm not too excited about it but whatever."

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "You don't like math?"

        scene e3s2-23 with dissolve
        hide e3s2_tiffany_blink1
        tf "Who does?"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "My dorm mate."

        scene e3s2-25 with dissolve
        hide e3s2_tiffany_blink1
        tf "Haha, he's a nerd then."

        scene e3s2-22 with dissolve
        tf "Well, I'll catch you later [mc]!"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "Alright [tf], take care!"

        scene e3s2-22 with dissolve
        hide e3s2_tiffany_blink1
        tf "Maybe we can hang out some time."

        scene e3s2-23 with dissolve
        tf "Bye!"

        scene e3s2-21 with dissolve
        show e3s2_tiffany_blink1
        mc "See you!"

        scene e3s2-26 with dissolve
        menu:
            "Check her out":
                $ tiffany_trust += 1

                stop music fadeout 2.0
                scene e3s2-27 with dissolve
                pause

            "Don't check her out":
                stop music fadeout 2.0
                pass

    scene e3s2-40 with wipeleft
    play music iwnlylmd
    pause

    scene e3s2-28 with dissolve
    pause

    scene e3s2-41 with dissolve
    pause

    scene e3s2-29 with dissolve
    pause

    scene e3s2-31 with dissolve
    cl "[mc], hi!"

    scene e3s2-32 with dissolve
    cl "Thought you wouldn't show up."

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "Haha, why is that?"

    scene e3s2-32 with dissolve
    hide e3s2_cleo_blink1
    cl "I think you're a couple of minutes late."

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "Oh, my bad then."
    mc "But the teacher's not here either so am I really late?"

    scene e3s2-33 with dissolve
    hide e3s2_cleo_blink1
    cl "Haha, fair point."

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "So, how have you been?"

    scene e3s2-34 with dissolve
    hide e3s2_cleo_blink1
    cl "Pretty good I must say."

    scene e3s2-35 with dissolve
    cl "I made a new friend yesterday."

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    if affinity_spectrum > 0:
        mc "Haha!"
        mc "I'm glad!"

        scene e3s2-35 with dissolve
        hide e3s2_cleo_blink1
        cl "Yeah."

        scene e3s2-36 with dissolve
        cl "Hey, so, in the end, what did you get [ke]?"

        scene e3s2-30 with dissolve
        show e3s2_cleo_blink1
        mc "Oh, well... I got him a bottle of booze."
        mc "Gotta give credit to Jon, he got him a bottle of booze as well."

        scene e3s2-33 with dissolve
        hide e3s2_cleo_blink1
        cl "Haha, no way!"

        scene e3s2-30 with dissolve
        show e3s2_cleo_blink1
    else:
        mc "Oh, that's nice."

        scene e3s2-35 with dissolve
        hide e3s2_cleo_blink1
        cl "Yeah."

        scene e3s2-36 with dissolve
        cl "Hey, what did [ke] think of our gift?"

        scene e3s2-30 with dissolve
        show e3s2_cleo_blink1
        mc "He loved it!"

    mc "I've also found out why he had those conditions for a gift."
    mc "He's actually rich."

    scene e3s2-37 with dissolve
    hide e3s2_cleo_blink1
    cl "What? No way."

    scene e3s2-38 with dissolve
    mc "Yes way."
    mc "I went to Jon's apartment wearing all casual clothes while he was dressed pretty formally."
    mc "He told me afterwards that he's rich and I should have gotten a suit."

    scene e3s2-39 with dissolve
    cl "Oh, so what did you do?"

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "Well... he lent me one of his old suits."
    mc "Which by the way was really small."
    mc "Come to think of it, I think it tore when I took it off."

    scene e3s2-32 with dissolve
    hide e3s2_cleo_blink1
    cl "Haha!"
    cl "Wasn't he mad?"

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "Nah, he wanted to throw it anyways."

    scene e3s2-34 with dissolve
    hide e3s2_cleo_blink1
    cl "And... how was the party amongst rich people?"

    scene e3s2-30 with dissolve
    show e3s2_cleo_blink1
    mc "It was actually pretty chill if you can believe it."
    mc "They know how to party I'll give them that."

    scene e3s2-32 with dissolve
    hide e3s2_cleo_blink1
    cl "Haha, I'm glad!"

    stop music fadeout 2.0
    scene e3s2-42 with dissolve
    pause

    jump e3s3

return
