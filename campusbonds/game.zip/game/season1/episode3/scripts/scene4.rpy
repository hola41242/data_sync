
# Scene 4 - Fishy business #####################################################

if persistent.fight_difficulty == 0:
    default e3s4_mc_health = 7
    default e3s4_spencer_health = 7
if persistent.fight_difficulty == 1:
    default e3s4_mc_health = 7
    default e3s4_spencer_health = 9
if persistent.fight_difficulty == 2:
    default e3s4_mc_health = 6
    default e3s4_spencer_health = 12

default e3s4_positive_fight = ["e3s4-23", "e3s4-25", "e3s4-26", "e3s4-28"]
default e3s4_negative_fight = ["e3s4-22", "e3s4-24", "e3s4-27", "e3s4-29"]

default last_fight_scene = 0
default fight_scene = 0

label e3s4:
    $ time_start = 0
    $ time_max = 1.0
    $ time_max = 0.01

    scene black with Dissolve(2.0)

    scene e3s4-01 with Dissolve(2.0)
    sp "So... do you think he stole it?"

    scene e3s4-02 with dissolve
    unknown "Didn't really look that intimidating to me when we first saw him."

    scene e3s4-03 with dissolve
    sp "Don't let yourself be fooled."

    scene e3s4-01 with dissolve
    sp "At this point, I'm exploring every possibility."

    scene e3s4-04 with dissolve
    unknown "Okay?"
    unknown "So, what does he have to do with it?"

    scene e3s4-05 with dissolve
    sp "Are you kidding me?"
    sp "He's been giving me weird vibes ever since I saw him."

    scene e3s4-02 with dissolve
    unknown "Do you think he's with the feds?"

    scene e3s4-01 with dissolve
    sp "No, he wouldn't make it that obvious for us."

    scene e3s4-03 with dissolve
    sp "And I don't want your chances to be affected by this."

    scene e3s4-04 with dissolve
    unknown "What do you have in mind?"

    scene e3s4-06 with dissolve
    sp "Follow me."

    scene e3s4-07 with dissolve
    pause

    scene e3s4-08 with dissolve
    pause

    scene black with Dissolve(2.0)

    scene e3s4-09 with Dissolve(2.0)
    pause

    scene e3s4-10 with dissolve
    pause

    scene e3s4-11 with dissolve
    pause

    play sound punch
    play music coalescense
    scene e3s4-12 with vpunch
    pause

    scene e3s4-14 with dissolve
    sp "Hello, freshie!"
    sp "Heard you've been snooping around my business."

    scene e3s4-13 with dissolve
    show e3s4_spencer_blink1
    mc "Around your what?"

    scene e3s4-15 with dissolve
    hide e3s4_spencer_blink1
    sp "Cut the crap, I know you have it."
    sp "And I want it back!"

    scene e3s4-13 with dissolve
    show e3s4_spencer_blink1
    mc "Huh, have what?"

    scene e3s4-16 with dissolve
    hide e3s4_spencer_blink1
    unknown "He's playing dumb, he definitely has it."

    scene e3s4-13 with dissolve
    show e3s4_spencer_blink1
    mc "What the hell are you guys talking about?"

    scene e3s4-17 with dissolve
    hide e3s4_spencer_blink1
    sp "Maybe this will refresh your memory."

    play sound woosh
    scene e3s4-18 with vpunch
    pause

    scene e3s4-19 with dissolve
    sp "Tough guy, huh?"
    sp "Alright, bring it on!"
    sp "We have some unfinished business from earlier."

    scene e3s4-20 with dissolve
    sp "Don't intervine [kv], he's all mine."

    scene e3s4-21 with dissolve

    if persistent.fight == 0:
        while e3s4_spencer_health > 0 and e3s4_mc_health > 0:
            call qte from _call_qte_32

            if qte == True:
                $ e3s4_spencer_health = max(0, e3s4_spencer_health - total_damage)

                $ fight_scene = renpy.random.choice(e3s4_positive_fight)

                while last_fight_scene == fight_scene:
                    $ fight_scene = renpy.random.choice(e3s4_positive_fight)

                play sound punch
                scene expression fight_scene with vpunch

                $ last_fight_scene = fight_scene
            else:
                $ e3s4_mc_health -= 1

                $ fight_scene = renpy.random.choice(e3s4_negative_fight)

                while last_fight_scene == fight_scene:
                    $ fight_scene = renpy.random.choice(e3s4_negative_fight)

                play sound punch
                show miss_screen at miss_anim
                show expression fight_scene behind miss_screen with vpunch

                $ last_fight_scene = fight_scene

        if qte_neg_count == 0:
            $ strength += 1
            if persistent.sc_gallery_9_unlocked == False:
                $ persistent.sc_gallery_9_unlocked = True
                $ renpy.show_screen("render_notify")
                $ persistent.scarlett9 = True
                python:
                    update_scarlett_list()

        if e3s4_spencer_health == 0:
            $ qte_neg_count == 0
            $ qte_pos_count == 0

            $ e3s4_fight = True
            pause (1.0)

            play sound punch
            scene e3s4-30 with vpunch
            pause

            scene e3s4-31 with dissolve
            pause

        if e3s4_mc_health == 0:
            $ qte_neg_count == 0
            $ qte_pos_count == 0

            $ e3s4_fight = False
            pause (1.0)

            play sound punch
            scene e3s4-35 with vpunch
            pause

            scene e3s4-36 with dissolve
            pause
    else:
        pause

        play sound punch
        scene e3s4-22 with vpunch
        pause

        play sound punch
        scene e3s4-23 with vpunch
        pause

        play sound punch
        scene e3s4-24 with vpunch
        pause

        play sound punch
        scene e3s4-25 with vpunch
        pause

        play sound punch
        scene e3s4-26 with vpunch
        pause

        play sound punch
        scene e3s4-27 with vpunch
        pause

        play sound punch
        scene e3s4-28 with vpunch
        pause

        play sound punch
        scene e3s4-29 with vpunch
        pause

        play sound punch
        scene e3s4-35 with vpunch
        pause

        scene e3s4-36 with dissolve
        pause

        $ e3s4_fight = False

    scene e3s4-33 with dissolve
    pause

    scene e3s4-32 with dissolve
    pause

    scene e3s4-34 with dissolve
    sp "You didn't think this would be a fair fight like in the ring, did you?"

    play sound punch
    scene e3s4-37 with vpunch
    pause

    scene e3s4-34 with dissolve
    sp "It seems to me like you're ready to talk now."

    play sound punch
    play music nerve_damage
    scene e3s4-38 with vpunch
    pause

    scene e3s4-39 with dissolve
    pause

    play sound punch
    scene e3s4-40 with vpunch
    pause

    scene e3s4-41 with dissolve
    unknown "Two on one?"
    unknown "With a knife?"
    unknown "Doesn't seem that fair to me."

    scene e3s4-42 with dissolve
    sp "..."

    scene e3s4-43 with dissolve
    unknown "Oh, what?"
    unknown "Don't tell me you were expecting this to be a fair fight."

    scene e3s4-44 with dissolve
    sp "This isn't over."
    sp "Your boyfriend won't be with you forever."

    stop music fadeout 2.0
    scene e3s4-45 with dissolve
    pause

    play music sun_sets_on_a_protagonist
    scene e3s4-46 with dissolve
    mc "What the hell was this all about...?"

    scene e3s4-47 with dissolve
    unknown "You don't know these guys?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "I only know the guy with the knife."
    mc "The one you just jumped."

    scene e3s4-49 with dissolve
    hide e3s4_mike_blink1
    unknown "[sp]?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "Do you know him?"

    scene e3s4-50 with dissolve
    hide e3s4_mike_blink1
    unknown "Let's just say we have some history together."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "I see."
    mc "Thanks for helping me."

    scene e3s4-51 with dissolve
    hide e3s4_mike_blink1
    unknown "Don't worry about it."

    scene e3s4-49 with dissolve
    unknown "Why were they after you?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "He was talking about something, I didn't really understand."
    mc "He thought I had it."

    scene e3s4-51 with dissolve
    hide e3s4_mike_blink1
    unknown "I understand."

    scene e3s4-49 with dissolve
    unknown "So... do you have it, or?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "No, I don't even know what I was supposed to have."

    scene e3s4-51 with dissolve
    hide e3s4_mike_blink1
    unknown "Oh, so you're not involved with him."
    unknown "I understand now."

    scene e3s4-52 with dissolve
    unknown "I'm [mi]."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "Nice to meet you [mi], I'm [mc]."

    scene e3s4-53 with dissolve
    hide e3s4_mike_blink1
    mi "You almost got your ass kicked."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    if e3s4_fight == True:
        mc "I could've beat him."
    else:
        mc "..."

    scene e3s4-49 with dissolve
    hide e3s4_mike_blink1
    mi "Still, you landed some good punches."
    mi "Where did you learn to fight?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "Well, I used to fight for ‘a living'."
    mc "But I got a really bad injury which stopped me from pursuing it further."

    scene e3s4-51 with dissolve
    hide e3s4_mike_blink1
    mi "Oh... that sucks."
    mi "Where?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "On the back of my head."

    scene e3s4-51 with dissolve
    hide e3s4_mike_blink1
    mi "Holy shit."

    scene e3s4-49 with dissolve
    mi "You're lucky to be alive then."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "I see you know a thing or two about fighting as well."

    scene e3s4-53 with dissolve
    hide e3s4_mike_blink1
    mi "Yeah, I'm fighting for a living."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "That's cool."

    scene e3s4-53 with dissolve
    hide e3s4_mike_blink1
    mi "Yeah."

    scene e3s4-52 with dissolve
    mi "I could teach you a thing or two if you're down."

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "Yeah, sure dude!"
    mc "Anyone who's ready to jump head first on a guy with a knife is a badass."

    scene e3s4-54 with dissolve
    hide e3s4_mike_blink1
    mi "Haha, I'm not a badass."
    mi "Just a fellow citizen doing his job protecting his country."

    scene e3s4-49 with dissolve
    mi "Hey, I've got to get somewhere."

    scene e3s4-52 with dissolve
    mi "Here's my number, get in touch with me and we'll grab a drink to talk about some sparring sessions, alright?"

    scene e3s4-48 with dissolve
    show e3s4_mike_blink1
    mc "Sure, no problem."
    mc "Thanks dude!"

    scene e3s4-53 with dissolve
    hide e3s4_mike_blink1
    mi "No worries."
    mi "Be safe."

    scene e3s4-55 with dissolve
    pause

    scene e3s4-56 with dissolve
    mc "*What the hell did [sp] want from me...?*"

    scene e3s4-57 with dissolve
    pause

    jump e3s5
return
