
# Scene 16 - Someone familiar? (Or not?) #######################################

label e3s16:
    scene e3s16-01 with wipeleft
    play music marathon_man
    pause

    scene e3s16-02 with dissolve
    pause

    scene e3s16-03 with dissolve
    mc "Please, after you!"

    scene e3s16-04 with dissolve
    br "Thank you!"

    if e2s10_br_number == True:
        scene e3s16-05 with dissolve
        br "Wait... [mc]?"

        scene e3s16-06 with dissolve
        show e3s16_bridget_blink1
        menu:
            "Check her out":
                $ bridget_trust -= 1

                scene e3s16-11 with dissolve
                hide e3s16_bridget_blink1
                pause(0.5)

                scene e3s16-12 with dissolve
                br "Oh no, no, no!"
                br "Eyes up here, mister."

            "Don't risk it":
                mc "Huh?"

        scene e3s16-07 with dissolve
        hide e3s16_bridget_blink1
        br "You're the guy from the club!"

        scene e3s16-08 with dissolve
        br "The one I gave my number to!"

        scene e3s16-06 with dissolve
        show e3s16_bridget_blink1
        mc "Maybe you're confusing me."

        scene e3s16-08 with dissolve
        hide e3s16_bridget_blink1
        br "I did not give my number to anybody else that night."
        br "If there's one guy I remember it's the one there."

        scene e3s16-06 with dissolve
        show e3s16_bridget_blink1
        mc "*Oh shit.*"

        scene e3s16-10 with dissolve
        hide e3s16_bridget_blink1
        br "What the hell are you doing here?"

        scene e3s16-09 with dissolve
        show e3s16_bridget_blink2
        menu:
            "Teaching" if affinity_spectrum >= 0:
                call extrovert_affinity_check from _call_extrovert_affinity_check_51
                call color_check from _call_color_check_98
                mc "I'm... teaching?"

                scene e3s16-08 with dissolve
                hide e3s16_bridget_blink2
                br "You're teaching..."
                br "In my class?"

                scene e3s16-06 with dissolve
                show e3s16_bridget_blink1
                mc "No... I meant..."
                mc "I got the class wrong."

                scene e3s16-15 with dissolve
                hide e3s16_bridget_blink1
                br "Stop bullshitting me!"

            "Going to class":
                mc "What am I doing here?"
                mc "I'm a student."
                mc "I'm going to class."

        scene e3s16-14 with dissolve
        hide e3s16_bridget_blink2
        br "I can't believe it."
        br "Who did I just give my number to..."

        scene e3s16-15 with dissolve
        br "Listen, you have to delete that number from your phone."
        br "And that's non-negotiable!"

        scene e3s16-13 with dissolve
        br "Now hurry up and get to class before someone gets the wrong idea about this."

        scene e3s16-16 with dissolve
        pause

    scene e3s16-17 with dissolve
    mc "Hey [tr]!"

    scene e3s16-19 with dissolve
    tr "Hello [mc]."

    scene e3s16-18 with dissolve
    show e3s16_tracy_blink1
    mc "Looks like we have a shared class."

    scene e3s16-20 with dissolve
    hide e3s16_tracy_blink1
    tr "Looks like we do, yeah!"

    scene e3s16-18 with dissolve
    show e3s16_tracy_blink1
    mc "How have you been?"

    scene e3s16-19 with dissolve
    hide e3s16_tracy_blink1
    tr "I've been alright."

    scene e3s16-21 with dissolve
    tr "Mostly been studying."

    scene e3s16-18 with dissolve
    show e3s16_tracy_blink1
    mc "I didn't see you as a studying student."

    scene e3s16-20 with dissolve
    hide e3s16_tracy_blink1
    tr "Oh don't worry, I'm not that kind."

    scene e3s16-19 with dissolve
    tr "I just wanna make something out of my future, that's all."

    scene e3s16-18 with dissolve
    show e3s16_tracy_blink1
    mc "I see, fair enough."

    scene e3s16-19 with dissolve
    hide e3s16_tracy_blink1
    tr "What's going on with you?"

    scene e3s16-22 with dissolve
    tr "Heard you and [sd] had a fight."

    scene e3s16-25 with dissolve
    show e3s16_tracy_blink2
    if e3f3_tracy == 3:
        mc "So, you do talk about boys now."

        scene e3s16-21 with dissolve
        hide e3s16_tracy_blink2
        tr "Yeah, about you!"

        scene e3s16-25 with dissolve
        show e3s16_tracy_blink2
    else:
        pass

    if affinity_spectrum > 0:
        mc "Damn the rumors spread fast..."

    mc "Yeah, we did fight."
    mc "What about that?"

    scene e3s16-19 with dissolve
    hide e3s16_tracy_blink2
    tr "Hey, it's none of my business."

    scene e3s16-24 with dissolve
    tr "What's between you guys is between you."

    scene e3s16-22 with dissolve
    if sadie_trust > 5:
        tr "But listen, [sd] cares about you."
        tr "She just made a mistake, she can't stop thinking about it."
        tr "You really got to her."

        scene e3s16-23 with dissolve
        tr "So, maybe just hear her out, okay?"
    else:
        tr "Just heard that she's sorry about it."
        tr "And she'd like to talk to you about that."

        scene e3s16-25 with dissolve
        show e3s16_tracy_blink2
        mc "Maybe she should have came to me in person."

        scene e3s16-23 with dissolve
        hide e3s16_tracy_blink2
        tr "I know, she will don't worry."

        scene e3s16-22 with dissolve
        tr "She told me not to tell you but I couldn't help it."
        tr "I don't want my friends to be mad at each other."

        scene e3s16-23 with dissolve
        tr "So, when the time comes, just hear her out, alright?"

    scene e3s16-25 with dissolve
    show e3s16_tracy_blink2
    mc "Alright [tr], I will do that."

    scene e3s16-22 with dissolve
    hide e3s16_tracy_blink2
    tr "Yeah!"

    scene e3s16-26 with dissolve
    pause

    if e2s10_br_number == True:
        scene e3s16-27 with dissolve
        mc "*Now... what should I do about the other problem...*"
        mc "*[br]'s number.*"

        scene e3s16-28 with dissolve
        menu:
            "Delete her number":
                mc "*I better delete it when I get my phone back, it's not like anything's going to happen after that.*"

            "Don't delete it":
                $ e3s16_bridget_path = True

                scene e3s16-27 with dissolve
                mc "*Hell no, I'm not deleting her number.*"
                mc "*I don't even have my phone with me.*"

                scene e3s16-28 with dissolve
                mc "*If there's a slight chance of something more happening between us, I'm taking it.*"

                scene e3s16-29 with dissolve
                mc "*Plus, there's nothing wrong in having a teacher's phone number, right?*"

                scene e3s16-27 with dissolve
                pause

    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s16-27 with Dissolve(2.0)
    pause

    scene e3s16-30 with dissolve
    jon "Yo, what's up, 'dude'?"

    scene e3s16-31 with dissolve
    mc "[jon]?"
    mc "What are you doing here?"

    scene e3s16-32 with dissolve
    jon "How long are you gonna ignore me for, man?"
    jon "I left you like 1000 messages, what's wrong?"

    scene e3s16-33 with dissolve
    show e3s16_jon_blink1
    mc "Nothing's wrong."

    scene e3s16-32 with dissolve
    hide e3s16_jon_blink1
    jon "Then why are you acting so weird lately?"

    scene e3s16-35 with dissolve
    jon "Ever since our last party, you kind of stopped hanging out with us altogether."

    scene e3s16-33 with dissolve
    show e3s16_jon_blink1
    mc "I lost my phone in the library, alright?"

    scene e3s16-34 with dissolve
    hide e3s16_jon_blink1
    jon "Damn... how did that happen?"
    jon "And why didn't the librarian give it back to you?"

    scene e3s16-33 with dissolve
    show e3s16_jon_blink1
    mc "I should pay her a visit and see if she's found it."

    scene e3s16-35 with dissolve
    hide e3s16_jon_blink1
    jon "Alright?"

    scene e3s16-36 with dissolve
    jon "Wanna hang out later when you find your phone?"

    scene e3s16-33 with dissolve
    show e3s16_jon_blink1
    mc "I'll see if I'm free."

    scene e3s16-37 with dissolve
    hide e3s16_jon_blink1
    pause

    stop music fadeout 2.0
    scene e3s16-38 with dissolve
    pause

    jump e3s17
return
