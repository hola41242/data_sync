
# Freeroam 3 screens ###########################################################

# couch ########################################################################
screen e3f3_couch():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    if e3f3_claire > 0 and e3f3_dj == True and e3f3_tracy > 0 and e3f3_charlie == True and e3f3_ken_roman == True and e3f3_scarlett == True:
        if e3f3_guys == False:
            add "e3f3-01_1"
        else:
            add "e3f3-01_2"
    else:
        add "e3f3-01"

    # Clickables
    if e3f3_claire == 0 or e3f3_claire == 2:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/couch/claire_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/couch/claire_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_claire")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_claire")

    if e3f3_claire > 0 and e3f3_dj == True and e3f3_tracy > 0 and e3f3_charlie == True and e3f3_ken_roman == True and e3f3_scarlett == True:
        if e3f3_guys == False:
            imagebutton:
                idle im.Scale("season1/episode3/images/freeroam3/couch/guys_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode3/images/freeroam3/couch/guys_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e3f3_guys")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e3f3_guys")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/couch/dj_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/couch/dj_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_dj")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_dj")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/couch/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/couch/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_pool")

    if persistent.fr_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/couch/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/couch/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_8_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca8", True), Function(update_francesca_list)]

# dj ########################################################################
screen e3f3_dj():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    add "e3f3-02"

    # Clickables
    if e3f3_dj == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/dj/dj_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/dj/dj_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_dj_npc")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_dj_npc")

    if persistent.mixed_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/dj/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/dj/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_9_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed9", True), Function(update_mixed_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/dj/couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/dj/couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/dj/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/dj/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_vending")

# vending ######################################################################
screen e3f3_vending():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    if e3f3_ken_roman == False:
        if e3f3_tracy == 0 or e3f3_tracy == 2:
            add "e3f3-03"
        else:
            add "e3f3-03_1"
    else:
        if e3f3_tracy == 0 or e3f3_tracy == 2:
            add "e3f3-03_2"
        else:
            add "e3f3-03_3"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/vending/bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/vending/bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_bar")

    if not e3f3_tracy == 0 or e3f3_tracy == 2:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/vending/vending_table_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/vending/vending_table_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_vending_table")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_vending_table")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/vending/dj_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/vending/dj_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_dj")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_dj")

    # Clickables
    if e3f3_tracy == 0 or e3f3_tracy == 2:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/vending/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/vending/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_tracy")

# pool ######################################################################
screen e3f3_pool():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    add "e3f3-04"

    # Clickables
    if e3f3_charlie == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/pool/charlie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/pool/charlie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_charlie")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_charlie")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/pool/couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/pool/couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/pool/pool_couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/pool/pool_couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_pool_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_pool_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/pool/staff_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/pool/staff_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_staff")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_staff")

# staff ########################################################################
screen e3f3_staff():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    add "e3f3-05"

    # Clickables

    if persistent.sd_gallery_10_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/staff/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/staff/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_10_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_10_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie10", True), Function(update_sadie_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/staff/bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/staff/bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_bar")

    if e3f3_guys == True:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/staff/bathroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/staff/bathroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_jordan")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_jordan")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/staff/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/staff/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_pool")

# bar ##########################################################################
screen e3f3_bar():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    if e3f3_ken_roman == False:
        add "e3f3-06"
    else:
        if e3f3_scarlett_angry == False:
            add "e3f3-06_1"
        else:
            add "e3f3-06_2"

    # Clickables
    if e3f3_ken_roman == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/bar/ken_roman_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/bar/ken_roman_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_ken_roman")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_ken_roman")

    if e3f3_ken_roman == True and e3f3_scarlett == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/bar/scarlett_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/bar/scarlett_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_scarlett")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_scarlett")

    if e3f3_claire == 1 and e3f3_ken_roman == True:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/bar/claire_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/bar/claire_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f3_claire")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f3_claire")

    if persistent.tr_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/bar/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/bar/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_9_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy9", True), Function(update_tracy_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/bar/staff_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/bar/staff_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_staff")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_staff")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/bar/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/bar/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_vending")

# pool_couch ###################################################################
screen e3f3_pool_couch():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    add "e3f3-07"

    # Clickables

    if persistent.mixed_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/pool_couch/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/pool_couch/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_8_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed8", True), Function(update_mixed_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/pool_couch/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/pool_couch/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_pool")

# vending_table ################################################################
screen e3f3_vending_table():

    $ renpy.random.shuffle(e3f3_tracks)
    modal True

    add "e3f3-08"

    # Clickables

    if persistent.cl_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam3/vending_table/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam3/vending_table/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_9_unlocked", True), SetVariable("persistent.e3f3_collected_p", persistent.e3f3_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo9", True), Function(update_cleo_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam3/vending_table/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam3/vending_table/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f3_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f3_vending")
