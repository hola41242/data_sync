
# Variables

default e3f2_hallway_right_door = False
default e3f2_guitar = False
default e3f2_hallway3_door = False
default e3f2_tracy = False
default e3f2_look = False
default e3f2_ken_jordan = False

default e3f2_explore = 0

# Freeroam Collected Photos #

default persistent.e3f2_collected_p = 0
default persistent.e3f2_collected_tp = 6

# Freeroam 1 ###################################################################
label e3f2:
    define e3f2_tracks = ["bloom.ogg", "border_blaster.ogg", "bpam.ogg", "darien_gap.ogg", "frannie.ogg", "inertia.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "marathon_man.ogg", "one_fine_day.ogg", "onfire.ogg", "pioneers.ogg", "serenity.ogg", "solo_acoustic_guitar.ogg", "sun_sets_on_a_protagonist.ogg", "sundown.ogg", "tidalwave.ogg", "travel_light.ogg", "twenty_twenty.ogg", "whhhsfs.ogg", "with_a_whimper.ogg", "wonder_under.ogg"]
    $ renpy.random.shuffle(e3f2_tracks)
    $ renpy.music.queue (e3f2_tracks, loop=True)

    scene e3f2-01 with wipeleft
    mc "*Hmm... I wonder where [nt] is.*"
    mc "*I guess I have some time to kill before going to bed.*"

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Go to bed.")
    $ optional_quests.append("Explore the place.")
    $ optional_quests.append("Practice the guitar.")

    scene e3f2-01 with dissolve

    call screen e3f2_main
    hide e3f2-01
return

# Map ##########################################################################

# Main ###
label e3f2_main:
    scene e3f2-01
    call screen e3f2_main with dissolve
return

# Left ###
label e3f2_left:
    scene e3f2-02
    call screen e3f2_left with dissolve
return

label e3f2_guitar:
    if e3f2_guitar == False:
        mc "*The guitar from college rock.*"
        mc "*[ev] told us to practice every day in order to get better.*"
        mc "*Should I practice now?*"

        menu:
            "Practice now":
                scene e3f2-gu_02 with dissolve
                mc "*Alright, I'll practice now.*"

                scene e3f2-gu_01 with dissolve
                pause

                scene black with Dissolve(2.0)
                pause(1.0)

                $ e3f2_guitar = True
                $ guitar_skills += 1
                $ music_skills += 1

                $ optional_quests.remove("Practice the guitar.")

                scene e3f2-gu_02 with Dissolve(2.0)
                pause

            "Practice later":
                mc "*I'll practice later.*"
    else:
        mc "*I've already practiced tonight.*"
        mc "*Better save some juice for tomorrow.*"

    jump e3f2_left
return

label e3f2_bed:
    $ collected_p = persistent.e3f2_collected_p
    $ collected_tp = persistent.e3f2_collected_tp
    $ renpy.show_screen("render_count_notify_pers")

    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            mc "*I guess I should hit the sack.*"
            mc "*Not much left for me to do.*"
            mc "*I'll get changed and then go to bed.*"

            scene e3f2-bed_01 with dissolve
            pause

            jump e3s19

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e3f2_left
return

# Right ###
label e3f2_right:
    scene e3f2-03
    call screen e3f2_right with dissolve
return

# Hallway1 ###
label e3f2_hallway1:
    scene e3f2-04
    call screen e3f2_hallway1 with dissolve
return

# Hallway2 ###
label e3f2_hallway2:
    scene e3f2-05
    call screen e3f2_hallway2 with dissolve
return

label e3f2_tracy:
    mc "*Hmm... I wonder where [tr] is.*"
    mc "*The door is locked, nobody's here.*"
    mc "*It's been some time since we've hung out.*"

    $ e3f2_explore += 1

    if e3f2_explore == 4:
        $ optional_quests.remove("Explore the place.")

    $ e3f2_tracy = True

    scene e3f2-05 with Dissolve(0.1)

    jump e3f2_hallway2
return

# Hallway3 ###
label e3f2_hallway3:
    scene e3f2-06
    call screen e3f2_hallway3 with dissolve
return

label e3f2_hallway3_door:
    mc "*I can't believe you did this to us [jd].*"
    mc "*Why the hell would he get involved with [sp]?*"
    mc "*I knew it was weird when me and [jon] came here to get you and the guys to that house party.*"
    mc "*Back when I heard [sp]'s conversation here I didn't know whose room this was.*"
    mc "*But it really was your room...*"

    $ e3f2_explore += 1

    if affinity_spectrum > 0:
        if e3f2_explore == 4:
            $ optional_quests.remove("Explore the place.")
    else:
        if e3f2_explore == 3:
            $ optional_quests.remove("Explore the place.")

    $ e3f2_hallway3_door = True

    scene e3f2-06 with Dissolve(0.1)

    jump e3f2_hallway3
return

# Hallway Middle ###
label e3f2_hallway_middle:
    scene e3f2-09
    call screen e3f2_hallway_middle with dissolve
return

label e3f2_ken_jordan:
    scene e3f2-kj_01 with dissolve
    pause

    scene e3f2-kj_02 with dissolve
    ke "Hey, [mc]!"
    ke "What's up man?"

    scene e3f2-kj_03 with dissolve
    show e3f2_ken_blink1
    mc "Hi guys."

    scene e3f2-kj_04 with dissolve
    hide e3f2_ken_blink1
    jd "Hey..."

    scene e3f2-kj_08 with dissolve
    ke "Damn, it's been a while since we've seen you."

    scene e3f2-kj_06 with dissolve
    ke "How have you been?"

    scene e3f2-kj_03 with dissolve
    show e3f2_ken_blink1
    mc "Well... I've been keeping up with classes and stuff."

    scene e3f2-kj_07 with dissolve
    hide e3f2_ken_blink1
    ke "Damn man, didn't know you were a nerd!"

    scene e3f2-kj_03 with dissolve
    show e3f2_ken_blink1
    mc "Don't worry, I'm not."

    scene e3f2-kj_08 with dissolve
    hide e3f2_ken_blink1
    ke "Yeah..."

    scene e3f2-kj_05 with dissolve
    ke "Hey, we've been missing you at the parties!"

    scene e3f2-kj_06 with dissolve
    ke "Maybe you could come to our next one?"

    scene e3f2-kj_03 with dissolve
    show e3f2_ken_blink1
    mc "Yeah, I don't know right now."
    mc "I'll have to check my schedule."

    scene e3f2-kj_08 with dissolve
    hide e3f2_ken_blink1
    ke "Alright."

    scene e3f2-kj_05 with dissolve
    ke "See you around then."

    scene e3f2-kj_03 with dissolve
    show e3f2_ken_blink1
    mc "See you!"

    scene e3f2-kj_09 with dissolve
    hide e3f2_ken_blink1
    pause

    scene e3f2-kj_10 with dissolve
    ke "Hey, am I the only one noticing something off?"
    ke "Is there something wrong with him?"

    scene e3f2-kj_11 with dissolve
    jd "I don... I don't know."

    $ e3f2_explore += 1

    if affinity_spectrum > 0:
        if e3f2_explore == 4:
            $ optional_quests.remove("Explore the place.")
    else:
        if e3f2_explore == 3:
            $ optional_quests.remove("Explore the place.")

    $ e3f2_ken_jordan = True

    scene e3f2-kj_12 with dissolve
    ke "Weird..."
return

# Hallway Left ###
label e3f2_hallway_left:
    if e3f2_ken_jordan == False:
        call e3f2_ken_jordan from _call_e3f2_ken_jordan
    scene e3f2-07
    call screen e3f2_hallway_left with dissolve
return

# Hallway Right ###
label e3f2_hallway_right:
    if e3f2_ken_jordan == False:
        call e3f2_ken_jordan from _call_e3f2_ken_jordan_1
    if e3f2_hallway_right_door == False:
        scene e3f2-08_1
    else:
        scene e3f2-08
    call screen e3f2_hallway_right with dissolve
return

label e3f2_hallway_right_door:
    if e3f2_hallway_right_door == False:
        scene e3f2-st_01 with dissolve
        pause

        scene e3f2-st_02 with dissolve
        mc "*Huh?*"
        mc "*What's going on in there?*"

        menu:
            "Take a look":
                call extrovert_affinity_check from _call_extrovert_affinity_check_23
                call color_check from _call_color_check_47
                $ e3f2_look = True
                mc "*Alright, I'll take a look.*"

                scene e3f2-st_03 with dissolve
                pause

                scene e3f2-st_04 with dissolve
                pause

                if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
                    if persistent.disable_nsfw == True:
                        scene e3f2-st_05 with vpunch
                        unknown "Oh, fuck yeah!"

                        scene e3f2-st_06 with dissolve
                        unknown "Fuck me baby!"

                        scene e3f2-st_04 with dissolve
                        if affinity_spectrum > 0:
                            mc "*Yeah, right on!*"
                        else:
                            mc "*Jeez, lock your door, people*"

                        scene e3f2-st_05 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3f2-st_05_cen with vpunch
                            unknown "Oh, fuck yeah!"

                            scene e3f2-st_06_cen with dissolve
                            unknown "Fuck me baby!"

                            scene e3f2-st_04 with dissolve
                            if affinity_spectrum > 0:
                                mc "*Yeah, right on!*"
                            else:
                                mc "*Jeez, lock your door, people*"

                            scene e3f2-st_05_cen with dissolve
                            pause

                scene e3f2-st_03 with dissolve
                pause

            "Leave it alone":
                call introvert_affinity_check from _call_introvert_affinity_check_35
                call color_check from _call_color_check_80
                mc "*I'm not just gonna invade people's privacy.*"

        $ e3f2_explore += 1

        if affinity_spectrum > 0:
            if e3f2_explore == 4:
                $ optional_quests.remove("Explore the place.")
        else:
            if e3f2_explore == 3:
                $ optional_quests.remove("Explore the place.")

        $ e3f2_hallway_right_door = True

        if e3f2_hallway_right_door == False:
            scene e3f2-08_1 with dissolve
        else:
            scene e3f2-08 with dissolve
    else:
        if e3f2_look == True:
            mc "*They're really going at it.*"
        else:
            mc "*I said I'm not gonna invade people's privacy.*"

    jump e3f2_hallway_right
return
