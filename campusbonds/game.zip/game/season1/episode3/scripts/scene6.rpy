
# Scene 6 - Damned list ########################################################

label e3s6:
    scene e3s6-01 with wipeleft
    play music travel_light
    pause

    scene e3s6-02 with dissolve
    pause

    scene e3s6-03 with dissolve
    pause

    scene e3s6-04 with dissolve
    mc "*Homecoming?*"
    mc "*Didn't know they were hosting this party as well.*"
    mc "*Guess I'll have to choose a partner if I wanna go.*"

    scene e3s6-05 with dissolve
    jon "What's up dude?"

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Hey [jon]!"
    mc "Just going to a class."
    mc "What's up with you?"

    scene e3s6-07 with dissolve
    hide e3s6_jon_blink1
    jon "Well, I've been doing some prep for the welcome party."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Homecoming?"

    scene e3s6-08 with dissolve
    hide e3s6_jon_blink1
    jon "Nah, that's rookie."

    scene e3s6-09 with dissolve
    jon "For the party ragers!"

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Another one?"

    scene e3s6-10 with dissolve
    hide e3s6_jon_blink1
    jon "You still don't get the name ‘party ragers', do you?"

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "I guess I don't."
    mc "Hey, I've been meaning to talk to you about something that happened last night."

    scene e3s6-10 with dissolve
    hide e3s6_jon_blink1
    jon "Sorry to turn you down bro but there's a lot of work to do."

    scene e3s6-11 with dissolve
    jon "And I'd like you to help me."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Alright then, what can I do?"

    scene e3s6-13 with dissolve
    hide e3s6_jon_blink1
    jon "Can you go ahead and buy me some stuff?"
    jon "I have a list here with everything that we need."

    scene e3s6-12 with dissolve
    jon "I would have personally done it myself but Scarlett's assigned me to go and get some decorations."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "I see."
    mc "Alright then, no worries."
    mc "I'll go and get them."

    scene e3s6-11 with dissolve
    hide e3s6_jon_blink1
    jon "Perfect!"

    scene e3s6-10 with dissolve
    jon "Oh, by the way, the party is tonight."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Tonight??"

    if affinity_spectrum > 0:
        mc "Holy shit."

    scene e3s6-09 with dissolve
    hide e3s6_jon_blink1
    jon "Come now, don't shit your pants just yet."

    scene e3s6-07 with dissolve
    jon "The place isn't 100 percent ready but we'll manage."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Alright then, you do you."
    mc "I'll go and get the products."

    scene e3s6-10 with dissolve
    hide e3s6_jon_blink1
    jon "Wait, don't you need money to buy them?"

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Oh... right."

    scene e3s6-13 with dissolve
    hide e3s6_jon_blink1
    jon "Here, keep the change."

    scene e3s6-06 with dissolve
    show e3s6_jon_blink1
    mc "Alright, thanks!"

    stop music fadeout 2.0
    scene e3s6-14 with dissolve
    hide e3s6_jon_blink1
    pause

    scene e3s6-15 with wipeleft
    play music crazy_glue
    pause

    scene e3s6-16 with dissolve
    pause

    scene e3s6-17 with dissolve
    mc "*Alright.. let's see what we have here.*"

    scene e3s6-18 with dissolve
    mc "*No... this is not the right one.*"

    scene e3s6-17 with dissolve
    mc "*Where is it damn it...*"

    scene e3s6-19 with dissolve
    sd "Hello [mc]!"

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Oh, [sd]!"
    mc "What's up?"

    scene e3s6-21 with dissolve
    hide e3s6_sadie_blink1
    sd "Just came to buy some groceries."

    scene e3s6-22 with dissolve
    sd "What about you?"

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Oh, Jon's assigned me to buy items from this stupid list."
    mc "But I can't seem to find the right ones."

    if e1f5_refuse_sadie == True and e2s6_talk == False:
        $ e2s6_sadie_friends = True
        mc "Anyways, are you alright?"

        scene e3s6-21 with dissolve
        hide e3s6_sadie_blink1
        sd "Yeah, I'm fine."
        sd "Why do you ask?"

        scene e3s6-20 with dissolve
        show e3s6_sadie_blink1
        mc "Well... you were pissed at me a couple of days ago about, you know, the party."
        mc "What's with the sudden change of heart?"

        scene e3s6-27 with dissolve
        hide e3s6_sadie_blink1
        sd "Look..."

        scene e3s6-28 with dissolve
        sd "Let's just forget about that, alright?"
        sd "You're not into me, I get it, it's fine."
        sd "Just sucks that you weren't honest about it upfront."

        scene e3s6-27 with dissolve
        sd "But I've gotten over it, alright?"

        scene e3s6-28 with dissolve
        sd "Let's just not make too much drama out of it."

        show e3s6_sadie_blink1
        mc "Alright... I agree."

        scene e3s6-23 with dissolve
        hide e3s6_sadie_blink1
        sd "Anyways, coming back to your problem..."
        sd "Wanna know what I learned from most of the parties I went to?"
    else:
        scene e3s6-23 with dissolve
        hide e3s6_sadie_blink1
        sd "You know what I learned from most of the parties I went to?"

    scene e3s6-21 with dissolve
    sd "The brand doesn't really matter that much."

    scene e3s6-25 with dissolve
    sd "If you can't find the exact thing you're looking for, try to look for a replacement."

    scene e3s6-24 with dissolve
    sd "Most of the times it's either as good as the original or better."

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Thanks [sd]!"
    mc "I'll keep looking then."

    scene e3s6-25 with dissolve
    hide e3s6_sadie_blink1
    sd "I could help you if you want."

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Would you do that?"

    scene e3s6-21 with dissolve
    hide e3s6_sadie_blink1
    sd "Sure!"
    sd "Give me the list."

    scene e3s6-23 with dissolve
    sd "I know this store inside out."

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Here."

    scene e3s6-26 with dissolve
    hide e3s6_sadie_blink1
    sd "Mhm..."

    scene e3s6-27 with dissolve
    sd "Alright... yeah."
    sd "I know how to find these."

    scene e3s6-28 with dissolve
    sd "Keep looking for these first 3 things and I'll handle the rest."

    scene e3s6-20 with dissolve
    show e3s6_sadie_blink1
    mc "Alright!"
    mc "Let's split up."

    scene e3s6-29 with dissolve
    hide e3s6_sadie_blink1
    pause

    scene e3s6-30 with dissolve
    pause

    scene e3s6-31 with dissolve
    pause

    scene e3s6-32 with dissolve
    play sound phone_buzz
    pause

    scene e3s6-33 with dissolve
    pause

    nvl clear

    scene e3s6-34 with dissolve
    sd_nvl "Hey, [mc]!"
    n_nvl "What's up [sd]?"
    sd_nvl "I think I've found one of your items in the back."
    sd_nvl "Come here."
    n_nvl "Alright, I'm on my way!"

    if e2s6_sadie_romance == True:
        stop music fadeout 2.0
    scene e3s6-35 with dissolve
    pause

    scene e3s6-36 with dissolve
    mc "[sd]?"

    if e2s6_sadie_romance == True:
        call e3s6_sadie_sex from _call_e3s6_sadie_sex

        scene e3s6-77 with dissolve
        mc "*Huh?*"
        mc "*What's that?*"

        scene e3s6-78 with dissolve
        pause

        scene e3s6-79 with dissolve
        mc "Heh."

        scene e3s6-80 with dissolve
        mc "*Thank you [sd]!*"

        stop music fadeout 2.0
        scene e3s6-81 with dissolve
        pause
    else:
        scene e3s6-82 with dissolve
        sd "Yeah, I'm over here."
        sd "Just got the last item."

        scene e3s6-83 with dissolve
        show e3s6_sadie_blink4
        mc "Wait, you already have everything?"
        mc "How?"

        scene e3s6-84 with dissolve
        hide e3s6_sadie_blink4
        sd "As I said, I know this store inside out."

        scene e3s6-85 with dissolve
        sd "Here's your basket."

        scene e3s6-83 with dissolve
        show e3s6_sadie_blink4
        mc "My God, you're a life saver."

        scene e3s6-86 with dissolve
        hide e3s6_sadie_blink4
        sd "What can I say..."

        scene e3s6-87 with dissolve
        sd "You're welcome [mc]!"

        scene e3s6-84 with dissolve
        sd "Well... I gotta get going."
        sd "I've got some groceries of my own to take care of."

        scene e3s6-83 with dissolve
        show e3s6_sadie_blink4
        mc "I assume you don't need any help."

        scene e3s6-87 with dissolve
        hide e3s6_sadie_blink4
        sd "Nope."

        scene e3s6-83 with dissolve
        show e3s6_sadie_blink4
        mc "Alright then, thanks [sd]!"
        mc "I owe you one."

        stop music fadeout 2.0
        scene e3s6-75 with dissolve
        hide e3s6_sadie_blink4
        pause

    jump e3s7
return

label e3s6_sadie_sex:
    scene e3s6-37 with dissolve
    pause

    play sound punch
    scene e3s6-38 with vpunch
    pause

    scene e3s6-39 with dissolve
    mc "Woah... what's gotten into you?"

    scene e3s6-40 with dissolve
    sd "Into me?"

    scene e3s6-41 with dissolve
    sd "You don't call, you don't text."

    scene e3s6-42 with dissolve
    sd "I've been wondering where the hell you are."

    scene e3s6-43 with dissolve
    show e3s6_sadie_blink2
    mc "What do you mean?"

    scene e3s6-39 with dissolve
    hide e3s6_sadie_blink2
    mc "Wait, are we even allowed to be here?"

    scene e3s6-44 with dissolve
    sd "I don't give a shit."
    sd "I'll tell you what I mean."

    if e2s10_sadie_sex == True:
        scene e3s6-41 with dissolve
        sd "You slept at my place, fucked me amazingly well..."

        scene e3s6-45 with dissolve
        sd "And you have the audacity to not call or text."
        sd "Who does that?"
    else:
        scene e3s6-45 with dissolve
        sd "I thought we had something going on."

        scene e3s6-43 with dissolve
        show e3s6_sadie_blink2
        mc "Aren't you the one who told me you needed more time?"

        scene e3s6-45 with dissolve
        hide e3s6_sadie_blink2
        sd "Yeah dude, that doesn't mean to ghost me."

    scene e3s6-43 with dissolve
    show e3s6_sadie_blink2
    mc "Look... [sd]."
    mc "You're right."
    mc "I'm sorry, I've been a bit busy."

    scene e3s6-40 with dissolve
    hide e3s6_sadie_blink2
    sd "You know? I don't really care about your bullshit excuses."

    scene e3s6-45 with dissolve
    sd "As a matter of fact, you're gonna make it up to me right here and right now."

    scene e3s6-43 with dissolve
    show e3s6_sadie_blink2
    mc "Make it up to you?"
    mc "How?"

    play music heartache
    scene e3s6-46 with dissolve
    hide e3s6_sadie_blink2
    sd "Oh, just wait."

    scene e3s6-47 with dissolve
    mc "[sd]?"

    scene e3s6-48 with dissolve
    pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e3s6-49 with dissolve
        mc "We're gonna do it here?!"
        mc "What if we get caught?"

        scene e3s6-50 with dissolve
        sd "I don't care."

        scene e3s6-51 with dissolve
        mc "Ah shit...!"

        if persistent.disable_nsfw == True:
            # Blowjob and Handjob
            scene e3s6-blowjob1 with dissolve
            pause

            scene e3s6-blowjob2 with dissolve
            mc "Ngh..."

            scene e3s6-52 with dissolve
            sd "If you don't want to get caught you better keep your moans to yourself."

            scene e3s6-53 with dissolve
            mc "It's a little hard when you're doing such a great job."

            scene e3s6-51 with dissolve
            mc "Fuck..."

            scene e3s6-blowjob3 with dissolve
            pause

            scene e3s6-blowjob1 with dissolve
            pause

            scene e3s6-blowjob2 with dissolve
            pause

            scene e3s6-handjob1 with dissolve
            mc "Ah... yes."
            mc "Keep going [sd]."

            scene e3s6-handjob2 with dissolve
            pause

            scene e3s6-blowjob3 with dissolve
            pause

            scene e3s6-52 with dissolve
            sd "And now to the part where you're actually making it up to me."

            scene e3s6-53 with dissolve
            mc "Wait, weren't we doing this already?"

            scene e3s6-54 with dissolve
            sd "Shhh."

            # Undressing
            scene e3s6-55 with dissolve
            pause

            scene e3s6-56 with dissolve
            pause

            scene e3s6-57 with dissolve
            pause

            scene e3s6-58 with dissolve
            pause

            # Lift her leg
            scene e3s6-standing1 with dissolve
            sd "Oh fuck..."

            scene e3s6-59 with dissolve
            sd "This feels so good."

            scene e3s6-60 with dissolve
            mc "Who's gonna have to keep their moans to themselves now?"

            scene e3s6-kiss1 with dissolve
            pause

            scene e3s6-standing2 with dissolve
            pause

            scene e3s6-standing3 with dissolve
            pause

            scene e3s6-standing1 with dissolve
            sd "Oh yeah, [mc]!"
            sd "Fuck me..."

            scene e3s6-standing2 with dissolve
            sd "This feels so good..."

            scene e3s6-standing3 with dissolve
            pause

            scene e3s6-kiss1 with dissolve
            pause

            scene e3s6-standing2 with dissolve
            pause

            scene e3s6-standing3 with dissolve
            pause

            scene e3s6-standing1 with dissolve
            pause

            scene e3s6-59 with dissolve
            sd "Alright, let's put those muscles to some good use."

            scene e3s6-60 with dissolve
            mc "What do you mean?"

            # Standing
            play sound punch
            scene e3s6-61 with vpunch
            pause

            scene e3s6-62 with dissolve
            mc "Damn..."

            scene e3s6-standing4 with dissolve
            sd "Oh... that feels so good."

            scene e3s6-standing5 with dissolve
            pause

            scene e3s6-standing6 with dissolve
            pause

            scene e3s6-standing7 with dissolve
            mc "Fuck... [sd]."

            scene e3s6-standing4 with dissolve
            sd "Ahh..."

            scene e3s6-standing5 with dissolve
            pause

            scene e3s6-standing6 with dissolve
            pause

            scene e3s6-standing7 with dissolve
            sd "You're going so deep in this position, [mc]."

            scene e3s6-standing6 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                # Blowjob and Handjob
                scene e3s6-blowjob1_cen with dissolve
                pause

                scene e3s6-blowjob2_cen with dissolve
                mc "Ngh..."

                scene e3s6-52_cen with dissolve
                sd "If you don't want to get caught you better keep your moans to yourself."

                scene e3s6-53_cen with dissolve
                mc "It's a little hard when you're doing such a great job."

                scene e3s6-51 with dissolve
                mc "Fuck..."

                scene e3s6-blowjob3_cen with dissolve
                pause

                scene e3s6-blowjob1_cen with dissolve
                pause

                scene e3s6-blowjob2_cen with dissolve
                pause

                scene e3s6-handjob1_cen with dissolve
                mc "Ah... yes."
                mc "Keep going [sd]."

                scene e3s6-handjob2_cen with dissolve
                pause

                scene e3s6-blowjob3_cen with dissolve
                pause

                scene e3s6-52_cen with dissolve
                sd "And now to the part where you're actually making it up to me."

                scene e3s6-53_cen with dissolve
                mc "Wait, weren't we doing this already?"

                scene e3s6-54 with dissolve
                sd "Shhh."

                # Undressing
                scene e3s6-55_cen with dissolve
                pause

                scene e3s6-56_cen with dissolve
                pause

                scene e3s6-57_cen with dissolve
                pause

                scene e3s6-58_cen with dissolve
                pause

                # Lift her leg
                scene e3s6-standing1_cen with dissolve
                sd "Oh fuck..."

                scene e3s6-59 with dissolve
                sd "This feels so good."

                scene e3s6-60 with dissolve
                mc "Who's gonna have to keep their moans to themselves now?"

                scene e3s6-kiss1 with dissolve
                pause

                scene e3s6-standing2_cen with dissolve
                pause

                scene e3s6-standing3_cen with dissolve
                pause

                scene e3s6-standing1_cen with dissolve
                sd "Oh yeah, [mc]!"
                sd "Fuck me..."

                scene e3s6-standing2_cen with dissolve
                sd "This feels so good..."

                scene e3s6-standing3_cen with dissolve
                pause

                scene e3s6-kiss1 with dissolve
                pause

                scene e3s6-standing2_cen with dissolve
                pause

                scene e3s6-standing3_cen with dissolve
                pause

                scene e3s6-standing1_cen with dissolve
                pause

                scene e3s6-59 with dissolve
                sd "Alright, let's put those muscles to some good use."

                scene e3s6-60 with dissolve
                mc "What do you mean?"

                # Standing
                play sound punch
                scene e3s6-61_cen with vpunch
                pause

                scene e3s6-62 with dissolve
                mc "Damn..."

                scene e3s6-standing4_cen with dissolve
                sd "Oh... that feels so good."

                scene e3s6-standing5_cen with dissolve
                pause

                scene e3s6-standing6_cen with dissolve
                pause

                scene e3s6-standing7_cen with dissolve
                mc "Fuck... [sd]."

                scene e3s6-standing4_cen with dissolve
                sd "Ahh..."

                scene e3s6-standing5_cen with dissolve
                pause

                scene e3s6-standing6_cen with dissolve
                pause

                scene e3s6-standing7_cen with dissolve
                sd "You're going so deep in this position, [mc]."

                scene e3s6-standing6_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Blowjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s6-blowjob1 with dissolve
                        pause

                        scene e3s6-blowjob2 with dissolve
                        mc "Ngh..."

                        scene e3s6-51 with dissolve
                        mc "Fuck..."

                        scene e3s6-blowjob3 with dissolve
                        pause

                        scene e3s6-blowjob1 with dissolve
                        pause

                        scene e3s6-blowjob2 with dissolve
                        pause

                        scene e3s6-blowjob3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s6-blowjob1_cen with dissolve
                            pause

                            scene e3s6-blowjob2_cen with dissolve
                            mc "Ngh..."

                            scene e3s6-51 with dissolve
                            mc "Fuck..."

                            scene e3s6-blowjob3_cen with dissolve
                            pause

                            scene e3s6-blowjob1_cen with dissolve
                            pause

                            scene e3s6-blowjob2_cen with dissolve
                            pause

                            scene e3s6-blowjob3_cen with dissolve
                            pause

                "Handjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s6-handjob1 with dissolve
                        mc "Ah... yes."
                        mc "Keep going [sd]."

                        scene e3s6-handjob2 with dissolve
                        pause

                        scene e3s6-handjob1 with dissolve
                        pause

                        scene e3s6-handjob2 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s6-handjob1_cen with dissolve
                            mc "Ah... yes."
                            mc "Keep going [sd]."

                            scene e3s6-handjob2_cen with dissolve
                            pause

                            scene e3s6-handjob1_cen with dissolve
                            pause

                            scene e3s6-handjob2_cen with dissolve
                            pause

                "Lift her leg":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s6-standing1 with dissolve
                        sd "Oh fuck..."

                        scene e3s6-59 with dissolve
                        sd "This feels so good."

                        scene e3s6-60 with dissolve
                        mc "Who's gonna have to keep their moans to themselves now?"

                        scene e3s6-kiss1 with dissolve
                        pause

                        scene e3s6-standing2 with dissolve
                        pause

                        scene e3s6-standing3 with dissolve
                        pause

                        scene e3s6-standing1 with dissolve
                        sd "Oh yeah, [mc]!"
                        sd "Fuck me..."

                        scene e3s6-standing2 with dissolve
                        sd "This feels so good..."

                        scene e3s6-standing3 with dissolve
                        pause

                        scene e3s6-kiss1 with dissolve
                        pause

                        scene e3s6-standing2 with dissolve
                        pause

                        scene e3s6-standing3 with dissolve
                        pause

                        scene e3s6-standing1 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s6-standing1_cen with dissolve
                            sd "Oh fuck..."

                            scene e3s6-59 with dissolve
                            sd "This feels so good."

                            scene e3s6-60 with dissolve
                            mc "Who's gonna have to keep their moans to themselves now?"

                            scene e3s6-kiss1 with dissolve
                            pause

                            scene e3s6-standing2_cen with dissolve
                            pause

                            scene e3s6-standing3_cen with dissolve
                            pause

                            scene e3s6-standing1_cen with dissolve
                            sd "Oh yeah, [mc]!"
                            sd "Fuck me..."

                            scene e3s6-standing2_cen with dissolve
                            sd "This feels so good..."

                            scene e3s6-standing3_cen with dissolve
                            pause

                            scene e3s6-kiss1 with dissolve
                            pause

                            scene e3s6-standing2_cen with dissolve
                            pause

                            scene e3s6-standing3_cen with dissolve
                            pause

                            scene e3s6-standing1_cen with dissolve
                            pause

                "Standing":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s6-standing4 with dissolve
                        sd "Oh... that feels so good."

                        scene e3s6-standing5 with dissolve
                        pause

                        scene e3s6-standing6 with dissolve
                        pause

                        scene e3s6-standing7 with dissolve
                        mc "Fuck... [sd]."

                        scene e3s6-standing4 with dissolve
                        sd "Ahh..."

                        scene e3s6-standing5 with dissolve
                        pause

                        scene e3s6-standing6 with dissolve
                        pause

                        scene e3s6-standing7 with dissolve
                        sd "You're going so deep in this position, [mc]."

                        scene e3s6-standing6 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s6-standing4_cen with dissolve
                            sd "Oh... that feels so good."

                            scene e3s6-standing5_cen with dissolve
                            pause

                            scene e3s6-standing6_cen with dissolve
                            pause

                            scene e3s6-standing7_cen with dissolve
                            mc "Fuck... [sd]."

                            scene e3s6-standing4_cen with dissolve
                            sd "Ahh..."

                            scene e3s6-standing5_cen with dissolve
                            pause

                            scene e3s6-standing6_cen with dissolve
                            pause

                            scene e3s6-standing7_cen with dissolve
                            sd "You're going so deep in this position, [mc]."

                            scene e3s6-standing6_cen with dissolve
                            pause

                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        mc "Sadie... I'm going to cum!"

                        scene e3s6-standing4 with dissolve
                        pause
                        mc "Oh shit!"

                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e3s6-64 with dissolve
                        sd "Fuck!"
                        mc "Holy shit [sd], this was amazing!"
                        sd "I know right?"

                        scene e3s6-65 with dissolve
                        mc "Damn... you are a crazy one."

                        scene e3s6-66 with dissolve
                        sd "Yeah, and if you're looking to date me you better start accepting it."

                        scene e3s6-69 with dissolve
                        sd "Because we're gonna do it in places waaay crazier than this."

                        scene e3s6-68 with dissolve
                        show e3s6_sadie_blink3
                        mc "Damn..."
                        mc "So was my item really here or was this just an excuse for a quickie?"

                        scene e3s6-69 with dissolve
                        hide e3s6_sadie_blink3
                        sd "A little bit of both, haha!"

                        if e2s10_sadie == True:
                            scene e3s6-70 with dissolve
                            sd "You don't know how much I've wanted you since last time."

                            scene e3s6-68 with dissolve
                            show e3s6_sadie_blink3
                            mc "Damn [sd], I didn't know this side of you."

                            scene e3s6-67 with dissolve
                            hide e3s6_sadie_blink3
                            sd "As I said, you better get used to it."
                        else:
                            scene e3s6-67 with dissolve
                            sd "Well... I'll be on my way."

                            scene e3s6-70 with dissolve
                            sd "You better start texting me or this is gonna get worse."

                            scene e3s6-68 with dissolve
                            show e3s6_sadie_blink3
                            mc "Maybe I like it worse."

                        scene e3s6-71 with dissolve
                        pause

                        scene e3s6-72 with dissolve
                        pause

                        scene e3s6-73 with dissolve
                        pause

                        scene e3s6-74 with dissolve
                        pause

                        scene e3s6-63 with dissolve
                        pause

                        scene e3s6-75 with dissolve
                        pause

                        stop music fadeout 2.0
                        scene e3s6-76 with dissolve
                        mc "*My God...*"
                        mc "*Wow!*"
                    else:
                        if persistent.type_nsfw == False:
                            mc "Sadie... I'm going to cum!"

                            scene e3s6-standing4_cen with dissolve
                            pause
                            mc "Oh shit!"

                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3s6-64_cen with dissolve
                            sd "Fuck!"
                            mc "Holy shit [sd], this was amazing!"
                            sd "I know right?"

                            scene e3s6-65 with dissolve
                            mc "Damn... you are a crazy one."

                            scene e3s6-66_cen with dissolve
                            sd "Yeah, and if you're looking to date me you better start accepting it."

                            scene e3s6-69 with dissolve
                            sd "Because we're gonna do it in places wayy crazier than this."

                            scene e3s6-68 with dissolve
                            show e3s6_sadie_blink3
                            mc "Damn..."
                            mc "So was my item really here or was this just an excuse for a quickie?"

                            scene e3s6-69 with dissolve
                            hide e3s6_sadie_blink3
                            sd "A little bit of both, haha!"

                            if e2s10_sadie == True:
                                scene e3s6-70 with dissolve
                                sd "You don't know how much I've wanted you since last time."

                                scene e3s6-68 with dissolve
                                show e3s6_sadie_blink3
                                mc "Damn [sd], I didn't know this side of you."

                                scene e3s6-67 with dissolve
                                hide e3s6_sadie_blink3
                                sd "As I said, you better get used to it."
                            else:
                                scene e3s6-67 with dissolve
                                sd "Well... I'll be on my way."

                                scene e3s6-70 with dissolve
                                sd "You better start texting me or this is gonna get worse."

                                scene e3s6-68 with dissolve
                                show e3s6_sadie_blink3
                                mc "Maybe I like it worse."

                            scene e3s6-71_cen with dissolve
                            pause

                            scene e3s6-72_cen with dissolve
                            pause

                            scene e3s6-73 with dissolve
                            pause

                            scene e3s6-74 with dissolve
                            pause

                            scene e3s6-63_cen with dissolve
                            pause

                            scene e3s6-75 with dissolve
                            pause

                            stop music fadeout 2.0
                            scene e3s6-76 with dissolve
                            mc "*My God...*"
                            mc "*Wow!*"

                    $ GameRunning = False

    $ renpy.end_replay()
return
