
# Scene 5 - A new opportunity (Tuesday) ########################################

label e3s5:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s5-01 with Dissolve(2.0)
    play music pioneers
    pause

    scene e3s5-02 with dissolve
    if affinity_spectrum > 0:
        mc "Holy shit, how do you know so much about this?"
    else:
        mc "How do you know so much about this?"

    scene e3s5-03 with dissolve
    fr "Well, having a father who's also in this domain really helps."
    fr "I've studied really hard these years in college."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "So you didn't really have fun?"

    scene e3s5-06 with dissolve
    hide e3s5_francesca_blink1
    fr "I wouldn't say that."

    scene e3s5-07 with dissolve
    fr "I managed to do a couple of activities here and there."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Like those tattoos on your arm?"

    scene e3s5-09 with dissolve
    hide e3s5_francesca_blink1
    fr "Yeah... something like that."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "By the way, what do they mean?"

    scene e3s5-05 with dissolve
    hide e3s5_francesca_blink1
    fr "Well, every tattoo has its meaning."

    scene e3s5-08 with dissolve
    fr "The most important one to me is this one which represents College Rock."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Why is it so important?"

    scene e3s5-07 with dissolve
    hide e3s5_francesca_blink1
    fr "College Rock is a club inside this college."

    scene e3s5-10 with dissolve
    fr "If I can't dance at least I can sing which is also an artistic talent."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Wow, I didn't know you could sing."

    scene e3s5-09 with dissolve
    hide e3s5_francesca_blink1
    fr "Perhaps you don't know a lot of things about me [mc]."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "So is it just a club for singing?"

    scene e3s5-06 with dissolve
    hide e3s5_francesca_blink1
    fr "Yeah, kind of like that."

    scene e3s5-07 with dissolve
    fr "We've also got competitions and whatnot."
    fr "You could join if you want."

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Nah, I'm sorry."
    mc "I've already talked to Jon about joining his group."
    mc "Plus, I'm not much of a singer myself."

    scene e3s5-10 with dissolve
    hide e3s5_francesca_blink1
    fr "Well, singing is not just about using your voice."

    scene e3s5-09 with dissolve
    fr "You could also play an instrument."

    scene e3s5-11 with dissolve
    fr "But it's alright, I understand."

    scene e3s5-07 with dissolve
    fr "Do you need any more help?"

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "No, it's alright, I understand it now."
    mc "Thanks [fr], let's wrap this up!"

    scene e3s5-05 with dissolve
    hide e3s5_francesca_blink1
    fr "No problem [mc]!"
    fr "I'm glad to help."

    scene e3s5-12 with dissolve
    fr "I'll see you around!"

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Bye!"

    scene e3s5-13 with dissolve
    hide e3s5_francesca_blink1
    menu:
        "Check her out":
            $ francesca_trust -= 1

            scene e3s5-14 with dissolve
            pause

            scene e3s5-15 with dissolve
            pause

            scene e3s5-16 with dissolve
            mc "*How did she...*"

        "Don't check her out":
            pass

    scene e3s5-17 with dissolve
    pause

    stop music fadeout 2.0
    scene e3s5-18 with dissolve
    pause

    jump e3s6
return
