
# Scene 21 - Cafeteria incident ################################################

label e3s21:
    if affinity_spectrum > 0:
        scene e3s21-03 with wipeleft
        pause

        scene e3s21-04 with dissolve
        pause

        scene e3s21-06 with dissolve
        tr "Hey!"

        scene e3s21-05 with dissolve
        mc "Hello [tr]."

        scene e3s21-07 with dissolve
        tr "What's up?"

        scene e3s21-05 with dissolve
        mc "I'm gonna go grab some lunch."
        mc "Wanna come?"

        scene e3s21-07 with dissolve
        tr "Sure, I've got some time before my next class."

        scene e3s21-06 with dissolve
        tr "But I have to do something else before that so I'll meet you there, alright?"

        scene e3s21-05 with dissolve
        mc "Yeah, sure."

        scene e3s21-08 with dissolve
        pause

    scene e3s21-01 with wipeleft
    pause

    scene e3s21-02 with dissolve
    pause

    scene e3s21-09 with vpunch
    play music aces_high
    unknown "SHIT!"

    scene e3s21-10 with dissolve
    mc "What the hell, man?"

    scene e3s21-11 with dissolve
    unknown "I'm sorry!"
    unknown "I didn't mean it."

    scene e3s21-15 with dissolve
    menu:
        "Get mad":
            $ e3s21_mad = True
            $ cleo_trust -= 1
            call extrovert_affinity_check from _call_extrovert_affinity_check_55
            call color_check from _call_color_check_105

            scene e3s21-12 with dissolve
            mc "Yeah, you're sorry my ass."

            scene e3s21-13 with dissolve
            mc "Now I've got food all over my clothes."

            scene e3s21-12 with dissolve
            mc "It's not like your sorry is going to undo this."

            scene e3s21-11 with dissolve
            unknown "You're right... let me buy you a meal."

            scene e3s21-12 with dissolve
            mc "Yeah... sure, like your meal is gonna do anything."

            scene e3s21-14 with dissolve
            mc "Can you just go away?"
            mc "You've done enough."

            scene e3s21-11 with dissolve
            unknown "Alright alright, I'll go."

        "Shrug it off":
            call introvert_affinity_check from _call_introvert_affinity_check_47
            call color_check from _call_color_check_106

            scene e3s21-14 with dissolve
            mc "Whatever."

            scene e3s21-16 with dissolve
            mc "It's okay, don't worry."
            mc "I'll go get changed."

            scene e3s21-17 with dissolve
            unknown "Nah, I feel sorry man."

            scene e3s21-11 with dissolve
            unknown "Let me buy you another one."

            scene e3s21-16 with dissolve
            mc "It's fine, you go ahead."

    scene e3s21-18 with dissolve
    pause

    scene e3s21-19 with dissolve
    pause

    if e3s21_mad == True:
        scene e3s21-20 with dissolve
        pause

    jump e3s22
return
