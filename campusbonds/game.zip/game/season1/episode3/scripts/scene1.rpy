
# Scene 1 - Walking Olivia home ################################################

label e3s1:
    stop music fadeout 2.0
    scene white with Dissolve(2.0)
    pause(1.0)

    play music bad_sexy_dad_vibes fadein 2.0
    scene e3s1-02 with Dissolve(2.0)
    pause

    scene e3s1-01 with dissolve
    pause

    scene e3s1-03 with dissolve
    pause

    scene e3s1-04 with dissolve
    ov "Did you call the driver?"

    scene e3s1-05 with dissolve
    wa "Yes, he was supposed to be here 15 minutes ago."
    wa "He's been stuck in traffic."

    scene e3s1-04 with dissolve
    ov "Can't you give him a call again?"
    ov "You know how it is to walk alone at night as a woman."

    scene e3s1-05 with dissolve
    wa "I sure do."
    wa "I'm going to call him again to find his status."

    scene e3s1-06 with dissolve
    pause

    scene e3s1-07 with dissolve
    show e3s1_olivia_blink1
    mc "Hey [ov], is everything alright?"

    scene e3s1-08 with dissolve
    hide e3s1_olivia_blink1
    ov "No, not really [mc]."

    scene e3s1-09 with dissolve
    ov "My driver didn't show up and I can't really get home."

    scene e3s1-07 with dissolve
    show e3s1_olivia_blink1
    mc "Is it far away from here?"

    scene e3s1-08 with dissolve
    hide e3s1_olivia_blink1
    ov "It's not that far but I don't really like to walk alone."

    scene e3s1-07 with dissolve
    show e3s1_olivia_blink1
    mc "I could walk you home if that's alright with you."

    scene e3s1-10 with dissolve
    hide e3s1_olivia_blink1
    ov "Really [mc]?"
    ov "Would you do that for me?"

    scene e3s1-07 with dissolve
    show e3s1_olivia_blink1
    mc "Yeah, it's no big deal, don't worry."

    scene e3s1-08 with dissolve
    hide e3s1_olivia_blink1
    ov "Alright then... let's wait for any news about the driver."

    scene e3s1-10 with dissolve
    ov "If he doesn't show up, we'll walk."

    scene e3s1-07 with dissolve
    show e3s1_olivia_blink1
    mc "Alright [ov]."

    scene e3s1-12 with dissolve
    hide e3s1_olivia_blink1
    ov "So... did you enjoy the party?"

    scene e3s1-11 with dissolve
    show e3s1_olivia_blink2
    mc "Yeah, I really liked it!"
    mc "I thought it would be a bit boring."
    mc "I don't want you to get the wrong idea but you know the rich stereotype."
    mc "They don't really have fun, they just talk about what they own."

    scene e3s1-13 with dissolve
    hide e3s1_olivia_blink1
    ov "Haha, I understand!"

    scene e3s1-14 with dissolve
    ov "No, we're not like that."

    scene e3s1-12 with dissolve
    ov "I like to think of ourselves as being humble."

    scene e3s1-14 with dissolve
    ov "Probably the exact same reason why [ke] will never take this house."

    scene e3s1-11 with dissolve
    show e3s1_olivia_blink2
    mc "He's been offered this house and he refused?"

    scene e3s1-14 with dissolve
    hide e3s1_olivia_blink1
    ov "Among many other things, yeah."
    ov "He wants to build his own life."

    scene e3s1-11 with dissolve
    show e3s1_olivia_blink2
    mc "That's pretty respectable to be honest."

    scene e3s1-15 with dissolve
    hide e3s1_olivia_blink1
    pause

    scene e3s1-16 with dissolve
    wa "Miss [ov], I've checked up with the driver."
    wa "He won't be here for at least one more hour."

    scene e3s1-17 with dissolve
    ov "Thank you for letting me know."

    scene e3s1-16 with dissolve
    wa "If you have any other requests, I will be in the main lobby."

    scene e3s1-18 with dissolve
    mc "So... I guess we're walking?"

    scene e3s1-19 with dissolve
    ov "If that's really fine by you, yeah!"

    scene e3s1-20 with dissolve

    scene e3s1-21 with wipeleft
    pause

    scene e3s1-22 with dissolve
    mc "Haha, well, I gotta be honest."
    mc "Hanging outside the gym feels a bit weird."

    scene e3s1-23 with dissolve
    ov "Haha, why do you say that?"

    scene e3s1-24 with dissolve
    mc "Well... you know... we've only seen each other there."

    scene e3s1-25 with dissolve
    mc "I'm just not used to seeing you out of your gymwear, I guess."

    scene e3s1-26 with dissolve
    ov "We're almost there."
    ov "Thank you [mc]!"
    ov "You really didn't have to do this."

    scene e3s1-27 with dissolve
    mc "Oh, come on [ov], don't worry about it."

    scene e3s1-28 with dissolve
    show e3s1_olivia_blink3
    mc "It's my pleasure!"
    mc "I couldn't just let you walk alone."

    scene e3s1-29 with dissolve
    hide e3s1_olivia_blink3
    ov "Would you like to have a cup of coffee inside?"

    scene e3s1-28 with dissolve
    show e3s1_olivia_blink3
    mc "Well... I don't know..."

    scene e3s1-30 with dissolve
    hide e3s1_olivia_blink3
    ov "You've walked me home, that's the least I could do."

    scene e3s1-28 with dissolve
    show e3s1_olivia_blink3
    mc "A coffee wouldn't hurt I guess."

    stop music fadeout 2.0
    scene e3s1-31 with dissolve
    hide e3s1_olivia_blink3
    pause

    scene e3s1-32 with wipeleft
    play music satfes
    ov "So... what have you been up to [mc]?"

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "You know... just this and that."

    scene e3s1-34 with dissolve
    hide e3s1_olivia_blink4
    ov "Haha, what does that mean?"

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    if affinity_spectrum > 0:
        mc "Well... I've been to some parties."
    else:
        mc "Well... I've been dragged through some parties."

    mc "And you know, just meeting people."

    scene e3s1-35 with dissolve
    hide e3s1_olivia_blink4
    ov "Ah... I remember my first time in college as well."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "How was it?"

    scene e3s1-36 with dissolve
    hide e3s1_olivia_blink4
    ov "Honestly, it felt pretty magical back then."

    scene e3s1-40 with dissolve
    ov "So many people to meet and so many things to do."

    scene e3s1-37 with dissolve
    ov "It really was something new for me."

    scene e3s1-34 with dissolve
    ov "I wasn't such a people person back then."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "Are you now?"

    scene e3s1-39 with dissolve
    hide e3s1_olivia_blink4
    ov "I mean, now I can talk to people."

    scene e3s1-35 with dissolve
    ov "Back then I was pretty shy."

    scene e3s1-40 with dissolve
    ov "The fact that I was homeschooled up until college didn't really help either."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "You were homeschooled?"

    scene e3s1-38 with dissolve
    hide e3s1_olivia_blink4
    ov "Yeah..."

    scene e3s1-37 with dissolve
    ov "To be fair, I would have preferred to at least go to a private school instead of doing it at home."

    scene e3s1-39 with dissolve
    ov "But what can you do now?"

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "I see."
    mc "Were your parents strict or what happened?"

    scene e3s1-38 with dissolve
    hide e3s1_olivia_blink4
    ov "A bit, yeah."

    scene e3s1-40 with dissolve
    ov "I can say that I wasn't really allowed to hang out with whoever I wanted to."

    scene e3s1-37 with dissolve
    ov "I could only hang out with my relatives and even then we were supervised."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "Not much privacy, I see."

    scene e3s1-36 with dissolve
    hide e3s1_olivia_blink4
    ov "I mean, I can understand why they did it."

    scene e3s1-38 with dissolve
    ov "But still, I wouldn't do that to my children if I had any."

    scene e3s1-39 with dissolve
    ov "Anyways, how were your school years [mc]?"

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "For the most part, they were pretty fine."
    mc "I was mostly just average, didn't break any barriers."

    scene e3s1-40 with dissolve
    hide e3s1_olivia_blink4
    ov "Interesting..."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "There was this one thing that happened though.."

    scene e3s1-41 with dissolve
    hide e3s1_olivia_blink4
    ov "Oh..."

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "You see, I was on track to become a professional fighter."
    mc "But I had one fight which ended pretty badly."

    scene e3s1-43 with dissolve
    hide e3s1_olivia_blink5
    ov "Oh, I'm sorry [mc]..."

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "Yeah, unfortunately I ended up paralyzed."
    mc "That whole year was a nightmare."

    scene e3s1-43 with dissolve
    hide e3s1_olivia_blink5
    ov "How did that happen!?"

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "Illegal shot to the head."
    mc "The back... of my head to be precise."

    scene e3s1-44 with dissolve
    hide e3s1_olivia_blink5
    ov "Oh my God..."

    scene e3s1-43 with dissolve
    ov "You could have died!"

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "Yeah, fortunately I didn't."
    mc "Still, it left me with a lot of complications."
    mc "Most people don't really recover from this but I was able to do so."
    mc "The doctors said it was a miracle."

    scene e3s1-43 with dissolve
    hide e3s1_olivia_blink5
    ov "What happened to the other kid?"

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    if e2s0_fight == True:
        mc "Well, I almost beat him."
    else:
        mc "He was dominating me."
        mc "I wasn't great in that fight."
        mc "Took a lot of blows but managed to pick myself up."

    mc "I was prepared to land the ending shot."
    mc "Unfortunately, I missed."
    mc "And that's when it happened."
    mc "He wasn't disqualified if you can believe it."
    mc "He still won."

    scene e3s1-45 with dissolve
    hide e3s1_olivia_blink5
    ov "That's such bullshit!"

    scene e3s1-43 with dissolve
    ov "Excuse my language."

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "It's alright."

    scene e3s1-41 with dissolve
    hide e3s1_olivia_blink5
    ov "I'm so sorry [mc]..."

    scene e3s1-38 with dissolve
    ov "It must be hard for you."

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "Well... it was."
    mc "Thankfully, I've learned to live with it."
    mc "I still have some controlled sparring sessions with my friend from time to time."

    scene e3s1-43 with dissolve
    hide e3s1_olivia_blink5
    ov "Still, isn't that dangerous?"

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "That's why they're controlled."
    mc "I don't think I'll ever stop fighting."
    mc "Even if it kills me in the end."

    scene e3s1-45 with dissolve
    hide e3s1_olivia_blink5
    ov "This is stupid of you to say!"

    scene e3s1-46 with dissolve
    ov "You should value your life more."

    scene e3s1-48 with dissolve
    mc "I'm sorry."

    scene e3s1-47 with dissolve
    ov "..."

    scene e3s1-43 with dissolve
    ov "I do appreciate it though."

    scene e3s1-38 with dissolve
    ov "I'm gonna admit I've never seen the point in this kind of sport."

    scene e3s1-39 with dissolve
    ov "But I like your passion."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "Thanks [ov]."

    scene e3s1-39 with dissolve
    hide e3s1_olivia_blink4
    ov "Just be careful, alright?"

    scene e3s1-43 with dissolve
    ov "I wouldn't want anything to happen to you."

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "It's alright, I will take care of myself."

    scene e3s1-43 with dissolve
    hide e3s1_olivia_blink5
    ov "Thank you, [mc]!"

    scene e3s1-42 with dissolve
    show e3s1_olivia_blink5
    mc "It's getting a bit late, I should be heading home."
    mc "Thank you for the coffee!"

    scene e3s1-37 with dissolve
    hide e3s1_olivia_blink5
    ov "You're welcome, [mc]."

    scene e3s1-36 with dissolve
    ov "Thank you also for walking me home."

    scene e3s1-34 with dissolve
    ov "It was very nice of you."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "Don't mention it!"

    scene e3s1-40 with dissolve
    hide e3s1_olivia_blink5
    ov "Good bye [mc]!"
    ov "Be safe."

    scene e3s1-33 with dissolve
    show e3s1_olivia_blink4
    mc "Bye [ov]!"

    scene e3s1-49 with dissolve
    hide e3s1_olivia_blink4
    pause

    jump e3s2
return
