
# Scene 26 - Rewarding risk ####################################################

label e3s26:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s26-60 with Dissolve(2.0)
    play music invisible_light
    pause

    scene e3s26-61 with dissolve
    pause

    scene e3s26-62 with dissolve
    nvl clear
    ca_nvl "Hey sweetie!"
    ca_nvl "Got any plans for the day?"
    n_nvl "Yeah, I was just about to go home."
    ca_nvl "Aw, that's unfortunate :("
    ca_nvl "Don't you have time for a little detour?"
    n_nvl "Why, what's wrong?"
    menu:
        "Go to the club":
            $ e3s26_candance_lewd = True
            $ candance_trust += 1
            n_nvl "I guess I have some spare time for a detour."
            ca_nvl "Amazing! Let me know when you get here. :)"

            scene e3s26-64 with dissolve
            pause

            stop music fadeout 2.0
            scene e3s26-63 with dissolve
            pause
        "Go home":
            n_nvl "I'm sorry [ca], I don't really have time right now."
            n_nvl "Maybe some other time."
            ca_nvl "Okay, have a nice trip."
            n_nvl "Thanks!"

            scene e3s26-64 with dissolve
            pause

            stop music fadeout 2.0
            scene e3s26-63 with dissolve
            pause

            jump e3s27

    scene e3s26-01 with wipeleft
    play music laurel_breeze
    pause

    scene e3s26-02 with dissolve
    mc "*Wow, this place looks completely different during the day!*"
    mc "*Also, there's nobody here.*"
    mc "*Let me text [ca].*"

    scene e3s26-03 with dissolve
    nvl clear
    n_nvl "Hey, I'm here!"
    ca_nvl "Okay, be there in a bit."

    scene e3s26-04 with dissolve
    ca "Hey [mc], welcome!"

    scene e3s26-05 with dissolve
    show e3s26_candance_blink1
    mc "Hello!"
    mc "Damn this place looks different during the day."

    scene e3s26-06 with dissolve
    hide e3s26_candance_blink1
    ca "Haha, I know right?"

    scene e3s26-05 with dissolve
    show e3s26_candance_blink1
    mc "So... what are we doing here?"

    scene e3s26-07 with dissolve
    hide e3s26_candance_blink1
    ca "I wanted to give you a little something for the other time."

    scene e3s26-05 with dissolve
    show e3s26_candance_blink1
    mc "I thought you already made it up to me with that photo."

    scene e3s26-06 with dissolve
    hide e3s26_candance_blink1
    ca "Haha, no!"

    scene e3s26-07 with dissolve
    ca "Just wait in here, alright?"

    scene e3s26-08 with dissolve
    ca "I need to go do something really quick."

    scene e3s26-05 with dissolve
    show e3s26_candance_blink1
    mc "Alright, I'm just gonna take a seat."

    scene e3s26-06 with dissolve
    hide e3s26_candance_blink1
    ca "Awesome!"

    scene e3s26-09 with dissolve
    pause

    scene e3s26-10 with dissolve
    pause

    play sound phone_buzz
    scene e3s26-11 with dissolve
    pause

    scene e3s26-12 with dissolve
    pause

    scene e3s26-13 with dissolve
    nvl clear
    ca_nvl "Could you come help me with something?"
    n_nvl "Sure, what's up?"
    ca_nvl "There's a room down the hall, meet me there."
    n_nvl "Okay, coming."

    stop music fadeout 2.0
    scene e3s26-14 with dissolve
    pause

    call e3s26_candance_lewd from _call_e3s26_candance_lewd

    jump e3s27
return

label e3s26_candance_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e3s26-15 with wipeleft
            mc "So... what's up [ca]?"

            scene e3s26-16 with dissolve
            play music heartache
            mc "Holy..."

            scene e3s26-17 with dissolve
            pause

            scene e3s26-18 with dissolve
            ca "Don't be shy sweetie, come on in!"

            scene e3s26-19 with dissolve
            mc "This is what you needed help with?"

            scene e3s26-20 with dissolve
            ca "Can't a lady have cravings?"

            scene e3s26-19 with dissolve
            mc "I mean, yeah, but I did not expect this."
            mc "Totally not complaining."

            scene e3s26-21 with dissolve
            ca "Ah, ah...!"

            scene e3s26-20 with dissolve
            ca "Clothes aren't allowed in here."
            ca "If you'd like to enter, you have to leave them by the door."

            scene e3s26-19 with dissolve
            mc "Talk about being straightforward!"

            scene e3s26-22 with dissolve
            pause

            scene e3s26-23 with dissolve
            ca "The glasses too, silly!"

            scene e3s26-24 with dissolve
            mc "Damn it..."

            scene e3s26-25 with dissolve
            ca "Now, let's see what we have here!"

            scene e3s26-26 with dissolve
            pause

            # Blowjob
            scene e3s26-blowjob1 with dissolve
            mc "Oh [ca], that's amazing!"

            scene e3s26-blowjob2 with dissolve
            pause

            scene e3s26-blowjob3 with dissolve
            mc "Keep going."

            scene e3s26-blowjob1 with dissolve
            mc "*Damn... she goes so fast!*"

            scene e3s26-27 with dissolve
            ca "How are you enjoying it so far?"

            scene e3s26-28 with dissolve
            mc "It feels really good, [ca]."

            scene e3s26-27 with dissolve
            ca "I'm glad!"

            scene e3s26-blowjob2 with dissolve
            mc "Ah... fuck!"

            scene e3s26-blowjob3 with dissolve
            pause

            scene e3s26-27 with dissolve
            ca "How does it feel when I do this?"

            # Handjob
            scene e3s26-handjob1 with dissolve
            mc "Ah... shit!"

            scene e3s26-handjob2 with dissolve
            mc "Out of this world..."

            scene e3s26-handjob1 with dissolve
            pause

            scene e3s26-handjob2 with dissolve
            pause

            scene e3s26-27 with dissolve
            ca "Now... lie back."
            ca "And let me work my magic."

            scene e3s26-29 with dissolve
            pause

            scene e3s26-30 with dissolve
            pause

            # Cowgirl
            scene e3s26-cowgirl1 with dissolve
            ca "Ah... you're so big [mc]!"

            scene e3s26-cowgirl2 with dissolve
            mc "Your pussy feels so good [ca]."

            scene e3s26-cowgirl3 with dissolve
            pause

            scene e3s26-cowgirl1 with dissolve
            ca "Fuck... [mc]!"
            ca "You're so big."

            scene e3s26-cowgirl2 with dissolve
            pause

            scene e3s26-cowgirl3 with dissolve
            pause

            scene e3s26-cowgirl4 with dissolve
            mc "Ah fuck [ca], keep going!"

            scene e3s26-cowgirl5 with dissolve
            ca "Oh, yes [mc]!"

            scene e3s26-cowgirl6 with dissolve
            pause

            scene e3s26-cowgirl5 with dissolve
            mc "Fuck, this feels so good!"

            scene e3s26-cowgirl6 with dissolve
            pause

            scene e3s26-31 with dissolve
            ca "I also have an exclusive service just for you sweetie."

            scene e3s26-32 with dissolve
            mc "What service are we talking about?"

            scene e3s26-33 with dissolve
            pause

            # Anal
            scene e3s26-32 with dissolve
            if not _in_replay:
                menu:
                    "Try anal":
                        mc "Thought you wouldn't ask."
                        mc "Teasing me with that sweet ass of yours."

                        scene e3s26-34 with dissolve
                        ca "I knew you'd like chocolate!"

                        scene e3s26-32 with dissolve
                        menu:
                            "Chocolate":
                                $ candance_trust += 2
                                $ e3s26_chocolate = True

                                mc "I like chocolate."

                                scene e3s26-35 with dissolve
                                ca "Aren't you Prince Charming?"
                            "Vanilla":
                                $ e3s26_vanilla = True

                                mc "I prefer vanilla."
                            "Both":
                                $ candance_trust += 1

                                mc "I also like vanilla."
                                mc "I like vanilla just as much as I like chocolate."

                        scene e3s26-34 with dissolve
                        ca "Good to know!"

                        $ e3s26_anal = True
                        $ persistent.e3s26_anal = True

                    "Pass the offer":
                        mc "Thanks for the offer but I'm good."
                        mc "I'll stick to vanilla for now."

                        scene e3s26-31 with dissolve
                        ca "I thought you liked chocolate."

                        scene e3s26-32 with dissolve
                        menu:
                            "Chocolate":
                                $ candance_trust += 2
                                $ e3s26_chocolate = True

                                mc "I like chocolate."

                                scene e3s26-35 with dissolve
                                ca "Aren't you Prince Charming?"
                            "Vanilla":
                                $ e3s26_vanilla = True

                                mc "I prefer vanilla."
                            "Both":
                                $ candance_trust += 1

                                mc "I also like chocolate."
                                mc "I like chocolate just as much as I do vanilla."

                        scene e3s26-34 with dissolve
                        ca "Good to know!"
            else:
                menu:
                    "Try anal" if persistent.e3s26_anal == True:
                        $ e3s26_anal = True
                        $ persistent.e3s26_anal = True
                        mc "Thought you wouldn't ask."
                        mc "Teasing me with that sweet ass of yours."

                        scene e3s26-34 with dissolve
                        ca "I knew you'd like chocolate!"

                        scene e3s26-32 with dissolve
                        menu:
                            "Chocolate":
                                $ candance_trust += 2
                                $ e3s26_chocolate = True

                                mc "I like chocolate."

                                scene e3s26-35 with dissolve
                                ca "Aren't you Prince Charming?"
                            "Vanilla":
                                $ e3s26_vanilla = True

                                mc "I prefer vanilla."
                            "Both":
                                $ candance_trust += 1

                                mc "I also like vanilla."
                                mc "I like vanilla just as much as I like chocolate."

                        scene e3s26-34 with dissolve
                        ca "Good to know!"

                    "Pass the offer":
                        mc "Thanks for the offer but I'm good."
                        mc "I'll stick to vanilla for now."

                        scene e3s26-31 with dissolve
                        ca "I thought you liked chocolate."

                        scene e3s26-32 with dissolve
                        menu:
                            "Chocolate":
                                $ candance_trust += 2
                                $ e3s26_chocolate = True

                                mc "I like chocolate."

                                scene e3s26-35 with dissolve
                                ca "Aren't you Prince Charming?"
                            "Vanilla":
                                $ e3s26_vanilla = True

                                mc "I prefer vanilla."
                            "Both":
                                $ candance_trust += 1

                                mc "I also like chocolate."
                                mc "I like chocolate just as much as I do vanilla."

                        scene e3s26-34 with dissolve
                        ca "Good to know!"

            if persistent.e3s26_anal == True:
                scene e3s26-36 with dissolve
                ca "Just let me get it ready for you sweetie."

                scene e3s26-33 with dissolve
                ca "Ah..."

                scene e3s26-39 with dissolve
                ca "Here, let's do this standing."
                ca "Maybe you'll get a better grip."

                scene e3s26-37 with dissolve
                mc "Are you ready [ca]?"

                scene e3s26-38 with dissolve
                ca "Do it [mc]..."

                scene e3s26-39 with dissolve
                ca "Insert your dick in that pretty little ass of mine."

                scene e3s26-40 with dissolve
                ca "Ahh... oh my God..."

                # Standing
                scene e3s26-anal_entering1 with dissolve
                pause(5.5)

                scene e3s26-standing_anal1 with dissolve
                mc "You're so tight [ca], it barely fits in there."

                scene e3s26-standing_anal2 with dissolve
                ca "Damn it... fuck!"
                ca "Fuck... it feels so good [mc]!"

                scene e3s26-standing_anal3 with dissolve
                pause

                scene e3s26-standing_anal1 with dissolve
                mc "Oh fuck..."

                scene e3s26-standing_anal2 with dissolve
                pause

                scene e3s26-standing_anal3 with dissolve
                mc "I'll speed up the pace."
                ca "Don't worry sweetie, I can take i-"

                scene e3s26-standing_anal4 with vpunch
                ca "Ahh, fuck!!"

                scene e3s26-standing_anal5 with dissolve
                ca "Yeah [mc], just like that!"
                ca "Fuck... keep going!"

                scene e3s26-standing_anal4 with dissolve
                pause

                scene e3s26-standing_anal5 with dissolve
                pause

                $ GameRunning = True

                while GameRunning:

                    $ renpy.block_rollback()
                    $ config.rollback_enabled = False
                    menu:
                        "Change positions":
                            mc "Here, let's change positions."

                            scene e3s26-41 with dissolve
                            ca "Okay sweetie, how do you want me?"

                            scene e3s26-37 with dissolve
                            mc "Get into doggy."

                            $ GameRunning = False
                        "Keep going":
                            scene e3s26-standing_anal1 with dissolve
                            mc "You're so tight [ca], it barely fits in there."

                            scene e3s26-standing_anal2 with dissolve
                            ca "Damn it... fuck!"
                            ca "Fuck... it feels so good [mc]!"

                            scene e3s26-standing_anal3 with dissolve
                            pause

                            scene e3s26-standing_anal1 with dissolve
                            mc "Oh fuck..."

                            scene e3s26-standing_anal2 with dissolve
                            pause

                            scene e3s26-standing_anal3 with dissolve
                            mc "I'll speed up the pace."
                            ca "Don't worry sweetie, I can take i-"

                            scene e3s26-standing_anal4 with vpunch
                            ca "Ahh, fuck!!"

                            scene e3s26-standing_anal5 with dissolve
                            ca "Yeah [mc], just like that!"
                            ca "Fuck... keep going!"

                            scene e3s26-standing_anal4 with dissolve
                            pause

                            scene e3s26-standing_anal5 with dissolve
                            pause

                # Doggy
                scene e3s26-doggy_anal1 with dissolve
                ca "Fuck [mc]... you're tearing me apart!"

                scene e3s26-doggy_anal2 with dissolve
                mc "Fuck..."

                scene e3s26-doggy_anal3 with dissolve
                pause

                scene e3s26-doggy_anal1 with dissolve
                pause

                scene e3s26-doggy_anal2 with dissolve
                pause

                scene e3s26-doggy_anal4 with dissolve
                ca "Oh my fucking God [mc]..."
                ca "I love that dick!"

                scene e3s26-doggy_anal5 with dissolve
                ca "Fuck... keep tearing my insides apart!"

                scene e3s26-doggy_anal6 with dissolve
                mc "I wanna hear you scream!"
                ca "AHH... FUCK!"
                ca "FUCK ME [mc]!"

                scene e3s26-doggy_anal4 with dissolve
                pause

                scene e3s26-doggy_anal5 with dissolve
                mc "Fuck... your asshole feels so good!"

            # Doggy
            scene e3s26-doggy1 with dissolve
            mc "Fuck [ca], this feels so good!"

            scene e3s26-doggy3 with dissolve
            ca "Shit...!"
            ca "I love it so much [mc]!"

            scene e3s26-doggy2 with dissolve
            ca "I love your dick."
            ca "Fuck me like I'm your little slut."

            scene e3s26-doggy4 with dissolve
            mc "Take it, bitch!"

            scene e3s26-doggy2 with dissolve
            ca "Ahh... that makes me so fucking wet."
            ca "Keep saying it!"

            scene e3s26-doggy4 with dissolve
            mc "Take it slut!"
            mc "I know how much you love this dick."

            scene e3s26-doggy2 with dissolve
            ca "Ahh!!"
        else:
            if persistent.type_nsfw == False:
                scene e3s26-15 with wipeleft
                mc "So... what's up [ca]?"

                scene e3s26-16_cen with dissolve
                play music heartache
                mc "Holy..."

                scene e3s26-17 with dissolve
                pause

                scene e3s26-18_cen with dissolve
                ca "Don't be shy sweetie, come on in!"

                scene e3s26-19 with dissolve
                mc "This is what you needed help with?"

                scene e3s26-20 with dissolve
                ca "Can't a lady have cravings?"

                scene e3s26-19 with dissolve
                mc "I mean, yeah, but I did not expect this."
                mc "Totally not complaining."

                scene e3s26-21 with dissolve
                ca "Ah, ah...!"

                scene e3s26-20 with dissolve
                ca "Clothes aren't allowed in here."
                ca "If you'd like to enter, you have to leave them by the door."

                scene e3s26-19 with dissolve
                mc "Talk about being straightforward!"

                scene e3s26-22 with dissolve
                pause

                scene e3s26-23_cen with dissolve
                ca "The glasses too, silly!"

                scene e3s26-24 with dissolve
                mc "Damn it..."

                scene e3s26-25_cen with dissolve
                ca "Now, let's see what we have here!"

                scene e3s26-26_cen with dissolve
                pause

                # Blowjob
                scene e3s26-blowjob1_cen with dissolve
                mc "Oh [ca], that's amazing!"

                scene e3s26-blowjob2_cen with dissolve
                pause

                scene e3s26-blowjob3_cen with dissolve
                mc "Keep going."

                scene e3s26-blowjob1_cen with dissolve
                mc "*Damn... she goes so fast!*"

                scene e3s26-27_cen with dissolve
                ca "How are you enjoying it so far?"

                scene e3s26-28_cen with dissolve
                mc "It feels really good, [ca]."

                scene e3s26-27_cen with dissolve
                ca "I'm glad!"

                scene e3s26-blowjob2_cen with dissolve
                mc "Ah... fuck!"

                scene e3s26-blowjob3_cen with dissolve
                pause

                scene e3s26-27_cen with dissolve
                ca "How does it feel when I do this?"

                # Handjob
                scene e3s26-handjob1_cen with dissolve
                mc "Ah... shit!"

                scene e3s26-handjob2_cen with dissolve
                mc "Out of this world..."

                scene e3s26-handjob1_cen with dissolve
                pause

                scene e3s26-handjob2_cen with dissolve
                pause

                scene e3s26-27_cen with dissolve
                ca "Now... lie back."
                ca "And let me work my magic."

                scene e3s26-29_cen with dissolve
                pause

                scene e3s26-30_cen with dissolve
                pause

                # Cowgirl
                scene e3s26-cowgirl1_cen with dissolve
                ca "Ah... you're so big [mc]!"

                scene e3s26-cowgirl2_cen with dissolve
                mc "Your pussy feels so good [ca]."

                scene e3s26-cowgirl3_cen with dissolve
                pause

                scene e3s26-cowgirl1_cen with dissolve
                ca "Fuck... [mc]!"
                ca "You're so big."

                scene e3s26-cowgirl2_cen with dissolve
                pause

                scene e3s26-cowgirl3_cen with dissolve
                pause

                scene e3s26-cowgirl4_cen with dissolve
                mc "Ah fuck [ca], keep going!"

                scene e3s26-cowgirl5_cen with dissolve
                ca "Oh, yes [mc]!"

                scene e3s26-cowgirl6_cen with dissolve
                pause

                scene e3s26-cowgirl5_cen with dissolve
                mc "Fuck, this feels so good!"

                scene e3s26-cowgirl6_cen with dissolve
                pause

                scene e3s26-31 with dissolve
                ca "I also have an exclusive service just for you sweetie."

                if candance_trust > 2:
                    pass
                else:
                    ca "Of course, not for free."

                scene e3s26-32 with dissolve
                mc "What service are we talking about?"

                scene e3s26-33_cen with dissolve
                pause

                # Anal
                scene e3s26-32 with dissolve

                if not _in_replay:
                    if candance_trust > 2:
                        menu:
                            "Try anal":
                                mc "Thought you wouldn't ask."
                                mc "Teasing me with that sweet ass of yours."

                                scene e3s26-34 with dissolve
                                ca "I knew you'd like chocolate!"

                                scene e3s26-32 with dissolve
                                menu:
                                    "Chocolate":
                                        $ candance_trust += 2
                                        $ e3s26_chocolate = True

                                        mc "I like chocolate."

                                        scene e3s26-35 with dissolve
                                        ca "Aren't you Prince Charming?"
                                    "Vanilla":
                                        $ e3s26_vanilla = True

                                        mc "I prefer vanilla."
                                    "Both":
                                        $ candance_trust += 1

                                        mc "I also like vanilla."
                                        mc "I like vanilla just as much as I like chocolate."

                                scene e3s26-34 with dissolve
                                ca "Good to know!"

                                $ e3s26_anal = True
                                $ persistent.e3s26_anal = True

                            "Pass the offer":
                                mc "Thanks for the offer but I'm good."
                                mc "I'll stick to vanilla for now."

                                scene e3s26-31 with dissolve
                                ca "I thought you liked chocolate."

                                scene e3s26-32 with dissolve
                                menu:
                                    "Chocolate":
                                        $ candance_trust += 2
                                        $ e3s26_chocolate = True

                                        mc "I like chocolate."

                                        scene e3s26-35 with dissolve
                                        ca "Aren't you Prince Charming?"
                                    "Vanilla":
                                        $ e3s26_vanilla = True

                                        mc "I prefer vanilla."
                                    "Both":
                                        $ candance_trust += 1

                                        mc "I also like chocolate."
                                        mc "I like chocolate just as much as I do vanilla."

                                scene e3s26-34 with dissolve
                                ca "Good to know!"
                    else:
                        $ renpy.show_screen("money_notify_pers")
                        menu:
                            "Try anal {color=#f00}(-$1){/color}" if money > 0:
                                $ renpy.show_screen("money_notify")
                                $ renpy.hide_screen("money_notify_pers")

                                mc "Thought you wouldn't ask."
                                mc "Teasing me with that sweet ass of yours."

                                scene e3s26-34 with dissolve
                                ca "I knew you'd like chocolate!"

                                scene e3s26-32 with dissolve
                                menu:
                                    "Chocolate":
                                        $ candance_trust += 2
                                        $ e3s26_chocolate = True

                                        mc "I like chocolate."

                                        scene e3s26-35 with dissolve
                                        ca "Aren't you Prince Charming?"
                                    "Vanilla":
                                        $ e3s26_vanilla = True

                                        mc "I prefer vanilla."
                                    "Both":
                                        $ candance_trust += 1

                                        mc "I also like vanilla."
                                        mc "I like vanilla just as much as I like chocolate."

                                scene e3s26-34 with dissolve
                                ca "Good to know!"

                                $ e3s26_anal = True
                                $ persistent.e3s26_anal = True

                            "Pass the offer":
                                mc "Thanks for the offer but I'm good."
                                mc "I'll stick to vanilla for now."

                                scene e3s26-31 with dissolve
                                ca "I thought you liked chocolate."

                                scene e3s26-32 with dissolve
                                menu:
                                    "Chocolate":
                                        $ candance_trust += 2
                                        $ e3s26_chocolate = True

                                        mc "I like chocolate."

                                        scene e3s26-35 with dissolve
                                        ca "Aren't you Prince Charming?"
                                    "Vanilla":
                                        $ e3s26_vanilla = True

                                        mc "I prefer vanilla."
                                    "Both":
                                        $ candance_trust += 1

                                        mc "I also like chocolate."
                                        mc "I like chocolate just as much as I do vanilla."

                                scene e3s26-34 with dissolve
                                ca "Good to know!"
                else:
                    menu:
                        "Try anal" if persistent.e3s26_anal == True:
                            $ e3s26_anal = True
                            $ persistent.e3s26_anal = True
                            mc "Thought you wouldn't ask."
                            mc "Teasing me with that sweet ass of yours."

                            scene e3s26-34 with dissolve
                            ca "I knew you'd like chocolate!"

                            scene e3s26-32 with dissolve
                            menu:
                                "Chocolate":
                                    $ candance_trust += 2
                                    $ e3s26_chocolate = True

                                    mc "I like chocolate"

                                    scene e3s26-35 with dissolve
                                    ca "Aren't you Prince Charming?"
                                "Vanilla":
                                    $ e3s26_vanilla = True

                                    mc "I prefer vanilla."
                                "Both":
                                    $ candance_trust += 1

                                    mc "I also like vanilla."
                                    mc "I like vanilla just as much as I like chocolate."

                            scene e3s26-34 with dissolve
                            ca "Good to know!"

                        "Pass the offer":
                            mc "Thanks for the offer but I'm good."
                            mc "I'll stick to vanilla for now."

                            scene e3s26-31 with dissolve
                            ca "I thought you liked chocolate."

                            scene e3s26-32 with dissolve
                            menu:
                                "Chocolate":
                                    $ candance_trust += 2
                                    $ e3s26_chocolate = True

                                    mc "I like chocolate."

                                    scene e3s26-35 with dissolve
                                    ca "Aren't you Prince Charming?"
                                "Vanilla":
                                    $ e3s26_vanilla = True

                                    mc "I prefer vanilla."
                                "Both":
                                    $ candance_trust += 1

                                    mc "I also like chocolate."
                                    mc "I like chocolate just as much as I do vanilla."

                            scene e3s26-34 with dissolve
                            ca "Good to know!"

                if persistent.e3s26_anal == True:
                    scene e3s26-36 with dissolve
                    ca "Just let me get it ready for you sweetie."

                    scene e3s26-33_cen with dissolve
                    ca "Ah..."

                    scene e3s26-39_cen with dissolve
                    ca "Here, let's do this standing."
                    ca "Maybe you'll get a better grip."

                    scene e3s26-37_cen with dissolve
                    mc "Are you ready [ca]?"

                    scene e3s26-38_cen with dissolve
                    ca "Do it [mc]..."

                    scene e3s26-39_cen with dissolve
                    ca "Insert your dick in that pretty little ass of mine."

                    scene e3s26-40_cen with dissolve
                    ca "Ahh... oh my God..."

                    # Standing
                    scene e3s26-anal_entering1_cen with dissolve
                    pause(5.5)

                    scene e3s26-standing_anal1_cen with dissolve
                    mc "You're so tight [ca], it barely fits in there."

                    scene e3s26-standing_anal2_cen with dissolve
                    ca "Damn it... fuck!"
                    ca "Fuck... it feels so good [mc]!"

                    scene e3s26-standing_anal3_cen with dissolve
                    pause

                    scene e3s26-standing_anal1_cen with dissolve
                    mc "Oh fuck..."

                    scene e3s26-standing_anal2_cen with dissolve
                    pause

                    scene e3s26-standing_anal3_cen with dissolve
                    mc "I'll speed up the pace."
                    ca "Don't worry sweetie, I can take i-"

                    scene e3s26-standing_anal4_cen with vpunch
                    ca "Ahh, fuck!!"

                    scene e3s26-standing_anal5_cen with dissolve
                    ca "Yeah [mc], just like that!"
                    ca "Fuck... keep going!"

                    scene e3s26-standing_anal4_cen with dissolve
                    pause

                    scene e3s26-standing_anal5_cen with dissolve
                    pause

                    $ GameRunning = True

                    while GameRunning:

                        $ renpy.block_rollback()
                        $ config.rollback_enabled = False
                        menu:
                            "Change positions":
                                mc "Here, let's change positions."

                                scene e3s26-41_cen with dissolve
                                ca "Okay sweetie, how do you want me?"

                                scene e3s26-37_cen with dissolve
                                mc "Get into doggy."

                                $ GameRunning = False
                            "Keep going":
                                scene e3s26-standing_anal1_cen with dissolve
                                mc "You're so tight [ca], it barely fits in there."

                                scene e3s26-standing_anal2_cen with dissolve
                                ca "Damn it... fuck!"
                                ca "Fuck... it feels so good [mc]!"

                                scene e3s26-standing_anal3_cen with dissolve
                                pause

                                scene e3s26-standing_anal1_cen with dissolve
                                mc "Oh fuck..."

                                scene e3s26-standing_anal2_cen with dissolve
                                pause

                                scene e3s26-standing_anal3_cen with dissolve
                                mc "I'll speed up the pace."
                                ca "Don't worry sweetie, I can take i-"

                                scene e3s26-standing_anal4_cen with vpunch
                                ca "Ahh, fuck!!"

                                scene e3s26-standing_anal5_cen with dissolve
                                ca "Yeah [mc], just like that!"
                                ca "Fuck... keep going!"

                                scene e3s26-standing_anal4_cen with dissolve
                                pause

                                scene e3s26-standing_anal5_cen with dissolve
                                pause

                    # Doggy
                    scene e3s26-doggy_anal1_cen with dissolve
                    ca "Fuck [mc]... you're tearing me apart!"

                    scene e3s26-doggy_anal2_cen with dissolve
                    mc "Fuck..."

                    scene e3s26-doggy_anal3_cen with dissolve
                    pause

                    scene e3s26-doggy_anal1_cen with dissolve
                    pause

                    scene e3s26-doggy_anal2_cen with dissolve
                    pause

                    scene e3s26-doggy_anal4_cen with dissolve
                    ca "Oh my fucking God [mc]..."
                    ca "I love that dick!"

                    scene e3s26-doggy_anal5_cen with dissolve
                    ca "Fuck... keep tearing my insides apart!"

                    scene e3s26-doggy_anal6_cen with dissolve
                    mc "I wanna hear you scream!"
                    ca "AHH... FUCK!"
                    ca "FUCK ME [mc]!"

                    scene e3s26-doggy_anal4_cen with dissolve
                    pause

                    scene e3s26-doggy_anal5_cen with dissolve
                    mc "Fuck... your asshole feels so good!"

                # Doggy
                scene e3s26-doggy1_cen with dissolve
                mc "Fuck [ca], this feels so good!"

                scene e3s26-doggy3_cen with dissolve
                ca "Shit...!"
                ca "I love it so much [mc]!"

                scene e3s26-doggy2_cen with dissolve
                ca "I love your dick."
                ca "Fuck me like I'm your little slut."

                scene e3s26-doggy4_cen with dissolve
                mc "Take it, bitch!"

                scene e3s26-doggy2_cen with dissolve
                ca "Ahh... that makes me so fucking wet."
                ca "Keep saying it!"

                scene e3s26-doggy4_cen with dissolve
                mc "Take it slut!"
                mc "I know how much you love this dick."

                scene e3s26-doggy2_cen with dissolve
                ca "Ahh!!"

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            if e3s26_anal == True:
                menu:
                    "Blowjob":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-blowjob1 with dissolve
                            mc "Oh [ca], that's amazing!"

                            scene e3s26-blowjob2 with dissolve
                            pause

                            scene e3s26-blowjob3 with dissolve
                            mc "Keep going."

                            scene e3s26-blowjob1 with dissolve
                            mc "*Damn... she goes so fast!*"

                            scene e3s26-27 with dissolve
                            ca "How are you enjoying it so far?"

                            scene e3s26-28 with dissolve
                            mc "It feels really good, [ca]."

                            scene e3s26-27 with dissolve
                            ca "I'm glad!"

                            scene e3s26-blowjob2 with dissolve
                            mc "Ah... fuck!"

                            scene e3s26-blowjob3 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-blowjob1_cen with dissolve
                                mc "Oh [ca], that's amazing!"

                                scene e3s26-blowjob2_cen with dissolve
                                pause

                                scene e3s26-blowjob3_cen with dissolve
                                mc "Keep going."

                                scene e3s26-blowjob1_cen with dissolve
                                mc "*Damn... she goes so fast!*"

                                scene e3s26-27_cen with dissolve
                                ca "How are you enjoying it so far?"

                                scene e3s26-28_cen with dissolve
                                mc "It feels really good, [ca]."

                                scene e3s26-27_cen with dissolve
                                ca "I'm glad!"

                                scene e3s26-blowjob2_cen with dissolve
                                mc "Ah... fuck!"

                                scene e3s26-blowjob3_cen with dissolve
                                pause
                    "Handjob":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-handjob1 with dissolve
                            mc "Ah... shit!"

                            scene e3s26-handjob2 with dissolve
                            mc "Out of this world..."

                            scene e3s26-handjob1 with dissolve
                            pause

                            scene e3s26-handjob2 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-handjob1_cen with dissolve
                                mc "Ah... shit!"

                                scene e3s26-handjob2_cen with dissolve
                                mc "Out of this world..."

                                scene e3s26-handjob1_cen with dissolve
                                pause

                                scene e3s26-handjob2_cen with dissolve
                                pause
                    "Cowgirl":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-cowgirl1 with dissolve
                            ca "Ah... you're so big [mc]!"

                            scene e3s26-cowgirl2 with dissolve
                            mc "Your pussy feels so good [ca]."

                            scene e3s26-cowgirl3 with dissolve
                            pause

                            scene e3s26-cowgirl1 with dissolve
                            ca "Fuck... [mc]!"
                            ca "You're so big."

                            scene e3s26-cowgirl2 with dissolve
                            pause

                            scene e3s26-cowgirl3 with dissolve
                            pause

                            scene e3s26-cowgirl4 with dissolve
                            mc "Ah fuck [ca], keep going!"

                            scene e3s26-cowgirl5 with dissolve
                            ca "Oh, yes [mc]!"

                            scene e3s26-cowgirl6 with dissolve
                            pause

                            scene e3s26-cowgirl5 with dissolve
                            mc "Fuck, this feels so good!"

                            scene e3s26-cowgirl6 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-cowgirl1_cen with dissolve
                                ca "Ah... you're so big [mc]!"

                                scene e3s26-cowgirl2_cen with dissolve
                                mc "Your pussy feels so good [ca]."

                                scene e3s26-cowgirl3_cen with dissolve
                                pause

                                scene e3s26-cowgirl1_cen with dissolve
                                ca "Fuck... [mc]!"
                                ca "You're so big."

                                scene e3s26-cowgirl2_cen with dissolve
                                pause

                                scene e3s26-cowgirl3_cen with dissolve
                                pause

                                scene e3s26-cowgirl4_cen with dissolve
                                mc "Ah fuck [ca], keep going!"

                                scene e3s26-cowgirl5_cen with dissolve
                                ca "Oh, yes [mc]!"

                                scene e3s26-cowgirl6_cen with dissolve
                                pause

                                scene e3s26-cowgirl5_cen with dissolve
                                mc "Fuck, this feels so good!"

                                scene e3s26-cowgirl6_cen with dissolve
                                pause
                    "Anal":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-standing_anal1 with dissolve
                            mc "You're so tight [ca], it barely fits in there."

                            scene e3s26-standing_anal2 with dissolve
                            ca "Damn it... fuck!"
                            ca "Fuck... it feels so good [mc]!"

                            scene e3s26-standing_anal3 with dissolve
                            pause

                            scene e3s26-standing_anal1 with dissolve
                            mc "Oh fuck..."

                            scene e3s26-standing_anal2 with dissolve
                            pause

                            scene e3s26-standing_anal3 with dissolve
                            mc "I'll speed up the pace."

                            scene e3s26-standing_anal4 with dissolve
                            ca "Ahh, fuck!!"

                            scene e3s26-standing_anal5 with dissolve
                            ca "Yeah [mc], just like that!"
                            ca "Fuck... keep going!"

                            scene e3s26-standing_anal4 with dissolve
                            pause

                            scene e3s26-standing_anal5 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-standing_anal1_cen with dissolve
                                mc "You're so tight [ca], it barely fits in there."

                                scene e3s26-standing_anal2_cen with dissolve
                                ca "Damn it... fuck!"
                                ca "Fuck... it feels so good [mc]!"

                                scene e3s26-standing_anal3_cen with dissolve
                                pause

                                scene e3s26-standing_anal1_cen with dissolve
                                mc "Oh fuck..."

                                scene e3s26-standing_anal2_cen with dissolve
                                pause

                                scene e3s26-standing_anal3_cen with dissolve
                                mc "I'll speed up the pace."

                                scene e3s26-standing_anal4_cen with dissolve
                                ca "Ahh, fuck!!"

                                scene e3s26-standing_anal5_cen with dissolve
                                ca "Yeah [mc], just like that!"
                                ca "Fuck... keep going!"

                                scene e3s26-standing_anal4_cen with dissolve
                                pause

                                scene e3s26-standing_anal5_cen with dissolve
                                pause
                    "Doggy anal":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-doggy_anal1 with dissolve
                            ca "Fuck [mc]... you're tearing me apart!"

                            scene e3s26-doggy_anal2 with dissolve
                            mc "Fuck..."

                            scene e3s26-doggy_anal3 with dissolve
                            pause

                            scene e3s26-doggy_anal1 with dissolve
                            pause

                            scene e3s26-doggy_anal2 with dissolve
                            pause

                            scene e3s26-doggy_anal4 with dissolve
                            ca "Oh my fucking God [mc]..."
                            ca "I love that dick!"

                            scene e3s26-doggy_anal5 with dissolve
                            ca "Fuck... keep tearing my insides apart!"

                            scene e3s26-doggy_anal6 with dissolve
                            mc "I wanna hear you scream!"
                            ca "AHH... FUCK!"
                            ca "FUCK ME [mc]!"

                            scene e3s26-doggy_anal4 with dissolve
                            pause

                            scene e3s26-doggy_anal5 with dissolve
                            mc "Fuck... your asshole feels so good!"
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-doggy_anal1_cen with dissolve
                                ca "Fuck [mc]... you're tearing me apart!"

                                scene e3s26-doggy_anal2_cen with dissolve
                                mc "Fuck..."

                                scene e3s26-doggy_anal3_cen with dissolve
                                pause

                                scene e3s26-doggy_anal1_cen with dissolve
                                pause

                                scene e3s26-doggy_anal2_cen with dissolve
                                pause

                                scene e3s26-doggy_anal4_cen with dissolve
                                ca "Oh my fucking God [mc]..."
                                ca "I love that dick!"

                                scene e3s26-doggy_anal5_cen with dissolve
                                ca "Fuck... keep tearing my insides apart!"

                                scene e3s26-doggy_anal6_cen with dissolve
                                mc "I wanna hear you scream!"
                                ca "AHH... FUCK!"
                                ca "FUCK ME [mc]!"

                                scene e3s26-doggy_anal4_cen with dissolve
                                pause

                                scene e3s26-doggy_anal5_cen with dissolve
                                mc "Fuck... your asshole feels so good!"
                    "Doggy vaginal":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-doggy1 with dissolve
                            mc "Fuck [ca], this feels so good!"

                            scene e3s26-doggy3 with dissolve
                            ca "Shit...!"
                            ca "I love it so much [mc]!"

                            scene e3s26-doggy2 with dissolve
                            ca "I love your dick."
                            ca "Fuck me like I'm your little slut."

                            scene e3s26-doggy4 with dissolve
                            mc "Take it, bitch!"

                            scene e3s26-doggy2 with dissolve
                            ca "Ahh... that makes me so fucking wet."
                            ca "Keep saying it!"

                            scene e3s26-doggy4 with dissolve
                            mc "Take it slut!"
                            mc "I know how much you love this dick."

                            scene e3s26-doggy2 with dissolve
                            ca "Ahh!!"
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-doggy1_cen with dissolve
                                mc "Fuck [ca], this feels so good!"

                                scene e3s26-doggy3_cen with dissolve
                                ca "Shit...!"
                                ca "I love it so much [mc]!"

                                scene e3s26-doggy2_cen with dissolve
                                ca "I love your dick."
                                ca "Fuck me like I'm your little slut."

                                scene e3s26-doggy4_cen with dissolve
                                mc "Take it, bitch!"

                                scene e3s26-doggy2_cen with dissolve
                                ca "Ahh... that makes me so fucking wet."
                                ca "Keep saying it!"

                                scene e3s26-doggy4_cen with dissolve
                                mc "Take it slut!"
                                mc "I know how much you love this dick."

                                scene e3s26-doggy2_cen with dissolve
                                ca "Ahh!!"
                    "Cum":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:

                            mc "[ca], I'm about to cum."

                            scene e3s26-handjob2 with dissolve
                            ca "Give me your cum, [mc]!"
                            ca "Cum on my pretty face."
                            ca "Let it go, just like that!"
                            mc "Fuck..."

                            scene e3s26-42 with dissolve
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3s26-43 with dissolve
                            mc "My God... that was so good!"
                            mc "Thanks [ca]."

                            scene e3s26-44 with dissolve
                            ca "You're welcome sweetie!"

                            scene e3s26-45 with dissolve
                            mc "Damn, I'm wasted."
                            mc "I'mma just lie down here a bit."

                            stop music fadeout 2.0
                            scene e3s26-46 with dissolve
                            play music the_darker_side
                            ca "Be careful [mc], moments like there are pretty expensive."

                            scene e3s26-47 with dissolve
                            mc "Haha, are we really gonna talk money right now?"
                            mc "You let me fuck you for free and then charge me for a bit of after care?"

                            scene e3s26-48 with dissolve
                            ca "In this world and age..."
                            ca "Intimacy is more expensive than sex."

                            scene e3s26-49 with dissolve
                            mc "Yeah... I guess you're right."

                            scene e3s26-52 with dissolve
                            mc "Hey, are you allowed to smoke in here?"

                            scene e3s26-50 with dissolve
                            ca "Yeah..."

                            scene e3s26-51 with dissolve
                            ca "No?"
                            ca "I don't know to be honest."

                            scene e3s26-52 with dissolve
                            mc "Anyways, random thought..."

                            scene e3s26-53 with dissolve
                            mc "Hope I'm not ruining the mood here."

                            scene e3s26-52 with dissolve
                            mc "What was up with that prick from a couple of days ago?"
                            mc "We didn't really talk about that."

                            scene e3s26-55 with dissolve
                            ca "He's just some asshole who I've done business with."
                            ca "More specifically, I've been using substances from him."

                            scene e3s26-50 with dissolve
                            ca "I wanted to quit and he's still charging me for the service."
                            ca "Even though I'm not buying anymore."

                            scene e3s26-54 with dissolve
                            mc "What the hell?"
                            mc "What's wrong with him?"

                            scene e3s26-55 with dissolve
                            ca "I don't know."

                            scene e3s26-52 with dissolve
                            mc "Why were you using?"

                            scene e3s26-48 with dissolve
                            ca "This job comes with a lot of sacrifices [mc]."

                            scene e3s26-51 with dissolve
                            ca "It was my way of coping and escaping reality."

                            scene e3s26-53 with dissolve
                            mc "It doesn't sound like you're enjoying this kind of lifestyle."

                            scene e3s26-56 with dissolve
                            ca "You're right, I don't."
                            ca "But what can you do now?"

                            scene e3s26-57 with dissolve
                            ca "It's paying the bills, right."

                            scene e3s26-52 with dissolve
                            mc "Just move away."
                            mc "Start a new life."

                            scene e3s26-53 with dissolve
                            mc "Just... do whatever else."

                            scene e3s26-50 with dissolve
                            ca "It's not so simple."

                            scene e3s26-57 with dissolve
                            ca "Let's just... stop talking about this, alright?"
                            ca "Let's just lie here for a bit."

                            scene e3s26-58 with dissolve
                            pause

                            stop music fadeout 2.0
                            scene e3s26-59 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:

                                mc "[ca], I'm about to cum."

                                scene e3s26-handjob2_cen with dissolve
                                ca "Give me your cum, [mc]!"
                                ca "Cum on my pretty face."
                                ca "Let it go, just like that!"
                                mc "Fuck..."

                                scene e3s26-42_cen with dissolve
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)

                                scene e3s26-43_cen with dissolve
                                mc "My God... that was so good!"
                                mc "Thanks [ca]."

                                scene e3s26-44_cen with dissolve
                                ca "You're welcome sweetie!"

                                scene e3s26-45 with dissolve
                                mc "Damn, I'm wasted."
                                mc "I'mma just lie down here a bit."

                                stop music fadeout 2.0
                                scene e3s26-46_cen with dissolve
                                play music the_darker_side
                                ca "Be careful [mc], moments like there are pretty expensive."

                                scene e3s26-47_cen with dissolve
                                mc "Haha, are we really gonna talk money right now?"
                                mc "You let me fuck you for free and then charge me for a bit of after care?"

                                scene e3s26-48_cen with dissolve
                                ca "In this world and age..."
                                ca "Intimacy is more expensive than sex."

                                scene e3s26-49_cen with dissolve
                                mc "Yeah... I guess you're right."

                                scene e3s26-52 with dissolve
                                mc "Hey, are you allowed to smoke in here?"

                                scene e3s26-50 with dissolve
                                ca "Yeah..."

                                scene e3s26-51 with dissolve
                                ca "No?"
                                ca "I don't know to be honest."

                                scene e3s26-52 with dissolve
                                mc "Anyways, random thought..."

                                scene e3s26-53 with dissolve
                                mc "Hope I'm not ruining the mood here."

                                scene e3s26-52 with dissolve
                                mc "What was up with that prick from a couple of days ago?"
                                mc "We didn't really talk about that."

                                scene e3s26-55_cen with dissolve
                                ca "He's just some asshole who I've done business with."
                                ca "More specifically, I've been using substances from him."

                                scene e3s26-50 with dissolve
                                ca "I wanted to quit and he's still charging me for the service."
                                ca "Even though I'm not buying anymore."

                                scene e3s26-54 with dissolve
                                mc "What the hell?"
                                mc "What's wrong with him?"

                                scene e3s26-55_cen with dissolve
                                ca "I don't know."

                                scene e3s26-52 with dissolve
                                mc "Why were you using?"

                                scene e3s26-48_cen with dissolve
                                ca "This job comes with a lot of sacrifices [mc]."

                                scene e3s26-51 with dissolve
                                ca "It was my way of coping and escaping reality."

                                scene e3s26-53 with dissolve
                                mc "It doesn't sound like you're enjoying this kind of lifestyle."

                                scene e3s26-56 with dissolve
                                ca "You're right, I don't."
                                ca "But what can you do now?"

                                scene e3s26-57 with dissolve
                                ca "It's paying the bills, right."

                                scene e3s26-52 with dissolve
                                mc "Just move away."
                                mc "Start a new life."

                                scene e3s26-53 with dissolve
                                mc "Just... do whatever else."

                                scene e3s26-50 with dissolve
                                ca "It's not so simple."

                                scene e3s26-57 with dissolve
                                ca "Let's just... stop talking about this, alright?"
                                ca "Let's just lie here for a bit."

                                scene e3s26-58 with dissolve
                                pause

                                stop music fadeout 2.0
                                scene e3s26-59_cen with dissolve
                                pause

                        $ GameRunning = False
            else:
                menu:
                    "Blowjob":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-blowjob1 with dissolve
                            mc "Oh [ca], that's amazing!"

                            scene e3s26-blowjob2 with dissolve
                            pause

                            scene e3s26-blowjob3 with dissolve
                            mc "Keep going."

                            scene e3s26-blowjob1 with dissolve
                            mc "*Damn... she goes so fast!*"

                            scene e3s26-27 with dissolve
                            ca "How are you enjoying it so far?"

                            scene e3s26-28 with dissolve
                            mc "It feels really good, [ca]."

                            scene e3s26-27 with dissolve
                            ca "I'm glad!"

                            scene e3s26-blowjob2 with dissolve
                            mc "Ah... fuck!"

                            scene e3s26-blowjob3 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-blowjob1_cen with dissolve
                                mc "Oh [ca], that's amazing!"

                                scene e3s26-blowjob2_cen with dissolve
                                pause

                                scene e3s26-blowjob3_cen with dissolve
                                mc "Keep going."

                                scene e3s26-blowjob1_cen with dissolve
                                mc "*Damn... she goes so fast!*"

                                scene e3s26-27_cen with dissolve
                                ca "How are you enjoying it so far?"

                                scene e3s26-28_cen with dissolve
                                mc "It feels really good, [ca]."

                                scene e3s26-27_cen with dissolve
                                ca "I'm glad!"

                                scene e3s26-blowjob2_cen with dissolve
                                mc "Ah... fuck!"

                                scene e3s26-blowjob3_cen with dissolve
                                pause
                    "Handjob":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-handjob1 with dissolve
                            mc "Ah... shit!"

                            scene e3s26-handjob2 with dissolve
                            mc "Out of this world..."

                            scene e3s26-handjob1 with dissolve
                            pause

                            scene e3s26-handjob2 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-handjob1_cen with dissolve
                                mc "Ah... shit!"

                                scene e3s26-handjob2_cen with dissolve
                                mc "Out of this world..."

                                scene e3s26-handjob1_cen with dissolve
                                pause

                                scene e3s26-handjob2_cen with dissolve
                                pause
                    "Cowgirl":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-cowgirl1 with dissolve
                            ca "Ah... you're so big [mc]!"

                            scene e3s26-cowgirl2 with dissolve
                            mc "Your pussy feels so good [ca]."

                            scene e3s26-cowgirl3 with dissolve
                            pause

                            scene e3s26-cowgirl1 with dissolve
                            ca "Fuck... [mc]!"
                            ca "You're so big."

                            scene e3s26-cowgirl2 with dissolve
                            pause

                            scene e3s26-cowgirl3 with dissolve
                            pause

                            scene e3s26-cowgirl4 with dissolve
                            mc "Ah fuck [ca], keep going!"

                            scene e3s26-cowgirl5 with dissolve
                            ca "Oh, yes [mc]!"

                            scene e3s26-cowgirl6 with dissolve
                            pause

                            scene e3s26-cowgirl5 with dissolve
                            mc "Fuck, this feels so good!"

                            scene e3s26-cowgirl6 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-cowgirl1_cen with dissolve
                                ca "Ah... you're so big [mc]!"

                                scene e3s26-cowgirl2_cen with dissolve
                                mc "Your pussy feels so good [ca]."

                                scene e3s26-cowgirl3_cen with dissolve
                                pause

                                scene e3s26-cowgirl1_cen with dissolve
                                ca "Fuck... [mc]!"
                                ca "You're so big."

                                scene e3s26-cowgirl2_cen with dissolve
                                pause

                                scene e3s26-cowgirl3_cen with dissolve
                                pause

                                scene e3s26-cowgirl4_cen with dissolve
                                mc "Ah fuck [ca], keep going!"

                                scene e3s26-cowgirl5_cen with dissolve
                                ca "Oh, yes [mc]!"

                                scene e3s26-cowgirl6_cen with dissolve
                                pause

                                scene e3s26-cowgirl5_cen with dissolve
                                mc "Fuck, this feels so good!"

                                scene e3s26-cowgirl6_cen with dissolve
                                pause
                    "Doggy":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:
                            scene e3s26-doggy1 with dissolve
                            mc "Fuck [ca], this feels so good!"

                            scene e3s26-doggy3 with dissolve
                            ca "Shit...!"
                            ca "I love it so much [mc]!"

                            scene e3s26-doggy2 with dissolve
                            ca "I love your dick."
                            ca "Fuck me like I'm your little slut."

                            scene e3s26-doggy4 with dissolve
                            mc "Take it, bitch!"

                            scene e3s26-doggy2 with dissolve
                            ca "Ahh... that makes me so fucking wet."
                            ca "Keep saying it!"

                            scene e3s26-doggy4 with dissolve
                            mc "Take it slut!"
                            mc "I know how much you love this dick."

                            scene e3s26-doggy2 with dissolve
                            ca "Ahh!!"
                        else:
                            if persistent.type_nsfw == False:
                                scene e3s26-doggy1_cen with dissolve
                                mc "Fuck [ca], this feels so good!"

                                scene e3s26-doggy3_cen with dissolve
                                ca "Shit...!"
                                ca "I love it so much [mc]!"

                                scene e3s26-doggy2_cen with dissolve
                                ca "I love your dick."
                                ca "Fuck me like I'm your little slut."

                                scene e3s26-doggy4_cen with dissolve
                                mc "Take it, bitch!"

                                scene e3s26-doggy2_cen with dissolve
                                ca "Ahh... that makes me so fucking wet."
                                ca "Keep saying it!"

                                scene e3s26-doggy4_cen with dissolve
                                mc "Take it slut!"
                                mc "I know how much you love this dick."

                                scene e3s26-doggy2_cen with dissolve
                                ca "Ahh!!"
                    "Cum":
                        $ config.rollback_enabled = True

                        if persistent.disable_nsfw == True:

                            mc "[ca], I'm about to cum."

                            scene e3s26-handjob2 with dissolve
                            ca "Give me your cum, [mc]!"
                            ca "Cum on my pretty face."
                            ca "Let it go, just like that!"
                            mc "Fuck..."

                            scene e3s26-42 with dissolve
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3s26-43 with dissolve
                            mc "My God... that was so good!"
                            mc "Thanks [ca]."

                            scene e3s26-44 with dissolve
                            ca "You're welcome sweetie!"

                            scene e3s26-45 with dissolve
                            mc "Damn, I'm wasted."
                            mc "I'mma just lie down here a bit."

                            stop music fadeout 2.0
                            scene e3s26-46 with dissolve
                            play music the_darker_side
                            ca "Be careful [mc], moments like there are pretty expensive."

                            scene e3s26-47 with dissolve
                            mc "Haha, are we really gonna talk money right now?"
                            mc "You let me fuck you for free and then charge me for a bit of after care?"

                            scene e3s26-48 with dissolve
                            ca "In this world and age..."
                            ca "Intimacy is more expensive than sex."

                            scene e3s26-49 with dissolve
                            mc "Yeah... I guess you're right."

                            scene e3s26-52 with dissolve
                            mc "Hey, are you allowed to smoke in here?"

                            scene e3s26-50 with dissolve
                            ca "Yeah..."

                            scene e3s26-51 with dissolve
                            ca "No?"
                            ca "I don't know to be honest."

                            scene e3s26-52 with dissolve
                            mc "Anyways, random thought..."

                            scene e3s26-53 with dissolve
                            mc "Hope I'm not ruining the mood here."

                            scene e3s26-52 with dissolve
                            mc "What was up with that prick from a couple of days ago?"
                            mc "We didn't really talk about that."

                            scene e3s26-55 with dissolve
                            ca "He's just some asshole who I've done business with."
                            ca "More specifically, I've been using substances from him."

                            scene e3s26-50 with dissolve
                            ca "I wanted to quit and he's still charging me for the service."
                            ca "Even though I'm not buying anymore."

                            scene e3s26-54 with dissolve
                            mc "What the hell?"
                            mc "What's wrong with him?"

                            scene e3s26-55 with dissolve
                            ca "I don't know."

                            scene e3s26-52 with dissolve
                            mc "Why were you using?"

                            scene e3s26-48 with dissolve
                            ca "This job comes with a lot of sacrifices [mc]."

                            scene e3s26-51 with dissolve
                            ca "It was my way of coping and escaping reality."

                            scene e3s26-53 with dissolve
                            mc "It doesn't sound like you're enjoying this kind of lifestyle."

                            scene e3s26-56 with dissolve
                            ca "You're right, I don't."
                            ca "But what can you do now?"

                            scene e3s26-57 with dissolve
                            ca "It's paying the bills, right."

                            scene e3s26-52 with dissolve
                            mc "Just move away."
                            mc "Start a new life."

                            scene e3s26-53 with dissolve
                            mc "Just... do whatever else."

                            scene e3s26-50 with dissolve
                            ca "It's not so simple."

                            scene e3s26-57 with dissolve
                            ca "Let's just... stop talking about this, alright?"
                            ca "Let's just lie here for a bit."

                            scene e3s26-58 with dissolve
                            pause

                            stop music fadeout 2.0
                            scene e3s26-59 with dissolve
                            pause
                        else:
                            if persistent.type_nsfw == False:

                                mc "[ca], I'm about to cum."

                                scene e3s26-handjob2_cen with dissolve
                                ca "Give me your cum, [mc]!"
                                ca "Cum on my pretty face."
                                ca "Let it go, just like that!"
                                mc "Fuck..."

                                scene e3s26-42_cen with dissolve
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)

                                scene e3s26-43_cen with dissolve
                                mc "My God... that was so good!"
                                mc "Thanks [ca]."

                                scene e3s26-44_cen with dissolve
                                ca "You're welcome sweetie!"

                                scene e3s26-45 with dissolve
                                mc "Damn, I'm wasted."
                                mc "I'mma just lie down here a bit."

                                stop music fadeout 2.0
                                scene e3s26-46_cen with dissolve
                                play music the_darker_side
                                ca "Be careful [mc], moments like there are pretty expensive."

                                scene e3s26-47_cen with dissolve
                                mc "Haha, are we really gonna talk money right now?"
                                mc "You let me fuck you for free and then charge me for a bit of after care?"

                                scene e3s26-48_cen with dissolve
                                ca "In this world and age..."
                                ca "Intimacy is more expensive than sex."

                                scene e3s26-49_cen with dissolve
                                mc "Yeah... I guess you're right."

                                scene e3s26-52 with dissolve
                                mc "Hey, are you allowed to smoke in here?"

                                scene e3s26-50 with dissolve
                                ca "Yeah..."

                                scene e3s26-51 with dissolve
                                ca "No?"
                                ca "I don't know to be honest."

                                scene e3s26-52 with dissolve
                                mc "Anyways, random thought..."

                                scene e3s26-53 with dissolve
                                mc "Hope I'm not ruining the mood here."

                                scene e3s26-52 with dissolve
                                mc "What was up with that prick from a couple of days ago?"
                                mc "We didn't really talk about that."

                                scene e3s26-55_cen with dissolve
                                ca "He's just some asshole who I've done business with."
                                ca "More specifically, I've been using substances from him."

                                scene e3s26-50 with dissolve
                                ca "I wanted to quit and he's still charging me for the service."
                                ca "Even though I'm not buying anymore."

                                scene e3s26-54 with dissolve
                                mc "What the hell?"
                                mc "What's wrong with him?"

                                scene e3s26-55_cen with dissolve
                                ca "I don't know."

                                scene e3s26-52 with dissolve
                                mc "Why were you using?"

                                scene e3s26-48_cen with dissolve
                                ca "This job comes with a lot of sacrifices [mc]."

                                scene e3s26-51 with dissolve
                                ca "It was my way of coping and escaping reality."

                                scene e3s26-53 with dissolve
                                mc "It doesn't sound like you're enjoying this kind of lifestyle."

                                scene e3s26-56 with dissolve
                                ca "You're right, I don't."
                                ca "But what can you do now?"

                                scene e3s26-57 with dissolve
                                ca "It's paying the bills, right."

                                scene e3s26-52 with dissolve
                                mc "Just move away."
                                mc "Start a new life."

                                scene e3s26-53 with dissolve
                                mc "Just... do whatever else."

                                scene e3s26-50 with dissolve
                                ca "It's not so simple."

                                scene e3s26-57 with dissolve
                                ca "Let's just... stop talking about this, alright?"
                                ca "Let's just lie here for a bit."

                                scene e3s26-58 with dissolve
                                pause

                                stop music fadeout 2.0
                                scene e3s26-59_cen with dissolve
                                pause

                        $ GameRunning = False

    $ renpy.end_replay()
return
