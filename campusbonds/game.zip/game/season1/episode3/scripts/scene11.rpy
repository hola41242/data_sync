
# Scene 11 - Library days ######################################################

label e3s11:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s11-01 with Dissolve(2.0)
    pause

    play music serenity
    scene e3s11-02 with dissolve
    ov "[mc], hi!"
    ov "Thought I might run into you."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "[ov]?"
    mc "What are you doing here?"

    scene e3s11-04 with dissolve
    hide e3s11_olivia_blink1
    ov "I'm grabbing a couple of books."
    ov "Why?"

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "No... I mean, what are {b}you{/b} doing here."
    mc "You're not a student anymore."
    mc "Wait a minute..."
    mc "The new job you got, this is where you got it?"

    scene e3s11-05 with dissolve
    hide e3s11_olivia_blink1
    ov "Haha, yeah!"

    scene e3s11-06 with dissolve
    ov "Now that I think about it, I didn't tell you where I got my job."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "Or what job you got for that matter."

    scene e3s11-05 with dissolve
    hide e3s11_olivia_blink1
    ov "Haha, yeah."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "So what?"
    mc "You're the new librarian now?"

    scene e3s11-07 with dissolve
    hide e3s11_olivia_blink1
    ov "Haha, no!"

    scene e3s11-08 with dissolve
    ov "I'm teaching foreign students English."

    scene e3s11-09 with dissolve
    ov "I'm here to grab some books best suited for that class."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "Oh, I see."
    mc "I didn't know you majored in this."

    scene e3s11-08 with dissolve
    hide e3s11_olivia_blink1
    ov "Well, I like to help people."

    scene e3s11-09 with dissolve
    ov "And I'm not locked into this job anyways, it's just a starting position."

    scene e3s11-06 with dissolve
    ov "If I do good in this, I'll become an English professor."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "That's pretty nice then."
    mc "So if I'm ever in need of some English tips, I should call you?"

    scene e3s11-05 with dissolve
    hide e3s11_olivia_blink1
    ov "Haha, I'm not giving you exam answers."

    scene e3s11-09 with dissolve
    ov "But nice try though!"

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "Damn it..."
    mc "Alright."

    scene e3s11-10 with dissolve
    hide e3s11_olivia_blink1
    ov "Well, I've got a class to attend to."

    scene e3s11-08 with dissolve
    ov "Bye [mc]!"
    ov "It was nice seeing you."

    scene e3s11-03 with dissolve
    show e3s11_olivia_blink1
    mc "Likewise!"

    scene e3s11-11 with dissolve
    hide e3s11_olivia_blink1
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music dances_and_dames
    scene e3s11-12 with Dissolve(2.0)
    pause

    scene e3s11-13 with dissolve
    pause

    scene e3s11-14 with dissolve
    pause

    scene e3s11-15 with dissolve
    mc "*Alright now, let's see how am I gonna do this.*"
    mc "*I go in there, I just grab the phone and then I'm out.*"
    mc "*Nothing more, nothing less.*"

    scene e3s11-16 with dissolve
    pause

    scene e3s11-17 with dissolve
    pause

    scene e3s11-18 with dissolve
    mc "*Shit!*"

    scene e3s11-19 with dissolve
    pause

    scene e3s11-20 with dissolve
    pause

    scene e3s11-21 with dissolve
    pause

    scene e3s11-47 with dissolve
    pause

    scene e3s11-15 with dissolve
    mc "*The longer I stay here the more unwanted attention I get.*"
    mc "*Come on, let's go!*"
    play sound phone_buzz

    scene e3s11-44 with dissolve
    if affinity_spectrum < 0:
        mc "*It's [jon].*"
        mc "*Great, now this.*"
    else:
        mc "*Fuck... it's [jon].*"
        mc "*Shit, what does he want?*"

    mc "*What am I even gonna do about it?*"

    menu:
        "Take his call":
            call extrovert_affinity_check from _call_extrovert_affinity_check_47
            call color_check from _call_color_check_90

            mc "*I guess I'm gonna take it.*"

            scene e3s11-45 with dissolve
            jon "Yoo, what's up my dude?"
            jon "Where have you been?"

            scene e3s11-46 with dissolve
            mc "What do you mean where have I been?"
            mc "I've been here, just like yesterday and the day before, taking classes."

            scene e3s11-45 with dissolve
            jon "Yeah, anyways."
            jon "We've got a really crazy idea and we want you in."

            scene e3s11-46 with dissolve
            mc "I'm sorry, I can't."

            scene e3s11-45 with dissolve
            jon "Fuck you mean you can't?"

            scene e3s11-46 with dissolve
            mc "I'm busy."

            if e3s10_cleo_hangout == True:
                mc "I've got a date tonight."

            scene e3s11-45 with dissolve
            jon "Damn, alright party pooper."
            jon "I'll see you later then."

            scene e3s11-46 with dissolve
            mc "Bye!"

            scene e3s11-44 with dissolve
            pause

        "Ignore him":
            call introvert_affinity_check from _call_introvert_affinity_check_40
            call color_check from _call_color_check_91

            mc "*I'm not ready to talk to him yet.*"
            mc "*Plus, I don't have a lot of time.*"

    scene e3s11-22 with dissolve
    pause

    scene e3s11-23 with dissolve
    mc "*The librarian is not in sight, let's do this quick.*"

    scene e3s11-24 with dissolve
    mc "*Now... where would a woman like this keep her confiscated phones?*"

    call e3s11_fr from _call_e3s11_fr

    if e3s11_explore == 4:
        if optional_quests:
            $ optional_quests.clear()
        if current_quests:
            $ current_quests.clear()

        $ renpy.hide_screen("questtracker_icon")

        scene e3s11-48 with dissolve
        mc "*Let me try and text her see if her phone rings.*"

        stop music
        $renpy.sound.play("audio/sfx/heart_beat.ogg", loop=True)
        scene e3s11-27 with dissolve
        pause

        scene e3s11-26 with dissolve
        pause

        scene e3s11-29 with dissolve
        mc "*Shit! I don't have time.*"
        mc "*I'm hearing footsteps.*"
        mc "*Better get out of here.*"

    scene e3s11-30 with dissolve
    pause

    stop sound fadeout 1.0
    scene e3s11-31 with dissolve
    ev "Ahem?"
    ev "What are you doing here?"

    scene e3s11-32 with dissolve
    mc "Uh... what do you mean what am I doing here?"

    scene e3s11-35 with dissolve
    ev "I mean, students aren't allowed here when I'm not at my desk."

    scene e3s11-33 with dissolve
    show e3s11_evelyn_blink1
    mc "Sorry, I didn't know that."

    scene e3s11-34 with dissolve
    hide e3s11_evelyn_blink1
    ev "Do you need something?"

    scene e3s11-33 with dissolve
    show e3s11_evelyn_blink1
    mc "Uh..."

    menu:
        "Return a book":
            $ e3s11_return = True
            call introvert_affinity_check from _call_introvert_affinity_check_41
            call color_check from _call_color_check_92

            mc "I came here to return a book."

            scene e3s11-35 with dissolve
            hide e3s11_evelyn_blink1
            ev "Where is it?"

            scene e3s11-33 with dissolve
            show e3s11_evelyn_blink1
            mc "*Shit.*"
            mc "Damn it, and I knew I forgot something."
            mc "I'll be back with it!"

            scene e3s11-36 with dissolve
            hide e3s11_evelyn_blink1
            pause

            scene e3s11-38 with dissolve
            hide e3s11_evelyn_blink1
            pause
        "Nothing":
            $ e3s11_nothing = True

            mc "Nothing actually."
            mc "I wanted to get a student pass but I forgot I already have one."

            scene e3s11-34 with dissolve
            hide e3s11_evelyn_blink1
            ev "You don't need a student pass, you use your id."

            scene e3s11-33 with dissolve
            show e3s11_evelyn_blink1
            mc "Sorry, I'm a first year, I don't know how things go around here."
            mc "Thanks anyways!"

            scene e3s11-38 with dissolve
            hide e3s11_evelyn_blink1
            mc "..."
        "Ask about her" if affinity_spectrum > 0:
            $ e3s11_ask = True
            call extrovert_affinity_check from _call_extrovert_affinity_check_48
            call color_check from _call_color_check_93

            mc "I've been meaning to ask about you."

            scene e3s11-34 with dissolve
            hide e3s11_evelyn_blink1
            ev "Ask about me?"

            scene e3s11-33 with dissolve
            show e3s11_evelyn_blink1
            mc "Yeah, I wanted to get to know you."

            scene e3s11-35 with dissolve
            hide e3s11_evelyn_blink1
            ev "I'd say I'm flattered but I'm not."

            scene e3s11-37 with dissolve
            ev "Relationships with students are strictly forbidden."

            scene e3s11-34 with dissolve
            ev "And truth be told, I'm not even interested so thanks but no thanks."

            scene e3s11-33 with dissolve
            show e3s11_evelyn_blink1
            mc "Sorry it came out that way but I meant as a friend."

            scene e3s11-35 with dissolve
            hide e3s11_evelyn_blink1
            ev "Haven't you got better things to do?"

            scene e3s11-37 with dissolve
            ev "I just remembered that I have some books to return to their shelves, so if you don't have any other questions you can go."

            scene e3s11-33 with dissolve
            show e3s11_evelyn_blink1
            mc "Alright I guess, bye!"

            scene e3s11-38 with dissolve
            hide e3s11_evelyn_blink1
            mc "*Nope, not awkward at all...*"

    scene e3s11-39 with dissolve
    pause

    scene e3s11-40 with dissolve
    pause

    if e3s11_explore == 4:
        scene e3s11-50 with dissolve
        pause

        scene e3s11-52 with dissolve
        pause

        scene e3s11-51 with dissolve
        pause

    else:
        scene e3s11-41 with dissolve
        pause

        scene e3s11-43 with dissolve
        pause

        scene e3s11-42 with dissolve
        pause

    if e3s10_cleo_hangout == True:
        jump e3s12
    else:
        jump e3s13
return
