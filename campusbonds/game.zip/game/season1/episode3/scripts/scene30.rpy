
# Scene 30 - Jon's confession #############################################

label e3s30:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s30-01 with Dissolve(2.0)
    play music iwnlylmd
    pause

    play sound knock_knock
    scene e3s30-02 with dissolve
    pause

    scene e3s30-03 with dissolve
    jon "Am I interrupting something?"

    scene e3s30-04 with dissolve
    mc "No, come on in."

    scene e3s30-05 with dissolve
    mc "What's up?"

    scene e3s30-06 with dissolve
    jon "Damn, call this a downgrade."

    scene e3s30-07 with dissolve
    jon "My place was way better."

    scene e3s30-08 with dissolve
    mc "Haha, shut up!"
    mc "At least I have my own bed now."

    scene e3s30-09 with dissolve
    jon "Come on, wasn't the couch also technically a bed?"

    scene e3s30-05 with dissolve
    mc "I wouldn't even classify it as a chair but whatever floats your boat."

    scene e3s30-10 with dissolve
    mc "And what's with the shirt?"
    mc "'Game on'?"

    scene e3s30-11 with dissolve
    mc "Didn't know thrift stores had a ‘rejects' bin."

    scene e3s30-13 with dissolve
    jon "They did, you must've gotten the last piece of trash they had."

    scene e3s30-15 with dissolve
    jon "Who are you trying to impress, the president?"

    scene e3s30-14 with dissolve
    jon "You ain't getting a piece buddy."

    scene e3s30-12 with dissolve
    mc "Yeah, okay, 'Game Over'."

    scene e3s30-16 with dissolve
    jon "Haha, yeah."

    scene e3s30-17 with dissolve
    jon "I missed you man."

    scene e3s30-18 with dissolve
    jon "How's it going?"

    scene e3s30-19 with dissolve
    mc "Just got here from home."

    scene e3s30-20 with dissolve
    jon "Oh, you went back?"

    scene e3s30-21 with dissolve
    jon "How's pops doing?"

    scene e3s30-22 with dissolve
    mc "He's fine, with work and such."
    mc "He told me to say hello when I see you."

    scene e3s30-23 with dissolve
    jon "Haha, brings me back to when you first got here!"

    scene e3s30-24 with dissolve
    jon "Did you manage to get your phone back?"

    scene e3s30-22 with dissolve
    mc "Yeah, had a friend work her magic and return it."

    scene e3s30-25 with dissolve
    jon "I see, I see."

    scene e3s30-28 with dissolve
    jon "Alright dude, look."

    scene e3s30-27 with dissolve
    jon "I'm here to talk."
    jon "And we should have had this talk when you first had had your problems."
    jon "I'm sorry for putting you down."

    scene e3s30-26 with dissolve
    show e3s30_jon_blink1
    mc "It's alright, I get that you were busy."

    scene e3s30-28 with dissolve
    hide e3s30_jon_blink1
    jon "Yeah, anyways."

    scene e3s30-27 with dissolve
    jon "[sd]'s basically filled me in with the details."
    jon "So we're almost on the same page."

    scene e3s30-26 with dissolve
    show e3s30_jon_blink1
    mc "What do you mean almost?"

    scene e3s30-29 with dissolve
    hide e3s30_jon_blink1
    jon "There are some things I have to tell you about."

    scene e3s30-27 with dissolve
    jon "From what I've heard around here you haven't exactly been yourself these past couple of days."
    jon "I wouldn't want you to take the same dark path."
    jon "As I pretty much think that's where you are headed."

    scene e3s30-26 with dissolve
    show e3s30_jon_blink1
    mc "What do you mean the same dark path?"

    stop music fadeout 2.0
    scene e3s30-30 with dissolve
    hide e3s30_jon_blink1
    jon "..."

    scene e3s30-27 with dissolve
    jon "[sp] is my cousin."

    scene e3s30-26 with dissolve
    show e3s30_jon_blink1
    mc "Your cousin?"

    scene e3s30-31 with dissolve
    hide e3s30_jon_blink1
    mc "[sp] is your cousin?"
    mc "What??"

    $ episode_count += 1
    jump credits
return
