
# Scene 18 - Unexpected girl ###################################################

label e3s18:
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s18-01 with Dissolve(2.0)
    pause

    scene e3s18-02 with dissolve
    pause

    scene e3s18-04 with dissolve
    sc "Hello freshie!"

    scene e3s18-03 with dissolve
    show e3s18_scarlett_blink1
    if affinity_spectrum > 0:
        mc "What do you want [sc]?"

        scene e3s18-05 with dissolve
        hide e3s18_scarlett_blink1
        sc "Wow, wow..."
        sc "Relax."
        sc "I'm not here to cause any trouble."

        scene e3s18-06 with dissolve
        sc "Sadly..."

        scene e3s18-03 with dissolve
        show e3s18_scarlett_blink1
        mc "Then, why are you here?"
    else:
        mc "What?"

    scene e3s18-07 with dissolve
    hide e3s18_scarlett_blink1
    sc "Come with me."
    sc "I wanna take you somewhere."

    scene e3s18-03 with dissolve
    show e3s18_scarlett_blink1
    mc "*Damn... what's with everyone today...*"
    mc "I'm not really interested."

    scene e3s18-08 with dissolve
    hide e3s18_scarlett_blink1
    sc "It wasn't a request jackass."

    scene e3s18-09 with dissolve
    sc "Now move!"
    mc "Damn, okay, jeez!"

    if affinity_spectrum > 0:
        mc "*What the hell is wrong with her...?*"

    scene e3s18-10 with wipeleft
    play music energizing_indie_pop
    mc "..."
    mc "You're giving me a ride?"

    scene e3s18-11 with dissolve
    mc "You should have said so in the first place."

    scene e3s18-12 with dissolve
    sc "Shut up and get in!"

    scene e3s18-13 with dissolve
    mc "Talk about being kidnapped..."

    stop music fadeout 2.0
    scene e3s18-14 with wipeleft
    pause

    scene e3s18-15 with dissolve
    play music brighter
    mc "So... nice weather outside."

    scene e3s18-16 with dissolve
    sc "Mhm..."

    scene e3s18-17 with dissolve
    mc "..."

    scene e3s18-18 with dissolve
    mc "[sc], why am I here?"

    scene e3s18-20 with dissolve
    sc "What do you mean?"

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "I mean, why am I in this car."
    mc "In your car."
    mc "I thought you hated me."

    scene e3s18-21 with dissolve
    hide e3s18_scarlett_blink2
    sc "I don't hate you."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "Don't you?"
    mc "Then why are you mocking me every time you get the chance?"

    if affinity_spectrum > 0:
        mc "And also acting like a bitch."

        scene e3s18-20 with dissolve
        hide e3s18_scarlett_blink2
        sc "Excuse me?"

        scene e3s18-19 with dissolve
        show e3s18_scarlett_blink2
        mc "You've heard me."
    else:
        mc "And also being rude."

    scene e3s18-22 with dissolve
    hide e3s18_scarlett_blink2
    sc "Dude, that's just how I am."

    scene e3s18-20 with dissolve
    sc "Don't think I'm treating you different."

    scene e3s18-21 with dissolve
    sc "That's how I am with everybody else."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "I haven't heard you talk like this to [jon] or anyone else for that matter."

    scene e3s18-23 with dissolve
    hide e3s18_scarlett_blink2
    sc "Would you just get off my back?"

    scene e3s18-24 with dissolve
    sc "I don't like being held accountable, especially by you."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "What do you mean?"
    mc "You're the one who forced me to join you for a ride."
    mc "I was just asking."

    scene e3s18-23 with dissolve
    hide e3s18_scarlett_blink2
    sc "Hey, fuck you!"
    sc "I'm only doing this because of [jon]."

    scene e3s18-24 with dissolve
    sc "It's not like I give a flying fuck about you."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "Oh, so that's what this is about..."
    mc "I knew you didn't care about me."
    mc "But if you really wanted to help [jon], you could have at least pretended you do."

    scene e3s18-25 with dissolve
    hide e3s18_scarlett_blink2
    mc "[jon] really chose the best possible person to talk about this subject..."

    scene e3s18-27 with dissolve
    mc "Can you just drop me off at the next stop?"

    scene e3s18-26 with dissolve
    mc "I'll just take the bus back."

    scene e3s18-24 with dissolve
    sc "Fine!"

    scene e3s18-28 with dissolve
    pause

    scene e3s18-29 with dissolve
    pause

    scene e3s18-30 with dissolve
    pause

    scene e3s18-31 with dissolve
    sc "Did [jon] really treat you that bad?"

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "I thought you didn't care about me."

    scene e3s18-23 with dissolve
    hide e3s18_scarlett_blink2
    sc "Just stop being a pussy and answer the question."

    scene e3s18-26 with dissolve
    mc "Well... it's not really [jon]."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "I don't even know who I can trust and who I can't."
    mc "And you're probably the last person I can put my trust in."
    mc "But assuming that this information gets to [jon], I'm going to tell you anyway."
    mc "Back when you organised your welcome party at the old cafeteria."
    mc "Let's just say that I overheard some things that most probably I shouldn't have."
    mc "From someone I considered close to me and to [jon]."
    mc "And ever since that I don't know who I can trust and who I can't."
    mc "I've been exploring a couple of other clubs."

    scene e3s18-20 with dissolve
    hide e3s18_scarlett_blink2
    sc "Okay, first of all, most of the other groups are trash and you know it."
    sc "You're not that nerdy so you don't belong there."

    scene e3s18-21 with dissolve
    sc "Second of all..."

    scene e3s18-20 with dissolve
    sc "Dude, you've got to talk to him!"

    scene e3s18-22 with dissolve
    sc "How do you expect him to know about all of this if you don't tell him?"

    scene e3s18-26 with dissolve
    mc "I guess he won't..."

    scene e3s18-20 with dissolve
    sc "Exactly!"

    scene e3s18-24 with dissolve
    sc "Suck it up, be a man, bring all your courage and tell him what's up."

    scene e3s18-20 with dissolve
    sc "If it really is that bad and there are bad people around him, don't you think he should know about it?"

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "You're right."
    mc "Damn... I didn't expect you out of all people to come up with reasonable solutions."

    scene e3s18-32 with dissolve
    hide e3s18_scarlett_blink2
    if affinity_spectrum > 0:
        sc "I might be a bitch, but I'm not stupid."
    else:
        sc "I might be rude, but I'm not stupid."

    scene e3s18-20 with dissolve
    sc "It's not a coincidence that the last president of the party ragers chose me to lead the group."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "Well, I hate to be the one to break it to you, but you're not doing a great job."

    scene e3s18-20 with dissolve
    hide e3s18_scarlett_blink2
    sc "Now you're just being ironic."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "Am I?"

    scene e3s18-32 with dissolve
    hide e3s18_scarlett_blink2
    sc "So that's how it feels, huh?"

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "Finally, a moment of reflection!"

    scene e3s18-32 with dissolve
    hide e3s18_scarlett_blink2
    sc "Doesn't mean I'll stop doing it."

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    if affinity_spectrum > 0:
        mc "I wouldn't want you to stop it."
    else:
        mc "Damn it..."

    scene e3s18-36 with wipeleft
    hide e3s18_scarlett_blink2
    pause

    scene e3s18-33 with dissolve
    mc "Thanks for the ride."

    scene e3s18-34 with dissolve
    mc "It has been surprisingly constructive."

    scene e3s18-35 with dissolve
    sc "Well, it's the last one you'll get."
    sc "So don't get used to it."

    scene e3s18-36 with dissolve
    pause

    scene e3s18-37 with dissolve
    pause

    scene e3s18-38 with dissolve
    pause

    scene e3s18-36 with dissolve
    pause

    scene e3s18-35 with dissolve
    sc "Hey, also, we share the same sentiment."

    scene e3s18-34 with dissolve
    mc "What?"

    scene e3s18-35 with dissolve
    sc "Remember when you said that I'd be the last person you'd put your trust in?"

    scene e3s18-34 with dissolve
    mc "Yeah."

    scene e3s18-35 with dissolve
    sc "You're the last person I would put my trust in as well."
    sc "I don't think I would put it in you even if you were the last person on Earth, but oh well."

    scene e3s18-34 with dissolve
    if affinity_spectrum > 0:
        if scarlett_trust > 1:
            mc "That's crazy because I would definitely *put it* in you if you were the last person in this world."

            scene e3s18-39 with dissolve
            sc "Haha, at least you're good at something."
        else:
            mc "Great, we're on the same page."
    else:
        mc "Great, we're on the same page."

    scene e3s18-40 with dissolve
    sc "Yeah..."

    scene e3s18-37 with dissolve
    pause

    scene e3s18-41 with dissolve
    pause

    stop music fadeout 2.0
    scene e3s18-42 with dissolve
    pause

    jump e3f2
return
