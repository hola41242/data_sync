
define e3s9_tracks = ["party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/rock_this_house.ogg", "party/instrumentals/turn_up.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/encryption.ogg"]

# Scene 9 - Midnight hookup ####################################################

label e3s9:
    stop music fadeout 2.0
    if e3s8_tiffany_hangout == True:
        scene e3s9-01 with wipeleft
        pause

        play sound knock_knock
        scene e3s9-02 with dissolve
        play music mom_n_pa
        pause

        scene e3s9-03 with dissolve
        pause

        play sound door_open
        scene e3s9-04 with dissolve
        tf "Hey [mc], come on in!"

        play sound door_close
        scene e3s9-05 with dissolve
        mc "What's up?"

        scene e3s9-06 with dissolve
        menu:
            "Check her out":
                scene e3s9-07 with dissolve

            "Don't check her out":
                pass

        tf "I was just sitting in bed."
        mc "Nice."

        scene e3s9-08 with dissolve
        tf "So... what happened?"

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "Nothing happened."

        scene e3s9-12 with dissolve
        hide e3s9_tiffany_blink1
        tf "Okay then."

        scene e3s9-10 with dissolve
        tf "How was your evening?"

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "It was pretty alright."

        scene e3s9-11 with dissolve
        hide e3s9_tiffany_blink1
        tf "I see."

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "How was yours?"

        scene e3s9-11 with dissolve
        hide e3s9_tiffany_blink1
        tf "It was pretty alright as well."

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "Great!"

        scene e3s9-13 with dissolve
        hide e3s9_tiffany_blink1
        tf "So, what do you want to watch?"

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "Anything is fine by me."
        mc "Your roommate isn't here?"

        scene e3s9-11 with dissolve
        hide e3s9_tiffany_blink1
        tf "Nope, she's gone for the night to her boyfriend's place."

        scene e3s9-09 with dissolve
        show e3s9_tiffany_blink1
        mc "Oh, alright."

        scene e3s9-14 with dissolve
        hide e3s9_tiffany_blink1
        tf "I'm gonna set up the movie, sit tight."

        stop music fadeout 2.0
        scene e3s9-15 with dissolve
        mc "Okay."

        call e3s9_tiffany_sex from _call_e3s9_tiffany_sex

        scene e3s9-39 with wipeleft
        pause

        scene e3s9-40 with dissolve
        pause

        scene e3s9-41 with dissolve
        if e3s9_tiffany_sex == True:
            mc "Thank you [tf] for the movie and the release."

            scene e3s9-42 with dissolve
            mc "I really needed it."

            scene e3s9-43 with dissolve
            tf "You're welcome [mc]."

            scene e3s9-44 with dissolve
            tf "Thank you for the movie as well."

            scene e3s9-45 with dissolve
            tf "I'm glad you enjoyed tonight."
        else:
            mc "Thank you [tf] for the movie."

            scene e3s9-45 with dissolve
            tf "You're welcome [mc]."
            tf "Thank you for the movie as well."
            tf "I'm glad you've enjoyed tonight."

        scene e3s9-46 with dissolve
        mc "Well... I won't be taking any more of your time."

        scene e3s9-47 with dissolve
        mc "It's already a bit late."

        scene e3s9-48 with dissolve
        mc "Good night [tf]."

        scene e3s9-49 with dissolve
        tf "Night, [mc]."

        scene e3s9-50 with dissolve
        pause

        scene e3s9-51 with dissolve
        pause

        if e3s9_tiffany_sex == True:
            scene e3s9-52 with dissolve
            pause
    if e3s8_candance == True:
        $ time_start = 0
        $ time_max = 1.0
        $ time_max = 0.01

        scene e3s9_ca-01 with wipeleft
        $ renpy.random.shuffle(e3s9_tracks)
        $ renpy.music.queue (e3s9_tracks, loop=True)
        pause

        scene e3s9_ca-02 with dissolve
        mc "*I wonder where [ca] is...*"
        mc "*I'm just gonna sit by the bar and order a few drinks until she shows up.*"

        scene e3s9_ca-03 with dissolve
        pause

        scene e3s9_ca-04 with dissolve
        unknown "Hey sweetie!"

        scene e3s9_ca-05 with dissolve
        pause

        scene e3s9_ca-06 with dissolve
        unknown "You're looking a bit lonely."

        scene e3s9_ca-07 with dissolve
        mc "Sorry... I'm waiting for someone else right now."

        scene e3s9_ca-08 with dissolve
        unknown "That's alright."
        unknown "If you need me I'll be around here!"

        scene e3s9_ca-07 with dissolve
        mc "Thanks."

        scene e3s9_ca-09 with dissolve
        pause

        scene e3s9_ca-10 with dissolve
        mc "Hey, also... do you know a certain person working here?"

        scene e3s9_ca-11 with dissolve
        unknown "Who?"

        scene e3s9_ca-12 with dissolve
        mc "[ca]."

        scene e3s9_ca-13 with dissolve
        unknown "Oh... [ca]."

        scene e3s9_ca-14 with dissolve
        unknown "Yeah, she was here today."

        scene e3s9_ca-15 with dissolve
        mc "Is she still here?"

        scene e3s9_ca-16 with dissolve
        unknown "I don't know, I haven't seen her."

        scene e3s9_ca-14 with dissolve
        unknown "I have to go!"

        scene e3s9_ca-15 with dissolve
        mc "Alright, thank you."

        scene e3s9_ca-09 with dissolve
        pause

        scene black with Dissolve(2.0)

        scene e3s9_ca-03 with Dissolve(2.0)
        pause

        scene e3s9_ca-04 with dissolve
        mc "*Looks like [ca] isn't showing up tonight.*"
        mc "*Maybe she checked out early.*"
        mc "*I'll just take a leak and them I'm out of here.*"

        scene e3s9_ca-17 with dissolve
        pause

        scene e3s9_ca-18 with dissolve
        pause

        scene e3s9_ca-19 with dissolve
        "{i}Muffled arguing.{/i}"

        scene e3s9_ca-20 with dissolve
        mc "*Am I hearing something in there or is it just the alcohol in me?*"

        scene e3s9_ca-21 with dissolve
        menu:
            "Check it out":
                mc "*Let's check it out, hope I don't catch anyone doing the deed.*"

                scene e3s9_ca-22 with dissolve
                pause

                stop music fadeout 2.0
                scene e3s9_ca-23 with dissolve
                pause

                scene e3s9_ca-24 with dissolve
                unknown "Where's my money, bitch?"

                scene e3s9_ca-25 with dissolve
                unknown "WHERE... IS... IT?"

                scene e3s9_ca-23 with dissolve
                menu:
                    "Intervene" if affinity_spectrum > 0:
                        call extrovert_affinity_check from _call_extrovert_affinity_check_57
                        call color_check from _call_color_check_109
                        $ e3s9_intervene = True
                        $ candance_trust += 1

                        mc "Hey, get off of her!"

                        scene e3s9_ca-26 with dissolve
                        unknown "Mind your own business kid."

                        scene e3s9_ca-24 with dissolve
                        unknown "This doesn't concern you."

                        scene e3s9_ca-27 with dissolve
                        mc "It does concern me, get off of her!"

                        scene e3s9_ca-24 with dissolve
                        unknown "I'm not saying this twice."

                        scene e3s9_ca-25 with dissolve
                        unknown "GET THE HELL OU-"

                        play music keep_it_down
                        scene e3s9_ca-28 with vpunch
                        pause

                        scene e3s9_ca-29 with dissolve

                        if persistent.fight == 0:
                            while e3s9_unknown_health > 0 and e3s9_mc_health > 0:
                                call qte from _call_qte_33

                                if qte == True:
                                    $ e3s9_unknown_health = max(0, e3s9_unknown_health - total_damage)

                                    $ fight_scene = renpy.random.choice(e3s9_positive_fight)

                                    while last_fight_scene == fight_scene:
                                        $ fight_scene = renpy.random.choice(e3s9_positive_fight)

                                    play sound punch
                                    scene expression fight_scene with vpunch

                                    $ last_fight_scene = fight_scene
                                else:
                                    $ e3s9_mc_health -= 1

                                    $ fight_scene = renpy.random.choice(e3s9_negative_fight)

                                    while last_fight_scene == fight_scene:
                                        $ fight_scene = renpy.random.choice(e3s9_negative_fight)

                                    play sound punch
                                    show miss_screen at miss_anim
                                    show expression fight_scene behind miss_screen with vpunch

                                    $ last_fight_scene = fight_scene

                            if qte_neg_count == 0:
                                $ strength += 1
                                if persistent.sd_gallery_11_unlocked == False:
                                    $ persistent.sd_gallery_11_unlocked = True
                                    $ renpy.show_screen("render_notify")
                                    $ persistent.sadie11 = True
                                    python:
                                        update_sadie_list()

                            if e3s9_unknown_health == 0:
                                $ qte_neg_count = 0
                                $ qte_pos_count = 0

                                $ e3s9_fight = True
                                pause (1.0)

                                $ fight_scene = renpy.random.choice(e3s9_positive_fight)

                                while last_fight_scene == fight_scene:
                                    $ fight_scene = renpy.random.choice(e3s9_positive_fight)

                                play sound punch
                                scene expression fight_scene with vpunch

                                $ last_fight_scene = fight_scene

                                scene e3s9_ca-50 with dissolve
                                pause

                                scene e3s9_ca-51 with dissolve
                                unknown "Ah... fuck!"

                            if e3s9_mc_health == 0:
                                $ qte_neg_count = 0
                                $ qte_pos_count = 0

                                $ e3s9_fight = False
                                pause (1.0)

                                $ fight_scene = renpy.random.choice(e3s9_negative_fight)

                                while last_fight_scene == fight_scene:
                                    $ fight_scene = renpy.random.choice(e3s9_negative_fight)

                                play sound punch
                                show miss_screen at miss_anim
                                show expression fight_scene behind miss_screen with vpunch

                                $ last_fight_scene = fight_scene

                                scene e3s9_ca-36 with dissolve
                                unknown "I told you to stay the fuck out of my business prick!"

                                play sound punch
                                scene e3s9_ca-37 with vpunch
                                pause

                                scene e3s9_ca-38 with dissolve
                                unknown "Ah... fuck!"
                        else:
                            $ e3s9_fight = False

                            pause

                            play sound punch
                            scene e3s9_ca-30 with vpunch
                            pause

                            play sound punch
                            scene e3s9_ca-32 with vpunch
                            pause

                            play sound punch
                            scene e3s9_ca-31 with vpunch
                            pause

                            play sound punch
                            scene e3s9_ca-33 with vpunch
                            pause

                            play sound punch
                            scene e3s9_ca-34 with vpunch
                            pause

                            play sound punch
                            scene e3s9_ca-35 with vpunch
                            pause

                            scene e3s9_ca-36 with dissolve
                            unknown "I told you to stay the fuck out of my business prick!"

                            play sound punch
                            scene e3s9_ca-37 with vpunch
                            pause

                            scene e3s9_ca-38 with dissolve
                            unknown "Ah... fuck!"

                        if e3s9_fight == True:
                            $ candance_trust += 1
                            scene e3s9_ca-49 with dissolve
                        else:
                            scene e3s9_ca-45 with dissolve
                        unknown "This isn't over you fuckers!"

                        scene e3s9_ca-46 with dissolve
                        unknown "You better have my money next time I come in here bitch."
                        unknown "Or else I'll just finish what I started!"

                        scene e3s9_ca-47 with dissolve
                        pause

                        stop music fadeout 2.0
                        scene e3s9_ca-48 with dissolve
                        pause

                        play music the_pawnbrokers_stepdaughter
                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "Are you alright?"

                        scene e3s9_ca-40 with dissolve
                        hide e3s9_candance_blink1
                        ca "[mc]... you shouldn't have done that."

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "I couldn't just watch him kill you!"

                        scene e3s9_ca-40 with dissolve
                        hide e3s9_candance_blink1
                        ca "He wouldn't have killed me..."

                        scene e3s9_ca-41 with dissolve
                        ca "Now he's just more pissed at me."

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "I'm not gonna apologize for it."

                        scene e3s9_ca-42 with dissolve
                        hide e3s9_candance_blink1
                        ca "I don't want an apology."

                        scene e3s9_ca-41 with dissolve
                        ca "It's just that... this life isn't for you [mc]."

                        scene e3s9_ca-40 with dissolve
                        ca "You shouldn't hang out around places like this."

                        scene e3s9_ca-41 with dissolve
                        ca "And you especially shouldn't get into fights with people you don't know."

                        scene e3s9_ca-42 with dissolve
                        ca "What if he pulled out a knife?"

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "..."
                        mc "I guess you're kind of right."
                        mc "But I couldn't just let him choke you like that!"

                        scene e3s9_ca-41 with dissolve
                        hide e3s9_candance_blink1
                        ca "I know and I appreciate it."

                        scene e3s9_ca-42 with dissolve
                        ca "Just... be more careful in the future, alright?"

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "From where I'm standing, {b}you{/b} should be more careful about the people you get involved with."

                        scene e3s9_ca-43 with dissolve
                        hide e3s9_candance_blink1
                        ca "Haha, I guess you're right!"

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "No, but seriously now."
                        mc "You shouldn't work in environments like this."
                        mc "I know risks like this come with the job and stuff."
                        mc "And I don't know your deal with these people."
                        mc "But you should stay away from them."

                        scene e3s9_ca-41 with dissolve
                        hide e3s9_candance_blink1
                        ca "Yeah..."

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "Anyways, I'll be on my way now."

                        scene e3s9_ca-42 with dissolve
                        hide e3s9_candance_blink1
                        ca "Hey... can I have your number?"

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "I thought you had it."

                        scene e3s9_ca-42 with dissolve
                        hide e3s9_candance_blink1
                        ca "No... I gave you my number but you never called."
                        ca "I didn't get the chance to save yours."

                        scene e3s9_ca-39 with dissolve
                        show e3s9_candance_blink1
                        mc "Oh... right."
                        mc "Here it is."
                        mc "See you around!"

                        stop music
                        scene e3s9_ca-44 with dissolve
                        hide e3s9_candance_blink1
                        pause

                        scene e3s9_ca-52 with dissolve
                        pause

                        play sound phone_buzz
                        scene e3s9_ca-53 with dissolve
                        pause

                        scene e3s9_ca-54 with dissolve
                        pause

                        scene e3s9_ca-55 with dissolve
                        nvl clear

                        ca_nvl "Hey, I never got the chance to say thank you!"

                        if persistent.mixed_gallery_10_unlocked == False:
                            $ persistent.mixed_gallery_10_unlocked = True
                            $ renpy.show_screen("render_notify")
                            $ persistent.mixed10 = True
                            python:
                                update_mixed_list()

                        if persistent.disable_nsfw == True:
                            ca_nvl "image: phone/candance/1.webp"
                        else:
                            ca_nvl "image: phone/candance/censored/1.webp"

                        scene e3s9_ca-56 with dissolve
                        mc "*Damn... if I knew I'd get this kind of treatment...*"

                        scene e3s9_ca-55 with dissolve
                        n_nvl "Don't worry about it [ca]."
                        n_nvl "Btw, nice pair :*"

                        scene e3s9_ca-57 with dissolve
                        pause

                    "Stay out of it":
                        call introvert_affinity_check from _call_introvert_affinity_check_49
                        call color_check from _call_color_check_110

                        mc "*Not my business...*"
                        mc "*I'll go tell someone to break them up.*"

            "Leave it alone":
                scene e3s9_ca-19 with dissolve
                mc "*Meh... it's probably just the alcohol.*"

    jump e3s10
return

label e3s9_tiffany_sex:
    play music river_meditation
    scene e3s9-16 with wipeleft
    pause

    scene e3s9-17 with dissolve
    mc "*...*"

    scene e3s9-18 with dissolve
    mc "*I wonder if [tf]'s enjoying the movie.*"

    scene e3s9-19 with dissolve
    mc "*...*"
    mc "*She smells so nice.*"
    mc "*She's got this aroma which really pulls me towards her but I can't put my finger on it.*"

    scene e3s9-18 with dissolve
    mc "*Maybe I can get something out of tonight...*"
    menu:
        "Make a move":
            call extrovert_affinity_check from _call_extrovert_affinity_check_58
            call color_check from _call_color_check_111

            mc "*I'm going to try and kiss her.*"
            mc "*See if she's open to something more.*"

            scene e3s9-20 with dissolve
            mc "Hey, [tf]?"

            scene e3s9-21 with dissolve
            tf "Yeah [mc]?"

            scene e3s9-22 with dissolve
            mc "*I'm going to kiss her.*"

            scene e3s9-23 with dissolve
            pause

            scene e3s9-24 with dissolve
            pause

            if not _in_replay:
                if tiffany_trust > 2:
                    $ e3s9_tiffany_sex = True
                    $ persistent.e3s9_tiffany_sex = True
                else:
                    scene e3s9-25 with dissolve
                    pause

                    scene e3s9-26 with dissolve
                    tf "We... shouldn't do this."

                    scene e3s9-53 with dissolve
                    tf "I'm sorry [mc], I'm not ready."

                    scene e3s9-54 with dissolve
                    mc "I understand."

                    scene e3s9-55 with dissolve
                    tf "I'm sorry, I'm not trying to be a mood breaker or anything."

                    scene e3s9-53 with dissolve
                    tf "We can go back to watching the movie if you'd like."

                    stop music fadeout 2.0
                    scene e3s9-54 with dissolve
                    mc "Yeah, sure [tf], sounds good."
                    mc "Don't worry about it."

                    scene e3s9-53 with dissolve
                    tf "Okay!"
                    return
            else:
                if persistent.e3s9_tiffany_sex == True:
                    pass
                else:
                    scene e3s9-25 with dissolve
                    pause

                    scene e3s9-26 with dissolve
                    tf "We... shouldn't do this."

                    scene e3s9-53 with dissolve
                    tf "I'm sorry [mc], I'm not ready."

                    scene e3s9-54 with dissolve
                    mc "I understand."

                    scene e3s9-55 with dissolve
                    tf "I'm sorry, I'm not trying to be a mood breaker or anything."

                    scene e3s9-53 with dissolve
                    tf "We can go back to watching the movie if you'd like."

                    stop music fadeout 2.0
                    scene e3s9-54 with dissolve
                    mc "Yeah, sure [tf], sounds good."
                    mc "Don't worry about it."

                    scene e3s9-53 with dissolve
                    tf "Okay!"
                    return

        "Enjoy the movie" if not _in_replay:
            call introvert_affinity_check from _call_introvert_affinity_check_50
            call color_check from _call_color_check_112

            $ tiffany_trust += 1

            scene e3s9-17 with dissolve
            mc "*I'll just enjoy the movie.*"
            mc "*Maybe this is what I needed.*"
            mc "*I also feel like the mood isn't exactly right for anything more.*"

            return

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e3s9-25 with dissolve
        tf "Ah..."

        scene e3s9-26 with dissolve
        mc "*She's got the sweetest boobs.*"

        scene e3s9-27 with dissolve
        pause

        scene e3s9-28 with dissolve
        tf "Uh..."

        scene e3s9-29 with dissolve
        pause

        scene e3s9-30 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e3s9-31 with dissolve
            pause

            scene e3s9-32 with dissolve
            pause

            scene e3s9-33 with dissolve
            pause

            scene e3s9-34 with dissolve
            pause

            scene e3s9-35 with dissolve
            pause

            # Missionary
            scene e3s9-missionary1 with dissolve
            tf "Guh...!"

            scene e3s9-missionary2 with dissolve
            mc "Ah! Fuck me."

            scene e3s9-missionary3 with dissolve
            tf "Ahh...!"

            scene e3s9-missionary2 with dissolve
            pause

            scene e3s9-missionary3 with dissolve
            pause

            scene e3s9-missionary2 with dissolve
            pause

            # Spooning
            scene e3s9-spooning1 with dissolve
            pause

            scene e3s9-spooning2 with dissolve
            mc "This feels so good [tf]!"

            scene e3s9-spooning3 with dissolve
            tf "Ah...!"

            scene e3s9-spooning4 with dissolve
            pause

            scene e3s9-spooning5 with dissolve
            tf "Ah [mc]!"
            tf "Slow down a bit."

            scene e3s9-spooning3 with dissolve
            pause

            scene e3s9-spooning4 with dissolve
            pause

            scene e3s9-spooning5 with dissolve
            pause

            scene e3s9-spooning4 with dissolve
            pause

            scene e3s9-spooning3 with dissolve
            pause

            # Doggy
            scene e3s9-doggy1 with dissolve
            tf "[mc]... ah...!"

            scene e3s9-doggy2 with dissolve
            pause

            scene e3s9-doggy3 with dissolve
            pause

            scene e3s9-doggy5 with dissolve
            mc "This feels amazing!"

            scene e3s9-doggy4 with dissolve
            pause

            scene e3s9-doggy1 with dissolve
            pause

            scene e3s9-doggy2 with dissolve
            pause

            scene e3s9-doggy3 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e3s9-31_cen with dissolve
                pause

                scene e3s9-32_cen with dissolve
                pause

                scene e3s9-33 with dissolve
                pause

                scene e3s9-34_cen with dissolve
                pause

                scene e3s9-35_cen with dissolve
                pause

                # Missionary
                scene e3s9-missionary1_cen with dissolve
                tf "Guh...!"

                scene e3s9-missionary2_cen with dissolve
                mc "Ah! Fuck me."

                scene e3s9-missionary3_cen with dissolve
                tf "Ahh...!"

                scene e3s9-missionary2_cen with dissolve
                pause

                scene e3s9-missionary3_cen with dissolve
                pause

                scene e3s9-missionary2_cen with dissolve
                pause

                # Spooning
                scene e3s9-spooning1_cen with dissolve
                pause

                scene e3s9-spooning2_cen with dissolve
                mc "This feels so good [tf]!"

                scene e3s9-spooning3_cen with dissolve
                tf "Ah...!"

                scene e3s9-spooning4_cen with dissolve
                pause

                scene e3s9-spooning5_cen with dissolve
                tf "Ah [mc]!"
                tf "Slow down a bit."

                scene e3s9-spooning3_cen with dissolve
                pause

                scene e3s9-spooning4_cen with dissolve
                pause

                scene e3s9-spooning5_cen with dissolve
                pause

                scene e3s9-spooning4_cen with dissolve
                pause

                scene e3s9-spooning3_cen with dissolve
                pause

                # Doggy
                scene e3s9-doggy1_cen with dissolve
                tf "[mc]... ah...!"

                scene e3s9-doggy2_cen with dissolve
                pause

                scene e3s9-doggy3_cen with dissolve
                pause

                scene e3s9-doggy5_cen with dissolve
                mc "This feels amazing!"

                scene e3s9-doggy4_cen with dissolve
                pause

                scene e3s9-doggy1_cen with dissolve
                pause

                scene e3s9-doggy2_cen with dissolve
                pause

                scene e3s9-doggy3_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Missionary":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s9-missionary1 with dissolve
                        tf "Guh...!"

                        scene e3s9-missionary2 with dissolve
                        mc "Ah! Fuck me."

                        scene e3s9-missionary3 with dissolve
                        tf "Ahh...!"

                        scene e3s9-missionary2 with dissolve
                        pause

                        scene e3s9-missionary3 with dissolve
                        pause

                        scene e3s9-missionary2 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s9-missionary1_cen with dissolve
                            tf "Guh...!"

                            scene e3s9-missionary2_cen with dissolve
                            mc "Ah! Fuck me."

                            scene e3s9-missionary3_cen with dissolve
                            tf "Ahh...!"

                            scene e3s9-missionary2_cen with dissolve
                            pause

                            scene e3s9-missionary3_cen with dissolve
                            pause

                            scene e3s9-missionary2_cen with dissolve
                            pause
                "Spooning":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s9-spooning1 with dissolve
                        pause

                        scene e3s9-spooning2 with dissolve
                        mc "This feels so good [tf]!"

                        scene e3s9-spooning3 with dissolve
                        tf "Ah...!"

                        scene e3s9-spooning4 with dissolve
                        pause

                        scene e3s9-spooning5 with dissolve
                        tf "Ah [mc]!"
                        tf "Slow down a bit."

                        scene e3s9-spooning3 with dissolve
                        pause

                        scene e3s9-spooning4 with dissolve
                        pause

                        scene e3s9-spooning5 with dissolve
                        pause

                        scene e3s9-spooning4 with dissolve
                        pause

                        scene e3s9-spooning3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s9-spooning1_cen with dissolve
                            pause

                            scene e3s9-spooning2_cen with dissolve
                            mc "This feels so good [tf]!"

                            scene e3s9-spooning3_cen with dissolve
                            tf "Ah...!"

                            scene e3s9-spooning4_cen with dissolve
                            pause

                            scene e3s9-spooning5_cen with dissolve
                            tf "Ah [mc]!"
                            tf "Slow down a bit."

                            scene e3s9-spooning3_cen with dissolve
                            pause

                            scene e3s9-spooning4_cen with dissolve
                            pause

                            scene e3s9-spooning5_cen with dissolve
                            pause

                            scene e3s9-spooning4_cen with dissolve
                            pause

                            scene e3s9-spooning3_cen with dissolve
                            pause
                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s9-doggy1 with dissolve
                        tf "[mc]... ah...!"

                        scene e3s9-doggy2 with dissolve
                        pause

                        scene e3s9-doggy3 with dissolve
                        pause

                        scene e3s9-doggy5 with dissolve
                        mc "This feels amazing!"

                        scene e3s9-doggy4 with dissolve
                        pause

                        scene e3s9-doggy1 with dissolve
                        pause

                        scene e3s9-doggy2 with dissolve
                        pause

                        scene e3s9-doggy3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s9-doggy1_cen with dissolve
                            tf "[mc]... ah...!"

                            scene e3s9-doggy2_cen with dissolve
                            pause

                            scene e3s9-doggy3_cen with dissolve
                            pause

                            scene e3s9-doggy5_cen with dissolve
                            mc "This feels amazing!"

                            scene e3s9-doggy4_cen with dissolve
                            pause

                            scene e3s9-doggy1_cen with dissolve
                            pause

                            scene e3s9-doggy2_cen with dissolve
                            pause

                            scene e3s9-doggy3_cen with dissolve
                            pause
                "Cum":
                    $ config.rollback_enabled = True

                    mc "Ah fuck, I'm going to cum!"
                    tf "O-oh... okay!"
                    tf "Do it then [mc]!"

                    if persistent.disable_nsfw == True:
                        scene e3s9-missionary2 with dissolve
                        mc "Fuuck!"

                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e3s9-36 with dissolve
                        mc "Oh damn, [tf]."
                        mc "That was really good."
                        tf "I'm glad you enjoyed it [mc]."
                        mc "Thank you!"

                        scene e3s9-37 with dissolve
                        tf "Let me get cleaned up and then we can continue the movie."

                        scene e3s9-35 with dissolve
                        mc "Alright."

                        stop music fadeout 2.0
                        scene e3s9-38 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s9-missionary2_cen with dissolve
                            mc "Fuuck!"

                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e3s9-36_cen with dissolve
                            mc "Oh damn, [tf]."
                            mc "That was really good."
                            tf "I'm glad you enjoyed it [mc]."
                            mc "Thank you!"

                            scene e3s9-37_cen with dissolve
                            tf "Let me get cleaned up and then we can continue the movie."

                            scene e3s9-35_cen with dissolve
                            mc "Alright."

                            stop music fadeout 2.0
                            scene e3s9-38_cen with dissolve
                            pause

                    $ GameRunning = False

    $ renpy.end_replay()
return

# Fighting scene

if persistent.fight_difficulty == 0:
    default e3s9_mc_health = 7
    default e3s9_unknown_health = 7
if persistent.fight_difficulty == 1:
    default e3s9_mc_health = 7
    default e3s9_unknown_health = 8
if persistent.fight_difficulty == 2:
    default e3s9_mc_health = 6
    default e3s9_unknown_health = 10

default e3s9_positive_fight = ["e3s9_ca-30", "e3s9_ca-32", "e3s9_ca-34"]
default e3s9_negative_fight = ["e3s9_ca-31", "e3s9_ca-33", "e3s9_ca-35"]

default last_fight_scene = 0
default fight_scene = 0
