
# Scene 15 - A conflict of interests ###########################################

label e3s15:
    stop music fadeout 2.0
    scene e3s15-13 with dissolve
    fr "Alright everyone, I'm back."

    scene e3s15-14 with dissolve
    fr "Let's get settled for our repetitions."
    fr "[ev] is going to be here in a bit."

    scene e3s15-15 with dissolve
    mc "[ev]?"

    play music welcome_to_zombie_coast
    scene e3s15-16 with dissolve
    pause
    mc "*Oh shit.*"

    scene e3s15-17 with dissolve
    pause

    scene e3s15-18 with dissolve
    pause

    scene e3s15-19 with dissolve
    pause

    play sound punch
    scene e3s15-20 with vpunch
    eva "Get off me man!"
    mc "Damn, alright... jeez!"

    scene e3s15-21 with dissolve
    fr "Also, [ev], we have a new pledge today."

    scene e3s15-22 with dissolve
    mc "*!!!*"

    scene e3s15-23 with dissolve
    fr "There's this guy that was really eager to join and I thought I would show him around and see if he would be a good fit."

    scene e3s15-24 with dissolve
    ev "A guy?"

    scene e3s15-23 with dissolve
    fr "Yeah, his name is [mc]."

    scene e3s15-25 with dissolve
    fr "[mc], where are you?"

    scene e3s15-26 with dissolve
    mc "I'm right here."

    scene e3s15-27 with dissolve
    mc "Hi...!"

    scene e3s15-28 with dissolve
    ev "Oh... [mc]."

    scene e3s15-29 with dissolve
    fr "Have you two met?"

    scene e3s15-30 with dissolve
    mc "We've seen each other a couple of times in the library."
    mc "You know... because she's the librarian?"

    scene e3s15-31 with dissolve
    fr "Alright...?"

    scene e3s15-33 with dissolve
    fr "Well... if everything is settled then I guess we can start!"

    scene e3s15-32 with dissolve
    fr "Have you figured which instrument you'd like to play?"

    scene e3s15-30 with dissolve
    mc "I couldn't really decide."

    scene e3s15-34 with dissolve
    fr "Well, in that case you can start with the guitar."

    scene e3s15-32 with dissolve
    fr "And later when you make up your mind you can choose which instrument you like, alright?"

    scene e3s15-30 with dissolve
    mc "Alright."

    scene e3s15-35 with dissolve
    ev "Okay everyone, grab your instruments and your sheet music."
    ev "We're gonna do the first song."

    scene e3s15-36 with dissolve
    mc "Wait, but I don't know how to sing!"
    mc "I have no musical knowledge."
    mc "I barely know how to hold the guitar right."

    scene e3s15-37 with dissolve
    pause

    scene e3s15-38 with dissolve
    fr "Don't worry [mc], I'll come in a bit and help you with it."
    fr "I'll teach you the basics, you don't have to take part in the repetitions today."

    scene e3s15-39 with dissolve
    mc "Alright, thank you very much."

    if affinity_spectrum > 0:
        mc "*At least someone wants me here.*"

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s15-40 with Dissolve(2.0)
    play music solo_acoustic_guitar
    pause

    scene e3s15-41 with dissolve
    ev "Alright everyone, that was very good for today!"

    scene e3s15-42 with dissolve
    ev "I'm excited to see that most of you are making promising progress."

    scene e3s15-41 with dissolve
    ev "With how the things are currently going, we'll be ready for the competition."
    ev "Remember to practice daily for at least one hour."
    ev "Any overtime work is going to be rewarded."

    scene e3s15-43 with dissolve
    ev "You are dismissed!"

    scene e3s15-44 with dissolve
    mc "Damn, that's so much information."

    scene e3s15-46 with dissolve
    fr "Well, nobody said playing a guitar is going to be easy."
    fr "But it is damn rewarding."

    scene e3s15-45 with dissolve
    mc "I guess so."

    scene e3s15-47 with dissolve
    ev "[mc], can I have a minute with you after you're done with [fr]?"
    mc "Uh... sure."

    if francesca_trust > 3:
        scene e3s15-48 with dissolve
        fr "Is there something wrong?"

        scene e3s15-49 with dissolve
        ev "No, I'd just like to have a small chat with him about his performance today."

        scene e3s15-50 with dissolve
        fr "Okay then."

    scene e3s15-46 with dissolve
    fr "Well, we're done here, we're gonna do some more practicing tomorrow."
    fr "Just try to keep in mind what I've taught you and make sure to keep practicing."
    fr "We have a spare guitar which you can take to your dorm, just be sure not to break it."

    scene e3s15-45 with dissolve
    mc "Thanks!"
    mc "I'll make sure of it."

    if affinity_spectrum > 0:
        mc "*Like I would try to get on [ev]'s nerves anyways.*"

    scene e3s15-51 with dissolve
    fr "I will be waiting for you outside [mc]."

    scene e3s15-52 with dissolve
    pause

    scene e3s15-54 with dissolve
    ev "Nice performance today."
    ev "You've got a thing for the guitar."

    scene e3s15-53 with dissolve
    mc "Thanks!"

    scene e3s15-55 with dissolve
    ev "You know, I found it weird how one of the drawers from my office was slightly opened."
    ev "And I remember that same exact drawer being closed when I left."
    ev "Because I had to leave something in there."

    scene e3s15-56 with dissolve
    ev "Care to explain that?"

    scene e3s15-53 with dissolve
    mc "*Shit... she definitely knows.*"
    menu:
        "Play dumb":
            call extrovert_affinity_check from _call_extrovert_affinity_check_50
            call color_check from _call_color_check_96
            mc "What drawer?"

            scene e3s15-58 with dissolve
            pause(0.5)

            scene e3s15-57 with dissolve
            ev "Don't play dumb!"
            ev "How dare you go through my stuff?"

            scene e3s15-58 with dissolve
            mc "But I didn't."

            scene e3s15-57 with dissolve
            ev "Listen here, I already know the truth."

            scene e3s15-63 with dissolve
            ev "I don't even care if you try to play dumb or not."

            scene e3s15-61 with dissolve
            ev "I know it was you and I would have come up to you in the library anyways about this."
            ev "One thing I don't understand is, why?"

            scene e3s15-58 with dissolve
        "Admit to it":
            call introvert_affinity_check from _call_introvert_affinity_check_43
            call color_check from _call_color_check_97
            mc "Alright [ev], you caught me."
            mc "I'm sorry."

            scene e3s15-57 with dissolve
            ev "How dare you?"

            scene e3s15-58 with dissolve
            mc "I've already said I'm sorry, alright?"

    mc "A friend asked me to get her phone back from you."
    mc "She has everything there and she can't continue her classes without it."

    if e3s11_phone_left == False and e3s11_phone_right == False:
        if e3s11_explore == 4:
            mc "I didn't even have time to take the phone."
            mc "You got back really fast."

            scene e3s15-61 with dissolve
            ev "I don't give a shit about that, the rules are no phones allowed in the library."

            scene e3s15-58 with dissolve
            mc "But she just received a call and forgot to mute her phone."
            mc "That's not fair, you know?"
        else:
            mc "I didn't even take the phone anyways, didn't know which one to get."

            scene e3s15-59 with dissolve
            ev "I knew you were stupid but I didn't think you were this stupid to risk your library pass without even knowing which phone to steal."
            mc "Well, when you put it that way..."

            scene e3s15-60 with dissolve
            ev "I don't care if you took it or not."

            scene e3s15-61 with dissolve
            ev "Doing something like that is against the rules."

            scene e3s15-58 with dissolve
            mc "If you were at least a bit more forgiving I wouldn't have had to steal it in the first place."

            scene e3s15-61 with dissolve
            ev "What do you mean forgiving?"

            scene e3s15-58 with dissolve
            mc "She just received a call and forgot to mute her phone."
            mc "Is that really a reason to take it away from her?"

    else:
        scene e3s15-61 with dissolve
        ev "I don't give a shit about that, the rules are no phones allowed in the library."

        scene e3s15-58 with dissolve
        mc "But she just received a call and forgot to mute her phone."
        mc "That's not fair, you know?"

    scene e3s15-62 with dissolve
    ev "Oh, you're talking about that girl."

    scene e3s15-63 with dissolve
    ev "She didn't tell you, did she?"

    scene e3s15-59 with dissolve
    ev "Let's get something straight, I didn't just grab her phone for a simple mistake."

    scene e3s15-61 with dissolve
    ev "She was having a full-on conversation, I had to tell her multiple times to hang up or go outside to talk."
    ev "After multiple warnings, I took it from her."

    scene e3s15-58 with dissolve
    mc "Yeah, well, maybe it was important!"

    scene e3s15-61 with dissolve
    ev "That's why I told her to take it outside, I'm not a monster!"

    scene e3s15-60 with dissolve
    ev "But students these days just refuse to listen to anything they're told, don't they?"

    scene e3s15-57 with dissolve
    ev "If I catch you doing something like that again, it's not only your library access getting canceled."
    ev "You won't be allowed to join college rock either."
    ev "Are we clear?"

    scene e3s15-58 with dissolve
    mc "I understand, I'm sorry."

    scene e3s15-57 with dissolve
    ev "Good!"

    scene e3s15-64 with dissolve
    mc "*God damn it [sd], why did you lie to me?*"

    scene e3s15-65 with dissolve
    pause

    scene e3s15-66 with dissolve
    fr "Damn... what happened in there?"

    scene e3s15-67 with dissolve
    fr "She seemed really mad at you."

    scene e3s15-68 with dissolve
    fr "Even if your performance wasn't good today, she wouldn't be this mad at you."

    scene e3s15-67 with dissolve
    fr "Is there something you're not telling me about her?"

    scene e3s15-70 with dissolve
    menu:
        "Tell [fr] the truth":
            $ e3s15_truth = True
            $ francesca_trust += 1

            mc "Yeah, it's more to it."
            mc "A friend asked me to get her phone from [ev]'s desk because she received a call in the library."
            mc "And [ev] took it from her."

            scene e3s15-67 with dissolve
            fr "[ev] wouldn't do that to her."

            scene e3s15-68 with dissolve
            fr "She might come off a bit harsh but she is really understanding."

            scene e3s15-70 with dissolve
            mc "Well... I'm sorry [fr], I'm not really in the mood to talk about this right now."
            mc "Can we just move on?"

            scene e3s15-67 with dissolve
            fr "Okay, we'll move on."

            scene e3s15-70 with dissolve
            mc "Thanks!"
        "Hide it from her":
            mc "If you can believe it she really was mad at my performance."
            mc "And also she didn't like how I intrerupted the class to tell everyone about my musical problem."
            mc "So I guess I made a bad first impression."

            scene e3s15-69 with dissolve
            fr "Hey, don't be upset about it."
            fr "She'll get over it."

            scene e3s15-71 with dissolve
            fr "I know she might come off a bit harsh but she is really understanding."

            scene e3s15-70 with dissolve
            mc "Thanks [fr], I'll keep that in mind."

    stop music fadeout 2.0
    scene e3s15-72 with dissolve
    pause

    scene e3s15-01 with wipeleft
    play music little_tomcat
    pause

    scene e3s15-02 with dissolve
    if e3s11_phone_left == False and e3s11_phone_right == False:
        mc "Hey [sd]."

        scene e3s15-03 with dissolve
        sd "Hi [mc]!"

        scene e3s15-04 with dissolve
        show e3s15_sadie_blink1
        mc "Just came over to tell you that I couldn't get your phone."

        scene e3s15-09 with dissolve
        hide e3s15_sadie_blink1
        sd "Damn... really?"

        scene e3s15-07 with dissolve
        sd "What happened?"

        scene e3s15-08 with dissolve
        show e3s15_sadie_blink2
        mc "I didn't know which phone to get so I panicked."
        mc "But I'm not here just to tell you this."
    else:
        mc "Hey, I got your phone."

        scene e3s15-03 with dissolve
        sd "Really?"
        sd "That's awesome!"
        sd "Thank you so much!"

        scene e3s15-04 with dissolve
        show e3s15_sadie_blink1
        mc "Ah, ah, not so fast."
        mc "I didn't just come to give you your phone back."

    scene e3s15-05 with dissolve
    hide e3s15_sadie_blink1
    hide e3s15_sadie_blink2
    sd "What's up?"

    scene e3s15-04 with dissolve
    show e3s15_sadie_blink1
    mc "Why did you lie to me?"

    scene e3s15-06 with dissolve
    hide e3s15_sadie_blink1
    sd "What do you mean why did I lie?"

    scene e3s15-04 with dissolve
    show e3s15_sadie_blink1
    mc "Well, [ev] had a different side of the story."

    scene e3s15-07 with dissolve
    hide e3s15_sadie_blink1
    sd "You talked to her about this?"

    scene e3s15-08 with dissolve
    show e3s15_sadie_blink2
    mc "I got caught [sd]!"
    mc "I couldn't hide it from her."
    mc "Long story short she would have made my life a living hell."

    scene e3s15-09 with dissolve
    hide e3s15_sadie_blink2
    sd "I can't believe this..."

    scene e3s15-08 with dissolve
    show e3s15_sadie_blink2
    mc "No, I can't believe this."
    mc "You lied straight to my face!"

    scene e3s15-10 with dissolve
    hide e3s15_sadie_blink2
    sd "And you believe what she told you?"

    scene e3s15-08 with dissolve
    show e3s15_sadie_blink2
    mc "Of course I do, why would she lie?"

    if sadie_trust > 5:
        mc "It's not like she's trying to get between us or something."

    mc "She would have no reason to lie."

    scene e3s15-11 with dissolve
    hide e3s15_sadie_blink2
    sd "Alright, you want to know why I lied to you?"
    sd "I wasn't sure you would do it if I told you the truth."

    scene e3s15-08 with dissolve
    show e3s15_sadie_blink2
    mc "Well... if you can't trust me with this then maybe I wasn't the right person to ask."

    scene e3s15-09 with dissolve
    hide e3s15_sadie_blink2
    sd "You know what?"

    scene e3s15-10 with dissolve
    sd "It was an important call if you really did care."

    if sadie_trust > 5:
        scene e3s15-11 with dissolve
        sd "And I see you have no problem believing someone else other than me."

        scene e3s15-10 with dissolve

    sd "So maybe you're the one that's not so trusting after all."

    scene e3s15-08 with dissolve
    show e3s15_sadie_blink2
    mc "Of course I'm not trusting when you're just lying to my face!"
    mc "I knew it was a bad idea and I shouldn't have done it."

    if sadie_trust > 5:
        mc "But I care about you so I still went ahead and did it."
        mc "But what do you know about caring?"
        mc "You don't want to let me in either way so what's the point?"
    else:
        mc "And for your information, it wasn't a problem that the call was important."
        mc "It was how you handled the problem."
        mc "And ignoring [ev]'s multiple requests wasn't the right call."

    stop music fadeout 2.0
    scene e3s15-12 with dissolve
    hide e3s15_sadie_blink2
    pause

    jump e3s16
return
