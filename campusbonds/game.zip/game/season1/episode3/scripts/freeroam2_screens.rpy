
# Freeroam 2 screens ###########################################################

# main #########################################################################
screen e3f2_main():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-01"

    # Clickables
    if persistent.ev_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_1_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn1", True), Function(update_evelyn_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/main/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/main/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_left")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/main/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/main/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway1")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/main/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/main/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_right")

# left #########################################################################
screen e3f2_left():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-02"

    # Clickables
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/left/guitar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/left/guitar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_guitar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_guitar")

    if persistent.mixed_gallery_12_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_12_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_12_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed12", True), Function(update_mixed_list)]

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/left/bed_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/left/bed_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_bed")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_bed")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/left/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/left/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_main")

# right ########################################################################
screen e3f2_right():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-03"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/right/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/right/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_main")

    # Clickables
    if persistent.sd_gallery_12_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_12_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_12_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie12", True), Function(update_sadie_list)]

# hallway1 #####################################################################
screen e3f2_hallway1():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-04"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway1/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway1/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_main")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway1/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway1/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway2")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway1/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway1/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_middle")

    # Clickables
    if persistent.fr_gallery_10_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway1/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway1/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_10_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_10_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca10", True), Function(update_francesca_list)]

# hallway2 #####################################################################
screen e3f2_hallway2():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-05"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway2/hallway3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway2/hallway3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway3")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway2/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway2/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway1")

    # Clickables
    if e3f2_tracy == False and affinity_spectrum > 0:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway2/door_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway2/door_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f2_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f2_tracy")

# hallway3 #####################################################################
screen e3f2_hallway3():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-06"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway3/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway3/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway2")

    # Clickables
    if e3f2_hallway3_door == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway3/door_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway3/door_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f2_hallway3_door")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f2_hallway3_door")

# hallway_middle ###############################################################
screen e3f2_hallway_middle():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-09"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway1")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_left")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_middle/hallway_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_right")

    # Clickables
    if persistent.mixed_gallery_11_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway_middle/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway_middle/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_11_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_11_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed11", True), Function(update_mixed_list)]

# hallway_left ###############################################################
screen e3f2_hallway_left():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    add "e3f2-07"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_left/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_left/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_middle")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_left/hallway_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_left/hallway_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_right")

    # Clickables
    if persistent.sc_gallery_11_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway_left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway_left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_11_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_11_unlocked", True), SetVariable("persistent.e3f2_collected_p", persistent.e3f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett11", True), Function(update_scarlett_list)]

# hallway_right ###############################################################
screen e3f2_hallway_right():

    $ renpy.random.shuffle(e3f2_tracks)
    modal True

    if e3f2_hallway_right_door == False:
        add "e3f2-08_1"
    else:
        add "e3f2-08"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_right/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_right/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_middle")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam2/hallway_right/hallway_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam2/hallway_right/hallway_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f2_hallway_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f2_hallway_left")

    # Clickables
    if e3f2_hallway_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway_right/door_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway_right/door_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f2_hallway_right_door")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f2_hallway_right_door")
    else:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam2/hallway_right/door2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam2/hallway_right/door2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f2_hallway_right_door")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f2_hallway_right_door")
