
# Scene 29 - Therapy is my therapy #############################################

label e3s29:
    play sound punch
    scene e3s29-15 with vpunch
    play music keep_it_down
    pause

    play sound punch
    scene e3s29-16 with vpunch
    pause

    play sound punch
    scene e3s29-17 with vpunch
    pause

    play sound punch
    scene e3s29-18 with vpunch
    pause

    play sound punch
    scene e3s29-16 with vpunch
    pause

    play sound punch
    scene e3s29-17 with vpunch
    pause

    scene e3s29-19 with dissolve
    ov "Hey [mc]!"

    play sound punch
    scene e3s29-15 with vpunch
    pause

    play sound punch
    scene e3s29-18 with vpunch
    pause

    stop music fadeout 2.0
    scene e3s29-20 with dissolve
    play music darien_gap
    mc "Oh, [ov], hi!"

    scene e3s29-21 with dissolve
    mc "Sorry, my mind is not really here at the moment."

    scene e3s29-22 with dissolve
    ov "Where is it?"

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "I'm sorry?"

    scene e3s29-23 with dissolve
    hide e3s29_olivia_blink3
    ov "I've never seen you this aggressive."

    scene e3s29-22 with dissolve
    ov "I know you said you're not gonna take it easy with the fighting bit."
    ov "But this is not fighting, this is raging."
    ov "And I would like to know what's going on."

    scene e3s29-20 with dissolve
    mc "I've got nothing to say [ov]."

    scene e3s29-24 with dissolve
    mc "I just need to blow off some steam."

    scene e3s29-22 with dissolve
    ov "Perhaps you have to say something and you can't say it to anyone."

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "Even if that's the case, what are you gonna help me with?"

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "I'm also a therapist."

    scene e3s29-25 with dissolve
    ov "That's why I consider myself a bit of a people person now."

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "That I didn't know."

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "What do you say we schedule an appointment?"
    ov "Maybe it will make you feel better."

    scene e3s29-20 with dissolve
    mc "Thanks but no thanks [ov]."

    scene e3s29-24 with dissolve
    mc "I don't need therapy."

    scene e3s29-23 with dissolve
    ov "From what I'm seeing, you need it."

    scene e3s29-22 with dissolve
    ov "I haven't seen you talk like that ever."

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "Well, how about you stop judging me?"

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "I'm not judging you [mc]."
    ov "I'm just trying to get you to understand that this is not you."

    scene e3s29-23 with dissolve
    ov "I don't know what you're going through but I'd like to know and to help you with what I can."

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "..."

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "Look, let's just schedule one appointment."

    scene e3s29-25 with dissolve
    ov "We'll see if you like it and if you don't, I won't press anymore."

    scene e3s29-21 with dissolve
    show e3s29_olivia_blink3
    mc "Alright, but you don't bring this up ever again if I don't like it."

    scene e3s29-26 with dissolve
    hide e3s29_olivia_blink3
    ov "I give you my word."

    scene e3s29-20 with dissolve
    mc "Now, shall we get into some training?"
    mc "Or are we just gonna keep crying about my problems."

    stop music fadeout 2.0
    scene e3s29-27 with dissolve
    ov "Bring it on!"

    scene e3s29-01 with wipeleft
    pause

    scene e3s29-02 with dissolve
    pause

    scene e3s29-03 with dissolve
    show e3s29_mc_blink1
    pause

    scene e3s29-04 with dissolve
    hide e3s29_mc_blink1
    show e3s29_olivia_blink1
    pause

    scene e3s29-03 with dissolve
    hide e3s29_olivia_blink1
    show e3s29_mc_blink1
    pause

    scene e3s29-05 with dissolve
    hide e3s29_mc_blink1
    mc "Alright, this is stupid."
    mc "I'm leaving."

    scene e3s29-06 with dissolve
    play music one_fine_day
    ov "Hold on [mc]!"

    scene e3s29-07 with dissolve
    ov "You haven't said a single word since you came here."

    scene e3s29-08 with dissolve
    ov "Therapy is about talking, sharing."

    scene e3s29-07 with dissolve
    ov "You can't just sit on my sofa and expect your problems to go away."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I don't even know where to start."
    mc "Or how to start for that matter."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "Maybe you should start with what's bothering you the most in this moment."

    scene e3s29-10 with dissolve
    ov "We have to take things gradually."
    ov "Don't rush it, take your time, let the words flow naturally."

    stop music fadeout 2.0
    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    play music satfes
    mc "Alright..."
    mc "I guess I should start with my mom..."
    mc "Well, my dad actually."
    mc "Some friend mentioned my mom a little while back and it got me thinking."
    mc "I've always thought that it was my mom who left us."
    mc "But recently, I found out that it was actually my dad who drove her away."
    mc "He's the reason she left."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "How did you find that out?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I just asked my father, plain and simple."

    if e3s13_tiffany_hangout == True:
        mc "One of my other friends, [tf], also gave me this idea that my father was actually guilty for what happened in my family."
        mc "I didn't want to believe her."
        mc "Now it turns out I got mad at her for literally no reason."

        scene e3s29-10 with dissolve
        hide e3s29_olivia_blink2
        ov "And how did you feel when your father told you about your mother?"

        scene e3s29-09 with dissolve
        show e3s29_olivia_blink2
        mc "When my father told me everything..."
        mc "I felt so much anger, disappointment."
        mc "I refused to believe it."
    else:
        mc "He told me everything."

        scene e3s29-10 with dissolve
        hide e3s29_olivia_blink2
        ov "How did you feel about it?"

        scene e3s29-09 with dissolve
        show e3s29_olivia_blink2
        mc "Anger, confusion."
        mc "Mostly disappointment."
        mc "I just refused to believe it."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "Why didn't you want to believe it?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Because I've always blamed my mom for what happened."
    mc "I always thought that she was the one who left."
    mc "When in reality, he was the one who left."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "It sounds like it was a really hard pill to swallow."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Yeah, it kind of still is."
    mc "And what's hurting the most is the fact that he kept it away from me for so long."
    mc "If I hadn't brought this up I'm sure he wouldn't have told me about it, ever."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "Why do you think he did that?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "What?"
    mc "Leave or hide it from me?"

    scene e3s29-13 with dissolve
    hide e3s29_olivia_blink2
    ov "You can answer both questions if you'd like."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Well, he told me why he left."
    mc "He pointed out how unhappy my mother was with him working all the time."
    mc "And not really making time for us."
    mc "I just can't understand why he would be the one to file for divorce."
    mc "If Mom was unhappy perhaps she should have been the one to do that."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "Perhaps there's more to the story than meets the eye."

    scene e3s29-10 with dissolve
    ov "If you'd like more answers I'm afraid you'll have to talk to him again about this."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I don't wanna talk to him."
    mc "Not after what he's done."

    scene e3s29-12 with dissolve
    hide e3s29_olivia_blink2
    ov "Let's get back to the other question."

    scene e3s29-10 with dissolve
    ov "Why do you think he hid it from you?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I don't know..."
    mc "If we're gonna take the basic route I'd say he wanted to protect me."
    mc "Or maybe he wanted to protect himself from the fact that I'd hate him."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "Do you hate him?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    menu:
        "Hate him":
            call extrovert_affinity_check from _call_extrovert_affinity_check_56
            call color_check from _call_color_check_107
            $ e3s29_hate = True

            mc "Of course I do!"
            mc "Who wouldn't?"

            scene e3s29-11 with dissolve
            hide e3s29_olivia_blink2

        "Don't hate him":
            call introvert_affinity_check from _call_introvert_affinity_check_48
            call color_check from _call_color_check_108

            $ e3s29_hate = False

            mc "No... I don't."
            mc "Hate's kind of a strong word to be honest."
            mc "He's still my father after all."

            scene e3s29-13 with dissolve
            hide e3s29_olivia_blink2
            ov "Good... that's a good place to be."

            scene e3s29-11 with dissolve

    ov "Tell me about your mother."
    ov "How was she?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I mean... she was really sweet."
    mc "She would always look after me."
    mc "I remember this one time a kid picked on me in school and she got so mad because of it."
    mc "She almost came to the school to give that kid a good beating!"
    mc "Good thing I calmed her down."

    scene e3s29-13 with dissolve
    hide e3s29_olivia_blink2
    ov "She seems like a warm person."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Yeah... she is."

    if affinity_spectrum > 0:
        mc "I believe I'm a bit like her in this sense."

        scene e3s29-11 with dissolve
        hide e3s29_olivia_blink2
        ov "In what sense?"

        scene e3s29-09 with dissolve
        show e3s29_olivia_blink2
        mc "Being impulsive."
        mc "We both erupt kind of like a volcano."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "Did you ever have any reasons to believe your father was the culprit in this story?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I've had my doubts but I've always let the facts speak."
    mc "I never thought he was the bad person here."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "Why not?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "He's also got some of Mom's characteristics."
    mc "He's a really great father."
    mc "He was very good to me."
    mc "If my mother is impulsive, my father's the complete opposite."
    mc "He's always calm, he isn't one to pick fights."
    mc "There were very few times I saw him angry to the point where he screamed or raised his voice."
    mc "My mom on the other hand.. there wouldn't be a day of her not getting upset at something Dad did."
    mc "It's like she would always try and look for ways to blame my dad for everything that was wrong in our life."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "Did you also talk to him about this?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "No... I didn't get the chance."
    mc "I stormed out."
    mc "I didn't give him the chance to speak."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "How did he feel about you storming out?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "He had sort of a disappointed look on his face."
    mc "And also a worried one."

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "Disappointed how?"
    ov "Disappointed in himself, or in your reaction?"

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "I sure hope it was in himself and not in my reaction."
    mc "Because as far as I'm concerned, it was more than justified."
    mc "Right?"

    scene e3s29-11 with dissolve
    hide e3s29_olivia_blink2
    ov "These emotions you're feeling are pretty normal."

    scene e3s29-10 with dissolve
    ov "It's okay to feel betrayed, or even lost."

    scene e3s29-12 with dissolve
    ov "Sometimes... understanding the reasons behind someone's actions can help us make sense of things, even if it doesn't excuse them."

    scene e3s29-10 with dissolve
    ov "To me, this doesn't seem like the full story."
    ov "Maybe it could be worth hearing more of his side to understand what happened."
    ov "It could also be worth hearing your mother out as well."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Unfortunately, I don't know where she is."
    mc "I haven't seen her since the divorce."

    scene e3s29-10 with dissolve
    hide e3s29_olivia_blink2
    ov "Reconnecting with her and making sense of everything that's happening right now could very well help you heal."
    ov "The void you're feeling in your heart could start to fill up."

    scene e3s29-09 with dissolve
    show e3s29_olivia_blink2
    mc "Yeah, good luck with that."
    mc "It's enough that she didn't even try to contact me once."
    mc "I'm not gonna go and look for her."

    scene e3s29-13 with dissolve
    hide e3s29_olivia_blink2
    ov "Life has a very weird way of connecting the dots even when we don't feel like it."
    ov "Maybe you'll see her again some day."

    scene e3s29-14 with dissolve
    mc "Maybe, maybe not."
    mc "Who knows?"
    mc "Anyways, leaving this subject aside."
    mc "There were some things that happened at college I'd like to talk to you about as well."

    scene e3s29-13 with dissolve
    ov "Sure [mc]!"
    ov "We've got all the time."

    scene e3s29-14 with dissolve
    mc "Alright... where do I start..."

    scene e3s29-01 with dissolve
    pause

    jump e3s30
return
