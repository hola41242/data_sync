
# Scene 20 - No guitar no rock #################################################

label e3s20:
    play sound door_close
    scene e3s20-01 with wipeleft
    play music the_encouragement_stick
    pause

    scene e3s20-07 with dissolve
    fr "Hey [mc], are you alright?"

    scene e3s20-08 with dissolve
    fr "You're a bit late."

    scene e3s20-06 with dissolve
    mc "Yeah, I'm alright."
    mc "Sorry... I went to the bathroom before coming here."

    scene e3s20-08 with dissolve
    fr "I see!"
    fr "That's alright."

    scene e3s20-02 with dissolve
    pause

    scene e3s20-03 with dissolve
    pause

    scene e3s20-04 with dissolve
    pause

    scene e3s20-05 with dissolve
    ev "*You can't be serious...*"

    scene e3s20-09 with dissolve
    ev "Excuse me a bit."

    scene e3s20-10 with dissolve
    pause

    scene e3s20-11 with dissolve
    ev "[fr], can I get a couple of minutes with [mc]?"

    scene e3s20-12 with dissolve
    fr "Sure [ev]!"

    scene e3s20-13 with dissolve
    pause

    scene e3s20-15 with dissolve
    ev "What are you doing here!"

    scene e3s20-14 with dissolve
    mc "What do you mean what am I doing here?"
    mc "I'm here for the repetitions."

    scene e3s20-16 with dissolve
    ev "Stop playing dumb, you know what we discussed yesterday!"
    ev "I told you to stay away from college rock."

    scene e3s20-14 with dissolve
    mc "I know... but..."

    scene e3s20-15 with dissolve
    ev "No buts."
    ev "May I remind you that you're in no position to counter this decision?"

    scene e3s20-14 with dissolve
    mc "Why do you have to be like that?"

    scene e3s20-17 with dissolve
    fr "Hey, is everything alright?"
    fr "We're about to start the repetitions!"

    scene e3s20-18 with dissolve
    ev "No, it's not alright."

    scene e3s20-19 with dissolve
    ev "[mc] here is getting kicked out."

    scene e3s20-20 with dissolve
    fr "What? Why?"

    scene e3s20-19 with dissolve
    ev "He knows why."

    scene e3s20-22 with dissolve
    fr "What happened [mc]?"

    scene e3s20-21 with dissolve
    mc "It's a long story..."

    scene e3s20-20 with dissolve
    fr "Come on, can we sort this out later?"
    fr "Let him play this once."
    fr "There's already enough drama."

    scene e3s20-18 with dissolve
    ev "You handle him."

    scene e3s20-20 with dissolve
    fr "Alright, I'm gonna go tell the girls to get ready."

    scene e3s20-13 with dissolve
    pause

    scene e3s20-14 with dissolve
    if affinity_spectrum > 0:
        mc "So..."

        scene e3s20-23 with dissolve
        ev "Don't push it!"

        scene e3s20-14 with dissolve
        mc "Alright... I'm gone."
    else:
        mc "..."

    stop music fadeout 2.0
    scene e3s20-24 with dissolve
    pause

    scene e3s20-25 with wipeleft
    pause

    play sound door_close
    scene e3s20-27 with dissolve
    unknown "Hello!"
    unknown "Sorry I'm late."

    scene e3s20-28 with dissolve
    ev "It's alright, we haven't started yet."
    ev "Go ahead and get your instrument."

    scene e3s20-26 with dissolve
    mc "*Hm?*"

    scene e3s20-29 with dissolve
    play music pioneers
    mc "*[al]?*"

    scene e3s20-26 with dissolve
    menu:
        "Say hi to her":
            call extrovert_affinity_check from _call_extrovert_affinity_check_54
            call color_check from _call_color_check_103

            scene e3s20-30 with dissolve
            mc "Hey [al]!"
            al "[mc]?"

            scene e3s20-31 with dissolve
            al "Haha, what are you doing here?"

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "I'm the newest member of college rock!"

            scene e3s20-34 with dissolve
            hide e3s20_alice_blink1
            al "You are?"

            scene e3s20-35 with dissolve
            al "I'm surprised [ev] let you in."

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "Yeah..."
            mc "She doesn't really like me but, yeah."

            scene e3s20-33 with dissolve
            hide e3s20_alice_blink1
            al "Yeah, that's more like it."

            scene e3s20-36 with dissolve
            al "Did she assign you the guitar?"

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "Nah, it was kind of my choice."
            mc "Well, actually [fr] recommended that I start with it."

            scene e3s20-33 with dissolve
            hide e3s20_alice_blink1
            al "That's a pretty nice choice if you're gonna ask me."
        "Ignore her":
            call introvert_affinity_check from _call_introvert_affinity_check_46
            call color_check from _call_color_check_104

            scene e3s20-25 with dissolve
            pause

            scene e3s20-46 with dissolve
            al "[mc]?"

            scene e3s20-31 with dissolve
            al "What are you doing here?"

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "Hey [al]!"
            mc "I'm a pledge."

            scene e3s20-34 with dissolve
            hide e3s20_alice_blink1
            al "You want to join college rock?"
            al "How so?"

            scene e3s20-35 with dissolve
            al "And how does [ev] feel about that?"

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "Well, she doesn't really accept it."
            mc "[fr] basically helped me get in."

            scene e3s20-33 with dissolve
            hide e3s20_alice_blink1
            al "Ah, I see!"
            al "That's more like it."

            scene e3s20-35 with dissolve
            al "She doesn't really want guy members here."

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "Isn't that a little sexist?"

            scene e3s20-37 with dissolve
            hide e3s20_alice_blink1
            al "Perhaps... yeah."

            scene e3s20-38 with dissolve
            al "But that's how she is."

            scene e3s20-40 with dissolve
            al "She's had some bad experiences in the past with guy members hitting on the girls in here."

            scene e3s20-41 with dissolve
            al "That's why she doesn't really want any more guys here."

            scene e3s20-32 with dissolve
            show e3s20_alice_blink1
            mc "I understand."

            scene e3s20-36 with dissolve
            hide e3s20_alice_blink1
            al "I see you've chosen the guitar, nice choice!"

    scene e3s20-38 with dissolve
    al "I personally play the rock guitar."

    scene e3s20-42 with dissolve
    mc "The rock guitar?"

    scene e3s20-32 with dissolve
    show e3s20_alice_blink1
    mc "I didn't expect that."

    scene e3s20-33 with dissolve
    hide e3s20_alice_blink1
    al "Haha, why?"

    scene e3s20-32 with dissolve
    show e3s20_alice_blink1
    mc "I don't know, your personality doesn't seem that fitting for a rock guitar."
    mc "You seem introverted to me."

    scene e3s20-39 with dissolve
    hide e3s20_alice_blink1
    al "Just wait until you see me play."

    scene e3s20-32 with dissolve
    show e3s20_alice_blink1
    mc "I will most definitely look forward to it!"
    mc "Do you want me to move over?"

    scene e3s20-37 with dissolve
    hide e3s20_alice_blink1
    al "No, don't worry."
    al "I can reach it from here."

    scene e3s20-32 with dissolve
    show e3s20_alice_blink1
    mc "Alright!"

    scene e3s20-43 with dissolve
    hide e3s20_alice_blink1
    pause

    scene e3s20-44 with dissolve
    pause

    scene e3s20-45 with dissolve
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s20-60 with Dissolve(2.0)
    play music travel_light
    pause

    scene e3s20-47 with dissolve
    fr "Put your finger a little higher, you're getting the note wrong."

    scene e3s20-49 with dissolve
    mc "Yeah, I know."
    mc "It's a bit hard getting the motion right."

    scene e3s20-50 with dissolve
    fr "So... what happened with [ev] there?"

    if affinity_spectrum > 0:
        scene e3s20-51 with dissolve
        mc "She was being up my ass is what happened."

        scene e3s20-52 with dissolve
        fr "[mc]..."

        scene e3s20-48 with dissolve
        mc "Right... I'm sorry."
    else:
        scene e3s20-48 with dissolve

    mc "It's just that she likes to pick on me for the stupidest reasons."

    scene e3s20-53 with dissolve
    fr "And what would those reasons be?"

    scene e3s20-48 with dissolve
    mc "Well..."

    if e3s15_truth == False:
        mc "I snuck into her office to grab a phone."
    else:
        mc "Remember that phone I was telling you about?"

        scene e3s20-54 with dissolve
        fr "The one you had to get for your friend?"
        fr "What about it?"

        scene e3s20-48 with dissolve
        mc "Well.. I pretty much had to sneak into her office to grab it."

    scene e3s20-55 with dissolve
    fr "[mc], you can't do that!"

    scene e3s20-57 with dissolve
    fr "You can get expelled for it."

    scene e3s20-56 with dissolve
    mc "I know... it's just that they needed their phone back really soon."
    mc "And she wouldn't give it back so I had to take matters into my own hands."

    scene e3s20-59 with dissolve
    fr "Why didn't you ask me?"

    scene e3s20-58 with dissolve
    fr "I could have talked to her and gotten the phone back."

    scene e3s20-56 with dissolve
    mc "I didn't think about that."
    mc "Anyways, that's not the end of the story."

    if affinity_spectrum > 0:
        mc "I snuck in there a second time because my stupid ass forgot my own phone."
    else:
        mc "I had to sneak in there a second time because I forgot my own phone."
        mc "I must have dropped it or something."

    mc "First time, she let it go."
    mc "The second, she said it's enough and that she's getting me kicked out of college rock."

    scene e3s20-58 with dissolve
    fr "I understand..."

    scene e3s20-57 with dissolve
    fr "Maybe I can talk to her about it."

    scene e3s20-56 with dissolve
    mc "Also... there's this other thing."

    scene e3s20-55 with dissolve
    fr "Come on..."

    scene e3s20-59 with dissolve
    fr "Dude, you've gotta stop getting on her nerves!"

    scene e3s20-56 with dissolve
    mc "No... it's not that."
    mc "I couldn't get my phone back."
    mc "The drawer was locked and she had my phone on her."
    mc "If you're gonna talk to her about college rock, could you also ask her about my phone?"
    mc "I probably have hundreds of messages from not only friends but my father as well."

    scene e3s20-58 with dissolve
    fr "Okay, I'll see what I can do."

    scene e3s20-61 with dissolve
    pause

    scene e3s20-62 with dissolve
    mc "Come on, you stupid note."
    mc "Come... on!"

    stop music
    scene e3s20-63 with vpunch
    play music electric_girlfriend
    pause

    scene e3s20-64 with dissolve
    mc "God damn it stupid string!"

    scene e3s20-65 with dissolve
    ev "Alright, I've had enough!"
    ev "I want him out of here!"

    scene e3s20-66 with dissolve
    fr "[ev], please!"

    scene e3s20-67 with dissolve
    mc "You know what?"
    mc "I'm done with [ev]!"
    mc "I'm done with college rock!"
    mc "And I'm done with this stupid guitar!"

    scene e3s20-68 with dissolve
    pause

    scene e3s20-69 with dissolve
    fr "[mc], wait!"

    scene e3s20-70 with dissolve
    ev "Don't forget to bring back the guitar!"

    stop music fadeout 2.0
    scene e3s20-71 with dissolve
    ev "Let him leave."

    jump e3s21
return
