
# Scene 23 - Tracy's dilema ####################################################

label e3s23:
    stop music fadeout 2.0
    scene e3s23-01 with wipeleft
    pause

    scene e3s23-02 with dissolve
    pause

    play sound door_open
    scene e3s23-03 with dissolve
    mc "[tr]?"
    mc "Hi, what are you doing here?"

    scene e3s23-04 with dissolve
    tr "Hey [mc], you got a minute?"

    scene e3s23-03 with dissolve
    mc "Yeah, I was just heading to my class."
    mc "Also, sorry about our lunch."
    mc "Something got in the way."

    scene e3s23-06 with dissolve
    tr "Don't worry [mc]."

    scene e3s23-05 with dissolve
    tr "Is it alright if we go to my dorm and discuss this?"

    scene e3s23-06 with dissolve
    tr "No offense to your roommate but I'd like this to be more private."

    scene e3s23-03 with dissolve
    mc "Yeah, sure, don't worry."
    mc "Let's go."

    scene e3s23-07 with dissolve
    pause

    scene e3s23-09 with wipeleft
    play music inertia
    mc "So... what's going on?"

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "Why did you want this to be private?"

    scene e3s23-10 with dissolve
    hide e3s23_tracy_blink2
    tr "What's your relationship with [sd] exactly?"

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "Uhh... why do you ask?"

    scene e3s23-11 with dissolve
    hide e3s23_tracy_blink2
    tr "I'm just curious."

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "Have you two girls talked or...?"

    scene e3s23-10 with dissolve
    hide e3s23_tracy_blink2
    tr "Yeah, we've talked."

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "And... am I in trouble?"

    scene e3s23-12 with dissolve
    hide e3s23_tracy_blink2
    tr "Depends on your next answer."

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "Wait, I don't get it."
    mc "Did I do something or?"

    scene e3s23-13 with dissolve
    hide e3s23_tracy_blink2
    tr "Dude, just answer the question I asked you."

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    mc "Alright, my relationship with [sd]..."

    if e2s6_sadie_romance == True:
        menu:
            "Lie to her":
                $ e3s23_lie = True
                mc "We're friends."

                scene e3s23-10 with dissolve
                hide e3s23_tracy_blink2
                tr "Friends?"

                scene e3s23-08 with dissolve
                show e3s23_tracy_blink2
                mc "Yeah, just friends."

                scene e3s23-11 with dissolve
                hide e3s23_tracy_blink2
                tr "Alright..."
            "Tell her the truth":
                mc "Well... I wouldn't say we're exactly together."
                mc "But we're growing pretty close."
                mc "We had a heart to heart and decided we want to try more."
                mc "But just not right now, she said she needs a bit of space."

                scene e3s23-12 with dissolve
                hide e3s23_tracy_blink2
                tr "Alright."
    else:
        if e2s6_sadie_fwb == True:
            mc "It's not really a relationship I would say."
            mc "It's more like a friends with benefits-ship?"
            mc "I mean, neither of us is looking for anything serious right now, it's just casual."

            scene e3s23-10 with dissolve
            hide e3s23_tracy_blink2
            tr "I see."
        if e2s6_sadie_friends == True:
            if e2s6_talk == True:
                mc "Well.. we've had a heart to heart a couple of days ago."
                mc "We've basically cleared the air between us and decided to stay friends."
                mc "Nothing more, nothing less."

                scene e3s23-10 with dissolve
                hide e3s23_tracy_blink2
                tr "I understand."
            else:
                mc "I guess we're just friends now?"
                mc "I mean she was mad at me a couple of days ago but she's not anymore."
                mc "We're not close by any means."

                scene e3s23-10 with dissolve
                hide e3s23_tracy_blink2
                tr "I understand."

    scene e3s23-11 with dissolve
    if e3f3_tracy == 3:
        tr "Look, my point is that at the party you told me something that's stuck with me."

        scene e3s23-12 with dissolve
        tr "And I want some answers."

        scene e3s23-14 with dissolve
        tr "I didn't really talk to [sd] so I lied to you."

        scene e3s23-10 with dissolve
        tr "But that's because I know how territorial she can get and I wouldn't want to upset her."
        tr "Of course, that is if she likes a guy enough to care about him."
    else:
        tr "Look... I've been talking to [sd] over these past couple of days."

        scene e3s23-12 with dissolve
        tr "And I've just realized that the only guy we both have in common is you."

        scene e3s23-10 with dissolve
        tr "And I know this honestly can't be good, especially for her."

    scene e3s23-11 with dissolve
    tr "What I'm trying to say is that I care about my friendship with [sd]."

    scene e3s23-14 with dissolve
    tr "And honestly I wouldn't want a guy to come between us."

    scene e3s23-11 with dissolve
    tr "Me? I personally don't care if we're both fucking the same guy."

    scene e3s23-13 with dissolve
    tr "As long as there's no feelings involved, I'm okay with it."

    scene e3s23-10 with dissolve
    tr "Her on the other hand? I don't know how she feels about you."
    tr "So if you have any feelings for her, anything at all."
    tr "I'd advise you to stop fucking around."

    scene e3s23-13 with dissolve
    tr "It's gonna get nasty."

    scene e3s23-08 with dissolve
    show e3s23_tracy_blink2
    menu:
        "Feelings for [tr]" if tracy_trust > 5:
            $ tracy_trust += 1
            $ e3s23_tracy_feelings = True

            mc "What if I have feelings for you?"

            scene e3s23-16 with dissolve
            hide e3s23_tracy_blink2
            tr "For me?"
            tr "Come on, stop joking around."
            tr "We don't even know each other that well."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "We don't need to know each other that well to have a crush on each other."

            scene e3s23-10 with dissolve
            hide e3s23_tracy_blink3
            tr "Crushes are one thing, feelings are another."

            scene e3s23-11 with dissolve
            tr "For me, looks don't matter all that much in a relationship."

            scene e3s23-15 with dissolve
            tr "Of course, physical attraction matters, but for me, what's on the inside is more important than what's on the outside."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "I can understand that, but that doesn't mean that I'm not interested in you and I wouldn't like to get to know you better."

            scene e3s23-20 with dissolve
            hide e3s23_tracy_blink3
            tr "You do?"

            scene e3s23-19 with dissolve
            tr "I thought it was all casual."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Well, we never really got the chance to have a deeper conversation about all of this."
            mc "All this casual stuff came down pretty naturally I guess, but for me it was never only about that."
            mc "I've been wanting to get to know you for a while."

            scene e3s23-17 with dissolve
            hide e3s23_tracy_blink3
            tr "I'll be honest, this caught me off guard."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "In a good way or in a bad way?"

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "In a good way."

            scene e3s23-16 with dissolve
            tr "I mean.. now that you've told me, I think I can see you as a potential partner."
            tr "I can be quite picky when it comes to relationships."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "What exactly do you see in me?"

            scene e3s23-21 with dissolve
            hide e3s23_tracy_blink3
            tr "Well, I see one big reason right there."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Alright, and I also see two very big reasons why I'd date you."
            mc "Well... three if you count the mouth."

            scene e3s23-12 with dissolve
            hide e3s23_tracy_blink3
            tr "Wait, you've got me a bit lost here."

            scene e3s23-16 with dissolve
            tr "You're not talking about my tits?"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "I'm talking about your eyes and mouth."

            scene e3s23-22 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah.. sure Prince Charming, shut up!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "So, now that we've got this settled, I'm afraid I have to leave."
            mc "Those classes aren't gonna take themselves."

            scene e3s23-22 with dissolve
            hide e3s23_tracy_blink3
            tr "Haha, alright, fair enough!"

            scene e3s23-23 with dissolve
            tr "I probably have some classes of my own to take care of."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Okay then, see you around!"

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah, we'll keep in touch."
            tr "Bye [mc]!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Bye [tr]!"

            scene e3s23-24 with dissolve
            hide e3s23_tracy_blink3
            pause

            scene e3s23-25 with dissolve
            pause

        "Feelings for [sd]" if e2s6_sadie_romance == True:
            $ e3s23_sadie_feelings = True

            mc "I guess you're right."
            mc "I do have feelings for [sd]."
            mc "It's just that we aren't really in a relationship, I didn't expect her to be like this."
            mc "Plus, she told me she needed time."
            mc "I'm not even entirely sure she likes me."

            scene e3s23-12 with dissolve
            hide e3s23_tracy_blink2
            tr "Trust me, if you managed to get a conversation like that out of her, she likes you."

            scene e3s23-10 with dissolve
            tr "If she didn't like you, at all, she would have told you straight to your face."
            tr "So you should be safe."

            scene e3s23-08 with dissolve
            show e3s23_tracy_blink2
            if e1f5_tracy_sex == True or e2f2_tracy_sex == True or e3f3_tracy_sex == True or e3s9_tiffany_sex == True:
                mc "Yeah... I don't know how safe I'll be considering I've been sleeping around quite a bit."

                scene e3s23-11 with dissolve
                hide e3s23_tracy_blink2
                tr "You can't change what happened in the past but you can change your actions from now on."

                scene e3s23-15 with dissolve
                tr "I doubt she'll ever ask you point blank 'Have you slept around while getting to know me?'."

                scene e3s23-08 with dissolve
                show e3s23_tracy_blink2
                mc "That would be an unfortunate turn of events, I'm not going to lie."
                mc "But you're right, she doesn't strike me as that type of girl."

            mc "Anyways, I'm afraid I have to leave."
            mc "Those classes aren't gonna take themselves."

            scene e3s23-11 with dissolve
            hide e3s23_tracy_blink2
            tr "Yeah, you're right."

            scene e3s23-12 with dissolve
            tr "I probably have some classes of my own to take care of."

            scene e3s23-10 with dissolve
            tr "Just... don't break her heart, alright?"

            scene e3s23-08 with dissolve
            show e3s23_tracy_blink2
            mc "Yeah [tr]."
            mc "I'll see you around."

            scene e3s23-27 with dissolve
            hide e3s23_tracy_blink2
            pause

        "Feelings for someone else" if cleo_trust > 3 or francesca_trust > 2:

            mc "Don't worry about it [tr], I don't have any feelings for her."
            mc "I do have feelings for someone else, sure, but she's not a problem here."

            scene e3s23-12 with dissolve
            hide e3s23_tracy_blink2
            tr "That's good to know."

            scene e3s23-16 with dissolve
            tr "Just make sure you don't break anyone's heart, alright?"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Haha, will do!"
            mc "So... everything's good, right?"

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah, it's fine!"

            scene e3s23-26 with dissolve
            tr "Sorry for all of this, haha!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Don't worry, I get it."
            mc "It shows that you care about [sd]."
            mc "I'm glad that we got the opportunity to clear the air."

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah, me too!"
            tr "Thanks."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Well, if you don't have any other questions, I'll go ahead and get to my class now."

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Alright, sure thing."

            scene e3s23-16 with dissolve
            tr "See you around!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Bye [tr]!"

            scene e3s23-24 with dissolve
            hide e3s23_tracy_blink3
            pause

        "No feelings":

            mc "Don't worry about it [tr], I don't have any feelings for anybody."
            mc "At best, I could maybe be friends with benefits."
            mc "But right now, I'm not looking for anything more with anyone."

            scene e3s23-12 with dissolve
            hide e3s23_tracy_blink2
            tr "Well, that's good to know!"

            scene e3s23-17 with dissolve
            tr "This definitely took some weight off my shoulders."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "So... everything's good, right?"

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah, it's fine!"

            scene e3s23-26 with dissolve
            tr "Sorry for all of this, haha!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Don't worry, I get it."
            mc "It shows that you care about [sd]."
            mc "I'm glad that we got the opportunity to clear the air."

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Yeah, me too!"
            tr "Thanks."

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Well, if you don't have any other questions, I'll go ahead and get to my class now."

            scene e3s23-19 with dissolve
            hide e3s23_tracy_blink3
            tr "Alright, sure thing."

            scene e3s23-16 with dissolve
            tr "See you around!"

            scene e3s23-18 with dissolve
            show e3s23_tracy_blink3
            mc "Bye [tr]!"

            scene e3s23-24 with dissolve
            hide e3s23_tracy_blink3
            pause

    stop music fadeout 2.0

    jump e3s24
return
