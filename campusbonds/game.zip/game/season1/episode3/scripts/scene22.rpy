
# Scene 22 - Another minion ####################################################

label e3s22:
    scene e3s22-01 with dissolve
    mc "God damn stupid day."
    mc "Can this get any worse?"

    scene e3s22-02 with dissolve
    pause

    scene e3s22-03 with dissolve
    sd "Spit it out."

    scene e3s22-04 with dissolve
    mc "Uhh, hi?"

    scene e3s22-05 with dissolve
    sd "Tell me everything."

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    mc "What are you talking about?"
    mc "About what?"

    scene e3s22-08 with dissolve
    hide e3s22_sadie_blink1
    sd "About what happened with you and [jon]."

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    mc "Huh?"
    mc "What happened with me and [jon]?"

    scene e3s22-07 with dissolve
    hide e3s22_sadie_blink1
    sd "Stop playing, [mc]."

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    mc "No, you stop playing!"
    mc "I'm kind of starting to get sick and tired of everyone coming to me about [jon]."
    mc "Maybe I just need some time to cool off."

    scene e3s22-09 with dissolve
    hide e3s22_sadie_blink1
    sd "You need time to cool off?"
    sd "I thought you liked parties."

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    if affinity_spectrum > 0:
        mc "Yeah, I do."
        mc "It's just... not that."
    else:
        mc "I tolerate them if that's what you mean."

    scene e3s22-09 with dissolve
    hide e3s22_sadie_blink1
    sd "Then what's wrong?"

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    mc "Nothing is wrong."

    scene e3s22-10 with dissolve
    hide e3s22_sadie_blink1
    sd "Dude, come on, talk to me."

    scene e3s22-06 with dissolve
    show e3s22_sadie_blink1
    mc "No [sd], I'm not talking to you!"
    mc "I've been waiting for an apology and instead I got nothing from you."
    mc "If you only came to anger me more, you can save us both the trouble."
    mc "I got this stupid shirt stained as well and I don't need any more reasons to be upset."

    scene e3s22-11 with dissolve
    hide e3s22_sadie_blink1
    sd "Stained shirt?"

    scene e3s22-12 with dissolve
    sd "Anyways..."
    sd "Damn, I didn't think I'd have to do it so fast..."

    scene e3s22-13 with dissolve
    sd "Do you wanna sit down for this?"
    sd "I'd just feel more comfortable that way."

    scene e3s22-14 with dissolve
    mc "Sure I guess."

    if affinity_spectrum > 0:
        mc "Whatever gets you through the night."

    stop music fadeout 2.0
    scene e3s22-15 with dissolve
    play music words_fall_apart
    sd "Look dude, I'm not that great with words."

    scene e3s22-16 with dissolve
    sd "Sometimes, I might come up a bit rude or cold or whatever."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "That's not an excuse."

    scene e3s22-18 with dissolve
    hide e3s22_sadie_blink2
    sd "I know, I know..."

    scene e3s22-19 with dissolve
    sd "And what I did doesn't have anything to do with that."

    scene e3s22-18 with dissolve
    sd "Look, I know I lied to you and I'm sorry."

    scene e3s22-20 with dissolve
    sd "I shouldn't have lied."

    scene e3s22-16 with dissolve
    sd "I know you did what's best for me and I appreciate it."
    sd "And I should have been upfront with you."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "Thank you [sd]!"
    mc "This means a lot to me."
    mc "Truth be told, I could have probably handled the situation better."
    mc "I should have given you time to explain yourself."

    scene e3s22-19 with dissolve
    hide e3s22_sadie_blink2
    sd "So, we're even now?"

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "Yeah, we're good."

    scene e3s22-20 with dissolve
    hide e3s22_sadie_blink2
    sd "Good, because now I'm not leaving until I hear about your problem with [jon]."

    if affinity_spectrum > 0:
        scene e3s22-17 with dissolve
        show e3s22_sadie_blink2
        mc "Wait, can I take my apology back if that means I don't have to talk about my problem with [jon]?"

        scene e3s22-21 with dissolve
        hide e3s22_sadie_blink2
        sd "Haha, just shut up and tell me already!"

    scene e3s22-22 with dissolve
    mc "*Inhales...*"

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "Alright, look..."
    mc "It's not exactly a problem to be honest."
    mc "And it's especially not with [jon]."
    mc "It's that, I just don't know who to trust anymore."

    scene e3s22-23 with dissolve
    hide e3s22_sadie_blink2
    sd "What are you talking about?"

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "I was assaulted a few nights ago."
    mc "[sp] and one of his mates jumped me when I was walking back home."

    scene e3s22-24 with dissolve
    hide e3s22_sadie_blink2
    sd "Oh, that son of a bitch!"

    scene e3s22-25 with dissolve
    show e3s22_sadie_blink3
    if e3s4_fight == True:
        mc "I had them, I took on [sp] and beat him."
        mc "But the bastard pulled out a knife and threatened me."
    else:
        mc "I've gotta say, I kind of got my ass kicked."
        mc "What I didn't see coming though was that he pulled out a knife."
        mc "I thought I would get just a good beating and that would be it, I'm used to it."
        mc "But looks like he had other plans in mind."

    scene e3s22-26 with dissolve
    hide e3s22_sadie_blink3
    sd "Oh my god..."

    scene e3s22-25 with dissolve
    show e3s22_sadie_blink3
    mc "Good thing a guy jumped on [sp] before he could do anything and saved me."
    mc "And I wanted to tell [jon] about this but he always put me off saying that he has something else going on or that we should just party and leave the worries aside."

    scene e3s22-16 with dissolve
    hide e3s22_sadie_blink3
    sd "I'm not trying to take his side but I know how busy he can get when he plans parties."

    scene e3s22-19 with dissolve
    sd "And when he parties, he likes to feel good."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "Yeah... I can understand that to some extent."
    mc "Anyways, back to what I was saying."
    mc "This wasn't even the worst part."
    mc "At that welcome party that I left early, I found out that [jd] was conspiring with [sp]."

    scene e3s22-27 with dissolve
    hide e3s22_sadie_blink2
    sd "He was what?"

    scene e3s22-25 with dissolve
    show e3s22_sadie_blink3
    mc "Yeah, at first I didn't think he was talking to the same [sp]."
    mc "But when I asked him about it he fumbled and didn't know what to say."

    scene e3s22-20 with dissolve
    hide e3s22_sadie_blink3
    sd "[mc], I'm sorry..."
    sd "I didn't know."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "What would you do in my shoes?"

    scene e3s22-18 with dissolve
    hide e3s22_sadie_blink2
    sd "Well, for what it's worth, [jon] isn't 100 percent to blame here."

    scene e3s22-28 with dissolve
    sd "He was only wrong for not listening to you but the timing really wasn't on his side either."

    scene e3s22-16 with dissolve
    sd "I'm sure that if you tell him about it he will be more than happy to apologise and try to settle everything."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "So, you're telling me that I should talk to him?"

    scene e3s22-29 with dissolve
    hide e3s22_sadie_blink2
    sd "I'm not telling you what to do [mc], as far as I'm concerned you're old enough to make your own choices."

    scene e3s22-19 with dissolve
    sd "You should do whatever you feel like, I'm just telling you what would happen if you decide to tell him."

    scene e3s22-17 with dissolve
    show e3s22_sadie_blink2
    mc "I'm just afraid of [jon] and [sp] working together."

    scene e3s22-29 with dissolve
    hide e3s22_sadie_blink2
    sd "Working together? Haha, no."
    sd "Not in a million years."
    sd "They are basically two different breeds."

    scene e3s22-30 with dissolve
    sd "[jon] would never work with someone like [sp]."
    sd "I just think that everything has been a big fat coincidence and it has nothing to do with [jon] working with [sp]."

    scene e3s22-33 with dissolve
    show e3s22_sadie_blink4
    mc "I see..."
    mc "That makes more sense I guess."

    scene e3s22-29 with dissolve
    hide e3s22_sadie_blink4
    sd "Yup!"

    scene e3s22-31 with dissolve
    mc "*Now that this has been settled...*"
    mc "*What am I gonna do about college rock now?*"
    mc "*I wonder if [sd]'s got a guitar with which I could keep on practicing.*"
    menu:
        "Ask her about a guitar":
            $ e3s22_guitar = True
            $ guitar_skills += 1
            $ music_skills += 1
            scene e3s22-17 with dissolve
            show e3s22_sadie_blink2
            mc "Hey... also."
            mc "Weird question, do you have any guitars at home?"

            scene e3s22-32 with dissolve
            hide e3s22_sadie_blink2
            sd "Haha, what?"
            sd "Are you trying to serenade me now?"

            scene e3s22-33 with dissolve
            show e3s22_sadie_blink4
            mc "Haha!"
            mc "No, I'm just trying to learn it."
            mc "And right now, I don't have a guitar to play on."
            mc "So I just wondered if you might have one."

            scene e3s22-34 with dissolve
            hide e3s22_sadie_blink4
            sd "What made you think I'd have one?"

            scene e3s22-33 with dissolve
            show e3s22_sadie_blink4
            mc "Honestly? Nothing."
            mc "Just thought I might ask you in case you had one."

            scene e3s22-29 with dissolve
            hide e3s22_sadie_blink4
            sd "I think I have one buried deep inside my closet."

            scene e3s22-34 with dissolve
            sd "I'll have to search for it but no promises made, alright?"

            scene e3s22-32 with dissolve
            sd "I might have thrown it out."

            scene e3s22-33 with dissolve
            show e3s22_sadie_blink4
            mc "Thanks [sd]! I owe you one."

            scene e3s22-29 with dissolve
            hide e3s22_sadie_blink4
            sd "Yeah... I think we're even from that phone incident."

            scene e3s22-33 with dissolve
            show e3s22_sadie_blink4
            mc "Haha!"
        "Don't ask her":
            mc "*...*"
            mc "*Nah... I'm done with that group.*"

    if e3s11_phone_right == True:
        scene e3s22-30 with dissolve
        hide e3s22_sadie_blink4
        sd "Oh... also."
        sd "You got the wrong phone dude!"

        scene e3s22-33 with dissolve
        show e3s22_sadie_blink4
        mc "Huh?"
        mc "What do you mean?"

        scene e3s22-58 with dissolve
        hide e3s22_sadie_blink4
        sd "This isn't mine."

        scene e3s22-59 with dissolve
        mc "Oh..."

        scene e3s22-17 with dissolve
        show e3s22_sadie_blink2
        mc "Well.. to be honest I didn't even know which phone was yours."
        mc "I tried sending you a picture and seeing if your phone lit up."
        mc "But they were all out of juice."
        mc "[ev] must have turned them off so they stop ringing."

        scene e3s22-29 with dissolve
        hide e3s22_sadie_blink2
        sd "I guess so..."

        scene e3s22-30 with dissolve
        sd "Maybe you can sneak in there again and put the phone back."

        scene e3s22-33 with dissolve
        show e3s22_sadie_blink4
        mc "Haha, sure, I'm not doing it a third time."
        mc "[ev]'s gonna get me expelled for it."

        scene e3s22-29 with dissolve
        hide e3s22_sadie_blink4
        sd "Damn it..."

        scene e3s22-32 with dissolve
        sd "And here I was thinking you could also get my phone back."

        scene e3s22-30 with dissolve
        sd "Anyways, good luck giving this back to whoever it belongs to."

        scene e3s22-33 with dissolve
        show e3s22_sadie_blink4
        mc "Haha!"
        mc "I'll deal with it later."

        scene e3s22-28 with dissolve
        hide e3s22_sadie_blink4
        sd "Anyways, thank you for telling me [mc], you must be feeling better now."
    else:
        scene e3s22-28 with dissolve
        hide e3s22_sadie_blink4
        sd "Thank you for telling me [mc], you must be feeling better now."

    scene e3s22-33 with dissolve
    show e3s22_sadie_blink4
    mc "Truth be told, I'm still feeling a bit like shit."

    if e2s6_sadie_romance == True or e2s6_sadie_fwb == True:
        scene e3s22-32 with dissolve
        hide e3s22_sadie_blink4
        sd "Then I think I have a way to make you feel better."

        scene e3s22-33 with dissolve
        show e3s22_sadie_blink4
        mc "What are you talking about?"

        call e3s22_lewd from _call_e3s22_lewd

        play sound door_open
        scene e3s22-49 with dissolve
        play music invisible_light
        nt "Hey guys!"

        scene e3s22-50 with dissolve
        mc "Hi [nt]."

        scene e3s22-51 with dissolve
        mc "[sd], this is my roommate, [nt]."

        scene e3s22-52 with dissolve
        sd "Nice to meet you [nt]!"

        scene e3s22-53 with dissolve
        nt "Nice to meet you too."

        scene e3s22-54 with dissolve
        sd "Well, it was nice talking to you [mc], but I'll get going."
        sd "I will leave you two guys to catch up."
        sd "See you later [mc]!"

        scene e3s22-51 with dissolve
        mc "Bye [sd]."

        scene e3s22-55 with dissolve
        mc "*Fuck, that was a close one...*"

        scene e3s22-56 with dissolve
        nt "So, how's it going?"
    else:
        scene e3s22-16 with dissolve
        hide e3s22_sadie_blink4
        sd "I'm sorry about that [mc]."
        sd "I really hope you get better."

        scene e3s22-17 with dissolve
        show e3s22_sadie_blink2
        mc "Yeah, I hope so too."

        scene e3s22-19 with dissolve
        hide e3s22_sadie_blink2
        sd "Well, I better get going."

        scene e3s22-20 with dissolve
        sd "I'll be seeing you around [mc]!"

        scene e3s22-17 with dissolve
        show e3s22_sadie_blink2
        mc "See you [sd]!"
        mc "Thanks for listening to me."

        scene e3s22-16 with dissolve
        hide e3s22_sadie_blink4
        sd "No problem [mc]!"

        scene e3s22-57 with dissolve
        pause

        scene e3s22-42 with dissolve
        pause

        play sound door_open
        stop music fadeout 2.0
        scene e3s22-49 with dissolve
        nt "So, how's it going?"

    if affinity_spectrum > 0:
        if e1f5_tracy_sex == True or e2f2_tracy_sex == True or e3f3_tracy_sex == True:
            jump e3s23
        else:
            jump e3s24
    else:
        jump e3s24
return

label e3s22_lewd:
    stop music fadeout 2.0
    scene e3s22-34 with dissolve
    hide e3s22_sadie_blink4
    sd "Do you trust me?"

    scene e3s22-33 with dissolve
    show e3s22_sadie_blink4
    mc "Yeah, I do."

    scene e3s22-32 with dissolve
    hide e3s22_sadie_blink4
    sd "Good, then I'm going to have to ask you to close your eyes and keep them shut until I tell you to open them."

    scene e3s22-33 with dissolve
    show e3s22_sadie_blink4
    mc "Okay!"

    scene black with dissolve
    hide e3s22_sadie_blink4
    pause

    if affinity_spectrum > 0:
        mc "I like this!"
        sd "Then you should also really like what's coming next."
        mc "Haha, what are you talking about?"

    mc "Oh my God, that's tickling!"
    mc "What are you doing?"
    sd "Open your eyes!"

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e3s22-35 with dissolve
            play music heartache
            mc "Damn, that's a really hot sight."

            scene e3s22-36 with dissolve
            sd "You don't look so bad from here either."

            # Handjob
            scene e3s22-handjob2 with dissolve
            pause

            scene e3s22-handjob1 with dissolve
            mc "This feels so good [sd]!"

            scene e3s22-handjob3 with dissolve
            mc "Ah... keep doing it."

            scene e3s22-handjob2 with dissolve
            pause

            if affinity_spectrum < 0:
                mc "You have really beautiful eyes [sd]!"

                scene e3s22-36 with dissolve
                sd "Aww, thank you!"
            else:
                mc "You look really hot from here [sd]!"

            scene e3s22-handjob4 with dissolve
            pause
            mc "Fuck...!"
            mc "Your handjobs are amazing."

            scene e3s22-handjob1 with dissolve
            pause

            # Blowjob
            scene e3s22-blowjob1 with dissolve
            mc "I'm always blown away by your blowjobs, [sd]."

            scene e3s22-blowjob4 with dissolve
            mc "Oh shit, keep going!"

            scene e3s22-blowjob2 with dissolve
            pause
            mc "I love it when you look at me [sd]."

            scene e3s22-blowjob3 with dissolve
            pause

            scene e3s22-36 with dissolve
            sd "The way you talk to me makes me really wet, [mc]."
            sd "As much as I'd like to go further, you're only getting a blowjob today."

            scene e3s22-35 with dissolve
            mc "Ah... damn it!"
            mc "That's a bummer."

            scene e3s22-blowjob1 with dissolve
            pause

            scene e3s22-blowjob4 with dissolve
            pause

            scene e3s22-37 with dissolve
            sd "Here, let me try something out."
            mc "Alright."

            scene e3s22-blowjob5 with dissolve
            mc "Ah... shit!"

            scene e3s22-blowjob6 with dissolve
            mc "This feels really good [sd]."

            scene e3s22-blowjob7 with dissolve
            mc "You're doing a great job, keep going!"

            scene e3s22-38 with dissolve
            sd "Tell me when you want to cum, alright?"

            scene e3s22-39 with dissolve
            mc "Sure thing [sd]!"

            scene e3s22-blowjob5 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e3s22-35_cen with dissolve
                play music heartache
                mc "Damn, that's a really hot sight."

                scene e3s22-36_cen with dissolve
                sd "You don't look so bad from here either."

                # Handjob
                scene e3s22-handjob2_cen with dissolve
                pause

                scene e3s22-handjob1_cen with dissolve
                mc "This feels so good [sd]!"

                scene e3s22-handjob3_cen with dissolve
                mc "Ah... keep doing it."

                scene e3s22-handjob2_cen with dissolve
                pause

                if affinity_spectrum < 0:
                    mc "You have really beautiful eyes [sd]!"

                    scene e3s22-36_cen with dissolve
                    sd "Aww, thank you!"
                else:
                    mc "You look really hot from here [sd]!"

                scene e3s22-handjob4_cen with dissolve
                pause
                mc "Fuck...!"
                mc "Your handjobs are amazing."

                scene e3s22-handjob1_cen with dissolve
                pause

                # Blowjob
                scene e3s22-blowjob1_cen with dissolve
                mc "I'm always blown away by your blowjobs, [sd]."

                scene e3s22-blowjob4_cen with dissolve
                mc "Oh shit, keep going!"

                scene e3s22-blowjob2_cen with dissolve
                pause
                mc "I love it when you look at me [sd]."

                scene e3s22-blowjob3_cen with dissolve
                pause

                scene e3s22-36_cen with dissolve
                sd "The way you talk to me makes me really wet, [mc]."
                sd "As much as I'd like to go further, you're only getting a blowjob today."

                scene e3s22-35_cen with dissolve
                mc "Ah... damn it!"
                mc "That's a bummer."

                scene e3s22-blowjob1_cen with dissolve
                pause

                scene e3s22-blowjob4_cen with dissolve
                pause

                scene e3s22-37_cen with dissolve
                sd "Here, let me try something out."
                mc "Alright."

                scene e3s22-blowjob5_cen with dissolve
                mc "Ah... shit!"

                scene e3s22-blowjob6_cen with dissolve
                mc "This feels really good [sd]."

                scene e3s22-blowjob7_cen with dissolve
                mc "You're doing a great job, keep going!"

                scene e3s22-38_cen with dissolve
                sd "Tell me when you want to cum, alright?"

                scene e3s22-39_cen with dissolve
                mc "Sure thing [sd]!"

                scene e3s22-blowjob5_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Handjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s22-handjob2 with dissolve
                        pause

                        scene e3s22-handjob1 with dissolve
                        mc "This feels so good [sd]!"

                        scene e3s22-handjob3 with dissolve
                        mc "Ah... keep doing it."

                        scene e3s22-handjob2 with dissolve
                        pause

                        if affinity_spectrum < 0:
                            mc "You have really beautiful eyes [sd]!"

                            scene e3s22-36 with dissolve
                            sd "Aww, thank you!"
                        else:
                            mc "You look really hot from here [sd]!"

                        scene e3s22-handjob4 with dissolve
                        pause
                        mc "Fuck...!"
                        mc "Your handjobs are amazing."

                        scene e3s22-handjob1 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s22-handjob2_cen with dissolve
                            pause

                            scene e3s22-handjob1_cen with dissolve
                            mc "This feels so good [sd]!"

                            scene e3s22-handjob3_cen with dissolve
                            mc "Ah... keep doing it."

                            scene e3s22-handjob2_cen with dissolve
                            pause

                            if affinity_spectrum < 0:
                                mc "You have really beautiful eyes [sd]!"

                                scene e3s22-36_cen with dissolve
                                sd "Aww, thank you!"
                            else:
                                mc "You look really hot from here [sd]!"

                            scene e3s22-handjob4_cen with dissolve
                            pause
                            mc "Fuck...!"
                            mc "Your handjobs are amazing."

                            scene e3s22-handjob1_cen with dissolve
                            pause
                "Blowjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e3s22-blowjob1 with dissolve
                        mc "I'm always blown away by your blowjobs, [sd]."

                        scene e3s22-blowjob4 with dissolve
                        mc "Oh shit, keep going!"

                        scene e3s22-blowjob2 with dissolve
                        pause
                        mc "I love it when you look at me [sd]."

                        scene e3s22-blowjob3 with dissolve
                        pause

                        scene e3s22-blowjob1 with dissolve
                        pause

                        scene e3s22-blowjob4 with dissolve
                        pause

                        scene e3s22-blowjob5 with dissolve
                        mc "Ah... shit!"

                        scene e3s22-blowjob6 with dissolve
                        mc "This feels really good [sd]."

                        scene e3s22-blowjob7 with dissolve
                        mc "You're doing a great job, keep going!"

                        scene e3s22-blowjob5 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e3s22-blowjob1_cen with dissolve
                            mc "I'm always blown away by your blowjobs, [sd]."

                            scene e3s22-blowjob4_cen with dissolve
                            mc "Oh shit, keep going!"

                            scene e3s22-blowjob2_cen with dissolve
                            pause
                            mc "I love it when you look at me [sd]."

                            scene e3s22-blowjob3_cen with dissolve
                            pause

                            scene e3s22-blowjob1_cen with dissolve
                            pause

                            scene e3s22-blowjob4_cen with dissolve
                            pause

                            scene e3s22-blowjob5_cen with dissolve
                            mc "Ah... shit!"

                            scene e3s22-blowjob6_cen with dissolve
                            mc "This feels really good [sd]."

                            scene e3s22-blowjob7_cen with dissolve
                            mc "You're doing a great job, keep going!"

                            scene e3s22-blowjob5_cen with dissolve
                            pause
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        mc "Ah... fuck [sd]!"
                        mc "I'm cumming!"

                        scene e3s22-blowjob5 with dissolve
                        pause
                        mc "Shit!!"

                        scene e3s22-40 with dissolve
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        mc "Oh my God [sd], that was amazing."

                        scene e3s22-41 with dissolve
                        sd "That made me so wet, you have no idea."

                        scene e3s22-60 with dissolve
                        mc "I'd be happy to take it further-"

                        stop music
                        play sound door_open
                        scene e3s22-42
                        pause
                        mc "Shit, I think [nt]'s back!"

                        scene e3s22-43 with dissolve
                        play music nerve_damage
                        sd "Quick, put your clothes back on!"

                        scene e3s22-44 with dissolve
                        pause

                        scene e3s22-45 with dissolve
                        mc "What are you doing??"

                        scene e3s22-46 with dissolve
                        sd "Cleaning you up, idiot!"
                    else:
                        if persistent.type_nsfw == False:
                            mc "Ah... fuck [sd]!"
                            mc "I'm cumming!"

                            scene e3s22-blowjob5_cen with dissolve
                            pause
                            mc "Shit!!"

                            scene e3s22-40_cen with dissolve
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            mc "Oh my God [sd], that was amazing."

                            scene e3s22-41_cen with dissolve
                            sd "That made me so wet, you have no idea."

                            scene e3s22-60_cen with dissolve
                            mc "I'd be happy to take it further-"

                            stop music
                            play sound door_open
                            scene e3s22-42
                            pause
                            mc "Shit, I think [nt]'s back!"

                            scene e3s22-43_cen with dissolve
                            play music nerve_damage
                            sd "Quick, put your clothes back on!"

                            scene e3s22-44_cen with dissolve
                            pause

                            scene e3s22-45 with dissolve
                            mc "What are you doing??"

                            scene e3s22-46_cen with dissolve
                            sd "Cleaning you up, idiot!"

                    scene e3s22-47 with dissolve
                    sd "*Gulp!*"

                    scene e3s22-48 with dissolve
                    mc "*Holy shit.*"

                    if _in_replay:
                        play sound door_open
                        stop music fadeout 2.0
                        scene e3s22-49 with dissolve
                        play music invisible_light
                        nt "Hey guys!"

                        scene e3s22-50 with dissolve
                        mc "Hi [nt]."

                        scene e3s22-51 with dissolve
                        mc "[sd], this is my room mate, [nt]."

                        scene e3s22-52 with dissolve
                        sd "Nice to meet you [nt]!"

                        scene e3s22-53 with dissolve
                        nt "Nice to meet you too."

                        scene e3s22-54 with dissolve
                        sd "Well, it was nice talking to you [mc], but I'll get going."
                        sd "I will leave you two guys to catch up."
                        sd "See you later [mc]!"

                        scene e3s22-51 with dissolve
                        mc "Bye [sd]."

                        scene e3s22-55 with dissolve
                        mc "*Fuck, that was a close one...*"

                        scene e3s22-56 with dissolve
                        nt "So, how's it going?"

                    $ GameRunning = False

    $ renpy.end_replay()
return
