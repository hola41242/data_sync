
# Freeroam 1 screens ###########################################################

# main #########################################################################
screen e3f1_main():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-01"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/main/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/main/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_drums")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_drums")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/main/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/main/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/main/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/main/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_exit_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_exit_door")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/main/front_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/main/front_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_left_shelf")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_left_shelf")

    # Clickables
    if e3f1_ellie == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/main/ellie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/main/ellie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_ellie")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_ellie")

# drums ########################################################################
screen e3f1_drums():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-02"

    # Clickables
    if e3f1_drum == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/drums/drums_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/drums/drums_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_drum")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_drum")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/drums/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/drums/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_exit_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_exit_door")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/drums/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/drums/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_piano")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_piano")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/drums/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/drums/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

# exit door ####################################################################
screen e3f1_exit_door():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-08"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/exit_door/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/exit_door/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/exit_door/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/exit_door/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_drums")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_drums")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/exit_door/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/exit_door/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

    # Clickables
    if e3f1_instrument > 1 and e3f1_ellie == True and e3f1_penny_eva == True:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/exit_door/door_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/exit_door/door_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_door")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_door")

    if persistent.cl_gallery_11_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/exit_door/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/exit_door/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_11_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_11_unlocked", True), SetVariable("persistent.e3f1_collected_p", persistent.e3f1_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo11", True), Function(update_cleo_list)]

# couch #########################################################################
screen e3f1_couch():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-03"

    # Clickables
    if e3f1_penny_eva == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/couch/penny_eva_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/couch/penny_eva_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_penny_eva")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_penny_eva")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/couch/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/couch/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_corner")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_corner")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/couch/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/couch/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_exit_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_exit_door")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/couch/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/couch/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

# corner #######################################################################
screen e3f1_corner():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-04"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/corner/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/corner/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_left_shelf")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_left_shelf")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/corner/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/corner/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_couch")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/corner/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/corner/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

    # Clickables
    if e3f1_rock_guitar == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/corner/guitar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/corner/guitar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_rock_guitar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_rock_guitar")

    if persistent.sc_gallery_10_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/corner/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/corner/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_10_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_10_unlocked", True), SetVariable("persistent.e3f1_collected_p", persistent.e3f1_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett10", True), Function(update_scarlett_list)]

# left_shelf ###################################################################
screen e3f1_left_shelf():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-05"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/left_shelf/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/left_shelf/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_right_shelf")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_right_shelf")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/left_shelf/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/left_shelf/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_corner")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_corner")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/left_shelf/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/left_shelf/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

    # Clickables
    if e3f1_flute == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/left_shelf/flute_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/left_shelf/flute_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_flute")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_flute")

    if persistent.tf_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/left_shelf/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/left_shelf/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_1_unlocked", True), SetVariable("persistent.e3f1_collected_p", persistent.e3f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany1", True), Function(update_tiffany_list)]

# right_shelf ###################################################################
screen e3f1_right_shelf():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-06"

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/right_shelf/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/right_shelf/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_piano")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_piano")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/right_shelf/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/right_shelf/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_left_shelf")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_left_shelf")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/right_shelf/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/right_shelf/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")

    # Clickables
    if e3f1_djembe == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/right_shelf/djembe_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/right_shelf/djembe_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_djembe")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_djembe")

    if persistent.fr_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/right_shelf/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/right_shelf/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_9_unlocked", True), SetVariable("persistent.e3f1_collected_p", persistent.e3f1_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca9", True), Function(update_francesca_list)]

# piano ###################################################################
screen e3f1_piano():

    $ renpy.random.shuffle(e3f1_tracks)
    modal True

    add "e3f1-07"

    # Clickables
    if e3f1_keyboard == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/piano/piano_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/piano/piano_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3f1_keyboard")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3f1_keyboard")

    if persistent.tr_gallery_11_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/freeroam1/piano/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/freeroam1/piano/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_11_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_11_unlocked", True), SetVariable("persistent.e3f1_collected_p", persistent.e3f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy11", True), Function(update_tracy_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/piano/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/piano/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_drums")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_drums")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/piano/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/piano/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_right_shelf")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_right_shelf")

    imagebutton:
        idle im.Scale("season1/episode3/images/freeroam1/piano/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/freeroam1/piano/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3f1_main")
