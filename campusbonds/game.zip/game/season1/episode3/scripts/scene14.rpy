
# Scene 14 - Group introduction (Thursday) #####################################

label e3s14:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s14-01 with Dissolve(2.0)
    play music bpam
    fr "So, [mc], are you having second thoughts?"

    scene e3s14-02 with dissolve
    if affinity_spectrum < 0:
        mc "Truth be told, it feels a bit awkward."

        scene e3s14-01 with dissolve
        fr "Haha, don't worry, you've got nothing to worry about."

        scene e3s14-03 with dissolve
        fr "The people are very friendly here, I'm sure you'll get settled in no time."

        scene e3s14-04 with dissolve
        mc "I hope so."
    else:
        mc "Nah, I'm okay."
        mc "I was looking forward to meeting new people actually."

        scene e3s14-01 with dissolve
        fr "Oh, that's pretty great then!"

        scene e3s14-03 with dissolve
        fr "You'll get settled in no time."

        scene e3s14-04 with dissolve
        fr "Here, let's get inside."

    scene e3s14-05 with dissolve
    fr "Hey there people!"
    fr "I'd like to introduce you to our new pledge, [mc]!"

    scene e3s14-06 with dissolve
    pause

    scene e3s14-07 with dissolve
    mc "You didn't tell me this was a group full of girls."

    scene e3s14-08 with dissolve
    fr "Haha, what?"

    scene e3s14-11 with dissolve
    fr "Are you afraid of some female interaction?"

    scene e3s14-09 with dissolve
    menu:
        "Afraid":
            call introvert_affinity_check from _call_introvert_affinity_check_42
            call color_check from _call_color_check_94
            mc "Maybe I am."

            scene e3s14-08 with dissolve
            fr "Come on, stop joking around."

            if affinity_spectrum > 0:
                scene e3s14-10 with dissolve
                fr "You've basically been hanging out with women since the day you came here."

                scene e3s14-09 with dissolve
                mc "How did you..."

        "Not afraid":
            call extrovert_affinity_check from _call_extrovert_affinity_check_49
            call color_check from _call_color_check_95
            mc "Of course not."

            scene e3s14-11 with dissolve
            fr "That's what I thought."

    scene e3s14-12 with dissolve
    fr "Meet the people in here."

    scene e3s14-11 with dissolve
    fr "Grab a couple of instruments, see which one you like."

    scene e3s14-10 with dissolve
    fr "I'm gonna be away for a little bit, I need to grab something from the principal."

    scene e3s14-08 with dissolve
    fr "Be good, alright?"

    scene e3s14-09 with dissolve
    mc "Sure thing."

    scene e3s14-08 with dissolve
    fr "When I come back we can start doing repetitions."

    scene e3s14-13 with dissolve
    pause

    stop music fadeout 2.0
    scene e3s14-14 with dissolve
    pause

    jump e3f1
return
