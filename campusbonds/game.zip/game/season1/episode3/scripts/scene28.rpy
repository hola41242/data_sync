
# Scene 28 - A talk about the past #############################################

label e3s28:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s28-18 with Dissolve(2.0)
    pause

    scene e3s28-19 with dissolve
    pause

    scene e3s28-20 with dissolve
    pause

    scene e3s28-21 with dissolve
    pause

    $renpy.sound.play("audio/sfx/frying_egg.ogg", loop=True)
    scene e3s28-01 with dissolve
    play music mom_n_pa
    pause

    scene e3s28-02 with dissolve
    mc "Morning Dad."
    mc "What's cooking? Smells really nice."

    scene e3s28-03 with dissolve
    jo "Oh, morning son!"

    scene e3s28-05 with dissolve
    jo "Take a seat please, the breakfast is gonna be ready in a bit."

    scene e3s28-04 with dissolve
    jo "Some good old bacon and eggs."

    scene e3s28-02 with dissolve
    mc "Haven't had these in so long."

    scene e3s28-06 with dissolve
    jo "I thought it would be a really good time to take a trip down memory lane."

    scene e3s28-07 with dissolve
    mc "Yeah, I guess you're right Dad."

    stop sound fadeout 1.0
    scene e3s28-08 with wipeleft
    jo "I'm so glad you came home, son."

    scene e3s28-09 with dissolve
    jo "The stories you told me about college are something else."

    scene e3s28-10 with dissolve
    show e3s28_joel_blink1
    mc "I'm sure there's more to come."
    mc "I'm now stuck between choosing 2 groups that I should be in."

    scene e3s28-11 with dissolve
    hide e3s28_joel_blink1
    jo "What are you inclined towards?"

    scene e3s28-10 with dissolve
    show e3s28_joel_blink1
    mc "For now, I'm not entirely sure."
    mc "I mean, I've been enjoying partying and whatnot with the party ragers."
    mc "But I've found out that I also somewhat enjoy college rock."
    mc "I like playing an instrument and I also like the challenge of it."

    scene e3s28-11 with dissolve
    hide e3s28_joel_blink1
    jo "Well, don't be in a rush to choose son."

    scene e3s28-12 with dissolve
    jo "Take your time, rushed decisions almost always turn out bad."

    scene e3s28-10 with dissolve
    show e3s28_joel_blink1
    mc "Thank you Dad, I'll do just that."
    mc "Listen, now that you brought up memory lane..."
    mc "I've been meaning to talk to you about something."

    stop music fadeout 2.0
    scene e3s28-12 with dissolve
    hide e3s28_joel_blink1
    jo "What's up son?"

    scene e3s28-10 with dissolve
    show e3s28_joel_blink1
    mc "I know you might not want to hear this..."
    mc "But [hl] reminded me of someone last night."

    scene e3s28-13 with dissolve
    hide e3s28_joel_blink1
    jo "No, no no."
    play music it_was_then
    jo "I'm not talking about your mother."

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "I just want to know why?"
    mc "Don't I deserve to know what happened?"

    scene e3s28-15 with dissolve
    hide e3s28_joel_blink2
    jo "[mc], don't put me in this spot."

    scene e3s28-16 with dissolve
    jo "You know how much I hate talking about her."

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "What did she do to you Dad that was so bad?"
    mc "What made you crack like this?"
    mc "I know she left us but you gotta tell me something."

    scene e3s28-15 with dissolve
    hide e3s28_joel_blink2
    jo "It's not what she did..."

    scene e3s28-16 with dissolve
    jo "It's what I did!"

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "What?"
    mc "What do you mean?"

    scene e3s28-17 with dissolve
    hide e3s28_joel_blink2
    jo "Listen son, now you're grown up."
    jo "You're old enough to learn how the world works."

    scene e3s28-15 with dissolve
    jo "I know I never told you the reason me and your mom got divorced."
    jo "But I was the one that was to blame."

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "What did you do?"

    scene e3s28-16 with dissolve
    hide e3s28_joel_blink2
    jo "Something that I came to regret for the rest of my life."
    jo "I'm the one who left..."

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "What do you mean Dad?"
    mc "You've always been there for me."

    scene e3s28-17 with dissolve
    hide e3s28_joel_blink2
    jo "I've always been there for you after the divorce."

    scene e3s28-14 with dissolve
    show e3s28_joel_blink2
    mc "But we used to watch movies when I was younger."
    mc "We used to hang out in the park and have father-son time."

    scene e3s28-16 with dissolve
    hide e3s28_joel_blink2
    jo "I never got the chance to become more than that to you son."

    scene e3s28-24 with dissolve
    jo "I didn't listen to your problems in school, hell I didn't even watch you grow up."

    scene e3s28-25 with dissolve
    jo "I was always away for work and I put it above you and your mom."

    scene e3s28-16 with dissolve
    jo "She was always complaining but I didn't do anything about it..."
    jo "I thought that she could handle it and that my role was to provide."
    jo "But I only provided financially, not emotionally."
    jo "Which is equally, if not more important than money."

    scene e3s28-23 with dissolve
    show e3s28_joel_blink3
    mc "So... you're telling me that the whole reason Mom left was... because of you?"

    scene e3s28-22 with dissolve
    hide e3s28_joel_blink3
    jo "Son, this is something that I'm gonna be regretting for the rest of my life."

    scene e3s28-23 with dissolve
    show e3s28_joel_blink3
    mc "When she needed you, you just left?"
    mc "You vanished from her life?"

    scene e3s28-16 with dissolve
    hide e3s28_joel_blink3
    jo "That's why I didn't want to talk about her..."

    scene e3s28-23 with dissolve
    show e3s28_joel_blink3
    mc "I don't even want to know who filed for divorce."

    scene e3s28-16 with dissolve
    hide e3s28_joel_blink3
    jo "...it was me."

    scene e3s28-26 with dissolve
    mc "..."

    scene e3s28-27 with dissolve
    pause

    scene e3s28-28 with dissolve
    jo "Where are you going son?"

    scene e3s28-29 with dissolve
    mc "I'm going back to college."
    mc "I don't feel like I belong here."

    stop music fadeout 2.0
    scene e3s28-30 with dissolve
    jo "Son..."

    jump e3s29
return
