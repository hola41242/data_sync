
# Scene 27 - Father-son time ###################################################

label e3s27:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s27-62 with Dissolve(2.0)
    play music little_tomcat
    jo "My son!"

    scene e3s27-63 with dissolve
    jo "Welcome back."

    scene e3s27-64 with dissolve
    mc "Hey Dad!"

    scene e3s27-65 with dissolve
    pause

    scene e3s27-66 with dissolve
    pause

    scene e3s27-67 with dissolve
    jo "How was the trip here?"

    scene e3s27-68 with dissolve
    mc "It was alright."

    scene e3s27-69 with dissolve
    show e3s27_joel_blink1
    mc "Not as crowded as I thought it would be."
    mc "How have you been Dad?"

    scene e3s27-70 with dissolve
    hide e3s27_joel_blink1
    jo "Well, you know how I've been."

    scene e3s27-71 with dissolve
    jo "Nothing's changed son."

    scene e3s27-69 with dissolve
    show e3s27_joel_blink1
    mc "I'm glad to hear that."
    mc "How's work?"

    scene e3s27-72 with dissolve
    hide e3s27_joel_blink1
    jo "It's been a bit of a mess these last couple of days."

    scene e3s27-73 with dissolve
    jo "So many new cases, it's a bit overwhelming."

    scene e3s27-71 with dissolve
    jo "But we'll manage!"

    scene e3s27-69 with dissolve
    show e3s27_joel_blink1
    mc "Hey Dad, when's the movie running?"

    scene e3s27-71 with dissolve
    hide e3s27_joel_blink1
    jo "In about three hours."

    scene e3s27-69 with dissolve
    show e3s27_joel_blink1
    mc "I see!"
    mc "So I have a bit of time to unwind."

    scene e3s27-71 with dissolve
    hide e3s27_joel_blink1
    jo "Yeah son, by all means!"

    scene e3s27-72 with dissolve
    jo "Take your time."

    scene e3s27-69 with dissolve
    show e3s27_joel_blink1
    mc "Thanks Dad!"
    mc "It's good to be home."

    scene e3s27-71 with dissolve
    hide e3s27_joel_blink1
    jo "It's good to have you back."

    scene e3s27-74 with dissolve
    pause

    play sound door_close
    scene e3s27-76 with dissolve
    mc "*Damn.. I can't believe it's been two weeks already since I was last here.*"

    scene e3s27-75 with dissolve
    mc "*Time flies fast when you're in college.*"

    scene e3s27-77 with dissolve
    pause

    stop music fadeout 2.0
    scene e3s27-78 with dissolve
    pause

    scene e3s27-01 with wipeleft
    play music bad_sexy_dad_vibes
    mc "I can't believe it Dad, it's been so long since we've been here."

    scene e3s27-02 with dissolve
    pause

    scene e3s27-03 with dissolve
    jo "I know right?"
    jo "Remember when we watched the first Killer in Action?"
    jo "It was at this very cinema."

    scene e3s27-04 with dissolve
    mc "Yeah, it's been so long."
    mc "They sure have taken their time with this one."

    scene e3s27-05 with dissolve
    jo "If it's at least as good as the first one then I don't mind the waiting time."
    mc "You're right on this regard!"

    scene e3s27-06 with dissolve
    pause

    scene e3s27-07 with dissolve
    jo "Hey son, isn't that [hl]?"

    scene e3s27-08 with dissolve
    mc "Is it?"

    scene e3s27-09 with dissolve
    jo "Yeah, come on let's say hi."

    scene e3s27-10 with dissolve
    mc "Dad, I don't think-"

    scene e3s27-11 with dissolve
    pause

    scene e3s27-12 with dissolve
    jo "Hey there [hl]!"
    jo "Long time no see."

    if affinity_spectrum > 0:
        mc "*Oh my God...*"

    scene e3s27-13 with dissolve
    hl "[jo]?"

    scene e3s27-14 with dissolve
    hl "Oh, it's so good to see you!"

    scene e3s27-15 with dissolve
    hl "How have you guys been?"

    scene e3s27-16 with dissolve
    jo "Oh, we've been pretty good!"

    scene e3s27-17 with dissolve
    jo "[mc]'s here just started college."

    scene e3s27-18 with dissolve
    hl "Oh, did he now?"

    scene e3s27-20 with dissolve
    hl "How's college treating you, [mc]?"

    scene e3s27-19 with dissolve
    if affinity_spectrum > 0:
        mc "*I swear to God, if I have to answer this one more time...*"

    mc "It's okay."

    scene e3s27-20 with dissolve
    hl "Oh... I'm glad really!"

    scene e3s27-18 with dissolve
    hl "Hey, you guys are here to watch Killer in Action as well?"

    scene e3s27-21 with dissolve
    jo "Haha, of course we are!"
    jo "We used to love this series."

    scene e3s27-18 with dissolve
    hl "Haha, yeah, I remember!"
    hl "How's [aml], did you keep in touch?"

    scene e3s27-22 with dissolve
    jo "No... not at all."

    scene e3s27-23 with dissolve
    hl "It's such a shame you guys broke up."

    scene e3s27-20 with dissolve
    hl "I remember how rough it was for [mc] here."

    scene e3s27-24 with dissolve
    jo "Yeah well... that's life, what can you do?"

    scene e3s27-25 with dissolve
    hl "Anyways, I'll go inside."
    hl "Hopefully we're not too far apart, maybe we can watch the movie together!"

    scene e3s27-21 with dissolve
    jo "Yeah well, see you inside!"

    scene e3s27-26 with dissolve
    pause

    scene e3s27-28 with dissolve
    jo "She's so sweet."

    scene e3s27-27 with dissolve
    mc "Yeah... like a bittersweet candy."
    mc "Only that she's just bitter without the sweet."

    scene e3s27-29 with dissolve
    jo "Why did you guys stop talking?"

    scene e3s27-30 with dissolve
    jo "I can't remember."

    scene e3s27-31 with dissolve
    mc "Circumstances, Dad."
    mc "I don't really want to talk about her."

    scene e3s27-32 with dissolve
    jo "But she was your best friend!"

    scene e3s27-31 with dissolve
    mc "Yeah, *was*, past tense?"

    scene e3s27-33 with dissolve
    jo "Alright, alright..."

    scene e3s27-34 with dissolve
    jo "I won't press on it."

    scene e3s27-33 with dissolve
    jo "You were too young anyways."

    scene e3s27-31 with dissolve
    mc "What does that even mean?"

    scene e3s27-35 with dissolve
    jo "Let's just get some popcorn and then we can go inside, alright?"

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e3s27-37 with Dissolve(2.0)
    pause

    scene e3s27-36 with dissolve
    if affinity_spectrum > 0:
        mc "Holy shit, that was awesome!"
    else:
        mc "That was awesome!"

    scene e3s27-38 with dissolve
    jo "I really didn't think they would be able to top their last entries."
    jo "But here they are, proving me wrong once again."

    scene e3s27-39 with dissolve
    mc "Haha, yeah!"
    mc "If it wasn't for the constant audio interference throughout 90 percent of the movie, I would have rated it a 10/10."

    scene e3s27-42
    play music motown_rehearsal
    hl "Hey, oh my God, look at that!"

    scene e3s27-43
    hl "Did you guys just see that?"

    scene e3s27-44
    hl "No way he just escapes like that."

    scene e3s27-45
    hl "Woow... that must've hurt!"

    stop music
    scene e3s27-46 with dissolve
    mc "..."

    scene e3s27-40 with dissolve
    jo "Hey, hey, it's not fair to judge the movie based on outside factors."

    scene e3s27-41 with dissolve
    if affinity_spectrum < 0:
        mc "Yeah, you're right Dad, I was just joking."
    else:
        mc "The 'outside factors' shouldn't have been present there in the first place."

    scene e3s27-47 with dissolve
    play music tidalwave
    hl "Holy mother of God, that movie was boring."

    scene e3s27-48 with dissolve
    mc "What?"
    mc "I thought you liked it."

    scene e3s27-49 with dissolve
    hl "More or less, yeah."

    scene e3s27-50 with dissolve
    hl "I just hated the way it ended."

    scene e3s27-51 with dissolve
    hl "Anyways, it was really fun!"
    hl "Hey, we should hang out some time [mc]."
    hl "Now that you're home again."

    scene e3s27-52 with dissolve
    mc "Yeah, maybe some other time."
    mc "I'll have to get back to college."

    scene e3s27-53 with dissolve
    hl "Oh... that's a bummer."

    scene e3s27-54 with dissolve
    jo "Join us for dinner!"
    mc "*You did not just say that...*"

    scene e3s27-55 with dissolve
    jo "Catch up a bit, make use of the time."

    scene e3s27-54 with dissolve
    mc "Nah... no need-"

    scene e3s27-56 with dissolve
    hl "Really?"

    scene e3s27-58 with dissolve
    hl "That's such a great idea!"
    hl "Thank you [jo] for the invitation."
    hl "We're gonna have the time of our lives."

    scene e3s27-59 with dissolve
    mc "Yay..."

    scene e3s27-55 with dissolve
    jo "Let me call a taxi and we can go home."

    scene e3s27-60 with dissolve
    jo "I've got some lasagna ready for us, just the way you like it [mc]!"

    scene e3s27-57 with dissolve
    hl "Oh yeah, I remember how much he used to like lasagna when he was younger!"

    scene e3s27-61 with dissolve
    hl "Also, do you remember when I used to call [jo] sir?"
    hl "Haha, it feels so weird now to call him that."
    mc "*It's gonna be a long night...*"

    jump e3s28
return
