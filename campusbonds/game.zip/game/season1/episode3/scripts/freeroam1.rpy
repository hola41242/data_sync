
# Variables
default e3f1_ellie = False
default e3f1_flute = False
default e3f1_rock_guitar = False
default e3f1_keyboard = False
default e3f1_djembe = False
default e3f1_instrument = 0

default e3f1_explore = 0

# Freeroam Collected Photos #

default persistent.e3f1_collected_p = 0
default persistent.e3f1_collected_tp = 5

# Freeroam 1 ###################################################################
label e3f1:
    define e3f1_tracks = ["aces_high.ogg", "bad_sexy_dad_vibes.ogg", "dances_and_dames.ogg", "heartless_man.ogg", "hi_as_hats.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "marathon_man.ogg", "motown_rehearsal.ogg", "onfire.ogg", "pioneers.ogg", "tidalwave.ogg", "travel_light.ogg"]
    $ renpy.random.shuffle(e3f1_tracks)
    $ renpy.music.queue (e3f1_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")
    $ current_quests.append("Try out a couple of instruments.")

    scene e3f1-01 with dissolve
    call screen e3f1_main
    hide e3f1-01
return

# Map ##########################################################################

# Main ###
label e3f1_main:
    scene e3f1-01
    call screen e3f1_main with dissolve
return

label e3f1_ellie:
    scene e3f1-el_01 with dissolve
    mc "Hey, what's up?"

    scene e3f1-el_03 with dissolve
    unknown "Hello!"

    scene e3f1-el_04 with dissolve
    unknown "[mc], right?"

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "Yup, that's me!"

    scene e3f1-el_05 with dissolve
    hide e3f1_ellie_blink1
    unknown "I'm [el], nice to meet you!"

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "So, you're a vocalist?"

    scene e3f1-el_06 with dissolve
    hide e3f1_ellie_blink1
    el "I'm not the lead vocalist, but yeah."

    scene e3f1-el_03 with dissolve
    el "I'm kind of a back up in case something happens to [fr]."

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "She's the lead vocalist?"

    scene e3f1-el_05 with dissolve
    hide e3f1_ellie_blink1
    el "Yup!"

    scene e3f1-el_04 with dissolve
    el "She can also play the rock guitar."

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "So she's basically two in one."

    scene e3f1-el_05 with dissolve
    hide e3f1_ellie_blink1
    el "Kind of like that, yeah!"

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "I see!"
    mc "So, are you also playing something else?"

    scene e3f1-el_06 with dissolve
    hide e3f1_ellie_blink1
    el "I've been practicing with some instruments."

    scene e3f1-el_05 with dissolve
    el "The piano has been most to my liking but I've still got lots to learn."

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "I see!"

    scene e3f1-el_04 with dissolve
    hide e3f1_ellie_blink1
    el "So, [mc], what do you know how to play?"

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "Well... that's kind of the thing."
    mc "I don't know how to play anything."

    scene e3f1-el_07 with dissolve
    hide e3f1_ellie_blink1
    el "Haha!"

    scene e3f1-el_03 with dissolve
    el "Don't worry, you'll have a lot of time to learn."

    scene e3f1-el_05 with dissolve
    el "We've also got really good teachers."

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "I see!"

    scene e3f1-el_06 with dissolve
    hide e3f1_ellie_blink1
    el "There's also this member who couldn't make it today."

    scene e3f1-el_03 with dissolve
    el "You'll have to meet her some other time."

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "Well, it's not really a problem."

    if affinity_spectrum > 0:
        mc "I don't think I'll be here for long anyways."

        scene e3f1-el_08 with dissolve
        hide e3f1_ellie_blink1
        el "Oh, why's that?"

        scene e3f1-el_02 with dissolve
        show e3f1_ellie_blink1
        mc "I'm not much of a singer myself."
        mc "And I'd be lucky to play a couple of single notes."

        scene e3f1-el_03 with dissolve
        hide e3f1_ellie_blink1
        el "Oh, haha!"
        el "I see."

        scene e3f1-el_02 with dissolve
        show e3f1_ellie_blink1

    mc "Anyways, I won't take any more of your time."
    mc "I'll go ahead and try some instruments and maybe talk to the other girls as well."

    scene e3f1-el_05 with dissolve
    hide e3f1_ellie_blink1
    el "Alright, good luck!"

    scene e3f1-el_04 with dissolve
    el "If you need any type of help, you can ask me, alright?"

    $ e3f1_explore += 1

    if e3f1_explore == 2:
        $ current_quests.remove("Interact with people.")

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    $ e3f1_ellie = True

    scene e3f1-el_02 with dissolve
    show e3f1_ellie_blink1
    mc "Sure!"

    hide e3f1_ellie_blink1

    jump e3f1_main
return

# Drums ###
label e3f1_drums:
    scene e3f1-02
    call screen e3f1_drums with dissolve
return

label e3f1_drum:

    if e3f1_penny_eva == False:
        scene e3f1-dr_01 with dissolve
        mc "*Alright, let's try the drums!*"

        scene e3f1-dr_02 with dissolve
        pause

        scene e3f1-dr_03 with dissolve
        unknown "Hey, hey!"
        unknown "What do you think you're doing?"

        scene e3f1-dr_04 with dissolve
        mc "Trying out the drums?"

        scene e3f1-dr_06 with dissolve
        unknown "And did you even think about asking first?"

        scene e3f1-dr_08 with dissolve
        mc "I didn't think that was necessary."

        scene e3f1-dr_09 with dissolve
        unknown "Come on [eva]!"
        unknown "Cut him some slack, he's new."

        scene e3f1-dr_10 with dissolve
        eva "I don't care, [pe]!"
        eva "He should have asked permission first."

        scene e3f1-dr_11 with dissolve
        if affinity_spectrum > 0:
            mc "Just chill, alright?"
            mc "I didn't know they were yours, jeez."
            mc "I'm not gonna pick a fight with you."

            scene e3f1-dr_12 with dissolve
            eva "These fucking guys, they never listen."
        else:
            mc "Alright, sorry!"

            scene e3f1-dr_12 with dissolve
            eva "Guh..."

        scene e3f1-dr_15 with dissolve
        pe "Just excuse her, alright?"
        pe "She's not that fond of new people."

        $ e3f1_explore += 1

        if e3f1_explore == 2:
            $ current_quests.remove("Interact with people.")

        if e3f1_explore == 2 and e3f1_instrument > 1:
            if not "Open the front door." in current_quests:
                $ current_quests.append("Open the front door.")

        $ e3f1_penny_eva = True

        scene e3f1-dr_14 with dissolve
        mc "Yeah, I can tell."

    else:
        if e3f1_option == 3:
            scene e3f1-dr_01 with dissolve
            mc "*You know what?*"
            mc "*I'm gonna try the drums anyways.*"

            scene e3f1-dr_02 with dissolve
            pause

            scene e3f1-dr_03 with dissolve
            eva "Hey, hey!"
            eva "What do you think you're doing?"

            scene e3f1-dr_04 with dissolve
            mc "Trying out the drums?"

            scene e3f1-dr_06 with dissolve
            eva "I thought I made it clear that I don't want you anywhere near them!"

            scene e3f1-dr_05 with dissolve
            mc "But I just wanna try them."

            scene e3f1-dr_07 with dissolve
            eva "Listen here, punk!"
            eva "If you wanna get along here, you better listen."

            scene e3f1-dr_09 with dissolve
            pe "[eva], come on, cut it out!"
            pe "Stop fighting with him."

            scene e3f1-dr_10 with dissolve
            eva "I don't care, he is not gonna touch my drums, period!"

            scene e3f1-dr_09 with dissolve
            pe "He won't, come on."

            scene e3f1-dr_13 with dissolve
            eva "..."

            if affinity_spectrum > 0:
                scene e3f1-dr_16 with dissolve
                mc "*Crazy ass people...*"
        else:
            scene e3f1-dr_01 with dissolve
            mc "*Alright, let's try the drums!*"

            scene e3f1-dr_02 with dissolve
            pause

            scene e3f1-dr_03 with dissolve
            eva "Hey, hey!"
            eva "What do you think you're doing?"

            scene e3f1-dr_04 with dissolve
            mc "Trying out the drums?"

            scene e3f1-dr_06 with dissolve
            eva "And did you even think about asking first?"

            scene e3f1-dr_08 with dissolve
            mc "I didn't think that was necessary."

            scene e3f1-dr_09 with dissolve
            pe "Come on [eva]!"
            pe "Cut him some slack, he's new."

            scene e3f1-dr_10 with dissolve
            eva "I don't care, [pe]!"
            eva "He should have asked permission first."

            scene e3f1-dr_11 with dissolve
            if affinity_spectrum > 0:
                mc "Just chill, alright?"
                mc "I didn't know they were yours, jeez."
                mc "I'm not gonna pick a fight with you."

                scene e3f1-dr_12 with dissolve
                eva "These fucking guys, they never listen."
            else:
                mc "Alright, sorry!"

                scene e3f1-dr_12 with dissolve
                eva "Guh..."

    $ e3f1_drum = True
    $ eva_trust -= 1

    jump e3f1_drums
return

# Exit door ###
label e3f1_exit_door:
    scene e3f1-08
    call screen e3f1_exit_door with dissolve
return

label e3f1_door:
    $ collected_p = persistent.e3f1_collected_p
    $ collected_tp = persistent.e3f1_collected_tp
    $ renpy.show_screen("render_count_notify_pers")

    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e3s15

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e3f1_exit_door
return

# couch ###
label e3f1_couch:
    scene e3f1-03
    call screen e3f1_couch with dissolve
return

label e3f1_penny_eva:
    scene e3f1-pe_01 with dissolve
    mc "Hey!"

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    mc "What's up?"

    scene e3f1-pe_03 with dissolve
    hide e3f1_penny_blink1
    unknown "Hello!"
    unknown "Welcome to college rock!"

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    mc "Thank you."

    scene e3f1-pe_04 with dissolve
    hide e3f1_penny_blink1
    unknown "I'm [pe]."

    scene e3f1-pe_05 with dissolve
    pe "This is [eva]."

    scene e3f1-pe_06 with dissolve
    eva "Sup."

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    mc "I'm [mc]."
    mc "Nice to meet you."

    scene e3f1-pe_04 with dissolve
    hide e3f1_penny_blink1
    pe "You too!"
    pe "We've been talking about you and we've both been wondering what instrument you play."

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    if affinity_spectrum < 0:
        mc "Well... that's gotta be a bit awkward."
        mc "I don't really play any instrument."

        scene e3f1-pe_04 with dissolve
        hide e3f1_penny_blink1
        pe "Oh, that's no reason to feel ashamed!"

        scene e3f1-pe_03 with dissolve
        pe "We've all started from the ground up."
    else:
        mc "I don't play any instrument."

        scene e3f1-pe_07 with dissolve
        hide e3f1_penny_blink1
        pe "Oh... I understand."

    scene e3f1-pe_04 with dissolve
    pe "Do you have any instrument which sounds interesting to you?"

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    if e3f1_instrument > 0:
        mc "Well... I've tried some instruments here."
    else:
        mc "Honestly... I haven't touched anything yet."

    mc "I guess I've been thinking about..."

    menu:
        "Piano keyboard":
            $ e3f1_option = 1
            mc "I guess the piano keyboard looks interesting."

            scene e3f1-pe_08 with dissolve
            hide e3f1_penny_blink1
            pe "Oh, haha!"

            scene e3f1-pe_04 with dissolve
            pe "That's basically the second option newcomers choose for an instrument."

            scene e3f1-pe_05 with dissolve
            pe "The first one being of course the guitar."

            scene e3f1-pe_04 with dissolve
            pe "I'm a bit shocked you didn't choose that one."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Well... from where I'm standing, every single one of them sounds like a different language to me."

            scene e3f1-pe_08 with dissolve
            hide e3f1_penny_blink1
            pe "Haha, I guess you could say that!"

            scene e3f1-pe_03 with dissolve
            pe "Don't worry, we've got a great professor, I'm sure you're gonna learn in no time."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "I mean, that would be pretty nice."
            mc "Having touched no instrument in this lifetime will surely make it tough."

            scene e3f1-pe_04 with dissolve
            hide e3f1_penny_blink1
            pe "Tough but not impossible!"

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
        "Guitar":
            $ e3f1_option = 2
            mc "The guitar looked pretty interesting."

            scene e3f1-pe_07 with dissolve
            hide e3f1_penny_blink1
            pe "The guitar... hmm!"

            scene e3f1-pe_04 with dissolve
            pe "I thought you might have chosen that."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Haha, why's that?"

            scene e3f1-pe_05 with dissolve
            hide e3f1_penny_blink1
            pe "It's basically every newbie's undisputed choice."
            pe "That and the piano."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Oh... I see."

            scene e3f1-pe_04 with dissolve
            hide e3f1_penny_blink1
            pe "Yeah, don't worry."
            pe "The guitar is not that complicated to learn."
            pe "If you practice it daily it will be like riding a bike."

            scene e3f1-pe_03 with dissolve
            pe "You'll never forget it."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Haha, that's nice to hear!"
        "Drums":
            $ e3f1_option = 3
            $ eva_trust -= 1

            mc "Well... the drums look interesting to me."

            scene e3f1-pe_09 with dissolve
            hide e3f1_penny_blink1
            eva "Oh no, don't you even think about it!"

            scene e3f1-pe_10 with dissolve
            mc "Huh?"

            scene e3f1-pe_11 with dissolve
            eva "I play the drums, nobody else."

            scene e3f1-pe_12 with dissolve
            eva "That was a very expensive kit and I wouldn't like anyone touching and breaking it."

            scene e3f1-pe_11 with dissolve
            eva "Much less you."

            scene e3f1-pe_10 with dissolve
            mc "Alright...?"

            scene e3f1-pe_11 with dissolve
            eva "So don't even think about going near them."

            scene e3f1-pe_10 with dissolve
            mc "It's not like I destroyed them."
            mc "Just thought they sound interesting to play."

            scene e3f1-pe_13 with dissolve
            pe "That's enough [eva]."

            scene e3f1-pe_14 with dissolve
            eva "Whatever..."

            scene e3f1-pe_04 with dissolve
            pe "The drums can be a bit of a challange."
            pe "Because there's a lot of things to be mindful of."
            pe "But it sure is satisfying to play!"

            scene e3f1-pe_08 with dissolve
            pe "I can understand why [eva] gatekeeps them that much, haha!"

            scene e3f1-pe_15 with dissolve
            eva "It's not gatekeeping [pe]."
            eva "I just wouldn't like for them to break."

            scene e3f1-pe_12 with dissolve
            eva "You know how much it would take for them to replace the kit?"
            eva "I don't wanna play the stupid flute again."

            scene e3f1-pe_13 with dissolve
            pe "Haha, you know you don't have to play the flute if you don't like it, right?"

            scene e3f1-pe_14 with dissolve
            eva "That's not what I've been told..."
            eva "Nobody plays the flute, she told me that it would be a good instrument to learn."

            scene e3f1-pe_13 with dissolve
            pe "That doesn't mean that you were obligated to learn it."

            scene e3f1-pe_14 with dissolve
            eva "Yeah, whatever..."

            scene e3f1-pe_11 with dissolve
            eva "Nobody goes near the drums and that's that."

            scene e3f1-pe_14 with dissolve
            eva "It's better that way for everyone."

            scene e3f1-pe_04 with dissolve
            pe "Ignore her, she gets really defensive about the drums."
            pe "Just... don't touch them, alright?"

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Yeah... sure."
        "Flute":
            $ e3f1_option = 4
            mc "The flute."

            scene e3f1-pe_08 with dissolve
            hide e3f1_penny_blink1
            pe "The flute?"
            pe "That's a first!"
            pe "You're more than welcome to try that out."
            pe "We have no flute players in here."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Really?"

            scene e3f1-pe_07 with dissolve
            hide e3f1_penny_blink1
            pe "Yeah, we don't really use it in our plays."

            scene e3f1-pe_04 with dissolve
            pe "But I'm sure it could come in handy for some special plays."
            pe "And I'm sure we could find a way to incorporate that into our repetitions."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "That's relieving to hear."
        "Small drum in the corner":
            $ e3f1_option = 5
            $ penny_trust += 1
            mc "I guess the little drum in the corner looks interesting."

            scene e3f1-pe_08 with dissolve
            hide e3f1_penny_blink1
            pe "Haha, that's a djembe!"

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "A what?"

            scene e3f1-pe_04 with dissolve
            hide e3f1_penny_blink1
            pe "A djembe."
            pe "It's a goblet drum which is played with bare hands."
            pe "It firstly originated in West Africa."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "Oh... I see."

            scene e3f1-pe_04 with dissolve
            hide e3f1_penny_blink1
            pe "Yeah, that's what I play."
            pe "I could show you how to play it if you'd like."

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "That would be pretty nice!"

            scene e3f1-pe_08 with dissolve
            hide e3f1_penny_blink1
            pe "Yeah, sure!"

            scene e3f1-pe_04 with dissolve
            pe "It's not an instrument for everyone but if you come to understand it I'm sure you're gonna like it!"

            scene e3f1-pe_02 with dissolve
            show e3f1_penny_blink1
            mc "I see."

    mc "Anyways, I'll get off your backs."
    mc "Probably try some instruments around here."

    scene e3f1-pe_08 with dissolve
    hide e3f1_penny_blink1
    pe "Alright, have fun!"

    scene e3f1-pe_04 with dissolve
    pe "If you need any help, don't be afraid to ask okay?"

    $ e3f1_explore += 1

    if e3f1_explore == 2:
        $ current_quests.remove("Interact with people.")

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    $ e3f1_penny_eva = True

    scene e3f1-pe_02 with dissolve
    show e3f1_penny_blink1
    mc "Sure!"

    hide e3f1_penny_blink1

    jump e3f1_couch
return

# Corner ###
label e3f1_corner:
    scene e3f1-04
    call screen e3f1_corner with dissolve
return

label e3f1_rock_guitar:
    scene e3f1-gu_01 with dissolve
    mc "*Let's make this a little interesting, shall we?*"

    scene e3f1-gu_02 with dissolve
    mc "*That's what I'm talking about!*"
    mc "*ROCK N ROLL!*"

    $renpy.sound.play("audio/sfx/bad_electric_guitar.ogg", loop=False)
    scene e3f1-gu_03 with vpunch
    pause

    scene e3f1-gu_02 with dissolve
    mc "*Holy shit..*"

    scene e3f1-gu_04 with dissolve
    mc "Sorry guys!"
    mc "I didn't know it gets so loud."

    $ e3f1_rock_guitar = True
    $ e3f1_instrument += 1
    $ music_skills += 1

    if e3f1_instrument > 1:
        if "Try out a couple of instruments." in current_quests:
            $ current_quests.remove("Try out a couple of instruments.")
        if not "Try out all instruments." in optional_quests:
            $ optional_quests.append("Try out all instruments.")

    if e3f1_instrument == 4:
        $ optional_quests.remove("Try out all instruments.")
        $ music_skills += 1

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    scene e3f1-gu_02 with dissolve
    mc "*Damn... no rock and roll I guess...*"

    jump e3f1_corner
return

# Left shelf ###
label e3f1_left_shelf:
    scene e3f1-05
    call screen e3f1_left_shelf with dissolve
return

label e3f1_flute:
    scene e3f1-fl_01 with dissolve
    mc "*Alright, let's see how this thing works.*"

    scene e3f1-fl_02 with dissolve
    mc "*Do I just... blow into it or what?*"

    if affinity_spectrum > 0:
        mc "*Wow... I sound like a virgin who's never sucked dick before.*"

    $renpy.sound.play("audio/sfx/bad_flute.ogg", loop=False)
    scene e3f1-fl_03 with dissolve
    pause

    scene e3f1-fl_02 with dissolve
    mc "*Alright...*"

    scene e3f1-fl_04 with dissolve
    mc "*I'm assuming these little air spaces are for simulating notes, right?*"
    mc "*If only I'd knew which notes I'm playing...*"

    $renpy.sound.play("audio/sfx/bad_flute.ogg", loop=False)
    scene e3f1-fl_03 with dissolve
    pause

    $ e3f1_flute = True
    $ e3f1_instrument += 1
    $ music_skills += 1

    if e3f1_instrument > 1:
        if "Try out a couple of instruments." in current_quests:
            $ current_quests.remove("Try out a couple of instruments.")
        if not "Try out all instruments." in optional_quests:
            $ optional_quests.append("Try out all instruments.")

    if e3f1_instrument == 4:
        $ optional_quests.remove("Try out all instruments.")
        $ music_skills += 1

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    scene e3f1-fl_02 with dissolve
    mc "*Yeah... alright.*"
    mc "*Enough with this one.*"

    jump e3f1_left_shelf
return

# Right shelf ###
label e3f1_right_shelf:
    scene e3f1-06
    call screen e3f1_right_shelf with dissolve
return

label e3f1_djembe:
    scene e3f1-dj_01 with dissolve
    mc "*Alright let's try this bongo drum.*"
    mc "*Or whatever is it called.*"

    scene e3f1-dj_02 with dissolve
    mc "*Why didn't they make this taller?*"
    mc "*It would have made it easier to play standing up.*"
    mc "*I mean, at a concert is the player sitting down?*"
    mc "*Isn't that a bit rude?*"
    mc "*But at the same time, a piano player would also sit down to play it.*"
    mc "*Yeah, great points there [mc], very nice.*"
    mc "*Insult their culture.*"
    mc "*Okay, enough talk, I almost forgot what I'm here for.*"
    mc "*So... do I tap it lightly or hard?*"
    mc "*How does it work?*"
    mc "*Only one way to find out...*"

    menu:
        "Tap it lightly":
            call introvert_affinity_check from _call_introvert_affinity_check_51
            call color_check from _call_color_check_114
            mc "*Let's be gentle.*"

            $renpy.sound.play("audio/sfx/tap_djembe.ogg", loop=False)
            scene e3f1-dj_03 with dissolve
            pause

            scene e3f1-dj_02 with dissolve
            mc "*Oh, that's cute.*"
            mc "*Almost like in a jungle.*"

            $renpy.sound.play("audio/sfx/tap_djembe.ogg", loop=False)
            scene e3f1-dj_03 with dissolve
            pause

            scene e3f1-dj_02 with dissolve
            mc "*It's pretty nice, not gonna lie.*"
            mc "*I'm a bit unsure of its uses in a rock band but hey...*"
            mc "*If they can make it work then I'm happy!*"

        "Tap it hard":
            call extrovert_affinity_check from _call_extrovert_affinity_check_59
            call color_check from _call_color_check_115
            mc "*Let's get this show on the road!*"

            scene e3f1-dj_04 with dissolve
            pause

            $renpy.sound.play("audio/sfx/slap_djembe.ogg", loop=False)
            scene e3f1-dj_03 with vpunch
            pause

            scene e3f1-dj_02 with dissolve
            mc "*Oh God...*"
            mc "*Hope I didn't break it, did I?*"

            if e3f1_option == 5:
                scene e3f1-dj_05 with dissolve
                mc "*Hopefully [pe] didn't hear it.*"
                mc "*Although, it would have been pretty hard not to hear it.*"

                scene e3f1-dj_02 with dissolve

            mc "*Yeah... I don't know about this one.*"
            mc "*Might have to leave it alone for now.*"

    $ e3f1_djembe = True
    $ e3f1_instrument += 1
    $ music_skills += 1

    if e3f1_instrument > 1:
        if "Try out a couple of instruments." in current_quests:
            $ current_quests.remove("Try out a couple of instruments.")
        if not "Try out all instruments." in optional_quests:
            $ optional_quests.append("Try out all instruments.")

    if e3f1_instrument == 4:
        $ optional_quests.remove("Try out all instruments.")
        $ music_skills += 1

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    scene e3f1-06 with dissolve

    jump e3f1_right_shelf
return

# Piano ###
label e3f1_piano:
    scene e3f1-07
    call screen e3f1_piano with dissolve
return

label e3f1_keyboard:
    scene e3f1-pi_01 with dissolve
    mc "*Let's see this one...*"
    mc "*At least this one I've seen before.*"
    mc "*But that doesn't mean that I know a single thing about it.*"

    scene e3f1-pi_02 with dissolve
    mc "*I'm guessing I just need to press these keys, right?*"

    scene e3f1-pi_04 with dissolve
    pause

    scene e3f1-pi_02 with dissolve
    mc "*Does it... do anything?*"
    mc "*Do I need to press harder?*"

    scene e3f1-pi_04 with dissolve
    pause

    scene e3f1-pi_05 with dissolve
    pause

    scene e3f1-pi_02 with dissolve
    mc "*Maybe this one's broken, let's try the other keys.*"

    scene e3f1-pi_03 with dissolve
    pause

    $ e3f1_keyboard = True
    $ e3f1_instrument += 1
    $ music_skills += 1

    if e3f1_instrument > 1:
        if "Try out a couple of instruments." in current_quests:
            $ current_quests.remove("Try out a couple of instruments.")
        if not "Try out all instruments." in optional_quests:
            $ optional_quests.append("Try out all instruments.")

    if e3f1_instrument == 4:
        $ optional_quests.remove("Try out all instruments.")
        $ music_skills += 1

    if e3f1_explore == 2 and e3f1_instrument > 1:
        if not "Open the front door." in current_quests:
            $ current_quests.append("Open the front door.")

    scene e3f1-pi_02 with dissolve
    mc "*Maybe it has to be connected somewhere.*"
    mc "*Yeah.. I don't wanna break it.*"
    mc "*I'm gonna leave it alone.*"

    jump e3f1_piano
return
