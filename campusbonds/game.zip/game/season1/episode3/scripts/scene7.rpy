
# Scene 7 - A “reformed” president #############################################

label e3s7:
    play music invisible_light
    scene e3s7-01 with wipeleft
    pause

    play sound door_close
    scene e3s7-02 with dissolve
    pause

    scene e3s7-03 with dissolve
    mc "Sup [nt]!"

    scene e3s7-04 with dissolve
    nt "Hi [mc]."

    scene e3s7-05 with dissolve
    mc "What are you working on?"

    scene e3s7-06 with dissolve
    nt "Just some college assignments."
    nt "What's up with you?"

    scene e3s7-07 with dissolve
    mc "Well, [jon] told me there's a party tonight."

    scene e3s7-08 with dissolve
    mc "You should come."

    scene e3s7-09 with dissolve
    nt "Damn, that guy never sleeps does he?"

    scene e3s7-08 with dissolve
    mc "Haha, nope."

    scene e3s7-10 with dissolve
    nt "Sure, I'll come."

    scene e3s7-09 with dissolve
    nt "Just need to get these things done."

    scene e3s7-08 with dissolve
    mc "Alright, I'm gonna get changed and then I'm gonna be on my way."
    mc "I guess you know where the old cafeteria is, right?"

    scene e3s7-09 with dissolve
    nt "Yeah, I do."

    stop music fadeout 2.0
    scene e3s7-11 with dissolve
    mc "Great, see you there!"

    scene e3s7-12 with dissolve

    scene e3s7-29 with wipeleft
    pause

    $renpy.sound.play("audio/sfx/crowded_venue.ogg", loop=True)
    scene e3s7-30 with dissolve
    pause

    scene e3s7-31 with dissolve
    play music all_around_you
    pause

    scene e3s7-13 with dissolve
    stop sound fadeout 4.0
    kv "We have all gathered here to talk about this college."

    scene e3s7-14 with dissolve
    kv "Which, from my understanding and everyone else's..."

    scene e3s7-15 with dissolve
    kv "is not in its best shape."

    scene e3s7-16 with dissolve
    kv "I know, the last president left the place in a crumbling state."

    scene e3s7-17 with dissolve
    kv "And it hasn't been easy since then."

    scene e3s7-18 with dissolve
    kv "But I, come with a proposal."
    kv "A change which would benefit everyone around here."

    scene e3s7-19 with dissolve
    kv "I deserve it, the students deserve it, everyone deserves it."

    scene e3s7-13 with dissolve
    kv "So, as the students' president, I promise to give you back what you have lost."

    scene e3s7-19 with dissolve
    kv "I know my attributes, I know my duties."

    scene e3s7-16 with dissolve
    kv "I also know that some clubs have overstepped and are not in our control anymore."

    scene e3s7-18 with dissolve
    kv "But don't you worry, the first thing I will do as president is to regain control over them."

    scene e3s7-19 with dissolve
    kv "Thank you everyone!"
    kv "It was a pleasure."

    play sound clapping
    scene e3s7-20 with dissolve
    pause

    scene e3s7-21 with dissolve
    pause

    scene e3s7-22 with dissolve
    mc "*This guy is going for the students' presidency?*"
    mc "*Maybe that's why they attacked me last night.*"
    mc "*They think I'm a threat to their operation or something.*"
    mc "*Now I really have to tell [jon] about it.*"

    stop music fadeout 2.0
    scene e3s7-23 with dissolve
    pause

    scene e3s7-24 with dissolve
    pause

    scene e3s7-25 with dissolve
    cl "Hey [mc], are you alright?"
    cl "You look like you've seen a ghost."

    scene e3s7-26 with dissolve
    mc "I'm sorry [cl], I have to go."
    mc "I can't talk right now."

    scene e3s7-27 with dissolve
    pause

    stop music fadeout 2.0
    scene e3s7-28 with dissolve
    cl "Ookay...?"

    jump e3s8
return
