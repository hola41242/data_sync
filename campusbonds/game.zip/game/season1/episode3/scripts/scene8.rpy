
# Scene 8 - Party ragers PARTY #################################################

label e3s8:
    play music dance_tonight
    scene e3s8-01 with wipeleft
    pause

    scene e3s8-02 with dissolve
    pause

    scene e3s8-03 with dissolve
    jon "Hey guys!!"
    jon "Look who's here, our dear friend [mc]!"

    scene e3s8-04 with dissolve
    mc "Hi guys!"

    scene e3s8-05 with dissolve
    mc "[jon], can I talk to you for a second?"

    scene e3s8-06 with dissolve
    jon "Come on bro, we're at a party!"

    scene e3s8-07 with dissolve
    jon "Let's leave the worries aside and enjoy the moment."

    scene e3s8-08 with dissolve
    show e3s8_jon_blink1
    mc "But it's really urgent."

    scene e3s8-09 with dissolve
    hide e3s8_jon_blink1
    jon "[mc], there's nothing that urgent that can't wait an extra couple of hours."

    scene e3s8-10 with dissolve
    jon "Come on, don't be a mood breaker, just enjoy the party we've put on."

    scene e3s8-07 with dissolve
    jon "I don't wanna hear any bad news."
    jon "Anyways, did you get what I asked you to get?"

    scene e3s8-08 with dissolve
    show e3s8_jon_blink1
    mc "Yeah, I did."

    scene e3s8-10 with dissolve
    hide e3s8_jon_blink1
    jon "Awesome! Thanks a lot."

    scene e3s8-08 with dissolve
    show e3s8_jon_blink1
    mc "You're welcome."
    mc "Also, the change you told me to keep?"
    mc "There wasn't any."

    scene e3s8-07 with dissolve
    hide e3s8_jon_blink1
    jon "So I gave you the perfect amount?"
    jon "Perfect!"

    if money > 0:
        $ money -= 1

    scene e3s8-08 with dissolve
    show e3s8_jon_blink1
    mc "No, actually you owe me-"

    scene e3s8-11 with dissolve
    hide e3s8_jon_blink1
    jon "Do you wanna get a drink?"
    jon "We've got a lot of different drinks from different brands, just name it!"

    scene e3s8-08 with dissolve
    show e3s8_jon_blink1
    mc "Alright, just one beer."
    mc "But nothing more!"

    scene e3s8-12 with wipeleft
    hide e3s8_jon_blink1
    pause

    play music aux_intro_cut
    scene e3s8-13 with vpunch
    jd "HELL YEAH!"

    scene e3s8-14 with dissolve
    pause

    scene e3s8-15 with dissolve
    jon "I call this... the HELL SHOT!"

    scene e3s8-16 with dissolve
    ro "Why is it called the hell shot?"

    scene e3s8-17 with dissolve
    ke "Ah, fuck! Oh my God, it burns!"

    scene e3s8-18 with dissolve
    jd "That's why!"

    scene e3s8-19 with dissolve
    ro "Here, have some beer!"
    ke "Gghhgh..."

    scene e3s8-20 with dissolve
    pause

    scene e3s8-21 with dissolve
    mc "Haha!"

    scene e3s8-22 with dissolve
    jd "What are you laughing at?"

    scene e3s8-23 with dissolve
    jd "Drink, hell boy!"
    mc "Gghhgh..."

    scene e3s8-26 with dissolve
    pause

    scene e3s8-24 with dissolve
    pause

    scene e3s8-27 with dissolve
    pause

    scene e3s8-25 with dissolve
    pause

    scene e3s8-28 with dissolve
    pause

    scene e3s8-14 with dissolve
    pause

    scene e3s8-29 with dissolve
    pause

    scene e3s8-30 with dissolve
    mc "Alright, alright, guys."
    mc "I'm gonna go and see what other people I can meet."

    scene e3s8-31 with dissolve
    jon "Don't get lost my guy."

    call e3f3 from _call_e3f3

    scene e3s8-32 with wipeleft
    play music the_darker_side
    mc "*What the hell was that?*"
    mc "*How could [jd] do something like this?*"
    mc "*Can I even trust anyone right now?*"

    if affinity_spectrum > 0:
        if tiffany_trust > 0 or e2s10_lap_dance > 0:
            scene e3s8-33 with dissolve
            mc "*I need to cool off.*"

            scene e3s8-34 with dissolve
            menu:
                "Call [tf]" if affinity_spectrum > 0 and tiffany_trust > 0 and e2f2_tiffany_refuse == False:

                    mc "*Maybe I can call Tiffany.*"

                    menu:
                        "Really call [tf]":
                            $ e3s8_tiffany_hangout = True

                            scene e3s8-37 with dissolve
                            mc "*Let's see if she picks up.*"
                            tf "[mc]?"

                            scene e3s8-38 with dissolve
                            mc "Hey [tf]!"

                            scene e3s8-39 with dissolve
                            mc "I was wondering if you'd like to hang out and maybe watch a movie?"

                            scene e3s8-40 with dissolve
                            tf "Hey, as much as I'd like that, isn't it a little late?"
                            tf "It's 10 PM."

                            scene e3s8-41 with dissolve
                            mc "So what?"
                            mc "I won't take much of your time."

                            scene e3s8-42 with dissolve
                            tf "Alrighty [mc]."
                            tf "My dorm or yours?"

                            scene e3s8-43 with dissolve
                            mc "Whatever works for you."

                            scene e3s8-44 with dissolve
                            tf "Alright then, I'll be waiting you at mine."
                            tf "I'll text you the address."

                            scene e3s8-45 with dissolve
                            mc "Great, see you there!"

                            scene e3s8-46 with dissolve
                            pause

                            jump e3s9

                        "Don't call her":

                            scene e3s8-35 with dissolve
                            mc "*...*"

                            scene e3s8-36 with dissolve
                            mc "*Not like this.*"

                "[ca]" if e2s10_lap_dance > 0 and candance_trust > 0:
                    $ e3s8_candance = True

                    mc "*Maybe I can go to the club.*"
                    mc "*Meet [ca] there for a release.*"

                    scene e3s8-46 with dissolve
                    pause

                    jump e3s9

                "Nobody":

                    scene e3s8-36 with dissolve
                    mc "*Fuck it, I'm going home.*"
                    mc "*I've had enough of everyone for the night.*"
    else:
        scene e3s8-33 with dissolve
        mc "*Fuck it, I'm going home.*"
        mc "*I've had enough of everyone for the night.*"

    scene e3s8-46 with dissolve
    pause

    jump e3s10
return
