
# Scene 0 - Spencer flashback ##################################################

label e3s0:

    $ renpy.block_rollback()
    $ config.rollback_enabled = False

    hide screen recap_skip

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    $ config.rollback_enabled = True

    scene e3s0-02 with Dissolve(2.0)
    play music odesa
    pause

    scene e3s0-03 with dissolve
    pause

    scene e3s0-04 with dissolve
    pause

    scene e3s0-05 with dissolve
    pause

    scene e3s0-06 with dissolve
    pause

    scene e3s0-07 with dissolve
    pause

    scene e3s0-01 with dissolve
    pause

    scene e3s0-08 with dissolve
    pause
    unknown "Ey, Junior!"

    scene e3s0-09 with dissolve
    pause

    scene e3s0-10 with dissolve
    unknown "Fetch me a beer, would you?"

    scene e3s0-12 with dissolve
    ju "Yes."

    scene e3s0-11 with dissolve
    unknown "Yes what?"

    scene e3s0-12 with dissolve
    ju "Yes sir."

    scene e3s0-10 with dissolve
    unknown "That's my boy."

    scene e3s0-13 with dissolve
    pause

    scene e3s0-14 with dissolve
    pause

    scene e3s0-15 with dissolve
    pause

    scene e3s0-16 with dissolve
    pause

    scene e3s0-17 with dissolve
    pause

    scene e3s0-18 with dissolve
    pause

    scene e3s0-19 with dissolve
    unknown "I didn't say you could leave."

    scene e3s0-20 with dissolve
    pause

    scene e3s0-21 with dissolve
    ju "I'm sorry..."

    scene e3s0-22 with vpunch
    unknown "WHAT DID I TELL YOU?"
    unknown "IT'S SIR!"

    scene e3s0-23 with dissolve
    ju "I'm sorry sir..."

    scene e3s0-24 with dissolve
    unknown "You need to be disciplined."

    scene e3s0-25 with dissolve
    unknown "I've been away for too long, that woman forgot how to take care of her child."

    scene e3s0-23 with dissolve
    ju "No Dad, please!"

    scene e3s0-26 with vpunch
    unknown "Stop calling me that you piece of shit!"

    scene e3s0-27 with dissolve
    pause

    scene e3s0-28 with dissolve
    unknown "You're just a filth in this world, a disease."

    scene e3s0-29 with dissolve
    unknown "You were a mistake, your mother's mistake."

    scene e3s0-30 with dissolve
    unknown "I will not be punished for her mistakes."

    scene e3s0-31 with dissolve
    unknown "But you will."

    scene e3s0-32 with dissolve
    ju "No, please!"

    scene e3s0-33 with dissolve
    pause

    jump e3s1
return
