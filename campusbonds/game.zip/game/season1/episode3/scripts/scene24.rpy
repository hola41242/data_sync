
# Scene 24 - A helping hand ####################################################

label e3s24:
    scene e3s24-125 with wipeleft
    pause

    if e3s22_guitar == False:
        scene e3s24-126 with dissolve
        pause
    else:
        scene e3s24-127 with dissolve
        pause

    scene e3s24-128 with dissolve
    pause

    scene e3s24-129 with dissolve
    pause

    scene e3s24-130 with dissolve
    pause

    if e3s10_cleo_hangout == True and cleo_trust > 2 and e3s21_mad == False:
        if e3s22_guitar == False:
            scene e3s24-70 with dissolve
            pause

            play sound knock_knock
            scene e3s24-71 with dissolve
            pause

            scene e3s24-73 with dissolve
            mc "*Huh?*"
        else:
            scene e3s24-24 with dissolve
            pause

            play sound knock_knock
            scene e3s24-71 with dissolve
            pause

            scene e3s24-75 with dissolve
            mc "*Huh?*"

        scene e3s24-72 with dissolve
        pause

        scene e3s24-74 with dissolve
        pause

        scene e3s24-76 with dissolve
        mc "*Meet me at the riverside lake, 11 PM, I will tell you everything. xoxo [cl].*"
        mc "*Oh...*"
        menu:
            "Meet her":
                $ cleo_trust += 1
                $ e3s24_cleo_path = True

                scene e3s24-77 with dissolve
                mc "*Alright, I'll go and meet her in 2 hours.*"

                scene e3s24-79 with dissolve
                pause

            "Let it go":
                $ cleo_trust -= 1
                mc "*I'm sorry [cl], I think this is as far as we go.*"

                scene e3s24-78 with dissolve
                pause
    if e3s22_guitar == False:
        scene e3s24-70 with dissolve
        pause

        play sound knock_knock
        scene e3s24-71 with dissolve
        pause

        scene e3s24-80 with dissolve
        play music serenity
        fr "Hey [mc]!"
        fr "May I come in?"

        scene e3s24-81 with dissolve
        mc "[fr]!"
        mc "Sure."

        scene e3s24-29 with dissolve
        mc "What are you doing here?"

        scene e3s24-82 with dissolve
        fr "Oh, well... you know."
        fr "I was just passing by."

        scene e3s24-36 with dissolve
        fr "Are you still mad after the last session?"

        scene e3s24-83 with dissolve
        mc "I mean, not really."

        scene e3s24-84 with dissolve
        fr "I see."

        scene e3s24-85 with dissolve
        fr "Hey, I managed to get your phone back!"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Really?"
        mc "That's awesome [fr], thanks!"

        scene e3s24-86 with dissolve
        hide e3s24_francesca_blink1
        fr "Also, I talked to [ev] about this situation."

        scene e3s24-37 with dissolve
        fr "She's gonna cut you some slack from now on."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Great!"

        scene e3s24-86 with dissolve
        hide e3s24_francesca_blink1
        fr "...with the proviso that you stay away from her."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Haha, how am I supposed to do that?"
        mc "She's the librarian after all."

        scene e3s24-87 with dissolve
        hide e3s24_francesca_blink1
        fr "Haha, no, not in that sense."

        scene e3s24-37 with dissolve
        fr "Just... don't get into trouble again, alright?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Sure, duly noted."
        mc "Oh, also, I should charge my phone."
        mc "It's most likely out of juice."

        mc "Hey, by the way, what's up with [ev] and college rock?"

        scene e3s24-33 with dissolve
        hide e3s24_francesca_blink1
        fr "What do you mean?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Like, is she some sort of mentor or what's up with her?"
        mc "Why is she there?"

        scene e3s24-37 with dissolve
        hide e3s24_francesca_blink1
        fr "Every group is required to have at least one professor."

        scene e3s24-33 with dissolve
        fr "She's kind of the president here."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "President?"

        scene e3s24-37 with dissolve
        hide e3s24_francesca_blink1
        fr "Yeah, she pretty much makes the important calls."
        fr "She named me vice president."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "You're the vice president?"

        scene e3s24-87 with dissolve
        hide e3s24_francesca_blink1
        fr "Haha, yeah!"

        scene e3s24-86 with dissolve
        fr "When she's not around I'm the one in charge."

        scene e3s24-37 with dissolve
        fr "A bit like running a country if you like."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "But [jon]'s club for example isn't being run by any professors."

        scene e3s24-33 with dissolve
        hide e3s24_francesca_blink1
        fr "Yeah, if a club isn't on campus grounds that could be the case."
        fr "It's out of their control."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Oh, that explains it."
        mc "Don't you find it a bit weird?"

        scene e3s24-33 with dissolve
        hide e3s24_francesca_blink1
        fr "Weird how?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "I mean, we're all adults here, right?"
        mc "Why would we need a supervisor?"

        scene e3s24-37 with dissolve
        hide e3s24_francesca_blink1
        fr "If you're planning on starting a group on campus grounds it's their choice to do whatever they want."
        fr "It's their space after all."

        scene e3s24-86 with dissolve
        fr "And I bet they'd want these clubs to be at the very least productive."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "I guess that makes sense."
        mc "Also, how are you this good at playing the guitar?"

        scene e3s24-84 with dissolve
        hide e3s24_francesca_blink1
        fr "Well, I've been playing it since I was a child."

        scene e3s24-86 with dissolve
        fr "Being a dancing star also involved musicals and stuff like that."

        scene e3s24-87 with dissolve
        fr "You have no idea how much I begged my father to buy me a guitar, haha!"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Haha, I see!"
        mc "Does he know that you're still playing it?"

        scene e3s24-36 with dissolve
        hide e3s24_francesca_blink1
        fr "He knows that I'm playing it in my free time."

        scene e3s24-37 with dissolve
        fr "He doesn't know that I'm playing in a full-on group."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Would he be against it?"

        scene e3s24-84 with dissolve
        hide e3s24_francesca_blink1
        fr "He would say that it's a distraction and that I have to set my priorities right."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "That sucks!"

        scene e3s24-37 with dissolve
        hide e3s24_francesca_blink1
        fr "I know, but what can you do?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "How does it feel?"
        mc "To have to hide from your father with things you like?"

        scene e3s24-84 with dissolve
        hide e3s24_francesca_blink1
        fr "It doesn't feel good but I've gotten used to it."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "I understand."

        scene e3s24-88 with dissolve
        hide e3s24_francesca_blink1
        pause
    else:
        scene e3s24-24 with dissolve
        pause

        play sound knock_knock
        scene e3s24-25 with dissolve
        pause

        scene e3s24-26 with dissolve
        pause

        scene e3s24-27 with dissolve
        play music serenity
        fr "Hey [mc]!"
        fr "May I come in?"

        scene e3s24-28 with dissolve
        mc "[fr]!"
        mc "Sure."

        scene e3s24-29 with dissolve
        mc "What are you doing here?"

        scene e3s24-30 with dissolve
        fr "Oh, well... you know."
        fr "I was just passing by."
        fr "And I heard a really good singer."

        scene e3s24-31 with dissolve
        mc "Yeah... I was just practicing."

        scene e3s24-32 with dissolve
        fr "I see!"

        scene e3s24-33 with dissolve
        fr "Where did you get the guitar?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "One of my friends said they have a guitar that they don't use."

        scene e3s24-35 with dissolve
        hide e3s24_francesca_blink1
        mc "So, they lent it to me."

        scene e3s24-36 with dissolve
        fr "Are you still mad after the last session?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "I mean, not really."
        mc "I'm trying to get used to this guitar."

        scene e3s24-35 with dissolve
        hide e3s24_francesca_blink1
        mc "I'm approaching it with an open mind now."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Plus I think it's sort of calming when you don't have to follow a certain structure."

        scene e3s24-84 with dissolve
        hide e3s24_francesca_blink1
        fr "I see."

        scene e3s24-85 with dissolve
        fr "Hey, I managed to get your phone back!"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Really?"
        mc "That's awesome [fr], thanks!"

        scene e3s24-86 with dissolve
        hide e3s24_francesca_blink1
        fr "Also, I talked to [ev] about this situation."

        scene e3s24-37 with dissolve
        fr "She's gonna cut you some slack from now on."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Great!"

        scene e3s24-86 with dissolve
        hide e3s24_francesca_blink1
        fr "...with the proviso that you stay away from her."

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Haha, how am I supposed to do that?"
        mc "She's the librarian after all."

        scene e3s24-87 with dissolve
        hide e3s24_francesca_blink1
        fr "Haha, no, not in that sense."

        scene e3s24-37 with dissolve
        fr "Just... don't get into trouble again, alright?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Sure, duly noted."

        scene e3s24-86 with dissolve
        hide e3s24_francesca_blink1
        fr "So, would you like my help with the guitar?"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        if affinity_spectrum > 0:
            mc "Is it really that bad?"

            scene e3s24-87 with dissolve
            hide e3s24_francesca_blink1
            fr "Haha, no!"

            scene e3s24-86 with dissolve
            fr "Though I might be able to help you with some harder notes."

            scene e3s24-34 with dissolve
            show e3s24_francesca_blink1

        mc "Sure, if you can make it work."

        scene e3s24-37 with dissolve
        hide e3s24_francesca_blink1
        fr "Alright!"

        scene e3s24-34 with dissolve
        show e3s24_francesca_blink1
        mc "Wait, let me plug in my phone first."

        scene e3s24-38 with dissolve
        hide e3s24_francesca_blink1
        pause

        scene e3s24-39 with dissolve
        pause

        if affinity_spectrum > 0:
            scene e3s24-40 with dissolve
            mc "Is this part of the help?"

            scene e3s24-41 with dissolve
            fr "Haha, shut up!"

        scene e3s24-42 with dissolve
        fr "Here, I'm going to push your hands onto the right notes."

        scene e3s24-45 with dissolve
        fr "Let's sing a song."

        scene e3s24-43 with dissolve
        mc "Hey, by the way, what's up with [ev] and college rock?"

        scene e3s24-45 with dissolve
        fr "What do you mean?"

        scene e3s24-43 with dissolve
        mc "Like, is she some sort of mentor or what's up with her?"
        mc "Why is she there?"

        scene e3s24-44 with dissolve
        fr "Every group is required to have at least one professor."

        scene e3s24-45 with dissolve
        fr "She's kind of the president here."

        scene e3s24-48 with dissolve
        mc "President?"

        scene e3s24-44 with dissolve
        fr "Yeah, she pretty much makes the important calls."
        fr "She named me vice president."

        scene e3s24-40 with dissolve
        mc "You're the vice president?"

        scene e3s24-41 with dissolve
        fr "Haha, yeah!"

        scene e3s24-44 with dissolve
        fr "When she's not around I'm the one in charge."

        scene e3s24-45 with dissolve
        fr "A bit like running a country if you like."

        scene e3s24-43 with dissolve
        mc "But [jon]'s club for example isn't being run by any professors."

        scene e3s24-44 with dissolve
        fr "Yeah, if a club isn't on campus grounds that could be the case."
        fr "It's out of their control."

        scene e3s24-43 with dissolve
        mc "Oh, that explains it."

        scene e3s24-47 with dissolve
        mc "Don't you find it a bit weird?"

        scene e3s24-41 with dissolve
        fr "Weird how?"

        scene e3s24-46 with dissolve
        mc "I mean, we're all adults here, right?"
        mc "Why would we need a supervisor?"

        scene e3s24-44 with dissolve
        fr "If you're planning on starting a group on campus grounds it's their choice to do whatever they want."
        fr "It's their space after all."

        scene e3s24-45 with dissolve
        fr "And I bet they'd want these clubs to be at the very least productive."

        scene e3s24-43 with dissolve
        mc "I guess that makes sense."

        scene e3s24-47 with dissolve
        mc "Also, how are you this good at playing the guitar?"

        scene e3s24-44 with dissolve
        fr "Well, I've been playing it since I was a child."
        fr "Being a dancing star also involved musicals and stuff like that."

        scene e3s24-45 with dissolve
        fr "You have no idea how much I begged my father to buy me a guitar, haha!"

        scene e3s24-46 with dissolve
        mc "Haha, I see!"
        mc "Does he know that you're still playing it?"

        scene e3s24-45 with dissolve
        fr "He knows that I'm playing it in my free time."
        fr "He doesn't know that I'm playing in a full-on group."

        scene e3s24-48 with dissolve
        mc "Would he be against it?"

        scene e3s24-44 with dissolve
        fr "He would say that it's a distraction and that I have to set my priorities right."

        scene e3s24-48 with dissolve
        mc "That sucks..."

        scene e3s24-44 with dissolve
        fr "I know, but what can you do?"

        scene e3s24-48 with dissolve
        mc "How does it feel?"
        mc "To have to hide from your father with things you like?"

        scene e3s24-44 with dissolve
        fr "It doesn't feel good but I've gotten used to it."

        scene e3s24-43 with dissolve
        mc "I understand."

        scene e3s24-01 with dissolve
        pause

    if affinity_spectrum < 0 and francesca_trust > 2:
        menu:
            "Kiss her":
                $ francesca_trust += 1
                $ e3s24_francesca_lewd = True

                call e3s24_lewd from _call_e3s24_lewd

            "Don't kiss her":
                pass

    if e3s24_francesca_lewd == False:
        if e3s22_guitar == False:
            scene e3s24-56 with dissolve
            fr "Oh, shit [mc]!"
            fr "Look at the time."

            scene e3s24-55 with dissolve
            fr "My dad's probably looking for me."

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Shit!"

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "I'm really sorry for leaving like this."

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Don't worry [fr], I understand."

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "Thank you a lot!"

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Wait, how are you gonna get home?"
            mc "Do you want me to come with you?"

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "No, don't worry [mc]."

            scene e3s24-56 with dissolve
            fr "I'm gonna get a cab."
            fr "Plus if my dad sees you again he will start asking questions."

            scene e3s24-57 with dissolve
            mc "Alright, alright."

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Be safe, okay?"

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "I will."
            fr "Take care [mc], bye!"

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Bye!"
        else:
            scene e3s24-49 with dissolve
            pause

            scene e3s24-50 with dissolve
            pause

            scene e3s24-51 with dissolve
            fr "Oh, shit [mc]..."
            fr "Look at the time."
            fr "My dad's probably looking for me."

            scene e3s24-52 with dissolve
            mc "Shit!"

            scene e3s24-53 with dissolve
            fr "I'm really sorry for leaving like this."

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Don't worry [fr], I understand."

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "Thank you a lot!"

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Wait, how are you gonna get home?"
            mc "Do you want me to come with you?"

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "No, don't worry [mc]."

            scene e3s24-56 with dissolve
            fr "I'm gonna get a cab."
            fr "Plus if my dad sees you again he will start asking questions."

            scene e3s24-57 with dissolve
            mc "Alright, alright."

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Be safe, okay?"

            scene e3s24-55 with dissolve
            hide e3s24_francesca_blink2
            fr "I will."
            fr "Take care [mc], bye!"

            scene e3s24-54 with dissolve
            show e3s24_francesca_blink2
            mc "Bye!"

    scene e3s24-58 with dissolve
    hide e3s24_francesca_blink2
    pause

    scene e3s24-59 with dissolve
    pause

    scene e3s24-60 with vpunch
    pause

    scene e3s24-61 with dissolve
    pause

    if e3s22_guitar == False:
        scene e3s24-123 with dissolve
        nt "Damn... what'd you do to her bro?"

        scene e3s24-131 with dissolve
        mc "Haha, nothing."
        mc "She just had to hurry back home."

        scene e3s24-124 with dissolve
        nt "Are you sure...?"
        nt "She seemed creeped out."

        scene e3s24-81 with dissolve
        mc "As I said, she was hurrying back home."

        scene e3s24-66 with dissolve
        nt "Alright."

        scene e3s24-70 with dissolve
        pause
    else:
        scene e3s24-62 with dissolve
        nt "Damn... what'd you do to her bro?"

        scene e3s24-63 with dissolve
        mc "Haha, nothing."
        mc "She just had to hurry back home."

        scene e3s24-64 with dissolve
        nt "Are you sure...?"
        nt "She seemed creeped out."

        scene e3s24-65 with dissolve
        mc "As I said, she was hurrying back home."

        scene e3s24-66 with dissolve
        nt "Alright."

        scene e3s24-67 with dissolve
        mc "Hey, I'm gonna practice a bit on my guitar."
        mc "Hope you don't mind it."

        scene e3s24-68 with dissolve
        nt "Nah, go ahead."
        nt "I'm gonna do some assignments in the meantime."

        scene e3s24-67 with dissolve
        mc "Okay!"

        scene e3s24-69 with dissolve
        pause

    if e3s24_cleo_path == True:
        jump e3s25
    else:
        if e3s9_intervene == True:
            jump e3s26
        else:
            jump e3s27
return

label e3s24_lewd:
    stop music fadeout 2.0
    scene e3s24-02 with dissolve
    play music hollow_grove
    pause

    scene e3s24-03 with dissolve
    pause

    scene e3s24-04 with dissolve
    pause

    scene e3s24-kiss1 with dissolve
    pause

    scene e3s24-05 with dissolve
    pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e3s24-06 with dissolve
        pause

        scene e3s24-07 with dissolve
        pause

        scene e3s24-08 with dissolve
        pause

        scene e3s24-09 with dissolve
        pause

        scene e3s24-10 with vpunch
        pause

        scene e3s24-11 with dissolve
        pause

        scene e3s24-12 with dissolve
        fr "[mc], wait!"

        scene e3s24-13 with dissolve
        mc "Huh?"
        mc "What's wrong?"

        scene e3s24-12 with dissolve
        fr "I can't do this..."

        if persistent.disable_nsfw == True:
            scene e3s24-14 with dissolve
            mc "Why not?"

            scene e3s24-15 with dissolve
            fr "I haven't... done this before..."

            scene e3s24-16 with dissolve
            mc "Oh..."

            scene e3s24-17 with dissolve
            fr "And... I don't think I'm ready for it right now..."

            scene e3s24-18 with dissolve
            fr "I'm sorry for coming at you like that and kissing you and giving you hope."

            scene e3s24-15 with dissolve
            fr "I thought I was ready."

            scene e3s24-19 with dissolve
            mc "Hey, [fr]!"
            mc "It's okay, don't worry."
            mc "I understand you."

            scene e3s24-18 with dissolve
            fr "We could do something else if that's okay!"

            scene e3s24-16 with dissolve
            mc "Whatever you're comfortable with."

            scene e3s24-20 with dissolve
            fr "Thank you [mc]!"
            fr "I'm really grateful to have you."

            scene e3s24-21 with dissolve
            mc "You're welcome [fr]."
            mc "I'll be here for you."

            scene e3s24-22 with dissolve
            pause

            scene e3s24-23 with dissolve
            mc "So, what do you have in mind?"

            scene e3s24-20 with dissolve
            fr "We could... play with each other."
            fr "Find out what we like."
            fr "I think it will make it more enjoyable when we actually do it."

            scene e3s24-21 with dissolve
            mc "Alright."

            scene e3s24-89 with dissolve
            pause

            scene e3s24-90 with dissolve
            pause

            scene e3s24-91 with dissolve
            mc "Here... I'm going to remove your panties."

            scene e3s24-92 with dissolve
            fr "Ah..."

            # Finger
            scene e3s24-93 with dissolve
            mc "I'm going to start massaging your clit slowly."

            scene e3s24-finger1 with dissolve
            fr "Ah, [mc]!"

            scene e3s24-95 with dissolve
            fr "This feels... really good!"

            scene e3s24-finger2 with dissolve
            fr "It's so sensitive."
            fr "Don't go too fa-ast...!"

            scene e3s24-finger3 with dissolve
            pause

            scene e3s24-96 with dissolve
            pause

            scene e3s24-97 with dissolve
            pause

            scene e3s24-98 with dissolve
            mc "Damn [fr]..."

            scene e3s24-99 with dissolve
            mc "Ah...!"

            scene e3s24-handjob1 with dissolve
            fr "Am I doing this right?"

            scene e3s24-handjob2 with dissolve
            mc "Yeah, you're doing great!"
            mc "Keep going."

            scene e3s24-handjob1 with dissolve
            fr "This is so hot."
            mc "Here, let me have a taste."
            fr "What do you mean?"

            scene e3s24-titsuck1 with dissolve
            fr "Oh... wow!"
            fr "Ah... it feels good!"

            scene e3s24-titsuck2 with dissolve
            fr "Ahh oh my God!"

            scene e3s24-titsuck1 with dissolve
            pause

            scene e3s24-titsuck2 with dissolve
            pause

            scene e3s24-101 with dissolve
            mc "I'm going to insert a finger [fr]."

            scene e3s24-102 with dissolve
            fr "Oh my God..."

            scene e3s24-94 with dissolve
            fr "Ah..."

            scene e3s24-finger4 with dissolve
            fr "Yes [mc], right there!"

            scene e3s24-finger5 with dissolve
            fr "It feels so good."

            scene e3s24-finger6 with dissolve
            pause

            scene e3s24-finger4 with dissolve
            fr "Oh God..."
            fr "Please go on!"

            scene e3s24-finger7 with dissolve
            mc "You're so wet [fr]!"
            fr "Oh yeah..."
            mc "Is this what I think it is?"
            fr "Keep going [mc] please!"
            mc "*She is about to cum.*"
            fr "Oh my God!!"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)

            scene e3s24-92 with dissolve
            fr "Fuck..."

            scene e3s24-102 with dissolve
            fr "Look at the mess we made!"

            scene e3s24-101 with dissolve
            mc "You're so beautiful Francesca."

            scene e3s24-103 with dissolve
            fr "Oh [mc]..."

            scene e3s24-100 with dissolve
            pause

            scene e3s24-99 with dissolve
            fr "Now... let's see what we're gonna do about this bad boy here."
            mc "Your power's back huh?"

            scene e3s24-105 with dissolve
            fr "Shut up!"

            scene e3s24-102 with dissolve
            fr "Lie back, I have an idea."

            scene e3s24-104 with dissolve
            mc "Wow, careful [fr]!"
            fr "Don't worry [mc]."
            fr "It's not gonna slip in."

            # Handjob
            scene e3s24-handjob3 with dissolve
            mc "Ah, that feels really good [fr]!"
            mc "Keep going."

            scene e3s24-handjob4 with dissolve
            fr "I'm glad you like it [mc]."
            fr "Tell me if I'm being too rough, alright?"
            mc "Yeah."

            scene e3s24-handjob3 with dissolve
            mc "Ah..."

            scene e3s24-handjob5 with dissolve
            pause

            scene e3s24-handjob4 with dissolve
            mc "Ah... oh my God [fr]."

            scene e3s24-handjob3 with dissolve
            mc "That feels so good!"

            scene e3s24-handjob5 with dissolve
            pause

            scene e3s24-handjob4 with dissolve
            mc "[fr]... I'm getting close."
            fr "Oh... uhh..."
            fr "What am I supposed to do?"
            mc "Nothing, just keep going!"
            fr "Oh, alright!"
            mc "Ah... there's not much left."
            mc "It's coming [fr]!"
            mc "I'm cumming!"

            scene e3s24-106 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)

            scene e3s24-107 with dissolve
            fr "Damn..."
            mc "That was really good [fr]!"
            mc "Thank you."
            fr "This is a bit of a weird feeling, haha!"
            fr "How it's pulsating as the semen is coming out."
            fr "I've been wondering how it would feel to hold one in my hand."
            mc "Well... now you know!"

            scene e3s24-108 with dissolve
            pause

            scene e3s24-109 with dissolve
            mc "That felt amazing [fr]."

            scene e3s24-110 with dissolve
            fr "It was good for me too."

            scene e3s24-111 with dissolve
            mc "Just good?"

            scene e3s24-112 with dissolve
            mc "I remember you rolling your eyes in pleasure back there."

            scene e3s24-113 with dissolve
            fr "Okay, I was not rolling my eyes in pleasure."

            scene e3s24-114 with dissolve
            fr "But yeah... it was amazing."

            scene e3s24-115 with dissolve
            fr "I was just messing with you."

            scene e3s24-116 with dissolve
            fr "Oh, shit [mc]!"
            fr "The time!"
            fr "My dad's probably looking for me."

            scene e3s24-117 with dissolve
            mc "Shit!"

            scene e3s24-118 with dissolve
            fr "I'm really sorry for leaving like this."

            scene e3s24-119 with dissolve
            mc "Don't worry [fr], I understand."

            scene e3s24-120 with dissolve
            fr "Thank you a lot!"
        else:
            if persistent.type_nsfw == False:
                scene e3s24-14_cen with dissolve
                mc "Why not?"

                scene e3s24-15_cen with dissolve
                fr "I haven't... done this before..."

                scene e3s24-16_cen with dissolve
                mc "Oh..."

                scene e3s24-17_cen with dissolve
                fr "And... I don't think I'm ready for it right now..."

                scene e3s24-18_cen with dissolve
                fr "I'm sorry for coming at you like that and kissing you and giving you hope."

                scene e3s24-15_cen with dissolve
                fr "I thought I was ready."

                scene e3s24-19_cen with dissolve
                mc "Hey, [fr]!"
                mc "It's okay, don't worry."
                mc "I understand you."

                scene e3s24-18_cen with dissolve
                fr "We could do something else if that's okay!"

                scene e3s24-16_cen with dissolve
                mc "Whatever you're comfortable with."

                scene e3s24-20_cen with dissolve
                fr "Thank you [mc]!"
                fr "I'm really grateful to have you."

                scene e3s24-21_cen with dissolve
                mc "You're welcome [fr]."
                mc "I'll be here for you."

                scene e3s24-22_cen with dissolve
                pause

                scene e3s24-23_cen with dissolve
                mc "So, what do you have in mind?"

                scene e3s24-20_cen with dissolve
                fr "We could... play with each other."
                fr "Find out what we like."
                fr "I think it will make it more enjoyable when we actually do it."

                scene e3s24-21_cen with dissolve
                mc "Alright."

                scene e3s24-89_cen with dissolve
                pause

                scene e3s24-90_cen with dissolve
                pause

                scene e3s24-91 with dissolve
                mc "Here... I'm going to remove your panties."

                scene e3s24-92_cen with dissolve
                fr "Ah..."

                # Finger
                scene e3s24-93_cen with dissolve
                mc "I'm going to start massaging your clit slowly."

                scene e3s24-finger1_cen with dissolve
                fr "Ah, [mc]!"

                scene e3s24-95 with dissolve
                fr "This feels... really good!"

                scene e3s24-finger2_cen with dissolve
                fr "It's so sensitive."
                fr "Don't go too fa-ast...!"

                scene e3s24-finger3_cen with dissolve
                pause

                scene e3s24-96 with dissolve
                pause

                scene e3s24-97 with dissolve
                pause

                scene e3s24-98_cen with dissolve
                mc "Damn [fr]..."

                scene e3s24-99_cen with dissolve
                mc "Ah...!"

                scene e3s24-handjob1_cen with dissolve
                fr "Am I doing this right?"

                scene e3s24-handjob2_cen with dissolve
                mc "Yeah, you're doing great!"
                mc "Keep going."

                scene e3s24-handjob1_cen with dissolve
                fr "This is so hot."
                mc "Here, let me have a taste."
                fr "What do you mean?"

                scene e3s24-titsuck1_cen with dissolve
                fr "Oh... wow!"
                fr "Ah... it feels good!"

                scene e3s24-titsuck2_cen with dissolve
                fr "Ahh oh my God!"

                scene e3s24-titsuck1_cen with dissolve
                pause

                scene e3s24-titsuck2_cen with dissolve
                pause

                scene e3s24-101_cen with dissolve
                mc "I'm going to insert a finger [fr]."

                scene e3s24-102_cen with dissolve
                fr "Oh my God..."

                scene e3s24-94_cen with dissolve
                fr "Ah..."

                scene e3s24-finger4_cen with dissolve
                fr "Yes [mc], right there!"

                scene e3s24-finger5_cen with dissolve
                fr "It feels so good."

                scene e3s24-finger6_cen with dissolve
                pause

                scene e3s24-finger4_cen with dissolve
                fr "Oh God..."
                fr "Please go on!"

                scene e3s24-finger7_cen with dissolve
                mc "You're so wet [fr]!"
                fr "Oh yeah..."
                mc "Is this what I think it is?"
                fr "Keep going [mc] please!"
                mc "*She is about to cum.*"
                fr "Oh my God!!"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)

                scene e3s24-92_cen with dissolve
                fr "Fuck..."

                scene e3s24-102_cen with dissolve
                fr "Look at the mess we made!"

                scene e3s24-101_cen with dissolve
                mc "You're so beautiful Francesca."

                scene e3s24-103_cen with dissolve
                fr "Oh [mc]..."

                scene e3s24-100_cen with dissolve
                pause

                scene e3s24-99_cen with dissolve
                fr "Now... let's see what we're gonna do about this bad boy here."
                mc "Your power's back huh?"

                scene e3s24-105_cen with dissolve
                fr "Shut up!"

                scene e3s24-102_cen with dissolve
                fr "Lie back, I have an idea."

                scene e3s24-104_cen with dissolve
                mc "Wow, careful [fr]!"
                fr "Don't worry [mc]."
                fr "It's not gonna slip in."

                # Handjob
                scene e3s24-handjob3_cen with dissolve
                mc "Ah, that feels really good [fr]!"
                mc "Keep going."

                scene e3s24-handjob4_cen with dissolve
                fr "I'm glad you like it [mc]."
                fr "Tell me if I'm being too rough, alright?"
                mc "Yeah."

                scene e3s24-handjob3_cen with dissolve
                mc "Ah."

                scene e3s24-handjob5_cen with dissolve
                pause

                scene e3s24-handjob4_cen with dissolve
                mc "Ah... oh my God [fr]."

                scene e3s24-handjob3_cen with dissolve
                mc "That feels so good!"

                scene e3s24-handjob5_cen with dissolve
                pause

                scene e3s24-handjob4_cen with dissolve
                mc "[fr]... I'm getting close."
                fr "Oh... uhh..."
                fr "What am I supposed to do?"
                mc "Nothing, just keep going!"
                fr "Oh, alright!"
                mc "Ah... there's not much left."
                mc "It's coming [fr]!"
                mc "I'm cumming!"

                scene e3s24-106_cen with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)

                scene e3s24-107_cen with dissolve
                fr "Damn..."
                mc "That was really good [fr]!"
                mc "Thank you."
                fr "This is a bit of a weird feeling, haha!"
                fr "How it's pulsating as the semen is coming out."
                fr "I've been wondering how it would feel to hold one in my hand."
                mc "Well... now you know!"

                scene e3s24-108_cen with dissolve
                pause

                scene e3s24-109 with dissolve
                mc "That felt amazing [fr]."

                scene e3s24-110 with dissolve
                fr "It was good for me too."

                scene e3s24-111 with dissolve
                mc "Just good?"

                scene e3s24-112_cen with dissolve
                mc "I remember you rolling your eyes in pleasure back there."

                scene e3s24-113 with dissolve
                fr "Okay, I was not rolling my eyes in pleasure."

                scene e3s24-114 with dissolve
                fr "But yeah... it was amazing."

                scene e3s24-115 with dissolve
                fr "I was just messing with you."

                scene e3s24-116 with dissolve
                fr "Oh, shit [mc]!"
                fr "The time!"
                fr "My dad's probably looking for me."

                scene e3s24-117_cen with dissolve
                mc "Shit!"

                scene e3s24-118_cen with dissolve
                fr "I'm really sorry for leaving like this."

                scene e3s24-119_cen with dissolve
                mc "Don't worry [fr], I understand."

                scene e3s24-120_cen with dissolve
                fr "Thank you a lot!"

        scene e3s24-121 with dissolve
        mc "Wait, how are you gonna get home?"
        mc "Do you want me to come with you?"

        scene e3s24-122 with dissolve
        fr "No, don't worry [mc]."
        fr "I'm gonna get a cab."
        fr "Plus if my dad sees you again he will start asking questions."

        scene e3s24-121 with dissolve
        mc "Alright, alright."
        mc "Be safe, okay?"

        scene e3s24-122 with dissolve
        fr "I will."
        fr "Take care [mc], bye!"

        scene e3s24-121 with dissolve
        mc "Bye!"
return
