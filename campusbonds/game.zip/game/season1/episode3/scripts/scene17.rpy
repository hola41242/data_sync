
# Scene 17 - Library days (Part 2) #############################################

label e3s17:
    scene e3s17-01 with wipeleft
    play music liar
    pause

    scene e3s17-02 with dissolve
    mc "*Can't believe I'm doing this for the second time.*"
    mc "*Alright, I should just respect the initial plan.*"
    mc "*In and out.*"
    mc "*I can't let her catch me under any circumstances.*"

    if e3s11_photo == True or e3s11_toy == True or e3s11_bin == True or e3s11_pb == True:
        mc "*This time... I'm not gonna waste any second on distractions.*"

    scene e3s17-03 with dissolve
    pause

    if e3s11_phone_left == False or e3s11_phone_right == False:
        scene e3s17-04 with dissolve
        mc "*Alright, last time everything was in the media drawer.*"

    scene e3s17-05 with dissolve
    pause

    stop music
    $renpy.sound.play("audio/sfx/heart_beat.ogg", loop=True)
    scene e3s17-06 with dissolve
    mc "*Wait... they're not here!*"
    stop sound
    ev "Looking for something?"

    scene e3s17-07 with dissolve
    mc "*SHIT!*"

    scene e3s17-08 with dissolve
    pause

    scene e3s17-09 with dissolve
    play music onfire
    mc "Uhh... hi... [ev]..."
    mc "I see you've got my phone there."

    scene e3s17-12 with dissolve
    ev "I can't believe this!"

    scene e3s17-10 with dissolve
    ev "After we just talked, you go and search through my stuff again?"

    scene e3s17-13 with dissolve
    ev "I should have you expelled for it."

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "Look... I'm sorry..."
    mc "I was just looking for my phone."

    scene e3s17-12 with dissolve
    hide e3s17_evelyn_blink1
    ev "No... I don't even wanna hear it."

    scene e3s17-13 with dissolve
    ev "You're out of college rock."

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "What?"
    mc "Come on, you can't do that to me."

    scene e3s17-14 with dissolve
    hide e3s17_evelyn_blink1
    ev "Oh, yes I can!"

    scene e3s17-15 with dissolve
    ev "And this? You're never gonna see it again."

    scene e3s17-16 with dissolve
    ev "So, better start saving up for a new one."

    scene e3s17-13 with dissolve
    ev "Because you're not getting it back."

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "You can't be serious."

    scene e3s17-13 with dissolve
    hide e3s17_evelyn_blink1
    ev "What part of 'you're never gonna see it again' don't you get?"

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "Why do you have to be such a hard ass?"

    scene e3s17-17 with dissolve
    hide e3s17_evelyn_blink1
    ev "Excuse me?"

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "You heard me."
    mc "I wouldn't have had to sneak in here in the first place if it wasn't for you giving me a hard time."

    scene e3s17-13 with dissolve
    hide e3s17_evelyn_blink1
    ev "Do I have to remind you of how it all began?"

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    mc "Yeah, maybe [sd] was stupid for doing what she did."
    mc "But why won't you just give me my phone back and we can move on from this?"
    mc "I had nothing to do with you girls, what's between you is between you."
    mc "If I knew all the facts beforehand I probably wouldn't have done it."

    if sadie_trust > 5:
        mc "But because I care for [sd] I did it anyway."
        mc "Shame on me, what can I say?"

        if affinity_spectrum > 0:
            mc "Boo fucking hoo!"
    else:
        mc "But what can I do now?"

    scene e3s17-13 with dissolve
    hide e3s17_evelyn_blink1
    ev "You've gotta learn that actions have consequences!"

    scene e3s17-16 with dissolve
    ev "What you did is unacceptable, I will not tolerate this kind of behaviour."
    ev "This college doesn't need any more rebels."

    scene e3s17-11 with dissolve
    show e3s17_evelyn_blink1
    menu:
        "Push it":
            call extrovert_affinity_check from _call_extrovert_affinity_check_52
            call color_check from _call_color_check_99
            $ evelyn_trust += 1

            stop music
            scene e3s17-18 with vpunch
            hide e3s17_evelyn_blink1
            mc "How long are you gonna abuse this power?"

            scene e3s17-19 with dissolve
            mc "Are you really that power hungry?"
            mc "You wanna be in control of absolutely anything?"
            mc "..."

            scene e3s17-20 with dissolve
            ev "..."

            scene e3s17-21 with dissolve
            ev "I... I have to go."

            scene e3s17-22 with dissolve
            ev "Stay away from college rock!"
        "Back down":
            call introvert_affinity_check from _call_introvert_affinity_check_44
            call color_check from _call_color_check_100
            mc "..."

            scene e3s17-17 with dissolve
            hide e3s17_evelyn_blink1
            ev "So, are we clear?"

            scene e3s17-11 with dissolve
            mc "I guess..."

            scene e3s17-13 with dissolve
            ev "Good!"

    scene e3s17-23 with dissolve
    menu:
        "Check her out":
            scene e3s17-24 with dissolve
            pause

        "Don't check her out":
            pass

    stop music fadeout 2.0
    scene e3s17-25 with dissolve
    mc "*What am I even gonna do about it now...*"

    jump e3s18
return
