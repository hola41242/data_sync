
# Scene 5 images ###############################################################

image e3s5-01 = im.Scale("season1/episode3/images/scene5/1.webp", 1920, 1080)
image e3s5-02 = im.Scale("season1/episode3/images/scene5/2.webp", 1920, 1080)
image e3s5-03 = im.Scale("season1/episode3/images/scene5/3.webp", 1920, 1080)
image e3s5-04 = im.Scale("season1/episode3/images/scene5/4.webp", 1920, 1080)
image e3s5-05 = im.Scale("season1/episode3/images/scene5/5.webp", 1920, 1080)
image e3s5-06 = im.Scale("season1/episode3/images/scene5/6.webp", 1920, 1080)
image e3s5-07 = im.Scale("season1/episode3/images/scene5/7.webp", 1920, 1080)
image e3s5-08 = im.Scale("season1/episode3/images/scene5/8.webp", 1920, 1080)
image e3s5-09 = im.Scale("season1/episode3/images/scene5/9.webp", 1920, 1080)
image e3s5-10 = im.Scale("season1/episode3/images/scene5/10.webp", 1920, 1080)
image e3s5-11 = im.Scale("season1/episode3/images/scene5/11.webp", 1920, 1080)
image e3s5-12 = im.Scale("season1/episode3/images/scene5/12.webp", 1920, 1080)
image e3s5-13 = im.Scale("season1/episode3/images/scene5/13.webp", 1920, 1080)
image e3s5-14 = im.Scale("season1/episode3/images/scene5/14.webp", 1920, 1080)
image e3s5-15 = im.Scale("season1/episode3/images/scene5/15.webp", 1920, 1080)
image e3s5-16 = im.Scale("season1/episode3/images/scene5/16.webp", 1920, 1080)
image e3s5-17 = im.Scale("season1/episode3/images/scene5/17.webp", 1920, 1080)
image e3s5-18 = im.Scale("season1/episode3/images/scene5/18.webp", 1920, 1080)

image e3s5_francesca_blink1:
    im.Scale("season1/episode3/images/scene5/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene5/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
