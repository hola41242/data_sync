
# Scene 24 images ##############################################################

# Images
image e3s24-01 = im.Scale("season1/episode3/images/scene24/1.webp", 1920, 1080)
image e3s24-02 = im.Scale("season1/episode3/images/scene24/2.webp", 1920, 1080)
image e3s24-03 = im.Scale("season1/episode3/images/scene24/3.webp", 1920, 1080)
image e3s24-04 = im.Scale("season1/episode3/images/scene24/4.webp", 1920, 1080)
image e3s24-05 = im.Scale("season1/episode3/images/scene24/5.webp", 1920, 1080)
image e3s24-06 = im.Scale("season1/episode3/images/scene24/6.webp", 1920, 1080)
image e3s24-07 = im.Scale("season1/episode3/images/scene24/7.webp", 1920, 1080)
image e3s24-08 = im.Scale("season1/episode3/images/scene24/8.webp", 1920, 1080)
image e3s24-09 = im.Scale("season1/episode3/images/scene24/9.webp", 1920, 1080)
image e3s24-10 = im.Scale("season1/episode3/images/scene24/10.webp", 1920, 1080)
image e3s24-11 = im.Scale("season1/episode3/images/scene24/11.webp", 1920, 1080)
image e3s24-12 = im.Scale("season1/episode3/images/scene24/12.webp", 1920, 1080)
image e3s24-13 = im.Scale("season1/episode3/images/scene24/13.webp", 1920, 1080)
image e3s24-14 = im.Scale("season1/episode3/images/scene24/14.webp", 1920, 1080)
image e3s24-15 = im.Scale("season1/episode3/images/scene24/15.webp", 1920, 1080)
image e3s24-16 = im.Scale("season1/episode3/images/scene24/16.webp", 1920, 1080)
image e3s24-17 = im.Scale("season1/episode3/images/scene24/17.webp", 1920, 1080)
image e3s24-18 = im.Scale("season1/episode3/images/scene24/18.webp", 1920, 1080)
image e3s24-19 = im.Scale("season1/episode3/images/scene24/19.webp", 1920, 1080)
image e3s24-20 = im.Scale("season1/episode3/images/scene24/20.webp", 1920, 1080)
image e3s24-21 = im.Scale("season1/episode3/images/scene24/21.webp", 1920, 1080)
image e3s24-22 = im.Scale("season1/episode3/images/scene24/22.webp", 1920, 1080)
image e3s24-23 = im.Scale("season1/episode3/images/scene24/23.webp", 1920, 1080)
image e3s24-24 = im.Scale("season1/episode3/images/scene24/24.webp", 1920, 1080)
image e3s24-25 = im.Scale("season1/episode3/images/scene24/25.webp", 1920, 1080)
image e3s24-26 = im.Scale("season1/episode3/images/scene24/26.webp", 1920, 1080)
image e3s24-27 = im.Scale("season1/episode3/images/scene24/27.webp", 1920, 1080)
image e3s24-28 = im.Scale("season1/episode3/images/scene24/28.webp", 1920, 1080)
image e3s24-29 = im.Scale("season1/episode3/images/scene24/29.webp", 1920, 1080)
image e3s24-30 = im.Scale("season1/episode3/images/scene24/30.webp", 1920, 1080)
image e3s24-31 = im.Scale("season1/episode3/images/scene24/31.webp", 1920, 1080)
image e3s24-32 = im.Scale("season1/episode3/images/scene24/32.webp", 1920, 1080)
image e3s24-33 = im.Scale("season1/episode3/images/scene24/33.webp", 1920, 1080)
image e3s24-34 = im.Scale("season1/episode3/images/scene24/34.webp", 1920, 1080)
image e3s24-35 = im.Scale("season1/episode3/images/scene24/35.webp", 1920, 1080)
image e3s24-36 = im.Scale("season1/episode3/images/scene24/36.webp", 1920, 1080)
image e3s24-37 = im.Scale("season1/episode3/images/scene24/37.webp", 1920, 1080)
image e3s24-38 = im.Scale("season1/episode3/images/scene24/38.webp", 1920, 1080)
image e3s24-39 = im.Scale("season1/episode3/images/scene24/39.webp", 1920, 1080)
image e3s24-40 = im.Scale("season1/episode3/images/scene24/40.webp", 1920, 1080)
image e3s24-41 = im.Scale("season1/episode3/images/scene24/41.webp", 1920, 1080)
image e3s24-42 = im.Scale("season1/episode3/images/scene24/42.webp", 1920, 1080)
image e3s24-43 = im.Scale("season1/episode3/images/scene24/43.webp", 1920, 1080)
image e3s24-44 = im.Scale("season1/episode3/images/scene24/44.webp", 1920, 1080)
image e3s24-45 = im.Scale("season1/episode3/images/scene24/45.webp", 1920, 1080)
image e3s24-46 = im.Scale("season1/episode3/images/scene24/46.webp", 1920, 1080)
image e3s24-47 = im.Scale("season1/episode3/images/scene24/47.webp", 1920, 1080)
image e3s24-48 = im.Scale("season1/episode3/images/scene24/48.webp", 1920, 1080)
image e3s24-49 = im.Scale("season1/episode3/images/scene24/49.webp", 1920, 1080)
image e3s24-50 = im.Scale("season1/episode3/images/scene24/50.webp", 1920, 1080)
image e3s24-51 = im.Scale("season1/episode3/images/scene24/51.webp", 1920, 1080)
image e3s24-52 = im.Scale("season1/episode3/images/scene24/52.webp", 1920, 1080)
image e3s24-53 = im.Scale("season1/episode3/images/scene24/53.webp", 1920, 1080)
image e3s24-54 = im.Scale("season1/episode3/images/scene24/54.webp", 1920, 1080)
image e3s24-55 = im.Scale("season1/episode3/images/scene24/55.webp", 1920, 1080)
image e3s24-56 = im.Scale("season1/episode3/images/scene24/56.webp", 1920, 1080)
image e3s24-57 = im.Scale("season1/episode3/images/scene24/57.webp", 1920, 1080)
image e3s24-58 = im.Scale("season1/episode3/images/scene24/58.webp", 1920, 1080)
image e3s24-59 = im.Scale("season1/episode3/images/scene24/59.webp", 1920, 1080)
image e3s24-60 = im.Scale("season1/episode3/images/scene24/60.webp", 1920, 1080)
image e3s24-61 = im.Scale("season1/episode3/images/scene24/61.webp", 1920, 1080)
image e3s24-62 = im.Scale("season1/episode3/images/scene24/62.webp", 1920, 1080)
image e3s24-63 = im.Scale("season1/episode3/images/scene24/63.webp", 1920, 1080)
image e3s24-64 = im.Scale("season1/episode3/images/scene24/64.webp", 1920, 1080)
image e3s24-65 = im.Scale("season1/episode3/images/scene24/65.webp", 1920, 1080)
image e3s24-66 = im.Scale("season1/episode3/images/scene24/66.webp", 1920, 1080)
image e3s24-67 = im.Scale("season1/episode3/images/scene24/67.webp", 1920, 1080)
image e3s24-68 = im.Scale("season1/episode3/images/scene24/68.webp", 1920, 1080)
image e3s24-69 = im.Scale("season1/episode3/images/scene24/69.webp", 1920, 1080)
image e3s24-70 = im.Scale("season1/episode3/images/scene24/70.webp", 1920, 1080)
image e3s24-71 = im.Scale("season1/episode3/images/scene24/71.webp", 1920, 1080)
image e3s24-72 = im.Scale("season1/episode3/images/scene24/72.webp", 1920, 1080)
image e3s24-73 = im.Scale("season1/episode3/images/scene24/73.webp", 1920, 1080)
image e3s24-74 = im.Scale("season1/episode3/images/scene24/74.webp", 1920, 1080)
image e3s24-75 = im.Scale("season1/episode3/images/scene24/75.webp", 1920, 1080)
image e3s24-76 = im.Scale("season1/episode3/images/scene24/76.webp", 1920, 1080)
image e3s24-77 = im.Scale("season1/episode3/images/scene24/77.webp", 1920, 1080)
image e3s24-78 = im.Scale("season1/episode3/images/scene24/78.webp", 1920, 1080)
image e3s24-79 = im.Scale("season1/episode3/images/scene24/79.webp", 1920, 1080)
image e3s24-80 = im.Scale("season1/episode3/images/scene24/80.webp", 1920, 1080)
image e3s24-81 = im.Scale("season1/episode3/images/scene24/81.webp", 1920, 1080)
image e3s24-82 = im.Scale("season1/episode3/images/scene24/82.webp", 1920, 1080)
image e3s24-83 = im.Scale("season1/episode3/images/scene24/83.webp", 1920, 1080)
image e3s24-84 = im.Scale("season1/episode3/images/scene24/84.webp", 1920, 1080)
image e3s24-85 = im.Scale("season1/episode3/images/scene24/85.webp", 1920, 1080)
image e3s24-86 = im.Scale("season1/episode3/images/scene24/86.webp", 1920, 1080)
image e3s24-87 = im.Scale("season1/episode3/images/scene24/87.webp", 1920, 1080)
image e3s24-88 = im.Scale("season1/episode3/images/scene24/88.webp", 1920, 1080)
image e3s24-89 = im.Scale("season1/episode3/images/scene24/89.webp", 1920, 1080)
image e3s24-90 = im.Scale("season1/episode3/images/scene24/90.webp", 1920, 1080)
image e3s24-91 = im.Scale("season1/episode3/images/scene24/91.webp", 1920, 1080)
image e3s24-92 = im.Scale("season1/episode3/images/scene24/92.webp", 1920, 1080)
image e3s24-93 = im.Scale("season1/episode3/images/scene24/93.webp", 1920, 1080)
image e3s24-94 = im.Scale("season1/episode3/images/scene24/94.webp", 1920, 1080)
image e3s24-95 = im.Scale("season1/episode3/images/scene24/95.webp", 1920, 1080)
image e3s24-96 = im.Scale("season1/episode3/images/scene24/96.webp", 1920, 1080)
image e3s24-97 = im.Scale("season1/episode3/images/scene24/97.webp", 1920, 1080)
image e3s24-98 = im.Scale("season1/episode3/images/scene24/98.webp", 1920, 1080)
image e3s24-99 = im.Scale("season1/episode3/images/scene24/99.webp", 1920, 1080)
image e3s24-100 = im.Scale("season1/episode3/images/scene24/100.webp", 1920, 1080)
image e3s24-101 = im.Scale("season1/episode3/images/scene24/101.webp", 1920, 1080)
image e3s24-102 = im.Scale("season1/episode3/images/scene24/102.webp", 1920, 1080)
image e3s24-103 = im.Scale("season1/episode3/images/scene24/103.webp", 1920, 1080)
image e3s24-104 = im.Scale("season1/episode3/images/scene24/104.webp", 1920, 1080)
image e3s24-105 = im.Scale("season1/episode3/images/scene24/105.webp", 1920, 1080)
image e3s24-106 = im.Scale("season1/episode3/images/scene24/106.webp", 1920, 1080)
image e3s24-107 = im.Scale("season1/episode3/images/scene24/107.webp", 1920, 1080)
image e3s24-108 = im.Scale("season1/episode3/images/scene24/108.webp", 1920, 1080)
image e3s24-109 = im.Scale("season1/episode3/images/scene24/109.webp", 1920, 1080)
image e3s24-110 = im.Scale("season1/episode3/images/scene24/110.webp", 1920, 1080)
image e3s24-111 = im.Scale("season1/episode3/images/scene24/111.webp", 1920, 1080)
image e3s24-112 = im.Scale("season1/episode3/images/scene24/112.webp", 1920, 1080)
image e3s24-113 = im.Scale("season1/episode3/images/scene24/113.webp", 1920, 1080)
image e3s24-114 = im.Scale("season1/episode3/images/scene24/114.webp", 1920, 1080)
image e3s24-115 = im.Scale("season1/episode3/images/scene24/115.webp", 1920, 1080)
image e3s24-116 = im.Scale("season1/episode3/images/scene24/116.webp", 1920, 1080)
image e3s24-117 = im.Scale("season1/episode3/images/scene24/117.webp", 1920, 1080)
image e3s24-118 = im.Scale("season1/episode3/images/scene24/118.webp", 1920, 1080)
image e3s24-119 = im.Scale("season1/episode3/images/scene24/119.webp", 1920, 1080)
image e3s24-120 = im.Scale("season1/episode3/images/scene24/120.webp", 1920, 1080)
image e3s24-121 = im.Scale("season1/episode3/images/scene24/121.webp", 1920, 1080)
image e3s24-122 = im.Scale("season1/episode3/images/scene24/122.webp", 1920, 1080)
image e3s24-123 = im.Scale("season1/episode3/images/scene24/123.webp", 1920, 1080)
image e3s24-124 = im.Scale("season1/episode3/images/scene24/124.webp", 1920, 1080)
image e3s24-125 = im.Scale("season1/episode3/images/scene24/125.webp", 1920, 1080)
image e3s24-126 = im.Scale("season1/episode3/images/scene24/126.webp", 1920, 1080)
image e3s24-127 = im.Scale("season1/episode3/images/scene24/127.webp", 1920, 1080)
image e3s24-128 = im.Scale("season1/episode3/images/scene24/128.webp", 1920, 1080)
image e3s24-129 = im.Scale("season1/episode3/images/scene24/129.webp", 1920, 1080)
image e3s24-130 = im.Scale("season1/episode3/images/scene24/130.webp", 1920, 1080)
image e3s24-131 = im.Scale("season1/episode3/images/scene24/131.webp", 1920, 1080)

# Animations #
# Static
image e3s24_francesca_blink1:
    im.Scale("season1/episode3/images/scene24/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s24_francesca_blink2:
    im.Scale("season1/episode3/images/scene24/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene24/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s24-finger1 = Movie(play="season1/episode3/images/scene24/finger1.webm")
image e3s24-finger2 = Movie(play="season1/episode3/images/scene24/finger2.webm")
image e3s24-finger3 = Movie(play="season1/episode3/images/scene24/finger3.webm")
image e3s24-finger4 = Movie(play="season1/episode3/images/scene24/finger4.webm")
image e3s24-finger5 = Movie(play="season1/episode3/images/scene24/finger5.webm")
image e3s24-finger6 = Movie(play="season1/episode3/images/scene24/finger6.webm")
image e3s24-finger7 = Movie(play="season1/episode3/images/scene24/finger7.webm")
image e3s24-handjob1 = Movie(play="season1/episode3/images/scene24/handjob1.webm")
image e3s24-handjob2 = Movie(play="season1/episode3/images/scene24/handjob2.webm")
image e3s24-handjob3 = Movie(play="season1/episode3/images/scene24/handjob3.webm")
image e3s24-handjob4 = Movie(play="season1/episode3/images/scene24/handjob4.webm")
image e3s24-handjob5 = Movie(play="season1/episode3/images/scene24/handjob5.webm")
image e3s24-titsuck1 = Movie(play="season1/episode3/images/scene24/titsuck1.webm")
image e3s24-titsuck2 = Movie(play="season1/episode3/images/scene24/titsuck2.webm")
image e3s24-kiss1 = Movie(play="season1/episode3/images/scene24/kiss1.webm")
image e3s24-kiss2 = Movie(play="season1/episode3/images/scene24/kiss2.webm")

# Censored
# Images
image e3s24-14_cen = im.Scale("season1/episode3/images/scene24/censored/14.webp", 1920, 1080)
image e3s24-15_cen = im.Scale("season1/episode3/images/scene24/censored/15.webp", 1920, 1080)
image e3s24-16_cen = im.Scale("season1/episode3/images/scene24/censored/16.webp", 1920, 1080)
image e3s24-17_cen = im.Scale("season1/episode3/images/scene24/censored/17.webp", 1920, 1080)
image e3s24-18_cen = im.Scale("season1/episode3/images/scene24/censored/18.webp", 1920, 1080)
image e3s24-19_cen = im.Scale("season1/episode3/images/scene24/censored/19.webp", 1920, 1080)
image e3s24-20_cen = im.Scale("season1/episode3/images/scene24/censored/20.webp", 1920, 1080)
image e3s24-21_cen = im.Scale("season1/episode3/images/scene24/censored/21.webp", 1920, 1080)
image e3s24-22_cen = im.Scale("season1/episode3/images/scene24/censored/22.webp", 1920, 1080)
image e3s24-23_cen = im.Scale("season1/episode3/images/scene24/censored/23.webp", 1920, 1080)
image e3s24-89_cen = im.Scale("season1/episode3/images/scene24/censored/89.webp", 1920, 1080)
image e3s24-90_cen = im.Scale("season1/episode3/images/scene24/censored/90.webp", 1920, 1080)
image e3s24-92_cen = im.Scale("season1/episode3/images/scene24/censored/92.webp", 1920, 1080)
image e3s24-93_cen = im.Scale("season1/episode3/images/scene24/censored/93.webp", 1920, 1080)
image e3s24-94_cen = im.Scale("season1/episode3/images/scene24/censored/94.webp", 1920, 1080)
image e3s24-98_cen = im.Scale("season1/episode3/images/scene24/censored/98.webp", 1920, 1080)
image e3s24-99_cen = im.Scale("season1/episode3/images/scene24/censored/99.webp", 1920, 1080)
image e3s24-100_cen = im.Scale("season1/episode3/images/scene24/censored/100.webp", 1920, 1080)
image e3s24-101_cen = im.Scale("season1/episode3/images/scene24/censored/101.webp", 1920, 1080)
image e3s24-102_cen = im.Scale("season1/episode3/images/scene24/censored/102.webp", 1920, 1080)
image e3s24-103_cen = im.Scale("season1/episode3/images/scene24/censored/103.webp", 1920, 1080)
image e3s24-104_cen = im.Scale("season1/episode3/images/scene24/censored/104.webp", 1920, 1080)
image e3s24-105_cen = im.Scale("season1/episode3/images/scene24/censored/105.webp", 1920, 1080)
image e3s24-106_cen = im.Scale("season1/episode3/images/scene24/censored/106.webp", 1920, 1080)
image e3s24-107_cen = im.Scale("season1/episode3/images/scene24/censored/107.webp", 1920, 1080)
image e3s24-108_cen = im.Scale("season1/episode3/images/scene24/censored/108.webp", 1920, 1080)
image e3s24-112_cen = im.Scale("season1/episode3/images/scene24/censored/112.webp", 1920, 1080)
image e3s24-117_cen = im.Scale("season1/episode3/images/scene24/censored/117.webp", 1920, 1080)
image e3s24-118_cen = im.Scale("season1/episode3/images/scene24/censored/118.webp", 1920, 1080)
image e3s24-119_cen = im.Scale("season1/episode3/images/scene24/censored/119.webp", 1920, 1080)
image e3s24-120_cen = im.Scale("season1/episode3/images/scene24/censored/120.webp", 1920, 1080)

# Animations
image e3s24-finger1_cen = Movie(play="season1/episode3/images/scene24/censored/finger1.webm")
image e3s24-finger2_cen = Movie(play="season1/episode3/images/scene24/censored/finger2.webm")
image e3s24-finger3_cen = Movie(play="season1/episode3/images/scene24/censored/finger3.webm")
image e3s24-finger4_cen = Movie(play="season1/episode3/images/scene24/censored/finger4.webm")
image e3s24-finger5_cen = Movie(play="season1/episode3/images/scene24/censored/finger5.webm")
image e3s24-finger6_cen = Movie(play="season1/episode3/images/scene24/censored/finger6.webm")
image e3s24-finger7_cen = Movie(play="season1/episode3/images/scene24/censored/finger7.webm")
image e3s24-handjob1_cen = Movie(play="season1/episode3/images/scene24/censored/handjob1.webm")
image e3s24-handjob2_cen = Movie(play="season1/episode3/images/scene24/censored/handjob2.webm")
image e3s24-handjob3_cen = Movie(play="season1/episode3/images/scene24/censored/handjob3.webm")
image e3s24-handjob4_cen = Movie(play="season1/episode3/images/scene24/censored/handjob4.webm")
image e3s24-handjob5_cen = Movie(play="season1/episode3/images/scene24/censored/handjob5.webm")
image e3s24-titsuck1_cen = Movie(play="season1/episode3/images/scene24/censored/titsuck1.webm")
image e3s24-titsuck2_cen = Movie(play="season1/episode3/images/scene24/censored/titsuck2.webm")
image e3s24-kiss2_cen = Movie(play="season1/episode3/images/scene24/censored/kiss2.webm")
