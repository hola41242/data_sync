
# Scene 17 images ###############################################################

image e3s17-01 = im.Scale("season1/episode3/images/scene17/1.webp", 1920, 1080)
image e3s17-02 = im.Scale("season1/episode3/images/scene17/2.webp", 1920, 1080)
image e3s17-03 = im.Scale("season1/episode3/images/scene17/3.webp", 1920, 1080)
image e3s17-04 = im.Scale("season1/episode3/images/scene17/4.webp", 1920, 1080)
image e3s17-05 = im.Scale("season1/episode3/images/scene17/5.webp", 1920, 1080)
image e3s17-06 = im.Scale("season1/episode3/images/scene17/6.webp", 1920, 1080)
image e3s17-07 = im.Scale("season1/episode3/images/scene17/7.webp", 1920, 1080)
image e3s17-08 = im.Scale("season1/episode3/images/scene17/8.webp", 1920, 1080)
image e3s17-09 = im.Scale("season1/episode3/images/scene17/9.webp", 1920, 1080)
image e3s17-10 = im.Scale("season1/episode3/images/scene17/10.webp", 1920, 1080)
image e3s17-11 = im.Scale("season1/episode3/images/scene17/11.webp", 1920, 1080)
image e3s17-12 = im.Scale("season1/episode3/images/scene17/12.webp", 1920, 1080)
image e3s17-13 = im.Scale("season1/episode3/images/scene17/13.webp", 1920, 1080)
image e3s17-14 = im.Scale("season1/episode3/images/scene17/14.webp", 1920, 1080)
image e3s17-15 = im.Scale("season1/episode3/images/scene17/15.webp", 1920, 1080)
image e3s17-16 = im.Scale("season1/episode3/images/scene17/16.webp", 1920, 1080)
image e3s17-17 = im.Scale("season1/episode3/images/scene17/17.webp", 1920, 1080)
image e3s17-18 = im.Scale("season1/episode3/images/scene17/18.webp", 1920, 1080)
image e3s17-19 = im.Scale("season1/episode3/images/scene17/19.webp", 1920, 1080)
image e3s17-20 = im.Scale("season1/episode3/images/scene17/20.webp", 1920, 1080)
image e3s17-21 = im.Scale("season1/episode3/images/scene17/21.webp", 1920, 1080)
image e3s17-22 = im.Scale("season1/episode3/images/scene17/22.webp", 1920, 1080)
image e3s17-23 = im.Scale("season1/episode3/images/scene17/23.webp", 1920, 1080)
image e3s17-24 = im.Scale("season1/episode3/images/scene17/24.webp", 1920, 1080)
image e3s17-25 = im.Scale("season1/episode3/images/scene17/25.webp", 1920, 1080)

image e3s17_evelyn_blink1:
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene17/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
