
# Freeroam 2 Images ############################################################
# Main
image e3f2-01 = im.Scale("season1/episode3/images/freeroam2/1.webp", 1920, 1080)

# Left
image e3f2-02 = im.Scale("season1/episode3/images/freeroam2/2.webp", 1920, 1080)

# Right
image e3f2-03 = im.Scale("season1/episode3/images/freeroam2/3.webp", 1920, 1080)

# Hallway1
image e3f2-04 = im.Scale("season1/episode3/images/freeroam2/4.webp", 1920, 1080)

# Hallway2
image e3f2-05 = im.Scale("season1/episode3/images/freeroam2/5.webp", 1920, 1080)

# Hallway3
image e3f2-06 = im.Scale("season1/episode3/images/freeroam2/6.webp", 1920, 1080)

# Hallway_left
image e3f2-07 = im.Scale("season1/episode3/images/freeroam2/7.webp", 1920, 1080)

# Hallway_right
image e3f2-08 = im.Scale("season1/episode3/images/freeroam2/8.webp", 1920, 1080)
image e3f2-08_1 = im.Scale("season1/episode3/images/freeroam2/8.1.webp", 1920, 1080)

# Hallway_middle
image e3f2-09 = im.Scale("season1/episode3/images/freeroam2/9.webp", 1920, 1080)


# Ken Jordan
image e3f2-kj_01 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/1.webp", 1920, 1080)
image e3f2-kj_02 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/2.webp", 1920, 1080)
image e3f2-kj_03 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/3.webp", 1920, 1080)
image e3f2-kj_04 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/4.webp", 1920, 1080)
image e3f2-kj_05 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/5.webp", 1920, 1080)
image e3f2-kj_06 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/6.webp", 1920, 1080)
image e3f2-kj_07 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/7.webp", 1920, 1080)
image e3f2-kj_08 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/8.webp", 1920, 1080)
image e3f2-kj_09 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/9.webp", 1920, 1080)
image e3f2-kj_10 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/10.webp", 1920, 1080)
image e3f2-kj_11 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/11.webp", 1920, 1080)
image e3f2-kj_12 = im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/12.webp", 1920, 1080)

image e3f2_ken_blink1:
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam2/images/ken_jordan1/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Strangers
image e3f2-st_01 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/1.webp", 1920, 1080)
image e3f2-st_02 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/2.webp", 1920, 1080)
image e3f2-st_03 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/3.webp", 1920, 1080)
image e3f2-st_04 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/4.webp", 1920, 1080)
image e3f2-st_05 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/5.webp", 1920, 1080)
image e3f2-st_06 = im.Scale("season1/episode3/images/freeroam2/images/strangers1/6.webp", 1920, 1080)

# Censored
image e3f2-st_05_cen = im.Scale("season1/episode3/images/freeroam2/images/strangers1/censored/5.webp", 1920, 1080)
image e3f2-st_06_cen = im.Scale("season1/episode3/images/freeroam2/images/strangers1/censored/6.webp", 1920, 1080)

# Guitar
image e3f2-gu_01 = im.Scale("season1/episode3/images/freeroam2/images/guitar1/1.webp", 1920, 1080)
image e3f2-gu_02 = im.Scale("season1/episode3/images/freeroam2/images/guitar1/2.webp", 1920, 1080)

# Bed
image e3f2-bed_01 = im.Scale("season1/episode3/images/freeroam2/images/3.webp", 1920, 1080)
