
# Scene 30 images ###############################################################

image e3s30-01 = im.Scale("season1/episode3/images/scene30/1.webp", 1920, 1080)
image e3s30-02 = im.Scale("season1/episode3/images/scene30/2.webp", 1920, 1080)
image e3s30-03 = im.Scale("season1/episode3/images/scene30/3.webp", 1920, 1080)
image e3s30-04 = im.Scale("season1/episode3/images/scene30/4.webp", 1920, 1080)
image e3s30-05 = im.Scale("season1/episode3/images/scene30/5.webp", 1920, 1080)
image e3s30-06 = im.Scale("season1/episode3/images/scene30/6.webp", 1920, 1080)
image e3s30-07 = im.Scale("season1/episode3/images/scene30/7.webp", 1920, 1080)
image e3s30-08 = im.Scale("season1/episode3/images/scene30/8.webp", 1920, 1080)
image e3s30-09 = im.Scale("season1/episode3/images/scene30/9.webp", 1920, 1080)
image e3s30-10 = im.Scale("season1/episode3/images/scene30/10.webp", 1920, 1080)
image e3s30-11 = im.Scale("season1/episode3/images/scene30/11.webp", 1920, 1080)
image e3s30-12 = im.Scale("season1/episode3/images/scene30/12.webp", 1920, 1080)
image e3s30-13 = im.Scale("season1/episode3/images/scene30/13.webp", 1920, 1080)
image e3s30-14 = im.Scale("season1/episode3/images/scene30/14.webp", 1920, 1080)
image e3s30-15 = im.Scale("season1/episode3/images/scene30/15.webp", 1920, 1080)
image e3s30-16 = im.Scale("season1/episode3/images/scene30/16.webp", 1920, 1080)
image e3s30-17 = im.Scale("season1/episode3/images/scene30/17.webp", 1920, 1080)
image e3s30-18 = im.Scale("season1/episode3/images/scene30/18.webp", 1920, 1080)
image e3s30-19 = im.Scale("season1/episode3/images/scene30/19.webp", 1920, 1080)
image e3s30-20 = im.Scale("season1/episode3/images/scene30/20.webp", 1920, 1080)
image e3s30-21 = im.Scale("season1/episode3/images/scene30/21.webp", 1920, 1080)
image e3s30-22 = im.Scale("season1/episode3/images/scene30/22.webp", 1920, 1080)
image e3s30-23 = im.Scale("season1/episode3/images/scene30/23.webp", 1920, 1080)
image e3s30-24 = im.Scale("season1/episode3/images/scene30/24.webp", 1920, 1080)
image e3s30-25 = im.Scale("season1/episode3/images/scene30/25.webp", 1920, 1080)
image e3s30-26 = im.Scale("season1/episode3/images/scene30/26.webp", 1920, 1080)
image e3s30-27 = im.Scale("season1/episode3/images/scene30/27.webp", 1920, 1080)
image e3s30-28 = im.Scale("season1/episode3/images/scene30/28.webp", 1920, 1080)
image e3s30-29 = im.Scale("season1/episode3/images/scene30/29.webp", 1920, 1080)
image e3s30-30 = im.Scale("season1/episode3/images/scene30/30.webp", 1920, 1080)
image e3s30-31 = im.Scale("season1/episode3/images/scene30/31.webp", 1920, 1080)

image e3s30_jon_blink1:
    im.Scale("season1/episode3/images/scene30/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene30/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
