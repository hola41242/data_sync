
# Scene 8 images ###############################################################

image e3s8-01 = im.Scale("season1/episode3/images/scene8/1.webp", 1920, 1080)
image e3s8-02 = im.Scale("season1/episode3/images/scene8/2.webp", 1920, 1080)
image e3s8-03 = im.Scale("season1/episode3/images/scene8/3.webp", 1920, 1080)
image e3s8-04 = im.Scale("season1/episode3/images/scene8/4.webp", 1920, 1080)
image e3s8-05 = im.Scale("season1/episode3/images/scene8/5.webp", 1920, 1080)
image e3s8-06 = im.Scale("season1/episode3/images/scene8/6.webp", 1920, 1080)
image e3s8-07 = im.Scale("season1/episode3/images/scene8/7.webp", 1920, 1080)
image e3s8-08 = im.Scale("season1/episode3/images/scene8/8.webp", 1920, 1080)
image e3s8-09 = im.Scale("season1/episode3/images/scene8/9.webp", 1920, 1080)
image e3s8-10 = im.Scale("season1/episode3/images/scene8/10.webp", 1920, 1080)
image e3s8-11 = im.Scale("season1/episode3/images/scene8/11.webp", 1920, 1080)
image e3s8-12 = im.Scale("season1/episode3/images/scene8/12.webp", 1920, 1080)
image e3s8-13 = im.Scale("season1/episode3/images/scene8/13.webp", 1920, 1080)
image e3s8-14 = im.Scale("season1/episode3/images/scene8/14.webp", 1920, 1080)
image e3s8-15 = im.Scale("season1/episode3/images/scene8/15.webp", 1920, 1080)
image e3s8-15 = im.Scale("season1/episode3/images/scene8/15.webp", 1920, 1080)
image e3s8-16 = im.Scale("season1/episode3/images/scene8/16.webp", 1920, 1080)
image e3s8-17 = im.Scale("season1/episode3/images/scene8/17.webp", 1920, 1080)
image e3s8-18 = im.Scale("season1/episode3/images/scene8/18.webp", 1920, 1080)
image e3s8-19 = im.Scale("season1/episode3/images/scene8/19.webp", 1920, 1080)
image e3s8-20 = im.Scale("season1/episode3/images/scene8/20.webp", 1920, 1080)
image e3s8-21 = im.Scale("season1/episode3/images/scene8/21.webp", 1920, 1080)
image e3s8-22 = im.Scale("season1/episode3/images/scene8/22.webp", 1920, 1080)
image e3s8-23 = im.Scale("season1/episode3/images/scene8/23.webp", 1920, 1080)
image e3s8-24 = im.Scale("season1/episode3/images/scene8/24.webp", 1920, 1080)
image e3s8-25 = im.Scale("season1/episode3/images/scene8/25.webp", 1920, 1080)
image e3s8-26 = im.Scale("season1/episode3/images/scene8/26.webp", 1920, 1080)
image e3s8-27 = im.Scale("season1/episode3/images/scene8/27.webp", 1920, 1080)
image e3s8-28 = im.Scale("season1/episode3/images/scene8/28.webp", 1920, 1080)
image e3s8-29 = im.Scale("season1/episode3/images/scene8/29.webp", 1920, 1080)
image e3s8-30 = im.Scale("season1/episode3/images/scene8/30.webp", 1920, 1080)
image e3s8-31 = im.Scale("season1/episode3/images/scene8/31.webp", 1920, 1080)
image e3s8-32 = im.Scale("season1/episode3/images/scene8/32.webp", 1920, 1080)
image e3s8-33 = im.Scale("season1/episode3/images/scene8/33.webp", 1920, 1080)
image e3s8-34 = im.Scale("season1/episode3/images/scene8/34.webp", 1920, 1080)
image e3s8-35 = im.Scale("season1/episode3/images/scene8/35.webp", 1920, 1080)
image e3s8-36 = im.Scale("season1/episode3/images/scene8/36.webp", 1920, 1080)
image e3s8-37 = im.Scale("season1/episode3/images/scene8/37.webp", 1920, 1080)
image e3s8-38 = im.Scale("season1/episode3/images/scene8/38.webp", 1920, 1080)
image e3s8-39 = im.Scale("season1/episode3/images/scene8/39.webp", 1920, 1080)
image e3s8-40 = im.Scale("season1/episode3/images/scene8/40.webp", 1920, 1080)
image e3s8-41 = im.Scale("season1/episode3/images/scene8/41.webp", 1920, 1080)
image e3s8-42 = im.Scale("season1/episode3/images/scene8/42.webp", 1920, 1080)
image e3s8-43 = im.Scale("season1/episode3/images/scene8/43.webp", 1920, 1080)
image e3s8-44 = im.Scale("season1/episode3/images/scene8/44.webp", 1920, 1080)
image e3s8-45 = im.Scale("season1/episode3/images/scene8/45.webp", 1920, 1080)
image e3s8-46 = im.Scale("season1/episode3/images/scene8/46.webp", 1920, 1080)

image e3s8_jon_blink1:
    im.Scale("season1/episode3/images/scene8/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
