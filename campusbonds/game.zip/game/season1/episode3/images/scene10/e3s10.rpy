
# Scene 10 images ###############################################################

image e3s10-01 = im.Scale("season1/episode3/images/scene10/1.webp", 1920, 1080)
image e3s10-02 = im.Scale("season1/episode3/images/scene10/2.webp", 1920, 1080)
image e3s10-03 = im.Scale("season1/episode3/images/scene10/3.webp", 1920, 1080)
image e3s10-04 = im.Scale("season1/episode3/images/scene10/4.webp", 1920, 1080)
image e3s10-05 = im.Scale("season1/episode3/images/scene10/5.webp", 1920, 1080)
image e3s10-06 = im.Scale("season1/episode3/images/scene10/6.webp", 1920, 1080)
image e3s10-07 = im.Scale("season1/episode3/images/scene10/7.webp", 1920, 1080)
image e3s10-08 = im.Scale("season1/episode3/images/scene10/8.webp", 1920, 1080)
image e3s10-09 = im.Scale("season1/episode3/images/scene10/9.webp", 1920, 1080)
image e3s10-10 = im.Scale("season1/episode3/images/scene10/10.webp", 1920, 1080)
image e3s10-11 = im.Scale("season1/episode3/images/scene10/11.webp", 1920, 1080)
image e3s10-12 = im.Scale("season1/episode3/images/scene10/12.webp", 1920, 1080)
image e3s10-13 = im.Scale("season1/episode3/images/scene10/13.webp", 1920, 1080)
image e3s10-14 = im.Scale("season1/episode3/images/scene10/14.webp", 1920, 1080)
image e3s10-15 = im.Scale("season1/episode3/images/scene10/15.webp", 1920, 1080)
image e3s10-16 = im.Scale("season1/episode3/images/scene10/16.webp", 1920, 1080)
image e3s10-17 = im.Scale("season1/episode3/images/scene10/17.webp", 1920, 1080)
image e3s10-18 = im.Scale("season1/episode3/images/scene10/18.webp", 1920, 1080)
image e3s10-19 = im.Scale("season1/episode3/images/scene10/19.webp", 1920, 1080)
image e3s10-20 = im.Scale("season1/episode3/images/scene10/20.webp", 1920, 1080)
image e3s10-21 = im.Scale("season1/episode3/images/scene10/21.webp", 1920, 1080)
image e3s10-22 = im.Scale("season1/episode3/images/scene10/22.webp", 1920, 1080)
image e3s10-23 = im.Scale("season1/episode3/images/scene10/23.webp", 1920, 1080)
image e3s10-24 = im.Scale("season1/episode3/images/scene10/24.webp", 1920, 1080)
image e3s10-25 = im.Scale("season1/episode3/images/scene10/25.webp", 1920, 1080)
image e3s10-26 = im.Scale("season1/episode3/images/scene10/26.webp", 1920, 1080)
image e3s10-27 = im.Scale("season1/episode3/images/scene10/27.webp", 1920, 1080)
image e3s10-28 = im.Scale("season1/episode3/images/scene10/28.webp", 1920, 1080)
image e3s10-29 = im.Scale("season1/episode3/images/scene10/29.webp", 1920, 1080)
image e3s10-30 = im.Scale("season1/episode3/images/scene10/30.webp", 1920, 1080)
image e3s10-31 = im.Scale("season1/episode3/images/scene10/31.webp", 1920, 1080)
image e3s10-32 = im.Scale("season1/episode3/images/scene10/32.webp", 1920, 1080)
image e3s10-33 = im.Scale("season1/episode3/images/scene10/33.webp", 1920, 1080)
image e3s10-34 = im.Scale("season1/episode3/images/scene10/34.webp", 1920, 1080)
image e3s10-35 = im.Scale("season1/episode3/images/scene10/35.webp", 1920, 1080)
image e3s10-36 = im.Scale("season1/episode3/images/scene10/36.webp", 1920, 1080)
image e3s10-37 = im.Scale("season1/episode3/images/scene10/37.webp", 1920, 1080)
image e3s10-38 = im.Scale("season1/episode3/images/scene10/38.webp", 1920, 1080)
image e3s10-39 = im.Scale("season1/episode3/images/scene10/39.webp", 1920, 1080)
image e3s10-40 = im.Scale("season1/episode3/images/scene10/40.webp", 1920, 1080)
image e3s10-41 = im.Scale("season1/episode3/images/scene10/41.webp", 1920, 1080)
image e3s10-42 = im.Scale("season1/episode3/images/scene10/42.webp", 1920, 1080)
image e3s10-43 = im.Scale("season1/episode3/images/scene10/43.webp", 1920, 1080)
image e3s10-44 = im.Scale("season1/episode3/images/scene10/44.webp", 1920, 1080)
image e3s10-45 = im.Scale("season1/episode3/images/scene10/45.webp", 1920, 1080)
image e3s10-46 = im.Scale("season1/episode3/images/scene10/46.webp", 1920, 1080)
image e3s10-47 = im.Scale("season1/episode3/images/scene10/47.webp", 1920, 1080)
image e3s10-48 = im.Scale("season1/episode3/images/scene10/48.webp", 1920, 1080)
image e3s10-49 = im.Scale("season1/episode3/images/scene10/49.webp", 1920, 1080)
image e3s10-50 = im.Scale("season1/episode3/images/scene10/50.webp", 1920, 1080)
image e3s10-51 = im.Scale("season1/episode3/images/scene10/51.webp", 1920, 1080)
image e3s10-52 = im.Scale("season1/episode3/images/scene10/52.webp", 1920, 1080)
image e3s10-53 = im.Scale("season1/episode3/images/scene10/53.webp", 1920, 1080)
image e3s10-54 = im.Scale("season1/episode3/images/scene10/54.webp", 1920, 1080)
image e3s10-55 = im.Scale("season1/episode3/images/scene10/55.webp", 1920, 1080)
image e3s10-56 = im.Scale("season1/episode3/images/scene10/56.webp", 1920, 1080)
image e3s10-57 = im.Scale("season1/episode3/images/scene10/57.webp", 1920, 1080)
image e3s10-58 = im.Scale("season1/episode3/images/scene10/58.webp", 1920, 1080)
image e3s10-59 = im.Scale("season1/episode3/images/scene10/59.webp", 1920, 1080)
image e3s10-60 = im.Scale("season1/episode3/images/scene10/60.webp", 1920, 1080)
image e3s10-61 = im.Scale("season1/episode3/images/scene10/61.webp", 1920, 1080)
image e3s10-62 = im.Scale("season1/episode3/images/scene10/62.webp", 1920, 1080)
image e3s10-63 = im.Scale("season1/episode3/images/scene10/63.webp", 1920, 1080)
image e3s10-64 = im.Scale("season1/episode3/images/scene10/64.webp", 1920, 1080)
image e3s10-65 = im.Scale("season1/episode3/images/scene10/65.webp", 1920, 1080)
image e3s10-66 = im.Scale("season1/episode3/images/scene10/66.webp", 1920, 1080)
image e3s10-67 = im.Scale("season1/episode3/images/scene10/67.webp", 1920, 1080)
image e3s10-68 = im.Scale("season1/episode3/images/scene10/68.webp", 1920, 1080)
image e3s10-69 = im.Scale("season1/episode3/images/scene10/69.webp", 1920, 1080)
image e3s10-70 = im.Scale("season1/episode3/images/scene10/70.webp", 1920, 1080)
image e3s10-71 = im.Scale("season1/episode3/images/scene10/71.webp", 1920, 1080)
image e3s10-72 = im.Scale("season1/episode3/images/scene10/72.webp", 1920, 1080)
image e3s10-73 = im.Scale("season1/episode3/images/scene10/73.webp", 1920, 1080)
image e3s10-74 = im.Scale("season1/episode3/images/scene10/74.webp", 1920, 1080)
image e3s10-75 = im.Scale("season1/episode3/images/scene10/75.webp", 1920, 1080)
image e3s10-76 = im.Scale("season1/episode3/images/scene10/76.webp", 1920, 1080)
image e3s10-77 = im.Scale("season1/episode3/images/scene10/77.webp", 1920, 1080)
image e3s10-78 = im.Scale("season1/episode3/images/scene10/78.webp", 1920, 1080)
image e3s10-79 = im.Scale("season1/episode3/images/scene10/79.webp", 1920, 1080)
image e3s10-80 = im.Scale("season1/episode3/images/scene10/80.webp", 1920, 1080)
image e3s10-81 = im.Scale("season1/episode3/images/scene10/81.webp", 1920, 1080)

image e3s10_cleo_blink1:
    im.Scale("season1/episode3/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s10_cleo_blink2:
    im.Scale("season1/episode3/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s10_francesca_blink1:
    im.Scale("season1/episode3/images/scene10/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s10_francesca_blink2:
    im.Scale("season1/episode3/images/scene10/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s10_sadie_blink1:
    im.Scale("season1/episode3/images/scene10/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s10_sadie_blink2:
    im.Scale("season1/episode3/images/scene10/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene10/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
