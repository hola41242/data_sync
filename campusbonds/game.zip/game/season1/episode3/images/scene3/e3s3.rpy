
# Scene 3 images ###############################################################

image e3s3-01 = im.Scale("season1/episode3/images/scene3/1.webp", 1920, 1080)
image e3s3-02 = im.Scale("season1/episode3/images/scene3/2.webp", 1920, 1080)
image e3s3-03 = im.Scale("season1/episode3/images/scene3/3.webp", 1920, 1080)
image e3s3-04 = im.Scale("season1/episode3/images/scene3/4.webp", 1920, 1080)
image e3s3-05 = im.Scale("season1/episode3/images/scene3/5.webp", 1920, 1080)
image e3s3-06 = im.Scale("season1/episode3/images/scene3/6.webp", 1920, 1080)
image e3s3-07 = im.Scale("season1/episode3/images/scene3/7.webp", 1920, 1080)
image e3s3-08 = im.Scale("season1/episode3/images/scene3/8.webp", 1920, 1080)
image e3s3-09 = im.Scale("season1/episode3/images/scene3/9.webp", 1920, 1080)
image e3s3-10 = im.Scale("season1/episode3/images/scene3/10.webp", 1920, 1080)
image e3s3-11 = im.Scale("season1/episode3/images/scene3/11.webp", 1920, 1080)

image e3s3_francesca_blink1:
    im.Scale("season1/episode3/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
