
# Scene 26 images ##############################################################

# Images
image e3s26-01 = im.Scale("season1/episode3/images/scene26/1.webp", 1920, 1080)
image e3s26-02 = im.Scale("season1/episode3/images/scene26/2.webp", 1920, 1080)
image e3s26-03 = im.Scale("season1/episode3/images/scene26/3.webp", 1920, 1080)
image e3s26-04 = im.Scale("season1/episode3/images/scene26/4.webp", 1920, 1080)
image e3s26-05 = im.Scale("season1/episode3/images/scene26/5.webp", 1920, 1080)
image e3s26-06 = im.Scale("season1/episode3/images/scene26/6.webp", 1920, 1080)
image e3s26-07 = im.Scale("season1/episode3/images/scene26/7.webp", 1920, 1080)
image e3s26-08 = im.Scale("season1/episode3/images/scene26/8.webp", 1920, 1080)
image e3s26-09 = im.Scale("season1/episode3/images/scene26/9.webp", 1920, 1080)
image e3s26-10 = im.Scale("season1/episode3/images/scene26/10.webp", 1920, 1080)
image e3s26-11 = im.Scale("season1/episode3/images/scene26/11.webp", 1920, 1080)
image e3s26-12 = im.Scale("season1/episode3/images/scene26/12.webp", 1920, 1080)
image e3s26-13 = im.Scale("season1/episode3/images/scene26/13.webp", 1920, 1080)
image e3s26-14 = im.Scale("season1/episode3/images/scene26/14.webp", 1920, 1080)
image e3s26-15 = im.Scale("season1/episode3/images/scene26/15.webp", 1920, 1080)
image e3s26-16 = im.Scale("season1/episode3/images/scene26/16.webp", 1920, 1080)
image e3s26-17 = im.Scale("season1/episode3/images/scene26/17.webp", 1920, 1080)
image e3s26-18 = im.Scale("season1/episode3/images/scene26/18.webp", 1920, 1080)
image e3s26-19 = im.Scale("season1/episode3/images/scene26/19.webp", 1920, 1080)
image e3s26-20 = im.Scale("season1/episode3/images/scene26/20.webp", 1920, 1080)
image e3s26-21 = im.Scale("season1/episode3/images/scene26/21.webp", 1920, 1080)
image e3s26-22 = im.Scale("season1/episode3/images/scene26/22.webp", 1920, 1080)
image e3s26-23 = im.Scale("season1/episode3/images/scene26/23.webp", 1920, 1080)
image e3s26-24 = im.Scale("season1/episode3/images/scene26/24.webp", 1920, 1080)
image e3s26-25 = im.Scale("season1/episode3/images/scene26/25.webp", 1920, 1080)
image e3s26-26 = im.Scale("season1/episode3/images/scene26/26.webp", 1920, 1080)
image e3s26-27 = im.Scale("season1/episode3/images/scene26/27.webp", 1920, 1080)
image e3s26-28 = im.Scale("season1/episode3/images/scene26/28.webp", 1920, 1080)
image e3s26-29 = im.Scale("season1/episode3/images/scene26/29.webp", 1920, 1080)
image e3s26-30 = im.Scale("season1/episode3/images/scene26/30.webp", 1920, 1080)
image e3s26-31 = im.Scale("season1/episode3/images/scene26/31.webp", 1920, 1080)
image e3s26-32 = im.Scale("season1/episode3/images/scene26/32.webp", 1920, 1080)
image e3s26-33 = im.Scale("season1/episode3/images/scene26/33.webp", 1920, 1080)
image e3s26-34 = im.Scale("season1/episode3/images/scene26/34.webp", 1920, 1080)
image e3s26-35 = im.Scale("season1/episode3/images/scene26/35.webp", 1920, 1080)
image e3s26-36 = im.Scale("season1/episode3/images/scene26/36.webp", 1920, 1080)
image e3s26-37 = im.Scale("season1/episode3/images/scene26/37.webp", 1920, 1080)
image e3s26-38 = im.Scale("season1/episode3/images/scene26/38.webp", 1920, 1080)
image e3s26-39 = im.Scale("season1/episode3/images/scene26/39.webp", 1920, 1080)
image e3s26-40 = im.Scale("season1/episode3/images/scene26/40.webp", 1920, 1080)
image e3s26-41 = im.Scale("season1/episode3/images/scene26/41.webp", 1920, 1080)
image e3s26-42 = im.Scale("season1/episode3/images/scene26/42.webp", 1920, 1080)
image e3s26-43 = im.Scale("season1/episode3/images/scene26/43.webp", 1920, 1080)
image e3s26-44 = im.Scale("season1/episode3/images/scene26/44.webp", 1920, 1080)
image e3s26-45 = im.Scale("season1/episode3/images/scene26/45.webp", 1920, 1080)
image e3s26-46 = im.Scale("season1/episode3/images/scene26/46.webp", 1920, 1080)
image e3s26-47 = im.Scale("season1/episode3/images/scene26/47.webp", 1920, 1080)
image e3s26-48 = im.Scale("season1/episode3/images/scene26/48.webp", 1920, 1080)
image e3s26-49 = im.Scale("season1/episode3/images/scene26/49.webp", 1920, 1080)
image e3s26-50 = im.Scale("season1/episode3/images/scene26/50.webp", 1920, 1080)
image e3s26-51 = im.Scale("season1/episode3/images/scene26/51.webp", 1920, 1080)
image e3s26-52 = im.Scale("season1/episode3/images/scene26/52.webp", 1920, 1080)
image e3s26-53 = im.Scale("season1/episode3/images/scene26/53.webp", 1920, 1080)
image e3s26-54 = im.Scale("season1/episode3/images/scene26/54.webp", 1920, 1080)
image e3s26-55 = im.Scale("season1/episode3/images/scene26/55.webp", 1920, 1080)
image e3s26-56 = im.Scale("season1/episode3/images/scene26/56.webp", 1920, 1080)
image e3s26-57 = im.Scale("season1/episode3/images/scene26/57.webp", 1920, 1080)
image e3s26-58 = im.Scale("season1/episode3/images/scene26/58.webp", 1920, 1080)
image e3s26-59 = im.Scale("season1/episode3/images/scene26/59.webp", 1920, 1080)
image e3s26-60 = im.Scale("season1/episode3/images/scene26/60.webp", 1920, 1080)
image e3s26-61 = im.Scale("season1/episode3/images/scene26/61.webp", 1920, 1080)
image e3s26-62 = im.Scale("season1/episode3/images/scene26/62.webp", 1920, 1080)
image e3s26-63 = im.Scale("season1/episode3/images/scene26/63.webp", 1920, 1080)
image e3s26-64 = im.Scale("season1/episode3/images/scene26/64.webp", 1920, 1080)

# Animations #
# Static
image e3s26_candance_blink1:
    im.Scale("season1/episode3/images/scene26/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene26/candance_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s26-anal_entering1 = Movie(play="season1/episode3/images/scene26/anal_entering1.webm")
image e3s26-blowjob1 = Movie(play="season1/episode3/images/scene26/blowjob1.webm")
image e3s26-blowjob2 = Movie(play="season1/episode3/images/scene26/blowjob2.webm")
image e3s26-blowjob3 = Movie(play="season1/episode3/images/scene26/blowjob3.webm")
image e3s26-cowgirl1 = Movie(play="season1/episode3/images/scene26/cowgirl1.webm")
image e3s26-cowgirl2 = Movie(play="season1/episode3/images/scene26/cowgirl2.webm")
image e3s26-cowgirl3 = Movie(play="season1/episode3/images/scene26/cowgirl3.webm")
image e3s26-cowgirl4 = Movie(play="season1/episode3/images/scene26/cowgirl4.webm")
image e3s26-cowgirl5 = Movie(play="season1/episode3/images/scene26/cowgirl5.webm")
image e3s26-cowgirl6 = Movie(play="season1/episode3/images/scene26/cowgirl6.webm")
image e3s26-doggy_anal1 = Movie(play="season1/episode3/images/scene26/doggy_anal1.webm")
image e3s26-doggy_anal2 = Movie(play="season1/episode3/images/scene26/doggy_anal2.webm")
image e3s26-doggy_anal3 = Movie(play="season1/episode3/images/scene26/doggy_anal3.webm")
image e3s26-doggy_anal4 = Movie(play="season1/episode3/images/scene26/doggy_anal4.webm")
image e3s26-doggy_anal5 = Movie(play="season1/episode3/images/scene26/doggy_anal5.webm")
image e3s26-doggy_anal6 = Movie(play="season1/episode3/images/scene26/doggy_anal6.webm")
image e3s26-doggy1 = Movie(play="season1/episode3/images/scene26/doggy1.webm")
image e3s26-doggy2 = Movie(play="season1/episode3/images/scene26/doggy2.webm")
image e3s26-doggy3 = Movie(play="season1/episode3/images/scene26/doggy3.webm")
image e3s26-doggy4 = Movie(play="season1/episode3/images/scene26/doggy4.webm")
image e3s26-handjob1 = Movie(play="season1/episode3/images/scene26/handjob1.webm")
image e3s26-handjob2 = Movie(play="season1/episode3/images/scene26/handjob2.webm")
image e3s26-standing_anal1 = Movie(play="season1/episode3/images/scene26/standing_anal1.webm")
image e3s26-standing_anal2 = Movie(play="season1/episode3/images/scene26/standing_anal2.webm")
image e3s26-standing_anal3 = Movie(play="season1/episode3/images/scene26/standing_anal3.webm")
image e3s26-standing_anal4 = Movie(play="season1/episode3/images/scene26/standing_anal4.webm")
image e3s26-standing_anal5 = Movie(play="season1/episode3/images/scene26/standing_anal5.webm")

# Censored
# Images
image e3s26-16_cen = im.Scale("season1/episode3/images/scene26/censored/16.webp", 1920, 1080)
image e3s26-18_cen = im.Scale("season1/episode3/images/scene26/censored/18.webp", 1920, 1080)
image e3s26-23_cen = im.Scale("season1/episode3/images/scene26/censored/23.webp", 1920, 1080)
image e3s26-25_cen = im.Scale("season1/episode3/images/scene26/censored/25.webp", 1920, 1080)
image e3s26-26_cen = im.Scale("season1/episode3/images/scene26/censored/26.webp", 1920, 1080)
image e3s26-27_cen = im.Scale("season1/episode3/images/scene26/censored/27.webp", 1920, 1080)
image e3s26-28_cen = im.Scale("season1/episode3/images/scene26/censored/28.webp", 1920, 1080)
image e3s26-29_cen = im.Scale("season1/episode3/images/scene26/censored/29.webp", 1920, 1080)
image e3s26-30_cen = im.Scale("season1/episode3/images/scene26/censored/30.webp", 1920, 1080)
image e3s26-33_cen = im.Scale("season1/episode3/images/scene26/censored/33.webp", 1920, 1080)
image e3s26-37_cen = im.Scale("season1/episode3/images/scene26/censored/37.webp", 1920, 1080)
image e3s26-38_cen = im.Scale("season1/episode3/images/scene26/censored/38.webp", 1920, 1080)
image e3s26-39_cen = im.Scale("season1/episode3/images/scene26/censored/39.webp", 1920, 1080)
image e3s26-40_cen = im.Scale("season1/episode3/images/scene26/censored/40.webp", 1920, 1080)
image e3s26-41_cen = im.Scale("season1/episode3/images/scene26/censored/41.webp", 1920, 1080)
image e3s26-42_cen = im.Scale("season1/episode3/images/scene26/censored/42.webp", 1920, 1080)
image e3s26-43_cen = im.Scale("season1/episode3/images/scene26/censored/43.webp", 1920, 1080)
image e3s26-44_cen = im.Scale("season1/episode3/images/scene26/censored/44.webp", 1920, 1080)
image e3s26-46_cen = im.Scale("season1/episode3/images/scene26/censored/46.webp", 1920, 1080)
image e3s26-47_cen = im.Scale("season1/episode3/images/scene26/censored/47.webp", 1920, 1080)
image e3s26-48_cen = im.Scale("season1/episode3/images/scene26/censored/48.webp", 1920, 1080)
image e3s26-49_cen = im.Scale("season1/episode3/images/scene26/censored/49.webp", 1920, 1080)
image e3s26-55_cen = im.Scale("season1/episode3/images/scene26/censored/55.webp", 1920, 1080)
image e3s26-59_cen = im.Scale("season1/episode3/images/scene26/censored/59.webp", 1920, 1080)

# Animations
image e3s26-anal_entering1_cen = Movie(play="season1/episode3/images/scene26/censored/anal_entering1.webm")
image e3s26-blowjob1_cen = Movie(play="season1/episode3/images/scene26/censored/blowjob1.webm")
image e3s26-blowjob2_cen = Movie(play="season1/episode3/images/scene26/censored/blowjob2.webm")
image e3s26-blowjob3_cen = Movie(play="season1/episode3/images/scene26/censored/blowjob3.webm")
image e3s26-cowgirl1_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl1.webm")
image e3s26-cowgirl2_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl2.webm")
image e3s26-cowgirl3_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl3.webm")
image e3s26-cowgirl4_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl4.webm")
image e3s26-cowgirl5_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl5.webm")
image e3s26-cowgirl6_cen = Movie(play="season1/episode3/images/scene26/censored/cowgirl6.webm")
image e3s26-doggy_anal1_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal1.webm")
image e3s26-doggy_anal2_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal2.webm")
image e3s26-doggy_anal3_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal3.webm")
image e3s26-doggy_anal4_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal4.webm")
image e3s26-doggy_anal5_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal5.webm")
image e3s26-doggy_anal6_cen = Movie(play="season1/episode3/images/scene26/censored/doggy_anal6.webm")
image e3s26-doggy1_cen = Movie(play="season1/episode3/images/scene26/censored/doggy1.webm")
image e3s26-doggy2_cen = Movie(play="season1/episode3/images/scene26/censored/doggy2.webm")
image e3s26-doggy3_cen = Movie(play="season1/episode3/images/scene26/censored/doggy3.webm")
image e3s26-doggy4_cen = Movie(play="season1/episode3/images/scene26/censored/doggy4.webm")
image e3s26-handjob1_cen = Movie(play="season1/episode3/images/scene26/censored/handjob1.webm")
image e3s26-handjob2_cen = Movie(play="season1/episode3/images/scene26/censored/handjob2.webm")
image e3s26-standing_anal1_cen = Movie(play="season1/episode3/images/scene26/censored/standing_anal1.webm")
image e3s26-standing_anal2_cen = Movie(play="season1/episode3/images/scene26/censored/standing_anal2.webm")
image e3s26-standing_anal3_cen = Movie(play="season1/episode3/images/scene26/censored/standing_anal3.webm")
image e3s26-standing_anal4_cen = Movie(play="season1/episode3/images/scene26/censored/standing_anal4.webm")
image e3s26-standing_anal5_cen = Movie(play="season1/episode3/images/scene26/censored/standing_anal5.webm")
