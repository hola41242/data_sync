
# Scene 16 images ###############################################################

image e3s16-01 = im.Scale("season1/episode3/images/scene16/1.webp", 1920, 1080)
image e3s16-02 = im.Scale("season1/episode3/images/scene16/2.webp", 1920, 1080)
image e3s16-03 = im.Scale("season1/episode3/images/scene16/3.webp", 1920, 1080)
image e3s16-04 = im.Scale("season1/episode3/images/scene16/4.webp", 1920, 1080)
image e3s16-05 = im.Scale("season1/episode3/images/scene16/5.webp", 1920, 1080)
image e3s16-06 = im.Scale("season1/episode3/images/scene16/6.webp", 1920, 1080)
image e3s16-07 = im.Scale("season1/episode3/images/scene16/7.webp", 1920, 1080)
image e3s16-08 = im.Scale("season1/episode3/images/scene16/8.webp", 1920, 1080)
image e3s16-09 = im.Scale("season1/episode3/images/scene16/9.webp", 1920, 1080)
image e3s16-10 = im.Scale("season1/episode3/images/scene16/10.webp", 1920, 1080)
image e3s16-11 = im.Scale("season1/episode3/images/scene16/11.webp", 1920, 1080)
image e3s16-12 = im.Scale("season1/episode3/images/scene16/12.webp", 1920, 1080)
image e3s16-13 = im.Scale("season1/episode3/images/scene16/13.webp", 1920, 1080)
image e3s16-14 = im.Scale("season1/episode3/images/scene16/14.webp", 1920, 1080)
image e3s16-15 = im.Scale("season1/episode3/images/scene16/15.webp", 1920, 1080)
image e3s16-16 = im.Scale("season1/episode3/images/scene16/16.webp", 1920, 1080)
image e3s16-17 = im.Scale("season1/episode3/images/scene16/17.webp", 1920, 1080)
image e3s16-18 = im.Scale("season1/episode3/images/scene16/18.webp", 1920, 1080)
image e3s16-19 = im.Scale("season1/episode3/images/scene16/19.webp", 1920, 1080)
image e3s16-20 = im.Scale("season1/episode3/images/scene16/20.webp", 1920, 1080)
image e3s16-21 = im.Scale("season1/episode3/images/scene16/21.webp", 1920, 1080)
image e3s16-22 = im.Scale("season1/episode3/images/scene16/22.webp", 1920, 1080)
image e3s16-23 = im.Scale("season1/episode3/images/scene16/23.webp", 1920, 1080)
image e3s16-24 = im.Scale("season1/episode3/images/scene16/24.webp", 1920, 1080)
image e3s16-25 = im.Scale("season1/episode3/images/scene16/25.webp", 1920, 1080)
image e3s16-26 = im.Scale("season1/episode3/images/scene16/26.webp", 1920, 1080)
image e3s16-27 = im.Scale("season1/episode3/images/scene16/27.webp", 1920, 1080)
image e3s16-28 = im.Scale("season1/episode3/images/scene16/28.webp", 1920, 1080)
image e3s16-29 = im.Scale("season1/episode3/images/scene16/29.webp", 1920, 1080)
image e3s16-30 = im.Scale("season1/episode3/images/scene16/30.webp", 1920, 1080)
image e3s16-31 = im.Scale("season1/episode3/images/scene16/31.webp", 1920, 1080)
image e3s16-32 = im.Scale("season1/episode3/images/scene16/32.webp", 1920, 1080)
image e3s16-33 = im.Scale("season1/episode3/images/scene16/33.webp", 1920, 1080)
image e3s16-34 = im.Scale("season1/episode3/images/scene16/34.webp", 1920, 1080)
image e3s16-35 = im.Scale("season1/episode3/images/scene16/35.webp", 1920, 1080)
image e3s16-36 = im.Scale("season1/episode3/images/scene16/36.webp", 1920, 1080)
image e3s16-37 = im.Scale("season1/episode3/images/scene16/37.webp", 1920, 1080)
image e3s16-38 = im.Scale("season1/episode3/images/scene16/38.webp", 1920, 1080)

image e3s16_bridget_blink1:
    im.Scale("season1/episode3/images/scene16/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s16_bridget_blink2:
    im.Scale("season1/episode3/images/scene16/bridget_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/bridget_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s16_tracy_blink1:
    im.Scale("season1/episode3/images/scene16/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s16_tracy_blink2:
    im.Scale("season1/episode3/images/scene16/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s16_jon_blink1:
    im.Scale("season1/episode3/images/scene16/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene16/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
