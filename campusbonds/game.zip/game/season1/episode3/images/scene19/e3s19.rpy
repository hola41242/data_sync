
# Scene 19 images ###############################################################

# Images
image e3s19-01 = im.Scale("season1/episode3/images/scene19/1.webp", 1920, 1080)
image e3s19-02 = im.Scale("season1/episode3/images/scene19/2.webp", 1920, 1080)
image e3s19-03 = im.Scale("season1/episode3/images/scene19/3.webp", 1920, 1080)
image e3s19-04 = im.Scale("season1/episode3/images/scene19/4.webp", 1920, 1080)
image e3s19-05 = im.Scale("season1/episode3/images/scene19/5.webp", 1920, 1080)
image e3s19-06 = im.Scale("season1/episode3/images/scene19/6.webp", 1920, 1080)
image e3s19-07 = im.Scale("season1/episode3/images/scene19/7.webp", 1920, 1080)
image e3s19-08 = im.Scale("season1/episode3/images/scene19/8.webp", 1920, 1080)
image e3s19-09 = im.Scale("season1/episode3/images/scene19/9.webp", 1920, 1080)
image e3s19-10 = im.Scale("season1/episode3/images/scene19/10.webp", 1920, 1080)
image e3s19-11 = im.Scale("season1/episode3/images/scene19/11.webp", 1920, 1080)
image e3s19-12 = im.Scale("season1/episode3/images/scene19/12.webp", 1920, 1080)
image e3s19-13 = im.Scale("season1/episode3/images/scene19/13.webp", 1920, 1080)
image e3s19-14 = im.Scale("season1/episode3/images/scene19/14.webp", 1920, 1080)
image e3s19-15 = im.Scale("season1/episode3/images/scene19/15.webp", 1920, 1080)
image e3s19-16 = im.Scale("season1/episode3/images/scene19/16.webp", 1920, 1080)
image e3s19-17 = im.Scale("season1/episode3/images/scene19/17.webp", 1920, 1080)
image e3s19-18 = im.Scale("season1/episode3/images/scene19/18.webp", 1920, 1080)
image e3s19-19 = im.Scale("season1/episode3/images/scene19/19.webp", 1920, 1080)
image e3s19-20 = im.Scale("season1/episode3/images/scene19/20.webp", 1920, 1080)
image e3s19-21 = im.Scale("season1/episode3/images/scene19/21.webp", 1920, 1080)
image e3s19-22 = im.Scale("season1/episode3/images/scene19/22.webp", 1920, 1080)
image e3s19-23 = im.Scale("season1/episode3/images/scene19/23.webp", 1920, 1080)
image e3s19-24 = im.Scale("season1/episode3/images/scene19/24.webp", 1920, 1080)
image e3s19-25 = im.Scale("season1/episode3/images/scene19/25.webp", 1920, 1080)
image e3s19-26 = im.Scale("season1/episode3/images/scene19/26.webp", 1920, 1080)
image e3s19-27 = im.Scale("season1/episode3/images/scene19/27.webp", 1920, 1080)
image e3s19-28 = im.Scale("season1/episode3/images/scene19/28.webp", 1920, 1080)
image e3s19-29 = im.Scale("season1/episode3/images/scene19/29.webp", 1920, 1080)
image e3s19-30 = im.Scale("season1/episode3/images/scene19/30.webp", 1920, 1080)
image e3s19-31 = im.Scale("season1/episode3/images/scene19/31.webp", 1920, 1080)
image e3s19-32 = im.Scale("season1/episode3/images/scene19/32.webp", 1920, 1080)
image e3s19-33 = im.Scale("season1/episode3/images/scene19/33.webp", 1920, 1080)
image e3s19-34 = im.Scale("season1/episode3/images/scene19/34.webp", 1920, 1080)
image e3s19-35 = im.Scale("season1/episode3/images/scene19/35.webp", 1920, 1080)
image e3s19-36 = im.Scale("season1/episode3/images/scene19/36.webp", 1920, 1080)
image e3s19-37 = im.Scale("season1/episode3/images/scene19/37.webp", 1920, 1080)
image e3s19-38 = im.Scale("season1/episode3/images/scene19/38.webp", 1920, 1080)
image e3s19-39 = im.Scale("season1/episode3/images/scene19/39.webp", 1920, 1080)
image e3s19-40 = im.Scale("season1/episode3/images/scene19/40.webp", 1920, 1080)
image e3s19-41 = im.Scale("season1/episode3/images/scene19/41.webp", 1920, 1080)
image e3s19-42 = im.Scale("season1/episode3/images/scene19/42.webp", 1920, 1080)
image e3s19-43 = im.Scale("season1/episode3/images/scene19/43.webp", 1920, 1080)
image e3s19-44 = im.Scale("season1/episode3/images/scene19/44.webp", 1920, 1080)
image e3s19-45 = im.Scale("season1/episode3/images/scene19/45.webp", 1920, 1080)
image e3s19-46 = im.Scale("season1/episode3/images/scene19/46.webp", 1920, 1080)
image e3s19-47 = im.Scale("season1/episode3/images/scene19/47.webp", 1920, 1080)
image e3s19-48 = im.Scale("season1/episode3/images/scene19/48.webp", 1920, 1080)
image e3s19-49 = im.Scale("season1/episode3/images/scene19/49.webp", 1920, 1080)
image e3s19-50 = im.Scale("season1/episode3/images/scene19/50.webp", 1920, 1080)
image e3s19-51 = im.Scale("season1/episode3/images/scene19/51.webp", 1920, 1080)
image e3s19-52 = im.Scale("season1/episode3/images/scene19/52.webp", 1920, 1080)
image e3s19-53 = im.Scale("season1/episode3/images/scene19/53.webp", 1920, 1080)
image e3s19-54 = im.Scale("season1/episode3/images/scene19/54.webp", 1920, 1080)
image e3s19-55 = im.Scale("season1/episode3/images/scene19/55.webp", 1920, 1080)
image e3s19-56 = im.Scale("season1/episode3/images/scene19/56.webp", 1920, 1080)
image e3s19-57 = im.Scale("season1/episode3/images/scene19/57.webp", 1920, 1080)
image e3s19-58 = im.Scale("season1/episode3/images/scene19/58.webp", 1920, 1080)
image e3s19-59 = im.Scale("season1/episode3/images/scene19/59.webp", 1920, 1080)
image e3s19-60 = im.Scale("season1/episode3/images/scene19/60.webp", 1920, 1080)
image e3s19-61 = im.Scale("season1/episode3/images/scene19/61.webp", 1920, 1080)
image e3s19-62 = im.Scale("season1/episode3/images/scene19/62.webp", 1920, 1080)
image e3s19-63 = im.Scale("season1/episode3/images/scene19/63.webp", 1920, 1080)
image e3s19-64 = im.Scale("season1/episode3/images/scene19/64.webp", 1920, 1080)

# Animations #
# Static
image e3s19_amber_blink1:
    im.Scale("season1/episode3/images/scene19/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene19/amber_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s19-blowjob1 = Movie(play="season1/episode3/images/scene19/blowjob1.webm")
image e3s19-blowjob2 = Movie(play="season1/episode3/images/scene19/blowjob2.webm")
image e3s19-blowjob3 = Movie(play="season1/episode3/images/scene19/blowjob3.webm")
image e3s19-blowjob4 = Movie(play="season1/episode3/images/scene19/blowjob4.webm")
image e3s19-blowjob5 = Movie(play="season1/episode3/images/scene19/blowjob5.webm")
image e3s19-handjob1 = Movie(play="season1/episode3/images/scene19/handjob1.webm")
image e3s19-handjob2 = Movie(play="season1/episode3/images/scene19/handjob2.webm")
image e3s19-handjob3 = Movie(play="season1/episode3/images/scene19/handjob3.webm")
image e3s19-handjob4 = Movie(play="season1/episode3/images/scene19/handjob4.webm")
image e3s19-handjob5 = Movie(play="season1/episode3/images/scene19/handjob5.webm")

# Censored
# Images
image e3s19-21_cen = im.Scale("season1/episode3/images/scene19/censored/21.webp", 1920, 1080)
image e3s19-22_cen = im.Scale("season1/episode3/images/scene19/censored/22.webp", 1920, 1080)
image e3s19-24_cen = im.Scale("season1/episode3/images/scene19/censored/24.webp", 1920, 1080)
image e3s19-28_cen = im.Scale("season1/episode3/images/scene19/censored/28.webp", 1920, 1080)
image e3s19-34_cen = im.Scale("season1/episode3/images/scene19/censored/34.webp", 1920, 1080)
image e3s19-35_cen = im.Scale("season1/episode3/images/scene19/censored/35.webp", 1920, 1080)
image e3s19-36_cen = im.Scale("season1/episode3/images/scene19/censored/36.webp", 1920, 1080)
image e3s19-37_cen = im.Scale("season1/episode3/images/scene19/censored/37.webp", 1920, 1080)
image e3s19-38_cen = im.Scale("season1/episode3/images/scene19/censored/38.webp", 1920, 1080)
image e3s19-41_cen = im.Scale("season1/episode3/images/scene19/censored/41.webp", 1920, 1080)
image e3s19-44_cen = im.Scale("season1/episode3/images/scene19/censored/44.webp", 1920, 1080)
image e3s19-45_cen = im.Scale("season1/episode3/images/scene19/censored/45.webp", 1920, 1080)
image e3s19-46_cen = im.Scale("season1/episode3/images/scene19/censored/46.webp", 1920, 1080)
image e3s19-48_cen = im.Scale("season1/episode3/images/scene19/censored/48.webp", 1920, 1080)
image e3s19-49_cen = im.Scale("season1/episode3/images/scene19/censored/49.webp", 1920, 1080)
image e3s19-50_cen = im.Scale("season1/episode3/images/scene19/censored/50.webp", 1920, 1080)
image e3s19-51_cen = im.Scale("season1/episode3/images/scene19/censored/51.webp", 1920, 1080)
image e3s19-52_cen = im.Scale("season1/episode3/images/scene19/censored/52.webp", 1920, 1080)
image e3s19-53_cen = im.Scale("season1/episode3/images/scene19/censored/53.webp", 1920, 1080)
image e3s19-54_cen = im.Scale("season1/episode3/images/scene19/censored/54.webp", 1920, 1080)
image e3s19-56_cen = im.Scale("season1/episode3/images/scene19/censored/56.webp", 1920, 1080)

# Animations
image e3s19-blowjob1_cen = Movie(play="season1/episode3/images/scene19/censored/blowjob1.webm")
image e3s19-blowjob2_cen = Movie(play="season1/episode3/images/scene19/censored/blowjob2.webm")
image e3s19-blowjob3_cen = Movie(play="season1/episode3/images/scene19/censored/blowjob3.webm")
image e3s19-blowjob4_cen = Movie(play="season1/episode3/images/scene19/censored/blowjob4.webm")
image e3s19-blowjob5_cen = Movie(play="season1/episode3/images/scene19/censored/blowjob5.webm")
image e3s19-handjob1_cen = Movie(play="season1/episode3/images/scene19/censored/handjob1.webm")
image e3s19-handjob2_cen = Movie(play="season1/episode3/images/scene19/censored/handjob2.webm")
image e3s19-handjob3_cen = Movie(play="season1/episode3/images/scene19/censored/handjob3.webm")
image e3s19-handjob4_cen = Movie(play="season1/episode3/images/scene19/censored/handjob4.webm")
image e3s19-handjob5_cen = Movie(play="season1/episode3/images/scene19/censored/handjob5.webm")
