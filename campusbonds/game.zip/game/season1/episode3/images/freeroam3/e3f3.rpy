
# Freeroam 3 Images ############################################################
# Couch
image e3f3-01 = im.Scale("season1/episode3/images/freeroam3/1.webp", 1920, 1080)
image e3f3-01_1 = im.Scale("season1/episode3/images/freeroam3/1.1.webp", 1920, 1080)
image e3f3-01_2 = im.Scale("season1/episode3/images/freeroam3/1.2.webp", 1920, 1080)

# Dj
image e3f3-02 = im.Scale("season1/episode3/images/freeroam3/2.webp", 1920, 1080)

# Vending
image e3f3-03 = im.Scale("season1/episode3/images/freeroam3/3.webp", 1920, 1080)
image e3f3-03_1 = im.Scale("season1/episode3/images/freeroam3/3.1.webp", 1920, 1080)
image e3f3-03_2 = im.Scale("season1/episode3/images/freeroam3/3.2.webp", 1920, 1080)
image e3f3-03_3 = im.Scale("season1/episode3/images/freeroam3/3.3.webp", 1920, 1080)

# Pool
image e3f3-04 = im.Scale("season1/episode3/images/freeroam3/4.webp", 1920, 1080)

# Staff
image e3f3-05 = im.Scale("season1/episode3/images/freeroam3/5.webp", 1920, 1080)

# Bar
image e3f3-06 = im.Scale("season1/episode3/images/freeroam3/6.webp", 1920, 1080)
image e3f3-06_1 = im.Scale("season1/episode3/images/freeroam3/6.1.webp", 1920, 1080)
image e3f3-06_2 = im.Scale("season1/episode3/images/freeroam3/6.2.webp", 1920, 1080)

# Pool couch
image e3f3-07 = im.Scale("season1/episode3/images/freeroam3/7.webp", 1920, 1080)

# Vending table
image e3f3-08 = im.Scale("season1/episode3/images/freeroam3/8.webp", 1920, 1080)

# Charlie
image e3f3-ch_01 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/1.webp", 1920, 1080)
image e3f3-ch_02 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/2.webp", 1920, 1080)
image e3f3-ch_03 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/3.webp", 1920, 1080)
image e3f3-ch_04 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/4.webp", 1920, 1080)
image e3f3-ch_05 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/5.webp", 1920, 1080)
image e3f3-ch_06 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/6.webp", 1920, 1080)
image e3f3-ch_07 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/7.webp", 1920, 1080)
image e3f3-ch_08 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/8.webp", 1920, 1080)
image e3f3-ch_09 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/9.webp", 1920, 1080)
image e3f3-ch_10 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/10.webp", 1920, 1080)
image e3f3-ch_11 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/11.webp", 1920, 1080)
image e3f3-ch_12 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/12.webp", 1920, 1080)
image e3f3-ch_13 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/13.webp", 1920, 1080)
image e3f3-ch_14 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/14.webp", 1920, 1080)
image e3f3-ch_15 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/15.webp", 1920, 1080)
image e3f3-ch_16 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/16.webp", 1920, 1080)
image e3f3-ch_17 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/17.webp", 1920, 1080)
image e3f3-ch_18 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/18.webp", 1920, 1080)
image e3f3-ch_19 = im.Scale("season1/episode3/images/freeroam3/images/charlie1/19.webp", 1920, 1080)

# Claire
image e3f3-ci_01 = im.Scale("season1/episode3/images/freeroam3/images/claire1/1.webp", 1920, 1080)
image e3f3-ci_02 = im.Scale("season1/episode3/images/freeroam3/images/claire1/2.webp", 1920, 1080)
image e3f3-ci_03 = im.Scale("season1/episode3/images/freeroam3/images/claire1/3.webp", 1920, 1080)
image e3f3-ci_04 = im.Scale("season1/episode3/images/freeroam3/images/claire1/4.webp", 1920, 1080)
image e3f3-ci_05 = im.Scale("season1/episode3/images/freeroam3/images/claire1/5.webp", 1920, 1080)
image e3f3-ci_06 = im.Scale("season1/episode3/images/freeroam3/images/claire1/6.webp", 1920, 1080)
image e3f3-ci_07 = im.Scale("season1/episode3/images/freeroam3/images/claire1/7.webp", 1920, 1080)
image e3f3-ci_08 = im.Scale("season1/episode3/images/freeroam3/images/claire1/8.webp", 1920, 1080)
image e3f3-ci_09 = im.Scale("season1/episode3/images/freeroam3/images/claire1/9.webp", 1920, 1080)
image e3f3-ci_10 = im.Scale("season1/episode3/images/freeroam3/images/claire1/10.webp", 1920, 1080)
image e3f3-ci_11 = im.Scale("season1/episode3/images/freeroam3/images/claire1/11.webp", 1920, 1080)
image e3f3-ci_12 = im.Scale("season1/episode3/images/freeroam3/images/claire1/12.webp", 1920, 1080)
image e3f3-ci_13 = im.Scale("season1/episode3/images/freeroam3/images/claire1/13.webp", 1920, 1080)
image e3f3-ci_14 = im.Scale("season1/episode3/images/freeroam3/images/claire1/14.webp", 1920, 1080)
image e3f3-ci_15 = im.Scale("season1/episode3/images/freeroam3/images/claire1/15.webp", 1920, 1080)
image e3f3-ci_16 = im.Scale("season1/episode3/images/freeroam3/images/claire1/16.webp", 1920, 1080)
image e3f3-ci_17 = im.Scale("season1/episode3/images/freeroam3/images/claire1/17.webp", 1920, 1080)
image e3f3-ci_18 = im.Scale("season1/episode3/images/freeroam3/images/claire1/18.webp", 1920, 1080)
image e3f3-ci_19 = im.Scale("season1/episode3/images/freeroam3/images/claire1/19.webp", 1920, 1080)
image e3f3-ci_20 = im.Scale("season1/episode3/images/freeroam3/images/claire1/20.webp", 1920, 1080)
image e3f3-ci_21 = im.Scale("season1/episode3/images/freeroam3/images/claire1/21.webp", 1920, 1080)
image e3f3-ci_22 = im.Scale("season1/episode3/images/freeroam3/images/claire1/22.webp", 1920, 1080)
image e3f3-ci_23 = im.Scale("season1/episode3/images/freeroam3/images/claire1/23.webp", 1920, 1080)
image e3f3-ci_24 = im.Scale("season1/episode3/images/freeroam3/images/claire1/24.webp", 1920, 1080)
image e3f3-ci_25 = im.Scale("season1/episode3/images/freeroam3/images/claire1/25.webp", 1920, 1080)
image e3f3-ci_26 = im.Scale("season1/episode3/images/freeroam3/images/claire1/26.webp", 1920, 1080)
image e3f3-ci_27 = im.Scale("season1/episode3/images/freeroam3/images/claire1/27.webp", 1920, 1080)
image e3f3-ci_28 = im.Scale("season1/episode3/images/freeroam3/images/claire1/28.webp", 1920, 1080)
image e3f3-ci_29 = im.Scale("season1/episode3/images/freeroam3/images/claire1/29.webp", 1920, 1080)
image e3f3-ci_30 = im.Scale("season1/episode3/images/freeroam3/images/claire1/30.webp", 1920, 1080)
image e3f3-ci_31 = im.Scale("season1/episode3/images/freeroam3/images/claire1/31.webp", 1920, 1080)

# Dj
image e3f3-dj_01 = im.Scale("season1/episode3/images/freeroam3/images/dj1/1.webp", 1920, 1080)
image e3f3-dj_02 = im.Scale("season1/episode3/images/freeroam3/images/dj1/2.webp", 1920, 1080)
image e3f3-dj_03 = im.Scale("season1/episode3/images/freeroam3/images/dj1/3.webp", 1920, 1080)
image e3f3-dj_04 = im.Scale("season1/episode3/images/freeroam3/images/dj1/4.webp", 1920, 1080)
image e3f3-dj_05 = im.Scale("season1/episode3/images/freeroam3/images/dj1/5.webp", 1920, 1080)
image e3f3-dj_06 = im.Scale("season1/episode3/images/freeroam3/images/dj1/6.webp", 1920, 1080)
image e3f3-dj_07 = im.Scale("season1/episode3/images/freeroam3/images/dj1/7.webp", 1920, 1080)
image e3f3-dj_08 = im.Scale("season1/episode3/images/freeroam3/images/dj1/8.webp", 1920, 1080)
image e3f3-dj_09 = im.Scale("season1/episode3/images/freeroam3/images/dj1/9.webp", 1920, 1080)
image e3f3-dj_10 = im.Scale("season1/episode3/images/freeroam3/images/dj1/10.webp", 1920, 1080)

image e3f3_dj_dj_blink1:
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/dj1/dj_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Guys
image e3f3-gu_01 = im.Scale("season1/episode3/images/freeroam3/images/guys1/1.webp", 1920, 1080)
image e3f3-gu_02 = im.Scale("season1/episode3/images/freeroam3/images/guys1/2.webp", 1920, 1080)
image e3f3-gu_03 = im.Scale("season1/episode3/images/freeroam3/images/guys1/3.webp", 1920, 1080)
image e3f3-gu_04 = im.Scale("season1/episode3/images/freeroam3/images/guys1/4.webp", 1920, 1080)
image e3f3-gu_05 = im.Scale("season1/episode3/images/freeroam3/images/guys1/5.webp", 1920, 1080)
image e3f3-gu_06 = im.Scale("season1/episode3/images/freeroam3/images/guys1/6.webp", 1920, 1080)
image e3f3-gu_07 = im.Scale("season1/episode3/images/freeroam3/images/guys1/7.webp", 1920, 1080)
image e3f3-gu_08 = im.Scale("season1/episode3/images/freeroam3/images/guys1/8.webp", 1920, 1080)
image e3f3-gu_09 = im.Scale("season1/episode3/images/freeroam3/images/guys1/9.webp", 1920, 1080)
image e3f3-gu_10 = im.Scale("season1/episode3/images/freeroam3/images/guys1/10.webp", 1920, 1080)
image e3f3-gu_11 = im.Scale("season1/episode3/images/freeroam3/images/guys1/11.webp", 1920, 1080)
image e3f3-gu_12 = im.Scale("season1/episode3/images/freeroam3/images/guys1/12.webp", 1920, 1080)
image e3f3-gu_13 = im.Scale("season1/episode3/images/freeroam3/images/guys1/13.webp", 1920, 1080)
image e3f3-gu_14 = im.Scale("season1/episode3/images/freeroam3/images/guys1/14.webp", 1920, 1080)
image e3f3-gu_15 = im.Scale("season1/episode3/images/freeroam3/images/guys1/15.webp", 1920, 1080)
image e3f3-gu_16 = im.Scale("season1/episode3/images/freeroam3/images/guys1/16.webp", 1920, 1080)

# Jordan
image e3f3-jd_01 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/1.webp", 1920, 1080)
image e3f3-jd_02 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/2.webp", 1920, 1080)
image e3f3-jd_03 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/3.webp", 1920, 1080)
image e3f3-jd_04 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/4.webp", 1920, 1080)
image e3f3-jd_05 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/5.webp", 1920, 1080)
image e3f3-jd_06 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/6.webp", 1920, 1080)
image e3f3-jd_07 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/7.webp", 1920, 1080)
image e3f3-jd_08 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/8.webp", 1920, 1080)
image e3f3-jd_09 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/9.webp", 1920, 1080)
image e3f3-jd_10 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/10.webp", 1920, 1080)
image e3f3-jd_11 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/11.webp", 1920, 1080)
image e3f3-jd_12 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/12.webp", 1920, 1080)
image e3f3-jd_13 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/13.webp", 1920, 1080)
image e3f3-jd_14 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/14.webp", 1920, 1080)
image e3f3-jd_15 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/15.webp", 1920, 1080)
image e3f3-jd_16 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/16.webp", 1920, 1080)
image e3f3-jd_17 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/17.webp", 1920, 1080)
image e3f3-jd_18 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/18.webp", 1920, 1080)
image e3f3-jd_19 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/19.webp", 1920, 1080)
image e3f3-jd_20 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/20.webp", 1920, 1080)
image e3f3-jd_21 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/21.webp", 1920, 1080)
image e3f3-jd_22 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/22.webp", 1920, 1080)
image e3f3-jd_23 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/23.webp", 1920, 1080)
image e3f3-jd_24 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/24.webp", 1920, 1080)
image e3f3-jd_25 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/25.webp", 1920, 1080)
image e3f3-jd_26 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/26.webp", 1920, 1080)
image e3f3-jd_27 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/27.webp", 1920, 1080)
image e3f3-jd_28 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/28.webp", 1920, 1080)
image e3f3-jd_29 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/29.webp", 1920, 1080)
image e3f3-jd_30 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/30.webp", 1920, 1080)
image e3f3-jd_31 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/31.webp", 1920, 1080)
image e3f3-jd_32 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/32.webp", 1920, 1080)
image e3f3-jd_33 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/33.webp", 1920, 1080)
image e3f3-jd_34 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/34.webp", 1920, 1080)
image e3f3-jd_35 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/35.webp", 1920, 1080)
image e3f3-jd_36 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/36.webp", 1920, 1080)
image e3f3-jd_37 = im.Scale("season1/episode3/images/freeroam3/images/jordan1/37.webp", 1920, 1080)

# Ken Roman
image e3f3-kr_01 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/1.webp", 1920, 1080)
image e3f3-kr_02 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/2.webp", 1920, 1080)
image e3f3-kr_03 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/3.webp", 1920, 1080)
image e3f3-kr_04 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/4.webp", 1920, 1080)
image e3f3-kr_05 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/5.webp", 1920, 1080)
image e3f3-kr_06 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/6.webp", 1920, 1080)
image e3f3-kr_07 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/7.webp", 1920, 1080)
image e3f3-kr_08 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/8.webp", 1920, 1080)
image e3f3-kr_09 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/9.webp", 1920, 1080)
image e3f3-kr_10 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/10.webp", 1920, 1080)
image e3f3-kr_11 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/11.webp", 1920, 1080)
image e3f3-kr_12 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/12.webp", 1920, 1080)
image e3f3-kr_13 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/13.webp", 1920, 1080)
image e3f3-kr_14 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/14.webp", 1920, 1080)
image e3f3-kr_15 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/15.webp", 1920, 1080)
image e3f3-kr_16 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/16.webp", 1920, 1080)
image e3f3-kr_17 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/17.webp", 1920, 1080)
image e3f3-kr_18 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/18.webp", 1920, 1080)
image e3f3-kr_19 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/19.webp", 1920, 1080)
image e3f3-kr_20 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/20.webp", 1920, 1080)
image e3f3-kr_21 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/21.webp", 1920, 1080)
image e3f3-kr_22 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/22.webp", 1920, 1080)
image e3f3-kr_23 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/23.webp", 1920, 1080)
image e3f3-kr_24 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/24.webp", 1920, 1080)
image e3f3-kr_25 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/25.webp", 1920, 1080)
image e3f3-kr_26 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/26.webp", 1920, 1080)
image e3f3-kr_27 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/27.webp", 1920, 1080)
image e3f3-kr_28 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/28.webp", 1920, 1080)
image e3f3-kr_29 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/29.webp", 1920, 1080)
image e3f3-kr_30 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/30.webp", 1920, 1080)
image e3f3-kr_31 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/31.webp", 1920, 1080)
image e3f3-kr_32 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/32.webp", 1920, 1080)
image e3f3-kr_33 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/33.webp", 1920, 1080)
image e3f3-kr_34 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/34.webp", 1920, 1080)
image e3f3-kr_35 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/35.webp", 1920, 1080)
image e3f3-kr_36 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/36.webp", 1920, 1080)
image e3f3-kr_37 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/37.webp", 1920, 1080)
image e3f3-kr_38 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/38.webp", 1920, 1080)
image e3f3-kr_39 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/39.webp", 1920, 1080)
image e3f3-kr_40 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/40.webp", 1920, 1080)
image e3f3-kr_41 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/41.webp", 1920, 1080)
image e3f3-kr_42 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/42.webp", 1920, 1080)
image e3f3-kr_43 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/43.webp", 1920, 1080)
image e3f3-kr_44 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/44.webp", 1920, 1080)
image e3f3-kr_45 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/45.webp", 1920, 1080)
image e3f3-kr_46 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/46.webp", 1920, 1080)
image e3f3-kr_47 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/47.webp", 1920, 1080)
image e3f3-kr_48 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/48.webp", 1920, 1080)
image e3f3-kr_49 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/49.webp", 1920, 1080)
image e3f3-kr_50 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/50.webp", 1920, 1080)
image e3f3-kr_51 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/51.webp", 1920, 1080)
image e3f3-kr_52 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/52.webp", 1920, 1080)
image e3f3-kr_53 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/53.webp", 1920, 1080)
image e3f3-kr_54 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/54.webp", 1920, 1080)
image e3f3-kr_55 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/55.webp", 1920, 1080)
image e3f3-kr_56 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/56.webp", 1920, 1080)
image e3f3-kr_57 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/57.webp", 1920, 1080)
image e3f3-kr_58 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/58.webp", 1920, 1080)
image e3f3-kr_59 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/59.webp", 1920, 1080)
image e3f3-kr_60 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/60.webp", 1920, 1080)
image e3f3-kr_61 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/61.webp", 1920, 1080)
image e3f3-kr_62 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/62.webp", 1920, 1080)
image e3f3-kr_63 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/63.webp", 1920, 1080)
image e3f3-kr_64 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/64.webp", 1920, 1080)
image e3f3-kr_65 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/65.webp", 1920, 1080)
image e3f3-kr_66 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/66.webp", 1920, 1080)
image e3f3-kr_67 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/67.webp", 1920, 1080)
image e3f3-kr_68 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/68.webp", 1920, 1080)
image e3f3-kr_69 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/69.webp", 1920, 1080)
image e3f3-kr_70 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/70.webp", 1920, 1080)
image e3f3-kr_71 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/71.webp", 1920, 1080)
image e3f3-kr_72 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/72.webp", 1920, 1080)
image e3f3-kr_73 = im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/73.webp", 1920, 1080)

image e3f3_kr_mia_blink1:
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/ken_roman1/mia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Scarlett
image e3f3-sc_01 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/1.webp", 1920, 1080)
image e3f3-sc_02 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/2.webp", 1920, 1080)
image e3f3-sc_03 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/3.webp", 1920, 1080)
image e3f3-sc_04 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/4.webp", 1920, 1080)
image e3f3-sc_05 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/5.webp", 1920, 1080)
image e3f3-sc_06 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/6.webp", 1920, 1080)
image e3f3-sc_07 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/7.webp", 1920, 1080)
image e3f3-sc_08 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/8.webp", 1920, 1080)
image e3f3-sc_09 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/9.webp", 1920, 1080)
image e3f3-sc_10 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/10.webp", 1920, 1080)
image e3f3-sc_11 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/11.webp", 1920, 1080)
image e3f3-sc_12 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/12.webp", 1920, 1080)
image e3f3-sc_13 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/13.webp", 1920, 1080)
image e3f3-sc_14 = im.Scale("season1/episode3/images/freeroam3/images/scarlett1/14.webp", 1920, 1080)

# Tracy sex
image e3f3-tr_01 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/1.webp", 1920, 1080)
image e3f3-tr_02 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/2.webp", 1920, 1080)
image e3f3-tr_03 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/3.webp", 1920, 1080)
image e3f3-tr_04 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/4.webp", 1920, 1080)
image e3f3-tr_05 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/5.webp", 1920, 1080)
image e3f3-tr_06 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/6.webp", 1920, 1080)
image e3f3-tr_07 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/7.webp", 1920, 1080)
image e3f3-tr_08 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/8.webp", 1920, 1080)
image e3f3-tr_09 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/9.webp", 1920, 1080)
image e3f3-tr_10 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/10.webp", 1920, 1080)
image e3f3-tr_11 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/11.webp", 1920, 1080)
image e3f3-tr_12 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/12.webp", 1920, 1080)
image e3f3-tr_13 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/13.webp", 1920, 1080)
image e3f3-tr_14 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/14.webp", 1920, 1080)
image e3f3-tr_15 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/15.webp", 1920, 1080)
image e3f3-tr_16 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/16.webp", 1920, 1080)
image e3f3-tr_17 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/17.webp", 1920, 1080)
image e3f3-tr_18 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/18.webp", 1920, 1080)
image e3f3-tr_19 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/19.webp", 1920, 1080)
image e3f3-tr_20 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/20.webp", 1920, 1080)
image e3f3-tr_21 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/21.webp", 1920, 1080)
image e3f3-tr_22 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/22.webp", 1920, 1080)
image e3f3-tr_23 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/23.webp", 1920, 1080)
image e3f3-tr_24 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/24.webp", 1920, 1080)
image e3f3-tr_25 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/25.webp", 1920, 1080)
image e3f3-tr_26 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/26.webp", 1920, 1080)
image e3f3-tr_27 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/27.webp", 1920, 1080)
image e3f3-tr_28 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/28.webp", 1920, 1080)
image e3f3-tr_29 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/29.webp", 1920, 1080)
image e3f3-tr_30 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/30.webp", 1920, 1080)
image e3f3-tr_31 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/31.webp", 1920, 1080)
image e3f3-tr_32 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/32.webp", 1920, 1080)
image e3f3-tr_33 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/33.webp", 1920, 1080)
image e3f3-tr_34 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/34.webp", 1920, 1080)
image e3f3-tr_35 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/35.webp", 1920, 1080)
image e3f3-tr_36 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/36.webp", 1920, 1080)
image e3f3-tr_37 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/37.webp", 1920, 1080)
image e3f3-tr_38 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/38.webp", 1920, 1080)
image e3f3-tr_39 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/39.webp", 1920, 1080)
image e3f3-tr_40 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/40.webp", 1920, 1080)
image e3f3-tr_41 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/41.webp", 1920, 1080)
image e3f3-tr_42 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/42.webp", 1920, 1080)
image e3f3-tr_43 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/43.webp", 1920, 1080)
image e3f3-tr_44 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/44.webp", 1920, 1080)
image e3f3-tr_45 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/45.webp", 1920, 1080)
image e3f3-tr_46 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/46.webp", 1920, 1080)
image e3f3-tr_47 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/47.webp", 1920, 1080)
image e3f3-tr_48 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/48.webp", 1920, 1080)
image e3f3-tr_49 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/49.webp", 1920, 1080)
image e3f3-tr_50 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/50.webp", 1920, 1080)
image e3f3-tr_51 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/51.webp", 1920, 1080)
image e3f3-tr_52 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/52.webp", 1920, 1080)
image e3f3-tr_53 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/53.webp", 1920, 1080)
image e3f3-tr_54 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/54.webp", 1920, 1080)
image e3f3-tr_55 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/55.webp", 1920, 1080)
image e3f3-tr_56 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/56.webp", 1920, 1080)
image e3f3-tr_57 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/57.webp", 1920, 1080)
image e3f3-tr_58 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/58.webp", 1920, 1080)
image e3f3-tr_59 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/59.webp", 1920, 1080)
image e3f3-tr_60 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/60.webp", 1920, 1080)
image e3f3-tr_61 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/61.webp", 1920, 1080)
image e3f3-tr_62 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/62.webp", 1920, 1080)
image e3f3-tr_63 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/63.webp", 1920, 1080)
image e3f3-tr_64 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/64.webp", 1920, 1080)
image e3f3-tr_65 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/65.webp", 1920, 1080)
image e3f3-tr_66 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/66.webp", 1920, 1080)
image e3f3-tr_67 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/67.webp", 1920, 1080)
image e3f3-tr_68 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/68.webp", 1920, 1080)
image e3f3-tr_69 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/69.webp", 1920, 1080)
image e3f3-tr_70 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/70.webp", 1920, 1080)
image e3f3-tr_71 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/71.webp", 1920, 1080)
image e3f3-tr_72 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/72.webp", 1920, 1080)
image e3f3-tr_73 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/73.webp", 1920, 1080)
image e3f3-tr_74 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/74.webp", 1920, 1080)
image e3f3-tr_75 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/75.webp", 1920, 1080)
image e3f3-tr_76 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/76.webp", 1920, 1080)
image e3f3-tr_77 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/77.webp", 1920, 1080)
image e3f3-tr_78 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/78.webp", 1920, 1080)
image e3f3-tr_79 = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/79.webp", 1920, 1080)

# Animations #
# Static
image e3f3_tr_tracy_blink1:
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3f3-doggy1 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/doggy1.webm")
image e3f3-doggy2 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/doggy2.webm")
image e3f3-doggy3 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/doggy3.webm")
image e3f3-doggy4 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/doggy4.webm")
image e3f3-doggy5 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/doggy5.webm")
image e3f3-faceoff1 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff1.webm")
image e3f3-faceoff2 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff2.webm")
image e3f3-faceoff3 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff3.webm")
image e3f3-faceoff4 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff4.webm")
image e3f3-faceoff5 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff5.webm")
image e3f3-faceoff6 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/faceoff6.webm")
image e3f3-handjob1 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/handjob1.webm")
image e3f3-handjob2 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/handjob2.webm")
image e3f3-handjob3 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/handjob3.webm")
image e3f3-missionary1 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/missionary1.webm")
image e3f3-missionary2 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/missionary2.webm")
image e3f3-missionary3 = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/missionary3.webm")

# Censored
# Images
image e3f3-tr_33_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/33.webp", 1920, 1080)
image e3f3-tr_34_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/34.webp", 1920, 1080)
image e3f3-tr_35_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/35.webp", 1920, 1080)
image e3f3-tr_36_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/36.webp", 1920, 1080)
image e3f3-tr_37_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/37.webp", 1920, 1080)
image e3f3-tr_38_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/38.webp", 1920, 1080)
image e3f3-tr_41_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/41.webp", 1920, 1080)
image e3f3-tr_44_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/44.webp", 1920, 1080)
image e3f3-tr_46_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/46.webp", 1920, 1080)
image e3f3-tr_47_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/47.webp", 1920, 1080)
image e3f3-tr_48_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/48.webp", 1920, 1080)
image e3f3-tr_49_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/49.webp", 1920, 1080)
image e3f3-tr_50_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/50.webp", 1920, 1080)
image e3f3-tr_51_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/51.webp", 1920, 1080)
image e3f3-tr_52_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/52.webp", 1920, 1080)
image e3f3-tr_53_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/53.webp", 1920, 1080)
image e3f3-tr_54_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/54.webp", 1920, 1080)
image e3f3-tr_55_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/55.webp", 1920, 1080)
image e3f3-tr_56_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/56.webp", 1920, 1080)
image e3f3-tr_57_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/57.webp", 1920, 1080)
image e3f3-tr_58_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/58.webp", 1920, 1080)
image e3f3-tr_59_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/59.webp", 1920, 1080)
image e3f3-tr_60_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/60.webp", 1920, 1080)
image e3f3-tr_61_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/61.webp", 1920, 1080)
image e3f3-tr_62_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/62.webp", 1920, 1080)
image e3f3-tr_63_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/63.webp", 1920, 1080)
image e3f3-tr_64_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/64.webp", 1920, 1080)
image e3f3-tr_65_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/65.webp", 1920, 1080)
image e3f3-tr_66_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/66.webp", 1920, 1080)
image e3f3-tr_67_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/67.webp", 1920, 1080)
image e3f3-tr_68_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/68.webp", 1920, 1080)
image e3f3-tr_70_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/70.webp", 1920, 1080)
image e3f3-tr_71_cen = im.Scale("season1/episode3/images/freeroam3/images/tracy_sex1/censored/71.webp", 1920, 1080)

# Videos
image e3f3-doggy1_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/doggy1.webm")
image e3f3-doggy2_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/doggy2.webm")
image e3f3-doggy3_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/doggy3.webm")
image e3f3-doggy4_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/doggy4.webm")
image e3f3-doggy5_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/doggy5.webm")
image e3f3-faceoff1_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff1.webm")
image e3f3-faceoff2_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff2.webm")
image e3f3-faceoff3_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff3.webm")
image e3f3-faceoff4_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff4.webm")
image e3f3-faceoff5_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff5.webm")
image e3f3-faceoff6_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/faceoff6.webm")
image e3f3-handjob1_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/handjob1.webm")
image e3f3-handjob2_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/handjob2.webm")
image e3f3-handjob3_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/handjob3.webm")
image e3f3-missionary1_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/missionary1.webm")
image e3f3-missionary2_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/missionary2.webm")
image e3f3-missionary3_cen = Movie(play="season1/episode3/images/freeroam3/images/tracy_sex1/censored/missionary3.webm")
