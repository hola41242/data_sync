
# Scene 8 images ###############################################################
# Images

image e3s8-01 = im.Scale("season1/episode3/images/scene8/1.webp", 1920, 1080)
image e3s8-02 = im.Scale("season1/episode3/images/scene8/2.webp", 1920, 1080)
image e3s8-03 = im.Scale("season1/episode3/images/scene8/3.webp", 1920, 1080)
image e3s8-04 = im.Scale("season1/episode3/images/scene8/4.webp", 1920, 1080)
image e3s8-05 = im.Scale("season1/episode3/images/scene8/5.webp", 1920, 1080)
image e3s8-06 = im.Scale("season1/episode3/images/scene8/6.webp", 1920, 1080)
image e3s8-07 = im.Scale("season1/episode3/images/scene8/7.webp", 1920, 1080)
image e3s8-08 = im.Scale("season1/episode3/images/scene8/8.webp", 1920, 1080)
image e3s8-09 = im.Scale("season1/episode3/images/scene8/9.webp", 1920, 1080)
image e3s8-10 = im.Scale("season1/episode3/images/scene8/10.webp", 1920, 1080)
image e3s8-11 = im.Scale("season1/episode3/images/scene8/11.webp", 1920, 1080)
image e3s8-12 = im.Scale("season1/episode3/images/scene8/12.webp", 1920, 1080)
image e3s8-13 = im.Scale("season1/episode3/images/scene8/13.webp", 1920, 1080)
image e3s8-14 = im.Scale("season1/episode3/images/scene8/14.webp", 1920, 1080)
image e3s8-15 = im.Scale("season1/episode3/images/scene8/15.webp", 1920, 1080)
image e3s8-16 = im.Scale("season1/episode3/images/scene8/16.webp", 1920, 1080)
image e3s8-17 = im.Scale("season1/episode3/images/scene8/17.webp", 1920, 1080)
image e3s8-18 = im.Scale("season1/episode3/images/scene8/18.webp", 1920, 1080)
image e3s8-19 = im.Scale("season1/episode3/images/scene8/19.webp", 1920, 1080)
image e3s8-20 = im.Scale("season1/episode3/images/scene8/20.webp", 1920, 1080)
image e3s8-21 = im.Scale("season1/episode3/images/scene8/21.webp", 1920, 1080)
image e3s8-22 = im.Scale("season1/episode3/images/scene8/22.webp", 1920, 1080)
image e3s8-23 = im.Scale("season1/episode3/images/scene8/23.webp", 1920, 1080)
image e3s8-24 = im.Scale("season1/episode3/images/scene8/24.webp", 1920, 1080)
image e3s8-25 = im.Scale("season1/episode3/images/scene8/25.webp", 1920, 1080)
image e3s8-26 = im.Scale("season1/episode3/images/scene8/26.webp", 1920, 1080)
image e3s8-27 = im.Scale("season1/episode3/images/scene8/27.webp", 1920, 1080)
image e3s8-28 = im.Scale("season1/episode3/images/scene8/28.webp", 1920, 1080)
image e3s8-29 = im.Scale("season1/episode3/images/scene8/29.webp", 1920, 1080)
image e3s8-30 = im.Scale("season1/episode3/images/scene8/30.webp", 1920, 1080)
image e3s8-31 = im.Scale("season1/episode3/images/scene8/31.webp", 1920, 1080)
image e3s8-32 = im.Scale("season1/episode3/images/scene8/32.webp", 1920, 1080)
image e3s8-33 = im.Scale("season1/episode3/images/scene8/33.webp", 1920, 1080)
image e3s8-34 = im.Scale("season1/episode3/images/scene8/34.webp", 1920, 1080)
image e3s8-35 = im.Scale("season1/episode3/images/scene8/35.webp", 1920, 1080)
image e3s8-36 = im.Scale("season1/episode3/images/scene8/36.webp", 1920, 1080)
image e3s8-37 = im.Scale("season1/episode3/images/scene8/37.webp", 1920, 1080)
image e3s8-38 = im.Scale("season1/episode3/images/scene8/38.webp", 1920, 1080)
image e3s8-39 = im.Scale("season1/episode3/images/scene8/39.webp", 1920, 1080)
image e3s8-40 = im.Scale("season1/episode3/images/scene8/40.webp", 1920, 1080)
image e3s8-41 = im.Scale("season1/episode3/images/scene8/41.webp", 1920, 1080)
image e3s8-42 = im.Scale("season1/episode3/images/scene8/42.webp", 1920, 1080)
image e3s8-43 = im.Scale("season1/episode3/images/scene8/43.webp", 1920, 1080)
image e3s8-44 = im.Scale("season1/episode3/images/scene8/44.webp", 1920, 1080)
image e3s8-45 = im.Scale("season1/episode3/images/scene8/45.webp", 1920, 1080)
image e3s8-46 = im.Scale("season1/episode3/images/scene8/46.webp", 1920, 1080)
image e3s8-47 = im.Scale("season1/episode3/images/scene8/47.webp", 1920, 1080)
image e3s8-48 = im.Scale("season1/episode3/images/scene8/48.webp", 1920, 1080)
image e3s8-49 = im.Scale("season1/episode3/images/scene8/49.webp", 1920, 1080)
image e3s8-50 = im.Scale("season1/episode3/images/scene8/50.webp", 1920, 1080)

# Animations #
# Static
image e3s8_tracy_blink1:
    im.Scale("season1/episode3/images/scene8/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene8/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s8-doggy1 = Movie(play="season1/episode3/images/scene8/doggy1.webm")
image e3s8-doggy2 = Movie(play="season1/episode3/images/scene8/doggy2.webm")
image e3s8-doggy3 = Movie(play="season1/episode3/images/scene8/doggy3.webm")
image e3s8-doggy4 = Movie(play="season1/episode3/images/scene8/doggy4.webm")
image e3s8-doggy5 = Movie(play="season1/episode3/images/scene8/doggy5.webm")
image e3s8-faceoff1 = Movie(play="season1/episode3/images/scene8/faceoff1.webm")
image e3s8-faceoff2 = Movie(play="season1/episode3/images/scene8/faceoff2.webm")
image e3s8-faceoff3 = Movie(play="season1/episode3/images/scene8/faceoff3.webm")
image e3s8-faceoff4 = Movie(play="season1/episode3/images/scene8/faceoff4.webm")
image e3s8-faceoff5 = Movie(play="season1/episode3/images/scene8/faceoff5.webm")
image e3s8-faceoff6 = Movie(play="season1/episode3/images/scene8/faceoff6.webm")
image e3s8-handjob1 = Movie(play="season1/episode3/images/scene8/handjob1.webm")
image e3s8-handjob2 = Movie(play="season1/episode3/images/scene8/handjob2.webm")
image e3s8-handjob3 = Movie(play="season1/episode3/images/scene8/handjob3.webm")
image e3s8-missionary1 = Movie(play="season1/episode3/images/scene8/missionary1.webm")
image e3s8-missionary2 = Movie(play="season1/episode3/images/scene8/missionary2.webm")
image e3s8-missionary3 = Movie(play="season1/episode3/images/scene8/missionary3.webm")

# Censored
# Images

# Animations
image e3s8-doggy1_cen = Movie(play="season1/episode3/images/scene8/censored/doggy1.webm")
image e3s8-doggy2_cen = Movie(play="season1/episode3/images/scene8/censored/doggy2.webm")
image e3s8-doggy3_cen = Movie(play="season1/episode3/images/scene8/censored/doggy3.webm")
image e3s8-doggy4_cen = Movie(play="season1/episode3/images/scene8/censored/doggy4.webm")
image e3s8-doggy5_cen = Movie(play="season1/episode3/images/scene8/censored/doggy5.webm")
image e3s8-faceoff1_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff1.webm")
image e3s8-faceoff2_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff2.webm")
image e3s8-faceoff3_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff3.webm")
image e3s8-faceoff4_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff4.webm")
image e3s8-faceoff5_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff5.webm")
image e3s8-faceoff6_cen = Movie(play="season1/episode3/images/scene8/censored/faceoff6.webm")
image e3s8-handjob1_cen = Movie(play="season1/episode3/images/scene8/censored/handjob1.webm")
image e3s8-handjob2_cen = Movie(play="season1/episode3/images/scene8/censored/handjob2.webm")
image e3s8-handjob3_cen = Movie(play="season1/episode3/images/scene8/censored/handjob3.webm")
image e3s8-missionary1_cen = Movie(play="season1/episode3/images/scene8/censored/missionary1.webm")
image e3s8-missionary2_cen = Movie(play="season1/episode3/images/scene8/censored/missionary2.webm")
image e3s8-missionary3_cen = Movie(play="season1/episode3/images/scene8/censored/missionary3.webm")
