
# Scene 28 images ###############################################################

image e3s28-01 = im.Scale("season1/episode3/images/scene28/1.webp", 1920, 1080)
image e3s28-02 = im.Scale("season1/episode3/images/scene28/2.webp", 1920, 1080)
image e3s28-03 = im.Scale("season1/episode3/images/scene28/3.webp", 1920, 1080)
image e3s28-04 = im.Scale("season1/episode3/images/scene28/4.webp", 1920, 1080)
image e3s28-05 = im.Scale("season1/episode3/images/scene28/5.webp", 1920, 1080)
image e3s28-06 = im.Scale("season1/episode3/images/scene28/6.webp", 1920, 1080)
image e3s28-07 = im.Scale("season1/episode3/images/scene28/7.webp", 1920, 1080)
image e3s28-08 = im.Scale("season1/episode3/images/scene28/8.webp", 1920, 1080)
image e3s28-09 = im.Scale("season1/episode3/images/scene28/9.webp", 1920, 1080)
image e3s28-10 = im.Scale("season1/episode3/images/scene28/10.webp", 1920, 1080)
image e3s28-11 = im.Scale("season1/episode3/images/scene28/11.webp", 1920, 1080)
image e3s28-12 = im.Scale("season1/episode3/images/scene28/12.webp", 1920, 1080)
image e3s28-13 = im.Scale("season1/episode3/images/scene28/13.webp", 1920, 1080)
image e3s28-14 = im.Scale("season1/episode3/images/scene28/14.webp", 1920, 1080)
image e3s28-15 = im.Scale("season1/episode3/images/scene28/15.webp", 1920, 1080)
image e3s28-16 = im.Scale("season1/episode3/images/scene28/16.webp", 1920, 1080)
image e3s28-17 = im.Scale("season1/episode3/images/scene28/17.webp", 1920, 1080)
image e3s28-18 = im.Scale("season1/episode3/images/scene28/18.webp", 1920, 1080)
image e3s28-19 = im.Scale("season1/episode3/images/scene28/19.webp", 1920, 1080)
image e3s28-20 = im.Scale("season1/episode3/images/scene28/20.webp", 1920, 1080)
image e3s28-21 = im.Scale("season1/episode3/images/scene28/21.webp", 1920, 1080)
image e3s28-22 = im.Scale("season1/episode3/images/scene28/22.webp", 1920, 1080)
image e3s28-23 = im.Scale("season1/episode3/images/scene28/23.webp", 1920, 1080)
image e3s28-24 = im.Scale("season1/episode3/images/scene28/24.webp", 1920, 1080)
image e3s28-25 = im.Scale("season1/episode3/images/scene28/25.webp", 1920, 1080)
image e3s28-26 = im.Scale("season1/episode3/images/scene28/26.webp", 1920, 1080)
image e3s28-27 = im.Scale("season1/episode3/images/scene28/27.webp", 1920, 1080)
image e3s28-28 = im.Scale("season1/episode3/images/scene28/28.webp", 1920, 1080)
image e3s28-29 = im.Scale("season1/episode3/images/scene28/29.webp", 1920, 1080)
image e3s28-30 = im.Scale("season1/episode3/images/scene28/30.webp", 1920, 1080)

image e3s28_joel_blink1:
    im.Scale("season1/episode3/images/scene28/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s28_joel_blink2:
    im.Scale("season1/episode3/images/scene28/joel_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s28_joel_blink3:
    im.Scale("season1/episode3/images/scene28/joel_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene28/joel_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
