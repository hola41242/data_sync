
# Scene 23 images ##############################################################

image e3s23-01 = im.Scale("season1/episode3/images/scene23/1.webp", 1920, 1080)
image e3s23-02 = im.Scale("season1/episode3/images/scene23/2.webp", 1920, 1080)
image e3s23-03 = im.Scale("season1/episode3/images/scene23/3.webp", 1920, 1080)
image e3s23-04 = im.Scale("season1/episode3/images/scene23/4.webp", 1920, 1080)
image e3s23-05 = im.Scale("season1/episode3/images/scene23/5.webp", 1920, 1080)
image e3s23-06 = im.Scale("season1/episode3/images/scene23/6.webp", 1920, 1080)
image e3s23-07 = im.Scale("season1/episode3/images/scene23/7.webp", 1920, 1080)
image e3s23-08 = im.Scale("season1/episode3/images/scene23/8.webp", 1920, 1080)
image e3s23-09 = im.Scale("season1/episode3/images/scene23/9.webp", 1920, 1080)
image e3s23-10 = im.Scale("season1/episode3/images/scene23/10.webp", 1920, 1080)
image e3s23-11 = im.Scale("season1/episode3/images/scene23/11.webp", 1920, 1080)
image e3s23-12 = im.Scale("season1/episode3/images/scene23/12.webp", 1920, 1080)
image e3s23-13 = im.Scale("season1/episode3/images/scene23/13.webp", 1920, 1080)
image e3s23-14 = im.Scale("season1/episode3/images/scene23/14.webp", 1920, 1080)
image e3s23-15 = im.Scale("season1/episode3/images/scene23/15.webp", 1920, 1080)
image e3s23-16 = im.Scale("season1/episode3/images/scene23/16.webp", 1920, 1080)
image e3s23-17 = im.Scale("season1/episode3/images/scene23/17.webp", 1920, 1080)
image e3s23-18 = im.Scale("season1/episode3/images/scene23/18.webp", 1920, 1080)
image e3s23-19 = im.Scale("season1/episode3/images/scene23/19.webp", 1920, 1080)
image e3s23-20 = im.Scale("season1/episode3/images/scene23/20.webp", 1920, 1080)
image e3s23-21 = im.Scale("season1/episode3/images/scene23/21.webp", 1920, 1080)
image e3s23-22 = im.Scale("season1/episode3/images/scene23/22.webp", 1920, 1080)
image e3s23-23 = im.Scale("season1/episode3/images/scene23/23.webp", 1920, 1080)
image e3s23-24 = im.Scale("season1/episode3/images/scene23/24.webp", 1920, 1080)
image e3s23-25 = im.Scale("season1/episode3/images/scene23/25.webp", 1920, 1080)
image e3s23-26 = im.Scale("season1/episode3/images/scene23/26.webp", 1920, 1080)
image e3s23-27 = im.Scale("season1/episode3/images/scene23/27.webp", 1920, 1080)

image e3s23_tracy_blink2:
    im.Scale("season1/episode3/images/scene23/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s23_tracy_blink3:
    im.Scale("season1/episode3/images/scene23/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene23/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
