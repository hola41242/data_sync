
# Scene 22 images ##############################################################

# Images
image e3s22-01 = im.Scale("season1/episode3/images/scene22/1.webp", 1920, 1080)
image e3s22-02 = im.Scale("season1/episode3/images/scene22/2.webp", 1920, 1080)
image e3s22-03 = im.Scale("season1/episode3/images/scene22/3.webp", 1920, 1080)
image e3s22-04 = im.Scale("season1/episode3/images/scene22/4.webp", 1920, 1080)
image e3s22-05 = im.Scale("season1/episode3/images/scene22/5.webp", 1920, 1080)
image e3s22-06 = im.Scale("season1/episode3/images/scene22/6.webp", 1920, 1080)
image e3s22-07 = im.Scale("season1/episode3/images/scene22/7.webp", 1920, 1080)
image e3s22-08 = im.Scale("season1/episode3/images/scene22/8.webp", 1920, 1080)
image e3s22-09 = im.Scale("season1/episode3/images/scene22/9.webp", 1920, 1080)
image e3s22-10 = im.Scale("season1/episode3/images/scene22/10.webp", 1920, 1080)
image e3s22-11 = im.Scale("season1/episode3/images/scene22/11.webp", 1920, 1080)
image e3s22-12 = im.Scale("season1/episode3/images/scene22/12.webp", 1920, 1080)
image e3s22-13 = im.Scale("season1/episode3/images/scene22/13.webp", 1920, 1080)
image e3s22-14 = im.Scale("season1/episode3/images/scene22/14.webp", 1920, 1080)
image e3s22-15 = im.Scale("season1/episode3/images/scene22/15.webp", 1920, 1080)
image e3s22-16 = im.Scale("season1/episode3/images/scene22/16.webp", 1920, 1080)
image e3s22-17 = im.Scale("season1/episode3/images/scene22/17.webp", 1920, 1080)
image e3s22-18 = im.Scale("season1/episode3/images/scene22/18.webp", 1920, 1080)
image e3s22-19 = im.Scale("season1/episode3/images/scene22/19.webp", 1920, 1080)
image e3s22-20 = im.Scale("season1/episode3/images/scene22/20.webp", 1920, 1080)
image e3s22-21 = im.Scale("season1/episode3/images/scene22/21.webp", 1920, 1080)
image e3s22-22 = im.Scale("season1/episode3/images/scene22/22.webp", 1920, 1080)
image e3s22-23 = im.Scale("season1/episode3/images/scene22/23.webp", 1920, 1080)
image e3s22-24 = im.Scale("season1/episode3/images/scene22/24.webp", 1920, 1080)
image e3s22-25 = im.Scale("season1/episode3/images/scene22/25.webp", 1920, 1080)
image e3s22-26 = im.Scale("season1/episode3/images/scene22/26.webp", 1920, 1080)
image e3s22-27 = im.Scale("season1/episode3/images/scene22/27.webp", 1920, 1080)
image e3s22-28 = im.Scale("season1/episode3/images/scene22/28.webp", 1920, 1080)
image e3s22-29 = im.Scale("season1/episode3/images/scene22/29.webp", 1920, 1080)
image e3s22-30 = im.Scale("season1/episode3/images/scene22/30.webp", 1920, 1080)
image e3s22-31 = im.Scale("season1/episode3/images/scene22/31.webp", 1920, 1080)
image e3s22-32 = im.Scale("season1/episode3/images/scene22/32.webp", 1920, 1080)
image e3s22-33 = im.Scale("season1/episode3/images/scene22/33.webp", 1920, 1080)
image e3s22-34 = im.Scale("season1/episode3/images/scene22/34.webp", 1920, 1080)
image e3s22-35 = im.Scale("season1/episode3/images/scene22/35.webp", 1920, 1080)
image e3s22-36 = im.Scale("season1/episode3/images/scene22/36.webp", 1920, 1080)
image e3s22-37 = im.Scale("season1/episode3/images/scene22/37.webp", 1920, 1080)
image e3s22-38 = im.Scale("season1/episode3/images/scene22/38.webp", 1920, 1080)
image e3s22-39 = im.Scale("season1/episode3/images/scene22/39.webp", 1920, 1080)
image e3s22-40 = im.Scale("season1/episode3/images/scene22/40.webp", 1920, 1080)
image e3s22-41 = im.Scale("season1/episode3/images/scene22/41.webp", 1920, 1080)
image e3s22-42 = im.Scale("season1/episode3/images/scene22/42.webp", 1920, 1080)
image e3s22-43 = im.Scale("season1/episode3/images/scene22/43.webp", 1920, 1080)
image e3s22-44 = im.Scale("season1/episode3/images/scene22/44.webp", 1920, 1080)
image e3s22-45 = im.Scale("season1/episode3/images/scene22/45.webp", 1920, 1080)
image e3s22-46 = im.Scale("season1/episode3/images/scene22/46.webp", 1920, 1080)
image e3s22-47 = im.Scale("season1/episode3/images/scene22/47.webp", 1920, 1080)
image e3s22-48 = im.Scale("season1/episode3/images/scene22/48.webp", 1920, 1080)
image e3s22-49 = im.Scale("season1/episode3/images/scene22/49.webp", 1920, 1080)
image e3s22-50 = im.Scale("season1/episode3/images/scene22/50.webp", 1920, 1080)
image e3s22-51 = im.Scale("season1/episode3/images/scene22/51.webp", 1920, 1080)
image e3s22-52 = im.Scale("season1/episode3/images/scene22/52.webp", 1920, 1080)
image e3s22-53 = im.Scale("season1/episode3/images/scene22/53.webp", 1920, 1080)
image e3s22-54 = im.Scale("season1/episode3/images/scene22/54.webp", 1920, 1080)
image e3s22-55 = im.Scale("season1/episode3/images/scene22/55.webp", 1920, 1080)
image e3s22-56 = im.Scale("season1/episode3/images/scene22/56.webp", 1920, 1080)
image e3s22-57 = im.Scale("season1/episode3/images/scene22/57.webp", 1920, 1080)
image e3s22-58 = im.Scale("season1/episode3/images/scene22/58.webp", 1920, 1080)
image e3s22-59 = im.Scale("season1/episode3/images/scene22/59.webp", 1920, 1080)
image e3s22-60 = im.Scale("season1/episode3/images/scene22/60.webp", 1920, 1080)

# Animations #
# Static
image e3s22_sadie_blink1:
    im.Scale("season1/episode3/images/scene22/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s22_sadie_blink2:
    im.Scale("season1/episode3/images/scene22/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s22_sadie_blink3:
    im.Scale("season1/episode3/images/scene22/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s22_sadie_blink4:
    im.Scale("season1/episode3/images/scene22/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene22/sadie_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s22-blowjob1 = Movie(play="season1/episode3/images/scene22/blowjob1.webm")
image e3s22-blowjob2 = Movie(play="season1/episode3/images/scene22/blowjob2.webm")
image e3s22-blowjob3 = Movie(play="season1/episode3/images/scene22/blowjob3.webm")
image e3s22-blowjob4 = Movie(play="season1/episode3/images/scene22/blowjob4.webm")
image e3s22-blowjob5 = Movie(play="season1/episode3/images/scene22/blowjob5.webm")
image e3s22-blowjob6 = Movie(play="season1/episode3/images/scene22/blowjob6.webm")
image e3s22-blowjob7 = Movie(play="season1/episode3/images/scene22/blowjob7.webm")
image e3s22-handjob1 = Movie(play="season1/episode3/images/scene22/handjob1.webm")
image e3s22-handjob2 = Movie(play="season1/episode3/images/scene22/handjob2.webm")
image e3s22-handjob3 = Movie(play="season1/episode3/images/scene22/handjob3.webm")
image e3s22-handjob4 = Movie(play="season1/episode3/images/scene22/handjob4.webm")

# Censored
# Images
image e3s22-35_cen = im.Scale("season1/episode3/images/scene22/censored/35.webp", 1920, 1080)
image e3s22-36_cen = im.Scale("season1/episode3/images/scene22/censored/36.webp", 1920, 1080)
image e3s22-37_cen = im.Scale("season1/episode3/images/scene22/censored/37.webp", 1920, 1080)
image e3s22-38_cen = im.Scale("season1/episode3/images/scene22/censored/38.webp", 1920, 1080)
image e3s22-39_cen = im.Scale("season1/episode3/images/scene22/censored/39.webp", 1920, 1080)
image e3s22-40_cen = im.Scale("season1/episode3/images/scene22/censored/40.webp", 1920, 1080)
image e3s22-41_cen = im.Scale("season1/episode3/images/scene22/censored/41.webp", 1920, 1080)
image e3s22-43_cen = im.Scale("season1/episode3/images/scene22/censored/43.webp", 1920, 1080)
image e3s22-44_cen = im.Scale("season1/episode3/images/scene22/censored/44.webp", 1920, 1080)
image e3s22-46_cen = im.Scale("season1/episode3/images/scene22/censored/46.webp", 1920, 1080)
image e3s22-60_cen = im.Scale("season1/episode3/images/scene22/censored/60.webp", 1920, 1080)

# Animations
image e3s22-blowjob1_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob1.webm")
image e3s22-blowjob2_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob2.webm")
image e3s22-blowjob3_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob3.webm")
image e3s22-blowjob4_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob4.webm")
image e3s22-blowjob5_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob5.webm")
image e3s22-blowjob6_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob6.webm")
image e3s22-blowjob7_cen = Movie(play="season1/episode3/images/scene22/censored/blowjob7.webm")
image e3s22-handjob1_cen = Movie(play="season1/episode3/images/scene22/censored/handjob1.webm")
image e3s22-handjob2_cen = Movie(play="season1/episode3/images/scene22/censored/handjob2.webm")
image e3s22-handjob3_cen = Movie(play="season1/episode3/images/scene22/censored/handjob3.webm")
image e3s22-handjob4_cen = Movie(play="season1/episode3/images/scene22/censored/handjob4.webm")
