
# Scene 4 images ###############################################################

image e3s4-01 = im.Scale("season1/episode3/images/scene4/1.webp", 1920, 1080)
image e3s4-02 = im.Scale("season1/episode3/images/scene4/2.webp", 1920, 1080)
image e3s4-03 = im.Scale("season1/episode3/images/scene4/3.webp", 1920, 1080)
image e3s4-04 = im.Scale("season1/episode3/images/scene4/4.webp", 1920, 1080)
image e3s4-05 = im.Scale("season1/episode3/images/scene4/5.webp", 1920, 1080)
image e3s4-06 = im.Scale("season1/episode3/images/scene4/6.webp", 1920, 1080)
image e3s4-07 = im.Scale("season1/episode3/images/scene4/7.webp", 1920, 1080)
image e3s4-08 = im.Scale("season1/episode3/images/scene4/8.webp", 1920, 1080)
image e3s4-09 = im.Scale("season1/episode3/images/scene4/9.webp", 1920, 1080)
image e3s4-10 = im.Scale("season1/episode3/images/scene4/10.webp", 1920, 1080)
image e3s4-11 = im.Scale("season1/episode3/images/scene4/11.webp", 1920, 1080)
image e3s4-12 = im.Scale("season1/episode3/images/scene4/12.webp", 1920, 1080)
image e3s4-13 = im.Scale("season1/episode3/images/scene4/13.webp", 1920, 1080)
image e3s4-14 = im.Scale("season1/episode3/images/scene4/14.webp", 1920, 1080)
image e3s4-15 = im.Scale("season1/episode3/images/scene4/15.webp", 1920, 1080)
image e3s4-16 = im.Scale("season1/episode3/images/scene4/16.webp", 1920, 1080)
image e3s4-17 = im.Scale("season1/episode3/images/scene4/17.webp", 1920, 1080)
image e3s4-18 = im.Scale("season1/episode3/images/scene4/18.webp", 1920, 1080)
image e3s4-19 = im.Scale("season1/episode3/images/scene4/19.webp", 1920, 1080)
image e3s4-20 = im.Scale("season1/episode3/images/scene4/20.webp", 1920, 1080)
image e3s4-21 = im.Scale("season1/episode3/images/scene4/21.webp", 1920, 1080)
image e3s4-22 = im.Scale("season1/episode3/images/scene4/22.webp", 1920, 1080)
image e3s4-23 = im.Scale("season1/episode3/images/scene4/23.webp", 1920, 1080)
image e3s4-24 = im.Scale("season1/episode3/images/scene4/24.webp", 1920, 1080)
image e3s4-25 = im.Scale("season1/episode3/images/scene4/25.webp", 1920, 1080)
image e3s4-26 = im.Scale("season1/episode3/images/scene4/26.webp", 1920, 1080)
image e3s4-27 = im.Scale("season1/episode3/images/scene4/27.webp", 1920, 1080)
image e3s4-28 = im.Scale("season1/episode3/images/scene4/28.webp", 1920, 1080)
image e3s4-29 = im.Scale("season1/episode3/images/scene4/29.webp", 1920, 1080)
image e3s4-30 = im.Scale("season1/episode3/images/scene4/30.webp", 1920, 1080)
image e3s4-31 = im.Scale("season1/episode3/images/scene4/31.webp", 1920, 1080)
image e3s4-32 = im.Scale("season1/episode3/images/scene4/32.webp", 1920, 1080)
image e3s4-33 = im.Scale("season1/episode3/images/scene4/33.webp", 1920, 1080)
image e3s4-34 = im.Scale("season1/episode3/images/scene4/34.webp", 1920, 1080)
image e3s4-35 = im.Scale("season1/episode3/images/scene4/35.webp", 1920, 1080)
image e3s4-36 = im.Scale("season1/episode3/images/scene4/36.webp", 1920, 1080)
image e3s4-37 = im.Scale("season1/episode3/images/scene4/37.webp", 1920, 1080)
image e3s4-38 = im.Scale("season1/episode3/images/scene4/38.webp", 1920, 1080)
image e3s4-39 = im.Scale("season1/episode3/images/scene4/39.webp", 1920, 1080)
image e3s4-40 = im.Scale("season1/episode3/images/scene4/40.webp", 1920, 1080)
image e3s4-41 = im.Scale("season1/episode3/images/scene4/41.webp", 1920, 1080)
image e3s4-42 = im.Scale("season1/episode3/images/scene4/42.webp", 1920, 1080)
image e3s4-43 = im.Scale("season1/episode3/images/scene4/43.webp", 1920, 1080)
image e3s4-44 = im.Scale("season1/episode3/images/scene4/44.webp", 1920, 1080)
image e3s4-45 = im.Scale("season1/episode3/images/scene4/45.webp", 1920, 1080)
image e3s4-46 = im.Scale("season1/episode3/images/scene4/46.webp", 1920, 1080)
image e3s4-47 = im.Scale("season1/episode3/images/scene4/47.webp", 1920, 1080)
image e3s4-48 = im.Scale("season1/episode3/images/scene4/48.webp", 1920, 1080)
image e3s4-49 = im.Scale("season1/episode3/images/scene4/49.webp", 1920, 1080)
image e3s4-50 = im.Scale("season1/episode3/images/scene4/50.webp", 1920, 1080)
image e3s4-51 = im.Scale("season1/episode3/images/scene4/51.webp", 1920, 1080)
image e3s4-52 = im.Scale("season1/episode3/images/scene4/52.webp", 1920, 1080)
image e3s4-53 = im.Scale("season1/episode3/images/scene4/53.webp", 1920, 1080)
image e3s4-54 = im.Scale("season1/episode3/images/scene4/54.webp", 1920, 1080)
image e3s4-55 = im.Scale("season1/episode3/images/scene4/55.webp", 1920, 1080)
image e3s4-56 = im.Scale("season1/episode3/images/scene4/56.webp", 1920, 1080)
image e3s4-57 = im.Scale("season1/episode3/images/scene4/57.webp", 1920, 1080)

image e3s4_spencer_blink1:
    im.Scale("season1/episode3/images/scene4/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/spencer_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s4_mike_blink1:
    im.Scale("season1/episode3/images/scene4/mike_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene4/mike_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
