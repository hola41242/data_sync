
# Scene 29 images ###############################################################

image e3s29-01 = im.Scale("season1/episode3/images/scene29/1.webp", 1920, 1080)
image e3s29-02 = im.Scale("season1/episode3/images/scene29/2.webp", 1920, 1080)
image e3s29-03 = im.Scale("season1/episode3/images/scene29/3.webp", 1920, 1080)
image e3s29-04 = im.Scale("season1/episode3/images/scene29/4.webp", 1920, 1080)
image e3s29-05 = im.Scale("season1/episode3/images/scene29/5.webp", 1920, 1080)
image e3s29-06 = im.Scale("season1/episode3/images/scene29/6.webp", 1920, 1080)
image e3s29-07 = im.Scale("season1/episode3/images/scene29/7.webp", 1920, 1080)
image e3s29-08 = im.Scale("season1/episode3/images/scene29/8.webp", 1920, 1080)
image e3s29-09 = im.Scale("season1/episode3/images/scene29/9.webp", 1920, 1080)
image e3s29-10 = im.Scale("season1/episode3/images/scene29/10.webp", 1920, 1080)
image e3s29-11 = im.Scale("season1/episode3/images/scene29/11.webp", 1920, 1080)
image e3s29-12 = im.Scale("season1/episode3/images/scene29/12.webp", 1920, 1080)
image e3s29-13 = im.Scale("season1/episode3/images/scene29/13.webp", 1920, 1080)
image e3s29-14 = im.Scale("season1/episode3/images/scene29/14.webp", 1920, 1080)
image e3s29-15 = im.Scale("season1/episode3/images/scene29/15.webp", 1920, 1080)
image e3s29-16 = im.Scale("season1/episode3/images/scene29/16.webp", 1920, 1080)
image e3s29-17 = im.Scale("season1/episode3/images/scene29/17.webp", 1920, 1080)
image e3s29-18 = im.Scale("season1/episode3/images/scene29/18.webp", 1920, 1080)
image e3s29-19 = im.Scale("season1/episode3/images/scene29/19.webp", 1920, 1080)
image e3s29-20 = im.Scale("season1/episode3/images/scene29/20.webp", 1920, 1080)
image e3s29-21 = im.Scale("season1/episode3/images/scene29/21.webp", 1920, 1080)
image e3s29-22 = im.Scale("season1/episode3/images/scene29/22.webp", 1920, 1080)
image e3s29-23 = im.Scale("season1/episode3/images/scene29/23.webp", 1920, 1080)
image e3s29-24 = im.Scale("season1/episode3/images/scene29/24.webp", 1920, 1080)
image e3s29-25 = im.Scale("season1/episode3/images/scene29/25.webp", 1920, 1080)
image e3s29-26 = im.Scale("season1/episode3/images/scene29/26.webp", 1920, 1080)
image e3s29-27 = im.Scale("season1/episode3/images/scene29/27.webp", 1920, 1080)

image e3s29_mc_blink1:
    im.Scale("season1/episode3/images/scene29/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s29_olivia_blink1:
    im.Scale("season1/episode3/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s29_olivia_blink2:
    im.Scale("season1/episode3/images/scene29/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s29_olivia_blink3:
    im.Scale("season1/episode3/images/scene29/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene29/olivia_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
