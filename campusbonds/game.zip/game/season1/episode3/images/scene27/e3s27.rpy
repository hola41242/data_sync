
# Scene 27 images ##############################################################

# Images
image e3s27-01 = im.Scale("season1/episode3/images/scene27/1.webp", 1920, 1080)
image e3s27-02 = im.Scale("season1/episode3/images/scene27/2.webp", 1920, 1080)
image e3s27-03 = im.Scale("season1/episode3/images/scene27/3.webp", 1920, 1080)
image e3s27-04 = im.Scale("season1/episode3/images/scene27/4.webp", 1920, 1080)
image e3s27-05 = im.Scale("season1/episode3/images/scene27/5.webp", 1920, 1080)
image e3s27-06 = im.Scale("season1/episode3/images/scene27/6.webp", 1920, 1080)
image e3s27-07 = im.Scale("season1/episode3/images/scene27/7.webp", 1920, 1080)
image e3s27-08 = im.Scale("season1/episode3/images/scene27/8.webp", 1920, 1080)
image e3s27-09 = im.Scale("season1/episode3/images/scene27/9.webp", 1920, 1080)
image e3s27-10 = im.Scale("season1/episode3/images/scene27/10.webp", 1920, 1080)
image e3s27-11 = im.Scale("season1/episode3/images/scene27/11.webp", 1920, 1080)
image e3s27-12 = im.Scale("season1/episode3/images/scene27/12.webp", 1920, 1080)
image e3s27-13 = im.Scale("season1/episode3/images/scene27/13.webp", 1920, 1080)
image e3s27-14 = im.Scale("season1/episode3/images/scene27/14.webp", 1920, 1080)
image e3s27-15 = im.Scale("season1/episode3/images/scene27/15.webp", 1920, 1080)
image e3s27-16 = im.Scale("season1/episode3/images/scene27/16.webp", 1920, 1080)
image e3s27-17 = im.Scale("season1/episode3/images/scene27/17.webp", 1920, 1080)
image e3s27-18 = im.Scale("season1/episode3/images/scene27/18.webp", 1920, 1080)
image e3s27-19 = im.Scale("season1/episode3/images/scene27/19.webp", 1920, 1080)
image e3s27-20 = im.Scale("season1/episode3/images/scene27/20.webp", 1920, 1080)
image e3s27-21 = im.Scale("season1/episode3/images/scene27/21.webp", 1920, 1080)
image e3s27-22 = im.Scale("season1/episode3/images/scene27/22.webp", 1920, 1080)
image e3s27-23 = im.Scale("season1/episode3/images/scene27/23.webp", 1920, 1080)
image e3s27-24 = im.Scale("season1/episode3/images/scene27/24.webp", 1920, 1080)
image e3s27-25 = im.Scale("season1/episode3/images/scene27/25.webp", 1920, 1080)
image e3s27-26 = im.Scale("season1/episode3/images/scene27/26.webp", 1920, 1080)
image e3s27-27 = im.Scale("season1/episode3/images/scene27/27.webp", 1920, 1080)
image e3s27-28 = im.Scale("season1/episode3/images/scene27/28.webp", 1920, 1080)
image e3s27-29 = im.Scale("season1/episode3/images/scene27/29.webp", 1920, 1080)
image e3s27-30 = im.Scale("season1/episode3/images/scene27/30.webp", 1920, 1080)
image e3s27-31 = im.Scale("season1/episode3/images/scene27/31.webp", 1920, 1080)
image e3s27-32 = im.Scale("season1/episode3/images/scene27/32.webp", 1920, 1080)
image e3s27-33 = im.Scale("season1/episode3/images/scene27/33.webp", 1920, 1080)
image e3s27-34 = im.Scale("season1/episode3/images/scene27/34.webp", 1920, 1080)
image e3s27-35 = im.Scale("season1/episode3/images/scene27/35.webp", 1920, 1080)
image e3s27-36 = im.Scale("season1/episode3/images/scene27/36.webp", 1920, 1080)
image e3s27-37 = im.Scale("season1/episode3/images/scene27/37.webp", 1920, 1080)
image e3s27-38 = im.Scale("season1/episode3/images/scene27/38.webp", 1920, 1080)
image e3s27-39 = im.Scale("season1/episode3/images/scene27/39.webp", 1920, 1080)
image e3s27-40 = im.Scale("season1/episode3/images/scene27/40.webp", 1920, 1080)
image e3s27-41 = im.Scale("season1/episode3/images/scene27/41.webp", 1920, 1080)
image e3s27-42 = im.Scale("season1/episode3/images/scene27/42.webp", 1920, 1080)
image e3s27-43 = im.Scale("season1/episode3/images/scene27/43.webp", 1920, 1080)
image e3s27-44 = im.Scale("season1/episode3/images/scene27/44.webp", 1920, 1080)
image e3s27-45 = im.Scale("season1/episode3/images/scene27/45.webp", 1920, 1080)
image e3s27-46 = im.Scale("season1/episode3/images/scene27/46.webp", 1920, 1080)
image e3s27-47 = im.Scale("season1/episode3/images/scene27/47.webp", 1920, 1080)
image e3s27-48 = im.Scale("season1/episode3/images/scene27/48.webp", 1920, 1080)
image e3s27-49 = im.Scale("season1/episode3/images/scene27/49.webp", 1920, 1080)
image e3s27-50 = im.Scale("season1/episode3/images/scene27/50.webp", 1920, 1080)
image e3s27-51 = im.Scale("season1/episode3/images/scene27/51.webp", 1920, 1080)
image e3s27-52 = im.Scale("season1/episode3/images/scene27/52.webp", 1920, 1080)
image e3s27-53 = im.Scale("season1/episode3/images/scene27/53.webp", 1920, 1080)
image e3s27-54 = im.Scale("season1/episode3/images/scene27/54.webp", 1920, 1080)
image e3s27-55 = im.Scale("season1/episode3/images/scene27/55.webp", 1920, 1080)
image e3s27-56 = im.Scale("season1/episode3/images/scene27/56.webp", 1920, 1080)
image e3s27-57 = im.Scale("season1/episode3/images/scene27/57.webp", 1920, 1080)
image e3s27-58 = im.Scale("season1/episode3/images/scene27/58.webp", 1920, 1080)
image e3s27-59 = im.Scale("season1/episode3/images/scene27/59.webp", 1920, 1080)
image e3s27-60 = im.Scale("season1/episode3/images/scene27/60.webp", 1920, 1080)
image e3s27-61 = im.Scale("season1/episode3/images/scene27/61.webp", 1920, 1080)
image e3s27-62 = im.Scale("season1/episode3/images/scene27/62.webp", 1920, 1080)
image e3s27-63 = im.Scale("season1/episode3/images/scene27/63.webp", 1920, 1080)
image e3s27-64 = im.Scale("season1/episode3/images/scene27/64.webp", 1920, 1080)
image e3s27-65 = im.Scale("season1/episode3/images/scene27/65.webp", 1920, 1080)
image e3s27-66 = im.Scale("season1/episode3/images/scene27/66.webp", 1920, 1080)
image e3s27-67 = im.Scale("season1/episode3/images/scene27/67.webp", 1920, 1080)
image e3s27-68 = im.Scale("season1/episode3/images/scene27/68.webp", 1920, 1080)
image e3s27-69 = im.Scale("season1/episode3/images/scene27/69.webp", 1920, 1080)
image e3s27-70 = im.Scale("season1/episode3/images/scene27/70.webp", 1920, 1080)
image e3s27-71 = im.Scale("season1/episode3/images/scene27/71.webp", 1920, 1080)
image e3s27-72 = im.Scale("season1/episode3/images/scene27/72.webp", 1920, 1080)
image e3s27-73 = im.Scale("season1/episode3/images/scene27/73.webp", 1920, 1080)
image e3s27-74 = im.Scale("season1/episode3/images/scene27/74.webp", 1920, 1080)
image e3s27-75 = im.Scale("season1/episode3/images/scene27/75.webp", 1920, 1080)
image e3s27-76 = im.Scale("season1/episode3/images/scene27/76.webp", 1920, 1080)
image e3s27-77 = im.Scale("season1/episode3/images/scene27/77.webp", 1920, 1080)
image e3s27-78 = im.Scale("season1/episode3/images/scene27/78.webp", 1920, 1080)

image e3s27_joel_blink1:
    im.Scale("season1/episode3/images/scene27/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene27/joel_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
