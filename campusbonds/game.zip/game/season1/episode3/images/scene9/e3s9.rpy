
# Scene 9 images ###############################################################

# Images Tiffany
image e3s9-01 = im.Scale("season1/episode3/images/scene9/1.webp", 1920, 1080)
image e3s9-02 = im.Scale("season1/episode3/images/scene9/2.webp", 1920, 1080)
image e3s9-03 = im.Scale("season1/episode3/images/scene9/3.webp", 1920, 1080)
image e3s9-04 = im.Scale("season1/episode3/images/scene9/4.webp", 1920, 1080)
image e3s9-05 = im.Scale("season1/episode3/images/scene9/5.webp", 1920, 1080)
image e3s9-06 = im.Scale("season1/episode3/images/scene9/6.webp", 1920, 1080)
image e3s9-07 = im.Scale("season1/episode3/images/scene9/7.webp", 1920, 1080)
image e3s9-08 = im.Scale("season1/episode3/images/scene9/8.webp", 1920, 1080)
image e3s9-09 = im.Scale("season1/episode3/images/scene9/9.webp", 1920, 1080)
image e3s9-10 = im.Scale("season1/episode3/images/scene9/10.webp", 1920, 1080)
image e3s9-11 = im.Scale("season1/episode3/images/scene9/11.webp", 1920, 1080)
image e3s9-12 = im.Scale("season1/episode3/images/scene9/12.webp", 1920, 1080)
image e3s9-13 = im.Scale("season1/episode3/images/scene9/13.webp", 1920, 1080)
image e3s9-14 = im.Scale("season1/episode3/images/scene9/14.webp", 1920, 1080)
image e3s9-15 = im.Scale("season1/episode3/images/scene9/15.webp", 1920, 1080)
image e3s9-16 = im.Scale("season1/episode3/images/scene9/16.webp", 1920, 1080)
image e3s9-17 = im.Scale("season1/episode3/images/scene9/17.webp", 1920, 1080)
image e3s9-18 = im.Scale("season1/episode3/images/scene9/18.webp", 1920, 1080)
image e3s9-19 = im.Scale("season1/episode3/images/scene9/19.webp", 1920, 1080)
image e3s9-20 = im.Scale("season1/episode3/images/scene9/20.webp", 1920, 1080)
image e3s9-21 = im.Scale("season1/episode3/images/scene9/21.webp", 1920, 1080)
image e3s9-22 = im.Scale("season1/episode3/images/scene9/22.webp", 1920, 1080)
image e3s9-23 = im.Scale("season1/episode3/images/scene9/23.webp", 1920, 1080)
image e3s9-24 = im.Scale("season1/episode3/images/scene9/24.webp", 1920, 1080)
image e3s9-25 = im.Scale("season1/episode3/images/scene9/25.webp", 1920, 1080)
image e3s9-26 = im.Scale("season1/episode3/images/scene9/26.webp", 1920, 1080)
image e3s9-27 = im.Scale("season1/episode3/images/scene9/27.webp", 1920, 1080)
image e3s9-28 = im.Scale("season1/episode3/images/scene9/28.webp", 1920, 1080)
image e3s9-29 = im.Scale("season1/episode3/images/scene9/29.webp", 1920, 1080)
image e3s9-30 = im.Scale("season1/episode3/images/scene9/30.webp", 1920, 1080)
image e3s9-31 = im.Scale("season1/episode3/images/scene9/31.webp", 1920, 1080)
image e3s9-32 = im.Scale("season1/episode3/images/scene9/32.webp", 1920, 1080)
image e3s9-33 = im.Scale("season1/episode3/images/scene9/33.webp", 1920, 1080)
image e3s9-34 = im.Scale("season1/episode3/images/scene9/34.webp", 1920, 1080)
image e3s9-35 = im.Scale("season1/episode3/images/scene9/35.webp", 1920, 1080)
image e3s9-36 = im.Scale("season1/episode3/images/scene9/36.webp", 1920, 1080)
image e3s9-37 = im.Scale("season1/episode3/images/scene9/37.webp", 1920, 1080)
image e3s9-38 = im.Scale("season1/episode3/images/scene9/38.webp", 1920, 1080)
image e3s9-39 = im.Scale("season1/episode3/images/scene9/39.webp", 1920, 1080)
image e3s9-40 = im.Scale("season1/episode3/images/scene9/40.webp", 1920, 1080)
image e3s9-41 = im.Scale("season1/episode3/images/scene9/41.webp", 1920, 1080)
image e3s9-42 = im.Scale("season1/episode3/images/scene9/42.webp", 1920, 1080)
image e3s9-43 = im.Scale("season1/episode3/images/scene9/43.webp", 1920, 1080)
image e3s9-44 = im.Scale("season1/episode3/images/scene9/44.webp", 1920, 1080)
image e3s9-45 = im.Scale("season1/episode3/images/scene9/45.webp", 1920, 1080)
image e3s9-46 = im.Scale("season1/episode3/images/scene9/46.webp", 1920, 1080)
image e3s9-47 = im.Scale("season1/episode3/images/scene9/47.webp", 1920, 1080)
image e3s9-48 = im.Scale("season1/episode3/images/scene9/48.webp", 1920, 1080)
image e3s9-49 = im.Scale("season1/episode3/images/scene9/49.webp", 1920, 1080)
image e3s9-50 = im.Scale("season1/episode3/images/scene9/50.webp", 1920, 1080)
image e3s9-51 = im.Scale("season1/episode3/images/scene9/51.webp", 1920, 1080)
image e3s9-52 = im.Scale("season1/episode3/images/scene9/52.webp", 1920, 1080)
image e3s9-53 = im.Scale("season1/episode3/images/scene9/53.webp", 1920, 1080)
image e3s9-54 = im.Scale("season1/episode3/images/scene9/54.webp", 1920, 1080)
image e3s9-55 = im.Scale("season1/episode3/images/scene9/55.webp", 1920, 1080)

# Images Candance
image e3s9_ca-01 = im.Scale("season1/episode3/images/scene9/candance/1.webp", 1920, 1080)
image e3s9_ca-02 = im.Scale("season1/episode3/images/scene9/candance/2.webp", 1920, 1080)
image e3s9_ca-03 = im.Scale("season1/episode3/images/scene9/candance/3.webp", 1920, 1080)
image e3s9_ca-04 = im.Scale("season1/episode3/images/scene9/candance/4.webp", 1920, 1080)
image e3s9_ca-05 = im.Scale("season1/episode3/images/scene9/candance/5.webp", 1920, 1080)
image e3s9_ca-06 = im.Scale("season1/episode3/images/scene9/candance/6.webp", 1920, 1080)
image e3s9_ca-07 = im.Scale("season1/episode3/images/scene9/candance/7.webp", 1920, 1080)
image e3s9_ca-08 = im.Scale("season1/episode3/images/scene9/candance/8.webp", 1920, 1080)
image e3s9_ca-09 = im.Scale("season1/episode3/images/scene9/candance/9.webp", 1920, 1080)
image e3s9_ca-10 = im.Scale("season1/episode3/images/scene9/candance/10.webp", 1920, 1080)
image e3s9_ca-11 = im.Scale("season1/episode3/images/scene9/candance/11.webp", 1920, 1080)
image e3s9_ca-12 = im.Scale("season1/episode3/images/scene9/candance/12.webp", 1920, 1080)
image e3s9_ca-13 = im.Scale("season1/episode3/images/scene9/candance/13.webp", 1920, 1080)
image e3s9_ca-14 = im.Scale("season1/episode3/images/scene9/candance/14.webp", 1920, 1080)
image e3s9_ca-15 = im.Scale("season1/episode3/images/scene9/candance/15.webp", 1920, 1080)
image e3s9_ca-16 = im.Scale("season1/episode3/images/scene9/candance/16.webp", 1920, 1080)
image e3s9_ca-17 = im.Scale("season1/episode3/images/scene9/candance/17.webp", 1920, 1080)
image e3s9_ca-18 = im.Scale("season1/episode3/images/scene9/candance/18.webp", 1920, 1080)
image e3s9_ca-19 = im.Scale("season1/episode3/images/scene9/candance/19.webp", 1920, 1080)
image e3s9_ca-20 = im.Scale("season1/episode3/images/scene9/candance/20.webp", 1920, 1080)
image e3s9_ca-21 = im.Scale("season1/episode3/images/scene9/candance/21.webp", 1920, 1080)
image e3s9_ca-22 = im.Scale("season1/episode3/images/scene9/candance/22.webp", 1920, 1080)
image e3s9_ca-23 = im.Scale("season1/episode3/images/scene9/candance/23.webp", 1920, 1080)
image e3s9_ca-24 = im.Scale("season1/episode3/images/scene9/candance/24.webp", 1920, 1080)
image e3s9_ca-25 = im.Scale("season1/episode3/images/scene9/candance/25.webp", 1920, 1080)
image e3s9_ca-26 = im.Scale("season1/episode3/images/scene9/candance/26.webp", 1920, 1080)
image e3s9_ca-27 = im.Scale("season1/episode3/images/scene9/candance/27.webp", 1920, 1080)
image e3s9_ca-28 = im.Scale("season1/episode3/images/scene9/candance/28.webp", 1920, 1080)
image e3s9_ca-29 = im.Scale("season1/episode3/images/scene9/candance/29.webp", 1920, 1080)
image e3s9_ca-30 = im.Scale("season1/episode3/images/scene9/candance/30.webp", 1920, 1080)
image e3s9_ca-31 = im.Scale("season1/episode3/images/scene9/candance/31.webp", 1920, 1080)
image e3s9_ca-32 = im.Scale("season1/episode3/images/scene9/candance/32.webp", 1920, 1080)
image e3s9_ca-33 = im.Scale("season1/episode3/images/scene9/candance/33.webp", 1920, 1080)
image e3s9_ca-34 = im.Scale("season1/episode3/images/scene9/candance/34.webp", 1920, 1080)
image e3s9_ca-35 = im.Scale("season1/episode3/images/scene9/candance/35.webp", 1920, 1080)
image e3s9_ca-36 = im.Scale("season1/episode3/images/scene9/candance/36.webp", 1920, 1080)
image e3s9_ca-37 = im.Scale("season1/episode3/images/scene9/candance/37.webp", 1920, 1080)
image e3s9_ca-38 = im.Scale("season1/episode3/images/scene9/candance/38.webp", 1920, 1080)
image e3s9_ca-39 = im.Scale("season1/episode3/images/scene9/candance/39.webp", 1920, 1080)
image e3s9_ca-40 = im.Scale("season1/episode3/images/scene9/candance/40.webp", 1920, 1080)
image e3s9_ca-41 = im.Scale("season1/episode3/images/scene9/candance/41.webp", 1920, 1080)
image e3s9_ca-42 = im.Scale("season1/episode3/images/scene9/candance/42.webp", 1920, 1080)
image e3s9_ca-43 = im.Scale("season1/episode3/images/scene9/candance/43.webp", 1920, 1080)
image e3s9_ca-44 = im.Scale("season1/episode3/images/scene9/candance/44.webp", 1920, 1080)
image e3s9_ca-45 = im.Scale("season1/episode3/images/scene9/candance/45.webp", 1920, 1080)
image e3s9_ca-46 = im.Scale("season1/episode3/images/scene9/candance/46.webp", 1920, 1080)
image e3s9_ca-47 = im.Scale("season1/episode3/images/scene9/candance/47.webp", 1920, 1080)
image e3s9_ca-48 = im.Scale("season1/episode3/images/scene9/candance/48.webp", 1920, 1080)
image e3s9_ca-49 = im.Scale("season1/episode3/images/scene9/candance/49.webp", 1920, 1080)
image e3s9_ca-50 = im.Scale("season1/episode3/images/scene9/candance/50.webp", 1920, 1080)
image e3s9_ca-51 = im.Scale("season1/episode3/images/scene9/candance/51.webp", 1920, 1080)
image e3s9_ca-52 = im.Scale("season1/episode3/images/scene9/candance/52.webp", 1920, 1080)
image e3s9_ca-53 = im.Scale("season1/episode3/images/scene9/candance/53.webp", 1920, 1080)
image e3s9_ca-54 = im.Scale("season1/episode3/images/scene9/candance/54.webp", 1920, 1080)
image e3s9_ca-55 = im.Scale("season1/episode3/images/scene9/candance/55.webp", 1920, 1080)
image e3s9_ca-56 = im.Scale("season1/episode3/images/scene9/candance/56.webp", 1920, 1080)
image e3s9_ca-57 = im.Scale("season1/episode3/images/scene9/candance/57.webp", 1920, 1080)

# Animations #
# Static
image e3s9_tiffany_blink1:
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s9_candance_blink1:
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene9/candance/candance_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s9-doggy1 = Movie(play="season1/episode3/images/scene9/doggy1.webm")
image e3s9-doggy2 = Movie(play="season1/episode3/images/scene9/doggy2.webm")
image e3s9-doggy3 = Movie(play="season1/episode3/images/scene9/doggy3.webm")
image e3s9-doggy4 = Movie(play="season1/episode3/images/scene9/doggy4.webm")
image e3s9-doggy5 = Movie(play="season1/episode3/images/scene9/doggy5.webm")
image e3s9-spooning1 = Movie(play="season1/episode3/images/scene9/spooning1.webm")
image e3s9-spooning2 = Movie(play="season1/episode3/images/scene9/spooning2.webm")
image e3s9-spooning3 = Movie(play="season1/episode3/images/scene9/spooning3.webm")
image e3s9-spooning4 = Movie(play="season1/episode3/images/scene9/spooning4.webm")
image e3s9-spooning5 = Movie(play="season1/episode3/images/scene9/spooning5.webm")
image e3s9-missionary1 = Movie(play="season1/episode3/images/scene9/missionary1.webm")
image e3s9-missionary2 = Movie(play="season1/episode3/images/scene9/missionary2.webm")
image e3s9-missionary3 = Movie(play="season1/episode3/images/scene9/missionary3.webm")

# Censored
# Images
image e3s9-31_cen = im.Scale("season1/episode3/images/scene9/censored/31.webp", 1920, 1080)
image e3s9-32_cen = im.Scale("season1/episode3/images/scene9/censored/32.webp", 1920, 1080)
image e3s9-34_cen = im.Scale("season1/episode3/images/scene9/censored/34.webp", 1920, 1080)
image e3s9-35_cen = im.Scale("season1/episode3/images/scene9/censored/35.webp", 1920, 1080)
image e3s9-36_cen = im.Scale("season1/episode3/images/scene9/censored/36.webp", 1920, 1080)
image e3s9-37_cen = im.Scale("season1/episode3/images/scene9/censored/37.webp", 1920, 1080)
image e3s9-38_cen = im.Scale("season1/episode3/images/scene9/censored/38.webp", 1920, 1080)

# Animations
image e3s9-doggy1_cen = Movie(play="season1/episode3/images/scene9/censored/doggy1.webm")
image e3s9-doggy2_cen = Movie(play="season1/episode3/images/scene9/censored/doggy2.webm")
image e3s9-doggy3_cen = Movie(play="season1/episode3/images/scene9/censored/doggy3.webm")
image e3s9-doggy4_cen = Movie(play="season1/episode3/images/scene9/censored/doggy4.webm")
image e3s9-doggy5_cen = Movie(play="season1/episode3/images/scene9/censored/doggy5.webm")
image e3s9-spooning1_cen = Movie(play="season1/episode3/images/scene9/censored/spooning1.webm")
image e3s9-spooning2_cen = Movie(play="season1/episode3/images/scene9/censored/spooning2.webm")
image e3s9-spooning3_cen = Movie(play="season1/episode3/images/scene9/censored/spooning3.webm")
image e3s9-spooning4_cen = Movie(play="season1/episode3/images/scene9/censored/spooning4.webm")
image e3s9-spooning5_cen = Movie(play="season1/episode3/images/scene9/censored/spooning5.webm")
image e3s9-missionary1_cen = Movie(play="season1/episode3/images/scene9/censored/missionary1.webm")
image e3s9-missionary2_cen = Movie(play="season1/episode3/images/scene9/censored/missionary2.webm")
image e3s9-missionary3_cen = Movie(play="season1/episode3/images/scene9/censored/missionary3.webm")
