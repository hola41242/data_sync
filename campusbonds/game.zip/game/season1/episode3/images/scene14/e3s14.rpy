
# Scene 14 #####################################################################

image e3s14-01 = im.Scale("season1/episode3/images/scene14/1.webp", 1920, 1080)
image e3s14-02 = im.Scale("season1/episode3/images/scene14/2.webp", 1920, 1080)
image e3s14-03 = im.Scale("season1/episode3/images/scene14/3.webp", 1920, 1080)
image e3s14-04 = im.Scale("season1/episode3/images/scene14/4.webp", 1920, 1080)
image e3s14-05 = im.Scale("season1/episode3/images/scene14/5.webp", 1920, 1080)
image e3s14-06 = im.Scale("season1/episode3/images/scene14/6.webp", 1920, 1080)
image e3s14-07 = im.Scale("season1/episode3/images/scene14/7.webp", 1920, 1080)
image e3s14-08 = im.Scale("season1/episode3/images/scene14/8.webp", 1920, 1080)
image e3s14-09 = im.Scale("season1/episode3/images/scene14/9.webp", 1920, 1080)
image e3s14-10 = im.Scale("season1/episode3/images/scene14/10.webp", 1920, 1080)
image e3s14-11 = im.Scale("season1/episode3/images/scene14/11.webp", 1920, 1080)
image e3s14-12 = im.Scale("season1/episode3/images/scene14/12.webp", 1920, 1080)
image e3s14-13 = im.Scale("season1/episode3/images/scene14/13.webp", 1920, 1080)
image e3s14-14 = im.Scale("season1/episode3/images/scene14/14.webp", 1920, 1080)
