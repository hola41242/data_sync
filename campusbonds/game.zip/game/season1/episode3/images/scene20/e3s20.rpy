
# Scene 20 images ##############################################################

image e3s20-01 = im.Scale("season1/episode3/images/scene20/1.webp", 1920, 1080)
image e3s20-02 = im.Scale("season1/episode3/images/scene20/2.webp", 1920, 1080)
image e3s20-03 = im.Scale("season1/episode3/images/scene20/3.webp", 1920, 1080)
image e3s20-04 = im.Scale("season1/episode3/images/scene20/4.webp", 1920, 1080)
image e3s20-05 = im.Scale("season1/episode3/images/scene20/5.webp", 1920, 1080)
image e3s20-06 = im.Scale("season1/episode3/images/scene20/6.webp", 1920, 1080)
image e3s20-07 = im.Scale("season1/episode3/images/scene20/7.webp", 1920, 1080)
image e3s20-08 = im.Scale("season1/episode3/images/scene20/8.webp", 1920, 1080)
image e3s20-09 = im.Scale("season1/episode3/images/scene20/9.webp", 1920, 1080)
image e3s20-10 = im.Scale("season1/episode3/images/scene20/10.webp", 1920, 1080)
image e3s20-11 = im.Scale("season1/episode3/images/scene20/11.webp", 1920, 1080)
image e3s20-12 = im.Scale("season1/episode3/images/scene20/12.webp", 1920, 1080)
image e3s20-13 = im.Scale("season1/episode3/images/scene20/13.webp", 1920, 1080)
image e3s20-14 = im.Scale("season1/episode3/images/scene20/14.webp", 1920, 1080)
image e3s20-15 = im.Scale("season1/episode3/images/scene20/15.webp", 1920, 1080)
image e3s20-16 = im.Scale("season1/episode3/images/scene20/16.webp", 1920, 1080)
image e3s20-17 = im.Scale("season1/episode3/images/scene20/17.webp", 1920, 1080)
image e3s20-18 = im.Scale("season1/episode3/images/scene20/18.webp", 1920, 1080)
image e3s20-19 = im.Scale("season1/episode3/images/scene20/19.webp", 1920, 1080)
image e3s20-20 = im.Scale("season1/episode3/images/scene20/20.webp", 1920, 1080)
image e3s20-21 = im.Scale("season1/episode3/images/scene20/21.webp", 1920, 1080)
image e3s20-22 = im.Scale("season1/episode3/images/scene20/22.webp", 1920, 1080)
image e3s20-23 = im.Scale("season1/episode3/images/scene20/23.webp", 1920, 1080)
image e3s20-24 = im.Scale("season1/episode3/images/scene20/24.webp", 1920, 1080)
image e3s20-25 = im.Scale("season1/episode3/images/scene20/25.webp", 1920, 1080)
image e3s20-26 = im.Scale("season1/episode3/images/scene20/26.webp", 1920, 1080)
image e3s20-27 = im.Scale("season1/episode3/images/scene20/27.webp", 1920, 1080)
image e3s20-28 = im.Scale("season1/episode3/images/scene20/28.webp", 1920, 1080)
image e3s20-29 = im.Scale("season1/episode3/images/scene20/29.webp", 1920, 1080)
image e3s20-30 = im.Scale("season1/episode3/images/scene20/30.webp", 1920, 1080)
image e3s20-31 = im.Scale("season1/episode3/images/scene20/31.webp", 1920, 1080)
image e3s20-32 = im.Scale("season1/episode3/images/scene20/32.webp", 1920, 1080)
image e3s20-33 = im.Scale("season1/episode3/images/scene20/33.webp", 1920, 1080)
image e3s20-34 = im.Scale("season1/episode3/images/scene20/34.webp", 1920, 1080)
image e3s20-35 = im.Scale("season1/episode3/images/scene20/35.webp", 1920, 1080)
image e3s20-36 = im.Scale("season1/episode3/images/scene20/36.webp", 1920, 1080)
image e3s20-37 = im.Scale("season1/episode3/images/scene20/37.webp", 1920, 1080)
image e3s20-38 = im.Scale("season1/episode3/images/scene20/38.webp", 1920, 1080)
image e3s20-39 = im.Scale("season1/episode3/images/scene20/39.webp", 1920, 1080)
image e3s20-40 = im.Scale("season1/episode3/images/scene20/40.webp", 1920, 1080)
image e3s20-41 = im.Scale("season1/episode3/images/scene20/41.webp", 1920, 1080)
image e3s20-42 = im.Scale("season1/episode3/images/scene20/42.webp", 1920, 1080)
image e3s20-43 = im.Scale("season1/episode3/images/scene20/43.webp", 1920, 1080)
image e3s20-44 = im.Scale("season1/episode3/images/scene20/44.webp", 1920, 1080)
image e3s20-45 = im.Scale("season1/episode3/images/scene20/45.webp", 1920, 1080)
image e3s20-46 = im.Scale("season1/episode3/images/scene20/46.webp", 1920, 1080)
image e3s20-47 = im.Scale("season1/episode3/images/scene20/47.webp", 1920, 1080)
image e3s20-48 = im.Scale("season1/episode3/images/scene20/48.webp", 1920, 1080)
image e3s20-49 = im.Scale("season1/episode3/images/scene20/49.webp", 1920, 1080)
image e3s20-50 = im.Scale("season1/episode3/images/scene20/50.webp", 1920, 1080)
image e3s20-51 = im.Scale("season1/episode3/images/scene20/51.webp", 1920, 1080)
image e3s20-52 = im.Scale("season1/episode3/images/scene20/52.webp", 1920, 1080)
image e3s20-53 = im.Scale("season1/episode3/images/scene20/53.webp", 1920, 1080)
image e3s20-54 = im.Scale("season1/episode3/images/scene20/54.webp", 1920, 1080)
image e3s20-55 = im.Scale("season1/episode3/images/scene20/55.webp", 1920, 1080)
image e3s20-56 = im.Scale("season1/episode3/images/scene20/56.webp", 1920, 1080)
image e3s20-57 = im.Scale("season1/episode3/images/scene20/57.webp", 1920, 1080)
image e3s20-58 = im.Scale("season1/episode3/images/scene20/58.webp", 1920, 1080)
image e3s20-59 = im.Scale("season1/episode3/images/scene20/59.webp", 1920, 1080)
image e3s20-60 = im.Scale("season1/episode3/images/scene20/60.webp", 1920, 1080)
image e3s20-61 = im.Scale("season1/episode3/images/scene20/61.webp", 1920, 1080)
image e3s20-62 = im.Scale("season1/episode3/images/scene20/62.webp", 1920, 1080)
image e3s20-63 = im.Scale("season1/episode3/images/scene20/63.webp", 1920, 1080)
image e3s20-64 = im.Scale("season1/episode3/images/scene20/64.webp", 1920, 1080)
image e3s20-65 = im.Scale("season1/episode3/images/scene20/65.webp", 1920, 1080)
image e3s20-66 = im.Scale("season1/episode3/images/scene20/66.webp", 1920, 1080)
image e3s20-67 = im.Scale("season1/episode3/images/scene20/67.webp", 1920, 1080)
image e3s20-68 = im.Scale("season1/episode3/images/scene20/68.webp", 1920, 1080)
image e3s20-69 = im.Scale("season1/episode3/images/scene20/69.webp", 1920, 1080)
image e3s20-70 = im.Scale("season1/episode3/images/scene20/70.webp", 1920, 1080)
image e3s20-71 = im.Scale("season1/episode3/images/scene20/71.webp", 1920, 1080)

image e3s20_alice_blink1:
    im.Scale("season1/episode3/images/scene20/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene20/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
