
# Scene 1 images ###############################################################

image e3s1-01 = im.Scale("season1/episode3/images/scene1/1.webp", 1920, 1080)
image e3s1-02 = im.Scale("season1/episode3/images/scene1/2.webp", 1920, 1080)
image e3s1-03 = im.Scale("season1/episode3/images/scene1/3.webp", 1920, 1080)
image e3s1-04 = im.Scale("season1/episode3/images/scene1/4.webp", 1920, 1080)
image e3s1-05 = im.Scale("season1/episode3/images/scene1/5.webp", 1920, 1080)
image e3s1-06 = im.Scale("season1/episode3/images/scene1/6.webp", 1920, 1080)
image e3s1-07 = im.Scale("season1/episode3/images/scene1/7.webp", 1920, 1080)
image e3s1-08 = im.Scale("season1/episode3/images/scene1/8.webp", 1920, 1080)
image e3s1-09 = im.Scale("season1/episode3/images/scene1/9.webp", 1920, 1080)
image e3s1-10 = im.Scale("season1/episode3/images/scene1/10.webp", 1920, 1080)
image e3s1-11 = im.Scale("season1/episode3/images/scene1/11.webp", 1920, 1080)
image e3s1-12 = im.Scale("season1/episode3/images/scene1/12.webp", 1920, 1080)
image e3s1-13 = im.Scale("season1/episode3/images/scene1/13.webp", 1920, 1080)
image e3s1-14 = im.Scale("season1/episode3/images/scene1/14.webp", 1920, 1080)
image e3s1-15 = im.Scale("season1/episode3/images/scene1/15.webp", 1920, 1080)
image e3s1-16 = im.Scale("season1/episode3/images/scene1/16.webp", 1920, 1080)
image e3s1-17 = im.Scale("season1/episode3/images/scene1/17.webp", 1920, 1080)
image e3s1-18 = im.Scale("season1/episode3/images/scene1/18.webp", 1920, 1080)
image e3s1-19 = im.Scale("season1/episode3/images/scene1/19.webp", 1920, 1080)
image e3s1-20 = im.Scale("season1/episode3/images/scene1/20.webp", 1920, 1080)
image e3s1-21 = im.Scale("season1/episode3/images/scene1/21.webp", 1920, 1080)
image e3s1-22 = im.Scale("season1/episode3/images/scene1/22.webp", 1920, 1080)
image e3s1-23 = im.Scale("season1/episode3/images/scene1/23.webp", 1920, 1080)
image e3s1-24 = im.Scale("season1/episode3/images/scene1/24.webp", 1920, 1080)
image e3s1-25 = im.Scale("season1/episode3/images/scene1/25.webp", 1920, 1080)
image e3s1-26 = im.Scale("season1/episode3/images/scene1/26.webp", 1920, 1080)
image e3s1-27 = im.Scale("season1/episode3/images/scene1/27.webp", 1920, 1080)
image e3s1-28 = im.Scale("season1/episode3/images/scene1/28.webp", 1920, 1080)
image e3s1-29 = im.Scale("season1/episode3/images/scene1/29.webp", 1920, 1080)
image e3s1-30 = im.Scale("season1/episode3/images/scene1/30.webp", 1920, 1080)
image e3s1-31 = im.Scale("season1/episode3/images/scene1/31.webp", 1920, 1080)
image e3s1-32 = im.Scale("season1/episode3/images/scene1/32.webp", 1920, 1080)
image e3s1-33 = im.Scale("season1/episode3/images/scene1/33.webp", 1920, 1080)
image e3s1-34 = im.Scale("season1/episode3/images/scene1/34.webp", 1920, 1080)
image e3s1-35 = im.Scale("season1/episode3/images/scene1/35.webp", 1920, 1080)
image e3s1-36 = im.Scale("season1/episode3/images/scene1/36.webp", 1920, 1080)
image e3s1-37 = im.Scale("season1/episode3/images/scene1/37.webp", 1920, 1080)
image e3s1-38 = im.Scale("season1/episode3/images/scene1/38.webp", 1920, 1080)
image e3s1-39 = im.Scale("season1/episode3/images/scene1/39.webp", 1920, 1080)
image e3s1-40 = im.Scale("season1/episode3/images/scene1/40.webp", 1920, 1080)
image e3s1-41 = im.Scale("season1/episode3/images/scene1/41.webp", 1920, 1080)
image e3s1-42 = im.Scale("season1/episode3/images/scene1/42.webp", 1920, 1080)
image e3s1-43 = im.Scale("season1/episode3/images/scene1/43.webp", 1920, 1080)
image e3s1-44 = im.Scale("season1/episode3/images/scene1/44.webp", 1920, 1080)
image e3s1-45 = im.Scale("season1/episode3/images/scene1/45.webp", 1920, 1080)
image e3s1-46 = im.Scale("season1/episode3/images/scene1/46.webp", 1920, 1080)
image e3s1-47 = im.Scale("season1/episode3/images/scene1/47.webp", 1920, 1080)
image e3s1-48 = im.Scale("season1/episode3/images/scene1/48.webp", 1920, 1080)
image e3s1-49 = im.Scale("season1/episode3/images/scene1/49.webp", 1920, 1080)

image e3s1_olivia_blink1:
    im.Scale("season1/episode3/images/scene1/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s1_olivia_blink2:
    im.Scale("season1/episode3/images/scene1/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s1_olivia_blink3:
    im.Scale("season1/episode3/images/scene1/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s1_olivia_blink4:
    im.Scale("season1/episode3/images/scene1/olivia_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s1_olivia_blink5:
    im.Scale("season1/episode3/images/scene1/olivia_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene1/olivia_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat
