
# Scene 11 images ###############################################################

image e3s11-01 = im.Scale("season1/episode3/images/scene11/1.webp", 1920, 1080)
image e3s11-02 = im.Scale("season1/episode3/images/scene11/2.webp", 1920, 1080)
image e3s11-03 = im.Scale("season1/episode3/images/scene11/3.webp", 1920, 1080)
image e3s11-04 = im.Scale("season1/episode3/images/scene11/4.webp", 1920, 1080)
image e3s11-05 = im.Scale("season1/episode3/images/scene11/5.webp", 1920, 1080)
image e3s11-06 = im.Scale("season1/episode3/images/scene11/6.webp", 1920, 1080)
image e3s11-07 = im.Scale("season1/episode3/images/scene11/7.webp", 1920, 1080)
image e3s11-08 = im.Scale("season1/episode3/images/scene11/8.webp", 1920, 1080)
image e3s11-09 = im.Scale("season1/episode3/images/scene11/9.webp", 1920, 1080)
image e3s11-10 = im.Scale("season1/episode3/images/scene11/10.webp", 1920, 1080)
image e3s11-11 = im.Scale("season1/episode3/images/scene11/11.webp", 1920, 1080)
image e3s11-12 = im.Scale("season1/episode3/images/scene11/12.webp", 1920, 1080)
image e3s11-13 = im.Scale("season1/episode3/images/scene11/13.webp", 1920, 1080)
image e3s11-14 = im.Scale("season1/episode3/images/scene11/14.webp", 1920, 1080)
image e3s11-15 = im.Scale("season1/episode3/images/scene11/15.webp", 1920, 1080)
image e3s11-16 = im.Scale("season1/episode3/images/scene11/16.webp", 1920, 1080)
image e3s11-17 = im.Scale("season1/episode3/images/scene11/17.webp", 1920, 1080)
image e3s11-18 = im.Scale("season1/episode3/images/scene11/18.webp", 1920, 1080)
image e3s11-19 = im.Scale("season1/episode3/images/scene11/19.webp", 1920, 1080)
image e3s11-20 = im.Scale("season1/episode3/images/scene11/20.webp", 1920, 1080)
image e3s11-21 = im.Scale("season1/episode3/images/scene11/21.webp", 1920, 1080)
image e3s11-22 = im.Scale("season1/episode3/images/scene11/22.webp", 1920, 1080)
image e3s11-23 = im.Scale("season1/episode3/images/scene11/23.webp", 1920, 1080)
image e3s11-24 = im.Scale("season1/episode3/images/scene11/24.webp", 1920, 1080)
image e3s11-25 = im.Scale("season1/episode3/images/scene11/25.webp", 1920, 1080)
image e3s11-26 = im.Scale("season1/episode3/images/scene11/26.webp", 1920, 1080)
image e3s11-27 = im.Scale("season1/episode3/images/scene11/27.webp", 1920, 1080)
image e3s11-28 = im.Scale("season1/episode3/images/scene11/28.webp", 1920, 1080)
image e3s11-29 = im.Scale("season1/episode3/images/scene11/29.webp", 1920, 1080)
image e3s11-30 = im.Scale("season1/episode3/images/scene11/30.webp", 1920, 1080)
image e3s11-31 = im.Scale("season1/episode3/images/scene11/31.webp", 1920, 1080)
image e3s11-32 = im.Scale("season1/episode3/images/scene11/32.webp", 1920, 1080)
image e3s11-33 = im.Scale("season1/episode3/images/scene11/33.webp", 1920, 1080)
image e3s11-34 = im.Scale("season1/episode3/images/scene11/34.webp", 1920, 1080)
image e3s11-35 = im.Scale("season1/episode3/images/scene11/35.webp", 1920, 1080)
image e3s11-36 = im.Scale("season1/episode3/images/scene11/36.webp", 1920, 1080)
image e3s11-37 = im.Scale("season1/episode3/images/scene11/37.webp", 1920, 1080)
image e3s11-38 = im.Scale("season1/episode3/images/scene11/38.webp", 1920, 1080)
image e3s11-39 = im.Scale("season1/episode3/images/scene11/39.webp", 1920, 1080)
image e3s11-40 = im.Scale("season1/episode3/images/scene11/40.webp", 1920, 1080)
image e3s11-41 = im.Scale("season1/episode3/images/scene11/41.webp", 1920, 1080)
image e3s11-42 = im.Scale("season1/episode3/images/scene11/42.webp", 1920, 1080)
image e3s11-43 = im.Scale("season1/episode3/images/scene11/43.webp", 1920, 1080)
image e3s11-44 = im.Scale("season1/episode3/images/scene11/44.webp", 1920, 1080)
image e3s11-45 = im.Scale("season1/episode3/images/scene11/45.webp", 1920, 1080)
image e3s11-46 = im.Scale("season1/episode3/images/scene11/46.webp", 1920, 1080)
image e3s11-47 = im.Scale("season1/episode3/images/scene11/47.webp", 1920, 1080)
image e3s11-48 = im.Scale("season1/episode3/images/scene11/48.webp", 1920, 1080)
image e3s11-49 = im.Scale("season1/episode3/images/scene11/49.webp", 1920, 1080)
image e3s11-50 = im.Scale("season1/episode3/images/scene11/50.webp", 1920, 1080)
image e3s11-51 = im.Scale("season1/episode3/images/scene11/51.webp", 1920, 1080)
image e3s11-52 = im.Scale("season1/episode3/images/scene11/52.webp", 1920, 1080)

# Freeroam
# 01
image e3s11-fr_01 = im.Scale("season1/episode3/images/scene11/freeroam/1.webp", 1920, 1080)

# 02
image e3s11-fr_02 = im.Scale("season1/episode3/images/scene11/freeroam/2.webp", 1920, 1080)
image e3s11-fr_02-envelopes = im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes.webp", 1920, 1080)
image e3s11-fr_02-notebooks = im.Scale("season1/episode3/images/scene11/freeroam/2/notebooks.webp", 1920, 1080)
image e3s11-fr_02-media = im.Scale("season1/episode3/images/scene11/freeroam/2/media.webp", 1920, 1080)

# 03
image e3s11-fr_03 = im.Scale("season1/episode3/images/scene11/freeroam/3.webp", 1920, 1080)

# 04
image e3s11-fr_04 = im.Scale("season1/episode3/images/scene11/freeroam/4.webp", 1920, 1080)
image e3s11-fr_04_bin = im.Scale("season1/episode3/images/scene11/freeroam/4/bin.webp", 1920, 1080)

image e3s11_olivia_blink1:
    im.Scale("season1/episode3/images/scene11/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s11_evelyn_blink1:
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene11/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
