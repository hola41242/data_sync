
# Freeroam screens #############################################################

# 01 ###########################################################################
screen e3s11_01():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_01"

    # Clickables
    if e3s11_photo == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/scene11/freeroam/1/photo_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/scene11/freeroam/1/photo_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3s11_photo")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3s11_photo")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/1/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/1/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_02")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_02")

# 02 ###########################################################################
screen e3s11_02():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_02"

    # Clickables ###############################################################
    # Not working
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/batteries_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/batteries_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_batteries")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_batteries")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/screws_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/screws_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_screws")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_screws")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/work_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/work_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_work")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_work")

    # Working
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_envelopes")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_envelopes")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/media_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/media_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_media")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_media")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/notebooks_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/notebooks_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_notebooks")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_notebooks")

    # Map ######################################################################
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_01")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_01")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_03")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_03")

screen e3s11_02_envelopes():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_02-envelopes"

    # Clickables
    if persistent.cl_gallery_10_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_10_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_10_unlocked", True), SetVariable("persistent.e3s11_collected_p", persistent.e3s11_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo10", True), Function(update_cleo_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/envelopes/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_02")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_02")
screen e3s11_02_notebooks():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_02-notebooks"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/2/notebooks/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/2/notebooks/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_02")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_02")

# 03 ###########################################################################
screen e3s11_03():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_03"

    # Clickables
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/3/pb_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/3/pb_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_pb")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_pb")

    if persistent.mixed_gallery_13_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/scene11/freeroam/3/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/scene11/freeroam/3/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_13_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_13_unlocked", True), SetVariable("persistent.e3s11_collected_p", persistent.e3s11_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed13", True), Function(update_mixed_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/3/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/3/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_04")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_04")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/3/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/3/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_02")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_02")

# 04 ###########################################################################
screen e3s11_04():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_04"

    # Clickables
    if e3s11_toy == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/scene11/freeroam/4/toy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/scene11/freeroam/4/toy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e3s11_toy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e3s11_toy")

    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/4/bin_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/4/bin_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_bin")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_bin")

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/4/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/4/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_03")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_03")

screen e3s11_04_bin():

    $ renpy.random.shuffle(e3s11_tracks)
    modal True

    add "e3s11-fr_04_bin"

    # Clickables
    if persistent.tr_gallery_10_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode3/images/scene11/freeroam/4/bin/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode3/images/scene11/freeroam/4/bin/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_10_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_10_unlocked", True), SetVariable("persistent.e3s11_collected_p", persistent.e3s11_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy10", True), Function(update_tracy_list)]

    # Map
    imagebutton:
        idle im.Scale("season1/episode3/images/scene11/freeroam/4/bin/back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode3/images/scene11/freeroam/4/bin/back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e3s11_04")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e3s11_04")
