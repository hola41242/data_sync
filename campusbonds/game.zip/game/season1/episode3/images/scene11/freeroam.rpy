
default e3s11_bin = False
default e3s11_pb = False

default e3s11_explore = 0

# Freeroam Collected Photos #

default persistent.e3s11_collected_p = 0
default persistent.e3s11_collected_tp = 3

# Freeroam #####################################################################
label e3s11_fr:
    define e3s11_tracks = ["aces_high.ogg", "dances_and_dames.ogg", "hi_as_hats.ogg", "liar.ogg", "onfire.ogg", "whhhsfs.ogg"]
    $ renpy.random.shuffle(e3s11_tracks)
    $ renpy.music.queue (e3s11_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Find Sadie's phone.")

    scene e3s11-fr_01 with dissolve
    call screen e3s11_01
    hide e3s11-fr_01
return

# Map ##########################################################################
# 01
label e3s11_01:
    scene e3s11-fr_01
    call screen e3s11_01 with dissolve
return

label e3s11_photo:
    $ e3s11_photo = True
    scene e3s11-fr_01
    mc "*This seems to be her doggo.*"
    mc "*Didn't think she was too much of an animal lover.*"
    mc "*Good to know!*"

    $ e3s11_explore += 1

    if e3s11_explore == 4:
        return
    call screen e3s11_01 with dissolve
return

# 02 ###########################################################################
label e3s11_02:
    scene e3s11-fr_02
    call screen e3s11_02 with dissolve
return

# Clickables
# Not working
label e3s11_batteries:
    scene e3s11-fr_02
    mc "*The hell am I gonna do with batteries?*"
    mc "*Come on, focus, I can't stay here for much longer.*"

    $ e3s11_explore += 1

    if e3s11_explore == 4:
        return
    call screen e3s11_02 with dissolve
return

label e3s11_screws:
    scene e3s11-fr_02
    mc "*Why do I need screws for?*"
    mc "*I'm looking for a phone.*"
    mc "*Come to think of it, why would she keep screws at her work desk as a librarian?*"

    $ e3s11_explore += 1
    if e3s11_explore == 4:
        return
    call screen e3s11_02 with dissolve
return

label e3s11_work:
    scene e3s11-fr_02
    mc "*Hmm.. this one's stuck.*"

    $ e3s11_explore += 1
    if e3s11_explore == 4:
        return
    call screen e3s11_02 with dissolve
return

# Working
label e3s11_envelopes:
    scene e3s11-fr_02-envelopes
    call screen e3s11_02_envelopes with dissolve
return

label e3s11_media:
    if optional_quests:
        $ optional_quests.clear()
    if current_quests:
        $ current_quests.clear()

    $ renpy.hide_screen("questtracker_icon")

    scene e3s11-28 with dissolve
    mc "*Let’s try this drawer.*"

    scene e3s11-fr_02-media with dissolve
    mc "*Bingo!*"
    mc "*Wait, damn it..!*"
    mc "*There’s like a dozen phones here.*"
    mc "*Which one do I take?*"

    scene e3s11-48 with dissolve
    mc "*Let me take a photo, send it to her and see which one lights up.*"

    scene e3s11-49 with dissolve
    pause

    play sound camera_shutter
    scene white
    pause(0.1)

    scene e3s11-49 with dissolve
    pause

    scene e3s11-fr_02-media with dissolve
    mc "*Damn it, why is no phone lighting up?*"
    mc "*Maybe it's not here.*"

    stop music
    $renpy.sound.play("audio/sfx/heart_beat.ogg", loop=True)
    scene e3s11-27 with dissolve
    pause

    scene e3s11-29 with dissolve
    mc "*Oh shit, I’m hearing footsteps!*"

    scene e3s11-fr_02-media with dissolve
    mc "*Quick, which one do I pick?*"

    $ timed_max = 3.9
    $ timed_start = 4.00
    $ timed_interval = 0.01
    $ timed_choice = 1

    if persistent.tutorial == True:
        show tutorial_background_menu with wiperight
        show dialogue_box with wiperight
        show e2s0_text "This is a Timed Choice." with wiperight
        pause

        hide e2s0_text with wipeleft
        show e2s0_text "During this state of the game, you'll need \n to make a decision." with wiperight
        pause

        hide e2s0_text with wipeleft
        show e2s0_text "Keep an eye on the timer, as you must choose \n before it runs out." with wiperight
        pause

        hide e2s0_text with wipeleft
        hide dialogue_box with wipeleft
        hide tutorial_background_menu with wipeleft

    $ renpy.block_rollback()

    menu:
        "Don’t take any phone":
            $ renpy.block_rollback()
            stop sound fadeout 1.0
            scene e3s11-28 with dissolve
            mc "*Fuck it, I'm not grabbing anything.*"
            mc "*If I'm wrong I'll have to snoop here again to return it.*"

        "Take the one on the left":
            $ renpy.block_rollback()
            $ e3s11_phone_left = True
            stop sound fadeout 1.0
            scene e3s11-26 with dissolve
            mc "*I’m grabbing this one, hopefully it's hers.*"

        "Take the one on the right":
            $ renpy.block_rollback()
            $ e3s11_phone_right = True
            stop sound fadeout 1.0
            scene e3s11-26 with dissolve
            mc "*I’m grabbing this one, hopefully it's hers.*"

    $ timed_max = 3.9
    $ timed_start = 4.00
    $ timed_interval = 0.01
    $ timed_choice = 0
return

label e3s11_notebooks:

    $ e3s11_explore += 1
    if e3s11_explore == 4:
        return
    scene e3s11-fr_02-notebooks
    call screen e3s11_02_notebooks with dissolve
return

# 03 ###########################################################################
label e3s11_03:
    scene e3s11-fr_03
    call screen e3s11_03 with dissolve
return

label e3s11_pb:
    scene e3s11-fr_03
    mc "*Wait.. is that..*"
    mc "*What the hell is peanut butter doing there?*"
    mc "*Ain't no way that picture is hiding it.*"
    mc "*This is one weird lady..*"

    $ e3s11_pb = True

    $ e3s11_explore += 1

    if e3s11_explore == 4:
        return

    jump e3s11_03
return

# 04 ###########################################################################
label e3s11_04:
    scene e3s11-fr_04
    call screen e3s11_04 with dissolve
return

label e3s11_toy:
    $ e3s11_toy = True
    scene e3s11-fr_04
    mc "*Heh, that's a cute bear.*"
    mc "*She might not be so cold after all.*"

    $ e3s11_explore += 1

    if e3s11_explore == 4:
        return

    jump e3s11_04
return

label e3s11_bin:
    if e3s11_bin == False:
        scene e3s11-fr_04_bin with dissolve
        mc "*Come on.. what am I doing searching in the bin?*"
        mc "*There's no way she would have put [sd]'s phone in here.*"

        $ e3s11_explore += 1

        if e3s11_explore == 4:
            return

        $ e3s11_bin = True

    scene e3s11-fr_04_bin
    call screen e3s11_04_bin with dissolve
return
