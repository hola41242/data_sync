
# Scene 25 images ##############################################################

image e3s25-01 = im.Scale("season1/episode3/images/scene25/1.webp", 1920, 1080)
image e3s25-02 = im.Scale("season1/episode3/images/scene25/2.webp", 1920, 1080)
image e3s25-03 = im.Scale("season1/episode3/images/scene25/3.webp", 1920, 1080)
image e3s25-04 = im.Scale("season1/episode3/images/scene25/4.webp", 1920, 1080)
image e3s25-05 = im.Scale("season1/episode3/images/scene25/5.webp", 1920, 1080)
image e3s25-06 = im.Scale("season1/episode3/images/scene25/6.webp", 1920, 1080)
image e3s25-07 = im.Scale("season1/episode3/images/scene25/7.webp", 1920, 1080)
image e3s25-08 = im.Scale("season1/episode3/images/scene25/8.webp", 1920, 1080)
image e3s25-09 = im.Scale("season1/episode3/images/scene25/9.webp", 1920, 1080)
image e3s25-10 = im.Scale("season1/episode3/images/scene25/10.webp", 1920, 1080)
image e3s25-11 = im.Scale("season1/episode3/images/scene25/11.webp", 1920, 1080)
image e3s25-12 = im.Scale("season1/episode3/images/scene25/12.webp", 1920, 1080)
image e3s25-13 = im.Scale("season1/episode3/images/scene25/13.webp", 1920, 1080)
image e3s25-14 = im.Scale("season1/episode3/images/scene25/14.webp", 1920, 1080)
image e3s25-15 = im.Scale("season1/episode3/images/scene25/15.webp", 1920, 1080)
image e3s25-16 = im.Scale("season1/episode3/images/scene25/16.webp", 1920, 1080)
image e3s25-17 = im.Scale("season1/episode3/images/scene25/17.webp", 1920, 1080)
image e3s25-18 = im.Scale("season1/episode3/images/scene25/18.webp", 1920, 1080)
image e3s25-19 = im.Scale("season1/episode3/images/scene25/19.webp", 1920, 1080)
image e3s25-20 = im.Scale("season1/episode3/images/scene25/20.webp", 1920, 1080)
image e3s25-21 = im.Scale("season1/episode3/images/scene25/21.webp", 1920, 1080)
image e3s25-22 = im.Scale("season1/episode3/images/scene25/22.webp", 1920, 1080)
image e3s25-23 = im.Scale("season1/episode3/images/scene25/23.webp", 1920, 1080)
image e3s25-24 = im.Scale("season1/episode3/images/scene25/24.webp", 1920, 1080)
image e3s25-25 = im.Scale("season1/episode3/images/scene25/25.webp", 1920, 1080)
image e3s25-26 = im.Scale("season1/episode3/images/scene25/26.webp", 1920, 1080)
image e3s25-27 = im.Scale("season1/episode3/images/scene25/27.webp", 1920, 1080)
image e3s25-28 = im.Scale("season1/episode3/images/scene25/28.webp", 1920, 1080)
image e3s25-29 = im.Scale("season1/episode3/images/scene25/29.webp", 1920, 1080)
image e3s25-30 = im.Scale("season1/episode3/images/scene25/30.webp", 1920, 1080)
image e3s25-31 = im.Scale("season1/episode3/images/scene25/31.webp", 1920, 1080)
image e3s25-32 = im.Scale("season1/episode3/images/scene25/32.webp", 1920, 1080)
image e3s25-33 = im.Scale("season1/episode3/images/scene25/33.webp", 1920, 1080)
image e3s25-34 = im.Scale("season1/episode3/images/scene25/34.webp", 1920, 1080)
image e3s25-35 = im.Scale("season1/episode3/images/scene25/35.webp", 1920, 1080)
image e3s25-36 = im.Scale("season1/episode3/images/scene25/36.webp", 1920, 1080)
image e3s25-37 = im.Scale("season1/episode3/images/scene25/37.webp", 1920, 1080)
image e3s25-38 = im.Scale("season1/episode3/images/scene25/38.webp", 1920, 1080)
image e3s25-39 = im.Scale("season1/episode3/images/scene25/39.webp", 1920, 1080)
image e3s25-40 = im.Scale("season1/episode3/images/scene25/40.webp", 1920, 1080)
image e3s25-41 = im.Scale("season1/episode3/images/scene25/41.webp", 1920, 1080)
image e3s25-42 = im.Scale("season1/episode3/images/scene25/42.webp", 1920, 1080)
image e3s25-43 = im.Scale("season1/episode3/images/scene25/43.webp", 1920, 1080)
image e3s25-44 = im.Scale("season1/episode3/images/scene25/44.webp", 1920, 1080)
image e3s25-45 = im.Scale("season1/episode3/images/scene25/45.webp", 1920, 1080)
image e3s25-46 = im.Scale("season1/episode3/images/scene25/46.webp", 1920, 1080)
image e3s25-47 = im.Scale("season1/episode3/images/scene25/47.webp", 1920, 1080)
image e3s25-48 = im.Scale("season1/episode3/images/scene25/48.webp", 1920, 1080)

# Animations #
# Static
image e3s25_cleo_blink2:
    im.Scale("season1/episode3/images/scene25/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s25_cleo_blink3:
    im.Scale("season1/episode3/images/scene25/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene25/cleo_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e3s25-kiss1 = Movie(play="season1/episode3/images/scene25/kiss1.webm")
image e3s25-kiss2 = Movie(play="season1/episode3/images/scene25/kiss2.webm")
