
# Scene 18 images ###############################################################

image e3s18-01 = im.Scale("season1/episode3/images/scene18/1.webp", 1920, 1080)
image e3s18-02 = im.Scale("season1/episode3/images/scene18/2.webp", 1920, 1080)
image e3s18-03 = im.Scale("season1/episode3/images/scene18/3.webp", 1920, 1080)
image e3s18-04 = im.Scale("season1/episode3/images/scene18/4.webp", 1920, 1080)
image e3s18-05 = im.Scale("season1/episode3/images/scene18/5.webp", 1920, 1080)
image e3s18-06 = im.Scale("season1/episode3/images/scene18/6.webp", 1920, 1080)
image e3s18-07 = im.Scale("season1/episode3/images/scene18/7.webp", 1920, 1080)
image e3s18-08 = im.Scale("season1/episode3/images/scene18/8.webp", 1920, 1080)
image e3s18-09 = im.Scale("season1/episode3/images/scene18/9.webp", 1920, 1080)
image e3s18-10 = im.Scale("season1/episode3/images/scene18/10.webp", 1920, 1080)
image e3s18-11 = im.Scale("season1/episode3/images/scene18/11.webp", 1920, 1080)
image e3s18-12 = im.Scale("season1/episode3/images/scene18/12.webp", 1920, 1080)
image e3s18-13 = im.Scale("season1/episode3/images/scene18/13.webp", 1920, 1080)
image e3s18-14 = im.Scale("season1/episode3/images/scene18/14.webp", 1920, 1080)
image e3s18-15 = im.Scale("season1/episode3/images/scene18/15.webp", 1920, 1080)
image e3s18-16 = im.Scale("season1/episode3/images/scene18/16.webp", 1920, 1080)
image e3s18-17 = im.Scale("season1/episode3/images/scene18/17.webp", 1920, 1080)
image e3s18-18 = im.Scale("season1/episode3/images/scene18/18.webp", 1920, 1080)
image e3s18-19 = im.Scale("season1/episode3/images/scene18/19.webp", 1920, 1080)
image e3s18-20 = im.Scale("season1/episode3/images/scene18/20.webp", 1920, 1080)
image e3s18-21 = im.Scale("season1/episode3/images/scene18/21.webp", 1920, 1080)
image e3s18-22 = im.Scale("season1/episode3/images/scene18/22.webp", 1920, 1080)
image e3s18-23 = im.Scale("season1/episode3/images/scene18/23.webp", 1920, 1080)
image e3s18-24 = im.Scale("season1/episode3/images/scene18/24.webp", 1920, 1080)
image e3s18-25 = im.Scale("season1/episode3/images/scene18/25.webp", 1920, 1080)
image e3s18-26 = im.Scale("season1/episode3/images/scene18/26.webp", 1920, 1080)
image e3s18-27 = im.Scale("season1/episode3/images/scene18/27.webp", 1920, 1080)
image e3s18-28 = im.Scale("season1/episode3/images/scene18/28.webp", 1920, 1080)
image e3s18-29 = im.Scale("season1/episode3/images/scene18/29.webp", 1920, 1080)
image e3s18-30 = im.Scale("season1/episode3/images/scene18/30.webp", 1920, 1080)
image e3s18-31 = im.Scale("season1/episode3/images/scene18/31.webp", 1920, 1080)
image e3s18-32 = im.Scale("season1/episode3/images/scene18/32.webp", 1920, 1080)
image e3s18-33 = im.Scale("season1/episode3/images/scene18/33.webp", 1920, 1080)
image e3s18-34 = im.Scale("season1/episode3/images/scene18/34.webp", 1920, 1080)
image e3s18-35 = im.Scale("season1/episode3/images/scene18/35.webp", 1920, 1080)
image e3s18-36 = im.Scale("season1/episode3/images/scene18/36.webp", 1920, 1080)
image e3s18-37 = im.Scale("season1/episode3/images/scene18/37.webp", 1920, 1080)
image e3s18-38 = im.Scale("season1/episode3/images/scene18/38.webp", 1920, 1080)
image e3s18-39 = im.Scale("season1/episode3/images/scene18/39.webp", 1920, 1080)
image e3s18-40 = im.Scale("season1/episode3/images/scene18/40.webp", 1920, 1080)
image e3s18-41 = im.Scale("season1/episode3/images/scene18/41.webp", 1920, 1080)
image e3s18-42 = im.Scale("season1/episode3/images/scene18/42.webp", 1920, 1080)

image e3s18_scarlett_blink1:
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e3s18_scarlett_blink2:
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/scene18/scarlett_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
