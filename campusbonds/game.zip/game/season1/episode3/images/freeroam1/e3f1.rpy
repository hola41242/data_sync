
# Freeroam 1 Images ############################################################
# Main
image e3f1-01 = im.Scale("season1/episode3/images/freeroam1/1.webp", 1920, 1080)

# Drums
image e3f1-02 = im.Scale("season1/episode3/images/freeroam1/2.webp", 1920, 1080)

# couch
image e3f1-03 = im.Scale("season1/episode3/images/freeroam1/3.webp", 1920, 1080)

# Corner
image e3f1-04 = im.Scale("season1/episode3/images/freeroam1/4.webp", 1920, 1080)

# Left shelf
image e3f1-05 = im.Scale("season1/episode3/images/freeroam1/5.webp", 1920, 1080)

# Right shelf
image e3f1-06 = im.Scale("season1/episode3/images/freeroam1/6.webp", 1920, 1080)

# Piano
image e3f1-07 = im.Scale("season1/episode3/images/freeroam1/7.webp", 1920, 1080)

# Exit door
image e3f1-08 = im.Scale("season1/episode3/images/freeroam1/8.webp", 1920, 1080)


# Djembe
image e3f1-dj_01 = im.Scale("season1/episode3/images/freeroam1/images/djembe1/1.webp", 1920, 1080)
image e3f1-dj_02 = im.Scale("season1/episode3/images/freeroam1/images/djembe1/2.webp", 1920, 1080)
image e3f1-dj_03 = im.Scale("season1/episode3/images/freeroam1/images/djembe1/3.webp", 1920, 1080)
image e3f1-dj_04 = im.Scale("season1/episode3/images/freeroam1/images/djembe1/4.webp", 1920, 1080)
image e3f1-dj_05 = im.Scale("season1/episode3/images/freeroam1/images/djembe1/5.webp", 1920, 1080)

# Drums
image e3f1-dr_01 = im.Scale("season1/episode3/images/freeroam1/images/drums1/1.webp", 1920, 1080)
image e3f1-dr_02 = im.Scale("season1/episode3/images/freeroam1/images/drums1/2.webp", 1920, 1080)
image e3f1-dr_03 = im.Scale("season1/episode3/images/freeroam1/images/drums1/3.webp", 1920, 1080)
image e3f1-dr_04 = im.Scale("season1/episode3/images/freeroam1/images/drums1/4.webp", 1920, 1080)
image e3f1-dr_05 = im.Scale("season1/episode3/images/freeroam1/images/drums1/5.webp", 1920, 1080)
image e3f1-dr_06 = im.Scale("season1/episode3/images/freeroam1/images/drums1/6.webp", 1920, 1080)
image e3f1-dr_07 = im.Scale("season1/episode3/images/freeroam1/images/drums1/7.webp", 1920, 1080)
image e3f1-dr_08 = im.Scale("season1/episode3/images/freeroam1/images/drums1/8.webp", 1920, 1080)
image e3f1-dr_09 = im.Scale("season1/episode3/images/freeroam1/images/drums1/9.webp", 1920, 1080)
image e3f1-dr_10 = im.Scale("season1/episode3/images/freeroam1/images/drums1/10.webp", 1920, 1080)
image e3f1-dr_11 = im.Scale("season1/episode3/images/freeroam1/images/drums1/11.webp", 1920, 1080)
image e3f1-dr_12 = im.Scale("season1/episode3/images/freeroam1/images/drums1/12.webp", 1920, 1080)
image e3f1-dr_13 = im.Scale("season1/episode3/images/freeroam1/images/drums1/13.webp", 1920, 1080)
image e3f1-dr_14 = im.Scale("season1/episode3/images/freeroam1/images/drums1/14.webp", 1920, 1080)
image e3f1-dr_15 = im.Scale("season1/episode3/images/freeroam1/images/drums1/15.webp", 1920, 1080)
image e3f1-dr_16 = im.Scale("season1/episode3/images/freeroam1/images/drums1/16.webp", 1920, 1080)

# Ellie
image e3f1-el_01 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/1.webp", 1920, 1080)
image e3f1-el_02 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/2.webp", 1920, 1080)
image e3f1-el_03 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/3.webp", 1920, 1080)
image e3f1-el_04 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/4.webp", 1920, 1080)
image e3f1-el_05 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/5.webp", 1920, 1080)
image e3f1-el_06 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/6.webp", 1920, 1080)
image e3f1-el_07 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/7.webp", 1920, 1080)
image e3f1-el_08 = im.Scale("season1/episode3/images/freeroam1/images/ellie1/8.webp", 1920, 1080)

image e3f1_ellie_blink1:
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/ellie1/ellie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Flute
image e3f1-fl_01 = im.Scale("season1/episode3/images/freeroam1/images/flute1/1.webp", 1920, 1080)
image e3f1-fl_02 = im.Scale("season1/episode3/images/freeroam1/images/flute1/2.webp", 1920, 1080)
image e3f1-fl_03 = im.Scale("season1/episode3/images/freeroam1/images/flute1/3.webp", 1920, 1080)
image e3f1-fl_04 = im.Scale("season1/episode3/images/freeroam1/images/flute1/4.webp", 1920, 1080)

# Guitar
image e3f1-gu_01 = im.Scale("season1/episode3/images/freeroam1/images/guitar1/1.webp", 1920, 1080)
image e3f1-gu_02 = im.Scale("season1/episode3/images/freeroam1/images/guitar1/2.webp", 1920, 1080)
image e3f1-gu_03 = im.Scale("season1/episode3/images/freeroam1/images/guitar1/3.webp", 1920, 1080)
image e3f1-gu_04 = im.Scale("season1/episode3/images/freeroam1/images/guitar1/4.webp", 1920, 1080)

# Penny Eva
image e3f1-pe_01 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/1.webp", 1920, 1080)
image e3f1-pe_02 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/2.webp", 1920, 1080)
image e3f1-pe_03 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/3.webp", 1920, 1080)
image e3f1-pe_04 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/4.webp", 1920, 1080)
image e3f1-pe_05 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/5.webp", 1920, 1080)
image e3f1-pe_06 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/6.webp", 1920, 1080)
image e3f1-pe_07 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/7.webp", 1920, 1080)
image e3f1-pe_08 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/8.webp", 1920, 1080)
image e3f1-pe_09 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/9.webp", 1920, 1080)
image e3f1-pe_10 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/10.webp", 1920, 1080)
image e3f1-pe_11 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/11.webp", 1920, 1080)
image e3f1-pe_12 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/12.webp", 1920, 1080)
image e3f1-pe_13 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/13.webp", 1920, 1080)
image e3f1-pe_14 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/14.webp", 1920, 1080)
image e3f1-pe_15 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/15.webp", 1920, 1080)
image e3f1-pe_16 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/16.webp", 1920, 1080)
image e3f1-pe_17 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/17.webp", 1920, 1080)
image e3f1-pe_18 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/18.webp", 1920, 1080)
image e3f1-pe_19 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/19.webp", 1920, 1080)
image e3f1-pe_20 = im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/20.webp", 1920, 1080)

image e3f1_penny_blink1:
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode3/images/freeroam1/images/penny_eva1/penny_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Piano
image e3f1-pi_01 = im.Scale("season1/episode3/images/freeroam1/images/piano1/1.webp", 1920, 1080)
image e3f1-pi_02 = im.Scale("season1/episode3/images/freeroam1/images/piano1/2.webp", 1920, 1080)
image e3f1-pi_03 = im.Scale("season1/episode3/images/freeroam1/images/piano1/3.webp", 1920, 1080)
image e3f1-pi_04 = im.Scale("season1/episode3/images/freeroam1/images/piano1/4.webp", 1920, 1080)
image e3f1-pi_05 = im.Scale("season1/episode3/images/freeroam1/images/piano1/5.webp", 1920, 1080)
