
# Variables ####################################################################

default e1f5_sadie_tracy_1 = False
default e1f5_nate_bar1 = False
default e1f5_outside = False
default e1f5_sadie_drink2 = 0
default e1f5_tracy_drink = 0
default e1f5_banana = False
default e1f5_finish = False
default e1f5_sadie_introvert = False
default e1f5_money = False
default e1f5_tracy_drink_ask = False
default e1f5_francesca = False

default e1f5_explore = 0

# Freeroam Collected Photos #

default persistent.e1f5_collected_p = 0
default persistent.e1f5_collected_tp = 5

# Main #########################################################################

label e1f5_main:

    if e1f5_sadie_tracy_1 == False and e1f5_outside == True and affinity_spectrum < 0:
        $ e1f5_sadie_tracy_1 = True

        $ e1f5_explore += 1

        $ optional_quests.append("Talk to Sadie at the bar.")

        if e1f5_explore == 3:
            $ current_quests.remove("Interact with people.")

    if e1f5_sadie_tracy_1 == False:
        scene e1f5-01
    elif e1f5_tracy_drink < 7:
            if e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
                scene e1f5-01-3
            else:
                scene e1f5-01-1
    elif e1f5_tracy_drink == 7:
        if e1f5_refuse_sadie == False:
            if e1f5_tracy_sex == True:
                scene e1f5-01-1
            else:
                scene e1f5-01-2
        elif e1f5_refuse_sadie == False or e1f5_sadie_introvert == True:
            if e1f5_tracy_sex == True:
                scene e1f5-01-3
            else:
                scene e1f5-01-4

    call screen e1f5_main with dissolve
return

# Clickables #

label e1f5_sadie_tracy_1:

    if affinity_spectrum >= 0:
        scene sdtr1_e1f5-02 with dissolve
        pause

        scene sdtr1_e1f5-03 with dissolve
        sd "Come on, move it [tr]!"

        scene sdtr1_e1f5-01 with dissolve
        mc "Hey girls!"

        scene sdtr1_e1f5-06 with dissolve
        tr "[mc]!"

        scene sdtr1_e1f5-05 with dissolve
        sd "Haha!"

        scene sdtr1_e1f5-04 with dissolve
        sd "Come dance with us."
        mc "You girls are crazy."

        scene sdtr1_e1f5-07 with dissolve
        pause

        scene sdtr1_e1f5-08 with dissolve
        pause

        scene sdtr1_e1f5-09 with dissolve
        pause

        scene sdtr1_e1f5-10 with dissolve
        pause

        if affinity_spectrum > 0:
            scene sdtr1_e1f5-11 with dissolve
            pause

            scene sdtr1_e1f5-12 with dissolve
            pause

            scene sdtr1_e1f5-13 with dissolve
            sd "Mmm..."

        scene sdtr1_e1f5-14 with dissolve
        tr "Yeah [sd]! Just like that."

        scene sdtr1_e1f5-15 with dissolve
        mc "Damn, you got moves."

        scene sdtr1_e1f5-16 with dissolve
        pause

        scene sdtr1_e1f5-17 with dissolve
        pause

        scene sdtr1_e1f5-18 with dissolve
        pause

        scene sdtr1_e1f5-19 with dissolve
        mc "Alright, alright, I'll leave you girls to it."
        mc "I'm gonna go and meet some more people."

        scene sdtr1_e1f5-20 with dissolve
        sd "Alright, have fun!"

        if affinity_spectrum > 0:
            play sound punch
            scene sdtr1_e1f5-27 with vpunch
            pause

            scene sdtr1_e1f5-28 with dissolve
            mc "You're crazy."

            scene sdtr1_e1f5-29 with dissolve
            sd "Haha!"

        if affinity_spectrum > 0:
            scene sdtr1_e1f5-21 with dissolve
            tr "Hey [mc], would you mind grabbing me a drink if you come across the bar?"

            scene sdtr1_e1f5-22 with dissolve
            show sdtr1_e1f5-tracy_blink1
            mc "Sure, what would you like?"

            scene sdtr1_e1f5-23 with dissolve
            hide sdtr1_e1f5-tracy_blink1
            tr "I'd like an orange margarita."

            scene sdtr1_e1f5-24 with dissolve
            tr "Could you ask them to drop in two pieces of orange when you order the drink?"

            scene sdtr1_e1f5-23 with dissolve
            tr "They usually don't do that unless you ask them."

            scene sdtr1_e1f5-25 with dissolve
            tr "I love how it complements the taste."

            scene sdtr1_e1f5-22 with dissolve
            show sdtr1_e1f5-tracy_blink1
            mc "Alright, no problemo!"

            scene sdtr1_e1f5-26 with dissolve
            hide sdtr1_e1f5-tracy_blink1
            pause

            $ e1f5_tracy_drink_ask = True

            $ optional_quests.append("Get Tracy a margarita.")

        $ e1f5_sadie_tracy_1 = True

        $ e1f5_explore += 1

        if e1f5_explore == 3:
            $ current_quests.remove("Interact with people.")

        $ optional_quests.append("Talk to Sadie at the bar.")

        scene e1f5-01-1 with Dissolve(0.5)

    else:
        scene e1f5-01
        "*I shouldn't disturb them.*"

    call screen e1f5_main with dissolve
return

# Bar #########################################################################

label e1f5_bar:

    if e1f5_sadie_tracy_1 == False and e1f5_refuse_sadie == False:
        scene e1f5-02

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
        scene e1f5-02-1

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
        scene e1f5-02

    call screen e1f5_bar with dissolve
return

# Clickables #

label e1f5_sadie_drink1:

    scene sddr_e1f5-01 with dissolve
    mc "What's up?"

    scene sddr_e1f5-04 with dissolve
    sd "I'm resting a bit."

    scene sddr_e1f5-05 with dissolve
    sd "All that dancing is making my feet hurt."

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    mc "Haha, I know right?"

    scene sddr_e1f5-04 with dissolve
    hide sddr_e1f5-sadie_blink1
    sd "Especially when you're wearing heels."

    scene sddr_e1f5-03 with dissolve
    if affinity_spectrum > 0:
        mc "Oh shit!"
    else:
        mc "Oh wow."
    mc "Don't you have a spare pair of shoes?"

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    mc "Normal shoes perhaps?"

    scene sddr_e1f5-06 with dissolve
    hide sddr_e1f5-sadie_blink1
    sd "To be honest, no."
    sd "I wasn't expecting to see people dance."

    scene sddr_e1f5-05 with dissolve
    sd "Anyways, you drinking or what?"

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    menu:
        "Drink with her":
            call extrovert_affinity_check from _call_extrovert_affinity_check_3
            $ e1f5_sadie_drink2 = 1
            call color_check from _call_color_check_6
            mc "Sure, what's on the menu?"

            scene sddr_e1f5-12 with dissolve
            hide sddr_e1f5-sadie_blink1
            sd "Vodka babyy!"

            scene sddr_e1f5-02 with dissolve
            show sddr_e1f5-sadie_blink1
            mc "Alright!"

            if affinity_spectrum >= 0:
                scene sddr_e1f5-13 with dissolve
                hide sddr_e1f5-sadie_blink1
                mc "Hey, bartender!"
                mc "Two vodka shots here."
            else:
                scene sddr_e1f5-11 with dissolve
                hide sddr_e1f5-sadie_blink1
                sd "Hey, bartender!"
                sd "Two vodka shots here."

            scene sddr_e1f5-14 with dissolve
            ba "Coming right up."

            $ renpy.show_screen("money_notify_pers")
            scene sddr_e1f5-15 with dissolve
            menu:
                "Pay for her drink {color=#f00}(-$1){/color}" if money >= 1:

                    $ money -= 1
                    $ sadie_trust += 1

                    scene sddr_e1f5-16 with dissolve
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    mc "Hey, my treat."

                    scene sddr_e1f5-12 with dissolve
                    sd "Woooo!"

                "Don't pay for her drink":
                    scene sddr_e1f5-15 with dissolve
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    pass

            scene sddr_e1f5-17 with dissolve
            ba "Here are your shots."

            scene sddr_e1f5-18 with dissolve
            pause

            scene sddr_e1f5-19 with dissolve
            mc "Ohh, that's some strong stuff!"

            scene sddr_e1f5-04 with dissolve
            sd "That's strong?"

            scene sddr_e1f5-05 with dissolve
            sd "You're a rookie."

            scene sddr_e1f5-06 with dissolve
            sd "It's not even the strongest they have."

            scene sddr_e1f5-02 with dissolve
            show sddr_e1f5-sadie_blink1
            mc "There's something stronger?"

            scene sddr_e1f5-20 with dissolve
            hide sddr_e1f5-sadie_blink1
            sd "There's always something stronger!"

            scene sddr_e1f5-02 with dissolve
            show sddr_e1f5-sadie_blink1
            mc "Haha, I know what you're thinking."
            mc "I'm not drinking it right now, I wanna get home in one piece."

            scene sddr_e1f5-04 with dissolve
            hide sddr_e1f5-sadie_blink1
            sd "If you change your mind, you know where to find me."

            scene sddr_e1f5-02 with dissolve
            show sddr_e1f5-sadie_blink1
            mc "Haha, you're crazy!"

            $ optional_quests.append("Drink the shot with Sadie.")

        "Don't drink":
            call introvert_affinity_check from _call_introvert_affinity_check_2
            $ sadie_trust -= 1
            $ e1f5_sadie_drink2 = 2
            call color_check from _call_color_check_7
            mc "Nah, not tonight, sorry."

            scene sddr_e1f5-07 with dissolve
            hide sddr_e1f5-sadie_blink1
            sd "Duude, you're at a party..."

            scene sddr_e1f5-08 with dissolve
            sd "What do you mean you're not gonna drink?"

            scene sddr_e1f5-09 with dissolve
            show sddr_e1f5-sadie_blink2
            mc "Not really feeling like it right now."

            scene sddr_e1f5-10 with dissolve
            hide sddr_e1f5-sadie_blink2
            sd "Pfft, alright, suit yourself."

            scene sddr_e1f5-11 with dissolve
            sd "Hey, [ba]!"
            sd "Give me a vodka shot."

    $ optional_quests.remove("Talk to Sadie at the bar.")

    if e1f5_sadie_tracy_1 == False:
        scene e1f5-02 with Dissolve(0.5)
    else:
        scene e1f5-02-1 with Dissolve(0.5)

    call screen e1f5_bar with dissolve
return

label e1f5_sadie_drink2:

    scene sddr_e1f5-05 with dissolve
    sd "So, you're up for the challenge now?"

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    mc "We're doing challenges now?"

    scene sddr_e1f5-04 with dissolve
    hide sddr_e1f5-sadie_blink1
    sd "Don't worry, it's nothing too crazy."

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    mc "Alright, I'm ready."

    scene sddr_e1f5-06 with dissolve
    hide sddr_e1f5-sadie_blink1
    sd "Perfect!"

    scene sddr_e1f5-11 with dissolve
    sd "Hey, [ba]."
    sd "Can we get the Baiser shot?"

    scene sddr_e1f5-14 with dissolve
    ba "Alright."

    scene sddr_e1f5-02 with dissolve
    show sddr_e1f5-sadie_blink1
    mc "What's the Baiser shot?"

    scene sddr_e1f5-04 with dissolve
    hide sddr_e1f5-sadie_blink1
    sd "Haha, you'll see!"

    scene sddr_e1f5-21 with dissolve
    ba "Here's your shots."

    scene sddr_e1f5-22 with dissolve
    sd "Alright, we're gonna drink the shot at the same time."

    scene sddr_e1f5-23 with dissolve
    sd "But don't swallow it, wait for my signal!"

    scene sddr_e1f5-24 with dissolve
    mc "Seems easy enough."

    scene sddr_e1f5-25 with dissolve
    pause

    scene sddr_e1f5-26 with dissolve
    menu:

        "Kiss her":

            scene sddr_e1f5-kiss with dissolve
            pause

            scene sddr_e1f5-04 with dissolve
            sd "Hey [mc], wanna check something out?"

            scene sddr_e1f5-02 with dissolve
            show sddr_e1f5-sadie_blink1
            mc "What?"

            scene sddr_e1f5-33 with dissolve
            hide sddr_e1f5-sadie_blink1
            pause

            if persistent.disable_nsfw == True:

                scene sddr_e1f5-34 with dissolve
                mc "*Oh shit, she's not wearing any panties.*"

            else:

                if persistent.type_nsfw == False:

                    scene sddr_e1f5-34_cen with dissolve
                    mc "*Oh shit, she's not wearing any panties.*"

            scene sddr_e1f5-35 with dissolve
            sd "Look how wet this shot made me."

            scene sddr_e1f5-36 with dissolve
            mc "That's pretty hot."

            if affinity_spectrum >= 0:

                scene sddr_e1f5-04 with dissolve
                sd "I'm gonna have a smoke, wanna come?"

                scene sddr_e1f5-02 with dissolve
                show sddr_e1f5-sadie_blink1
                menu:

                    "Go with her":

                        $ sadie_trust += 1

                        $ e1f5_sadie_sex = True

                        mc "Let's go!"

                        stop music fadeout 2.0

                        scene sddr_e1f5-37 with dissolve
                        hide sddr_e1f5-sadie_blink1
                        pause

                        call e1f5_sadie_sex from _call_e1f5_sadie_sex

                    "Don't go with her":

                        $ sadie_trust -= 1
                        $ e1f5_refuse_sadie = True

                        mc "Not really a smoker, sorry."

                        scene sddr_e1f5-09 with dissolve
                        hide sddr_e1f5-sadie_blink1
                        show sddr_e1f5-sadie_blink2
                        pause

                        scene sddr_e1f5-32 with dissolve
                        pause
                        mc "*Did I do something wrong?*"

            else:

                scene sddr_e1f5-04 with dissolve
                sd "I'm gonna go and have a smoke."

                scene sddr_e1f5-02 with dissolve
                show sddr_e1f5-sadie_blink1
                mc "Alright."
                mc "Take care!"

                $ e1f5_sadie_introvert = True

        "Refuse her advances":

            $ sadie_trust -= 2
            $ e1f5_refuse_sadie = True

            scene sddr_e1f5-27 with dissolve
            pause

            scene sddr_e1f5-28 with dissolve
            pause

            scene sddr_e1f5-29 with dissolve
            sd "Dude, what the fuck?"

            scene sddr_e1f5-30 with dissolve
            sd "I told you not to swallow!"

            scene sddr_e1f5-31 with dissolve
            show sddr_e1f5-sadie_blink3
            mc "You were gonna kiss me!"

            scene sddr_e1f5-29 with dissolve
            hide sddr_e1f5-sadie_blink3
            sd "Yeah, so?"

            scene sddr_e1f5-30 with dissolve
            sd "That's how you're supposed to drink the shot, idiot!"

            if e1f2_tracy_kiss == True:
                scene sddr_e1f5-29 with dissolve
                sd "Plus, you didn't have a problem kissing [tr] when you drank that shot from her tits!"

            scene sddr_e1f5-31 with dissolve
            show sddr_e1f5-sadie_blink3
            mc "[sd], look, I'm sorry..."

            scene sddr_e1f5-30 with dissolve
            hide sddr_e1f5-sadie_blink3
            sd "Ugh... move..."

            scene sddr_e1f5-32 with dissolve
            pause

    $ e1f5_sadie_drink2 = 2

    $ optional_quests.remove("Drink the shot with Sadie.")

    if e1f5_sadie_tracy_1 == False and e1f5_refuse_sadie == False:
        scene e1f5-02 with Dissolve(0.5)

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
        scene e1f5-02-1 with Dissolve(0.5)

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
        scene e1f5-02 with Dissolve(0.5)

    call e1f5_bar from _call_e1f5_bar
return

label e1f5_tracy_drink:

    # Ordering Tracy the 1st drink #############################################

    if e1f5_tracy_drink == 0:

        scene trdr_e1f5-01 with dissolve
        show trdr_e1f5-bartender_blink1
        mc "Hello?"

        scene trdr_e1f5-02 with dissolve
        hide trdr_e1f5-bartender_blink1
        ba "What would you like to order?"

        scene trdr_e1f5-01 with dissolve
        show trdr_e1f5-bartender_blink1
        mc "I'd like uh..."

        menu:
            "Strawberry margarita":

                $ e1f5_tracy_drink = 1

                mc "A strawberry margarita."

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Alright, coming right up."

                scene trdr_e1f5-01 with dissolve
                show trdr_e1f5-bartender_blink1
                mc "Oh and also, could you add two slices of strawberry?"

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Of course."

                scene trdr_e1f5-04 with dissolve
                mc "Thanks!"

                scene trdr_e1f5-07 with dissolve
                ba "Here's your drink."

                scene trdr_e1f5-10 with dissolve
                mc "Thanks!"

            "Banana margarita":

                $ e1f5_tracy_drink = 2
                $ tracy_trust -= 1
                $ e1f5_banana = True

                mc "A banana margarita."

                scene trdr_e1f5-13 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Uh, banana?"

                scene trdr_e1f5-02 with dissolve
                ba "Alright then, coming right up."

                scene trdr_e1f5-01 with dissolve
                show trdr_e1f5-bartender_blink1
                mc "Oh and also, could you add two slices of banana?"

                scene trdr_e1f5-14 with dissolve
                hide trdr_e1f5-bartender_blink1
                pause

                scene trdr_e1f5-15 with dissolve
                ba "Alright?"

                scene trdr_e1f5-14 with dissolve
                mc "Thanks!"

                scene trdr_e1f5-04 with dissolve
                ba "*That's a weird fella...*"

                scene trdr_e1f5-09 with dissolve
                ba "Here's your drink."
                mc "Thank you!"

                scene trdr_e1f5-12 with dissolve
                ba "This drink's on us, don't worry."
                mc "Nice! Thank you very much!"

                scene trdr_e1f5-16 with dissolve
                pause

            "Orange margarita":

                $ e1f5_tracy_drink = 3
                $ tracy_trust += 1

                mc "An orange margarita."

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Alright, coming right up."

                scene trdr_e1f5-01 with dissolve
                show trdr_e1f5-bartender_blink1
                mc "Oh and also, could you add two slices of orange?"

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Of course."

                scene trdr_e1f5-04 with dissolve
                mc "Thanks!"

                scene trdr_e1f5-08 with dissolve
                ba "Here's your drink."

                scene trdr_e1f5-11 with dissolve
                mc "Thanks!"

        $ optional_quests.remove("Get Tracy a margarita.")
        $ optional_quests.append("Give Tracy the drink.")

        if e1f5_sadie_tracy_1 == False and e1f5_refuse_sadie == False:
            scene e1f5-02 with Dissolve(0.5)

        if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
            scene e1f5-02-1 with Dissolve(0.5)

        if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
            scene e1f5-02 with Dissolve(0.5)

        call e1f5_bar from _call_e1f5_bar_1

    # Giving Tracy the 1st drink ###############################################

    # Strawberry
    if e1f5_tracy_drink == 1:

        scene trdr_e1f5-17 with dissolve
        mc "Here's the drink you ordered."

        scene trdr_e1f5-18 with dissolve
        tr "[mc], what's this?"

        scene trdr_e1f5-19 with dissolve
        show trdr_e1f5-tracy_blink1
        mc "The drink you ordered?"

        scene trdr_e1f5-20 with dissolve
        hide trdr_e1f5-tracy_blink1
        tr "I asked for an orange margarita, not strawberry."

        scene trdr_e1f5-19 with dissolve
        show trdr_e1f5-tracy_blink1
        mc "Oh shit, for real?"

        scene trdr_e1f5-21 with dissolve
        hide trdr_e1f5-tracy_blink1
        tr "It's alright [mc], I'll just drink this one instead."

        scene trdr_e1f5-20 with dissolve
        tr "You're lucky I also like strawberries."

        scene trdr_e1f5-22 with dissolve
        mc "Perfect then!"

        scene trdr_e1f5-29 with dissolve
        show trdr_e1f5-tracy_blink1
        mc "So, what are you up to?"

        $ optional_quests.remove("Give Tracy the drink.")

        jump e1f5_tracy_ask

    # Banana
    if e1f5_tracy_drink == 2:

        scene trdr_e1f5-17 with dissolve
        mc "Here's the drink you ordered."

        scene trdr_e1f5-39 with dissolve
        tr "Woo, thanks [mc]!"

        scene trdr_e1f5-24 with dissolve
        pause

        scene trdr_e1f5-40 with dissolve
        tr "[mc]?"
        tr "What the fuck is this?"

        scene trdr_e1f5-41 with dissolve
        show trdr_e1f5-tracy_blink4
        mc "The drink you ordered?"

        scene trdr_e1f5-40 with dissolve
        hide trdr_e1f5-tracy_blink4
        tr "This is {b}not{/b} an orange margarita."

        scene trdr_e1f5-41 with dissolve
        show trdr_e1f5-tracy_blink4
        mc "Wait, you asked for orange?"

        scene trdr_e1f5-42 with dissolve
        hide trdr_e1f5-tracy_blink4
        tr "Whatever [mc]..."

        scene trdr_e1f5-43 with dissolve
        tr "Just bring me another one."
        tr "This time, an {b}orange margarita{/b}, alright?"

        $ e1f5_tracy_drink = 4

        $ optional_quests.remove("Give Tracy the drink.")
        $ optional_quests.append("Get Tracy an orange margarita.")

        scene trdr_e1f5-37 with dissolve
        show trdr_e1f5-tracy_blink3
        mc "Okay, got it."

        call e1f5_main from _call_e1f5_main_1

    # Orange
    if e1f5_tracy_drink == 3:

        scene trdr_e1f5-17 with dissolve
        mc "Here's the drink you ordered."

        scene trdr_e1f5-31 with dissolve
        tr "Woo, thanks [mc]!"

        scene trdr_e1f5-23 with dissolve
        pause

        scene trdr_e1f5-25 with dissolve
        tr "Holy shit, this is so tasty!"

        scene trdr_e1f5-26 with dissolve
        tr "I'll have to be careful with the drinks tho."

        scene trdr_e1f5-27 with dissolve
        tr "I tend to get drunk a tad too fast."

        scene trdr_e1f5-26 with dissolve
        tr "Thank you [mc]!"

        scene trdr_e1f5-25 with dissolve
        tr "You also remembered about the orange slices."

        scene trdr_e1f5-28 with dissolve
        show trdr_e1f5-tracy_blink2
        mc "Haha, yeah!"
        mc "No problem [tr]."

        $ optional_quests.remove("Give Tracy the drink.")

        scene trdr_e1f5-23 with dissolve
        hide trdr_e1f5-tracy_blink2
        mc "So, what are you up to?"

        jump e1f5_tracy_ask

    # Ordering Tracy the 2nd drink #############################################

    if e1f5_banana == True and e1f5_tracy_drink < 5:

        scene trdr_e1f5-02 with dissolve
        ba "So, she didn't like the banana margarita?"

        scene trdr_e1f5-01 with dissolve
        show trdr_e1f5-bartender_blink1
        mc "I didn't even know this drink doesn't exist."

        scene trdr_e1f5-02 with dissolve
        hide trdr_e1f5-bartender_blink1
        ba "Well, I thought it'd be funny to try and make it for the first time and see how people react to it."
        ba "From what I've seen... not so well."

        scene trdr_e1f5-01 with dissolve
        show trdr_e1f5-bartender_blink1
        mc "Yeah..."
        mc "I really thought she said banana."

        scene trdr_e1f5-02 with dissolve
        hide trdr_e1f5-bartender_blink1
        ba "It's alright."
        ba "What can I give you?"

        scene trdr_e1f5-01 with dissolve
        show trdr_e1f5-bartender_blink1
        mc "I'd like uh..."

        menu:
            "Strawberry margarita":

                $ tracy_trust -= 1
                $ e1f5_tracy_drink = 5

                mc "A strawberry margarita."

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Alright, coming right up."

                scene trdr_e1f5-01 with dissolve
                show trdr_e1f5-bartender_blink1
                mc "Oh and also, could you add two slices of strawberry?"

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Of course."

                scene trdr_e1f5-04 with dissolve
                mc "Thanks!"

                scene trdr_e1f5-07 with dissolve
                ba "Here's your drink."

                scene trdr_e1f5-10 with dissolve
                mc "Thanks!"

            "Banana margarita" if e1f5_banana == False:
                pass

            "Orange margarita":

                $ tracy_trust += 1
                $ e1f5_tracy_drink = 6

                mc "An orange margarita."

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Alright, coming right up."

                scene trdr_e1f5-01 with dissolve
                show trdr_e1f5-bartender_blink1
                mc "Oh and also, could you add two slices of orange?"

                scene trdr_e1f5-03 with dissolve
                hide trdr_e1f5-bartender_blink1
                ba "Of course!"

                scene trdr_e1f5-04 with dissolve
                mc "Thanks!"

                scene trdr_e1f5-08 with dissolve
                ba "Here's your drink."

                scene trdr_e1f5-11 with dissolve
                mc "Thanks!"

        $ e1f5_banana = False

        if optional_quests:
            $ optional_quests.remove("Get Tracy an orange margarita.")
            $ optional_quests.append("Give Tracy the drink.")

        if e1f5_sadie_tracy_1 == False and e1f5_refuse_sadie == False:
            scene e1f5-02 with Dissolve(0.5)

        if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
            scene e1f5-02-1 with Dissolve(0.5)

        if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
            scene e1f5-02 with Dissolve(0.5)

        call e1f5_bar from _call_e1f5_bar_2

    # Giving Tracy the second drink ############################################

    # Strawberry
    if e1f5_tracy_drink == 5:

        scene trdr_e1f5-17 with dissolve
        mc "Here's the drink you ordered."

        scene trdr_e1f5-19 with dissolve
        show trdr_e1f5-tracy_blink1
        mc "This time I remembered that you wanted a strawberry margarita!"

        scene trdr_e1f5-21 with dissolve
        hide trdr_e1f5-tracy_blink1
        tr "[mc], what's wrong with you?"

        scene trdr_e1f5-20 with dissolve
        tr "Are you drunk already?"

        scene trdr_e1f5-19 with dissolve
        show trdr_e1f5-tracy_blink1
        mc "What?"

        scene trdr_e1f5-20 with dissolve
        tr "I said orange margarita, not strawberry!"

        scene trdr_e1f5-38 with dissolve
        tr "Forget it, I'm gonna get one myself."
        tr "Thanks for nothing, [mc]."

        scene trdr_e1f5-44 with dissolve
        pause

        $ e1f5_tracy_drink = 4

        $ optional_quests.remove("Give Tracy the drink.")

        scene trdr_e1f5-45 with dissolve
        mc "*I could have sworn she said strawberry...*"

        call e1f5_main from _call_e1f5_main_3

    # Orange
    if e1f5_tracy_drink == 6:

        scene trdr_e1f5-17 with dissolve
        mc "Here's the drink you ordered."

        scene trdr_e1f5-25 with dissolve
        tr "Finally!"

        scene trdr_e1f5-26 with dissolve
        tr "Thanks [mc]!"

        scene trdr_e1f5-23 with dissolve
        pause

        scene trdr_e1f5-25 with dissolve
        tr "Holy shit, this is so tasty!"

        scene trdr_e1f5-26 with dissolve
        tr "I'll have to be careful with the drinks tho, I tend to get drunk a tad too fast."

        scene trdr_e1f5-28 with dissolve
        show trdr_e1f5-tracy_blink2
        mc "Haha, yeah!"
        mc "No problem [tr]."

        scene trdr_e1f5-23 with dissolve
        hide trdr_e1f5-tracy_blink2
        mc "So, what are you up to?"

        if optional_quests:
            $ optional_quests.remove("Give Tracy the drink.")

        jump e1f5_tracy_ask
return

label e1f5_tracy_ask:

    scene trdr_e1f5-32 with dissolve
    tr "Tonight I'm gonna get wasted!"

    scene trdr_e1f5-30 with dissolve
    show trdr_e1f5-tracy_blink2
    mc "That's your plan?"

    scene trdr_e1f5-33 with dissolve
    hide trdr_e1f5-tracy_blink2
    tr "Yeah."

    scene trdr_e1f5-34 with dissolve
    tr "I love to party when I'm drunk."

    scene trdr_e1f5-30 with dissolve
    show trdr_e1f5-tracy_blink2
    mc "Cool!"

    scene trdr_e1f5-35 with dissolve
    hide trdr_e1f5-tracy_blink2
    tr "Did you drink anything tonight?"

    scene trdr_e1f5-30 with dissolve
    show trdr_e1f5-tracy_blink2
    mc "Not really."

    scene trdr_e1f5-37 with dissolve
    hide trdr_e1f5-tracy_blink2
    show trdr_e1f5-tracy_blink3
    mc "I've had a few drinks here and there."

    scene trdr_e1f5-34 with dissolve
    hide trdr_e1f5-tracy_blink3
    tr "Holy shit, really?"

    scene trdr_e1f5-33 with dissolve
    tr "Come on, let's drink something."

    scene trdr_e1f5-30 with dissolve
    show trdr_e1f5-tracy_blink2
    menu:
        "Drink with [tr]":
            call extrovert_affinity_check from _call_extrovert_affinity_check_4
            call color_check from _call_color_check_8
            mc "Alright, let's do it."

            scene trdr_e1f5-32 with dissolve
            hide trdr_e1f5-tracy_blink2
            tr "Nice!"

            scene trdr_e1f5-46 with dissolve
            pause

            scene trdr_e1f5-48 with dissolve
            mc "Vodka?"

            scene trdr_e1f5-49 with dissolve
            tr "Sounds good."

            scene sddr_e1f5-13 with dissolve
            mc "Hey, [ba]."
            mc "Two vodka shots here."

            scene sddr_e1f5-14 with dissolve
            ba "Alright!"

            scene trdr_e1f5-50 with dissolve
            tr "Cheers, [mc]!"

            scene trdr_e1f5-47 with dissolve
            pause

            scene trdr_e1f5-51 with dissolve
            tr "That's strong stuff!"

            scene trdr_e1f5-52 with dissolve
            show trdr_e1f5-tracy_blink5
            mc "Hah, yeah!"

            if affinity_spectrum > 0 and tracy_trust >= 3:
                scene trdr_e1f5-51 with dissolve
                hide trdr_e1f5-tracy_blink5
                tr "I need to use the restrooms."

                scene trdr_e1f5-53 with dissolve
                tr "I shouldn't tell you about this, but meet me there if you'd like to have some fun."

                scene trdr_e1f5-52 with dissolve
                show trdr_e1f5-tracy_blink5
                mc "Fun?"

                scene trdr_e1f5-54 with dissolve
                hide trdr_e1f5-tracy_blink5
                tr "Just trust me on this one, see you there."

                scene trdr_e1f5-52 with dissolve
                show trdr_e1f5-tracy_blink5
                mc "Alright alright."

                $ optional_quests.append("Follow Tracy to the bathroom.")

                $ e1f5_tracy_drink = 7

                scene trdr_e1f5-55 with dissolve
                hide trdr_e1f5-tracy_blink5
                pause

            else:
                scene trdr_e1f5-53 with dissolve
                hide trdr_e1f5-tracy_blink5
                tr "I need to use the restrooms."

                scene trdr_e1f5-51 with dissolve
                tr "See you later, [mc]!"

                scene trdr_e1f5-52 with dissolve
                show trdr_e1f5-tracy_blink5
                mc "See you later [tr]!"

                scene trdr_e1f5-55 with dissolve
                hide trdr_e1f5-tracy_blink5
                pause

                $ e1f5_tracy_drink = 4

        "Don't drink":
            call introvert_affinity_check from _call_introvert_affinity_check_3
            call color_check from _call_color_check_9
            mc "Sorry, I'm not drinking."

            scene trdr_e1f5-36 with dissolve
            hide trdr_e1f5-tracy_blink2
            tr "Huh, why?"

            scene trdr_e1f5-34 with dissolve
            show trdr_e1f5-tracy_blink3
            mc "Just not feeling like it."

            scene trdr_e1f5-36 with dissolve
            hide trdr_e1f5-tracy_blink3
            tr "Psst, suit yourself."

            $ e1f5_tracy_drink = 4

    jump e1f5_main
return

label e1f5_nate_bar1:
    scene ntbr_e1f5-01 with dissolve
    mc "Hey [nt]!"

    scene ntbr_e1f5-02 with dissolve
    show ntbr_e1f5-nate_blink1
    mc "What's up?"

    scene ntbr_e1f5-04 with dissolve
    hide ntbr_e1f5-nate_blink1
    nt "Hey [mc]!"

    scene ntbr_e1f5-03 with dissolve
    nt "I was just looking around."

    scene ntbr_e1f5-02 with dissolve
    show ntbr_e1f5-nate_blink1
    mc "Are you eyeballing those drinks?"

    scene ntbr_e1f5-04 with dissolve
    hide ntbr_e1f5-nate_blink1
    nt "Yeah man!"

    scene ntbr_e1f5-05 with dissolve
    nt "All those drinks look real good on that shelf."

    scene ntbr_e1f5-03 with dissolve
    nt "Hey, do you want a drink?"

    scene ntbr_e1f5-02 with dissolve
    show ntbr_e1f5-nate_blink1
    menu:
        "Drink with [nt]":
            call extrovert_affinity_check from _call_extrovert_affinity_check_5
            call color_check from _call_color_check_10

            mc "Sure man!"

            scene ntbr_e1f5-06 with dissolve
            hide ntbr_e1f5-nate_blink1
            nt "Hey, bartender!"
            nt "Could you give us 2 drinks with rum and coke?"

            scene ntbr_e1f5-07 with dissolve
            ba "Sure!"

            scene ntbr_e1f5-08 with dissolve
            ba "Here you are."
            nt "Thanks!"
            nt "This one's on me."
            mc "Thanks, [nt]!"

            scene ntbr_e1f5-10 with dissolve
            pause

        "Don't drink":
            call introvert_affinity_check from _call_introvert_affinity_check_4
            call color_check from _call_color_check_11

            mc "Nah, sorry!"
            mc "Maybe I'll drink something later."

            scene ntbr_e1f5-04 with dissolve
            hide ntbr_e1f5-nate_blink1
            nt "Alright, don't worry."

            scene ntbr_e1f5-06 with dissolve
            nt "Hey, bartender!"
            nt "Could you give me a drink with rum and coke?"

            scene ntbr_e1f5-07 with dissolve
            ba "Sure!"

            scene ntbr_e1f5-09 with dissolve
            ba "Here you are."
            nt "Thanks!"

            scene ntbr_e1f5-11 with dissolve
            pause

    scene ntbr_e1f5-12 with dissolve
    show ntbr_e1f5-nate_blink2
    mc "So, what's up man?"
    mc "Why aren't you dancing?"

    scene ntbr_e1f5-13 with dissolve
    hide ntbr_e1f5-nate_blink2
    nt "I don't know bro..."

    scene ntbr_e1f5-14 with dissolve
    nt "I feel like I need a little bit of courage."

    scene ntbr_e1f5-13 with dissolve
    nt "That's why I'm drinking."

    scene ntbr_e1f5-12 with dissolve
    show ntbr_e1f5-nate_blink2
    mc "Doesn't sound like the best idea to me."

    scene ntbr_e1f5-14 with dissolve
    hide ntbr_e1f5-nate_blink2
    nt "Don't worry, I'm not gonna get wasted."

    scene ntbr_e1f5-15 with dissolve
    nt "Just one or two drinks."

    scene ntbr_e1f5-16 with dissolve
    show ntbr_e1f5-nate_blink3
    mc "Well, you do you man."
    pause

    scene ntbr_e1f5-15 with dissolve
    hide ntbr_e1f5-nate_blink1
    hide ntbr_e1f5-nate_blink3
    nt "I wonder what happened at Eddy's..."

    scene ntbr_e1f5-12 with dissolve
    show ntbr_e1f5-nate_blink2
    mc "Yeah... me too."

    if e1f5_bouncer_talk == True:

        mc "I actually talked to the bouncer."

        if e1s18_ken_greet == False:

            mc "Did you know he's the one that was supposed to be there tonight?"

            scene ntbr_e1f5-19 with dissolve
            hide ntbr_e1f5-nate_blink2
            nt "What a coincidence!"

            scene ntbr_e1f5-12 with dissolve
            show ntbr_e1f5-nate_blink2
            mc "Yeah..."

        mc "He said that he was supposed to work the night shift."
        mc "Meaning that he was supposed to guard the party."
        mc "He got there after the place was trashed."
        mc "He saw nothing."

        scene ntbr_e1f5-13 with dissolve
        hide ntbr_e1f5-nate_blink2
        nt "That's a bummer."

        scene ntbr_e1f5-12 with dissolve
        show ntbr_e1f5-nate_blink2
        mc "Yeah... maybe the day shift bouncer knows more."

        scene ntbr_e1f5-15 with dissolve
        hide ntbr_e1f5-nate_blink2
        nt "I feel sorry for the guys that spent all this time to organize the party..."
        nt "...just so it could be trashed that easily."

        scene ntbr_e1f5-12 with dissolve
        show ntbr_e1f5-nate_blink2
        mc "Yeah... poor [jon]..."

    else:

        if e1s18_ken_greet == True:

            scene ntbr_e1f5-17 with dissolve
            hide ntbr_e1f5-nate_blink2
            nt "Hey, maybe you should talk to the bouncer."

            scene ntbr_e1f5-14 with dissolve
            nt "If he's the one from there, maybe he knows something."

            scene ntbr_e1f5-12 with dissolve
            show ntbr_e1f5-nate_blink2
            mc "Hey, good idea!"
            mc "I'm gonna do that, thanks [nt]."

    mc "Hey, I'm gonna go meet some other people."
    mc "Thanks for the drink, [nt]!"

    $ e1f5_nate_bar1 = True

    $ e1f5_explore += 1

    if e1f5_explore == 3:
        $ current_quests.remove("Interact with people.")

    scene ntbr_e1f5-18 with dissolve
    hide ntbr_e1f5-nate_blink2
    nt "Don't mention it!"

    jump e1f5_bar
return

# Exit #########################################################################

label e1f5_exit:
    if e1f5_sadie_tracy_1 == False:
        scene e1f5-03
    else:
        scene e1f5-03-1

    if affinity_spectrum >= 0 and e1f5_nate_bar1 == True and e1f5_bouncer_talk == True and e1f5_outside == True and e1f5_sadie_tracy_1 == True:
        $ e1f5_finish = True

    if affinity_spectrum < 0 and e1f5_nate_bar1 == True and e1f5_bouncer_talk == True and e1f5_outside == True:
        $ e1f5_finish = True

    call screen e1f5_exit with dissolve
return

# Back #########################################################################

label e1f5_back:
    scene e1f5-04

    call screen e1f5_back with dissolve
return

# Bathroom #####################################################################

label e1f5_bathroom:

    if e1f5_tracy_drink == 7 and e1f5_tracy_sex == False:
        scene e1f5-05-1
    else:
        scene e1f5-05

    call screen e1f5_bathroom with dissolve
return

label e1f5_tracy_sex:

    scene trsx_e1f5-04 with dissolve
    mc "Hey [tr]!"

    scene trsx_e1f5-05 with dissolve
    tr "[mc]!"
    tr "I've been waiting you."

    scene trsx_e1f5-09 with dissolve
    mc "So, what's up?"

    scene trsx_e1f5-06 with dissolve
    tr "Are you ready, [mc]?"

    scene trsx_e1f5-10 with dissolve
    mc "Ready for what?"

    scene trsx_e1f5-07 with dissolve
    pause
    mc "You're crazy."

    scene trsx_e1f5-08 with dissolve
    tr "Don't tell me you never wanted to give it a try."

    scene trsx_e1f5-11 with dissolve
    mc "I mean..."

    scene trsx_e1f5-12 with dissolve
    tr "Here, take a hit!"

    scene trsx_e1f5-13 with dissolve
    show trsx_e1f5-tracy_blink2
    menu:
        "Take a hit":
            call extrovert_affinity_check from _call_extrovert_affinity_check_6
            $ tracy_trust += 1
            call color_check from _call_color_check_12

            jump e1f5_tracy_sex_2

        "Pass it" if not _in_replay:
            call introvert_affinity_check from _call_introvert_affinity_check_5
            call color_check from _call_color_check_13

            mc "Sorry, [tr]!"

            scene trsx_e1f5-18 with dissolve
            hide trsx_e1f5-tracy_blink2
            show trsx_e1f5-tracy_blink3
            mc "I'm gonna have to pass up the offer."

            scene trsx_e1f5-19 with dissolve
            hide trsx_e1f5-tracy_blink3
            tr "Are you sure [mc]?"

            scene trsx_e1f5-18 with dissolve
            show trsx_e1f5-tracy_blink3
            mc "Yeah, I'm not interested in trying it."

            scene trsx_e1f5-19 with dissolve
            hide trsx_e1f5-tracy_blink3
            tr "Alright I guess."
            tr "More for me!"

            scene trsx_e1f5-34 with dissolve
            pause

            scene trsx_e1f5-11 with dissolve
            mc "I'll leave you to it."

            $ e1f5_tracy_drink = 4

            $ optional_quests.remove("Follow Tracy to the bathroom.")

            scene trsx_e1f5-35 with dissolve
            pause

            jump e1f5_bathroom
return

label e1f5_tracy_sex_2:

    stop music

    play music turn_up

    if persistent.disable_nsfw == True:

        scene trsx_e1f5-14 with dissolve
        hide trsx_e1f5-tracy_blink2
        pause

        scene trsx_e1f5-16 with dissolve
        pause

        scene trsx_e1f5-17 with dissolve
        tr "Haha, don't worry [mc]!"
        tr "This is what happens on your first time."

        scene trsx_e1f5-20 with dissolve
        pause

        scene trsx_e1f5-08 with dissolve
        tr "It's gonna take effect in a little bit."

        scene trsx_e1f5-12 with dissolve
        tr "Here, take another hit."

        scene trsx_e1f5-15 with dissolve
        pause

        scene trsx_e1f5-22 with dissolve
        tr "How do you feel [mc]?"

        scene trsx_e1f5-mc_high with dissolve
        pause 1.9

        scene trsx_e1f5-23 with dissolve
        pause

        scene trsx_e1f5-21 with dissolve
        tr "Haha, are you okay [mc]?"

        scene trsx_e1f5-24 with dissolve
        mc "I feel amazing!"

        scene trsx_e1f5-25 with dissolve
        pause

        scene trsx_e1f5-26 with dissolve
        tr "Hey! Easy now, haha!"

        scene trsx_e1f5-01 with dissolve
        tr "I'm glad you like it [mc]!"

        scene trsx_e1f5-kiss with dissolve
        pause

        scene trsx_e1f5-02 with dissolve
        tr "Haha, I'm surprised you can still kiss me while being high."

        scene trsx_e1f5-kiss with dissolve
        pause

        scene trsx_e1f5-03 with dissolve
        show trsx_e1f5-tracy_blink1
        mc "If two vegans are arguing, is it considered beef?"

        scene trsx_e1f5-02 with dissolve
        hide trsx_e1f5-tracy_blink1
        tr "Haha, what?"
        tr "What are you saying, [mc]?"

        scene trsx_e1f5-03 with dissolve
        show trsx_e1f5-tracy_blink1
        mc "Oh yeah!"

        scene trsx_e1f5-02 with dissolve
        hide trsx_e1f5-tracy_blink1
        tr "Hey, [mc], wanna have sex?"

        scene trsx_e1f5-03 with dissolve
        show trsx_e1f5-tracy_blink1
        mc "What?"

        scene trsx_e1f5-02 with dissolve
        hide trsx_e1f5-tracy_blink1
        tr "Do you want to fuck?"

        scene trsx_e1f5-03 with dissolve
        show trsx_e1f5-tracy_blink1
        mc "Yeah!"

        scene trsx_e1f5-02 with dissolve
        hide trsx_e1f5-tracy_blink1
        tr "Alright then, stand still for me!"
        tr "I'm gonna give you the best high fuck of your life."

        scene trsx_e1f5-27 with dissolve
        tr "Prepare yourself [mc]."

        # Handjob ##############################################################

        scene trsx_e1f5-hand-01 with dissolve
        pause
        mc "Holy shit, this feels so good!"

        scene trsx_e1f5-hand-02 with dissolve
        pause

        scene trsx_e1f5-27 with dissolve
        tr "And now, for the main course..."

        # Blowjob ##############################################################

        scene trsx_e1f5-blow-01 with dissolve
        pause

        scene trsx_e1f5-blow-02 with dissolve
        pause

        scene trsx_e1f5-blow-03 with dissolve
        pause

        scene trsx_e1f5-blow-04 with dissolve
        pause

        scene trsx_e1f5-27 with dissolve
        tr "I can't believe you still got so much blood in your dick while being high."

        scene trsx_e1f5-28 with dissolve
        mc "Hey [tr], I wanna sit down."

        scene trsx_e1f5-01 with dissolve
        tr "Alright, follow me!"
        tr "Let's go in here."

        # Face her #############################################################

        scene trsx_e1f5-29 with dissolve
        tr "Here, let me help you!"

        scene trsx_e1f5-sex-01 with dissolve
        pause
        tr "Ahh, fuck [mc]!"
        tr "This feels so good!"

        scene trsx_e1f5-31 with dissolve
        tr "Here, look at my tits."

        scene trsx_e1f5-sex-02 with dissolve
        pause

        scene trsx_e1f5-sex-01 with dissolve
        pause

        scene trsx_e1f5-30 with dissolve
        tr "Here, [mc]!"
        tr "I'm gonna switch positions."

        # Sitting ##############################################################

        scene trsx_e1f5-sex-03 with dissolve
        pause
        tr "Oh yeah, [mc]!"
        tr "Keep going!"

        scene trsx_e1f5-sex-04 with dissolve
        pause

        scene trsx_e1f5-sex-03 with dissolve
        mc "Woahh, this feels great!"
        tr "Did the high fade?"
        mc "A little bit."

        scene trsx_e1f5-32 with dissolve
        mc "Hey [tr]!"
        mc "I wanna try a different position."

        scene trsx_e1f5-33 with dissolve
        tr "Alright [mc]!"

        # Doggy ################################################################

        scene trsx_e1f5-sex-05 with dissolve
        pause
        tr "Ohh fuck yeah!"
        tr "Just like that [mc]."

        scene trsx_e1f5-sex-06 with dissolve
        pause

        scene trsx_e1f5-sex-05 with dissolve
        pause

        play sound punch
        scene trsx_e1f5-36 with vpunch
        mc "Oh shit!"
        mc "I think someone's trying to enter!"
        tr "Quick, let's hide in here."

        scene trsx_e1f5-37 with dissolve
        pause

        scene trsx_e1f5-32 with dissolve
        mc "Did they leave yet?"

        scene trsx_e1f5-33 with dissolve
        tr "I don't know."

        menu:
            "Go on":

                $ e1f5_trsx_go_on = True

                scene trsx_e1f5-sex-03 with dissolve
                pause
                tr "Ahh, fuck [mc]!"
                mc "Be quiet [tr]!"

                scene trsx_e1f5-sex-04 with dissolve
                pause

                scene trsx_e1f5-sex-03 with dissolve
                pause

                play sound door_close
                scene trsx_e1f5-36 with vpunch
                pause
                mc "Alright, I think we're good."

            "Stop":
                scene trsx_e1f5-32 with dissolve
                mc "Let's stop and wait for them to leave."

                scene trsx_e1f5-33 with dissolve
                tr "Okay, okay!"

                scene trsx_e1f5-37 with dissolve
                pause

                play sound door_close
                scene trsx_e1f5-36 with vpunch
                pause
                mc "Alright, I think we're good."

        scene trsx_e1f5-sex-03 with dissolve
        pause

    else:

        if persistent.type_nsfw == False:

            scene trsx_e1f5-14 with dissolve
            hide trsx_e1f5-tracy_blink2
            pause

            scene trsx_e1f5-16 with dissolve
            pause

            scene trsx_e1f5-17 with dissolve
            tr "Haha, don't worry [mc]!"
            tr "This is what happens on your first time."

            scene trsx_e1f5-20 with dissolve
            pause

            scene trsx_e1f5-08 with dissolve
            tr "It's gonna take effect in a little bit."

            scene trsx_e1f5-12 with dissolve
            tr "Here, take another hit."

            scene trsx_e1f5-15 with dissolve
            pause

            scene trsx_e1f5-22 with dissolve
            tr "How do you feel [mc]?"

            scene trsx_e1f5-mc_high with dissolve
            pause 1.9

            scene trsx_e1f5-23 with dissolve
            pause

            scene trsx_e1f5-21 with dissolve
            tr "Haha, are you okay [mc]?"

            scene trsx_e1f5-24 with dissolve
            mc "I feel amazing!"

            scene trsx_e1f5-25 with dissolve
            pause

            scene trsx_e1f5-26 with dissolve
            tr "Hey! Easy now, haha!"

            scene trsx_e1f5-01 with dissolve
            tr "I'm glad you like it [mc]!"

            scene trsx_e1f5-kiss with dissolve
            pause

            scene trsx_e1f5-02 with dissolve
            tr "Haha, I'm surprised you can still kiss me while being high."

            scene trsx_e1f5-kiss with dissolve
            pause

            scene trsx_e1f5-03 with dissolve
            show trsx_e1f5-tracy_blink1
            mc "If two vegans are arguing, is it considered beef?"

            scene trsx_e1f5-02 with dissolve
            hide trsx_e1f5-tracy_blink1
            tr "Haha, what?"
            tr "What are you saying, [mc]?"

            scene trsx_e1f5-03 with dissolve
            show trsx_e1f5-tracy_blink1
            mc "Oh yeah!"

            scene trsx_e1f5-02 with dissolve
            hide trsx_e1f5-tracy_blink1
            tr "Hey, [mc], wanna have sex?"

            scene trsx_e1f5-03 with dissolve
            show trsx_e1f5-tracy_blink1
            mc "What?"

            scene trsx_e1f5-02 with dissolve
            hide trsx_e1f5-tracy_blink1
            tr "Do you want to fuck?"

            scene trsx_e1f5-03 with dissolve
            show trsx_e1f5-tracy_blink1
            mc "Yeah!"

            scene trsx_e1f5-02 with dissolve
            hide trsx_e1f5-tracy_blink1
            tr "Alright then, stand still for me!"
            tr "I'm gonna give you the best high fuck of your life."

            scene trsx_e1f5-27_cen with dissolve
            tr "Prepare yourself [mc]."

            scene trsx_e1f5-hand-01_cen with dissolve
            pause
            mc "Holy shit, this feels so good!"

            scene trsx_e1f5-hand-02_cen with dissolve
            pause

            scene trsx_e1f5-27_cen with dissolve
            tr "And now, for the main course..."

            scene trsx_e1f5-blow-01_cen with dissolve
            pause

            scene trsx_e1f5-blow-02_cen with dissolve
            pause

            scene trsx_e1f5-blow-03_cen with dissolve
            pause

            scene trsx_e1f5-blow-04_cen with dissolve
            pause

            scene trsx_e1f5-27_cen with dissolve
            tr "I can't believe you still got so much blood in your dick while being high."

            scene trsx_e1f5-28 with dissolve
            mc "Hey [tr], I wanna sit down."

            scene trsx_e1f5-01 with dissolve
            tr "Alright, follow me!"
            tr "Let's go in here."

            scene trsx_e1f5-29_cen with dissolve
            tr "Here, let me help you."

            scene trsx_e1f5-sex-01_cen with dissolve
            pause
            tr "Ahh, fuck [mc]!"
            tr "This feels so good!"

            scene trsx_e1f5-31 with dissolve
            tr "Here, look at my tits."

            scene trsx_e1f5-sex-02_cen with dissolve
            pause

            scene trsx_e1f5-sex-01_cen with dissolve
            pause

            scene trsx_e1f5-30_cen with dissolve
            tr "[mc]!"
            tr "I'm gonna switch positions."

            scene trsx_e1f5-sex-03_cen with dissolve
            pause
            tr "Oh yeah, [mc]!"
            tr "Keep going!"

            scene trsx_e1f5-sex-04_cen with dissolve
            pause

            scene trsx_e1f5-sex-03_cen with dissolve
            mc "Woahh, this feels great!"
            tr "Did the high fade?"
            mc "A little bit."

            scene trsx_e1f5-32 with dissolve
            mc "Hey [tr]!"
            mc "I wanna try a different position."

            scene trsx_e1f5-33 with dissolve
            tr "Alright [mc]!"

            scene trsx_e1f5-sex-05_cen with dissolve
            pause
            tr "Ohh fuck yeah!"
            tr "Just like that [mc]."

            scene trsx_e1f5-sex-06_cen with dissolve
            pause

            scene trsx_e1f5-sex-05_cen with dissolve
            pause

            play sound punch
            scene trsx_e1f5-36 with vpunch
            mc "Oh shit!"
            mc "I think someone's trying to enter!"
            tr "Quick, let's hide in here."

            scene trsx_e1f5-37 with dissolve
            pause

            scene trsx_e1f5-32 with dissolve
            mc "Did they leave yet?"

            scene trsx_e1f5-33 with dissolve
            tr "I don't know."

            menu:
                "Go on":

                    $ e1f5_trsx_go_on = True

                    scene trsx_e1f5-sex-03_cen with dissolve
                    pause
                    tr "Ahh, fuck [mc]!"
                    mc "Be quiet [tr]!"

                    scene trsx_e1f5-sex-04_cen with dissolve
                    pause

                    scene trsx_e1f5-sex-03_cen with dissolve
                    pause

                    play sound door_close
                    scene trsx_e1f5-36 with vpunch
                    pause
                    mc "Alright, I think we're good."

                "Stop":
                    scene trsx_e1f5-32 with dissolve
                    mc "Let's stop and wait for them to leave."

                    scene trsx_e1f5-33 with dissolve
                    tr "Okay, okay!"

                    scene trsx_e1f5-37 with dissolve
                    pause

                    play sound door_close
                    scene trsx_e1f5-36 with vpunch
                    pause
                    mc "Alright, I think we're good."

            scene trsx_e1f5-sex-03_cen with dissolve
            pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Blowjob":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene trsx_e1f5-blow-01 with dissolve
                        pause

                        scene trsx_e1f5-blow-02 with dissolve
                        pause

                        scene trsx_e1f5-blow-03 with dissolve
                        pause

                        scene trsx_e1f5-blow-04 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene trsx_e1f5-blow-01_cen with dissolve
                            pause

                            scene trsx_e1f5-blow-02_cen with dissolve
                            pause

                            scene trsx_e1f5-blow-03_cen with dissolve
                            pause

                            scene trsx_e1f5-blow-04_cen with dissolve
                            pause

                "Handjob":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene trsx_e1f5-hand-01 with dissolve
                        pause

                        scene trsx_e1f5-hand-02 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene trsx_e1f5-hand-01_cen with dissolve
                            pause

                            scene trsx_e1f5-hand-02_cen with dissolve
                            pause

                "Face her":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene trsx_e1f5-sex-01 with dissolve
                        pause

                        scene trsx_e1f5-sex-02 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene trsx_e1f5-sex-01_cen with dissolve
                            pause

                            scene trsx_e1f5-sex-02_cen with dissolve
                            pause

                "Sitting":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene trsx_e1f5-sex-03 with dissolve
                        pause

                        scene trsx_e1f5-sex-04 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene trsx_e1f5-sex-03_cen with dissolve
                            pause

                            scene trsx_e1f5-sex-04_cen with dissolve
                            pause

                "Doggy":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene trsx_e1f5-sex-05 with dissolve
                        pause

                        scene trsx_e1f5-sex-06 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene trsx_e1f5-sex-05_cen with dissolve
                            pause

                            scene trsx_e1f5-sex-06_cen with dissolve
                            pause

                "Cum":

                    $ GameRunning = False

        $ config.rollback_enabled = True

        if persistent.disable_nsfw == True:

            scene trsx_e1f5-blow-01 with dissolve
            pause
            mc "Oh shit [tr]!"
            mc "I'm gonna cum!"

            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)

            scene trsx_e1f5-cum-02 with dissolve
            mc "Fuuuuck, this was so good!"

            scene trsx_e1f5-cum-01 with dissolve
            tr "And the fact that you were high made it even better."

            scene trsx_e1f5-cum-03 with dissolve
            pause

        else:

            if persistent.type_nsfw == False:

                scene trsx_e1f5-blow-01_cen with dissolve
                pause
                mc "Oh shit [tr]!"
                mc "I'm gonna cum!"

                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)

                scene trsx_e1f5-cum-02_cen with dissolve
                mc "Fuuuuck, this was so good!"

                scene trsx_e1f5-cum-01_cen with dissolve
                tr "And the fact that you were high made it even better."

                scene trsx_e1f5-cum-03_cen with dissolve
                pause

    scene trsx_e1f5-01 with dissolve
    tr "Damn, I loved it [mc]!"

    scene trsx_e1f5-03 with dissolve
    show trsx_e1f5-tracy_blink1
    mc "Yeah!"
    mc "The fact that I was high made it 10 times better."

    scene trsx_e1f5-38 with dissolve
    hide trsx_e1f5-tracy_blink1
    tr "Haha!"

    $ renpy.end_replay()

    $ e1f5_tracy_sex = True

    $ optional_quests.remove("Follow Tracy to the bathroom.")

    $ renpy.music.queue (e1f5_tracks, loop=True)

    scene trsx_e1f5-38 with Dissolve(0.1)

    jump e1f5_bathroom
return

# Outside ######################################################################

label e1f5_outside:

    if e1f5_outside == True:

        if e1f5_finish == False:
            if e1f5_sadie_tracy_1 == True:
                scene e1f5-06-3 with dissolve
            else:
                scene e1f5-06 with dissolve
        else:
            if e1f5_francesca == False:
                if e1f5_sadie_tracy_1 == True or affinity_spectrum < 0 and e1f5_outside == True:
                    scene e1f5-06-2 with dissolve
                else:
                    scene e1f5-06-1 with dissolve
                mc "*Huh?*"
                mc "*Where's [fr]?*"

                $ current_quests.remove("Talk to Francesca after she is done.")
                $ current_quests.append("Talk to Ken and Jordan.")

                $ e1f5_francesca = True

                mc "*I think she left...*"
            else:
                if e1f5_sadie_tracy_1 == True or affinity_spectrum < 0 and e1f5_outside == True:
                    scene e1f5-06-2
                else:
                    scene e1f5-06-1

        call screen e1f5_outside with dissolve

    else:
        scene kenout_e1f5-01 with dissolve
        pause

        scene kenout_e1f5-02 with dissolve
        pause

        scene kenout_e1f5-03 with dissolve
        mc "Hey [ke]!"

        scene kenout_e1f5-04 with dissolve
        ke "Hey [mc]!"
        ke "What's good bro?"

        scene kenout_e1f5-05 with dissolve
        ke "You drinking?"

        scene kenout_e1f5-06 with dissolve
        menu:
            "Drink with [ke]":
                call extrovert_affinity_check from _call_extrovert_affinity_check_7
                call color_check from _call_color_check_14

                ke "Alright!"

                scene kenout_e1f5-07 with dissolve
                play sound glass_cheers
                ke "Cheers [mc]!"
                mc "Cheers!"

                scene kenout_e1f5-08 with dissolve
                pause

            "Don't drink":
                call introvert_affinity_check from _call_introvert_affinity_check_6
                call color_check from _call_color_check_15

                mc "Nah, sorry!"
                mc "I'm not drinking."

                scene kenout_e1f5-04 with dissolve
                ke "It's alright."

        scene kenout_e1f5-09 with dissolve
        show kenout_e1f5-ken_blink1
        mc "So, what's up [ke]?"
        mc "Where's [ro]?"

        scene kenout_e1f5-10 with dissolve
        hide kenout_e1f5-ken_blink1
        ke "You wouldn't believe me if I told you."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "Right... he's home again."

        scene kenout_e1f5-12 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "Pretty much, yeah."

        scene kenout_e1f5-10 with dissolve
        ke "I'm waiting for [jd] to show up, he said he's gonna be a little late to the party."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "Is he helping [jon] out?"

        scene kenout_e1f5-12 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "I mean, yeah!"

        scene kenout_e1f5-13 with dissolve
        ke "He went there for a bit to see what's going on."

        scene kenout_e1f5-10 with dissolve
        ke "He's not really the type to lose a party."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "Oh, I see!"
        mc "Do you know what happened there?"

        scene kenout_e1f5-14 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "To be honest, nobody really knows."

        scene kenout_e1f5-10 with dissolve
        ke "They're going to check the security camera footage but I doubt they'll find anything."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "Why not?"

        scene kenout_e1f5-15 with dissolve
        hide  kenout_e1f5-ken_blink2
        ke "The camera system was busted when they got there."

        scene kenout_e1f5-13 with dissolve
        ke "They covered their tracks pretty well if you ask me."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "That's so unfortunate to be honest."
        mc "Who would want to do that?"

        scene kenout_e1f5-17 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "Well, whoever it was, they're going to pay."

        scene kenout_e1f5-13 with dissolve
        ke "I've never seen [jon] as angry as tonight."

        scene kenout_e1f5-16 with dissolve
        ke "I bet he's gonna do everything in his powers to find the ones responsible."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "What do the other guys say?"

        scene kenout_e1f5-10 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "Well, they're pretty defeated as well."

        scene kenout_e1f5-13 with dissolve
        ke "Nobody expected this to happen."

        scene kenout_e1f5-17 with dissolve
        ke "Especially in this short amount of time."

        scene kenout_e1f5-14 with dissolve
        ke "It's so unbelievable because we were there today."

        scene kenout_e1f5-13 with dissolve
        ke "Everything was so nice and all."

        scene kenout_e1f5-15 with dissolve
        ke "We left like an hour before [jon] arrived..."

        scene kenout_e1f5-12 with dissolve
        ke "They had a short amount of time to do this."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "So, it means that whoever did this knew about the party and everything."

        scene kenout_e1f5-17 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "Yeah..."

        scene kenout_e1f5-13 with dissolve
        ke "No freshman would be dumb enough to try that."

        scene kenout_e1f5-17 with dissolve
        ke "It had to be someone older..."

        scene kenout_e1f5-11 with dissolve
        show kenout_e1f5-ken_blink2
        mc "Well, just know that if you guys need me, just give me a call and I'll be there to help, alright?"

        scene kenout_e1f5-18 with dissolve
        hide kenout_e1f5-ken_blink2
        ke "Thanks [mc]!"
        ke "Really appreciate that."

        scene kenout_e1f5-10 with dissolve
        ke "So, who's the guy you came with?"

        scene kenout_e1f5-09 with dissolve
        show kenout_e1f5-ken_blink1
        mc "Who, [nt]?"
        mc "He's my roommate actually."
        menu:
            "Chill guy":
                $ nate_friendship += 1
                call extrovert_affinity_check from _call_extrovert_affinity_check_8
                call color_check from _call_color_check_16
                mc "He's alright."

                scene kenout_e1f5-18 with dissolve
                hide kenout_e1f5-ken_blink1
                ke "I'm glad he's not some mood killer wimp."

                scene kenout_e1f5-09 with dissolve
                show kenout_e1f5-ken_blink1
                mc "Yeah..."
                mc "Did you talk to him or something?"

                scene kenout_e1f5-18 with dissolve
                hide kenout_e1f5-ken_blink1
                ke "Yeah, I had the occasion of exchanging a word or two with him."

                scene kenout_e1f5-09 with dissolve
                show kenout_e1f5-ken_blink1
                mc "I see."

            "A little annoying":
                $ nate_friendship -= 1
                call introvert_affinity_check from _call_introvert_affinity_check_7
                call color_check from _call_color_check_17
                mc "He's a little annoying if I think about it."

                scene kenout_e1f5-10 with dissolve
                hide kenout_e1f5-ken_blink1
                ke "Why? Has he done something in particular?"

                scene kenout_e1f5-11 with dissolve
                show kenout_e1f5-ken_blink2
                mc "I mean, no... not really."
                mc "It's just the fact that I think he's a little intrusive, you know?"
                mc "I mean, I barely know the guy and all of a sudden he acts like we're best friends."

                scene kenout_e1f5-13 with dissolve
                hide kenout_e1f5-ken_blink1
                ke "I see!"

                scene kenout_e1f5-15 with dissolve
                ke "Well, you know better, [mc]."

                scene kenout_e1f5-16 with dissolve
                ke "I think he's alright."

                scene kenout_e1f5-10 with dissolve
                ke "I like that he's pretty open to partying and isn't a mood killer."

                scene kenout_e1f5-11 with dissolve
                show kenout_e1f5-ken_blink2
                mc "Well, you're right in this regard."

        scene kenout_e1f5-19 with dissolve
        hide kenout_e1f5-ken_blink2
        hide kenout_e1f5-ken_blink1
        pause
        ke "You got eyes on that green head?"

        scene kenout_e1f5-20 with dissolve
        menu:
            "My type":
                $ e1f5_scarlett_mytype = True
                $ scarlett_trust += 1
                call extrovert_affinity_check from _call_extrovert_affinity_check_9
                call color_check from _call_color_check_18

                scene kenout_e1f5-21 with dissolve
                mc "She's just my type."
                ke "Nice!"

            "Not for me":
                call introvert_affinity_check from _call_introvert_affinity_check_8
                call color_check from _call_color_check_19

                mc "Nah, not my type."
                mc "I was just looking around."
                ke "Whatever you say, [mc]!"

        scene kenout_e1f5-22 with dissolve
        mc "*Who's the girl that's talking to [sc]?*"
        mc "*Is that... [fr]?*"
        mc "*What is she doing here?*"
        mc "*I'll find her after they finish talking.*"

        scene kenout_e1f5-09 with dissolve
        show kenout_e1f5-ken_blink1
        mc "Hey, I'll go ahead and talk to some other people."
        mc "Thanks for the beer."

        scene kenout_e1f5-18 with dissolve
        hide kenout_e1f5-ken_blink1
        ke "Alright, don't sweat it."
        ke "Talk to you later, [mc]!"

        $ current_quests.append("Talk to Francesca after she is done.")

        $ e1f5_outside = True

        if e1f5_finish == False:
            if e1f5_sadie_tracy_1 == True:
                scene e1f5-06-3 with dissolve
            else:
                scene e1f5-06 with dissolve
        else:
            if e1f5_sadie_tracy_1 == True or affinity_spectrum < 0 and e1f5_outside == True:
                scene e1f5-06-2 with dissolve
            else:
                scene e1f5-06-1 with dissolve

        jump e1f5_outside
return

label e1f5_sadie_sex:

    scene sdsx_e1f5-01 with wipeleft
    pause

    scene sdsx_e1f5-02 with dissolve
    pause

    scene sdsx_e1f5-03 with dissolve
    pause

    if persistent.disable_nsfw == True:

        play music inhale fadein 1.0

        scene sdsx_e1f5-04 with dissolve
        pause

        scene sdsx_e1f5-kiss with dissolve
        pause

        scene sdsx_e1f5-05 with dissolve
        mc "Haha, didn't you say you're gonna smoke?"

        scene sdsx_e1f5-06 with dissolve
        sd "That was just a pretext dude, learn to take a hint."

        scene sdsx_e1f5-kiss with dissolve
        pause

        scene sdsx_e1f5-07 with dissolve
        pause

        scene sdsx_e1f5-08 with dissolve
        sd "Sit back and enjoy this."

        scene sdsx_e1f5-09 with dissolve
        pause

        scene sdsx_e1f5-10 with dissolve
        pause

        scene sdsx_e1f5-12 with dissolve
        sd "Let's see what you're hiding under there."

        scene sdsx_e1f5-11 with dissolve
        pause

        scene sdsx_e1f5-13 with dissolve
        sd "You've got quite the thing."

        scene sdsx_e1f5-14 with dissolve
        sd "And it's only growing!"

        scene sdsx_e1f5-blow-01 with dissolve
        pause

        scene sdsx_e1f5-blow-02 with dissolve
        pause

        scene sdsx_e1f5-15 with dissolve
        sd "Did you enjoy it, [mc]?"

        scene sdsx_e1f5-16 with dissolve
        sd "I know just the thing to get you even more excited."

        scene sdsx_e1f5-17 with dissolve
        sd "Are you ready?"

        scene sdsx_e1f5-20 with dissolve
        mc "I'm ready!"

        scene sdsx_e1f5-18 with dissolve
        pause

        scene sdsx_e1f5-19 with dissolve
        sd "Do you like my tits, [mc]?"

        scene sdsx_e1f5-21 with dissolve
        sd "Tell me how much you like my tits."

        scene sdsx_e1f5-22 with dissolve
        mc "I love your tits, [sd]!"

        scene sdsx_e1f5-blow-03 with dissolve
        pause

        scene sdsx_e1f5-blow-04 with dissolve
        pause

        scene sdsx_e1f5-19 with dissolve
        sd "Now, [mc], let's get ready for some more exciting things."

        scene sdsx_e1f5-09 with dissolve
        pause

        scene sdsx_e1f5-04 with dissolve
        pause

        # Lift her leg #########################################################

        scene sdsx_e1f5-27 with dissolve
        sd "Fuck me, [mc]!"
        sd "Show me just how much you love my pussy!"

        scene sdsx_e1f5-sex-01 with dissolve
        pause
        sd "Ahh, fuck!"

        scene sdsx_e1f5-sex-02 with dissolve
        pause

        scene sdsx_e1f5-sex-06 with dissolve
        pause

        scene sdsx_e1f5-sex-07 with dissolve
        sd "[mc], this feels sooo good!"
        sd "I love it when you grab my titties."
        sd "Fuck me harder!"

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()

            menu:
                "Keep going":

                    scene sdsx_e1f5-sex-01 with dissolve
                    pause
                    sd "Fuck me, [mc]!"
                    sd "Show me just how much you love my pussy!"

                    scene sdsx_e1f5-sex-02 with dissolve
                    pause

                    scene sdsx_e1f5-sex-06 with dissolve
                    pause

                    scene sdsx_e1f5-sex-07 with dissolve
                    sd "[mc], this feels sooo good!"
                    sd "I love it when you grab my titties."
                    sd "Fuck me harder!"

                "Switch positions":

                    $ GameRunning = False

        scene sdsx_e1f5-27 with dissolve
        mc "Hey [sd], wanna switch positions?"
        sd "Sure [mc]!"
        sd "How do you want me?"
        mc "Against the wall."

        # Against the wall #####################################################

        scene sdsx_e1f5-sex-04 with dissolve
        pause

        scene sdsx_e1f5-sex-03 with dissolve
        pause
        sd "Deeper, [mc]!"

        scene sdsx_e1f5-sex-05 with dissolve
        pause
        sd "Fuuck! This feels so good!"

    else:

        if persistent.type_nsfw == False:

            play music inhale fadein 1.0

            scene sdsx_e1f5-04 with dissolve
            pause

            scene sdsx_e1f5-kiss with dissolve
            pause

            scene sdsx_e1f5-05 with dissolve
            mc "Haha, didn't you say you're gonna smoke?"

            scene sdsx_e1f5-06 with dissolve
            sd "That was just a pretext dude, learn to take a hint."

            scene sdsx_e1f5-kiss with dissolve
            pause

            scene sdsx_e1f5-07 with dissolve
            pause

            scene sdsx_e1f5-08 with dissolve
            sd "Sit back and enjoy this."

            scene sdsx_e1f5-09 with dissolve
            pause

            scene sdsx_e1f5-10 with dissolve
            pause

            scene sdsx_e1f5-12 with dissolve
            sd "Let's see what you're hiding under there."

            scene sdsx_e1f5-11_cen with dissolve
            pause

            scene sdsx_e1f5-13_cen with dissolve
            sd "You've got quite the thing."

            scene sdsx_e1f5-14_cen with dissolve
            sd "And it's only growing!"

            scene sdsx_e1f5-blow-01_cen with dissolve
            pause

            scene sdsx_e1f5-blow-02_cen with dissolve
            pause

            scene sdsx_e1f5-15_cen with dissolve
            sd "Did you enjoy it, [mc]?"

            scene sdsx_e1f5-16_cen with dissolve
            sd "I know just the thing to get you even more excited."

            scene sdsx_e1f5-17_cen with dissolve
            sd "Are you ready?"

            scene sdsx_e1f5-20_cen with dissolve
            mc "I'm ready!"

            scene sdsx_e1f5-18_cen with dissolve
            pause

            scene sdsx_e1f5-19_cen with dissolve
            sd "Do you like my tits, [mc]?"

            scene sdsx_e1f5-21_cen with dissolve
            sd "Tell me how much you like my tits."

            scene sdsx_e1f5-22_cen with dissolve
            mc "I love your tits, [sd]!"

            scene sdsx_e1f5-blow-03_cen with dissolve
            pause

            scene sdsx_e1f5-blow-04_cen with dissolve
            pause

            scene sdsx_e1f5-19_cen with dissolve
            sd "Now, [mc], let's get ready for some more exciting things."

            scene sdsx_e1f5-09 with dissolve
            pause

            scene sdsx_e1f5-04 with dissolve
            pause

            # Lift her leg #####################################################

            scene sdsx_e1f5-27_cen with dissolve
            sd "Fuck me, [mc]!"
            sd "Show me just how much you love my pussy!"

            scene sdsx_e1f5-sex-01_cen with dissolve
            pause
            sd "Ahh, fuck!"

            scene sdsx_e1f5-sex-02_cen with dissolve
            pause

            scene sdsx_e1f5-sex-06_cen with dissolve
            pause

            scene sdsx_e1f5-sex-07_cen with dissolve
            sd "[mc], this feels sooo good!"
            sd "I love it when you grab my titties."
            sd "Fuck me harder!"

            $ GameRunning = True

            while GameRunning:

                $ renpy.block_rollback()

                menu:
                    "Keep going":

                        scene sdsx_e1f5-sex-01_cen with dissolve
                        pause
                        sd "Fuck me, [mc]!"
                        sd "Show me just how much you love my pussy!"

                        scene sdsx_e1f5-sex-02_cen with dissolve
                        pause

                        scene sdsx_e1f5-sex-06_cen with dissolve
                        pause

                        scene sdsx_e1f5-sex-07_cen with dissolve
                        sd "[mc], this feels sooo good!"
                        sd "I love it when you grab my titties."
                        sd "Fuck me harder!"

                    "Switch positions":

                        $ GameRunning = False

            scene sdsx_e1f5-27_cen with dissolve
            mc "Hey [sd], wanna switch positions?"
            sd "Sure [mc]!"
            sd "How do you want me?"
            mc "Against the wall."

            # Against the wall #################################################

            scene sdsx_e1f5-sex-04_cen with dissolve
            pause

            scene sdsx_e1f5-sex-03_cen with dissolve
            pause
            sd "Deeper, [mc]!"

            scene sdsx_e1f5-sex-05_cen with dissolve
            pause
            sd "Fuuck! This feels so good!"

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Blowjob":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene sdsx_e1f5-blow-01 with dissolve
                        pause

                        scene sdsx_e1f5-blow-02 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene sdsx_e1f5-blow-01_cen with dissolve
                            pause

                            scene sdsx_e1f5-blow-02_cen with dissolve
                            pause

                "Handjob":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene sdsx_e1f5-blow-03 with dissolve
                        pause

                        scene sdsx_e1f5-blow-04 with dissolve
                        pause

                    else:

                        if persistent.type_nsfw == False:
                            scene sdsx_e1f5-blow-03_cen with dissolve
                            pause

                            scene sdsx_e1f5-blow-04_cen with dissolve
                            pause

                "Lift her leg":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:

                        scene sdsx_e1f5-27 with dissolve
                        sd "Fuck me, [mc]!"
                        sd "Show me just how much you love my pussy!"

                        scene sdsx_e1f5-sex-01 with dissolve
                        pause
                        sd "Ahh, fuck!"

                        scene sdsx_e1f5-sex-02 with dissolve
                        pause

                        scene sdsx_e1f5-sex-06 with dissolve
                        pause

                        scene sdsx_e1f5-sex-07 with dissolve
                        sd "[mc], this feels sooo good!"
                        sd "I love it when you grab my titties."
                        sd "Fuck me harder!"

                    else:

                        if persistent.type_nsfw == False:

                            scene sdsx_e1f5-27_cen with dissolve
                            sd "Fuck me, [mc]!"
                            sd "Show me just how much you love my pussy!"

                            scene sdsx_e1f5-sex-01_cen with dissolve
                            pause
                            sd "Ahh, fuck!"

                            scene sdsx_e1f5-sex-02_cen with dissolve
                            pause

                            scene sdsx_e1f5-sex-06_cen with dissolve
                            pause

                            scene sdsx_e1f5-sex-07_cen with dissolve
                            sd "[mc], this feels sooo good!"
                            sd "I love it when you grab my titties."
                            sd "Fuck me harder!"

                "Against the wall":

                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:

                        scene sdsx_e1f5-sex-04 with dissolve
                        pause

                        scene sdsx_e1f5-sex-03 with dissolve
                        pause
                        sd "Deeper, [mc]!"

                        scene sdsx_e1f5-sex-05 with dissolve
                        pause
                        sd "Fuuck! This feels so good!"

                    else:

                        if persistent.type_nsfw == False:

                            scene sdsx_e1f5-sex-04_cen with dissolve
                            pause

                            scene sdsx_e1f5-sex-03_cen with dissolve
                            pause
                            sd "Deeper, [mc]!"

                            scene sdsx_e1f5-sex-05_cen with dissolve
                            pause
                            sd "Fuuck! This feels so good!"

                "Cum":

                    mc "Shit, I'm gonna cum!"

                    $ GameRunning = False


        $ config.rollback_enabled = True

    if persistent.disable_nsfw == True:

        scene sdsx_e1f5-blow-05 with dissolve
        pause
        sd "Cum, [mc]!"
        sd "Cum on my pretty face!"

        show white with Dissolve(0.25)
        scene sdsx_e1f5-cum-01
        show white with vpunch
        hide white with Dissolve(0.25)
        show white with Dissolve(0.25)
        show white with vpunch
        hide white with Dissolve(0.25)
        show white with Dissolve(0.25)
        show white with vpunch
        hide white with Dissolve(0.25)
        pause

        scene sdsx_e1f5-cum-02 with dissolve
        hide sdsx_e1f5-cum-01
        sd "I hope you enjoyed it, [mc]!"
        sd "I certainly did!"

        scene sdsx_e1f5-cum-03 with dissolve
        mc "That felt really good, [sd]."
        mc "Thanks!"

    else:

        if persistent.type_nsfw == False:

            scene sdsx_e1f5-blow-05_cen with dissolve
            pause
            sd "Cum, [mc]!"
            sd "Cum on my pretty face!"

            show white with Dissolve(0.25)
            scene sdsx_e1f5-cum-01_cen
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            pause

            scene sdsx_e1f5-cum-02_cen with dissolve
            sd "I hope you enjoyed it, [mc]!"
            sd "I certainly did!"

            scene sdsx_e1f5-cum-03_cen with dissolve
            mc "That felt really good, [sd]."
            mc "Thanks!"

    scene sdsx_e1f5-23 with dissolve
    pause

    scene sdsx_e1f5-24 with dissolve
    sd "We should go inside."
    sd "Hopefully nobody noticed that we've been missing."

    scene sdsx_e1f5-25 with dissolve
    mc "Yeah, let's go."

    scene sdsx_e1f5-26 with dissolve
    pause

    $ renpy.end_replay()

    call extrovert_affinity_check from _call_extrovert_affinity_check_10
    call color_check from _call_color_check_20

    stop music fadeout 2.0

    $ renpy.music.queue (e1f5_tracks, loop=True)
return

# Clickables #

label e1f5_bouncer:

    if e1f5_sadie_tracy_1 == True:
        scene e1f5-06-3
    else:
        scene e1f5-06

    scene bcer_e1f5-01 with dissolve
    mc "Hey man, just wanted to say thank you for letting us through!"

    scene bcer_e1f5-04 with dissolve
    bo "Don't worry about it."

    scene bcer_e1f5-02 with dissolve
    show bcer_e1f5-bouncer_blink1
    mc "How's working here?"

    scene bcer_e1f5-03 with dissolve
    hide bcer_e1f5-bouncer_blink1
    bo "Well, you know, it's not so bad."

    scene bcer_e1f5-04 with dissolve
    bo "Honestly, working at Eddy's is more enjoyable."

    scene bcer_e1f5-02 with dissolve
    show bcer_e1f5-bouncer_blink1

    if e1s18_ken_greet == True:
        mc "Oh, right."
        mc "So, you know [jon], right?"
    else:
        mc "Wait, you work at Eddy's?"

        scene bcer_e1f5-03 with dissolve
        hide bcer_e1f5-bouncer_blink1
        bo "Yeah."

        scene bcer_e1f5-05 with dissolve
        bo "I was supposed to be there tonight but they had other plans for me."

        scene bcer_e1f5-02 with dissolve
        show bcer_e1f5-bouncer_blink1
        mc "So, I'm assuming you know [jon]."

    scene bcer_e1f5-04 with dissolve
    hide bcer_e1f5-bouncer_blink1
    bo "Yeah, he's the one who sent me here."

    scene bcer_e1f5-02 with dissolve
    show bcer_e1f5-bouncer_blink1
    mc "That's nice."
    mc "So, do you know what happened there?"
    mc "Weren't you there today?"

    scene bcer_e1f5-05 with dissolve
    hide bcer_e1f5-bouncer_blink1
    bo "I was supposed to work the night shift."

    scene bcer_e1f5-03 with dissolve
    bo "Maybe the guy before me knows more about it."

    scene bcer_e1f5-04 with dissolve
    bo "But all I know is, I only just got there and right after that I was sent here."

    scene bcer_e1f5-02 with dissolve
    show bcer_e1f5-bouncer_blink1
    mc "Alright, I see."
    mc "Thanks man!"

    scene bcer_e1f5-03 with dissolve
    hide bcer_e1f5-bouncer_blink1
    bo "Don't mention it."

    $ e1f5_bouncer_talk = True

    $ e1f5_explore += 1

    if e1f5_explore == 3:
        $ current_quests.remove("Interact with people.")

    if e1f5_sadie_tracy_1 == True:
        scene e1f5-06-3 with dissolve
    else:
        scene e1f5-06 with dissolve

    call screen e1f5_outside with dissolve
return

label e1f5_scarlett_francesca:

    if e1f5_sadie_tracy_1 == True:
        scene e1f5-06-3
    else:
        scene e1f5-06

    mc "*I should wait for them to split.*"

    call screen e1f5_outside with dissolve
return

label e1f5_ken_jordan:
    $ collected_p = persistent.e1f5_collected_p
    $ collected_tp = persistent.e1f5_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            stop music fadeout 1.0

            scene kejd_e1f5-01 with dissolve
            play music "party/instrumentals/rock_this_house.ogg"
            pause

            scene kejd_e1f5-02 with dissolve
            ke "Yoo, [mc]!"

            scene kejd_e1f5-03 with dissolve
            jd "What's up my guy?"

            scene kejd_e1f5-04 with dissolve
            mc "Hey guys!"
            mc "Glad to see you could make it, [jd]."

            scene kejd_e1f5-06 with dissolve
            jd "Yeah."

            scene kejd_e1f5-05 with dissolve
            jd "I just talked to [jon] about Eddy's..."
            jd "Things aren't looking that good..."

            scene kejd_e1f5-07 with dissolve
            mc "Oh shit..."
            mc "I'm sorry."

            scene kejd_e1f5-08 with dissolve
            ke "Guys, guys!"
            ke "The surprise should be here any minute now!"

            scene kejd_e1f5-09 with dissolve
            jd "Oh shit, let's go inside."

            scene kejd_e1f5-11 with dissolve
            mc "*[jd] said things aren't looking good at Eddy's...*"
            mc "*I think I've partied enough...*"
            mc "*Maybe I should go and help [jon] out.*"

            scene kejd_e1f5-10 with dissolve
            mc "Sorry guys, I'll leave you to it."

            scene kejd_e1f5-12 with dissolve
            ke "Are you sure dude?"

            scene kejd_e1f5-13 with dissolve
            jd "You're gonna miss the best part."

            scene kejd_e1f5-14 with dissolve
            mc "Yeah, I've partied enough."
            mc "Maybe [jon] needs my help."
            mc "He's the only one that hasn't partied a bit."

            scene kejd_e1f5-15 with dissolve
            ke "Oh... I see."

            scene kejd_e1f5-13 with dissolve
            jd "Good luck, [mc]!"

            scene kejd_e1f5-15 with dissolve
            ke "If you need a helping hand, you know who to call."

            scene kejd_e1f5-14 with dissolve
            mc "Alright, have fun guys!"

            scene kejd_e1f5-16 with dissolve
            pause

            jump e1s19

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            pass

    call e1f5_outside from _call_e1f5_outside
return

# Freeroam #####################################################################

label e1f5:
    stop music fadeout 1.0

    scene e1f5-01 with dissolve

    define e1f5_tracks = ["party/i_wont_fall_in_love.ogg", "party/galaxies.ogg", "party/instrumentals/piano.ogg", "party/instrumentals/2010_pop.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/turn_up.ogg"]
    $ renpy.music.queue (e1f5_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")

    call screen e1f5_main
    hide e1f5-01
return
