
# Scene 2 - First glance #######################################################

label e1s2:

    scene e1s2-05 with Dissolve(2.0)
    play music twenty_twenty loop fadein 1.0
    pause

    scene e1s2-06 with dissolve
    pause

    scene e1s2-01 with dissolve
    show e1s2_mc_blink1
    mc "*I wonder what college is gonna be like.*"
    mc "*Is it gonna be like in those movies where everyone is constantly drunk and partying?"
    mc "*Or maybe it's just gonna be plain boring and nobody's gonna party at all.*"
    mc "*I haven't really given this a thought until now.*"

    menu:
        "Excited":
            show e1s2-07 behind e1s2_mc_blink1 with dissolve
            call extrovert_affinity_check from _call_extrovert_affinity_check_19
            call color_check from _call_color_check_38
            mc "*I feel so excited.*"
            mc "*Think of all the crazy stuff I'm gonna do.*"
            mc "*I'm really gonna make the most out of this experience.*"
            mc "*Maybe, in the future, I'll tell my kids about the stuff I used to do in college.*"
            mc "*It would really make a great bonding experience.*"
            mc "*Anyways...*"

        "Nervous":
            show stressed_e1s2 behind e1s2_mc_blink1 with dissolve
            call introvert_affinity_check from _call_introvert_affinity_check_16
            call color_check from _call_color_check_39
            mc "*I feel so nervous.*"
            mc "*Except [jon], I don't really have any other friends.*"
            mc "*I'm not even that good at making new friends.*"
            mc "*I probably should have worked more on my social skills.*"
            mc "*I wouldn't be sitting here all alone waiting for this train.*"
            mc "*Eh, anyways...*"

    mc "*My life is going to be so different from now on.*"
    mc "*I really feel like I needed this change.*"

    if affinity_spectrum == 0:
        mc "*I'll see what college is really about when I get there.*"

    if affinity_spectrum < 0:
        mc "*I hope that everything turns out to be good in the end.*"
    else:
        mc "*I'm looking forward to seeing [jon]!*"

    scene e1s2-09 with dissolve
    stop music fadeout 1.0
    pause
    hide e1s2-07
    hide e1s2_mc_blink1
    hide stressed_e1s2

    scene black with Dissolve(2.0)

    play sound train_ambient loop fadein 1.0

    scene e1s2-10 with Dissolve(2.0)
    pause

    scene e1s2-11 with dissolve
    pause

    scene e1s2-12 with dissolve
    pause

    scene e1s2-13 with dissolve
    mc "*Oh shit!*"

    scene e1s2-14 with dissolve
    pause

    menu:
        "Smile back":
            $ cleo_trust += 1
            $ e1s2_smile_back = True
            scene e1s2-15 with dissolve
            mc "*She is cute.*"

            menu:
                "Go and talk to her":
                    call extrovert_affinity_check from _call_extrovert_affinity_check_20
                    call color_check from _call_color_check_40
                    $ e1s2_talk_to_her = True

                    scene e1s2-18 with dissolve
                    mc "*Damn it!*"
                    mc "*I should have talked to her.*"

                    menu:
                        "Check her out":
                            scene e1s2-19 with dissolve
                            pause
                        "Don't check her out":
                            pass

                "Don't go":
                    call introvert_affinity_check from _call_introvert_affinity_check_17
                    call color_check from _call_color_check_41
                    scene e1s2-17 with dissolve
                    mc "*I better not, it's not worth it.*"

                    scene e1s2-18 with dissolve
                    pause

        "Don't smile back":
            scene e1s2-16 with dissolve
            mc "*Eh, not really my type.*"

            scene e1s2-17 with dissolve
            pause

            scene e1s2-18 with dissolve
            pause

    stop music fadeout 2.5
    stop sound fadeout 2.5

    scene black with Dissolve(2.0)

    scene e1s2-20 with Dissolve(2.0)

    stop music
    stop sound
    play music heartless_man loop fadein 1.0

    mc "What's up man!"
    mc "How's things?"

    scene e1s2-21 with dissolve
    jn "[mc]!"
    jn "Welcome, my friend!"

    scene e1s2-22 with dissolve
    jn "Getting my ass through life, that's how it is."

    scene e1s2-23 with dissolve
    jn "Let's go, my apartment is not that far from here."

    scene e1s2-24 with dissolve
    mc "Wait, first let me give my dad a call."
    mc "Let him know I've arrived."

    scene e1s2-25 with dissolve
    jn "Sure, I'll go get something to drink."

    scene e1s2-26 with dissolve
    show e1s2-jon_blink1
    mc "Alright."

    scene e1s2-27 with dissolve
    hide e1s2-jon_blink1
    pause

    scene e1s2-28 with dissolve
    pause

    scene e1s2-29 with dissolve
    mc "Hey, what's up?"

    scene e1s2-30 with dissolve
    jo "Hey son!"
    jo "Nothing much, with the boys at work."

    scene e1s2-31 with dissolve
    jo "What about you?"
    jo "Are you in Underport yet?"

    scene e1s2-29 with dissolve
    mc "Yeah, I just arrived."
    mc "I met [jon] and we're heading down to his apartment now."

    scene e1s2-32 with dissolve
    jo "Oh, that's great!"
    jo "Tell [jon] I said hi."

    scene e1s2-29 with dissolve
    mc "Alright, I will."
    mc "How's work?"

    scene e1s2-31 with dissolve
    jo "For now, it's nothing new."
    jo "We're working on getting the truck back up and running again."
    jo "We've still got the emergency one, but that one's pretty small."

    scene e1s2-34 with dissolve
    "Come on lads, let's move!"
    "We've got a burning building down on Riverside Alley."

    scene e1s2-33 with dissolve
    jo "Listen, something came up and I need to go."
    jo "Take care and talk to you soon."
    jo "Love you son!"

    scene e1s2-29 with dissolve
    mc "Alright!"
    mc "Good luck, and I love you too, Dad!"

    scene e1s2-35 with dissolve
    pause

    scene e1s2-36 with dissolve
    jn "So, how's Pops?"

    scene e1s2-37 with dissolve
    mc "Well, you know how he is with work and stuff."
    mc "He said hi."

    scene e1s2-38 with dissolve
    jn "He's such a great guy!"
    jn "Hope we get to meet again soon."

    scene e1s2-39 with dissolve
    jn "Let's go now!"
    jn "We can't keep the ladies waiting."

    scene e1s2-40 with dissolve
    mc "Don't tell me you already brought women to your apartment."

    scene e1s2-41 with dissolve
    jn "Nah, for now it's just us."
    jn "Although, that would've made a great surprise."

    scene e1s2-42 with dissolve
    pause

    scene e1s2-43 with dissolve
    pause

    stop music fadeout 2.5
    stop sound fadeout 2.5
    scene black with Dissolve(2.0)

    jump e1s3
return
