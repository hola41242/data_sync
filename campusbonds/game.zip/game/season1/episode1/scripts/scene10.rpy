
# Scene 10 - UNI Tour ##########################################################

label e1s10:
    play music breathe
    scene e1s10-01 with wipeleft:
        ease 10.0 zoom 1.1
    pause

    scene e1s10-02 with dissolve
    pause

    scene e1s10-03 with dissolve
    pause

    scene e1s10-04 with dissolve
    pause

    scene e1s10-05 with dissolve
    pause

    scene e1s10-06 with dissolve
    br "Hello everyone!"
    br "I'd like to take a moment to thank you all for coming to our beloved university."
    br "First of all, we're gonna talk about the great history of how this place came to be."

    scene e1s10-07 with dissolve
    br "As you all may know, this city was initially a naval port used in the great war of independence..."
    br "...which used to carry all the artillery to the soldiers across the sea."
    br "Richard The Great founded this place as an homage to all the soldiers who lost their lives so this city could prosper."

    scene e1s10-05 with dissolve
    mc "*This is boring as hell...*"
    scene e1s10-06 with dissolve
    mc "*Am I at a museum or a college?*"
    scene e1s10-18 with dissolve
    br "Alright, moving on..."

    stop music fadeout 1.0
    scene e1s10-08 with wipeleft
    play music pop_song
    pause

    scene e1s10-09 with dissolve
    "*Muffled Arguing...*"

    scene e1s10-10 with dissolve
    cl "Can't you do anything about it?"

    scene e1s10-11 with dissolve
    se "I'm sorry."
    se "We're doing the best we can."

    scene e1s10-12 with dissolve
    pause

    scene e1s10-15 with dissolve
    cl "Exhale..."

    scene e1s10-14 with dissolve
    cl "Can you believe this?"
    cl "I won't get my dorm until next month!"
    cl "They confused me with some other girl and I've been left out."

    scene e1s10-13 with dissolve
    show e1s10-cleo_blink1
    mc "How does this happen?"

    scene e1s10-17 with dissolve
    hide e1s10-cleo_blink1
    cl "I don't know."
    cl "I've never heard of anything like this before..."

    scene e1s10-13 with dissolve
    show e1s10-cleo_blink1
    mc "This sucks."

    scene e1s10-17 with dissolve
    hide e1s10-cleo_blink1
    cl "Yeah, whatever."
    cl "What are you up to?"
    cl "Shouldn't you be with the guide over there?"

    scene e1s10-13 with dissolve
    show e1s10-cleo_blink1
    mc "Well, I wanted to come by and say hi."
    mc "And I also need to get my dorm key."

    scene e1s10-17 with dissolve
    hide e1s10-cleo_blink1
    cl "I see."
    cl "Thanks for stopping by."

    scene e1s10-16 with dissolve
    cl "Are you sure there's nothing you can do?"

    scene e1s10-11 with dissolve
    se "I've already checked all the alternatives, I'm afraid there's really nothing we can do about it."

    scene e1s10-15 with dissolve
    cl "Exhale..."

    scene e1s10-17 with dissolve
    cl "I need to get my mind off of this."
    cl "How about I show you around instead?"
    cl "That guide is boring anyways."

    scene e1s10-13 with dissolve
    show e1s10-cleo_blink1
    mc "Sure!"
    mc "Lead the way."

    scene e1s10-19 with dissolve
    hide e1s10-cleo_blink1
    pause

    stop music fadeout 2.0
    scene e1s10-20 with dissolve
    play music sun_sets_on_a_protagonist
    pause

    scene e1s10-21-5 with dissolve
    cl "So... let me guess..."
    cl "Did the guide, by any chance, start with the 'great' great history of this wonderful city?"

    scene e1s10-21 with dissolve
    show e1s10_cleo_blink2
    mc "Haha, yeah!"
    mc "How did you know?"

    scene e1s10-22 with dissolve
    hide e1s10_cleo_blink2
    cl "They've held the same tour 3 days in a row and I had the unfortunate luck of attending one of them."

    scene e1s10-23 with dissolve
    show e1s10_cleo_blink2
    mc "Well, I guess you just saved me from eternal boredom."

    scene e1s10-24 with dissolve
    hide e1s10_cleo_blink2
    cl "Haha, you're welcome by the way!"

    scene e1s10-25 with dissolve
    show e1s10_cleo_blink2
    mc "Haha, yeah."

    show e1s10-26 behind e1s10_cleo_blink2 with dissolve
    mc "..."

    show e1s10-27 behind e1s10_cleo_blink2 with dissolve
    hide e1s10-26
    mc "So... what's up with the diner job?"

    show e1s10-28 behind e1s10_cleo_blink2 with dissolve
    hide e1s10-27
    mc "You don't seem like the type of girl who would work there."

    scene e1s10-29 with dissolve
    hide e1s10-28
    hide e1s10_cleo_blink2
    cl "Well, you're kind of right, I don't really like that job."

    scene e1s10-30 with dissolve
    cl "It's something that I must do in order to keep studying at university."

    scene e1s10-31 with dissolve
    menu:
        "Push her more":

            $ cleo_trust -= 1
            mc "Aren't your parents helping you with all of this?"

            scene e1s10-32-5 with dissolve
            hide e1s10_cleo_blink2
            cl "..."
            scene e1s10-32 with dissolve
            cl "Yeah, they're helping with what they can."

        "Don't inquire":

            $ cleo_trust += 1
            mc "Oh... I see."

    scene e1s10-41 with dissolve
    hide e1s10_cleo_blink2
    cl "So, here's the sports hall."

    scene e1s10-42 with dissolve
    cl "It's where most of the school games are held."
    cl "At least that's what the guide told me yesterday."

    scene e1s10-43 with dissolve
    cl "If you were to ask me, I haven't heard a lot about sports in UPL."
    cl "So... you can draw your own conclusions."

    scene e1s10-44 with dissolve
    mc "When I lived here, the main sport people were interested in was fighting."

    scene e1s10-45 with dissolve
    mc "It didn't matter if that involved Muay Thai, Karate or Brazilian Jiu Jitsu."
    mc "Everyone would just learn whatever they thought was interesting."

    scene e1s10-46 with dissolve
    cl "Oh! That's pretty cool!"
    cl "So I get that you're a fighter as well?"

    scene e1s10-47 with dissolve
    mc "Sort of, yeah."
    mc "I wanted to become a professional but life just gets in the way."

    scene e1s10-48 with dissolve
    cl "Haha! I see."

    if cleo_trust >= 1:
        cl "You'll have to teach me sometimes!"

    scene e1s10-49 with dissolve
    cl "So, next up we have the cafeteria."

    scene e1s10-50 with dissolve
    cl "People usually come here to eat."
    cl "It's already pretty obvious so this doesn't need any more presentation."

    scene e1s10-53 with dissolve
    cl "There's nothing else going on other than grabbing a snack then going to your class."

    scene e1s10-52 with dissolve
    show e1s10_cleo_blink3
    mc "I gotta ask you..."

    show e1s10-51 behind e1s10_cleo_blink3 with dissolve
    mc "Why is the school so empty today?"
    mc "I thought that it would be full of people."

    scene e1s10-54 with dissolve
    hide e1s10-51
    hide e1s10-cleo_blink3
    cl "I don't think people are excited for school..."
    cl "Be it college or high school or whatever."
    cl "So I'm not entirely surprised."

    scene e1s10-51 with dissolve
    show e1s10_cleo_blink3
    mc "Well... I guess you're right."
    mc "So we must be the only crazy ones to come here then."

    scene e1s10-54 with dissolve
    hide e1s10_cleo_blink3
    cl "Yeah! Us and the other people with the guide!"

    scene e1s10-51 with dissolve
    show e1s10_cleo_blink3
    mc "Haha!"

    scene e1s10-54 with dissolve
    hide e1s10_cleo_blink3
    cl "Oh, also..."
    cl "There's this tradition where all the freshies are invited to go to some bar called 'Eddy's' so they can get to know people easier."
    cl "They say it's a good way of knowing which freshies are cool and which are mood killers."
    cl "To be fair, I think this is all stupid."
    cl "College is not all about partying you know?"

    scene e1s10-51 with dissolve
    show e1s10_cleo_blink3
    if affinity_spectrum >= 0:
        mc "I think it's kinda cool!"
        mc "I get your point but sometimes you gotta have some fun."

        scene e1s10-54 with dissolve
        hide e1s10_cleo_blink3
        cl "You're right. It's just that partying is not really my thing so I won't be going."

        if affinity_spectrum > 0 and cleo_trust >= 1:
            scene e1s10-51 with dissolve
            show e1s10_cleo_blink3
            mc "That's a bummer!"

        if cleo_trust < 1:
            scene e1s10-51 with dissolve
            show e1s10_cleo_blink3
            mc "I see."
            mc "Well... it's your choice after all."

        scene e1s10-54 with dissolve
        hide e1s10_cleo_blink3
        cl "Yeah..."

    if affinity_spectrum < 0:
        $ cleo_trust += 1
        mc "You're right. I'm really not into partying and sometimes I don't even see its purpose in this world."
        mc "I mean, what's so fun about them?"

        scene e1s10-54 with dissolve
        hide e1s10_cleo_blink3
        cl "Haha! Hop in my boat because partying is not my thing either."

    scene e1s10-51 with dissolve
    show e1s10_cleo_blink3
    mc "*I wonder if [jon] knows about this freshies party.*"

    scene e1s10-33 with wipeleft
    pause

    scene e1s10-34 with dissolve
    show e1s10_cleo_blink4
    mc "Thank you for showing me around."

    scene e1s10-35 with dissolve
    hide e1s10_cleo_blink4
    cl "No problem!"

    scene e1s10-36 with dissolve
    cl "I wish I had someone yesterday instead of listening to the guide."

    scene e1s10-37 with dissolve
    cl "It would have made my life easier."

    scene e1s10-38 with dissolve
    show e1s10_cleo_blink4
    mc "Haha! For sure."

    scene e1s10-40 with dissolve
    hide e1s10_cleo_blink4
    cl "Well, I've got to go now."
    cl "My boss will be upset if I'm late to my shift."

    scene e1s10-39 with dissolve
    show e1s10_cleo_blink5
    if cleo_trust >= 1:
        mc "Alright, good luck!"

        scene e1s10-40 with dissolve
        hide e1s10_cleo_blink5
        cl "Thanks, see ya!"

        scene e1s10-39 with dissolve
        show e1s10_cleo_blink5
        mc "Bye!"
    if cleo_trust < 1:
        mc "Alright, bye!"

        scene e1s10-40 with dissolve
        hide e1s10_cleo_blink5
        cl "Bye!"

    scene e1s10-55 with dissolve
    hide e1s10_cleo_blink4
    pause

    stop music
    scene e1s10-56 with wipeleft
    play music invisible_light
    mc "Well... room 34."
    mc "This seems to be the place."

    scene e1s10-57 with dissolve
    pause

    scene e1s10-58 with dissolve
    mc "What's up?"

    scene e1s10-59 with dissolve
    unknown "Hey! Looks like I got a roommate in the end."

    scene e1s10-60 with dissolve
    show e1s10_nate_blink1
    mc "Yeah!"
    mc "I've been staying at a friend's place so I wasn't really around college."

    scene e1s10-59 with dissolve
    hide e1s10_nate_blink1
    unknown "It's alright, don't worry."
    unknown "I enjoyed the time alone."

    scene e1s10-60 with dissolve
    show e1s10_nate_blink1
    mc "Haha, I see!"
    mc "I'm [mc] by the way."

    scene e1s10-59 with dissolve
    hide e1s10_nate_blink1
    nt "I'm Nathan, but you can call me [nt]."

    scene e1s10-60 with dissolve
    show e1s10_nate_blink1
    mc "Alright."

    scene e1s10-59 with dissolve
    hide e1s10_nate_blink1
    nt "Well, make yourself at home."

    scene e1s10-60 with dissolve
    show e1s10_nate_blink1
    mc "Thanks!"
    mc "I won't be staying long though."
    mc "I don't have my stuff with me, just wanted to see the room."

    scene e1s10-59 with dissolve
    hide e1s10_nate_blink1
    nt "Alright, tell me if you need anything."

    stop music fadeout 2.0
    jump e1f3
return
