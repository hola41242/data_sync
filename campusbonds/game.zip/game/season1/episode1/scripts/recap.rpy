
# Episode 1 Recap ##############################################################

label e1re:
    $ quick_menu = True
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    show screen recap_skip
    play music careful
    show text "{size=80}Previously, on Campus Bonds...{/size}"
    pause(1.0)

    scene e1s1-06 with wipeleft
    mc "Yoo! I got in!{w=1.0}{nw}"

    scene e1s1-05 with dissolve
    jn "You did?{w=0.7}{nw}"
    jn "That's awesome!{w=0.7}{nw}"

    scene e1s2-14 with wiperight
    pause(1.0)

    if e1s2_smile_back == True:
        scene e1s2-15 with dissolve
        mc "*She is cute!*{w=1.0}{nw}"

    if e1s2_smile_back == False:
        scene e1s2-16 with dissolve
        mc "*Eh, not really my type.*{w=1.0}{nw}"

    scene e1s4-47 with wipeleft
    show e1s4_mc_blink1
    jd "I got a pretty funny idea!{w=1.0}{nw}"

    show e1s4-48 behind e1s4_mc_blink1 with dissolve
    jd "What if we throw this balloon at her right now!{w=1.0}{nw}"

    if balloon_hit == True:
        scene e1s4-55 with dissolve
        hide e1s4-48
        hide e1s4_mc_blink1
        mc "I'll do it!{w=0.7}{nw}"

        play sound water_balloon
        scene e1s4-64 with dissolve
        unknown "What the fuck??{w=0.7}{nw}"

    if balloon_hit == False:
        scene e1s4-56 with dissolve
        hide e1s4-48
        hide e1s4_mc_blink1
        mc "Sorry guys..{w=0.7}{nw}"
        mc "I'm not doing it.{w=0.7}{nw}"

    scene e1s6-14 with wiperight
    unknown "Oh my gosh!{w=1.0}{nw}"

    scene e1s6-28 with dissolve
    unknown "I'm so sorry!{w=0.7}{nw}"

    scene e1s6-28 with dissolve
    hide e1s6-olivia_blink2
    unknown "The front office told me I shouldn't be filming here.{w=1.0}{nw}"

    scene e1s7-07 with wipeleft
    show e1s7_cleo_blink1
    mc "*Is that..?*{w=0.7}{nw}"
    mc "*Yeah it is!*{w=0.7}{nw}"

    scene e1s10-14 with wiperight
    cl "Can you believe this?{w=0.7}{nw}"
    cl "I won't get my dorm until next month.{w=1.0}{nw}"

    scene e1s10-59 with wipeleft
    unknown "Hey! Looks like I got a roommate in the end!{w=1.0}{nw}"

    scene e1s10-60 with dissolve
    show e1s10_nate_blink1
    mc "I've been staying at a friend's place so I wasn't really around college!{w=1.5}{nw}"

    scene e1s13-31 with wipeleft
    show e1s13_jon_blink1
    mc "Have you heard anything about the freshies party at Eddy's?{w=1.0}{nw}"

    scene e1s18-22 with dissolve
    jn "About that..{w=0.7}{nw}"

    scene e1s18-25 with dissolve
    jn "The party's off!{w=0.7}{nw}"

    scene sp_e1f4-04 with dissolve
    mc "*I need to find out what's going on..*{w=1.0}{nw}"

    scene e1s16-01 with wiperight
    jn "So, I guess this is where we say good bye..{w=1.0}{nw}"
    jn "You've been a good man..{w=1.0}{nw}"

    scene e1s16-02
    mc "Dude, I'm only moving to my dorm!{w=1.0}{nw}"

    scene e1s11-13 with wipeleft
    show e1s11_francesca_blink2
    mc "Well, getting a career in fighting was my original plan..{w=1.0}{nw}"

    show e1s11-16 behind e1s11_francesca_blink2 with dissolve
    mc "..but unfortunately I got seriously injured during a fight.{w=1.0}{nw}"
    mc "And because of that I'm unable to pursue a career.{w=1.0}{nw}"

    if e1s11_kiss_her == True:
        scene e1s11-29 with dissolve
        pause(1.0)

        scene e1s11-30 with dissolve
        hide e1s11-francesca_blink4
        fr "[mc].. I.. I'm sorry, I have to go!{w=1.0}{nw}"

    scene e1s14-72 with wiperight
    sp "I think we're gonna have to cut some expenses this month.{w=1.0}{nw}"

    scene e1s14-73 with dissolve
    mc "*Who is he talking about?*{w=1.0}{nw}"

    scene e1s14-77 with vpunch
    mc "*Oh shit!*{w=0.7}{nw}"

    scene e1s15-07 with dissolve
    cl "No, I would not like to go out with you, [da]!{w=1.0}{nw}"
    cl "I've already told you that I'm seeing someone today.{w=1.0}{nw}"

    scene e1s15-06 with dissolve
    da "Okay, so it's a date then!{w=1.0}{nw}"

    scene e1s19-27 with dissolve
    jn "Let's go inside, we'll talk more there.{w=1.0}{nw}"

    scene e1s19-29
    pause(1.0)

    jump e2s0
return
