
# Freeroam Screens #############################################################

# Freeroam #2 Screens ##########################################################

screen f2_living():
    $ renpy.random.shuffle(f2_tracks)

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        add "e1f2-01"
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        add "e1f2-01-1"
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        add "e1f2-01-2"
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        add "e1f2-01-4"
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        add "e1f2-01-4"
    if e1f2_interact == 4:
        add "e1f2-01-3"
    modal True

    if e1f2_interact < 4 and e1f2_jon == False and e1f2_sadie_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_jon_girls_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_jon_girls_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_kitchen")

    if e1f2_interact < 4 and e1f2_jon == True and e1f2_sadie_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_girls_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_girls_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_kitchen")

    if e1f2_interact < 4 and e1f2_jon == False and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_jon_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_jon_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_kitchen")

    if e1f2_interact < 4 and e1f2_jon == True and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_kitchen_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_kitchen")

    if e1f2_interact == 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bathroom_shots_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bathroom_shots_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_bathroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_bathroom")

    if e1f2_interact == 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bedroom_shots_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bedroom_shots_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_bedroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_bedroom")

    if e1f2_sadie_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/sadie_tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/sadie_tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_sadie_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_sadie_tracy")

    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_sadie")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_sadie")

    if e1f2_interact == 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/shots_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/shots_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_shots")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_shots")

    if e1f2_interact < 4 and e1f2_ken == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_ken")

    # Rooms ####################################################################

    if e1f2_interact < 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bathroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bathroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_bathroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_bathroom")

    if e1f2_interact < 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bedroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/from_living_to_bedroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_bedroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_bedroom")

    if persistent.cl_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/living_room/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/living_room/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_1_unlocked", True), SetVariable("persistent.e1f2_collected_p", persistent.e1f2_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo1", True), Function(update_cleo_list)]

screen f2_kitchen():
    $ renpy.random.shuffle(f2_tracks)

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        add "e1f2-02"
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        add "e1f2-02-1"
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        add "e1f2-02-2"
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        add "e1f2-02-4"
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        add "e1f2-02-4"
    if e1f2_interact == 4:
        add "e1f2-02-3"

    modal True

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_girls_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_girls_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_living")

    if e1f2_jon == True and e1f2_sadie_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_girls_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_girls_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_living")

    if e1f2_jon == False and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_living")

    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_living")

    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/from_kitchen_to_living_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_living")

    if e1f2_jon == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/jon_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/jon_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f2_jon")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f2_jon")

    if persistent.cl_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam2/kitchen/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam2/kitchen/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_2_unlocked", True), SetVariable("persistent.e1f2_collected_p", persistent.e1f2_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo2", True), Function(update_cleo_list)]

screen f2_bathroom():
    $ renpy.random.shuffle(f2_tracks)

    add "e1f1-05"
    modal True

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/bathroom/from_bathroom_to_living_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/bathroom/from_bathroom_to_living_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f2_living")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f2_living")

    if persistent.sc_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_1_unlocked", True), SetVariable("persistent.e1f2_collected_p", persistent.e1f2_collected_p+1), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett1", True), Function(update_scarlett_list)]
