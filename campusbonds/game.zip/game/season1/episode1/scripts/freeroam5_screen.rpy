
# Freeroam Screens #############################################################

# Freeroam #5 Screens ##########################################################

screen e1f5_main():
    $ renpy.random.shuffle(e1f5_tracks)

    if e1f5_sadie_tracy_1 == False:
        add "e1f5-01"
    elif e1f5_tracy_drink < 7:
            if e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
                add "e1f5-01-3"
            else:
                add "e1f5-01-1"
    elif e1f5_tracy_drink == 7:
        if e1f5_refuse_sadie == False:
            if e1f5_tracy_sex == True:
                add "e1f5-01-1"
            else:
                add "e1f5-01-2"
        elif e1f5_refuse_sadie == False or e1f5_sadie_introvert == True:
            if e1f5_tracy_sex == True:
                add "e1f5-01-3"
            else:
                add "e1f5-01-4"

    modal True

    # To Bar ###################################################################

    if e1f5_sadie_tracy_1 == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/from_main_to_bar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/from_main_to_bar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_bar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_bar")
    else:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/from_main_to_bar_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/from_main_to_bar_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_bar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_bar")

    # To Exit ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/main/from_main_to_exit_sadie_tracy_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/main/from_main_to_exit_sadie_tracy_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_exit")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_exit")

    # To Back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/main/from_main_to_back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/main/from_main_to_back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_back")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_back")

    # Clickables ###############################################################

    if e1f5_sadie_tracy_1 == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/sadie_tracy_1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/sadie_tracy_1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_sadie_tracy_1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_sadie_tracy_1")

    if e1f5_tracy_drink > 0 and e1f5_tracy_drink <= 3 and affinity_spectrum > 0 or e1f5_tracy_drink == 5 and affinity_spectrum > 0 or e1f5_tracy_drink == 6 and affinity_spectrum > 0:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/tracy_drink_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/tracy_drink_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_tracy_drink")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_tracy_drink")

    if persistent.mixed_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_4_unlocked", True), SetVariable("persistent.e1f5_collected_p", persistent.e1f5_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed4", True), Function(update_mixed_list)]

    if e1f5_money == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/main/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/main/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e1f5_money", True)]

screen e1f5_bar():
    $ renpy.random.shuffle(e1f5_tracks)

    if e1f5_sadie_tracy_1 == False and e1f5_refuse_sadie == False:
        add "e1f5-02"

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
        add "e1f5-02-1"

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
        add "e1f5-02"

    modal True

    # To Exit ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_exit_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_exit_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_exit")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_exit")

    # To Back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_back")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_back")

    # To Main ##################################################################

    if e1f5_sadie_tracy_1 == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_main")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_main")

    if e1f5_sadie_tracy_1 == True and e1f5_refuse_sadie == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_main")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_main")

    if e1f5_refuse_sadie == True or e1f5_sadie_introvert == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/from_bar_to_main_nate_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_main")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_main")

    # Clickables ###############################################################

    if e1f5_sadie_tracy_1 == True and e1f5_sadie_drink2 == 0:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/sadie_drink_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/sadie_drink_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_sadie_drink1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_sadie_drink1")

    if e1f5_sadie_drink2 == 1:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/sadie_drink_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/sadie_drink_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_sadie_drink2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_sadie_drink2")

    if e1f5_tracy_drink_ask == True and e1f5_tracy_drink == 0 and affinity_spectrum > 0 and e1f5_sadie_tracy_1 == True or e1f5_banana == True and e1f5_tracy_drink == 4:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/bartender_tracy_drink_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/bartender_tracy_drink_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_tracy_drink")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_tracy_drink")

    if e1f5_nate_bar1 == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/nate_bar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/nate_bar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_nate_bar1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_nate_bar1")

    if persistent.cl_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bar/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bar/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_4_unlocked", True), SetVariable("persistent.e1f5_collected_p", persistent.e1f5_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo4", True), Function(update_cleo_list)]

screen e1f5_exit():
    $ renpy.random.shuffle(e1f5_tracks)

    if e1f5_sadie_tracy_1 == False:
        add "e1f5-03"
    else:
        add "e1f5-03-1"

    modal True

    # To Bar ###################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_bar")

    # To Outside ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_outside_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_outside_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_outside")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_outside")

    # To Main ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/exit/from_exit_to_main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_main")

    if persistent.mixed_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/exit/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/exit/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_3_unlocked", True), SetVariable("persistent.e1f5_collected_p", persistent.e1f5_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed3", True), Function(update_mixed_list)]

screen e1f5_back():

    $ renpy.random.shuffle(e1f5_tracks)

    add "e1f5-04"
    modal True

    # To Bar ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/back/from_back_to_bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/back/from_back_to_bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_bar")

    # To Main ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/back/from_back_to_main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/back/from_back_to_main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_main")

    # To Bathroom ##############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/back/from_back_to_bathroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/back/from_back_to_bathroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_bathroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_bathroom")

    # Clickables ###############################################################

    if persistent.fr_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/back/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/back/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_3_unlocked", True), SetVariable("persistent.e1f5_collected_p", persistent.e1f5_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca3", True), Function(update_francesca_list)]

screen e1f5_bathroom():
    $ renpy.random.shuffle(e1f5_tracks)

    if e1f5_tracy_drink == 7 and e1f5_tracy_sex == False:
        add "e1f5-05-1"
    else:
        add "e1f5-05"

    modal True

    # To Back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/bathroom/from_bathroom_to_back_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/bathroom/from_bathroom_to_back_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_back")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_back")

    # Clickables ###############################################################

    if persistent.tr_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_3_unlocked", True), SetVariable("persistent.e1f5_collected_p", persistent.e1f5_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy3", True), Function(update_tracy_list)]

    if e1f5_tracy_drink == 7 and e1f5_tracy_sex == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/bathroom/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/bathroom/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_tracy_sex")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_tracy_sex")

screen e1f5_outside():
    $ renpy.random.shuffle(e1f5_tracks)

    if e1f5_finish == False:
        if e1f5_sadie_tracy_1 == True:
            add "e1f5-06-3"
        else:
            add "e1f5-06"
    else:
        if e1f5_sadie_tracy_1 == True or affinity_spectrum < 0 and e1f5_outside == True:
            add "e1f5-06-2"
        else:
            add "e1f5-06-1"

    modal True

    # To Main ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam5/outside/from_outside_to_main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam5/outside/from_outside_to_main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f5_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f5_main")

    # Clickables ###############################################################

    if e1f5_bouncer_talk == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/outside/bouncer_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/outside/bouncer_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_bouncer")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_bouncer")

    if e1f5_finish == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/outside/scarlett_francesca_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/outside/scarlett_francesca_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_scarlett_francesca")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_scarlett_francesca")

    if e1f5_finish == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam5/outside/ken_jordan_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam5/outside/ken_jordan_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f5_ken_jordan")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f5_ken_jordan")
