
# Scene 12 - Jon's apartment ###################################################

label e1s12:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    play sound door_open
    scene e1s12-01 with Dissolve(2.0)
    pause

    play music onfire
    play sound door_close
    scene e1s12-02 with dissolve
    pause

    scene e1s12-03 with dissolve
    pause

    scene e1s12-04 with dissolve
    mc "Dude, what are you doing?"

    scene e1s12-03 with dissolve
    pause

    scene e1s12-07 with dissolve
    jn "Counting pennies, obviously..."

    scene e1s12-03 with dissolve
    pause

    scene e1s12-04 with dissolve
    mc "Yeah but, why do you have that many?"

    scene e1s12-03 with dissolve
    pause

    scene e1s12-07 with dissolve
    jn "Dude you're..."
    jn "You're asking the wrong questions here man!"

    scene e1s12-06 with dissolve
    mc "Alright, you do you."

    scene e1s12-05 with dissolve
    pause

    scene e1s12-08 with dissolve
    pause

    scene e1s12-09 with dissolve
    pause

    scene e1s12-12 with dissolve
    jn "So, how was the uni tour?"

    scene e1s12-17 with dissolve
    jn "I get it was really interesting for you to show this late at night."

    scene e1s12-18 with dissolve
    show e1s12_jon_blink2
    menu:
        "Tell him the full story":

            $ jon_friendship += 1

            mc "Funnily enough, I didn't even get the full tour."
            mc "Do you remember the girl from the diner?"

            scene e1s12-10 with dissolve
            hide e1s12_jon_blink1
            pause

            scene e1s12-12 with dissolve
            jn "Yeah, what about her?"

            if e1s2_smile_back == True:
                scene e1s12-11 with dissolve
                show e1s12_jon_blink1
                mc "I actually met her on the train before coming here and she smiled at me."

                scene e1s12-13 with dissolve
                hide e1s12_jon_blink1
                jn "Haha, what?"
                jn "What are the odds?"

                scene e1s12-14 with dissolve
                show e1s12_jon_blink3
                mc "I know right??"

                if e1s2_talk_to_her == True:
                    mc "I smiled back because I thought she was cute and I wanted to talk to her."

                if e1s2_talk_to_her == False:
                    mc "I smiled back because I thought she was cute."

                mc "But, before I got the chance, she got off..."
                mc "After this, I met her again at the diner."

                scene e1s12-12 with dissolve
                hide e1s12_jon_blink3
                jn "Yeah, I remember."

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "After you left, we talked for a bit and today I found out she's going to the same university as us."
            mc "So, as the gentleman I am, I said hi and she offered to give me a tour instead."

            scene e1s12-17 with dissolve
            hide e1s12_jon_blink1
            jn "What? Just like that?"

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "Yeah, and that's not even the craziest part..."

            scene e1s12-12 with dissolve
            hide e1s12_jon_blink1
            jn "Don't say what I think you're gonna say..."

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "Nah, nothing happened between us."
            mc "I actually met another girl tonight."

            scene e1s12-15 with dissolve
            hide e1s12_jon_blink1
            jn "Ooh, so that's who you did it with!"

            scene e1s12-16 with dissolve
            mc "Um... no!"
            mc "Bro, just listen."

            scene e1s12-12 with dissolve
            hide e1s12_jon_blink1
            jn "Alright, alright."

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "So, as I was walking back here, I walked past a food truck and there was this girl who dropped all her food on me."
            mc "She felt really bad about it so she offered to give me a meal."

            if e1s11_kiss_her == True:
                mc "We shared some things about our pasts and I had the feeling that I should kiss her..."
                mc "...so I did!"

                scene e1s12-13 with dissolve
                hide e1s12_jon_blink1
                jn "That's my boy!"

                scene e1s12-14 with dissolve
                show e1s12_jon_blink3
                mc "The sad part about this is that she suddenly got a scared look on her face and she stormed off..."

                scene e1s12-12 with dissolve
                hide e1s12_jon_blink3
                jn "Bro... you scared her off."

                scene e1s12-11 with dissolve
                show e1s12_jon_blink1
                mc "What? No, I didn't!"
                mc "She was leaning into me, I thought that's what she wanted!"

                scene e1s12-12 with dissolve
                hide e1s12_jon_blink1
                jn "Nah... you surely did..."

            if e1s11_kiss_her == False:
                mc "We shared some things about our pasts and I really felt a connection with her."

                scene e1s12-12 with dissolve
                hide e1s12_jon_blink1
                jn "So, did you do anything or what?"

                scene e1s12-11 with dissolve
                show e1s12_jon_blink1
                mc "Nah, that's what's been bugging me..."
                mc "It's like she wanted to kiss me but she was holding off."

                scene e1s12-12 with dissolve
                hide e1s12_jon_blink1
                jn "Yeah, you definitely should have kissed her."

        "Spare him the details":

            mc "Well, I hung out with some girl I met tonight at a food truck."

            scene e1s12-19 with dissolve
            hide e1s12_jon_blink1
            jn "That's one weird way to meet a woman."

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "I know right? Too bad she stormed off..."

            scene e1s12-12 with dissolve
            hide e1s12_jon_blink1
            jn "Bro... you scared her off."

            scene e1s12-11 with dissolve
            show e1s12_jon_blink1
            mc "What? No, I didn't!"

            scene e1s12-12 with dissolve
            hide e1s12_jon_blink1
            jn "Nah... you surely did..."

    scene e1s12-12 with dissolve
    hide e1s12_jon_blink1
    jn "Cheer up buddy!"
    jn "It is what it is."
    jn "There's plenty of women out there, don't waste your emotions on some girl you just met."

    scene e1s12-20 with dissolve
    jn "I've had multiple encounters like this and I can say that none of them actually ended up being something more..."

    scene e1s12-12 with dissolve
    jn "It's just better to shrug it off and go on about your life."
    jn "It gets easier..."

    scene e1s12-11 with dissolve
    show e1s12_jon_blink1
    menu:
        "Something more":

            $ francesca_trust += 1
            mc "I don't know man... I felt like it was something more."
            mc "But I guess you're right to some extent..."

        "Just an encounter":

            mc "Yeah, I guess you're right."
            mc "It was just a random encounter, it didn't mean anything."

    scene e1s12-12 with dissolve
    hide e1s12_jon_blink1
    jn "Now, cheer up and help me count these pennies."

    scene e1s12-21 with dissolve
    pause

    jump e1s13
return
