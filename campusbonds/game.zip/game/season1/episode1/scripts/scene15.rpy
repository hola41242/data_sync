
# Scene 15 - A date with Cleo ##################################################

label e1s15:
    stop music fadeout 2.0
    play music laurel_breeze
    scene e1s15-01 with wipeleft
    pause

    scene e1s15-02 with dissolve
    n_nvl "Hey, it's [mc]."
    n_nvl "I just finished my classes."
    cl_nvl "Alright, come pick me up from the diner."

    scene e1s15-03 with wipeleft
    pause

    scene e1s15-04 with dissolve
    pause

    stop music fadeout 2.0
    scene e1s15-05 with dissolve
    play music rollin_at_5
    pause

    scene e1s15-07 with dissolve
    cl "No, I would not like to go out with you, [da]!"
    cl "I've already told you that I'm seeing someone today."
    cl "Why do you have to be so intrusive?"

    scene e1s15-06 with dissolve
    da "Alright then, tomorrow?"

    scene e1s15-07 with dissolve
    cl "You already know that I'm working tomorrow..."

    scene e1s15-06 with dissolve
    da "Okay, so it's a date then."

    scene e1s15-14 with dissolve
    cl "*Exhales...*"

    scene e1s15-08 with dissolve

    if persistent.tutorial == True:
        show tutorial_background_menu with wiperight
        show dialogue_box with wiperight
        show f1_text "The following menu will have limited availability." with wiperight
        pause

        hide f1_text with wipeleft
        show f1_text "Based on your previous choices, you can only \n choose one of the following choices." with wiperight
        pause

        hide f1_text with wipeleft
        show f1_text "From this point onwards, you will encounter locked \n choices." with wiperight
        pause

        hide f1_text with wipeleft
        hide dialogue_box with wipeleft
        hide tutorial_background_menu with wipeleft
    menu:

    # Confront him #############################################################

        "Confront him" if affinity_spectrum > 0:
            call extrovert_affinity_check from _call_extrovert_affinity_check_14
            call color_check from _call_color_check_27

            scene e1s15-09 with dissolve
            mc "Hey, is there a problem here?"

            scene e1s15-11 with dissolve
            da "Go away, fam!"

            scene e1s15-13 with dissolve
            da "This one's taken."

            scene e1s15-07 with dissolve
            cl "No, I'm not."

            scene e1s15-10 with dissolve
            show e1s15_darryl_blink1
            menu:

            # Pretend to be BF #################################################

                "Pretend to be her boyfriend":

                    $ cleo_trust += 1
                    $ e1s15_gfpretend = True

                    mc "Taken by me, yeah!"

                    scene e1s15-11 with dissolve
                    hide e1s15_darryl_blink1
                    da "What do you mean?"

                    scene e1s15-10 with dissolve
                    show e1s15_darryl_blink1
                    mc "It seems to me that you're trying to hit on my girlfriend."

                    scene e1s15-12 with dissolve
                    hide e1s15_darryl_blink1
                    pause

                    scene e1s15-23 with dissolve
                    da "Girlfriend...?"

                    scene e1s15-10 with dissolve
                    show e1s15_darryl_blink1
                    mc "So... unless you need anything else, how about you stop bothering us?"

                    scene e1s15-18 with dissolve
                    hide e1s15_darryl_blink1
                    da "Guh..."

            # Politely make him leave ##########################################

                "Politely make him leave":

                    mc "Look bro, I'm supposed to meet this girl."
                    mc "I don't know what your problem is and why you're bothering her but she's here for me, not you."

                    scene e1s15-11 with dissolve
                    hide e1s15_darryl_blink1
                    da "My problem is with you, so how about you leave or else I'll make you leave?"

                    scene e1s15-10 with dissolve
                    show e1s15_darryl_blink1
                    menu:

                    # Get mad ##################################################

                        "Get mad":

                            $ e1s15_mad = True

                            mc "Look 'fam', I've tried being polite but now you're getting on my nerves."
                            mc "Don't say you haven't been warned."

                            scene e1s15-18 with dissolve
                            hide e1s15_darryl_blink1
                            da "Guh..."
                            mc "Yeah, I thought so too!"

                    # Be polite ################################################

                        "Be polite":

                            mc "Look dude, let's be mature here and not escalate into something else..."
                            mc "I've already told you the situation, how about you just leave us alone now?"

                            scene e1s15-23 with dissolve
                            hide e1s15_darryl_blink1
                            da "Oh yeah?"
                            da "How about this?"

                            play sound punch
                            scene e1s15-19 with vpunch
                            play music keep_it_down
                            menu:

                            # Fight him ########################################

                                "Fight him":

                                    $ e1s15_mad = True

                                    mc "Ok, now you're asking for it!"

                                    scene e1s15-15 with dissolve
                                    cl "[mc]..."

                                    scene e1s15-16 with dissolve
                                    cl "[da], just leave!"

                                    scene e1s15-18 with dissolve
                                    da "You're lucky this girl just saved your ass!"

                            # Don't escalate ###################################

                                "Don't escalate":

                                    $ e1s15_calm = True
                                    $ cleo_trust += 1

                                    scene e1s15-16 with dissolve
                                    cl "Alright, that's enough!"
                                    cl "[da], just leave!"

                                    scene e1s15-17 with dissolve
                                    da "You're lucky this girl saved you."

                                    scene e1s15-18 with dissolve
                                    da "Cunt."

    # Let it slide #############################################################

        "Let it slide" if affinity_spectrum <= 0:
            call introvert_affinity_check from _call_introvert_affinity_check_12
            $ cleo_trust += 1
            call color_check from _call_color_check_28

            scene e1s15-06 with dissolve
            da "So, I'll be seeing you tomorrow then, alright?"

            scene e1s15-18 with dissolve
            pause

    scene e1s15-20 with dissolve
    stop music fadeout 1.0
    show e1s15_cleo_blink1
    mc "What was that all about?"

    scene e1s15-21 with dissolve
    hide e1s15_cleo_blink1
    cl "Oh, just my stupid co-worker."

    scene e1s15-22 with dissolve
    cl "Come on, let's go."

    play music release
    if cleo_trust <= 1:
        scene e1s15-24 with wipeleft
        pause

    if cleo_trust > 1:
        scene e1s15-25 with wipeleft
        pause

    scene e1s15-26 with dissolve
    pause

    if cleo_trust <= 1:
        scene e1s15-29 with dissolve
        pause

    if cleo_trust > 1:
        scene e1s15-28 with dissolve
        pause

    if e1s15_gfpretend == True:
        scene e1s15-30 with dissolve
        cl "So... looks like I'm 'taken' by you now, huh?"

        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2
        mc "Haha, I only told him that so he would leave you alone."

        scene e1s15-37 with dissolve
        hide e1s15_cleo_blink2
        cl "Haha, a clever idea I must say."

        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2
        mc "So, what's up with that guy anyways?"

    if e1s15_gfpretend == False:
        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2
        mc "So, what's up with that guy?"

    scene e1s15-31 with dissolve
    hide e1s15_cleo_blink2
    cl "He's my co-worker and the son of my boss."

    scene e1s15-32 with dissolve
    cl "He's been bugging me ever since I signed up for the job."

    if e1s15_calm == True:
        scene e1s15-31 with dissolve
        cl "I must say I'm pretty surprised you kept a straight face throughout the whole argument."

        scene e1s15-36 with dissolve
        cl "If I were in your shoes, I would have probably punched him in the face long before he opened his mouth."

        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2

    if e1s15_mad == True:
        scene e1s15-31 with dissolve
        cl "I'm not surprised you wanted to punch him in the face."

        scene e1s15-36 with dissolve
        cl "He deserves it!"

        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2

    if e1s15_gfpretend == True:
        scene e1s15-38 with dissolve
        cl "I don't think he's gonna bother me anymore, at least for a while..."

        scene e1s15-30 with dissolve
        cl "...now that I'm your 'girlfriend'"

        scene e1s15-27 with dissolve
        show e1s15_cleo_blink2
        mc "Haha, stop fucking with me."

    mc "If he keeps bugging you then why don't you quit?"
    mc "Find another job perhaps?"

    scene e1s15-38 with dissolve
    hide e1s15_cleo_blink2
    cl "It's not that easy!"
    cl "It was already hard finding this one."

    scene e1s15-33 with dissolve
    show e1s15_cleo_blink2
    mc "So... why did you tell me to meet you there if you hate that place so much?"

    scene e1s15-31 with dissolve
    hide e1s15_cleo_blink2
    cl "I had to pick up something, that's why."

    scene e1s15-32 with dissolve
    cl "I wouldn't have stepped foot in that place if it weren't for me working there."

    scene e1s15-38 with dissolve
    cl "I thought he wasn't around but he showed up out of nowhere."

    scene e1s15-33 with dissolve
    show e1s15_cleo_blink2
    mc "Why don't you tell your boss about him?"

    scene e1s15-35 with dissolve
    hide e1s15_cleo_blink2
    cl "He's just like him, it's no use."

    menu:
        "Offer to help":

            $ cleo_trust += 1
            $ e1s15_help = True

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "Hey, what if I try and find another job suitable for you?"
            mc "I know that sounds a bit weird but, hear me out."
            mc "My friend [jon] is a little bit influential around these places and maybe he can help."
            mc "I can always call him and he can-"

            scene e1s15-35 with dissolve
            hide e1s15_cleo_blink2
            cl "[mc], look..."

            scene e1s15-34 with dissolve
            cl "I really appreciate that you're trying to help."

            scene e1s15-36 with dissolve
            cl "But I don't know if I can take you up on that offer..."

            scene e1s15-38 with dissolve
            cl "Especially now that I'm living in an apartment bought by him."

            scene e1s15-34 with dissolve
            cl "You're really sweet for trying to help me and all."

            scene e1s15-36 with dissolve
            cl "What if we leave it at that and if I need help I'll tell you."
            cl "Is that alright?"

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "Yeah, of course!"
            mc "Don't worry about it."
            mc "I was just exploring options, it's fine if you can't."

            scene e1s15-38 with dissolve
            hide e1s15_cleo_blink2
            cl "Thanks [mc]!"

            scene e1s15-39 with dissolve
            mc "..."

            scene e1s15-41 with dissolve
            show e1s15_mc_blink1
            pause

            scene e1s15-40 with dissolve
            hide e1s15_mc_blink1

        "Stay out of it":

            $ e1s15_help = False

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "So, what are you gonna do about it?"

            scene e1s15-31 with dissolve
            hide e1s15_cleo_blink2
            cl "I'll just keep my head down and try to avoid him at all costs."

            scene e1s15-32 with dissolve
            cl "Keep working there until I've saved enough money so I can quit that shithole and survive for at least a couple of months on my own."

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "Looks like you got everything figured out."

            scene e1s15-36 with dissolve
            hide e1s15_cleo_blink2
            cl "Trust me, I've been making plans from day one."

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "That's very good!"

            scene e1s15-31 with dissolve
            hide e1s15_cleo_blink2
            cl "Yeah!"

            scene e1s15-33 with dissolve
            show e1s15_cleo_blink2
            mc "..."

    hide e1s15_cleo_blink2
    mc "So... are you still not coming to Eddy's?"

    scene e1s15-37 with dissolve
    cl "Haha, nice try!"

    scene e1s15-43 with dissolve
    cl "It's gonna take more than listening to my problems to make me join you at a party."

    scene e1s15-27 with dissolve
    show e1s15_cleo_blink2
    mc "Well, at least I tried."

    scene e1s15-37 with dissolve
    hide e1s15_cleo_blink2
    cl "Haha!"

    stop music fadeout 4.0
    scene e1s15-46 with dissolve
    pause

    scene e1s15-45 with dissolve
    pause

    scene e1s15-46 with dissolve
    pause

    play music thanks_for_coming
    scene e1s15-43 with dissolve
    cl "Hey, I want some cotton candy."

    scene e1s15-34 with dissolve
    cl "Come on, let's grab some."

    scene e1s15-27 with dissolve
    show e1s15_cleo_blink2
    mc "Haha, aren't you a little too old for that?"

    scene e1s15-42 with vpunch
    hide e1s15_cleo_blink2
    cl "Hey, don't make fun of me!"
    cl "I'm almost 19."

    scene e1s15-43 with dissolve
    cl "Come on!!"

    scene e1s15-44 with dissolve
    pause

    scene e1s15-47 with Dissolve(2.0)
    pause

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "Also, forgot to tell you..."
    mc "I'm finally moving into my dorm tomorrow."

    scene e1s15-49 with dissolve
    hide e1s15_cleo_blink3
    cl "Haha, it took you a while."

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "Yeah, you should have seen [jon]."
    mc "Not even my father was this sad to see me leave."

    scene e1s15-49 with dissolve
    hide e1s15_cleo_blink3
    cl "Haha, looks like he really does care about you."

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "Of course, we were like brothers before I moved."

    scene e1s15-50 with dissolve
    hide e1s15_cleo_blink3
    cl "How was it there? Before you moved?"

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "It was pretty awesome."
    mc "I don't know if it's the nostalgia talking, or if things were better as a kid..."
    mc "...but I feel like there's something special about your place of birth..."
    mc "...and that things just feel alright whenever you move back."

    scene e1s15-51 with dissolve
    hide e1s15_cleo_blink3
    cl "I've never looked at things this way."

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "Yeah well, I had plenty of time to think about it."
    mc "I'm glad that me and [jon] kept in touch and that we're still really good friends to this day."

    scene e1s15-52 with dissolve
    hide e1s15_cleo_blink3
    cl "Hey, I'm happy for you!"

    scene e1s15-50 with dissolve
    cl "Not everyone manages to keep a friendship this strong for so long."

    scene e1s15-51 with dissolve
    cl "Some people don't even get to have friendships like this, ever."

    scene e1s15-50 with dissolve
    cl "So, consider yourself lucky."

    scene e1s15-48 with dissolve
    show e1s15_cleo_blink3
    mc "Yeah, for sure!"

    stop music
    play sound water_drop
    scene e1s15-54 with dissolve
    play music keep_it_down
    hide e1s15_cleo_blink3
    pause

    scene e1s15-53 with dissolve
    mc "Oh shit, is it raining?"

    $renpy.sound.play("audio/sfx/rain.ogg", loop=True)
    scene e1s15-55 with dissolve
    cl "Haha, I guess it is!"

    scene e1s15-56 with dissolve
    mc "Quick, run!"

    scene e1s15-57 with dissolve
    pause

    stop music fadeout 1.0
    stop sound fadeout 1.0
    scene e1s15-58 with wipeleft
    play music inhale
    pause

    scene e1s15-60 with dissolve

    cl "So... this is me."
    cl "I had a great time today."

    scene e1s15-61 with dissolve
    cl "Thanks for the invitation."

    scene e1s15-59 with dissolve
    show e1s15_cleo_blink4
    mc "Yeah, it was pretty fun!"
    mc "Too bad the rain ruined it."

    scene e1s15-60 with dissolve
    hide e1s15_cleo_blink4
    cl "I think it made it even better."

    scene e1s15-61 with dissolve
    cl "So, I guess I'll be seeing you around?"

    scene e1s15-59 with dissolve
    show e1s15_cleo_blink4
    mc "Sure!"

    if cleo_trust >= 2:
        if affinity_spectrum <= 0:
            scene e1s15-62 with dissolve
            hide e1s15_cleo_blink4
            pause

        if affinity_spectrum > 0:
            scene e1s15-63 with dissolve
            hide e1s15_cleo_blink4
            pause

    scene e1s15-61 with dissolve
    cl "Bye [mc]! Take care."

    scene e1s15-59 with dissolve
    show e1s15_cleo_blink4
    mc "You too, bye!"

    scene e1s15-64 with dissolve
    hide e1s15_cleo_blink4

    menu:
        "Check her out":
            scene e1s15-65 with dissolve
            pause
        "Don't check her out":
            pass

    scene e1s15-66 with dissolve
    pause

    jump e1s16

return
