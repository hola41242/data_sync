
# Scene 17 - Spending time with (...) ##########################################

label e1s17:
    # Tracy ####################################################################
    if e1s17_tracy == True:
        stop music fadeout 2.0
        scene tr-e1s17-01 with dissolve
        pause

        play sound knock_knock
        scene tr-e1s17-02 with dissolve
        pause

        scene tr-e1s17-03 with dissolve
        pause

        play music invisible_light
        scene tr-e1s17-04 with dissolve
        tr "Hey [mc]!"

        scene tr-e1s17-05 with dissolve
        tr "Come on in."

        scene tr-e1s17-06 with dissolve
        mc "Nice room!"

        scene tr-e1s17-07 with dissolve
        tr "Thanks!"

        scene tr-e1s17-08 with dissolve
        mc "So, what's up?"

        scene tr-e1s17-10 with dissolve
        tr "Well, just got back from the audition."

        scene tr-e1s17-09 with dissolve
        show e1s17-tracy_blink1
        mc "And? How was it?"

        scene tr-e1s17-11 with dissolve
        hide e1s17-tracy_blink1
        pause

        scene tr-e1s17-12 with dissolve
        pause

        scene tr-e1s17-15 with dissolve
        tr "It was alright, I made a couple of small mistakes but overall my performance was decent."

        scene tr-e1s17-17 with dissolve
        tr "Wait, I haven't told you what the auditions were about, right?"

        scene tr-e1s17-23 with dissolve
        show e1s17-tracy_blink3
        mc "Haha, it's alright, Sadie already told me."

        scene tr-e1s17-16 with dissolve
        hide e1s17-tracy_blink3
        tr "Haha, I see."

        scene tr-e1s17-17 with dissolve
        tr "What about you, dude?"

        scene tr-e1s17-14 with dissolve
        tr "Tell me again. why did you move?"

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        mc "So, let's say you're sleeping at a friend's on his couch and it barely fits your ass, would you stay there?"
        mc "Knowing that you have a pretty obvious better alternative?"

        scene tr-e1s17-14 with dissolve
        hide e1s17-tracy_blink2
        tr "Uh, no?"

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        mc "Exactly the reason I moved."

        scene tr-e1s17-14 with dissolve
        hide e1s17-tracy_blink2
        tr "That's understandable then."

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        menu:
            "Make a joke":
                call extrovert_affinity_check from _call_extrovert_affinity_check_16
                call color_check from _call_color_check_32
                mc "Understandable have a nice day."

                scene tr-e1s17-14 with dissolve
                hide e1s17-tracy_blink2
                tr "What?"

                scene tr-e1s17-13 with dissolve
                show e1s17-tracy_blink2
                mc "Nothing."

            "Don't make it":
                call color_check from _call_color_check_33
                mc "..."

        scene tr-e1s17-17 with dissolve
        hide e1s17-tracy_blink2
        tr "Hey, you're coming to Eddy's tonight, right?"

        scene tr-e1s17-15 with dissolve
        tr "I assume that Jon already told you what's happening."

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        mc "Yeah, he told me yesterday."
        mc "Everyone's talking about how wild it's going to be and stuff like that."

        scene tr-e1s17-16 with dissolve
        hide e1s17-tracy_blink2
        tr "Of course! They probably invest the most in that party."

        scene tr-e1s17-23 with dissolve
        show e1s17-tracy_blink3
        mc "But I don't get it, how can they afford to organize such parties?"

        scene tr-e1s17-14 with dissolve
        hide e1s17-tracy_blink3
        tr "Well, obviously you have to buy massively overpriced drinks."

        scene tr-e1s17-15 with dissolve
        tr "But rumor has it that there's someone very rich in their planning team."

        scene tr-e1s17-14 with dissolve
        tr "Who's contributing a lot to the party's budget."

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        mc "That's crazy!"

        scene tr-e1s17-16 with dissolve
        hide e1s17-tracy_blink2
        tr "Not as crazy as the things we're gonna bring."

        scene tr-e1s17-23 with dissolve
        show e1s17-tracy_blink3
        mc "Haha, what things?"

        scene tr-e1s17-17 with dissolve
        hide e1s17-tracy_blink3
        tr "Aren't you a little impatient?"

        scene tr-e1s17-16 with dissolve
        tr "You'll see at the party."

        scene tr-e1s17-23 with dissolve
        show e1s17-tracy_blink3
        mc "Come on, you can't tease me and then give me nothing."

        scene tr-e1s17-14 with dissolve
        hide e1s17-tracy_blink3
        tr "Hmm... I don't think I trust you well enough to show it."

        scene tr-e1s17-13 with dissolve
        show e1s17-tracy_blink2
        mc "But you trusted me enough to drink a shot from your tits?"

        scene tr-e1s17-16 with dissolve
        hide e1s17-tracy_blink2
        tr "Haha, shut up!"
        tr "That was different, this thing doesn't compare."

        scene tr-e1s17-17 with dissolve
        tr "Although, that was pretty hot I gotta admit."

        scene tr-e1s17-23 with dissolve
        show e1s17-tracy_blink3
        mc "*I think I like where this is going.*"

        scene tr-e1s17-18 with dissolve
        hide e1s17-tracy_blink3
        menu:
            "Kiss her":
                stop music fadeout 2.0
                $ tracy_trust += 1

                play music blues_of_t
                scene tr-e1s17_kiss with dissolve
                pause

                scene tr-e1s17_touch with dissolve
                pause

                scene tr-e1s17_kiss with dissolve
                pause

                scene tr-e1s17-20 with dissolve
                tr "[mc], we should stop."

                scene tr-e1s17-21 with dissolve
                show e1s17-tracy_blink4
                mc "Why?"

                scene tr-e1s17-22 with dissolve
                hide e1s17-tracy_blink4
                tr "My roommate is supposed to be here any minute now."

                scene tr-e1s17-20 with dissolve
                tr "Find me at the party and we'll talk, alright?"

                scene tr-e1s17-21 with dissolve
                show e1s17-tracy_blink4
                mc "Sure."
                mc "I'll go ahead and get ready then."

                scene tr-e1s17-20 with dissolve
                hide e1s17-tracy_blink4
                tr "Good, see you there."

            "Don't kiss her":

                scene tr-e1s17-14 with dissolve
                tr "Anyways, I'll get ready for the party."

                scene tr-e1s17-13 with dissolve
                show e1s17-tracy_blink2
                mc "Oh, right."
                mc "I forgot you girls need 10 hours to put some makeup on."

                scene tr-e1s17-14 with dissolve
                hide e1s17-tracy_blink2
                tr "Ha, ha, very funny."

                scene tr-e1s17-23 with dissolve
                show e1s17-tracy_blink3
                mc "I'll leave you to it then."

        scene tr-e1s17-19 with dissolve
        hide e1s17-tracy_blink3
        pause

    else:
        stop music fadeout 2.0
        scene black with Dissolve(2.0)

    # Sadie ####################################################################

    if e1s17_sadie == True:
        play music sun_sets_on_a_protagonist
        scene sd-e1s17-01 with dissolve
        sd "What was that all about?"

        scene sd-e1s17-02 with dissolve
        mc "What was what?"

        scene sd-e1s17-03 with dissolve
        sd "Are you kidding me?"

        if e1s6_mad == True:
            scene sd-e1s17-04 with dissolve
            sd "You almost gave it to [sp]!"
        else:
            scene sd-e1s17-04 with dissolve
            sd "You almost got into a fight with [sp]!"

        scene sd-e1s17-05 with dissolve
        show e1s17-sadie_blink1
        mc "Do you know the guy?"

        scene sd-e1s17-06 with dissolve
        hide e1s17-sadie_blink1
        sd "Hey, remember when we talked at the party about that guy I was seeing?"

        scene sd-e1s17-07 with dissolve
        mc "Yeah?"

        scene sd-e1s17-08 with dissolve
        sd "It's [sp]."

        scene sd-e1s17-09 with dissolve
        if affinity_spectrum > 0:
            mc "Oh shit!"
        else:
            mc "Really?"

        scene sd-e1s17-10 with dissolve
        sd "Yeah... that's why I gave him the look."

        scene sd-e1s17-11 with dissolve
        mc "So, then, what's happening between you two guys?"

        scene sd-e1s17-12 with dissolve
        sd "Nothing really, we got into a big argument and decided to break things off."

        scene sd-e1s17-13 with dissolve
        mc "Doesn't sound like nothing to me."

        scene sd-e1s17-14 with vpunch
        sd "Haha, shut up."

        stop music fadeout 2.0
        scene sd-e1s17-15 with dissolve
        sd "That guy is a prick."

        play music invisible_light
        scene sd-e1s17-16 with wipeleft
        pause

        scene sd-e1s17-17 with dissolve
        mc "..."

        scene sd-e1s17-18 with dissolve
        mc "So... how did you guys meet in the first place?"

        scene sd-e1s17-19 with dissolve
        sd "This place isn't that big, [mc]."

        scene sd-e1s17-20 with dissolve
        sd "You meet people at every turn."

        scene sd-e1s17-21 with dissolve
        sd "We happened to run into each other a couple of times and we started talking."

        scene sd-e1s17-22 with dissolve
        mc "I see."

        scene sd-e1s17-23 with dissolve
        sd "Wait here, I'll go and give this to [tr] and then we can go and grab some lunch."

        scene sd-e1s17-24 with dissolve
        show e1s17-sadie_blink2
        mc "Alright."

        stop music fadeout 2.0
        scene sd-e1s17-25 with dissolve
        hide e1s17-sadie_blink2
        pause

        play music dances_and_dames
        scene sd-e1s17-26 with dissolve
        pause

        scene sd-e1s17-27 with dissolve
        pause

        scene sd-e1s17-28 with dissolve
        mc "Hey [jd]!"

        scene sd-e1s17-29 with dissolve
        show e1s17-jordan_blink1
        mc "What's up man?"

        scene sd-e1s17-30 with dissolve
        hide e1s17-jordan_blink1
        jd "Hey [mc]! Sorry, I'm kind of in a hurry."

        scene sd-e1s17-29 with dissolve
        show e1s17-jordan_blink1
        mc "Hey, it's alright."
        mc "I just wanted to let you know that [ke] was looking for you."
        mc "He told me that he's waiting for you at Eddy's."

        scene sd-e1s17-31 with dissolve
        hide e1s17-jordan_blink1
        jd "Yeah, that's where I'm headed now."

        scene sd-e1s17-32 with dissolve
        jd "Thanks for letting me know [mc]."

        scene sd-e1s17-33 with dissolve
        show e1s17-jordan_blink2
        mc "Don't sweat it."

        scene sd-e1s17-34 with dissolve
        hide e1s17-jordan_blink2
        pause

        stop music fadeout 2.0
        scene sd-e1s17-26 with dissolve
        pause

        scene sd-e1s17-35 with dissolve
        pause

        scene sd-e1s17-37 with dissolve

        scene sd-e1s17-36 with dissolve
        sd "Done deal!"

        scene sd-e1s17-37 with dissolve
        show e1s17-sadie_blink3
        mc "How's her auditions going?"

        scene sd-e1s17-36 with dissolve
        hide e1s17-sadie_blink3
        sd "Oh, it's going perfect!"

        scene sd-e1s17-38 with dissolve
        sd "Hasn't even started yet."

        scene sd-e1s17-37 with dissolve
        show e1s17-sadie_blink3
        mc "Oh, wow."
        mc "For real?"

        scene sd-e1s17-36 with dissolve
        hide e1s17-sadie_blink3
        sd "Yeah, let's go."

        stop music fadeout 2.0
        scene sd-e1s17-39 with dissolve
        pause

        play music bloom
        $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
        scene sd-e1s17-40 with wipeleft
        show e1s17-sadie_blink4
        mc "Hey, can you tell me more about [sp]?"

        scene sd-e1s17-41 with dissolve
        hide e1s17-sadie_blink4
        sd "Why?"
        sd "Are you some kind of detective?"

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink5_serious
        show e1s17-sadie_eat_serious
        mc "Whoop, you caught me!"
        mc "Secret undercover agent."

        scene sd-e1s17-42 with dissolve
        hide e1s17-sadie_eat_serious
        hide e1s17-sadie_blink5_serious
        sd "You're so lame."

        scene sd-e1s17-43 with dissolve
        sd "There's not a lot about this guy that I know of."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink5_serious
        show e1s17-sadie_eat_serious
        mc "Come on!"
        mc "You guys have been really close."

        scene sd-e1s17-43 with dissolve
        hide e1s17-sadie_eat_serious
        hide e1s17-sadie_blink5_serious
        sd "I wouldn't exactly say 'really' close, but alright."

        scene sd-e1s17-45 with dissolve
        sd "He's very impulsive."

        scene sd-e1s17-46 with dissolve
        sd "Sometimes, it feels like you're talking to some 8-year-old child whose momma is refusing to buy him candy."

        scene sd-e1s17-47 with dissolve
        sd "He can be a real pain in the ass."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink5_serious
        show e1s17-sadie_eat_serious
        mc "Oh yeah, very surprising."
        mc "I {b}Totally{/b} didn't see him as an immature person."

        play sound punch
        scene sd-e1s17-48 with vpunch
        $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
        hide e1s17-sadie_eat_serious
        hide e1s17-sadie_blink5_serious
        sd "You're a sarcastic prick!"

        scene sd-e1s17-45 with dissolve
        sd "Anyways, he didn't really open up to me about anything."

        scene sd-e1s17-46 with dissolve
        sd "If you're looking for any past traumas or something like that I can't help you."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink4
        mc "I was just curious about the type of person he is."

        scene sd-e1s17-47 with dissolve
        hide e1s17-sadie_blink4
        sd "Well, I've heard some rumors of him dropping college once."

        scene sd-e1s17-45 with dissolve
        sd "But I don't really know about that, we weren't talking back then."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink4
        mc "Why would you say he decided to do that?"

        scene sd-e1s17-46 with dissolve
        sd "I don't know, maybe he just got bored..."

        scene sd-e1s17-47 with dissolve
        sd "...the same way he did with me."

        scene sd-e1s17-55 with dissolve
        sd "Who knows, [mc]?"
        sd "Why don't you talk to him about it if you're so curious?"

        scene sd-e1s17-56 with dissolve
        show e1s17-sadie_blink6
        show e1s17-sadie_blink6_1
        mc "Hey, look, I'm sorry, alright?"
        mc "I didn't want to touch a sensitive subject."
        mc "I'm done with the questions, let's just enjoy the meal, alright?"
        sd "..."
        mc "..."

        scene sd-e1s17-57 with dissolve
        hide e1s17-sadie_blink6
        hide e1s17-sadie_blink6_1
        sd "Hey, sorry for being so defensive."
        sd "It's not fair to take my frustrations out on you."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink4
        mc "It's okay, I'm not mad."

        scene sd-e1s17-46 with dissolve
        hide e1s17-sadie_blink4
        sd "It's like... you actually listen, you know?"

        scene sd-e1s17-58 with dissolve
        sd "I'm not really used to that."

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink4
        mc "Haha, I can do that, yeah."

        scene sd-e1s17-42 with dissolve
        hide e1s17-sadie_blink4
        sd "Thanks [mc], for helping me through this and all."

        scene sd-e1s17-59 with dissolve
        show e1s17-sadie_blink7
        mc "Hey, don't mention it."

        if affinity_spectrum > 0 and sadie_trust >= 2:
            $ sadie_trust += 1
            mc "You're gonna make it up to me in some way or another."

            scene sd-e1s17-42 with dissolve
            hide e1s17-sadie_blink7
            sd "Haha, so you're doing this just to get something in return?"

            scene sd-e1s17-59 with dissolve
            show e1s17-sadie_blink7
            mc "Innocent 'til proven guilty."

            play sound punch
            scene sd-e1s17-48 with vpunch
            $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
            hide e1s17-sadie_blink7
            sd "I hate you!"

        scene sd-e1s17-42 with dissolve
        hide e1s17-sadie_blink4
        sd "So, what's going on with you, dude?"

        scene sd-e1s17-60 with dissolve
        sd "I've talked so much about myself, I don't know shit about you."

        scene sd-e1s17-61 with dissolve
        sd "Have you got any lady or something going on for you?"

        scene sd-e1s17-59 with dissolve
        show e1s17-sadie_blink7
        mc "Hmm..."

        scene sd-e1s17-44 with dissolve
        show e1s17-sadie_blink5_smile
        show e1s17-sadie_eat_smile
        menu:
            "Cleo" if cleo_trust >= 2:
                $ e1s17_cleo_choice = True

                mc "Well, I've been talking to this girl I met a couple of days ago."
                mc "And I can say we're growing pretty close."

                scene sd-e1s17-62 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Interesting..."
                sd "Is she studying here as well?"

                scene sd-e1s17-44 with dissolve
                show e1s17-sadie_blink5_smile
                show e1s17-sadie_eat_smile
                mc "As a matter of fact, yeah."
                mc "Funny story is that we actually first met on the way here."

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Haha, really?"

                scene sd-e1s17-44 with dissolve
                show e1s17-sadie_blink5_smile
                show e1s17-sadie_eat_smile
                mc "We were on the same train, just a couple of seats apart."
                mc "But we didn't know we were both going to the same college."

                if e1s2_smile_back == True:
                    mc "We just smiled at each other and went on about our lives."
                else:
                    mc "She smiled to me but I didn't think too much of it... so I didn't smile back."

                mc "After a while, we met in a diner near here, she was the waitress."
                mc "And so, we talked for a bit and then we started hanging out."

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Haha, no way!"
                sd "What are the odds?"

                scene sd-e1s17-44 with dissolve
                show e1s17-sadie_blink5_smile
                show e1s17-sadie_eat_smile
                mc "I know right?"
                mc "We were both pretty surprised about it as well."

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Haha, wow!"

                scene sd-e1s17-60 with dissolve
                sd "That's a story to tell your kids on 'How I met your mother'."

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7
                mc "Haha, you're right."

                scene sd-e1s17-60 with dissolve
                hide e1s17-sadie_blink7
                sd "Well, I'm happy you're making friends, [mc]."

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7
                mc "Thanks, [sd]!"
                mc "This means a lot to me."

            "Sadie" if sadie_trust >= 3:
                $ sadie_trust += 1

                mc "Well, other than you, I haven't really had the chance to talk to any other women since I got here."

                scene sd-e1s17-62 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Interesting..."
                sd "Not a single soul?"

                scene sd-e1s17-44 with dissolve
                show e1s17-sadie_blink5_smile
                show e1s17-sadie_eat_smile
                mc "Well, of course I've talked to some girls here and there..."
                mc "But I haven't really gotten the chance to get close to anyone."

                scene sd-e1s17-62 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "I see."

                scene sd-e1s17-42 with dissolve
                sd "Well, you can consider me your friend, [mc]."

                scene sd-e1s17-43 with dissolve
                sd "Of course, there's [jn] and all..."

                scene sd-e1s17-46 with dissolve
                sd "...but you need the opposite sex in your life as well."

                scene sd-e1s17-40 with dissolve
                show e1s17-sadie_blink4
                mc "Yup, you're right."

                scene sd-e1s17-60 with dissolve
                hide e1s17-sadie_blink4
                sd "You seem like a pretty cool guy."

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7

                if affinity_spectrum < 0:
                    mc "Thanks [sd]!"

                if affinity_spectrum >= 0:
                    mc "Well, I am!"

                    scene sd-e1s17-48 with vpunch
                    hide e1s17-sadie_blink7
                    sd "Haha, I like you already!"

                scene sd-e1s17-59 with dissolve

                if affinity_spectrum >= 0:
                    show e1s17-sadie_blink7
                mc "It feels good having someone like you to talk to."

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink7
                sd "I'm happy you think that [mc]."

                scene sd-e1s17-43 with dissolve
                sd "But don't get too attached though..."

                scene sd-e1s17-46 with dissolve
                sd "I've just ended things with [sp] and I need a little bit of time to process things."

                scene sd-e1s17-40 with dissolve
                show e1s17-sadie_blink4
                mc "Hey, I understand!"
                mc "Don't worry."

            "No one":
                mc "Well, to be fair, I haven't really had the chance to get close to any women since I got here."

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Haha, really?"

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7
                mc "Hey, it's only been a couple of days, give me some time."

                scene sd-e1s17-60 with dissolve
                hide e1s17-sadie_blink7
                sd "Haha, don't worry dude, I'm not judging."
                sd "I'm just pulling your leg."

                scene sd-e1s17-46 with dissolve
                sd "Some of them might find you disgusting for talking to multiple girls at once."

                scene sd-e1s17-43 with dissolve
                sd "So, my advice to you would be to be careful about whoever you choose to be with."

                scene sd-e1s17-46 with dissolve
                sd "If you're planning on talking to multiple girls, at least expect them to be okay with it."

                scene sd-e1s17-40 with dissolve
                show e1s17-sadie_blink4
                mc "Do you find it disgusting?"

                scene sd-e1s17-60 with dissolve
                hide e1s17-sadie_blink4
                sd "Haha, I'm not telling you that."

                scene sd-e1s17-44 with dissolve
                show e1s17-sadie_blink5_smile
                show e1s17-sadie_eat_smile
                mc "You're such a tease."
                mc "Why would you tell me this in the first place?"

                scene sd-e1s17-42 with dissolve
                hide e1s17-sadie_blink5_smile
                hide e1s17-sadie_eat_smile
                sd "Well, I like you [mc]."

                scene sd-e1s17-62 with dissolve
                sd "You also seem like a smart guy so you'll figure it out."

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7
                mc "Oh so you're just gonna leave me with this?"

                scene sd-e1s17-62 with dissolve
                hide e1s17-sadie_blink7
                sd "You guessed it!"

                scene sd-e1s17-59 with dissolve
                show e1s17-sadie_blink7
                mc "Damn..."

        scene sd-e1s17-63 with dissolve
        hide e1s17-sadie_blink7
        hide e1s17-sadie_blink4
        sd "Oh shit, it's getting pretty late."

        scene sd-e1s17-46 with dissolve
        sd "Hey, you do know about the party at Eddy's happening tonight, right?"

        scene sd-e1s17-40 with dissolve
        show e1s17-sadie_blink4
        mc "Yup, [jon] filled me in with the details and all."

        scene sd-e1s17-60 with dissolve
        sd "That's awesome."

        if sadie_trust >= 2:
            scene sd-e1s17-46 with dissolve
            sd "It would have been a bummer if you couldn't attend it."

            scene sd-e1s17-43 with dissolve
            sd "Anyways..."

        scene sd-e1s17-43 with dissolve
        sd "I need to get prepared for it and all."

        scene sd-e1s17-42 with dissolve
        sd "Thanks for the meal, [mc]."

        scene sd-e1s17-59 with dissolve
        show e1s17-sadie_blink7
        mc "Don't mention it."
        mc "See you [sd]!"

        scene sd-e1s17-60 with dissolve
        sd "Bye [mc]!"

        scene sd-e1s17-64 with dissolve
        pause

    # Olivia ###################################################################
    if e1s17_olivia == True:
        play music laurel_breeze
        scene ov-e1s17-01 with wipeleft
        pause

        play sound phone_buzz
        scene ov-e1s17-02 with dissolve
        pause

        scene ov-e1s17-03 with dissolve
        pause

        scene ov-e1s17-04 with dissolve
        pause

        scene ov-e1s17-05 with dissolve
        pause

        scene ov-e1s17-06 with dissolve
        unknown "[mc], hi!"

        scene ov-e1s17-07-1 with dissolve
        show e1s17_pedestrian_anim
        show e1s17_taxi_anim
        show ov-e1s17-07 behind e1s17_pedestrian_anim, e1s17_taxi_anim
        show e1s17-olivia_blink1
        mc "Oh, hi [ov]!"

        hide e1s17-olivia_blink1
        show ov-e1s17-08 behind e1s17_pedestrian_anim, e1s17_taxi_anim with dissolve
        hide ov-e1s17-07
        ov "Going to the gym?"

        show ov-e1s17-07 behind e1s17_pedestrian_anim, e1s17_taxi_anim with dissolve
        show e1s17-olivia_blink1
        hide ov-e1s17-08
        mc "Yeah, I thought I'd stay consistent now that I'm here."

        hide e1s17-olivia_blink1
        show ov-e1s17-08 behind e1s17_pedestrian_anim, e1s17_taxi_anim with dissolve
        hide ov-e1s17-07
        ov "Great."

        show ov-e1s17-09 behind e1s17_pedestrian_anim, e1s17_taxi_anim with dissolve
        hide ov-e1s17-08
        ov "Wanna join me, then?"

        show ov-e1s17-07 behind e1s17_pedestrian_anim, e1s17_taxi_anim with dissolve
        show e1s17-olivia_blink1
        hide ov-e1s17-09
        mc "Sure, let's go."

        stop music fadeout 2.0
        hide e1s17-olivia_blink1
        scene ov-e1s17-10 with dissolve
        hide ov-e1s17-07
        hide e1s17_pedestrian_anim
        hide e1s17_taxi_anim
        pause

        play music border_blaster
        scene ov-e1s17-11 with wipeleft
        pause

        scene ov-e1s17-12 with dissolve
        mc "*Hmm... I think this will be a good time to ask her about [sp].*"

        scene ov-e1s17-13 with dissolve
        menu:
            "Ask her":
                $ e1s17_ov_ask = True
                call extrovert_affinity_check from _call_extrovert_affinity_check_17
                call color_check from _call_color_check_34

                scene ov-e1s17-14 with dissolve
                pause

                scene ov-e1s17-15 with dissolve
                mc "Hey, random question, how long have you been going to this gym?"

                scene ov-e1s17-16 with dissolve
                ov "For 2 years maybe, why do you ask?"

                scene ov-e1s17-17 with dissolve
                mc "Do you happen to know a guy named [sp] that goes to this gym as well?"

                scene ov-e1s17-19 with dissolve
                ov "Yeah... he goes to UPL."

                scene ov-e1s17-20 with dissolve
                ov "In fact, we were in the same class until he skipped school for the better part of the year."

                scene ov-e1s17-19 with dissolve
                ov "So he had to repeat the year afterwards."

                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "Do you know what happened?"

                scene ov-e1s17-19 with dissolve
                hide e1s17-olivia_blink2
                ov "Not really, he keeps his private life as private as he can."

                scene ov-e1s17-21 with dissolve
                ov "But most people assume that he just didn't care and stopped turning up to classes."

                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "That's pretty weird."

                scene ov-e1s17-19 with dissolve
                hide e1s17-olivia_blink2
                ov "Yeah, I don't bite that either but who cares anyways."

                scene ov-e1s17-21 with dissolve
                ov "It's just [sp] after all, it's not like he's the most interesting guy out there."

                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "Haha, I guess you're right."

                scene ov-e1s17-22 with dissolve
                hide e1s17-olivia_blink2
                ov "Has he been causing you problems or why do you ask?"

                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "Well, we got into an argument or two but nothing too serious."

                scene ov-e1s17-19 with dissolve
                hide e1s17-olivia_blink2
                ov "Yeah, he has a habit of getting into fights with freshmen."

                scene ov-e1s17-22 with dissolve
                ov "It's his way of 'asserting' dominance."

                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "That ain't gonna work with me though."

                scene ov-e1s17-23 with dissolve
                hide e1s17-olivia_blink2
                ov "Haha, I can tell."

                scene ov-e1s17-24 with dissolve
                ov "Most freshies would just try their best to avoid him."

                scene ov-e1s17-19 with dissolve
                ov "It seems to me like you're trying to dig him up more than avoid him."

                scene ov-e1s17-25 with dissolve
                show e1s17-olivia_blink3
                mc "I'm not scared of him."
                mc "I've been in a couple of fights in my life."

                scene ov-e1s17-24 with dissolve
                hide e1s17-olivia_blink3
                ov "It's good that you're standing your ground."

                scene ov-e1s17-21 with dissolve
                ov "I never liked bullies, it's like they never grow up."

                stop music fadeout 2.0
                scene ov-e1s17-18 with dissolve
                show e1s17-olivia_blink2
                mc "Yeah..."

            "Don't ask":
                call introvert_affinity_check from _call_introvert_affinity_check_14
                call color_check from _call_color_check_35

                stop music fadeout 2.0
                mc "*On the other hand, maybe getting involved isn't the best idea.*"

        play music tidalwave
        scene ov-e1s17-26 with dissolve
        ov "So, [mc], which part of the body is your favourite to train?"

        scene ov-e1s17-27 with dissolve
        mc "I don't think I have a favourite part."

        scene ov-e1s17-28 with dissolve
        ov "Oh, come on! There's gotta be something!"
        ov "Everyone has a favourite."

        scene ov-e1s17-41 with dissolve
        menu:
            "Make a joke" if affinity_spectrum > 0:
                call extrovert_affinity_check from _call_extrovert_affinity_check_18
                call color_check from _call_color_check_36

                scene ov-e1s17-27 with dissolve
                mc "I mostly like to train my D."

                scene ov-e1s17-31 with dissolve
                ov "Haha, gross!"
                ov "I meant in the gym, dummy."

                scene ov-e1s17-32 with dissolve
                mc "You can't train that in the gym?"
                mc "I've been scammed..."
                ov "Oh my gosh..."

                scene ov-e1s17-29 with dissolve
                mc "Okay but for real, I think the lats are my favourite."

            "Be serious" if affinity_spectrum <= 0:
                call introvert_affinity_check from _call_introvert_affinity_check_15
                call color_check from _call_color_check_37

                scene ov-e1s17-29 with dissolve
                mc "Probably the lats are my favourite muscles to train."

        scene ov-e1s17-30 with dissolve
        ov "Ok, so latissimus dorsi it is."

        scene ov-e1s17-33 with dissolve
        mc "Lati what?"

        scene ov-e1s17-35 with dissolve
        ov "Latissimus dorsi."

        scene ov-e1s17-34 with dissolve
        show e1s17-olivia_blink4
        mc "Huh?"

        scene ov-e1s17-36 with dissolve
        hide e1s17-olivia_blink4
        ov "Haha, that's the 'lats'."

        scene ov-e1s17-35 with dissolve
        ov "'Lats' is short for Latissimus dorsi."

        scene ov-e1s17-34 with dissolve
        show e1s17-olivia_blink4
        mc "Oh, haha!"
        mc "I didn't even know that."

        scene ov-e1s17-35 with dissolve
        hide e1s17-olivia_blink4
        ov "Have you never wondered where the term 'lats' comes from?"

        scene ov-e1s17-37 with dissolve
        mc "Well, assuming that they're positioned on the laterals of your back..."

        scene ov-e1s17-34 with dissolve
        show e1s17-olivia_blink4
        mc "...I thought that's where they got their name from."

        scene ov-e1s17-35 with dissolve
        hide e1s17-olivia_blink4
        ov "That's what everyone calls them but the official scientific name is latissimus dorsi."

        scene ov-e1s17-34 with dissolve
        show e1s17-olivia_blink4
        mc "No wonder you're trying to teach people about the gym..."

        scene ov-e1s17-39 with dissolve
        pause

        scene ov-e1s17-38 with dissolve
        mc "Also, about that social media thing, how's it going on for you?"

        scene ov-e1s17-40 with dissolve
        ov "Less talking, more working."

        scene ov-e1s17-42 with dissolve
        mc "Oh, sorry!"

        scene ov-e1s17-40 with dissolve
        ov "To be fair, it's going fairly decent."
        ov "I mean, I've been getting some traction but nothing too serious."
        ov "I'm not focused on that at the moment, it's more like a side hustle."

        scene ov-e1s17-42 with dissolve
        mc "How's my form coach?"

        scene ov-e1s17-43 with dissolve
        ov "It's good, keep it up."

        scene ov-e1s17-44 with dissolve
        pause

        scene ov-e1s17-45 with dissolve
        mc "Haha, what are you doing?"

        scene ov-e1s17-46 with dissolve
        ov "Stimulating the muscle by touching it."

        scene ov-e1s17-44 with dissolve
        mc "It's tickling!"

        scene ov-e1s17-47 with dissolve
        mc "Alright, that's my final set for this exercise."

        scene ov-e1s17-35 with dissolve
        ov "Great."

        scene ov-e1s17-34 with dissolve
        show e1s17-olivia_blink4
        mc "What's the next exercise?"

        scene ov-e1s17-35 with dissolve
        hide e1s17-olivia_blink4
        ov "Let's go with some squats."

        scene ov-e1s17-48 with dissolve
        mc "Do you need a spot?"

        scene ov-e1s17-50 with dissolve
        ov "Yeah!"

        scene ov-e1s17-51 with dissolve
        ov "I usually go lighter with this but today I'll go a little heavier."

        scene ov-e1s17-50 with dissolve
        ov "You can help me get it up in case I don't get it."

        scene ov-e1s17-49 with dissolve
        show e1s17-olivia_blink5
        if affinity_spectrum > 0:
            mc "*Get it up, huh?*"
        mc "Alright."

        scene ov-e1s17-52 with dissolve
        hide e1s17-olivia_blink5
        pause

        scene ov-e1s17_squat1 with dissolve
        pause

        scene ov-e1s17_squat2 with dissolve
        ov "How's my form 'coach'."
        mc "Haha, don't turn this up on me."

        scene ov-e1s17-53 with dissolve
        mc "You're doing good."

        scene ov-e1s17_squat1 with dissolve
        pause

        scene ov-e1s17-54 with dissolve
        mc "Come on! Push!"

        scene ov-e1s17-55 with dissolve
        mc "You got it!"

        scene ov-e1s17-56 with dissolve
        mc "*Oh shit!*"

        play sound weights
        scene ov-e1s17-57 with vpunch
        mc "That's it!"
        mc "Well done!"

        scene ov-e1s17-59 with dissolve
        ov "Look who's teaching now."

        scene ov-e1s17-58 with dissolve
        show e1s17-olivia_blink6
        mc "Haha!"

        scene ov-e1s17-60 with dissolve
        hide e1s17-olivia_blink6
        ov "That was really heavy for me."

        scene ov-e1s17-58 with dissolve
        show e1s17-olivia_blink6
        mc "Yeah! I can tell."

        scene ov-e1s17-60 with dissolve
        hide e1s17-olivia_blink6
        ov "We'll do 3 more sets and then we're good to go."

        scene ov-e1s17-58 with dissolve
        show e1s17-olivia_blink6
        mc "Alright!"

        stop music fadeout 2.0
        scene black with Dissolve(2.0)

        scene ov-e1s17-61 with Dissolve(2.0)
        pause

        play music crazy_glue
        scene ov-e1s17-62 with dissolve
        show e1s17-olivia_blink7
        mc "Damn, I'm wasted."
        mc "I'll probably be so sore tomorrow."

        scene ov-e1s17-63 with dissolve
        hide e1s17-olivia_blink7
        ov "Tell me about it."

        scene ov-e1s17-64 with dissolve
        ov "My legs are shaking."

        scene ov-e1s17-65 with dissolve
        ov "I'd be extremely surprised if I manage not to fall today."

        scene ov-e1s17-62 with dissolve
        show e1s17-olivia_blink7
        mc "I probably won't be able to get my hands up in the air anymore."

        scene ov-e1s17-66 with dissolve
        hide e1s17-olivia_blink7
        show e1s17-olivia_blink8
        mc "You know what? A cold shower could fix every single one of your problems."

        scene ov-e1s17-67 with dissolve
        hide e1s17-olivia_blink8
        ov "Couldn't agree more."

        scene ov-e1s17-68 with dissolve
        pause

        stop music
        play sound woosh
        scene ov-e1s17-69 with vpunch
        pause

        scene ov-e1s17-70 with dissolve
        pause

        play sound punch
        scene ov-e1s17-76 with vpunch
        pause

        play music hey_ruth
        scene ov-e1s17-71 with dissolve
        show ov_e1s17-mc_blink1
        ov "Uhh, hi?"

        scene ov-e1s17-72 with dissolve
        hide ov_e1s17-mc_blink1
        show e1s17-olivia_blink9
        mc "Hi, haha!"

        scene ov-e1s17-73 with dissolve
        hide e1s17-olivia_blink9
        mc "*Holy shit.*"

        scene ov-e1s17-72 with dissolve
        show e1s17-olivia_blink9
        menu:
            "Kiss her":
                $ olivia_trust += 1
                $ e1s17_ovkiss = True

                scene ov-e1s17_kiss1 with dissolve
                hide e1s17-olivia_blink9
                pause

                scene ov-e1s17_kiss2 with dissolve
                pause

                scene ov-e1s17_kiss1 with dissolve
                pause

                scene ov-e1s17-74 with dissolve
                show ov_e1s17-mc_blink2
                ov "Oh... I'm so sorry."

                scene ov-e1s17-75 with dissolve
                hide ov_e1s17-mc_blink2
                show e1s17-olivia_blink10
                mc "Haha, don't worry!"

                scene ov-e1s17-74 with dissolve
                hide e1s17-olivia_blink10
                show ov_e1s17-mc_blink2
                ov "Heh..."
                ov "I'll get up now."

            "Don't kiss her":
                scene ov-e1s17-71 with dissolve
                hide e1s17-olivia_blink9
                show ov_e1s17-mc_blink1
                ov "Haha, I'm so sorry!"
                ov "I'll get up."

        if e1s17_ovkiss == True:

            scene ov-e1s17-78 with dissolve
            hide ov_e1s17-mc_blink1
            hide ov_e1s17-mc_blink2
            ov "Haha, I told you I'm gonna be surprised if I don't fall over today."

            scene ov-e1s17-77 with dissolve
            show e1s17-olivia_blink11
            mc "It's understandable, don't worry."
            mc "I really liked it."

            scene ov-e1s17-92 with dissolve
            ov "Oh well..."

            scene ov-e1s17-78 with dissolve
            ov "I liked it too, [mc]!"

            scene ov-e1s17-77 with dissolve
            show e1s17-olivia_blink11
            mc "I'm happy you did, [ov]."

            scene ov-e1s17-92 with dissolve
            ov "Heh..."

            scene ov-e1s17-77 with dissolve
            show e1s17-olivia_blink11
            mc "Come on, let's go!"

            stop music fadeout 2.0
            scene ov-e1s17-79 with dissolve
            hide e1s17-olivia_blink11
            pause

        else:

            scene ov-e1s17-84 with dissolve
            hide ov_e1s17-mc_blink1
            hide ov_e1s17-mc_blink2
            ov "Haha, I told you I'm gonna be surprised if I don't fall over today."

            scene ov-e1s17-85 with dissolve
            show e1s17-olivia_blink14
            mc "It's understandable, don't worry."
            mc "Come on, let's go!"

            stop music fadeout 2.0
            scene ov-e1s17-83 with dissolve
            hide e1s17-olivia_blink14
            pause

        play music bloom
        scene ov-e1s17-80 with wipeleft

        scene ov-e1s17-81 with dissolve
        ov "So... I guess I'll be seeing you around?"

        scene ov-e1s17-80 with dissolve
        show e1s17-olivia_blink12
        mc "Yeah."
        mc "Hey, do you wanna give me your phone number?"
        mc "I liked working out with you today so maybe we could do it again sometime?"

        scene ov-e1s17-82 with dissolve
        hide e1s17-olivia_blink12
        ov "Sure, give me your phone."

        scene ov-e1s17-86 with dissolve
        pause

        scene ov-e1s17-87 with dissolve
        pause

        scene ov-e1s17-88 with dissolve
        ov "Here."

        scene ov-e1s17-89 with dissolve
        show e1s17-olivia_blink13
        mc "Thanks!"

        scene ov-e1s17-90 with dissolve
        hide e1s17-olivia_blink13
        ov "Alright, I'll be on my way."
        ov "Bye [mc]!"

        scene ov-e1s17-89 with dissolve
        show e1s17-olivia_blink13
        mc "Bye [ov], take care!"

        scene ov-e1s17-91 with dissolve
        hide e1s17-olivia_blink13
        pause

    jump e1s18
return
