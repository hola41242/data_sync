
# Freeroam Screens #############################################################

# Freeroam #3 Screens ##########################################################

screen e1f3_room34_default():
    $ renpy.random.shuffle(e1f3_tracks)

    add "e1f3-01"
    modal True

    # Clickables ###############################################################

    if e1f3_nate == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/room34/nate_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/room34/nate_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f3_nate")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f3_nate")

    # To Right #################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/room34/from_default_to_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/room34/from_default_to_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_room34_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_room34_right")

    # To Hallway ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/room34/from_room34_to_hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/room34/from_room34_to_hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_hallway_1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_hallway_1")

    if persistent.sc_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/room34/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/room34/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_2_unlocked", True), SetVariable("persistent.e1f3_collected_p", persistent.e1f3_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett2", True), Function(update_scarlett_list)]

screen e1f3_room34_right():
    $ renpy.random.shuffle(e1f3_tracks)

    add "e1f3-02"
    modal True

    # To Default ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/room34/right/from_right_to_default_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/room34/right/from_right_to_default_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_room34_default")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_room34_default")

    if persistent.sc_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/room34/right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/room34/right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_3_unlocked", True), SetVariable("persistent.e1f3_collected_p", persistent.e1f3_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett3", True), Function(update_scarlett_list)]

screen e1f3_hallway_1():
    $ renpy.random.shuffle(e1f3_tracks)

    add "e1f3-03"
    modal True

    # Clickables ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/from_hallway_to_room34_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/from_hallway_to_room34_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_room34_default")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_room34_default")

    if e1f3_roman_ken == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/roman_ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/roman_ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f3_roman_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f3_roman_ken")

    if e1f3_raven == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/raven_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/raven_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f3_raven")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f3_raven")

    if e1f3_raven == True and e1f3_rk_first == True and e1f3_rk_second == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/roman_ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/roman_ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f3_rk_second")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f3_rk_second")

    if persistent.tr_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/magazine_1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/magazine_1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_2_unlocked", True), SetVariable("persistent.e1f3_collected_p", persistent.e1f3_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy2", True), Function(update_tracy_list)]

    # In front #################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/from_1_to_2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/from_1_to_2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_hallway_2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_hallway_2")

    # Exit #####################################################################
    if e1f3_nate == True and e1f3_raven == True and e1f3_roman_ken == True and e1f3_eavesdrop == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/from_hallway_to_exit_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/from_hallway_to_exit_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f3_hallway_exit")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f3_hallway_exit")

screen e1f3_hallway_2():
    $ renpy.random.shuffle(e1f3_tracks)

    add "e1f3-04"
    modal True

    # In front #################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/from_2_to_3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/from_2_to_3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_hallway_3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_hallway_3")

    # To back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/from_2_to_1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/from_2_to_1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_hallway_1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_hallway_1")

    if e1f3_money == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e1f3_money", True)]

screen e1f3_hallway_3():
    $ renpy.random.shuffle(e1f3_tracks)

    add "e1f3-05"
    modal True
    # Clickables ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/hallway_3_rightdoor_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/hallway_3_rightdoor_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "hallway_3_rightdoor")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("hallway_3_rightdoor")

    if persistent.sd_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam3/hallway/magazine_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam3/hallway/magazine_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_2_unlocked", True), SetVariable("persistent.e1f3_collected_p", persistent.e1f3_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie2", True), Function(update_sadie_list)]

    # To back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam3/hallway/from_3_to_2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam3/hallway/from_3_to_2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f3_hallway_2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f3_hallway_2")
