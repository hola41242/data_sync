
# Scene 7 - A familiar face ####################################################

label e1s7:

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)

    scene e1s7-01 with Dissolve(2.0)
    pause

    scene e1s7-02 with dissolve
    jn "Holy... there's so many 50's paintings."
    jn "I've never seen that many before!"
    jn "It's insane!"

    scene e1s7-03 with dissolve
    pause

    scene e1s7-04 with dissolve
    mc "*There's something weird going on.*"
    mc "*Why was [jon] siding with those guys?*"
    mc "*Usually, he has a shorter fuse than me...*"
    mc "*He would've beat the hell out of those guys if the circumstances were different!*"
    mc "*Does he know them personally?*"
    mc "*That would explain why he wouldn't let me talk to them.*"
    mc "*But still it doesn't make a lot of sense.*"
    mc "*I wonder if [ov] knows anything about them.*"
    mc "*Since they seem to go to the same gym, she probably does know something about them!*"
    play music bloom
    unknown "Hi guys!"

    scene e1s7-05 with dissolve
    unknown "What can I get you?"

    scene e1s7-06 with dissolve
    pause

    scene e1s7-07 with dissolve
    show e1s7_cleo_blink1
    if affinity_spectrum < 0 and cleo_trust == 1:
        mc "Hi, I'd like to get a-"
        mc "*Is that...?*"
        mc "*Yeah it is!*"
        mc "I... uh-"
        mc "I'd like to order a cheeseburger with french fries and a large coke please!"
        jn "And I'll have 2 tacos with a diet coke."

        scene e1s7-05 with dissolve
        hide e1s7_cleo_blink1
        unknown "Alright!"
        unknown "Coming right up!"

    if affinity_spectrum > 0 and cleo_trust == 1:
        mc "Hi, I'd like to get a-"
        mc "*Is that...?*"
        mc "*Yeah it is!*"
        mc "I'd like to order a cheeseburger with french fries and a large coke!"
        jn "And I'll have 2 tacos with a diet coke."

        scene e1s7-05 with dissolve
        hide e1s7_cleo_blink1
        unknown "Alright!"
        unknown "Coming right up!"

    if cleo_trust == 0:
        mc "Hi!"
        mc "I'd like to get a large cheeseburger with french fries and a large coke!"
        jn "And I'll have 2 tacos with a diet coke."

        scene e1s7-05 with dissolve
        hide e1s7_cleo_blink1
        unknown "Alright!"
        unknown "Coming right up!"

    scene e1s7-08 with dissolve
    pause

    scene e1s7-09 with dissolve
    jn "Cute girl, huh?"

    if cleo_trust == 1:
        scene e1s7-11 with dissolve
        mc "Yeah!"

    if cleo_trust == 0:
        scene e1s7-10 with dissolve
        mc "She's alright!"

    show e1s7-13 with dissolve
    show e1s7_jon_blink1
    mc "So..."
    mc "Shall we address the elephant in the room?"

    scene e1s7-12 with dissolve
    hide e1s7_jon_blink1
    jn "What are you talking about?"

    scene e1s7-13 with dissolve
    show e1s7_jon_blink1
    mc "What was that about at the gym?"
    mc "Who are those guys?"

    scene e1s7-12 with dissolve
    hide e1s7_jon_blink1
    jn "Oh so that's what's been bugging you..."
    jn "They're just some assholes who are picking on everyone new they see."
    jn "I've had some problems with them in the past but I don't know a whole lot more about them."

    scene e1s7-13 with dissolve
    show e1s7_jon_blink1
    mc "So why wouldn't you let me talk to them?"

    scene e1s7-12 with dissolve
    hide e1s7_jon_blink1
    jn "Well, the thing is that I don't want you to get involved with guys like that."
    jn "They're mostly just spoiled brats whose parents are highly influential and could realistically get them out of trouble at any given time."
    jn "They're not your average Joe with whom you would resolve your problems by just talking..."
    jn "...And you shouldn't risk your life just for some stupid bump."
    jn "I know it sucks but sometimes life just goes like that!"

    scene e1s7-13 with dissolve
    show e1s7_jon_blink1
    mc "As much as I hate to admit it, you're right!"
    mc "I still think that I should have at least tried talking to them."
    mc "Standing up for yourself means that bullies won't pick you as an easy target."
    mc "And I'm not one that would allow bullies to mess with me."

    scene e1s7-12 with dissolve
    hide e1s7_jon_blink1
    jn "Next time bud, next time!"

    scene e1s7-14 with dissolve
    pause

    scene e1s7-15 with dissolve
    unknown "Here's your order!"
    menu:
        "Check her out":
            scene e1s7-16 with dissolve
            $ cleo_trust -= 1
            if affinity_spectrum < 0:
                pause
            if affinity_spectrum > 0:
                mc "*Nice!*"
        "Don't risk it":
            pass

    scene e1s7-17 with dissolve
    pause

    scene e1s7-18 with dissolve
    unknown "Let me know if you need anything else!"

    scene e1s7-19 with dissolve
    pause

    scene e1s7-20 with dissolve
    pause

    scene e1s7-21 with dissolve
    pause

    scene e1s7-22 with dissolve
    pause

    scene e1s7-23 with dissolve
    mc "I'm gonna go and take a piss."
    mc "Be right back!"

    scene e1s7-24 with dissolve
    pause

    play sound phone_buzz
    scene e1s7-25 with dissolve
    pause

    stop sound fadeout 1.0

    scene e1s7-26 with dissolve
    $renpy.sound.play("audio/sfx/peeing.ogg", loop=True)
    pause
    play sound pants_zip
    pause

    scene e1s7-27 with dissolve
    pause

    $renpy.sound.play("audio/sfx/sink_water_loop.ogg", loop=True)
    scene e1s7-28 with dissolve
    pause

    play sound phone_buzz
    scene e1s7-29 with dissolve
    pause

    scene e1s7-30 with dissolve
    pause
    mc "Typical [jon]..."

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e1s7-31 with dissolve
    pause

    scene e1s7-32 with dissolve
    pause

    scene e1s7-33 with dissolve
    pause

    scene e1s7-34 with dissolve
    mc "Hi!"
    mc "I'd like the check please!"

    scene e1s7-35 with dissolve
    unknown "Sure!"

    scene e1s7-36 with dissolve
    pause

    scene e1s7-37 with dissolve
    unknown "So, your friend left huh?"

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "Yeah!"
    mc "He said that something came up."

    scene e1s7-44 with dissolve
    hide e1s7_cleo_blink2
    unknown "He did seem to be in a hurry!"

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "Yeah!"
    mc "..."
    mc "I'm [mc] by the way!"

    scene e1s7-37 with dissolve
    hide e1s7_cleo_blink2
    cl "[cl], nice to meet you!"

    scene e1s7-45 with dissolve
    cl "Have we met before?"
    cl "You look weirdly familiar..."

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "We saw each other yesterday on the train!"

    scene e1s7-44 with dissolve
    hide e1s7_cleo_blink2
    cl "Ohh..."
    scene e1s7-45 with dissolve
    cl "I remember now!"
    scene e1s7-37 with dissolve
    cl "So... what's up?"
    cl "Why did you come here?"

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "Well, for starters I got accepted to UPL!"
    mc "And because of that, my friend [jon] invited me to stay at his place for a couple of days until college starts!"

    scene e1s7-37 with dissolve
    hide e1s7_cleo_blink2
    cl "Underport Liberty, huh?"
    scene e1s7-44 with dissolve
    cl "I got into UPL as well but it wasn't really on my priority list."

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "How so?"

    scene e1s7-47 with dissolve
    hide e1s7_cleo_blink2
    cl "It's just that I don't really like this city that much..."
    scene e1s7-46 with dissolve
    cl "There's a lot of shit people here and to be honest I haven't made a lot of friends."

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "Oh, I'm sorry about that!"

    scene e1s7-45 with dissolve
    hide e1s7_cleo_blink2
    cl "Don't be! It's alright!"

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    mc "I used to live here a couple of years ago until my parents decided to move."
    mc "I also used to love this city so I wanted to come back here!"

    scene e1s7-44 with dissolve
    hide e1s7_cleo_blink2
    cl "Well, don't get me wrong!"
    cl "The city is indeed beautiful and all that..."
    scene e1s7-45 with dissolve
    cl "But, I guess it's just not for me!"

    scene e1s7-48 with dissolve
    "[cl]!!"
    "We've got new customers, stop chit chatting!"

    scene e1s7-44 with dissolve
    cl "Well, I gotta get back to it!"
    cl "I guess I'll be seeing you around!"
    scene e1s7-45 with dissolve
    cl "Also, your meal has already been paid for, I wanted to mess with you a bit!"

    scene e1s7-40 with dissolve
    mc "Oh, wow!"

    scene e1s7-39 with dissolve
    mc "I didn't even notice this is a clothes receipt!"

    scene e1s7-49 with dissolve
    cl "Haha!"

    scene e1s7-45 with dissolve
    cl "See ya!"

    scene e1s7-38 with dissolve
    show e1s7_cleo_blink2
    if cleo_trust == 1:
        mc "Yeah, sure!"
        mc "See ya!"

    if cleo_trust == 0:
        mc "Bye!"

    scene e1s7-41 with dissolve
    hide e1s7_cleo_blink2
    pause

    scene e1s7-43 with dissolve
    pause

    if cleo_trust == 1:
        scene e1s7-42 with dissolve
        pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    jump e1s8
return
