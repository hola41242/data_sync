# Variables ####################################################################

default e1f4_ken = False
default e1f4_tracy = False
default e1f4_right_door = False
default e1f4_sadie = False
default e1f4_money = False

default e1f4_hallway = False

# Freeroam Collected Photos #

default persistent.e1f4_collected_p = 0
default persistent.e1f4_collected_tp = 4

# Room 34 ######################################################################

label e1f4_room34_default:
    scene e1f4-01

    call screen e1f4_room34_default with dissolve
return

label e1f4_room34_left:
    scene e1f4-02

    call screen e1f4_room34_left with dissolve
return

label e1f4_room34_right:
    scene e1f4-03

    call screen e1f4_room34_right with dissolve
return

# Clickables ###############################################################

label e1f4_room34_bed:
    scene e1f4-02
    "*This is where I'm gonna sleep now...*"
    "*I gotta say, I'm not gonna miss [jon]'s couch.*"

    call screen e1f4_room34_left with dissolve
return

# Hallway ######################################################################

label e1f4_hallway_1:

    if e1f4_hallway == False:
        $ current_quests.remove("Leave the room.")
        $ current_quests.append("Talk to Ken.")
        $ current_quests.append("Explore the place.")

        $ e1f4_hallway = True

        if e1f4_ken == False and e1f4_right_door == False:
            scene e1f4-04 with Dissolve(0.5)
        if e1f4_ken == True and e1f4_right_door == False:
            scene e1f4-04_1 with Dissolve(0.5)
        if e1f4_ken == False and e1f4_right_door == True:
            scene e1f4-04_2 with Dissolve(0.5)
        if e1f4_ken == True and e1f4_right_door == True:
            scene e1f4-04_3 with Dissolve(0.5)
    else:
        if e1f4_ken == False and e1f4_right_door == False:
            scene e1f4-04
        if e1f4_ken == True and e1f4_right_door == False:
            scene e1f4-04_1
        if e1f4_ken == False and e1f4_right_door == True:
            scene e1f4-04_2
        if e1f4_ken == True and e1f4_right_door == True:
            scene e1f4-04_3

    call screen e1f4_hallway_1 with dissolve
return

label e1f4_hallway_2:
    if e1f4_tracy == False:

        scene tr_e1f4-01 with dissolve
        pause

        scene tr_e1f4-03 with dissolve
        tr "Hey [mc]!"

        scene tr_e1f4-04 with dissolve
        tr "What are you doing here?"

        scene tr_e1f4-02 with dissolve
        show e1f4-tracy_blink1
        mc "I just moved into my dorm."

        scene tr_e1f4-04 with dissolve
        hide e1f4-tracy_blink1
        tr "Weren't you staying at [jon]'s?"

        scene tr_e1f4-02 with dissolve
        show e1f4-tracy_blink1
        mc "Yeah, I was."
        mc "Unfortunately, his couch wasn't big enough to keep me there, so I moved."

        scene tr_e1f4-07 with dissolve
        hide e1f4-tracy_blink1
        tr "Haha, what?"

        scene tr_e1f4-02 with dissolve
        show e1f4-tracy_blink1
        mc "Yeah, don't ask."
        mc "He's most likely enjoying the privacy more than my presence there..."
        mc "...although, with [jd] always sleeping at his place at the end of every party, it kind of defeats the whole privacy thing."

        scene tr_e1f4-03 with dissolve
        hide e1f4-tracy_blink1
        tr "Looks like we're missing a lot of stuff by actually leaving the party, huh?"

        scene tr_e1f4-02 with dissolve
        show e1f4-tracy_blink1
        mc "I doubt his place would allow us all to sleep there without constantly bumping into each other."

        scene tr_e1f4-07 with dissolve
        hide e1f4-tracy_blink1
        tr "Haha, it would most certainly be an 'interesting' experience."

        scene tr_e1f4-02 with dissolve
        show e1f4-tracy_blink1
        mc "Haha, yeah!"

        scene tr_e1f4-08 with dissolve
        hide e1f4-tracy_blink1
        tr "Shit, I'm gonna be late to the auditions."

        if affinity_spectrum <= 0:
            scene tr_e1f4-04 with dissolve
            tr "I'll see you later [mc]."

        if affinity_spectrum > 0 and tracy_trust >= 2 :
            scene tr_e1f4-05 with dissolve
            tr "Hey, I'm gonna be back in like half an hour so if you're up to continuing this talk you can find me here."

            scene tr_e1f4-04 with dissolve
            tr "Just be sure to knock on the door, alright?"

            scene tr_e1f4-03 with dissolve
            tr "I usually keep it locked."

            $ optional_quests.append("Wait for Tracy to return.")

        if affinity_spectrum > 0 and tracy_trust >= 2:
            scene tr_e1f4-02 with dissolve
            show e1f4-tracy_blink1
            mc "Alright, good luck and see you later!"

        else:
            scene tr_e1f4-02 with dissolve
            show e1f4-tracy_blink1
            mc "Alright, good luck."

        scene tr_e1f4-03 with dissolve
        hide e1f4-tracy_blink1
        tr "Thanks, bye!"

        scene tr_e1f4-06 with dissolve
        pause

        $ e1f4_tracy = True

    if e1f4_ken == False and e1f4_right_door == False:
        scene e1f4-05
    if e1f4_ken == True and e1f4_right_door == False:
        scene e1f4-05_1
    if e1f4_ken == False and e1f4_right_door == True:
        scene e1f4-05_2
    if e1f4_ken == True and e1f4_right_door == True:
        scene e1f4-05_3

    call screen e1f4_hallway_2 with dissolve
return

label e1f4_hallway_3:

    if e1f4_right_door == False and e1f4_sadie == False:
        scene e1f4-06
    else:
        scene e1f4-06_1

    call screen e1f4_hallway_3 with dissolve
return

# Clickables ###################################################################

label e1f4_hallway_2_ken:
    scene ke_e1f4-01 with dissolve
    pause

    scene ke_e1f4-02 with dissolve
    mc "Hey [ke]!"

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "What's up?"

    scene ke_e1f4-04 with dissolve
    hide e1f4-ken_blink1
    ke "Hi [mc]!"

    scene ke_e1f4-05 with dissolve
    ke "Just waiting for [jd] to show up."

    scene ke_e1f4-06 with dissolve
    ke "He told me to meet him here but I don't know where he is."

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "Oh, I see."

    scene ke_e1f4-04 with dissolve
    hide e1f4-ken_blink1
    ke "Yeah... what's up with you?"

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "I just moved into my dorm and now I'm exploring the place."

    scene ke_e1f4-04 with dissolve
    hide e1f4-ken_blink1
    ke "That's cool."

    scene ke_e1f4-05 with dissolve
    ke "So, I get that you're not staying with [jon] anymore, right?"

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "Yeah."
    mc "Hey, where's [ro]?"

    scene ke_e1f4-06 with dissolve
    hide e1f4-ken_blink1
    ke "You won't believe me but he's home again doing God knows what."

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "On a wednesday?"

    scene ke_e1f4-05 with dissolve
    hide e1f4-ken_blink1
    ke "I know right?"

    scene ke_e1f4-06 with dissolve
    ke "It's not even about us partying or shit anymore..."

    scene ke_e1f4-04 with dissolve
    ke "...it's the fact that he skips classes."

    scene ke_e1f4-05 with dissolve
    ke "I get that he cares about his family a lot and all but it's his future that needs attention as well."

    scene ke_e1f4-04 with dissolve
    ke "Sorry for my little rant, I'm gonna stop now."
    ke "I'm gonna go grab something to drink."

    scene ke_e1f4-05 with dissolve
    ke "In the meantime, if you happen to see [jd], tell him I'm at Eddy's, alright?"

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "Sure thing man."

    scene ke_e1f4-04 with dissolve
    hide e1f4-ken_blink1
    ke "Alright, talk to you later."

    $ e1f4_ken = True

    $ current_quests.remove("Talk to Ken.")

    if e1f4_right_door == True:
        $ current_quests.append("Talk to Sadie.")
    else:
        pass

    scene ke_e1f4-03 with dissolve
    show e1f4-ken_blink1
    mc "Bye!"

    call e1f4_hallway_2 from _call_e1f4_hallway_2
return

label e1f4_hallway_2_tracy:
    if e1f4_sadie == False and e1f4_ken == True or e1f4_ken == False:
        mc "I should wait for her to return."

    if e1f4_ken == True and e1f4_sadie == True:
        $ collected_p = persistent.e1f4_collected_p
        $ collected_tp = persistent.e1f4_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                $ e1s17_tracy = True

                jump e1s17
            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                pass

    call e1f4_hallway_2 from _call_e1f4_hallway_2_1
return

label e1f4_hallway_3_rightdoor:

    if e1f4_right_door == False and e1f4_sadie == False:
        scene sp_e1f4-01 with dissolve
        "{i} Muffled arguing... {/i}"

        scene sp_e1f4-02 with dissolve
        pause

        scene sp_e1f4-03 with dissolve
        pause

        scene sp_e1f4-04 with dissolve
        sp "Look dude, you're done!"
        sp "I gave you the easiest task to complete, you couldn't even do that."
        sp "I really wanted this to work but you give me no choice."
        unknown "Please dude, I'll do anything!"
        sp "Sorry, this is non-negotiable."
        unknown "Don't do this [sp]..."
        unknown "I'll reveal everything if you kick me out!"
        sp "Sure, good luck with that."
        sp "Like anyone's gonna believe you."

        stop music
        play sound punch
        scene sp_e1f4-05 with vpunch
        pause

        play music keep_it_down
        scene sp_e1f4-06 with dissolve
        sp "Hey, what the fuck is your problem?"
        sp "Are you spying on me?"

        scene sp_e1f4-07 with dissolve
        show e1f4-spencer_blink1
        mc "What? No!"
        mc "I was just passing by..."

        scene sp_e1f4-08 with dissolve
        hide e1f4-spencer_blink1
        sp "Look freshie, consider this a warning."

        scene sp_e1f4-09 with dissolve
        sp "Don't stick your nose in what doesn't concern you."

        scene sp_e1f4-10 with dissolve
        show e1f4-spencer_blink2
        mc "Man, what the hell is your problem?"
        mc "Threatening everyone like they're your little dolls."

        scene sp_e1f4-09 with dissolve
        hide e1f4-spencer_blink2
        sp "You don't know shit!"

        scene sp_e1f4-08 with dissolve
        sp "I treat everyone however the fuck I want."
        sp "Plus, most of them dipshits deserve it."

        if e1s6_mad == True and affinity_spectrum > 0:
            scene sp_e1f4-10 with dissolve
            show e1f4-spencer_blink2
            mc "I'm tired of all this bullshit, you're all bark but no bite."

            scene sp_e1f4-09 with dissolve
            hide e1f4-spencer_blink2
            sp "I'll show you bite-!"

            scene sp_e1f4-11 with dissolve
            unknown "Hey, [mc]!"

            scene sp_e1f4-12 with dissolve
            pause

            scene sp_e1f4-16 with dissolve
            pause

            scene sp_e1f4-09 with dissolve
            sp "This isn't over dipshit."

            scene sp_e1f4-13 with dissolve
            pause

        else:
            scene sp_e1f4-15 with dissolve
            sp "Now move!"

        scene sp_e1f4-14 with dissolve
        pause

        scene sp_e1f4-17 with dissolve
        pause

        stop music fadeout 1.0

        scene sp_e1f4-18 with dissolve
        $ renpy.random.shuffle(e1f4_tracks)
        $ renpy.music.queue (e1f4_tracks, loop=True)
        show e1f4-sadie_blink1
        mc "What's up?"

        scene sp_e1f4-20 with dissolve
        hide e1f4-sadie_blink1
        sd "[tr] told me she forgot something so she asked me to bring it to her."

        scene sp_e1f4-22 with dissolve
        show e1f4-sadie_blink1
        mc "She said she was going to some kind of audition, right?"

        scene sp_e1f4-19 with dissolve
        hide e1f4-sadie_blink1
        sd "Yeah, she wants to be in the cheerleading squad."

        scene sp_e1f4-21 with dissolve
        sd "I'm gonna go grab it, be right back."

        scene sp_e1f4-22 with dissolve
        show e1f4-sadie_blink1
        mc "Alright."

        $ e1f4_right_door = True

        if "Talk to Ken." in current_quests:
            pass
        else:
            $ current_quests.append("Talk to Sadie.")

        $ current_quests.remove("Explore the place.")

        scene sp_e1f4-23 with dissolve
        hide e1f4-sadie_blink1
        pause

    else:

        mc "*I need to find out what's going on...*"

    call e1f4_hallway_3 from _call_e1f4_hallway_3
return

label e1f4_hallway_2_sadie:

    scene sd_e1f4-02 with dissolve
    sd "Okay, got it."

    scene sd_e1f4-03 with dissolve
    sd "Wanna come with me?"

    scene sd_e1f4-01 with dissolve
    show e1f4-sadie_blink2

    mc "*Hmm... I could go with [sd]!*"

    if affinity_spectrum > 0 and tracy_trust >= 2:
        mc "*[tr] said she'd be back here in a bit.*"

    mc "*I could also go to the gym, maybe meet [ov] there and ask her about [sp].*"

    $ collected_p = persistent.e1f4_collected_p
    $ collected_tp = persistent.e1f4_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "Go with her":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            mc "Alright, lead the way."

            scene sd_e1f4-04 with dissolve
            hide e1f4-sadie_blink2
            pause

            $ e1s17_sadie = True

            jump e1s17

        "Do something else":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            mc "Nah, I'm afraid I've got something else to do."

            scene sd_e1f4-02 with dissolve
            hide e1f4-sadie_blink2
            sd "Alright, suit yourself."

            $ e1f4_sadie = True
            $ e1f4_right_door = False

    $ current_quests.remove("Talk to Sadie.")

    $ optional_quests.append("Go to the gym.")

    scene sd_e1f4-02 with Dissolve(0.1)

    call e1f4_hallway_2 from _call_e1f4_hallway_2_2
return

label e1f4_hallway_1_exit:
    $ collected_p = persistent.e1f4_collected_p
    $ collected_tp = persistent.e1f4_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "Go to the gym":
            $ strength += 1
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            $ e1s17_olivia = True
            jump e1s17

        "Do something else":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            pass

    call e1f4_hallway_1 from _call_e1f4_hallway_1
return

# Freeroam #####################################################################

label e1f4:
    stop music fadeout 1.0

    scene e1f4-01 with dissolve

    define e1f4_tracks = ["wonder_under.ogg", "with_a_whimper.ogg", "welcome_to_zombie_coast.ogg", "tidalwave.ogg", "sun_sets_on_a_protagonist.ogg", "punk_rock_holiday.ogg", "pop_song.ogg", "killer_rabbit.ogg", "iwnlylmd.ogg", "invisible_light.ogg", "inertia.ogg", "hi_as_hats.ogg", "heartless_man.ogg", "darien_gap.ogg", "border_blaster.ogg", "bloom.ogg", "airplane_mode.ogg"]
    $ renpy.music.queue (e1f4_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Leave the room.")

    scene e1f4-01 with Dissolve(0.1)

    call screen e1f4_room34_default
    hide e1f4-01
return
