
# Scene 13 - Back to school (Tuesday) ##########################################

label e1s13:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play music hi_as_hats

    scene e1s13-01 with Dissolve(2.0)
    pause

    scene e1s13-02 with dissolve
    pause

    scene e1s13-03 with dissolve
    jn "So, what's on your calendar today?"

    scene e1s13-04 with dissolve
    mc "I think I have math first..."

    scene e1s13-05 with dissolve
    mc "I'm not entirely sure."

    scene e1s13-06 with dissolve
    jn "You're in luck then! I've got the same class."

    scene e1s13-07 with dissolve
    jn "Who do you think is going to be our teacher?"

    scene e1s13-08 with dissolve
    jn "I bet she's fine as hell."

    scene e1s13-09 with dissolve
    pause

    if affinity_spectrum <= 0:
        scene e1s13-10 with dissolve
        mc "*Typical [jon], always thinking about sex.*"

    if affinity_spectrum > 0:
        scene e1s13-11 with dissolve
        mc "I hope so too."

        scene e1s13-12 with dissolve
        mc "I'm tired of male teachers."

        scene e1s13-13 with dissolve
        jn "Haha, I know right??"

    scene e1s13-14 with dissolve
    pause

    scene e1s13-15 with wipeleft
    pause

    scene e1s13-16 with dissolve
    pause

    scene e1s13-17 with dissolve
    pause

    scene e1s13-16 with dissolve
    pause

    scene e1s13-18 with dissolve
    mc "Hey, go ahead and take a seat."
    mc "I'll come to you in a minute."

    scene e1s13-19 with dissolve
    pause

    scene e1s13-20 with dissolve
    show e1s13_cleo_blink1
    mc "Hey [cl]!"
    mc "What's up?"

    scene e1s13-21 with dissolve
    hide e1s13_cleo_blink1
    cl "Hi [mc]!"

    scene e1s13-22 with dissolve
    cl "Looks like we've got the same class, huh?"

    scene e1s13-20 with dissolve
    show e1s13_cleo_blink1
    mc "Yeah, it seems that it's a shared class among freshmen."

    scene e1s13-21 with dissolve
    hide e1s13_cleo_blink1
    cl "Did you manage to find your dorm?"

    scene e1s13-20 with dissolve
    show e1s13_cleo_blink1
    mc "Yup! I've also met my roommate, he's pretty chill."

    scene e1s13-21 with dissolve
    hide e1s13_cleo_blink1
    cl "That's great."

    scene e1s13-20 with dissolve
    show e1s13_cleo_blink1
    mc "Yeah."

    scene e1s13-22 with dissolve
    hide e1s13_cleo_blink1
    if affinity_spectrum <= 0:
        cl "So, are you going to Eddy's?"

    if affinity_spectrum > 0:
        cl "So, are you still going to Eddy's?"

    scene e1s13-20 with dissolve
    show e1s13_cleo_blink1
    mc "Yeah, I've been thinking about it and I'm gonna go."
    mc "Now that you've reminded me, I'm gonna ask my friend about it."

    scene e1s13-23 with dissolve
    hide e1s13_cleo_blink1
    cl "Alright, see ya!"

    scene e1s13-24 with dissolve
    pause

    scene e1s13-25 with dissolve
    pause

    scene e1s13-26 with dissolve
    pause

    scene e1s13-27 with dissolve
    pause

    scene e1s13-28 with dissolve
    mc "Dude..."
    mc "What the hell are you looking at?"

    scene e1s13-29 with dissolve
    jn "That painting looks funny..."

    scene e1s13-30 with dissolve
    jn "Hehe..."

    scene e1s13-31 with dissolve
    show e1s13_jon_blink1
    mc "Have you heard anything about the freshies party at Eddy's?"

    scene e1s13-32 with dissolve
    hide e1s13_jon_blink1
    jn "Ohh, yeah, that's what I've been meaning to tell you about..."
    jn "The party is tomorrow night, I've been helping to organize it behind the scenes."

    scene e1s13-33 with dissolve
    jn "Normally, a freshies party is not organized by a freshman..."

    scene e1s13-34 with dissolve
    jn "...but I have my connections"

    scene e1s13-31 with dissolve
    show e1s13_jon_blink1
    mc "That's neat!"

    scene e1s13-32 with dissolve
    hide e1s13_jon_blink1
    jn "Yeah, it's gonna be awesome!"
    jn "We've spent a long time planning it."

    scene e1s13-31 with dissolve
    show e1s13_jon_blink1
    mc "How did you even manage to take part in it?"

    scene e1s13-32 with dissolve
    hide e1s13_jon_blink1
    jn "Let's just say some girl was once at one of my parties and, of course, because she is a girl, the guys listened to her and added me to their planning group."

    scene e1s13-31 with dissolve
    show e1s13_jon_blink1
    mc "It's weird how they never advertise it anywhere."

    scene e1s13-33 with dissolve
    hide e1s13_jon_blink1
    jn "Yeah, it's kind of like an inside thing."

    scene e1s13-32 with dissolve
    jn "Even though everyone is invited, almost no one knows about it."
    jn "They like to keep it that way so from the small portion of people that show up they can choose an even smaller portion of cool people."
    jn "Also, it's way easier to manage and to keep the damages inside."

    scene e1s13-31 with dissolve
    show e1s13_jon_blink1
    mc "That's nice! I'm glad you got to plan that party."
    mc "Must be huge!"

    scene e1s13-32 with dissolve
    hide e1s13_jon_blink1
    jn "Yup! Let's hope everything goes as it should."

    stop music fadeout 1.0
    scene e1s13-35 with dissolve
    pause

    call e1s13_daydream from _call_e1s13_daydream

    jump e1s14
return

label e1s13_daydream:

    play music darien_gap
    scene e1s13-36_anim with Dissolve(1.0)
    pause 2.85

    scene e1s13-36 with dissolve
    pause

    scene e1s13-37 with dissolve
    br "Hello everyone!"

    scene e1s13-38 with dissolve
    br "My name is [br] and I'm pleased to tell you all that we're gonna study maths together."

    scene e1s13-42 with dissolve
    mc "Bro, there's no way!"

    scene e1s13-40 with dissolve
    jn "What?"

    scene e1s13-39 with dissolve
    show e1s13_jon_blink2
    mc "It's the guide from yesterday!"
    mc "I thought she was a history teacher."

    scene e1s13-41 with dissolve
    hide e1s13_jon_blink2
    jn "Well, looks like we're in luck because history is on our side today."

    scene e1s13-42 with dissolve
    pause

    scene e1s13-43 with dissolve
    pause

    scene e1s13-44 with dissolve
    pause

    stop music fadeout 1.0
    scene e1s13-45 with dissolve
    play music blues_of_t fadein 1.0
    pause

    if persistent.disable_nsfw == True:
        scene e1s13-46 with dissolve
        mc "*Oh shit!*"

        scene e1s13-45 with dissolve
        mc "*What's happening?*"

        scene e1s13-42 with dissolve
        mc "*...*"

        scene e1s13-45 with dissolve
        pause

        scene e1s13-47 with dissolve
        pause

        scene e1s13-56 with dissolve
        pause

        scene e1s13-48 with dissolve
        pause

        scene e1s13-49 with dissolve
        pause 0.5
        menu:
            "Check her out":
                scene e1s13-50 with dissolve
                pause
            "Don't check her out":
                pass

        scene e1s13-49 with dissolve
        pause

        scene e1s13-51 with dissolve
        pause

        scene e1s13-52 with dissolve
        pause

        scene e1s13-53 with dissolve
        pause

        scene e1s13-54 with dissolve
        pause

    if persistent.disable_nsfw == False:
        if persistent.type_nsfw == False:
            scene c_e1s13-46 with dissolve
            mc "*Oh shit!*"

            scene e1s13-45 with dissolve
            mc "*What's happening?*"

            scene e1s13-42 with dissolve
            mc "*...*"

            scene e1s13-45 with dissolve
            pause

            scene e1s13-47 with dissolve
            pause

            scene e1s13-56 with dissolve
            pause

            scene e1s13-48 with dissolve
            pause

            scene c_e1s13-49 with dissolve
            pause 0.5

            menu:
                "Check her out":
                    scene c_e1s13-50 with dissolve
                    pause
                "Don't check her out":
                    pass

            scene c_e1s13-49 with dissolve
            pause

            scene c_e1s13-51 with dissolve
            pause

            scene c_e1s13-52 with dissolve
            pause

            scene c_e1s13-53 with dissolve
            pause

            scene c_e1s13-54 with dissolve
            pause

    stop music
    scene e1s13-55
    br "Is there something wrong?"

    scene e1s13-60 with dissolve
    show e1s13_bridget_blink1
    mc "No... I... uh..."

    scene e1s13-58 with dissolve
    hide e1s13_bridget_blink1
    mc "..."

    scene e1s13-59 with dissolve
    pause

    scene e1s13-58 with dissolve
    menu:

        "Truth":
            call introvert_affinity_check from _call_introvert_affinity_check_11
            call color_check from _call_color_check_25

            scene e1s13-60 with dissolve
            show e1s13_bridget_blink1
            mc "I wasn't paying attention, I'm sorry."

            br "..."

            scene e1s13-61 with dissolve
            pause

        "Lie":
            call extrovert_affinity_check from _call_extrovert_affinity_check_13
            call color_check from _call_color_check_26

            scene e1s13-60 with dissolve
            show e1s13_bridget_blink1
            mc "I was just listening to the class!"

            scene e1s13-55 with dissolve
            hide e1s13_bridget_blink1
            br "Is that so?"
            br "Can you repeat what I just said?"

            scene e1s13-60 with dissolve
            show e1s13_bridget_blink1
            mc "Well... I..."

            scene e1s13-61 with dissolve
            pause

    scene e1s13-62 with dissolve
    pause

    scene e1s13-57 with dissolve
    mc "*Not funny bro...*"

    $ renpy.end_replay()

return
