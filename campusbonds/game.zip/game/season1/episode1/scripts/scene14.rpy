
# Scene 14 - Boring classes ####################################################

label e1s14:
    stop music fadeout 2.0
    scene e1s14-01 with wipeleft
    play music invisible_light
    pause

    scene e1s14-02 with dissolve
    mc "Hey, what are you up to?"

    scene e1s14-03 with dissolve
    cl "Just trying to grab my book for the next class."
    cl "If this stupid locker wasn't stuck."

    scene e1s14-04 with dissolve
    show e1s14_cleo_blink1
    mc "Want me to try getting it open?"

    scene e1s14-03 with dissolve
    hide e1s14_cleo_blink1
    cl "Alright."

    scene e1s14-07 with dissolve
    mc "..."
    mc "Yup, it's really stuck."

    scene e1s14-05 with dissolve
    hide e1s14_cleo_blink1
    show e1s14_cleo_blink2
    mc "So, what do you have next?"

    scene e1s14-06 with dissolve
    hide e1s14_cleo_blink2
    cl "English Ed., you?"

    scene e1s14-05 with dissolve
    show e1s14_cleo_blink2
    mc "Same."
    mc "Mind if I tag along?"

    scene e1s14-06 with dissolve
    hide e1s14_cleo_blink2
    cl "Sure, be my guest."

    scene e1s14-08 with dissolve
    show e1s14_cleo_blink3
    mc "So, how's the dorm situation?"

    scene e1s14-09 with dissolve
    hide e1s14_cleo_blink3
    cl "Nothing has changed..."

    scene e1s14-10 with dissolve
    cl "...they said that they're gonna give me 3 free months for the inconvenience."

    scene e1s14-11 with dissolve
    cl "And that they're sorry."

    scene e1s14-12 with dissolve
    cl "Like that's gonna make me any less homeless..."

    scene e1s14-13 with dissolve
    show e1s14_cleo_blink4
    mc "Homeless? Don't tell me you're sleeping on the street."

    scene e1s14-14 with dissolve
    hide e1s14_cleo_blink4
    cl "No!"

    scene e1s14-15 with dissolve
    cl "Luckily, my boss helped me with renting an apartment which he pays from his own pocket."

    scene e1s14-16 with dissolve
    cl "I can tell he doesn't like the situation but imagine if I lost the job."

    scene e1s14-17 with dissolve
    cl "I would probably be homeless!"

    scene e1s14-18 with dissolve
    cl "I'm surprised he even helped me in the first place."

    scene e1s14-19 with dissolve
    cl "He doesn't really like me that much..."

    scene e1s14-20 with dissolve
    show e1s14_cleo_blink3
    mc "Honestly that sucks big time."

    scene e1s14-21 with dissolve
    hide e1s14_cleo_blink3
    show e1s14_cleo_blink4
    mc "Let's hope this all gets sorted out so you don't have to rely on your boss anymore."

    scene e1s14-22 with dissolve
    hide e1s14_cleo_blink4
    cl "Yeah."

    scene e1s14-23 with dissolve
    cl "A shit situation indeed..."

    scene e1s14-24 with vpunch
    cl "But, anyways, how's things going for you?"

    scene e1s14-25 with dissolve
    cl "Did you manage to move into your dorm yet?"

    scene e1s14-26 with dissolve
    show e1s14_cleo_blink3
    mc "Not really... for now I'm still staying at a friend's."

    scene e1s14-27 with dissolve
    hide e1s14_cleo_blink3
    show e1s14_cleo_blink4
    mc "I hope that tomorrow I can get my stuff moved into my dorm."

    scene e1s14-28 with dissolve
    hide e1s14_cleo_blink4
    show e1s14_cleo_blink3
    mc "I liked staying at his place but I like having a bed of my own more."

    scene e1s14-29 with dissolve
    hide e1s14_cleo_blink3
    cl "Haha, don't tell me you were sleeping on his couch!"

    scene e1s14-30 with dissolve
    show e1s14_cleo_blink3
    mc "Oh yeah I was! He even made a big speech about how much he cares about me and that he's gonna give me his couch."

    scene e1s14-31 with dissolve
    hide e1s14_cleo_blink3
    cl "Haha, no way!"

    scene e1s14-32 with dissolve
    show e1s14_cleo_blink3
    mc "Yeah... I'm not gonna miss it."

    scene e1s14-33 with dissolve
    hide e1s14_cleo_blink3
    cl "I can tell."

    scene e1s14-34 with dissolve
    pause

    stop music
    scene e1s14-35 with wipeleft
    play music whhhsfs
    show e1s14_cleo_blink5
    mc "I've never liked English classes to be honest."
    mc "I find it pretty boring to learn all that grammar..."

    scene e1s14-36 with dissolve
    hide e1s14_cleo_blink5
    cl "Well, I'm not a big fan either."

    scene e1s14-38 with dissolve
    cl "But I guess it's better than working at the diner."

    scene e1s14-37 with dissolve
    cl "Thankfully, I'm free today so I don't have to endure any more shit customers."

    scene e1s14-35 with dissolve
    show e1s14_cleo_blink5
    mc "I see!"
    mc "Wanna hang out later then?"

    scene e1s14-36 with dissolve
    hide e1s14_cleo_blink5
    cl "Sure!"
    cl "Here's my number, text me after school."

    scene e1s14-35 with dissolve
    show e1s14_cleo_blink5
    mc "Alright!"

    scene e1s14-39 with dissolve
    hide e1s14_cleo_blink5
    pause

    scene e1s14-40 with dissolve
    ar "Hello everyone and welcome to my English Ed. class!"

    scene e1s14-41 with dissolve
    ar "My name is [ar] and today we're gonna have a pretty simple test before we go any further regarding your English level."

    play sound punch
    scene e1s14-42 with vpunch
    unknown "Oh God damn it, a test on the first day..."

    scene e1s14-43 with dissolve
    ar "Now, you don't have to worry too much about this test."
    ar "It's not gonna count for your final grade."

    scene e1s14-41 with dissolve
    ar "As I've already mentioned, it's a way for me to see the average level of this class."

    stop music
    scene e1s14-44 with wipeleft
    play music inertia
    pause

    scene e1s14-45 with dissolve
    pause

    scene e1s14-46 with dissolve
    show e1s14_francesca_blink1
    mc "Hey [fr]!"

    if e1s11_kiss_her == True:
        scene e1s14-47 with dissolve
        hide e1s14_francesca_blink1
        fr "[mc]! I just want you to know that what happened last night was a mistake."

        scene e1s14-48 with dissolve
        fr "It shouldn't have happened the way it did."

        scene e1s14-47 with dissolve
        fr "I'm sorry but I have to go!"

        scene e1s14-49 with dissolve
        mc "*Okay... that was weird.*"

    if e1s11_kiss_her == False:
        scene e1s14-47 with dissolve
        hide e1s14_francesca_blink1
        fr "Hey [mc]! I'm sorry but I can't really talk right now, I'm a little busy."

        scene e1s14-46 with dissolve
        show e1s14_francesca_blink1
        mc "It's alright! I just came to borrow a book anyways."

        scene e1s14-47 with dissolve
        hide e1s14_francesca_blink1
        fr "Nice! I'll be seeing you around then."

        scene e1s14-46 with dissolve
        show e1s14_francesca_blink1
        mc "Bye!"

        scene e1s14-49 with dissolve
        hide e1s14_francesca_blink1
        mc "*That was kinda awkward...*"

    scene e1s14-50 with dissolve
    pause

    scene e1s14-51 with dissolve
    pause

    scene e1s14-52 with dissolve
    pause

    scene e1s14-53 with dissolve
    mc "*Wait, is she reading the same book?*"

    scene e1s14-54 with dissolve
    pause

    scene e1s14-55 with dissolve
    pause

    scene e1s14-53 with dissolve
    mc "*I didn't know there was anyone else interested in this other than me.*"

    scene e1s14-56 with dissolve
    pause

    scene e1s14-57 with dissolve
    mc "I didn't know there was anyone else interested in Train Infection other than me."

    scene e1s14-58 with dissolve
    unknown "What?"

    if affinity_spectrum <= 0:
        mc "The book... the one you're reading?"

    if affinity_spectrum > 0:
        mc "I'm talking about the book you're reading!"

    scene e1s14-59 with dissolve
    pause

    scene e1s14-60 with dissolve
    unknown "Oh, haha!"

    scene e1s14-62 with dissolve
    unknown "To be honest {b} I also {/b} didn't know there was anyone else interested in it."

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "I guess that makes the two of us now!"

    scene e1s14-60 with dissolve
    hide e1s14_alice_blink1
    unknown "Haha, yeah!"

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "I'm [mc]."

    scene e1s14-62 with dissolve
    hide e1s14_alice_blink1
    al "[al]!"

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "So, which volume did you like the most?"

    scene e1s14-62 with dissolve
    hide e1s14_alice_blink1
    al "I most certainly gotta give it to the second one."
    al "I wasn't really a big fan of the drama in the first one."

    scene e1s14-63 with dissolve
    al "It became way too complicated real quick."

    scene e1s14-64 with dissolve
    al "And I just love the direction that the second one took."

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1

    if affinity_spectrum <= 0:
        mc "Well, I think the third one is where it shines the most."
        mc "For sure, the drama in the first one didn't appeal to me at all."
        mc "Just like you said, it became messy."
        mc "The second one was good but not third level good, you know?"
        mc "I feel like they started something in the second and made a breakthrough in the third."

    if affinity_spectrum > 0:
        mc "Haha, looks like we're different on this one."
        mc "I loved the drama in the first one."
        mc "There were so many twists and whatnot that really kept me going."
        mc "The second and the third felt kind of flat because there wasn't much story progression."
        mc "And that's why I started reading it in the first place, for the story."

    scene e1s14-62 with dissolve
    hide e1s14_alice_blink1
    al "Well, at the end of the day, everyone has a different opinion about it."
    al "That's why I love it so much, it leaves different impressions."

    scene e1s14-64 with dissolve
    al "It's so versatile yet feels almost the same for everyone."

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "Haha, I haven't heard anyone speak so passionately about this."

    scene e1s14-62 with dissolve
    hide e1s14_alice_blink1
    al "Well yeah! I don't have anyone to share my thoughts on this."

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "Haha, don't worry!"
    mc "I enjoy talking about it as well."

    scene e1s14-62 with dissolve
    hide e1s14_alice_blink1
    al "That's good to know!"

    scene e1s14-65 with dissolve
    pause

    scene e1s14-62 with dissolve
    al "Well, I'll be seeing you around!"
    al "My brother's waiting to pick me up."

    scene e1s14-61 with dissolve
    show e1s14_alice_blink1
    mc "Alright, bye!"

    scene e1s14-66 with dissolve
    hide e1s14_alice_blink1
    menu:
        "Check her out":
            scene e1s14-67 with dissolve
            pause
        "Don't check her out":
            pass

    scene e1s14-68 with dissolve
    pause

    stop music fadeout 1.0
    scene e1s14-69 with dissolve
    unknown "{i}Muffled arguing{/i}"
    mc "*Huh?*"

    scene e1s14-70 with dissolve
    mc "*The arguing is coming from this way.*"

    scene e1s14-71 with dissolve
    play music dances_and_dames
    pause

    scene e1s14-72 with dissolve
    sp "I think we're gonna have to cut some expenses this month."

    scene e1s14-74 with dissolve
    sp "That stupid little shit lost it and we don't have anything else to bring in..."

    scene e1s14-73 with dissolve
    mc "*Who is he talking about?*"

    scene e1s14-93 with dissolve
    show e1s14_spencer_blink1
    unknown "I've already told you that he shouldn't have been involved in this in the first place."

    scene e1s14-74 with dissolve
    hide e1s14_spencer_blink1
    sp "I didn't know he would be this stupid."

    scene e1s14-79 with dissolve
    sp "I should have known that he's not a trustworthy source from the moment I saw him hanging out with my brother..."

    scene e1s14-93 with dissolve
    show e1s14_spencer_blink1
    unknown "Well, it's your mess now so fix it!"

    stop music
    play sound punch
    scene e1s14-77 with vpunch
    hide e1s14_spencer_blink1
    pause

    scene e1s14-78 with dissolve
    mc "*Oh shit!*"

    scene e1s14-76 with dissolve
    pause

    scene e1s14-75 with dissolve
    sp "I'll call you later, alright?"

    scene e1s14-83 with dissolve
    pause

    scene e1s14-82 with dissolve
    pause

    scene e1s14-84 with dissolve
    pause

    scene e1s14-85 with dissolve
    pause

    scene e1s14-86 with dissolve
    mc "*Ok that was way too close, I should just mind my own business.*"

    scene e1s14-80 with dissolve
    pause

    scene e1s14-81 with wipeleft
    play music crazy_glue
    pause

    scene e1s14-87 with dissolve
    pause

    scene e1s14-88 with dissolve
    mc "Uh... hi?"

    scene e1s14-89 with dissolve
    show e1s14_evelyn_blink1
    mc "I'd like to borrow this book."

    scene e1s14-91 with dissolve
    hide e1s14_evelyn_blink1
    unknown "Student card."

    scene e1s14-89 with dissolve
    show e1s14_evelyn_blink1
    menu:
        "Check her out":

            $ evelyn_trust -= 1

            scene e1s14-92 with dissolve
            hide e1s14_evelyn_blink1
            pause

            scene e1s14-90 with dissolve
            unknown "Eyes up here."

            scene e1s14-89 with dissolve
            show e1s14_evelyn_blink1
            mc "Sorry..."

        "Don't check her out":
            pass

    mc "Here!"

    scene e1s14-88 with dissolve
    hide e1s14_evelyn_blink1
    pause

    scene e1s14-91 with dissolve
    unknown "You may go now."

    scene e1s14-89 with dissolve
    show e1s14_evelyn_blink1
    mc "Alright... thanks."
    mc "*She's pretty rude...*"

    jump e1s15
return
