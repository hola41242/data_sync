
# Free roam ####################################################################

# Free roam #1 Variables #######################################################
default meet_sadie = False
default used_luggage = False
default f1_money_picked = False
default f1_house_explored = 0
default f1_dumbbells = False

# Freeroam Collected Photos #

default persistent.e1f1_collected_p = 0
default persistent.e1f1_collected_tp = 5

################################################################################

label f1_living:
    if used_luggage == False:
        scene e1f1-01
    if used_luggage == True:
        scene e1f1-01-no_luggage
    call screen f1_living with dissolve
return

label f1_kitchen:
    scene e1f1-02
    call screen f1_kitchen with dissolve
return

label f1_balcony:
    if meet_sadie == True:

        scene e1f1-03
        call screen f1_balcony with dissolve
    else:

        $ f1_house_explored += 1

        scene e1f1-bc1 with dissolve
        pause

        scene e1f1-bc2 with dissolve
        pause

        scene e1f1-bc3 with dissolve

        if affinity_spectrum >= 0:
            mc "Talk about living extreme..."
        if affinity_spectrum < 0:
            mc "..."

        scene e1f1-bc4 with dissolve
        pause

        menu:

            "Check her out":
                scene e1f1-bc10 with dissolve
                pause

                scene e1f1-bc11 with dissolve
                pause

            "Don't risk it":
                pause(0.1)

        scene e1f1-bc5 with dissolve
        pause

        scene e1f1-bc6 with dissolve
        pause

        scene e1f1-bc7 with dissolve
        pause

        scene e1f1-bc8 with dissolve
        pause

        $ meet_sadie = True

        if f1_house_explored == 3:
            $ optional_quests.remove("Explore the place.")

        scene e1f1-bc9 with dissolve
        if affinity_spectrum >= 0:
            mc "Bummer."
        else:
            mc "..."

        scene e1f1-03
        call screen f1_balcony with dissolve
return

label f1_bedroom:
    scene e1f1-04
    call screen f1_bedroom with dissolve

    if f1_dumbbells == False:

        label f1_dumbbells:

            $ f1_dumbbells = True
            $ f1_house_explored += 1
            $ strength += 1

            scene e1f1-br2 with dissolve
            pause

            scene e1f1-br1 with dissolve
            mc "Hmm..."
            mc "A quick workout wouldn't hurt."

            scene e1f1-br3 with dissolve
            pause

            scene e1f1-br4 with dissolve
            pause

            scene e1f1-br5 with dissolve
            pause

            scene e1f1-br6 with dissolve
            pause

            scene e1f1-br5 with dissolve
            pause

            scene e1f1-br4 with dissolve
            pause

            scene e1f1-br7 with dissolve
            pause

            scene e1f1-br8 with dissolve
            pause

            scene e1f1-br7 with dissolve
            pause

            scene e1f1-br4 with dissolve
            pause

            scene e1f1-br3 with dissolve
            pause

            scene e1f1-br9 with dissolve
            pause

            if f1_house_explored == 3:
                $ optional_quests.remove("Explore the place.")

            scene e1f1-04 with dissolve
            call screen f1_bedroom with dissolve

    if f1_dumbbells == True:
        scene e1f1-04
        call screen f1_bedroom with dissolve

    return
return

label f1_bathroom:
    scene e1f1-05
    call screen f1_bathroom with dissolve
return

label f1_luggage:

    $ f1_house_explored += 1
    scene e1f1-li1 with dissolve
    mc "I should use the free time to unpack."

    scene e1f1-li2 with dissolve
    pause

    scene e1f1-li3 with dissolve
    pause

    scene e1f1-li4 with dissolve
    pause

    scene e1f1-li5 with dissolve
    pause

    if f1_house_explored == 3:
        $ optional_quests.remove("Explore the place.")

    $ used_luggage = True
    $ current_quests.remove("Unpack.")
    $ current_quests.append("Rest on the couch.")

    scene e1f1-li6 with dissolve
    pause

    call f1_living from _call_f1_living
return

label f1_couch:
    $ collected_p = persistent.e1f1_collected_p
    $ collected_tp = persistent.e1f1_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "End free roam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            jump e1s4

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            call f1_living from _call_f1_living_2
    return
return

# Free roam #1 Cutscene ########################################################

transform small_notes_pos:
    on show:
        xpos 77 ypos 90 alpha 1.0
        linear 0.0 alpha 0.0
        linear 0.5 alpha 0.0
        linear 0.0 alpha 1.0
        linear 0.5 alpha 1.0
        linear 0.0 alpha 0.0
        linear 0.5 alpha 0.0
        linear 0.0 alpha 1.0
        linear 0.5 alpha 1.0
        linear 0.0 alpha 0.0
        linear 0.5 alpha 0.0
        linear 0.0 alpha 1.0
        linear 0.5 alpha 1.0
        linear 0.0 alpha 0.0
        linear 0.5 alpha 0.0
        linear 0.0 alpha 1.0
    on hide:
        xpos 77 ypos 90 alpha 1.0
        linear 0.5 alpha 0.0

image f1_text = ParameterizedText(xalign=0.5, yalign=0.5, font="fonts/celebes_light.otf", textalign = 0.5, size=40,)

label freeroam1:

    scene e1f1-money with dissolve

    if persistent.tutorial == True:
        show tutorial_background_menu with wiperight
        show dialogue_box with wiperight
        show f1_text "You are now inside a free roam! Interact with the world \n around you to advance the story." with wiperight
        pause

        hide f1_text with wipeleft
        show f1_text "During this state of the game, you can explore different \n areas for photos and money." with wiperight
        pause

        hide f1_text with wipeleft
        show f1_text "You can find the collected photos in the 'gallery' section \n from the main menu." with wiperight
        pause

        hide f1_text with wipeleft
        show image "quest_tracker/small_notes_notification.webp" at quest_notification
        play sound notification
        show f1_text "There is an icon in the top-right corner that allows you to \n open the quest tracker." with wiperight
        pause

        hide image "quest_tracker/small_notes_notification.webp" at quest_notification
        hide f1_text with wipeleft
        show f1_text "The quest tracker shows your active tasks, divided into \n main and optional quests." with wiperight
        pause

        hide f1_text with wipeleft
        show f1_text "You can close it by clicking outside the screen or by \n tapping on the pin icon." with wiperight
        pause

        call screen questtracker_tutorial

        hide f1_text with wipeleft
        show f1_text "It updates automatically as you complete tasks, and if \n there are no remaining quests, it will display \n a message saying 'No tasks available.'" with wiperight
        pause

        hide f1_text with wipeleft
        hide dialogue_box with wipeleft
        hide tutorial_background_menu with wipeleft

    define f1_tracks = ["killer_rabbit.ogg", "airplane_mode.ogg", "heartless_man.ogg", "punk_rock_holiday.ogg", "tidalwave.ogg", "sundown.ogg", "welcome_to_zombie_coast.ogg", "pop_song.ogg", "wonder_under.ogg"]
    $ renpy.music.queue (f1_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Unpack.")
    $ optional_quests.append("Explore the place.")

    scene e1f1-money with Dissolve(0.5)

    call screen f1_living
    hide e1f1-01
return
