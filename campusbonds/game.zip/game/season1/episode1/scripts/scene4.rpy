
label e1s4:

    stop music fadeout 2.5
    scene e1s4-01 with dissolve
    pause

    scene e1s4-02 with dissolve
    pause

    stop music fadeout 2.5
    stop sound fadeout 2.5
    scene black with Dissolve(2.0)

    scene e1s4-07 with Dissolve(2.0)
    play music motown_rehearsal loop
    pause

    scene e1s4-08 with dissolve
    pause

    scene e1s4-03 with dissolve
    jn "Sup [mc]!"
    jn "Are you sleeping?"

    scene e1s4-05 with dissolve
    mc "Nah, I'm just resting."
    mc "I was pretty exhausted from the trip."

    scene e1s4-04 with dissolve
    jn "My friends should be here any minute now."
    jn "Let's prepare the place a little."

    scene e1s4-06 with dissolve
    pause

    scene e1s4-04 with dissolve
    jn "Oh and also..."

    scene e1s4-09 with dissolve
    jn "I got the goods!!"

    scene e1s4-10 with dissolve
    mc "Nice!"
    jn "I even got a discount for getting so many."
    mc "They don't seem that many."
    jn "Just wait until you see the rest of the bag."

    scene e1s4-11 with dissolve
    pause

    scene e1s4-12 with dissolve
    pause

    scene e1s4-13 with dissolve
    pause

    scene e1s4-14 with dissolve
    pause

    scene e1s4-33 with dissolve
    mc "Bro, how did you even manage to fit that many beers in that tiny bag?"
    jn "A magician doesn't reveal his tricks."
    stop music fadeout 1

    scene e1s4-15 with dissolve
    play music moving_up
    jn "[ke]!"
    jn "Welcome bro!"

    scene e1s4-16 with dissolve
    ke "Hey [jon]!"

    scene e1s4-17 with dissolve
    unknown "[jn]!"

    scene e1s4-18 with dissolve
    jn "What's up [jd]!"

    scene e1s4-19 with dissolve
    unknown "What's good bro!"

    scene e1s4-20 with dissolve
    pause

    scene e1s4-21 with dissolve
    jn "So, guys..."

    scene e1s4-22 with dissolve
    jn "I'd like to introduce you to my friend here, [mc]."
    jn "He's gonna be a freshman at Underport Liberty as well."

    scene e1s4-25 with dissolve
    ke "Nice!"
    scene e1s4-24 with dissolve
    pause

    scene e1s4-21 with dissolve
    jn "I've invited him to stay at my place for a couple of days so he could get a proper introduction to the college experience."

    scene e1s4-27 with dissolve
    jd "You sure chose the right people to be his guide."
    scene e1s4-26 with dissolve
    pause

    scene e1s4-30 with dissolve
    ke "I'm [ke]!"
    ke "Nice to meet you, [mc]!"

    scene e1s4-31 with dissolve
    jd "[jd]."

    scene e1s4-32 with dissolve
    ro "I'm [ro]."

    scene e1s4-23 with dissolve
    mc "Nice to meet you guys!"

    scene e1s4-28 with dissolve
    ro "So, [mc], what are you studying?"

    scene e1s4-23 with dissolve
    mc "Well, I thought about majoring in management."

    scene e1s4-29 with dissolve
    mc "It's pretty much the only subject that I found interesting."

    scene e1s4-23 with dissolve
    mc "And there wasn't a big selection really."

    scene e1s4-73 with dissolve
    jn "Guys, guys..."
    jn "Let's leave all this school crap outside and get to drinking."

    scene e1s4-22 with dissolve
    jn "As you can see here..."

    scene e1s4-33 with dissolve
    jn "Me and [mc] made sure that we're not gonna have to worry about drinks tonight."
    jd "You sure did get a lot!"

    scene e1s4-22 with dissolve
    jn "So, with that being said..."
    jn "Let's dig in gentlemen."

    scene e1s4-33 with dissolve
    jn "Come now, don't be shy."

    scene e1s4-37 with dissolve
    pause

    scene e1s4-38 with dissolve
    pause

    scene e1s4-39 with dissolve
    pause

    scene e1s4-40 with dissolve
    play sound glass_cheers
    "Cheers!!"

    scene e1s4-41 with dissolve
    pause

    scene e1s4-42 with dissolve
    pause

    scene e1s4-43 with dissolve
    pause

    scene e1s4-44 with dissolve
    jd "Guys, you need to come outside."

    scene e1s4-45 with dissolve
    pause

    scene e1s4-46 with dissolve
    pause

    scene e1s4-47 with dissolve
    show e1s4_mc_blink1
    jd "I got a pretty funny idea."
    jd "Bear with me a little."

    show e1s4-48 behind e1s4_mc_blink1 with dissolve
    jd "What if we throw this balloon at her right now!"
    jd "And see if we hit her!"

    scene e1s4-49 with dissolve
    hide e1s4-48
    hide e1s4_mc_blink1
    ke "I don't know guys..."
    ke "That doesn't sound like the best idea to me."

    scene e1s4-50 with dissolve
    jn "Well, I think we should do it."

    scene e1s4-51 with dissolve
    jn "It's just a little bit of water."

    scene e1s4-52 with dissolve
    jn "It would be pretty funny."
    jn "And it's not like she can sue us or anything."

    scene e1s4-53 with dissolve
    show e1s4_mc_blink2
    jd "What do you think [mc]?"
    jd "Shall we do it?"

    show e1s4-54 behind e1s4_mc_blink2 with dissolve
    menu:
        "Do it":
            $ balloon_hit = True
            call extrovert_affinity_check from _call_extrovert_affinity_check_21
            call color_check from _call_color_check_42
            scene e1s4-55 with dissolve
            hide e1s4-54
            hide e1s4_mc_blink2
            mc "I'll do it!"

            scene e1s4-58 with dissolve
            jd "Alright!"

            scene e1s4-59 with dissolve
            jd "Let's have some fun shall we?"

            scene e1s4-60 with dissolve
            mc "Here it goes."

            scene e1s4-61 with dissolve
            pause

            scene e1s4-62 with dissolve
            pause

            scene e1s4-63 with dissolve
            pause

            play sound water_balloon
            scene e1s4-64 with dissolve
            unknown "HUH??"
            jd "Oh shit!"
            jd "You actually hit her!"

            scene e1s4-65 with dissolve
            unknown "What the fuck??"

            scene e1s4-66 with dissolve
            jd "Shit, she's looking at us."
            jn "Fuck! Go back!"

            scene e1s4-71 with dissolve
            mc "Haha!"

        "Don't do it":
            call introvert_affinity_check from _call_introvert_affinity_check_18
            call color_check from _call_color_check_43
            scene e1s4-56 with dissolve
            hide e1s4-54
            hide e1s4_mc_blink2
            mc "Sorry guys..."
            mc "I'm not doing it."

            scene e1s4-57 with dissolve
            jd "Alright then, let's have some fun shall we?"

            scene e1s4-67 with dissolve
            show e1s4-jon_blink1
            jd "Let's drop this bad boy on her."

            scene e1s4-68 with dissolve
            hide e1s4-jon_blink1
            pause

            scene e1s4-63 with dissolve
            pause

            play sound water_balloon
            scene e1s4-69 with dissolve
            jd "Bro..."
            jd "I missed."

            scene e1s4-70 with dissolve
            jn "You really have no aim."
            jn "Let's go back inside."

            scene e1s4-72 with dissolve
            jd "I really thought I'd hit her..."

    scene e1s4-33 with dissolve
    pause

    scene e1s4-34
    pause

    scene e1s4-35
    pause

    scene e1s4-36
    pause

    scene black
    stop music
    pause

    jump e1s5
return
