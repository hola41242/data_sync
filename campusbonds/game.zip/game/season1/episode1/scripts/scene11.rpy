
# Scene 11 - A new friend ######################################################

label e1s11:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene e1s11-01 with Dissolve(2.0)
    pause

    scene e1s11-02 with dissolve
    pause

    scene e1s11-03 with dissolve
    pause

    scene e1s11-04 with dissolve
    pause

    play sound punch
    scene e1s11-05 with vpunch
    pause

    scene e1s11-06 with dissolve
    unknown "Oh my gosh!!"
    unknown "I am so sorry!"

    scene e1s11-10 with dissolve
    hide e1s11-francesca_blink1
    play music border_blaster
    unknown "Are you okay?"

    scene e1s11-09 with dissolve
    show e1s11-francesca_blink1
    mc "Yeah, I'm fine."
    if affinity_spectrum > 0:
        mc "I got some ketchup in my ear I think."

    scene e1s11-10 with dissolve
    hide e1s11-francesca_blink1
    unknown "I'm so so sorry!"
    unknown "Let me make it up to you!"

    scene e1s11-09 with dissolve
    show e1s11-francesca_blink1
    mc "It's fine, don't worry."
    mc "It can happen to anyone."

    scene e1s11-10 with dissolve
    hide e1s11-francesca_blink1
    unknown "At least let me buy you a hotdog!"

    scene e1s11-09 with dissolve
    show e1s11-francesca_blink1
    mc "Alright, alright."
    mc "If that's gonna make you feel better."

    scene e1s11-11 with dissolve
    hide e1s11-francesca_blink1
    pause

    scene e1s11-22 with dissolve
    unknown "I'm really sorry!"
    unknown "I wasn't paying attention to where I was going."

    scene e1s11-20 with dissolve
    show e1s11-francesca_blink3
    mc "It's alright, this is certainly the weirdest way I've met a person."

    scene e1s11-21 with dissolve
    hide e1s11-francesca_blink3
    unknown "Haha, I see!"
    fr "I'm [fr] by the way."

    scene e1s11-20 with dissolve
    show e1s11-francesca_blink3
    mc "I'm [mc], nice to meet you."

    scene e1s11-21 with dissolve
    hide e1s11-francesca_blink3
    fr "So, what would you like to get?"

    scene e1s11-20 with dissolve
    show e1s11-francesca_blink3
    mc "A hotdog is fine."

    scene e1s11-21 with dissolve
    hide e1s11-francesca_blink3
    fr "Alright, a hotdog coming right up."

    scene e1s11-24 with dissolve
    unknown "Here's your hotdog miss!"

    scene e1s11-25 with dissolve
    pause

    scene e1s11-12 with wipeleft
    pause

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "So, do you come here often?"

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    fr "Not really."

    scene e1s11-15 with dissolve
    fr "I wasn't in the mood for anything tonight so I preffered to get food from here."

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "I see!"
    mc "Any particular reason as to why you're not in the mood?"

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    fr "Let's just say I got into a fight with someone."
    fr "But, enough about me, what brings you around this place?"

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "I just came from my uni dorm and now I'm going back to my friend's place."

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    fr "Ah! So you're going to university."
    fr "UPL I assume, right?"

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "Yup! I just got accepted and now I'm trying to get settled in."

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    fr "Nice! The first year's probably going to be the hardest but you'll get used to it pretty soon."
    fr "I'm also at UPL, year 3."
    fr "What are you studying?"

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "Well, I've been thinking about getting a bachelor's degree in management."
    mc "Besides fighting, I don't have any other skills, so..."

    scene e1s11-15 with dissolve
    hide e1s11_francesca_blink2
    fr "Why are you going to university then?"
    fr "Why not just become a fighter if you like it that much?"

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "Well, it's a little bit more complicated than that."

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    stop music fadeout 2.0
    fr "Come on! It can't be that bad."

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    play music hollow_grove
    mc "Well, getting a career in fighting was my original plan..."

    show e1s11-16 behind e1s11_francesca_blink2 with dissolve
    mc "...but unfortunately I got seriously injured during a fight."
    mc "And because of that I'm unable to pursue a career."

    scene e1s11-15 with dissolve
    hide e1s11_francesca_blink2
    hide e1s11-16
    fr "Oh my..."
    fr "Is it that serious?"

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "Yup! I'm lucky it didn't cause me any permanent paralysis."

    scene e1s11-15 with dissolve
    hide e1s11_francesca_blink2
    fr "I'm sorry."
    fr "Must be tough that you can't do the thing you love."

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "Yeah, well I still spar from time to time."
    mc "But professionally, it's over..."
    mc "I mean, I've gotten used to it."
    mc "It doesn't really bother me anymore."
    mc "Just random thoughts from time to time about what I could have done differently."

    scene e1s11-15 with dissolve
    hide e1s11_francesca_blink2
    fr "Hey, don't say that!"
    fr "You couldn't have known back then that it could end your career."

    scene e1s11-17 with dissolve
    fr "You shouldn't live with regrets, especially when it's not your fault."

    scene e1s11-15 with dissolve
    fr "At least you're still here."

    scene e1s11-19 with dissolve
    fr "You're alive and that's all that matters!"

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "Well, I guess you're right."
    mc "Thanks, that made me feel better!"

    scene e1s11-14 with dissolve
    hide e1s11_francesca_blink2
    fr "No problem!"
    fr "I'm glad to be helpful."

    scene e1s11-13 with dissolve
    show e1s11_francesca_blink2
    mc "..."

    scene e1s11-17 with dissolve
    hide e1s11_francesca_blink2
    fr "...when I was little I used to love dancing..."

    scene e1s11-39 with dissolve
    fr "...and I dreamt about becoming a super star."

    scene e1s11-40 with dissolve
    fr "All those cartoons really spoiled me."

    scene e1s11-23 with dissolve
    fr "But good old Dad wanted me to follow a different path in life, a 'real' career."

    scene e1s11-18 with dissolve
    fr "He said that a bachelor's degree in business is going to be way more useful than following some 'stupid' dream..."

    scene e1s11-19 with dissolve
    fr "And here I am, following someone else's dream and hating myself for it..."

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "I seriously don't get parents that force careers onto their children."
    mc "It's so fucked up to destroy one's dreams like that at such a young age."

    scene e1s11-15 with dissolve
    hide e1s11_francesca_blink2
    fr "Yeah, I didn't get that either..."
    fr "Maybe that's just the way his father taught him to be, who knows?"

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "You might be right, but that still doesn't make it right."
    mc "My father also had a shit father but that doesn't mean he passed that onto me."
    mc "He's been the best father I could have asked for and he always supported me in anything I wanted to do."

    scene e1s11-16 with dissolve
    hide e1s11_francesca_blink2
    fr "..."

    scene e1s11-15 with dissolve
    fr "Looks like we both have had our dreams ruined, huh?"

    scene e1s11-16 with dissolve
    show e1s11_francesca_blink2
    mc "Hah, yeah..."

    scene e1s11-26 with dissolve
    menu:
        "Kiss her":
            call extrovert_affinity_check from _call_extrovert_affinity_check_12
            $ francesca_trust += 1
            $ e1s11_kiss_her = True
            call color_check from _call_color_check_23

            scene e1s11-29 with dissolve
            pause

            scene e1s11-38 with dissolve
            pause

            scene e1s11-29 with dissolve
            pause

            scene e1s11-28 with dissolve
            show e1s11-francesca_blink4
            fr "..."

            scene e1s11-30 with dissolve
            hide e1s11-francesca_blink4
            fr "[mc]... I... I'm sorry, I have to go!"

            scene e1s11-28 with dissolve
            show e1s11-francesca_blink4
            mc "Huh?"
            mc "Why? Did I do something wrong?"

            scene e1s11-36 with dissolve
            hide e1s11-francesca_blink4
            fr "No it's..."

            scene e1s11-37 with dissolve
            fr "..."

            scene e1s11-36 with dissolve
            fr "uh... forget it."

            scene e1s11-31 with dissolve
            fr "Sorry, I must get going!"

            scene e1s11-32 with dissolve
            pause

            scene e1s11-33 with dissolve
            pause

            scene e1s11-35 with dissolve
            pause

            scene e1s11-34 with dissolve
            pause

            scene black with Dissolve(2.0)

            scene e1s11-42 with Dissolve(2.0)
            mc "*We had a pretty nice conversation.*"
            mc "*I really felt like we had a connection there.*"

            scene e1s11-41 with dissolve
            mc "*Why did she leave so suddenly though...*"
            mc "*Did I do something wrong?*"
            mc "*It seemed like she wanted to kiss me too.*"
            mc "*Why was she so scared?*"
            mc "*Maybe things moved way too fast...*"

        "Don't kiss her":
            call introvert_affinity_check from _call_introvert_affinity_check_10
            call color_check from _call_color_check_24
            scene e1s11-26 with dissolve
            pause

            scene e1s11-15 with dissolve
            fr "Well, I better get going, it's getting pretty late."
            fr "It was nice talking to you [mc]."

            scene e1s11-13 with dissolve
            show e1s11_francesca_blink2
            mc "Nice talking to you as well."
            mc "Oh and also, thanks for the meal!"

            scene e1s11-14 with dissolve
            hide e1s11_francesca_blink2
            fr "No problem!"
            fr "See you around!"

            scene e1s11-13 with dissolve
            show e1s11_francesca_blink2
            mc "Alright, bye!"

            scene e1s11-32 with dissolve
            pause

            scene e1s11-33 with dissolve
            pause

            scene black with Dissolve(2.0)

            scene e1s11-42 with Dissolve(2.0)
            mc "*We had a pretty nice conversation.*"
            mc "*I really felt we had a connection there.*"
            mc "*I really enjoyed the night with her.*"
            mc "*I have this weird feeling that I should have probably kissed her...*"

    jump e1s12
return
