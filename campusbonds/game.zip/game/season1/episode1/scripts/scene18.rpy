
# Scene 18 - Unfortunate turn of events ########################################

label e1s18:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    play music wonder_under
    scene e1s18-01 with Dissolve(2.0)
    mc "*Back at my dorm once again.*"

    scene e1s18-02 with dissolve
    pause

    play sound door_open
    scene e1s18-03 with dissolve
    nt "What's up bro?"

    scene e1s18-04 with dissolve
    nt "Glad to see you finally move in."

    scene e1s18-05 with dissolve
    show e1s18-nate_blink1
    mc "Yeah, I thought it was time I got the full uni experience."

    scene e1s18-04 with dissolve
    hide e1s18-nate_blink1
    nt "Haha, I see."

    scene e1s18-06 with dissolve
    nt "For me, it's all been boring until now."

    scene e1s18-07 with dissolve
    nt "I just found out about this freshies party happening tonight and I heard it's gonna be wild."

    scene e1s18-05 with dissolve
    show e1s18-nate_blink1
    mc "Oh, you found out as well?"
    mc "One of my friends told me about it yesterday."

    scene e1s18-07 with dissolve
    hide e1s18-nate_blink1
    nt "That's awesome!"

    scene e1s18-04 with dissolve
    nt "I'm really excited."

    scene e1s18-05 with dissolve
    show e1s18-nate_blink1
    mc "Yeah, me too."
    mc "I'm really curious about how it's going to be."

    scene e1s18-07 with dissolve
    hide e1s18-nate_blink1
    nt "Well, better get prepared for it then."

    stop music fadeout 2.0
    play sound phone_buzz
    scene e1s18-08 with dissolve
    pause

    play music the_darker_side
    scene e1s18-21 with dissolve
    jn "Hey [mc], what's up?"

    scene e1s18-09 with dissolve
    mc "Hey [jon], getting prepared for the party, you?"

    scene e1s18-22 with dissolve
    jn "About that..."

    scene e1s18-25 with dissolve
    jn "The party's off."

    scene e1s18-10 with dissolve
    mc "Huh?"
    mc "What happened?"

    scene e1s18-23 with dissolve
    jn "We were out getting some of the things that were missing for our last touches..."

    scene e1s18-29 with dissolve
    jn "...and when we came back we found the place trashed."

    scene e1s18-24 with dissolve
    jn "We don't know who could have done that or why, but we can't hold the party anymore..."

    scene e1s18-25 with dissolve
    jn "I'm sorry."

    scene e1s18-11 with dissolve
    mc "Hey, don't be!"

    scene e1s18-09 with dissolve
    mc "Want some help with cleaning up?"

    scene e1s18-21 with dissolve
    jn "Nah, we got this."

    scene e1s18-23 with dissolve
    jn "If you're still in the mood for partying, there's another club you can go to."

    scene e1s18-24 with dissolve
    jn "It's near the gym."

    scene e1s18-21 with dissolve
    jn "That's where some of the people that were supposed to come tonight will go."

    scene e1s18-23 with dissolve
    jn "It's fully rented so you don't have to worry about unwanted visitors."

    scene e1s18-12 with dissolve
    mc "I see..."

    scene e1s18-09 with dissolve
    mc "Well, I'm sorry about what happened and good luck restoring the place."

    scene e1s18-11 with dissolve
    mc "If you need a helping hand, you know who to call."

    scene e1s18-21 with dissolve
    jn "Alright, thanks."
    jn "Have fun partying tonight."

    scene e1s18-09 with dissolve
    mc "Thanks!"

    scene e1s18-13 with dissolve
    pause

    scene e1s18-14 with dissolve
    nt "What's happening?"

    scene e1s18-15 with dissolve
    mc "The party's off, man."

    scene e1s18-16 with dissolve
    nt "It's off?"
    nt "Why??"

    scene e1s18-17 with dissolve
    mc "Well, one of my friends who's organizing it just called me saying that they found the place trashed."

    scene e1s18-19 with dissolve
    mc "They can't hold the party anymore..."

    scene e1s18-18 with dissolve
    nt "Oh, dang it..."

    scene e1s18-14 with dissolve
    nt "Are they still gonna hold it this year?"

    scene e1s18-19 with dissolve
    mc "Well, I'm not entirely sure..."

    scene e1s18-17 with dissolve
    mc "I didn't ask him, but knowing how my friend is, he will most probably try and redo it."

    scene e1s18-14 with dissolve
    nt "So, what are we gonna do now?"

    scene e1s18-17 with dissolve
    mc "He told me there's another club near the gym."
    mc "We should go there."

    stop music fadeout 4.0
    scene e1s18-18 with dissolve
    nt "Damn, can this day get any worse?"

    scene e1s18-20 with dissolve
    mc "*I wonder who did it...*"

    play music savage
    scene e1s18-26 with wipeleft
    pause

    scene e1s18-27 with dissolve
    nt "So, who do you think we're gonna meet there?"

    scene e1s18-28 with dissolve
    mc "Well, most probably freshies and a couple of older students."

    scene e1s18-30 with dissolve
    mc "Jon told me that the club is fully rented so only UPL students are allowed."

    scene e1s18-31 with dissolve
    nt "Shit, I think I left my student card at the dorm."

    stop music fadeout 3.0
    scene e1s18-32 with dissolve
    mc "Let's hope they won't ask for it."

    play music galaxies
    scene e1s18-33 with wipeleft
    pause

    scene e1s18-34 with dissolve
    bo "Where do you think you're going?"

    scene e1s18-35 with dissolve
    bo "Student card and ID please."

    scene e1s18-37 with dissolve
    nt "Hey man, look, I'm sorry but I don't have my student card on me."

    scene e1s18-36 with dissolve
    nt "But I can prove in some other ways that I'm a student."

    scene e1s18-38 with dissolve
    bo "Sorry, no student card, no entry."

    if sadie_trust == tracy_trust or sadie_trust < 4 and tracy_trust < 4:
        $ e1s18_ken_greet = True
        scene e1s18-39 with dissolve
        pause

        scene e1s18-42 with dissolve
        ke "Hi guys."

        scene e1s18-43 with dissolve
        ke "What's up?"

        scene e1s18-44 with dissolve
        show e1s18-ken_blink1
        mc "We're kind of trying to get in but my friend [nt] here forgot his student card."

        scene e1s18-45 with dissolve
        hide e1s18-ken_blink1
        ke "Oh shit, that's a bummer."

        scene e1s18-46 with dissolve
        show e1s18-ken_blink1
        mc "Yeah... we're most probably going to have to head back to get it."

        scene e1s18-45 with dissolve
        hide e1s18-ken_blink1
        ke "But you'll miss all the fun!"

        scene e1s18-47 with dissolve
        ke "Let me call [jon] and see if he can work something out."

        scene e1s18-46 with dissolve
        show e1s18-ken_blink1
        mc "What does [jon] have to do with this?"

        scene e1s18-48 with dissolve
        hide e1s18-ken_blink1
        ke "This is the bouncer that was supposed to be at Eddy's."

        scene e1s18-49 with dissolve
        ke "He's usually pretty nice..."

        scene e1s18-50 with dissolve
        ke "But tonight he's got strict orders."

        scene e1s18-51 with dissolve
        ke "{b}Don't let anyone in without a student card.{/b}"

        scene e1s18-52 with dissolve
        mc "He doesn't seem too friendly."

        scene e1s18-45 with dissolve
        ke "If [jon]'s in the planning group, maybe he'll listen to him."

        scene e1s18-46 with dissolve
        show e1s18-ken_blink1
        mc "Alright, I guess it's worth a shot."
        mc "It's not like we have anything to lose."

        scene e1s18-47 with dissolve
        hide e1s18-ken_blink1
        ke "Okay, let me see what I can do."

        scene e1s18-53 with dissolve
        ke "Hey [jon], what's up?"

        scene e1s18-54 with dissolve
        ke "Yeah... I'm good."

        scene e1s18-55 with dissolve
        ke "I see..."

        scene e1s18-56 with dissolve
        ke "How's the club looking?"

        scene e1s18-61 with dissolve
        pause

        scene e1s18-57 with dissolve
        ke "Listen... [jon]... this is why I called you."

        scene e1s18-58 with dissolve
        ke "[mc]'s here with one of his friends..."
        ke "...problem is, his friend forgot his student card."

        scene e1s18-56 with dissolve
        ke "Do you think we can work something out?"

        scene e1s18-61 with dissolve
        pause

        scene e1s18-58 with dissolve
        ke "Alright, I'll put you on speaker."

        scene e1s18-59 with dissolve
        ke "[jon] wants to talk to you."

        scene e1s18-60 with dissolve
        pause

        scene e1s18-62 with dissolve
        mc "Do you think it'll work?"

        scene e1s18-63 with dissolve
        nt "I hope so..."

        scene e1s18-64 with dissolve
        pause

        scene e1s18-66 with dissolve
        bo "Alright, you can go in."

        scene e1s18-65 with dissolve
        pause

        scene e1s18-67 with wipeleft
        mc "Holy shit, I can't believe [jon] really did it."

        scene e1s18-68 with dissolve
        ke "It wasn't even that hard."

        scene e1s18-69 with dissolve
        ke "The moment [jon] started talking to him, he instantly turned into this friendly guy."

    if e1s18_tracy_greet == False and sadie_trust >= 4:
        $ e1s18_sadie_greet = True
        scene e1s18-40 with dissolve
        pause

        scene e1s18-86 with dissolve
        sd "Hey [mc]!"

        scene e1s18-77 with dissolve
        sd "Come on in!"

        scene e1s18-78 with dissolve
        show e1s18-sadie_blink1
        mc "I'd love to, but I'm afraid we're not allowed to."

        hide e1s18-sadie_blink1
        scene e1s18-79 with dissolve
        show e1s18-sadie_blink1
        mc "My roomie here [nt] forgot his student card and the bouncer won't let us in."

        scene e1s18-80 with dissolve
        hide e1s18-sadie_blink1
        pause

        scene e1s18-81 with dissolve
        sd "What do you mean by 'us'?"
        sd "You didn't forget it, did you?"

        scene e1s18-82 with dissolve
        mc "I didn't..."

        scene e1s18-85 with dissolve
        mc "But I can't just abandon him."

        scene e1s18-84 with dissolve
        sd "Right, I'm sorry..."

        scene e1s18-83 with dissolve
        sd "Let me see what I can do."

        scene e1s18-87 with dissolve
        pause

        scene e1s18-88 with dissolve
        pause

        scene e1s18-89 with dissolve
        pause

        scene e1s18-90 with dissolve
        pause

        scene e1s18-91 with dissolve
        pause

        scene e1s18-92 with dissolve
        mc "Damn..."

        scene e1s18-93 with dissolve
        pause

        scene e1s18-62 with dissolve
        mc "What do you think they're talking about?"

        scene e1s18-63 with dissolve
        nt "I don't know..."
        nt "If it works then I'm happy."

        scene e1s18-94 with dissolve
        pause

        scene e1s18-66 with dissolve
        bo "Alright, you can go."

        scene e1s18-95 with dissolve
        nt "Thanks a lot man!"

        scene e1s18-96 with dissolve
        mc "Haha, what did you tell him?"

        scene e1s18-97 with dissolve
        sd "You got in, didn't you?"

        scene e1s18-98 with dissolve
        sd "Don't worry about it."

    if e1s18_sadie_greet == False and tracy_trust >= 4:
        $ e1s18_tracy_greet = True
        scene e1s18-41 with dissolve
        pause

        scene e1s18-99 with dissolve
        tr "[mc]? What's going on?"

        scene e1s18-103 with dissolve
        mc "Hi [tr]!"
        mc "We're trying to get in but my friend here doesn't have his student card on him."

        scene e1s18-105 with dissolve
        tr "How did that happen?"

        scene e1s18-103 with dissolve
        mc "I don't know..."
        mc "I don't think he even knew he needed it to begin with."

        scene e1s18-105 with dissolve
        tr "That's really unfortunate."

        scene e1s18-100 with dissolve
        tr "Hey, let me work my magic."

        scene e1s18-101 with dissolve
        tr "See if I can get you inside."

        scene e1s18-102 with dissolve
        show e1s18-tracy_blink1
        mc "Haha, what do you mean?"

        scene e1s18-104 with dissolve
        hide e1s18-tracy_blink1
        tr "Just watch me."

        scene e1s18-106 with dissolve
        pause

        scene e1s18-107 with dissolve
        pause

        scene e1s18-108 with dissolve
        pause

        scene e1s18-109 with dissolve
        mc "*What the... they're leaving?*"

        scene e1s18-110 with dissolve
        pause

        scene e1s18-109 with dissolve
        mc "*Haha, thank you [tr].*"

        scene e1s18-111 with dissolve
        pause

        scene e1s18-112 with dissolve
        pause

    scene e1s18-70 with dissolve
    nt "Dude..."

    scene e1s18-72
    nt "this..."

    scene e1s18-71
    nt "...is..."

    if tracy_trust >= 4:
        scene e1s18-113 with vpunch
    else:
        scene e1s18-73 with vpunch
    nt "{b}AWESOME!{/b}"

    scene e1s18-74 with dissolve
    nt "We're gonna have so much fun!!"

    scene e1s18-75 with dissolve
    mc "Haha, slow down dude."

    scene e1s18-76 with dissolve
    nt "I'm so excited, I don't even know where to begin."

    jump e1f5
return
