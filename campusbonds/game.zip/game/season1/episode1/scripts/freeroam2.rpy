
label f2_living:
    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-01
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-01-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-01-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_interact == 4:
        scene e1f2-01-3

    call screen f2_living with dissolve
return

label f2_kitchen:

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-02
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-02-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-02-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-02-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-02-4
    if e1f2_interact == 4:
        scene e1f2-02-3

    call screen f2_kitchen with dissolve
return

label f2_bedroom:
    scene bd-e1f2-01 with dissolve
    mc "Hmm... it's locked."
    mc "Looks like Jon doesn't want anyone snooping around in his room during parties."

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-01
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-01-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-01-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_interact == 4:
        scene e1f2-01-3

    call screen f2_living with dissolve
return

label f2_bathroom:
    scene e1f1-05
    call screen f2_bathroom with dissolve
return

label f2_sadie_tracy:
    scene ts-e1f2-01 with dissolve
    pause
    mc "*Looks like they're talking about something...*"

    scene ts-e1f2-02 with dissolve
    unknown "[tr], I'm telling you, there's no way that happens."

    scene ts-e1f2-03 with dissolve
    tr "Come on [sd]!"
    tr "Live a little."

    scene ts-e1f2-04 with dissolve
    menu:
        "Check them out":
            $ tracy_trust += 1
            $ sadie_trust += 1

            scene ts-e1f2-07 with dissolve
            pause

            scene ts-e1f2-08 with dissolve
            pause
        "Don't check them out":
            pass

    scene ts-e1f2-05 with dissolve
    sd "Hey, [jon]'s party tonight is great!"

    scene ts-e1f2-06 with dissolve
    tr "Yeah, woo!"

    scene ts-e1f2-09 with dissolve
    pause

    scene ts-e1f2-10 with dissolve
    jn "Glad you're enjoying yourself girls."

    scene ts-e1f2-11 with dissolve
    jn "Meet my friend here, [mc]."
    jn "He's a freshie."

    scene ts-e1f2-13 with dissolve
    tr "Ohh, I wonder how drunk we can get him!"

    scene ts-e1f2-12 with dissolve
    sd "Yeah, haha!"

    scene ts-e1f2-14 with dissolve
    jn "Ladies, ladies..."
    jn "Calm down."

    scene ts-e1f2-10 with dissolve
    jn "The night is still young!"
    jn "We have all the time in the world!"

    scene ts-e1f2-02 with dissolve
    sd "Come on [tr], I wanna have a smoke."

    scene ts-e1f2-15 with dissolve
    pause

    scene ts-e1f2-16 with dissolve
    jn "So... tell me [mc]..."
    jn "Which one do you like?"

    scene ts-e1f2-17 with dissolve
    show ts-e1f2-17_jon_blink1
    menu:
        "[sd]":
            $ sadie_trust += 2
            mc "Well, [sd] looks particularly cute to me."

            scene ts-e1f2-16 with dissolve
            hide ts-e1f2-17_jon_blink1
            jn "A man of culture I must say."
            jn "If I were you, I would probably choose the same."
            jn "I'm not really digging the way [tr]'s face looks..."
            jn "Also, don't tell her I said that."

            scene ts-e1f2-17 with dissolve
            show ts-e1f2-17_jon_blink1
            mc "You're so dumb."

            scene ts-e1f2-16 with dissolve
            hide ts-e1f2-17_jon_blink1
            jn "Just know that I'm here to support you tonight alright?"
            jn "So... anything you 'need', I'm here to help."

            scene ts-e1f2-17 with dissolve
            show ts-e1f2-17_jon_blink1
            mc "What is that supposed to mean?"

            scene ts-e1f2-16 with dissolve
            hide ts-e1f2-17_jon_blink1
            jn "Just keep that in mind, you'll figure it out when the opportunity arises."

        "[tr]":
            $ tracy_trust += 2
            mc "I like how [tr] looks."

            scene ts-e1f2-16 with dissolve
            hide ts-e1f2-17_jon_blink1
            jn "Ohh, I get it."
            jn "So, you're into big asses!"
            jn "I'm not judging."
            jn "Quite the opposite, a wise choice I must say."
            jn "I wouldn't personally choose her but if that's what the dick wants then that's what the dick gets."

            scene ts-e1f2-17 with dissolve
            show ts-e1f2-17_jon_blink1
            menu:
                "Badmouth":
                    mc "She really is packing!"

                    scene ts-e1f2-16 with dissolve
                    hide ts-e1f2-17_jon_blink1
                    jn "Told ya!"
                    jn "Have fun tonight."
                    jn "'Winks'."

                "Don't badmouth":
                    $ tracy_trust += 1
                    mc "That's not why I like her..."

                    scene ts-e1f2-16 with dissolve
                    hide ts-e1f2-17_jon_blink1
                    jn "Yeah, 'sure' bro, whatever."
                    jn "Just have fun tonight alright?"

    jn "I gotta run now, my services are needed somewhere else."

    scene ts-e1f2-17 with dissolve
    show ts-e1f2-17_jon_blink1
    mc "Where?"
    mc "There's literally nowhere to run in this tiny apartment."

    scene ts-e1f2-18 with dissolve
    hide ts-e1f2-17_jon_blink1
    jn "Over and out."

    $ e1f2_sadie_tracy += True

    $ e1f2_interact += 1

    if e1f2_interact == 4:
        $ current_quests.remove("Interact with people.")

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-01
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-01-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-01-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-3
    call screen f2_living with dissolve
return

label f2_jon:
    scene jn-e1f2-01 with dissolve
    pause

    scene jn-e1f2-02 with dissolve
    jn "So?"
    jn "Is it working??"

    scene jn-e1f2-03 with dissolve
    jd "Almost..."

    scene jn-e1f2-04 with dissolve
    jd "I just need to adjust it to get to the right frequency."

    scene jn-e1f2-05 with dissolve
    mc "What's up guys?"

    scene jn-e1f2-06 with dissolve
    jn "Hey [mc]!"
    jn "Me and [jd] are trying to set up a prank."

    scene jn-e1f2-07 with dissolve
    show jn-e1f2_jon_blink1
    mc "What kind of prank?"

    scene jn-e1f2-08 with dissolve
    hide jn-e1f2_jon_blink1
    jd "Just come and see for yourself."

    scene jn-e1f2-09 with dissolve
    jd "So..."

    scene jn-e1f2-10 with dissolve
    jd "Okay, it's all set."

    scene jn-e1f2-11 with dissolve
    jd "So... first of all look to your right."

    scene jn-e1f2-12 with dissolve
    jd "There's a 'special' tree at the end of the road..."

    scene jn-e1f2-13 with dissolve
    jd "And it has a little something installed."
    jd "I made sure that it works as intended."

    scene jn-e1f2-10 with dissolve
    jd "And now we just wait for the victim..."

    scene jn-e1f2-14 with dissolve
    jd "There it is!!"

    scene jn-e1f2-15 with dissolve
    jd "Prepare yourself ladies."

    scene jn-e1f2-16 with dissolve
    jd "..."

    scene jn-e1f2-17 with dissolve
    play sound walkie_talkie
    jd "STOP RIGHT THERE! YOU'RE UNDER ARREST!"

    scene jn-e1f2-10 with dissolve
    jd "Haha!"

    scene jn-e1f2-19 with dissolve
    jn "Bro I can't believe it worked!"

    scene jn-e1f2-18 with dissolve
    jn "What do you think [mc]?"

    scene jn-e1f2-20 with dissolve
    menu:
        "It's stupid":
            call introvert_affinity_check from _call_introvert_affinity_check
            call color_check from _call_color_check

            scene jn-e1f2-22 with dissolve
            mc "Sorry to ruin the mood but I think this is all stupid."

            scene jn-e1f2-23 with dissolve
            jd "Bro... you're no fun..."

        "It's funny":
            call extrovert_affinity_check from _call_extrovert_affinity_check
            call color_check from _call_color_check_1

            scene jn-e1f2-21 with dissolve
            mc "Haha! It was pretty funny."

            scene jn-e1f2-10 with dissolve
            jd "I know right?"
            jd "My best invention yet."

    $ e1f2_jon = True

    $ e1f2_interact += 1

    if e1f2_interact == 4:
        $ current_quests.remove("Interact with people.")

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-02
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-02-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-02-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-02-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-02-3
    call screen f2_kitchen with dissolve
return

label f2_sadie:
    $ e1f2_sadie = True

    scene s-e1f2-01 with dissolve
    mc "*Why is she sitting alone?*"

    scene s-e1f2-02 with dissolve
    pause
    mc "Hey, what's wrong?"

    scene s-e1f2-03 with dissolve
    pause

    scene s-e1f2-05 with dissolve
    sd "[mc], right?"

    scene s-e1f2-04 with dissolve
    show s_e1f2_sadie_blink1
    mc "That's me."

    scene s-e1f2-05 with dissolve
    hide s_e1f2_sadie_blink1
    sd "Can you keep a secret?"
    sd "I need to unload myself on someone and since we're strangers there's no commitment."

    scene s-e1f2-04 with dissolve
    show s_e1f2_sadie_blink1
    mc "Alright, go on..."

    scene s-e1f2-05 with dissolve
    hide s_e1f2_sadie_blink1
    sd "So, I met this guy a couple of weeks ago and we've been kind of hanging out..."

    scene s-e1f2-06 with dissolve
    sd "To be completely honest, it's all been very weird because I don't know what we are exactly."

    scene s-e1f2-05 with dissolve
    sd "Anyways, so I'm texting this guy..."

    scene s-e1f2-07 with dissolve
    sd "...and I've SPECIFICALLY told him that I'm going to a party tonight and I invited him to come with me."

    scene s-e1f2-05 with dissolve
    sd "He got pretty mad over it and we fought..."

    scene s-e1f2-06 with dissolve
    sd "...he said something along the lines of 'I don't make time for him' and that 'I'm always partying' and shit like this."
    sd "This is my first party in like 2 months, I haven't even gone to a single party since I've met him."

    scene s-e1f2-05 with dissolve
    sd "To be honest, I don't even know what to make of this, am I in the right or in the wrong?"

    scene s-e1f2-08 with dissolve
    sd "It's not like I didn't let him know about the type of person I am beforehand."

    scene s-e1f2-05 with dissolve
    sd "And I've always tried making time for him..."

    scene s-e1f2-04 with dissolve
    show s_e1f2_sadie_blink1
    mc "Do you want my honest oppinion about this?"

    scene s-e1f2-05 with dissolve
    hide s_e1f2_sadie_blink1
    sd "I would love to hear your thoughts."

    scene s-e1f2-04 with dissolve
    show s_e1f2_sadie_blink1
    menu:
        "Side with her":
            $ sadie_trust += 1
            mc "Well, from what you've told me it's pretty obvious that he's in the wrong."

            show s-e1f2-09 behind s_e1f2_sadie_blink1 with dissolve
            mc "The fact that he already knows you and decides to act like this is so shit."
            mc "It feels as if he got bored of you."

            scene s-e1f2-11 with dissolve
            hide s_e1f2_sadie_blink1
            hide s-e1f2-09
            sd "I know right??"

            scene s-e1f2-10 with dissolve
            sd "That's what I've been thinking about."

            scene s-e1f2-06 with dissolve
            sd "I mean, he's never been the perfect guy but at least when we first talked he wasn't such a jackass."

            scene s-e1f2-04 with dissolve
            show s_e1f2_sadie_blink1
            mc "What I would do if I were you is to break things up."

            show s-e1f2-09 behind s_e1f2_sadie_blink1 with dissolve
            mc "I mean, what's the point of continuing this 'almost relationship' if he acts so childish?"

            scene s-e1f2-11 with dissolve
            hide s_e1f2_sadie_blink1
            hide s-e1f2-09
            sd "Haha, yeah!"
            sd "He should just grow up."

            scene s-e1f2-10 with dissolve
            sd "Thanks [mc]!"
            sd "This really made me feel better."

        "Be impartial":
            mc "It seems as if you care about him."
            mc "What I would try to do if I were you is to talk it over and make things right."
            mc "From what you've told me, it seems as if he is in the wrong but I don't know the whole context, maybe there's more to his side than meets the eye."
            mc "I'm not trying to say that you're right or he's wrong..."
            mc "...I'm just saying that you should just talk to him and sort it out."

            scene s-e1f2-05 with dissolve
            hide s_e1f2_sadie_blink1
            sd "I've been trying to talk to him and to make him open up to me but it's like he's a rock."

            scene s-e1f2-04 with dissolve
            show s_e1f2_sadie_blink1
            mc "Then the only logical thing to do here is to break things up."

            show s-e1f2-09 behind s_e1f2_sadie_blink1 with dissolve
            mc "If you can't find a middle ground then what's the point?"

            scene s-e1f2-10 with dissolve
            hide s_e1f2_sadie_blink1
            hide s-e1f2-09
            sd "Hey, thanks!"
            sd "It feels good having someone to talk to."

    scene s-e1f2-09 with dissolve
    show s_e1f2_sadie_blink1
    mc "Well, I'm glad I could be of help."
    mc "Let's go back to partying, shall we?"

    $ e1f2_interact += 1

    if e1f2_interact == 4:
        $ current_quests.remove("Interact with people.")

    scene s-e1f2-11 with dissolve
    hide s_e1f2_sadie_blink1
    sd "Haha, sure!"

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-01
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-01-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-01-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_interact == 4:
        scene e1f2-01-3
    call screen f2_living with dissolve
return

label f2_ken:
    $ e1f2_ken = True
    scene k-e1f2-01 with dissolve
    pause

    scene k-e1f2-02 with dissolve
    ke "What's up [mc]!"

    scene k-e1f2-03 with dissolve
    show ke-e1f2-ken_blink1
    mc "Hi [ke]!"
    mc "Enjoying the party?"

    scene k-e1f2-02 with dissolve
    hide ke-e1f2-ken_blink1
    ke "Yeah!"
    ke "I'm kind of surprised because [jon] doesn't typically throw these kind of parties."
    ke "He says that it's a lot of work to clean up afterwards."

    scene k-e1f2-03 with dissolve
    show ke-e1f2-ken_blink1
    mc "I can see that being a problem."

    scene k-e1f2-02 with dissolve
    hide ke-e1f2-ken_blink1
    ke "Well, for us it was never a problem..."
    ke "...because we've always wanted to stay a little longer and help him with cleaning but he doesn't want our help."
    ke "He says that it's his job as an organizer to take care of everything."

    scene k-e1f2-03 with dissolve
    show ke-e1f2-ken_blink1
    mc "Oh, I see!"
    mc "That's pretty nice of him to be honest."

    scene k-e1f2-02 with dissolve
    hide ke-e1f2-ken_blink1
    ke "It's not something you hear too often about [jon], but yeah, it's nice."

    scene k-e1f2-03 with dissolve
    show ke-e1f2-ken_blink1
    mc "Well, it was nice talking to you [ke]."
    mc "I'm gonna go and meet some other people."

    $ e1f2_interact += 1

    if e1f2_interact == 4:
        $ current_quests.remove("Interact with people.")

    scene k-e1f2-02 with dissolve
    hide ke-e1f2-ken_blink1
    ke "Alright, have fun!"

    if e1f2_jon == False and e1f2_sadie_tracy == False:
        scene e1f2-01
    if e1f2_jon == True and e1f2_sadie_tracy == False:
        scene e1f2-01-1
    if e1f2_jon == False and e1f2_sadie_tracy == True:
        scene e1f2-01-2
    if e1f2_sadie == False and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_sadie == True and e1f2_jon == True and e1f2_sadie_tracy == True:
        scene e1f2-01-4
    if e1f2_interact == 4:
        scene e1f2-01-3
    call screen f2_living with dissolve
return

label f2_shots:
    $ collected_p = persistent.e1f2_collected_p
    $ collected_tp = persistent.e1f2_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            scene sh-e1f2-01 with dissolve
            $ renpy.hide_screen("render_count_notify_pers")
            pause

            scene sh-e1f2-02 with dissolve
            pause

            scene sh-e1f2-03 with dissolve
            jn "[mc]!!"

            scene sh-e1f2-24 with dissolve
            jn "I've got a surprise for you."
            jn "Why don't you go ahead and take a look at [tr]?"

            scene sh-e1f2-04 with dissolve
            pause

            scene sh-e1f2-05 with dissolve
            pause

            scene sh-e1f2-24 with dissolve
            jn "I want you to drink that shot from her tits without hands."

            scene sh-e1f2-05 with dissolve
            pause

            scene sh-e1f2-06 with dissolve
            pause

            scene sh-e1f2-07 with dissolve
            pause

            if affinity_spectrum > 0:
                scene sh-e1f2-08 with dissolve
                jn "Wooo!!"
                jn "Grab her."

            scene sh-e1f2-09 with dissolve
            pause

            scene sh-e1f2-12 with dissolve
            jn "Nice!"
            jn "Just like that."

            scene sh-e1f2-13 with dissolve
            jn "Come on guys, cheer him up!"

            scene sh-e1f2-10 with dissolve
            pause

            scene sh-e1f2-11 with dissolve
            show sh-e1f2-tracy_blink1
            if affinity_spectrum > 0 and tracy_trust >= 1:
                menu:
                    "Kiss her":
                        $ e1f2_tracy_kiss = True
                        $ tracy_trust += 1
                        call extrovert_affinity_check from _call_extrovert_affinity_check_1
                        call color_check from _call_color_check_2

                        scene sh-e1f2-14 with dissolve
                        hide sh-e1f2-tracy_blink1
                        pause

                        scene sh-e1f2-15 with dissolve
                        pause

                        scene sh-e1f2-16 with dissolve
                        jn "Nice!!!"

                        scene sh-e1f2-17 with dissolve
                        pause

                        scene sh-e1f2-11 with dissolve
                        tr "Mmmm..."

                        scene sh-e1f2-25 with dissolve
                        tr "You're a good kisser!"

                    "Don't kiss her":
                        call color_check from _call_color_check_3
                        scene sh-e1f2-18 with dissolve
                        hide sh-e1f2-tracy_blink1
                        pause

            else:
                pause

            scene sh-e1f2-19 with dissolve
            pause

            scene sh-e1f2-20
            pause

            scene sh-e1f2-21
            pause

            scene sh-e1f2-22
            pause

            scene sh-e1f2-23
            pause

            scene black
            stop music
            pause
            jump e1s9

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            jump f2_living

return

# Free roam #2 Variables #######################################################
default e1f2_sadie_tracy = False
default e1f2_sadie = False
default e1f2_jon = False
default e1f2_ken = False

default e1f2_interact = 0

# Freeroam Collected Photos #

default persistent.e1f2_collected_p = 0
default persistent.e1f2_collected_tp = 3

################################################################################

label freeroam2:
    define f2_tracks = ["party/instrumentals/2010_pop.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/turn_up.ogg"]

    $ renpy.music.queue (f2_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")

    scene e1f2-01 with dissolve
    call screen f2_living
    hide e1f2-01
return
