# Variables ####################################################################

default e1f3_roman_ken = False
default e1f3_raven = False
default e1f3_nate = False
default e1f3_rk_first = False
default e1f3_eavesdrop = False
default e1f3_money = False

default e1f3_hallway = False

default e1f3_explore = 0

# Freeroam Collected Photos #

default persistent.e1f3_collected_p = 0
default persistent.e1f3_collected_tp = 4

# Room 34 ######################################################################

label e1f3_room34_right:
    scene e1f3-02

    call screen e1f3_room34_right with dissolve
return

label e1f3_room34_default:
    scene e1f3-01

    call screen e1f3_room34_default with dissolve
return

# Hallway ######################################################################

label e1f3_hallway_1:
    if e1f3_hallway == False:
        $ current_quests.remove("Leave the room.")

        $ current_quests.append("Talk to Ken and Roman.")
        $ current_quests.append("Talk to the unknown girl.")
        $ current_quests.append("Explore the place.")

        $ e1f3_hallway = True
    scene e1f3-03 with Dissolve(0.5)
    call screen e1f3_hallway_1 with dissolve
return

label e1f3_hallway_exit:
    $ collected_p = persistent.e1f3_collected_p
    $ collected_tp = persistent.e1f3_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    scene e1f3-03
    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            jump e1s11
        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")
            pass

    call screen e1f3_hallway_1 with dissolve
return

label e1f3_hallway_2:
    scene e1f3-04

    call screen e1f3_hallway_2 with dissolve
return

label e1f3_hallway_3:
    if e1f3_eavesdrop == False:
        scene sp_e1f3-01 with dissolve
        pause

        scene sp_e1f3-02 with dissolve
        mc "*Huh? Someone's arguing next door.*"

        scene sp_e1f3-03 with dissolve
        unknown "Look, [sp], I'm sorry!"
        unknown "I lost it, alright?"
        unknown "I promise, I'm gonna make it up to you next month."
        sp "Next month?!"
        sp "Next month ain't gonna cut it."
        sp "We're already short and you're bringing me excuses like these."
        sp "I don't know what to tell you."
        sp "Seriously, I don't know!"
        sp "We're fucked if we don't find it."
        unknown "I'll find it and I'll make it right, I promise!"
        sp "I'm gonna leave now."
        sp "You better have {b}it{/b} when I come back, otherwise I don't know what I'll do!"

        scene sp_e1f3-04 with dissolve
        pause

        scene sp_e1f3-05 with dissolve
        pause

        scene sp_e1f3-06 with dissolve
        pause

        scene sp_e1f3-07 with dissolve
        pause

        $ e1f3_eavesdrop = True

        $ current_quests.remove("Explore the place.")

        $ e1f3_explore += 1

        if e1f3_explore == 4:
            $ current_quests.append("Go back to Jon's apartment.")

    scene e1f3-05 with Dissolve(0.5)

    call screen e1f3_hallway_3 with dissolve
return

# Clickables ###################################################################

label e1f3_roman_ken:
    $ e1f3_roman_ken = True

    scene rk_e1f3-01 with dissolve
    pause

    scene rk_e1f3-07 with dissolve
    ke "Bro, I've already told you, it's the shit!"

    scene rk_e1f3-02 with dissolve
    ro "Man, {b}you're{/b} full of shit!"
    ro "I've tried it and I didn't like it."
    ro "Multiple times even."

    scene rk_e1f3-07 with dissolve
    ke "Bro, it's an acquired taste."
    ke "Wine and coke takes time to get used to."
    ke "I'm telling you, it has become my favourite drink."

    scene rk_e1f3-04 with dissolve
    mc "Hey guys!"
    mc "What's up?"

    scene rk_e1f3-05 with dissolve
    ro "Sup [mc]!"

    scene rk_e1f3-06 with dissolve
    ke "We're just hanging around."
    ke "Waiting for some pussy to show up."

    scene rk_e1f3-08 with dissolve
    ro "Haha!"
    ro "You sound just like [jon]."

    scene rk_e1f3-04 with dissolve
    mc "If you're looking for pussy, I think you just missed the one on the right."

    scene rk_e1f3-11 with dissolve
    ro "Who, the emo girl?"

    scene rk_e1f3-12 with dissolve
    ro "Hell no, man!"

    scene rk_e1f3-09 with dissolve
    ke "We might, sometimes, be desperate..."

    scene rk_e1f3-10 with dissolve
    ke "...but even {b}we{/b} wouldn't go that far."

    scene rk_e1f3-12 with dissolve
    ro "Yeah, not cool."

    scene rk_e1f3-04 with dissolve
    mc "Did you know that she's the girl we tried to throw a balloon at?"

    scene rk_e1f3-14 with dissolve
    ke "Wait, for real?"

    scene rk_e1f3-04 with dissolve
    mc "Yeah."
    mc "I remember the shirt she wore that night, looks like she's wearing it again today."

    scene rk_e1f3-12 with dissolve
    ro "Well, I've heard that she's really insufferable..."

    if balloon_hit == True:
        scene rk_e1f3-11 with dissolve
        ro "Good thing you hit her with a balloon man."

        scene rk_e1f3-06 with dissolve
        ke "Yeah!"

        scene rk_e1f3-09 with dissolve
        ke "Even if I was against it, when it comes down to her you did good."

        scene rk_e1f3-05 with dissolve
        ro "She so deserved it!"

    if balloon_hit == False:
        scene rk_e1f3-11 with dissolve
        ro "Too bad [jd] didn't hit her that night..."

        scene rk_e1f3-12 with dissolve
        ro "She so deserves it!"

    if e1f3_raven == True:
        scene rk_e1f3-04 with dissolve
        mc "Tell me about it man."
        mc "I've tried talking to her and she is so rude."

        scene rk_e1f3-15 with dissolve
        ro "Why would you do that?"

        scene rk_e1f3-16 with dissolve
        mc "Well, for starters, I didn't think she was so full of herself..."

        if balloon_hit == True:
            mc "And I felt bad for hitting her with the balloon."

        if balloon_hit == False:
            mc "And I felt bad because we wanted to throw a balloon at her."

        scene rk_e1f3-06 with dissolve
        ke "Welcome to the club."
        ke "Everyone hates her and it's not like it's not justified."

        scene rk_e1f3-05 with dissolve
        ro "Yeah!"
        ro "With a personality like that, I'm not surprised."

    if e1f3_raven == False:
        $ e1f3_rk_first = True

        scene rk_e1f3-04 with dissolve
        mc "Why do you say she deserves it?"
        mc "Is she really such a shitty person?"

        scene rk_e1f3-12 with dissolve
        ro "Bro, trust me-"

        scene rk_e1f3-20 with dissolve
        ke "Hey, [mc]..."

        scene rk_e1f3-06 with dissolve
        ke "...to be honest, we haven't talked to her."
        ke "We only heard rumors."
        ke "Why don't you go ahead and talk to her?"
        ke "Maybe she's not that bad..."

        scene rk_e1f3-12 with dissolve
        ro "Uh..."

        scene rk_e1f3-05 with dissolve
        ro "Oh, yeah!"
        ro "Definitely, go and talk to her."
        ro "You know, rumors are just rumors after all."

        scene rk_e1f3-06 with dissolve
        ke "Yeah, for sure!"

        scene rk_e1f3-04 with dissolve
        mc "I feel like you're fucking with me guys."

        scene rk_e1f3-15 with dissolve
        ro "Who, us?"

        scene rk_e1f3-11 with dissolve
        ro "We would never..."

        scene rk_e1f3-09 with dissolve
        ke "Bro, for real now, we only heard rumors."

        scene rk_e1f3-10 with dissolve
        ke "None of us had any real interaction with her."
        ke "Just talk to her and then tell us about it."
        ke "I'm honestly curious right now!"

        scene rk_e1f3-17 with dissolve
        mc "Alright, if you say so..."

    scene rk_e1f3-04 with dissolve
    mc "Also, missed you at the party [ro]."
    mc "Where were you?"

    scene rk_e1f3-11 with dissolve
    ro "Well, unfortunately I had some 'business' I had to take care of..."

    scene rk_e1f3-03 with dissolve
    ke "Come on man, tell him!"
    ke "Why are you avoiding the subject?"

    scene rk_e1f3-02 with dissolve
    ro "Alright, alright..."

    scene rk_e1f3-12 with dissolve
    ro "My mom wanted me home for a family gathering with all my relatives..."

    scene rk_e1f3-13 with dissolve
    menu:
        "Make fun of him":
            call extrovert_affinity_check from _call_extrovert_affinity_check_2
            call color_check from _call_color_check_4
            mc "Bro, you really missed a party for that?"
            mc "You need to get your priorities right."

            scene rk_e1f3-12 with dissolve
            ro "It's not like I had a choice."

            scene rk_e1f3-11 with dissolve
            ro "My mom says it's a 'tradition' so every year she holds that gathering..."

            scene rk_e1f3-12 with dissolve
            ro "And she wants me home for that."

            scene rk_e1f3-03 with dissolve
            ke "You had a choice, stop saying that."
            ke "You could have said no."
            ke "It's not like you don't leave every weekend to go home and miss most of the parties."

            scene rk_e1f3-02 with dissolve
            ro "Come on bro..."
            ro "Don't be like that."

        "Be understanding":
            call introvert_affinity_check from _call_introvert_affinity_check_1
            call color_check from _call_color_check_5
            mc "Well, I guess that family comes first."
            mc "There's gonna be parties and parties but once family is gone, you can't go back and spend more time with them."

            scene rk_e1f3-12 with dissolve
            ro "Finally, someone that gets it."

            scene rk_e1f3-11 with dissolve
            ro "It's not like I fully like it, but my mom is pretty old and who knows how long she's got to live..."

            scene rk_e1f3-03 with dissolve
            ke "Bro... chill!"
            ke "She's barely 60, she's got plenty to live."
            ke "Stop being such a pessimist."

            scene rk_e1f3-02 with dissolve
            ro "You're right..."

    scene rk_e1f3-04 with dissolve
    mc "Well, I'll leave you guys to it."

    scene rk_e1f3-05 with dissolve
    ro "Alright bro, take care!"

    $ current_quests.remove("Talk to Ken and Roman.")

    $ e1f3_explore += 1

    if e1f3_explore == 4:
        $ current_quests.append("Go back to Jon's apartment.")

    scene rk_e1f3-06 with dissolve
    ke "See ya!"

    if e1f3_raven == False:
        scene rk_e1f3-06 with dissolve
        ke "Don't forget to talk to [rv]."

    call e1f3_hallway_1 from _call_e1f3_hallway_1
return

label e1f3_rk_second:

    scene rk_e1f3-04 with dissolve
    mc "You guys are assholes!"

    $ e1f3_rk_first = True

    scene rk_e1f3-18 with dissolve
    ke "Bro, did you really talk to her?"

    scene rk_e1f3-19 with dissolve
    ro "Haha, no way!"

    scene rk_e1f3-07 with dissolve
    ke "I told you bro that my serious face is gonna work."

    scene rk_e1f3-08 with dissolve
    ro "You've gotta teach me this skill sometimes."

    scene rk_e1f3-07 with dissolve
    ke "10 bucks per session and we've got a deal."

    scene rk_e1f3-02 with dissolve
    ro "Man, fuck you!"
    ro "You know I don't have that kind of money, especially for something so useless."

    scene rk_e1f3-03 with dissolve
    ke "It wasn't completely useless, was it?"

    $ e1f3_rk_second = True

    $ optional_quests.remove("Talk to Ken and Roman.")

    scene rk_e1f3-04 with dissolve
    mc "You guys are so stupid..."

    call e1f3_hallway_1 from _call_e1f3_hallway_1_1
return

label e1f3_raven:
    $ e1f3_raven = True

    if e1f3_rk_first == False:
        scene r_e1f3-01 with dissolve
        mc "*Wait, I think I remember this girl...*"

        if balloon_hit == True:
            mc "*It's the girl I hit with a balloon.*"

        if balloon_hit == False:
            mc "*It's the girl [jd] wanted to hit with a balloon.*"

        mc "*Maybe I should apologize to her...*"

    if e1f3_rk_first == True:
        scene r_e1f3-01 with dissolve
        mc "*Well, here goes nothing...*"

    scene r_e1f3-02 with dissolve
    mc "Hi!"

    scene r_e1f3-04 with dissolve
    if e1f3_rk_first == True:
        rv "Hey?"
        rv "Do you need something?"
    else:
        unknown "Hey?"
        unknown"Do you need something?"

    scene r_e1f3-03 with dissolve
    mc "Uh, no?"
    mc "I just wanted to come and say hi."

    scene r_e1f3-04 with dissolve
    if e1f3_rk_first == True:
        rv "Do I know you?"
    else:
        unknown "Do I know you?"

    scene r_e1f3-03 with dissolve
    mc "No?"

    scene r_e1f3-02 with dissolve
    pause

    if balloon_hit == True:
        mc "*Ok, nevermind.*"
        mc "*She really did deserve to be hit with a balloon.*"
        mc "*Thank God I did it.*"

    if balloon_hit == False:
        mc "*Maybe I should have actually hit her with the balloon...*"
        mc "*She deserves it.*"

    scene r_e1f3-04 with dissolve
    if e1f3_rk_first == True:
        rv "Why are you still here?"
        $ optional_quests.append("Talk to Ken and Roman.")
    else:
        unknown "Why are you still here?"

    $ current_quests.remove("Talk to the unknown girl.")

    $ e1f3_explore += 1

    if e1f3_explore == 4:
        $ current_quests.append("Go back to Jon's apartment.")

    scene r_e1f3-03 with dissolve
    mc "*I'm leaving.*"

    call e1f3_hallway_1 from _call_e1f3_hallway_1_2
return

label e1f3_nate:
    $ e1f3_nate = True

    scene n_e1f3-01 with dissolve
    pause

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Hi [nt]!"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Oh, hi [mc]!"

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "What's up?"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Nothing much, just trying to figure some things out."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Can I help?"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Sure, take a look!"
    nt "Altough, I gotta warn you, I don't think advanced math is a commonly known subject."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Is that what it is?"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Unfortunately, yes."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "I don't think I want to take a look anymore..."

    scene n_e1f3-04 with dissolve
    hide n_e1f3-nate_blink1
    nt "Haha!"

    scene n_e1f3-03 with dissolve
    nt "I thought so."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Is that what you're supposed to study?"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Well, not really."
    nt "I do it because I enjoy it."
    nt "I didn't even bother going to my math classes last year..."
    nt "I kind of already knew everything they taught there."
    nt "The professor was really surprised to see me ace the exam."
    nt "She thought I cheated so I proved her wrong by doing a complex math problem."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Haha! That's a weird passion."
    mc "But I'm not judging!"

    scene n_e1f3-03 with dissolve
    hide n_e1f3-nate_blink1
    nt "Trust me, I didn't think I'd like it so much myself."
    nt "Back in elementary school I would do anything just to escape from math."
    nt "And now I'd do this over anything else."
    nt "Who would have thought..."

    scene n_e1f3-02 with dissolve
    show n_e1f3-nate_blink1
    mc "Haha! You know how the saying goes..."
    mc "If you can't beat them, join them!"

    $ current_quests.remove("Talk to Nate.")

    $ e1f3_explore += 1

    if e1f3_explore == 4:
        $ current_quests.append("Go back to Jon's apartment.")

    scene n_e1f3-04 with dissolve
    hide n_e1f3-nate_blink1
    nt "Haha, you're right!"

    call e1f3_room34_default from _call_e1f3_room34_default
return

label hallway_3_rightdoor:
    scene e1f3-05
    mc "I shouldn't get involved..."

    call screen e1f3_hallway_3
return
# Freeroam #####################################################################

label e1f3:

    scene e1f3-01 with dissolve

    define e1f3_tracks = ["wonder_under.ogg", "with_a_whimper.ogg", "welcome_to_zombie_coast.ogg", "tidalwave.ogg", "sun_sets_on_a_protagonist.ogg", "punk_rock_holiday.ogg", "pop_song.ogg", "killer_rabbit.ogg", "iwnlylmd.ogg", "invisible_light.ogg", "heartless_man.ogg", "border_blaster.ogg", "bloom.ogg", "airplane_mode.ogg"]
    $ renpy.music.queue (e1f3_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Talk to Nate.")
    $ current_quests.append("Leave the room.")

    scene e1f3-01 with Dissolve(0.1)

    call screen e1f3_room34_default
    hide e1f3-01
return
