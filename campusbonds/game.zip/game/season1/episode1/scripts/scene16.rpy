
# Scene 16 - Moving out (Wednesday) ############################################

label e1s16:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    play music love
    scene e1s16-18 with Dissolve(2.0)
    pause

    scene e1s16-01 with dissolve
    jn "So, I guess this is where we say good bye..."
    jn "It wasn't supposed to end like this..."
    jn "But it's too late now..."
    jn "You've been a good man..."

    stop music
    scene e1s16-02
    mc "Dude, I'm only moving to my dorm."
    mc "It's not like I'm leaving for good."

    scene e1s16-03 with dissolve
    jn "They grow up so fast..."

    play sound punch
    scene e1s16-04 with dissolve
    mc "Oh, just shut up."

    scene e1s16-05 with dissolve
    "*Laughs*"
    jn "Nah, but for real, I'm gonna miss you."

    play music laurel_breeze
    scene e1s16-07 with wipeleft
    pause

    scene e1s16-06 with dissolve
    pause

    scene e1s16-08 with dissolve
    pause

    scene e1s16-10 with dissolve
    show e1s16_pass_str
    show e1s16-19 behind e1s16_pass_str
    sd "[mc], hi!"

    show e1s16-12 behind e1s16_pass_str with dissolve
    hide e1s16-19
    show e1s16_sadie_blink1
    mc "Hi [sd]!"
    mc "What's up?"

    hide e1s16_sadie_blink1
    show e1s16-19 behind e1s16_pass_str with dissolve
    hide e1s16-12
    sd "Just had to do something down at the front office."

    show e1s16-13 behind e1s16_pass_str with dissolve
    hide e1s16-19
    sd "What's up with you?"
    sd "Moving away from [jn]?"

    scene e1s16-14 with dissolve
    hide e1s16-13
    hide e1s16_pass_str
    pause

    scene e1s16-12 with dissolve
    show e1s16_sadie_blink1
    mc "Yeah well, I thought it was finally time I took life in my own hands."

    scene e1s16-13 with dissolve
    hide e1s16_sadie_blink1
    sd "You probably caught some philosophy classes along the way too."

    scene e1s16-12 with dissolve
    show e1s16_sadie_blink1
    mc "Ha, ha, very funny."

    scene e1s16-19 with dissolve
    hide e1s16_sadie_blink1
    sd "Yeah."
    sd "I gotta get going, catch you later!"

    scene e1s16-12 with dissolve
    show e1s16_sadie_blink1
    mc "Alright, see ya."

    scene e1s16-15 with dissolve
    hide e1s16_sadie_blink1
    menu:
        "Check her out":
            scene e1s16-16 with dissolve

            if affinity_spectrum > 0:
                mc "*Nice!*"
            else:
                pause

        "Don't check her out":
            pass

    stop music fadeout 2.0
    scene e1s16-17 with dissolve
    pause

    play music dances_and_dames
    scene e1s16-21 with wipeleft
    pause

    scene e1s16-22 with dissolve
    mc "*Hmm...*"
    mc "*Looks like [nt] isn't here which means I have the place to myself.*"

    stop music fadeout 1.0
    play sound phone_buzz
    scene e1s16-23 with dissolve
    "{i} Ring... {/i}"

    play music crazy_glue
    scene e1s16-27 with dissolve
    jo "Hey son, how's it going?"

    scene e1s16-24 with dissolve
    mc "Hi Dad!"

    scene e1s16-25 with dissolve
    mc "It's going pretty well, I just arrived at my dorm right now and I'm getting settled."

    scene e1s16-28 with dissolve
    jo "Oh, that's great."

    scene e1s16-27 with dissolve
    jo "How's college treating you so far?"

    menu:
        "Good response":
            call extrovert_affinity_check from _call_extrovert_affinity_check_15
            call color_check from _call_color_check_29

            scene e1s16-26 with dissolve
            mc "Oh, it's pretty great."
            mc "I'm loving it so far."
            mc "With [jn] introducing me to so many people and all, I'm really enjoying it."

            scene e1s16-27 with dissolve
            jo "Oh, I'm happy to hear that son!"

            scene e1s16-28 with dissolve
            jo "Glad to see you're having a positive response to it all."

        "Neutral response":
            call color_check from _call_color_check_30
            scene e1s16-25 with dissolve
            mc "Well, it's decent."

            scene e1s16-24 with dissolve
            mc "I can't really say too much because not a lot of things have happened yet."
            mc "I've met some people but I can't form an opinion at the moment."

            scene e1s16-27 with dissolve
            jo "I see."

            scene e1s16-28 with dissolve
            jo "Well, you've got plenty of time to discover it."

        "Bad response":
            call introvert_affinity_check from _call_introvert_affinity_check_13
            call color_check from _call_color_check_31

            scene e1s16-24 with dissolve
            mc "To be honest, it's not really what I expected."

            scene e1s16-25 with dissolve
            mc "I mean, yeah, I've been going to some parties and all, but they're not really my thing."

            scene e1s16-24 with dissolve
            mc "It's been boring so far."

            scene e1s16-27 with dissolve
            jo "Hey, chin up son."

            scene e1s16-29 with dissolve
            jo "Don't let it demotivate you, I bet there's a lot of fun stuff planned along the way for you."

            scene e1s16-28 with dissolve
            jo "It's only been a couple of days, I'm sure you'll come to love it."

    scene e1s16-24 with dissolve
    mc "Yeah..."

    scene e1s16-25 with dissolve
    mc "How are you doing, Dad?"

    scene e1s16-27 with dissolve
    jo "Well, you know, with work and stuff."

    scene e1s16-28 with dissolve
    jo "I'm trying to keep myself busy."

    scene e1s16-27 with dissolve
    jo "I'm actually home right now, today's a free day."

    scene e1s16-26 with dissolve
    mc "Yeah? How come?"

    scene e1s16-29 with dissolve
    jo "There was a leaking pipe so they had to kick us all out until they fix it."

    scene e1s16-28 with dissolve
    jo "Fortunately, there's the other station that can take the calls for us."
    jo "But, in case they don't have enough manpower, they can always call us and we'll be on our way."

    scene e1s16-24 with dissolve
    mc "So it's not an entirely free day."

    scene e1s16-29 with dissolve
    jo "Haha, well, I consider it to be."

    scene e1s16-27 with dissolve
    jo "How's Jon doing?"

    scene e1s16-24 with dissolve
    mc "He's fine."

    scene e1s16-25 with dissolve
    mc "I talked to him this morning when I moved away from his place."

    scene e1s16-26 with dissolve
    mc "He told me to say hi to you next time we talk."

    scene e1s16-29 with dissolve
    jo "Tell him I said hi as well."

    scene e1s16-26 with dissolve
    mc "Okay, I will."

    scene e1s16-27 with dissolve
    jo "Well, I won't be taking any more of your time."

    scene e1s16-28 with dissolve
    jo "Good luck with college son and talk to you soon."

    scene e1s16-26 with dissolve
    mc "Alright, thanks Dad!"
    mc "See you!"

    scene e1s16-28 with dissolve
    jo "Bye!"

    scene e1s16-23 with dissolve
    pause

    scene e1s16-22 with dissolve
    pause

    jump e1f4
return
