
# Scene 3 - Jon's place ########################################################

label e1s3:

    play music killer_rabbit loop

    scene e1s3-01 with Dissolve(2.0)
    pause

    scene e1s3-02 with dissolve
    jn "Welcome to my kingdom!"

    scene e1s3-03 with dissolve
    mc "This is probably the smallest kingdom I've ever been to."

    scene e1s3-04 with dissolve
    show e1s3-jon_blink1
    pause

    scene e1s3-05 with dissolve
    hide e1s3-jon_blink1
    jn "[mc], you know how much I care for you, right?"

    scene e1s3-06 with dissolve
    jn "I really do, you're like a brother to me."
    jn "If I had a penny for every friend that left me..."
    jn "I'd probably be rich by now."

    scene e1s3-05 with dissolve
    jn "Alright, anyways..."
    jn "...so... where was I?"
    jn "Oh yeah."

    scene e1s3-08 with dissolve
    jn "I'd like you to have the couch tonight!"

    scene e1s3-13 with dissolve
    mc "..."

    scene e1s3-09 with dissolve
    jn "I know, I know..."

    scene e1s3-07 with dissolve
    jn "You probably consider this too good to be true."
    jn "I'd be shocked as well if I were in your shoes."

    scene e1s3-10 with dissolve
    jn "But, a brother is a brother."
    jn "Enjoy!"

    scene e1s3-11 with dissolve
    play sound punch
    mc "Hey, fuck you!"

    scene e1s3-12 with dissolve
    pause

    scene e1s3-10 with dissolve
    jn "Make yourself at home."

    scene e1s3-14 with dissolve
    pause

    jn "Also, forgot to mention..."

    scene e1s3-15 with dissolve
    pause

    scene e1s3-16 with dissolve
    jn "I'm having some friends over tonight."
    jn "I wanted to introduce them to you so you don't feel left out or something."
    jn "I hope that's not a problem."

    scene e1s3-17 with dissolve
    mc "Nah, it's okay."

    if affinity_spectrum < 0:
        mc "I need to make some friends anyways while I'm here."

    scene e1s3-16 with dissolve
    jn "Alright then."

    scene e1s3-18 with dissolve
    jn "I'm gonna go buy some beers."
    jn "Feel free to explore the house if you'd like!"

    scene e1s3-19 with dissolve
    pause

    stop music fadeout 2
    jump freeroam1

return
