
# Scene 8 - A big pongblem #####################################################

label e1s8:
    stop sound fadeout 1.0
    play music i_wont_fall_in_love

    scene e1s8-01 with Dissolve(2.0)
    pause

    scene e1s8-02 with dissolve
    pause

    scene e1s8-03 with dissolve
    pause

    scene e1s8-05 with dissolve
    mc "What the..."

    scene e1s8-04 with dissolve
    jn "[mc]!"
    jn "There you are!"

    scene e1s8-05 with dissolve
    mc "So, this was the big PONGblem?"

    scene e1s8-04 with dissolve
    jn "Dude, this is super important to me."

    scene e1s8-05 with dissolve
    mc "Beer pong... but with shoes?"

    scene e1s8-04 with dissolve
    jn "I know right?"
    jn "Amazing!"

    scene e1s8-03 with dissolve
    pause

    play sound water_balloon
    scene e1s8-07 with dissolve
    pause

    scene e1s8-06 with dissolve
    pause

    scene e1s8-08 with dissolve
    pause

    scene e1s8-09 with dissolve
    pause

    scene e1s8-10 with dissolve
    jn "I know I said that we should go out tonight and stuff."

    scene e1s8-11 with dissolve
    jn "But, I came up with a better idea."
    jn "Why not throw a party here?"
    jn "Not like last time though..."
    jn "At least we have some pussy tonight."

    scene e1s8-13 with dissolve
    show e1s8_jon_blink1
    mc "Not trying to be a mood killer, but this place is kinda crowded."

    scene e1s8-12 with dissolve
    hide e1s8_jon_blink1
    jn "That's what makes it better!"

    scene e1s8-14 with dissolve
    pause

    scene e1s8-15 with dissolve
    pause

    scene e1s8-16 with dissolve
    jn "Come on, have some fun."

    scene e1s8-17 with dissolve
    pause

    stop music fadeout 1.0
    jump freeroam2
return
