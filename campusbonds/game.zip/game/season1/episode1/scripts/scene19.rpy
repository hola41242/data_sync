
# Scene 19 - Helping Jon #######################################################

label e1s19:

    stop music fadeout 2.0

    scene black with Dissolve(2.0)

    play music love

    scene e1s19-01 with Dissolve(2.0)
    pause

    scene e1s19-02 with dissolve
    pause

    scene e1s19-03 with dissolve
    bo "Sorry, chump!"
    bo "This place is off limits tonight."

    scene e1s19-04 with dissolve
    bo "There's another party going on at Cabanna's."

    scene e1s19-05 with dissolve
    show e1s19-bouncer_blink1
    mc "Sorry, I'm not here to party."
    mc "I'm here to meet a friend, [jon]."

    scene e1s19-06 with dissolve
    hide e1s19-bouncer_blink1
    bo "You don't look familiar..."

    scene e1s19-05 with dissolve
    show e1s19-bouncer_blink1
    mc "I'm not an organizer."
    mc "I'm here to meet my friend."

    scene e1s19-07 with dissolve
    hide e1s19-bouncer_blink1
    pause

    scene e1s19-08 with dissolve
    jn "Hey, [mc]!"

    scene e1s19-09 with dissolve
    jn "What are you doing here?"

    scene e1s19-10 with dissolve
    show e1s19-jon_blink1
    mc "Hey [jon]."
    mc "Figured you needed some help so I came here."

    scene e1s19-08 with dissolve
    hide e1s19-jon_blink1
    jn "Thanks, [mc]!"
    jn "I really appreciate it."

    scene e1s19-09 with dissolve
    jn "How was the party?"

    scene e1s19-10 with dissolve
    show e1s19-jon_blink1
    mc "Well, it was alright."
    mc "Not as cool as the parties you throw, though."

    scene e1s19-11 with dissolve
    hide e1s19-jon_blink1
    jn "Haha, I know right?"

    scene e1s19-10 with dissolve
    show e1s19-jon_blink1
    mc "Yeah!"

    scene e1s19-12 with dissolve
    hide e1s19-jon_blink1
    jn "This is the first time in years in which we didn't hold the Eddy's party."

    scene e1s19-13 with dissolve
    jn "This year they had the most budget."

    scene e1s19-14 with dissolve
    jn "We could have done so much."

    scene e1s19-15 with dissolve
    mc "I'm sorry bro..."
    mc "I'm gonna help with whatever I can."

    scene e1s19-16 with dissolve
    pause

    scene e1s19-17 with dissolve
    jn "[ke]? [jd]?"

    scene e1s19-18 with dissolve
    mc "What are you guys doing here?"

    scene e1s19-19 with dissolve
    ke "Well, we thought about what you said, [mc]."
    ke "[jon] needs our help."

    scene e1s19-20 with dissolve
    jd "Besides, the surprise didn't even come."
    jd "So you didn't miss anything."

    scene e1s19-21 with dissolve
    jn "It didn't come??"

    scene e1s19-18 with dissolve
    mc "What was supposed to be the surprise?"

    scene e1s19-22 with dissolve
    jn "Oh for fuck sake!"

    scene e1s19-23 with dissolve
    jn "We talked to the girls from here to go to Cabanna's."

    scene e1s19-22 with dissolve
    jn "This night is ruined for good."

    scene e1s19-24 with dissolve
    mc "Hey, [jon], don't worry man."

    scene e1s19-25 with dissolve
    mc "We got you."

    scene e1s19-26 with dissolve
    ke "Yeah, we'll help with whatever we can."

    scene e1s19-17 with dissolve
    jn "Thanks guys, I really appreciate it."

    scene e1s19-27 with dissolve
    jn "Let's go inside, we'll talk more there."

    scene e1s19-28 with dissolve
    pause

    stop music fadeout 2.0

    scene e1s19-29 with dissolve
    pause

    scene black with Dissolve(2.0)
    $ episode_count += 1
    jump credits

return
