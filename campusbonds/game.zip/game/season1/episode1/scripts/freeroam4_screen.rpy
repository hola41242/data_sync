
# Freeroam Screens #############################################################

# Freeroam #4 Screens ##########################################################

screen e1f4_room34_default():
    $ renpy.random.shuffle(e1f4_tracks)

    add "e1f4-01"
    modal True

    # To Right #################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/from_default_to_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/from_default_to_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_right")

    # To Left ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/from_default_to_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/from_default_to_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_left")

    # To Hallway ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/from_room34_to_hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/from_room34_to_hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_hallway_1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_hallway_1")

    if persistent.fr_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/room34/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/room34/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_1_unlocked", True), SetVariable("persistent.e1f4_collected_p", persistent.e1f4_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca1", True), Function(update_francesca_list)]

screen e1f4_room34_left():
    $ renpy.random.shuffle(e1f4_tracks)

    add "e1f4-02"
    modal True

    # Clickables ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/left/bed_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/left/bed_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_bed")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_bed")

    # To Default ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/left/from_left_to_default_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/left/from_left_to_default_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_default")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_default")

    if persistent.fr_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/room34/left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/room34/left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_2_unlocked", True), SetVariable("persistent.e1f4_collected_p", persistent.e1f4_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca2", True), Function(update_francesca_list)]

screen e1f4_room34_right():
    $ renpy.random.shuffle(e1f4_tracks)

    add "e1f4-03"
    modal True

    # To Default ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/room34/right/from_right_to_default_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/room34/right/from_right_to_default_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_default")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_default")

    if persistent.cl_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/room34/right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/room34/right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_3_unlocked", True), SetVariable("persistent.e1f4_collected_p", persistent.e1f4_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo3", True), Function(update_cleo_list)]

screen e1f4_hallway_1():
    $ renpy.random.shuffle(e1f4_tracks)

    if e1f4_ken == False and e1f4_right_door == False:
        add "e1f4-04"
    if e1f4_ken == True and e1f4_right_door == False:
        add "e1f4-04_1"
    if e1f4_ken == False and e1f4_right_door == True:
        add "e1f4-04_2"
    if e1f4_ken == True and e1f4_right_door == True:
        add "e1f4-04_3"
    modal True

    # Clickables ###############################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_hallway_to_room34_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_hallway_to_room34_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_room34_default")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_room34_default")

    # In front #################################################################

    if e1f4_ken == False and e1f4_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2")

    if e1f4_ken == True and e1f4_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_no_ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_no_ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2")

    if e1f4_ken == False and e1f4_right_door == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2")

    if e1f4_ken == True and e1f4_right_door == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_sadie_no_ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_2_sadie_no_ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2")

    # To back ##################################################################

    if e1f4_ken == True and e1f4_sadie == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_exit_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/1/from_1_to_exit_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_1_exit")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_1_exit")

screen e1f4_hallway_2():
    $ renpy.random.shuffle(e1f4_tracks)

    if e1f4_ken == False and e1f4_right_door == False:
        add "e1f4-05"
    if e1f4_ken == True and e1f4_right_door == False:
        add "e1f4-05_1"
    if e1f4_ken == False and e1f4_right_door == True:
        add "e1f4-05_2"
    if e1f4_ken == True and e1f4_right_door == True:
        add "e1f4-05_3"
    modal True

    # In front #################################################################

    if e1f4_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_3_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_3_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_3")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_3")
    else:
        if e1f4_ken == True:
            imagebutton:
                idle im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_3_sadie_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_3_sadie_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e1f4_hallway_3")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e1f4_hallway_3")

    # To back ##################################################################

    if e1f4_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_1")
    else:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_1_sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/from_2_to_1_sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_1")

    # Clickables ###############################################################

    if affinity_spectrum > 0 and tracy_trust >= 2 and e1f4_right_door == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/to_tracy_room_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/to_tracy_room_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2_tracy")

    if e1f4_ken == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2_ken")

    if e1f4_right_door == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_2_sadie")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_2_sadie")

    if persistent.sd_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_3_unlocked", True), SetVariable("persistent.e1f4_collected_p", persistent.e1f4_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie3", True), Function(update_sadie_list)]

    if e1f4_money == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/2/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/2/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e1f4_money", True)]

screen e1f4_hallway_3():
    $ renpy.random.shuffle(e1f4_tracks)

    if e1f4_right_door == False:
        add "e1f4-06"
    else:
        add "e1f4-06_1"
    modal True
    # Clickables ###############################################################

    if e1f4_right_door == False and e1f4_sadie == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/3/to_right_door_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/3/to_right_door_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_3_rightdoor")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_3_rightdoor")

    else:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam4/hallway/3/to_right_door_closed_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam4/hallway/3/to_right_door_closed_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e1f4_hallway_3_rightdoor")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e1f4_hallway_3_rightdoor")

    # To back ##################################################################

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam4/hallway/3/from_3_to_2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam4/hallway/3/from_3_to_2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e1f4_hallway_2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e1f4_hallway_2")
