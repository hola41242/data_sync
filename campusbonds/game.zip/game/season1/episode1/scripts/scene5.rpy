
# Scene 5 - After party ########################################################

label e1s5:
    play music little_tomcat
    scene e1s5-01 with Dissolve(2.0)
    pause

    scene e1s5-02 with dissolve
    show e1s5-mc_blink1
    pause

    play sound punch
    scene e1s5-03 with vpunch
    hide e1s5-mc_blink1
    pause

    scene e1s5-04 with dissolve
    show e1s5-mc_blink2
    pause

    play sound punch
    scene e1s5-05 with vpunch
    hide e1s5-mc_blink1
    pause

    scene e1s5-06 with dissolve
    pause

    scene e1s5-07 with dissolve
    pause

    play sound sink_water
    scene e1s5-08 with dissolve
    pause

    scene e1s5-09 with dissolve
    mc "What the..."
    jn "Yeah, don't mind that guy."

    scene e1s5-10 with dissolve
    jn "We're lucky he settled for that spot."

    scene e1s5-11 with dissolve
    jn "Usually, he sleeps in weirder places."

    scene e1s5-12 with dissolve
    jn "Anyways, enough about him."

    scene e1s5-14 with dissolve
    jn "How about I show you around town today?"
    jn "It's been some time since we last hung out."

    scene e1s5-13 with dissolve
    show e1s5-jon_blink1
    mc "Sure! I'll be ready in a bit."

    scene e1s5-14 with dissolve
    hide e1s5-jon_blink1
    jn "Awesome!"

    scene e1s5-13 with dissolve
    show e1s5-jon_blink1
    mc "Oh, also..."
    mc "Why the hell is he wearing my t-shirt?"

    scene e1s5-17 with dissolve
    hide e1s5-jon_blink1
    jn "Nobody knows!"

    scene e1s5-16 with dissolve
    jn "You were all pretty wasted last night."

    scene e1s5-13 with dissolve
    show e1s5-jon_blink1
    if balloon_hit == True:
        mc "Yeah."
        mc "I remember hitting someone in the head with a balloon."

        scene e1s5-14 with dissolve
        hide e1s5-jon_blink1
        jn "Haha!"
        jn "She seemed so mad."

        scene e1s5-16 with dissolve
        jn "I wonder what [jd] put in that balloon..."

        if affinity_spectrum < 0:
            scene e1s5-13 with dissolve
            show e1s5-jon_blink1
            mc "I feel kinda bad for her."
            mc "Maybe she already had a bad night before and we made it worse by throwing a balloon at her with God knows what in it."

            scene e1s5-16 with dissolve
            hide e1s5-jon_blink1
            jn "Well, I think that it was pretty funny."
            jn "I get where you're coming from but it's just a prank."
            jn "I'd probably get mad in the moment but after a while I'd joke around with it."

            scene e1s5-13 with dissolve
            show e1s5-jon_blink1
            mc "Well, I guess you're right."
        if affinity_spectrum >= 0:
            scene e1s5-13 with dissolve
            show e1s5-jon_blink1
            mc "Even though I feel kinda bad for her I think that it was funny."

            scene e1s5-16 with dissolve
            hide e1s5-jon_blink1
            jn "Well, in the end it's just a prank."
            jn "It's not like we killed someone."
            jn "And yeah, I gotta admit it was pretty funny."
            jn "But if I were in her shoes I'd probably get mad in the moment and after a while I'd joke around with it."

            scene e1s5-13 with dissolve
            show e1s5-jon_blink1
            mc "You're right."

    if balloon_hit == False:
        mc "Yeah."
        mc "I remember [jd] wanting to throw a balloon at some stranger on the street."

        scene e1s5-14 with dissolve
        hide e1s5-jon_blink1
        jn "Well, yeah, he *wanted* to."

        scene e1s5-16 with dissolve
        jn "Too bad his aim is so trash, else we would have laughed for a long while about this."

        scene e1s5-13 with dissolve
        show e1s5-jon_blink1
        mc "Well, maybe it's better this way."
        mc "Who knows? Maybe she already had a bad night to begin with..."
        mc "...and we would have made it worse by throwing a balloon at her."

        scene e1s5-16 with dissolve
        hide e1s5-jon_blink1
        jn "Well, I get where you're coming from."
        jn "But, in the end, it would have just been a prank."
        jn "It's not like we would have killed someone."
        jn "And also, if I were in her shoes I'd probably get mad in the moment and after a while I'd joke around with it."

        scene e1s5-13 with dissolve
        show e1s5-jon_blink1
        mc "I guess you're right."

    scene e1s5-15 with dissolve
    hide e1s5-jon_blink1
    jd "Guys..."
    jd "...where am I?"

    stop music
    jump e1s6
return
