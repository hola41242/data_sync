
# Freeroam Screens #############################################################

# Freeroam #1 Screens ##########################################################

screen f1_living():

    $ renpy.random.shuffle(f1_tracks)
    modal True

    if used_luggage == False:
        add "e1f1-01"

    if used_luggage == True:
        add "e1f1-01-no_luggage"

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_kitchen_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_kitchen_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_kitchen")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_kitchen")

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_bathroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_bathroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_bathroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_bathroom")

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_bedroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/living_room/from_living_to_bedroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_bedroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_bedroom")

    if persistent.mixed_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/living_room/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/living_room/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_1_unlocked", True), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed1", True), Function(update_mixed_list)]

    if used_luggage == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/living_room/luggage_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/living_room/luggage_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f1_luggage")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f1_luggage")

    if used_luggage == True:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/living_room/couch_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/living_room/couch_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f1_couch")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f1_couch")

    if f1_money_picked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/living_room/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/living_room/money_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f1_money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", +1), Show("money_notify"), SetVariable("f1_money_picked", True)]

screen f1_kitchen():
    $ renpy.random.shuffle(f1_tracks)

    add "e1f1-02"
    modal True

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/kitchen/from_kitchen_to_living_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/kitchen/from_kitchen_to_living_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_living")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_living")

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/kitchen/from_kitchen_to_balcony_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/kitchen/from_kitchen_to_balcony_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_balcony")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_balcony")

    if f1_money_picked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/kitchen/living_money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/kitchen/living_money_hover.webp", 1920, 1080)
            focus_mask True

    if persistent.mixed_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/kitchen/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/kitchen/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_2_unlocked", True), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed2", True), Function(update_mixed_list)]

screen f1_balcony():
    $ renpy.random.shuffle(f1_tracks)

    add "e1f1-03"
    modal True

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/balcony/from_balcony_to_kitchen_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/balcony/from_balcony_to_kitchen_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_kitchen")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_kitchen")

    if persistent.tr_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/balcony/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/balcony/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_1_unlocked", True), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy1", True), Function(update_tracy_list)]

screen f1_bedroom():
    $ renpy.random.shuffle(f1_tracks)

    add "e1f1-04"
    modal True

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/bedroom/from_bedroom_to_living_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/bedroom/from_bedroom_to_living_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_living")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_living")

    if f1_dumbbells == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/bedroom/dumbbells_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/bedroom/dumbbells_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "f1_dumbbells")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("f1_dumbbells")

    if persistent.sd_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/bedroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/bedroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_1_unlocked", True), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie1", True), Function(update_sadie_list)]

screen f1_bathroom():

    $ renpy.random.shuffle(f1_tracks)

    add "e1f1-05"
    modal True

    imagebutton:
        idle im.Scale("season1/episode1/images/freeroam1/bathroom/from_bathroom_to_living_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode1/images/freeroam1/bathroom/from_bathroom_to_living_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "f1_living")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("f1_living")

    if persistent.sc_gallery_1_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode1/images/freeroam1/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode1/images/freeroam1/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_1_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_1_unlocked", True), SetVariable("persistent.e1f1_collected_p", persistent.e1f1_collected_p+1), SetVariable("persistent.e1f2_collected_p", persistent.e1f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett1", True), Function(update_scarlett_list)]
