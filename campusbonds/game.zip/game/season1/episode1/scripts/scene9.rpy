
# Scene 9 - After party (Monday) ###############################################

label e1s9:
    scene e1s9-01 with Dissolve(2.0)
    play music frannie loop
    pause

    scene e1s9-02 with dissolve
    show e1s9-mc_blink1
    pause

    scene e1s9-03 with dissolve
    hide e1s9-mc_blink1
    show e1s9-mc_blink2
    mc "*Why am I feeling like I'm having déjà vu?*"

    play sound punch
    scene e1s9-04 with vpunch
    hide e1s9-mc_blink2
    pause

    scene e1s9-05 with dissolve
    pause

    scene e1s9-06 with dissolve
    pause

    scene e1s9-07 with dissolve
    mc "..."
    mc "*I'm starting to think this guy lives here.*"

    scene e1s9-08 with dissolve
    pause

    if sadie_trust > tracy_trust:
        call e1s9_sadie_shower from _call_e1s9_sadie_shower
    else:
        call e1s9_tracy_shower from _call_e1s9_tracy_shower

    play music frannie loop
    scene e1s9-35 with dissolve
    pause

    scene e1s9-36 with dissolve
    jn "Going somewhere?"

    scene e1s9-37 with dissolve
    mc "Today's the uni tour."

    scene e1s9-38 with dissolve
    mc "I also gotta get my dorm key."

    scene e1s9-39 with dissolve
    jn "Oh, right."
    jn "Have fun!"

    scene e1s9-40 with dissolve
    jn "Also, if you're planning on extending your stay at my place just let me know, okay?"

    scene e1s9-42 with dissolve
    mc "Like I would willingly sleep on your couch."

    scene e1s9-41 with dissolve
    jn "Haha, fuck you!"
    jn "It's not that bad."

    scene e1s9-43 with dissolve
    mc "Hah, yeah, I'll be on my way now."

    stop music fadeout 2.0
    jump e1s10

return

# Replay #######################################################################

label e1s9_sadie_shower:

    scene e1s9-09 with dissolve
    pause

    $renpy.sound.play("audio/sfx/sink_water_loop.ogg", loop=True)
    scene e1s9-10 with dissolve
    pause

    scene e1s9-11 with dissolve
    pause

    scene e1s9-12 with dissolve
    pause

    stop sound fadeout 2.0
    stop music fadeout 2.0
    scene white with Dissolve(2.0)

    if persistent.disable_nsfw == True:

        play music wonder_under
        scene e1s9-14 with Dissolve(2.0)
        pause

        menu:
            "Check her out":
                scene e1s9-15 with dissolve
                pause
            "Don't check her":
                pass

        scene e1s9-13 with dissolve
        pause

        scene e1s9-16 with dissolve
        pause

        scene e1s9-17 with dissolve
        pause

        scene e1s9-18 with dissolve
        pause

        scene e1s9-19 with dissolve
        pause

        scene e1s9-20 with dissolve
        pause

        scene e1s9-21 with dissolve
        pause

    if persistent.disable_nsfw == False:

        if persistent.type_nsfw == False:

            play music wonder_under
            scene c_e1s9-14 with Dissolve(2.0)
            pause

            menu:
                "Check her out":
                    scene c_e1s9-15 with dissolve
                    pause
                "Don't check her":
                    pass

            scene c_e1s9-13 with dissolve
            pause

            scene c_e1s9-16 with dissolve
            pause

            scene c_e1s9-17 with dissolve
            pause

            scene c_e1s9-18 with dissolve
            pause

            scene c_e1s9-19 with dissolve
            pause

            scene e1s9-20 with dissolve
            pause

            scene e1s9-21 with dissolve
            pause

    stop music
    play sound woosh
    scene e1s9-25 with vpunch
    mc "Shit!"

    scene e1s9-22 with vpunch
    pause

    scene e1s9-23 with dissolve
    pause

    scene e1s9-24 with dissolve
    pause

    $ renpy.end_replay()

return

label e1s9_tracy_shower:

    scene e1s9-09 with dissolve
    pause

    $renpy.sound.play("audio/sfx/sink_water_loop.ogg", loop=True)
    scene e1s9-10 with dissolve
    pause

    scene e1s9-11 with dissolve
    pause

    scene e1s9-12 with dissolve
    pause

    stop sound fadeout 2.0
    stop music fadeout 2.0
    scene white with Dissolve(2.0)

    if persistent.disable_nsfw == True:

        play music ariana_grande_synthet
        scene e1s9-27 with Dissolve(2.0)
        pause

        menu:
            "Check her out":
                scene e1s9-28 with dissolve
                pause
            "Don't check her":
                pass

        scene e1s9-29 with dissolve
        pause

        scene e1s9-26 with dissolve
        pause

        scene e1s9-30 with dissolve
        pause

        scene e1s9-31 with dissolve
        pause

        scene e1s9-32 with dissolve
        pause

        scene e1s9-33 with dissolve
        pause

        scene e1s9-34 with dissolve
        pause

    if persistent.disable_nsfw == False:

        if persistent.type_nsfw == False:

            play music ariana_grande_synthet
            scene c_e1s9-27 with Dissolve(2.0)
            pause

            menu:
                "Check her out":
                    scene c_e1s9-28 with dissolve
                    pause
                "Don't check her":
                    pass

            scene c_e1s9-29 with dissolve
            pause

            scene c_e1s9-26 with dissolve
            pause

            scene c_e1s9-30 with dissolve
            pause

            scene c_e1s9-31 with dissolve
            pause

            scene c_e1s9-32 with dissolve
            pause

            scene c_e1s9-33 with dissolve
            pause

            scene c_e1s9-34 with dissolve
            pause

    stop music
    play sound woosh
    scene e1s9-25 with vpunch
    mc "Shit!"

    scene e1s9-22 with vpunch
    pause

    scene e1s9-23 with dissolve
    pause

    scene e1s9-24 with dissolve
    pause

    $ renpy.end_replay()

return
