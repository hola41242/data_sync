
# Scene 1 - News (Saturday) ####################################################

label start:
    label e1s1:
        pause
        play music sundown loop fadein 1.0
        window hide
        scene black with Dissolve(1.0)

        scene e1s1-01 with Dissolve(1.0)
        jn "So, what's up?"
        jn "Did you get accepted or what?"

        scene e1s1-02 with dissolve
        bmc "Hold on, let me check."

        scene e1s1-01 with dissolve
        bmc "*Hmm, what was my username?*"

        scene e1s1-03 with dissolve
        $ persistent.mcname = renpy.input("What is your name?", length=32, default = "MC").strip()

        scene e1s1-04 with dissolve
        $ renpy.block_rollback()
        pause

        scene e1s1-05 with dissolve

        scene e1s1-06 with dissolve
        mc "Yoo! I got in!"

        scene e1s1-05 with dissolve
        jn "You did?"
        jn "That's awesome!"

        scene e1s1-06 with dissolve
        mc "Yeah."
        mc "I applied so late I didn't think I would get accepted."

        scene e1s1-05 with dissolve
        jn "You know what would be cool?"
        jn "How about you come and stay at my place until college starts?"
        jn "I could show you around."
        jn "And also celebrate if you know what I mean."

        if persistent.tutorial == True:
            show tutorial_background_menu with wiperight
            show dialogue_box with wiperight
            show f1_text "This is a choice that affects your affinity." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "The game uses an Affinity Spectrum system, which \n shapes the [mc]'s personality based on your \n decisions." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "{color=#2572C4}Introverted{/color} – Thoughtful, reserved. \n {color=#FF3A37}Extroverted{/color} – Outgoing, bold, more inclined toward \n parties." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "Some love interests may be more attracted to a \n specific affinity, so your personality can \n influence who you're able to connect with." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "You're not locked in yet, your affinity can still \n shift based on your choices." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "However, once you enter a relationship, your \n current affinity will lock in and no longer \n change." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "If you decide to break up, your affinity will \n unlock again, giving you the chance to explore \n a different personality." with wiperight
            pause

            hide f1_text with wipeleft
            show f1_text "You can check your current affinity by looking at \n your name's color, or disable this feature in the \n preferences menu for a more immersive experience." with wiperight
            pause

            hide f1_text with wipeleft
            hide dialogue_box with wipeleft
            hide tutorial_background_menu with wipeleft

        scene e1s1-05 with dissolve
        menu:
            "Good idea":
                call extrovert_affinity_check from _call_extrovert_affinity_check_11
                call color_check from _call_color_check_21

                scene e1s1-06 with dissolve
                mc "That would be pretty sick!"
                mc "I can also revisit Underport."
                mc "It's been so long, gosh."

                scene e1s1-05 with dissolve
                jn "I know right?"

                scene e1s1-06 with dissolve
                mc "I'll have to check in with Dad first."
                mc "Be right back."

                scene e1s1-05 with dissolve
                pause

            "Bad idea":
                call introvert_affinity_check from _call_introvert_affinity_check_9
                call color_check from _call_color_check_22

                scene e1s1-02 with dissolve
                mc "I don't know to be fair."
                mc "Doesn't really sound like a good idea to me."

                scene e1s1-01 with dissolve
                jn "Come on bro."
                jn "It will be fun trust me."

                scene e1s1-02 with dissolve
                mc "Alright, alright."
                mc "I'll have to check in with Dad first."
                mc "Be right back."

                scene e1s1-01 with dissolve
                pause

        scene e1s1-07 with dissolve
        pause

        scene black with Dissolve(1.0)

        scene e1s1-08 with Dissolve(1.0)
        mc "Hey Dad!"

        scene e1s1-09 with dissolve
        jo "Hey!"
        jo "I'll be there in a bit."

        scene e1s1-10 with dissolve
        jo "Hey son!"
        jo "What's up?"

        scene e1s1-11 with dissolve
        mc "I just checked the Underport Liberty website."

        scene e1s1-12 with dissolve
        show e1s1-joel_blink1
        mc "And I got accepted to college!"

        scene e1s1-13 with dissolve
        hide e1s1-joel_blink1
        jo "Wait, for real?"

        scene e1s1-14 with dissolve
        jo "That's amazing!"

        scene e1s1-15 with dissolve
        jo "I'm so proud of you son."
        jo "Well done!"

        scene e1s1-16 with dissolve
        jo "Let me get us 2 beers."

        scene e1s1-17 with dissolve
        pause

        scene e1s1-18 with dissolve
        pause

        scene e1s1-19 with dissolve
        pause

        scene e1s1-20 with dissolve
        play sound glass_cheers
        jo "Cheers!"

        scene e1s1-21 with dissolve
        jo "So, that's it..."
        jo "You're finally going to college."
        jo "Can't say I didn't expect this day to come, but it still caught me by surprise."

        scene e1s1-22 with dissolve
        mc "Hey, don't worry!"
        mc "I'll still come home to visit you."

        scene e1s1-24 with dissolve
        jo "I'm not worrying."
        jo "Whenever you got the time."

        scene e1s1-21 with dissolve
        jo "I want you to be careful son."
        jo "There's a lot of bad influences out there."
        jo "Now, I'm aware you probably heard this a hundred times from me."
        jo "And I don't want to annoy you with all of this dad-son talk."

        scene e1s1-24 with dissolve
        jo "But, be mindful about the choices you make."
        jo "If you ever have any issues and you need some advice, you know who to call."

        scene e1s1-23 with dissolve
        show e1s1-joel_blink2
        mc "Thanks Dad!"

        scene e1s1-21 with dissolve
        hide e1s1-joel_blink2
        jo "So, when are you leaving?"

        scene e1s1-22 with dissolve
        mc "Well, I just talked to [jon] and he proposed that I should go and stay at his place until college starts."

        scene e1s1-23 with dissolve
        show e1s1-joel_blink2
        mc "I thought about checking in with you to see what you think about it."
        mc "I also need to get some documents sorted for my dorm and stuff."

        scene e1s1-24 with dissolve
        hide e1s1-joel_blink2
        jo "I see!"
        jo "Well, I'm not against it."

        scene e1s1-24 with dissolve
        jo "I know that [jon]'s a good guy and you'll be fine with him."

        scene e1s1-21 with dissolve
        jo "Are you still going to get a dorm if you're gonna stay at his place?"

        scene e1s1-24 with dissolve
        jo "Isn't it gonna be cheaper to stay with him?"

        scene e1s1-22 with dissolve
        mc "Dad, his apartment is so small he barely fits in there by himself."
        mc "I need my own space."

        scene e1s1-24 with dissolve
        jo "Yeah, I can understand that."
        jo "You do what you think is best for you son."

        scene e1s1-21 with dissolve
        jo "Just be careful out there alright?"

        scene e1s1-24 with dissolve
        jo "Don't forget to give me a call when you get there."

        scene e1s1-23 with dissolve
        show e1s1-joel_blink2
        mc "Sure Dad."

        scene e1s1-23 with dissolve
        hide e1s1-joel_blink2
        mc "I'm gonna go and pack my things."
        mc "Thanks for the beer!"

        scene e1s1-24 with dissolve
        jo "Don't mention it!"

        scene e1s1-25 with dissolve
        pause

        stop music fadeout 2.5
        scene black with Dissolve(2.0)

        jump e1s2
    return
return
