
# Scene 6 - Around town ########################################################

label e1s6:
    play music daft_punk
    scene e1s6-01 with wipeleft
    pause

    scene e1s6-11 with dissolve
    jn "And, that right there is the mall."

    scene e1s6-10 with dissolve
    mc "Nice!"

    scene e1s6-02 with dissolve
    mc "Also, I was wondering..."
    mc "Could you help me sign up at the gym?"

    scene e1s6-03 with dissolve
    jn "Sure, I'll get you signed up."
    jn "I was about to show you the gym anyways."

    scene e1s6-04 with dissolve
    mc "Great!"

    scene e1s6-05 with dissolve
    jn "It's been so long since we last trained."
    jn "You were so bad at fighting, remember?"

    scene e1s6-12 with dissolve
    mc "Haha! Yeah."

    scene e1s6-06 with dissolve
    mc "Hey, don't act like you were any better than me!"
    mc "At least I didn't get my ass kicked by a girl."

    scene e1s6-07 with dissolve
    jn "Hey, fuck you!"
    jn "No need to bring that up."
    jn "I wasn't in my strongest form back then."

    scene e1s6-08 with dissolve
    mc "Sure you *weren't*."

    scene e1s6-09 with dissolve
    jn "I'll show you when we get there."

    stop music
    play music tidalwave
    scene e1s6-15 with slideleft
    pause

    scene e1s6-16 with dissolve
    pause

    scene e1s6-17 with dissolve
    pause

    scene e1s6-18 with dissolve
    pause

    scene e1s6-18 with dissolve
    jn "Aw, hell no!"

    scene e1s6-19 with dissolve
    pause

    scene e1s6-20 with dissolve
    jn "I know what you're trying to do!"

    scene e1s6-21 with dissolve
    mc "What's wrong?"

    show e1s6-22 with dissolve
    jn "You stay away from this kind of woman."

    scene e1s6-13 with dissolve
    mc "Huh?"

    scene e1s6-23 with dissolve
    show e1s6-jon_blink1
    mc "Why?"

    scene e1s6-22 with dissolve
    hide e1s6-jon_blink1
    jn "They will record you and then post you on social media calling you a creep for staring at their ass."

    scene e1s6-23 with dissolve
    show e1s6-jon_blink1
    mc "What the hell...?"

    scene e1s6-22 with dissolve
    hide e1s6-jon_blink1
    jn "It's not funny bro."
    jn "It once happened to me and I can say that it wasn't a pleasant experience."

    scene e1s6-13 with dissolve
    pause

    scene e1s6-14 with dissolve
    pause

    if affinity_spectrum > 0:
        scene e1s6-24 with dissolve
        jn "..."

        scene e1s6-27 with dissolve
        mc "*Jon's so stupid.*"

    if affinity_spectrum <= 0:
        scene e1s6-25 with dissolve
        jn "..."

        scene e1s6-26 with dissolve
        mc "*Oh shit!*"

    scene e1s6-14 with dissolve
    unknown "Oh my gosh!"

    scene e1s6-32 with dissolve
    pause

    scene e1s6-33 with dissolve
    pause

    stop music fadeout 1.0
    scene e1s6-28 with dissolve
    play music invisible_light
    unknown "I'm so sorry!"

    scene e1s6-34 with dissolve
    show e1s6-olivia_blink2
    mc "*She's sorry? For what?*"
    if affinity_spectrum > 0:
        mc "*I was the one staring at her ass, not the other way around...*"
    if affinity_spectrum <= 0:
        mc "*Did she do anything wrong?*"

    scene e1s6-28 with dissolve
    hide e1s6-olivia_blink2
    unknown "The front office told me I shouldn't be filming here."

    if affinity_spectrum <= 0:
        scene e1s6-34 with dissolve
        show e1s6-olivia_blink2
        mc "Ohh... I see!"
        mc "It's alright, I don't mind."

    if affinity_spectrum > 0:
        scene e1s6-34 with dissolve
        show e1s6-olivia_blink2
        mc "Ohh... I see!"
        mc "It's alright."

    mc "*I get it now.*"
    mc "What's up with that?"
    mc "Are you some sort of influencer?"

    scene e1s6-29 with dissolve
    hide e1s6-olivia_blink2
    unknown "Well, I try to be."

    scene e1s6-30 with dissolve
    unknown "I found out about this app called 'Brixter' and I wanted to help people get started in the gym."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "That's some weird naming right there."
    mc "How's it going so far?"

    scene e1s6-29 with dissolve
    unknown "Well, not that great."

    scene e1s6-35 with dissolve
    unknown "There's a lot of people already doing this and I'm not really bringing anything new to the table."

    scene e1s6-29 with dissolve
    unknown "Perhaps they think that a more popular person is more trustworthy than a normal person in a normal gym."

    scene e1s6-30 with dissolve
    unknown "But, it is what it is."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "I don't believe that to be the case."
    mc "Maybe they just haven't found out about you yet."
    mc "Maybe, if you keep trying, you'll get somewhere at some point."

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    unknown "Hey, that's a good point."
    unknown "I'll definetely keep trying and see where I go with this."
    ov "My name is [ov] by the way!"

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "I'm [mc]!"
    mc "Nice to meet you."

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    ov "Likewise!"
    ov "I haven't seen you around here before."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "Well, I just moved into town."
    mc "I'm starting college tomorrow at UPL and one of my friends invited me over for a couple of days."

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    ov "Is it the one who just left?"

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "Haha, yeah!"

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    ov "I also studied at UPL, just graduated this year."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "Oh, really?"
    mc "That's pretty cool."

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    ov "Yeah."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "How was it?"

    scene e1s6-30 with dissolve
    hide e1s6-olivia_blink1
    ov "Well, for the most part, college was pretty good to me."

    scene e1s6-29 with dissolve
    ov "I met some, rather, 'interesting' people there."

    scene e1s6-30 with dissolve
    ov "But, that's that."
    ov "I wasn't really a party person."
    ov "And I've always minded my own business."

    scene e1s6-31 with dissolve
    show e1s6-olivia_blink1
    mc "You've gotta tell me more about it."

    scene e1s6-36 with dissolve
    hide e1s6-olivia_blink1
    jn "Hey [mc]!"

    scene e1s6-37 with dissolve
    jn "What's going on here?"

    scene e1s6-38 with dissolve
    mc "Hey [jon]!"

    scene e1s6-40 with dissolve
    mc "I was just talking to [ov] here."

    scene e1s6-39 with dissolve
    ov "Hi [jon]!"
    ov "Nice to meet you."

    scene e1s6-41 with dissolve
    jn "Nice to meet you too."

    scene e1s6-42 with dissolve
    jn "Do you guys..."

    scene e1s6-43 with dissolve
    jn "...know each other?"

    scene e1s6-44 with dissolve
    ov "Haha, no."

    scene e1s6-45 with dissolve
    ov "We literally just met right now."

    scene e1s6-46 with dissolve
    jn "Oh, haha!"

    scene e1s6-47 with dissolve
    mc "Yeah."
    mc "She told me she was filming some kind of guide for newbies in the gym."

    scene e1s6-46 with dissolve
    jn "Mhmm..."
    jn "That's actually pretty great!"

    scene e1s6-45 with dissolve
    ov "Well, I just finished my last set now and I'm gonna be on my way."
    ov "It was nice talking to you guys."
    ov "I'll be seeing you around, bye!"

    scene e1s6-47 with dissolve
    mc "Bye [ov]!"

    scene e1s6-52 with dissolve
    pause

    scene e1s6-48 with dissolve
    pause

    scene e1s6-50 with dissolve
    menu:
        "Check her out":
            scene e1s6-51 with dissolve
            pause
        "Don't risk it":
            pass

    scene e1s6-49 with dissolve
    pause

    scene e1s6-53 with dissolve
    jn "Bro, I thought you were gonna follow me when I left."

    scene e1s6-54 with dissolve
    show e1s6-jon_blink2
    mc "At first I wanted to, but she apologized and it was really weird because I didn't even know why she was apologizing for."

    scene e1s6-55 with dissolve
    hide e1s6-jon_blink2
    jn "Indeed that's weird."

    scene e1s6-54 with dissolve
    show e1s6-jon_blink2
    mc "Then she introduced herself and we talked a bit."

    scene e1s6-55 with dissolve
    hide e1s6-jon_blink2
    jn "Wow."

    scene e1s6-54 with dissolve
    show e1s6-jon_blink2
    mc "And here you were thinking she was trying to pull some shenanigans on you."

    scene e1s6-56 with dissolve
    hide e1s6-jon_blink2
    jn "Hey, I've had my fair share of gym related traumas."

    scene e1s6-53 with dissolve
    jn "Just because it didn't happen now doesn't mean it can't happen ever."
    jn "You don't even wanna know what some people would do for a little bit of clout."

    scene e1s6-54 with dissolve
    show e1s6-jon_blink2
    mc "Yeah, whatever bro."
    mc "Let's spar."

    scene e1s6-56 with dissolve
    hide e1s6-jon_blink2
    jn "Alright."

    stop music
    play music electric_girlfriend
    scene e1s6-57 with vpunch
    play sound woosh
    pause

    scene e1s6-58 with vpunch
    play sound woosh
    pause

    scene e1s6-59 with vpunch
    play sound woosh
    pause

    scene e1s6-60 with vpunch
    play sound woosh
    pause

    scene e1s6-61 with vpunch
    play sound punch
    pause

    scene e1s6-62 with vpunch
    play sound woosh
    pause

    scene e1s6-63 with vpunch
    play sound punch
    pause

    scene e1s6-64 with dissolve
    pause

    scene e1s6-65 with dissolve
    jn "You've gotten much better since the last time we sparred."

    scene e1s6-66 with dissolve
    show e1s6-jon_blink3
    mc "Yeah, I've trained very hard since then."
    mc "Too bad I had the injury which kind of killed my career in this sport."

    scene e1s6-65 with dissolve
    hide e1s6-jon_blink3
    jn "Hey, cheer up buddy!"
    jn "Let's go clubbing tonight."
    jn "It'll make you feel better."

    scene e1s6-67 with vpunch
    play sound punch
    pause

    scene e1s6-68 with dissolve
    unknown "Watch where you're going!"

    scene e1s6-69 with dissolve
    unknown "Haha!"

    scene e1s6-70 with dissolve
    mc "But I wasn't-"

    scene e1s6-71 with dissolve
    mc "Hey!"

    scene e1s6-72 with dissolve
    jn "It's not worth it bro, just drop it."

    scene e1s6-74 with dissolve
    show e1s6-jon_blink4
    mc "Why are you taking their side?"

    scene e1s6-73 with dissolve
    hide e1s6-jon_blink4
    jn "I'm not taking their side..."
    jn "It's just not worth it."
    jn "Guys like these are only looking for trouble, which might get {b}you{/b} into trouble if you get involved with them."

    scene e1s6-75 with dissolve
    menu:
        "Be mad about it":
            call extrovert_affinity_check from _call_extrovert_affinity_check_22
            $ e1s6_mad = True
            call color_check from _call_color_check_44
            scene e1s6-74 with dissolve
            show e1s6-jon_blink4
            mc "But those guys are asking for it, what's their problem?"

            scene e1s6-73 with dissolve
            hide e1s6-jon_blink4
            jn "Just trust me on this one okay?"

            scene e1s6-74 with dissolve
            show e1s6-jon_blink4
            mc "Alright, fine."
            mc "But next time they won't get away so easily."

        "Drop it":
            call introvert_affinity_check from _call_introvert_affinity_check_19
            call color_check from _call_color_check_45
            scene e1s6-74 with dissolve
            show e1s6-jon_blink4
            mc "You're right, they're just assholes."

    scene e1s6-76 with dissolve
    hide e1s6-jon_blink4
    jn "Let's get out of here, I'm starving!"

    scene e1s6-77 with dissolve
    pause

    scene e1s6-78 with dissolve
    pause

    stop music fadeout 2.5
    scene black with Dissolve(2.0)
    jump e1s7
return
