
# Scene 5 Images ###############################################################

image e1s5-01 = im.Scale("season1/episode1/images/scene5/1.webp", 1920, 1080)
image e1s5-02 = im.Scale("season1/episode1/images/scene5/2.webp", 1920, 1080)
image e1s5-03 = im.Scale("season1/episode1/images/scene5/3.webp", 1920, 1080)
image e1s5-04 = im.Scale("season1/episode1/images/scene5/4.webp", 1920, 1080)
image e1s5-05 = im.Scale("season1/episode1/images/scene5/5.webp", 1920, 1080)
image e1s5-06 = im.Scale("season1/episode1/images/scene5/6.webp", 1920, 1080)
image e1s5-07 = im.Scale("season1/episode1/images/scene5/7.webp", 1920, 1080)
image e1s5-08 = im.Scale("season1/episode1/images/scene5/8.webp", 1920, 1080)
image e1s5-09 = im.Scale("season1/episode1/images/scene5/9.webp", 1920, 1080)
image e1s5-10 = im.Scale("season1/episode1/images/scene5/10.webp", 1920, 1080)
image e1s5-11 = im.Scale("season1/episode1/images/scene5/11.webp", 1920, 1080)
image e1s5-12 = im.Scale("season1/episode1/images/scene5/12.webp", 1920, 1080)
image e1s5-13 = im.Scale("season1/episode1/images/scene5/13.webp", 1920, 1080)
image e1s5-14 = im.Scale("season1/episode1/images/scene5/14.webp", 1920, 1080)
image e1s5-15 = im.Scale("season1/episode1/images/scene5/15.webp", 1920, 1080)
image e1s5-16 = im.Scale("season1/episode1/images/scene5/16.webp", 1920, 1080)
image e1s5-17 = im.Scale("season1/episode1/images/scene5/17.webp", 1920, 1080)

image e1s5-mc_blink1:
    im.Scale("season1/episode1/images/scene5/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s5-mc_blink2:
    im.Scale("season1/episode1/images/scene5/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/mc_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s5-jon_blink1:
    im.Scale("season1/episode1/images/scene5/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene5/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
