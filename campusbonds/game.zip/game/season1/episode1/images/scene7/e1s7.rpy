
# Scene 7 Images ###############################################################

image e1s7-01 = im.Scale("season1/episode1/images/scene7/1.webp", 1920, 1080)
image e1s7-02 = im.Scale("season1/episode1/images/scene7/2.webp", 1920, 1080)
image e1s7-03 = im.Scale("season1/episode1/images/scene7/3.webp", 1920, 1080)
image e1s7-04 = im.Scale("season1/episode1/images/scene7/4.webp", 1920, 1080)
image e1s7-05 = im.Scale("season1/episode1/images/scene7/5.webp", 1920, 1080)
image e1s7-06 = im.Scale("season1/episode1/images/scene7/6.webp", 1920, 1080)
image e1s7-07 = im.Scale("season1/episode1/images/scene7/7.webp", 1920, 1080)
image e1s7-08 = im.Scale("season1/episode1/images/scene7/8.webp", 1920, 1080)
image e1s7-09 = im.Scale("season1/episode1/images/scene7/9.webp", 1920, 1080)
image e1s7-10 = im.Scale("season1/episode1/images/scene7/10.webp", 1920, 1080)
image e1s7-11 = im.Scale("season1/episode1/images/scene7/11.webp", 1920, 1080)
image e1s7-12 = im.Scale("season1/episode1/images/scene7/12.webp", 1920, 1080)
image e1s7-13 = im.Scale("season1/episode1/images/scene7/13.webp", 1920, 1080)
image e1s7-14 = im.Scale("season1/episode1/images/scene7/14.webp", 1920, 1080)
image e1s7-15 = im.Scale("season1/episode1/images/scene7/15.webp", 1920, 1080)
image e1s7-16 = im.Scale("season1/episode1/images/scene7/16.webp", 1920, 1080)
image e1s7-17 = im.Scale("season1/episode1/images/scene7/17.webp", 1920, 1080)
image e1s7-18 = im.Scale("season1/episode1/images/scene7/18.webp", 1920, 1080)
image e1s7-19 = im.Scale("season1/episode1/images/scene7/19.webp", 1920, 1080)
image e1s7-20 = im.Scale("season1/episode1/images/scene7/20.webp", 1920, 1080)
image e1s7-21 = im.Scale("season1/episode1/images/scene7/21.webp", 1920, 1080)
image e1s7-22 = im.Scale("season1/episode1/images/scene7/22.webp", 1920, 1080)
image e1s7-23 = im.Scale("season1/episode1/images/scene7/23.webp", 1920, 1080)
image e1s7-24 = im.Scale("season1/episode1/images/scene7/24.webp", 1920, 1080)
image e1s7-25 = im.Scale("season1/episode1/images/scene7/25.webp", 1920, 1080)
image e1s7-26 = im.Scale("season1/episode1/images/scene7/26.webp", 1920, 1080)
image e1s7-27 = im.Scale("season1/episode1/images/scene7/27.webp", 1920, 1080)
image e1s7-28 = im.Scale("season1/episode1/images/scene7/28.webp", 1920, 1080)
image e1s7-29 = im.Scale("season1/episode1/images/scene7/29.webp", 1920, 1080)
image e1s7-30 = im.Scale("season1/episode1/images/scene7/30.webp", 1920, 1080)
image e1s7-31 = im.Scale("season1/episode1/images/scene7/31.webp", 1920, 1080)
image e1s7-32 = im.Scale("season1/episode1/images/scene7/32.webp", 1920, 1080)
image e1s7-33 = im.Scale("season1/episode1/images/scene7/33.webp", 1920, 1080)
image e1s7-34 = im.Scale("season1/episode1/images/scene7/34.webp", 1920, 1080)
image e1s7-35 = im.Scale("season1/episode1/images/scene7/35.webp", 1920, 1080)
image e1s7-36 = im.Scale("season1/episode1/images/scene7/36.webp", 1920, 1080)
image e1s7-37 = im.Scale("season1/episode1/images/scene7/37.webp", 1920, 1080)
image e1s7-38 = im.Scale("season1/episode1/images/scene7/38.webp", 1920, 1080)
image e1s7-39 = im.Scale("season1/episode1/images/scene7/39.webp", 1920, 1080)
image e1s7-40 = im.Scale("season1/episode1/images/scene7/40.webp", 1920, 1080)
image e1s7-41 = im.Scale("season1/episode1/images/scene7/41.webp", 1920, 1080)
image e1s7-42 = im.Scale("season1/episode1/images/scene7/42.webp", 1920, 1080)
image e1s7-43 = im.Scale("season1/episode1/images/scene7/43.webp", 1920, 1080)
image e1s7-44 = im.Scale("season1/episode1/images/scene7/44.webp", 1920, 1080)
image e1s7-45 = im.Scale("season1/episode1/images/scene7/45.webp", 1920, 1080)
image e1s7-46 = im.Scale("season1/episode1/images/scene7/46.webp", 1920, 1080)
image e1s7-47 = im.Scale("season1/episode1/images/scene7/47.webp", 1920, 1080)
image e1s7-48 = im.Scale("season1/episode1/images/scene7/48.webp", 1920, 1080)
image e1s7-49 = im.Scale("season1/episode1/images/scene7/49.webp", 1920, 1080)


image e1s7_cleo_blink1:
    im.Scale("season1/episode1/images/scene7/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s7_cleo_blink2:
    im.Scale("season1/episode1/images/scene7/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s7_jon_blink1:
    im.Scale("season1/episode1/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
