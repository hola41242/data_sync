
# Scene 16 images ##############################################################

image e1s16-01 = im.Scale("season1/episode1/images/scene16/1.webp", 1920, 1080)
image e1s16-02 = im.Scale("season1/episode1/images/scene16/2.webp", 1920, 1080)
image e1s16-03 = im.Scale("season1/episode1/images/scene16/3.webp", 1920, 1080)
image e1s16-04 = im.Scale("season1/episode1/images/scene16/4.webp", 1920, 1080)
image e1s16-05 = im.Scale("season1/episode1/images/scene16/5.webp", 1920, 1080)
image e1s16-06 = im.Scale("season1/episode1/images/scene16/6.webp", 1920, 1080)
image e1s16-07 = im.Scale("season1/episode1/images/scene16/7.webp", 1920, 1080)
image e1s16-08 = im.Scale("season1/episode1/images/scene16/8.webp", 1920, 1080)
image e1s16-09 = im.Scale("season1/episode1/images/scene16/9.webp", 1920, 1080)
image e1s16-10 = im.Scale("season1/episode1/images/scene16/10.webp", 1920, 1080)
image e1s16-11 = im.Scale("season1/episode1/images/scene16/11.webp", 1920, 1080)
image e1s16-12 = im.Scale("season1/episode1/images/scene16/12.webp", 1920, 1080)
image e1s16-13 = im.Scale("season1/episode1/images/scene16/13.webp", 1920, 1080)
image e1s16-14 = im.Scale("season1/episode1/images/scene16/14.webp", 1920, 1080)
image e1s16-15 = im.Scale("season1/episode1/images/scene16/15.webp", 1920, 1080)
image e1s16-16 = im.Scale("season1/episode1/images/scene16/16.webp", 1920, 1080)
image e1s16-17 = im.Scale("season1/episode1/images/scene16/17.webp", 1920, 1080)
image e1s16-18 = im.Scale("season1/episode1/images/scene16/18.webp", 1920, 1080)
image e1s16-19 = im.Scale("season1/episode1/images/scene16/19.webp", 1920, 1080)
image e1s16-20 = im.Scale("season1/episode1/images/scene16/20.webp", 1920, 1080)
image e1s16-21 = im.Scale("season1/episode1/images/scene16/21.webp", 1920, 1080)
image e1s16-22 = im.Scale("season1/episode1/images/scene16/22.webp", 1920, 1080)
image e1s16-23 = im.Scale("season1/episode1/images/scene16/23.webp", 1920, 1080)
image e1s16-24 = im.Scale("season1/episode1/images/scene16/24.webp", 1920, 1080)
image e1s16-25 = im.Scale("season1/episode1/images/scene16/25.webp", 1920, 1080)
image e1s16-26 = im.Scale("season1/episode1/images/scene16/26.webp", 1920, 1080)
image e1s16-27 = im.Scale("season1/episode1/images/scene16/27.webp", 1920, 1080)
image e1s16-28 = im.Scale("season1/episode1/images/scene16/28.webp", 1920, 1080)
image e1s16-29 = im.Scale("season1/episode1/images/scene16/29.webp", 1920, 1080)
image e1s16-30 = im.Scale("season1/episode1/images/scene16/30.webp", 1920, 1080)

# Sadie Blink ###################################################################

image e1s16_sadie_blink1:
    im.Scale("season1/episode1/images/scene16/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene16/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Passing Stranger #############################################################

image e1s16_pass_str:
    im.Scale("season1/episode1/images/scene16/9.webp", 1920, 1080) with dissolve
    4
    im.Scale("season1/episode1/images/scene16/11.webp", 1920, 1080) with dissolve
    4
    im.Scale("season1/episode1/images/scene16/20.webp", 1920, 1080) with dissolve
