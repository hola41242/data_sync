
# Scene 17 images ##############################################################

# Tracy ########################################################################
image tr-e1s17-01 = im.Scale("season1/episode1/images/scene17/tracy/1.webp", 1920, 1080)
image tr-e1s17-02 = im.Scale("season1/episode1/images/scene17/tracy/2.webp", 1920, 1080)
image tr-e1s17-03 = im.Scale("season1/episode1/images/scene17/tracy/3.webp", 1920, 1080)
image tr-e1s17-04 = im.Scale("season1/episode1/images/scene17/tracy/4.webp", 1920, 1080)
image tr-e1s17-05 = im.Scale("season1/episode1/images/scene17/tracy/5.webp", 1920, 1080)
image tr-e1s17-06 = im.Scale("season1/episode1/images/scene17/tracy/6.webp", 1920, 1080)
image tr-e1s17-07 = im.Scale("season1/episode1/images/scene17/tracy/7.webp", 1920, 1080)
image tr-e1s17-08 = im.Scale("season1/episode1/images/scene17/tracy/8.webp", 1920, 1080)
image tr-e1s17-09 = im.Scale("season1/episode1/images/scene17/tracy/9.webp", 1920, 1080)
image tr-e1s17-10 = im.Scale("season1/episode1/images/scene17/tracy/10.webp", 1920, 1080)
image tr-e1s17-11 = im.Scale("season1/episode1/images/scene17/tracy/11.webp", 1920, 1080)
image tr-e1s17-12 = im.Scale("season1/episode1/images/scene17/tracy/12.webp", 1920, 1080)
image tr-e1s17-13 = im.Scale("season1/episode1/images/scene17/tracy/13.webp", 1920, 1080)
image tr-e1s17-14 = im.Scale("season1/episode1/images/scene17/tracy/14.webp", 1920, 1080)
image tr-e1s17-15 = im.Scale("season1/episode1/images/scene17/tracy/15.webp", 1920, 1080)
image tr-e1s17-16 = im.Scale("season1/episode1/images/scene17/tracy/16.webp", 1920, 1080)
image tr-e1s17-17 = im.Scale("season1/episode1/images/scene17/tracy/17.webp", 1920, 1080)
image tr-e1s17-18 = im.Scale("season1/episode1/images/scene17/tracy/18.webp", 1920, 1080)
image tr-e1s17-19 = im.Scale("season1/episode1/images/scene17/tracy/19.webp", 1920, 1080)
image tr-e1s17-20 = im.Scale("season1/episode1/images/scene17/tracy/20.webp", 1920, 1080)
image tr-e1s17-21 = im.Scale("season1/episode1/images/scene17/tracy/21.webp", 1920, 1080)
image tr-e1s17-22 = im.Scale("season1/episode1/images/scene17/tracy/22.webp", 1920, 1080)
image tr-e1s17-23 = im.Scale("season1/episode1/images/scene17/tracy/23.webp", 1920, 1080)

image tr-e1s17_kiss = Movie(play="season1/episode1/images/scene17/tracy/kiss.webm")
image tr-e1s17_touch = Movie(play="season1/episode1/images/scene17/tracy/touch.webm")

# Tracy Blink ##################################################################

image e1s17-tracy_blink1:
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-tracy_blink2:
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-tracy_blink3:
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-tracy_blink4:
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/tracy/tracy_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie ########################################################################
image sd-e1s17-01 = im.Scale("season1/episode1/images/scene17/sadie/1.webp", 1920, 1080)
image sd-e1s17-02 = im.Scale("season1/episode1/images/scene17/sadie/2.webp", 1920, 1080)
image sd-e1s17-03 = im.Scale("season1/episode1/images/scene17/sadie/3.webp", 1920, 1080)
image sd-e1s17-04 = im.Scale("season1/episode1/images/scene17/sadie/4.webp", 1920, 1080)
image sd-e1s17-05 = im.Scale("season1/episode1/images/scene17/sadie/5.webp", 1920, 1080)
image sd-e1s17-06 = im.Scale("season1/episode1/images/scene17/sadie/6.webp", 1920, 1080)
image sd-e1s17-07 = im.Scale("season1/episode1/images/scene17/sadie/7.webp", 1920, 1080)
image sd-e1s17-08 = im.Scale("season1/episode1/images/scene17/sadie/8.webp", 1920, 1080)
image sd-e1s17-09 = im.Scale("season1/episode1/images/scene17/sadie/9.webp", 1920, 1080)
image sd-e1s17-10 = im.Scale("season1/episode1/images/scene17/sadie/10.webp", 1920, 1080)
image sd-e1s17-11 = im.Scale("season1/episode1/images/scene17/sadie/11.webp", 1920, 1080)
image sd-e1s17-12 = im.Scale("season1/episode1/images/scene17/sadie/12.webp", 1920, 1080)
image sd-e1s17-13 = im.Scale("season1/episode1/images/scene17/sadie/13.webp", 1920, 1080)
image sd-e1s17-14 = im.Scale("season1/episode1/images/scene17/sadie/14.webp", 1920, 1080)
image sd-e1s17-15 = im.Scale("season1/episode1/images/scene17/sadie/15.webp", 1920, 1080)
image sd-e1s17-16 = im.Scale("season1/episode1/images/scene17/sadie/16.webp", 1920, 1080)
image sd-e1s17-17 = im.Scale("season1/episode1/images/scene17/sadie/17.webp", 1920, 1080)
image sd-e1s17-18 = im.Scale("season1/episode1/images/scene17/sadie/18.webp", 1920, 1080)
image sd-e1s17-19 = im.Scale("season1/episode1/images/scene17/sadie/19.webp", 1920, 1080)
image sd-e1s17-20 = im.Scale("season1/episode1/images/scene17/sadie/20.webp", 1920, 1080)
image sd-e1s17-21 = im.Scale("season1/episode1/images/scene17/sadie/21.webp", 1920, 1080)
image sd-e1s17-22 = im.Scale("season1/episode1/images/scene17/sadie/22.webp", 1920, 1080)
image sd-e1s17-23 = im.Scale("season1/episode1/images/scene17/sadie/23.webp", 1920, 1080)
image sd-e1s17-24 = im.Scale("season1/episode1/images/scene17/sadie/24.webp", 1920, 1080)
image sd-e1s17-25 = im.Scale("season1/episode1/images/scene17/sadie/25.webp", 1920, 1080)
image sd-e1s17-26 = im.Scale("season1/episode1/images/scene17/sadie/26.webp", 1920, 1080)
image sd-e1s17-27 = im.Scale("season1/episode1/images/scene17/sadie/27.webp", 1920, 1080)
image sd-e1s17-28 = im.Scale("season1/episode1/images/scene17/sadie/28.webp", 1920, 1080)
image sd-e1s17-29 = im.Scale("season1/episode1/images/scene17/sadie/29.webp", 1920, 1080)
image sd-e1s17-30 = im.Scale("season1/episode1/images/scene17/sadie/30.webp", 1920, 1080)
image sd-e1s17-31 = im.Scale("season1/episode1/images/scene17/sadie/31.webp", 1920, 1080)
image sd-e1s17-32 = im.Scale("season1/episode1/images/scene17/sadie/32.webp", 1920, 1080)
image sd-e1s17-33 = im.Scale("season1/episode1/images/scene17/sadie/33.webp", 1920, 1080)
image sd-e1s17-34 = im.Scale("season1/episode1/images/scene17/sadie/34.webp", 1920, 1080)
image sd-e1s17-35 = im.Scale("season1/episode1/images/scene17/sadie/35.webp", 1920, 1080)
image sd-e1s17-36 = im.Scale("season1/episode1/images/scene17/sadie/36.webp", 1920, 1080)
image sd-e1s17-37 = im.Scale("season1/episode1/images/scene17/sadie/37.webp", 1920, 1080)
image sd-e1s17-38 = im.Scale("season1/episode1/images/scene17/sadie/38.webp", 1920, 1080)
image sd-e1s17-39 = im.Scale("season1/episode1/images/scene17/sadie/39.webp", 1920, 1080)
image sd-e1s17-40 = im.Scale("season1/episode1/images/scene17/sadie/40.webp", 1920, 1080)
image sd-e1s17-41 = im.Scale("season1/episode1/images/scene17/sadie/41.webp", 1920, 1080)
image sd-e1s17-42 = im.Scale("season1/episode1/images/scene17/sadie/42.webp", 1920, 1080)
image sd-e1s17-43 = im.Scale("season1/episode1/images/scene17/sadie/43.webp", 1920, 1080)
image sd-e1s17-44 = im.Scale("season1/episode1/images/scene17/sadie/44.webp", 1920, 1080)
image sd-e1s17-45 = im.Scale("season1/episode1/images/scene17/sadie/45.webp", 1920, 1080)
image sd-e1s17-46 = im.Scale("season1/episode1/images/scene17/sadie/46.webp", 1920, 1080)
image sd-e1s17-47 = im.Scale("season1/episode1/images/scene17/sadie/47.webp", 1920, 1080)
image sd-e1s17-48 = im.Scale("season1/episode1/images/scene17/sadie/48.webp", 1920, 1080)
image sd-e1s17-49 = im.Scale("season1/episode1/images/scene17/sadie/49.webp", 1920, 1080)
image sd-e1s17-50 = im.Scale("season1/episode1/images/scene17/sadie/50.webp", 1920, 1080)
image sd-e1s17-51 = im.Scale("season1/episode1/images/scene17/sadie/51.webp", 1920, 1080)
image sd-e1s17-52 = im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080)
image sd-e1s17-53 = im.Scale("season1/episode1/images/scene17/sadie/53.webp", 1920, 1080)
image sd-e1s17-54 = im.Scale("season1/episode1/images/scene17/sadie/54.webp", 1920, 1080)
image sd-e1s17-55 = im.Scale("season1/episode1/images/scene17/sadie/55.webp", 1920, 1080)
image sd-e1s17-56 = im.Scale("season1/episode1/images/scene17/sadie/56.webp", 1920, 1080)
image sd-e1s17-57 = im.Scale("season1/episode1/images/scene17/sadie/57.webp", 1920, 1080)
image sd-e1s17-58 = im.Scale("season1/episode1/images/scene17/sadie/58.webp", 1920, 1080)
image sd-e1s17-59 = im.Scale("season1/episode1/images/scene17/sadie/59.webp", 1920, 1080)
image sd-e1s17-60 = im.Scale("season1/episode1/images/scene17/sadie/60.webp", 1920, 1080)
image sd-e1s17-61 = im.Scale("season1/episode1/images/scene17/sadie/61.webp", 1920, 1080)
image sd-e1s17-62 = im.Scale("season1/episode1/images/scene17/sadie/62.webp", 1920, 1080)
image sd-e1s17-63 = im.Scale("season1/episode1/images/scene17/sadie/63.webp", 1920, 1080)
image sd-e1s17-64 = im.Scale("season1/episode1/images/scene17/sadie/64.webp", 1920, 1080)

# Sadie Blink ##################################################################

image e1s17-jordan_blink1:
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-jordan_blink2:
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/jordan_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink1:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink2:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink3:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink4:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink5_smile:
    im.Scale("transparent.png", 1920, 1080) with dissolve
    7.0
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    3.40
    repeat

image e1s17-sadie_blink5_serious:
    im.Scale("transparent.png", 1920, 1080) with dissolve
    7.0
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    3.40
    repeat

image e1s17-sadie_blink6:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_blink6_1:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/6.webp", 1920, 1080) with dissolve
    2.0
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("transparent.png", 1920, 1080) with dissolve
    0.01

image e1s17-sadie_blink7:
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/sadie_blink7/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-sadie_eat_smile:
    im.Scale("season1/episode1/images/scene17/sadie/44.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/49.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/50.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/51.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/53.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/54.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/53.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/54.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("transparent.png", 1920, 1080) with dissolve
    4.0
    repeat

image e1s17-sadie_eat_serious:
    im.Scale("season1/episode1/images/scene17/sadie/40.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/sadie/49.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/50.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/51.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/53.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/54.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/53.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/52.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode1/images/scene17/sadie/54.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("transparent.png", 1920, 1080) with dissolve
    4.0
    repeat

# Olivia #######################################################################
image ov-e1s17-01 = im.Scale("season1/episode1/images/scene17/olivia/1.webp", 1920, 1080)
image ov-e1s17-02 = im.Scale("season1/episode1/images/scene17/olivia/2.webp", 1920, 1080)
image ov-e1s17-03 = im.Scale("season1/episode1/images/scene17/olivia/3.webp", 1920, 1080)
image ov-e1s17-04 = im.Scale("season1/episode1/images/scene17/olivia/4.webp", 1920, 1080)
image ov-e1s17-05 = im.Scale("season1/episode1/images/scene17/olivia/5.webp", 1920, 1080)
image ov-e1s17-06 = im.Scale("season1/episode1/images/scene17/olivia/6.webp", 1920, 1080)
image ov-e1s17-07 = im.Scale("season1/episode1/images/scene17/olivia/7.webp", 1920, 1080)
image ov-e1s17-07-1 = im.Scale("season1/episode1/images/scene17/olivia/7.1.webp", 1920, 1080)
image ov-e1s17-08 = im.Scale("season1/episode1/images/scene17/olivia/8.webp", 1920, 1080)
image ov-e1s17-09 = im.Scale("season1/episode1/images/scene17/olivia/9.webp", 1920, 1080)
image ov-e1s17-10 = im.Scale("season1/episode1/images/scene17/olivia/10.webp", 1920, 1080)
image ov-e1s17-11 = im.Scale("season1/episode1/images/scene17/olivia/11.webp", 1920, 1080)
image ov-e1s17-12 = im.Scale("season1/episode1/images/scene17/olivia/12.webp", 1920, 1080)
image ov-e1s17-13 = im.Scale("season1/episode1/images/scene17/olivia/13.webp", 1920, 1080)
image ov-e1s17-14 = im.Scale("season1/episode1/images/scene17/olivia/14.webp", 1920, 1080)
image ov-e1s17-15 = im.Scale("season1/episode1/images/scene17/olivia/15.webp", 1920, 1080)
image ov-e1s17-16 = im.Scale("season1/episode1/images/scene17/olivia/16.webp", 1920, 1080)
image ov-e1s17-17 = im.Scale("season1/episode1/images/scene17/olivia/17.webp", 1920, 1080)
image ov-e1s17-18 = im.Scale("season1/episode1/images/scene17/olivia/18.webp", 1920, 1080)
image ov-e1s17-19 = im.Scale("season1/episode1/images/scene17/olivia/19.webp", 1920, 1080)
image ov-e1s17-20 = im.Scale("season1/episode1/images/scene17/olivia/20.webp", 1920, 1080)
image ov-e1s17-21 = im.Scale("season1/episode1/images/scene17/olivia/21.webp", 1920, 1080)
image ov-e1s17-22 = im.Scale("season1/episode1/images/scene17/olivia/22.webp", 1920, 1080)
image ov-e1s17-23 = im.Scale("season1/episode1/images/scene17/olivia/23.webp", 1920, 1080)
image ov-e1s17-24 = im.Scale("season1/episode1/images/scene17/olivia/24.webp", 1920, 1080)
image ov-e1s17-25 = im.Scale("season1/episode1/images/scene17/olivia/25.webp", 1920, 1080)
image ov-e1s17-26 = im.Scale("season1/episode1/images/scene17/olivia/26.webp", 1920, 1080)
image ov-e1s17-27 = im.Scale("season1/episode1/images/scene17/olivia/27.webp", 1920, 1080)
image ov-e1s17-28 = im.Scale("season1/episode1/images/scene17/olivia/28.webp", 1920, 1080)
image ov-e1s17-29 = im.Scale("season1/episode1/images/scene17/olivia/29.webp", 1920, 1080)
image ov-e1s17-30 = im.Scale("season1/episode1/images/scene17/olivia/30.webp", 1920, 1080)
image ov-e1s17-31 = im.Scale("season1/episode1/images/scene17/olivia/31.webp", 1920, 1080)
image ov-e1s17-32 = im.Scale("season1/episode1/images/scene17/olivia/32.webp", 1920, 1080)
image ov-e1s17-33 = im.Scale("season1/episode1/images/scene17/olivia/33.webp", 1920, 1080)
image ov-e1s17-34 = im.Scale("season1/episode1/images/scene17/olivia/34.webp", 1920, 1080)
image ov-e1s17-35 = im.Scale("season1/episode1/images/scene17/olivia/35.webp", 1920, 1080)
image ov-e1s17-36 = im.Scale("season1/episode1/images/scene17/olivia/36.webp", 1920, 1080)
image ov-e1s17-37 = im.Scale("season1/episode1/images/scene17/olivia/37.webp", 1920, 1080)
image ov-e1s17-38 = im.Scale("season1/episode1/images/scene17/olivia/38.webp", 1920, 1080)
image ov-e1s17-39 = im.Scale("season1/episode1/images/scene17/olivia/39.webp", 1920, 1080)
image ov-e1s17-40 = im.Scale("season1/episode1/images/scene17/olivia/40.webp", 1920, 1080)
image ov-e1s17-41 = im.Scale("season1/episode1/images/scene17/olivia/41.webp", 1920, 1080)
image ov-e1s17-42 = im.Scale("season1/episode1/images/scene17/olivia/42.webp", 1920, 1080)
image ov-e1s17-43 = im.Scale("season1/episode1/images/scene17/olivia/43.webp", 1920, 1080)
image ov-e1s17-44 = im.Scale("season1/episode1/images/scene17/olivia/44.webp", 1920, 1080)
image ov-e1s17-45 = im.Scale("season1/episode1/images/scene17/olivia/45.webp", 1920, 1080)
image ov-e1s17-46 = im.Scale("season1/episode1/images/scene17/olivia/46.webp", 1920, 1080)
image ov-e1s17-47 = im.Scale("season1/episode1/images/scene17/olivia/47.webp", 1920, 1080)
image ov-e1s17-48 = im.Scale("season1/episode1/images/scene17/olivia/48.webp", 1920, 1080)
image ov-e1s17-49 = im.Scale("season1/episode1/images/scene17/olivia/49.webp", 1920, 1080)
image ov-e1s17-50 = im.Scale("season1/episode1/images/scene17/olivia/50.webp", 1920, 1080)
image ov-e1s17-51 = im.Scale("season1/episode1/images/scene17/olivia/51.webp", 1920, 1080)
image ov-e1s17-52 = im.Scale("season1/episode1/images/scene17/olivia/52.webp", 1920, 1080)
image ov-e1s17-53 = im.Scale("season1/episode1/images/scene17/olivia/53.webp", 1920, 1080)
image ov-e1s17-54 = im.Scale("season1/episode1/images/scene17/olivia/54.webp", 1920, 1080)
image ov-e1s17-55 = im.Scale("season1/episode1/images/scene17/olivia/55.webp", 1920, 1080)
image ov-e1s17-56 = im.Scale("season1/episode1/images/scene17/olivia/56.webp", 1920, 1080)
image ov-e1s17-57 = im.Scale("season1/episode1/images/scene17/olivia/57.webp", 1920, 1080)
image ov-e1s17-58 = im.Scale("season1/episode1/images/scene17/olivia/58.webp", 1920, 1080)
image ov-e1s17-59 = im.Scale("season1/episode1/images/scene17/olivia/59.webp", 1920, 1080)
image ov-e1s17-60 = im.Scale("season1/episode1/images/scene17/olivia/60.webp", 1920, 1080)
image ov-e1s17-61 = im.Scale("season1/episode1/images/scene17/olivia/61.webp", 1920, 1080)
image ov-e1s17-62 = im.Scale("season1/episode1/images/scene17/olivia/62.webp", 1920, 1080)
image ov-e1s17-63 = im.Scale("season1/episode1/images/scene17/olivia/63.webp", 1920, 1080)
image ov-e1s17-64 = im.Scale("season1/episode1/images/scene17/olivia/64.webp", 1920, 1080)
image ov-e1s17-65 = im.Scale("season1/episode1/images/scene17/olivia/65.webp", 1920, 1080)
image ov-e1s17-66 = im.Scale("season1/episode1/images/scene17/olivia/66.webp", 1920, 1080)
image ov-e1s17-67 = im.Scale("season1/episode1/images/scene17/olivia/67.webp", 1920, 1080)
image ov-e1s17-68 = im.Scale("season1/episode1/images/scene17/olivia/68.webp", 1920, 1080)
image ov-e1s17-69 = im.Scale("season1/episode1/images/scene17/olivia/69.webp", 1920, 1080)
image ov-e1s17-70 = im.Scale("season1/episode1/images/scene17/olivia/70.webp", 1920, 1080)
image ov-e1s17-71 = im.Scale("season1/episode1/images/scene17/olivia/71.webp", 1920, 1080)
image ov-e1s17-72 = im.Scale("season1/episode1/images/scene17/olivia/72.webp", 1920, 1080)
image ov-e1s17-73 = im.Scale("season1/episode1/images/scene17/olivia/73.webp", 1920, 1080)
image ov-e1s17-74 = im.Scale("season1/episode1/images/scene17/olivia/74.webp", 1920, 1080)
image ov-e1s17-75 = im.Scale("season1/episode1/images/scene17/olivia/75.webp", 1920, 1080)
image ov-e1s17-76 = im.Scale("season1/episode1/images/scene17/olivia/76.webp", 1920, 1080)
image ov-e1s17-77 = im.Scale("season1/episode1/images/scene17/olivia/77.webp", 1920, 1080)
image ov-e1s17-78 = im.Scale("season1/episode1/images/scene17/olivia/78.webp", 1920, 1080)
image ov-e1s17-79 = im.Scale("season1/episode1/images/scene17/olivia/79.webp", 1920, 1080)
image ov-e1s17-80 = im.Scale("season1/episode1/images/scene17/olivia/80.webp", 1920, 1080)
image ov-e1s17-81 = im.Scale("season1/episode1/images/scene17/olivia/81.webp", 1920, 1080)
image ov-e1s17-82 = im.Scale("season1/episode1/images/scene17/olivia/82.webp", 1920, 1080)
image ov-e1s17-83 = im.Scale("season1/episode1/images/scene17/olivia/83.webp", 1920, 1080)
image ov-e1s17-84 = im.Scale("season1/episode1/images/scene17/olivia/84.webp", 1920, 1080)
image ov-e1s17-85 = im.Scale("season1/episode1/images/scene17/olivia/85.webp", 1920, 1080)
image ov-e1s17-86 = im.Scale("season1/episode1/images/scene17/olivia/86.webp", 1920, 1080)
image ov-e1s17-87 = im.Scale("season1/episode1/images/scene17/olivia/87.webp", 1920, 1080)
image ov-e1s17-88 = im.Scale("season1/episode1/images/scene17/olivia/88.webp", 1920, 1080)
image ov-e1s17-89 = im.Scale("season1/episode1/images/scene17/olivia/89.webp", 1920, 1080)
image ov-e1s17-90 = im.Scale("season1/episode1/images/scene17/olivia/90.webp", 1920, 1080)
image ov-e1s17-91 = im.Scale("season1/episode1/images/scene17/olivia/91.webp", 1920, 1080)
image ov-e1s17-92 = im.Scale("season1/episode1/images/scene17/olivia/92.webp", 1920, 1080)

image ov-e1s17_squat1 = Movie(play="season1/episode1/images/scene17/olivia/squat1.webm")
image ov-e1s17_squat2 = Movie(play="season1/episode1/images/scene17/olivia/squat2.webm")
image ov-e1s17_kiss1 = Movie(play="season1/episode1/images/scene17/olivia/kiss1.webm")
image ov-e1s17_kiss2 = Movie(play="season1/episode1/images/scene17/olivia/kiss2.webm")

# Pedestrian Anim ##############################################################

image e1s17_pedestrian_anim:
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/1.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/2.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/3.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/4.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/5.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/6.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode1/images/scene17/olivia/pedestrian_anim/7.webp", 1920, 1080) with dissolve
    1.0

# Taxi Anim ##############################################################

image e1s17_taxi_anim:
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/1.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/2.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/3.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/4.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/5.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/6.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/7.webp", 1920, 1080) with dissolve
    0.4
    im.Scale("season1/episode1/images/scene17/olivia/taxi_anim/8.webp", 1920, 1080) with dissolve
    0.4

# Olivia Blink #################################################################

image e1s17-olivia_blink1:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink2:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink3:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink4:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink5:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink6:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink6/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink7:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink7/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink8:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink8/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink9:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink9/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink10:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink10/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink11:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink11/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink12:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink12/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink13:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink13/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s17-olivia_blink14:
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/olivia_blink14/0.webp", 1920, 1080) with dissolve
    4
    repeat

# MC Blink #################################################################

image ov_e1s17-mc_blink1:
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image ov_e1s17-mc_blink2:
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene17/olivia/mc_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
