# Images #######################################################################

image e1f2-01 = im.Scale("season1/episode1/images/freeroam2/1.webp", 1920, 1080)
image e1f2-01-1 = im.Scale("season1/episode1/images/freeroam2/1-1.webp", 1920, 1080)
image e1f2-01-2 = im.Scale("season1/episode1/images/freeroam2/1-2.webp", 1920, 1080)
image e1f2-01-3 = im.Scale("season1/episode1/images/freeroam2/1-3.webp", 1920, 1080)
image e1f2-01-4 = im.Scale("season1/episode1/images/freeroam2/1-4.webp", 1920, 1080)

image e1f2-02 = im.Scale("season1/episode1/images/freeroam2/2.webp", 1920, 1080)
image e1f2-02-1 = im.Scale("season1/episode1/images/freeroam2/2-1.webp", 1920, 1080)
image e1f2-02-2 = im.Scale("season1/episode1/images/freeroam2/2-2.webp", 1920, 1080)
image e1f2-02-3 = im.Scale("season1/episode1/images/freeroam2/2-3.webp", 1920, 1080)
image e1f2-02-4 = im.Scale("season1/episode1/images/freeroam2/2-4.webp", 1920, 1080)

# Tracy_Sadie E1F2 #############################################################

image ts-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/1.webp", 1920, 1080)
image ts-e1f2-02 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/2.webp", 1920, 1080)
image ts-e1f2-03 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/3.webp", 1920, 1080)
image ts-e1f2-04 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/4.webp", 1920, 1080)
image ts-e1f2-05 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/5.webp", 1920, 1080)
image ts-e1f2-06 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/6.webp", 1920, 1080)
image ts-e1f2-07 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/7.webp", 1920, 1080)
image ts-e1f2-08 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/8.webp", 1920, 1080)
image ts-e1f2-09 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/9.webp", 1920, 1080)
image ts-e1f2-10 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/10.webp", 1920, 1080)
image ts-e1f2-11 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/11.webp", 1920, 1080)
image ts-e1f2-12 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/12.webp", 1920, 1080)
image ts-e1f2-13 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/13.webp", 1920, 1080)
image ts-e1f2-14 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/14.webp", 1920, 1080)
image ts-e1f2-15 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/15.webp", 1920, 1080)
image ts-e1f2-16 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/16.webp", 1920, 1080)
image ts-e1f2-17 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/17.webp", 1920, 1080)
image ts-e1f2-18 = im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/18.webp", 1920, 1080)

image ts-e1f2-17_jon_blink1:
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie_tracy/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie E1F2 ###################################################################

image s-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/sadie/1.webp", 1920, 1080)
image s-e1f2-02 = im.Scale("season1/episode1/images/freeroam2/images/sadie/2.webp", 1920, 1080)
image s-e1f2-03 = im.Scale("season1/episode1/images/freeroam2/images/sadie/3.webp", 1920, 1080)
image s-e1f2-04 = im.Scale("season1/episode1/images/freeroam2/images/sadie/4.webp", 1920, 1080)
image s-e1f2-05 = im.Scale("season1/episode1/images/freeroam2/images/sadie/5.webp", 1920, 1080)
image s-e1f2-06 = im.Scale("season1/episode1/images/freeroam2/images/sadie/6.webp", 1920, 1080)
image s-e1f2-07 = im.Scale("season1/episode1/images/freeroam2/images/sadie/7.webp", 1920, 1080)
image s-e1f2-08 = im.Scale("season1/episode1/images/freeroam2/images/sadie/8.webp", 1920, 1080)
image s-e1f2-09 = im.Scale("season1/episode1/images/freeroam2/images/sadie/9.webp", 1920, 1080)
image s-e1f2-10 = im.Scale("season1/episode1/images/freeroam2/images/sadie/10.webp", 1920, 1080)
image s-e1f2-11 = im.Scale("season1/episode1/images/freeroam2/images/sadie/11.webp", 1920, 1080)

image s_e1f2_sadie_blink1:
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ken E1F2 #####################################################################

image k-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/ken/1.webp", 1920, 1080)
image k-e1f2-02 = im.Scale("season1/episode1/images/freeroam2/images/ken/2.webp", 1920, 1080)
image k-e1f2-03 = im.Scale("season1/episode1/images/freeroam2/images/ken/3.webp", 1920, 1080)

image ke-e1f2-ken_blink1:
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Bedroom E1F2 #################################################################

image bd-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/1.webp", 1920, 1080)

# Jon E1F2 #####################################################################

image jn-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/jon/1.webp", 1920, 1080)
image jn-e1f2-02 = im.Scale("season1/episode1/images/freeroam2/images/jon/2.webp", 1920, 1080)
image jn-e1f2-03 = im.Scale("season1/episode1/images/freeroam2/images/jon/3.webp", 1920, 1080)
image jn-e1f2-04 = im.Scale("season1/episode1/images/freeroam2/images/jon/4.webp", 1920, 1080)
image jn-e1f2-05 = im.Scale("season1/episode1/images/freeroam2/images/jon/5.webp", 1920, 1080)
image jn-e1f2-06 = im.Scale("season1/episode1/images/freeroam2/images/jon/6.webp", 1920, 1080)
image jn-e1f2-07 = im.Scale("season1/episode1/images/freeroam2/images/jon/7.webp", 1920, 1080)
image jn-e1f2-08 = im.Scale("season1/episode1/images/freeroam2/images/jon/8.webp", 1920, 1080)
image jn-e1f2-09 = im.Scale("season1/episode1/images/freeroam2/images/jon/9.webp", 1920, 1080)
image jn-e1f2-10 = im.Scale("season1/episode1/images/freeroam2/images/jon/10.webp", 1920, 1080)
image jn-e1f2-11 = im.Scale("season1/episode1/images/freeroam2/images/jon/11.webp", 1920, 1080)
image jn-e1f2-12 = im.Scale("season1/episode1/images/freeroam2/images/jon/12.webp", 1920, 1080)
image jn-e1f2-13 = im.Scale("season1/episode1/images/freeroam2/images/jon/13.webp", 1920, 1080)
image jn-e1f2-14 = im.Scale("season1/episode1/images/freeroam2/images/jon/14.webp", 1920, 1080)
image jn-e1f2-15 = im.Scale("season1/episode1/images/freeroam2/images/jon/15.webp", 1920, 1080)
image jn-e1f2-16 = im.Scale("season1/episode1/images/freeroam2/images/jon/16.webp", 1920, 1080)
image jn-e1f2-17 = im.Scale("season1/episode1/images/freeroam2/images/jon/17.webp", 1920, 1080)
image jn-e1f2-18 = im.Scale("season1/episode1/images/freeroam2/images/jon/18.webp", 1920, 1080)
image jn-e1f2-19 = im.Scale("season1/episode1/images/freeroam2/images/jon/19.webp", 1920, 1080)
image jn-e1f2-20 = im.Scale("season1/episode1/images/freeroam2/images/jon/20.webp", 1920, 1080)
image jn-e1f2-21 = im.Scale("season1/episode1/images/freeroam2/images/jon/21.webp", 1920, 1080)
image jn-e1f2-22 = im.Scale("season1/episode1/images/freeroam2/images/jon/22.webp", 1920, 1080)
image jn-e1f2-23 = im.Scale("season1/episode1/images/freeroam2/images/jon/23.webp", 1920, 1080)

image jn-e1f2_jon_blink1:
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/jon/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Shots E1F2 ###################################################################

image sh-e1f2-01 = im.Scale("season1/episode1/images/freeroam2/images/shots/1.webp", 1920, 1080)
image sh-e1f2-02 = im.Scale("season1/episode1/images/freeroam2/images/shots/2.webp", 1920, 1080)
image sh-e1f2-03 = im.Scale("season1/episode1/images/freeroam2/images/shots/3.webp", 1920, 1080)
image sh-e1f2-04 = im.Scale("season1/episode1/images/freeroam2/images/shots/4.webp", 1920, 1080)
image sh-e1f2-05 = im.Scale("season1/episode1/images/freeroam2/images/shots/5.webp", 1920, 1080)
image sh-e1f2-06 = im.Scale("season1/episode1/images/freeroam2/images/shots/6.webp", 1920, 1080)
image sh-e1f2-07 = im.Scale("season1/episode1/images/freeroam2/images/shots/7.webp", 1920, 1080)
image sh-e1f2-08 = im.Scale("season1/episode1/images/freeroam2/images/shots/8.webp", 1920, 1080)
image sh-e1f2-09 = im.Scale("season1/episode1/images/freeroam2/images/shots/9.webp", 1920, 1080)
image sh-e1f2-10 = im.Scale("season1/episode1/images/freeroam2/images/shots/10.webp", 1920, 1080)
image sh-e1f2-11 = im.Scale("season1/episode1/images/freeroam2/images/shots/11.webp", 1920, 1080)
image sh-e1f2-12 = im.Scale("season1/episode1/images/freeroam2/images/shots/12.webp", 1920, 1080)
image sh-e1f2-13 = im.Scale("season1/episode1/images/freeroam2/images/shots/13.webp", 1920, 1080)
image sh-e1f2-14 = im.Scale("season1/episode1/images/freeroam2/images/shots/14.webp", 1920, 1080)
image sh-e1f2-15 = im.Scale("season1/episode1/images/freeroam2/images/shots/15.webp", 1920, 1080)
image sh-e1f2-16 = im.Scale("season1/episode1/images/freeroam2/images/shots/16.webp", 1920, 1080)
image sh-e1f2-17 = im.Scale("season1/episode1/images/freeroam2/images/shots/17.webp", 1920, 1080)
image sh-e1f2-18 = im.Scale("season1/episode1/images/freeroam2/images/shots/18.webp", 1920, 1080)
image sh-e1f2-19 = im.Scale("season1/episode1/images/freeroam2/images/shots/19.webp", 1920, 1080)
image sh-e1f2-20 = im.Scale("season1/episode1/images/freeroam2/images/shots/20.webp", 1920, 1080)
image sh-e1f2-21 = im.Scale("season1/episode1/images/freeroam2/images/shots/21.webp", 1920, 1080)
image sh-e1f2-22 = im.Scale("season1/episode1/images/freeroam2/images/shots/22.webp", 1920, 1080)
image sh-e1f2-23 = im.Scale("season1/episode1/images/freeroam2/images/shots/23.webp", 1920, 1080)
image sh-e1f2-24 = im.Scale("season1/episode1/images/freeroam2/images/shots/24.webp", 1920, 1080)
image sh-e1f2-25 = im.Scale("season1/episode1/images/freeroam2/images/shots/25.webp", 1920, 1080)

image sh-e1f2-tracy_blink1:
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam2/images/shots/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
