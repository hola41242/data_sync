
# Scene 19 images ##############################################################

image e1s19-01 = im.Scale("season1/episode1/images/scene19/1.webp", 1920, 1080)
image e1s19-02 = im.Scale("season1/episode1/images/scene19/2.webp", 1920, 1080)
image e1s19-03 = im.Scale("season1/episode1/images/scene19/3.webp", 1920, 1080)
image e1s19-04 = im.Scale("season1/episode1/images/scene19/4.webp", 1920, 1080)
image e1s19-05 = im.Scale("season1/episode1/images/scene19/5.webp", 1920, 1080)
image e1s19-06 = im.Scale("season1/episode1/images/scene19/6.webp", 1920, 1080)
image e1s19-07 = im.Scale("season1/episode1/images/scene19/7.webp", 1920, 1080)
image e1s19-08 = im.Scale("season1/episode1/images/scene19/8.webp", 1920, 1080)
image e1s19-09 = im.Scale("season1/episode1/images/scene19/9.webp", 1920, 1080)
image e1s19-10 = im.Scale("season1/episode1/images/scene19/10.webp", 1920, 1080)
image e1s19-11 = im.Scale("season1/episode1/images/scene19/11.webp", 1920, 1080)
image e1s19-12 = im.Scale("season1/episode1/images/scene19/12.webp", 1920, 1080)
image e1s19-13 = im.Scale("season1/episode1/images/scene19/13.webp", 1920, 1080)
image e1s19-14 = im.Scale("season1/episode1/images/scene19/14.webp", 1920, 1080)
image e1s19-15 = im.Scale("season1/episode1/images/scene19/15.webp", 1920, 1080)
image e1s19-16 = im.Scale("season1/episode1/images/scene19/16.webp", 1920, 1080)
image e1s19-17 = im.Scale("season1/episode1/images/scene19/17.webp", 1920, 1080)
image e1s19-18 = im.Scale("season1/episode1/images/scene19/18.webp", 1920, 1080)
image e1s19-19 = im.Scale("season1/episode1/images/scene19/19.webp", 1920, 1080)
image e1s19-20 = im.Scale("season1/episode1/images/scene19/20.webp", 1920, 1080)
image e1s19-21 = im.Scale("season1/episode1/images/scene19/21.webp", 1920, 1080)
image e1s19-22 = im.Scale("season1/episode1/images/scene19/22.webp", 1920, 1080)
image e1s19-23 = im.Scale("season1/episode1/images/scene19/23.webp", 1920, 1080)
image e1s19-24 = im.Scale("season1/episode1/images/scene19/24.webp", 1920, 1080)
image e1s19-25 = im.Scale("season1/episode1/images/scene19/25.webp", 1920, 1080)
image e1s19-26 = im.Scale("season1/episode1/images/scene19/26.webp", 1920, 1080)
image e1s19-27 = im.Scale("season1/episode1/images/scene19/27.webp", 1920, 1080)
image e1s19-28 = im.Scale("season1/episode1/images/scene19/28.webp", 1920, 1080)
image e1s19-29 = im.Scale("season1/episode1/images/scene19/29.webp", 1920, 1080)

image e1s19-bouncer_blink1:
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s19-jon_blink1:
    im.Scale("season1/episode1/images/scene19/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene19/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
