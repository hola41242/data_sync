
# Scene 18 images ##############################################################

image e1s18-01 = im.Scale("season1/episode1/images/scene18/1.webp", 1920, 1080)
image e1s18-02 = im.Scale("season1/episode1/images/scene18/2.webp", 1920, 1080)
image e1s18-03 = im.Scale("season1/episode1/images/scene18/3.webp", 1920, 1080)
image e1s18-04 = im.Scale("season1/episode1/images/scene18/4.webp", 1920, 1080)
image e1s18-05 = im.Scale("season1/episode1/images/scene18/5.webp", 1920, 1080)
image e1s18-06 = im.Scale("season1/episode1/images/scene18/6.webp", 1920, 1080)
image e1s18-07 = im.Scale("season1/episode1/images/scene18/7.webp", 1920, 1080)
image e1s18-08 = im.Scale("season1/episode1/images/scene18/8.webp", 1920, 1080)
image e1s18-09 = im.Scale("season1/episode1/images/scene18/9.webp", 1920, 1080)
image e1s18-10 = im.Scale("season1/episode1/images/scene18/10.webp", 1920, 1080)
image e1s18-11 = im.Scale("season1/episode1/images/scene18/11.webp", 1920, 1080)
image e1s18-12 = im.Scale("season1/episode1/images/scene18/12.webp", 1920, 1080)
image e1s18-13 = im.Scale("season1/episode1/images/scene18/13.webp", 1920, 1080)
image e1s18-14 = im.Scale("season1/episode1/images/scene18/14.webp", 1920, 1080)
image e1s18-15 = im.Scale("season1/episode1/images/scene18/15.webp", 1920, 1080)
image e1s18-16 = im.Scale("season1/episode1/images/scene18/16.webp", 1920, 1080)
image e1s18-17 = im.Scale("season1/episode1/images/scene18/17.webp", 1920, 1080)
image e1s18-18 = im.Scale("season1/episode1/images/scene18/18.webp", 1920, 1080)
image e1s18-19 = im.Scale("season1/episode1/images/scene18/19.webp", 1920, 1080)
image e1s18-20 = im.Scale("season1/episode1/images/scene18/20.webp", 1920, 1080)
image e1s18-21 = im.Scale("season1/episode1/images/scene18/21.webp", 1920, 1080)
image e1s18-22 = im.Scale("season1/episode1/images/scene18/22.webp", 1920, 1080)
image e1s18-23 = im.Scale("season1/episode1/images/scene18/23.webp", 1920, 1080)
image e1s18-24 = im.Scale("season1/episode1/images/scene18/24.webp", 1920, 1080)
image e1s18-25 = im.Scale("season1/episode1/images/scene18/25.webp", 1920, 1080)
image e1s18-26 = im.Scale("season1/episode1/images/scene18/26.webp", 1920, 1080)
image e1s18-27 = im.Scale("season1/episode1/images/scene18/27.webp", 1920, 1080)
image e1s18-28 = im.Scale("season1/episode1/images/scene18/28.webp", 1920, 1080)
image e1s18-29 = im.Scale("season1/episode1/images/scene18/29.webp", 1920, 1080)
image e1s18-30 = im.Scale("season1/episode1/images/scene18/30.webp", 1920, 1080)
image e1s18-31 = im.Scale("season1/episode1/images/scene18/31.webp", 1920, 1080)
image e1s18-32 = im.Scale("season1/episode1/images/scene18/32.webp", 1920, 1080)
image e1s18-33 = im.Scale("season1/episode1/images/scene18/33.webp", 1920, 1080)
image e1s18-34 = im.Scale("season1/episode1/images/scene18/34.webp", 1920, 1080)
image e1s18-35 = im.Scale("season1/episode1/images/scene18/35.webp", 1920, 1080)
image e1s18-36 = im.Scale("season1/episode1/images/scene18/36.webp", 1920, 1080)
image e1s18-37 = im.Scale("season1/episode1/images/scene18/37.webp", 1920, 1080)
image e1s18-38 = im.Scale("season1/episode1/images/scene18/38.webp", 1920, 1080)
image e1s18-39 = im.Scale("season1/episode1/images/scene18/39.webp", 1920, 1080)
image e1s18-40 = im.Scale("season1/episode1/images/scene18/40.webp", 1920, 1080)
image e1s18-41 = im.Scale("season1/episode1/images/scene18/41.webp", 1920, 1080)
image e1s18-42 = im.Scale("season1/episode1/images/scene18/42.webp", 1920, 1080)
image e1s18-43 = im.Scale("season1/episode1/images/scene18/43.webp", 1920, 1080)
image e1s18-44 = im.Scale("season1/episode1/images/scene18/44.webp", 1920, 1080)
image e1s18-45 = im.Scale("season1/episode1/images/scene18/45.webp", 1920, 1080)
image e1s18-46 = im.Scale("season1/episode1/images/scene18/46.webp", 1920, 1080)
image e1s18-47 = im.Scale("season1/episode1/images/scene18/47.webp", 1920, 1080)
image e1s18-48 = im.Scale("season1/episode1/images/scene18/48.webp", 1920, 1080)
image e1s18-49 = im.Scale("season1/episode1/images/scene18/49.webp", 1920, 1080)
image e1s18-50 = im.Scale("season1/episode1/images/scene18/50.webp", 1920, 1080)
image e1s18-51 = im.Scale("season1/episode1/images/scene18/51.webp", 1920, 1080)
image e1s18-52 = im.Scale("season1/episode1/images/scene18/52.webp", 1920, 1080)
image e1s18-53 = im.Scale("season1/episode1/images/scene18/53.webp", 1920, 1080)
image e1s18-54 = im.Scale("season1/episode1/images/scene18/54.webp", 1920, 1080)
image e1s18-55 = im.Scale("season1/episode1/images/scene18/55.webp", 1920, 1080)
image e1s18-56 = im.Scale("season1/episode1/images/scene18/56.webp", 1920, 1080)
image e1s18-57 = im.Scale("season1/episode1/images/scene18/57.webp", 1920, 1080)
image e1s18-58 = im.Scale("season1/episode1/images/scene18/58.webp", 1920, 1080)
image e1s18-59 = im.Scale("season1/episode1/images/scene18/59.webp", 1920, 1080)
image e1s18-60 = im.Scale("season1/episode1/images/scene18/60.webp", 1920, 1080)
image e1s18-61 = im.Scale("season1/episode1/images/scene18/61.webp", 1920, 1080)
image e1s18-62 = im.Scale("season1/episode1/images/scene18/62.webp", 1920, 1080)
image e1s18-63 = im.Scale("season1/episode1/images/scene18/63.webp", 1920, 1080)
image e1s18-64 = im.Scale("season1/episode1/images/scene18/64.webp", 1920, 1080)
image e1s18-65 = im.Scale("season1/episode1/images/scene18/65.webp", 1920, 1080)
image e1s18-66 = im.Scale("season1/episode1/images/scene18/66.webp", 1920, 1080)
image e1s18-67 = im.Scale("season1/episode1/images/scene18/67.webp", 1920, 1080)
image e1s18-68 = im.Scale("season1/episode1/images/scene18/68.webp", 1920, 1080)
image e1s18-69 = im.Scale("season1/episode1/images/scene18/69.webp", 1920, 1080)
image e1s18-70 = im.Scale("season1/episode1/images/scene18/70.webp", 1920, 1080)
image e1s18-71 = im.Scale("season1/episode1/images/scene18/71.webp", 1920, 1080)
image e1s18-72 = im.Scale("season1/episode1/images/scene18/72.webp", 1920, 1080)
image e1s18-73 = im.Scale("season1/episode1/images/scene18/73.webp", 1920, 1080)
image e1s18-74 = im.Scale("season1/episode1/images/scene18/74.webp", 1920, 1080)
image e1s18-75 = im.Scale("season1/episode1/images/scene18/75.webp", 1920, 1080)
image e1s18-76 = im.Scale("season1/episode1/images/scene18/76.webp", 1920, 1080)
image e1s18-77 = im.Scale("season1/episode1/images/scene18/77.webp", 1920, 1080)
image e1s18-78 = im.Scale("season1/episode1/images/scene18/78.webp", 1920, 1080)
image e1s18-79 = im.Scale("season1/episode1/images/scene18/79.webp", 1920, 1080)
image e1s18-80 = im.Scale("season1/episode1/images/scene18/80.webp", 1920, 1080)
image e1s18-81 = im.Scale("season1/episode1/images/scene18/81.webp", 1920, 1080)
image e1s18-82 = im.Scale("season1/episode1/images/scene18/82.webp", 1920, 1080)
image e1s18-83 = im.Scale("season1/episode1/images/scene18/83.webp", 1920, 1080)
image e1s18-84 = im.Scale("season1/episode1/images/scene18/84.webp", 1920, 1080)
image e1s18-85 = im.Scale("season1/episode1/images/scene18/85.webp", 1920, 1080)
image e1s18-86 = im.Scale("season1/episode1/images/scene18/86.webp", 1920, 1080)
image e1s18-87 = im.Scale("season1/episode1/images/scene18/87.webp", 1920, 1080)
image e1s18-88 = im.Scale("season1/episode1/images/scene18/88.webp", 1920, 1080)
image e1s18-89 = im.Scale("season1/episode1/images/scene18/89.webp", 1920, 1080)
image e1s18-90 = im.Scale("season1/episode1/images/scene18/90.webp", 1920, 1080)
image e1s18-91 = im.Scale("season1/episode1/images/scene18/91.webp", 1920, 1080)
image e1s18-92 = im.Scale("season1/episode1/images/scene18/92.webp", 1920, 1080)
image e1s18-93 = im.Scale("season1/episode1/images/scene18/93.webp", 1920, 1080)
image e1s18-94 = im.Scale("season1/episode1/images/scene18/94.webp", 1920, 1080)
image e1s18-95 = im.Scale("season1/episode1/images/scene18/95.webp", 1920, 1080)
image e1s18-96 = im.Scale("season1/episode1/images/scene18/96.webp", 1920, 1080)
image e1s18-97 = im.Scale("season1/episode1/images/scene18/97.webp", 1920, 1080)
image e1s18-98 = im.Scale("season1/episode1/images/scene18/98.webp", 1920, 1080)
image e1s18-99 = im.Scale("season1/episode1/images/scene18/99.webp", 1920, 1080)
image e1s18-100 = im.Scale("season1/episode1/images/scene18/100.webp", 1920, 1080)
image e1s18-101 = im.Scale("season1/episode1/images/scene18/101.webp", 1920, 1080)
image e1s18-102 = im.Scale("season1/episode1/images/scene18/102.webp", 1920, 1080)
image e1s18-103 = im.Scale("season1/episode1/images/scene18/103.webp", 1920, 1080)
image e1s18-104 = im.Scale("season1/episode1/images/scene18/104.webp", 1920, 1080)
image e1s18-105 = im.Scale("season1/episode1/images/scene18/105.webp", 1920, 1080)
image e1s18-106 = im.Scale("season1/episode1/images/scene18/106.webp", 1920, 1080)
image e1s18-107 = im.Scale("season1/episode1/images/scene18/107.webp", 1920, 1080)
image e1s18-108 = im.Scale("season1/episode1/images/scene18/108.webp", 1920, 1080)
image e1s18-109 = im.Scale("season1/episode1/images/scene18/109.webp", 1920, 1080)
image e1s18-110 = im.Scale("season1/episode1/images/scene18/110.webp", 1920, 1080)
image e1s18-111 = im.Scale("season1/episode1/images/scene18/111.webp", 1920, 1080)
image e1s18-112 = im.Scale("season1/episode1/images/scene18/112.webp", 1920, 1080)
image e1s18-113 = im.Scale("season1/episode1/images/scene18/113.webp", 1920, 1080)

image e1s18-nate_blink1:
    im.Scale("season1/episode1/images/scene18/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s18-ken_blink1:
    im.Scale("season1/episode1/images/scene18/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s18-sadie_blink1:
    im.Scale("season1/episode1/images/scene18/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s18-tracy_blink1:
    im.Scale("season1/episode1/images/scene18/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene18/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
