# Images #######################################################################

image e1f3-01 = im.Scale("season1/episode1/images/freeroam3/1.webp", 1920, 1080)
image e1f3-02 = im.Scale("season1/episode1/images/freeroam3/2.webp", 1920, 1080)


# Hallway #######################################################################
image e1f3-03 = im.Scale("season1/episode1/images/freeroam3/3.webp", 1920, 1080)
image e1f3-04 = im.Scale("season1/episode1/images/freeroam3/4.webp", 1920, 1080)
image e1f3-05 = im.Scale("season1/episode1/images/freeroam3/5.webp", 1920, 1080)

# Roman_Ken ####################################################################
image rk_e1f3-01 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/1.webp", 1920, 1080)
image rk_e1f3-02 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/2.webp", 1920, 1080)
image rk_e1f3-03 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/3.webp", 1920, 1080)
image rk_e1f3-04 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/4.webp", 1920, 1080)
image rk_e1f3-05 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/5.webp", 1920, 1080)
image rk_e1f3-06 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/6.webp", 1920, 1080)
image rk_e1f3-07 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/7.webp", 1920, 1080)
image rk_e1f3-08 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/8.webp", 1920, 1080)
image rk_e1f3-09 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/9.webp", 1920, 1080)
image rk_e1f3-10 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/10.webp", 1920, 1080)
image rk_e1f3-11 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/11.webp", 1920, 1080)
image rk_e1f3-12 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/12.webp", 1920, 1080)
image rk_e1f3-13 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/13.webp", 1920, 1080)
image rk_e1f3-14 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/14.webp", 1920, 1080)
image rk_e1f3-15 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/15.webp", 1920, 1080)
image rk_e1f3-16 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/16.webp", 1920, 1080)
image rk_e1f3-17 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/17.webp", 1920, 1080)
image rk_e1f3-18 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/18.webp", 1920, 1080)
image rk_e1f3-19 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/19.webp", 1920, 1080)
image rk_e1f3-20 = im.Scale("season1/episode1/images/freeroam3/images/roman_ken/20.webp", 1920, 1080)

# Nate #########################################################################
image n_e1f3-01 = im.Scale("season1/episode1/images/freeroam3/images/nate/1.webp", 1920, 1080)
image n_e1f3-02 = im.Scale("season1/episode1/images/freeroam3/images/nate/2.webp", 1920, 1080)
image n_e1f3-03 = im.Scale("season1/episode1/images/freeroam3/images/nate/3.webp", 1920, 1080)
image n_e1f3-04 = im.Scale("season1/episode1/images/freeroam3/images/nate/4.webp", 1920, 1080)

image n_e1f3-nate_blink1:
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam3/images/nate/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Raven ########################################################################
image r_e1f3-01 = im.Scale("season1/episode1/images/freeroam3/images/raven/1.webp", 1920, 1080)
image r_e1f3-02 = im.Scale("season1/episode1/images/freeroam3/images/raven/2.webp", 1920, 1080)
image r_e1f3-03 = im.Scale("season1/episode1/images/freeroam3/images/raven/3.webp", 1920, 1080)
image r_e1f3-04 = im.Scale("season1/episode1/images/freeroam3/images/raven/4.webp", 1920, 1080)

# Spencer ######################################################################
image sp_e1f3-01 = im.Scale("season1/episode1/images/freeroam3/images/spencer/1.webp", 1920, 1080)
image sp_e1f3-02 = im.Scale("season1/episode1/images/freeroam3/images/spencer/2.webp", 1920, 1080)
image sp_e1f3-03 = im.Scale("season1/episode1/images/freeroam3/images/spencer/3.webp", 1920, 1080)
image sp_e1f3-04 = im.Scale("season1/episode1/images/freeroam3/images/spencer/4.webp", 1920, 1080)
image sp_e1f3-05 = im.Scale("season1/episode1/images/freeroam3/images/spencer/5.webp", 1920, 1080)
image sp_e1f3-06 = im.Scale("season1/episode1/images/freeroam3/images/spencer/6.webp", 1920, 1080)
image sp_e1f3-07 = im.Scale("season1/episode1/images/freeroam3/images/spencer/7.webp", 1920, 1080)
