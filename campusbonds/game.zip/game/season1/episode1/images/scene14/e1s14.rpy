
# Scene 14 images ##############################################################

image e1s14-01 = im.Scale("season1/episode1/images/scene14/1.webp", 1920, 1080)
image e1s14-02 = im.Scale("season1/episode1/images/scene14/2.webp", 1920, 1080)
image e1s14-03 = im.Scale("season1/episode1/images/scene14/3.webp", 1920, 1080)
image e1s14-04 = im.Scale("season1/episode1/images/scene14/4.webp", 1920, 1080)
image e1s14-05 = im.Scale("season1/episode1/images/scene14/5.webp", 1920, 1080)
image e1s14-06 = im.Scale("season1/episode1/images/scene14/6.webp", 1920, 1080)
image e1s14-07 = im.Scale("season1/episode1/images/scene14/7.webp", 1920, 1080)
image e1s14-08 = im.Scale("season1/episode1/images/scene14/8.webp", 1920, 1080)
image e1s14-09 = im.Scale("season1/episode1/images/scene14/9.webp", 1920, 1080)
image e1s14-10 = im.Scale("season1/episode1/images/scene14/10.webp", 1920, 1080)
image e1s14-11 = im.Scale("season1/episode1/images/scene14/11.webp", 1920, 1080)
image e1s14-12 = im.Scale("season1/episode1/images/scene14/12.webp", 1920, 1080)
image e1s14-13 = im.Scale("season1/episode1/images/scene14/13.webp", 1920, 1080)
image e1s14-14 = im.Scale("season1/episode1/images/scene14/14.webp", 1920, 1080)
image e1s14-15 = im.Scale("season1/episode1/images/scene14/15.webp", 1920, 1080)
image e1s14-16 = im.Scale("season1/episode1/images/scene14/16.webp", 1920, 1080)
image e1s14-17 = im.Scale("season1/episode1/images/scene14/17.webp", 1920, 1080)
image e1s14-18 = im.Scale("season1/episode1/images/scene14/18.webp", 1920, 1080)
image e1s14-19 = im.Scale("season1/episode1/images/scene14/19.webp", 1920, 1080)
image e1s14-20 = im.Scale("season1/episode1/images/scene14/20.webp", 1920, 1080)
image e1s14-21 = im.Scale("season1/episode1/images/scene14/21.webp", 1920, 1080)
image e1s14-22 = im.Scale("season1/episode1/images/scene14/22.webp", 1920, 1080)
image e1s14-23 = im.Scale("season1/episode1/images/scene14/23.webp", 1920, 1080)
image e1s14-24 = im.Scale("season1/episode1/images/scene14/24.webp", 1920, 1080)
image e1s14-25 = im.Scale("season1/episode1/images/scene14/25.webp", 1920, 1080)
image e1s14-26 = im.Scale("season1/episode1/images/scene14/26.webp", 1920, 1080)
image e1s14-27 = im.Scale("season1/episode1/images/scene14/27.webp", 1920, 1080)
image e1s14-28 = im.Scale("season1/episode1/images/scene14/28.webp", 1920, 1080)
image e1s14-29 = im.Scale("season1/episode1/images/scene14/29.webp", 1920, 1080)
image e1s14-30 = im.Scale("season1/episode1/images/scene14/30.webp", 1920, 1080)
image e1s14-31 = im.Scale("season1/episode1/images/scene14/31.webp", 1920, 1080)
image e1s14-32 = im.Scale("season1/episode1/images/scene14/32.webp", 1920, 1080)
image e1s14-33 = im.Scale("season1/episode1/images/scene14/33.webp", 1920, 1080)
image e1s14-34 = im.Scale("season1/episode1/images/scene14/34.webp", 1920, 1080)
image e1s14-35 = im.Scale("season1/episode1/images/scene14/35.webp", 1920, 1080)
image e1s14-36 = im.Scale("season1/episode1/images/scene14/36.webp", 1920, 1080)
image e1s14-37 = im.Scale("season1/episode1/images/scene14/37.webp", 1920, 1080)
image e1s14-38 = im.Scale("season1/episode1/images/scene14/38.webp", 1920, 1080)
image e1s14-39 = im.Scale("season1/episode1/images/scene14/39.webp", 1920, 1080)
image e1s14-40 = im.Scale("season1/episode1/images/scene14/40.webp", 1920, 1080)
image e1s14-41 = im.Scale("season1/episode1/images/scene14/41.webp", 1920, 1080)
image e1s14-42 = im.Scale("season1/episode1/images/scene14/42.webp", 1920, 1080)
image e1s14-43 = im.Scale("season1/episode1/images/scene14/43.webp", 1920, 1080)
image e1s14-44 = im.Scale("season1/episode1/images/scene14/44.webp", 1920, 1080)
image e1s14-45 = im.Scale("season1/episode1/images/scene14/45.webp", 1920, 1080)
image e1s14-46 = im.Scale("season1/episode1/images/scene14/46.webp", 1920, 1080)
image e1s14-47 = im.Scale("season1/episode1/images/scene14/47.webp", 1920, 1080)
image e1s14-48 = im.Scale("season1/episode1/images/scene14/48.webp", 1920, 1080)
image e1s14-49 = im.Scale("season1/episode1/images/scene14/49.webp", 1920, 1080)
image e1s14-50 = im.Scale("season1/episode1/images/scene14/50.webp", 1920, 1080)
image e1s14-51 = im.Scale("season1/episode1/images/scene14/51.webp", 1920, 1080)
image e1s14-52 = im.Scale("season1/episode1/images/scene14/52.webp", 1920, 1080)
image e1s14-53 = im.Scale("season1/episode1/images/scene14/53.webp", 1920, 1080)
image e1s14-54 = im.Scale("season1/episode1/images/scene14/54.webp", 1920, 1080)
image e1s14-55 = im.Scale("season1/episode1/images/scene14/55.webp", 1920, 1080)
image e1s14-56 = im.Scale("season1/episode1/images/scene14/56.webp", 1920, 1080)
image e1s14-57 = im.Scale("season1/episode1/images/scene14/57.webp", 1920, 1080)
image e1s14-58 = im.Scale("season1/episode1/images/scene14/58.webp", 1920, 1080)
image e1s14-59 = im.Scale("season1/episode1/images/scene14/59.webp", 1920, 1080)
image e1s14-60 = im.Scale("season1/episode1/images/scene14/60.webp", 1920, 1080)
image e1s14-61 = im.Scale("season1/episode1/images/scene14/61.webp", 1920, 1080)
image e1s14-62 = im.Scale("season1/episode1/images/scene14/62.webp", 1920, 1080)
image e1s14-63 = im.Scale("season1/episode1/images/scene14/63.webp", 1920, 1080)
image e1s14-64 = im.Scale("season1/episode1/images/scene14/64.webp", 1920, 1080)
image e1s14-65 = im.Scale("season1/episode1/images/scene14/65.webp", 1920, 1080)
image e1s14-66 = im.Scale("season1/episode1/images/scene14/66.webp", 1920, 1080)
image e1s14-67 = im.Scale("season1/episode1/images/scene14/67.webp", 1920, 1080)
image e1s14-68 = im.Scale("season1/episode1/images/scene14/68.webp", 1920, 1080)
image e1s14-69 = im.Scale("season1/episode1/images/scene14/69.webp", 1920, 1080)
image e1s14-70 = im.Scale("season1/episode1/images/scene14/70.webp", 1920, 1080)
image e1s14-71 = im.Scale("season1/episode1/images/scene14/71.webp", 1920, 1080)
image e1s14-72 = im.Scale("season1/episode1/images/scene14/72.webp", 1920, 1080)
image e1s14-73 = im.Scale("season1/episode1/images/scene14/73.webp", 1920, 1080)
image e1s14-74 = im.Scale("season1/episode1/images/scene14/74.webp", 1920, 1080)
image e1s14-75 = im.Scale("season1/episode1/images/scene14/75.webp", 1920, 1080)
image e1s14-76 = im.Scale("season1/episode1/images/scene14/76.webp", 1920, 1080)
image e1s14-77 = im.Scale("season1/episode1/images/scene14/77.webp", 1920, 1080)
image e1s14-78 = im.Scale("season1/episode1/images/scene14/78.webp", 1920, 1080)
image e1s14-79 = im.Scale("season1/episode1/images/scene14/79.webp", 1920, 1080)
image e1s14-80 = im.Scale("season1/episode1/images/scene14/80.webp", 1920, 1080)
image e1s14-81 = im.Scale("season1/episode1/images/scene14/81.webp", 1920, 1080)
image e1s14-82 = im.Scale("season1/episode1/images/scene14/82.webp", 1920, 1080)
image e1s14-83 = im.Scale("season1/episode1/images/scene14/83.webp", 1920, 1080)
image e1s14-84 = im.Scale("season1/episode1/images/scene14/84.webp", 1920, 1080)
image e1s14-85 = im.Scale("season1/episode1/images/scene14/85.webp", 1920, 1080)
image e1s14-86 = im.Scale("season1/episode1/images/scene14/86.webp", 1920, 1080)
image e1s14-87 = im.Scale("season1/episode1/images/scene14/87.webp", 1920, 1080)
image e1s14-88 = im.Scale("season1/episode1/images/scene14/88.webp", 1920, 1080)
image e1s14-89 = im.Scale("season1/episode1/images/scene14/89.webp", 1920, 1080)
image e1s14-90 = im.Scale("season1/episode1/images/scene14/90.webp", 1920, 1080)
image e1s14-91 = im.Scale("season1/episode1/images/scene14/91.webp", 1920, 1080)
image e1s14-92 = im.Scale("season1/episode1/images/scene14/92.webp", 1920, 1080)
image e1s14-93 = im.Scale("season1/episode1/images/scene14/93.webp", 1920, 1080)

# Cleo Blink ###################################################################

image e1s14_cleo_blink1:
    im.Scale("season1/episode1/images/scene14/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s14_cleo_blink2:
    im.Scale("season1/episode1/images/scene14/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s14_cleo_blink3:
    im.Scale("season1/episode1/images/scene14/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s14_cleo_blink4:
    im.Scale("season1/episode1/images/scene14/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s14_cleo_blink5:
    im.Scale("season1/episode1/images/scene14/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/cleo_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Francesca Blink ##############################################################

image e1s14_francesca_blink1:
    im.Scale("season1/episode1/images/scene14/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Alice Blink ##################################################################

image e1s14_alice_blink1:
    im.Scale("season1/episode1/images/scene14/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Evelyn Blink #################################################################

image e1s14_evelyn_blink1:
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Spencer Blink ################################################################

image e1s14_spencer_blink1:
    im.Scale("season1/episode1/images/scene14/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene14/spencer_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
