
# Scene 10 images ##############################################################

image e1s10-01 = im.Scale("season1/episode1/images/scene10/1.webp", 1920, 1080)
image e1s10-02 = im.Scale("season1/episode1/images/scene10/2.webp", 1920, 1080)
image e1s10-03 = im.Scale("season1/episode1/images/scene10/3.webp", 1920, 1080)
image e1s10-04 = im.Scale("season1/episode1/images/scene10/4.webp", 1920, 1080)
image e1s10-05 = im.Scale("season1/episode1/images/scene10/5.webp", 1920, 1080)
image e1s10-06 = im.Scale("season1/episode1/images/scene10/6.webp", 1920, 1080)
image e1s10-07 = im.Scale("season1/episode1/images/scene10/7.webp", 1920, 1080)
image e1s10-08 = im.Scale("season1/episode1/images/scene10/8.webp", 1920, 1080)
image e1s10-09 = im.Scale("season1/episode1/images/scene10/9.webp", 1920, 1080)
image e1s10-10 = im.Scale("season1/episode1/images/scene10/10.webp", 1920, 1080)
image e1s10-11 = im.Scale("season1/episode1/images/scene10/11.webp", 1920, 1080)
image e1s10-12 = im.Scale("season1/episode1/images/scene10/12.webp", 1920, 1080)
image e1s10-13 = im.Scale("season1/episode1/images/scene10/13.webp", 1920, 1080)
image e1s10-14 = im.Scale("season1/episode1/images/scene10/14.webp", 1920, 1080)
image e1s10-15 = im.Scale("season1/episode1/images/scene10/15.webp", 1920, 1080)
image e1s10-16 = im.Scale("season1/episode1/images/scene10/16.webp", 1920, 1080)
image e1s10-17 = im.Scale("season1/episode1/images/scene10/17.webp", 1920, 1080)
image e1s10-18 = im.Scale("season1/episode1/images/scene10/18.webp", 1920, 1080)
image e1s10-19 = im.Scale("season1/episode1/images/scene10/19.webp", 1920, 1080)
image e1s10-20 = im.Scale("season1/episode1/images/scene10/20.webp", 1920, 1080)
image e1s10-21-5 = im.Scale("season1/episode1/images/scene10/21.5.webp", 1920, 1080)
image e1s10-21 = im.Scale("season1/episode1/images/scene10/21.webp", 1920, 1080)
image e1s10-22 = im.Scale("season1/episode1/images/scene10/22.webp", 1920, 1080)
image e1s10-23 = im.Scale("season1/episode1/images/scene10/23.webp", 1920, 1080)
image e1s10-24 = im.Scale("season1/episode1/images/scene10/24.webp", 1920, 1080)
image e1s10-25 = im.Scale("season1/episode1/images/scene10/25.webp", 1920, 1080)
image e1s10-26 = im.Scale("season1/episode1/images/scene10/26.webp", 1920, 1080)
image e1s10-27 = im.Scale("season1/episode1/images/scene10/27.webp", 1920, 1080)
image e1s10-28 = im.Scale("season1/episode1/images/scene10/28.webp", 1920, 1080)
image e1s10-29 = im.Scale("season1/episode1/images/scene10/29.webp", 1920, 1080)
image e1s10-30 = im.Scale("season1/episode1/images/scene10/30.webp", 1920, 1080)
image e1s10-31 = im.Scale("season1/episode1/images/scene10/31.webp", 1920, 1080)
image e1s10-32 = im.Scale("season1/episode1/images/scene10/32.webp", 1920, 1080)
image e1s10-32-5 = im.Scale("season1/episode1/images/scene10/32.5.webp", 1920, 1080)
image e1s10-33 = im.Scale("season1/episode1/images/scene10/33.webp", 1920, 1080)
image e1s10-34 = im.Scale("season1/episode1/images/scene10/34.webp", 1920, 1080)
image e1s10-35 = im.Scale("season1/episode1/images/scene10/35.webp", 1920, 1080)
image e1s10-36 = im.Scale("season1/episode1/images/scene10/36.webp", 1920, 1080)
image e1s10-37 = im.Scale("season1/episode1/images/scene10/37.webp", 1920, 1080)
image e1s10-38 = im.Scale("season1/episode1/images/scene10/38.webp", 1920, 1080)
image e1s10-39 = im.Scale("season1/episode1/images/scene10/39.webp", 1920, 1080)
image e1s10-40 = im.Scale("season1/episode1/images/scene10/40.webp", 1920, 1080)
image e1s10-41 = im.Scale("season1/episode1/images/scene10/41.webp", 1920, 1080)
image e1s10-42 = im.Scale("season1/episode1/images/scene10/42.webp", 1920, 1080)
image e1s10-43 = im.Scale("season1/episode1/images/scene10/43.webp", 1920, 1080)
image e1s10-44 = im.Scale("season1/episode1/images/scene10/44.webp", 1920, 1080)
image e1s10-45 = im.Scale("season1/episode1/images/scene10/45.webp", 1920, 1080)
image e1s10-46 = im.Scale("season1/episode1/images/scene10/46.webp", 1920, 1080)
image e1s10-47 = im.Scale("season1/episode1/images/scene10/47.webp", 1920, 1080)
image e1s10-48 = im.Scale("season1/episode1/images/scene10/48.webp", 1920, 1080)
image e1s10-49 = im.Scale("season1/episode1/images/scene10/49.webp", 1920, 1080)
image e1s10-50 = im.Scale("season1/episode1/images/scene10/50.webp", 1920, 1080)
image e1s10-51 = im.Scale("season1/episode1/images/scene10/51.webp", 1920, 1080)
image e1s10-52 = im.Scale("season1/episode1/images/scene10/52.webp", 1920, 1080)
image e1s10-53 = im.Scale("season1/episode1/images/scene10/53.webp", 1920, 1080)
image e1s10-54 = im.Scale("season1/episode1/images/scene10/54.webp", 1920, 1080)
image e1s10-55 = im.Scale("season1/episode1/images/scene10/55.webp", 1920, 1080)
image e1s10-56 = im.Scale("season1/episode1/images/scene10/56.webp", 1920, 1080)
image e1s10-57 = im.Scale("season1/episode1/images/scene10/57.webp", 1920, 1080)
image e1s10-58 = im.Scale("season1/episode1/images/scene10/58.webp", 1920, 1080)
image e1s10-59 = im.Scale("season1/episode1/images/scene10/59.webp", 1920, 1080)
image e1s10-60 = im.Scale("season1/episode1/images/scene10/60.webp", 1920, 1080)

# Cleo Blink ###################################################################

image e1s10-cleo_blink1:
    im.Scale("season1/episode1/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s10_cleo_blink2:
    im.Scale("season1/episode1/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s10_cleo_blink3:
    im.Scale("season1/episode1/images/scene10/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s10_cleo_blink4:
    im.Scale("season1/episode1/images/scene10/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s10_cleo_blink5:
    im.Scale("season1/episode1/images/scene10/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/cleo_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Nate Blink ###################################################################

image e1s10_nate_blink1:
    im.Scale("season1/episode1/images/scene10/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene10/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
