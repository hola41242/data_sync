# Room 34 ######################################################################
image e1f4-01 = im.Scale("season1/episode1/images/freeroam4/1.webp", 1920, 1080)
image e1f4-02 = im.Scale("season1/episode1/images/freeroam4/2.webp", 1920, 1080)
image e1f4-03 = im.Scale("season1/episode1/images/freeroam4/3.webp", 1920, 1080)

# Hallway #######################################################################
image e1f4-04 = im.Scale("season1/episode1/images/freeroam4/4.webp", 1920, 1080)
image e1f4-05 = im.Scale("season1/episode1/images/freeroam4/5.webp", 1920, 1080)
image e1f4-06 = im.Scale("season1/episode1/images/freeroam4/6.webp", 1920, 1080)

image e1f4-04_1 = im.Scale("season1/episode1/images/freeroam4/4.1.webp", 1920, 1080)
image e1f4-05_1 = im.Scale("season1/episode1/images/freeroam4/5.1.webp", 1920, 1080)
image e1f4-06_1 = im.Scale("season1/episode1/images/freeroam4/6.1.webp", 1920, 1080)

image e1f4-04_2 = im.Scale("season1/episode1/images/freeroam4/4.2.webp", 1920, 1080)
image e1f4-05_2 = im.Scale("season1/episode1/images/freeroam4/5.2.webp", 1920, 1080)

image e1f4-04_3 = im.Scale("season1/episode1/images/freeroam4/4.3.webp", 1920, 1080)
image e1f4-05_3 = im.Scale("season1/episode1/images/freeroam4/5.3.webp", 1920, 1080)

# Tracy ########################################################################
image tr_e1f4-01 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/1.webp", 1920, 1080)
image tr_e1f4-02 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/2.webp", 1920, 1080)
image tr_e1f4-03 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/3.webp", 1920, 1080)
image tr_e1f4-04 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/4.webp", 1920, 1080)
image tr_e1f4-05 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/5.webp", 1920, 1080)
image tr_e1f4-06 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/6.webp", 1920, 1080)
image tr_e1f4-07 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/7.webp", 1920, 1080)
image tr_e1f4-08 = im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/8.webp", 1920, 1080)

image e1f4-tracy_blink1:
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ken ##########################################################################
image ke_e1f4-01 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/1.webp", 1920, 1080)
image ke_e1f4-02 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/2.webp", 1920, 1080)
image ke_e1f4-03 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/3.webp", 1920, 1080)
image ke_e1f4-04 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/4.webp", 1920, 1080)
image ke_e1f4-05 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/5.webp", 1920, 1080)
image ke_e1f4-06 = im.Scale("season1/episode1/images/freeroam4/images/meet_ken/6.webp", 1920, 1080)

image e1f4-ken_blink1:
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Spencer ######################################################################
image sp_e1f4-01 = im.Scale("season1/episode1/images/freeroam4/images/spencer/1.webp", 1920, 1080)
image sp_e1f4-02 = im.Scale("season1/episode1/images/freeroam4/images/spencer/2.webp", 1920, 1080)
image sp_e1f4-03 = im.Scale("season1/episode1/images/freeroam4/images/spencer/3.webp", 1920, 1080)
image sp_e1f4-04 = im.Scale("season1/episode1/images/freeroam4/images/spencer/4.webp", 1920, 1080)
image sp_e1f4-05 = im.Scale("season1/episode1/images/freeroam4/images/spencer/5.webp", 1920, 1080)
image sp_e1f4-06 = im.Scale("season1/episode1/images/freeroam4/images/spencer/6.webp", 1920, 1080)
image sp_e1f4-07 = im.Scale("season1/episode1/images/freeroam4/images/spencer/7.webp", 1920, 1080)
image sp_e1f4-08 = im.Scale("season1/episode1/images/freeroam4/images/spencer/8.webp", 1920, 1080)
image sp_e1f4-09 = im.Scale("season1/episode1/images/freeroam4/images/spencer/9.webp", 1920, 1080)
image sp_e1f4-10 = im.Scale("season1/episode1/images/freeroam4/images/spencer/10.webp", 1920, 1080)
image sp_e1f4-11 = im.Scale("season1/episode1/images/freeroam4/images/spencer/11.webp", 1920, 1080)
image sp_e1f4-12 = im.Scale("season1/episode1/images/freeroam4/images/spencer/12.webp", 1920, 1080)
image sp_e1f4-13 = im.Scale("season1/episode1/images/freeroam4/images/spencer/13.webp", 1920, 1080)
image sp_e1f4-14 = im.Scale("season1/episode1/images/freeroam4/images/spencer/14.webp", 1920, 1080)
image sp_e1f4-15 = im.Scale("season1/episode1/images/freeroam4/images/spencer/15.webp", 1920, 1080)
image sp_e1f4-16 = im.Scale("season1/episode1/images/freeroam4/images/spencer/16.webp", 1920, 1080)
image sp_e1f4-17 = im.Scale("season1/episode1/images/freeroam4/images/spencer/17.webp", 1920, 1080)
image sp_e1f4-18 = im.Scale("season1/episode1/images/freeroam4/images/spencer/18.webp", 1920, 1080)
image sp_e1f4-19 = im.Scale("season1/episode1/images/freeroam4/images/spencer/19.webp", 1920, 1080)
image sp_e1f4-20 = im.Scale("season1/episode1/images/freeroam4/images/spencer/20.webp", 1920, 1080)
image sp_e1f4-21 = im.Scale("season1/episode1/images/freeroam4/images/spencer/21.webp", 1920, 1080)
image sp_e1f4-22 = im.Scale("season1/episode1/images/freeroam4/images/spencer/22.webp", 1920, 1080)
image sp_e1f4-23 = im.Scale("season1/episode1/images/freeroam4/images/spencer/23.webp", 1920, 1080)

image e1f4-spencer_blink1:
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1f4-spencer_blink2:
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/spencer_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie ########################################################################
image sd_e1f4-01 = im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/1.webp", 1920, 1080)
image sd_e1f4-02 = im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/2.webp", 1920, 1080)
image sd_e1f4-03 = im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/3.webp", 1920, 1080)
image sd_e1f4-04 = im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/4.webp", 1920, 1080)

image e1f4-sadie_blink1:
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/spencer/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1f4-sadie_blink2:
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam4/images/meet_sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
