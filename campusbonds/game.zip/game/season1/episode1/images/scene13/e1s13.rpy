
# Scene 13 images ##############################################################

image e1s13-01 = im.Scale("season1/episode1/images/scene13/1.webp", 1920, 1080)
image e1s13-02 = im.Scale("season1/episode1/images/scene13/2.webp", 1920, 1080)
image e1s13-03 = im.Scale("season1/episode1/images/scene13/3.webp", 1920, 1080)
image e1s13-04 = im.Scale("season1/episode1/images/scene13/4.webp", 1920, 1080)
image e1s13-05 = im.Scale("season1/episode1/images/scene13/5.webp", 1920, 1080)
image e1s13-06 = im.Scale("season1/episode1/images/scene13/6.webp", 1920, 1080)
image e1s13-07 = im.Scale("season1/episode1/images/scene13/7.webp", 1920, 1080)
image e1s13-08 = im.Scale("season1/episode1/images/scene13/8.webp", 1920, 1080)
image e1s13-09 = im.Scale("season1/episode1/images/scene13/9.webp", 1920, 1080)
image e1s13-10 = im.Scale("season1/episode1/images/scene13/10.webp", 1920, 1080)
image e1s13-11 = im.Scale("season1/episode1/images/scene13/11.webp", 1920, 1080)
image e1s13-12 = im.Scale("season1/episode1/images/scene13/12.webp", 1920, 1080)
image e1s13-13 = im.Scale("season1/episode1/images/scene13/13.webp", 1920, 1080)
image e1s13-14 = im.Scale("season1/episode1/images/scene13/14.webp", 1920, 1080)
image e1s13-15 = im.Scale("season1/episode1/images/scene13/15.webp", 1920, 1080)
image e1s13-16 = im.Scale("season1/episode1/images/scene13/16.webp", 1920, 1080)
image e1s13-17 = im.Scale("season1/episode1/images/scene13/17.webp", 1920, 1080)
image e1s13-18 = im.Scale("season1/episode1/images/scene13/18.webp", 1920, 1080)
image e1s13-19 = im.Scale("season1/episode1/images/scene13/19.webp", 1920, 1080)
image e1s13-20 = im.Scale("season1/episode1/images/scene13/20.webp", 1920, 1080)
image e1s13-21 = im.Scale("season1/episode1/images/scene13/21.webp", 1920, 1080)
image e1s13-22 = im.Scale("season1/episode1/images/scene13/22.webp", 1920, 1080)
image e1s13-23 = im.Scale("season1/episode1/images/scene13/23.webp", 1920, 1080)
image e1s13-24 = im.Scale("season1/episode1/images/scene13/24.webp", 1920, 1080)
image e1s13-25 = im.Scale("season1/episode1/images/scene13/25.webp", 1920, 1080)
image e1s13-26 = im.Scale("season1/episode1/images/scene13/26.webp", 1920, 1080)
image e1s13-27 = im.Scale("season1/episode1/images/scene13/27.webp", 1920, 1080)
image e1s13-28 = im.Scale("season1/episode1/images/scene13/28.webp", 1920, 1080)
image e1s13-29 = im.Scale("season1/episode1/images/scene13/29.webp", 1920, 1080)
image e1s13-30 = im.Scale("season1/episode1/images/scene13/30.webp", 1920, 1080)
image e1s13-31 = im.Scale("season1/episode1/images/scene13/31.webp", 1920, 1080)
image e1s13-32 = im.Scale("season1/episode1/images/scene13/32.webp", 1920, 1080)
image e1s13-33 = im.Scale("season1/episode1/images/scene13/33.webp", 1920, 1080)
image e1s13-34 = im.Scale("season1/episode1/images/scene13/34.webp", 1920, 1080)
image e1s13-35 = im.Scale("season1/episode1/images/scene13/35.webp", 1920, 1080)
image e1s13-36 = im.Scale("season1/episode1/images/scene13/36.webp", 1920, 1080)

image e1s13-36_anim = Movie(play="season1/episode1/images/scene13/36_anim.webm")

image e1s13-37 = im.Scale("season1/episode1/images/scene13/37.webp", 1920, 1080)
image e1s13-38 = im.Scale("season1/episode1/images/scene13/38.webp", 1920, 1080)
image e1s13-39 = im.Scale("season1/episode1/images/scene13/39.webp", 1920, 1080)
image e1s13-40 = im.Scale("season1/episode1/images/scene13/40.webp", 1920, 1080)
image e1s13-41 = im.Scale("season1/episode1/images/scene13/41.webp", 1920, 1080)
image e1s13-42 = im.Scale("season1/episode1/images/scene13/42.webp", 1920, 1080)
image e1s13-43 = im.Scale("season1/episode1/images/scene13/43.webp", 1920, 1080)
image e1s13-44 = im.Scale("season1/episode1/images/scene13/44.webp", 1920, 1080)
image e1s13-45 = im.Scale("season1/episode1/images/scene13/45.webp", 1920, 1080)
image e1s13-46 = im.Scale("season1/episode1/images/scene13/46.webp", 1920, 1080)
image e1s13-47 = im.Scale("season1/episode1/images/scene13/47.webp", 1920, 1080)
image e1s13-48 = im.Scale("season1/episode1/images/scene13/48.webp", 1920, 1080)
image e1s13-49 = im.Scale("season1/episode1/images/scene13/49.webp", 1920, 1080)
image e1s13-50 = im.Scale("season1/episode1/images/scene13/50.webp", 1920, 1080)
image e1s13-51 = im.Scale("season1/episode1/images/scene13/51.webp", 1920, 1080)
image e1s13-52 = im.Scale("season1/episode1/images/scene13/52.webp", 1920, 1080)
image e1s13-53 = im.Scale("season1/episode1/images/scene13/53.webp", 1920, 1080)
image e1s13-54 = im.Scale("season1/episode1/images/scene13/54.webp", 1920, 1080)
image e1s13-55 = im.Scale("season1/episode1/images/scene13/55.webp", 1920, 1080)
image e1s13-56 = im.Scale("season1/episode1/images/scene13/56.webp", 1920, 1080)
image e1s13-57 = im.Scale("season1/episode1/images/scene13/57.webp", 1920, 1080)
image e1s13-58 = im.Scale("season1/episode1/images/scene13/58.webp", 1920, 1080)
image e1s13-59 = im.Scale("season1/episode1/images/scene13/59.webp", 1920, 1080)
image e1s13-60 = im.Scale("season1/episode1/images/scene13/60.webp", 1920, 1080)
image e1s13-61 = im.Scale("season1/episode1/images/scene13/61.webp", 1920, 1080)
image e1s13-62 = im.Scale("season1/episode1/images/scene13/62.webp", 1920, 1080)

# Censored images ##############################################################

image c_e1s13-46 = im.Scale("season1/episode1/images/scene13/censored/46.webp", 1920, 1080)
image c_e1s13-49 = im.Scale("season1/episode1/images/scene13/censored/49.webp", 1920, 1080)
image c_e1s13-50 = im.Scale("season1/episode1/images/scene13/censored/50.webp", 1920, 1080)
image c_e1s13-51 = im.Scale("season1/episode1/images/scene13/censored/51.webp", 1920, 1080)
image c_e1s13-52 = im.Scale("season1/episode1/images/scene13/censored/52.webp", 1920, 1080)
image c_e1s13-53 = im.Scale("season1/episode1/images/scene13/censored/53.webp", 1920, 1080)
image c_e1s13-54 = im.Scale("season1/episode1/images/scene13/censored/54.webp", 1920, 1080)

# Cleo Blink ###################################################################

image e1s13_cleo_blink1:
    im.Scale("season1/episode1/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Jon Blink ####################################################################

image e1s13_jon_blink1:
    im.Scale("season1/episode1/images/scene13/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s13_jon_blink2:
    im.Scale("season1/episode1/images/scene13/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/jon_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Bridget Blink ################################################################

image e1s13_bridget_blink1:
    im.Scale("season1/episode1/images/scene13/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene13/bridget_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
