
# Scene 12 images ##############################################################

image e1s12-01 = im.Scale("season1/episode1/images/scene12/1.webp", 1920, 1080)
image e1s12-02 = im.Scale("season1/episode1/images/scene12/2.webp", 1920, 1080)
image e1s12-03 = im.Scale("season1/episode1/images/scene12/3.webp", 1920, 1080)
image e1s12-04 = im.Scale("season1/episode1/images/scene12/4.webp", 1920, 1080)
image e1s12-05 = im.Scale("season1/episode1/images/scene12/5.webp", 1920, 1080)
image e1s12-06 = im.Scale("season1/episode1/images/scene12/6.webp", 1920, 1080)
image e1s12-07 = im.Scale("season1/episode1/images/scene12/7.webp", 1920, 1080)
image e1s12-08 = im.Scale("season1/episode1/images/scene12/8.webp", 1920, 1080)
image e1s12-09 = im.Scale("season1/episode1/images/scene12/9.webp", 1920, 1080)
image e1s12-10 = im.Scale("season1/episode1/images/scene12/10.webp", 1920, 1080)
image e1s12-11 = im.Scale("season1/episode1/images/scene12/11.webp", 1920, 1080)
image e1s12-12 = im.Scale("season1/episode1/images/scene12/12.webp", 1920, 1080)
image e1s12-13 = im.Scale("season1/episode1/images/scene12/13.webp", 1920, 1080)
image e1s12-14 = im.Scale("season1/episode1/images/scene12/14.webp", 1920, 1080)
image e1s12-15 = im.Scale("season1/episode1/images/scene12/15.webp", 1920, 1080)
image e1s12-16 = im.Scale("season1/episode1/images/scene12/16.webp", 1920, 1080)
image e1s12-17 = im.Scale("season1/episode1/images/scene12/17.webp", 1920, 1080)
image e1s12-18 = im.Scale("season1/episode1/images/scene12/18.webp", 1920, 1080)
image e1s12-19 = im.Scale("season1/episode1/images/scene12/19.webp", 1920, 1080)
image e1s12-20 = im.Scale("season1/episode1/images/scene12/20.webp", 1920, 1080)
image e1s12-21 = im.Scale("season1/episode1/images/scene12/21.webp", 1920, 1080)

# Jon Blink ####################################################################

image e1s12_jon_blink1:
    im.Scale("season1/episode1/images/scene12/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s12_jon_blink2:
    im.Scale("season1/episode1/images/scene12/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s12_jon_blink3:
    im.Scale("season1/episode1/images/scene12/jon_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene12/jon_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
