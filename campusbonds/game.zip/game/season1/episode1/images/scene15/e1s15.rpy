
# Scene 15 images ##############################################################

image e1s15-01 = im.Scale("season1/episode1/images/scene15/1.webp", 1920, 1080)
image e1s15-02 = im.Scale("season1/episode1/images/scene15/2.webp", 1920, 1080)
image e1s15-03 = im.Scale("season1/episode1/images/scene15/3.webp", 1920, 1080)
image e1s15-04 = im.Scale("season1/episode1/images/scene15/4.webp", 1920, 1080)
image e1s15-05 = im.Scale("season1/episode1/images/scene15/5.webp", 1920, 1080)
image e1s15-06 = im.Scale("season1/episode1/images/scene15/6.webp", 1920, 1080)
image e1s15-07 = im.Scale("season1/episode1/images/scene15/7.webp", 1920, 1080)
image e1s15-08 = im.Scale("season1/episode1/images/scene15/8.webp", 1920, 1080)
image e1s15-09 = im.Scale("season1/episode1/images/scene15/9.webp", 1920, 1080)
image e1s15-10 = im.Scale("season1/episode1/images/scene15/10.webp", 1920, 1080)
image e1s15-11 = im.Scale("season1/episode1/images/scene15/11.webp", 1920, 1080)
image e1s15-12 = im.Scale("season1/episode1/images/scene15/12.webp", 1920, 1080)
image e1s15-13 = im.Scale("season1/episode1/images/scene15/13.webp", 1920, 1080)
image e1s15-14 = im.Scale("season1/episode1/images/scene15/14.webp", 1920, 1080)
image e1s15-15 = im.Scale("season1/episode1/images/scene15/15.webp", 1920, 1080)
image e1s15-16 = im.Scale("season1/episode1/images/scene15/16.webp", 1920, 1080)
image e1s15-17 = im.Scale("season1/episode1/images/scene15/17.webp", 1920, 1080)
image e1s15-18 = im.Scale("season1/episode1/images/scene15/18.webp", 1920, 1080)
image e1s15-19 = im.Scale("season1/episode1/images/scene15/19.webp", 1920, 1080)
image e1s15-20 = im.Scale("season1/episode1/images/scene15/20.webp", 1920, 1080)
image e1s15-21 = im.Scale("season1/episode1/images/scene15/21.webp", 1920, 1080)
image e1s15-22 = im.Scale("season1/episode1/images/scene15/22.webp", 1920, 1080)
image e1s15-23 = im.Scale("season1/episode1/images/scene15/23.webp", 1920, 1080)
image e1s15-24 = im.Scale("season1/episode1/images/scene15/24.webp", 1920, 1080)
image e1s15-25 = im.Scale("season1/episode1/images/scene15/25.webp", 1920, 1080)
image e1s15-26 = im.Scale("season1/episode1/images/scene15/26.webp", 1920, 1080)
image e1s15-27 = im.Scale("season1/episode1/images/scene15/27.webp", 1920, 1080)
image e1s15-28 = im.Scale("season1/episode1/images/scene15/28.webp", 1920, 1080)
image e1s15-29 = im.Scale("season1/episode1/images/scene15/29.webp", 1920, 1080)
image e1s15-30 = im.Scale("season1/episode1/images/scene15/30.webp", 1920, 1080)
image e1s15-31 = im.Scale("season1/episode1/images/scene15/31.webp", 1920, 1080)
image e1s15-32 = im.Scale("season1/episode1/images/scene15/32.webp", 1920, 1080)
image e1s15-33 = im.Scale("season1/episode1/images/scene15/33.webp", 1920, 1080)
image e1s15-34 = im.Scale("season1/episode1/images/scene15/34.webp", 1920, 1080)
image e1s15-35 = im.Scale("season1/episode1/images/scene15/35.webp", 1920, 1080)
image e1s15-36 = im.Scale("season1/episode1/images/scene15/36.webp", 1920, 1080)
image e1s15-37 = im.Scale("season1/episode1/images/scene15/37.webp", 1920, 1080)
image e1s15-38 = im.Scale("season1/episode1/images/scene15/38.webp", 1920, 1080)
image e1s15-39 = im.Scale("season1/episode1/images/scene15/39.webp", 1920, 1080)
image e1s15-40 = im.Scale("season1/episode1/images/scene15/40.webp", 1920, 1080)
image e1s15-41 = im.Scale("season1/episode1/images/scene15/41.webp", 1920, 1080)
image e1s15-42 = im.Scale("season1/episode1/images/scene15/42.webp", 1920, 1080)
image e1s15-43 = im.Scale("season1/episode1/images/scene15/43.webp", 1920, 1080)
image e1s15-44 = im.Scale("season1/episode1/images/scene15/44.webp", 1920, 1080)
image e1s15-45 = im.Scale("season1/episode1/images/scene15/45.webp", 1920, 1080)
image e1s15-46 = im.Scale("season1/episode1/images/scene15/46.webp", 1920, 1080)
image e1s15-47 = im.Scale("season1/episode1/images/scene15/47.webp", 1920, 1080)
image e1s15-48 = im.Scale("season1/episode1/images/scene15/48.webp", 1920, 1080)
image e1s15-49 = im.Scale("season1/episode1/images/scene15/49.webp", 1920, 1080)
image e1s15-50 = im.Scale("season1/episode1/images/scene15/50.webp", 1920, 1080)
image e1s15-51 = im.Scale("season1/episode1/images/scene15/51.webp", 1920, 1080)
image e1s15-52 = im.Scale("season1/episode1/images/scene15/52.webp", 1920, 1080)
image e1s15-53 = im.Scale("season1/episode1/images/scene15/53.webp", 1920, 1080)
image e1s15-54 = im.Scale("season1/episode1/images/scene15/54.webp", 1920, 1080)
image e1s15-55 = im.Scale("season1/episode1/images/scene15/55.webp", 1920, 1080)
image e1s15-56 = im.Scale("season1/episode1/images/scene15/56.webp", 1920, 1080)
image e1s15-57 = im.Scale("season1/episode1/images/scene15/57.webp", 1920, 1080)
image e1s15-58 = im.Scale("season1/episode1/images/scene15/58.webp", 1920, 1080)
image e1s15-59 = im.Scale("season1/episode1/images/scene15/59.webp", 1920, 1080)
image e1s15-60 = im.Scale("season1/episode1/images/scene15/60.webp", 1920, 1080)
image e1s15-61 = im.Scale("season1/episode1/images/scene15/61.webp", 1920, 1080)
image e1s15-62 = im.Scale("season1/episode1/images/scene15/62.webp", 1920, 1080)
image e1s15-63 = im.Scale("season1/episode1/images/scene15/63.webp", 1920, 1080)
image e1s15-64 = im.Scale("season1/episode1/images/scene15/64.webp", 1920, 1080)
image e1s15-65 = im.Scale("season1/episode1/images/scene15/65.webp", 1920, 1080)
image e1s15-66 = im.Scale("season1/episode1/images/scene15/66.webp", 1920, 1080)

# Cleo Blink ###################################################################

image e1s15_cleo_blink1:
    im.Scale("season1/episode1/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s15_cleo_blink2:
    im.Scale("season1/episode1/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s15_cleo_blink3:
    im.Scale("season1/episode1/images/scene15/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s15_cleo_blink4:
    im.Scale("season1/episode1/images/scene15/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/cleo_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Darryl Blink ###################################################################

image e1s15_darryl_blink1:
    im.Scale("season1/episode1/images/scene15/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/darryl_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# MC Blink #####################################################################

image e1s15_mc_blink1:
    im.Scale("season1/episode1/images/scene15/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene15/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
