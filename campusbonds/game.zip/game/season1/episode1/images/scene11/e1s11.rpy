
# Scene 11 images ##############################################################

image e1s11-01 = im.Scale("season1/episode1/images/scene11/1.webp", 1920, 1080)
image e1s11-02 = im.Scale("season1/episode1/images/scene11/2.webp", 1920, 1080)
image e1s11-03 = im.Scale("season1/episode1/images/scene11/3.webp", 1920, 1080)
image e1s11-04 = im.Scale("season1/episode1/images/scene11/4.webp", 1920, 1080)
image e1s11-05 = im.Scale("season1/episode1/images/scene11/5.webp", 1920, 1080)
image e1s11-06 = im.Scale("season1/episode1/images/scene11/6.webp", 1920, 1080)
image e1s11-07 = im.Scale("season1/episode1/images/scene11/7.webp", 1920, 1080)
image e1s11-08 = im.Scale("season1/episode1/images/scene11/8.webp", 1920, 1080)
image e1s11-09 = im.Scale("season1/episode1/images/scene11/9.webp", 1920, 1080)
image e1s11-10 = im.Scale("season1/episode1/images/scene11/10.webp", 1920, 1080)
image e1s11-11 = im.Scale("season1/episode1/images/scene11/11.webp", 1920, 1080)
image e1s11-12 = im.Scale("season1/episode1/images/scene11/12.webp", 1920, 1080)
image e1s11-13 = im.Scale("season1/episode1/images/scene11/13.webp", 1920, 1080)
image e1s11-14 = im.Scale("season1/episode1/images/scene11/14.webp", 1920, 1080)
image e1s11-15 = im.Scale("season1/episode1/images/scene11/15.webp", 1920, 1080)
image e1s11-16 = im.Scale("season1/episode1/images/scene11/16.webp", 1920, 1080)
image e1s11-17 = im.Scale("season1/episode1/images/scene11/17.webp", 1920, 1080)
image e1s11-18 = im.Scale("season1/episode1/images/scene11/18.webp", 1920, 1080)
image e1s11-19 = im.Scale("season1/episode1/images/scene11/19.webp", 1920, 1080)
image e1s11-20 = im.Scale("season1/episode1/images/scene11/20.webp", 1920, 1080)
image e1s11-21 = im.Scale("season1/episode1/images/scene11/21.webp", 1920, 1080)
image e1s11-22 = im.Scale("season1/episode1/images/scene11/22.webp", 1920, 1080)
image e1s11-23 = im.Scale("season1/episode1/images/scene11/23.webp", 1920, 1080)
image e1s11-24 = im.Scale("season1/episode1/images/scene11/24.webp", 1920, 1080)
image e1s11-25 = im.Scale("season1/episode1/images/scene11/25.webp", 1920, 1080)
image e1s11-26 = im.Scale("season1/episode1/images/scene11/26.webp", 1920, 1080)
image e1s11-28 = im.Scale("season1/episode1/images/scene11/28.webp", 1920, 1080)

image e1s11-29 = Movie(play="season1/episode1/images/scene11/29.webm")

image e1s11-30 = im.Scale("season1/episode1/images/scene11/30.webp", 1920, 1080)
image e1s11-31 = im.Scale("season1/episode1/images/scene11/31.webp", 1920, 1080)
image e1s11-32 = im.Scale("season1/episode1/images/scene11/32.webp", 1920, 1080)
image e1s11-33 = im.Scale("season1/episode1/images/scene11/33.webp", 1920, 1080)
image e1s11-34 = im.Scale("season1/episode1/images/scene11/34.webp", 1920, 1080)
image e1s11-35 = im.Scale("season1/episode1/images/scene11/35.webp", 1920, 1080)
image e1s11-36 = im.Scale("season1/episode1/images/scene11/36.webp", 1920, 1080)
image e1s11-37 = im.Scale("season1/episode1/images/scene11/37.webp", 1920, 1080)

image e1s11-38 = Movie(play="season1/episode1/images/scene11/38.webm")

image e1s11-39 = im.Scale("season1/episode1/images/scene11/39.webp", 1920, 1080)
image e1s11-40 = im.Scale("season1/episode1/images/scene11/40.webp", 1920, 1080)
image e1s11-41 = im.Scale("season1/episode1/images/scene11/41.webp", 1920, 1080)
image e1s11-42 = im.Scale("season1/episode1/images/scene11/42.webp", 1920, 1080)

# Francesca Blink ##############################################################

image e1s11-francesca_blink1:
    im.Scale("season1/episode1/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s11_francesca_blink2:
    im.Scale("season1/episode1/images/scene11/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s11-francesca_blink3:
    im.Scale("season1/episode1/images/scene11/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s11-francesca_blink4:
    im.Scale("season1/episode1/images/scene11/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene11/francesca_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
