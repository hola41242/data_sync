# Images #######################################################################

image e1f1-02 = im.Scale("season1/episode1/images/freeroam1/2.webp", 1920, 1080)
image e1f1-05 = im.Scale("season1/episode1/images/freeroam1/5.webp", 1920, 1080)

# Living #######################################################################

image e1f1-01 = im.Scale("season1/episode1/images/freeroam1/1.webp", 1920, 1080)

image e1f1-01-no_luggage = im.Scale("season1/episode1/images/freeroam1/1_no_luggage.webp", 1920, 1080)
image e1f1-money = im.Scale("season1/episode1/images/freeroam1/1_money.webp", 1920, 1080)

image e1f1-li1 = im.Scale("season1/episode1/images/freeroam1/images/21.webp", 1920, 1080)
image e1f1-li2 = im.Scale("season1/episode1/images/freeroam1/images/22.webp", 1920, 1080)
image e1f1-li3 = im.Scale("season1/episode1/images/freeroam1/images/23.webp", 1920, 1080)
image e1f1-li4 = im.Scale("season1/episode1/images/freeroam1/images/24.webp", 1920, 1080)
image e1f1-li5 = im.Scale("season1/episode1/images/freeroam1/images/25.webp", 1920, 1080)
image e1f1-li6 = im.Scale("season1/episode1/images/freeroam1/images/26.webp", 1920, 1080)

image e1s4-01 = im.Scale("season1/episode1/images/freeroam1/1.webp", 1920, 1080)
image e1s4-02 = im.Scale("season1/episode1/images/freeroam1/2.webp", 1920, 1080)

# Balcony ######################################################################

image e1f1-03 = im.Scale("season1/episode1/images/freeroam1/3.webp", 1920, 1080)

image e1f1-bc1 = im.Scale("season1/episode1/images/freeroam1/images/10.webp", 1920, 1080)
image e1f1-bc2 = im.Scale("season1/episode1/images/freeroam1/images/11.webp", 1920, 1080)
image e1f1-bc3 = im.Scale("season1/episode1/images/freeroam1/images/12.webp", 1920, 1080)
image e1f1-bc4 = im.Scale("season1/episode1/images/freeroam1/images/13.webp", 1920, 1080)
image e1f1-bc5 = im.Scale("season1/episode1/images/freeroam1/images/14.webp", 1920, 1080)
image e1f1-bc6 = im.Scale("season1/episode1/images/freeroam1/images/15.webp", 1920, 1080)
image e1f1-bc7 = im.Scale("season1/episode1/images/freeroam1/images/16.webp", 1920, 1080)
image e1f1-bc8 = im.Scale("season1/episode1/images/freeroam1/images/17.webp", 1920, 1080)
image e1f1-bc9 = im.Scale("season1/episode1/images/freeroam1/images/18.webp", 1920, 1080)
image e1f1-bc10 = im.Scale("season1/episode1/images/freeroam1/images/19.webp", 1920, 1080)
image e1f1-bc11 = im.Scale("season1/episode1/images/freeroam1/images/20.webp", 1920, 1080)

# Bedroom ######################################################################

image e1f1-04 = im.Scale("season1/episode1/images/freeroam1/4.webp", 1920, 1080)

image e1f1-br1 = im.Scale("season1/episode1/images/freeroam1/images/1.webp", 1920, 1080)
image e1f1-br2 = im.Scale("season1/episode1/images/freeroam1/images/2.webp", 1920, 1080)
image e1f1-br3 = im.Scale("season1/episode1/images/freeroam1/images/3.webp", 1920, 1080)
image e1f1-br4 = im.Scale("season1/episode1/images/freeroam1/images/4.webp", 1920, 1080)
image e1f1-br5 = im.Scale("season1/episode1/images/freeroam1/images/5.webp", 1920, 1080)
image e1f1-br6 = im.Scale("season1/episode1/images/freeroam1/images/6.webp", 1920, 1080)
image e1f1-br7 = im.Scale("season1/episode1/images/freeroam1/images/7.webp", 1920, 1080)
image e1f1-br8 = im.Scale("season1/episode1/images/freeroam1/images/8.webp", 1920, 1080)
image e1f1-br9 = im.Scale("season1/episode1/images/freeroam1/images/9.webp", 1920, 1080)
