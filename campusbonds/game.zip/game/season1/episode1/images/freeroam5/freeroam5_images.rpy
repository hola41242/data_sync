
# Main #########################################################################
image e1f5-01 = im.Scale("season1/episode1/images/freeroam5/1.webp", 1920, 1080)
image e1f5-01-1 = im.Scale("season1/episode1/images/freeroam5/1.1.webp", 1920, 1080)
image e1f5-01-2 = im.Scale("season1/episode1/images/freeroam5/1.2.webp", 1920, 1080)
image e1f5-01-3 = im.Scale("season1/episode1/images/freeroam5/1.3.webp", 1920, 1080)
image e1f5-01-4 = im.Scale("season1/episode1/images/freeroam5/1.4.webp", 1920, 1080)

# Bar ##########################################################################
image e1f5-02 = im.Scale("season1/episode1/images/freeroam5/2.webp", 1920, 1080)
image e1f5-02-1 = im.Scale("season1/episode1/images/freeroam5/2.1.webp", 1920, 1080)

# Exit #########################################################################
image e1f5-03 = im.Scale("season1/episode1/images/freeroam5/3.webp", 1920, 1080)
image e1f5-03-1 = im.Scale("season1/episode1/images/freeroam5/3.1.webp", 1920, 1080)

# Back #########################################################################
image e1f5-04 = im.Scale("season1/episode1/images/freeroam5/4.webp", 1920, 1080)

# Bathroom #####################################################################
image e1f5-05 = im.Scale("season1/episode1/images/freeroam5/5.webp", 1920, 1080)
image e1f5-05-1 = im.Scale("season1/episode1/images/freeroam5/5.1.webp", 1920, 1080)

# Outside #####################################################################
image e1f5-06 = im.Scale("season1/episode1/images/freeroam5/6.webp", 1920, 1080)
image e1f5-06-1 = im.Scale("season1/episode1/images/freeroam5/6.1.webp", 1920, 1080)
image e1f5-06-2 = im.Scale("season1/episode1/images/freeroam5/6.2.webp", 1920, 1080)
image e1f5-06-3 = im.Scale("season1/episode1/images/freeroam5/6.3.webp", 1920, 1080)


# Bouncer ######################################################################

# Static

image bcer_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/1.webp", 1920, 1080)
image bcer_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/2.webp", 1920, 1080)
image bcer_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/3.webp", 1920, 1080)
image bcer_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/4.webp", 1920, 1080)
image bcer_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/5.webp", 1920, 1080)
image bcer_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/6.webp", 1920, 1080)
image bcer_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/7.webp", 1920, 1080)
image bcer_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/8.webp", 1920, 1080)
image bcer_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/9.webp", 1920, 1080)
image bcer_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/bouncer1/10.webp", 1920, 1080)

# Animations

image bcer_e1f5-bouncer_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/bouncer1/bouncer_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ken_Jordan ###################################################################

# Static

image kejd_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/1.webp", 1920, 1080)
image kejd_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/2.webp", 1920, 1080)
image kejd_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/3.webp", 1920, 1080)
image kejd_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/4.webp", 1920, 1080)
image kejd_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/5.webp", 1920, 1080)
image kejd_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/6.webp", 1920, 1080)
image kejd_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/7.webp", 1920, 1080)
image kejd_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/8.webp", 1920, 1080)
image kejd_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/9.webp", 1920, 1080)
image kejd_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/10.webp", 1920, 1080)
image kejd_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/11.webp", 1920, 1080)
image kejd_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/12.webp", 1920, 1080)
image kejd_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/13.webp", 1920, 1080)
image kejd_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/14.webp", 1920, 1080)
image kejd_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/15.webp", 1920, 1080)
image kejd_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/ken_jordan/16.webp", 1920, 1080)

# Ken Outside ##################################################################

# Static

image kenout_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/1.webp", 1920, 1080)
image kenout_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/2.webp", 1920, 1080)
image kenout_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/3.webp", 1920, 1080)
image kenout_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/4.webp", 1920, 1080)
image kenout_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/5.webp", 1920, 1080)
image kenout_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/6.webp", 1920, 1080)
image kenout_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/7.webp", 1920, 1080)
image kenout_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/8.webp", 1920, 1080)
image kenout_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/9.webp", 1920, 1080)
image kenout_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/10.webp", 1920, 1080)
image kenout_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/11.webp", 1920, 1080)
image kenout_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/12.webp", 1920, 1080)
image kenout_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/13.webp", 1920, 1080)
image kenout_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/14.webp", 1920, 1080)
image kenout_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/15.webp", 1920, 1080)
image kenout_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/16.webp", 1920, 1080)
image kenout_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/17.webp", 1920, 1080)
image kenout_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/18.webp", 1920, 1080)
image kenout_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/19.webp", 1920, 1080)
image kenout_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/20.webp", 1920, 1080)
image kenout_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/21.webp", 1920, 1080)
image kenout_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/22.webp", 1920, 1080)
image kenout_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/23.webp", 1920, 1080)
image kenout_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/24.webp", 1920, 1080)
image kenout_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/ken_outside/25.webp", 1920, 1080)

# Animations

image kenout_e1f5-ken_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image kenout_e1f5-ken_blink2:
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/ken_outside/ken_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Nate Bar 1 #####################################################################

# Static

image ntbr_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/1.webp", 1920, 1080)
image ntbr_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/2.webp", 1920, 1080)
image ntbr_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/3.webp", 1920, 1080)
image ntbr_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/4.webp", 1920, 1080)
image ntbr_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/5.webp", 1920, 1080)
image ntbr_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/6.webp", 1920, 1080)
image ntbr_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/7.webp", 1920, 1080)
image ntbr_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/8.webp", 1920, 1080)
image ntbr_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/9.webp", 1920, 1080)
image ntbr_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/10.webp", 1920, 1080)
image ntbr_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/11.webp", 1920, 1080)
image ntbr_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/12.webp", 1920, 1080)
image ntbr_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/13.webp", 1920, 1080)
image ntbr_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/14.webp", 1920, 1080)
image ntbr_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/15.webp", 1920, 1080)
image ntbr_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/16.webp", 1920, 1080)
image ntbr_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/17.webp", 1920, 1080)
image ntbr_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/18.webp", 1920, 1080)
image ntbr_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/19.webp", 1920, 1080)

# Animations

image ntbr_e1f5-nate_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image ntbr_e1f5-nate_blink2:
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image ntbr_e1f5-nate_blink3:
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/nate_bar1/nate_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie Drink ##################################################################

# Static

image sddr_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/1.webp", 1920, 1080)
image sddr_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/2.webp", 1920, 1080)
image sddr_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/3.webp", 1920, 1080)
image sddr_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/4.webp", 1920, 1080)
image sddr_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/5.webp", 1920, 1080)
image sddr_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/6.webp", 1920, 1080)
image sddr_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/7.webp", 1920, 1080)
image sddr_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/8.webp", 1920, 1080)
image sddr_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/9.webp", 1920, 1080)
image sddr_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/10.webp", 1920, 1080)
image sddr_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/11.webp", 1920, 1080)
image sddr_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/12.webp", 1920, 1080)
image sddr_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/13.webp", 1920, 1080)
image sddr_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/14.webp", 1920, 1080)
image sddr_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/15.webp", 1920, 1080)
image sddr_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/16.webp", 1920, 1080)
image sddr_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/17.webp", 1920, 1080)
image sddr_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/18.webp", 1920, 1080)
image sddr_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/19.webp", 1920, 1080)
image sddr_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/20.webp", 1920, 1080)
image sddr_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/21.webp", 1920, 1080)
image sddr_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/22.webp", 1920, 1080)
image sddr_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/23.webp", 1920, 1080)
image sddr_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/24.webp", 1920, 1080)
image sddr_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/25.webp", 1920, 1080)
image sddr_e1f5-26 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/26.webp", 1920, 1080)
image sddr_e1f5-27 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/27.webp", 1920, 1080)
image sddr_e1f5-28 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/28.webp", 1920, 1080)
image sddr_e1f5-29 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/29.webp", 1920, 1080)
image sddr_e1f5-30 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/30.webp", 1920, 1080)
image sddr_e1f5-31 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/31.webp", 1920, 1080)
image sddr_e1f5-32 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/32.webp", 1920, 1080)
image sddr_e1f5-33 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/33.webp", 1920, 1080)
image sddr_e1f5-34 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/34.webp", 1920, 1080)
image sddr_e1f5-35 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/35.webp", 1920, 1080)
image sddr_e1f5-36 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/36.webp", 1920, 1080)
image sddr_e1f5-37 = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/37.webp", 1920, 1080)

# Censored

image sddr_e1f5-34_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/censored/34.webp", 1920, 1080)

# Animations

image sddr_e1f5-kiss = Movie(play="season1/episode1/images/freeroam5/images/sadie_drink/kiss.webm")

image sddr_e1f5-sadie_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image sddr_e1f5-sadie_blink2:
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image sddr_e1f5-sadie_blink3:
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_drink/sadie_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie Sex ####################################################################

# Static

image sdsx_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/1.webp", 1920, 1080)
image sdsx_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/2.webp", 1920, 1080)
image sdsx_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/3.webp", 1920, 1080)
image sdsx_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/4.webp", 1920, 1080)
image sdsx_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/5.webp", 1920, 1080)
image sdsx_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/6.webp", 1920, 1080)
image sdsx_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/7.webp", 1920, 1080)
image sdsx_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/8.webp", 1920, 1080)
image sdsx_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/9.webp", 1920, 1080)
image sdsx_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/10.webp", 1920, 1080)
image sdsx_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/11.webp", 1920, 1080)
image sdsx_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/12.webp", 1920, 1080)
image sdsx_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/13.webp", 1920, 1080)
image sdsx_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/14.webp", 1920, 1080)
image sdsx_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/15.webp", 1920, 1080)
image sdsx_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/16.webp", 1920, 1080)
image sdsx_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/17.webp", 1920, 1080)
image sdsx_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/18.webp", 1920, 1080)
image sdsx_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/19.webp", 1920, 1080)
image sdsx_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/20.webp", 1920, 1080)
image sdsx_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/21.webp", 1920, 1080)
image sdsx_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/22.webp", 1920, 1080)
image sdsx_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/23.webp", 1920, 1080)
image sdsx_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/24.webp", 1920, 1080)
image sdsx_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/25.webp", 1920, 1080)
image sdsx_e1f5-26 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/26.webp", 1920, 1080)
image sdsx_e1f5-27 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/27.webp", 1920, 1080)

image sdsx_e1f5-cum-01 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/cum.webp", 1920, 1080)
image sdsx_e1f5-cum-02 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/cum2.webp", 1920, 1080)
image sdsx_e1f5-cum-03 = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/cum3.webp", 1920, 1080)

# Animations

image sdsx_e1f5-kiss = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/kiss.webm")

image sdsx_e1f5-blow-01 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/blow1.webm")
image sdsx_e1f5-blow-02 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/blow2.webm")
image sdsx_e1f5-blow-03 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/blow3.webm")
image sdsx_e1f5-blow-04 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/blow4.webm")
image sdsx_e1f5-blow-05 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/blow5.webm")
image sdsx_e1f5-sex-01 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex1.webm")
image sdsx_e1f5-sex-02 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex2.webm")
image sdsx_e1f5-sex-03 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex3.webm")
image sdsx_e1f5-sex-04 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex4.webm")
image sdsx_e1f5-sex-05 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex5.webm")
image sdsx_e1f5-sex-06 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex6.webm")
image sdsx_e1f5-sex-07 = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/sex7.webm")

# censored #####

# Static


image sdsx_e1f5-11_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/11.webp", 1920, 1080)
image sdsx_e1f5-13_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/13.webp", 1920, 1080)
image sdsx_e1f5-14_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/14.webp", 1920, 1080)
image sdsx_e1f5-15_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/15.webp", 1920, 1080)
image sdsx_e1f5-16_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/16.webp", 1920, 1080)
image sdsx_e1f5-17_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/17.webp", 1920, 1080)
image sdsx_e1f5-18_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/18.webp", 1920, 1080)
image sdsx_e1f5-19_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/19.webp", 1920, 1080)
image sdsx_e1f5-20_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/20.webp", 1920, 1080)
image sdsx_e1f5-21_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/21.webp", 1920, 1080)
image sdsx_e1f5-22_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/22.webp", 1920, 1080)
image sdsx_e1f5-27_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/27.webp", 1920, 1080)

image sdsx_e1f5-cum-01_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/cum.webp", 1920, 1080)
image sdsx_e1f5-cum-02_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/cum2.webp", 1920, 1080)
image sdsx_e1f5-cum-03_cen = im.Scale("season1/episode1/images/freeroam5/images/sadie_sex/censored/cum3.webp", 1920, 1080)

# Animations

image sdsx_e1f5-blow-01_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/blow1.webm")
image sdsx_e1f5-blow-02_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/blow2.webm")
image sdsx_e1f5-blow-03_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/blow3.webm")
image sdsx_e1f5-blow-04_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/blow4.webm")
image sdsx_e1f5-blow-05_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/blow5.webm")
image sdsx_e1f5-sex-01_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex1.webm")
image sdsx_e1f5-sex-02_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex2.webm")
image sdsx_e1f5-sex-03_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex3.webm")
image sdsx_e1f5-sex-04_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex4.webm")
image sdsx_e1f5-sex-05_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex5.webm")
image sdsx_e1f5-sex-06_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex6.webm")
image sdsx_e1f5-sex-07_cen = Movie(play="season1/episode1/images/freeroam5/images/sadie_sex/censored/sex7.webm")

# Sadie Tracy 1 ################################################################

# Static

image sdtr1_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/1.webp", 1920, 1080)
image sdtr1_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/2.webp", 1920, 1080)
image sdtr1_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/3.webp", 1920, 1080)
image sdtr1_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/4.webp", 1920, 1080)
image sdtr1_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/5.webp", 1920, 1080)
image sdtr1_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/6.webp", 1920, 1080)
image sdtr1_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/7.webp", 1920, 1080)
image sdtr1_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/8.webp", 1920, 1080)
image sdtr1_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/9.webp", 1920, 1080)
image sdtr1_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/10.webp", 1920, 1080)
image sdtr1_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/11.webp", 1920, 1080)
image sdtr1_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/12.webp", 1920, 1080)
image sdtr1_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/13.webp", 1920, 1080)
image sdtr1_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/14.webp", 1920, 1080)
image sdtr1_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/15.webp", 1920, 1080)
image sdtr1_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/16.webp", 1920, 1080)
image sdtr1_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/17.webp", 1920, 1080)
image sdtr1_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/18.webp", 1920, 1080)
image sdtr1_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/19.webp", 1920, 1080)
image sdtr1_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/20.webp", 1920, 1080)
image sdtr1_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/21.webp", 1920, 1080)
image sdtr1_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/22.webp", 1920, 1080)
image sdtr1_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/23.webp", 1920, 1080)
image sdtr1_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/24.webp", 1920, 1080)
image sdtr1_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/25.webp", 1920, 1080)
image sdtr1_e1f5-26 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/26.webp", 1920, 1080)
image sdtr1_e1f5-27 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/27.webp", 1920, 1080)
image sdtr1_e1f5-28 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/28.webp", 1920, 1080)
image sdtr1_e1f5-29 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/29.webp", 1920, 1080)
image sdtr1_e1f5-30 = im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/30.webp", 1920, 1080)

# Animations

image sdtr1_e1f5-tracy_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/sadie_tracy_1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy Drink ##################################################################

# Static

image trdr_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/1.webp", 1920, 1080)
image trdr_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/2.webp", 1920, 1080)
image trdr_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/3.webp", 1920, 1080)
image trdr_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/4.webp", 1920, 1080)
image trdr_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/5.webp", 1920, 1080)
image trdr_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/6.webp", 1920, 1080)
image trdr_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/7.webp", 1920, 1080)
image trdr_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/8.webp", 1920, 1080)
image trdr_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/9.webp", 1920, 1080)
image trdr_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/10.webp", 1920, 1080)
image trdr_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/11.webp", 1920, 1080)
image trdr_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/12.webp", 1920, 1080)
image trdr_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/13.webp", 1920, 1080)
image trdr_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/14.webp", 1920, 1080)
image trdr_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/15.webp", 1920, 1080)
image trdr_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/16.webp", 1920, 1080)
image trdr_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/17.webp", 1920, 1080)
image trdr_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/18.webp", 1920, 1080)
image trdr_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/19.webp", 1920, 1080)
image trdr_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/20.webp", 1920, 1080)
image trdr_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/21.webp", 1920, 1080)
image trdr_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/22.webp", 1920, 1080)
image trdr_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/23.webp", 1920, 1080)
image trdr_e1f5-26 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/24.webp", 1920, 1080)
image trdr_e1f5-27 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/25.webp", 1920, 1080)
image trdr_e1f5-28 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/26.webp", 1920, 1080)
image trdr_e1f5-29 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/27.webp", 1920, 1080)
image trdr_e1f5-30 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/28.webp", 1920, 1080)
image trdr_e1f5-31 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/29.webp", 1920, 1080)
image trdr_e1f5-32 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/30.webp", 1920, 1080)
image trdr_e1f5-33 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/31.webp", 1920, 1080)
image trdr_e1f5-34 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/32.webp", 1920, 1080)
image trdr_e1f5-35 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/33.webp", 1920, 1080)
image trdr_e1f5-36 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/34.webp", 1920, 1080)
image trdr_e1f5-37 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/35.webp", 1920, 1080)
image trdr_e1f5-38 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/36.webp", 1920, 1080)
image trdr_e1f5-39 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/37.webp", 1920, 1080)
image trdr_e1f5-40 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/38.webp", 1920, 1080)
image trdr_e1f5-41 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/39.webp", 1920, 1080)
image trdr_e1f5-42 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/40.webp", 1920, 1080)
image trdr_e1f5-43 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/41.webp", 1920, 1080)
image trdr_e1f5-44 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/42.webp", 1920, 1080)
image trdr_e1f5-45 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/43.webp", 1920, 1080)
image trdr_e1f5-46 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/44.webp", 1920, 1080)
image trdr_e1f5-47 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/45.webp", 1920, 1080)
image trdr_e1f5-48 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/46.webp", 1920, 1080)
image trdr_e1f5-49 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/47.webp", 1920, 1080)
image trdr_e1f5-50 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/48.webp", 1920, 1080)
image trdr_e1f5-51 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/49.webp", 1920, 1080)
image trdr_e1f5-52 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/50.webp", 1920, 1080)
image trdr_e1f5-53 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/51.webp", 1920, 1080)
image trdr_e1f5-54 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/52.webp", 1920, 1080)
image trdr_e1f5-55 = im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/53.webp", 1920, 1080)

# Animations

image trdr_e1f5-bartender_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/bartender_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trdr_e1f5-tracy_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trdr_e1f5-tracy_blink2:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trdr_e1f5-tracy_blink3:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trdr_e1f5-tracy_blink4:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trdr_e1f5-tracy_blink5:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_drink/tracy_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy Sex ####################################################################

# Static

image trsx_e1f5-01 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/1.webp", 1920, 1080)
image trsx_e1f5-02 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/2.webp", 1920, 1080)
image trsx_e1f5-03 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/3.webp", 1920, 1080)
image trsx_e1f5-04 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/4.webp", 1920, 1080)
image trsx_e1f5-05 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/5.webp", 1920, 1080)
image trsx_e1f5-06 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/6.webp", 1920, 1080)
image trsx_e1f5-07 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/7.webp", 1920, 1080)
image trsx_e1f5-08 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/8.webp", 1920, 1080)
image trsx_e1f5-09 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/9.webp", 1920, 1080)
image trsx_e1f5-10 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/10.webp", 1920, 1080)
image trsx_e1f5-11 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/11.webp", 1920, 1080)
image trsx_e1f5-12 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/12.webp", 1920, 1080)
image trsx_e1f5-13 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/13.webp", 1920, 1080)
image trsx_e1f5-14 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/14.webp", 1920, 1080)
image trsx_e1f5-15 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/15.webp", 1920, 1080)
image trsx_e1f5-16 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/16.webp", 1920, 1080)
image trsx_e1f5-17 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/17.webp", 1920, 1080)
image trsx_e1f5-18 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/18.webp", 1920, 1080)
image trsx_e1f5-19 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/19.webp", 1920, 1080)
image trsx_e1f5-20 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/20.webp", 1920, 1080)
image trsx_e1f5-21 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/21.webp", 1920, 1080)
image trsx_e1f5-22 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/22.webp", 1920, 1080)
image trsx_e1f5-23 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/23.webp", 1920, 1080)
image trsx_e1f5-24 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/24.webp", 1920, 1080)
image trsx_e1f5-25 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/25.webp", 1920, 1080)
image trsx_e1f5-26 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/26.webp", 1920, 1080)
image trsx_e1f5-27 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/27.webp", 1920, 1080)
image trsx_e1f5-28 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/28.webp", 1920, 1080)
image trsx_e1f5-29 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/29.webp", 1920, 1080)
image trsx_e1f5-30 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/30.webp", 1920, 1080)
image trsx_e1f5-31 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/31.webp", 1920, 1080)
image trsx_e1f5-32 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/32.webp", 1920, 1080)
image trsx_e1f5-33 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/33.webp", 1920, 1080)
image trsx_e1f5-34 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/34.webp", 1920, 1080)
image trsx_e1f5-35 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/35.webp", 1920, 1080)
image trsx_e1f5-36 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/36.webp", 1920, 1080)
image trsx_e1f5-37 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/37.webp", 1920, 1080)
image trsx_e1f5-38 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/38.webp", 1920, 1080)

image trsx_e1f5-cum-01 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/cum.webp", 1920, 1080)
image trsx_e1f5-cum-02 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/cum2.webp", 1920, 1080)
image trsx_e1f5-cum-03 = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/cum3.webp", 1920, 1080)

# Animations

image trsx_e1f5-mc_high = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/mc_high.webm")
image trsx_e1f5-kiss = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/kiss.webm")

image trsx_e1f5-blow-01 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/blow1.webm")
image trsx_e1f5-blow-02 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/blow2.webm")
image trsx_e1f5-blow-03 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/blow3.webm")
image trsx_e1f5-blow-04 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/blow4.webm")
image trsx_e1f5-hand-01 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/hand1.webm")
image trsx_e1f5-hand-02 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/hand2.webm")
image trsx_e1f5-sex-01 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex1.webm")
image trsx_e1f5-sex-02 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex2.webm")
image trsx_e1f5-sex-03 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex3.webm")
image trsx_e1f5-sex-04 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex4.webm")
image trsx_e1f5-sex-05 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex5.webm")
image trsx_e1f5-sex-06 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex6.webm")
image trsx_e1f5-sex-07 = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/sex7.webm")

image trsx_e1f5-tracy_blink1:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trsx_e1f5-tracy_blink2:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image trsx_e1f5-tracy_blink3:
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# censored #####

# Static

image trsx_e1f5-27_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/27.webp", 1920, 1080)
image trsx_e1f5-29_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/29.webp", 1920, 1080)
image trsx_e1f5-30_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/30.webp", 1920, 1080)

image trsx_e1f5-cum-01_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/cum.webp", 1920, 1080)
image trsx_e1f5-cum-02_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/cum2.webp", 1920, 1080)
image trsx_e1f5-cum-03_cen = im.Scale("season1/episode1/images/freeroam5/images/tracy_sex/censored/cum3.webp", 1920, 1080)

# Animations

image trsx_e1f5-blow-01_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/blow1.webm")
image trsx_e1f5-blow-02_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/blow2.webm")
image trsx_e1f5-blow-03_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/blow3.webm")
image trsx_e1f5-blow-04_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/blow4.webm")
image trsx_e1f5-hand-01_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/hand1.webm")
image trsx_e1f5-hand-02_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/hand2.webm")
image trsx_e1f5-sex-01_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex1.webm")
image trsx_e1f5-sex-02_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex2.webm")
image trsx_e1f5-sex-03_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex3.webm")
image trsx_e1f5-sex-04_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex4.webm")
image trsx_e1f5-sex-05_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex5.webm")
image trsx_e1f5-sex-06_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex6.webm")
image trsx_e1f5-sex-07_cen = Movie(play="season1/episode1/images/freeroam5/images/tracy_sex/censored/sex7.webm")
