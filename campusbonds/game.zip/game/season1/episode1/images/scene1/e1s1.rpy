
# E1S1 Scenes

image e1s1-01 = im.Scale("season1/episode1/images/scene1/1.webp", 1920, 1080)
image e1s1-02 = im.Scale("season1/episode1/images/scene1/2.webp", 1920, 1080)
image e1s1-03 = im.Scale("season1/episode1/images/scene1/3.webp", 1920, 1080)
image e1s1-04 = im.Scale("season1/episode1/images/scene1/4.webp", 1920, 1080)
image e1s1-05 = im.Scale("season1/episode1/images/scene1/5.webp", 1920, 1080)
image e1s1-06 = im.Scale("season1/episode1/images/scene1/6.webp", 1920, 1080)
image e1s1-07 = im.Scale("season1/episode1/images/scene1/7.webp", 1920, 1080)
image e1s1-08 = im.Scale("season1/episode1/images/scene1/8.webp", 1920, 1080)
image e1s1-09 = im.Scale("season1/episode1/images/scene1/9.webp", 1920, 1080)
image e1s1-10 = im.Scale("season1/episode1/images/scene1/10.webp", 1920, 1080)
image e1s1-11 = im.Scale("season1/episode1/images/scene1/11.webp", 1920, 1080)
image e1s1-12 = im.Scale("season1/episode1/images/scene1/12.webp", 1920, 1080)
image e1s1-13 = im.Scale("season1/episode1/images/scene1/13.webp", 1920, 1080)
image e1s1-14 = im.Scale("season1/episode1/images/scene1/14.webp", 1920, 1080)
image e1s1-15 = im.Scale("season1/episode1/images/scene1/15.webp", 1920, 1080)
image e1s1-16 = im.Scale("season1/episode1/images/scene1/16.webp", 1920, 1080)
image e1s1-17 = im.Scale("season1/episode1/images/scene1/17.webp", 1920, 1080)
image e1s1-18 = im.Scale("season1/episode1/images/scene1/18.webp", 1920, 1080)
image e1s1-19 = im.Scale("season1/episode1/images/scene1/19.webp", 1920, 1080)
image e1s1-20 = im.Scale("season1/episode1/images/scene1/20.webp", 1920, 1080)
image e1s1-21 = im.Scale("season1/episode1/images/scene1/21.webp", 1920, 1080)
image e1s1-22 = im.Scale("season1/episode1/images/scene1/22.webp", 1920, 1080)
image e1s1-23 = im.Scale("season1/episode1/images/scene1/23.webp", 1920, 1080)
image e1s1-24 = im.Scale("season1/episode1/images/scene1/24.webp", 1920, 1080)
image e1s1-25 = im.Scale("season1/episode1/images/scene1/25.webp", 1920, 1080)

image e1s1-joel_blink1:
    im.Scale("season1/episode1/images/scene1/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s1-joel_blink2:
    im.Scale("season1/episode1/images/scene1/joel_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene1/joel_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
