
# Scene 9 images ###############################################################

image e1s9-01 = im.Scale("season1/episode1/images/scene9/1.webp", 1920, 1080)
image e1s9-02 = im.Scale("season1/episode1/images/scene9/2.webp", 1920, 1080)
image e1s9-03 = im.Scale("season1/episode1/images/scene9/3.webp", 1920, 1080)
image e1s9-04 = im.Scale("season1/episode1/images/scene9/4.webp", 1920, 1080)
image e1s9-05 = im.Scale("season1/episode1/images/scene9/5.webp", 1920, 1080)
image e1s9-06 = im.Scale("season1/episode1/images/scene9/6.webp", 1920, 1080)
image e1s9-07 = im.Scale("season1/episode1/images/scene9/7.webp", 1920, 1080)
image e1s9-08 = im.Scale("season1/episode1/images/scene9/8.webp", 1920, 1080)
image e1s9-09 = im.Scale("season1/episode1/images/scene9/9.webp", 1920, 1080)
image e1s9-10 = im.Scale("season1/episode1/images/scene9/10.webp", 1920, 1080)
image e1s9-11 = im.Scale("season1/episode1/images/scene9/11.webp", 1920, 1080)
image e1s9-12 = im.Scale("season1/episode1/images/scene9/12.webp", 1920, 1080)
image e1s9-13 = im.Scale("season1/episode1/images/scene9/13.webp", 1920, 1080)
image e1s9-14 = im.Scale("season1/episode1/images/scene9/14.webp", 1920, 1080)
image e1s9-15 = im.Scale("season1/episode1/images/scene9/15.webp", 1920, 1080)
image e1s9-16 = im.Scale("season1/episode1/images/scene9/16.webp", 1920, 1080)
image e1s9-17 = im.Scale("season1/episode1/images/scene9/17.webp", 1920, 1080)
image e1s9-18 = im.Scale("season1/episode1/images/scene9/18.webp", 1920, 1080)
image e1s9-19 = im.Scale("season1/episode1/images/scene9/19.webp", 1920, 1080)
image e1s9-20 = im.Scale("season1/episode1/images/scene9/20.webp", 1920, 1080)
image e1s9-21 = im.Scale("season1/episode1/images/scene9/21.webp", 1920, 1080)
image e1s9-22 = im.Scale("season1/episode1/images/scene9/22.webp", 1920, 1080)
image e1s9-23 = im.Scale("season1/episode1/images/scene9/23.webp", 1920, 1080)
image e1s9-24 = im.Scale("season1/episode1/images/scene9/24.webp", 1920, 1080)
image e1s9-25 = im.Scale("season1/episode1/images/scene9/25.webp", 1920, 1080)
image e1s9-26 = im.Scale("season1/episode1/images/scene9/26.webp", 1920, 1080)
image e1s9-27 = im.Scale("season1/episode1/images/scene9/27.webp", 1920, 1080)
image e1s9-28 = im.Scale("season1/episode1/images/scene9/28.webp", 1920, 1080)
image e1s9-29 = im.Scale("season1/episode1/images/scene9/29.webp", 1920, 1080)
image e1s9-30 = im.Scale("season1/episode1/images/scene9/30.webp", 1920, 1080)
image e1s9-31 = im.Scale("season1/episode1/images/scene9/31.webp", 1920, 1080)
image e1s9-32 = im.Scale("season1/episode1/images/scene9/32.webp", 1920, 1080)
image e1s9-33 = im.Scale("season1/episode1/images/scene9/33.webp", 1920, 1080)
image e1s9-34 = im.Scale("season1/episode1/images/scene9/34.webp", 1920, 1080)
image e1s9-35 = im.Scale("season1/episode1/images/scene9/35.webp", 1920, 1080)
image e1s9-36 = im.Scale("season1/episode1/images/scene9/36.webp", 1920, 1080)
image e1s9-37 = im.Scale("season1/episode1/images/scene9/37.webp", 1920, 1080)
image e1s9-38 = im.Scale("season1/episode1/images/scene9/38.webp", 1920, 1080)
image e1s9-39 = im.Scale("season1/episode1/images/scene9/39.webp", 1920, 1080)
image e1s9-40 = im.Scale("season1/episode1/images/scene9/40.webp", 1920, 1080)
image e1s9-41 = im.Scale("season1/episode1/images/scene9/41.webp", 1920, 1080)
image e1s9-42 = im.Scale("season1/episode1/images/scene9/42.webp", 1920, 1080)
image e1s9-43 = im.Scale("season1/episode1/images/scene9/43.webp", 1920, 1080)
image e1s9-44 = im.Scale("season1/episode1/images/scene9/44.webp", 1920, 1080)

# Censored images ##############################################################

image c_e1s9-13 = im.Scale("season1/episode1/images/scene9/censored/13.webp", 1920, 1080)
image c_e1s9-14 = im.Scale("season1/episode1/images/scene9/censored/14.webp", 1920, 1080)
image c_e1s9-15 = im.Scale("season1/episode1/images/scene9/censored/15.webp", 1920, 1080)
image c_e1s9-16 = im.Scale("season1/episode1/images/scene9/censored/16.webp", 1920, 1080)
image c_e1s9-17 = im.Scale("season1/episode1/images/scene9/censored/17.webp", 1920, 1080)
image c_e1s9-18 = im.Scale("season1/episode1/images/scene9/censored/18.webp", 1920, 1080)
image c_e1s9-19 = im.Scale("season1/episode1/images/scene9/censored/19.webp", 1920, 1080)
image c_e1s9-26 = im.Scale("season1/episode1/images/scene9/censored/26.webp", 1920, 1080)
image c_e1s9-27 = im.Scale("season1/episode1/images/scene9/censored/27.webp", 1920, 1080)
image c_e1s9-28 = im.Scale("season1/episode1/images/scene9/censored/28.webp", 1920, 1080)
image c_e1s9-29 = im.Scale("season1/episode1/images/scene9/censored/29.webp", 1920, 1080)
image c_e1s9-30 = im.Scale("season1/episode1/images/scene9/censored/30.webp", 1920, 1080)
image c_e1s9-31 = im.Scale("season1/episode1/images/scene9/censored/31.webp", 1920, 1080)
image c_e1s9-32 = im.Scale("season1/episode1/images/scene9/censored/32.webp", 1920, 1080)
image c_e1s9-33 = im.Scale("season1/episode1/images/scene9/censored/33.webp", 1920, 1080)
image c_e1s9-34 = im.Scale("season1/episode1/images/scene9/censored/34.webp", 1920, 1080)

image white = im.Scale("white.png", 1920, 1080)

image e1s9-mc_blink1:
    im.Scale("season1/episode1/images/scene9/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e1s9-mc_blink2:
    im.Scale("season1/episode1/images/scene9/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode1/images/scene9/mc_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
