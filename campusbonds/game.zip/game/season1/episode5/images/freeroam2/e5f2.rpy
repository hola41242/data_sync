
# Freeroam 2 Images ############################################################
# Main
image e5f2-01 = im.Scale("season1/episode5/images/freeroam2/1.webp", 1920, 1080)
image e5f2-01_1 = im.Scale("season1/episode5/images/freeroam2/1.1.webp", 1920, 1080)

# Left
image e5f2-02 = im.Scale("season1/episode5/images/freeroam2/2.webp", 1920, 1080)
image e5f2-02_1 = im.Scale("season1/episode5/images/freeroam2/2.1.webp", 1920, 1080)
image e5f2-02_2 = im.Scale("season1/episode5/images/freeroam2/2.2.webp", 1920, 1080)

# Right
image e5f2-03 = im.Scale("season1/episode5/images/freeroam2/3.webp", 1920, 1080)

# Hallway 1
image e5f2-04 = im.Scale("season1/episode5/images/freeroam2/4.webp", 1920, 1080)

# Hallway 2
image e5f2-05 = im.Scale("season1/episode5/images/freeroam2/5.webp", 1920, 1080)

# Hallway 3
image e5f2-06 = im.Scale("season1/episode5/images/freeroam2/6.webp", 1920, 1080)

# Hallway Middle
image e5f2-07 = im.Scale("season1/episode5/images/freeroam2/7.webp", 1920, 1080)

# Hallway Left
image e5f2-08 = im.Scale("season1/episode5/images/freeroam2/8.webp", 1920, 1080)

# Hallway Right
image e5f2-09 = im.Scale("season1/episode5/images/freeroam2/9.webp", 1920, 1080)



# Cleo 1
image e5f2-cleo1_01 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/1.webp", 1920, 1080)
image e5f2-cleo1_02 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/2.webp", 1920, 1080)
image e5f2-cleo1_03 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/3.webp", 1920, 1080)
image e5f2-cleo1_04 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/4.webp", 1920, 1080)
image e5f2-cleo1_05 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/5.webp", 1920, 1080)
image e5f2-cleo1_06 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/6.webp", 1920, 1080)
image e5f2-cleo1_07 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/7.webp", 1920, 1080)
image e5f2-cleo1_08 = im.Scale("season1/episode5/images/freeroam2/images/cleo1/8.webp", 1920, 1080)

image e5f2_cleo1_blink1:
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Cleo 2
image e5f2-cleo2_01 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/1.webp", 1920, 1080)
image e5f2-cleo2_02 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/2.webp", 1920, 1080)
image e5f2-cleo2_03 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/3.webp", 1920, 1080)
image e5f2-cleo2_04 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/4.webp", 1920, 1080)
image e5f2-cleo2_05 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/5.webp", 1920, 1080)
image e5f2-cleo2_06 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/6.webp", 1920, 1080)
image e5f2-cleo2_07 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/7.webp", 1920, 1080)
image e5f2-cleo2_08 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/8.webp", 1920, 1080)
image e5f2-cleo2_09 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/9.webp", 1920, 1080)
image e5f2-cleo2_10 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/10.webp", 1920, 1080)
image e5f2-cleo2_11 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/11.webp", 1920, 1080)
image e5f2-cleo2_12 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/12.webp", 1920, 1080)
image e5f2-cleo2_13 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/13.webp", 1920, 1080)
image e5f2-cleo2_14 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/14.webp", 1920, 1080)
image e5f2-cleo2_15 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/15.webp", 1920, 1080)
image e5f2-cleo2_16 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/16.webp", 1920, 1080)
image e5f2-cleo2_17 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/17.webp", 1920, 1080)
image e5f2-cleo2_18 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/18.webp", 1920, 1080)
image e5f2-cleo2_19 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/19.webp", 1920, 1080)
image e5f2-cleo2_20 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/20.webp", 1920, 1080)
image e5f2-cleo2_21 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/21.webp", 1920, 1080)
image e5f2-cleo2_22 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/22.webp", 1920, 1080)
image e5f2-cleo2_23 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/23.webp", 1920, 1080)
image e5f2-cleo2_24 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/24.webp", 1920, 1080)
image e5f2-cleo2_25 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/25.webp", 1920, 1080)
image e5f2-cleo2_26 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/26.webp", 1920, 1080)
image e5f2-cleo2_27 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/27.webp", 1920, 1080)
image e5f2-cleo2_28 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/28.webp", 1920, 1080)
image e5f2-cleo2_29 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/29.webp", 1920, 1080)
image e5f2-cleo2_30 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/30.webp", 1920, 1080)
image e5f2-cleo2_31 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/31.webp", 1920, 1080)
image e5f2-cleo2_32 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/32.webp", 1920, 1080)
image e5f2-cleo2_33 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/33.webp", 1920, 1080)
image e5f2-cleo2_34 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/34.webp", 1920, 1080)
image e5f2-cleo2_35 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/35.webp", 1920, 1080)
image e5f2-cleo2_36 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/36.webp", 1920, 1080)
image e5f2-cleo2_37 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/37.webp", 1920, 1080)
image e5f2-cleo2_38 = im.Scale("season1/episode5/images/freeroam2/images/cleo2/38.webp", 1920, 1080)

image e5f2_cleo2_blink1:
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5f2_cleo2_blink2:
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam2/images/cleo2/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Cleo 3
image e5f2-cleo3_01 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/1.webp", 1920, 1080)
image e5f2-cleo3_02 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/2.webp", 1920, 1080)
image e5f2-cleo3_03 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/3.webp", 1920, 1080)
image e5f2-cleo3_04 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/4.webp", 1920, 1080)
image e5f2-cleo3_05 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/5.webp", 1920, 1080)
image e5f2-cleo3_06 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/6.webp", 1920, 1080)
image e5f2-cleo3_07 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/7.webp", 1920, 1080)
image e5f2-cleo3_08 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/8.webp", 1920, 1080)
image e5f2-cleo3_09 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/9.webp", 1920, 1080)
image e5f2-cleo3_10 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/10.webp", 1920, 1080)
image e5f2-cleo3_11 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/11.webp", 1920, 1080)
image e5f2-cleo3_12 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/12.webp", 1920, 1080)
image e5f2-cleo3_13 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/13.webp", 1920, 1080)
image e5f2-cleo3_14 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/14.webp", 1920, 1080)
image e5f2-cleo3_15 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/15.webp", 1920, 1080)
image e5f2-cleo3_16 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/16.webp", 1920, 1080)
image e5f2-cleo3_17 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/17.webp", 1920, 1080)
image e5f2-cleo3_18 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/18.webp", 1920, 1080)
image e5f2-cleo3_19 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/19.webp", 1920, 1080)
image e5f2-cleo3_20 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/20.webp", 1920, 1080)
image e5f2-cleo3_21 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/21.webp", 1920, 1080)
image e5f2-cleo3_22 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/22.webp", 1920, 1080)
image e5f2-cleo3_23 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/23.webp", 1920, 1080)
image e5f2-cleo3_24 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/24.webp", 1920, 1080)
image e5f2-cleo3_25 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/25.webp", 1920, 1080)
image e5f2-cleo3_26 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/26.webp", 1920, 1080)
image e5f2-cleo3_27 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/27.webp", 1920, 1080)
image e5f2-cleo3_28 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/28.webp", 1920, 1080)
image e5f2-cleo3_29 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/29.webp", 1920, 1080)
image e5f2-cleo3_30 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/30.webp", 1920, 1080)
image e5f2-cleo3_31 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/31.webp", 1920, 1080)
image e5f2-cleo3_32 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/32.webp", 1920, 1080)
image e5f2-cleo3_33 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/33.webp", 1920, 1080)
image e5f2-cleo3_34 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/34.webp", 1920, 1080)
image e5f2-cleo3_35 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/35.webp", 1920, 1080)
image e5f2-cleo3_36 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/36.webp", 1920, 1080)
image e5f2-cleo3_37 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/37.webp", 1920, 1080)
image e5f2-cleo3_38 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/38.webp", 1920, 1080)
image e5f2-cleo3_39 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/39.webp", 1920, 1080)
image e5f2-cleo3_40 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/40.webp", 1920, 1080)
image e5f2-cleo3_41 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/41.webp", 1920, 1080)
image e5f2-cleo3_42 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/42.webp", 1920, 1080)
image e5f2-cleo3_43 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/43.webp", 1920, 1080)
image e5f2-cleo3_44 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/44.webp", 1920, 1080)
image e5f2-cleo3_45 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/45.webp", 1920, 1080)
image e5f2-cleo3_46 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/46.webp", 1920, 1080)
image e5f2-cleo3_47 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/47.webp", 1920, 1080)
image e5f2-cleo3_48 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/48.webp", 1920, 1080)
image e5f2-cleo3_49 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/49.webp", 1920, 1080)
image e5f2-cleo3_50 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/50.webp", 1920, 1080)
image e5f2-cleo3_51 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/51.webp", 1920, 1080)
image e5f2-cleo3_52 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/52.webp", 1920, 1080)
image e5f2-cleo3_53 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/53.webp", 1920, 1080)
image e5f2-cleo3_54 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/54.webp", 1920, 1080)
image e5f2-cleo3_55 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/55.webp", 1920, 1080)
image e5f2-cleo3_56 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/56.webp", 1920, 1080)
image e5f2-cleo3_57 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/57.webp", 1920, 1080)
image e5f2-cleo3_58 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/58.webp", 1920, 1080)
image e5f2-cleo3_59 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/59.webp", 1920, 1080)
image e5f2-cleo3_60 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/60.webp", 1920, 1080)
image e5f2-cleo3_61 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/61.webp", 1920, 1080)
image e5f2-cleo3_62 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/62.webp", 1920, 1080)
image e5f2-cleo3_63 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/63.webp", 1920, 1080)
image e5f2-cleo3_64 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/64.webp", 1920, 1080)
image e5f2-cleo3_65 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/65.webp", 1920, 1080)
image e5f2-cleo3_66 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/66.webp", 1920, 1080)
image e5f2-cleo3_67 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/67.webp", 1920, 1080)
image e5f2-cleo3_68 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/68.webp", 1920, 1080)
image e5f2-cleo3_69 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/69.webp", 1920, 1080)
image e5f2-cleo3_70 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/70.webp", 1920, 1080)
image e5f2-cleo3_71 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/71.webp", 1920, 1080)
image e5f2-cleo3_72 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/72.webp", 1920, 1080)
image e5f2-cleo3_73 = im.Scale("season1/episode5/images/freeroam2/images/cleo3/73.webp", 1920, 1080)

# Guitar
image e5f2-desk_01 = im.Scale("season1/episode5/images/freeroam2/images/desk1/1.webp", 1920, 1080)
image e5f2-desk_02 = im.Scale("season1/episode5/images/freeroam2/images/desk1/2.webp", 1920, 1080)
image e5f2-desk_03 = im.Scale("season1/episode5/images/freeroam2/images/desk1/3.webp", 1920, 1080)

# Guitar
image e5f2-guitar_01 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/1.webp", 1920, 1080)
image e5f2-guitar_02 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/2.webp", 1920, 1080)
image e5f2-guitar_03 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/3.webp", 1920, 1080)
image e5f2-guitar_04 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/4.webp", 1920, 1080)
image e5f2-guitar_05 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/5.webp", 1920, 1080)
image e5f2-guitar_06 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/6.webp", 1920, 1080)
image e5f2-guitar_07 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/7.webp", 1920, 1080)
image e5f2-guitar_08 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/8.webp", 1920, 1080)
image e5f2-guitar_09 = im.Scale("season1/episode5/images/freeroam2/images/guitar1/9.webp", 1920, 1080)

# Jordan
image e5f2-jordan_01 = im.Scale("season1/episode5/images/freeroam2/images/jordan1/1.webp", 1920, 1080)
image e5f2-jordan_02 = im.Scale("season1/episode5/images/freeroam2/images/jordan1/2.webp", 1920, 1080)
image e5f2-jordan_03 = im.Scale("season1/episode5/images/freeroam2/images/jordan1/3.webp", 1920, 1080)
image e5f2-jordan_04 = im.Scale("season1/episode5/images/freeroam2/images/jordan1/4.webp", 1920, 1080)
image e5f2-jordan_05 = im.Scale("season1/episode5/images/freeroam2/images/jordan1/5.webp", 1920, 1080)

# Ken
image e5f2-ken_01 = im.Scale("season1/episode5/images/freeroam2/images/ken1/1.webp", 1920, 1080)
image e5f2-ken_02 = im.Scale("season1/episode5/images/freeroam2/images/ken1/2.webp", 1920, 1080)
image e5f2-ken_03 = im.Scale("season1/episode5/images/freeroam2/images/ken1/3.webp", 1920, 1080)
image e5f2-ken_04 = im.Scale("season1/episode5/images/freeroam2/images/ken1/4.webp", 1920, 1080)
image e5f2-ken_05 = im.Scale("season1/episode5/images/freeroam2/images/ken1/5.webp", 1920, 1080)
image e5f2-ken_06 = im.Scale("season1/episode5/images/freeroam2/images/ken1/6.webp", 1920, 1080)

# Scarlett
image e5f2-scarlett_01 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/1.webp", 1920, 1080)
image e5f2-scarlett_02 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/2.webp", 1920, 1080)
image e5f2-scarlett_03 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/3.webp", 1920, 1080)
image e5f2-scarlett_04 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/4.webp", 1920, 1080)
image e5f2-scarlett_05 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/5.webp", 1920, 1080)
image e5f2-scarlett_06 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/6.webp", 1920, 1080)
image e5f2-scarlett_07 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/7.webp", 1920, 1080)
image e5f2-scarlett_08 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/8.webp", 1920, 1080)
image e5f2-scarlett_09 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/9.webp", 1920, 1080)
image e5f2-scarlett_10 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/10.webp", 1920, 1080)
image e5f2-scarlett_11 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/11.webp", 1920, 1080)
image e5f2-scarlett_12 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/12.webp", 1920, 1080)
image e5f2-scarlett_13 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/13.webp", 1920, 1080)
image e5f2-scarlett_14 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/14.webp", 1920, 1080)
image e5f2-scarlett_15 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/15.webp", 1920, 1080)
image e5f2-scarlett_16 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/16.webp", 1920, 1080)
image e5f2-scarlett_17 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/17.webp", 1920, 1080)
image e5f2-scarlett_18 = im.Scale("season1/episode5/images/freeroam2/images/scarlett1/18.webp", 1920, 1080)

# Stranger
image e5f2-stranger_01 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/1.webp", 1920, 1080)
image e5f2-stranger_02 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/2.webp", 1920, 1080)
image e5f2-stranger_03 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/3.webp", 1920, 1080)
image e5f2-stranger_04 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/4.webp", 1920, 1080)
image e5f2-stranger_05 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/5.webp", 1920, 1080)
image e5f2-stranger_06 = im.Scale("season1/episode5/images/freeroam2/images/stranger1/6.webp", 1920, 1080)

# Tracy
image e5f2-tracy_01 = im.Scale("season1/episode5/images/freeroam2/images/tracy1/1.webp", 1920, 1080)
image e5f2-tracy_02 = im.Scale("season1/episode5/images/freeroam2/images/tracy1/2.webp", 1920, 1080)
