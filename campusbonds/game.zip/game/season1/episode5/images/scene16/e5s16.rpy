
# Scene 16 images ##############################################################

image e5s16-01 = im.Scale("season1/episode5/images/scene16/1.webp", 1920, 1080)
image e5s16-02 = im.Scale("season1/episode5/images/scene16/2.webp", 1920, 1080)
image e5s16-03 = im.Scale("season1/episode5/images/scene16/3.webp", 1920, 1080)
image e5s16-04 = im.Scale("season1/episode5/images/scene16/4.webp", 1920, 1080)
image e5s16-05 = im.Scale("season1/episode5/images/scene16/5.webp", 1920, 1080)
image e5s16-06 = im.Scale("season1/episode5/images/scene16/6.webp", 1920, 1080)
image e5s16-07 = im.Scale("season1/episode5/images/scene16/7.webp", 1920, 1080)
image e5s16-08 = im.Scale("season1/episode5/images/scene16/8.webp", 1920, 1080)
image e5s16-09 = im.Scale("season1/episode5/images/scene16/9.webp", 1920, 1080)
image e5s16-10 = im.Scale("season1/episode5/images/scene16/10.webp", 1920, 1080)
image e5s16-11 = im.Scale("season1/episode5/images/scene16/11.webp", 1920, 1080)
image e5s16-12 = im.Scale("season1/episode5/images/scene16/12.webp", 1920, 1080)
image e5s16-13 = im.Scale("season1/episode5/images/scene16/13.webp", 1920, 1080)
image e5s16-14 = im.Scale("season1/episode5/images/scene16/14.webp", 1920, 1080)
image e5s16-15 = im.Scale("season1/episode5/images/scene16/15.webp", 1920, 1080)
image e5s16-16 = im.Scale("season1/episode5/images/scene16/16.webp", 1920, 1080)
image e5s16-17 = im.Scale("season1/episode5/images/scene16/17.webp", 1920, 1080)
image e5s16-18 = im.Scale("season1/episode5/images/scene16/18.webp", 1920, 1080)
image e5s16-19 = im.Scale("season1/episode5/images/scene16/19.webp", 1920, 1080)
image e5s16-20 = im.Scale("season1/episode5/images/scene16/20.webp", 1920, 1080)
image e5s16-21 = im.Scale("season1/episode5/images/scene16/21.webp", 1920, 1080)
image e5s16-22 = im.Scale("season1/episode5/images/scene16/22.webp", 1920, 1080)
image e5s16-23 = im.Scale("season1/episode5/images/scene16/23.webp", 1920, 1080)
image e5s16-24 = im.Scale("season1/episode5/images/scene16/24.webp", 1920, 1080)
image e5s16-25 = im.Scale("season1/episode5/images/scene16/25.webp", 1920, 1080)
image e5s16-26 = im.Scale("season1/episode5/images/scene16/26.webp", 1920, 1080)
image e5s16-27 = im.Scale("season1/episode5/images/scene16/27.webp", 1920, 1080)
image e5s16-28 = im.Scale("season1/episode5/images/scene16/28.webp", 1920, 1080)
image e5s16-29 = im.Scale("season1/episode5/images/scene16/29.webp", 1920, 1080)
image e5s16-30 = im.Scale("season1/episode5/images/scene16/30.webp", 1920, 1080)
image e5s16-31 = im.Scale("season1/episode5/images/scene16/31.webp", 1920, 1080)
image e5s16-32 = im.Scale("season1/episode5/images/scene16/32.webp", 1920, 1080)
image e5s16-33 = im.Scale("season1/episode5/images/scene16/33.webp", 1920, 1080)
image e5s16-34 = im.Scale("season1/episode5/images/scene16/34.webp", 1920, 1080)
image e5s16-35 = im.Scale("season1/episode5/images/scene16/35.webp", 1920, 1080)
image e5s16-36 = im.Scale("season1/episode5/images/scene16/36.webp", 1920, 1080)
image e5s16-37 = im.Scale("season1/episode5/images/scene16/37.webp", 1920, 1080)
image e5s16-38 = im.Scale("season1/episode5/images/scene16/38.webp", 1920, 1080)
image e5s16-39 = im.Scale("season1/episode5/images/scene16/39.webp", 1920, 1080)
image e5s16-40 = im.Scale("season1/episode5/images/scene16/40.webp", 1920, 1080)
image e5s16-41 = im.Scale("season1/episode5/images/scene16/41.webp", 1920, 1080)
image e5s16-42 = im.Scale("season1/episode5/images/scene16/42.webp", 1920, 1080)
image e5s16-43 = im.Scale("season1/episode5/images/scene16/43.webp", 1920, 1080)
image e5s16-44 = im.Scale("season1/episode5/images/scene16/44.webp", 1920, 1080)
image e5s16-45 = im.Scale("season1/episode5/images/scene16/45.webp", 1920, 1080)
image e5s16-46 = im.Scale("season1/episode5/images/scene16/46.webp", 1920, 1080)
image e5s16-47 = im.Scale("season1/episode5/images/scene16/47.webp", 1920, 1080)
image e5s16-48 = im.Scale("season1/episode5/images/scene16/48.webp", 1920, 1080)
image e5s16-49 = im.Scale("season1/episode5/images/scene16/49.webp", 1920, 1080)
image e5s16-50 = im.Scale("season1/episode5/images/scene16/50.webp", 1920, 1080)
image e5s16-51 = im.Scale("season1/episode5/images/scene16/51.webp", 1920, 1080)
image e5s16-52 = im.Scale("season1/episode5/images/scene16/52.webp", 1920, 1080)
image e5s16-53 = im.Scale("season1/episode5/images/scene16/53.webp", 1920, 1080)
image e5s16-54 = im.Scale("season1/episode5/images/scene16/54.webp", 1920, 1080)
image e5s16-55 = im.Scale("season1/episode5/images/scene16/55.webp", 1920, 1080)
image e5s16-56 = im.Scale("season1/episode5/images/scene16/56.webp", 1920, 1080)
image e5s16-57 = im.Scale("season1/episode5/images/scene16/57.webp", 1920, 1080)
image e5s16-58 = im.Scale("season1/episode5/images/scene16/58.webp", 1920, 1080)
image e5s16-59 = im.Scale("season1/episode5/images/scene16/59.webp", 1920, 1080)
image e5s16-60 = im.Scale("season1/episode5/images/scene16/60.webp", 1920, 1080)
image e5s16-61 = im.Scale("season1/episode5/images/scene16/61.webp", 1920, 1080)
image e5s16-62 = im.Scale("season1/episode5/images/scene16/62.webp", 1920, 1080)
image e5s16-63 = im.Scale("season1/episode5/images/scene16/63.webp", 1920, 1080)
image e5s16-64 = im.Scale("season1/episode5/images/scene16/64.webp", 1920, 1080)
image e5s16-65 = im.Scale("season1/episode5/images/scene16/65.webp", 1920, 1080)
image e5s16-66 = im.Scale("season1/episode5/images/scene16/66.webp", 1920, 1080)
image e5s16-67 = im.Scale("season1/episode5/images/scene16/67.webp", 1920, 1080)
image e5s16-68 = im.Scale("season1/episode5/images/scene16/68.webp", 1920, 1080)
image e5s16-69 = im.Scale("season1/episode5/images/scene16/69.webp", 1920, 1080)

# Animations #
# Static
image e5s16_tiffany_blink1:
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s16_tiffany_blink2:
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e5s16-handjob1 = Movie(play="season1/episode5/images/scene16/handjob1.webm")
image e5s16-handjob2 = Movie(play="season1/episode5/images/scene16/handjob2.webm")
image e5s16-handjob3 = Movie(play="season1/episode5/images/scene16/handjob3.webm")
image e5s16-handjob4 = Movie(play="season1/episode5/images/scene16/handjob4.webm")
image e5s16-handjob5 = Movie(play="season1/episode5/images/scene16/handjob5.webm")
image e5s16-handjob6 = Movie(play="season1/episode5/images/scene16/handjob6.webm")
image e5s16-handjob7 = Movie(play="season1/episode5/images/scene16/handjob7.webm")
image e5s16-handjob8 = Movie(play="season1/episode5/images/scene16/handjob8.webm")
image e5s16-blowjob1 = Movie(play="season1/episode5/images/scene16/blowjob1.webm")
image e5s16-blowjob2 = Movie(play="season1/episode5/images/scene16/blowjob2.webm")
image e5s16-blowjob3 = Movie(play="season1/episode5/images/scene16/blowjob3.webm")

# Censored
# Images
image e5s16-51_cen = im.Scale("season1/episode5/images/scene16/censored/51.webp", 1920, 1080)
image e5s16-52_cen = im.Scale("season1/episode5/images/scene16/censored/52.webp", 1920, 1080)

# Videos
image e5s16-handjob1_cen = Movie(play="season1/episode5/images/scene16/censored/handjob1.webm")
image e5s16-handjob2_cen = Movie(play="season1/episode5/images/scene16/censored/handjob2.webm")
image e5s16-handjob3_cen = Movie(play="season1/episode5/images/scene16/censored/handjob3.webm")
image e5s16-handjob4_cen = Movie(play="season1/episode5/images/scene16/censored/handjob4.webm")
image e5s16-handjob5_cen = Movie(play="season1/episode5/images/scene16/censored/handjob5.webm")
image e5s16-handjob6_cen = Movie(play="season1/episode5/images/scene16/censored/handjob6.webm")
image e5s16-handjob7_cen = Movie(play="season1/episode5/images/scene16/censored/handjob7.webm")
image e5s16-handjob8_cen = Movie(play="season1/episode5/images/scene16/censored/handjob8.webm")
image e5s16-blowjob1_cen = Movie(play="season1/episode5/images/scene16/censored/blowjob1.webm")
image e5s16-blowjob2_cen = Movie(play="season1/episode5/images/scene16/censored/blowjob2.webm")
image e5s16-blowjob3_cen = Movie(play="season1/episode5/images/scene16/censored/blowjob3.webm")
