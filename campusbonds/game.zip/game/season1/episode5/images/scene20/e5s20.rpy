
# Scene 20 images ##############################################################

image e5s20-01 = im.Scale("season1/episode5/images/scene20/1.webp", 1920, 1080)
image e5s20-02 = im.Scale("season1/episode5/images/scene20/2.webp", 1920, 1080)
image e5s20-03 = im.Scale("season1/episode5/images/scene20/3.webp", 1920, 1080)
image e5s20-04 = im.Scale("season1/episode5/images/scene20/4.webp", 1920, 1080)
image e5s20-05 = im.Scale("season1/episode5/images/scene20/5.webp", 1920, 1080)
image e5s20-06 = im.Scale("season1/episode5/images/scene20/6.webp", 1920, 1080)
image e5s20-07 = im.Scale("season1/episode5/images/scene20/7.webp", 1920, 1080)
image e5s20-08 = im.Scale("season1/episode5/images/scene20/8.webp", 1920, 1080)
image e5s20-09 = im.Scale("season1/episode5/images/scene20/9.webp", 1920, 1080)
image e5s20-10 = im.Scale("season1/episode5/images/scene20/10.webp", 1920, 1080)
image e5s20-11 = im.Scale("season1/episode5/images/scene20/11.webp", 1920, 1080)
image e5s20-12 = im.Scale("season1/episode5/images/scene20/12.webp", 1920, 1080)
image e5s20-13 = im.Scale("season1/episode5/images/scene20/13.webp", 1920, 1080)
image e5s20-14 = im.Scale("season1/episode5/images/scene20/14.webp", 1920, 1080)
image e5s20-15 = im.Scale("season1/episode5/images/scene20/15.webp", 1920, 1080)
image e5s20-16 = im.Scale("season1/episode5/images/scene20/16.webp", 1920, 1080)
image e5s20-17 = im.Scale("season1/episode5/images/scene20/17.webp", 1920, 1080)
image e5s20-18 = im.Scale("season1/episode5/images/scene20/18.webp", 1920, 1080)
image e5s20-19 = im.Scale("season1/episode5/images/scene20/19.webp", 1920, 1080)
image e5s20-20 = im.Scale("season1/episode5/images/scene20/20.webp", 1920, 1080)
image e5s20-21 = im.Scale("season1/episode5/images/scene20/21.webp", 1920, 1080)
image e5s20-22 = im.Scale("season1/episode5/images/scene20/22.webp", 1920, 1080)
image e5s20-23 = im.Scale("season1/episode5/images/scene20/23.webp", 1920, 1080)
image e5s20-24 = im.Scale("season1/episode5/images/scene20/24.webp", 1920, 1080)
image e5s20-25 = im.Scale("season1/episode5/images/scene20/25.webp", 1920, 1080)
image e5s20-26 = im.Scale("season1/episode5/images/scene20/26.webp", 1920, 1080)
image e5s20-27 = im.Scale("season1/episode5/images/scene20/27.webp", 1920, 1080)
image e5s20-28 = im.Scale("season1/episode5/images/scene20/28.webp", 1920, 1080)
image e5s20-29 = im.Scale("season1/episode5/images/scene20/29.webp", 1920, 1080)
image e5s20-30 = im.Scale("season1/episode5/images/scene20/30.webp", 1920, 1080)
image e5s20-31 = im.Scale("season1/episode5/images/scene20/31.webp", 1920, 1080)
image e5s20-32 = im.Scale("season1/episode5/images/scene20/32.webp", 1920, 1080)
image e5s20-33 = im.Scale("season1/episode5/images/scene20/33.webp", 1920, 1080)
image e5s20-34 = im.Scale("season1/episode5/images/scene20/34.webp", 1920, 1080)
image e5s20-35 = im.Scale("season1/episode5/images/scene20/35.webp", 1920, 1080)
image e5s20-36 = im.Scale("season1/episode5/images/scene20/36.webp", 1920, 1080)
image e5s20-37 = im.Scale("season1/episode5/images/scene20/37.webp", 1920, 1080)
image e5s20-38 = im.Scale("season1/episode5/images/scene20/38.webp", 1920, 1080)
image e5s20-39 = im.Scale("season1/episode5/images/scene20/39.webp", 1920, 1080)
image e5s20-40 = im.Scale("season1/episode5/images/scene20/40.webp", 1920, 1080)
image e5s20-41 = im.Scale("season1/episode5/images/scene20/41.webp", 1920, 1080)
image e5s20-42 = im.Scale("season1/episode5/images/scene20/42.webp", 1920, 1080)
image e5s20-43 = im.Scale("season1/episode5/images/scene20/43.webp", 1920, 1080)
image e5s20-44 = im.Scale("season1/episode5/images/scene20/44.webp", 1920, 1080)
image e5s20-45 = im.Scale("season1/episode5/images/scene20/45.webp", 1920, 1080)
image e5s20-46 = im.Scale("season1/episode5/images/scene20/46.webp", 1920, 1080)
image e5s20-47 = im.Scale("season1/episode5/images/scene20/47.webp", 1920, 1080)
image e5s20-48 = im.Scale("season1/episode5/images/scene20/48.webp", 1920, 1080)
image e5s20-49 = im.Scale("season1/episode5/images/scene20/49.webp", 1920, 1080)
image e5s20-50 = im.Scale("season1/episode5/images/scene20/50.webp", 1920, 1080)
image e5s20-51 = im.Scale("season1/episode5/images/scene20/51.webp", 1920, 1080)
image e5s20-52 = im.Scale("season1/episode5/images/scene20/52.webp", 1920, 1080)
image e5s20-53 = im.Scale("season1/episode5/images/scene20/53.webp", 1920, 1080)
image e5s20-54 = im.Scale("season1/episode5/images/scene20/54.webp", 1920, 1080)
image e5s20-55 = im.Scale("season1/episode5/images/scene20/55.webp", 1920, 1080)
image e5s20-56 = im.Scale("season1/episode5/images/scene20/56.webp", 1920, 1080)
image e5s20-57 = im.Scale("season1/episode5/images/scene20/57.webp", 1920, 1080)
image e5s20-58 = im.Scale("season1/episode5/images/scene20/58.webp", 1920, 1080)
image e5s20-59 = im.Scale("season1/episode5/images/scene20/59.webp", 1920, 1080)
image e5s20-60 = im.Scale("season1/episode5/images/scene20/60.webp", 1920, 1080)
image e5s20-61 = im.Scale("season1/episode5/images/scene20/61.webp", 1920, 1080)
image e5s20-62 = im.Scale("season1/episode5/images/scene20/62.webp", 1920, 1080)
image e5s20-63 = im.Scale("season1/episode5/images/scene20/63.webp", 1920, 1080)
image e5s20-64 = im.Scale("season1/episode5/images/scene20/64.webp", 1920, 1080)
image e5s20-65 = im.Scale("season1/episode5/images/scene20/65.webp", 1920, 1080)
image e5s20-66 = im.Scale("season1/episode5/images/scene20/66.webp", 1920, 1080)
image e5s20-67 = im.Scale("season1/episode5/images/scene20/67.webp", 1920, 1080)
image e5s20-68 = im.Scale("season1/episode5/images/scene20/68.webp", 1920, 1080)
image e5s20-69 = im.Scale("season1/episode5/images/scene20/69.webp", 1920, 1080)
image e5s20-70 = im.Scale("season1/episode5/images/scene20/70.webp", 1920, 1080)
image e5s20-71 = im.Scale("season1/episode5/images/scene20/71.webp", 1920, 1080)
image e5s20-72 = im.Scale("season1/episode5/images/scene20/72.webp", 1920, 1080)
image e5s20-73 = im.Scale("season1/episode5/images/scene20/73.webp", 1920, 1080)
image e5s20-74 = im.Scale("season1/episode5/images/scene20/74.webp", 1920, 1080)

# Animations #
# Static
image e5s20_cheerleader_blink1:
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene20/cheerleader_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e5s20-blowjob1 = Movie(play="season1/episode5/images/scene20/blowjob1.webm")
image e5s20-blowjob2 = Movie(play="season1/episode5/images/scene20/blowjob2.webm")
image e5s20-blowjob3 = Movie(play="season1/episode5/images/scene20/blowjob3.webm")
image e5s20-blowjob4 = Movie(play="season1/episode5/images/scene20/blowjob4.webm")
image e5s20-blowjob5 = Movie(play="season1/episode5/images/scene20/blowjob5.webm")
image e5s20-blowjob6 = Movie(play="season1/episode5/images/scene20/blowjob6.webm")
image e5s20-titjob1 = Movie(play="season1/episode5/images/scene20/titjob1.webm")
image e5s20-titjob2 = Movie(play="season1/episode5/images/scene20/titjob2.webm")
image e5s20-titjob3 = Movie(play="season1/episode5/images/scene20/titjob3.webm")
image e5s20-titjob4 = Movie(play="season1/episode5/images/scene20/titjob4.webm")
image e5s20-titjob5 = Movie(play="season1/episode5/images/scene20/titjob5.webm")
image e5s20-titjob6 = Movie(play="season1/episode5/images/scene20/titjob6.webm")

# Censored
# Images
image e5s20-07_cen = im.Scale("season1/episode5/images/scene20/censored/7.webp", 1920, 1080)
image e5s20-09_cen = im.Scale("season1/episode5/images/scene20/censored/9.webp", 1920, 1080)
image e5s20-10_cen = im.Scale("season1/episode5/images/scene20/censored/10.webp", 1920, 1080)
image e5s20-11_cen = im.Scale("season1/episode5/images/scene20/censored/11.webp", 1920, 1080)
image e5s20-12_cen = im.Scale("season1/episode5/images/scene20/censored/12.webp", 1920, 1080)
image e5s20-13_cen = im.Scale("season1/episode5/images/scene20/censored/13.webp", 1920, 1080)
image e5s20-14_cen = im.Scale("season1/episode5/images/scene20/censored/14.webp", 1920, 1080)
image e5s20-15_cen = im.Scale("season1/episode5/images/scene20/censored/15.webp", 1920, 1080)
image e5s20-16_cen = im.Scale("season1/episode5/images/scene20/censored/16.webp", 1920, 1080)
image e5s20-17_cen = im.Scale("season1/episode5/images/scene20/censored/17.webp", 1920, 1080)
image e5s20-18_cen = im.Scale("season1/episode5/images/scene20/censored/18.webp", 1920, 1080)
image e5s20-19_cen = im.Scale("season1/episode5/images/scene20/censored/19.webp", 1920, 1080)
image e5s20-20_cen = im.Scale("season1/episode5/images/scene20/censored/20.webp", 1920, 1080)
image e5s20-21_cen = im.Scale("season1/episode5/images/scene20/censored/21.webp", 1920, 1080)
image e5s20-22_cen = im.Scale("season1/episode5/images/scene20/censored/22.webp", 1920, 1080)
image e5s20-23_cen = im.Scale("season1/episode5/images/scene20/censored/23.webp", 1920, 1080)
image e5s20-24_cen = im.Scale("season1/episode5/images/scene20/censored/24.webp", 1920, 1080)
image e5s20-25_cen = im.Scale("season1/episode5/images/scene20/censored/25.webp", 1920, 1080)
image e5s20-26_cen = im.Scale("season1/episode5/images/scene20/censored/26.webp", 1920, 1080)
image e5s20-27_cen = im.Scale("season1/episode5/images/scene20/censored/27.webp", 1920, 1080)
image e5s20-28_cen = im.Scale("season1/episode5/images/scene20/censored/28.webp", 1920, 1080)
image e5s20-29_cen = im.Scale("season1/episode5/images/scene20/censored/29.webp", 1920, 1080)
image e5s20-30_cen = im.Scale("season1/episode5/images/scene20/censored/30.webp", 1920, 1080)
image e5s20-31_cen = im.Scale("season1/episode5/images/scene20/censored/31.webp", 1920, 1080)
image e5s20-32_cen = im.Scale("season1/episode5/images/scene20/censored/32.webp", 1920, 1080)
image e5s20-33_cen = im.Scale("season1/episode5/images/scene20/censored/33.webp", 1920, 1080)
image e5s20-34_cen = im.Scale("season1/episode5/images/scene20/censored/34.webp", 1920, 1080)
image e5s20-35_cen = im.Scale("season1/episode5/images/scene20/censored/35.webp", 1920, 1080)
image e5s20-36_cen = im.Scale("season1/episode5/images/scene20/censored/36.webp", 1920, 1080)
image e5s20-39_cen = im.Scale("season1/episode5/images/scene20/censored/39.webp", 1920, 1080)

# Videos
image e5s20-blowjob1_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob1.webm")
image e5s20-blowjob2_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob2.webm")
image e5s20-blowjob3_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob3.webm")
image e5s20-blowjob4_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob4.webm")
image e5s20-blowjob5_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob5.webm")
image e5s20-blowjob6_cen = Movie(play="season1/episode5/images/scene20/censored/blowjob6.webm")
image e5s20-titjob1_cen = Movie(play="season1/episode5/images/scene20/censored/titjob1.webm")
image e5s20-titjob2_cen = Movie(play="season1/episode5/images/scene20/censored/titjob2.webm")
image e5s20-titjob3_cen = Movie(play="season1/episode5/images/scene20/censored/titjob3.webm")
image e5s20-titjob4_cen = Movie(play="season1/episode5/images/scene20/censored/titjob4.webm")
image e5s20-titjob5_cen = Movie(play="season1/episode5/images/scene20/censored/titjob5.webm")
image e5s20-titjob6_cen = Movie(play="season1/episode5/images/scene20/censored/titjob6.webm")
