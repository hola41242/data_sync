
# Scene 9 images ###############################################################

image e5s9-01 = im.Scale("season1/episode5/images/scene9/1.webp", 1920, 1080)
image e5s9-02 = im.Scale("season1/episode5/images/scene9/2.webp", 1920, 1080)
image e5s9-03 = im.Scale("season1/episode5/images/scene9/3.webp", 1920, 1080)
image e5s9-04 = im.Scale("season1/episode5/images/scene9/4.webp", 1920, 1080)
image e5s9-05 = im.Scale("season1/episode5/images/scene9/5.webp", 1920, 1080)
image e5s9-06 = im.Scale("season1/episode5/images/scene9/6.webp", 1920, 1080)
image e5s9-07 = im.Scale("season1/episode5/images/scene9/7.webp", 1920, 1080)
image e5s9-08 = im.Scale("season1/episode5/images/scene9/8.webp", 1920, 1080)
image e5s9-09 = im.Scale("season1/episode5/images/scene9/9.webp", 1920, 1080)
image e5s9-10 = im.Scale("season1/episode5/images/scene9/10.webp", 1920, 1080)
image e5s9-11 = im.Scale("season1/episode5/images/scene9/11.webp", 1920, 1080)
image e5s9-12 = im.Scale("season1/episode5/images/scene9/12.webp", 1920, 1080)
image e5s9-13 = im.Scale("season1/episode5/images/scene9/13.webp", 1920, 1080)
image e5s9-14 = im.Scale("season1/episode5/images/scene9/14.webp", 1920, 1080)
image e5s9-15 = im.Scale("season1/episode5/images/scene9/15.webp", 1920, 1080)
image e5s9-16 = im.Scale("season1/episode5/images/scene9/16.webp", 1920, 1080)
image e5s9-17 = im.Scale("season1/episode5/images/scene9/17.webp", 1920, 1080)
image e5s9-18 = im.Scale("season1/episode5/images/scene9/18.webp", 1920, 1080)
image e5s9-19 = im.Scale("season1/episode5/images/scene9/19.webp", 1920, 1080)
image e5s9-20 = im.Scale("season1/episode5/images/scene9/20.webp", 1920, 1080)
image e5s9-21 = im.Scale("season1/episode5/images/scene9/21.webp", 1920, 1080)
image e5s9-22 = im.Scale("season1/episode5/images/scene9/22.webp", 1920, 1080)
image e5s9-23 = im.Scale("season1/episode5/images/scene9/23.webp", 1920, 1080)
image e5s9-24 = im.Scale("season1/episode5/images/scene9/24.webp", 1920, 1080)
image e5s9-25 = im.Scale("season1/episode5/images/scene9/25.webp", 1920, 1080)
image e5s9-26 = im.Scale("season1/episode5/images/scene9/26.webp", 1920, 1080)
image e5s9-27 = im.Scale("season1/episode5/images/scene9/27.webp", 1920, 1080)
image e5s9-28 = im.Scale("season1/episode5/images/scene9/28.webp", 1920, 1080)
image e5s9-29 = im.Scale("season1/episode5/images/scene9/29.webp", 1920, 1080)
image e5s9-30 = im.Scale("season1/episode5/images/scene9/30.webp", 1920, 1080)
image e5s9-31 = im.Scale("season1/episode5/images/scene9/31.webp", 1920, 1080)
image e5s9-32 = im.Scale("season1/episode5/images/scene9/32.webp", 1920, 1080)
image e5s9-33 = im.Scale("season1/episode5/images/scene9/33.webp", 1920, 1080)
image e5s9-34 = im.Scale("season1/episode5/images/scene9/34.webp", 1920, 1080)
image e5s9-35 = im.Scale("season1/episode5/images/scene9/35.webp", 1920, 1080)
image e5s9-36 = im.Scale("season1/episode5/images/scene9/36.webp", 1920, 1080)
image e5s9-37 = im.Scale("season1/episode5/images/scene9/37.webp", 1920, 1080)
image e5s9-38 = im.Scale("season1/episode5/images/scene9/38.webp", 1920, 1080)

# Animations #
# Static
image e5s9_francesca_blink1:
    im.Scale("season1/episode5/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s9_francesca_blink2:
    im.Scale("season1/episode5/images/scene9/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s9_francesca_blink3:
    im.Scale("season1/episode5/images/scene9/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene9/francesca_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
