
# Scene 14 images ##############################################################

image e5s14-01 = im.Scale("season1/episode5/images/scene14/1.webp", 1920, 1080)
image e5s14-02 = im.Scale("season1/episode5/images/scene14/2.webp", 1920, 1080)
image e5s14-03 = im.Scale("season1/episode5/images/scene14/3.webp", 1920, 1080)
image e5s14-04 = im.Scale("season1/episode5/images/scene14/4.webp", 1920, 1080)
image e5s14-05 = im.Scale("season1/episode5/images/scene14/5.webp", 1920, 1080)
image e5s14-06 = im.Scale("season1/episode5/images/scene14/6.webp", 1920, 1080)
image e5s14-07 = im.Scale("season1/episode5/images/scene14/7.webp", 1920, 1080)
image e5s14-08 = im.Scale("season1/episode5/images/scene14/8.webp", 1920, 1080)
image e5s14-09 = im.Scale("season1/episode5/images/scene14/9.webp", 1920, 1080)
image e5s14-10 = im.Scale("season1/episode5/images/scene14/10.webp", 1920, 1080)
image e5s14-11 = im.Scale("season1/episode5/images/scene14/11.webp", 1920, 1080)
image e5s14-12 = im.Scale("season1/episode5/images/scene14/12.webp", 1920, 1080)
image e5s14-13 = im.Scale("season1/episode5/images/scene14/13.webp", 1920, 1080)
image e5s14-14 = im.Scale("season1/episode5/images/scene14/14.webp", 1920, 1080)
image e5s14-15 = im.Scale("season1/episode5/images/scene14/15.webp", 1920, 1080)
image e5s14-16 = im.Scale("season1/episode5/images/scene14/16.webp", 1920, 1080)
image e5s14-17 = im.Scale("season1/episode5/images/scene14/17.webp", 1920, 1080)
image e5s14-18 = im.Scale("season1/episode5/images/scene14/18.webp", 1920, 1080)
image e5s14-19 = im.Scale("season1/episode5/images/scene14/19.webp", 1920, 1080)
image e5s14-20 = im.Scale("season1/episode5/images/scene14/20.webp", 1920, 1080)
image e5s14-21 = im.Scale("season1/episode5/images/scene14/21.webp", 1920, 1080)
image e5s14-22 = im.Scale("season1/episode5/images/scene14/22.webp", 1920, 1080)
image e5s14-23 = im.Scale("season1/episode5/images/scene14/23.webp", 1920, 1080)
image e5s14-24 = im.Scale("season1/episode5/images/scene14/24.webp", 1920, 1080)
image e5s14-25 = im.Scale("season1/episode5/images/scene14/25.webp", 1920, 1080)
image e5s14-26 = im.Scale("season1/episode5/images/scene14/26.webp", 1920, 1080)
image e5s14-27 = im.Scale("season1/episode5/images/scene14/27.webp", 1920, 1080)
image e5s14-28 = im.Scale("season1/episode5/images/scene14/28.webp", 1920, 1080)
image e5s14-29 = im.Scale("season1/episode5/images/scene14/29.webp", 1920, 1080)
image e5s14-30 = im.Scale("season1/episode5/images/scene14/30.webp", 1920, 1080)
image e5s14-31 = im.Scale("season1/episode5/images/scene14/31.webp", 1920, 1080)
image e5s14-32 = im.Scale("season1/episode5/images/scene14/32.webp", 1920, 1080)
image e5s14-33 = im.Scale("season1/episode5/images/scene14/33.webp", 1920, 1080)
image e5s14-34 = im.Scale("season1/episode5/images/scene14/34.webp", 1920, 1080)
image e5s14-35 = im.Scale("season1/episode5/images/scene14/35.webp", 1920, 1080)
image e5s14-36 = im.Scale("season1/episode5/images/scene14/36.webp", 1920, 1080)
image e5s14-37 = im.Scale("season1/episode5/images/scene14/37.webp", 1920, 1080)
image e5s14-38 = im.Scale("season1/episode5/images/scene14/38.webp", 1920, 1080)
image e5s14-39 = im.Scale("season1/episode5/images/scene14/39.webp", 1920, 1080)
image e5s14-40 = im.Scale("season1/episode5/images/scene14/40.webp", 1920, 1080)
image e5s14-41 = im.Scale("season1/episode5/images/scene14/41.webp", 1920, 1080)
image e5s14-42 = im.Scale("season1/episode5/images/scene14/42.webp", 1920, 1080)
image e5s14-43 = im.Scale("season1/episode5/images/scene14/43.webp", 1920, 1080)
image e5s14-44 = im.Scale("season1/episode5/images/scene14/44.webp", 1920, 1080)
image e5s14-45 = im.Scale("season1/episode5/images/scene14/45.webp", 1920, 1080)
image e5s14-46 = im.Scale("season1/episode5/images/scene14/46.webp", 1920, 1080)
image e5s14-47 = im.Scale("season1/episode5/images/scene14/47.webp", 1920, 1080)
image e5s14-48 = im.Scale("season1/episode5/images/scene14/48.webp", 1920, 1080)

# Animations #
# Static
image e5s14_claire_blink1:
    im.Scale("season1/episode5/images/scene14/claire_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene14/claire_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
