
# Scene 6 images ###############################################################

image e5s6-01 = im.Scale("season1/episode5/images/scene6/1.webp", 1920, 1080)
image e5s6-02 = im.Scale("season1/episode5/images/scene6/2.webp", 1920, 1080)
image e5s6-03 = im.Scale("season1/episode5/images/scene6/3.webp", 1920, 1080)
image e5s6-04 = im.Scale("season1/episode5/images/scene6/4.webp", 1920, 1080)
image e5s6-05 = im.Scale("season1/episode5/images/scene6/5.webp", 1920, 1080)
image e5s6-06 = im.Scale("season1/episode5/images/scene6/6.webp", 1920, 1080)
image e5s6-07 = im.Scale("season1/episode5/images/scene6/7.webp", 1920, 1080)
image e5s6-08 = im.Scale("season1/episode5/images/scene6/8.webp", 1920, 1080)
image e5s6-09 = im.Scale("season1/episode5/images/scene6/9.webp", 1920, 1080)
image e5s6-10 = im.Scale("season1/episode5/images/scene6/10.webp", 1920, 1080)
image e5s6-11 = im.Scale("season1/episode5/images/scene6/11.webp", 1920, 1080)
image e5s6-12 = im.Scale("season1/episode5/images/scene6/12.webp", 1920, 1080)
image e5s6-13 = im.Scale("season1/episode5/images/scene6/13.webp", 1920, 1080)
image e5s6-14 = im.Scale("season1/episode5/images/scene6/14.webp", 1920, 1080)
image e5s6-15 = im.Scale("season1/episode5/images/scene6/15.webp", 1920, 1080)
image e5s6-16 = im.Scale("season1/episode5/images/scene6/16.webp", 1920, 1080)
image e5s6-17 = im.Scale("season1/episode5/images/scene6/17.webp", 1920, 1080)
image e5s6-18 = im.Scale("season1/episode5/images/scene6/18.webp", 1920, 1080)
image e5s6-19 = im.Scale("season1/episode5/images/scene6/19.webp", 1920, 1080)
image e5s6-20 = im.Scale("season1/episode5/images/scene6/20.webp", 1920, 1080)
image e5s6-21 = im.Scale("season1/episode5/images/scene6/21.webp", 1920, 1080)
image e5s6-22 = im.Scale("season1/episode5/images/scene6/22.webp", 1920, 1080)
image e5s6-23 = im.Scale("season1/episode5/images/scene6/23.webp", 1920, 1080)
image e5s6-24 = im.Scale("season1/episode5/images/scene6/24.webp", 1920, 1080)
image e5s6-25 = im.Scale("season1/episode5/images/scene6/25.webp", 1920, 1080)
image e5s6-26 = im.Scale("season1/episode5/images/scene6/26.webp", 1920, 1080)
image e5s6-27 = im.Scale("season1/episode5/images/scene6/27.webp", 1920, 1080)
image e5s6-28 = im.Scale("season1/episode5/images/scene6/28.webp", 1920, 1080)
image e5s6-29 = im.Scale("season1/episode5/images/scene6/29.webp", 1920, 1080)

# Animations #
# Static
image e5s6_jon_blink1:
    im.Scale("season1/episode5/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
