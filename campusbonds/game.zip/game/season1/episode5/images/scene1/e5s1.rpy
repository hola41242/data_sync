
# Scene 1 images ###############################################################

image e5s1-01 = im.Scale("season1/episode5/images/scene1/1.webp", 1920, 1080)
image e5s1-02 = im.Scale("season1/episode5/images/scene1/2.webp", 1920, 1080)
image e5s1-03 = im.Scale("season1/episode5/images/scene1/3.webp", 1920, 1080)
image e5s1-04 = im.Scale("season1/episode5/images/scene1/4.webp", 1920, 1080)
image e5s1-05 = im.Scale("season1/episode5/images/scene1/5.webp", 1920, 1080)
image e5s1-06 = im.Scale("season1/episode5/images/scene1/6.webp", 1920, 1080)
image e5s1-07 = im.Scale("season1/episode5/images/scene1/7.webp", 1920, 1080)
image e5s1-08 = im.Scale("season1/episode5/images/scene1/8.webp", 1920, 1080)
image e5s1-09 = im.Scale("season1/episode5/images/scene1/9.webp", 1920, 1080)
