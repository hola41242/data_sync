
# Scene 4 images ###############################################################

image e5s4-01 = im.Scale("season1/episode5/images/scene4/1.webp", 1920, 1080)
image e5s4-02 = im.Scale("season1/episode5/images/scene4/2.webp", 1920, 1080)
image e5s4-03 = im.Scale("season1/episode5/images/scene4/3.webp", 1920, 1080)
image e5s4-04 = im.Scale("season1/episode5/images/scene4/4.webp", 1920, 1080)
image e5s4-05 = im.Scale("season1/episode5/images/scene4/5.webp", 1920, 1080)
image e5s4-06 = im.Scale("season1/episode5/images/scene4/6.webp", 1920, 1080)
image e5s4-07 = im.Scale("season1/episode5/images/scene4/7.webp", 1920, 1080)
image e5s4-08 = im.Scale("season1/episode5/images/scene4/8.webp", 1920, 1080)
image e5s4-09 = im.Scale("season1/episode5/images/scene4/9.webp", 1920, 1080)
image e5s4-10 = im.Scale("season1/episode5/images/scene4/10.webp", 1920, 1080)
image e5s4-11 = im.Scale("season1/episode5/images/scene4/11.webp", 1920, 1080)
image e5s4-12 = im.Scale("season1/episode5/images/scene4/12.webp", 1920, 1080)
image e5s4-13 = im.Scale("season1/episode5/images/scene4/13.webp", 1920, 1080)
image e5s4-14 = im.Scale("season1/episode5/images/scene4/14.webp", 1920, 1080)
image e5s4-15 = im.Scale("season1/episode5/images/scene4/15.webp", 1920, 1080)
image e5s4-16 = im.Scale("season1/episode5/images/scene4/16.webp", 1920, 1080)
image e5s4-17 = im.Scale("season1/episode5/images/scene4/17.webp", 1920, 1080)
image e5s4-18 = im.Scale("season1/episode5/images/scene4/18.webp", 1920, 1080)
image e5s4-19 = im.Scale("season1/episode5/images/scene4/19.webp", 1920, 1080)
image e5s4-20 = im.Scale("season1/episode5/images/scene4/20.webp", 1920, 1080)
image e5s4-21 = im.Scale("season1/episode5/images/scene4/21.webp", 1920, 1080)
image e5s4-22 = im.Scale("season1/episode5/images/scene4/22.webp", 1920, 1080)

# Animations #
# Static
image e5s4_alice_blink1:
    im.Scale("season1/episode5/images/scene4/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene4/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
