
# Scene 24 images ##############################################################

image e5s24-01 = im.Scale("season1/episode5/images/scene24/1.webp", 1920, 1080)
image e5s24-02 = im.Scale("season1/episode5/images/scene24/2.webp", 1920, 1080)
image e5s24-03 = im.Scale("season1/episode5/images/scene24/3.webp", 1920, 1080)
image e5s24-04 = im.Scale("season1/episode5/images/scene24/4.webp", 1920, 1080)
image e5s24-05 = im.Scale("season1/episode5/images/scene24/5.webp", 1920, 1080)
image e5s24-06 = im.Scale("season1/episode5/images/scene24/6.webp", 1920, 1080)
image e5s24-07 = im.Scale("season1/episode5/images/scene24/7.webp", 1920, 1080)
image e5s24-08 = im.Scale("season1/episode5/images/scene24/8.webp", 1920, 1080)
image e5s24-09 = im.Scale("season1/episode5/images/scene24/9.webp", 1920, 1080)
image e5s24-10 = im.Scale("season1/episode5/images/scene24/10.webp", 1920, 1080)
image e5s24-11 = im.Scale("season1/episode5/images/scene24/11.webp", 1920, 1080)
image e5s24-12 = im.Scale("season1/episode5/images/scene24/12.webp", 1920, 1080)
image e5s24-13 = im.Scale("season1/episode5/images/scene24/13.webp", 1920, 1080)
image e5s24-14 = im.Scale("season1/episode5/images/scene24/14.webp", 1920, 1080)
image e5s24-15 = im.Scale("season1/episode5/images/scene24/15.webp", 1920, 1080)
image e5s24-16 = im.Scale("season1/episode5/images/scene24/16.webp", 1920, 1080)
image e5s24-17 = im.Scale("season1/episode5/images/scene24/17.webp", 1920, 1080)
image e5s24-18 = im.Scale("season1/episode5/images/scene24/18.webp", 1920, 1080)
image e5s24-19 = im.Scale("season1/episode5/images/scene24/19.webp", 1920, 1080)
image e5s24-20 = im.Scale("season1/episode5/images/scene24/20.webp", 1920, 1080)
image e5s24-21 = im.Scale("season1/episode5/images/scene24/21.webp", 1920, 1080)
image e5s24-22 = im.Scale("season1/episode5/images/scene24/22.webp", 1920, 1080)
image e5s24-23 = im.Scale("season1/episode5/images/scene24/23.webp", 1920, 1080)
image e5s24-24 = im.Scale("season1/episode5/images/scene24/24.webp", 1920, 1080)
image e5s24-25 = im.Scale("season1/episode5/images/scene24/25.webp", 1920, 1080)
image e5s24-26 = im.Scale("season1/episode5/images/scene24/26.webp", 1920, 1080)
image e5s24-27 = im.Scale("season1/episode5/images/scene24/27.webp", 1920, 1080)
image e5s24-28 = im.Scale("season1/episode5/images/scene24/28.webp", 1920, 1080)
image e5s24-29 = im.Scale("season1/episode5/images/scene24/29.webp", 1920, 1080)
image e5s24-30 = im.Scale("season1/episode5/images/scene24/30.webp", 1920, 1080)
image e5s24-31 = im.Scale("season1/episode5/images/scene24/31.webp", 1920, 1080)
image e5s24-32 = im.Scale("season1/episode5/images/scene24/32.webp", 1920, 1080)
image e5s24-33 = im.Scale("season1/episode5/images/scene24/33.webp", 1920, 1080)

image e5s24_bridget_blink1:
    im.Scale("season1/episode5/images/scene24/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene24/bridget_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
