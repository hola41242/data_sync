
# Scene 26 images ##############################################################

# Images
image e5s26-01 = im.Scale("season1/episode5/images/scene26/1.webp", 1920, 1080)
image e5s26-02 = im.Scale("season1/episode5/images/scene26/2.webp", 1920, 1080)
image e5s26-03 = im.Scale("season1/episode5/images/scene26/3.webp", 1920, 1080)
image e5s26-04 = im.Scale("season1/episode5/images/scene26/4.webp", 1920, 1080)
image e5s26-05 = im.Scale("season1/episode5/images/scene26/5.webp", 1920, 1080)
image e5s26-06 = im.Scale("season1/episode5/images/scene26/6.webp", 1920, 1080)
image e5s26-07 = im.Scale("season1/episode5/images/scene26/7.webp", 1920, 1080)
image e5s26-08 = im.Scale("season1/episode5/images/scene26/8.webp", 1920, 1080)
image e5s26-09 = im.Scale("season1/episode5/images/scene26/9.webp", 1920, 1080)
image e5s26-10 = im.Scale("season1/episode5/images/scene26/10.webp", 1920, 1080)
image e5s26-11 = im.Scale("season1/episode5/images/scene26/11.webp", 1920, 1080)
image e5s26-12 = im.Scale("season1/episode5/images/scene26/12.webp", 1920, 1080)
image e5s26-13 = im.Scale("season1/episode5/images/scene26/13.webp", 1920, 1080)
image e5s26-14 = im.Scale("season1/episode5/images/scene26/14.webp", 1920, 1080)
image e5s26-15 = im.Scale("season1/episode5/images/scene26/15.webp", 1920, 1080)
image e5s26-16 = im.Scale("season1/episode5/images/scene26/16.webp", 1920, 1080)
image e5s26-17 = im.Scale("season1/episode5/images/scene26/17.webp", 1920, 1080)
image e5s26-18 = im.Scale("season1/episode5/images/scene26/18.webp", 1920, 1080)
image e5s26-19 = im.Scale("season1/episode5/images/scene26/19.webp", 1920, 1080)
image e5s26-20 = im.Scale("season1/episode5/images/scene26/20.webp", 1920, 1080)
image e5s26-21 = im.Scale("season1/episode5/images/scene26/21.webp", 1920, 1080)
image e5s26-22 = im.Scale("season1/episode5/images/scene26/22.webp", 1920, 1080)
image e5s26-23 = im.Scale("season1/episode5/images/scene26/23.webp", 1920, 1080)
image e5s26-24 = im.Scale("season1/episode5/images/scene26/24.webp", 1920, 1080)
image e5s26-25 = im.Scale("season1/episode5/images/scene26/25.webp", 1920, 1080)
image e5s26-26 = im.Scale("season1/episode5/images/scene26/26.webp", 1920, 1080)
image e5s26-27 = im.Scale("season1/episode5/images/scene26/27.webp", 1920, 1080)
image e5s26-28 = im.Scale("season1/episode5/images/scene26/28.webp", 1920, 1080)
image e5s26-29 = im.Scale("season1/episode5/images/scene26/29.webp", 1920, 1080)
image e5s26-30 = im.Scale("season1/episode5/images/scene26/30.webp", 1920, 1080)
image e5s26-31 = im.Scale("season1/episode5/images/scene26/31.webp", 1920, 1080)
image e5s26-32 = im.Scale("season1/episode5/images/scene26/32.webp", 1920, 1080)
image e5s26-33 = im.Scale("season1/episode5/images/scene26/33.webp", 1920, 1080)
image e5s26-34 = im.Scale("season1/episode5/images/scene26/34.webp", 1920, 1080)
image e5s26-35 = im.Scale("season1/episode5/images/scene26/35.webp", 1920, 1080)
image e5s26-36 = im.Scale("season1/episode5/images/scene26/36.webp", 1920, 1080)
image e5s26-37 = im.Scale("season1/episode5/images/scene26/37.webp", 1920, 1080)
image e5s26-38 = im.Scale("season1/episode5/images/scene26/38.webp", 1920, 1080)
image e5s26-39 = im.Scale("season1/episode5/images/scene26/39.webp", 1920, 1080)
image e5s26-40 = im.Scale("season1/episode5/images/scene26/40.webp", 1920, 1080)
image e5s26-41 = im.Scale("season1/episode5/images/scene26/41.webp", 1920, 1080)
image e5s26-42 = im.Scale("season1/episode5/images/scene26/42.webp", 1920, 1080)
image e5s26-43 = im.Scale("season1/episode5/images/scene26/43.webp", 1920, 1080)
image e5s26-44 = im.Scale("season1/episode5/images/scene26/44.webp", 1920, 1080)
image e5s26-45 = im.Scale("season1/episode5/images/scene26/45.webp", 1920, 1080)
image e5s26-46 = im.Scale("season1/episode5/images/scene26/46.webp", 1920, 1080)
image e5s26-47 = im.Scale("season1/episode5/images/scene26/47.webp", 1920, 1080)
image e5s26-48 = im.Scale("season1/episode5/images/scene26/48.webp", 1920, 1080)
image e5s26-49 = im.Scale("season1/episode5/images/scene26/49.webp", 1920, 1080)
image e5s26-50 = im.Scale("season1/episode5/images/scene26/50.webp", 1920, 1080)
image e5s26-51 = im.Scale("season1/episode5/images/scene26/51.webp", 1920, 1080)
image e5s26-52 = im.Scale("season1/episode5/images/scene26/52.webp", 1920, 1080)
image e5s26-53 = im.Scale("season1/episode5/images/scene26/53.webp", 1920, 1080)
image e5s26-54 = im.Scale("season1/episode5/images/scene26/54.webp", 1920, 1080)
image e5s26-55 = im.Scale("season1/episode5/images/scene26/55.webp", 1920, 1080)
image e5s26-56 = im.Scale("season1/episode5/images/scene26/56.webp", 1920, 1080)
image e5s26-57 = im.Scale("season1/episode5/images/scene26/57.webp", 1920, 1080)
image e5s26-58 = im.Scale("season1/episode5/images/scene26/58.webp", 1920, 1080)
image e5s26-59 = im.Scale("season1/episode5/images/scene26/59.webp", 1920, 1080)
image e5s26-60 = im.Scale("season1/episode5/images/scene26/60.webp", 1920, 1080)
image e5s26-61 = im.Scale("season1/episode5/images/scene26/61.webp", 1920, 1080)
image e5s26-62 = im.Scale("season1/episode5/images/scene26/62.webp", 1920, 1080)
image e5s26-63 = im.Scale("season1/episode5/images/scene26/63.webp", 1920, 1080)
image e5s26-64 = im.Scale("season1/episode5/images/scene26/64.webp", 1920, 1080)
image e5s26-65 = im.Scale("season1/episode5/images/scene26/65.webp", 1920, 1080)
image e5s26-66 = im.Scale("season1/episode5/images/scene26/66.webp", 1920, 1080)
image e5s26-67 = im.Scale("season1/episode5/images/scene26/67.webp", 1920, 1080)
image e5s26-68 = im.Scale("season1/episode5/images/scene26/68.webp", 1920, 1080)
image e5s26-69 = im.Scale("season1/episode5/images/scene26/69.webp", 1920, 1080)
image e5s26-70 = im.Scale("season1/episode5/images/scene26/70.webp", 1920, 1080)
image e5s26-71 = im.Scale("season1/episode5/images/scene26/71.webp", 1920, 1080)
image e5s26-72 = im.Scale("season1/episode5/images/scene26/72.webp", 1920, 1080)
image e5s26-73 = im.Scale("season1/episode5/images/scene26/73.webp", 1920, 1080)
image e5s26-74 = im.Scale("season1/episode5/images/scene26/74.webp", 1920, 1080)
image e5s26-75 = im.Scale("season1/episode5/images/scene26/75.webp", 1920, 1080)
image e5s26-76 = im.Scale("season1/episode5/images/scene26/76.webp", 1920, 1080)
image e5s26-77 = im.Scale("season1/episode5/images/scene26/77.webp", 1920, 1080)
image e5s26-78 = im.Scale("season1/episode5/images/scene26/78.webp", 1920, 1080)
image e5s26-79 = im.Scale("season1/episode5/images/scene26/79.webp", 1920, 1080)
image e5s26-80 = im.Scale("season1/episode5/images/scene26/80.webp", 1920, 1080)
image e5s26-81 = im.Scale("season1/episode5/images/scene26/81.webp", 1920, 1080)
image e5s26-82 = im.Scale("season1/episode5/images/scene26/82.webp", 1920, 1080)
image e5s26-83 = im.Scale("season1/episode5/images/scene26/83.webp", 1920, 1080)
image e5s26-84 = im.Scale("season1/episode5/images/scene26/84.webp", 1920, 1080)
image e5s26-85 = im.Scale("season1/episode5/images/scene26/85.webp", 1920, 1080)
image e5s26-86 = im.Scale("season1/episode5/images/scene26/86.webp", 1920, 1080)
image e5s26-87 = im.Scale("season1/episode5/images/scene26/87.webp", 1920, 1080)
image e5s26-88 = im.Scale("season1/episode5/images/scene26/88.webp", 1920, 1080)
image e5s26-89 = im.Scale("season1/episode5/images/scene26/89.webp", 1920, 1080)
image e5s26-90 = im.Scale("season1/episode5/images/scene26/90.webp", 1920, 1080)
image e5s26-91 = im.Scale("season1/episode5/images/scene26/91.webp", 1920, 1080)
image e5s26-92 = im.Scale("season1/episode5/images/scene26/92.webp", 1920, 1080)
image e5s26-93 = im.Scale("season1/episode5/images/scene26/93.webp", 1920, 1080)
image e5s26-94 = im.Scale("season1/episode5/images/scene26/94.webp", 1920, 1080)
image e5s26-95 = im.Scale("season1/episode5/images/scene26/95.webp", 1920, 1080)
image e5s26-96 = im.Scale("season1/episode5/images/scene26/96.webp", 1920, 1080)
image e5s26-97 = im.Scale("season1/episode5/images/scene26/97.webp", 1920, 1080)
image e5s26-98 = im.Scale("season1/episode5/images/scene26/98.webp", 1920, 1080)
image e5s26-99 = im.Scale("season1/episode5/images/scene26/99.webp", 1920, 1080)
image e5s26-100 = im.Scale("season1/episode5/images/scene26/100.webp", 1920, 1080)
image e5s26-101 = im.Scale("season1/episode5/images/scene26/101.webp", 1920, 1080)
image e5s26-102 = im.Scale("season1/episode5/images/scene26/102.webp", 1920, 1080)
image e5s26-103 = im.Scale("season1/episode5/images/scene26/103.webp", 1920, 1080)
image e5s26-104 = im.Scale("season1/episode5/images/scene26/104.webp", 1920, 1080)
image e5s26-105 = im.Scale("season1/episode5/images/scene26/105.webp", 1920, 1080)
image e5s26-106 = im.Scale("season1/episode5/images/scene26/106.webp", 1920, 1080)
image e5s26-107 = im.Scale("season1/episode5/images/scene26/107.webp", 1920, 1080)
image e5s26-108 = im.Scale("season1/episode5/images/scene26/108.webp", 1920, 1080)
image e5s26-109 = im.Scale("season1/episode5/images/scene26/109.webp", 1920, 1080)
image e5s26-110 = im.Scale("season1/episode5/images/scene26/110.webp", 1920, 1080)
image e5s26-111 = im.Scale("season1/episode5/images/scene26/111.webp", 1920, 1080)
image e5s26-112 = im.Scale("season1/episode5/images/scene26/112.webp", 1920, 1080)
image e5s26-113 = im.Scale("season1/episode5/images/scene26/113.webp", 1920, 1080)
image e5s26-114 = im.Scale("season1/episode5/images/scene26/114.webp", 1920, 1080)
image e5s26-115 = im.Scale("season1/episode5/images/scene26/115.webp", 1920, 1080)
image e5s26-116 = im.Scale("season1/episode5/images/scene26/116.webp", 1920, 1080)
image e5s26-117 = im.Scale("season1/episode5/images/scene26/117.webp", 1920, 1080)
image e5s26-118 = im.Scale("season1/episode5/images/scene26/118.webp", 1920, 1080)
image e5s26-119 = im.Scale("season1/episode5/images/scene26/119.webp", 1920, 1080)
image e5s26-120 = im.Scale("season1/episode5/images/scene26/120.webp", 1920, 1080)
image e5s26-121 = im.Scale("season1/episode5/images/scene26/121.webp", 1920, 1080)
image e5s26-122 = im.Scale("season1/episode5/images/scene26/122.webp", 1920, 1080)
image e5s26-123 = im.Scale("season1/episode5/images/scene26/123.webp", 1920, 1080)
image e5s26-124 = im.Scale("season1/episode5/images/scene26/124.webp", 1920, 1080)
image e5s26-125 = im.Scale("season1/episode5/images/scene26/125.webp", 1920, 1080)
image e5s26-126 = im.Scale("season1/episode5/images/scene26/126.webp", 1920, 1080)
image e5s26-127 = im.Scale("season1/episode5/images/scene26/127.webp", 1920, 1080)
image e5s26-128 = im.Scale("season1/episode5/images/scene26/128.webp", 1920, 1080)
image e5s26-129 = im.Scale("season1/episode5/images/scene26/129.webp", 1920, 1080)
image e5s26-130 = im.Scale("season1/episode5/images/scene26/130.webp", 1920, 1080)
image e5s26-131 = im.Scale("season1/episode5/images/scene26/131.webp", 1920, 1080)
image e5s26-132 = im.Scale("season1/episode5/images/scene26/132.webp", 1920, 1080)
image e5s26-133 = im.Scale("season1/episode5/images/scene26/133.webp", 1920, 1080)
image e5s26-134 = im.Scale("season1/episode5/images/scene26/134.webp", 1920, 1080)
image e5s26-135 = im.Scale("season1/episode5/images/scene26/135.webp", 1920, 1080)
image e5s26-136 = im.Scale("season1/episode5/images/scene26/136.webp", 1920, 1080)
image e5s26-137 = im.Scale("season1/episode5/images/scene26/137.webp", 1920, 1080)
image e5s26-138 = im.Scale("season1/episode5/images/scene26/138.webp", 1920, 1080)
image e5s26-139 = im.Scale("season1/episode5/images/scene26/139.webp", 1920, 1080)
image e5s26-140 = im.Scale("season1/episode5/images/scene26/140.webp", 1920, 1080)
image e5s26-141 = im.Scale("season1/episode5/images/scene26/141.webp", 1920, 1080)
image e5s26-142 = im.Scale("season1/episode5/images/scene26/142.webp", 1920, 1080)
image e5s26-143 = im.Scale("season1/episode5/images/scene26/143.webp", 1920, 1080)
image e5s26-144 = im.Scale("season1/episode5/images/scene26/144.webp", 1920, 1080)
image e5s26-145 = im.Scale("season1/episode5/images/scene26/145.webp", 1920, 1080)
image e5s26-146 = im.Scale("season1/episode5/images/scene26/146.webp", 1920, 1080)
image e5s26-147 = im.Scale("season1/episode5/images/scene26/147.webp", 1920, 1080)
image e5s26-148 = im.Scale("season1/episode5/images/scene26/148.webp", 1920, 1080)
image e5s26-149 = im.Scale("season1/episode5/images/scene26/149.webp", 1920, 1080)
image e5s26-150 = im.Scale("season1/episode5/images/scene26/150.webp", 1920, 1080)
image e5s26-151 = im.Scale("season1/episode5/images/scene26/151.webp", 1920, 1080)
image e5s26-152 = im.Scale("season1/episode5/images/scene26/152.webp", 1920, 1080)
image e5s26-153 = im.Scale("season1/episode5/images/scene26/153.webp", 1920, 1080)
image e5s26-154 = im.Scale("season1/episode5/images/scene26/154.webp", 1920, 1080)
image e5s26-155 = im.Scale("season1/episode5/images/scene26/155.webp", 1920, 1080)
image e5s26-156 = im.Scale("season1/episode5/images/scene26/156.webp", 1920, 1080)

# Animations #
# Static
image e5s26_jon_blink1:
    im.Scale("season1/episode5/images/scene26/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s26_nate_blink1:
    im.Scale("season1/episode5/images/scene26/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene26/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
