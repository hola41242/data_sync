
# Scene 5 images ###############################################################

image e5s5-01 = im.Scale("season1/episode5/images/scene5/1.webp", 1920, 1080)
image e5s5-02 = im.Scale("season1/episode5/images/scene5/2.webp", 1920, 1080)
image e5s5-03 = im.Scale("season1/episode5/images/scene5/3.webp", 1920, 1080)
image e5s5-04 = im.Scale("season1/episode5/images/scene5/4.webp", 1920, 1080)
image e5s5-05 = im.Scale("season1/episode5/images/scene5/5.webp", 1920, 1080)
image e5s5-06 = im.Scale("season1/episode5/images/scene5/6.webp", 1920, 1080)
image e5s5-07 = im.Scale("season1/episode5/images/scene5/7.webp", 1920, 1080)
image e5s5-08 = im.Scale("season1/episode5/images/scene5/8.webp", 1920, 1080)
image e5s5-09 = im.Scale("season1/episode5/images/scene5/9.webp", 1920, 1080)
image e5s5-10 = im.Scale("season1/episode5/images/scene5/10.webp", 1920, 1080)
image e5s5-11 = im.Scale("season1/episode5/images/scene5/11.webp", 1920, 1080)
image e5s5-12 = im.Scale("season1/episode5/images/scene5/12.webp", 1920, 1080)
image e5s5-13 = im.Scale("season1/episode5/images/scene5/13.webp", 1920, 1080)
image e5s5-14 = im.Scale("season1/episode5/images/scene5/14.webp", 1920, 1080)
image e5s5-15 = im.Scale("season1/episode5/images/scene5/15.webp", 1920, 1080)
image e5s5-16 = im.Scale("season1/episode5/images/scene5/16.webp", 1920, 1080)
image e5s5-17 = im.Scale("season1/episode5/images/scene5/17.webp", 1920, 1080)
image e5s5-18 = im.Scale("season1/episode5/images/scene5/18.webp", 1920, 1080)
image e5s5-19 = im.Scale("season1/episode5/images/scene5/19.webp", 1920, 1080)
image e5s5-20 = im.Scale("season1/episode5/images/scene5/20.webp", 1920, 1080)
image e5s5-21 = im.Scale("season1/episode5/images/scene5/21.webp", 1920, 1080)
image e5s5-22 = im.Scale("season1/episode5/images/scene5/22.webp", 1920, 1080)
image e5s5-23 = im.Scale("season1/episode5/images/scene5/23.webp", 1920, 1080)
image e5s5-24 = im.Scale("season1/episode5/images/scene5/24.webp", 1920, 1080)
image e5s5-25 = im.Scale("season1/episode5/images/scene5/25.webp", 1920, 1080)
image e5s5-26 = im.Scale("season1/episode5/images/scene5/26.webp", 1920, 1080)
image e5s5-27 = im.Scale("season1/episode5/images/scene5/27.webp", 1920, 1080)
image e5s5-28 = im.Scale("season1/episode5/images/scene5/28.webp", 1920, 1080)
image e5s5-29 = im.Scale("season1/episode5/images/scene5/29.webp", 1920, 1080)
image e5s5-30 = im.Scale("season1/episode5/images/scene5/30.webp", 1920, 1080)
image e5s5-31 = im.Scale("season1/episode5/images/scene5/31.webp", 1920, 1080)
image e5s5-32 = im.Scale("season1/episode5/images/scene5/32.webp", 1920, 1080)
image e5s5-33 = im.Scale("season1/episode5/images/scene5/33.webp", 1920, 1080)
image e5s5-34 = im.Scale("season1/episode5/images/scene5/34.webp", 1920, 1080)
image e5s5-35 = im.Scale("season1/episode5/images/scene5/35.webp", 1920, 1080)
image e5s5-36 = im.Scale("season1/episode5/images/scene5/36.webp", 1920, 1080)
image e5s5-37 = im.Scale("season1/episode5/images/scene5/37.webp", 1920, 1080)
image e5s5-38 = im.Scale("season1/episode5/images/scene5/38.webp", 1920, 1080)
image e5s5-39 = im.Scale("season1/episode5/images/scene5/39.webp", 1920, 1080)
image e5s5-40 = im.Scale("season1/episode5/images/scene5/40.webp", 1920, 1080)
image e5s5-41 = im.Scale("season1/episode5/images/scene5/41.webp", 1920, 1080)
image e5s5-42 = im.Scale("season1/episode5/images/scene5/42.webp", 1920, 1080)
image e5s5-43 = im.Scale("season1/episode5/images/scene5/43.webp", 1920, 1080)
image e5s5-44 = im.Scale("season1/episode5/images/scene5/44.webp", 1920, 1080)
image e5s5-45 = im.Scale("season1/episode5/images/scene5/45.webp", 1920, 1080)
image e5s5-46 = im.Scale("season1/episode5/images/scene5/46.webp", 1920, 1080)
image e5s5-47 = im.Scale("season1/episode5/images/scene5/47.webp", 1920, 1080)
image e5s5-48 = im.Scale("season1/episode5/images/scene5/48.webp", 1920, 1080)
image e5s5-49 = im.Scale("season1/episode5/images/scene5/49.webp", 1920, 1080)
image e5s5-50 = im.Scale("season1/episode5/images/scene5/50.webp", 1920, 1080)
image e5s5-51 = im.Scale("season1/episode5/images/scene5/51.webp", 1920, 1080)
image e5s5-52 = im.Scale("season1/episode5/images/scene5/52.webp", 1920, 1080)
image e5s5-53 = im.Scale("season1/episode5/images/scene5/53.webp", 1920, 1080)
image e5s5-54 = im.Scale("season1/episode5/images/scene5/54.webp", 1920, 1080)
image e5s5-55 = im.Scale("season1/episode5/images/scene5/55.webp", 1920, 1080)
image e5s5-56 = im.Scale("season1/episode5/images/scene5/56.webp", 1920, 1080)
image e5s5-57 = im.Scale("season1/episode5/images/scene5/57.webp", 1920, 1080)
image e5s5-58 = im.Scale("season1/episode5/images/scene5/58.webp", 1920, 1080)
image e5s5-59 = im.Scale("season1/episode5/images/scene5/59.webp", 1920, 1080)
image e5s5-60 = im.Scale("season1/episode5/images/scene5/60.webp", 1920, 1080)
image e5s5-61 = im.Scale("season1/episode5/images/scene5/61.webp", 1920, 1080)
image e5s5-62 = im.Scale("season1/episode5/images/scene5/62.webp", 1920, 1080)

# Animations #
# Static
image e5s5_alice_blink1:
    im.Scale("season1/episode5/images/scene5/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s5_alice_blink2:
    im.Scale("season1/episode5/images/scene5/alice_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene5/alice_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
