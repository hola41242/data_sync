
# Freeroam 3 Images ############################################################
# Living
image e5f3-01 = im.Scale("season1/episode5/images/freeroam3/1.webp", 1920, 1080)
image e5f3-01_1 = im.Scale("season1/episode5/images/freeroam3/1.1.webp", 1920, 1080)
image e5f3-01_2 = im.Scale("season1/episode5/images/freeroam3/1.2.webp", 1920, 1080)
image e5f3-01_3 = im.Scale("season1/episode5/images/freeroam3/1.3.webp", 1920, 1080)
image e5f3-01_4 = im.Scale("season1/episode5/images/freeroam3/1.4.webp", 1920, 1080)
image e5f3-01_5 = im.Scale("season1/episode5/images/freeroam3/1.5.webp", 1920, 1080)

# Bedroom
image e5f3-02 = im.Scale("season1/episode5/images/freeroam3/2.webp", 1920, 1080)

# Bathroom
image e5f3-03 = im.Scale("season1/episode5/images/freeroam3/3.webp", 1920, 1080)
image e5f3-03_1 = im.Scale("season1/episode5/images/freeroam3/3.1.webp", 1920, 1080)

# Kitchen
image e5f3-04 = im.Scale("season1/episode5/images/freeroam3/4.webp", 1920, 1080)
image e5f3-04_1 = im.Scale("season1/episode5/images/freeroam3/4.1.webp", 1920, 1080)
image e5f3-04_2 = im.Scale("season1/episode5/images/freeroam3/4.2.webp", 1920, 1080)
image e5f3-04_3 = im.Scale("season1/episode5/images/freeroam3/4.3.webp", 1920, 1080)



# Jon
image e5f3-jon_01 = im.Scale("season1/episode5/images/freeroam3/images/jon1/1.webp", 1920, 1080)
image e5f3-jon_02 = im.Scale("season1/episode5/images/freeroam3/images/jon1/2.webp", 1920, 1080)
image e5f3-jon_03 = im.Scale("season1/episode5/images/freeroam3/images/jon1/3.webp", 1920, 1080)
image e5f3-jon_04 = im.Scale("season1/episode5/images/freeroam3/images/jon1/4.webp", 1920, 1080)
image e5f3-jon_05 = im.Scale("season1/episode5/images/freeroam3/images/jon1/5.webp", 1920, 1080)

# Roman 1
image e5f3-roman1_01 = im.Scale("season1/episode5/images/freeroam3/images/roman1/1.webp", 1920, 1080)
image e5f3-roman1_02 = im.Scale("season1/episode5/images/freeroam3/images/roman1/2.webp", 1920, 1080)
image e5f3-roman1_03 = im.Scale("season1/episode5/images/freeroam3/images/roman1/3.webp", 1920, 1080)
image e5f3-roman1_04 = im.Scale("season1/episode5/images/freeroam3/images/roman1/4.webp", 1920, 1080)
image e5f3-roman1_05 = im.Scale("season1/episode5/images/freeroam3/images/roman1/5.webp", 1920, 1080)
image e5f3-roman1_06 = im.Scale("season1/episode5/images/freeroam3/images/roman1/6.webp", 1920, 1080)
image e5f3-roman1_07 = im.Scale("season1/episode5/images/freeroam3/images/roman1/7.webp", 1920, 1080)
image e5f3-roman1_08 = im.Scale("season1/episode5/images/freeroam3/images/roman1/8.webp", 1920, 1080)
image e5f3-roman1_09 = im.Scale("season1/episode5/images/freeroam3/images/roman1/9.webp", 1920, 1080)
image e5f3-roman1_10 = im.Scale("season1/episode5/images/freeroam3/images/roman1/10.webp", 1920, 1080)
image e5f3-roman1_11 = im.Scale("season1/episode5/images/freeroam3/images/roman1/11.webp", 1920, 1080)
image e5f3-roman1_12 = im.Scale("season1/episode5/images/freeroam3/images/roman1/12.webp", 1920, 1080)
image e5f3-roman1_13 = im.Scale("season1/episode5/images/freeroam3/images/roman1/13.webp", 1920, 1080)
image e5f3-roman1_14 = im.Scale("season1/episode5/images/freeroam3/images/roman1/14.webp", 1920, 1080)
image e5f3-roman1_15 = im.Scale("season1/episode5/images/freeroam3/images/roman1/15.webp", 1920, 1080)
image e5f3-roman1_16 = im.Scale("season1/episode5/images/freeroam3/images/roman1/16.webp", 1920, 1080)
image e5f3-roman1_17 = im.Scale("season1/episode5/images/freeroam3/images/roman1/17.webp", 1920, 1080)
image e5f3-roman1_18 = im.Scale("season1/episode5/images/freeroam3/images/roman1/18.webp", 1920, 1080)
image e5f3-roman1_19 = im.Scale("season1/episode5/images/freeroam3/images/roman1/19.webp", 1920, 1080)
image e5f3-roman1_20 = im.Scale("season1/episode5/images/freeroam3/images/roman1/20.webp", 1920, 1080)
image e5f3-roman1_21 = im.Scale("season1/episode5/images/freeroam3/images/roman1/21.webp", 1920, 1080)

# Roman 2
image e5f3-roman2_01 = im.Scale("season1/episode5/images/freeroam3/images/roman2/1.webp", 1920, 1080)
image e5f3-roman2_02 = im.Scale("season1/episode5/images/freeroam3/images/roman2/2.webp", 1920, 1080)
image e5f3-roman2_03 = im.Scale("season1/episode5/images/freeroam3/images/roman2/3.webp", 1920, 1080)
image e5f3-roman2_04 = im.Scale("season1/episode5/images/freeroam3/images/roman2/4.webp", 1920, 1080)
image e5f3-roman2_05 = im.Scale("season1/episode5/images/freeroam3/images/roman2/5.webp", 1920, 1080)
image e5f3-roman2_06 = im.Scale("season1/episode5/images/freeroam3/images/roman2/6.webp", 1920, 1080)
image e5f3-roman2_07 = im.Scale("season1/episode5/images/freeroam3/images/roman2/7.webp", 1920, 1080)
image e5f3-roman2_08 = im.Scale("season1/episode5/images/freeroam3/images/roman2/8.webp", 1920, 1080)
image e5f3-roman2_09 = im.Scale("season1/episode5/images/freeroam3/images/roman2/9.webp", 1920, 1080)
image e5f3-roman2_10 = im.Scale("season1/episode5/images/freeroam3/images/roman2/10.webp", 1920, 1080)
image e5f3-roman2_11 = im.Scale("season1/episode5/images/freeroam3/images/roman2/11.webp", 1920, 1080)
image e5f3-roman2_12 = im.Scale("season1/episode5/images/freeroam3/images/roman2/12.webp", 1920, 1080)
image e5f3-roman2_13 = im.Scale("season1/episode5/images/freeroam3/images/roman2/13.webp", 1920, 1080)
image e5f3-roman2_14 = im.Scale("season1/episode5/images/freeroam3/images/roman2/14.webp", 1920, 1080)

image e5f3_roman_blink1:
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/roman2/roman_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ruby 1
image e5f3-ruby1_01 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/1.webp", 1920, 1080)
image e5f3-ruby1_02 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/2.webp", 1920, 1080)
image e5f3-ruby1_03 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/3.webp", 1920, 1080)
image e5f3-ruby1_04 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/4.webp", 1920, 1080)
image e5f3-ruby1_05 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/5.webp", 1920, 1080)
image e5f3-ruby1_06 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/6.webp", 1920, 1080)
image e5f3-ruby1_07 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/7.webp", 1920, 1080)
image e5f3-ruby1_08 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/8.webp", 1920, 1080)
image e5f3-ruby1_09 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/9.webp", 1920, 1080)
image e5f3-ruby1_10 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/10.webp", 1920, 1080)
image e5f3-ruby1_11 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/11.webp", 1920, 1080)
image e5f3-ruby1_12 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/12.webp", 1920, 1080)
image e5f3-ruby1_13 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/13.webp", 1920, 1080)
image e5f3-ruby1_14 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/14.webp", 1920, 1080)
image e5f3-ruby1_15 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/15.webp", 1920, 1080)
image e5f3-ruby1_16 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/16.webp", 1920, 1080)
image e5f3-ruby1_17 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/17.webp", 1920, 1080)
image e5f3-ruby1_18 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/18.webp", 1920, 1080)
image e5f3-ruby1_19 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/19.webp", 1920, 1080)
image e5f3-ruby1_20 = im.Scale("season1/episode5/images/freeroam3/images/ruby1/20.webp", 1920, 1080)

image e5f3_ruby_blink1:
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5f3_ruby_blink2:
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5f3_ruby_blink3:
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/ruby1/ruby_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ruby 2
# images
image e5f3-ruby2_01 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/1.webp", 1920, 1080)
image e5f3-ruby2_02 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/2.webp", 1920, 1080)
image e5f3-ruby2_03 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/3.webp", 1920, 1080)
image e5f3-ruby2_04 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/4.webp", 1920, 1080)
image e5f3-ruby2_05 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/5.webp", 1920, 1080)
image e5f3-ruby2_06 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/6.webp", 1920, 1080)
image e5f3-ruby2_07 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/7.webp", 1920, 1080)
image e5f3-ruby2_08 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/8.webp", 1920, 1080)
image e5f3-ruby2_09 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/9.webp", 1920, 1080)
image e5f3-ruby2_10 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/10.webp", 1920, 1080)
image e5f3-ruby2_11 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/11.webp", 1920, 1080)
image e5f3-ruby2_12 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/12.webp", 1920, 1080)
image e5f3-ruby2_13 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/13.webp", 1920, 1080)
image e5f3-ruby2_14 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/14.webp", 1920, 1080)
image e5f3-ruby2_15 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/15.webp", 1920, 1080)
image e5f3-ruby2_16 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/16.webp", 1920, 1080)
image e5f3-ruby2_17 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/17.webp", 1920, 1080)
image e5f3-ruby2_18 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/18.webp", 1920, 1080)
image e5f3-ruby2_19 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/19.webp", 1920, 1080)
image e5f3-ruby2_20 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/20.webp", 1920, 1080)
image e5f3-ruby2_21 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/21.webp", 1920, 1080)
image e5f3-ruby2_22 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/22.webp", 1920, 1080)
image e5f3-ruby2_23 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/23.webp", 1920, 1080)
image e5f3-ruby2_24 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/24.webp", 1920, 1080)
image e5f3-ruby2_25 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/25.webp", 1920, 1080)
image e5f3-ruby2_26 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/26.webp", 1920, 1080)
image e5f3-ruby2_27 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/27.webp", 1920, 1080)
image e5f3-ruby2_28 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/28.webp", 1920, 1080)
image e5f3-ruby2_29 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/29.webp", 1920, 1080)
image e5f3-ruby2_30 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/30.webp", 1920, 1080)
image e5f3-ruby2_31 = im.Scale("season1/episode5/images/freeroam3/images/ruby2/31.webp", 1920, 1080)

# Animations #
# Videos
image e5f3-blowjob1 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob1.webm")
image e5f3-blowjob2 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob2.webm")
image e5f3-blowjob3 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob3.webm")
image e5f3-blowjob4 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob4.webm")
image e5f3-blowjob5 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob5.webm")
image e5f3-blowjob6 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/blowjob6.webm")
image e5f3-handjob1 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob1.webm")
image e5f3-handjob2 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob2.webm")
image e5f3-handjob3 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob3.webm")
image e5f3-handjob4 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob4.webm")
image e5f3-handjob5 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob5.webm")
image e5f3-handjob6 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob6.webm")
image e5f3-handjob7 = Movie(play="season1/episode5/images/freeroam3/images/ruby2/handjob7.webm")

# Censored
# Images
image e5f3-ruby2_09_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/9.webp", 1920, 1080)
image e5f3-ruby2_13_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/13.webp", 1920, 1080)
image e5f3-ruby2_14_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/14.webp", 1920, 1080)
image e5f3-ruby2_15_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/15.webp", 1920, 1080)
image e5f3-ruby2_16_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/16.webp", 1920, 1080)
image e5f3-ruby2_17_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/17.webp", 1920, 1080)
image e5f3-ruby2_18_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/18.webp", 1920, 1080)
image e5f3-ruby2_19_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/19.webp", 1920, 1080)
image e5f3-ruby2_20_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/20.webp", 1920, 1080)
image e5f3-ruby2_21_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/21.webp", 1920, 1080)
image e5f3-ruby2_22_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/22.webp", 1920, 1080)
image e5f3-ruby2_23_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/23.webp", 1920, 1080)
image e5f3-ruby2_24_cen = im.Scale("season1/episode5/images/freeroam3/images/ruby2/censored/24.webp", 1920, 1080)

# Videos
image e5f3-blowjob1_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob1.webm")
image e5f3-blowjob2_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob2.webm")
image e5f3-blowjob3_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob3.webm")
image e5f3-blowjob4_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob4.webm")
image e5f3-blowjob5_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob5.webm")
image e5f3-blowjob6_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/blowjob6.webm")
image e5f3-handjob1_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob1.webm")
image e5f3-handjob2_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob2.webm")
image e5f3-handjob3_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob3.webm")
image e5f3-handjob4_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob4.webm")
image e5f3-handjob5_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob5.webm")
image e5f3-handjob6_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob6.webm")
image e5f3-handjob7_cen = Movie(play="season1/episode5/images/freeroam3/images/ruby2/censored/handjob7.webm")

# Scarlett
image e5f3-scarlett_01 = im.Scale("season1/episode5/images/freeroam3/images/scarlett1/1.webp", 1920, 1080)
image e5f3-scarlett_02 = im.Scale("season1/episode5/images/freeroam3/images/scarlett1/2.webp", 1920, 1080)
image e5f3-scarlett_03 = im.Scale("season1/episode5/images/freeroam3/images/scarlett1/3.webp", 1920, 1080)
image e5f3-scarlett_04 = im.Scale("season1/episode5/images/freeroam3/images/scarlett1/4.webp", 1920, 1080)
image e5f3-scarlett_05 = im.Scale("season1/episode5/images/freeroam3/images/scarlett1/5.webp", 1920, 1080)

image e5f3_scarlett_blink1:
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy
image e5f3-tracy_01 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/1.webp", 1920, 1080)
image e5f3-tracy_02 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/2.webp", 1920, 1080)
image e5f3-tracy_03 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/3.webp", 1920, 1080)
image e5f3-tracy_04 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/4.webp", 1920, 1080)
image e5f3-tracy_05 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/5.webp", 1920, 1080)
image e5f3-tracy_06 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/6.webp", 1920, 1080)
image e5f3-tracy_07 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/7.webp", 1920, 1080)
image e5f3-tracy_08 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/8.webp", 1920, 1080)
image e5f3-tracy_09 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/9.webp", 1920, 1080)
image e5f3-tracy_10 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/10.webp", 1920, 1080)
image e5f3-tracy_11 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/11.webp", 1920, 1080)
image e5f3-tracy_12 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/12.webp", 1920, 1080)
image e5f3-tracy_13 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/13.webp", 1920, 1080)
image e5f3-tracy_14 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/14.webp", 1920, 1080)
image e5f3-tracy_15 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/15.webp", 1920, 1080)
image e5f3-tracy_16 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/16.webp", 1920, 1080)
image e5f3-tracy_17 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/17.webp", 1920, 1080)
image e5f3-tracy_18 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/18.webp", 1920, 1080)
image e5f3-tracy_19 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/19.webp", 1920, 1080)
image e5f3-tracy_20 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/20.webp", 1920, 1080)
image e5f3-tracy_21 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/21.webp", 1920, 1080)
image e5f3-tracy_22 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/22.webp", 1920, 1080)
image e5f3-tracy_23 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/23.webp", 1920, 1080)
image e5f3-tracy_24 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/24.webp", 1920, 1080)
image e5f3-tracy_25 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/25.webp", 1920, 1080)
image e5f3-tracy_26 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/26.webp", 1920, 1080)
image e5f3-tracy_27 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/27.webp", 1920, 1080)
image e5f3-tracy_28 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/28.webp", 1920, 1080)
image e5f3-tracy_29 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/29.webp", 1920, 1080)
image e5f3-tracy_30 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/30.webp", 1920, 1080)
image e5f3-tracy_31 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/31.webp", 1920, 1080)
image e5f3-tracy_32 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/32.webp", 1920, 1080)
image e5f3-tracy_33 = im.Scale("season1/episode5/images/freeroam3/images/tracy1/33.webp", 1920, 1080)

image e5f3_tracy_blink1:
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5f3_tracy_blink2:
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5f3_tracy_blink3:
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam3/images/tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
