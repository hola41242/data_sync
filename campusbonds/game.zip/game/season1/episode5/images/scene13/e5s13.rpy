
# Scene 13 images ##############################################################

image e5s13-01 = im.Scale("season1/episode5/images/scene13/1.webp", 1920, 1080)
image e5s13-02 = im.Scale("season1/episode5/images/scene13/2.webp", 1920, 1080)
image e5s13-03 = im.Scale("season1/episode5/images/scene13/3.webp", 1920, 1080)
image e5s13-04 = im.Scale("season1/episode5/images/scene13/4.webp", 1920, 1080)
image e5s13-05 = im.Scale("season1/episode5/images/scene13/5.webp", 1920, 1080)
image e5s13-06 = im.Scale("season1/episode5/images/scene13/6.webp", 1920, 1080)
image e5s13-07 = im.Scale("season1/episode5/images/scene13/7.webp", 1920, 1080)
image e5s13-08 = im.Scale("season1/episode5/images/scene13/8.webp", 1920, 1080)
image e5s13-09 = im.Scale("season1/episode5/images/scene13/9.webp", 1920, 1080)
image e5s13-10 = im.Scale("season1/episode5/images/scene13/10.webp", 1920, 1080)
image e5s13-11 = im.Scale("season1/episode5/images/scene13/11.webp", 1920, 1080)
image e5s13-12 = im.Scale("season1/episode5/images/scene13/12.webp", 1920, 1080)
image e5s13-13 = im.Scale("season1/episode5/images/scene13/13.webp", 1920, 1080)
image e5s13-14 = im.Scale("season1/episode5/images/scene13/14.webp", 1920, 1080)
image e5s13-15 = im.Scale("season1/episode5/images/scene13/15.webp", 1920, 1080)
image e5s13-16 = im.Scale("season1/episode5/images/scene13/16.webp", 1920, 1080)
image e5s13-17 = im.Scale("season1/episode5/images/scene13/17.webp", 1920, 1080)
image e5s13-18 = im.Scale("season1/episode5/images/scene13/18.webp", 1920, 1080)
image e5s13-19 = im.Scale("season1/episode5/images/scene13/19.webp", 1920, 1080)
image e5s13-20 = im.Scale("season1/episode5/images/scene13/20.webp", 1920, 1080)
image e5s13-21 = im.Scale("season1/episode5/images/scene13/21.webp", 1920, 1080)
image e5s13-22 = im.Scale("season1/episode5/images/scene13/22.webp", 1920, 1080)
image e5s13-23 = im.Scale("season1/episode5/images/scene13/23.webp", 1920, 1080)
image e5s13-24 = im.Scale("season1/episode5/images/scene13/24.webp", 1920, 1080)
image e5s13-25 = im.Scale("season1/episode5/images/scene13/25.webp", 1920, 1080)
image e5s13-26 = im.Scale("season1/episode5/images/scene13/26.webp", 1920, 1080)
image e5s13-27 = im.Scale("season1/episode5/images/scene13/27.webp", 1920, 1080)
image e5s13-28 = im.Scale("season1/episode5/images/scene13/28.webp", 1920, 1080)
image e5s13-29 = im.Scale("season1/episode5/images/scene13/29.webp", 1920, 1080)
image e5s13-30 = im.Scale("season1/episode5/images/scene13/30.webp", 1920, 1080)
image e5s13-31 = im.Scale("season1/episode5/images/scene13/31.webp", 1920, 1080)
image e5s13-32 = im.Scale("season1/episode5/images/scene13/32.webp", 1920, 1080)
image e5s13-33 = im.Scale("season1/episode5/images/scene13/33.webp", 1920, 1080)
image e5s13-34 = im.Scale("season1/episode5/images/scene13/34.webp", 1920, 1080)
image e5s13-35 = im.Scale("season1/episode5/images/scene13/35.webp", 1920, 1080)
image e5s13-36 = im.Scale("season1/episode5/images/scene13/36.webp", 1920, 1080)
image e5s13-37 = im.Scale("season1/episode5/images/scene13/37.webp", 1920, 1080)
image e5s13-38 = im.Scale("season1/episode5/images/scene13/38.webp", 1920, 1080)
image e5s13-39 = im.Scale("season1/episode5/images/scene13/39.webp", 1920, 1080)
image e5s13-40 = im.Scale("season1/episode5/images/scene13/40.webp", 1920, 1080)
image e5s13-41 = im.Scale("season1/episode5/images/scene13/41.webp", 1920, 1080)
image e5s13-42 = im.Scale("season1/episode5/images/scene13/42.webp", 1920, 1080)
image e5s13-43 = im.Scale("season1/episode5/images/scene13/43.webp", 1920, 1080)
image e5s13-44 = im.Scale("season1/episode5/images/scene13/44.webp", 1920, 1080)
image e5s13-45 = im.Scale("season1/episode5/images/scene13/45.webp", 1920, 1080)
image e5s13-46 = im.Scale("season1/episode5/images/scene13/46.webp", 1920, 1080)
image e5s13-47 = im.Scale("season1/episode5/images/scene13/47.webp", 1920, 1080)
image e5s13-48 = im.Scale("season1/episode5/images/scene13/48.webp", 1920, 1080)
image e5s13-49 = im.Scale("season1/episode5/images/scene13/49.webp", 1920, 1080)
image e5s13-50 = im.Scale("season1/episode5/images/scene13/50.webp", 1920, 1080)
image e5s13-51 = im.Scale("season1/episode5/images/scene13/51.webp", 1920, 1080)
image e5s13-52 = im.Scale("season1/episode5/images/scene13/52.webp", 1920, 1080)

# Animations #
# Static
image e5s13_amber_blink1:
    im.Scale("season1/episode5/images/scene13/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s13_amber_blink2:
    im.Scale("season1/episode5/images/scene13/amber_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s13_amber_blink3:
    im.Scale("season1/episode5/images/scene13/amber_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene13/amber_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e5s13-handjob1 = Movie(play="season1/episode5/images/scene13/handjob1.webm")
image e5s13-handjob2 = Movie(play="season1/episode5/images/scene13/handjob2.webm")
image e5s13-handjob3 = Movie(play="season1/episode5/images/scene13/handjob3.webm")
image e5s13-handjob4 = Movie(play="season1/episode5/images/scene13/handjob4.webm")
image e5s13-handjob5 = Movie(play="season1/episode5/images/scene13/handjob5.webm")
image e5s13-handjob6 = Movie(play="season1/episode5/images/scene13/handjob6.webm")
image e5s13-handjob7 = Movie(play="season1/episode5/images/scene13/handjob7.webm")
image e5s13-handjob8 = Movie(play="season1/episode5/images/scene13/handjob8.webm")

# Censored
# Images
image e5s13-36_cen = im.Scale("season1/episode5/images/scene13/censored/36.webp", 1920, 1080)
image e5s13-40_cen = im.Scale("season1/episode5/images/scene13/censored/40.webp", 1920, 1080)
image e5s13-41_cen = im.Scale("season1/episode5/images/scene13/censored/41.webp", 1920, 1080)

# Videos
image e5s13-handjob1_cen = Movie(play="season1/episode5/images/scene13/censored/handjob1.webm")
image e5s13-handjob2_cen = Movie(play="season1/episode5/images/scene13/censored/handjob2.webm")
image e5s13-handjob3_cen = Movie(play="season1/episode5/images/scene13/censored/handjob3.webm")
image e5s13-handjob4_cen = Movie(play="season1/episode5/images/scene13/censored/handjob4.webm")
image e5s13-handjob5_cen = Movie(play="season1/episode5/images/scene13/censored/handjob5.webm")
image e5s13-handjob6_cen = Movie(play="season1/episode5/images/scene13/censored/handjob6.webm")
image e5s13-handjob8_cen = Movie(play="season1/episode5/images/scene13/censored/handjob8.webm")
