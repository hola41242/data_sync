
# Scene 10 images ##############################################################

image e5s10-01 = im.Scale("season1/episode5/images/scene10/1.webp", 1920, 1080)
image e5s10-02 = im.Scale("season1/episode5/images/scene10/2.webp", 1920, 1080)
image e5s10-03 = im.Scale("season1/episode5/images/scene10/3.webp", 1920, 1080)
image e5s10-04 = im.Scale("season1/episode5/images/scene10/4.webp", 1920, 1080)
image e5s10-05 = im.Scale("season1/episode5/images/scene10/5.webp", 1920, 1080)
image e5s10-06 = im.Scale("season1/episode5/images/scene10/6.webp", 1920, 1080)
image e5s10-07 = im.Scale("season1/episode5/images/scene10/7.webp", 1920, 1080)
image e5s10-08 = im.Scale("season1/episode5/images/scene10/8.webp", 1920, 1080)
image e5s10-09 = im.Scale("season1/episode5/images/scene10/9.webp", 1920, 1080)
image e5s10-10 = im.Scale("season1/episode5/images/scene10/10.webp", 1920, 1080)
image e5s10-11 = im.Scale("season1/episode5/images/scene10/11.webp", 1920, 1080)
image e5s10-12 = im.Scale("season1/episode5/images/scene10/12.webp", 1920, 1080)
image e5s10-13 = im.Scale("season1/episode5/images/scene10/13.webp", 1920, 1080)
image e5s10-14 = im.Scale("season1/episode5/images/scene10/14.webp", 1920, 1080)
image e5s10-15 = im.Scale("season1/episode5/images/scene10/15.webp", 1920, 1080)
image e5s10-16 = im.Scale("season1/episode5/images/scene10/16.webp", 1920, 1080)
image e5s10-17 = im.Scale("season1/episode5/images/scene10/17.webp", 1920, 1080)
image e5s10-18 = im.Scale("season1/episode5/images/scene10/18.webp", 1920, 1080)

# Animations #
# Static
image e5s10_tracy_blink1:
    im.Scale("season1/episode5/images/scene10/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene10/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
