
# Scene 19 images ##############################################################

image e5s19-01 = im.Scale("season1/episode5/images/scene19/1.webp", 1920, 1080)
image e5s19-02 = im.Scale("season1/episode5/images/scene19/2.webp", 1920, 1080)
image e5s19-03 = im.Scale("season1/episode5/images/scene19/3.webp", 1920, 1080)
image e5s19-04 = im.Scale("season1/episode5/images/scene19/4.webp", 1920, 1080)
image e5s19-05 = im.Scale("season1/episode5/images/scene19/5.webp", 1920, 1080)
image e5s19-06 = im.Scale("season1/episode5/images/scene19/6.webp", 1920, 1080)
image e5s19-07 = im.Scale("season1/episode5/images/scene19/7.webp", 1920, 1080)
image e5s19-08 = im.Scale("season1/episode5/images/scene19/8.webp", 1920, 1080)
image e5s19-09 = im.Scale("season1/episode5/images/scene19/9.webp", 1920, 1080)
image e5s19-10 = im.Scale("season1/episode5/images/scene19/10.webp", 1920, 1080)
image e5s19-11 = im.Scale("season1/episode5/images/scene19/11.webp", 1920, 1080)
image e5s19-12 = im.Scale("season1/episode5/images/scene19/12.webp", 1920, 1080)
image e5s19-13 = im.Scale("season1/episode5/images/scene19/13.webp", 1920, 1080)
image e5s19-14 = im.Scale("season1/episode5/images/scene19/14.webp", 1920, 1080)
image e5s19-15 = im.Scale("season1/episode5/images/scene19/15.webp", 1920, 1080)
image e5s19-16 = im.Scale("season1/episode5/images/scene19/16.webp", 1920, 1080)
image e5s19-17 = im.Scale("season1/episode5/images/scene19/17.webp", 1920, 1080)
image e5s19-18 = im.Scale("season1/episode5/images/scene19/18.webp", 1920, 1080)
image e5s19-19 = im.Scale("season1/episode5/images/scene19/19.webp", 1920, 1080)
image e5s19-20 = im.Scale("season1/episode5/images/scene19/20.webp", 1920, 1080)
image e5s19-21 = im.Scale("season1/episode5/images/scene19/21.webp", 1920, 1080)

# Animations #
# Static
image e5s19_ken_blink1:
    im.Scale("season1/episode5/images/scene19/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene19/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
