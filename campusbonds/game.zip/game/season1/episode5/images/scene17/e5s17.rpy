
# Scene 17 images ##############################################################

image e5s17-01 = im.Scale("season1/episode5/images/scene17/1.webp", 1920, 1080)
image e5s17-02 = im.Scale("season1/episode5/images/scene17/2.webp", 1920, 1080)
image e5s17-03 = im.Scale("season1/episode5/images/scene17/3.webp", 1920, 1080)
image e5s17-04 = im.Scale("season1/episode5/images/scene17/4.webp", 1920, 1080)
image e5s17-05 = im.Scale("season1/episode5/images/scene17/5.webp", 1920, 1080)
image e5s17-06 = im.Scale("season1/episode5/images/scene17/6.webp", 1920, 1080)
image e5s17-07 = im.Scale("season1/episode5/images/scene17/7.webp", 1920, 1080)
image e5s17-08 = im.Scale("season1/episode5/images/scene17/8.webp", 1920, 1080)
image e5s17-09 = im.Scale("season1/episode5/images/scene17/9.webp", 1920, 1080)
image e5s17-10 = im.Scale("season1/episode5/images/scene17/10.webp", 1920, 1080)
image e5s17-11 = im.Scale("season1/episode5/images/scene17/11.webp", 1920, 1080)
image e5s17-12 = im.Scale("season1/episode5/images/scene17/12.webp", 1920, 1080)
image e5s17-13 = im.Scale("season1/episode5/images/scene17/13.webp", 1920, 1080)
image e5s17-14 = im.Scale("season1/episode5/images/scene17/14.webp", 1920, 1080)
image e5s17-15 = im.Scale("season1/episode5/images/scene17/15.webp", 1920, 1080)
image e5s17-16 = im.Scale("season1/episode5/images/scene17/16.webp", 1920, 1080)
image e5s17-17 = im.Scale("season1/episode5/images/scene17/17.webp", 1920, 1080)
image e5s17-18 = im.Scale("season1/episode5/images/scene17/18.webp", 1920, 1080)
image e5s17-19 = im.Scale("season1/episode5/images/scene17/19.webp", 1920, 1080)
image e5s17-20 = im.Scale("season1/episode5/images/scene17/20.webp", 1920, 1080)
image e5s17-21 = im.Scale("season1/episode5/images/scene17/21.webp", 1920, 1080)
image e5s17-22 = im.Scale("season1/episode5/images/scene17/22.webp", 1920, 1080)
image e5s17-23 = im.Scale("season1/episode5/images/scene17/23.webp", 1920, 1080)
image e5s17-24 = im.Scale("season1/episode5/images/scene17/24.webp", 1920, 1080)

# Animations #
# Static
image e5s17_olivia_blink1:
    im.Scale("season1/episode5/images/scene17/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s17_olivia_blink2:
    im.Scale("season1/episode5/images/scene17/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene17/olivia_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
