
# Scene 8 images ###############################################################

image e5s8-01 = im.Scale("season1/episode5/images/scene8/1.webp", 1920, 1080)
image e5s8-02 = im.Scale("season1/episode5/images/scene8/2.webp", 1920, 1080)
image e5s8-03 = im.Scale("season1/episode5/images/scene8/3.webp", 1920, 1080)
image e5s8-04 = im.Scale("season1/episode5/images/scene8/4.webp", 1920, 1080)
image e5s8-05 = im.Scale("season1/episode5/images/scene8/5.webp", 1920, 1080)
image e5s8-06 = im.Scale("season1/episode5/images/scene8/6.webp", 1920, 1080)
image e5s8-07 = im.Scale("season1/episode5/images/scene8/7.webp", 1920, 1080)
image e5s8-08 = im.Scale("season1/episode5/images/scene8/8.webp", 1920, 1080)
image e5s8-09 = im.Scale("season1/episode5/images/scene8/9.webp", 1920, 1080)
image e5s8-10 = im.Scale("season1/episode5/images/scene8/10.webp", 1920, 1080)
image e5s8-11 = im.Scale("season1/episode5/images/scene8/11.webp", 1920, 1080)
image e5s8-12 = im.Scale("season1/episode5/images/scene8/12.webp", 1920, 1080)
image e5s8-13 = im.Scale("season1/episode5/images/scene8/13.webp", 1920, 1080)
image e5s8-14 = im.Scale("season1/episode5/images/scene8/14.webp", 1920, 1080)
image e5s8-15 = im.Scale("season1/episode5/images/scene8/15.webp", 1920, 1080)
image e5s8-16 = im.Scale("season1/episode5/images/scene8/16.webp", 1920, 1080)
image e5s8-17 = im.Scale("season1/episode5/images/scene8/17.webp", 1920, 1080)
image e5s8-18 = im.Scale("season1/episode5/images/scene8/18.webp", 1920, 1080)
image e5s8-19 = im.Scale("season1/episode5/images/scene8/19.webp", 1920, 1080)
image e5s8-20 = im.Scale("season1/episode5/images/scene8/20.webp", 1920, 1080)
image e5s8-21 = im.Scale("season1/episode5/images/scene8/21.webp", 1920, 1080)

# Animations #
# Static
image e5s8_cleo_blink1:
    im.Scale("season1/episode5/images/scene8/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene8/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
