
# Scene 21 images ##############################################################

image e5s21-01 = im.Scale("season1/episode5/images/scene21/1.webp", 1920, 1080)
image e5s21-02 = im.Scale("season1/episode5/images/scene21/2.webp", 1920, 1080)
image e5s21-03 = im.Scale("season1/episode5/images/scene21/3.webp", 1920, 1080)
image e5s21-04 = im.Scale("season1/episode5/images/scene21/4.webp", 1920, 1080)
image e5s21-05 = im.Scale("season1/episode5/images/scene21/5.webp", 1920, 1080)
image e5s21-06 = im.Scale("season1/episode5/images/scene21/6.webp", 1920, 1080)
image e5s21-07 = im.Scale("season1/episode5/images/scene21/7.webp", 1920, 1080)
image e5s21-08 = im.Scale("season1/episode5/images/scene21/8.webp", 1920, 1080)
image e5s21-09 = im.Scale("season1/episode5/images/scene21/9.webp", 1920, 1080)
image e5s21-10 = im.Scale("season1/episode5/images/scene21/10.webp", 1920, 1080)
image e5s21-11 = im.Scale("season1/episode5/images/scene21/11.webp", 1920, 1080)
image e5s21-12 = im.Scale("season1/episode5/images/scene21/12.webp", 1920, 1080)
image e5s21-13 = im.Scale("season1/episode5/images/scene21/13.webp", 1920, 1080)
image e5s21-14 = im.Scale("season1/episode5/images/scene21/14.webp", 1920, 1080)
image e5s21-15 = im.Scale("season1/episode5/images/scene21/15.webp", 1920, 1080)
image e5s21-16 = im.Scale("season1/episode5/images/scene21/16.webp", 1920, 1080)
image e5s21-17 = im.Scale("season1/episode5/images/scene21/17.webp", 1920, 1080)
image e5s21-18 = im.Scale("season1/episode5/images/scene21/18.webp", 1920, 1080)
image e5s21-19 = im.Scale("season1/episode5/images/scene21/19.webp", 1920, 1080)
image e5s21-20 = im.Scale("season1/episode5/images/scene21/20.webp", 1920, 1080)
image e5s21-21 = im.Scale("season1/episode5/images/scene21/21.webp", 1920, 1080)
image e5s21-22 = im.Scale("season1/episode5/images/scene21/22.webp", 1920, 1080)
image e5s21-23 = im.Scale("season1/episode5/images/scene21/23.webp", 1920, 1080)
image e5s21-24 = im.Scale("season1/episode5/images/scene21/24.webp", 1920, 1080)
image e5s21-25 = im.Scale("season1/episode5/images/scene21/25.webp", 1920, 1080)
image e5s21-26 = im.Scale("season1/episode5/images/scene21/26.webp", 1920, 1080)
image e5s21-27 = im.Scale("season1/episode5/images/scene21/27.webp", 1920, 1080)
image e5s21-28 = im.Scale("season1/episode5/images/scene21/28.webp", 1920, 1080)
image e5s21-29 = im.Scale("season1/episode5/images/scene21/29.webp", 1920, 1080)
image e5s21-30 = im.Scale("season1/episode5/images/scene21/30.webp", 1920, 1080)
image e5s21-31 = im.Scale("season1/episode5/images/scene21/31.webp", 1920, 1080)
image e5s21-32 = im.Scale("season1/episode5/images/scene21/32.webp", 1920, 1080)
image e5s21-33 = im.Scale("season1/episode5/images/scene21/33.webp", 1920, 1080)
image e5s21-34 = im.Scale("season1/episode5/images/scene21/34.webp", 1920, 1080)
image e5s21-35 = im.Scale("season1/episode5/images/scene21/35.webp", 1920, 1080)
image e5s21-36 = im.Scale("season1/episode5/images/scene21/36.webp", 1920, 1080)
image e5s21-37 = im.Scale("season1/episode5/images/scene21/37.webp", 1920, 1080)
image e5s21-38 = im.Scale("season1/episode5/images/scene21/38.webp", 1920, 1080)
image e5s21-39 = im.Scale("season1/episode5/images/scene21/39.webp", 1920, 1080)
image e5s21-40 = im.Scale("season1/episode5/images/scene21/40.webp", 1920, 1080)
image e5s21-41 = im.Scale("season1/episode5/images/scene21/41.webp", 1920, 1080)
image e5s21-42 = im.Scale("season1/episode5/images/scene21/42.webp", 1920, 1080)
image e5s21-43 = im.Scale("season1/episode5/images/scene21/43.webp", 1920, 1080)
image e5s21-44 = im.Scale("season1/episode5/images/scene21/44.webp", 1920, 1080)
image e5s21-45 = im.Scale("season1/episode5/images/scene21/45.webp", 1920, 1080)
image e5s21-46 = im.Scale("season1/episode5/images/scene21/46.webp", 1920, 1080)
image e5s21-47 = im.Scale("season1/episode5/images/scene21/47.webp", 1920, 1080)
image e5s21-48 = im.Scale("season1/episode5/images/scene21/48.webp", 1920, 1080)
image e5s21-49 = im.Scale("season1/episode5/images/scene21/49.webp", 1920, 1080)
image e5s21-50 = im.Scale("season1/episode5/images/scene21/50.webp", 1920, 1080)
image e5s21-51 = im.Scale("season1/episode5/images/scene21/51.webp", 1920, 1080)
image e5s21-52 = im.Scale("season1/episode5/images/scene21/52.webp", 1920, 1080)
image e5s21-53 = im.Scale("season1/episode5/images/scene21/53.webp", 1920, 1080)
image e5s21-54 = im.Scale("season1/episode5/images/scene21/54.webp", 1920, 1080)
image e5s21-55 = im.Scale("season1/episode5/images/scene21/55.webp", 1920, 1080)
image e5s21-56 = im.Scale("season1/episode5/images/scene21/56.webp", 1920, 1080)
image e5s21-57 = im.Scale("season1/episode5/images/scene21/57.webp", 1920, 1080)
image e5s21-58 = im.Scale("season1/episode5/images/scene21/58.webp", 1920, 1080)
image e5s21-59 = im.Scale("season1/episode5/images/scene21/59.webp", 1920, 1080)
image e5s21-60 = im.Scale("season1/episode5/images/scene21/60.webp", 1920, 1080)
image e5s21-61 = im.Scale("season1/episode5/images/scene21/61.webp", 1920, 1080)
image e5s21-62 = im.Scale("season1/episode5/images/scene21/62.webp", 1920, 1080)
image e5s21-63 = im.Scale("season1/episode5/images/scene21/63.webp", 1920, 1080)
image e5s21-64 = im.Scale("season1/episode5/images/scene21/64.webp", 1920, 1080)
image e5s21-65 = im.Scale("season1/episode5/images/scene21/65.webp", 1920, 1080)
image e5s21-66 = im.Scale("season1/episode5/images/scene21/66.webp", 1920, 1080)
image e5s21-67 = im.Scale("season1/episode5/images/scene21/67.webp", 1920, 1080)
image e5s21-68 = im.Scale("season1/episode5/images/scene21/68.webp", 1920, 1080)
image e5s21-69 = im.Scale("season1/episode5/images/scene21/69.webp", 1920, 1080)
image e5s21-70 = im.Scale("season1/episode5/images/scene21/70.webp", 1920, 1080)
image e5s21-71 = im.Scale("season1/episode5/images/scene21/71.webp", 1920, 1080)

# Animations #
# Static
image e5s21_evelyn_blink1:
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s21_evelyn_blink2:
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s21_evelyn_blink3:
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene21/evelyn_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
