
# Scene 12 images ###############################################################

image e5s12-01 = im.Scale("season1/episode5/images/scene12/1.webp", 1920, 1080)
image e5s12-02 = im.Scale("season1/episode5/images/scene12/2.webp", 1920, 1080)
image e5s12-03 = im.Scale("season1/episode5/images/scene12/3.webp", 1920, 1080)
image e5s12-04 = im.Scale("season1/episode5/images/scene12/4.webp", 1920, 1080)
image e5s12-05 = im.Scale("season1/episode5/images/scene12/5.webp", 1920, 1080)
image e5s12-06 = im.Scale("season1/episode5/images/scene12/6.webp", 1920, 1080)
image e5s12-07 = im.Scale("season1/episode5/images/scene12/7.webp", 1920, 1080)
image e5s12-08 = im.Scale("season1/episode5/images/scene12/8.webp", 1920, 1080)
image e5s12-09 = im.Scale("season1/episode5/images/scene12/9.webp", 1920, 1080)
image e5s12-10 = im.Scale("season1/episode5/images/scene12/10.webp", 1920, 1080)
image e5s12-11 = im.Scale("season1/episode5/images/scene12/11.webp", 1920, 1080)
image e5s12-12 = im.Scale("season1/episode5/images/scene12/12.webp", 1920, 1080)
image e5s12-13 = im.Scale("season1/episode5/images/scene12/13.webp", 1920, 1080)
image e5s12-14 = im.Scale("season1/episode5/images/scene12/14.webp", 1920, 1080)
image e5s12-15 = im.Scale("season1/episode5/images/scene12/15.webp", 1920, 1080)

# Animations #
# Static
image e5s12_sadie_blink1:
    im.Scale("season1/episode5/images/scene12/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s12_sadie_blink2:
    im.Scale("season1/episode5/images/scene12/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene12/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
