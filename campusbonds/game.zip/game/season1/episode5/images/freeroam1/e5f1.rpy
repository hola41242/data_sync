
# Freeroam 1 Images ############################################################
# Main
image e5f1-01 = im.Scale("season1/episode5/images/freeroam1/1.webp", 1920, 1080)

# Left
image e5f1-02 = im.Scale("season1/episode5/images/freeroam1/2.webp", 1920, 1080)
image e5f1-02_1 = im.Scale("season1/episode5/images/freeroam1/2.1.webp", 1920, 1080)

# Right
image e5f1-03 = im.Scale("season1/episode5/images/freeroam1/3.webp", 1920, 1080)

# Hallway 1
image e5f1-04 = im.Scale("season1/episode5/images/freeroam1/4.webp", 1920, 1080)

# Hallway 2
image e5f1-05 = im.Scale("season1/episode5/images/freeroam1/5.webp", 1920, 1080)

# Hallway 3
image e5f1-06 = im.Scale("season1/episode5/images/freeroam1/6.webp", 1920, 1080)



# Cleo
image e5f1-cleo_01 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/1.webp", 1920, 1080)
image e5f1-cleo_02 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/2.webp", 1920, 1080)
image e5f1-cleo_03 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/3.webp", 1920, 1080)
image e5f1-cleo_04 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/4.webp", 1920, 1080)
image e5f1-cleo_05 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/5.webp", 1920, 1080)
image e5f1-cleo_06 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/6.webp", 1920, 1080)
image e5f1-cleo_07 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/7.webp", 1920, 1080)
image e5f1-cleo_08 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/8.webp", 1920, 1080)
image e5f1-cleo_09 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/9.webp", 1920, 1080)
image e5f1-cleo_10 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/10.webp", 1920, 1080)
image e5f1-cleo_11 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/11.webp", 1920, 1080)
image e5f1-cleo_12 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/12.webp", 1920, 1080)
image e5f1-cleo_13 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/13.webp", 1920, 1080)
image e5f1-cleo_14 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/14.webp", 1920, 1080)
image e5f1-cleo_15 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/15.webp", 1920, 1080)
image e5f1-cleo_16 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/16.webp", 1920, 1080)
image e5f1-cleo_17 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/17.webp", 1920, 1080)
image e5f1-cleo_18 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/18.webp", 1920, 1080)
image e5f1-cleo_19 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/19.webp", 1920, 1080)
image e5f1-cleo_20 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/20.webp", 1920, 1080)
image e5f1-cleo_21 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/21.webp", 1920, 1080)
image e5f1-cleo_22 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/22.webp", 1920, 1080)
image e5f1-cleo_23 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/23.webp", 1920, 1080)
image e5f1-cleo_24 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/24.webp", 1920, 1080)
image e5f1-cleo_25 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/25.webp", 1920, 1080)
image e5f1-cleo_26 = im.Scale("season1/episode5/images/freeroam1/images/cleo1/26.webp", 1920, 1080)

image e5f1_cleo1_blink1:
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/cleo1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Desk
image e5f1-desk_01 = im.Scale("season1/episode5/images/freeroam1/images/desk1/1.webp", 1920, 1080)
image e5f1-desk_02 = im.Scale("season1/episode5/images/freeroam1/images/desk1/2.webp", 1920, 1080)
image e5f1-desk_03 = im.Scale("season1/episode5/images/freeroam1/images/desk1/3.webp", 1920, 1080)

# Guitar
image e5f1-guitar_01 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/1.webp", 1920, 1080)
image e5f1-guitar_02 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/2.webp", 1920, 1080)
image e5f1-guitar_03 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/3.webp", 1920, 1080)
image e5f1-guitar_04 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/4.webp", 1920, 1080)
image e5f1-guitar_05 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/5.webp", 1920, 1080)
image e5f1-guitar_06 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/6.webp", 1920, 1080)
image e5f1-guitar_07 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/7.webp", 1920, 1080)
image e5f1-guitar_08 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/8.webp", 1920, 1080)
image e5f1-guitar_09 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/9.webp", 1920, 1080)
image e5f1-guitar_10 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/10.webp", 1920, 1080)
image e5f1-guitar_11 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/11.webp", 1920, 1080)
image e5f1-guitar_12 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/12.webp", 1920, 1080)
image e5f1-guitar_13 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/13.webp", 1920, 1080)
image e5f1-guitar_14 = im.Scale("season1/episode5/images/freeroam1/images/guitar1/14.webp", 1920, 1080)

image e5f1_cleo2_blink1:
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/guitar1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Jordan
image e5f1-jordan_01 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/1.webp", 1920, 1080)
image e5f1-jordan_02 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/2.webp", 1920, 1080)
image e5f1-jordan_03 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/3.webp", 1920, 1080)
image e5f1-jordan_04 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/4.webp", 1920, 1080)
image e5f1-jordan_05 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/5.webp", 1920, 1080)
image e5f1-jordan_06 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/6.webp", 1920, 1080)
image e5f1-jordan_07 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/7.webp", 1920, 1080)
image e5f1-jordan_08 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/8.webp", 1920, 1080)
image e5f1-jordan_09 = im.Scale("season1/episode5/images/freeroam1/images/jordan1/9.webp", 1920, 1080)

# Nate
image e5f1-nate_01 = im.Scale("season1/episode5/images/freeroam1/images/nate1/1.webp", 1920, 1080)
image e5f1-nate_02 = im.Scale("season1/episode5/images/freeroam1/images/nate1/2.webp", 1920, 1080)
image e5f1-nate_03 = im.Scale("season1/episode5/images/freeroam1/images/nate1/3.webp", 1920, 1080)
image e5f1-nate_04 = im.Scale("season1/episode5/images/freeroam1/images/nate1/4.webp", 1920, 1080)
image e5f1-nate_05 = im.Scale("season1/episode5/images/freeroam1/images/nate1/5.webp", 1920, 1080)
image e5f1-nate_06 = im.Scale("season1/episode5/images/freeroam1/images/nate1/6.webp", 1920, 1080)
image e5f1-nate_07 = im.Scale("season1/episode5/images/freeroam1/images/nate1/7.webp", 1920, 1080)
image e5f1-nate_08 = im.Scale("season1/episode5/images/freeroam1/images/nate1/8.webp", 1920, 1080)
image e5f1-nate_09 = im.Scale("season1/episode5/images/freeroam1/images/nate1/9.webp", 1920, 1080)
image e5f1-nate_10 = im.Scale("season1/episode5/images/freeroam1/images/nate1/10.webp", 1920, 1080)
image e5f1-nate_11 = im.Scale("season1/episode5/images/freeroam1/images/nate1/11.webp", 1920, 1080)
image e5f1-nate_12 = im.Scale("season1/episode5/images/freeroam1/images/nate1/12.webp", 1920, 1080)
image e5f1-nate_13 = im.Scale("season1/episode5/images/freeroam1/images/nate1/13.webp", 1920, 1080)

image e5f1_nate_blink1:
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/freeroam1/images/nate1/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy
image e5f1-tracy_01 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/1.webp", 1920, 1080)
image e5f1-tracy_02 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/2.webp", 1920, 1080)
image e5f1-tracy_03 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/3.webp", 1920, 1080)
image e5f1-tracy_04 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/4.webp", 1920, 1080)
image e5f1-tracy_05 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/5.webp", 1920, 1080)
image e5f1-tracy_06 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/6.webp", 1920, 1080)
image e5f1-tracy_07 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/7.webp", 1920, 1080)
image e5f1-tracy_08 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/8.webp", 1920, 1080)
image e5f1-tracy_09 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/9.webp", 1920, 1080)
image e5f1-tracy_10 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/10.webp", 1920, 1080)
image e5f1-tracy_11 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/11.webp", 1920, 1080)
image e5f1-tracy_12 = im.Scale("season1/episode5/images/freeroam1/images/tracy1/12.webp", 1920, 1080)
