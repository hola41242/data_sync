
# Scene 3 images ###############################################################

image e5s3-01 = im.Scale("season1/episode5/images/scene3/1.webp", 1920, 1080)
image e5s3-02 = im.Scale("season1/episode5/images/scene3/2.webp", 1920, 1080)
image e5s3-03 = im.Scale("season1/episode5/images/scene3/3.webp", 1920, 1080)
image e5s3-04 = im.Scale("season1/episode5/images/scene3/4.webp", 1920, 1080)
image e5s3-05 = im.Scale("season1/episode5/images/scene3/5.webp", 1920, 1080)
image e5s3-06 = im.Scale("season1/episode5/images/scene3/6.webp", 1920, 1080)
image e5s3-07 = im.Scale("season1/episode5/images/scene3/7.webp", 1920, 1080)
image e5s3-08 = im.Scale("season1/episode5/images/scene3/8.webp", 1920, 1080)
image e5s3-09 = im.Scale("season1/episode5/images/scene3/9.webp", 1920, 1080)
image e5s3-10 = im.Scale("season1/episode5/images/scene3/10.webp", 1920, 1080)
image e5s3-11 = im.Scale("season1/episode5/images/scene3/11.webp", 1920, 1080)
image e5s3-12 = im.Scale("season1/episode5/images/scene3/12.webp", 1920, 1080)
image e5s3-13 = im.Scale("season1/episode5/images/scene3/13.webp", 1920, 1080)
image e5s3-14 = im.Scale("season1/episode5/images/scene3/14.webp", 1920, 1080)
image e5s3-15 = im.Scale("season1/episode5/images/scene3/15.webp", 1920, 1080)
image e5s3-16 = im.Scale("season1/episode5/images/scene3/16.webp", 1920, 1080)
image e5s3-17 = im.Scale("season1/episode5/images/scene3/17.webp", 1920, 1080)
image e5s3-18 = im.Scale("season1/episode5/images/scene3/18.webp", 1920, 1080)
image e5s3-19 = im.Scale("season1/episode5/images/scene3/19.webp", 1920, 1080)
image e5s3-20 = im.Scale("season1/episode5/images/scene3/20.webp", 1920, 1080)
image e5s3-21 = im.Scale("season1/episode5/images/scene3/21.webp", 1920, 1080)
image e5s3-22 = im.Scale("season1/episode5/images/scene3/22.webp", 1920, 1080)
image e5s3-23 = im.Scale("season1/episode5/images/scene3/23.webp", 1920, 1080)
image e5s3-24 = im.Scale("season1/episode5/images/scene3/24.webp", 1920, 1080)

# Animations #
# Static
image e5s3_cleo_blink1:
    im.Scale("season1/episode5/images/scene3/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s3_cleo_blink2:
    im.Scale("season1/episode5/images/scene3/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene3/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
