
# Scene 23 images ##############################################################

image e5s23-01 = im.Scale("season1/episode5/images/scene23/1.webp", 1920, 1080)
image e5s23-02 = im.Scale("season1/episode5/images/scene23/2.webp", 1920, 1080)
image e5s23-03 = im.Scale("season1/episode5/images/scene23/3.webp", 1920, 1080)
image e5s23-04 = im.Scale("season1/episode5/images/scene23/4.webp", 1920, 1080)
image e5s23-05 = im.Scale("season1/episode5/images/scene23/5.webp", 1920, 1080)
image e5s23-06 = im.Scale("season1/episode5/images/scene23/6.webp", 1920, 1080)
image e5s23-07 = im.Scale("season1/episode5/images/scene23/7.webp", 1920, 1080)
image e5s23-08 = im.Scale("season1/episode5/images/scene23/8.webp", 1920, 1080)
image e5s23-09 = im.Scale("season1/episode5/images/scene23/9.webp", 1920, 1080)
image e5s23-10 = im.Scale("season1/episode5/images/scene23/10.webp", 1920, 1080)
image e5s23-11 = im.Scale("season1/episode5/images/scene23/11.webp", 1920, 1080)
image e5s23-12 = im.Scale("season1/episode5/images/scene23/12.webp", 1920, 1080)
image e5s23-13 = im.Scale("season1/episode5/images/scene23/13.webp", 1920, 1080)
image e5s23-14 = im.Scale("season1/episode5/images/scene23/14.webp", 1920, 1080)
