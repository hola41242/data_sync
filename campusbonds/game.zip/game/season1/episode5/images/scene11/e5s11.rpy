
# Scene 11 images ##############################################################

image e5s11-01 = im.Scale("season1/episode5/images/scene11/1.webp", 1920, 1080)
image e5s11-02 = im.Scale("season1/episode5/images/scene11/2.webp", 1920, 1080)
image e5s11-03 = im.Scale("season1/episode5/images/scene11/3.webp", 1920, 1080)
image e5s11-04 = im.Scale("season1/episode5/images/scene11/4.webp", 1920, 1080)
image e5s11-05 = im.Scale("season1/episode5/images/scene11/5.webp", 1920, 1080)
image e5s11-06 = im.Scale("season1/episode5/images/scene11/6.webp", 1920, 1080)
image e5s11-07 = im.Scale("season1/episode5/images/scene11/7.webp", 1920, 1080)
image e5s11-08 = im.Scale("season1/episode5/images/scene11/8.webp", 1920, 1080)
image e5s11-09 = im.Scale("season1/episode5/images/scene11/9.webp", 1920, 1080)
image e5s11-10 = im.Scale("season1/episode5/images/scene11/10.webp", 1920, 1080)
image e5s11-11 = im.Scale("season1/episode5/images/scene11/11.webp", 1920, 1080)
image e5s11-12 = im.Scale("season1/episode5/images/scene11/12.webp", 1920, 1080)
image e5s11-13 = im.Scale("season1/episode5/images/scene11/13.webp", 1920, 1080)
image e5s11-14 = im.Scale("season1/episode5/images/scene11/14.webp", 1920, 1080)
image e5s11-15 = im.Scale("season1/episode5/images/scene11/15.webp", 1920, 1080)
image e5s11-16 = im.Scale("season1/episode5/images/scene11/16.webp", 1920, 1080)
image e5s11-17 = im.Scale("season1/episode5/images/scene11/17.webp", 1920, 1080)
image e5s11-18 = im.Scale("season1/episode5/images/scene11/18.webp", 1920, 1080)
image e5s11-19 = im.Scale("season1/episode5/images/scene11/19.webp", 1920, 1080)
image e5s11-20 = im.Scale("season1/episode5/images/scene11/20.webp", 1920, 1080)
image e5s11-21 = im.Scale("season1/episode5/images/scene11/21.webp", 1920, 1080)
image e5s11-22 = im.Scale("season1/episode5/images/scene11/22.webp", 1920, 1080)

# Animations #
# Static
image e5s11_charlie_blink1:
    im.Scale("season1/episode5/images/scene11/charlie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e5s11_charlie_blink2:
    im.Scale("season1/episode5/images/scene11/charlie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode5/images/scene11/charlie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
