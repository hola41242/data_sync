
# Scene 18 #####################################################################

label e5s18:
    jump e5s19
return

# Just a placeholder, nothing to see :D #
