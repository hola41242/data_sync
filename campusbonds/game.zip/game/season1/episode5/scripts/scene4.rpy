
# Scene 4 - College Rock Tension (Monday) ######################################

label e5s4:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music write_hear_right_now
    scene e5s4-01 with Dissolve(2.0)
    pause

    scene e5s4-02 with dissolve
    pause

    if e4s29_sweet == False:
        scene e5s4-03 with dissolve
        pause
    else:
        scene e5s4-04 with dissolve
        mc "Hey."

        if e4s28_defensive == False:
            scene e5s4-05 with dissolve
            fr "Hi..."

        scene e5s4-03 with dissolve
        pause

    scene e5s4-06 with dissolve
    pause

    scene e5s4-07 with dissolve
    mc "Hey, [al]!"

    scene e5s4-08 with dissolve
    show e5s4_alice_blink1
    mc "Mind if I practice with you today?"

    scene e5s4-09 with dissolve
    hide e5s4_alice_blink1
    al "Not at all, be my guest."

    scene e5s4-10 with dissolve
    al "Did something happen between you and [fr]?"

    scene e5s4-08 with dissolve
    show e5s4_alice_blink1
    mc "Nope, nothing at all."

    scene e5s4-11 with dissolve
    hide e5s4_alice_blink1
    ev "Morning, everyone! I know we're a bit earlier than usual today, but I want this rehearsal to run a little longer."
    ev "Whenever you're all ready, we can start."

    scene e5s4-12 with dissolve
    al "I'm just surprised you're not practicing with her today, that's all."

    scene e5s4-08 with dissolve
    show e5s4_alice_blink1
    mc "You don't have to worry about it."

    menu:
        "Make small talk with [al]":
            $ alice_trust += 1
            $ e5s4_talk = True
            mc "Just thought it'd be cool to see what you're working on."
            mc "We haven't really talked much."

            scene e5s4-09 with dissolve
            hide e5s4_alice_blink1
            al "Yeah, I guess so."

            scene e5s4-12 with dissolve
            al "Well... uh-I'm not really sure what to tell you."

            scene e5s4-13 with dissolve
            al "I've mostly been studying these last few days."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Really? Nothing else?"

            scene e5s4-09 with dissolve
            hide e5s4_alice_blink1
            al "I mean, I play guitar too, but you already know that."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Yup, that makes two of us."

            scene e5s4-14 with dissolve
            hide e5s4_alice_blink1
            al "Haha, yeah!"

            scene e5s4-15 with dissolve
            al "..."

            scene e5s4-16 with dissolve
            al "Oh! Actually, I might have something interesting for you."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Yeah? What is it?"

            scene e5s4-16 with dissolve
            hide e5s4_alice_blink1
            al "Okay, so... maybe I shouldn't say this, but I've been helping [ev] plan the competition."
            al "Everything's in my dorm. We don't keep the drafts here, for safety reasons."

            scene e5s4-12 with dissolve
            al "[ev] trusts me with them... I guess."

            scene e5s4-16 with dissolve
            al "But if you want, I can show you."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Would [ev] get mad if she found out?"

            scene e5s4-09 with dissolve
            hide e5s4_alice_blink1
            al "Nah. She doesn't need to know."

            scene e5s4-16 with dissolve
            al "Besides, you're planning to stay, right?"

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "*Shit... I still haven't decided.*"
            mc "Yeah, all good!"

            scene e5s4-14 with dissolve
            hide e5s4_alice_blink1
            al "Great! Then it's settled."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Looks like everyone's already practicing."

            scene e5s4-17 with dissolve
            hide e5s4_alice_blink1
            mc "[ev]'s been giving me looks for a while now, but she still hasn't said anything."

            scene e5s4-18 with dissolve
            hide e5s4_alice_blink1
            al "Haha, probably because you're with me!"

            scene e5s4-14 with dissolve
            al "Anyway, let's not keep her waiting."

            scene e5s4-08 with dissolve
            show e5s4_alice_blink1
            mc "Right. Let's get started."
        "Ignore Alice":
            pass

    scene e5s4-19 with dissolve
    hide e5s4_alice_blink1
    pause

    scene black with Dissolve(2.0)

    scene e5s4-19 with Dissolve(2.0)
    pause

    if e5s4_talk == True:
        scene e5s4-16 with dissolve
        al "So... you wanna go now?"

        scene e5s4-08 with dissolve
        show e5s4_alice_blink1
        mc "Sure, why not."

    scene e5s4-20 with dissolve
    hide e5s4_alice_blink1
    pause

    if e4s29_sweet == True:
        scene e5s4-21 with dissolve
        pause

    if e4s28_defensive == False:
        scene e5s4-22 with dissolve
        pause

    if e5s4_talk == True:
        jump e5s5
    else:
        jump e5s6
return
