
if persistent.fight_difficulty == 0:
    default e5s14_qte_count = 3
    default e5s14_fail_count = 3
if persistent.fight_difficulty == 1:
    default e5s14_qte_count = 5
    default e5s14_fail_count = 2
if persistent.fight_difficulty == 2:
    default e5s14_qte_count = 6
    default e5s14_fail_count = 1

default e5s14_qte_stage = 1
default last_fight_scene = 0
default fight_scene = 0

# Scene 14 - Sticky Fingers ####################################################

label e5s14:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music mom_n_pa
    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e5s14-01 with Dissolve(2.0)
    pause

    scene e5s14-02 with dissolve
    pause

    scene e5s14-03 with dissolve
    mc "So... how have you been?"

    scene e5s14-05 with dissolve
    ci "I've been good. Busy, though."

    scene e5s14-06 with dissolve
    ci "Just came from cheer practice. Another rough day."

    scene e5s14-07 with dissolve
    ci "Half of them don't even listen unless you raise your voice."

    scene e5s14-08 with dissolve
    ci "And then they act like I'm the villain."

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "You still thinking about running?"

    scene e5s14-05 with dissolve
    hide e5s14_claire_blink1
    ci "Honestly? I don't know."

    scene e5s14-06 with dissolve
    ci "I'm still thinking about it."
    ci "You hear anything about [kv]?"

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "Nope. [jon] hasn't told me anything."

    scene e5s14-09 with dissolve
    hide e5s14_claire_blink1
    ci "Did you talk to [ch] yet?"

    scene e5s14-10 with vpunch
    play sound glass_shatter
    pause

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "About what?"

    scene e5s14-12 with dissolve
    hide e5s14_claire_blink1
    ci "She's involved in this too, right?"
    ci "I figured she'd be more open to helping us."

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "Oh. Yeah. She is."

    scene e5s14-11 with dissolve
    hide e5s14_claire_blink1
    ci "Sure she is."

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "What's going on between you two anyway? I thought she was pretty chill."

    scene e5s14-06 with dissolve
    hide e5s14_claire_blink1
    ci "I hate to break it to you, but appearances can be deceiving."
    ci "That's how she got elected president in the first place."

    scene e5s14-05 with dissolve
    ci "She smiles, acts supportive... and then somehow everything shifts in her favor."

    scene e5s14-12 with dissolve
    ci "You ever get that feeling someone's three steps ahead of you?"

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "I mean... I haven't known her that long."
    mc "Why not just vote her out?"

    scene e5s14-06 with dissolve
    hide e5s14_claire_blink1
    ci "Because there are still girls who back her."

    scene e5s14-05 with dissolve
    ci "I don't know what it is, but we can't push her out. Not yet."

    scene e5s14-04 with dissolve
    show e5s14_claire_blink1
    mc "Okay... you know best."

    scene e5s14-13 with dissolve
    mc "*There it is.*"
    mc "*I just need to get close to it somehow.*"

    scene e5s14-14 with dissolve
    mc "*But how do I do that without her noticing?*"
    mc "*If I pull this off, we're in the clear.*"
    mc "*If I don't... this could blow up in my face.*"

    scene black with Dissolve(2.0)

    scene e5s14-15 with Dissolve(2.0)
    pause

    scene e5s14-16 with dissolve
    mc "*Shit... she's almost done.*"

    scene e5s14-17 with dissolve
    mc "*Come on. Doesn't she need the bathroom or something?*"

    scene e5s14-18 with dissolve
    play sound phone_buzz
    pause

    scene e5s14-19 with dissolve
    ci "Oops... sorry."

    scene e5s14-20 with dissolve
    ci "I need to take this."

    stop music fadeout 2.0
    scene e5s14-21 with dissolve
    ci "Yeah?"

    play music dances_and_dames
    scene e5s14-22 with dissolve
    mc "*This is it. If she turns around, I'm dead.*"

    scene e5s14-23 with dissolve
    mc "*I just need to be careful. She doesn't have to see me.*"

    $ timed_max = 3.9
    $ timed_start = 4.00
    $ timed_interval = 0.01
    $ timed_choice = 0

    if persistent.fight == 0:
        while e5s14_qte_count > 0 and e5s14_fail_count > 0:
            scene e5s14-24 with dissolve
            call qte from _call_qte_38

            if qte == True:
                $ e5s14_qte_count -= 1
            else:
                $ e5s14_fail_count -= 1

                show miss_screen at miss_anim

                scene e5s14-29 with dissolve
                mc "*Come on, [mc]. Focus.*"

        if qte_neg_count == 0:
            #if persistent.tr_gallery_12_unlocked == False:
            #    $ persistent.tr_gallery_12_unlocked = True
            #    $ renpy.show_screen("render_notify")
            #    $ persistent.tracy12 = True
            #    python:
            #        update_tracy_list()
            pass

        if e5s14_qte_count == 0:
            $ e5s14_qte_stage = 2

            scene e5s14-25 with dissolve
            mc "*Bingo!*"

            scene e5s14-30 with dissolve
            mc "*Jesus... my hands are shaking.*"

        if e5s14_qte_stage == 2:
            if persistent.fight_difficulty == 0:
                $ e5s14_qte_count = 3
                $ e5s14_fail_count = 3
            if persistent.fight_difficulty == 1:
                $ e5s14_qte_count = 5
                $ e5s14_fail_count = 2
            if persistent.fight_difficulty == 2:
                $ e5s14_qte_count = 6
                $ e5s14_fail_count = 1

            scene e5s14-26 with dissolve
            while e5s14_qte_count > 0 and e5s14_fail_count > 0:
                call qte from _call_qte_39

                if qte == True:
                    $ e5s14_qte_count -= 1
                else:
                    $ e5s14_fail_count -= 1

                    show miss_screen at miss_anim

                    scene e5s14-29 with dissolve
                    mc "*Come on, [mc]. Focus.*"

            if e5s14_qte_count == 0:
                $ qte_neg_count = 0
                $ qte_pos_count = 0
                scene e5s14-27 with dissolve
                pause

                scene e5s14-28 with dissolve
                pause

                scene e5s14-29 with dissolve
                mc "*Okay. Act normal.*"
                mc "*Let's hope that's the end of it.*"

                scene e5s14-31 with dissolve
                pause

                scene e5s14-32 with dissolve
                ci "Hey, [mc], I'd love to stay, but I've gotta run."
                ci "We'll talk later, okay?"

                scene e5s14-34 with dissolve
                show e5s14_claire_blink1
                mc "Okay, see you."

                scene e5s14-48 with dissolve
                hide e5s14_claire_blink1
                pause

                $ e5s14_qte = True

        if e5s14_fail_count == 0:
            $ qte_neg_count = 0
            $ qte_pos_count = 0

            scene e5s14-31 with dissolve
            mc "*Shit! She's wrapping up the call.*"

            scene e5s14-33 with dissolve
            mc "*No no no no!*"

            scene e5s14-32 with dissolve
            ci "Hey, [mc], I'd love to stay, but I've gotta run."
            ci "We'll talk later, okay?"

            scene e5s14-34 with dissolve
            show e5s14_claire_blink1
            mc "Yeah... uh-sure."

            scene e5s14-33 with dissolve
            hide e5s14_claire_blink1
            mc "*Fuck... what do I do now?*"

            $ e5s14_qte = False

        stop music fadeout 2.0
        scene e5s14-35 with dissolve
        pause

        scene e5s14-36 with dissolve
        mc "[ci], wait!"

        scene e5s14-37 with dissolve
        ci "Yeah?"

        scene e5s14-38 with dissolve
        mc "A book fell out of your backpack."

        scene e5s14-39 with dissolve
        ci "Can you just put it back? I'm in a rush."

        scene e5s14-40 with dissolve
        mc "Yeah, don't worry about it."

        if e5s14_qte == False:
            scene e5s14-41 with dissolve
            mc "*Okay... book in left hand.*"
            mc "*Stick in right.*"

            scene e5s14-40 with dissolve
            mc "*Don't drop it. Don't drop it.*"
            mc "*God... almost there.*"

        scene e5s14-42 with dissolve
        pause

        scene e5s14-43 with dissolve
        mc "All set."

        scene e5s14-44 with dissolve
        ci "Thanks so much!"

        scene e5s14-45 with dissolve
        pause

        if e5s14_qte == True:
            scene e5s14-47 with dissolve
            mc "*That was clean.*"
            mc "*Almost too easy.*"
        else:
            scene e5s14-46 with dissolve
            mc "*She almost caught me.*"
            mc "*I can't screw up like that again.*"

        mc "*Appearances can be deceiving, huh?*"
    else:
        scene e5s14-24 with dissolve
        pause

        scene e5s14-29 with dissolve
        mc "*Come on, [mc]. Focus.*"

        scene e5s14-30 with dissolve
        mc "*Bingo!*"

        scene e5s14-25 with dissolve
        mc "*Jesus... my hands are shaking.*"

        scene e5s14-26 with dissolve
        pause

        scene e5s14-27 with dissolve
        pause

        scene e5s14-28 with dissolve
        pause

        scene e5s14-29 with dissolve
        mc "*Okay. Act normal.*"
        mc "*Let's hope that's the end of it.*"

        scene e5s14-31 with dissolve
        pause

        scene e5s14-32 with dissolve
        ci "Hey, [mc], I'd love to stay, but I've gotta run."
        ci "We'll talk later, okay?"

        scene e5s14-34 with dissolve
        show e5s14_claire_blink1
        mc "Okay, see you."

        scene e5s14-48 with dissolve
        hide e5s14_claire_blink1
        pause

        stop music fadeout 2.0
        scene e5s14-35 with dissolve
        pause

        scene e5s14-36 with dissolve
        mc "[ci], wait!"

        scene e5s14-37 with dissolve
        ci "Yeah?"

        scene e5s14-38 with dissolve
        mc "A book fell out of your backpack."

        scene e5s14-39 with dissolve
        ci "Can you just put it back? I'm in a rush."

        scene e5s14-40 with dissolve
        mc "Yeah, don't worry about it."

        scene e5s14-42 with dissolve
        pause

        scene e5s14-43 with dissolve
        mc "All set."

        scene e5s14-44 with dissolve
        ci "Thanks so much!"

        scene e5s14-45 with dissolve
        pause

        scene e5s14-47 with dissolve
        mc "*That was clean.*"
        mc "*Almost too easy.*"
        mc "*Appearances can be deceiving, huh?*"

    jump e5s15
return
