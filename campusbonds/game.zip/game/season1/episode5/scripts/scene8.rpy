
# Scene 8 - Cleo's dorm ########################################################

label e5s8:
    stop music fadeout 2.0
    scene e5s8-01 with wipeleft
    pause

    play music aces_high
    scene e5s8-02 with dissolve
    mc "I didn't know you liked computers."

    scene e5s8-03 with dissolve
    cl "I'm just filling up this form."

    scene e5s8-04 with dissolve
    mc "What's up?"
    mc "You don't look too happy."

    scene e5s8-05 with dissolve
    pause

    scene e5s8-06 with dissolve
    cl "Because I'm not."
    cl "They still won't give me a fucking dorm!"

    scene e5s8-05 with dissolve
    mc "Hey, calm down, I'm here."
    mc "Start from the beginning."

    scene e5s8-03 with dissolve
    cl "I went to the secretary's stupid office again."

    scene e5s8-08 with dissolve
    cl "Asked her about the incident and they still haven't figured it out yet."

    scene e5s8-06 with dissolve
    cl "What the hell is taking them so long?"
    cl "It's just a dorm for Christ's sake."

    scene e5s8-09 with dissolve
    cl "I am entitled to one just like everybody else."

    scene e5s8-07 with dissolve
    show e5s8_cleo_blink1
    mc "Damn... I'm sorry to hear that."
    mc "Did they give you a reason?"

    scene e5s8-09 with dissolve
    hide e5s8_cleo_blink1
    cl "Same as before, name mismatch."

    scene e5s8-07 with dissolve
    show e5s8_cleo_blink1
    mc "So, what? You won't get a dorm until that person leaves?"
    mc "It doesn't make any sense."

    scene e5s8-08 with dissolve
    hide e5s8_cleo_blink1
    cl "I know right?"

    scene e5s8-09 with dissolve
    cl "Something just... isn't right about all this."
    cl "Either I'm the unluckiest person in the world or someone has a sick sense of humor."

    scene e5s8-04 with dissolve
    mc "Okay, but... you still don't have a place, right?"

    scene e5s8-07 with dissolve
    show e5s8_cleo_blink1
    mc "Where are you gonna sleep?"

    if e5s3_stay == True:
        scene e5s8-10 with dissolve
        hide e5s8_cleo_blink1
        cl "I was... maybe thinking I could sleep at your dorm again."

        scene e5s8-11 with dissolve
        cl "Of course, It's okay if you can't, or you don't want to."
        cl "I'm not forcing you or anything..."
        cl "Just... asking."

        scene e5s8-07 with dissolve
        show e5s8_cleo_blink1
        menu:
            "Shelter [cl] at your dorm":
                $ e5s8_shelter_cleo = True
                $ cleo_trust += 1
                mc "Hey, don't worry about it."
                mc "Of course you can stay at my place."
                mc "I'm not going to just let you be homeless."

                scene e5s8-11 with dissolve
                hide e5s8_cleo_blink1
                cl "I'm really sorry for all the trouble."

                scene e5s8-10 with dissolve
                cl "It should have never gotten this far."

                scene e5s8-07 with dissolve
                show e5s8_cleo_blink1
                mc "It's okay, we'll figure this out."

                scene e5s8-12 with dissolve
                hide e5s8_cleo_blink1
                cl "Thank you so much!"

                scene e5s8-14 with dissolve
                pause

                scene e5s8-13 with dissolve
                pause

                if e3s24_cleo_path == True:
                    scene e5s8-15 with dissolve
                    pause

                    scene e5s8-16 with dissolve
                    pause

                    scene e5s8-17 with dissolve
                    pause

            "Let her find another place":
                $ cleo_trust -= 1
                mc "I... uh- I'm sorry [cl]."
                mc "My roommate didn't seem too happy last night."
                mc "I don't want problems, you know?"
                mc "Plus, if the college staff finds out, we're screwed."

                scene e5s8-18 with dissolve
                hide e5s8_cleo_blink1
                cl "Yeah... I guess you're right."

                scene e5s8-03 with dissolve
                cl "I'll try and talk to a friend, maybe she can help me."

                scene e5s8-07 with dissolve
                show e5s8_cleo_blink1
                mc "Tell me if it works out, okay?"

                scene e5s8-10 with dissolve
                hide e5s8_cleo_blink1
                cl "We'll see."
    else:
        scene e5s8-03 with dissolve
        hide e5s8_cleo_blink1
        cl "I'm not sure."
        cl "Last night I slept at a friend's dorm, but I don't want to keep disturbing her."

        scene e5s8-10 with dissolve
        cl "I guess I don't really have a choice."

        scene e5s8-08 with dissolve
        cl "She seems like she wants to help me, but I don't want her to think I'm taking advantage of her."

        scene e5s8-07 with dissolve
        show e5s8_cleo_blink1
        mc "I doubt that."
        mc "Why else would she help you?"

        scene e5s8-18 with dissolve
        hide e5s8_cleo_blink1
        cl "Maybe you're right."
        cl "Maybe I'm overthinking it right now."
        cl "It's just... really hard."

        scene e5s8-03 with dissolve
        cl "Anyway, thanks for listening to my rant."

        scene e5s8-19 with dissolve
        cl "Fuck the staff and fuck this college."

        scene e5s8-20 with dissolve
        cl "I'll get going now."
        cl "See you."

        scene e5s8-21 with dissolve
        mc "*Wow...*"

    jump e5f1
return
