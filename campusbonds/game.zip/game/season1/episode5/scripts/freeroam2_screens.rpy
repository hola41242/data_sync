
# Freeroam 2 screens ###########################################################

# Main #########################################################################
screen e5f2_main():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    if e5f2_cleo1 == False:
        add "e5f2-01"
    else:
        add "e5f2-01_1"

    # Clickables
    if e5f2_cleo1 == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/main/cleo_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/main/cleo_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_cleo1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_cleo1")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/main/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/main/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway1")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/main/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/main/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_left")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/main/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/main/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_right")

    # Collectibles
    if persistent.ev_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_6_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn6", True), Function(update_evelyn_list)]

# Left #########################################################################
screen e5f2_left():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    if e5s8_shelter_cleo == True:
        if e5f2_cleo1 == True:
            if e5f2_cleo_activity == True and e5f2_kettle == False:
                add "e5f2-02_2"
            else:
                add "e5f2-02"
        else:
            add "e5f2-02_2"
    else:
        add "e5f2-02_1"

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/left/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/left/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_main")

    # Clickables
    if e5s8_shelter_cleo == True:
        if e5f2_cleo1 == True:
            if e5f2_cleo_activity == True and e5f2_kettle == False:
                pass
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam2/left/bed2_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam2/left/bed2_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f2_bed")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f2_bed")
        else:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam2/left/bed1_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam2/left/bed1_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f2_bed")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f2_bed")
    else:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/left/bed1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/left/bed1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_bed")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_bed")

    if e5s8_shelter_cleo == True and e5f2_cleo1 == True and e5f2_cleo_activity == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/left/cleo_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/left/cleo_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_cleo2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_cleo2")

    if e5f2_guitar == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/left/guitar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/left/guitar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_guitar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_guitar")

    # Collectibles
    if persistent.ev_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_7_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn7", True), Function(update_evelyn_list)]

# Right ########################################################################
screen e5f2_right():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-03"

    # Clickables
    if e5f2_desk == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/right/desk_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/right/desk_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_desk")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_desk")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/right/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/right/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_main")

    # Collectibles
    if persistent.tf_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_7_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany7", True), Function(update_tiffany_list)]

# Hallway 1 ####################################################################
screen e5f2_hallway1():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-04"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway1/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway1/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_main")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway1/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway1/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway2")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway1/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway1/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway_middle")

    # Collectibles
    if persistent.tf_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway1/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway1/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_8_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany8", True), Function(update_tiffany_list)]

# Hallway 2 ####################################################################
screen e5f2_hallway2():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-05"

    # Clickables
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway2/tracy_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway2/tracy_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_tracy")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_tracy")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway2/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway2/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway1")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway2/hallway3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway2/hallway3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway3")

    # Collectibles
    if persistent.tr_gallery_15_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway2/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway2/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_15_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_15_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy15", True), Function(update_tracy_list)]

# Hallway 3 ####################################################################
screen e5f2_hallway3():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-06"

    # Clickables
    if e5f2_cleo_activity == True and e5f2_jordan == False and e5f2_kettle == False and e5f2_ken == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway3/jordan_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway3/jordan_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_jordan")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_jordan")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway3/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway3/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway2")

    # Collectibles
    if persistent.tr_gallery_16_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway3/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway3/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_16_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_16_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy16", True), Function(update_tracy_list)]

# Hallway Middle ####################################################################
screen e5f2_hallway_middle():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-07"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway1")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway_right")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway_middle/hallway_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway_left")

    # Collectibles
    if persistent.cl_gallery_15_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway_middle/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway_middle/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_15_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_15_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo15", True), Function(update_cleo_list)]

# Hallway Left ####################################################################
screen e5f2_hallway_left():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-08"

    # Clickables
    if e5f2_cleo_activity == True and e5f2_ken == False and e5f2_kettle == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway_left/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway_left/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_ken")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway_left/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway_left/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway_middle")

    # Collectibles
    if persistent.sd_gallery_15_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway_left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway_left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_15_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_15_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie15", True), Function(update_sadie_list)]

# Hallway Right ####################################################################
screen e5f2_hallway_right():

    $ renpy.random.shuffle(e5f2_tracks)
    modal True

    add "e5f2-09"

    # Clickables
    if e5f2_cleo_activity == True and e5f2_kettle == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway_right/stranger_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway_right/stranger_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f2_stranger")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f2_stranger")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam2/hallway_right/hallway_middle_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam2/hallway_right/hallway_middle_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f2_hallway_middle")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f2_hallway_middle")

    # Collectibles
    if persistent.sd_gallery_16_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam2/hallway_right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam2/hallway_right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_16_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_16_unlocked", True), SetVariable("persistent.e5f2_collected_p", persistent.e5f2_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie16", True), Function(update_sadie_list)]
