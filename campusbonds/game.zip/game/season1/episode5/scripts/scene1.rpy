
# Scene 1 - Backup Plan (Sunday) ###############################################

label e5s1:
    $ renpy.block_rollback()
    $ config.rollback_enabled = False

    hide screen recap_skip

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    $ config.rollback_enabled = True

    play music flowers
    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e5s1-01 with Dissolve(2.0)
    mc "So... what do you say?"

    scene e5s1-02 with dissolve
    ci "Guys, while this sounds very flattering and all..."

    scene e5s1-03 with dissolve
    ci "I don't think I can run for the presidency."

    scene e5s1-04 with dissolve
    jon "Why not?"

    scene e5s1-05 with dissolve
    ci "I never really wanted this, my main focus was always on the cheerleaders."

    scene e5s1-04 with dissolve
    jon "Yeah, but... it's for the greater good!"

    scene e5s1-06 with dissolve
    mc "We need you, [ci]."

    scene e5s1-07 with dissolve
    jon "Who else is gonna run? Me or [mc]?"

    scene e5s1-04 with dissolve
    jon "Be serious now, you know we're not made for that."

    if affinity_spectrum > 0:
        scene e5s1-06 with dissolve
        mc "Us? Presidents? We'd be like chipmunks with machine guns."

        scene e5s1-04 with dissolve
        jon "Exactly! That's what I'm saying."

    scene e5s1-05 with dissolve
    ci "I get it, I seriously do."

    scene e5s1-02 with dissolve
    ci "But what do you want me to do?"

    scene e5s1-03 with dissolve
    ci "I don't have a lot of experience with this, how am I going to put up a fight with the big dogs?"

    scene e5s1-04 with dissolve
    jon "That's why we are a team, right?"

    scene e5s1-08 with dissolve
    jon "We will help you get on track and learn whatever it is you need to do."

    scene e5s1-05 with dissolve
    ci "I'll have to think about it, okay?"
    ci "I don't want to say anything right now."

    scene e5s1-02 with dissolve
    ci "Maybe I can also talk to the girls and see what they think about it."

    scene e5s1-06 with dissolve
    mc "Not trying to force you or anything, but we're kind of in a rush."
    mc "I think you know that too."

    scene e5s1-05 with dissolve
    ci "I know..."

    scene e5s1-02 with dissolve
    ci "I just need to make up my mind, alright?"

    scene e5s1-03 with dissolve
    ci "I have a lot on my plate already."

    scene e5s1-08 with dissolve
    jon "Okay, we'll leave you the time to prepare."

    scene e5s1-02 with dissolve
    ci "Thanks!"

    scene e5s1-03 with dissolve
    ci "Now, if you'll excuse me, I've got some things to organize."

    scene e5s1-09 with dissolve
    pause

    jump e5s2
return
