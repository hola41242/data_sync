
# Scene 6 - Who's the president? ###############################################

label e5s6:
    stop music fadeout 2.0
    scene e5s6-01 with wipeleft
    pause

    play music welcome_to_zombie_coast
    scene e5s6-02 with vpunch
    ci "You always do this!"
    ch "Me? You're the one who's always against everything."

    scene e5s6-03 with dissolve
    pause

    scene e5s6-04 with dissolve
    pause

    scene e5s6-05 with dissolve
    jon "Oh for Christ's sake, you're finally here."

    scene e5s6-07 with dissolve
    jon "I don't know what to do!"

    scene e5s6-08 with dissolve
    jon "They started arguing, and they're still going at it, and they won't stop!"

    scene e5s6-06 with dissolve
    show e5s6_jon_blink1
    mc "Did you really call me for this?"
    mc "Why are they arguing in the first place? Do they know each other?"

    scene e5s6-09 with dissolve
    hide e5s6_jon_blink1
    jon "Yeah brother, holy shit it goes deeper than that."

    scene e5s6-08 with dissolve
    jon "So, you know that [ci] is the vice-president of the cheerleaders, right?"

    scene e5s6-06 with dissolve
    show e5s6_jon_blink1
    mc "Right."

    scene e5s6-07 with dissolve
    jon "Well, [ch] IS the fucking president!"

    scene e5s6-06 with dissolve
    show e5s6_jon_blink1
    mc "What? No way."
    mc "She's the president president? Like, the actual head of the squad?"

    scene e5s6-10 with dissolve
    hide e5s6_jon_blink1
    jon "Yes! The queen bee, the big boss, the one with all the keys to the cheer kingdom."

    scene e5s6-08 with dissolve
    jon "I just mentioned pushing [ci] to run up for the elections, big mistake."

    scene e5s6-10 with dissolve
    jon "Now they started arguing about their fucking politics and rules."

    scene e5s6-09 with dissolve
    jon "They don't agree with a single thing I swear."

    scene e5s6-06 with dissolve
    show e5s6_jon_blink1
    mc "How the fuck is she the petty president?"
    mc "I thought she was chill."

    scene e5s6-10 with dissolve
    hide e5s6_jon_blink1
    jon "I thought so too! But they are both so delusional, I don't even know who to trust at this point."

    scene e5s6-06 with dissolve
    show e5s6_jon_blink1
    mc "I don't get it, we got bigger fish to fry. What's the point of arguing if there will be no clubs to argue about?"
    mc "We still don't have anything against [kv] and if he wins the elections we're cooked."

    scene e5s6-12 with dissolve
    hide e5s6_jon_blink1
    jon "I know that, but..."

    scene e5s6-13 with dissolve
    jon "Wait, that's it! I know how to break them apart."

    scene e5s6-14 with dissolve
    mc "You really didn't try this?"

    scene e5s6-09 with dissolve
    jon "Fuck man, I tried everything, I don't know how this didn't cross my mind."

    scene e5s6-07 with dissolve
    jon "I got so fed up of everything I stopped thinking."

    scene e5s6-15 with dissolve
    ci "Yeah? And what the fuck do you know?"
    ci "Most girls want me as the president anyway."

    scene e5s6-11 with dissolve
    ch "You mean the girls you brainwashed?"
    ch "You can't even lead yourself, let alone an entire cheerleading squad."

    scene e5s6-16 with dissolve
    jon "Yo, yo, girls!"

    scene e5s6-17 with dissolve
    jon "Hey, chill, chill."
    jon "Look, I found the fix to all our problems."

    scene e5s6-18 with dissolve
    jon "..."

    scene e5s6-19 with dissolve
    ci "Well, what is it?"

    scene e5s6-20 with dissolve
    jon "Why the hell are we still arguing if we won't have any clubs to argue about?"
    jon "Think about it, leave the differences aside."
    jon "If [kv] wins this election it's shut down for everybody."

    scene e5s6-21 with dissolve
    ci "It's not like the cheerleaders were doing so well anyway."

    scene e5s6-22 with dissolve
    ci "Especially with her in the front."

    scene e5s6-23 with dissolve
    jon "Hey, stop! I said no more arguing."

    scene e5s6-20 with dissolve
    jon "She can be the president of her city while you're going to be the president of the whole country."
    jon "How does that sound?"

    scene e5s6-24 with dissolve
    ci "Now that you put it like that..."

    scene e5s6-25 with dissolve
    ch "Gosh, you only care about yourself."

    scene e5s6-26 with dissolve
    ch "But this still doesn't give us the fix, how are we going to beat [kv]?"
    ch "She certainly won't cut it."

    scene e5s6-27 with dissolve
    jon "You guys said you have access to his candidature, right?"
    jon "Like you're planning his shit."

    scene e5s6-28 with dissolve
    jon "Maybe get some info on him, see his weaknesses and act against them."

    scene e5s6-20 with dissolve
    jon "We can start preparing [ci] for the role."

    scene e5s6-29 with dissolve
    ch "Well... I guess it's worth a shot."
    ch "If it's as bad as you say it is, we don't have anything to lose anyway."

    if e4s29_sweet == True:
        jump e5s7
    else:
        jump e5s8
return
