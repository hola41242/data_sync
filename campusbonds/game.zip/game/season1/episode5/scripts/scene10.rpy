
# Scene 10 - Coffee with Tracy #################################################

label e5s10:
    stop music fadeout 2.0
    if e4s5_tracy_path_throw == True:
        scene e5s10-01 with wipeleft
        pause

        play music inertia
        scene e5s10-02 with dissolve
        pause

        scene e5s10-03 with dissolve
        mc "You got a minute?"

        scene e5s10-05 with dissolve
        tr "What's up?"

        scene e5s10-04 with dissolve
        mc "I was just thinking maybe we could talk?"
        mc "We can't keep acting like we don't know each other, right?"

        scene e5s10-06 with dissolve
        tr "Alright then."

        scene e5s10-04 with dissolve
        mc "Alright? You're not mad?"

        scene e5s10-07 with dissolve
        tr "I am mad, but you're right."

        scene e5s10-04 with dissolve
        mc "Wanna go grab a coffee for this?"

        scene e5s10-06 with dissolve
        tr "Lead the way."

        scene e5s10-08 with dissolve
        pause

        scene e5s10-09 with wipeleft
        show e5s10_tracy_blink1
        mc "I guess I should start, huh?"

        scene e5s10-10 with dissolve
        hide e5s10_tracy_blink1
        tr "I guess you should."

        scene e5s10-09 with dissolve
        show e5s10_tracy_blink1
        menu:
            "Stay friends with benefits":
                $ e5s10_fwb = True
                mc "Look... I'm not sure how this'll sit with you, but..."
                mc "I enjoy spending time with you, right?"
                mc "I liked the intimate moments we had... and that's about it."
                mc "I'm not looking for anything serious at the moment."
                mc "I like that you're crazy, and that you like to party, and I'd like things to remain exactly this way."
                mc "I'm really sorry if this breaks your heart, or if you expected more from me."

                scene e5s10-11 with dissolve
                hide e5s10_tracy_blink1
                tr "The most painful thing is that you led me to believe there could be more."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Yeah... I guess I was wrong about that."
                mc "I wasn't sure how this thing would go on."
                mc "I thought that if I lied about having feelings, we'd continue to mess around."
                mc "It was a really, really stupid decision."
                mc "And very selfish of me."

                scene e5s10-12 with dissolve
                hide e5s10_tracy_blink1
                tr "Mhm..."

                scene e5s10-13 with dissolve
                tr "I'm not usually a jealous person, but what you did with [sd]..."

                scene e5s10-11 with dissolve
                tr "It was really shitty. Especially that you told me you had no feelings for her."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Yeah... it was really shitty of me to do that."
                mc "I'm not trying to excuse myself."

                scene e5s10-11 with dissolve
                hide e5s10_tracy_blink1
                tr "Even if it was stupid, at least this thing between us didn't last too long."
                tr "In the end you chose what was right for you."

                scene e5s10-14 with dissolve
                tr "But please, please, just... stop messing around like that, okay?"

                scene e5s10-15 with dissolve
                tr "People have feelings and it's not fair."

                scene e5s10-10 with dissolve
                tr "Imagine if this thing was the other way around, imagine your favorite girl did this to you."
                tr "You wouldn't like it, would you?"

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "..."
                mc "You're right... I wouldn't."
                mc "Now I feel terrible about it."

                scene e5s10-11 with dissolve
                hide e5s10_tracy_blink1
                tr "I'm not sure how I feel right now."
                tr "I don't know if things can ever go back to how they were."

                scene e5s10-12 with dissolve
                pause

                scene e5s10-13 with dissolve
                tr "I think I just need some time to process and heal from all this."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Yeah, I think we both need some time away from each other."
                mc "But I'm glad we had this talk."

                scene e5s10-11 with dissolve
                hide e5s10_tracy_blink1
                tr "Me too. If I'm being honest, I didn't wanna see you again, but this helped a bit."

                scene e5s10-12 with dissolve
                mc "We couldn't have avoided it forever."
                mc "Better have the uncomfortable talk now rather than being awkward any time we bumped into each other."

                scene e5s10-11 with dissolve
                tr "Yeah..."

            "Break things off with [tr]":
                $ e5s10_breakup = True
                mc "Look... I'm sorry it got to this point."
                mc "I don't want to hurt you further, so I'll just go ahead and say it."
                mc "I'm sorry for leading you on, I actually enjoyed our moments."
                mc "But I'm not sure how I feel about you."

                scene e5s10-15 with dissolve
                hide e5s10_tracy_blink1
                tr "Then why did you tell me you had feelings for me?"

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "I don't know, I was stupid, alright?"
                mc "It was just a crush, but I don't know if I liked you for you or for your body."
                mc "I know how shitty that sounds, I'm a shit person."
                mc "I'm sorry for hurting your feelings."

                scene e5s10-16 with dissolve
                hide e5s10_tracy_blink1
                tr "That was shitty, you know?"
                tr "I actually thought you liked me."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Yeah..."

                scene e5s10-11 with dissolve
                hide e5s10_tracy_blink1
                tr "It was even more painful when I saw you with [sd]."

                scene e5s10-12 with dissolve
                mc "I don't really know what to say right now."

                scene e5s10-13 with dissolve
                tr "Maybe I deserved it."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Why do you say that?"

                scene e5s10-14 with dissolve
                hide e5s10_tracy_blink1
                tr "I caused a couple of heartbreaks myself."

                scene e5s10-11 with dissolve
                tr "I never thought about how it felt."
                tr "I guess you never do unless it happens to you."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "So... you're not mad?"

                scene e5s10-15 with dissolve
                hide e5s10_tracy_blink1
                tr "Of course I'm mad, I'm pissed."

                scene e5s10-14 with dissolve
                tr "But I can't force you to love me, right?"
                tr "I don't think I'd want that."

                scene e5s10-10 with dissolve
                tr "At least you've been honest for once."

                scene e5s10-09 with dissolve
                show e5s10_tracy_blink1
                mc "Yeah..."

        scene e5s10-17 with dissolve
        hide e5s10_tracy_blink1
        pause

        scene e5s10-18 with dissolve
        mc "*That was... something.*"

    jump e5s11
return
