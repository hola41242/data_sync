
# Scene 11 - Pool slip up ######################################################

label e5s11:
    stop music fadeout 2.0
    scene e5s11-01 with wipeleft
    pause

    play music travel_light
    scene e5s11-02 with dissolve
    mc "Are you playing pool alone?"

    scene e5s11-03 with dissolve
    ch "Huh?"

    scene e5s11-04 with dissolve
    mc "Sorry, didn't mean to startle you."

    scene e5s11-06 with dissolve
    ch "I'm just exercising my shots."
    ch "The club I usually go to is closed this week, I asked [jon] if I could use this table."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "Haha, I remember you asking me to play pool with you at one of our parties."
    mc "Come to think of it, you even made fun of me back then."

    scene e5s11-08 with dissolve
    hide e5s11_charlie_blink1
    ch "Haha, yeah, I remember."
    ch "You looked so clueless."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "How come you girls didn't visit us again?"

    scene e5s11-07 with dissolve
    hide e5s11_charlie_blink1
    ch "You never asked?"

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "What do you mean we didn't?"
    mc "We talked to [ci] and she said you were against it."
    mc "Come to think of it, why wouldn't you let the girls party with us?"

    scene e5s11-09 with dissolve
    hide e5s11_charlie_blink1
    ch "Huh? I never said no to that. What's that about?"
    ch "I remember thoroughly enjoying that party."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "She said you were worried it'd look bad... that you'd kick them out if they kept partying."

    scene e5s11-10 with dissolve
    hide e5s11_charlie_blink1
    ch "That little shit!"

    scene e5s11-11 with dissolve
    ch "What else did she say?"

    scene e5s11-12 with dissolve
    mc "*Fuck... maybe I shouldn't have said that.*"
    mc "*I'm not sure saying more is the way to go.*"
    mc "*They'll probably start hating each other, but I might get on [ch]'s good side for this.*"

    scene e5s11-13 with dissolve
    show e5s11_charlie_blink2
    menu:
        "Tell [ch] everything":
            $ charlie_trust += 1
            mc "A lot of stuff, actually."
            mc "She said you're not really showing up to the cheerleaders..."
            mc "That she talked to you about parties but you said no multiple times..."

            scene e5s11-14 with dissolve
            hide e5s11_charlie_blink2
            ch "That's why everyone stopped talking to me..."
        "Change the subject":
            $ charlie_trust -= 1
            $ claire_trust += 1
            mc "Maybe we should get back on the [kv] situation..."

            scene e5s11-11 with dissolve
            hide e5s11_charlie_blink2
            ch "Oh, don't even try to twist it."

            scene e5s11-15 with dissolve
            ch "I'm not even sure who's side you're on."
        "Stay silent":
            mc "..."

    scene e5s11-10 with dissolve
    hide e5s11_charlie_blink2
    ch "Alright, this is enough, I've been calm for way too long."

    scene e5s11-14 with dissolve
    ch "I need to get back at her."
    ch "I didn't want it to be like this, but she's left me no choice."

    scene e5s11-13 with dissolve
    show e5s11_charlie_blink2
    mc "Come on, there's no need for that, we've got to win an election."

    scene e5s11-16 with dissolve
    hide e5s11_charlie_blink2
    ch "You're right... it shouldn't come from me."

    scene e5s11-17 with dissolve
    ch "Could you do me a favour?"

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "I'm not doing anything that might make her hate me or you."

    scene e5s11-06 with dissolve
    hide e5s11_charlie_blink1
    ch "She already hates me."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "Yeah but she might not go for presidency anymore."

    scene e5s11-18 with dissolve
    hide e5s11_charlie_blink1
    ch "Then, if you don't do it, I'll make sure she definitely doesn't go for presidency."

    scene e5s11-19 with dissolve
    ch "Are you willing to risk it?"

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "..."
    mc "For fuck's sake..."
    mc "You guys are gonna be the end of me."
    mc "Promise me we're done after this."

    scene e5s11-19 with dissolve
    hide e5s11_charlie_blink1
    ch "Yeah, for sure, I just want to get my revenge."

    scene e5s11-18 with dissolve
    ch "She's the one who started it after all."

    scene e5s11-17 with dissolve
    ch "It's pretty easy actually, you just need to switch a thumb drive."

    scene e5s11-07 with dissolve
    ch "She has her class presentation in a few days, try to get close to her, she always keeps it inside her bag."

    scene e5s11-06 with dissolve
    ch "You don't even have to worry about it."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "What if she catches me?"

    scene e5s11-19 with dissolve
    hide e5s11_charlie_blink1
    ch "She won't if you're being careful."

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "Oh my God..."

    scene e5s11-07 with dissolve
    hide e5s11_charlie_blink1
    ch "I'll let you know if it worked, alright?"

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "Yeah... okay."

    scene e5s11-17 with dissolve
    hide e5s11_charlie_blink1
    ch "So, are you up for some pool?"

    scene e5s11-05 with dissolve
    show e5s11_charlie_blink1
    mc "I think I'm fine, just let me know when you have the stick ready."

    scene e5s11-19 with dissolve
    hide e5s11_charlie_blink1
    ch "Alright, we'll keep in touch."

    scene e5s11-20 with dissolve
    mc "*What have I gotten myself into?*"

    scene e5s11-21 with dissolve
    pause

    scene e5s11-22 with dissolve
    pause

    jump e5s12
return
