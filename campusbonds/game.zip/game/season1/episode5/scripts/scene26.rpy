
# Scene 26 - A party at Jon's place. (Second choice) ###########################

label e5s26:
    stop music fadeout 2.0
    scene e5s26-01 with wipeleft
    pause

    play music area_51
    scene e5s26-03 with dissolve
    mc "Yo, what's going on?"

    scene e5s26-04 with dissolve
    jon "[mc]! There you are."
    jon "Join us."

    scene e5s26-02 with dissolve
    show e5s26_jon_blink1
    mc "I thought we were discussing plans."

    scene e5s26-05 with dissolve
    hide e5s26_jon_blink1
    jon "This IS the plan."

    scene e5s26-06 with dissolve
    jon "There's no work to be done tonight, buddy, come on in."

    scene e5s26-02 with dissolve
    show e5s26_jon_blink1
    mc "When was this even planned?"

    scene e5s26-07 with dissolve
    hide e5s26_jon_blink1
    jon "It wasn't."

    scene e5s26-08 with dissolve
    jon "I happened to be sitting on my couch one day and wondered..."

    scene e5s26-09 with dissolve
    jon "Hey, we haven't had a party in quite some time."

    scene e5s26-07 with dissolve
    jon "So why not throw one here?"

    scene e5s26-06 with dissolve
    jon "We would have used the 'other' place, but Bridget's a pain in the ass."

    scene e5s26-09 with dissolve
    jon "We can't risk anything right now."

    scene e5s26-02 with dissolve
    show e5s26_jon_blink1
    mc "Damn, I forgot how crowded this place was."

    scene e5s26-06 with dissolve
    hide e5s26_jon_blink1
    jon "Grab a drink and let's have fun."

    if e4s5_date == True:
        scene e5s26-12 with dissolve
        mc "Is [sd] here?"

        scene e5s26-11 with dissolve
        jon "No, she told me she didn't want to come."
        jon "You guys don't talk anymore?"

        scene e5s26-10 with dissolve
        mc "No, we do... it's complicated."
        mc "Maybe I'll tell you later."

        scene e5s26-04 with dissolve
        jon "You're the boss."

    scene e5s26-12 with dissolve
    pause

    scene e5s26-13 with dissolve
    mc "*Wait, maybe I should also call [nt].*"
    mc "*He used to like parties.*"

    if e5s8_shelter_cleo == True:
        mc "*Besides, maybe I could make it up to him for having [cl] over.*"
        mc "*He seemed a bit bothered by it.*"

    scene e5s26-14 with dissolve
    pause

    scene e5s26-15 with dissolve
    mc "Yo, you up?"

    scene e5s26-14 with dissolve
    nt "What's up?"

    scene e5s26-15 with dissolve
    mc "So, we're having a party at a friend's place."

    scene e5s26-16 with dissolve
    mc "I was wondering if you'd be down for it."

    scene e5s26-14 with dissolve
    nt "Idk, it's a bit late."

    scene e5s26-15 with dissolve
    mc "Come on, man, you'll have fun."
    mc "Trust me."

    scene e5s26-14 with dissolve
    nt "Alright, I guess I could."

    scene e5s26-16 with dissolve
    mc "Awesome, I'll send you the location."
    mc "See you!"

    scene e5s26-17 with dissolve
    pause

    call e5f3 from _call_e5f3

    if e5f3_roman_prank == True:
        if e5f3_tracy_choice == True:
            stop music fadeout 2.0
            scene e5s26-18 with wipeleft
            ro "Alright, guys, there's our target."

            play music orbiting_a_distant_planet
            scene e5s26-19 with dissolve
            mc "So, what did you have in mind?"

            scene e5s26-20 with dissolve
            ro "Well, it's easy."

            scene e5s26-21 with dissolve
            ro "We're gonna have the girl walk up to him and provoke him."
            ro "So when he inevitably flirts back, she rejects him."

            scene e5s26-22 with dissolve
            mc "What makes you think he'll flirt back?"

            scene e5s26-23 with dissolve
            ro "Look at him dude, a guy like him gets no play."

            scene e5s26-19 with dissolve
            ro "He'll jump on the opportunity 100 percent."

            scene e5s26-24 with dissolve
            mc "You ready, [tr]?"

            scene e5s26-25 with dissolve
            tr "I'm ready, but just to be clear, I'm not touching that guy."

            scene e5s26-26 with dissolve
            ro "Don't worry, you just have to talk to him."
            ro "It's going to be enough."

            scene e5s26-27 with dissolve
            ro "This is gonna be so fun!"
            ro "[jon]'s gonna wanna see this."

            scene e5s26-28 with dissolve
            pause

            scene e5s26-29 with dissolve
            mc "Yo, wait, we're recording this?"

            scene e5s26-30 with dissolve
            ro "Of course, dude."
            ro "No one's gonna believe this if we don't."

            scene e5s26-29 with dissolve
            mc "Are you sure?"

            scene e5s26-38 with dissolve
            ro "Yeah, don't worry about it."
            ro "Just play along."

            scene e5s26-30 with dissolve
            ro "Now, shut up, don't mess up the video."

            scene e5s26-31 with dissolve
            mc "*I don't have a good feeling about this.*"

            scene e5s26-32 with dissolve
            pause

            scene e5s26-33 with dissolve
            tr "Oh! Excuse me... [kv], right? From campus?"

            scene e5s26-34 with dissolve
            kv "Yeah, that's me. What's up? You lost or something?"

            scene e5s26-35 with dissolve
            tr "I've seen you around. Honestly, it's kind of hard to ignore someone with... your presence."

            scene e5s26-36 with dissolve
            kv "Well, you know, I try to keep a low profile, but genius is hard to hide."

            scene e5s26-37 with dissolve
            kv "What's a gorgeous girl like you doing out here all alone?"

            scene e5s26-38 with dissolve
            ro "Look at this absolute clown. He's actually doing it."

            scene e5s26-39 with dissolve
            pause

            scene e5s26-40 with dissolve
            pause

            scene e5s26-41 with vpunch
            pause

            scene e5s26-43 with dissolve
            ro "Ouch! What's going on over there?"

            scene e5s26-42 with dissolve
            mc "Looks like it's over, she's coming back."

            scene e5s26-44 with dissolve
            ro "Yo, what happened?"

            scene e5s26-45 with dissolve
            tr "That little pervert tried to grab my ass."

            scene e5s26-24 with dissolve
            mc "What? No way."

            scene e5s26-46 with dissolve
            ro "Maybe you overdid it."

            scene e5s26-47 with dissolve
            tr "Overdid it? That guy was starving."
            tr "I gave him one compliment, and he started planning his future with me."

            scene e5s26-45 with dissolve
            tr "God damn, remind me never to come with you guys again."

            scene e5s26-26 with dissolve
            ro "Well, it's all good, 'cause I got exactly what I wanted."

            scene e5s26-21 with dissolve
            ro "Let's move before someone sees us."

            scene e5s26-48 with dissolve
            pause

            stop music fadeout 2.0
            scene black with Dissolve(2.0)

            scene e5s26-70 with dissolve
            pause

            scene e5s26-71 with dissolve
            pause
        else:
            if e5f3_ruby_choice == True:
                stop music fadeout 2.0
                scene e5s26-49 with wipeleft
                ro "Alright, guys, there's our target."

                play music orbiting_a_distant_planet
                scene e5s26-19 with dissolve
                mc "So, what did you have in mind?"

                scene e5s26-50 with dissolve
                ro "Well, it's easy."

                scene e5s26-21 with dissolve
                ro "We're gonna have the girl walk up to him and provoke him."
                ro "So when he inevitably flirts back, she rejects him."

                scene e5s26-22 with dissolve
                mc "What makes you think he'll flirt back?"

                scene e5s26-23 with dissolve
                ro "Look at him dude, a guy like him gets no play."

                scene e5s26-19 with dissolve
                ro "He'll jump on the opportunity 100 percent."

                scene e5s26-26 with dissolve
                ro "So, are you ready?"

                scene e5s26-51 with dissolve
                ru "I'm always ready for this."

                scene e5s26-52 with dissolve
                pause

                scene e5s26-53 with dissolve
                pause

                scene e5s26-27 with dissolve
                ro "This is gonna be so fun!"
                ro "[jon]'s gonna wanna see this."

                scene e5s26-28 with dissolve
                pause

                scene e5s26-29 with dissolve
                mc "Yo, wait, we're recording this?"

                scene e5s26-30 with dissolve
                ro "Of course, dude."
                ro "No one's gonna believe this if we don't."

                scene e5s26-29 with dissolve
                mc "Are you sure?"

                scene e5s26-38 with dissolve
                ro "Yeah, don't worry about it."
                ro "Just play along."

                scene e5s26-30 with dissolve
                ro "Now, shut up, don't mess up the video."

                scene e5s26-31 with dissolve
                mc "*I don't have a good feeling about this.*"

                scene e5s26-54 with dissolve
                pause

                scene e5s26-55 with dissolve
                ru "Hey! You're [kv], right?"

                scene e5s26-56 with dissolve
                kv "Yeah, that's me. What's up? You lost or something?"

                scene e5s26-57 with dissolve
                ru "I can see why! You have such a... unique feel."

                scene e5s26-58 with dissolve
                ru "I was just telling my friends that you look like someone who really knows how to have a good time."

                scene e5s26-59 with dissolve
                kv "A good time, huh?"

                scene e5s26-38 with dissolve
                ro "Look at this absolute clown. He's actually doing it."

                scene e5s26-60 with dissolve
                pause

                scene e5s26-61 with dissolve
                pause

                scene e5s26-62 with vpunch
                pause

                scene e5s26-43 with dissolve
                ro "Ouch! Haha, what did he do?"

                scene e5s26-63 with dissolve
                mc "Looks like it's over, she's coming back."

                scene e5s26-64 with dissolve
                ro "Yo, what happened?"

                scene e5s26-65 with dissolve
                ru "He called me a bitch, that's what he did!"
                ru "He grabbed my ass, and when I offered him a good time for money, he turned me down."

                scene e5s26-66 with dissolve
                mc "You know you only had to pretend, right?"
                mc "You didn't actually have to go fishing for customers or make an offer."

                scene e5s26-67 with dissolve
                ru "Wait, really? You didn't tell me that beforehand."
                ru "I thought you wanted me to sleep with your friend or something like that."

                scene e5s26-26 with dissolve
                ro "Well, it's all good, 'cause I got exactly what I wanted."

                scene e5s26-21 with dissolve
                ro "Let's move before someone sees us."

                scene e5s26-68 with dissolve
                pause

                stop music fadeout 2.0
                scene black with Dissolve(2.0)

                scene e5s26-69 with dissolve
                pause

                scene e5s26-72 with dissolve
                pause

        play music did_it_and_quit_it
        scene e5s26-73 with dissolve
        play sound door_close
        pause

        scene e5s26-74 with dissolve
        pause

        scene e5s26-75 with dissolve
        jon "Yo, where were you guys?"

        scene e5s26-77 with dissolve
        ro "It's best if I just show you."

        scene e5s26-78 with dissolve
        pause

        scene e5s26-79 with dissolve
        pause

        scene e5s26-80 with dissolve
        jon "Damn, you guys went and pranked [kv]?"

        scene e5s26-81 with dissolve
        jon "I kind of regret not being there."

        scene e5s26-76 with dissolve
        mc "What were you up to, anyway?"

        scene e5s26-82 with dissolve
        jon "Just some business, don't worry about it."

        scene e5s26-83 with dissolve
        pause

        if affinity_spectrum > 0:
            scene e5s26-85 with dissolve
            ro "'Business' he calls it."

            scene e5s26-87 with dissolve
            mc "Is little [jon] here shy?"
        else:
            scene e5s26-84 with dissolve
            ro "'Business' he calls it."

        scene e5s26-86 with dissolve
        jon "No, it's nothing like that."

        scene e5s26-88 with dissolve
        jon "I promised her I wouldn't brag about it or anything."
        jon "Just... don't tell anyone, alright?"

        stop music
        scene e5s26-89 with vpunch
        play sound knock_knock
        pause

        scene e5s26-90 with dissolve
        jon "Did you guys order anything?"

        scene e5s26-91 with dissolve
        mc "Uh... no. I thought you did."

        scene e5s26-92 with dissolve
        jon "Who could be at the door this time of night?"

        play music coalescense
        scene e5s26-93 with dissolve
        jon "Hello, may I help you?"

        scene e5s26-94 with dissolve
        unknown "Good evening. We received a few calls regarding a disturbance in this area tonight."

        scene e5s26-95 with dissolve
        pause

        scene e5s26-96 with dissolve
        ro "Dude... they already found us?"

        scene e5s26-97 with vpunch
        mc "Shut up, [ro]! Just look natural!"

        scene e5s26-98 with dissolve
        jon "A disturbance, officer? We've just been hanging out here, keeping things pretty low-key."

        scene e5s26-100 with dissolve
        unknown "Look, kids, I couldn't care less about your party."
        unknown "I've had some in my time too, but your neighbors definitely care about the bass vibrating through their floorboards for the last four hours."

        scene e5s26-101 with dissolve
        unknown "Turn the music down, keep the shouting to a minimum, and clear out the extra guests, or the next visit comes with a hefty fine. Understood?"

        scene e5s26-99 with dissolve
        jon "Absolutely, officer. Loud and clear. We'll shut it down right now."

        scene e5s26-94 with dissolve
        unknown "Good. Have a safe night."

        stop music fadeout 2.0
        scene e5s26-102 with dissolve
        pause

        scene e5s26-92 with dissolve
        pause

        scene e5s26-103 with dissolve
        jon "Oh my God, I thought they came here because of you."

        scene e5s26-105 with dissolve
        ro "Damn, man, I thought so too."

        scene e5s26-104 with dissolve
        mc "You're an idiot, [ro]. I told you it wasn't a good idea."

        scene e5s26-106 with dissolve
        ro "We didn't get caught, did we?"
        ro "Just relax, man, everything is going exactly as planned."

        scene e5s26-107 with dissolve
        pause

        scene e5s26-108 with dissolve
        pause

        scene e5s26-109 with dissolve
        mc "*Huh? Another knock?*"

        scene e5s26-110 with dissolve
        pause

        scene e5s26-111 with dissolve
        mc "Yo, you came!"

        scene e5s26-112 with dissolve
        nt "Yeah, what's up, dude?"

        scene e5s26-113 with dissolve
        mc "Come on in."

        scene e5s26-114 with dissolve
        pause

        scene e5s26-115 with dissolve
        pause

        scene e5s26-116 with dissolve
        sc "Haha, look who's here!"

        scene e5s26-117 with dissolve
        nt "[sc]?"

        scene e5s26-118 with dissolve
        nt "Why didn't you tell me she's here?"

        scene e5s26-119 with dissolve
        mc "Wait, you guys know each other?"

        scene e5s26-120 with dissolve
        sc "If we know each other?"

        scene e5s26-121 with dissolve
        sc "This guy is a creep."

        scene e5s26-122 with dissolve
        nt "Damn it, I knew I shouldn't have come..."

        scene e5s26-119 with dissolve
        mc "No, no, wait man."
        mc "What's going on?"

        scene e5s26-121 with dissolve
        sc "Nothing, right [nt]?"

        scene e5s26-123 with dissolve
        nt "..."

        scene e5s26-124 with dissolve
        pause

        scene e5s26-121 with dissolve
        sc "We're just having a party [nt] wasn't invited to."

        scene e5s26-125 with dissolve
        mc "I invited him."

        scene e5s26-126 with dissolve
        sc "Oh, you're funny."

        scene e5s26-127 with dissolve
        mc "[sc], what's going on with you?"
        mc "Why have you been drinking so much lately?"

        scene e5s26-128 with dissolve
        sc "Oh, look at him, worrying for me."
        sc "Isn't that cute?"

        scene e5s26-129 with dissolve
        sc "Don't worry pretty, I'll be fine."

        scene e5s26-130 with dissolve
        pause

        scene e5s26-131 with dissolve
        pause

        scene e5s26-132 with dissolve
        pause

        scene e5s26-133 with dissolve
        pause

        scene e5s26-134 with dissolve
        nt "You're sick."

        scene e5s26-135 with dissolve
        pause

        scene e5s26-136 with dissolve
        mc "[nt], wait up!"

        scene e5s26-137 with dissolve
        mc "Get off me."

        scene e5s26-138 with dissolve
        pause

        scene e5s26-139 with dissolve
        sc "Don't bother dude, he's a lost cause."

        scene e5s26-140 with dissolve
        pause

        scene e5s26-141 with dissolve
        mc "Yo man, what just happened in there?"

        scene e5s26-143 with dissolve
        nt "What happened? I thought you were different."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "Different how? Come on, man. Talk to me."
        mc "I have absolutely no idea what's going on."

        scene e5s26-144 with dissolve
        hide e5s26_nate_blink1
        nt "I fucking like her, alright?"

        scene e5s26-145 with dissolve
        nt "And she just... threw herself at you like that."
        nt "And you didn't even stop it."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "Shit bro... I didn't even know."
        mc "I'm sorry, alright?"

        scene e5s26-146 with dissolve
        hide e5s26_nate_blink1
        nt "Would you have stopped it if you knew?"

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "..."

        scene e5s26-143 with dissolve
        hide e5s26_nate_blink1
        nt "You just invited me here to make fun of me. You're not sorry."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "What? No. Why the hell would I do that?"
        mc "I didn't even know you guys knew each other."

        scene e5s26-145 with dissolve
        hide e5s26_nate_blink1
        nt "Just... leave me the fuck alone, alright?"
        nt "I'm tired of you guys."

        scene e5s26-146 with dissolve
        nt "Fuck... I think I'm gonna throw up."

        scene e5s26-147 with dissolve
        pause

        scene e5s26-148 with dissolve
        jon "Yo, what the hell just happened?"

        scene e5s26-149 with dissolve
        mc "We should ask [sc]."

        scene e5s26-150 with dissolve
        sc "What? I don't like him."

        scene e5s26-151 with dissolve
        mc "That doesn't mean you have to make him feel horrible."

        scene e5s26-152 with dissolve
        sc "You don't know him the way I do."
        sc "He's a prick."

        scene e5s26-153 with dissolve
        menu:
            "Defend [nt]":
                $ e5s26_defend_nate = True
                mc "He's my roommate!"

                scene e5s26-154 with dissolve
                sc "So?"

                scene e5s26-153 with dissolve
                mc "So? I don't want any trouble."
                mc "I know him. He's alright. He didn't hurt anybody."

                scene e5s26-154 with dissolve
                sc "You really don't know what he's like."

                scene e5s26-153 with dissolve
                mc "Did he actually do something?"
            "Drop it":
                mc "This isn't going anywhere."

        scene e5s26-155 with dissolve
        sc "Whatever dude, just carry on."

        scene e5s26-156 with dissolve
        sc "He'll be fine. He always was."

        scene e5s26-155 with dissolve
        mc "That wasn't nice."

        scene e5s26-156 with dissolve
        sc "Well, cry me a fucking river then."
    else:
        play music did_it_and_quit_it
        scene e5s26-73 with dissolve
        play sound door_close
        pause

        scene e5s26-74 with dissolve
        pause

        scene e5s26-76 with dissolve
        mc "Yo, what were you up to?"

        scene e5s26-82 with dissolve
        jon "Just some business, don't worry about it."

        scene e5s26-83 with dissolve
        pause

        if affinity_spectrum > 0:
            scene e5s26-85 with dissolve
            ro "'Business' he calls it."

            scene e5s26-87 with dissolve
            mc "Is little [jon] here shy?"
        else:
            scene e5s26-84 with dissolve
            ro "'Business' he calls it."

        scene e5s26-86 with dissolve
        jon "No, it's nothing like that."

        scene e5s26-88 with dissolve
        jon "I promised her I wouldn't brag about it or anything."
        jon "Just... don't tell anyone, alright?"

        stop music
        scene e5s26-89 with vpunch
        play sound knock_knock
        pause

        scene e5s26-90 with dissolve
        jon "Did you guys order anything?"

        scene e5s26-91 with dissolve
        mc "Uh... no. I thought you did."

        scene e5s26-92 with dissolve
        jon "Who could be at the door this time of night?"

        play music coalescense
        scene e5s26-93 with dissolve
        jon "Hello, may I help you?"

        scene e5s26-94 with dissolve
        unknown "Good evening. We received a few calls regarding a disturbance in this area tonight."

        scene e5s26-95 with dissolve
        pause

        scene e5s26-98 with dissolve
        jon "A disturbance, officer? We've just been hanging out here, keeping things pretty low-key."

        scene e5s26-100 with dissolve
        unknown "Look, kids, I couldn't care less about your party."
        unknown "I've had some in my time too, but your neighbors definitely care about the bass vibrating through their floorboards for the last four hours."

        scene e5s26-101 with dissolve
        unknown "Turn the music down, keep the shouting to a minimum, and clear out the extra guests, or the next visit comes with a hefty fine. Understood?"

        scene e5s26-99 with dissolve
        jon "Absolutely, officer. Loud and clear. We'll shut it down right now."

        scene e5s26-94 with dissolve
        unknown "Good. Have a safe night."

        stop music fadeout 2.0
        scene e5s26-102 with dissolve
        pause

        scene e5s26-92 with dissolve
        pause

        scene e5s26-103 with dissolve
        jon "What are they talking about?"
        jon "The music isn't even that loud."

        scene e5s26-104 with dissolve
        mc "I know right?"

        if affinity_spectrum > 0:
            mc "Some people can't tolerate shit."
            mc "Or maybe they heard you doing your 'business', haha!"

            scene e5s26-85 with dissolve
            ro "Haha!"

            scene e5s26-86 with dissolve
            jon "No, but for real."
            jon "No one has to find out."
            jon "This is between us."
        else:
            mc "Some people can't tolerate anything."

        scene e5s26-90 with dissolve
        jon "Anyway, let's just resume the party."

        scene e5s26-107 with dissolve
        pause

        scene e5s26-108 with dissolve
        play sound knock_knock
        pause

        scene e5s26-109 with dissolve
        mc "*Huh? Another knock?*"

        scene e5s26-110 with dissolve
        pause

        scene e5s26-111 with dissolve
        mc "Yo, you came!"

        scene e5s26-112 with dissolve
        nt "Yeah, what's up, dude?"

        scene e5s26-113 with dissolve
        mc "Come on in."

        scene e5s26-114 with dissolve
        pause

        scene e5s26-115 with dissolve
        pause

        scene e5s26-116 with dissolve
        sc "Haha, look who's here!"

        scene e5s26-117 with dissolve
        nt "[sc]?"

        scene e5s26-118 with dissolve
        nt "Why didn't you tell me she's here?"

        scene e5s26-119 with dissolve
        mc "Wait, you guys know each other?"

        scene e5s26-120 with dissolve
        sc "If we know each other?"

        scene e5s26-121 with dissolve
        sc "This guy is a creep."

        scene e5s26-122 with dissolve
        nt "Damn it, I knew I shouldn't have come..."

        scene e5s26-119 with dissolve
        mc "No, no, wait man."
        mc "What's going on?"

        scene e5s26-121 with dissolve
        sc "Nothing, right [nt]?"

        scene e5s26-123 with dissolve
        nt "..."

        scene e5s26-124 with dissolve
        pause

        scene e5s26-121 with dissolve
        sc "We're just having a party [nt] wasn't invited to."

        scene e5s26-125 with dissolve
        mc "I invited him."

        scene e5s26-126 with dissolve
        sc "Oh, you're funny."

        scene e5s26-127 with dissolve
        mc "[sc], what's going on with you?"
        mc "Why have you been drinking so much lately?"

        scene e5s26-128 with dissolve
        sc "Oh, look at him, worrying for me."
        sc "Isn't that cute?"

        scene e5s26-129 with dissolve
        sc "Don't worry pretty, I'll be fine."

        scene e5s26-130 with dissolve
        pause

        scene e5s26-131 with dissolve
        pause

        scene e5s26-132 with dissolve
        pause

        scene e5s26-133 with dissolve
        pause

        scene e5s26-134 with dissolve
        nt "You're sick."

        scene e5s26-135 with dissolve
        pause

        scene e5s26-136 with dissolve
        mc "[nt], wait up!"

        scene e5s26-137 with dissolve
        mc "Get off me."

        scene e5s26-138 with dissolve
        pause

        scene e5s26-139 with dissolve
        sc "Don't bother dude, he's a lost cause."

        scene e5s26-140 with dissolve
        pause

        scene e5s26-141 with dissolve
        mc "Yo man, what just happened in there?"

        scene e5s26-143 with dissolve
        nt "What happened? I thought you were different."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "Different how? Come on, man. Talk to me."
        mc "I have absolutely no idea what's going on."

        scene e5s26-144 with dissolve
        hide e5s26_nate_blink1
        nt "I fucking like her, alright?"

        scene e5s26-145 with dissolve
        nt "And she just... threw herself at you like that."
        nt "And you didn't even stop it."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "Shit bro... I didn't even know."
        mc "I'm sorry, alright?"

        scene e5s26-146 with dissolve
        hide e5s26_nate_blink1
        nt "Would you have stopped it if you knew?"

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "..."

        scene e5s26-143 with dissolve
        hide e5s26_nate_blink1
        nt "You just invited me here to make fun of me. You're not sorry."

        scene e5s26-142 with dissolve
        show e5s26_nate_blink1
        mc "What? No. Why the hell would I do that?"
        mc "I didn't even know you guys knew each other."

        scene e5s26-145 with dissolve
        hide e5s26_nate_blink1
        nt "Just... leave me the fuck alone, alright?"
        nt "I'm tired of you guys."

        scene e5s26-146 with dissolve
        nt "Fuck... I think I'm gonna throw up."

        scene e5s26-147 with dissolve
        pause

        scene e5s26-148 with dissolve
        jon "Yo, what the hell just happened?"

        scene e5s26-149 with dissolve
        mc "We should ask [sc]."

        scene e5s26-150 with dissolve
        sc "What? I don't like him."

        scene e5s26-151 with dissolve
        mc "That doesn't mean you have to make him feel horrible."

        scene e5s26-152 with dissolve
        sc "You don't know him the way I do."
        sc "He's a prick."

        scene e5s26-153 with dissolve
        menu:
            "Defend [nt]":
                $ e5s26_defend_nate = True
                mc "He's my roommate!"

                scene e5s26-154 with dissolve
                sc "So?"

                scene e5s26-153 with dissolve
                mc "So? I don't want any trouble."
                mc "I know him. He's alright. He didn't hurt anybody."

                scene e5s26-154 with dissolve
                sc "You really don't know what he's like."

                scene e5s26-153 with dissolve
                mc "Did he actually do something?"
            "Drop it":
                mc "This isn't going anywhere."

        scene e5s26-155 with dissolve
        sc "Whatever dude, just carry on."

        scene e5s26-156 with dissolve
        sc "He'll be fine. He always was."

        scene e5s26-155 with dissolve
        mc "That wasn't nice."

        scene e5s26-156 with dissolve
        sc "Well, cry me a fucking river then."

    scene black with Dissolve(2.0)
    pause(1.0)

    $ episode_count += 0.5
    jump credits
return
