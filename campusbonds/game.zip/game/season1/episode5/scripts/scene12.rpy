
# Scene 12 - Reconciliation ####################################################

label e5s12:
    stop music fadeout 2.0
    if e4s5_sadie_mad == False:
        if e4s5_date == True:
            play music with_a_whimper
            scene e5s12-01 with wipeleft
            pause

            scene e5s12-02 with dissolve
            pause

            scene e5s12-05 with dissolve
            show e5s12_sadie_blink2
            mc "[sd], hey!"
            mc "What's up?"

            scene e5s12-04 with dissolve
            hide e5s12_sadie_blink2
            sd "Oh, uh... hey!"

            scene e5s12-05 with dissolve
            show e5s12_sadie_blink2
            mc "Are you free this weekend?"
            mc "I know a great place we could go. Thought it'd be fun since we had such a good time last time."

            scene e5s12-06 with dissolve
            hide e5s12_sadie_blink2
            sd "Yeah... sorry. I can't this week."

            scene e5s12-07 with dissolve
            sd "Maybe some other time?"

            scene e5s12-05 with dissolve
            show e5s12_sadie_blink2
            mc "Okay?"
            mc "Are you... alright?"

            scene e5s12-08 with dissolve
            hide e5s12_sadie_blink2
            sd "Of course, yeah. Why wouldn't I be?"

            scene e5s12-05 with dissolve
            show e5s12_sadie_blink2
            mc "Just asking."

            scene e5s12-04 with dissolve
            hide e5s12_sadie_blink2
            sd "Listen, I gotta go."

            scene e5s12-05 with dissolve
            show e5s12_sadie_blink2
            mc "See you later?"

            scene e5s12-07 with dissolve
            hide e5s12_sadie_blink2
            sd "Yeah."

            scene e5s12-09 with dissolve
            pause

            scene e5s12-10 with dissolve
            mc "*That was... weird.*"
            mc "*I thought things were getting better.*"
    else:
        play music with_a_whimper
        scene e5s12-01 with wipeleft
        pause

        scene e5s12-02 with dissolve
        pause

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "[sd], hey!"
        mc "What's up?"

        scene e5s12-11 with dissolve
        hide e5s12_sadie_blink1
        sd "Hey."

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "Do you want to talk?"

        scene e5s12-11 with dissolve
        hide e5s12_sadie_blink1
        sd "About what?"

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "I don't know... about everything? I feel like enough time has passed now."

        scene e5s12-12 with dissolve
        hide e5s12_sadie_blink1
        sd "I'm fine with things as they are."

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "Really?"
        mc "So this is how you want to handle it?"

        scene e5s12-13 with dissolve
        hide e5s12_sadie_blink1
        sd "What am I even doing?"

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "I think you're being childish."

        scene e5s12-14 with dissolve
        hide e5s12_sadie_blink1
        sd "Why would I want to talk to you?"
        sd "You've made your choice."

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "It was just a class project."
        mc "But if you're gonna play it this way, fine."
        mc "Stay defensive."
        mc "It feels like you completely lost interest over something small."

        scene e5s12-13 with dissolve
        hide e5s12_sadie_blink1
        sd "I didn't lose interest, okay?"

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "Then why are you acting like this?"

        scene e5s12-12 with dissolve
        hide e5s12_sadie_blink1
        sd "I just don't want to talk to you."

        scene e5s12-13 with dissolve
        sd "Is it so hard to understand?"

        scene e5s12-03 with dissolve
        show e5s12_sadie_blink1
        mc "Yeah, actually, it is."
        mc "Because I really don't get it."
        mc "But I think I'm done chasing. When you're ready to talk, we'll talk. Until then, take care."

        scene e5s12-15 with dissolve
        hide e5s12_sadie_blink1
        pause

    jump e5f2
return
