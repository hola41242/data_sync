
# Scene 24 - Oh My Bridget #####################################################

label e5s24:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e5s24-01 with Dissolve(2.0)
    pause

    play music punk_rock_holiday
    scene e5s24-02 with dissolve
    mc "*Where is everyone?*"

    scene e5s24-03 with dissolve
    pause

    scene e5s24-04 with dissolve
    mc "[br]?"

    scene e5s24-05 with dissolve
    br "[mc]."

    scene e5s24-07 with dissolve
    mc "Oh, sorry. I didn't mean to interrupt."

    scene e5s24-06 with dissolve
    br "You're not interrupting. Come on in."
    br "Besides, I'm the one who caught you all off guard."

    scene e5s24-08 with dissolve
    mc "Oh, that's not what happened..."

    scene e5s24-10 with dissolve
    br "Isn't it?"
    br "Do you think I'm blind, [mc]?"

    scene e5s24-11 with dissolve
    br "I notice the way you look at me. And I notice how this place suddenly emptied out."

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "I'm sorry. It's nothing personal."

    scene e5s24-11 with dissolve
    hide e5s24_bridget_blink1
    br "Yeah, I know. I wouldn't have been thrilled about having a professor join my club either."

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "*Damn, what's gotten into [br] today?*"
    mc "So, what are you working on?"

    scene e5s24-11 with dissolve
    hide e5s24_bridget_blink1
    br "Just college stuff. Grading papers, preparing exams..."

    if affinity_spectrum > 0:
        scene e5s24-09 with dissolve
        show e5s24_bridget_blink1
        mc "Exams? Think I could take a peek?"

        scene e5s24-12 with dissolve
        hide e5s24_bridget_blink1
        br "Haha, nice try."

        scene e5s24-09 with dissolve
        show e5s24_bridget_blink1
        mc "Come on... just a little."

    scene e5s24-13 with dissolve
    hide e5s24_bridget_blink1
    br "So, what brings you here?"

    scene e5s24-11 with dissolve
    br "Shouldn't you be hanging out with your friends?"
    br "Or are they showing up later?"

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "Nah, I have no idea where they are."
    mc "I usually come here when I'm bored. Play some music, kill some time..."

    scene e5s24-13 with dissolve
    hide e5s24_bridget_blink1
    br "You actually know how to use that thing?"

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "Haha, yeah. [dj] taught me."

    scene e5s24-10 with dissolve
    hide e5s24_bridget_blink1
    br "The DJ?"

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "Yep. Ironically enough, that's his actual name. [dj]."

    scene e5s24-11 with dissolve
    hide e5s24_bridget_blink1
    br "That's... strange."

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "Maybe. But who am I to judge?"

    scene e5s24-13 with dissolve
    hide e5s24_bridget_blink1
    br "Would you mind showing me how it works?"

    scene e5s24-09 with dissolve
    show e5s24_bridget_blink1
    mc "Not at all."

    scene black with Dissolve(2.0)
    hide e5s24_bridget_blink1

    scene e5s24-14 with Dissolve(2.0)
    mc "...and once you're done, you just press this button to shut it down."

    scene e5s24-15 with dissolve
    mc "Did that make sense, or do you want me to go over it again?"

    stop music fadeout 2.0
    scene e5s24-16 with dissolve
    br "No, no, I got it. Thanks!"

    scene e5s24-17 with dissolve
    play music evening_jazz
    pause

    scene e5s24-18 with dissolve
    mc "Hey! You've got it!"
    br "Heh. Takes me back to my college days."

    scene e5s24-19 with dissolve
    br "So, do you dance?"

    scene e5s24-20 with dissolve
    mc "Sometimes."

    scene e5s24-19 with dissolve
    br "Then come dance with me."

    scene e5s24-20 with dissolve
    mc "Right now?"

    scene e5s24-19 with dissolve
    br "Yeah. Why not?"

    scene e5s24-20 with dissolve
    mc "Wow, okay."

    scene e5s24-21 with dissolve
    pause

    scene e5s24-22 with dissolve
    mc "Just so you know, I'm not much of a dancer."

    scene e5s24-23 with dissolve
    br "That's okay. You don't have to be."

    scene e5s24-24 with dissolve
    pause

    if affinity_spectrum > 0:
        scene e5s24-25 with dissolve
        pause

        scene e5s24-26 with dissolve
        br "I'm sorry. This is getting a little inappropriate."

        scene e5s24-30 with dissolve
        mc "Oh, shit! I mean... sorry."
        mc "I was just getting caught up in the moment."

        scene e5s24-29 with dissolve
        br "Yeah, no... I get it."
    else:
        scene e5s24-26 with dissolve
        pause

        scene e5s24-27 with dissolve
        pause

        scene e5s24-28 with dissolve
        br "I-I'm sorry."

        scene e5s24-29 with dissolve
    stop music fadeout 2.0
    br "I should probably get back to work."
    br "Thanks for keeping me company today."

    scene e5s24-31 with dissolve
    mc "*Wow... what was that?*"
    mc "Don't mention it."
    mc "I had fun."

    scene e5s24-04 with dissolve
    pause

    scene e5s24-32 with dissolve
    pause

    scene e5s24-33 with dissolve

    nvl clear

    jn_nvl "Yo!"
    jn_nvl "My place. Tonight."
    jn_nvl "Got some plans to make."
    n_nvl "You got it."

    jump e5s25
return
