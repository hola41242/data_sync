
# Variables
default e5f3_tracy = False
default e5f3_jon = False

default e5f3_roman1 = False
default e5f3_ruby1 = False

default e5f3_roman2 = False
default e5f3_ruby2 = False
default e5f3_scarlett2 = False

default e5f3_roman_return = False
default e5f3_roman_return_remaining = 3

# Freeroam Collected Photos #

default persistent.e5f3_collected_p = 0
default persistent.e5f3_collected_tp = 0

# Freeroam 3 ###################################################################
label e5f3:
    define e5f3_tracks = ["party/i_wont_fall_in_love.ogg", "party/galaxies.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/piano.ogg", "party/instrumentals/rock_this_house.ogg", "party/instrumentals/turn_up.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/random_drop.ogg", "party/instrumentals/2010_pop.ogg", "party/instrumentals/encryption.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/dance_tonight.ogg", "party/instrumentals/love_you.ogg"]
    $ renpy.random.shuffle(e5f3_tracks)
    $ renpy.music.queue (e5f3_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Talk to people.")

    scene e5f3-01 with dissolve
    call screen e5f3_living
    hide e5f3-01
return

# Map ##########################################################################

# Living ###
label e5f3_living:
    if e5f3_roman1 == True and e5f3_roman_return == False:
        if e5f3_roman_return_remaining > 0:
            $ e5f3_roman_return_remaining -= 1
        else:
            $ e5f3_roman_return = True


    if e5f3_roman1 == False:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            scene e5f3-01_4
        else:
            scene e5f3-01
    else:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            if e5f3_roman_return == False:
                scene e5f3-01_3
            else:
                scene e5f3-01_5
        else:
            if e5f3_roman_return == False:
                scene e5f3-01_2
            else:
                scene e5f3-01_1
    call screen e5f3_living with dissolve
return

label e5f3_roman1:
    scene e5f3-roman1_01 with dissolve
    ro "Yo, [mc]."
    ro "Come have a seat."

    scene e5f3-roman1_02 with dissolve
    pause

    scene e5f3-roman1_03 with dissolve
    mc "What's up with you, guys?"

    scene e5f3-roman1_04 with dissolve
    ro "Just being... chilling."

    scene e5f3-roman1_05 with dissolve
    jd "Haha, I can't believe you did that."

    scene e5f3-roman1_03 with dissolve
    mc "I've gotta say [ro], it's weird seeing you here without [ke]."

    scene e5f3-roman1_06 with dissolve
    ro "I know right?"

    scene e5f3-roman1_04 with dissolve
    ro "Usually, it's me who misses parties."

    scene e5f3-roman1_03 with dissolve
    mc "What happened to him?"

    scene e5f3-roman1_07 with dissolve
    ro "He said he's staying inside to 'study'."

    scene e5f3-roman1_06 with dissolve
    ro "We believe he's doing something else but doesn't want to tell us."

    scene e5f3-roman1_03 with dissolve
    mc "Why would he keep it from us?"

    scene e5f3-roman1_08 with dissolve
    ro "Maybe he's doing something he's ashamed of, who knows?"

    scene e5f3-roman1_06 with dissolve
    ro "Truth is, he's never been one to study."

    scene e5f3-roman1_03 with dissolve
    mc "I see, that's very strange indeed."

    scene e5f3-roman1_08 with dissolve
    ro "I have a weird feeling he's seeing his ex again, but I'm not very sure..."

    scene e5f3-roman1_09 with dissolve
    play sound phone_buzz
    pause

    scene e5f3-roman1_10 with dissolve
    jd "Sorry guys, I have to take this."

    scene e5f3-roman1_12 with dissolve
    jd "Yeah?"

    scene e5f3-roman1_11 with dissolve
    pause

    scene e5f3-roman1_13 with dissolve
    jd "They did what?"
    jd "No way."

    scene e5f3-roman1_14 with dissolve
    jd "Fucking bitch!"

    scene e5f3-roman1_15 with dissolve
    pause

    scene e5f3-roman1_16 with dissolve
    jd "Fuck, sorry guys, I have to go."

    scene e5f3-roman1_17 with dissolve
    mc "Wait, what happened?"

    scene e5f3-roman1_18 with dissolve
    pause

    scene e5f3-roman1_19 with dissolve
    ro "That didn't sound good..."

    scene e5f3-roman1_20 with dissolve
    mc "No kidding."

    scene e5f3-roman1_21 with dissolve
    ro "Yo, wait up, dude!"

    $ e5f3_roman1 = True

    jump e5f3_living
return

label e5f3_roman2:
    if e5f3_roman2 == False:
        scene e5f3-roman2_01 with dissolve
        mc "Yo, [ro]."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "Do you know where [jon] went?"

        scene e5f3-roman2_03 with dissolve
        hide e5f3_roman_blink1
        ro "I have no idea."

        scene e5f3-roman2_04 with dissolve
        ro "I might have seen him go to his room with that chick he was talking to."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "So, what are you up to tonight?"

        scene e5f3-roman2_04 with dissolve
        hide e5f3_roman_blink1
        ro "I have no idea."

        scene e5f3-roman2_05 with dissolve
        ro "Might go to the club with [jd] later to cheer him up."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "Why? What happened?"

        scene e5f3-roman2_06 with dissolve
        hide e5f3_roman_blink1
        ro "He got a call from one of his roommates."

        scene e5f3-roman2_07 with dissolve
        ro "Things are not looking good."

        scene e5f3-roman2_08 with dissolve
        ro "Some of his stuff has gone missing."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "You think it's [sp] who did it?"

        scene e5f3-roman2_05 with dissolve
        hide e5f3_roman_blink1
        ro "Probably."

        scene e5f3-roman2_07 with dissolve
        ro "Can't say for sure."

        scene e5f3-roman2_08 with dissolve
        ro "But it's a shit show nontheless."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "It had to be him, right?"
        mc "Who else would want to steal from him?"
        mc "Especially with everything that happened."

        scene e5f3-roman2_08 with dissolve
        hide e5f3_roman_blink1
        ro "Yeah, I think you might be onto something."

        scene e5f3-roman2_09 with dissolve
        ro "Hey, I had an idea."
        ro "What if we hurt them back?"

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        if affinity_spectrum > 0:
            mc "What? Like fight them?"
            mc "Already did that."

            scene e5f3-roman2_07 with dissolve
            hide e5f3_roman_blink1
            ro "Really?"
            ro "No, that's not what I had in mind."
        else:
            mc "How?"

        scene e5f3-roman2_10 with dissolve
        hide e5f3_roman_blink1
        ro "Let's play a prank on them, shall we?"

        scene e5f3-roman2_11 with dissolve
        menu:
            "Good idea":
                call extrovert_affinity_check from _call_extrovert_affinity_check_77
                call color_check from _call_color_check_150
                mc "Yeah, we should totally do that."
                mc "What do you have in mind?"

                scene e5f3-roman2_14 with dissolve
                ro "Hmm... I think we need a girl."

                scene e5f3-roman2_07 with dissolve
                ro "Can you find one?"

                scene e5f3-roman2_02 with dissolve
                show e5f3_roman_blink1
                $ e5f3_roman2 = True
                $ current_quests.append("Find a girl for Roman's prank.")
                $ current_quests.remove("Talk to people.")
                mc "I'll have a look."

                hide e5f3_roman_blink1

                jump e5f3_living

            "Bad idea":
                call introvert_affinity_check from _call_introvert_affinity_check_69
                call color_check from _call_color_check_151
                mc "Really? A prank?"

                scene e5f3-roman2_12 with dissolve
                ro "Do you have a better idea?"

                scene e5f3-roman2_02 with dissolve
                show e5f3_roman_blink1
                mc "What if we don't hurt him?"

                scene e5f3-roman2_13 with dissolve
                hide e5f3_roman_blink1
                ro "Boooring."

                scene e5f3-roman2_12 with dissolve
                ro "Can you be less lame?"
                ro "Come on, dude. He won't even know it was us."
                ro "Let's fight back."

                scene e5f3-roman2_11 with dissolve
                menu:
                    "Play along":
                        mc "Fine... what do you have in mind?"

                        scene e5f3-roman2_14 with dissolve
                        ro "Hmm... I think we need a girl."

                        scene e5f3-roman2_07 with dissolve
                        ro "Can you find one?"

                        scene e5f3-roman2_02 with dissolve
                        show e5f3_roman_blink1
                        $ e5f3_roman2 = True
                        $ current_quests.append("Find a girl for Roman's prank.")
                        $ current_quests.remove("Talk to people.")
                        mc "I'll have a look."

                        hide e5f3_roman_blink1

                        jump e5f3_living

                    "Reject his idea":
                        mc "Nah, sorry man."
                        mc "I'm out."

                        scene e5f3-roman2_05 with dissolve
                        ro "Whatever. Your loss."

                        if optional_quests:
                            $ optional_quests.clear()
                        if current_quests:
                            $ current_quests.clear()

                        $ renpy.hide_screen("questtracker_icon")

                        return

    if e5f3_tracy_choice == False or e5f3_ruby_choice == False:
        scene e5f3-roman2_06 with dissolve
        ro "So? Did you manage to find one?"

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "Yup, all set and ready to go."

        scene e5f3-roman2_10 with dissolve
        ro "Sweet!"
        if optional_quests:
            $ optional_quests.clear()
        if current_quests:
            $ current_quests.clear()

        $ renpy.hide_screen("questtracker_icon")
        ro "Let's get going."

        $ e5f3_roman_prank = True
    else:
        scene e5f3-roman2_06 with dissolve
        ro "So? Did you manage to find one?"

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        mc "Nah, nobody wants to come."

        scene e5f3-roman2_08 with dissolve
        hide e5f3_roman_blink1
        ro "Damn it..."
        ro "And I had such a good plan."
        ro "It's a shame."

        scene e5f3-roman2_02 with dissolve
        show e5f3_roman_blink1
        if optional_quests:
            $ optional_quests.clear()
        if current_quests:
            $ current_quests.clear()

        $ renpy.hide_screen("questtracker_icon")
        mc "Yeah..."

        hide e5f3_roman_blink1
return

label e5f3_scarlett1:
    mc "*I shouldn't approach her now.*"
    mc "*She's talking to someone over the phone.*"

    jump e5f3_living
return

label e5f3_scarlett2:
    scene e5f3-scarlett_01 with dissolve
    mc "Hey [sc]."

    scene e5f3-scarlett_03 with dissolve
    sc "Hey."

    scene e5f3-scarlett_02 with dissolve
    show e5f3_scarlett_blink1
    mc "Wanna help me out with something?"

    scene e5f3-scarlett_03 with dissolve
    hide e5f3_scarlett_blink1
    sc "What is it?"

    scene e5f3-scarlett_02 with dissolve
    show e5f3_scarlett_blink1
    mc "So, I've been talking to [ro] and we'd like to play a prank on [kv]."
    mc "Wondered if you wanted to get involved."

    scene e5f3-scarlett_03 with dissolve
    hide e5f3_scarlett_blink1
    sc "Really? You thought of asking me?"

    scene e5f3-scarlett_04 with dissolve
    sc "If [kv] catches me pulling pranks on him he's definitely going to use that against us."

    scene e5f3-scarlett_02 with dissolve
    show e5f3_scarlett_blink1
    mc "Damn, you're right, sorry."
    mc "I'll find somebody else."

    scene e5f3-scarlett_05 with dissolve
    hide e5f3_scarlett_blink1
    pause

    $ e5f3_scarlett2 = True

    jump e5f3_living
return

label e5f3_ruby1:
    if e5f3_roman2 == False:
        scene e5f3-ruby1_01 with dissolve
        if e4f2_stripper_offer == True:
            mc "Hey."

            scene e5f3-ruby1_03 with dissolve
            unknown "Oh, hey."
            unknown "Haven't seen you in a while."

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            mc "You remember me?"
            mc "We only met once at the last party."

            scene e5f3-ruby1_04 with dissolve
            hide e5f3_ruby_blink2
            unknown "You left quite the impression."

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            mc "Did I?"
            mc "I was wondering when I'd see you again, if ever."

            scene e5f3-ruby1_06 with dissolve
            hide e5f3_ruby_blink2
            unknown "Why's that?"

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            mc "To be honest I didn't think we'd have a party any time soon."
            mc "Things didn't end the best last time."
            mc "Especially now with a professor up our ass."

            scene e5f3-ruby1_07 with dissolve
            hide e5f3_ruby_blink2
            unknown "Is that why we're here now?"

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            mc "Kind of, yeah."

            scene e5f3-ruby1_06 with dissolve
            hide e5f3_ruby_blink2
            unknown "Hey, wanna pick up from where we left off last time?"

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            mc "What do you have in mind?"

            scene e5f3-ruby1_03 with dissolve
            hide e5f3_ruby_blink2
            unknown "Find me in the bathroom and I'll show you... for {color=#4CBB17}$1{/color}."

            scene e5f3-ruby1_05 with dissolve
            show e5f3_ruby_blink2
            $ renpy.show_screen("money_notify_pers")
            menu:
                "Take her offer {color=#f00}(-$1){/color}" if money > 0:
                    call extrovert_affinity_check from _call_extrovert_affinity_check_78
                    call color_check from _call_color_check_152
                    $ e5f3_stripper_offer = True
                    $ money -= 1

                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    mc "Alright, I'm in."

                    scene e5f3-ruby1_04 with dissolve
                    hide e5f3_ruby_blink2
                    $ optional_quests.append("Follow the stripper to the bathroom.")
                    unknown "See you there."

                "Refuse her":
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")

                    mc "Sorry, I'm not really feeling it."

                    scene e5f3-ruby1_03 with dissolve
                    hide e5f3_ruby_blink2
                    unknown "If you change your mind you know where to find me."

            $ e5f3_ruby1 = True
            jump e5f3_living
        else:
            mc "Hey, enjoying the party?"

            scene e5f3-ruby1_08 with dissolve
            unknown "I think I need some more alcohol."

            scene e5f3-ruby1_02 with dissolve
            show e5f3_ruby_blink1
            mc "You do?"

            scene e5f3-ruby1_03 with dissolve
            hide e5f3_ruby_blink1
            unknown "Yeah, I just got here an hour ago."

            scene e5f3-ruby1_02 with dissolve
            show e5f3_ruby_blink1
            mc "I think I've seen you before."

            scene e5f3-ruby1_04 with dissolve
            hide e5f3_ruby_blink1
            unknown "Oh, I've been in a lot of places, handsome."

            scene e5f3-ruby1_02 with dissolve
            show e5f3_ruby_blink1
            mc "I think we interacted during our last party."

            scene e5f3-ruby1_06 with dissolve
            hide e5f3_ruby_blink1
            unknown "We did?"

            scene e5f3-ruby1_08 with dissolve
            unknown "I can't remember."

            scene e5f3-ruby1_02 with dissolve
            show e5f3_ruby_blink1
            menu:
                "Grab a drink with her":
                    mc "Wanna go grab a drink?"

                    scene e5f3-ruby1_04 with dissolve
                    hide e5f3_ruby_blink1
                    unknown "You don't have to ask twice."

                    scene black with Dissolve(2.0)

                    scene e5f3-ruby1_09 with Dissolve(2.0)
                    pause

                    scene e5f3-ruby1_10 with dissolve
                    pause

                    scene e5f3-ruby1_11 with dissolve
                    unknown "Do you smoke?"

                    scene e5f3-ruby1_12 with dissolve
                    show e5f3_ruby_blink3
                    menu:
                        "Smoke":
                            call extrovert_affinity_check from _call_extrovert_affinity_check_79
                            call color_check from _call_color_check_153
                            mc "I don't usually smoke but I wouldn't mind a hit."

                            scene e5f3-ruby1_13 with dissolve
                            hide e5f3_ruby_blink3
                            pause

                            scene e5f3-ruby1_14 with dissolve
                            pause

                        "Don't smoke":
                            call introvert_affinity_check from _call_introvert_affinity_check_70
                            call color_check from _call_color_check_154
                            mc "Nah, not really, thanks."

                            scene e5f3-ruby1_17 with dissolve
                            hide e5f3_ruby_blink3
                            unknown "Your loss."

                            scene e5f3-ruby1_16 with dissolve
                            pause

                    scene e5f3-ruby1_15 with dissolve
                    unknown "So, what's your deal here?"

                    scene e5f3-ruby1_12 with dissolve
                    show e5f3_ruby_blink3
                    mc "My deal?"

                    scene e5f3-ruby1_18 with dissolve
                    hide e5f3_ruby_blink3
                    unknown "Yeah, so many pretty women around and no chick for you?"

                    scene e5f3-ruby1_17 with dissolve
                    unknown "It's a shame for such a handsome guy."

                    scene e5f3-ruby1_12 with dissolve
                    show e5f3_ruby_blink3
                    mc "I'm just chilling and having fun."
                    mc "Just got here."

                    scene e5f3-ruby1_18 with dissolve
                    hide e5f3_ruby_blink3
                    unknown "So I'm the first of the night, huh?"

                    scene e5f3-ruby1_12 with dissolve
                    show e5f3_ruby_blink3
                    mc "Haha, come on, it's not like that."

                    if affinity_spectrum > 0:
                        mc "I'm not gonna bang every girl inside this apartment."
                    else:
                        mc "I'm not trying to get with every girl here."

                    scene e5f3-ruby1_15 with dissolve
                    hide e5f3_ruby_blink3
                    unknown "Why not?"

                    scene e5f3-ruby1_17 with dissolve
                    unknown "That would be one hell of a story to tell."

                    scene e5f3-ruby1_16 with dissolve
                    if affinity_spectrum > 0:
                        mc "I guess it would, huh?"
                        mc "Nah, chill, I'm not that crazy."

                        scene e5f3-ruby1_18 with dissolve
                        hide e5f3_ruby_blink3
                        unknown "I don't know about the others, but I'd like to know what you're hiding."
                    else:
                        mc "Haha, yeah, that's not who I am."

                        scene e5f3-ruby1_15 with dissolve
                        hide e5f3_ruby_blink3
                        unknown "And who are you?"

                        scene e5f3-ruby1_12 with dissolve
                        show e5f3_ruby_blink3
                        mc "I'm pretty introverted to be honest."

                        scene e5f3-ruby1_17 with dissolve
                        hide e5f3_ruby_blink3
                        unknown "I've seen intorverted dudes pull chicks from all sides."
                        unknown "That's not it."

                        scene e5f3-ruby1_12 with dissolve
                        show e5f3_ruby_blink3
                        mc "Then I guess I have no idea who am I, haha."

                        scene e5f3-ruby1_19 with dissolve
                        hide e5f3_ruby_blink3
                        unknown "I think you're looking for fun but have no idea how to ask for it."

                    scene e5f3-ruby1_20 with vpunch
                    play sound slap
                    pause

                    scene e5f3-ruby1_18 with dissolve
                    unknown "I could show you a good time inside the bathroom... for {color=#4CBB17}$2{/color}."

                    scene e5f3-ruby1_12 with dissolve
                    show e5f3_ruby_blink3
                    menu:
                        "Take her offer {color=#f00}(-$2){/color}" if money > 1:
                            call extrovert_affinity_check from _call_extrovert_affinity_check_80
                            call color_check from _call_color_check_155
                            $ e5f3_stripper_offer = True
                            $ money -= 2

                            $ renpy.show_screen("money_notify")
                            $ renpy.hide_screen("money_notify_pers")
                            mc "Alright, I'm in."

                            scene e5f3-ruby1_18 with dissolve
                            hide e5f3_ruby_blink3
                            $ optional_quests.append("Follow the stripper to the bathroom.")
                            unknown "See you there."
                        "Refuse her":
                            mc "Sorry, I'm not really feeling it."

                            scene e5f3-ruby1_19 with dissolve
                            hide e5f3_ruby_blink3
                            unknown "If you change your mind you know where to find me."

                            scene e5f3-ruby1_16 with dissolve
                            pause

                    $ e5f3_ruby1 = True
                    jump e5f3_kitchen

                "Talk to other people":
                    mc "Anyway, I'll see you around."

                    scene e5f3-ruby1_04 with dissolve
                    hide e5f3_ruby_blink1
                    unknown "See you, handsome."

                    $ e5f3_ruby1 = True
                    jump e5f3_living
    else:
        scene e5f3-ruby1_01 with dissolve
        mc "Hey."

        scene e5f3-ruby1_03 with dissolve
        if e5f3_stripper_offer == False:
            unknown "Hey there, handsome."
            unknown "Do you need something?"
        else:
            ru "Hey there, handsome."
            ru "Do you need something?"

        scene e5f3-ruby1_02 with dissolve
        show e5f3_ruby_blink1
        mc "I was wondering if you'd help me out with something."

        scene e5f3-ruby1_04 with dissolve
        hide e5f3_ruby_blink1
        if e5f3_stripper_offer == False:
            unknown "I can help you out in multiple ways."
        else:
            ru "I can help you out in multiple ways."

        scene e5f3-ruby1_02 with dissolve
        show e5f3_ruby_blink1
        mc "No, no, not like that."
        mc "I was talking to this friend of mine and he wanted to pull a prank on someone."
        mc "He said he needed a chick for it to work."
        mc "So, what do you say?"

        scene e5f3-ruby1_06 with dissolve
        hide e5f3_ruby_blink1
        if e5f3_stripper_offer == False:
            unknown "I do admit this is one of those things I haven't been asked before."

            scene e5f3-ruby1_03 with dissolve
            unknown "But I can do it..."
            unknown "For {color=#4CBB17}$1{/color}."
        else:
            ru "I do admit this is one of those things I haven't been asked before."

            scene e5f3-ruby1_03 with dissolve
            ru "But I can do it..."
            ru "For {color=#4CBB17}$1{/color}."

        scene e5f3-ruby1_02 with dissolve
        show e5f3_ruby_blink1
        mc "*Damn, she's charging me for this?*"

        $ renpy.show_screen("money_notify_pers")
        menu:
            "Pay the stripper {color=#f00}(-$1){/color}" if money > 0:
                $ e5f3_ruby_choice = True
                $ money -= 1

                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")

                mc "Okay, okay, fine."
                mc "Just... help us out, okay?"

                scene e5f3-ruby1_04 with dissolve
                hide e5f3_ruby_blink1
                $ current_quests.remove("Find a girl for Roman's prank.")
                $ current_quests.append("Talk to Roman.")
                if e5f3_stripper_offer == False:
                    unknown "You got it."
                else:
                    ru "You got it."
            "Back out":
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")

                mc "On another thought, I changed my mind."
                mc "Thanks anyway."

                hide e5f3_ruby_blink1

        jump e5f3_living
return

label e5f3_tracy:
    if e5f3_roman2 == False:
        scene e5f3-tracy_01 with dissolve
        if e5s10_fwb == True and e4s5_tracy_path_throw == False:
            mc "Hey, how are you?"

            scene e5f3-tracy_07 with dissolve
            tr "Hey [mc]."
            tr "I'm fine, you?"

            scene e5f3-tracy_06 with dissolve
            show e5f3_tracy_blink2
            mc "I'm okay."
            mc "Enjoying the party?"

            scene e5f3-tracy_08 with dissolve
            hide e5f3_tracy_blink2
            tr "Yeah. Too bad [sd] isn't here."

            scene e5f3-tracy_06 with dissolve
            show e5f3_tracy_blink2
            mc "Is she okay?"

            scene e5f3-tracy_09 with dissolve
            hide e5f3_tracy_blink2
            tr "I don't know, maybe, we haven't really talked."

            scene e5f3-tracy_06 with dissolve
            show e5f3_tracy_blink2
            mc "Okay?"

            scene e5f3-tracy_08 with dissolve
            hide e5f3_tracy_blink2
            tr "Yeah..."

            scene e5f3-tracy_06 with dissolve
            show e5f3_tracy_blink2
            mc "*Things seem a bit awkward since our last talk.*"
            mc "So... I've been thinking about what we talked."

            scene e5f3-tracy_11 with dissolve
            hide e5f3_tracy_blink2
            tr "This isn't a good place or time to be talking about that."
            tr "Let's just enjoy the party and keep the distance, okay?"

            scene e5f3-tracy_10 with dissolve
            mc "Fine."
            mc "*Looks like she doesn't really want to talk to me.*"
        else:
            mc "Hey there!"

            scene e5f3-tracy_12 with dissolve
            tr "Hiii."

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            mc "Enjoying the party?"

            scene e5f3-tracy_03 with dissolve
            hide e5f3_tracy_blink1
            tr "Oh yeah, I've always liked parties."

            scene e5f3-tracy_13 with dissolve
            tr "Too bad [sd] isn't here."

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            mc "Takes me back to be honest."

            scene e5f3-tracy_14 with dissolve
            hide e5f3_tracy_blink1
            tr "Oh, yeah! You're right."
            tr "This is where we first met."

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            mc "Haha, yeah, time flies so fast, doesn't it?"

            scene e5f3-tracy_13 with dissolve
            hide e5f3_tracy_blink1
            tr "It really does, yeah."

            scene e5f3-tracy_05 with dissolve
            if e3s23_tracy_feelings == False:
                tr "Hey, I'll catch you later, I'm gonna go have something to drink."

                scene e5f3-tracy_02 with dissolve
                show e5f3_tracy_blink1
                mc "Alright, see you."

                hide e5f3_tracy_blink1
            else:
                if affinity_spectrum > 0:
                    tr "Wanna have a drink?"

                    scene e5f3-tracy_02 with dissolve
                    show e5f3_tracy_blink1
                    mc "Sure, lead the way."

                    scene black with Dissolve(2.0)
                    hide e5f3_tracy_blink1

                    scene e5f3-tracy_15 with Dissolve(2.0)
                    show e5f3_tracy_blink3
                    mc "So, how have you been?"
                    mc "I feel like we haven't spoken in so long."

                    scene e5f3-tracy_16 with dissolve
                    hide e5f3_tracy_blink3
                    tr "Yeah, I know right?"

                    scene e5f3-tracy_17 with dissolve
                    tr "I've just been keeping up with classes."

                    scene e5f3-tracy_18 with dissolve
                    tr "This time of the year is the worst."

                    scene e5f3-tracy_15 with dissolve
                    show e5f3_tracy_blink3
                    mc "I'm sorry to hear that."

                    scene e5f3-tracy_19 with dissolve
                    hide e5f3_tracy_blink3
                    tr "Aren't you stressed?"

                    scene e5f3-tracy_15 with dissolve
                    show e5f3_tracy_blink3
                    mc "A little yeah, but I'm more focused on other stuff."

                    scene e5f3-tracy_20 with dissolve
                    hide e5f3_tracy_blink3
                    tr "Be careful dude, don't let it pile up."
                    tr "It'll absolutely bite you in the ass later."

                    scene e5f3-tracy_15 with dissolve
                    show e5f3_tracy_blink3
                    menu:
                        "Make a joke":
                            call extrovert_affinity_check from _call_extrovert_affinity_check_81
                            call color_check from _call_color_check_156
                            $ tracy_trust += 1
                            mc "Bite me in the ass? Like how I bit you?"

                            scene e5f3-tracy_21 with dissolve
                            hide e5f3_tracy_blink3
                            tr "Haha, that never happened."

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "Well... do you want it to?"

                            scene e5f3-tracy_22 with dissolve
                            hide e5f3_tracy_blink3
                            tr "Are you suggesting something?"

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "Only if you're asking."

                            scene e5f3-tracy_21 with dissolve
                            hide e5f3_tracy_blink3
                            tr "Shut up. Focus on your classes first."

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "Damn, okay mom."
                        "Stay on topic":
                            call introvert_affinity_check from _call_introvert_affinity_check_71
                            call color_check from _call_color_check_157
                            mc "I guess you might be right."
                            mc "But there are more important things at stake right now."

                            scene e5f3-tracy_23 with dissolve
                            hide e5f3_tracy_blink3
                            tr "None of this will matter after you graduate."

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "Damn, when did you become so nerdy?"

                            scene e5f3-tracy_23 with dissolve
                            hide e5f3_tracy_blink3
                            tr "I'm not nerdy! Just responsible."

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "Sounds like a nerd to me."

                            scene e5f3-tracy_24 with dissolve
                            hide e5f3_tracy_blink3
                            tr "Okay, maybe a little."

                            scene e5f3-tracy_25 with dissolve
                            tr "It's just been a while since I've been to a party, alright?"
                            tr "Let me get used to it."

                            scene e5f3-tracy_15 with dissolve
                            show e5f3_tracy_blink3
                            mc "I can take it slow, no worries."

                    scene e5f3-tracy_26 with dissolve
                    hide e5f3_tracy_blink3
                    jon "Hey there, people!"
                    jon "Would you like to taste this new drink I made?"
                    jon "I call it... 'The Panty Dropper 3000'."

                    scene e5f3-tracy_27 with dissolve
                    mc "Hell no, dude. I'm not tasting anything made by you."
                    mc "Don't you remember last time?"

                    scene e5f3-tracy_29 with dissolve
                    jon "'Last time' we didn't have good ingredients, alright?"
                    jon "I had to improvise."

                    scene e5f3-tracy_28 with dissolve
                    jon "But you have to trust me on this one!"

                    scene e5f3-tracy_30 with dissolve
                    tr "Yeah... I'mma pass up on the offer. Thanks but no thanks."
                    tr "I'm gonna go have a smoke."

                    scene e5f3-tracy_31 with dissolve
                    jon "Huh? But you don't even-"

                    scene e5f3-tracy_32 with dissolve
                    pause

                    scene e5f3-tracy_33 with dissolve
                    jon "-smoke..."

                    scene e5f3-tracy_29 with dissolve
                    jon "What about you, my dear friend [mc]?"

                    scene e5f3-tracy_27 with dissolve
                    mc "No chance, dude."

                    scene e5f3-tracy_33 with dissolve
                    jon "Damn..."
                else:
                    tr "Hey, I'll catch you later, I'm gonna go have something to drink."

                    scene e5f3-tracy_02 with dissolve
                    show e5f3_tracy_blink1
                    mc "Alright, see you."

                    hide e5f3_tracy_blink1

        $ e5f3_tracy = True
    else:
        if e5s10_breakup == True:
            mc "*I don't think she wants to talk to me right now.*"
        else:
            scene e5f3-tracy_01 with dissolve
            mc "Hey."

            scene e5f3-tracy_03 with dissolve
            hide e5f3_tracy_blink1
            tr "Hey [mc]."

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            mc "Wanna help me out with something?"

            scene e5f3-tracy_04 with dissolve
            hide e5f3_tracy_blink1
            tr "Sure, what is it?"

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            mc "So, [ro]'s been trying to set up a prank and said we need a girl for it."
            mc "What do you say? Are you in or are you out?"

            scene e5f3-tracy_04 with dissolve
            hide e5f3_tracy_blink1
            tr "That sounds fun."

            scene e5f3-tracy_05 with dissolve
            tr "I'll be with you in a minute."

            scene e5f3-tracy_02 with dissolve
            show e5f3_tracy_blink1
            $ current_quests.remove("Find a girl for Roman's prank.")
            $ current_quests.append("Talk to Roman.")
            mc "Awesome! I'll let him know."

            $ e5f3_tracy_choice = True

            hide e5f3_tracy_blink1

    jump e5f3_living
return

# Bedroom ###
label e5f3_bedroom:
    if e5f3_jon == False and e5f3_roman_return == False:
        if e5f3_roman1 == True:
            if e5f3_roman_return_remaining > 0:
                $ e5f3_roman_return_remaining -= 1
            else:
                $ e5f3_roman_return = True

        scene e5f3-jon_01 with dissolve
        mc "*Huh? [jon]'s room is unlocked?*"
        mc "*He usually doesn't keep it unlocked during parties.*"

        scene e5f3-02
        call screen e5f3_bedroom with dissolve
    else:
        scene e5f3-jon_01 with dissolve
        mc "*[jon] locked the door to his bedroom. I can't enter anymore.*"

        jump e5f3_living
return

label e5f3_bedroom_leave:
    scene e5f3-jon_02 with dissolve
    jon "Yo!"

    scene e5f3-jon_03 with dissolve
    mc "Hey man."
    mc "Don't you usually keep this door locked?"

    scene e5f3-jon_04 with dissolve
    jon "Yeah, I do."
    jon "But I need it unlocked."

    scene e5f3-jon_03 with dissolve
    mc "Alright?"

    scene e5f3-jon_04 with dissolve
    jon "Let me go grab something."

    scene e5f3-jon_05 with dissolve
    mc "*Why is he acting so weird?*"

    $ e5f3_jon = True

    jump e5f3_living
return

# Bathroom ###
label e5f3_bathroom:
    if e5f3_roman1 == True and e5f3_roman_return == False:
        if e5f3_roman_return_remaining > 0:
            $ e5f3_roman_return_remaining -= 1
        else:
            $ e5f3_roman_return = True


    if e5f3_ruby2 == False and e5f3_stripper_offer == True:
        scene e5f3-03_1
    else:
        scene e5f3-03
    call screen e5f3_bathroom with dissolve
return

label e5f3_ruby2:
    call e5f3_ruby_lewd from _call_e5f3_ruby_lewd

    $ e5f3_ruby2 = True

    $ optional_quests.remove("Follow the stripper to the bathroom.")
    pause

    $ renpy.random.shuffle(e5f3_tracks)
    $ renpy.music.queue (e5f3_tracks, loop=True)

    jump e5f3_bathroom
return

label e5f3_ruby_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        play music heartache
        scene e5f3-ruby2_01 with dissolve
        mc "Hey, I'm here."

        scene e5f3-ruby2_02 with dissolve
        unknown "Good."

        scene e5f3-ruby2_03 with dissolve
        pause

        scene e5f3-ruby2_04 with vpunch
        pause

        scene e5f3-ruby2_05 with dissolve
        mc "Damn, what are you trying to do to me?"

        scene e5f3-ruby2_06 with dissolve
        unknown "I'm going to eat you whole."

        scene e5f3-ruby2_05 with dissolve
        mc "Haha, what?"

        scene e5f3-ruby2_07 with dissolve
        pause

        scene e5f3-ruby2_08 with dissolve
        pause

        scene e5f3-ruby2_10 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e5f3-ruby2_09 with dissolve
            mc "*She looks very horny.*"

            scene e5f3-ruby2_11 with dissolve
            unknown "Let's see what you're hiding down there."

            scene e5f3-ruby2_12 with dissolve
            pause

            scene e5f3-ruby2_13 with dissolve
            unknown "Wow!"

            scene e5f3-ruby2_14 with dissolve
            unknown "Where are you keeping this hidden?"

            scene e5f3-ruby2_15 with dissolve
            unknown "Just sit back and let me work my magic."

            scene e5f3-ruby2_16 with dissolve
            mc "Are you always this excited?"

            scene e5f3-ruby2_17 with dissolve
            unknown "Not always."

            scene e5f3-ruby2_18 with dissolve
            unknown "But you dear have something very special down here."

            scene e5f3-handjob1 with dissolve
            mc "Ahh..."

            scene e5f3-handjob3 with dissolve
            pause

            scene e5f3-ruby2_17 with dissolve
            unknown "We'll have a lot of fun together."

            scene e5f3-handjob2 with dissolve
            mc "Those are some big words coming out of your mouth."

            scene e5f3-handjob1 with dissolve
            pause

            scene e5f3-handjob3 with dissolve
            unknown "Just wait until you see what fills it."

            scene e5f3-handjob1 with dissolve
            mc "I think I might have a slight idea."

            scene e5f3-handjob4 with dissolve
            pause

            scene e5f3-handjob5 with dissolve
            pause

            scene e5f3-handjob6 with dissolve
            pause

            scene e5f3-ruby2_17 with dissolve
            unknown "I'll get down to it, but I have one small rule."

            scene e5f3-handjob4 with dissolve
            mc "What is it?"

            scene e5f3-handjob5 with dissolve
            unknown "No touching."
            unknown "I hate having my hair touched."

            scene e5f3-ruby2_14 with dissolve
            unknown "So, don't get any ideas."

            scene e5f3-ruby2_19 with dissolve
            if affinity_spectrum > 0:
                mc "Bummer."
            else:
                mc "You got it."

            scene e5f3-blowjob1 with dissolve
            mc "Ahhh..."
            mc "That feels amazing."

            scene e5f3-blowjob2 with dissolve
            pause

            scene e5f3-blowjob3 with dissolve
            pause

            scene e5f3-blowjob1 with dissolve
            mc "Keep going."

            scene e5f3-blowjob3 with dissolve
            mc "*Fuck... her mouth is so warm.*"
            mc "*She's got a great technique.*"

            scene e5f3-blowjob2 with dissolve
            mc "*I'm not sure how long I'll last.*"

            scene e5f3-blowjob1 with dissolve
            pause

            scene e5f3-blowjob3 with dissolve
            pause

            scene e5f3-blowjob2 with dissolve
            pause

            scene e5f3-blowjob4 with dissolve
            mc "Ohh..."

            scene e5f3-blowjob6 with dissolve
            pause

            scene e5f3-blowjob5 with dissolve
            mc "Do you... ah-offer any other services?"

            scene e5f3-ruby2_14 with dissolve
            unknown "Haha, is this not enough for you?"

            scene e5f3-ruby2_19 with dissolve
            mc "It is, just curious."

            scene e5f3-ruby2_20 with dissolve
            unknown "I do, but not tonight."

            scene e5f3-ruby2_14 with dissolve
            unknown "Stop by my club and who knows? Maybe I'll treat you to something nice."

            scene e5f3-blowjob4 with dissolve
            mc "Ahh..."
            mc "Damn, keep going."

            scene e5f3-blowjob5 with dissolve
            pause

            scene e5f3-blowjob6 with dissolve
            pause

            scene e5f3-blowjob5 with dissolve
            pause

            scene e5f3-blowjob4 with dissolve
            mc "I think I'm getting close."

            scene e5f3-handjob7 with dissolve
            unknown "Cum for me."
            unknown "Give me that sweet cum."
            mc "Ahhhh..."
            mc "I'm cumming!"
            scene e5f3-ruby2_21 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5f3-ruby2_22 with dissolve
            if affinity_spectrum > 0:
                mc "Fuck... that was amazing."
            else:
                mc "Ohh... that was amazing."

            scene e5f3-ruby2_23 with dissolve
            unknown "I'm glad you enjoyed it."
            unknown "Let me get cleaned up and then we can return to the party."

            scene e5f3-ruby2_24 with dissolve
            pause

            scene e5f3-ruby2_25 with dissolve
            mc "Hey, but I never got the chance to ask your name."

            scene e5f3-ruby2_26 with dissolve
            unknown "Haha, it's [ru]."

            scene e5f3-ruby2_27 with dissolve
            mc "Cool name, I'm [mc]."

            scene e5f3-ruby2_26 with dissolve
            ru "Nice to officially know you, [mc]."

            scene e5f3-ruby2_28 with dissolve
            ru "I assume we'll be seeing each other again in the near future."

            scene e5f3-ruby2_27 with dissolve
            mc "Haha, I hope so."

            scene e5f3-ruby2_29 with dissolve
            pause

            scene e5f3-ruby2_30 with dissolve
            pause

            stop music fadeout 2.0
            scene e5f3-ruby2_31 with dissolve
            mc "*Shit... I should get it cleaned.*"
        else:
            if persistent.type_nsfw == False:
                scene e5f3-ruby2_09_cen with dissolve
                mc "*She looks very horny.*"

                scene e5f3-ruby2_11 with dissolve
                unknown "Let's see what you're hiding down there."

                scene e5f3-ruby2_12 with dissolve
                pause

                scene e5f3-ruby2_13_cen with dissolve
                unknown "Wow!"

                scene e5f3-ruby2_14_cen with dissolve
                unknown "Where are you keeping this hidden?"

                scene e5f3-ruby2_15_cen with dissolve
                unknown "Just sit back and let me work my magic."

                scene e5f3-ruby2_16_cen with dissolve
                mc "Are you always this excited?"

                scene e5f3-ruby2_17_cen with dissolve
                unknown "Not always."

                scene e5f3-ruby2_18_cen with dissolve
                unknown "But you dear have something very special down here."

                scene e5f3-handjob1_cen with dissolve
                mc "Ahh..."

                scene e5f3-handjob3_cen with dissolve
                pause

                scene e5f3-ruby2_17_cen with dissolve
                unknown "We'll have a lot of fun together."

                scene e5f3-handjob2_cen with dissolve
                mc "Those are some big words coming out of your mouth."

                scene e5f3-handjob1_cen with dissolve
                pause

                scene e5f3-handjob3_cen with dissolve
                unknown "Just wait until you see what fills it."

                scene e5f3-handjob1_cen with dissolve
                mc "I think I might have a slight idea."

                scene e5f3-handjob4_cen with dissolve
                pause

                scene e5f3-handjob5_cen with dissolve
                pause

                scene e5f3-handjob6_cen with dissolve
                pause

                scene e5f3-ruby2_17_cen with dissolve
                unknown "I'll get down to it, but I have one small rule."

                scene e5f3-handjob4_cen with dissolve
                mc "What is it?"

                scene e5f3-handjob5_cen with dissolve
                unknown "No touching."
                unknown "I hate having my hair touched."

                scene e5f3-ruby2_14_cen with dissolve
                unknown "So, don't get any ideas."

                scene e5f3-ruby2_19_cen with dissolve
                if affinity_spectrum > 0:
                    mc "Bummer."
                else:
                    mc "You got it."

                scene e5f3-blowjob1_cen with dissolve
                mc "Ahhh..."
                mc "That feels amazing."

                scene e5f3-blowjob2_cen with dissolve
                pause

                scene e5f3-blowjob3_cen with dissolve
                pause

                scene e5f3-blowjob1_cen with dissolve
                mc "Keep going."

                scene e5f3-blowjob3_cen with dissolve
                mc "*Fuck... her mouth is so warm.*"
                mc "*She's got a great technique.*"

                scene e5f3-blowjob2_cen with dissolve
                mc "*I'm not sure how long I'll last.*"

                scene e5f3-blowjob1_cen with dissolve
                pause

                scene e5f3-blowjob3_cen with dissolve
                pause

                scene e5f3-blowjob2_cen with dissolve
                pause

                scene e5f3-blowjob4_cen with dissolve
                mc "Ohh..."

                scene e5f3-blowjob6_cen with dissolve
                pause

                scene e5f3-blowjob5_cen with dissolve
                mc "Do you... ah-offer any other services?"

                scene e5f3-ruby2_14_cen with dissolve
                unknown "Haha, is this not enough for you?"

                scene e5f3-ruby2_19_cen with dissolve
                mc "It is, just curious."

                scene e5f3-ruby2_20_cen with dissolve
                unknown "I do, but not tonight."

                scene e5f3-ruby2_14_cen with dissolve
                unknown "Stop by my club and who knows? Maybe I'll treat you to something nice."

                scene e5f3-blowjob4_cen with dissolve
                mc "Ahh..."
                mc "Damn, keep going."

                scene e5f3-blowjob5_cen with dissolve
                pause

                scene e5f3-blowjob6_cen with dissolve
                pause

                scene e5f3-blowjob5_cen with dissolve
                pause

                scene e5f3-blowjob4_cen with dissolve
                mc "I think I'm getting close."

                scene e5f3-handjob7_cen with dissolve
                unknown "Cum for me."
                unknown "Give me that sweet cum."
                mc "Ahhhh..."
                mc "I'm cumming!"
                scene e5f3-ruby2_21_cen with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5f3-ruby2_22_cen with dissolve
                if affinity_spectrum > 0:
                    mc "Fuck... that was amazing."
                else:
                    mc "Ohh... that was amazing."

                scene e5f3-ruby2_23_cen with dissolve
                unknown "I'm glad you enjoyed it."
                unknown "Let me get cleaned up and then we can return to the party."

                scene e5f3-ruby2_24_cen with dissolve
                pause

                scene e5f3-ruby2_25 with dissolve
                mc "Hey, but I never got the chance to ask your name."

                scene e5f3-ruby2_26 with dissolve
                unknown "Haha, it's [ru]."

                scene e5f3-ruby2_27 with dissolve
                mc "Cool name, I'm [mc]."

                scene e5f3-ruby2_26 with dissolve
                ru "Nice to officially know you, [mc]."

                scene e5f3-ruby2_28 with dissolve
                ru "I assume we'll be seeing each other again in the near future."

                scene e5f3-ruby2_27 with dissolve
                mc "Haha, I hope so."

                scene e5f3-ruby2_29 with dissolve
                pause

                scene e5f3-ruby2_30 with dissolve
                pause

                stop music fadeout 2.0
                scene e5f3-ruby2_31 with dissolve
                mc "*Shit... I should get it cleaned.*"

    $ renpy.end_replay()
return

# Kitchen ###
label e5f3_kitchen:
    if e5f3_roman1 == True and e5f3_roman_return == False:
        if e5f3_roman_return_remaining > 0:
            $ e5f3_roman_return_remaining -= 1
        else:
            $ e5f3_roman_return = True


    if e5f3_roman1 == False:
        scene e5f3-04
    else:
        if e5f3_roman_return == False:
            scene e5f3-04_1
        else:
            scene e5f3-04_2
    call screen e5f3_kitchen with dissolve
return
