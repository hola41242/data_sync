
# Scene 5 - Alice's dorm. ######################################################

label e5s5:
    stop music fadeout 2.0
    scene e5s5-01 with wipeleft
    pause

    play music bpam
    scene e5s5-02 with dissolve
    mc "*Shit, not now [jon].*"
    mc "*I'll call him later.*"

    scene e5s5-04 with dissolve
    al "So... here's my dorm!"

    scene e5s5-05 with dissolve
    al "That's my corner..."

    scene e5s5-06 with dissolve
    al "...and that's my roommate's."

    scene e5s5-07 with dissolve
    mc "Wow. It's like two completely different worlds."

    scene e5s5-08 with dissolve
    al "My roommate doesn't really like it when I play guitar, says it messes with her 'thinking process' or whatever."

    scene e5s5-09 with dissolve
    al "I try not to worry about it too much."

    scene e5s5-08 with dissolve
    al "Besides, she's hardly ever here."

    scene e5s5-11 with dissolve
    al "But she does give me the creeps sometimes."

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "Haha, why's that?"

    scene e5s5-08 with dissolve
    hide e5s5_alice_blink1
    al "I don't know, dude. It's like every time I touch my guitar she just materializes out of nowhere."
    al "Like she has some kind of trigger or something."

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "Wanna try it now and see if she shows up?"

    scene e5s5-10 with dissolve
    hide e5s5_alice_blink1
    al "Haha, please no! I don't want to torture myself."

    scene e5s5-04 with dissolve
    al "Anyway, let me grab the sheets."

    scene e5s5-12 with dissolve
    mc "You really like posters, huh?"

    scene e5s5-13 with dissolve
    al "You should see my book collection!"

    scene e5s5-14 with dissolve
    if affinity_spectrum > 0:
        mc "*Book collection, huh?*"

    mc "Wait, [ev] actually lets you keep them?"
    mc "I almost got killed for returning mine late."

    scene e5s5-15 with dissolve
    al "Haha, not all of them are borrowed."

    scene e5s5-16 with dissolve
    al "Here are the sheets! These are like half of them. The other half's at [ev]'s."

    scene e5s5-11 with dissolve
    al "Do you like them?"

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "I want to say yes, but honestly... I don't understand half of this."

    scene e5s5-17 with dissolve
    hide e5s5_alice_blink1
    al "Come on, really?"

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "Hey, don't blame me! I'm just doing what I'm told in College Rock."

    scene e5s5-08 with dissolve
    hide e5s5_alice_blink1
    al "You should start learning to play by notes, too."
    al "Not everything is played by ear, you know?"

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "Yeah, I get that. I'm still new to all this."

    scene e5s5-11 with dissolve
    hide e5s5_alice_blink1
    al "Fair enough."

    scene e5s5-04 with dissolve
    al "Wanna play it?"

    scene e5s5-03 with dissolve
    show e5s5_alice_blink1
    mc "Play it? Play it how?"

    scene e5s5-18 with dissolve
    hide e5s5_alice_blink1
    al "I've got two guitars."

    stop music fadeout 2.0
    if affinity_spectrum > 0:
        scene e5s5-19 with dissolve
    else:
        scene e5s5-20 with dissolve
    al "I'll play my part, and you play yours."
    al "You just have to memorize it for now."
    al "It's only four chords. Listen."

    play music sad_guitar
    scene e5s5-21 with dissolve
    pause(0.25)

    scene e5s5-22 with dissolve
    pause(0.25)

    scene e5s5-21 with dissolve
    pause(0.25)

    scene e5s5-22 with dissolve
    pause(0.25)

    scene e5s5-21 with dissolve
    pause(0.25)

    scene e5s5-22 with dissolve
    pause(0.25)

    scene e5s5-21 with dissolve
    pause(0.25)

    scene e5s5-22 with dissolve
    pause(0.25)

    scene e5s5-23 with dissolve
    pause

    scene e5s5-24 with dissolve
    pause

    scene e5s5-25 with dissolve
    pause

    scene e5s5-26 with dissolve
    pause(0.25)

    scene e5s5-27 with dissolve
    pause(0.25)

    scene e5s5-26 with dissolve
    pause(0.25)

    scene e5s5-27 with dissolve
    pause(0.25)

    scene e5s5-28 with dissolve
    pause

    scene e5s5-29 with dissolve
    al "Yeah, yeah, just like that!"
    al "Look at you, you're getting it."

    scene e5s5-30 with dissolve
    mc "I'm doing it... yeah!"

    scene e5s5-31 with dissolve
    mc "This is the first time I've picked up a melody this fast."

    scene e5s5-32 with dissolve
    pause

    scene e5s5-33 with dissolve
    pause

    scene e5s5-34 with dissolve
    pause

    scene e5s5-35 with dissolve
    pause

    scene e5s5-36 with dissolve
    pause

    scene e5s5-37 with dissolve
    pause

    scene e5s5-38 with dissolve
    pause

    scene e5s5-39 with dissolve
    pause

    scene e5s5-40 with dissolve
    pause

    scene e5s5-53 with dissolve
    pause

    scene e5s5-54 with dissolve
    pause

    scene e5s5-55 with dissolve
    pause

    scene e5s5-56 with dissolve
    menu:
        "Kiss [al]":
            $ e5s5_kiss = True
            $ alice_trust += 2

            scene e5s5-57 with dissolve
            pause

            scene e5s5-58 with dissolve
            pause

            scene e5s5-59 with dissolve
            al "Oh... I- uh..."

            scene e5s5-60 with dissolve
            al "Sorry!"

            scene e5s5-61 with dissolve
            mc "No, no, why are you apologizing for?"

            scene e5s5-60 with dissolve
            al "This got a bit awkward."

            scene e5s5-61 with dissolve
            mc "Well, I liked it."

            scene e5s5-62 with dissolve
            al "Oh my God, that came out wrong, didn't it?"

            scene e5s5-60 with dissolve
            al "Shit..."

            scene e5s5-59 with dissolve
            al "I also liked it, I loved it."
            al "I don't know why I said that."

            scene e5s5-61 with dissolve
            mc "Haha, it's alright, I get what you're trying to say."

            scene e5s5-62 with dissolve
            al "Wanna... uh... do it again?"

            scene e5s5-57 with dissolve
            pause

            scene e5s5-58 with dissolve
            pause
        "Keep playing":
            pass

    scene e5s5-41 with dissolve
    pause

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "Damn... so this is what we're playing at the competition?"

    scene e5s5-43 with dissolve
    hide e5s5_alice_blink2
    al "Something like that, yeah. But this is just the second half, and it's not finished yet."

    scene e5s5-44 with dissolve
    al "That's why I've got it at my place right now."

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "How come [ev] never showed this to us?"

    scene e5s5-45 with dissolve
    hide e5s5_alice_blink2
    al "Because we need to get good at the first part first. Once we've nailed that, we can start practicing this one too."

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "You really thought this through, didn't you?"
    mc "If it works out, I can totally see us blowing everyone out of the water with it."

    scene e5s5-46 with dissolve
    hide e5s5_alice_blink2
    al "Yeah, it took us a long time to come up with."

    scene e5s5-45 with dissolve
    al "This part is also easier to play, which is why we're focusing so much on the first part."

    scene e5s5-44 with dissolve
    al "We want to make a strong first impression, then finish with something simpler so we don't get exhausted."

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "Wow, that honestly sounds like a solid plan."

    scene e5s5-45 with dissolve
    hide e5s5_alice_blink2
    al "Thank you!"
    al "I'm really excited to perform it."

    scene e5s5-47 with dissolve
    play sound phone_buzz
    pause

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "Shit! Sorry, I have to take this."

    scene e5s5-46 with dissolve
    hide e5s5_alice_blink2
    al "Go ahead!"

    scene e5s5-49 with dissolve
    jon "Bro! Where the fuck are you?"

    scene e5s5-48 with dissolve
    mc "Whoa, slow down. What happened? I was busy."

    scene e5s5-49 with dissolve
    jon "I need you, ASAP!"
    jon "Get to the Party Ragers, it's about our situation."

    if affinity_spectrum > 0:
        scene e5s5-50 with dissolve
        mc "Alright, I'm coming, jeez!"
    else:
        scene e5s5-51 with dissolve
        mc "Okay, okay, I'm on my way."

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "Sorry [al], but I really have to go."

    scene e5s5-46 with dissolve
    hide e5s5_alice_blink2
    al "Don't worry, it's fine."

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "Thanks for showing me the piece!"
    mc "I really enjoyed it."

    scene e5s5-44 with dissolve
    hide e5s5_alice_blink2
    al "I enjoyed playing it with you too."

    scene e5s5-45 with dissolve
    al "See you around!"

    scene e5s5-42 with dissolve
    show e5s5_alice_blink2
    mc "See you!"

    scene e5s5-52 with dissolve
    hide e5s5_alice_blink2
    pause

    jump e5s6
return
