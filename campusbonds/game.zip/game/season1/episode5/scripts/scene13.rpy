
# Scene 13 - Amber's rehearsal #################################################

label e5s13:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music words_fall_apart
    scene e5s13-01 with Dissolve(2.0)
    pause

    scene e5s13-02 with dissolve
    pause

    scene e5s13-03 with dissolve
    play sound door_open
    pause

    scene e5s13-04 with dissolve
    pause

    scene e5s13-05 with dissolve
    am "Oh, [mc], hi!"

    scene e5s13-06 with dissolve
    am "I... uh-didn't expect to see you here."

    scene e5s13-07 with dissolve
    mc "I didn't expect to see you here either."

    scene e5s13-08 with dissolve
    pause

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "I was walking by and heard someone playing."

    scene e5s13-10 with dissolve
    hide e5s13_amber_blink1
    am "Ah, I see."
    am "I was just practicing a bit."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "That's a piano, huh?"

    scene e5s13-10 with dissolve
    hide e5s13_amber_blink1
    am "Yup, my favorite instrument."

    scene e5s13-11 with dissolve
    am "Sorry if I disturbed you."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "It's fine. It's not like you forced me to listen."

    if e4s11_tell == True or e4s27_listen == False:
        scene e5s13-11 with dissolve
        hide e5s13_amber_blink1
        am "...Didn't you tell me to stay away, though?"

        scene e5s13-12 with dissolve
        am "I'm not doing a very good job at that."

        scene e5s13-09 with dissolve
        show e5s13_amber_blink1
        mc "It's fine, don't worry."
    else:
        scene e5s13-09 with dissolve
        show e5s13_amber_blink1
    mc "I'll uh... leave you to it."

    scene e5s13-13 with dissolve
    hide e5s13_amber_blink1
    am "I could teach you, you know."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "Teach me?"

    scene e5s13-14 with dissolve
    hide e5s13_amber_blink1
    am "Yeah, come on. It'll be fun."

    scene e5s13-12 with dissolve
    am "What? I can teach things too, not just the girls in College Rock."

    scene e5s13-13 with dissolve
    am "Besides, piano is my instrument."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "Really? Is this some cheap trick to get something out of me?"

    scene e5s13-15 with dissolve
    hide e5s13_amber_blink1
    am "Of course not."
    am "What would I even get out of you?"

    scene e5s13-13 with dissolve
    am "Well... except pleasure, I guess."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    mc "I don't know, info about the competition?"

    scene e5s13-15 with dissolve
    hide e5s13_amber_blink1
    am "Come on, it's just me here."
    am "You don't have to say anything."

    scene e5s13-10 with dissolve
    am "Just sit down. It'll be fun, trust me."

    scene e5s13-09 with dissolve
    show e5s13_amber_blink1
    if e5s9_talk == True:
        mc "Yeah? And what about the stuff with [fr]?"
        mc "I talked to her, you know? She had a different opinion about you."

        scene e5s13-11 with dissolve
        hide e5s13_amber_blink1
        am "Alright, look. Why don't you sit down and we can talk about that?"

        scene e5s13-12 with dissolve
        am "You don't even have to play if you don't want to."
        am "But maybe we should just settle this."

        scene e5s13-09 with dissolve
        show e5s13_amber_blink1
        mc "..."

    mc "Okay, but I'm being extra careful."

    scene e5s13-16 with dissolve
    hide e5s13_amber_blink1
    am "You can strap a condom to your head if that makes you feel better."

    scene black with Dissolve(2.0)

    scene e5s13-17 with Dissolve(2.0)
    pause

    if e5s9_talk == True:
        scene e5s13-18 with dissolve
        show e5s13_amber_blink2
        mc "Okay... so, [fr]?"

        scene e5s13-21 with dissolve
        hide e5s13_amber_blink2
        am "Yeah, what about her?"
        am "What happened?"

        scene e5s13-18 with dissolve
        show e5s13_amber_blink2
        if e4s27_listen == True:
            mc "You lied to me!"
            mc "She never bought anyone over, neither did she take your place in the squad."
        else:
            mc "You told me to ask her about what happened."
            mc "Well, I did, and you took things out of context."

        mc "So, what's up with that, huh?"

        scene e5s13-42 with dissolve
        hide e5s13_amber_blink2
        am "Listen, I'm only going to say this once, and if you want to listen, fine."
        am "If not... then you're free to leave."

        scene e5s13-43 with dissolve
        am "That club doesn't owe you shit, they're gonna throw you out the first chance they get."

        scene e5s13-26 with dissolve
        am "Don't believe me? Just slip up, make a mistake."

        scene e5s13-44 with dissolve
        am "Nobody even told me I was kicked, I had to sit outside the building to get a reply."

        scene e5s13-26 with dissolve
        am "Imagine how I felt when I saw Francesca with them later on, in my place."
        am "She couldn't even be straight with me."

        scene e5s13-27 with dissolve
        show e5s13_amber_blink3
        menu:
            "Believe [am]":
                $ e5s13_believe_amber = True
                mc "Okay..."

                scene e5s13-26 with dissolve
                hide e5s13_amber_blink3
                am "Okay what?"

                scene e5s13-27 with dissolve
                show e5s13_amber_blink3
                mc "I believe you, I'm gonna be on high alert with College Rock."

                scene e5s13-42 with dissolve
                hide e5s13_amber_blink3
                am "Finally, can we get back to our piano, please?"

                scene e5s13-27 with dissolve
                show e5s13_amber_blink3
                mc "Yeah..."

                scene e5s13-26 with dissolve
                hide e5s13_amber_blink3
                am "Thank you!"
            "Be doubtful":
                mc "Yeah... I'm not buying any of this."
                mc "I think you're just playing me."
                mc "Maybe [fr]'s right, I shouldn't trust you."

                scene e5s13-26 with dissolve
                hide e5s13_amber_blink3
                am "Alright. It's your choice."
                am "But don't come crying after they kick you out too."

                scene e5s13-27 with dissolve
                show e5s13_amber_blink3
                mc "That's not going to happen."

                scene e5s13-44 with dissolve
                hide e5s13_amber_blink3
                am "I hope it doesn't."

                scene e5s13-26 with dissolve
                am "See you, [mc]!"

                scene e5s13-27 with dissolve
                show e5s13_amber_blink3
                mc "Hopefully not."

                scene e5s13-45 with dissolve
                hide e5s13_amber_blink3
                pause

                scene e5s13-46 with dissolve
                pause

                jump e5s14

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "So... how are we doing this?"

    scene e5s13-19 with dissolve
    hide e5s13_amber_blink2
    am "Let's start with the basics."

    scene e5s13-20 with dissolve
    am "This here is middle C, your home base."
    am "Notes get higher as you go right, lower as you go left."

    scene e5s13-21 with dissolve
    am "Keep your hands relaxed, curved. Let your fingers walk over the keys."
    am "It's not just about hitting the right notes, it's about timing and rhythm."

    scene e5s13-19 with dissolve
    am "I'll guide you through a simple melody."

    scene e5s13-22 with dissolve
    mc "Kinda feels like a guitar."

    scene e5s13-23 with dissolve
    am "Of course. Same notes, same concepts."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "I know I said I wouldn't talk about the competition, but... are you entering?"

    scene e5s13-24 with dissolve
    hide e5s13_amber_blink2
    am "Yeah. I can't pass up a chance this big."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "Are you performing with a club?"

    scene e5s13-21 with dissolve
    hide e5s13_amber_blink2
    am "Nope. Going solo."
    am "The piece I was rehearsing, that's what I'm playing."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "You might want to do a little better than that."

    scene e5s13-25 with dissolve
    hide e5s13_amber_blink2
    am "Getting cocky, huh? Was it really that bad?"

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "Not at all. But can it compete with a full band?"

    scene e5s13-26 with dissolve
    hide e5s13_amber_blink2
    am "Wait, you're going too?"

    scene e5s13-27 with dissolve
    show e5s13_amber_blink3
    mc "I don't know yet. Depends if they even take me."

    scene e5s13-26 with dissolve
    hide e5s13_amber_blink3
    am "Why wouldn't they?"

    scene e5s13-27 with dissolve
    show e5s13_amber_blink3
    mc "I only got into music a few weeks ago."
    mc "I'm not sure I'm ready. What if I mess up? Or freeze up?"

    scene e5s13-28 with dissolve
    hide e5s13_amber_blink3
    am "I doubt that."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "Why's that?"

    scene e5s13-21 with dissolve
    hide e5s13_amber_blink2
    am "I don't know you well, but you seem like the type who'd do great on stage."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "You sure?"

    scene e5s13-28 with dissolve
    hide e5s13_amber_blink2
    am "Hey, you're willing to learn. That's more than most."

    scene e5s13-19 with dissolve
    am "Mistakes happen. Don't cling to them."

    scene e5s13-25 with dissolve
    am "You'll do fine. It's just a competition, not the end of the world."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "Yeah... maybe you're right."

    scene e5s13-29 with dissolve
    hide e5s13_amber_blink2
    mc "..."

    scene e5s13-30 with dissolve
    am "You tense up every time you miss a note."
    am "You don't have to be perfect."

    scene e5s13-31 with dissolve
    mc "Easy for you to say."

    scene e5s13-32 with dissolve
    am "It's not easy. I just learned when to let go."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    mc "There are just... so many notes to think about."

    scene e5s13-28 with dissolve
    hide e5s13_amber_blink2
    am "Relax. Don't stress over it."

    scene e5s13-32 with dissolve
    am "Mess up, who cares?"

    scene e5s13-33 with dissolve
    am "...Here, I could help you relax if you want."
    mc "Huh?"

    scene e5s13-25 with dissolve
    am "Don't look so shocked."
    am "I'm just saying, a little... release might help your nerves."

    scene e5s13-18 with dissolve
    show e5s13_amber_blink2
    menu:
        "Relax with [am]":
            call extrovert_affinity_check from _call_extrovert_affinity_check_82
            call color_check from _call_color_check_158
            $ e5s13_amber_lewd = True
            call e5s13_amber_lewd from _call_e5s13_amber_lewd

            scene e5s13-17 with Dissolve(2.0)
            hide e5s13_amber_blink2
            pause

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "Thanks for the lesson... and the happy ending."

            scene e5s13-25 with dissolve
            hide e5s13_amber_blink2
            am "Happy to help!"

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "I... think it'd be great if you could teach me more sometime."

            scene e5s13-25 with dissolve
            hide e5s13_amber_blink2
            am "So you did like it!"

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "Yeah. I feel like I actually learned something today."
            mc "And, well... having another person teaching me wouldn't hurt."

            scene e5s13-26 with dissolve
            hide e5s13_amber_blink2
            am "Are you sure you want that?"
            am "I don't want you getting in trouble."

            scene e5s13-24 with dissolve
            am "Today wasn't even planned."

            scene e5s13-27 with dissolve
            show e5s13_amber_blink3
            mc "Yeah... maybe you're right. Forget I said anything."

            scene e5s13-47 with dissolve
            hide e5s13_amber_blink3
            am "No, I'm not bothered. I'm just watching out for you."

            if e4s11_tell == True:
                scene e5s13-44 with dissolve
                am "I could've helped you right inside College Rock. They've got so many instruments there."

                scene e5s13-26 with dissolve
                am "But [ev] won't let me go near the place anymore."
                am "So all we've really got is this piano, which is fine."

                scene e5s13-44 with dissolve
                am "But I'm not sure piano is the instrument you're actually aiming for."

                scene e5s13-27 with dissolve
                show e5s13_amber_blink3
                mc "Yeah... true. I'm better with guitar right now."
                mc "And I don't have time to learn something totally new."

                scene e5s13-44 with dissolve
                hide e5s13_amber_blink3
            else:
                scene e5s13-44 with dissolve
            am "Look, if you really want to, we can rehearse in College Rock anyway."

            scene e5s13-47 with dissolve
            am "You've got your guitar there. I've got my piano."

            scene e5s13-26 with dissolve
            am "We could just play something together. Doesn't even have to be for the competition."
            am "Just... a little song between friends."

            scene e5s13-27 with dissolve
            show e5s13_amber_blink3
            mc "That could work."

            scene e5s13-28 with dissolve
            hide e5s13_amber_blink3
            am "Great! We'll stay in touch, okay?"

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "Yeah, sure."

            scene e5s13-49 with dissolve
            hide e5s13_amber_blink2
            pause

            scene e5s13-48 with dissolve
            pause
        "Refuse her":
            call introvert_affinity_check from _call_introvert_affinity_check_72
            call color_check from _call_color_check_159
            mc "No. I'm sorry, this went way too far."
            mc "I thought you actually wanted to teach me something."

            scene e5s13-47 with dissolve
            hide e5s13_amber_blink2
            am "But I did!"
            am "I was teaching you to loosen up."

            scene e5s13-27 with dissolve
            show e5s13_amber_blink3
            mc "You're not helping."

            scene e5s13-47 with dissolve
            hide e5s13_amber_blink3
            am "Come on, you were doing so well."
            am "I just wanted to help you ease up a bit."

            scene e5s13-27 with dissolve
            show e5s13_amber_blink3
            mc "Thanks for the lesson, but I'm out of here."

            scene e5s13-47 with dissolve
            hide e5s13_amber_blink3
            am "Did I scare you off that badly?"

            scene e5s13-50 with dissolve
            pause

            scene e5s13-51 with dissolve
            am "A fucking 'thanks' would've been nice!"

            scene e5s13-52 with vpunch
            am "Jerk."

    jump e5s14
return

label e5s13_amber_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if _in_replay:
            play music blues_of_t
            scene e5s13-29 with dissolve
            hide e5s13_amber_blink2
            mc "..."

            scene e5s13-30 with dissolve
            am "You tense up every time you miss a note."
            am "You don't have to be perfect."

            scene e5s13-31 with dissolve
            mc "Easy for you to say."

            scene e5s13-32 with dissolve
            am "It's not easy. I just learned when to let go."

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "There are just... so many notes to think about."

            scene e5s13-28 with dissolve
            hide e5s13_amber_blink2
            am "Relax. Don't stress over it."

            scene e5s13-32 with dissolve
            am "Mess up, who cares?"

            scene e5s13-33 with dissolve
            am "...Here, I could help you relax if you want."
            mc "Huh?"

            scene e5s13-25 with dissolve
            am "Don't look so shocked."
            am "I'm just saying, a little... release might help your nerves."

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
        mc "I could ease up a bit."

        scene e5s13-33 with dissolve
        hide e5s13_amber_blink2
        am "That's my guy!"

        scene e5s13-34 with dissolve
        mc "Wait... what if someone walks in?"

        scene e5s13-35 with dissolve
        am "Don't worry, I'll be quick."
        am "We're facing away from the door, they can't see us."

        if persistent.disable_nsfw == True:
            scene e5s13-36 with dissolve
            am "See? Much easier when you stop thinking."

            scene e5s13-handjob2 with dissolve
            am "Good boy!"

            scene e5s13-handjob1 with dissolve
            mc "*Fuck... that feels really good!*"

            scene e5s13-handjob3 with dissolve
            mc "*[am] knows what she's doing.*"

            scene e5s13-handjob4 with dissolve
            mc "*It's so hard to resist her.*"

            scene e5s13-25 with dissolve
            am "You're getting better!"
            am "Your play starts making sense."

            scene e5s13-handjob2 with dissolve
            mc "That's... uh-good to know!"

            scene e5s13-handjob3 with dissolve
            am "Hope I'm not being too rough, am I?"

            scene e5s13-handjob1 with dissolve
            mc "No, no, it's perfect."
            mc "Just like that... yeah!"

            scene e5s13-handjob4 with dissolve
            am "I'll speed it up a notch."

            scene e5s13-handjob5 with dissolve
            am "Tell me how it feels."

            scene e5s13-37 with dissolve
            mc "It feels great!"

            scene e5s13-38 with dissolve
            am "Hey, hey! Don't get distracted."
            am "Keep on playing."

            scene e5s13-39 with dissolve
            mc "But it's uh-hard to when you're that good!"

            scene e5s13-handjob6 with dissolve
            am "You want me to be worse?"

            scene e5s13-handjob7 with dissolve
            mc "No, no, just... keep on doing it."
            mc "I'm almost there."

            scene e5s13-handjob5 with dissolve
            am "Alright, let's see what you're made of."

            scene e5s13-handjob8 with dissolve
            mc "Ah, shit!"
            mc "I'm gonna cum [am]!"
            scene e5s13-40 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5s13-41 with dissolve
            mc "Oh..."
            mc "Fuck... I don't think I can play anymore."

            scene e5s13-25 with dissolve
            am "Was it too relaxing?"

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            mc "Just a bit, yeah."
            mc "You take over while I clean it up."

            scene e5s13-25 with dissolve
            hide e5s13_amber_blink2
            am "Sure thing, darling!"

            scene e5s13-18 with dissolve
            show e5s13_amber_blink2
            scene black with Dissolve(2.0)
        else:
            if persistent.type_nsfw == False:
                scene e5s13-36_cen with dissolve
                am "See? Much easier when you stop thinking."

                scene e5s13-handjob2_cen with dissolve
                am "Good boy!"

                scene e5s13-handjob1_cen with dissolve
                mc "*Fuck... that feels really good!*"

                scene e5s13-handjob3_cen with dissolve
                mc "*[am] knows what she's doing.*"

                scene e5s13-handjob4_cen with dissolve
                mc "*It's so hard to resist her.*"

                scene e5s13-25 with dissolve
                am "You're getting better!"
                am "Your play starts making sense."

                scene e5s13-handjob2_cen with dissolve
                mc "That's... uh-good to know!"

                scene e5s13-handjob3_cen with dissolve
                am "Hope I'm not being too rough, am I?"

                scene e5s13-handjob1_cen with dissolve
                mc "No, no, it's perfect."
                mc "Just like that... yeah!"

                scene e5s13-handjob4_cen with dissolve
                am "I'll speed it up a notch."

                scene e5s13-handjob5_cen with dissolve
                am "Tell me how it feels."

                scene e5s13-37 with dissolve
                mc "It feels great!"

                scene e5s13-38 with dissolve
                am "Hey, hey! Don't get distracted."
                am "Keep on playing."

                scene e5s13-39 with dissolve
                mc "But it's uh-hard to when you're that good!"

                scene e5s13-handjob6_cen with dissolve
                am "You want me to be worse?"

                scene e5s13-handjob7 with dissolve
                mc "No, no, just... keep on doing it."
                mc "I'm almost there."

                scene e5s13-handjob5_cen with dissolve
                am "Alright, let's see what you're made of."

                scene e5s13-handjob8_cen with dissolve
                mc "Ah, shit!"
                mc "I'm gonna cum [am]!"
                scene e5s13-40_cen with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5s13-41_cen with dissolve
                mc "Oh..."
                mc "Fuck... I don't think I can play anymore."

                scene e5s13-25 with dissolve
                am "Was it too relaxing?"

                scene e5s13-18 with dissolve
                show e5s13_amber_blink2
                mc "Just a bit, yeah."
                mc "You take over while I clean it up."

                scene e5s13-25 with dissolve
                hide e5s13_amber_blink2
                am "Sure thing, darling!"

                scene e5s13-18 with dissolve
                show e5s13_amber_blink2
                scene black with Dissolve(2.0)
    $ renpy.end_replay()
return
