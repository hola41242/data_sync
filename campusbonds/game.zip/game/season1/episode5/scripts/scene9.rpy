
# Scene 9 - Understanding Francesca (Tuesday) ##################################

label e5s9:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music frannie
    scene e5s9-13 with Dissolve(2.0)
    pause

    if e4s29_sweet == False:
        scene e5s9-15 with dissolve
        pause

        if e4s28_defensive == False:
            scene e5s9-14 with dissolve
            pause

            scene e5s9-23 with dissolve
            pause

            scene e5s9-16 with dissolve
            fr "[mc], hi..."

            scene e5s9-18 with dissolve
            fr "I... uh-how are you?"

            scene e5s9-17 with dissolve
            show e5s9_francesca_blink2
            mc "I'm going to class."
            mc "You?"

            scene e5s9-19 with dissolve
            hide e5s9_francesca_blink2
            fr "Me too actually!"

            scene e5s9-18 with dissolve
            fr "I was... thinking maybe we could walk together?"

            scene e5s9-20 with dissolve
            fr "And talk... if that's okay with you."

            scene e5s9-17 with dissolve
            show e5s9_francesca_blink2
            menu:
                "Stay mad at [fr]":
                    $ francesca_trust -= 1
                    mc "Sorry, I'm in a rush."
                    mc "Not really in the mood either."

                    scene e5s9-21 with dissolve
                    hide e5s9_francesca_blink2
                    fr "Oh... okay."

                    scene e5s9-22 with dissolve
                    fr "*I just... thought we could talk.*"
                "Hear her out":
                    $ e5s9_talk = True
                    $ francesca_trust += 1
                    mc "Sure."

                    scene e5s9-19 with dissolve
                    hide e5s9_francesca_blink2
                    fr "Okay, great!"

                    scene e5s9-24 with dissolve
                    pause
        else:
            scene e5s9-25 with dissolve
            pause
    else:
        scene e5s9-26 with dissolve
        pause

        if e4s28_defensive == False:
            $ e5s9_talk = True
            scene e5s9-28 with dissolve
            mc "Hey, you got a minute?"

            scene e5s9-21 with dissolve
            fr "Yeah..."

            scene e5s9-17 with dissolve
            show e5s9_francesca_blink2
            mc "I was just on my way to class. Maybe we can talk there?"

            scene e5s9-29 with dissolve
            hide e5s9_francesca_blink2
            fr "That sounds good."

            scene e5s9-17 with dissolve
            show e5s9_francesca_blink2
            mc "Uh... okay then, let's go."

            scene e5s9-29 with dissolve
            hide e5s9_francesca_blink2
            fr "Okay..."

            scene e5s9-24 with dissolve
            pause
        else:
            scene e5s9-27 with dissolve
            mc "Hey, you got a minute?"

            if e5s7_text == False:
                scene e5s9-31 with dissolve
                fr "No, actually I don't."
                fr "I'm in a hurry."

                scene e5s9-30 with dissolve
                mc "This will only take a minute."

                scene e5s9-33 with dissolve
                fr "I don't want to talk to you, okay?"

                scene e5s9-32 with dissolve
                fr "Just leave me alone."

                scene e5s9-34 with dissolve
                pause

                scene e5s9-35 with dissolve
                mc "*I think I messed this up really bad...*"
                mc "*She won't talk to me anymore.*"
            else:
                $ e5s9_talk = True
                scene e5s9-31 with dissolve
                fr "For what? To hurt me again?"

                scene e5s9-30 with dissolve
                mc "I'm really, really sorry about that."
                mc "I was an asshole, alright? I fucked up."
                mc "But I just wanna talk to you, sort this thing out."
                mc "At least give me a chance."
                mc "I wanna hear the full story, your story."
                mc "After that, you're free to stop talking to me if that makes you feel better."

                scene e5s9-33 with dissolve
                fr "It doesn't..."

                scene e5s9-31 with dissolve
                fr "Okay, fine, I'll tell you."

                scene e5s9-36 with dissolve
                fr "It's not like I wanted to pay attention to the class anyway."

                scene e5s9-38 with dissolve
                show e5s9_francesca_blink3
                mc "Really? That's your excuse?"

                scene e5s9-37 with dissolve
                hide e5s9_francesca_blink3
                fr "I had to make something up, duh."

                scene e5s9-36 with dissolve
                fr "Your text yesterday messed up my entire day, I couldn't think about anything else."
                fr "I wanted to kill you at that point."

                scene e5s9-38 with dissolve
                show e5s9_francesca_blink3
                mc "Should I be scared?"

                scene e5s9-37 with dissolve
                hide e5s9_francesca_blink3
                fr "No, no, I'm fine now. Unless you got other reasons to upset me?"

                scene e5s9-38 with dissolve
                show e5s9_francesca_blink3
                mc "Nope, I'm keeping my mouth shut."
                mc "I think we should better walk."

                scene e5s9-24 with dissolve
                hide e5s9_francesca_blink3
                pause

    if e5s9_talk == True:
        scene e5s9-01 with wipeleft
        pause

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "Look, I'm sorry for what happened with [am] and all."
        mc "Maybe I shouldn't have been so judgemental towards you."

        scene e5s9-03 with dissolve
        hide e5s9_francesca_blink1
        fr "Maybe I shouldn't have stormed out..."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        if e4s27_listen == True:
            mc "I just... didn't know how to react to what you said."

            scene e5s9-03 with dissolve
            hide e5s9_francesca_blink1
            fr "I understand. I should have told you everything from the start."

            scene e5s9-04 with dissolve
            fr "But... as bad as it seems, you don't know Amber like I do."

            scene e5s9-02 with dissolve
            show e5s9_francesca_blink1
        mc "Okay, but something doesn't add up."
        mc "[am] made it sound like you sabotaged her on purpose... so what actually happened?"
        mc "I'd like to hear your side of the story."

        scene e5s9-05 with dissolve
        hide e5s9_francesca_blink1
        fr "Look... I took her place in the squad, alright?"

        scene e5s9-06 with dissolve
        fr "But it wasn't a hostile take-over, I didn't even want the role to begin with!"

        scene e5s9-04 with dissolve
        fr "I was fine with being sidelined, I was fine waiting."

        scene e5s9-06 with dissolve
        fr "But [ev] basically told me that I'm either in, or they go with one member less."

        scene e5s9-07 with dissolve
        fr "Like, she would have been kicked out either way. I don't know why that was."

        scene e5s9-08 with dissolve
        fr "I just know that I wanted to help my club, it was a lose-lose situation anyway."

        scene e5s9-09 with dissolve
        fr "I was caught in the crossfire."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        if e4s27_listen == True:
            mc "What about the buying friends over?"

            scene e5s9-10 with dissolve
            hide e5s9_francesca_blink1
            fr "That is such an out of context line, oh my God."

            scene e5s9-11 with dissolve
            fr "I paid somebody once to help me pass a class who also happened to be a friend of hers and she assumed I started buying people over."
            fr "Yeah, I cheated, who doesn't?"
            fr "She certainly did, multiple times even. So don't be telling me."

            scene e5s9-12 with dissolve
        mc "I... I didn't know that."

        scene e5s9-10 with dissolve
        hide e5s9_francesca_blink1
        fr "Of course you didn't, why would she show the full context?"
        fr "She always shows what benefits her and her goals."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "She told me she quit on her own."
        mc "Was that... just another story she twisted?"

        scene e5s9-08 with dissolve
        hide e5s9_francesca_blink1
        fr "Yes and no."

        scene e5s9-09 with dissolve
        fr "From my understanding, after the competition [ev] wanted to have a chat with her."

        scene e5s9-07 with dissolve
        fr "She didn't show up at College Rock anymore and said she 'quits'."

        scene e5s9-06 with dissolve
        fr "After a few days, we met and she called me a bitch for stealing her spot."
        fr "That was basically it."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "Wow. That's... a lot more anticlimactic than she made it sound."

        scene e5s9-03 with dissolve
        hide e5s9_francesca_blink1
        fr "Yeah, you tell me."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "I wish you'd told me sooner..."

        scene e5s9-03 with dissolve
        hide e5s9_francesca_blink1
        fr "I'm sorry about how I acted. I know you just wanted to know the truth."

        scene e5s9-04 with dissolve
        fr "I got defensive because you would have been yet another person she takes from me."
        fr "It was hard thinking you'd believe her."

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "No, I get it. I pushed you, and I didn't try to understand."
        mc "It's part of my fault too."

        scene e5s9-04 with dissolve
        hide e5s9_francesca_blink1
        fr "So... are we good?"

        scene e5s9-02 with dissolve
        show e5s9_francesca_blink1
        mc "Yeah, we are."

        scene e5s9-01 with dissolve
        pause

    jump e5s10
return
