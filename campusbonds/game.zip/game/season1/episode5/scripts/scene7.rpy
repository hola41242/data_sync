
# Scene 7 - Reconnecting #######################################################

label e5s7:
    stop music fadeout 2.0
    scene e5s7-01 with wipeleft
    pause

    play music bloom
    scene e5s7-02 with dissolve
    pause

    scene e5s7-03 with dissolve
    mc "*What's [fr] up to?*"
    mc "*I didn't like how our last conversation ended.*"

    scene e5s7-04 with dissolve
    mc "*Should I text her?*"

    menu:
        "Text [fr]":
            $ e5s7_text = True
            $ francesca_trust += 1
            scene e5s7-05 with dissolve
            mc "*I hope she's doing okay.*"

            scene e5s7-06 with dissolve
            show e5s7_mc_blink1
            mc "*What should I even say?*"

            nvl clear

            menu (nvl = True):
                "Hey!":
                    $ e5s7_hey = True
                    mc "*I'll just send a simple 'hey' and see what happens.*"
                    n_nvl "Hey!"
                "How are you?":
                    $ e5s7_ask = True
                    $ francesca_trust += 1
                    n_nvl "Hey!"
                    n_nvl "How are you?"
                "Are you okay?":
                    $ e5s7_ask = True
                    $ francesca_trust += 1
                    n_nvl "Hey!"
                    n_nvl "Are you okay?"
                "I'm sorry":
                    $ e5s7_sorry = True
                    $ francesca_trust += 2
                    mc "*I'll apologize and hope it helps.*"
                    n_nvl "Hey!"
                    n_nvl "I'm really sorry about what happened earlier."
            mc "..."
            mc "*Maybe she's just busy, she's not replying.*"

            scene e5s7-07 with dissolve
            hide e5s7_mc_blink1
            pause

            scene e5s7-05 with dissolve
            pause

            scene e5s7-04 with dissolve
            mc "*Ugh, I don't know if I should text again. Maybe she's ignoring me... or just not on her phone.*"
            mc "*Why is this so hard?*"

            scene e5s7-01 with dissolve
            mc "*I'm worried I'll make things worse...*"

            scene e5s7-02 with dissolve
            play sound phone_buzz
            pause

            scene e5s7-03 with dissolve
            pause

            scene e5s7-05 with dissolve
            mc "*Shit, is that her?*"

            if e4s28_defensive == False:
                scene e5s7-06 with dissolve
                show e5s7_mc_blink1
                if e5s7_hey == True:
                    fr_nvl "Hey."

                    scene e5s7-07 with dissolve
                    hide e5s7_mc_blink1
                    mc "*Ugh, just a plain 'hey'.*"

                    scene e5s7-08 with dissolve
                    mc "*This feels awkward. Maybe I should've said more.*"
                    mc "*Maybe talking in person would be better.*"
                    mc "*But I'm not really in the mood for that right now.*"
                    mc "*Guess I'll see if I run into her in the halls.*"
                if e5s7_ask == True:
                    fr_nvl "I'm okay, you?"
                    mc "*Her response is kinda short, but I get it.*"
                    n_nvl "I'm okay too."
                    mc "*Maybe I should just be honest.*"
                    n_nvl "Honestly, hearing that you're okay feels good."
                    fr_nvl "I'm glad... I just didn't want things to stay so weird between us."
                    n_nvl "Yeah, me neither."
                    mc "*She stopped replying.*"
                    mc "*Looks like that's all I'm going to get for today.*"
                if e5s7_sorry == True:
                    fr_nvl "Thanks, that makes me feel a little better."
                    mc "*Awesome, this is a good start.*"
                    n_nvl "How have you been?"
                    fr_nvl "I haven't really felt like myself since we argued."
                    n_nvl "I've been thinking about it too."
                    fr_nvl "Are you okay?"
                    n_nvl "Yeah, honestly, just hearing from you helps."
                    n_nvl "I didn't think you'd reply, but I'm glad you did."
                    fr_nvl "I'm glad you texted."
                    n_nvl "I was thinking we could grab a coffee or something tomorrow, to sort this thing out."
                    fr_nvl "We got a class together, right? We could talk there."
                    n_nvl "Yeah, for sure. That works."
                    n_nvl "I'll see you there."
                    mc "*I think this is all I can squeeze from today's conversation.*"
            else:
                scene e5s7-07 with dissolve
                mc "*Just a stupid notification.*"

                scene e5s7-08 with dissolve
                mc "*Guess I'm not hearing back today.*"
                mc "*Maybe I'll bump into her in the halls.*"
        "Don't do it":
            mc "*Yeah, maybe it's better to leave it for now.*"

    scene e5s7-01 with dissolve
    hide e5s7_mc_blink1
    mc "*I better head out, I think I studied enough for today.*"

    scene e5s7-09 with dissolve
    pause

    jump e5s8
return
