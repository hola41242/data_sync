
# Scene 25 - Late shift (Second choice) ########################################

label e5s25:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music daft_punk
    scene e5s25-01 with Dissolve(2.0)
    pause

    scene e5s25-02 with dissolve
    pause(1.0)

    scene e5s25-03 with dissolve
    pause(1.0)

    scene e5s25-04 with dissolve
    pause(1.0)

    scene e5s25-05 with dissolve
    play sound phone_buzz
    pause

    scene e5s25-06 with vpunch
    play sound weights
    pause

    scene e5s25-07 with dissolve
    if e5s9_talk == False:
        al "Hey, [mc], is this a bad time?"

        scene e5s25-08 with dissolve
        mc "No, no, it's fine. What's up?"

        scene e5s25-07 with dissolve
        al "Look, I need some help with College Rock."
        al "I was supposed to work on the play but something came up."
        al "Could you go there and fill for me?"
        mc "*Damn, [jon] wanted me for a party tonight.*"
        mc "*Said he had a plan or something.*"
        mc "*What should I do?*"

        menu:
            "Help College Rock":
                $ e5s25_college_rock = True
                mc "*[jon] can take care of it himself.*"
                mc "*It's just a party after all.*"

                scene e5s25-09 with dissolve
                mc "Sure [al], I'll be there."

                scene e5s25-07 with dissolve
                al "Thank you so much! I owe you one."

                scene e5s25-08 with dissolve
                mc "It's no problem."

                scene e5s25-07 with dissolve
                al "See you!"
            "Go to [jon]'s party":
                $ e5s25_party_ragers = True
                mc "*Sorry [al], not tonight.*"

                scene e5s25-10 with dissolve
                mc "I'm really sorry, [jon] asked me to help him out with something."
                mc "I wish I could've come, but I already told him I'm gonna go."

                scene e5s25-07 with dissolve
                al "I see, don't worry."
                al "Thanks anyway, bye!"

                scene e5s25-08 with dissolve
                mc "Bye."
    else:
        fr "Hey!"

        scene e5s25-08 with dissolve
        mc "Hey, what's up?"

        scene e5s25-07 with dissolve
        fr "So, [al] was supposed to help me out with the play tonight but she got caught up in something."
        fr "Do you think you can help me out?"
        fr "[ev]'s also pretty busy and I don't really have anyone else."
        mc "*Damn, [jon] wanted me for a party tonight.*"
        mc "*Said he had a plan or something.*"
        mc "*What should I do?*"

        menu:
            "Help College Rock":
                $ e5s25_college_rock = True
                mc "*[jon] can take care of it himself.*"
                mc "*It's just a party after all.*"

                scene e5s25-09 with dissolve
                mc "Sure [fr], I'll be there."

                scene e5s25-07 with dissolve
                fr "Thanks a lot!"
                fr "I'm at our place."

                scene e5s25-08 with dissolve
                mc "Okay, okay, see you there."
            "Go to [jon]'s party":
                $ e5s25_party_ragers = True
                $ francesca_trust -= 1
                mc "*Sorry [fr], not tonight.*"

                scene e5s25-10 with dissolve
                mc "I'm really sorry, [jon] asked me to help him out with something."
                mc "I wish I could've come, but I already told him I'm gonna go."

                scene e5s25-07 with dissolve
                fr "I understand."
                fr "Thanks anyway, [mc]."

    scene e5s25-11 with dissolve
    pause

    scene e5s25-12 with dissolve
    pause

    scene e5s25-01 with dissolve
    pause(1.0)

    scene e5s25-02 with dissolve
    pause(1.0)

    if e5s25_party_ragers == True:
        jump e5s26

    if e5s9_talk == False:
        stop music fadeout 2.0
        scene e5s25-13 with wipeleft
        pause

        play music flowers
        scene e5s25-14 with dissolve
        pause

        scene e5s25-15 with dissolve
        pause

        scene e5s25-16 with dissolve
        fr "[mc]?"
        fr "What are you doing here?"

        scene e5s25-17 with dissolve
        mc "Me? [al] asked me to take her place."
        mc "She said she's busy."
        mc "What are you doing here?"

        scene e5s25-18 with dissolve
        fr "I'm working on the play."

        scene e5s25-19 with dissolve
        mc "Damn... this is awkward."

        scene e5s25-20 with dissolve
        fr "..."

        scene e5s25-21 with dissolve
        fr "It's okay, I got it."

        scene e5s25-23 with dissolve
        mc "Are you sure?"

        scene e5s25-22 with dissolve
        fr "Yeah, I can handle it."

        scene e5s25-24 with dissolve
        mc "..."

        scene e5s25-25 with dissolve
        pause

        scene e5s25-26 with dissolve
        pause

        scene e5s25-27 with dissolve
        mc "Look, we don't have to pretend to be fine if we don't want it."
        mc "But, at least just let me help you out."
        mc "[al] called me for a reason."

        scene e5s25-28 with dissolve
        fr "Fine, there's the sheets."

        scene e5s25-29 with dissolve
        fr "Knock yourself out."

        scene e5s25-30 with dissolve
        mc "Okay..."

        scene e5s25-31 with dissolve
        pause

        scene black with Dissolve(2.0)

        scene e5s25-32 with Dissolve(2.0)
        pause

        if e4s29_sweet == False:
            if e4s28_defensive == False:
                scene e5s25-33 with dissolve
                pause

                scene e5s25-34 with dissolve
                fr "..."

                scene e5s25-35 with dissolve
                fr "Uh... hey."
                fr "Do you... wanna talk?"
                fr "I'm sorry about earlier."

                scene e5s25-36 with dissolve
                menu:
                    "Talk to Francesca":
                        $ e5s25_talk = True
                        mc "It's okay, I'm sorry too."

                    "Stay mad":
                        mc "It's okay, let's just stick to our work."

                        scene e5s25-29 with dissolve
                        fr "...Fine."

                        scene e5s25-31 with dissolve
                        pause
        else:
            scene e5s25-39 with dissolve
            pause

            scene e5s25-40 with dissolve
            menu:
                "Try to fix things":
                    $ e5s25_talk = True
                    scene e5s25-37 with dissolve
                    mc "Do you wanna talk?"

                    scene e5s25-38 with dissolve
                    fr "Talk about what?"

                    scene e5s25-36 with dissolve
                    mc "About what's going on between us?"
                "Stay quiet":
                    scene e5s25-39 with dissolve
                    mc "*Maybe I shouldn't...*"

                    scene e5s25-31 with dissolve
                    pause

        if e5s25_talk == True:
            mc "Look, I'm sorry for what happened with [am] and all."
            mc "Maybe I shouldn't have been so judgeful towards you."

            scene e5s25-29 with dissolve
            fr "Maybe I shouldn't have stormed out..."

            scene e5s25-36 with dissolve
            if e4s27_listen == True:
                mc "I just... didn't know how to react to what you said."

                scene e5s25-41 with dissolve
                fr "I understand. I should have told you everything from the start."

                scene e5s25-42 with dissolve
                fr "But... as bad as it seems, you don't know Amber like I do."

            mc "Okay, but something doesn't add up."
            mc "[am] made it sound like you sabotaged her on purpose... so what actually happened?"
            mc "I'd like to hear your side of the story."

            scene e5s25-43 with dissolve
            fr "Look... I took her place in the squad, alright?"
            fr "But it wasn't a hostile take-over, I didn't even want the role to begin with!"

            scene e5s25-29 with dissolve
            fr "I was fine with being sidelined, I was fine waiting."

            scene e5s25-41 with dissolve
            fr "But [ev] basically told me that I'm either in, or they go with one member less."

            scene e5s25-42 with dissolve
            fr "Like, she would have been kicked out either way. I don't know why that is."

            scene e5s25-43 with dissolve
            fr "I just know that I wanted to help my club, it was a lose-lose situation anyway."

            scene e5s25-41 with dissolve
            fr "I was caught in the crossfire."

            scene e5s25-36 with dissolve
            if e4s27_listen == True:
                mc "What about the buying friends over?"

                scene e5s25-44 with dissolve
                fr "That is such an out of context line, oh my God."

                scene e5s25-45 with dissolve
                fr "I paid somebody once to help me pass a class who also happened to be a friend of hers and she assumed I started buying people over."
                fr "Yeah, I cheated, who doesn't?"
                fr "She certainly did, multiple times even. So don't be telling me."

                scene e5s25-46 with dissolve

            mc "I... I didn't know that."

            scene e5s25-44 with dissolve
            fr "Of course you didn't, why would she show the full context?"

            scene e5s25-45 with dissolve
            fr "She always shows what benefits her and her goals."

            scene e5s25-46 with dissolve
            mc "She told me she quit on her own."
            mc "Was that... just another story she twisted?"

            scene e5s25-47 with dissolve
            fr "Yes and no."

            scene e5s25-49 with dissolve
            fr "From my understanding, after the competition [ev] wanted to have a chat with her."
            fr "She didn't show up at College Rock anymore and said she 'quits'."

            scene e5s25-50 with dissolve
            fr "After a few days, we met and she called me a bitch for stealing her spot."

            scene e5s25-41 with dissolve
            fr "That was basically it."

            scene e5s25-48 with dissolve
            mc "Wow. That's... a lot more anticlimactic than she made it sound."

            scene e5s25-29 with dissolve
            fr "Yeah, you tell me."

            scene e5s25-48 with dissolve
            mc "I wish you'd told me sooner..."

            scene e5s25-49 with dissolve
            fr "I'm sorry about how I acted. I know you just wanted to know the truth."

            scene e5s25-29 with dissolve
            fr "I got defensive because you would have been yet another person she takes from me."

            scene e5s25-51 with dissolve
            fr "It was hard thinking you'd believe her."

            scene e5s25-48 with dissolve
            mc "No, I get it. I pushed you, and I didn't try to understand."
            mc "It's part of my fault too."

            scene e5s25-49 with dissolve
            fr "So... are we good?"

            scene e5s25-48 with dissolve
            mc "Yeah, we are."

            scene e5s25-31 with dissolve
            pause
    else:
        play music flowers
        scene e5s25-39 with wipeleft
        pause

        scene e5s25-37 with dissolve
        mc "Hey, I was wondering about something."

        scene e5s25-38 with dissolve
        fr "What's up?"

        scene e5s25-48 with dissolve
        mc "So, hypothetically, let's say I were to choose a different club, would we still hang out?"

        scene e5s25-49 with dissolve
        fr "As friends? Sure. As something more? I don't know."

        scene e5s25-48 with dissolve
        mc "Why not? What's the difference?"

        scene e5s25-50 with dissolve
        fr "If you're not in the same club... schedules just don't match."

        scene e5s25-49 with dissolve
        fr "You grow apart faster than you think."

        scene e5s25-48 with dissolve
        mc "Did that ever happen to you?"

        scene e5s25-41 with dissolve
        fr "Kind of, but not really."

        scene e5s25-29 with dissolve
        fr "I don't want to start something that ends because I never see the person again. It hurts more that way."

        scene e5s25-48 with dissolve
        mc "Yeah, but if it never happened to you, how can you know?"

        scene e5s25-41 with dissolve
        fr "I saw it happening before, with [am] and some guy."
        fr "Relationships are hard when you're in a club."

        scene e5s25-48 with dissolve
        mc "What do you mean?"

        scene e5s25-43 with dissolve
        fr "I mean, it sucks all your free time, you don't really get to hang out with the other person."

        scene e5s25-41 with dissolve
        fr "Even if you try your hardest, you'd then have to sacrifice some things."

        scene e5s25-49 with dissolve
        fr "Maybe it will work for a while, but I think we'd just be delaying the inevitable."

        scene e5s25-50 with dissolve
        fr "Just the constant choosing between your club or your partner would honestly drain me."

        scene e5s25-48 with dissolve
        mc "Yeah... but if you really like someone, can't you make it work?"

        if francesca_trust > 5:
            scene e5s25-42 with dissolve
            fr "But I do! I really like you, okay? That's why I'm being careful about this."

            scene e5s25-41 with dissolve
            fr "If you were in my world... the rehearsals, the late nights, the chaos, maybe this could work."

            scene e5s25-43 with dissolve
            fr "But if we barely see each other, I'd just... I'd end up missing you more than enjoying you."

            scene e5s25-48 with dissolve
            mc "Do you really mean that?"

            scene e5s25-49 with dissolve
            fr "Of course, does that seem hard to believe?"

            scene e5s25-48 with dissolve
            mc "No, it's just that I didn't think you were like that."
            mc "Honestly, hearing all this is pretty sweet."

            scene e5s25-41 with dissolve
            fr "You think so?"

            scene e5s25-48 with dissolve
            mc "Yeah, I do."

            scene e5s25-52 with dissolve
            pause

            scene e5s25-kissing1 with dissolve
            pause

            scene e5s25-53 with dissolve
            pause

            scene e5s25-55 with dissolve
            fr "MC... I-"
            fr "I don't know what to say, haha!"

            scene e5s25-54 with dissolve
            mc "Then don't say a thing."

            scene e5s25-kissing2 with dissolve
            pause

            scene e5s25-55 with dissolve
            fr "I'm feeling pretty hot right now."

            scene e5s25-54 with dissolve
            mc "Then, what do you say we lose the clothes?"
            mc "Maybe fool around a little."
            mc "We've been working so hard, we deserve a bit of time off."

            scene e5s25-56 with dissolve
            fr "I don't know... do you think it's a good idea?"

            scene e5s25-57 with dissolve
            menu:
                "Do it":
                    $ e5s25_francesca_lewd = True

                    call e5s25_francesca_lewd from _call_e5s25_francesca_lewd
                "Hold back":
                    mc "No... you're right."
                    mc "I was just getting ahead of myself."

                    scene e5s25-59 with dissolve
                    fr "I'm sorry, we can do it if you want."

                    scene e5s25-57 with dissolve
                    mc "No, no, it's okay."
                    mc "We don't have to fool around every time we hang out."
                    mc "We can just enjoy each other's presence."

                    scene e5s25-81 with dissolve
                    pause

                    scene e5s25-82 with dissolve
                    pause

                    scene e5s25-83 with dissolve
                    pause
        else:
            scene e5s25-49 with dissolve
            fr "I mean... not really."

            scene e5s25-41 with dissolve
            fr "For me it's pretty much a no-go."
            fr "Sorry."

            scene e5s25-48 with dissolve
            mc "Yeah... I guess I can understand."
            mc "You don't have to apologize."
            mc "If it doesn't work for you, then it doesn't work for you."

            scene e5s25-41 with dissolve
            fr "Thank you for understanding."

            scene e5s25-32 with dissolve
            pause

            scene e5s25-31 with dissolve
            pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    $ episode_count += 0.5
    jump credits
return

label e5s25_francesca_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if _in_replay:
            play music one_fine_day
            scene e5s25-kissing1 with dissolve
            pause

            scene e5s25-53 with dissolve
            pause

            scene e5s25-55 with dissolve
            fr "MC... I-"
            fr "I don't know what to say, haha!"

            scene e5s25-54 with dissolve
            mc "Then don't say a thing."

            scene e5s25-kissing2 with dissolve
            pause

            scene e5s25-55 with dissolve
            fr "I'm feeling pretty hot right now."

            scene e5s25-54 with dissolve
            mc "Then, what do you say we lose the clothes?"
            mc "Maybe fool around a little."
            mc "We've been working so hard, we deserve a bit of time off."

            scene e5s25-56 with dissolve
            fr "I don't know... do you think it's a good idea?"

            scene e5s25-57 with dissolve
        mc "What's the harm?"
        mc "We're alone in here anyway."
        mc "But it's okay if you're not in the mood."

        scene e5s25-58 with dissolve
        fr "No... that's the thing."

        scene e5s25-59 with dissolve
        fr "I am in the mood, but I'm afraid I might not be able to stop myself."

        scene e5s25-58 with dissolve
        fr "I really like you, but I'm not sure I'd like my first time to be here."

        scene e5s25-57 with dissolve
        mc "Yeah, I completely understand."
        mc "I'm not looking for that honestly, I thought we both deserve a break."

        scene e5s25-59 with dissolve
        fr "I really like doing these things together, but can you promise me it won't lead to sex?"

        scene e5s25-57 with dissolve
        mc "Yeah, I promise I won't push for more."

        scene e5s25-60 with dissolve
        fr "Thank you [mc]."

        scene e5s25-kissing2 with dissolve
        pause

        scene e5s25-61 with dissolve
        pause

        scene e5s25-54 with dissolve
        mc "Ah... [fr]."
        mc "You make me so hard."

        scene e5s25-55 with dissolve
        fr "Let's see just how hard you are!"

        if persistent.disable_nsfw == True:
            scene e5s25-62 with dissolve
            pause

            scene e5s25-63 with dissolve
            fr "Damn... do I really make you that excited?"

            scene e5s25-54 with dissolve
            mc "Well, I think it's pretty clear already."

            scene e5s25-55 with dissolve
            fr "I... uh-I'm shocked every time I see it."
            fr "It feels like it's getting bigger."
            fr "That makes me so wet."

            scene e5s25-handjob2 with dissolve
            mc "Ah... that feels really good."
            mc "Keep going [fr]."

            scene e5s25-handjob1 with dissolve
            pause

            scene e5s25-handjob3 with dissolve
            fr "You're really hard."

            scene e5s25-handjob4 with dissolve
            pause

            scene e5s25-handjob2 with dissolve
            mc "At this point, it feels like I'm going to explode."

            scene e5s25-55 with dissolve
            fr "Stop... you're making me blush."

            scene e5s25-kissing2 with dissolve
            pause

            scene e5s25-handjob5 with dissolve
            mc "Ah... you're really going to drain me."

            scene e5s25-handjob6 with dissolve
            fr "Maybe that's the point."

            scene e5s25-handjob7 with dissolve
            pause

            scene e5s25-handjob6 with dissolve
            mc "Ah... oh..."

            scene e5s25-handjob5 with dissolve
            pause

            scene e5s25-handjob7 with dissolve
            pause

            scene e5s25-handjob6 with dissolve
            mc "You're... uh-killing me!"

            scene e5s25-kissing2 with dissolve
            pause

            scene e5s25-handjob7 with dissolve
            mc "Damn... I can't hold it for much longer."

            scene e5s25-handjob5 with dissolve
            fr "Then don't hold it, cum!"
            fr "I want to see just how bad you're going to explode."
            mc "Ahhh..."
            mc "*I've never seen her talk like that.*"
            mc "*She's really turning me on.*"
            mc "I'm doing it [fr], I'm going to cum!"
            fr "Cum for me."
            scene e5s25-65 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5s25-64 with dissolve
            mc "Ahh..."
            fr "Damn, you really came a lot."
            mc "You really turned me on."

            scene e5s25-66 with dissolve
            pause

            scene e5s25-67 with dissolve
            fr "Ah... [mc]..."
            mc "Your boobs look so pretty."

            scene e5s25-68 with dissolve
            fr "Take a better look."

            scene e5s25-69 with dissolve
            mc "Damn, you wanna make me hard again?"

            scene e5s25-70 with dissolve
            fr "Haha!"

            scene e5s25-71 with dissolve
            pause

            scene e5s25-72 with dissolve
            mc "You look so beautiful."

            scene e5s25-73 with dissolve
            fr "[mc]... can you..."
            fr "Touch me down there?"

            scene e5s25-74 with dissolve
            fr "Ohhh..."

            scene e5s25-73 with dissolve
            fr "I get such an intense feeling when you touch me."

            scene e5s25-75 with dissolve
            fr "Please, start fingering me."

            scene e5s25-fingering3 with dissolve
            fr "Ahh!"

            scene e5s25-fingering4 with dissolve
            mc "Does it feel good?"

            scene e5s25-fingering1 with dissolve
            fr "It feels amazing."
            fr "Please, don't stop."

            scene e5s25-fingering2 with dissolve
            pause

            scene e5s25-fingering3 with dissolve
            mc "You're so wet, my fingers are just sliding in there."

            scene e5s25-fingering1 with dissolve
            fr "Ohh..."

            scene e5s25-fingering2 with dissolve
            pause

            scene e5s25-fingering1 with dissolve
            mc "I'll start going faster."

            scene e5s25-fingering6 with dissolve
            fr "AHHH!"

            scene e5s25-fingering7 with dissolve
            pause

            scene e5s25-fingering5 with dissolve
            fr "Keep going..."
            fr "I'm so close."

            scene e5s25-fingering7 with dissolve
            mc "*Damn, Francesca's really horny tonight.*"

            scene e5s25-fingering5 with dissolve
            fr "Ohh, make me cum, [mc]!"
            fr "Your fingers are going to make me cum."

            scene e5s25-fingering6 with dissolve
            mc "Cum for me [fr]."
            fr "Ahhh!!!"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5s25-76 with dissolve
            fr "Oh my God! It's so intense."
            fr "Ohh... I can't even move. I'm so sensitive."

            scene e5s25-77 with dissolve
            mc "You don't have to move. Let's just sit here for a bit."

            scene e5s25-75 with dissolve
            fr "You make me feel so good."

            scene e5s25-73 with dissolve
            fr "And it's not just this, you as a whole."

            scene e5s25-75 with dissolve
            fr "I feel things I've never felt before."
            fr "Thank you for being here."

            scene e5s25-79 with dissolve
            mc "Thank you for trusting me with this."
            mc "I'll be here for you."

            scene e5s25-78 with dissolve
            mc "You make me really happy."

            scene e5s25-80 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e5s25-62_cen with dissolve
                pause

                scene e5s25-63_cen with dissolve
                fr "Damn... do I really make you that excited?"

                scene e5s25-54 with dissolve
                mc "Well, I think it's pretty clear already."

                scene e5s25-55 with dissolve
                fr "I... uh-I'm shocked every time I see it."
                fr "It feels like it's getting bigger."
                fr "That makes me so wet."

                scene e5s25-handjob2_cen with dissolve
                mc "Ah... that feels really good."
                mc "Keep going [fr]."

                scene e5s25-handjob1_cen with dissolve
                pause

                scene e5s25-handjob3_cen with dissolve
                fr "You're really hard."

                scene e5s25-handjob4_cen with dissolve
                pause

                scene e5s25-handjob2_cen with dissolve
                mc "At this point, it feels like I'm going to explode."

                scene e5s25-55 with dissolve
                fr "Stop... you're making me blush."

                scene e5s25-kissing2 with dissolve
                pause

                scene e5s25-handjob5_cen with dissolve
                mc "Ah... you're really going to drain me."

                scene e5s25-handjob6_cen with dissolve
                fr "Maybe that's the point."

                scene e5s25-handjob7_cen with dissolve
                pause

                scene e5s25-handjob6_cen with dissolve
                mc "Ah... oh..."

                scene e5s25-handjob5_cen with dissolve
                pause

                scene e5s25-handjob7_cen with dissolve
                pause

                scene e5s25-handjob6_cen with dissolve
                mc "You're... uh-killing me!"

                scene e5s25-kissing2 with dissolve
                pause

                scene e5s25-handjob7_cen with dissolve
                mc "Damn... I can't hold it for much longer."

                scene e5s25-handjob5_cen with dissolve
                fr "Then don't hold it, cum!"
                fr "I want to see just how bad you're going to explode."
                mc "Ahhh..."
                mc "*I've never seen her talk like that.*"
                mc "*She's really turning me on.*"
                mc "I'm doing it [fr], I'm going to cum!"
                fr "Cum for me."
                scene e5s25-65_cen with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5s25-64_cen with dissolve
                mc "Ahh..."
                fr "Damn, you really came a lot."
                mc "You really turned me on."

                scene e5s25-66_cen with dissolve
                pause

                scene e5s25-67 with dissolve
                fr "Ah... [mc]..."
                mc "Your boobs look so pretty."

                scene e5s25-68 with dissolve
                fr "Take a better look."

                scene e5s25-69_cen with dissolve
                mc "Damn, you wanna make me hard again?"

                scene e5s25-70 with dissolve
                fr "Haha!"

                scene e5s25-71_cen with dissolve
                pause

                scene e5s25-72 with dissolve
                mc "You look so beautiful."

                scene e5s25-73 with dissolve
                fr "[mc]... can you..."
                fr "Touch me down there?"

                scene e5s25-74_cen with dissolve
                fr "Ohhh..."

                scene e5s25-73 with dissolve
                fr "I get such an intense feeling when you touch me."

                scene e5s25-75 with dissolve
                fr "Please, start fingering me."

                scene e5s25-fingering3_cen with dissolve
                fr "Ahh!"

                scene e5s25-fingering4_cen with dissolve
                mc "Does it feel good?"

                scene e5s25-fingering1_cen with dissolve
                fr "It feels amazing."
                fr "Please, don't stop."

                scene e5s25-fingering2_cen with dissolve
                pause

                scene e5s25-fingering3_cen with dissolve
                mc "You're so wet, my fingers are just sliding in there."

                scene e5s25-fingering1_cen with dissolve
                fr "Ohh..."

                scene e5s25-fingering2_cen with dissolve
                pause

                scene e5s25-fingering1_cen with dissolve
                mc "I'll start going faster."

                scene e5s25-fingering6_cen with dissolve
                fr "AHHH!"

                scene e5s25-fingering7_cen with dissolve
                pause

                scene e5s25-fingering5_cen with dissolve
                fr "Keep going..."
                fr "I'm so close."

                scene e5s25-fingering7_cen with dissolve
                mc "*Damn, Francesca's really horny tonight.*"

                scene e5s25-fingering5_cen with dissolve
                fr "Ohh, make me cum, [mc]!"
                fr "Your fingers are going to make me cum."

                scene e5s25-fingering6_cen with dissolve
                mc "Cum for me [fr]."
                fr "Ahhh!!!"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5s25-76_cen with dissolve
                fr "Oh my God! It's so intense."
                fr "Ohh... I can't even move. I'm so sensitive."

                scene e5s25-77_cen with dissolve
                mc "You don't have to move. Let's just sit here for a bit."

                scene e5s25-75 with dissolve
                fr "You make me feel so good."

                scene e5s25-73 with dissolve
                fr "And it's not just this, you as a whole."

                scene e5s25-75 with dissolve
                fr "I feel things I've never felt before."
                fr "Thank you for being here."

                scene e5s25-79_cen with dissolve
                mc "Thank you for trusting me with this."
                mc "I'll be here for you."

                scene e5s25-78 with dissolve
                mc "You make me really happy."

                scene e5s25-80_cen with dissolve
                pause

    $ renpy.end_replay()
return
