
# Scene 15 - Darryl's dilema ###################################################

label e5s15:
    stop music fadeout 2.0
    stop sound fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music hi_as_hats
    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e5s15-01 with Dissolve(2.0)
    pause

    scene e5s15-02 with dissolve
    pause

    scene e5s15-03 with dissolve
    da "Hey [cl]..."

    scene e5s15-04 with dissolve
    pause

    scene e5s15-06 with dissolve
    cl "Do you mind? I'm having lunch."

    scene e5s15-07 with dissolve
    da "I won't take long."

    scene e5s15-05 with dissolve
    pause

    scene e5s15-08 with dissolve
    cl "What do you want?"

    scene e5s15-09 with dissolve
    da "Look, maybe we got on the wrong foot."

    scene e5s15-10 with dissolve
    cl "On the wrong foot? You fired me. You kicked me out."

    scene e5s15-11 with dissolve
    da "But you forced me to!"

    scene e5s15-12 with dissolve
    da "If you'd have just... accepted a date with me."
    da "We'd both be fine right now."

    scene e5s15-13 with dissolve
    cl "You've got some nerve!"

    scene e5s15-14 with dissolve
    cl "I see you're doing pretty well for yourself."

    scene e5s15-15 with dissolve
    da "I'm not, I'm dying inside."

    scene e5s15-16 with dissolve
    da "Just... give me a chance, please."

    scene e5s15-12 with dissolve
    da "Just this once, and I will give you your job back."

    scene e5s15-17 with dissolve
    cl "Dude, are you fucking kidding me?"

    scene e5s15-07 with dissolve
    da "What?"

    scene e5s15-10 with dissolve
    cl "Like I would want that fucking job back."

    scene e5s15-13 with dissolve
    cl "You know what [da]? Maybe I should be thanking you."
    cl "I hated that place anyway. I hated you. I hated everything about that cafe."
    cl "I was only playing along because I didn't want to lose it."

    scene e5s15-14 with dissolve
    cl "But seeing how I lost it anyway, it isn't worth it to keep up the facade anymore, is it?"

    scene e5s15-11 with dissolve
    da "No way, impossible."

    scene e5s15-17 with dissolve
    cl "Why is that so hard for you to believe?"

    scene e5s15-18 with dissolve
    da "..."

    scene e5s15-11 with dissolve
    da "That little shit, [mc] or what was his name?"
    da "He's been feeding you all this crap, hasn't he?"

    scene e5s15-19 with dissolve
    cl "Don't bring him into this."
    cl "What's between me and you is between me and you."

    scene e5s15-11 with dissolve
    da "I bet you've been sleeping at his place, you- you..."

    scene e5s15-13 with dissolve
    cl "You? You what? Say it."

    scene e5s15-18 with dissolve
    da "..."

    scene e5s15-10 with dissolve
    cl "So what if I've been staying at his place?"

    scene e5s15-19 with dissolve
    cl "It's none of your God damn business anyway."

    scene e5s15-17 with dissolve
    cl "Just... leave me the hell alone, okay?"
    cl "I don't want to be near you."

    scene e5s15-20 with dissolve
    pause

    scene e5s15-05 with dissolve
    pause

    stop sound fadeout 2.0
    scene e5s15-21 with dissolve
    pause

    if e5s2_movie == True:
        jump e5s16
    else:
        jump e5s17
return
