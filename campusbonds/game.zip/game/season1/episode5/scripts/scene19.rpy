
# Scene 19 - A tough choice ####################################################

label e5s19:
    stop music fadeout 2.0
    scene e5s19-01 with wipeleft
    pause

    play music invisible_light
    scene e5s19-02 with dissolve
    play sound knock_knock
    pause

    scene e5s19-03 with dissolve
    pause

    scene e5s19-04 with dissolve
    pause

    scene e5s19-06 with dissolve
    play sound door_open
    ke "Yo, what's up, my dude?"

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    mc "Nothing. Just chilling in bed."
    mc "You?"

    scene e5s19-07 with dissolve
    hide e5s19_ken_blink1
    ke "I'm good, I'm good."

    scene e5s19-08 with dissolve
    ke "Listen, [jon] wanted to know if you'd be willing to help him with something."

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    mc "What's up?"

    scene e5s19-09 with dissolve
    hide e5s19_ken_blink1
    ke "I wasn't really planning on getting involved, but he wants you to go over to the cheerleaders' place and grab something for him."

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    mc "Can't he do it himself?"

    scene e5s19-10 with dissolve
    hide e5s19_ken_blink1
    ke "I don't know, man. I didn't ask."

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    if affinity_spectrum > 0:
        mc "Fuck..."
    else:
        mc "*Exhales*"

    mc "Alright, what do you need me to do?"

    scene e5s19-08 with dissolve
    hide e5s19_ken_blink1
    ke "So, let's not waste any time."

    scene e5s19-09 with dissolve
    ke "He said you need to get over there as soon as possible."
    ke "The showers are empty right now, but they won't stay that way for long."

    scene e5s19-08 with dissolve
    ke "He needs something from one of their lockers."

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    mc "Why does this have to be some kind of covert operation?"
    mc "Can't [ci] or [ch] get it?"

    scene e5s19-10 with dissolve
    hide e5s19_ken_blink1
    ke "I don't know, dude. You think I cared enough to ask?"
    ke "I'm just telling you what he told me."

    scene e5s19-05 with dissolve
    show e5s19_ken_blink1
    mc "*Man, I'm really not in the mood for this.*"

    scene e5s19-11 with dissolve
    play sound phone_buzz
    hide e5s19_ken_blink1
    pause

    scene e5s19-12 with dissolve
    nvl clear

    if e5s9_talk == False:
        al_nvl "Hey, it's [al]."
        al_nvl "Are you busy?"

        scene e5s19-05 with dissolve
        show e5s19_ken_blink1
        mc "Hold on a sec. I just got a text."

        scene e5s19-12 with dissolve
        hide e5s19_ken_blink1
        n_nvl "What's up?"
        al_nvl "I know this is kind of last-minute, but I was wondering if you could help us with something."
        al_nvl "[ev] has a ton of paperwork to get through."
        al_nvl "We would've helped her, but everyone's busy tonight."
        al_nvl "Could you go over to her place? I'll send you the address."
    else:
        fr_nvl "Hey [mc]."
        fr_nvl "Do you have a minute?"

        scene e5s19-05 with dissolve
        show e5s19_ken_blink1
        mc "Hold on a sec. I just got a text."

        scene e5s19-12 with dissolve
        hide e5s19_ken_blink1
        n_nvl "What's up?"
        fr_nvl "I know this is short notice, but we could really use your help."
        fr_nvl "[ev] has a ton of paperwork to finish by tomorrow."
        fr_nvl "She doesn't want to admit it, but she really needs some help."
        fr_nvl "I'd go myself, but I can't leave Dad alone."
        fr_nvl "Do you think you could go over to her place and help her out?"
        fr_nvl "We'd really appreciate it."

    scene e5s19-13 with dissolve
    mc "*Shit... they need me for College Rock.*"
    mc "*But [jon] wants me to help him, too...*"
    mc "*Who do I help?*"

    menu:
        "College Rock":
            $ e5s19_college_rock = True
            scene e5s19-12 with dissolve
            mc "*[jon] can handle it on his own.*"
            mc "*I'll help College Rock.*"
            n_nvl "Alright, I'll get there asap."

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "Sorry, [ke]. I can't tonight."
            mc "I've got something else going on."

            scene e5s19-14 with dissolve
            hide e5s19_ken_blink1
            ke "I don't think [jon]'s gonna like that."

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "Can't you do it?"

            scene e5s19-14 with dissolve
            hide e5s19_ken_blink1
            ke "Fuck... I had something else planned, too."

            scene e5s19-09 with dissolve
            ke "But I guess I'll go do it if you can't."
            ke "Thanks anyway."

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "See you!"
        "Party Ragers":
            $ e5s19_party_ragers = True
            scene e5s19-12 with dissolve
            if e5s9_talk == False:
                mc "*Sorry, [al]. Not tonight.*"
            else:
                mc "*Sorry, [fr]. Not tonight.*"
            mc "*[kv] needs to be stopped.*"
            n_nvl "Sorry, I can't make it tonight either."

            scene e5s19-08 with dissolve
            ke "Who was that?"

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "Something College Rock-related."

            scene e5s19-14 with dissolve
            hide e5s19_ken_blink1
            ke "I see..."
            ke "Is it cool over there?"

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "It's alright."
            mc "A little stressful with [ev] and all, but overall, it's fine."

            scene e5s19-10 with dissolve
            hide e5s19_ken_blink1
            ke "I see."

            scene e5s19-08 with dissolve
            ke "Well, I won't keep you any longer."

            scene e5s19-09 with dissolve
            ke "Just get down to the cheerleaders as soon as you can, okay?"

            scene e5s19-05 with dissolve
            show e5s19_ken_blink1
            mc "Yeah, yeah. Got it."

            scene e5s19-06 with dissolve
            hide e5s19_ken_blink1
            ke "See you later, my friend."

    if e5s8_shelter_cleo == True:
        scene e5s19-16 with dissolve
        pause

        scene e5s19-17 with dissolve
        cl "Is everything alright?"

        scene e5s19-18 with dissolve
        mc "Yeah. Just a few things going on with the clubs I'm part of."

        scene e5s19-19 with dissolve
        cl "Oh... I see."

        scene e5s19-18 with dissolve
        mc "I've gotta run. I'm not sure when I'll be back."
        mc "Don't wait up."

        scene e5s19-20 with dissolve
        cl "Oh, okay."

        scene e5s19-21 with dissolve
        cl "Be careful!"

        scene e5s19-18 with dissolve
        mc "I will."
    else:
        scene e5s19-15 with dissolve
        pause

    if e5s19_college_rock == True:
        jump e5s21
    else:
        jump e5s20
return
