
# Scene 20 - Cheerleader trouble (First choice) ################################

label e5s20:
    stop music fadeout 2.0
    scene e5s20-01 with wipeleft
    pause

    play music rollin_at_5
    $renpy.sound.play("audio/sfx/rain.ogg", loop=True)
    scene e5s20-02 with dissolve
    mc "*What's going on in this place?*"
    mc "*Thought [ke] said this place was empty.*"

    scene e5s20-03 with dissolve
    mc "*I can't see shit!*"

    scene e5s20-04 with dissolve
    pause

    scene e5s20-05 with dissolve
    pause

    scene e5s20-06 with dissolve
    pause

    scene e5s20-08 with dissolve
    mc "*Ah-ha!*"
    mc "*Must be the room I'm looking for.*"

    scene e5s20-07 with dissolve
    pause

    play music tidalwave
    stop sound
    scene e5s20-10 with vpunch
    unknown "Aaahhh!!"
    unknown "Yo, what the hell?"

    scene e5s20-11 with dissolve
    unknown "Can't you see I'm showering in here?"

    scene e5s20-09 with dissolve
    show e5s20_cheerleader_blink1
    mc "Holy shit, I'm sorry."
    mc "I... uh-I had to grab something for [jon]!"
    mc "I didn't mean to scare you."

    scene e5s20-10 with dissolve
    hide e5s20_cheerleader_blink1
    unknown "To scare me?"

    scene e5s20-12 with dissolve
    unknown "You grabbed my tit!"

    scene e5s20-09 with dissolve
    show e5s20_cheerleader_blink1
    mc "God, I really didn't mean to, I'm so sorry."
    mc "My friend told me the place was empty."

    scene e5s20-10 with dissolve
    hide e5s20_cheerleader_blink1
    unknown "Maybe knock first next time?"

    scene e5s20-12 with dissolve
    unknown "You really scared the shit out of me."

    scene e5s20-09 with dissolve
    show e5s20_cheerleader_blink1
    mc "Yeah, yeah, totally my bad. Sorry!"
    mc "It's just a curtain, so I couldn't really knock."

    call e5s20_cheerleader_lewd from _call_e5s20_cheerleader_lewd

    if e5s20_cheerleader_lewd == True:
        unknown "Um... hello?"
        if affinity_spectrum > 0:
            stop music
            scene e5s20-09
            show e5s20_cheerleader_blink1
            mc "Uh, I thought you'd-"

            scene e5s20-12 with dissolve
            hide e5s20_cheerleader_blink1
            unknown "Really? You thought I'd just throw myself at you?"

            scene e5s20-09 with dissolve
            show e5s20_cheerleader_blink1
            mc "I mean, you're a cheerleader, right?"

            scene e5s20-39 with dissolve
            hide e5s20_cheerleader_blink1
            unknown "Oh my God... gross!"

            scene e5s20-09 with dissolve
            show e5s20_cheerleader_blink1
            mc "I'm sorry, I'll uh-just get out of here."

            scene e5s20-38 with dissolve
            hide e5s20_cheerleader_blink1
            mc "*That's what happens in the movies man...*"
        else:
            stop music
            scene e5s20-09
            show e5s20_cheerleader_blink1
            mc "Holy shit, oh my God, I'm sorry!"
            mc "Sure... uh-yeah, I'll get out of here."

            scene e5s20-38 with dissolve
            hide e5s20_cheerleader_blink1
            mc "*Good job [mc], keep this up and a ban will be the least of your problems.*"

    scene e5s20-40 with dissolve
    pause

    scene e5s20-41 with dissolve
    pause

    scene e5s20-42 with dissolve
    pause

    play music killer_rabbit
    scene e5s20-43 with wipeleft
    pause

    scene e5s20-44 with dissolve
    mc "Yo, what the hell was that?"

    scene e5s20-45 with dissolve
    ke "Haha, what? Did you have fun?"

    scene e5s20-46 with dissolve
    mc "No, I didn't."

    scene e5s20-47 with dissolve
    if affinity_spectrum > 0 and e5s20_cheerleader_lewd == True:
        mc "I mean... I might have wanted to, but..."

        scene e5s20-49 with dissolve
        ke "Haha, I knew you'd crack."
    else:
        if affinity_spectrum > 0:
            mc "You thought I'd just do it with a random girl?"
        else:
            mc "You thought she'd just do it with me?"

        scene e5s20-49 with dissolve
        ke "Nah, of course I knew, but I thought it would be funnier."

    scene e5s20-50 with dissolve
    ke "So, did you get it?"

    scene e5s20-48 with dissolve
    mc "Yeah, it's right here."

    scene e5s20-51 with dissolve
    ke "Thanks man!"

    scene e5s20-50 with dissolve
    ke "I'll see you tomorrow."

    scene e5s20-48 with dissolve
    mc "Tomorrow?"

    scene e5s20-50 with dissolve
    ke "That's what [jon] said."

    scene e5s20-51 with dissolve
    ke "Don't sleep in."

    scene e5s20-52 with dissolve
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music marathon_man
    scene e5s20-53 with Dissolve(2.0)
    pause

    scene e5s20-54 with dissolve
    mc "Yo, the hell dude?"

    scene e5s20-55 with dissolve
    jon "Huh? What's up?"

    scene e5s20-56 with dissolve
    mc "Why did you send me to the cheerleaders last night?"

    scene e5s20-58 with dissolve
    jon "What do you mean?"

    scene e5s20-57 with dissolve
    mc "[ke] told me the place was empty."
    mc "I ran into a girl showering in there."

    scene e5s20-59 with dissolve
    jon "Wait, wait, wait..."

    scene e5s20-60 with dissolve
    jon "I specifically told Ken to tell you to wait an hour first."

    scene e5s20-61 with dissolve
    jon "Then go and grab it when the place was clear."

    scene e5s20-62 with dissolve
    jon "I don't know what he told you."

    scene e5s20-57 with dissolve
    mc "He told me that I should hurry before anyone shows up."
    mc "That the girls left for some kind of shit they're up to."
    mc "And if the showers are on they probably forgot about them."

    scene e5s20-63 with dissolve
    jon "Oh my God, dude..."

    scene e5s20-62 with dissolve
    jon "And you actually believed him?"

    scene e5s20-60 with dissolve
    jon "Do you hear how all that sounds?"

    scene e5s20-58 with dissolve
    jon "...if the showers are on they probably forgot about them'?"

    scene e5s20-57 with dissolve
    mc "That's what I thought you said."
    mc "I knew it sounded kinda fishy..."

    scene e5s20-64 with dissolve
    ke "Yoo, what's good my bros."

    scene e5s20-65 with dissolve
    mc "You're no bro."

    scene e5s20-66 with dissolve
    ke "Me? I almost hooked you up."

    scene e5s20-67 with dissolve
    ke "You should be thanking me."

    scene e5s20-65 with dissolve
    mc "Thank you for getting expelled?"

    scene e5s20-68 with dissolve
    ke "Come on, it's not that deep."

    scene e5s20-67 with dissolve
    ke "I'm sure she also saw it as a harmless prank."

    scene e5s20-66 with dissolve
    ke "You're still here, so what's the fuss?"

    scene e5s20-57 with dissolve
    mc "Remember me to never listen to this guy again."

    scene e5s20-69 with dissolve
    jon "For real, [ke]. Chill out a little, brother."
    jon "It was kind of funny, but we're standing on business here."

    scene e5s20-70 with dissolve
    jon "We can't risk slipping."

    scene e5s20-71 with dissolve
    ke "Ok, ok... I get it."

    scene e5s20-72 with dissolve
    jon "Now, who's up for some party planning?"

    if e5s8_shelter_cleo == True:
        jump e5s23
    else:
        jump e5s24
return


label e5s20_cheerleader_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        play music inhale
        scene e5s20-13 with dissolve
        hide e5s20_cheerleader_blink1
        unknown "*On another thought... I could mess with him.*"

        scene e5s20-14 with dissolve
        unknown "So, how come from all the showers, you only checked mine?"

        scene e5s20-15 with dissolve
        mc "I mean... as I said, I couldn't really see."
        mc "I'm sorry, I didn't mean to."

        scene e5s20-16 with dissolve
        unknown "Don't be sorry."
        unknown "Mistakes happen, right?"

        scene e5s20-15 with dissolve
        mc "Right..."

        scene e5s20-17 with dissolve
        unknown "Is it just me, or is it getting hot in here?"

        scene e5s20-15 with dissolve
        mc "It is pretty hot, yeah."

        scene e5s20-18 with dissolve
        unknown "Maybe I should take my towel off."

        if persistent.disable_nsfw == True:
            scene e5s20-19 with dissolve
            mc "*Huh?*"

            scene e5s20-21 with dissolve
            unknown "Ah... much better."

            scene e5s20-20 with dissolve
            mc "Hey... I-uh think you should maybe put those away."

            scene e5s20-22 with dissolve
            unknown "Why? They're not hurting anybody."

            scene e5s20-23 with dissolve
            unknown "You can look if you want."

            scene e5s20-20 with dissolve
            mc "I can?"

            scene e5s20-24 with dissolve
            unknown "I mean, you already touched them, so what's looking gonna do?"

            scene e5s20-26 with dissolve
            menu:
                "Have a little fun":
                    if not _in_replay:
                        call extrovert_affinity_check from _call_extrovert_affinity_check_84
                        call color_check from _call_color_check_162
                        $ e5s20_cheerleader_lewd = True

                    if affinity_spectrum > 0:
                        scene e5s20-25 with dissolve
                        mc "Damn... they look pretty good I'm not going to lie."
                    else:
                        mc "..."

                        scene e5s20-25 with dissolve
                        unknown "Don't be shy."

                    scene e5s20-27 with dissolve
                    unknown "Get in here!"

                    scene e5s20-20 with dissolve
                    mc "Wait... for real, for real?"

                    scene e5s20-22 with dissolve
                    unknown "Unless you want to leave blue balled that is."

                    scene e5s20-25 with dissolve
                    mc "*Am I dreaming?*"

                    scene e5s20-27 with dissolve
                    unknown "Undress if you don't want your clothes getting wet."

                    scene e5s20-20 with dissolve
                    mc "Nope, not at all."

                    scene e5s20-29 with dissolve
                    unknown "Now... let me work my magic."

                    scene e5s20-31 with dissolve
                    unknown "You can't touch, you can only look."

                    scene e5s20-30 with dissolve
                    mc "*Sounds good to me.*"

                    scene e5s20-32 with dissolve
                    unknown "It's been so long since I've had something like this..."
                    unknown "Damn, and you're huge."

                    scene e5s20-33 with dissolve
                    unknown "How am I gonna fit all this in my mouth, huh?"

                    scene e5s20-30 with dissolve
                    mc "Do you need a little help?"

                    scene e5s20-31 with dissolve
                    unknown "Nope, no touching, remember?"

                    scene e5s20-32 with dissolve
                    unknown "Let's get it ready, shall we?"

                    scene e5s20-35 with dissolve
                    pause

                    scene e5s20-34 with dissolve
                    pause

                    scene e5s20-28 with dissolve
                    pause

                    scene e5s20-titjob1 with dissolve
                    mc "Ahh..."

                    scene e5s20-36 with dissolve
                    unknown "It seems to me like you're enjoying it."

                    scene e5s20-titjob2 with dissolve
                    mc "I am... keep doing it."

                    scene e5s20-titjob1 with dissolve
                    unknown "I have no intention of stopping, handsome."

                    scene e5s20-titjob3 with dissolve
                    mc "Oh..."
                    mc "*I feel like I'm in heaven.*"

                    scene e5s20-titjob2 with dissolve
                    pause

                    scene e5s20-titjob3 with dissolve
                    pause

                    scene e5s20-36 with dissolve
                    unknown "I'll speed it up a bit."

                    scene e5s20-titjob4 with dissolve
                    mc "*As if it didn't feel amazing already...*"

                    scene e5s20-36 with dissolve
                    unknown "How are you doing up there?"

                    scene e5s20-titjob5 with dissolve
                    mc "Fine... trying to hold on."

                    scene e5s20-titjob4 with dissolve
                    unknown "Oh... why are you trying?"
                    unknown "Just let go."
                    unknown "I'm here to make you forget."

                    scene e5s20-titjob6 with dissolve
                    mc "Damn..."
                    mc "If you keep this up, I won't be lasting much longer."

                    scene e5s20-36 with dissolve
                    unknown "It will be so satisfying watching you cum."

                    scene e5s20-titjob4 with dissolve
                    unknown "Let's not leave anything behind, shall we?"

                    scene e5s20-titjob5 with dissolve
                    mc "I'm with you on this one."

                    scene e5s20-blowjob1 with dissolve
                    mc "Nghh..."

                    scene e5s20-blowjob2 with dissolve
                    mc "Ahh, that feels amazing."

                    scene e5s20-blowjob3 with dissolve
                    pause

                    scene e5s20-blowjob2 with dissolve
                    mc "Your mouth is so hot, keep doing it."

                    scene e5s20-blowjob1 with dissolve
                    unknown "Guh... guh... guh..."

                    scene e5s20-blowjob3 with dissolve
                    mc "Fuck..."

                    scene e5s20-blowjob4 with dissolve
                    mc "Oh my God..."

                    scene e5s20-blowjob5 with dissolve
                    mc "*I can't believe I'm doing this.*"

                    scene e5s20-blowjob6 with dissolve
                    pause

                    scene e5s20-blowjob5 with dissolve
                    mc "*Is it really happening?*"

                    scene e5s20-blowjob4 with dissolve
                    pause

                    scene e5s20-blowjob6 with dissolve
                    mc "*Fuck... I can't last any longer.*"
                    mc "Hey, I'm gonna cum."

                    scene e5s20-blowjob4 with dissolve
                    mc "*She's not stopping!*"
                    mc "Ahhh, here it comes!"

                    scene e5s20-37 with dissolve
                    pause
                "Focus" if not _in_replay:
                    if not _in_replay:
                        call introvert_affinity_check from _call_introvert_affinity_check_74
                        call color_check from _call_color_check_163

                    scene e5s20-25 with dissolve
                    mc "*Come on, [mc]... focus.*"
                    mc "*I can't get lost in these fantasies.*"
                    unknown "Hello? Yo, are you still there?"

                    scene e5s20-25
                    unknown "What the hell are you doing?"
                    unknown "Can you let me shower in peace?"

                    scene e5s20-09 with dissolve
                    show e5s20_cheerleader_blink1
                    mc "Shit... sorry, go on."
                    mc "I'll leave."

                    scene e5s20-38 with dissolve
                    hide e5s20_cheerleader_blink1
                    mc "*I can't believe Jon asked me to come in here like that.*"
        else:
            if persistent.type_nsfw == False:
                scene e5s20-19_cen with dissolve
                mc "*Huh?*"

                scene e5s20-21_cen with dissolve
                unknown "Ah... much better."

                scene e5s20-20_cen with dissolve
                mc "Hey... I-uh think you should maybe put those away."

                scene e5s20-22_cen with dissolve
                unknown "Why? They're not hurting anybody."

                scene e5s20-23_cen with dissolve
                unknown "You can look if you want."

                scene e5s20-20_cen with dissolve
                mc "I can?"

                scene e5s20-24_cen with dissolve
                unknown "I mean, you already touched them, so what's looking gonna do?"

                scene e5s20-26_cen with dissolve
                menu:
                    "Have a little fun":
                        if not _in_replay:
                            call extrovert_affinity_check from _call_extrovert_affinity_check_85
                            call color_check from _call_color_check_164
                            $ e5s20_cheerleader_lewd = True

                        if affinity_spectrum > 0:
                            scene e5s20-25_cen with dissolve
                            mc "Damn... they look pretty good I'm not going to lie."
                        else:
                            mc "..."

                            scene e5s20-25_cen with dissolve
                            unknown "Don't be shy."

                        scene e5s20-27_cen with dissolve
                        unknown "Get in here!"

                        scene e5s20-20_cen with dissolve
                        mc "Wait... for real, for real?"

                        scene e5s20-22_cen with dissolve
                        unknown "Unless you want to leave blue balled that is."

                        scene e5s20-25_cen with dissolve
                        mc "*Am I dreaming?*"

                        scene e5s20-27_cen with dissolve
                        unknown "Undress if you don't want your clothes getting wet."

                        scene e5s20-20_cen with dissolve
                        mc "Nope, not at all."

                        scene e5s20-29_cen with dissolve
                        unknown "Now... let me work my magic."

                        scene e5s20-31_cen with dissolve
                        unknown "You can't touch, you can only look."

                        scene e5s20-30_cen with dissolve
                        mc "*Sounds good to me.*"

                        scene e5s20-32_cen with dissolve
                        unknown "It's been so long since I've had something like this..."
                        unknown "Damn, and you're huge."

                        scene e5s20-33_cen with dissolve
                        unknown "How am I gonna fit all this in my mouth, huh?"

                        scene e5s20-30_cen with dissolve
                        mc "Do you need a little help?"

                        scene e5s20-31_cen with dissolve
                        unknown "Nope, no touching, remember?"

                        scene e5s20-32_cen with dissolve
                        unknown "Let's get it ready, shall we?"

                        scene e5s20-35_cen with dissolve
                        pause

                        scene e5s20-34_cen with dissolve
                        pause

                        scene e5s20-28_cen with dissolve
                        pause

                        scene e5s20-titjob1_cen with dissolve
                        mc "Ahh..."

                        scene e5s20-36_cen with dissolve
                        unknown "It seems to me like you're enjoying it."

                        scene e5s20-titjob2_cen with dissolve
                        mc "I am... keep doing it."

                        scene e5s20-titjob1_cen with dissolve
                        unknown "I have no intention of stopping, handsome."

                        scene e5s20-titjob3_cen with dissolve
                        mc "Oh..."
                        mc "*I feel like I'm in heaven.*"

                        scene e5s20-titjob2_cen with dissolve
                        pause

                        scene e5s20-titjob3_cen with dissolve
                        pause

                        scene e5s20-36_cen with dissolve
                        unknown "I'll speed it up a bit."

                        scene e5s20-titjob4_cen with dissolve
                        mc "*As if it didn't feel amazing already...*"

                        scene e5s20-36_cen with dissolve
                        unknown "How are you doing up there?"

                        scene e5s20-titjob5_cen with dissolve
                        mc "Fine... trying to hold on."

                        scene e5s20-titjob4_cen with dissolve
                        unknown "Oh... why are you trying?"
                        unknown "Just let go."
                        unknown "I'm here to make you forget."

                        scene e5s20-titjob6_cen with dissolve
                        mc "Damn..."
                        mc "If you keep this up, I won't be lasting much longer."

                        scene e5s20-36_cen with dissolve
                        unknown "It will be so satisfying watching you cum."

                        scene e5s20-titjob4_cen with dissolve
                        unknown "Let's not leave anything behind, shall we?"

                        scene e5s20-titjob5_cen with dissolve
                        mc "I'm with you on this one."

                        scene e5s20-blowjob1_cen with dissolve
                        mc "Nghh..."

                        scene e5s20-blowjob2_cen with dissolve
                        mc "Ahh, that feels amazing."

                        scene e5s20-blowjob3_cen with dissolve
                        pause

                        scene e5s20-blowjob2_cen with dissolve
                        mc "Your mouth is so hot, keep doing it."

                        scene e5s20-blowjob1_cen with dissolve
                        unknown "Guh... guh... guh..."

                        scene e5s20-blowjob3_cen with dissolve
                        mc "Fuck..."

                        scene e5s20-blowjob4_cen with dissolve
                        mc "Oh my God..."

                        scene e5s20-blowjob5_cen with dissolve
                        mc "*I can't believe I'm doing this.*"

                        scene e5s20-blowjob6_cen with dissolve
                        pause

                        scene e5s20-blowjob5_cen with dissolve
                        mc "*Is it really happening?*"

                        scene e5s20-blowjob4_cen with dissolve
                        pause

                        scene e5s20-blowjob6_cen with dissolve
                        mc "*Fuck... I can't last any longer.*"
                        mc "Hey, I'm gonna cum."

                        scene e5s20-blowjob4_cen with dissolve
                        mc "*She's not stopping!*"
                        mc "Ahhh, here it comes!"

                        scene e5s20-37 with dissolve
                        pause
                    "Focus" if not _in_replay:
                        if not _in_replay:
                            call introvert_affinity_check from _call_introvert_affinity_check_75
                            call color_check from _call_color_check_165

                        scene e5s20-25_cen with dissolve
                        mc "*Come on, [mc]... focus.*"
                        mc "*I can't get lost in these fantasies.*"
                        unknown "Hello? Yo, are you still there?"

                        scene e5s20-11_cen
                        unknown "What the hell are you doing?"
                        unknown "Can you let me shower in peace?"

                        scene e5s20-09_cen with dissolve
                        show e5s20_cheerleader_blink1
                        mc "Shit... sorry, go on."
                        mc "I'll leave."

                        scene e5s20-38 with dissolve
                        hide e5s20_cheerleader_blink1
                        mc "*I can't believe Jon asked me to come in here like that.*"

    $ renpy.end_replay()
return
