
# Variables
default e5f1_cleo = False
default e5f1_nate = False
default e5f1_desk = False
default e5f1_guitar = False

# Freeroam Collected Photos #

default persistent.e5f1_collected_p = 0
default persistent.e5f1_collected_tp = 0

# Freeroam 1 ###################################################################
label e5f1:
    stop music fadeout 2.0

    define e5f1_tracks = ["aces_high.ogg", "bad_sexy_dad_vibes.ogg", "breathe.ogg", "circles.ogg", "crazy_glue.ogg", "darien_gap.ogg", "energizing_indie_pop.ogg", "heartless_man.ogg", "hi_as_hats.ogg", "inertia.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "marathon_man.ogg", "motown_rehearsal.ogg", "onfire.ogg", "pioneers.ogg", "pop_song.ogg", "solo_acoustic_guitar.ogg", "the_pawnbrokers_stepdaughter.ogg", "tidalwave.ogg", "travel_light.ogg", "with_a_whimper.ogg", "wonder_under.ogg", "write_hear_right_now.ogg"]
    $ renpy.random.shuffle(e5f1_tracks)
    $ renpy.music.queue (e5f1_tracks, loop=True)

    $ persistent.e5f1_collected_tp = 6

    scene black with Dissolve(2.0)
    pause(1.0)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Go to sleep.")

    if e5s8_shelter_cleo == True:
        $ optional_quests.append("Talk to Cleo.")

    $ optional_quests.append("Talk to Nate.")
    $ optional_quests.append("Practice the guitar.")
    $ optional_quests.append("Sit at the desk.")

    scene e5f1-01 with dissolve
    call screen e5f1_main
    hide e5f1-01
return

# Map ##########################################################################

# Main ###
label e5f1_main:
    scene e5f1-01
    call screen e5f1_main with dissolve
return

label e5f1_nate:
    scene e5f1-nate_01 with dissolve
    mc "Yo, what's up, dude?"

    scene e5f1-nate_03 with dissolve
    nt "Hey [mc]."

    scene e5f1-nate_04 with dissolve
    nt "I'm just scrolling on my phone."

    scene e5f1-nate_05 with dissolve
    nt "What's new?"

    if e5s8_shelter_cleo == True:
        scene e5f1-nate_06 with dissolve
        nt "Besides our guest."

    scene e5f1-nate_02 with dissolve
    show e5f1_nate_blink1
    mc "Nothing, just hanging around."
    mc "Preparing for bed, I guess."

    scene e5f1-nate_10 with dissolve
    hide e5f1_nate_blink1
    nt "That's nice."

    if e5s8_shelter_cleo == True:
        scene e5f1-nate_05 with dissolve
        nt "So... what's up with the girl?"

        scene e5f1-nate_06 with dissolve
        nt "Is she... uh-staying long?"

        scene e5f1-nate_02 with dissolve
        show e5f1_nate_blink1
        mc "[cl]?"
        mc "She got fired by her boss and didn't have anywhere else to go."
        mc "I thought I could let her stay for a bit until she gets her issues fixed."

        scene e5f1-nate_07 with dissolve
        hide e5f1_nate_blink1
        nt "I'm sorry to hear that."

        scene e5f1-nate_02 with dissolve
        show e5f1_nate_blink1
        mc "I hope it doesn't bother you, or anything."

        scene e5f1-nate_08 with dissolve
        hide e5f1_nate_blink1
        nt "Yeah... uh-no, it's fine."
        nt "As long as she gets back on her feet, it's okay."

        scene e5f1-nate_02 with dissolve
        show e5f1_nate_blink1
        mc "*It seems like Nate's a bit bothered by her presence here.*"
        mc "*He's okay with it now, but I can't keep [cl] here forever.*"
        mc "*I need to help her in some way or another.*"
        mc "Anyway, I'll leave you to it."

        scene e5f1-nate_03 with dissolve
        hide e5f1_nate_blink1
        $ e5f1_nate = True
        $ optional_quests.remove("Talk to Nate.")
        nt "Alright."
    else:
        if e5s3_stay == True:
            scene e5f1-nate_05 with dissolve
            nt "So... what happened with the girl from last night?"

            scene e5f1-nate_02 with dissolve
            show e5f1_nate_blink1
            mc "She got fired by her boss and didn't have anywhere else to go."
            mc "Told her she could sleep the night here, but in the end she had to go somewhere else."
            mc "I don't want to get in trouble."

            scene e5f1-nate_07 with dissolve
            hide e5f1_nate_blink1
            nt "Yeah... I can see how that could be an issue."

            scene e5f1-nate_05 with dissolve
            nt "I'm really sorry to hear that."

            scene e5f1-nate_02 with dissolve
            show e5f1_nate_blink1
            mc "It's unfortunate, her co-worker was a jerk though."
            mc "You win some, you lose some."

            scene e5f1-nate_07 with dissolve
            hide e5f1_nate_blink1
            $ e5f1_nate = True
            $ optional_quests.remove("Talk to Nate.")
            nt "I guess so, yeah."
        else:
            scene e5f1-nate_11 with dissolve
            nt "Did you manage to do anything interesting with the guitar?"

            scene e5f1-nate_09 with dissolve
            mc "Nah, not yet, I'm still practicing."

            scene e5f1-nate_02 with dissolve
            show e5f1_nate_blink1
            if music_skills > 4 or guitar_skills > 1:
                mc "I got a competition right around the corner."

                scene e5f1-nate_10 with dissolve
                hide e5f1_nate_blink1
                nt "That's nice!"

                scene e5f1-nate_12 with dissolve
                nt "You think you got it?"

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "I think so, yeah."
                mc "I've been feeling pretty confident about it."

                scene e5f1-nate_10 with dissolve
                hide e5f1_nate_blink1
                nt "I'm glad to hear that!"
                nt "I heard you play a bunch of times, you really got better as you practiced it more."

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "You think so?"

                scene e5f1-nate_12 with dissolve
                hide e5f1_nate_blink1
                nt "Yeah dude, I like hearing you play."

                scene e5f1-nate_13 with dissolve
                nt "Helps me focus on my stuff."

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "I thought it bothered you."

                scene e5f1-nate_08 with dissolve
                hide e5f1_nate_blink1
                nt "Not at all, whenever you feel like it, go ahead."

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                $ e5f1_nate = True
                $ optional_quests.remove("Talk to Nate.")
                mc "Thanks man!"

                hide e5f1_nate_blink1
            else:
                mc "I got a competition right around the corner, although I'm not sure I'll make it."

                scene e5f1-nate_05 with dissolve
                hide e5f1_nate_blink1
                nt "Why not?"

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "I don't know, I'm just... not feeling it."
                mc "I don't think I practiced it enough."

                scene e5f1-nate_05 with dissolve
                hide e5f1_nate_blink1
                nt "Maybe you still got time."

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "Yeah... but I'll probably have to practice a lot to get back on track."

                scene e5f1-nate_13 with dissolve
                hide e5f1_nate_blink1
                nt "Nothing is impossible if you truly want it."

                scene e5f1-nate_02 with dissolve
                show e5f1_nate_blink1
                mc "I guess I've been a bit lenient with it."
                mc "I'll have to see how it works out."

                scene e5f1-nate_10 with dissolve
                hide e5f1_nate_blink1
                $ e5f1_nate = True
                $ optional_quests.remove("Talk to Nate.")
                nt "You know best, my guy."

    jump e5f1_main
return

# Left ###
label e5f1_left:
    if e5s8_shelter_cleo == True:
        scene e5f1-02
    else:
        scene e5f1-02_1
    call screen e5f1_left with dissolve
return

label e5f1_cleo:
    scene e5f1-cleo_01 with dissolve
    mc "Hey. How are you holding up?"

    scene e5f1-cleo_02 with dissolve
    cl "I'm okay... just trying to process everything."

    scene e5f1-cleo_04 with dissolve
    cl "I don't really know how I'm supposed to feel."

    scene e5f1-cleo_03 with dissolve
    show e5f1_cleo1_blink1
    mc "Yeah... I get that."
    mc "Did he leave you alone?"

    scene e5f1-cleo_05 with dissolve
    hide e5f1_cleo1_blink1
    cl "I mean, considering he kicked me out, I don't expect to see him again anytime soon."

    scene e5f1-cleo_06 with dissolve
    cl "Besides, I've been avoiding him at all costs."

    scene e5f1-cleo_04 with dissolve
    cl "So... there's that."

    scene e5f1-cleo_03 with dissolve
    show e5f1_cleo1_blink1
    mc "Are you up for doing something fun?"

    scene e5f1-cleo_05 with dissolve
    hide e5f1_cleo1_blink1
    cl "Fun? Like what?"

    scene e5f1-cleo_03 with dissolve
    show e5f1_cleo1_blink1
    mc "I don't know. We could play something or just hang out for a while."

    scene e5f1-cleo_04 with dissolve
    hide e5f1_cleo1_blink1
    cl "I'd love to, but I'm pretty tired tonight."

    scene e5f1-cleo_06 with dissolve
    cl "I'm not really in the mood for much right now."

    scene e5f1-cleo_05 with dissolve
    cl "I'm sorry. Maybe tomorrow?"

    scene e5f1-cleo_03 with dissolve
    show e5f1_cleo1_blink1
    mc "Yeah, sure. No worries. I'll let you get some rest."

    scene e5f1-cleo_04 with dissolve
    hide e5f1_cleo1_blink1
    $ e5f1_cleo = True
    $ optional_quests.remove("Talk to Cleo.")
    cl "Thanks!"

    jump e5f1_left
return

label e5f1_bed:
    if e5s8_shelter_cleo == True:
        if e5f1_bed == False:
            mc "*God, last night was rough.*"
            mc "*I had to sleep on the floor.*"
            $ optional_quests.append("Ask around for bedding.")
            $ e5f1_bed = True
            mc "*Maybe I should ask around and see if anyone has some extra bedding.*"
        else:
            $ collected_p = persistent.e5f1_collected_p
            $ collected_tp = persistent.e5f1_collected_tp
            $ renpy.show_screen("render_count_notify_pers")
            menu:
                "End freeroam":
                    if optional_quests:
                        $ optional_quests.clear()
                    if current_quests:
                        $ current_quests.clear()

                    $ renpy.hide_screen("questtracker_icon")

                    $ renpy.show_screen("render_count_notify")
                    pause(0.5)
                    $ renpy.hide_screen("render_count_notify_pers")

                    scene e5f1-cleo_01 with dissolve
                    mc "So... you ready to get some sleep?"

                    scene e5f1-cleo_07 with dissolve
                    cl "Finally. I'm exhausted."

                    scene e5f1-cleo_04 with dissolve
                    cl "I was... uhm-maybe thinking I could sleep on the floor tonight."

                    scene e5f1-cleo_03 with dissolve
                    show e5f1_cleo1_blink1
                    mc "Why? Is the bed not comfortable enough?"

                    scene e5f1-cleo_04 with dissolve
                    hide e5f1_cleo1_blink1
                    cl "No, it's not that. It's really comfortable."

                    scene e5f1-cleo_05 with dissolve
                    cl "It's just... I feel bad for you."

                    scene e5f1-cleo_06 with dissolve
                    cl "I know you didn't ask for any of this. Letting me stay here is already more than enough."

                    scene e5f1-cleo_04 with dissolve
                    cl "The least I can do is sleep on the floor."

                    scene e5f1-cleo_03 with dissolve
                    show e5f1_cleo1_blink1
                    mc "Don't worry about it. Seriously."
                    mc "It's not like you had a choice. That scumbag kicked you out."
                    mc "And besides, I'm happy to help you."
                    mc "Really, it's fine."

                    scene e5f1-cleo_05 with dissolve
                    hide e5f1_cleo1_blink1
                    cl "Alright... if you're really okay with it."

                    scene e5f1-cleo_03 with dissolve
                    show e5f1_cleo1_blink1
                    mc "Yeah. No problem."
                    mc "Come on, let's hit the sack."

                    scene black with Dissolve(2.0)

                    if e5f1_tracy == True:
                        scene e5f1-cleo_08 with Dissolve(2.0)
                        hide e5f1_cleo1_blink1
                        pause

                        scene e5f1-cleo_11 with dissolve
                        cl "I didn't know you had a pink mattress."

                        scene e5f1-cleo_12 with dissolve
                        mc "Haha, no, it's not mine."
                        mc "I got it from someone."

                        if e3s24_cleo_path == True:
                            scene e5f1-cleo_15 with dissolve
                            cl "Oh... from someone."

                            scene e5f1-cleo_16 with dissolve
                            cl "Well, alright!"
                            cl "Sleep tight, [mc]."

                            scene e5f1-cleo_17 with dissolve
                            pause

                            scene e5f1-cleo_21 with dissolve
                            mc "*Was she... jealous?*"
                        else:
                            scene e5f1-cleo_13 with dissolve
                            cl "Haha, alright, alright."

                            scene e5f1-cleo_14 with dissolve
                            cl "Sleep tight, [mc]."

                            scene e5f1-cleo_17 with dissolve
                            pause
                    elif e5f1_jordan == True:
                        scene e5f1-cleo_09 with Dissolve(2.0)
                        hide e5f1_cleo1_blink1
                        pause

                        scene e5f1-cleo_22 with dissolve
                        pause
                    else:
                        scene e5f1-cleo_10 with Dissolve(2.0)
                        hide e5f1_cleo1_blink1
                        pause

                        scene e5f1-cleo_23 with dissolve
                        pause

                        scene e5f1-cleo_24 with dissolve
                        mc "*Looks like another rough night awaits me.*"

                        scene e5f1-cleo_25 with dissolve
                        mc "*God, I hate this floor.*"

                    scene e5f1-cleo_18 with dissolve
                    pause

                    scene e5f1-cleo_19 with dissolve
                    pause

                    scene e5f1-cleo_20 with dissolve
                    pause

                    jump e5s9
                "Explore more":
                    $ renpy.show_screen("render_count_notify")
                    pause(0.5)
                    $ renpy.hide_screen("render_count_notify_pers")

    else:
        $ collected_p = persistent.e5f1_collected_p
        $ collected_tp = persistent.e5f1_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                scene e5f1-cleo_26 with dissolve
                pause

                jump e5s9

            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

    jump e5f1_left
return

label e5f1_guitar:
    mc "*Should I practice the guitar?*"
    menu:
        "Yes":
            if e5s8_shelter_cleo == True:
                scene e5f1-guitar_01 with dissolve
                pause

                scene e5f1-guitar_02 with dissolve
                cl "I was wondering when you were gonna start playing that."

                scene e5f1-guitar_03 with dissolve
                mc "You actually wanna hear me play?"

                scene e5f1-guitar_05 with dissolve
                cl "You're kidding?"
                cl "I've been curious ever since I saw it."

                if music_skills > 4 or guitar_skills > 1:
                    pass
                else:
                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "Alright... but I should warn you, I'm not exactly that good yet."

                scene e5f1-guitar_06 with dissolve
                hide e5f1_cleo2_blink1
                pause

                scene black with Dissolve(2.0)

                scene e5f1-guitar_07 with Dissolve(2.0)
                pause

                if music_skills > 4 or guitar_skills > 1:
                    scene e5f1-guitar_09 with dissolve
                    cl "Wow! That was amazing!"

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "For real?"

                    scene e5f1-guitar_10 with dissolve
                    hide e5f1_cleo2_blink1
                    cl "Yeah, how long have you been playing?"

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "A couple weeks."

                    scene e5f1-guitar_05 with dissolve
                    hide e5f1_cleo2_blink1
                    cl "Weeks? Dude, you sound like you've been playing your whole life."

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "Haha, it's mostly just one song I've been practicing over and over."

                    scene e5f1-guitar_10 with dissolve
                    hide e5f1_cleo2_blink1
                    $ guitar_skills += 1
                    $ music_skills += 1
                    $ e5f1_guitar = True
                    $ optional_quests.remove("Practice the guitar.")
                    cl "Still. I couldn't play something like that after only a few weeks."
                else:
                    scene e5f1-guitar_08 with dissolve
                    cl "That was nice!"

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "Really? Because I messed up a bunch of notes."

                    scene e5f1-guitar_11 with dissolve
                    hide e5f1_cleo2_blink1
                    cl "I couldn't even tell, haha."

                    scene e5f1-guitar_10 with dissolve
                    cl "To someone who doesn't play, it sounded pretty good."

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    mc "Yeah... but I need to be good enough for a competition."
                    mc "There are gonna be professionals there."

                    scene e5f1-guitar_11 with dissolve
                    hide e5f1_cleo2_blink1
                    cl "Oh... then you're kinda screwed, haha!"

                    scene e5f1-guitar_04 with dissolve
                    show e5f1_cleo2_blink1
                    $ guitar_skills += 1
                    $ music_skills += 1
                    $ e5f1_guitar = True
                    $ optional_quests.remove("Practice the guitar.")
                    mc "I'll keep practicing. Maybe I can get good enough in time."

                    hide e5f1_cleo2_blink1
            else:
                scene e5f1-guitar_12 with dissolve
                pause

                scene e5f1-guitar_13 with dissolve
                pause

                scene black with Dissolve(2.0)

                scene e5f1-guitar_14 with Dissolve(2.0)
                $ guitar_skills += 1
                $ music_skills += 1
                $ e5f1_guitar = True
                $ optional_quests.remove("Practice the guitar.")
                pause
        "Later":
            mc "*Maybe some other time.*"

    jump e5f1_left
return

# Right ###
label e5f1_right:
    scene e5f1-03
    call screen e5f1_right with dissolve
return

label e5f1_desk:
    scene e5f1-desk_01 with dissolve
    mc "*Hmm... let's see what's new on the college wall.*"
    mc "*Maybe there's some new assignments I need to do.*"

    scene e5f1-desk_02 with dissolve
    pause

    scene e5f1-desk_03 with dissolve
    mc "*Damn, there are homecoming posts everywhere.*"
    mc "*I guess it's getting closer and closer.*"
    mc "*I still haven't decided which girl I'm gonna take.*"
    $ optional_quests.remove("Sit at the desk.")
    mc "*Maybe I should make up my mind soon.*"

    $ e5f1_desk = True

    call e5f1_right from _call_e5f1_right
return

# Hallway1 ###
label e5f1_hallway1:
    scene e5f1-04
    call screen e5f1_hallway1 with dissolve
return

# Hallway2 ###
label e5f1_hallway2:
    scene e5f1-05
    call screen e5f1_hallway2 with dissolve
return

label e5f1_tracy:
    scene e5f1-tracy_01 with dissolve
    play sound knock_knock
    pause

    scene e5f1-tracy_06 with dissolve
    pause

    if e4s5_tracy_path_throw == True:
        scene e5f1-tracy_04 with dissolve
        play sound door_open
        tr "May I help you?"

        scene e5f1-tracy_02 with dissolve
        mc "Hey, uh... sorry for showing up like this."
        mc "I was wondering if you had any extra bedding you could spare?"

        scene e5f1-tracy_05 with dissolve
        tr "Extra bedding?"
        tr "Why?"

        scene e5f1-tracy_02 with dissolve
        mc "Well... I'm kind of helping someone out."
        mc "They don't have anywhere else to sleep."
        mc "And-"

        scene e5f1-tracy_06 with vpunch
        play sound door_close
        pause

        scene e5f1-tracy_07 with dissolve
        mc "*Yeah... I probably would've done the same thing.*"
    else:
        scene e5f1-tracy_08 with dissolve
        play sound door_open
        tr "[mc]? What's up?"

        scene e5f1-tracy_03 with dissolve
        mc "Hey, [tr]. Sorry for showing up like this."
        mc "I was wondering if you had any extra bedding you could spare?"

        scene e5f1-tracy_09 with dissolve
        tr "Extra bedding?"
        tr "Why? What's going on?"

        scene e5f1-tracy_03 with dissolve
        mc "I'm having someone stay over, and they don't have anywhere else to sleep."
        mc "And, to be honest, the floor's pretty rough."

        scene e5f1-tracy_10 with dissolve
        tr "Oh, I get it."

        scene e5f1-tracy_11 with dissolve
        tr "Let me see if I have anything."

        scene e5f1-tracy_06 with dissolve
        play sound door_close
        pause

        scene e5f1-tracy_12 with dissolve
        play sound door_open
        tr "There you go!"

        scene e5f1-tracy_03 with dissolve
        mc "Thank God [tr]. You're a lifesaver."
        mc "Seriously, thank you so much."

        scene e5f1-tracy_08 with dissolve
        $ optional_quests.remove("Ask around for bedding.")
        tr "Don't worry about it."

    $ e5f1_tracy = True

    call e5f1_hallway2 from _call_e5f1_hallway2
return

# Hallway3 ###
label e5f1_hallway3:
    scene e5f1-06
    call screen e5f1_hallway3 with dissolve
return

label e5f1_jordan:
    if e4s14_forgive == False:
        mc "*Yeah... I'd rather sleep on the floor than ask him for help.*"
    else:
        scene e5f1-jordan_01 with dissolve
        play sound knock_knock
        pause

        scene e5f1-jordan_02 with dissolve
        jd "Who is it?"

        scene e5f1-jordan_03 with dissolve
        mc "Yo, [jd]. It's me, [mc]."

        scene e5f1-jordan_02 with dissolve
        jd "[mc]."
        jd "I'm kind of in the middle of something."
        jd "Can it wait?"

        scene e5f1-jordan_04 with dissolve
        mc "I mean, I just wanted to ask if you had any extra bedding you could spare."

        scene e5f1-jordan_02 with dissolve
        jd "Extra bedding? Why? What happened to yours?"

        scene e5f1-jordan_05 with dissolve
        mc "It's just that... I'm having someone over, right?"

        scene e5f1-jordan_03 with dissolve
        mc "And the bed isn't really big enough for both of us."

        scene e5f1-jordan_02 with dissolve
        mc "..."

        scene e5f1-jordan_03 with dissolve
        mc "[jd]?"

        scene e5f1-jordan_06 with dissolve
        play sound door_open
        mc "Yo, thanks!"

        scene e5f1-jordan_07 with dissolve
        jd "Just a heads-up, dude."
        jd "If it's a chick, just sleep in the same bed."
        jd "Trust me, you won't regret it."

        scene e5f1-jordan_08 with dissolve
        pause

        scene e5f1-jordan_09 with dissolve
        play sound door_close
        $ e5f1_jordan = True
        $ optional_quests.remove("Ask around for bedding.")
        mc "Alright, I guess?"

    call e5f1_hallway3 from _call_e5f1_hallway3
return
