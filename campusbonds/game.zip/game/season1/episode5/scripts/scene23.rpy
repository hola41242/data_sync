
# Scene 23 - Cleo's concern ####################################################

label e5s23:
    stop music fadeout 2.0
    if e5s8_shelter_cleo == True:
        if e5s22_evelyn_lewd == True:
            play music iwnlylmd
            scene e5s23-01 with wipeleft
            mc "Hey, what's up?"

            scene e5s23-03 with dissolve
            cl "Hey, [mc]."
            cl "Where were you?"
            cl "You didn't come back last night."

            scene e5s23-02 with dissolve
            mc "Yeah, I got caught up with some club stuff, so I ended up staying there overnight."

            if e3s24_cleo_path == True:
                scene e5s23-04 with dissolve
                cl "I was worried about you."

                scene e5s23-02 with dissolve
                mc "Hey, it's okay. I should've texted you."
            mc "Did [nt] come back?"

            scene e5s23-03 with dissolve
            cl "Yeah, he got back pretty late and left early this morning."

            scene e5s23-05 with dissolve
            cl "I don't know what's going on with him. He was really quiet."

            scene e5s23-02 with dissolve
            mc "I see..."
            mc "Thanks for letting me know."

            scene e5s23-03 with dissolve
            cl "Yeah."
            cl "Anyway, I've gotta get to class. I'll see you later."

            scene e5s23-02 with dissolve
            mc "See you [cl]!"

            if e3s24_cleo_path == True:
                scene e5s23-07 with dissolve
                pause
            else:
                scene e5s23-06 with dissolve
                pause
        else:
            if e3s24_cleo_path == True:
                play music iwnlylmd
                scene e5s23-08 with wipeleft
                pause
                cl "Hey, [mc]."
                cl "There's something I wanted to ask you."

                scene e5s23-09 with dissolve
                mc "Sure, [cl]. What's up?"

                scene e5s23-11 with dissolve
                cl "I've noticed you've been coming and going pretty late the past few nights."

                scene e5s23-13 with dissolve
                cl "I was just wondering if everything was okay."

                scene e5s23-10 with dissolve
                mc "Yeah, everything's fine."
                mc "I've just been caught up with club stuff."
                mc "I think things will stay this way until we get everything sorted out."

                scene e5s23-12 with dissolve
                cl "Yeah, I figured. I was just worried about you."

                scene e5s23-11 with dissolve
                cl "And... I don't know. I guess I've been getting a little anxious about it."

                scene e5s23-10 with dissolve
                mc "I understand."
                mc "But don't worry, everything's fine."
                mc "Things are just a bit chaotic right now."

                scene e5s23-12 with dissolve
                cl "I see."

                scene e5s23-13 with dissolve
                cl "Anyway, I've gotta get to class. I'll see you later."

                scene e5s23-10 with dissolve
                mc "See you [cl]!"

                scene e5s23-14 with dissolve
                pause

    jump e5s24
return
