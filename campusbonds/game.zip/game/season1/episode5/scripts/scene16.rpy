
# Scene 16 - Hot Cinema ########################################################

label e5s16:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music laurel_breeze
    scene e5s16-01 with Dissolve(2.0)
    pause

    scene e5s16-02 with dissolve
    tf "Heyyy!"

    scene e5s16-03 with dissolve
    show e5s16_tiffany_blink1
    menu:
        "Hug her":
            $ tiffany_trust += 1

            scene e5s16-04 with dissolve
            hide e5s16_tiffany_blink1
            pause

            scene e5s16-05 with dissolve
            pause

            scene e5s16-10 with dissolve
            tf "Haha, what are you wearing?"
        "Kiss her hand":
            call extrovert_affinity_check from _call_extrovert_affinity_check_83
            call color_check from _call_color_check_160
            $ tiffany_trust += 2

            scene e5s16-06 with dissolve
            hide e5s16_tiffany_blink1
            pause

            scene e5s16-07 with dissolve
            mc "M'lady!"

            scene e5s16-08 with dissolve
            tf "Haha, you don't have to do that."

            scene e5s16-09 with dissolve
            mc "What? I'm getting into the role."

            scene e5s16-10 with dissolve
            tf "And by the way, what are you wearing?"
        "Say hi":
            call introvert_affinity_check from _call_introvert_affinity_check_73
            call color_check from _call_color_check_161
            mc "Hi [tf]!"

            scene e5s16-10 with dissolve
            tf "Haha, what are you wearing?"

    scene e5s16-03 with dissolve
    show e5s16_tiffany_blink1
    mc "You said old-school, didn't you?"
    mc "What are YOU wearing?"

    scene e5s16-13 with dissolve
    hide e5s16_tiffany_blink1
    tf "I got these clothes from my mom, they're from the 80's or something."

    scene e5s16-12 with dissolve
    tf "Except for the pants, these are mine."

    scene e5s16-11 with dissolve
    tf "I thought you'd keep it lowkey."

    scene e5s16-14 with dissolve
    mc "This is lowkey."

    scene e5s16-15 with dissolve
    tf "Okay, okay, Elvis."

    scene e5s16-03 with dissolve
    show e5s16_tiffany_blink1
    mc "So, are we going or are we gonna keep making fun of my outfit?"

    scene e5s16-12 with dissolve
    hide e5s16_tiffany_blink1
    tf "Just a bit more fun..."
    tf "Haha, I'm kidding, let's go."

    scene e5s16-16 with wipeleft
    pause

    scene e5s16-17 with dissolve
    tf "Well... this is it!"

    scene e5s16-18 with dissolve
    mc "I thought we were gonna see a movie in the cinema."

    scene e5s16-20 with dissolve
    tf "This IS a cinema, just outdoor."

    scene e5s16-19 with dissolve
    mc "That's why you asked me to wear these clothes?"

    scene e5s16-21 with dissolve
    tf "Wouldn't have been the same without 'em, right?"

    scene e5s16-19 with dissolve
    mc "I guess they do make this a bit special."

    scene e5s16-22 with dissolve
    tf "Let's go grab our seats."

    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    play music orbiting_a_distant_planet
    scene e5s16-23 with Dissolve(2.0)
    pause

    scene e5s16-24 with dissolve
    mc "So... like, let me get this straight."
    mc "How is this a horror movie again?"

    scene e5s16-26 with dissolve
    tf "It's a horror *comedy*. It's not supposed to be horror all the way."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "It makes you think it has a plot... then halfway through, they just... abandon it?"

    scene e5s16-27 with dissolve
    hide e5s16_tiffany_blink2
    tf "Come on, it's not that bad."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "No, seriously! The lead character is supposed to be this tough, no-nonsense cop, right?"
    mc "But the entire time, she's just giving one-liners like she's auditioning for a stand-up gig."
    mc "'Oh no, the killer's in the kitchen! Better go grab my latte before anything else happens!'"
    mc "And what's with the laughs? Who's laughing?"
    mc "Is it a sitcom? A novel? A sketch? I'm really confused."

    scene e5s16-28 with dissolve
    hide e5s16_tiffany_blink2
    tf "Haha, alright, alright, maybe it wasn't the best."

    scene e5s16-29 with dissolve
    tf "But hey, at least we got to hang out, right?"

    scene e5s16-27 with dissolve
    tf "Look, if you just... turn off your brain, it's actually fun."

    scene e5s16-30 with dissolve
    tf "I thought the killing scenes were stupidly funny, it always finds a way for the most random events to occur."

    scene e5s16-31 with dissolve
    tf "I don't really think we should judge it based on the plot."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "Yeah, those were kinda fun."

    scene e5s16-26 with dissolve
    hide e5s16_tiffany_blink2
    tf "Haha, see? You liked it."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "Alright, maybe I did, just a bit."

    scene e5s16-31 with dissolve
    hide e5s16_tiffany_blink2
    tf "You really love to one-up me, don't you?"

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "You just seem like the easiest person to annoy."

    scene e5s16-27 with dissolve
    hide e5s16_tiffany_blink2
    tf "Nah, I don't think so."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "Mmm... yeah, you are."

    scene e5s16-31 with dissolve
    hide e5s16_tiffany_blink2
    tf "No, I'm not."

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "Yes, you are."

    scene e5s16-33 with dissolve
    hide e5s16_tiffany_blink2
    tf "No, I'm not!"

    scene e5s16-32 with dissolve
    mc "Yes, you are."

    scene e5s16-34 with dissolve
    tf "Come on!! Stop!"

    scene e5s16-35 with dissolve
    mc "No, I won't."

    scene e5s16-34 with dissolve
    tf "Yes, you will!"

    scene e5s16-35 with dissolve
    mc "No, I won't."

    scene e5s16-36 with dissolve
    tf "Yes, you will!!!"

    scene e5s16-35 with dissolve
    mc "Make me."

    scene e5s16-37 with dissolve
    tf "Make you?"
    tf "You really wanna go there?"

    scene e5s16-25 with dissolve
    show e5s16_tiffany_blink2
    mc "If it's as fun as it is angering you, I'm all for it."

    if e2f2_tiffany_refuse == False and e4s22_tiffany_path == True:
        $ e5s16_tiffany_lewd = True
        call e5s16_tiffany_lewd from _call_e5s16_tiffany_lewd
    else:
        if e4s22_tiffany_path == True:
            scene e5s16-37 with dissolve
            hide e5s16_tiffany_blink2
            tf "Hmmm... not tonight. I'm not in the mood."

        scene e5s16-37 with dissolve
        tf "You win, alright?"
        tf "I get annoyed easily."

        scene e5s16-25 with dissolve
        show e5s16_tiffany_blink2
        mc "Finally, some honesty in there."

        scene e5s16-31 with dissolve
        hide e5s16_tiffany_blink2
        tf "I don't really like losing."
        tf "So consider yourself lucky tonight."

        scene e5s16-25 with dissolve
        show e5s16_tiffany_blink2
        mc "Alright, I won't push it."

        scene e5s16-27 with dissolve
        hide e5s16_tiffany_blink2
        tf "Good."
        tf "Let's get back to the movie."

        scene e5s16-35 with dissolve
        mc "Woohoo... you can see the excitement on my face."

    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    play music which_that_is_this
    scene e5s16-56 with Dissolve(2.0)
    mc "Thank you for tonight [tf]."

    scene e5s16-57 with dissolve
    mc "I really enjoyed it."

    scene e5s16-58 with dissolve
    tf "You said you didn't like the movie, haha!"

    scene e5s16-57 with dissolve
    mc "Yeah... but I guess you made it better."
    mc "Have a good night."

    if e2f2_tiffany_refuse == False:
        menu:
            "Kiss her":
                $ e5s16_tiffany_kiss = True
                $ tiffany_trust += 1
                $ tiffany_intimacy += 1
                scene e5s16-59 with dissolve
                pause

                scene e5s16-60 with dissolve
                pause

                scene e5s16-61 with dissolve
                pause

                scene e5s16-62 with dissolve
                pause

                scene e5s16-63 with dissolve
                pause

                scene e5s16-64 with dissolve
                pause

                scene e5s16-66 with dissolve
                tf "Oh... I-uh, don't know how to respond to this."

                scene e5s16-65 with dissolve
                mc "Sorry, you didn't like it?"

                scene e5s16-67 with dissolve
                tf "No, no! I loved it."

                if e4s22_tiffany_path == False:
                    scene e5s16-68 with dissolve
                    tf "It's just... not what friends do."

                    scene e5s16-65 with dissolve
                    mc "Yeah, sorry. You're right."
                else:
                    scene e5s16-62 with dissolve
                    pause

                scene e5s16-68 with dissolve
                tf "See you around!"
            "Just leave":
                pass

    scene e5s16-69 with dissolve
    pause

    if e4s29_olivia_path == True:
        jump e5s17
    else:
        jump e5s18
return


label e5s16_tiffany_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if _in_replay:
            play music orbiting_a_distant_planet
            scene e5s16-35 with dissolve
            mc "Make me."

            scene e5s16-37 with dissolve
            tf "Make you?"
            tf "You really wanna go there?"

            scene e5s16-25 with dissolve
            show e5s16_tiffany_blink2
            mc "If it's as fun as it is angering you, I'm all for it."

        scene e5s16-37 with dissolve
        hide e5s16_tiffany_blink2
        tf "Then I think you ain't seen nothing yet."

        scene e5s16-38 with dissolve
        mc "Why do I feel like this will include something sexual?"

        scene e5s16-40 with dissolve
        tf "Because that's all there is in your little perverted mind?"

        scene e5s16-39 with dissolve
        mc "Stupid me, how could I possibly think that with your hand on my butt?"

        scene e5s16-41 with dissolve
        tf "Haha, alright, you got me."
        tf "It was something sexual."

        scene e5s16-25 with dissolve
        show e5s16_tiffany_blink2
        mc "Not saying I wouldn't enjoy it, though."

        scene e5s16-37 with dissolve
        hide e5s16_tiffany_blink2
        tf "So... you're saying yes?"

        scene e5s16-25 with dissolve
        show e5s16_tiffany_blink2
        mc "I would, but with all these people watching?"

        scene e5s16-30 with dissolve
        hide e5s16_tiffany_blink2
        tf "No one's watching us, we're in the back row. They're watching the movie."

        scene e5s16-42 with dissolve
        mc "If you're really gonna do what you wanna do... then I guess they're watching the wrong show."

        scene e5s16-29 with dissolve
        tf "Then sit back, but not too back, and enjoy it!"

        scene e5s16-42 with dissolve
        mc "We're so getting kicked."

        if persistent.disable_nsfw == True:
            scene e5s16-handjob3 with dissolve
            pause

            scene e5s16-43 with dissolve
            mc "Ah, this feels so good!"

            scene e5s16-44 with dissolve
            tf "Shhh."

            scene e5s16-45 with dissolve
            tf "Enjoy the movie, remember?"

            scene e5s16-handjob2 with dissolve
            mc "Shit... ah! Yeah."

            scene e5s16-handjob1 with dissolve
            pause

            scene e5s16-46 with dissolve
            mc "What uh-was the movie about again?"

            scene e5s16-45 with dissolve
            tf "Just shut up!"

            scene e5s16-handjob4 with dissolve
            mc "*Fuck... this is amazing.*"

            scene e5s16-handjob3 with dissolve
            mc "*Imagine if someone turned around and saw us...*"
            mc "*What would we even say?*"

            scene e5s16-47 with dissolve
            tf "How are you keeping up?"

            scene e5s16-43 with dissolve
            mc "Uh-fine, just fine."

            scene e5s16-handjob2 with dissolve
            mc "I'm... really enjoying it."

            scene e5s16-48 with dissolve
            tf "Just fine? Then I better speed it up."

            scene e5s16-handjob5 with dissolve
            mc "Ah... fuck!"

            scene e5s16-handjob6 with dissolve
            mc "*Hope there's no cameras around. This could turn out awkward real quick.*"

            scene e5s16-handjob7 with dissolve
            mc "You're doing an amazing job, [tf]!"

            scene e5s16-handjob8 with dissolve
            mc "Uh..."

            scene e5s16-49 with dissolve
            tf "Damn... this makes me so wet."

            scene e5s16-48 with dissolve
            tf "Would you like to see my wet pussy?"

            scene e5s16-handjob7 with dissolve
            mc "*Holy shit, I didn't think she'd have this talking game.*"

            scene e5s16-50 with dissolve
            mc "Fuck... that would have been great."

            scene e5s16-49 with dissolve
            tf "Just rubbing it back and forth on your cock, my clit would have felt so good."

            scene e5s16-handjob5 with dissolve
            mc "Then hop on it!"

            scene e5s16-45 with dissolve
            tf "Haha, I'm not *that* crazy."

            scene e5s16-48 with dissolve
            tf "How I wish I could have masturbated now... but we don't have another bucket."

            scene e5s16-handjob7 with dissolve
            mc "Damn... maybe we should have gotten two. Wanna borrow mine?"

            scene e5s16-45 with dissolve
            tf "Haha, let's see you finish first. We'll worry about me later."

            scene e5s16-handjob6 with dissolve
            pause

            scene e5s16-handjob8 with dissolve
            mc "Fuck... just picturing you naked makes me so hard."
            mc "I don't think I can last much longer."

            scene e5s16-48 with dissolve
            tf "Then close your eyes, and start imagining me riding you right now."

            scene e5s16-51 with dissolve
            mc "Oh my God... you're killing me."

            scene e5s16-blowjob2 with dissolve
            mc "It feels so warm and wet."
            mc "I'd love to see you ride me sometime."

            scene e5s16-blowjob1 with dissolve
            tf "Mhm-hm!"

            scene e5s16-blowjob3 with dissolve
            mc "Fuck... what are you doing to me Tiffany."

            scene e5s16-blowjob1 with dissolve
            pause

            scene e5s16-blowjob2 with dissolve
            mc "I'm getting really close now."
            mc "*Holy shit, she's not stopping.*"
            mc "[tf], I'm about to cum!"
            mc "*I can't hold it anymore!*"
            mc "Ahhh...!"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5s16-51 with dissolve
            mc "Oh, shit!"
            mc "Sorry, I told you I was cumming."

            scene e5s16-52 with dissolve
            tf "Hey, it's alright."
            tf "Where else would you have came? In the popcorn?"

            scene e5s16-53 with dissolve
            mc "Haha, you're right, good call."

            scene e5s16-48 with dissolve
            tf "I actually enjoyed it. It felt hot to feel you cumming in my mouth."

            scene e5s16-50 with dissolve
            mc "Damn... keep talking like that and I might be ready for round two."

            scene e5s16-45 with dissolve
            tf "Okay, okay, let's calm down a little, haha!"

            scene e5s16-54 with dissolve
            tf "The movie's wrapping up, I don't think we have time for a second round."

            scene e5s16-47 with dissolve
            tf "But I'm definitely looking forward to doing this with you again."

            scene e5s16-55 with dissolve
            mc "For sure, maybe you'll be the one on the receiving end."

            scene e5s16-47 with dissolve
            tf "That would be really nice I'm not going to lie."
        else:
            if persistent.type_nsfw == False:
                scene e5s16-handjob3_cen with dissolve
                pause

                scene e5s16-43 with dissolve
                mc "Ah, this feels so good!"

                scene e5s16-44 with dissolve
                tf "Shhh."

                scene e5s16-45 with dissolve
                tf "Enjoy the movie, remember?"

                scene e5s16-handjob2_cen with dissolve
                mc "Shit... ah! Yeah."

                scene e5s16-handjob1_cen with dissolve
                pause

                scene e5s16-46 with dissolve
                mc "What uh-was the movie about again?"

                scene e5s16-45 with dissolve
                tf "Just shut up!"

                scene e5s16-handjob4_cen with dissolve
                mc "*Fuck... this is amazing.*"

                scene e5s16-handjob3_cen with dissolve
                mc "*Imagine if someone turned around and saw us...*"
                mc "*What would we even say?*"

                scene e5s16-47 with dissolve
                tf "How are you keeping up?"

                scene e5s16-43 with dissolve
                mc "Uh-fine, just fine."

                scene e5s16-handjob2_cen with dissolve
                mc "I'm... really enjoying it."

                scene e5s16-48 with dissolve
                tf "Just fine? Then I better speed it up."

                scene e5s16-handjob5_cen with dissolve
                mc "Ah... fuck!"

                scene e5s16-handjob6_cen with dissolve
                mc "*Hope there's no cameras around. This could turn out awkward real quick.*"

                scene e5s16-handjob7_cen with dissolve
                mc "You're doing an amazing job, [tf]!"

                scene e5s16-handjob8_cen with dissolve
                mc "Uh..."

                scene e5s16-49 with dissolve
                tf "Damn... this makes me so wet."

                scene e5s16-48 with dissolve
                tf "Would you like to see my wet pussy?"

                scene e5s16-handjob7_cen with dissolve
                mc "*Holy shit, I didn't think she'd have this talking game.*"

                scene e5s16-50 with dissolve
                mc "Fuck... that would have been great."

                scene e5s16-49 with dissolve
                tf "Just rubbing it back and forth on your cock, my clit would have felt so good."

                scene e5s16-handjob5_cen with dissolve
                mc "Then hop on it!"

                scene e5s16-45 with dissolve
                tf "Haha, I'm not *that* crazy."

                scene e5s16-48 with dissolve
                tf "How I wish I could have masturbated now... but we don't have another bucket."

                scene e5s16-handjob7_cen with dissolve
                mc "Damn... maybe we should have gotten two. Wanna borrow mine?"

                scene e5s16-45 with dissolve
                tf "Haha, let's see you finish first. We'll worry about me later."

                scene e5s16-handjob6_cen with dissolve
                pause

                scene e5s16-handjob8_cen with dissolve
                mc "Fuck... just picturing you naked makes me so hard."
                mc "I don't think I can last much longer."

                scene e5s16-48 with dissolve
                tf "Then close your eyes, and start imagining me riding you right now."

                scene e5s16-51_cen with dissolve
                mc "Oh my God... you're killing me."

                scene e5s16-blowjob2_cen with dissolve
                mc "It feels so warm and wet."
                mc "I'd love to see you ride me sometime."

                scene e5s16-blowjob1_cen with dissolve
                tf "Mhm-hm!"

                scene e5s16-blowjob3_cen with dissolve
                mc "Fuck... what are you doing to me Tiffany."

                scene e5s16-blowjob1_cen with dissolve
                pause

                scene e5s16-blowjob2_cen with dissolve
                mc "I'm getting really close now."
                mc "*Holy shit, she's not stopping.*"
                mc "[tf], I'm about to cum!"
                mc "*I can't hold it anymore!*"
                mc "Ahhh...!"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5s16-51_cen with dissolve
                mc "Oh, shit!"
                mc "Sorry, I told you I was cumming."

                scene e5s16-52_cen with dissolve
                tf "Hey, it's alright."
                tf "Where else would you have came? In the popcorn?"

                scene e5s16-53 with dissolve
                mc "Haha, you're right, good call."

                scene e5s16-48 with dissolve
                tf "I actually enjoyed it. It felt hot to feel you cumming in my mouth."

                scene e5s16-50 with dissolve
                mc "Damn... keep talking like that and I might be ready for round two."

                scene e5s16-45 with dissolve
                tf "Okay, okay, let's calm down a little, haha!"

                scene e5s16-54 with dissolve
                tf "The movie's wrapping up, I don't think we have time for a second round."

                scene e5s16-47 with dissolve
                tf "But I'm definitely looking forward to doing this with you again."

                scene e5s16-55 with dissolve
                mc "For sure, maybe you'll be the one on the receiving end."

                scene e5s16-47 with dissolve
                tf "That would be really nice I'm not going to lie."

    $ renpy.end_replay()
return
