
# Scene 3 - The last resort ####################################################

label e5s3:
    stop music fadeout 2.0
    scene e5s3-01 with wipeleft
    pause

    scene e5s3-02 with dissolve
    pause
    play sound knock_knock
    play music odesa
    pause

    scene e5s3-03 with dissolve
    pause

    play sound door_open
    scene e5s3-04 with dissolve
    mc "[cl]? What are you doing here?"

    scene e5s3-05 with dissolve
    cl "I... I didn't know where else to go."

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    mc "What happened?"

    scene e5s3-05 with dissolve
    hide e5s3_cleo_blink1
    cl "I... I got fired."

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    mc "Fired? For what?"

    scene e5s3-07 with dissolve
    hide e5s3_cleo_blink1
    cl "I don't know. I didn't do anything wrong."

    scene e5s3-05 with dissolve
    cl "I finished my shift today and my boss just... told me."

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    mc "They can just fire people like that?"

    scene e5s3-08 with dissolve
    hide e5s3_cleo_blink1
    cl "Apparently."
    cl "And on top of that, I didn't even get paid for this month."

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    if affinity_spectrum > 0:
        mc "What the fuck? That's such bullshit."

    mc "We need to sue them."

    scene e5s3-08 with dissolve
    hide e5s3_cleo_blink1
    cl "This isn't a law school, [mc]."
    cl "What are we gonna sue them with?"

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    mc "Yeah... okay. I wasn't being serious."
    mc "But still, that's not fair."
    mc "They can't just get away with that."

    scene e5s3-05 with dissolve
    hide e5s3_cleo_blink1
    cl "I just... need a moment."

    scene e5s3-06 with dissolve
    show e5s3_cleo_blink1
    mc "Yeah, of course. Come in."
    mc "Take a seat and we'll talk."

    scene e5s3-09 with dissolve
    hide e5s3_cleo_blink1
    mc "Hey [nt], a friend dropped by. Hope you don't mind."
    mc "She's dealing with some stuff."

    scene e5s3-10 with dissolve
    pause

    scene e5s3-11 with dissolve
    nt "Alright, alright. Do your thing."

    scene e5s3-09 with dissolve
    mc "Thanks, man."

    scene e5s3-12 with dissolve
    mc "So... what are we gonna do now?"

    scene e5s3-14 with dissolve
    cl "Honestly? I have no idea."

    scene e5s3-16 with dissolve
    cl "I just can't believe this is happening."

    menu:
        "Be a smart ass":
            $ cleo_trust -= 1
            mc "I don't want to say it... but I kinda told you so."

            scene e5s3-15 with dissolve
            cl "Seriously? I don't need that right now."

            scene e5s3-13 with dissolve
            show e5s3_cleo_blink2
            mc "But it's the truth!"
            mc "I'm sorry, but the signs were there. It was only a matter of time."
            mc "The only way I could see that place working out is if you dated [da], but honestly, that'd be worse than getting fired."
        "Be empathetic":
            $ cleo_trust += 1
            mc "I'm here, [cl]. I know this is rough."

            scene e5s3-13 with dissolve
            show e5s3_cleo_blink2
            mc "To be honest... it wasn't a great job anyway."

            scene e5s3-14 with dissolve
            hide e5s3_cleo_blink2
            cl "Yeah... but it was paying my bills."
        "Don't say anything":
            mc "..."

    scene e5s3-16 with dissolve
    hide e5s3_cleo_blink2
    cl "Oh my God... what am I gonna do now?"
    mc "What about your dorm?"

    scene e5s3-13 with dissolve
    show e5s3_cleo_blink2
    mc "Still nothing?"
    mc "It's been almost a month, right?"

    scene e5s3-17 with dissolve
    hide e5s3_cleo_blink2
    cl "I haven't heard anything. I'll check in the morning."

    if e1s15_help == True:
        scene e5s3-13 with dissolve
        show e5s3_cleo_blink2
        mc "We really should've found you another job."

        scene e5s3-17 with dissolve
        hide e5s3_cleo_blink2
        cl "[mc], stop... please!"
        cl "That's not what I need right now."

        scene e5s3-14 with dissolve
        cl "I know I fucked up, alright?"

        scene e5s3-18 with dissolve
        cl "But I can't rely on other people forever. I need to make my own choices."

        scene e5s3-19 with dissolve
        cl "I appreciate that you want to help... but I have to figure this out on my own."

        scene e5s3-13 with dissolve
        show e5s3_cleo_blink2
        mc "Then why did you come here?"

        scene e5s3-14 with dissolve
        hide e5s3_cleo_blink2
        cl "I just... needed someone to listen."

    scene e5s3-13 with dissolve
    show e5s3_cleo_blink2
    menu:
        "Let [cl] stay":
            $ cleo_intimacy += 1
            $ cleo_trust += 1
            $ e5s3_stay = True
            mc "Let's deal with it tomorrow, okay?"
            mc "Here, you can take the bed. I'll sleep on the floor."

            scene e5s3-17 with dissolve
            hide e5s3_cleo_blink2
            cl "Are you sure?"
            cl "I can leave, really."

            scene e5s3-13 with dissolve
            show e5s3_cleo_blink2
            mc "Yeah? And go where?"

            scene e5s3-19 with dissolve
            hide e5s3_cleo_blink2
            cl "...What about your roommate?"

            scene e5s3-20 with dissolve
            mc "It'll be fine. I'll explain it to him in the morning."
            mc "He'll understand."

            scene e5s3-21 with dissolve
            cl "..."

            scene e5s3-23 with dissolve
            cl "Fine..."
            cl "I'm sorry for bothering you."

            scene e5s3-22 with dissolve
            mc "Hey, don't be!"
            mc "I'm glad you came."

            scene e5s3-23 with dissolve
            cl "Thank you."
        "Don't help her":
            mc "..."

            scene e5s3-14 with dissolve
            hide e5s3_cleo_blink2
            cl "I should go..."
            cl "Maybe I can crash at a friend's place."
            cl "There's nothing we can do right now anyway."

            scene e5s3-13 with dissolve
            show e5s3_cleo_blink2
            mc "Yeah... you're right."
            mc "We'll deal with it tomorrow."

            scene e5s3-17 with dissolve
            hide e5s3_cleo_blink2
            cl "Thanks for listening, [mc]."
            cl "I hope your roommate wasn't too annoyed."

            scene e5s3-20 with dissolve
            mc "Nah, he's fine."

            scene e5s3-13 with dissolve
            show e5s3_cleo_blink2
            mc "Just... make sure you find somewhere safe to sleep, okay?"

            scene e5s3-17 with dissolve
            hide e5s3_cleo_blink2
            cl "Yeah... I will."

            scene e5s3-24 with dissolve
            pause

    jump e5s4
return
