
# Scene 2 - Exciting movie #####################################################

label e5s2:
    stop music fadeout 2.0
    stop sound fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music pioneers
    scene e5s2-01 with Dissolve(2.0)
    pause

    if e4s22_tiffany_lie == True:
        scene e5s2-30 with dissolve
        pause

        scene e5s2-31 with dissolve
        pause

        scene e5s2-32 with dissolve
        pause

        jump e5s3
    else:
        scene e5s2-02 with dissolve
        pause

        scene e5s2-04 with dissolve
        tf "Hey there!"

        scene e5s2-03 with dissolve
        mc "Hello [tf]!"

        scene e5s2-05 with dissolve
        tf "What are you up to?"

        scene e5s2-03 with dissolve
        mc "Nothing special today."
        mc "You?"

        scene e5s2-06 with dissolve
        tf "I was thinking about getting my nails done."

        scene e5s2-05 with dissolve
        tf "It's been a while, and it always makes me feel pretty."

        scene e5s2-03 with dissolve
        menu:
            "Compliment Tiffany":
                $ tiffany_trust += 1

                mc "I think you're pretty either way."

                scene e5s2-07 with dissolve
                tf "Really? That's so sweet."

                scene e5s2-08 with dissolve
                pause

                scene e5s2-09 with dissolve
                pause
            "Stay silent":
                mc "..."

        scene e5s2-10 with dissolve
        pause

        scene e5s2-11 with dissolve
        pause

        scene e5s2-12 with dissolve
        tf "You know... there's this awesome movie that just came out this week."

        scene e5s2-13 with dissolve
        tf "I've been dying to see it."

        scene e5s2-14 with dissolve
        tf "What do you say we go together?"
        tf "I bet you'll love it."

        scene e5s2-15 with dissolve
        mc "A new movie?"
        mc "I haven't really been keeping up."
        mc "What's it about?"

        scene e5s2-16 with dissolve
        tf "It's kind of a horror–comedy mix."
        tf "I know they don't usually go hand in hand, but trust me, this one's a banger."

        scene e5s2-17 with dissolve
        if affinity_spectrum > 0:
            tf "Plus, I heard there are a bunch of hot women in it..."

        tf "So? What do you think?"
        tf "Just tell me when you’re free and I'll book the tickets."

        scene e5s2-18 with dissolve
        menu:
            "Go with Tiffany":
                $ tiffany_trust += 1
                $ e5s2_movie = True
                mc "Yeah, of course I'll go with you, [tf]!"

                scene e5s2-19 with dissolve
                tf "Really? Yay!"
                tf "We're going to have so much fun, trust me."
                tf "I'll call you, okay?"
                tf "Oh, and make sure you have something old-school to wear."

                scene e5s2-20 with dissolve
                mc "Old-school? What are you planning?"

                scene e5s2-21 with dissolve
                tf "Haha, just trust me."

                scene e5s2-22 with dissolve
                mc "Alright, alright."
                mc "Sounds like fun already."

                scene e5s2-23 with dissolve
                tf "Haha, see you around!"

                if e4s22_tiffany_path == True:
                    scene e5s2-24 with dissolve
                    pause
            "Turn her down":
                $ tiffany_trust -= 1
                mc "Oh... I uh-I'm sorry, [tf]."
                mc "I can't really go. I've got a lot on my plate right now."

                scene e5s2-26 with dissolve
                tf "Really?"
                tf "Okay... I get it."
                tf "Worth a try, I guess."

                scene e5s2-27 with dissolve
                mc "We can go another time."

                scene e5s2-28 with dissolve
                tf "Yeah... sure."
                tf "Anyway, I'll see you around."

                scene e5s2-29 with dissolve
                mc "Alright. See you."

        scene e5s2-25 with dissolve
        pause

        jump e5s3
return
