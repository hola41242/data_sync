
# Variables
default e5f2_cleo1 = False
default e5f2_cleo2 = False
default e5f2_guitar = False

default e5f2_desk = False
default e5f2_sadie = False

default e5f2_tracy = False
default e5f2_jordan = False
default e5f2_ken = False
default e5f2_kettle = False

# Freeroam Collected Photos #

default persistent.e5f2_collected_p = 0
default persistent.e5f2_collected_tp = 0

# Freeroam 2 - Activities ######################################################

label e5f2:
    stop music fadeout 2.0

    define e5f2_tracks = ["aces_high.ogg", "bad_sexy_dad_vibes.ogg", "breathe.ogg", "circles.ogg", "crazy_glue.ogg", "darien_gap.ogg", "energizing_indie_pop.ogg", "heartless_man.ogg", "hi_as_hats.ogg", "inertia.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "marathon_man.ogg", "motown_rehearsal.ogg", "onfire.ogg", "pioneers.ogg", "pop_song.ogg", "solo_acoustic_guitar.ogg", "the_pawnbrokers_stepdaughter.ogg", "tidalwave.ogg", "travel_light.ogg", "with_a_whimper.ogg", "wonder_under.ogg", "write_hear_right_now.ogg"]
    $ renpy.random.shuffle(e5f2_tracks)
    $ renpy.music.queue (e5f2_tracks, loop=True)

    $ persistent.e5f2_collected_tp = 9

    scene black with Dissolve(2.0)
    pause(1.0)

    scene e5f2-01 with Dissolve(2.0)
    mc "*Hmm... looks like [nt]'s not here tonight.*"
    mc "*He didn't mention anything about going out.*"

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Go to sleep.")

    if e5s8_shelter_cleo == True:
        $ optional_quests.append("Ask Cleo about Nate.")

    $ optional_quests.append("Practice the guitar.")
    $ optional_quests.append("Sit at the desk.")

    mc "*Maybe he's staying over at a friend's place.*"

    if e5s8_shelter_cleo == True:
        mc "*I'll ask [cl] about it. She might've seen him before he left.*"

    call screen e5f2_main
    hide e5f2-01
return

# Map ##########################################################################

# Main ###
label e5f2_main:
    if e5f2_kettle == True and e5f2_cleo2 == False:
        jump e5f2_cleo2

    if e5f2_cleo1 == False:
        scene e5f2-01
    else:
        scene e5f2-01_1
    call screen e5f2_main with dissolve
return

label e5f2_cleo1:
    scene e5f2-cleo1_01 with dissolve
    mc "Hey."

    scene e5f2-cleo1_03 with dissolve
    cl "Oh, hey, [mc]!"

    if e5f2_guitar == False:
        scene e5f2-cleo1_04 with dissolve
        cl "I didn't hear you come in."

    scene e5f2-cleo1_05 with dissolve
    cl "I hope you don't mind me using your desk to study."

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Haha, I don't mind."
    mc "Although... this isn't my desk."

    scene e5f2-cleo1_04 with dissolve
    hide e5f2_cleo1_blink1
    cl "It's not?"

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Nope. Mine's the other one."

    scene e5f2-cleo1_04 with dissolve
    hide e5f2_cleo1_blink1
    cl "Oh, I didn't realize. Sorry."

    scene e5f2-cleo1_06 with dissolve
    cl "Do you think your roommate's gonna mind?"

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    menu:
        "[nt] will mind it":
            $ e5f2_nate_mind = True
            mc "Yeah, he probably will."

            scene e5f2-cleo1_05 with dissolve
            hide e5f2_cleo1_blink1
            cl "Oh, I'm sorry."
            cl "I should probably move over to yours, then."

            scene e5f2-cleo1_02 with dissolve
            show e5f2_cleo1_blink1
        "[nt] won't care":
            mc "Nah, I don't think he'll care."

    mc "Oh, by the way... speaking of [nt]..."
    mc "Have you seen him?"

    scene e5f2-cleo1_03 with dissolve
    cl "Nope, not really."
    cl "He wasn't here when I got here."

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Huh. Interesting."

    scene e5f2-cleo1_04 with dissolve
    hide e5f2_cleo1_blink1
    cl "Why? Did you need something from him?"

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Nah, I was just wondering."

    scene e5f2-cleo1_04 with dissolve
    hide e5f2_cleo1_blink1
    cl "Maybe he's staying over at a friend's place."

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Yeah, that's what I figured, too."

    scene e5f2-cleo1_07 with dissolve
    hide e5f2_cleo1_blink1
    cl "So, what's up with you?"
    cl "You doing anything interesting tonight?"

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    mc "Looks like someone's in a good mood."
    mc "Why? You got something in mind?"

    scene e5f2-cleo1_08 with dissolve
    hide e5f2_cleo1_blink1
    cl "Haha, I was kinda hoping you'd come up with something."

    scene e5f2-cleo1_05 with dissolve
    cl "Let me finish studying first, and then we'll see, alright?"

    scene e5f2-cleo1_02 with dissolve
    show e5f2_cleo1_blink1
    $ optional_quests.remove("Ask Cleo about Nate.")
    $ optional_quests.append("Talk to Cleo.")
    mc "Sure thing."

    $ e5f2_cleo1 = True

    hide e5f2_cleo1_blink1

    jump e5f2_main
return

# Left ###
label e5f2_left:
    if e5s8_shelter_cleo == True:
        if e5f2_cleo1 == True:
            if e5f2_cleo_activity == True and e5f2_kettle == False:
                scene e5f2-02_2
            else:
                scene e5f2-02
        else:
            scene e5f2-02_2
    else:
        scene e5f2-02_1
    call screen e5f2_left with dissolve
return

label e5f2_guitar:
    mc "*Should I practice the guitar?*"
    menu:
        "Yes":
            if e5s8_shelter_cleo == True:
                scene e5f2-guitar_01 with dissolve
                pause
            else:
                scene e5f2-guitar_02 with dissolve
                pause

            scene e5f2-guitar_03 with dissolve
            pause

            scene black with Dissolve(2.0)

            if e5s8_shelter_cleo == True:
                if e5f2_cleo_activity == True:
                    if e5f2_kettle == True:
                        scene e5f2-guitar_04 with Dissolve(2.0)
                        pause
                        cl "That was nice."

                        scene e5f2-guitar_05 with dissolve
                        pause

                        if e5f2_cleo1 == True:
                            scene e5f2-guitar_06 with dissolve
                            mc "Oh, sorry."
                            mc "Didn't I disturb your work?"

                            scene e5f2-guitar_07 with dissolve
                            cl "Quite the opposite, it helped me concentrate."

                            scene e5f2-guitar_06 with dissolve
                            $ guitar_skills += 1
                            $ music_skills += 1
                            $ e5f2_guitar = True
                            $ optional_quests.remove("Practice the guitar.")
                            mc "I'm glad you liked it!"
                        else:
                            scene e5f2-guitar_08 with dissolve
                            mc "Oh, sorry."
                            mc "Didn't I disturb your work?"

                            scene e5f2-guitar_09 with dissolve
                            cl "Quite the opposite, it helped me concentrate."

                            scene e5f2-guitar_08 with dissolve
                            $ guitar_skills += 1
                            $ music_skills += 1
                            $ e5f2_guitar = True
                            $ optional_quests.remove("Practice the guitar.")
                            mc "I'm glad you liked it!"
                    else:
                        scene e5f2-guitar_04 with Dissolve(2.0)
                        $ guitar_skills += 1
                        $ music_skills += 1
                        $ e5f2_guitar = True
                        $ optional_quests.remove("Practice the guitar.")
                        pause
                else:
                    scene e5f2-guitar_04 with Dissolve(2.0)
                    pause
                    cl "That was nice."

                    scene e5f2-guitar_05 with dissolve
                    pause

                    if e5f2_cleo1 == True:
                        scene e5f2-guitar_06 with dissolve
                        mc "Oh, sorry."
                        mc "Didn't I disturb your work?"

                        scene e5f2-guitar_07 with dissolve
                        cl "Quite the opposite, it helped me concentrate."

                        scene e5f2-guitar_06 with dissolve
                        $ guitar_skills += 1
                        $ music_skills += 1
                        $ e5f2_guitar = True
                        $ optional_quests.remove("Practice the guitar.")
                        mc "I'm glad you liked it!"
                    else:
                        scene e5f2-guitar_08 with dissolve
                        mc "Oh, sorry."
                        mc "Didn't I disturb your work?"

                        scene e5f2-guitar_09 with dissolve
                        cl "Quite the opposite, it helped me concentrate."

                        scene e5f2-guitar_08 with dissolve
                        $ guitar_skills += 1
                        $ music_skills += 1
                        $ e5f2_guitar = True
                        $ optional_quests.remove("Practice the guitar.")
                        mc "I'm glad you liked it!"
            else:
                scene e5f2-guitar_04 with Dissolve(2.0)
                $ guitar_skills += 1
                $ music_skills += 1
                $ e5f2_guitar = True
                $ optional_quests.remove("Practice the guitar.")
                pause
        "Later":
            mc "*Maybe some other time.*"

    jump e5f2_left
return

label e5f2_cleo2:
    if e5f2_cleo_activity == False:
        menu:
            "Activity with [cl]":
                scene e5f2-cleo2_01 with dissolve
                mc "Hey, did you finish your thing?"

                scene e5f2-cleo2_02 with dissolve
                cl "Yup. I was just reading this book while I waited for you."

                scene e5f2-cleo2_03 with dissolve
                mc "So, I came up with something."

                scene e5f2-cleo2_04 with dissolve
                mc "I'm pretty hungry, so I thought we could cook something."

                scene e5f2-cleo2_05 with dissolve
                cl "Cook?"
                cl "Do you even have a kitchen around here?"

                scene e5f2-cleo2_06 with dissolve
                show e5f2_cleo2_blink1
                mc "Not really, but we're not making anything complicated."

                scene e5f2-cleo2_07 with dissolve
                hide e5f2_cleo2_blink1
                cl "Hmmm..."

                scene e5f2-cleo2_08 with dissolve
                cl "Maybe we could make some ramen?"

                scene e5f2-cleo2_04 with dissolve
                mc "Sounds good to me."

                scene e5f2-cleo2_09 with dissolve
                cl "Awesome!"

                scene e5f2-cleo2_06 with dissolve
                show e5f2_cleo2_blink1
                mc "There's just one small problem."
                mc "We don't have any ramen, and we don't have a kettle to boil the water with."

                scene e5f2-cleo2_10 with dissolve
                hide e5f2_cleo2_blink1
                cl "Well, ramen's the easy part. What about the kettle?"

                scene e5f2-cleo2_06 with dissolve
                show e5f2_cleo2_blink1
                mc "Hmmm..."
                mc "Maybe I can look around the floor and see if anyone has one."

                scene e5f2-cleo2_11 with dissolve
                hide e5f2_cleo2_blink1
                cl "Worth a shot, I guess."

                scene e5f2-cleo2_10 with dissolve
                $ optional_quests.remove("Talk to Cleo.")
                $ current_quests.append("Find a kettle.")
                cl "I'll go see if I can find some ramen."

                $ e5f2_cleo_activity = True
            "Return to freeroam":
                pass
    else:
        scene e5f2-cleo2_12 with dissolve
        play sound door_close
        pause

        scene e5f2-cleo2_13 with dissolve
        cl "Hey, did you find something?"

        scene e5f2-cleo2_14 with dissolve
        mc "Sort of."

        scene e5f2-cleo2_16 with dissolve
        cl "Um... that's not a kettle."

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "I know. It's an electric casserole."

        scene e5f2-cleo2_17 with dissolve
        hide e5f2_cleo2_blink2
        cl "Will it work?"

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "I mean, it's either this or cold water."

        scene e5f2-cleo2_16 with dissolve
        hide e5f2_cleo2_blink2
        cl "How long does it take?"

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "The guy said it takes a while."

        scene e5f2-cleo2_18 with dissolve
        hide e5f2_cleo2_blink2
        cl "How long is 'a while'?"

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "He wasn't exactly specific."

        scene e5f2-cleo2_16 with dissolve
        hide e5f2_cleo2_blink2
        cl "Great."

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "Look on the bright side. At least we're eating."

        scene e5f2-cleo2_18 with dissolve
        hide e5f2_cleo2_blink2
        cl "Eventually."

        scene e5f2-cleo2_15 with dissolve
        show e5f2_cleo2_blink2
        mc "Eventually."

        scene black with Dissolve(2.0)
        hide e5f2_cleo2_blink2

        scene e5f2-cleo2_19 with Dissolve(2.0)
        pause

        scene e5f2-cleo2_20 with vpunch
        play sound phone_buzz
        pause

        scene e5f2-cleo2_21 with dissolve
        pause

        scene e5f2-cleo2_22 with dissolve
        cl "Finally! It's been ages."

        scene e5f2-cleo2_23 with dissolve
        mc "Oh my God."
        mc "I was just about to fall sleep."

        scene e5f2-cleo2_24 with dissolve
        pause

        scene e5f2-cleo2_25 with dissolve
        play sound water_drop
        pause

        scene e5f2-cleo2_26 with dissolve
        cl "How is it?"

        scene e5f2-cleo2_25 with dissolve
        mc "Warm."

        scene e5f2-cleo2_27 with dissolve
        cl "How warm?"

        scene e5f2-cleo2_28 with dissolve
        mc "Dip a finger in."

        scene e5f2-cleo2_29 with dissolve
        play sound water_drop
        pause

        scene e5f2-cleo2_26 with dissolve
        cl "I feel like water left at room temperature would've been warmer than this."

        scene e5f2-cleo2_28 with dissolve
        mc "Well, good enough, I guess."

        scene e5f2-cleo2_30 with dissolve
        mc "Let's throw in the ramen and eat. I'm starving."

        scene e5f2-cleo2_27 with dissolve
        cl "All that waiting made me starving, too."

        scene black with Dissolve(2.0)

        scene e5f2-cleo2_31 with Dissolve(2.0)
        pause

        scene e5f2-cleo2_32 with dissolve
        pause

        scene e5f2-cleo2_33 with dissolve
        mc "Honestly, despite everything, I think it turned out pretty decent."

        scene e5f2-cleo2_35 with dissolve
        cl "I mean, yeah."

        scene e5f2-cleo2_36 with dissolve
        cl "I was really hungry, though, so pretty much anything would've tasted good."

        scene e5f2-cleo2_34 with dissolve
        mc "Haha, you do have a point."

        scene e5f2-cleo2_36 with dissolve
        cl "Well, I'm gonna get back to reading."

        scene e5f2-cleo2_34 with dissolve
        mc "Alright. I'll clean these up."

        scene e5f2-cleo2_37 with dissolve
        cl "Thanks for going through all that trouble, by the way."

        scene e5f2-cleo2_34 with dissolve
        mc "For ramen?"

        scene e5f2-cleo2_38 with dissolve
        $ current_quests.remove("Return to your dorm.")
        cl "For keeping me company."

        $ e5f2_cleo2 = True

    jump e5f2_left
return

label e5f2_bed:
    if e5s8_shelter_cleo == True:
        $ collected_p = persistent.e5f2_collected_p
        $ collected_tp = persistent.e5f2_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                if e5f2_cleo1 == True:
                    scene e5f2-cleo3_01 with dissolve
                    mc "Ready to hit the sack?"

                    scene e5f2-cleo3_02 with dissolve
                    cl "Sure."

                    scene e5f2-cleo3_03 with dissolve
                    pause

                    scene e5f2-cleo3_04 with dissolve
                    if e3s24_cleo_path == True or e5f1_jordan == True:
                        menu:
                            "Ask [cl] to sleep together":
                                mc "Hey, I wanted to ask you something."

                                scene e5f2-cleo3_05 with dissolve
                                cl "What's up?"

                                scene e5f2-cleo3_04 with dissolve
                                mc "What do you say we sleep in the same bed tonight?"

                                scene e5f2-cleo3_06 with dissolve
                                cl "Both of us? In the same bed?"

                                if e3s24_cleo_path == True if affinity_spectrum < 0:
                                    $ e5f2_cleo_lewd = True

                                    cl "I didn't think you'd want to."

                                    scene e5f2-cleo3_08 with dissolve
                                    mc "Huh? Why not?"

                                    scene e5f2-cleo3_07 with dissolve
                                    cl "I mean... I don't know."

                                    scene e5f2-cleo3_09 with dissolve
                                    cl "We've slept separately since the first day, so I just assumed that's what you wanted."

                                    scene e5f2-cleo3_08 with dissolve
                                    mc "Well, with [nt] here, I guess it would've been a little weird."
                                    mc "But since he's not here tonight, I thought it would be okay."

                                    scene e5f2-cleo3_05 with dissolve
                                    cl "Of course. I understand."

                                    scene e5f2-cleo3_10 with dissolve
                                    cl "Well, come on, then."

                                    scene black with Dissolve(2.0)

                                    call e5f2_cleo_lewd from _call_e5f2_cleo_lewd
                                else:
                                    scene e5f2-cleo3_07 with dissolve
                                    cl "I guess we could."

                                    scene e5f2-cleo3_04 with dissolve
                                    mc "I can sleep on the floor if you'd rather."

                                    scene e5f2-cleo3_09 with dissolve
                                    cl "No, it's fine. We can share the bed."
                                    cl "I think there's enough room for both of us, right?"

                                    scene e5f2-cleo3_04 with dissolve
                                    mc "Yeah, I think so."

                                    scene black with Dissolve(2.0)

                                    scene e5f2-cleo3_11 with Dissolve(2.0)
                                    pause

                                    scene e5f2-cleo3_12 with dissolve
                                    pause

                                    scene e5f2-cleo3_13 with dissolve
                                    cl "Well... good night, [mc]!"

                                    scene e5f2-cleo3_14 with dissolve
                                    mc "Night, [cl]."

                                    scene e5f2-cleo3_57 with dissolve
                                    mc "*Damn... this is awkward.*"
                                    mc "*I don't think [jd]'s idea was such a good one.*"
                                    mc "..."
                                    mc "*At least I'm not sleeping on the floor anymore.*"

                                    scene e5f2-cleo3_58 with dissolve
                                    pause

                            "Sleep on the floor":
                                scene e5f2-cleo3_59 with dissolve
                                cl "Good night, [mc]!"

                                scene e5f2-cleo3_60 with dissolve
                                mc "Night, [cl]."

                                if e5f1_tracy == True:
                                    scene e5f2-cleo3_61 with dissolve
                                    pause
                                elif e5f1_jordan == True:
                                    scene e5f2-cleo3_62 with dissolve
                                    pause
                                else:
                                    scene e5f2-cleo3_63 with dissolve
                                    pause

                    else:
                        scene e5f2-cleo3_59 with dissolve
                        cl "Good night, [mc]!"

                        scene e5f2-cleo3_60 with dissolve
                        mc "Night, [cl]."

                        if e5f1_tracy == True:
                            scene e5f2-cleo3_61 with dissolve
                            pause
                        elif e5f1_jordan == True:
                            scene e5f2-cleo3_62 with dissolve
                            pause
                        else:
                            scene e5f2-cleo3_63 with dissolve
                            pause
                else:
                    scene e5f2-cleo3_65 with dissolve
                    mc "Ready to hit the sack?"

                    scene e5f2-cleo3_67 with dissolve
                    cl "Sure."

                    scene e5f2-cleo3_66 with dissolve
                    if e3s24_cleo_path == True or e5f1_jordan == True:
                        menu:
                            "Ask [cl] to sleep together" if affinity_spectrum < 0:
                                mc "Hey, I wanted to ask you something."

                                scene e5f2-cleo3_71 with dissolve
                                cl "What's up?"

                                scene e5f2-cleo3_66 with dissolve
                                mc "What do you say we sleep in the same bed tonight?"

                                scene e5f2-cleo3_69 with dissolve
                                cl "Both of us? In the same bed?"

                                if e3s24_cleo_path == True:
                                    $ e5f2_cleo_lewd = True

                                    cl "I didn't think you'd want to."

                                    scene e5f2-cleo3_68 with dissolve
                                    mc "Huh? Why not?"

                                    scene e5f2-cleo3_73 with dissolve
                                    cl "I mean... I don't know."

                                    scene e5f2-cleo3_70 with dissolve
                                    cl "We've slept separately since the first day, so I just assumed that's what you wanted."

                                    scene e5f2-cleo3_68 with dissolve
                                    mc "Well, with [nt] here, I guess it would've been a little weird."
                                    mc "But since he's not here tonight, I thought it would be okay."

                                    scene e5f2-cleo3_72 with dissolve
                                    cl "Of course. I understand."

                                    scene e5f2-cleo3_67 with dissolve
                                    cl "Well, come on, then."

                                    scene black with Dissolve(2.0)

                                    call e5f2_cleo_lewd from _call_e5f2_cleo_lewd_1
                                else:
                                    scene e5f2-cleo3_73 with dissolve
                                    cl "I guess we could."

                                    scene e5f2-cleo3_66 with dissolve
                                    mc "I can sleep on the floor if you'd rather."

                                    scene e5f2-cleo3_70 with dissolve
                                    cl "No, it's fine. We can share the bed."
                                    cl "I think there's enough room for both of us, right?"

                                    scene e5f2-cleo3_66 with dissolve
                                    mc "Yeah, I think so."

                                    scene black with Dissolve(2.0)

                                    scene e5f2-cleo3_11 with Dissolve(2.0)
                                    pause

                                    scene e5f2-cleo3_12 with dissolve
                                    pause

                                    scene e5f2-cleo3_13 with dissolve
                                    cl "Well... good night, [mc]!"

                                    scene e5f2-cleo3_14 with dissolve
                                    mc "Night, [cl]."

                                    scene e5f2-cleo3_57 with dissolve
                                    mc "*Damn... this is awkward.*"
                                    mc "*I don't think [jd]'s idea was such a good one.*"
                                    mc "..."
                                    mc "*At least I'm not sleeping on the floor anymore.*"

                                    scene e5f2-cleo3_58 with dissolve
                                    pause

                            "Sleep on the floor":
                                scene e5f2-cleo3_59 with dissolve
                                cl "Good night, [mc]!"

                                scene e5f2-cleo3_60 with dissolve
                                mc "Night, [cl]."

                                if e5f1_tracy == True:
                                    scene e5f2-cleo3_61 with dissolve
                                    pause
                                elif e5f1_jordan == True:
                                    scene e5f2-cleo3_62 with dissolve
                                    pause
                                else:
                                    scene e5f2-cleo3_63 with dissolve
                                    pause

                    else:
                        scene e5f2-cleo3_59 with dissolve
                        cl "Good night, [mc]!"

                        scene e5f2-cleo3_60 with dissolve
                        mc "Night, [cl]."

                        if e5f1_tracy == True:
                            scene e5f2-cleo3_61 with dissolve
                            pause
                        elif e5f1_jordan == True:
                            scene e5f2-cleo3_62 with dissolve
                            pause
                        else:
                            scene e5f2-cleo3_63 with dissolve
                            pause

                jump e5s13
            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

    else:
        $ collected_p = persistent.e5f2_collected_p
        $ collected_tp = persistent.e5f2_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                scene e5f2-cleo3_64 with dissolve
                pause

                jump e5s13

            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

    jump e5f2_left
return

label e5f2_cleo_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e5f2-cleo3_11 with Dissolve(2.0)
        pause

        scene e5f2-cleo3_12 with dissolve
        pause

        scene e5f2-cleo3_13 with dissolve
        cl "Are you comfortable?"

        scene e5f2-cleo3_14 with dissolve
        mc "Yeah. I have to admit, it's a lot better than sleeping on the floor."

        scene e5f2-cleo3_15 with dissolve
        cl "I'm sorry. I told you I could've slept on the floor myself."

        scene e5f2-cleo3_14 with dissolve
        mc "I know, but don't worry about it, okay?"

        scene e5f2-cleo3_16 with dissolve
        cl "Thank you, [mc]."
        cl "I don't know what I would've done if it weren't for you."

        scene e5f2-cleo3_17 with dissolve
        mc "I'm here for you, [cl]."

        scene e5f2-cleo3_18 with dissolve
        pause

        scene e5f2-cleo3_19 with dissolve
        pause

        scene e5f2-cleo3_20 with dissolve
        pause

        scene e5f2-cleo3_21 with dissolve
        pause

        scene e5f2-cleo3_22 with dissolve
        pause

        scene e5f2-cleo3_23 with dissolve
        pause

        scene e5f2-cleo3_25 with dissolve
        pause

        scene e5f2-cleo3_24 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e5f2-cleo3_26 with dissolve
            pause

            scene e5f2-cleo3_27 with dissolve
            cl "Oh... [mc]..."
            cl "Your... thing..."

            scene e5f2-cleo3_28 with dissolve
            mc "Huh?"

            scene e5f2-cleo3_29 with dissolve
            mc "Shit, I'm sorry!"

            scene e5f2-cleo3_31 with dissolve
            cl "No, no, don't be."

            scene e5f2-cleo3_30 with dissolve
            mc "God, this is awkward."
            cl "..."

            scene e5f2-cleo3_32 with dissolve
            cl "Can I see it?"

            scene e5f2-cleo3_30 with dissolve
            mc "What?"

            scene e5f2-cleo3_33 with dissolve
            cl "Oh my God, sorry. Forget I said that."

            scene e5f2-cleo3_34 with dissolve
            cl "That was so stupid."

            scene e5f2-cleo3_35 with dissolve
            mc "Haha, no, it wasn't."

            scene e5f2-cleo3_36 with dissolve
            mc "I was just surprised to hear you say that."
            mc "I- do you really want to see it?"

            scene e5f2-cleo3_37 with dissolve
            cl "Only if you want to."

            scene e5f2-cleo3_38 with dissolve
            cl "But it's okay. Please, let's just go to sleep."

            scene e5f2-cleo3_39 with dissolve
            pause

            scene e5f2-cleo3_40 with dissolve
            cl "Huh? What are you..."

            scene e5f2-cleo3_41 with dissolve
            pause

            scene e5f2-cleo3_42 with dissolve
            cl "Oh... wow!"

            scene e5f2-cleo3_43 with dissolve
            cl "I... uh..."

            scene e5f2-cleo3_44 with dissolve
            cl "I've never seen one in real life."

            # Lewd #############################################################

            scene e5f2-cleo3_45 with dissolve
            mc "Well, there it is."

            scene e5f2-cleo3_46 with dissolve
            pause

            scene e5f2-cleo3_47 with dissolve
            mc "Ah..."

            scene e5f2-cleo3_48 with dissolve
            cl "Does it hurt?"

            scene e5f2-cleo3_49 with dissolve
            mc "Haha, no."
            mc "It's just that... you touched it."

            scene e5f2-cleo3_50 with dissolve
            cl "Oh..."

            scene e5f2-cleo3_47 with dissolve
            pause

            scene e5f2-cleo3_51 with dissolve
            mc "Uh..."
            mc "*She's holding it in her hand!*"
            mc "*Is she gonna give me a handjob?*"

            scene e5f2-cleo3_52 with dissolve
            pause(0.5)

            scene e5f2-cleo3_51 with dissolve
            pause(0.5)

            scene e5f2-cleo3_52 with dissolve
            pause(0.5)

            scene e5f2-cleo3_51 with dissolve
            pause

            scene e5f2-cleo3_53 with dissolve
            cl "Damn... okay..."
            cl "It's... very hard."
            cl "We should go to sleep now."

            scene e5f2-cleo3_51 with dissolve
            pause

            scene e5f2-cleo3_46 with dissolve
            pause

            scene e5f2-cleo3_54 with dissolve
            pause

            scene e5f2-cleo3_56 with dissolve
            pause

            scene e5f2-cleo3_55 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e5f2-cleo3_26 with dissolve
                pause

                scene e5f2-cleo3_27 with dissolve
                cl "Oh... [mc]..."
                cl "Your... thing..."

                scene e5f2-cleo3_28 with dissolve
                mc "Huh?"

                scene e5f2-cleo3_29 with dissolve
                mc "Shit, I'm sorry!"

                scene e5f2-cleo3_31 with dissolve
                cl "No, no, don't be."

                scene e5f2-cleo3_30 with dissolve
                mc "God, this is awkward."
                cl "..."

                scene e5f2-cleo3_32 with dissolve
                cl "Can I see it?"

                scene e5f2-cleo3_30 with dissolve
                mc "What?"

                scene e5f2-cleo3_33 with dissolve
                cl "Oh my God, sorry. Forget I said that."

                scene e5f2-cleo3_34 with dissolve
                cl "That was so stupid."

                scene e5f2-cleo3_35 with dissolve
                mc "Haha, no, it wasn't."

                scene e5f2-cleo3_36 with dissolve
                mc "I was just surprised to hear you say that."
                mc "I- do you really want to see it?"

                scene e5f2-cleo3_37 with dissolve
                cl "Only if you want to."

                scene e5f2-cleo3_38 with dissolve
                cl "But it's okay. Please, let's just go to sleep."

                scene e5f2-cleo3_39 with dissolve
                pause

                scene e5f2-cleo3_40 with dissolve
                cl "Huh? What are you..."

                scene e5f2-cleo3_41 with dissolve
                pause

                scene e5f2-cleo3_42 with dissolve
                cl "Oh... wow!"

                scene e5f2-cleo3_43 with dissolve
                cl "I... uh..."

                scene e5f2-cleo3_44 with dissolve
                cl "I've never seen one in real life."

                # Lewd #############################################################

                scene e5f2-cleo3_45_cen with dissolve
                mc "Well, there it is."

                scene e5f2-cleo3_46_cen with dissolve
                pause

                scene e5f2-cleo3_47_cen with dissolve
                mc "Ah..."

                scene e5f2-cleo3_48 with dissolve
                cl "Does it hurt?"

                scene e5f2-cleo3_49 with dissolve
                mc "Haha, no."
                mc "It's just that... you touched it."

                scene e5f2-cleo3_50 with dissolve
                cl "Oh..."

                scene e5f2-cleo3_47_cen with dissolve
                pause

                scene e5f2-cleo3_51_cen with dissolve
                mc "Uh..."
                mc "*She's holding it in her hand!*"
                mc "*Is she gonna give me a handjob?*"

                scene e5f2-cleo3_52_cen with dissolve
                pause(0.5)

                scene e5f2-cleo3_51_cen with dissolve
                pause(0.5)

                scene e5f2-cleo3_52_cen with dissolve
                pause(0.5)

                scene e5f2-cleo3_51_cen with dissolve
                pause

                scene e5f2-cleo3_53 with dissolve
                cl "Damn... okay..."
                cl "It's... very hard."
                cl "We should go to sleep now."

                scene e5f2-cleo3_51_cen with dissolve
                pause

                scene e5f2-cleo3_46_cen with dissolve
                pause

                scene e5f2-cleo3_54 with dissolve
                pause

                scene e5f2-cleo3_56 with dissolve
                pause

                scene e5f2-cleo3_55 with dissolve
                pause

    $ renpy.end_replay()
return

# Right ###
label e5f2_right:
    scene e5f2-03
    call screen e5f2_right with dissolve
return

label e5f2_desk:
    scene e5f2-desk_01 with dissolve
    pause

    scene e5f2-desk_02 with dissolve
    pause

    scene e5f2-desk_03 with dissolve
    pause

    $ GameRunning = True

    while GameRunning:
        $ renpy.block_rollback()
        $ config.rollback_enabled = False
        menu:
            "Scarlett" if e3s24_cleo_path == False and affinity_spectrum > 0 and e5f2_scarlett == False:
                $ config.rollback_enabled = True

                mc "*Let's give [sc] a call and see what she's up to.*"
                mc "*Maybe I can have a little fun.*"

                call e5f2_scarlett from _call_e5f2_scarlett
            "Sadie" if e5f2_sadie == False:
                $ config.rollback_enabled = True

                call e5f2_sadie from _call_e5f2_sadie
            "Get up":
                $ config.rollback_enabled = True

                $ GameRunning = False

    jump e5f2_right
return

label e5f2_scarlett:
    scene e5f2-scarlett_01 with dissolve
    pause

    scene e5f2-scarlett_02 with dissolve
    pause

    scene e5f2-scarlett_03 with dissolve
    pause

    scene e5f2-scarlett_04 with dissolve
    sc "Yeah?"

    scene e5f2-scarlett_07 with dissolve
    mc "Hey, [sc]."

    scene e5f2-scarlett_09 with dissolve
    sc "Oh, it's you. Hey."

    scene e5f2-scarlett_06 with dissolve
    mc "'It's me'?"

    scene e5f2-scarlett_08 with dissolve
    mc "What, you don't have my number saved?"

    scene e5f2-scarlett_05 with dissolve
    sc "Nope. Why would I?"

    scene e5f2-scarlett_08 with dissolve
    mc "I don't know. In case you ever need to call me?"

    scene e5f2-scarlett_09 with dissolve
    sc "I've managed just fine without it."

    scene e5f2-scarlett_08 with dissolve
    mc "Alright, have it your way."

    scene e5f2-scarlett_05 with dissolve
    sc "So, why are you calling?"

    scene e5f2-scarlett_10 with dissolve
    mc "Just wanted to see what you were up to."

    scene e5f2-scarlett_09 with dissolve
    sc "What, are we checking in on each other now?"

    scene e5f2-scarlett_07 with dissolve
    mc "Why not? I'm bored out of my mind in my room."

    scene e5f2-scarlett_05 with dissolve
    sc "You sound like you're about to invite me over."

    scene e5f2-scarlett_07 with dissolve
    mc "Would you come if I did?"

    scene e5f2-scarlett_05 with dissolve
    sc "I don't know. Ask me, and we'll see."

    scene e5f2-scarlett_01 with dissolve
    menu:
        "Ask [sc]":
            call extrovert_affinity_check from _call_extrovert_affinity_check_87
            call color_check from _call_color_check_168

            scene e5f2-scarlett_07 with dissolve
            mc "Wanna come over?"

            scene e5f2-scarlett_11 with dissolve
            sc "Fuck no, haha."
            sc "I can't believe you just asked me that."

            scene e5f2-scarlett_10 with dissolve
            mc "I knew you'd say that..."
        "Don't ask":
            call introvert_affinity_check from _call_introvert_affinity_check_77
            call color_check from _call_color_check_169

            scene e5f2-scarlett_08 with dissolve
            mc "I feel like you're just messing with me."
            mc "Better not risk it."

            scene e5f2-scarlett_01 with dissolve
            mc "Good."

    scene e5f2-scarlett_07 with dissolve
    mc "So, what are you up to?"

    scene e5f2-scarlett_09 with dissolve
    sc "None of your business."

    scene e5f2-scarlett_13 with dissolve
    mc "Come on, just tell me."

    scene e5f2-scarlett_12 with dissolve
    pause

    scene e5f2-scarlett_09 with dissolve
    sc "I'm halfway through a bottle of booze."

    scene e5f2-scarlett_08 with dissolve
    mc "Wait, really?"

    scene e5f2-scarlett_07 with dissolve
    mc "What are you wearing?"

    if e5s8_shelter_cleo == True:
        $ cleo_trust -= 2
        if e5f2_cleo1 == True:
            scene e5f2-scarlett_17 with dissolve
            pause
        else:
            scene e5f2-scarlett_18 with dissolve
            pause

    scene e5f2-scarlett_04 with dissolve
    sc "Seriously? Are we really doing this?"

    scene e5f2-scarlett_09 with dissolve
    sc "Where did that come from?"

    scene e5f2-scarlett_10 with dissolve
    mc "Why not?"
    mc "Thought it'd be fun."

    scene e5f2-scarlett_09 with dissolve
    sc "I'm not doing that with you."

    scene e5f2-scarlett_06 with dissolve
    mc "Why?"
    mc "Just tell me what you're wearing."

    scene e5f2-scarlett_04 with dissolve
    sc "Byyyye."

    scene e5f2-scarlett_03 with dissolve
    mc "Wait, [sc]-"

    scene e5f2-desk_03 with dissolve
    mc "*She actually hung up on me.*"
    mc "..."
    mc "*Well... that was fun.*"

    scene e5f2-scarlett_14 with dissolve
    play sound phone_buzz
    mc "*Wait, she's calling me?*"

    scene e5f2-scarlett_08 with dissolve
    mc "Hey?"

    scene e5f2-scarlett_15 with dissolve
    sc "Alright, fine. Maybe I'll play along with your stupid little game."

    scene e5f2-scarlett_08 with dissolve
    mc "Wait, seriously?"

    scene e5f2-desk_03 with dissolve
    mc "*Damn it... she hung up on me again.*"
    mc "*And here I thought she was actually going to go through with it.*"

    scene e5f2-scarlett_14 with dissolve
    play sound phone_buzz
    mc "*Wait, I got a text.*"

    scene e5f2-scarlett_16 with dissolve

    nvl clear

    if persistent.sc_gallery_14_unlocked == False:
        $ persistent.sc_gallery_14_unlocked = True
        $ renpy.show_screen("render_notify")
        $ persistent.scarlett14 = True
        python:
            update_scarlett_list()

    sc_nvl "image: phone/scarlett/1.webp"
    sc_nvl "This is what I was wearing :p"
    sc_nvl "Not anymore, though."
    mc "*Holy shit. I can't believe [sc] actually sent me that.*"
    mc "*What should I say back?*"

    menu (nvl = True):
        "Cocky":
            call extrovert_affinity_check from _call_extrovert_affinity_check_88
            call color_check from _call_color_check_170
            n_nvl "Can I come over now?"
            sc_nvl "In your dreams."
            n_nvl "Damn..."
            n_nvl "At least I got a little something out of this."
            sc_nvl "That's all you're getting."
            n_nvl "What a shame."
        "Woah":
            n_nvl "Woah!"
        "That's hot":
            call extrovert_affinity_check from _call_extrovert_affinity_check_89
            call color_check from _call_color_check_171
            n_nvl "That's hot!"
            sc_nvl "Keep your dick in your pants."
            n_nvl "Like how you kept your underwear?"
            sc_nvl "Don't push your luck."
            n_nvl "Or what?"

    mc "*Well... she's not replying anymore.*"
    mc "*Guess that's all I'm getting tonight.*"

    $ e5f2_scarlett = True

    if e5f2_sadie == True and e5f2_scarlett == True:
        $ optional_quests.remove("Sit at the desk.")
return

label e5f2_sadie:
    mc "*[sd]'s been acting weird lately.*"
    mc "*I feel like she's been avoiding me and I have no idea why.*"
    mc "*Maybe I should text her.*"

    nvl clear

    n_nvl "Hey, you up?"

    mc "..."
    mc "*No reply.*"
    mc "*This is starting to worry me.*"
    mc "*Did I do something wrong?*"
    mc "*Maybe she needs some space.*"
    mc "*I should just do something else.*"

    $ e5f2_sadie = True

    if e5f2_sadie == True and e5f2_scarlett == True:
        $ optional_quests.remove("Sit at the desk.")
return

# Hallway1 ###
label e5f2_hallway1:
    scene e5f2-04
    call screen e5f2_hallway1 with dissolve
return

# Hallway2 ###
label e5f2_hallway2:
    scene e5f2-05
    call screen e5f2_hallway2 with dissolve
return

label e5f2_tracy:
    if e5f2_tracy == False:
        if e5f2_cleo_activity == False:
            mc "*I wonder what [tr]'s been up to lately.*"

        scene e5f2-tracy_01 with dissolve
        play sound knock_knock
        pause

        scene e5f2-tracy_02 with dissolve
        pause
        mc "*I don't think she's at her dorm.*"

        if e5f2_cleo_activity == True:
            mc "*She had a microwave. That would've worked.*"
        mc "*That's a shame.*"

        $ e5f2_tracy = True
    else:
        mc "*She's not here, there's no point in trying again.*"

    call e5f2_hallway2 from _call_e5f2_hallway2
return

# Hallway3 ###
label e5f2_hallway3:
    scene e5f2-06
    call screen e5f2_hallway3 with dissolve
return

label e5f2_jordan:
    if e4s14_forgive == False:
        mc "*Yeah... I'm not asking him for help.*"
    else:
        scene e5f2-jordan_01 with dissolve
        play sound knock_knock
        pause

        scene e5f2-jordan_03 with dissolve
        play sound door_open
        jd "Yo, what's up?"

        scene e5f2-jordan_02 with dissolve
        mc "What's up, [jd]?"
        mc "I'm trying to make some ramen, but I don't have anything to heat the water with."
        mc "Do you happen to have a kettle or a microwave?"

        scene e5f2-jordan_04 with dissolve
        jd "Nah, sorry, dude. I'm barely ever in my dorm."

        scene e5f2-jordan_05 with dissolve
        jd "But try checking down the hall, on the left. [ke] might have something."

        scene e5f2-jordan_02 with dissolve
        $ current_quests.remove("Find a kettle.")
        $ current_quests.append("Talk to Ken about the kettle.")
        mc "Alright, thanks, dude."

        $ e5f2_jordan = True

    call e5f2_hallway3 from _call_e5f2_hallway3
return

# Hallway Middle ###
label e5f2_hallway_middle:
    scene e5f2-07
    call screen e5f2_hallway_middle with dissolve
return

# Hallway Left ###
label e5f2_hallway_left:
    scene e5f2-08
    call screen e5f2_hallway_left with dissolve
return

label e5f2_ken:
    scene e5f2-ken_01 with dissolve
    play sound knock_knock
    pause

    scene e5f2-ken_03 with dissolve
    play sound door_open
    ke "[mc]?"
    ke "What's up? What brings you here?"

    scene e5f2-ken_02 with dissolve
    mc "Yo, hey, [ke]."
    mc "Slightly weird question. Do you have a kettle or anything I could use to boil some water?"
    mc "I'm trying to make some ramen."

    scene e5f2-ken_04 with dissolve
    ke "Sorry, dude. My microwave broke last week."

    scene e5f2-ken_05 with dissolve
    ke "I've been meaning to replace it, but money's tight, you know?"

    scene e5f2-ken_02 with dissolve
    mc "Yeah... I get it."

    scene e5f2-ken_04 with dissolve
    ke "You could try asking my friend. I heard he was heating up his food with something."

    scene e5f2-ken_06 with dissolve
    ke "Can't remember what it was, though."

    scene e5f2-ken_03 with dissolve
    ke "It was pretty weird, whatever it was. Maybe it'll help."
    ke "He lives in the second to last dorm on the left, heading toward the exit."

    scene e5f2-ken_02 with dissolve
    mc "Alright, I'll give it a shot."
    mc "Thanks, man!"

    scene e5f2-ken_03 with dissolve
    if e5f2_jordan == False:
        $ current_quests.remove("Find a kettle.")
    else:
        $ current_quests.remove("Talk to Ken about the kettle.")

    $ current_quests.append("Talk to Ken's friend about the kettle.")
    ke "Don't mention it."

    $ e5f2_ken = True

    jump e5f2_hallway_left
return

# Hallway Right ###
label e5f2_hallway_right:
    scene e5f2-09
    call screen e5f2_hallway_right with dissolve
return

label e5f2_stranger:
    scene e5f2-stranger_01 with dissolve
    play sound knock_knock
    pause

    scene e5f2-stranger_03 with dissolve
    play sound door_open
    unknown "Yeah?"

    scene e5f2-stranger_02 with dissolve
    mc "Hey, sorry to bother you."
    mc "I was wondering if you had anything I could use to heat up some water."
    mc "I'm trying to make some ramen, but I don't have anything to boil the water with."

    scene e5f2-stranger_04 with dissolve
    unknown "Hmmm..."

    scene e5f2-stranger_05 with dissolve
    unknown "Unfortunately, I'm not sure I can help."

    scene e5f2-stranger_06 with dissolve
    unknown "I mean, I do have an electric casserole, but it takes forever to heat anything up."

    scene e5f2-stranger_05 with dissolve
    unknown "I stopped using it because of that."

    scene e5f2-stranger_02 with dissolve
    mc "Do you think I could borrow it?"

    scene e5f2-stranger_05 with dissolve
    unknown "Suit yourself, but it's going to be a slow and painful process."
    unknown "Don't expect to eat anytime soon."

    scene e5f2-stranger_02 with dissolve
    if e5f2_ken == False:
        if e5f2_jordan == False:
            $ current_quests.remove("Find a kettle.")
        else:
            $ current_quests.remove("Talk to Ken about the kettle.")
    else:
        $ current_quests.remove("Talk to Ken's friend about the kettle.")

    $ current_quests.append("Return to your dorm.")
    mc "Well, it's better than nothing, I guess."

    $ e5f2_kettle = True

    jump e5f2_hallway_right
return
