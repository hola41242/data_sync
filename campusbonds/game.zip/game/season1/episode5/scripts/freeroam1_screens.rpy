
# Freeroam 1 screens ###########################################################

# Main #########################################################################
screen e5f1_main():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    add "e5f1-01"

    # Clickables
    if e5f1_nate == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/main/nate_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/main/nate_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_nate")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_nate")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/main/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/main/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_hallway1")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/main/left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/main/left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_left")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/main/right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/main/right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_right")

    # Collectibles
    if persistent.cl_gallery_14_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_14_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_14_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo14", True), Function(update_cleo_list)]


# Left #########################################################################
screen e5f1_left():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    if e5s8_shelter_cleo == True:
        add "e5f1-02"
    else:
        add "e5f1-02_1"

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/left/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/left/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_main")

    # Clickables
    if e5s8_shelter_cleo == True:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/left/bed2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/left/bed2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_bed")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_bed")
    else:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/left/bed1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/left/bed1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_bed")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_bed")

    if e5s8_shelter_cleo == True:
        if e5f1_cleo == False:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam1/left/cleo_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam1/left/cleo_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f1_cleo")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f1_cleo")

    if e5f1_guitar == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/left/guitar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/left/guitar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_guitar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_guitar")

    # Collectibles
    if persistent.tr_gallery_14_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_14_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_14_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy14", True), Function(update_tracy_list)]

# Right ########################################################################
screen e5f1_right():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    add "e5f1-03"

    # Clickables
    if e5f1_desk == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/right/desk_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/right/desk_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_desk")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_desk")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/right/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/right/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_main")

    # Collectibles
    if persistent.sd_gallery_14_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_14_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_14_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie14", True), Function(update_sadie_list)]

# Hallway 1 ####################################################################
screen e5f1_hallway1():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    add "e5f1-04"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/hallway1/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/hallway1/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_main")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/hallway1/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/hallway1/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_hallway2")

    # Collectibles
    if persistent.tf_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/hallway1/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/hallway1/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_5_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany5", True), Function(update_tiffany_list)]

# Hallway 2 ####################################################################
screen e5f1_hallway2():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    add "e5f1-05"

    # Clickables
    if e5f1_bed == True and e5f1_tracy == False and e5f1_jordan == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/hallway2/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/hallway2/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_tracy")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/hallway2/hallway1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/hallway2/hallway1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_hallway1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_hallway1")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/hallway2/hallway3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/hallway2/hallway3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_hallway3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_hallway3")

    # Collectibles
    if persistent.ev_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/hallway2/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/hallway2/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_5_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn5", True), Function(update_evelyn_list)]

# Hallway 3 ####################################################################
screen e5f1_hallway3():

    $ renpy.random.shuffle(e5f1_tracks)
    modal True

    add "e5f1-06"

    # Clickables
    if e5f1_bed == True and e5f1_jordan == False and e5f1_tracy == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/hallway3/jordan_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/hallway3/jordan_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f1_jordan")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f1_jordan")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam1/hallway3/hallway2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam1/hallway3/hallway2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f1_hallway2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f1_hallway2")

    # Collectibles
    if persistent.tf_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam1/hallway3/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam1/hallway3/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_6_unlocked", True), SetVariable("persistent.e5f1_collected_p", persistent.e5f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany6", True), Function(update_tiffany_list)]
