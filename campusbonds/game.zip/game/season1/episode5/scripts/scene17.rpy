
# Scene 17 - Therapy continues #################################################

label e5s17:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music sun_sets_on_a_protagonist
    scene e5s17-01 with Dissolve(2.0)
    ov "So... [mc], are you ready for therapy?"

    scene e5s17-02 with dissolve
    mc "Are you going to kick me out if I say no?"

    scene e5s17-04 with dissolve
    ov "Try me and we'll see."

    scene e5s17-03 with dissolve
    show e5s17_olivia_blink1
    mc "Haha, yes, yes, I am ready."

    scene e5s17-05 with dissolve
    hide e5s17_olivia_blink1
    ov "Seriously, it makes me very happy to see you continuing therapy."

    scene e5s17-03 with dissolve
    show e5s17_olivia_blink1
    mc "Well, let's get down to it, shall we?"

    scene e5s17-07 with dissolve
    hide e5s17_olivia_blink1
    ov "Wait, I've got some tea ready."

    scene e5s17-06 with dissolve
    ov "I'll be right back!"

    scene e5s17-08 with dissolve
    pause

    scene e5s17-09 with dissolve
    pause

    scene e5s17-10 with vpunch
    play sound weights
    pause

    play music hollow_grove
    scene e5s17-11 with dissolve
    mc "Yo, you alright?"

    scene e5s17-12 with dissolve
    ov "Yeah, sorry, just need to lay a little."

    scene e5s17-13 with dissolve
    pause

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "What's wrong?"

    scene e5s17-15 with dissolve
    hide e5s17_olivia_blink2
    ov "Oh... it's-it's nothing."

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "Come on, you can tell me."
    mc "I know I'm not the therapist here, but hey... it's the least I can do."

    scene e5s17-16 with dissolve
    hide e5s17_olivia_blink2
    ov "..."

    scene e5s17-17 with dissolve
    ov "It's just... some guy."

    scene e5s17-15 with dissolve
    ov "I probably shouldn't be telling you this... but it's been bothering me all week."

    scene e5s17-18 with dissolve
    ov "I'm gonna be straight with you, alright?"

    scene e5s17-19 with dissolve
    ov "We used to date back in the day."

    scene e5s17-15 with dissolve
    ov "But... things got messy and we decided to end things."

    scene e5s17-17 with dissolve
    ov "He sent me a letter this week. I thought I'd moved on, but... it still made me feel uneasy."

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "I'm sorry to hear that."
    mc "Did he mean a lot to you?"

    scene e5s17-18 with dissolve
    hide e5s17_olivia_blink2
    ov "He did back then, but I came to realize how disconnected we both were from each other."

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "What does he want now?"

    scene e5s17-20 with dissolve
    hide e5s17_olivia_blink2
    ov "I'm not sure, but I assume to reconcile."

    scene e5s17-17 with dissolve
    ov "Sorry, I didn't mean to turn this into my own therapy session."

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "I think we're exactly where we need to be."
    mc "Tell you what, you said you're a professor, right?"
    mc "How about we have lunch sometime this week and talk more about this, if you're open to that of course."
    mc "When you feel better."

    scene e5s17-18 with dissolve
    hide e5s17_olivia_blink2
    ov "But what about you?"

    scene e5s17-14 with dissolve
    show e5s17_olivia_blink2
    mc "Don't worry about me, I'll be fine."
    mc "These sessions have honestly helped a lot."
    mc "Besides, you seem to need it more."
    mc "We can just get back to meditating now and stress about that other stuff later."

    scene e5s17-21 with dissolve
    hide e5s17_olivia_blink2
    ov "Yeah, that sounds good."
    ov "Looks like you're learning a thing or two, huh?"

    scene e5s17-22 with dissolve
    mc "Guess I've got a good teacher."

    scene e5s17-23 with dissolve
    ov "Haha, let me make the tea again and we'll continue."

    scene e5s17-24 with dissolve
    pause

    jump e5s18
return
