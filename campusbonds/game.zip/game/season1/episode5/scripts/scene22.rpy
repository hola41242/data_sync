
# Scene 22 - Morning, Professor ################################################

label e5s22:
    stop music fadeout 2.0
    stop sound fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    $ e5s22_evelyn_lewd = True

    call e5s22_evelyn_lewd from _call_e5s22_evelyn_lewd

    scene e5s22-25 with dissolve
    pause(0.25)

    stop music
    scene e5s22-26 with vpunch
    mc "*Holy fuck! What was that?*"

    scene e5s22-27 with dissolve
    pause

    scene e5s22-28 with dissolve
    mc "*Wait... no, no, no!*"

    scene e5s22-29 with dissolve
    mc "*Did I just have a wet dream?*"

    scene e5s22-30 with dissolve
    mc "*Oh my God...*"

    play music little_tomcat
    scene e5s22-31 with dissolve
    pause

    scene e5s22-32 with dissolve
    ev "Morning!"

    scene e5s22-33 with dissolve
    pause

    scene e5s22-34 with dissolve
    mc "Shit! Hi uh- good morning [ev]!"

    scene e5s22-35 with dissolve
    ev "Are you okay?"

    scene e5s22-34 with dissolve
    mc "Yeah... just a little headache..."
    mc "There was a ton of work last night, I'm uh- just a little tired, that's all."

    scene e5s22-32 with dissolve
    ev "Okay?"
    ev "Would you like some coffee?"

    scene e5s22-36 with dissolve
    pause

    scene e5s22-37 with dissolve
    mc "No... I think I'll just be on my way."

    scene e5s22-38 with dissolve
    mc "I've got a lot of stuff to do at College."

    scene e5s22-39 with dissolve
    mc "But... uh- thanks anyway!"
    mc "I'll see you around!"

    scene e5s22-40 with dissolve
    pause

    scene e5s22-41 with dissolve
    play sound door_close
    pause

    scene e5s22-42 with dissolve
    ev "*What's wrong with this boy?*"

    scene e5s22-43 with dissolve
    pause

    scene e5s22-44 with dissolve
    pause

    scene e5s22-45 with dissolve
    ev "*Did he piss himself?*"

    scene e5s22-46 with dissolve
    ev "..."

    scene e5s22-47 with dissolve
    ev "*Wait... is this... what I think it is?*"

    scene e5s22-48 with dissolve
    ev "*Oh... my... God...*"

    scene e5s22-49 with dissolve
    pause

    if e5s8_shelter_cleo == True:
        jump e5s23
    else:
        jump e5s24
return


label e5s22_evelyn_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e5s22-01 with Dissolve(2.0)
        pause

        scene e5s22-02 with dissolve
        pause

        scene e5s22-03 with dissolve
        mc "*Shit... my back hurts so bad.*"

        scene e5s22-04 with dissolve
        mc "*I guess the storm's over.*"

        scene e5s22-05 with dissolve
        pause

        scene e5s22-06 with dissolve
        mc "*I better go take a leak.*"

        scene e5s22-07 with dissolve
        pause

        scene e5s22-08 with dissolve
        pause

        scene e5s22-09 with dissolve
        mc "*Huh? What's that?*"

        play music the_darker_side
        scene e5s22-10 with dissolve
        pause
        if persistent.disable_nsfw == True:
            scene e5s22-fingering4 with dissolve
            ev "*Moaning...*"

            scene e5s22-11 with dissolve
            mc "*Holy shit, she's masturbating!*"

            scene e5s22-fingering2 with dissolve
            mc "*With me here? I didn't know she's dirty like that.*"

            scene e5s22-fingering3 with dissolve
            pause

            scene e5s22-fingering1 with dissolve
            pause

            scene e5s22-fingering2 with dissolve
            pause

            scene e5s22-fingering4 with dissolve
            pause

            scene e5s22-fingering6 with dissolve
            mc "*Oh shit!*"

            scene e5s22-fingering5 with dissolve
            pause

            scene e5s22-fingering7 with dissolve
            pause

            scene e5s22-fingering8 with dissolve
            pause

            scene e5s22-12 with dissolve
            mc "*Fuck... I think she saw me.*"

            scene e5s22-13 with dissolve
            mc "*I need to get out of here-*"

            scene e5s22-14 with vpunch
            play sound door_open
            pause

            scene e5s22-15 with dissolve
            mc "Oh, uh-hey [ev]!"
            mc "I-uh... I'm sorry! I was looking for the bathroom and-"

            scene e5s22-16 with vpunch
            play sound woosh
            pause

            scene e5s22-17 with vpunch
            play sound punch
            pause

            scene e5s22-18 with dissolve
            pause

            scene e5s22-19 with dissolve
            pause

            scene e5s22-20 with dissolve
            pause

            scene e5s22-21 with dissolve
            mc "Ah... [ev]!"
            mc "That feels so good."

            scene e5s22-23 with dissolve
            mc "Listen... I'm sorry-"

            scene e5s22-22 with dissolve
            ev "Shhh!"

            scene e5s22-cowgirl2 with dissolve
            pause

            scene e5s22-cowgirl1 with dissolve
            mc "*I can't believe this is happening!*"

            scene e5s22-cowgirl3 with dissolve
            mc "*I'm fucking [ev]! Just like that.*"

            scene e5s22-cowgirl1 with dissolve
            pause

            scene e5s22-cowgirl2 with dissolve
            mc "*Her pussy is so tight, it feels amazing.*"

            scene e5s22-cowgirl3 with dissolve
            mc "Oh... ah!"

            scene e5s22-cowgirl4 with dissolve
            pause

            scene e5s22-cowgirl6 with dissolve
            mc "Oh my God!"
            mc "You are so hot."

            scene e5s22-cowgirl5 with dissolve
            pause

            scene e5s22-cowgirl4 with dissolve
            mc "I don't think I can last much longer."

            scene e5s22-cowgirl6 with dissolve
            ev "Do it! Finish inside me."
            ev "Fill me with your hot cum."

            scene e5s22-cowgirl5 with dissolve
            pause

            scene e5s22-cowgirl4 with dissolve
            mc "Oh fuck... I can't hold it anymore."
            mc "I'm cumming!"
            mc "Ahhh!"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e5s22-24 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e5s22-fingering4_cen with dissolve
                ev "*Moaning...*"

                scene e5s22-11 with dissolve
                mc "*Holy shit, she's masturbating!*"

                scene e5s22-fingering2_cen with dissolve
                mc "*With me here? I didn't know she's dirty like that.*"

                scene e5s22-fingering3_cen with dissolve
                pause

                scene e5s22-fingering1_cen with dissolve
                pause

                scene e5s22-fingering2_cen with dissolve
                pause

                scene e5s22-fingering4_cen with dissolve
                pause

                scene e5s22-fingering6_cen with dissolve
                mc "*Oh shit!*"

                scene e5s22-fingering5_cen with dissolve
                pause

                scene e5s22-fingering7_cen with dissolve
                pause

                scene e5s22-fingering8_cen with dissolve
                pause

                scene e5s22-12 with dissolve
                mc "*Fuck... I think she saw me.*"

                scene e5s22-13_cen with dissolve
                mc "*I need to get out of here-*"

                scene e5s22-14_cen with vpunch
                play sound door_open
                pause

                scene e5s22-15_cen with dissolve
                mc "Oh, uh-hey [ev]!"
                mc "I-uh... I'm sorry! I was looking for the bathroom and-"

                scene e5s22-16_cen with vpunch
                play sound woosh
                pause

                scene e5s22-17_cen with vpunch
                play sound punch
                pause

                scene e5s22-18_cen with dissolve
                pause

                scene e5s22-19_cen with dissolve
                pause

                scene e5s22-20_cen with dissolve
                pause

                scene e5s22-21_cen with dissolve
                mc "Ah... [ev]!"
                mc "That feels so good."

                scene e5s22-23_cen with dissolve
                mc "Listen... I'm sorry-"

                scene e5s22-22_cen with dissolve
                ev "Shhh!"

                scene e5s22-cowgirl2_cen with dissolve
                pause

                scene e5s22-cowgirl1_cen with dissolve
                mc "*I can't believe this is happening!*"

                scene e5s22-cowgirl3_cen with dissolve
                mc "*I'm fucking [ev]! Just like that.*"

                scene e5s22-cowgirl1_cen with dissolve
                pause

                scene e5s22-cowgirl2_cen with dissolve
                mc "*Her pussy is so tight, it feels amazing.*"

                scene e5s22-cowgirl3_cen with dissolve
                mc "Oh... ah!"

                scene e5s22-cowgirl4_cen with dissolve
                pause

                scene e5s22-cowgirl6_cen with dissolve
                mc "Oh my God!"
                mc "You are so hot."

                scene e5s22-cowgirl5_cen with dissolve
                pause

                scene e5s22-cowgirl4_cen with dissolve
                mc "I don't think I can last much longer."

                scene e5s22-cowgirl6_cen with dissolve
                ev "Do it! Finish inside me."
                ev "Fill me with your hot cum."

                scene e5s22-cowgirl5_cen with dissolve
                pause

                scene e5s22-cowgirl4_cen with dissolve
                mc "Oh fuck... I can't hold it anymore."
                mc "I'm cumming!"
                mc "Ahhh!"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e5s22-24_cen with dissolve
                pause

    $ renpy.end_replay()
return
