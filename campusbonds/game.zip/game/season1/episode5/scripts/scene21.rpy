
# Scene 21 - Bonding night (First choice) ######################################

label e5s21:
    stop music fadeout 2.0
    scene e5s21-01 with wipeleft
    pause

    play music bad_sexy_dad_vibes
    scene e5s21-02 with dissolve
    pause

    scene e5s21-03 with dissolve
    pause

    scene e5s21-04 with dissolve
    pause

    scene e5s21-05 with dissolve
    play sound door_open
    ev "Great, you're here."

    scene e5s21-06 with dissolve
    ev "Come on in."

    if affinity_spectrum > 0:
        scene e5s21-07 with dissolve
        mc "I honestly never thought I'd see your place."
        mc "Not after everything that happened."

        scene e5s21-08 with dissolve
        ev "You can thank [fr] for that. Otherwise, you'd be looking for a new college right now."

        scene e5s21-09 with dissolve
        mc "Ouch?"

    scene e5s21-10 with dissolve
    pause

    scene e5s21-11 with dissolve
    mc "So... what do you need me to do?"

    scene e5s21-12 with dissolve
    ev "I have some paperwork to submit, but I'm already drowning in work."

    scene e5s21-13 with dissolve
    ev "I need you to go online, research the terms on these sheets, and summarize them."

    scene e5s21-14 with dissolve
    mc "That sounds... pretty difficult."

    scene e5s21-15 with dissolve
    ev "Not at all."

    scene e5s21-16 with dissolve
    ev "Once you get through the first one, the rest will be a walk in the park."
    ev "There's just a lot of information. It's tedious more than anything."

    scene e5s21-17 with dissolve
    mc "Got it."
    mc "So, when do we start?"

    scene e5s21-18 with dissolve
    ev "I was thinking we grab some coffee first."

    scene e5s21-17 with dissolve
    mc "Alright, sounds good to me."

    scene black with Dissolve(2.0)

    scene e5s21-20 with Dissolve(2.0)
    pause

    scene e5s21-21 with dissolve
    mc "..."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "So... uh, [ev]..."
    mc "What have you been up to lately?"

    scene e5s21-22 with dissolve
    hide e5s21_evelyn_blink1
    ev "Just work."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "That's it? No fun at all?"

    scene e5s21-23 with dissolve
    hide e5s21_evelyn_blink1
    ev "I don't have time for that."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "That sounds like a miserable way to live."

    scene e5s21-24 with dissolve
    hide e5s21_evelyn_blink1
    ev "I like it. I don't see what's so miserable about it."

    scene e5s21-23 with dissolve
    ev "Not everyone needs constant entertainment."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "You must have some hobby though. Something you enjoy?"

    scene e5s21-22 with dissolve
    hide e5s21_evelyn_blink1
    ev "Hmm... I guess I do."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "And? What is it?"

    scene e5s21-24 with dissolve
    hide e5s21_evelyn_blink1
    ev "Let's just get to work."

    scene e5s21-19 with dissolve
    show e5s21_evelyn_blink1
    mc "Oh, come on, you can't just drop that and walk away-"

    scene e5s21-25 with dissolve
    hide e5s21_evelyn_blink1
    pause

    scene e5s21-26 with dissolve
    mc "And she left... great."

    scene e5s21-27 with dissolve
    pause

    scene e5s21-28 with dissolve
    ev "I'm assuming you've used a laptop before, right?"

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    menu:
        "Make a joke":
            call extrovert_affinity_check from _call_extrovert_affinity_check_86
            call color_check from _call_color_check_166
            $ evelyn_trust -= 1
            mc "Nope. I've lived under a rock my whole life."

            scene e5s21-30 with dissolve
            hide e5s21_evelyn_blink2
            ev "If you don't take this seriously, I'm kicking you out."

            scene e5s21-29 with dissolve
            show e5s21_evelyn_blink2
            mc "Alright, alright. Show me how it's done."
            mc "I'm all rocks-excuse me, ears."

        "Be serious":
            call introvert_affinity_check from _call_introvert_affinity_check_76
            call color_check from _call_color_check_167
            $ evelyn_trust += 1
            mc "Yeah, I know my way around one."

            scene e5s21-31 with dissolve
            hide e5s21_evelyn_blink2
            ev "Good. That makes things easier."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "So... was literally nobody else available to help you besides me?"

    scene e5s21-32 with dissolve
    hide e5s21_evelyn_blink2
    ev "If you dislike being here, you can leave."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "No, no, I was just asking."
    mc "I figured you asked me because you can't stand me."

    scene e5s21-31 with dissolve
    hide e5s21_evelyn_blink2
    ev "It's not that I can't stand you."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "Then what's the issue?"

    scene e5s21-33 with dissolve
    hide e5s21_evelyn_blink2
    ev "Are we really going to pretend you didn't break into my office twice?"

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "Fair enough... but even before that, you weren't exactly warm toward me."
    mc "I've seen how you are with the other girls. You're way more lenient with them."

    scene e5s21-31 with dissolve
    hide e5s21_evelyn_blink2
    ev "I'm sorry you feel that way."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "Don't you want to know anything about me?"

    scene e5s21-33 with dissolve
    hide e5s21_evelyn_blink2
    ev "Why would I need to?"

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "I don't know... maybe so you can see I'm not completely terrible?"

    scene e5s21-31 with dissolve
    hide e5s21_evelyn_blink2
    ev "I know that."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "Do you?"

    scene e5s21-34 with dissolve
    hide e5s21_evelyn_blink2
    ev "..."

    scene e5s21-32 with dissolve
    ev "Listen, it's not about you, okay?"

    scene e5s21-31 with dissolve
    ev "I just don't want to talk about that."

    scene e5s21-29 with dissolve
    show e5s21_evelyn_blink2
    mc "Okay, okay. No talking."
    mc "But personally, I think this would be a good chance for us to start off on the right foot."

    if e4s29_olivia_path == True:
        mc "I know I can be a pain sometimes... but I'm trying to work on that."

        scene e5s21-34 with dissolve
        hide e5s21_evelyn_blink2
        ev "..."

    scene e5s21-31 with dissolve
    hide e5s21_evelyn_blink2
    ev "Let's just get back to work."

    scene e5s21-34 with dissolve
    mc "*Wow... okay.*"

    scene black with Dissolve(2.0)

    scene e5s21-35 with Dissolve(2.0)
    pause

    scene e5s21-36 with dissolve
    pause

    scene e5s21-37 with dissolve
    mc "Oh my God, this term is killing me."

    scene e5s21-38 with dissolve
    ev "Hm?"

    scene e5s21-41 with dissolve
    ev "What's the problem?"

    scene e5s21-39 with dissolve
    show e5s21_evelyn_blink3
    mc "I don't know, I just... don't get it."
    mc "There are a bunch of words I've never seen before."

    scene e5s21-40 with dissolve
    hide e5s21_evelyn_blink3
    ev "Let me see."

    scene e5s21-42 with dissolve
    pause

    scene e5s21-43 with dissolve
    mc "Ah, sorry!"

    scene e5s21-44 with dissolve
    mc "Here... uh-go ahead!"

    scene e5s21-45 with dissolve
    ev "..."
    ev "*God... I feel like a college girl right now.*"

    scene e5s21-46 with dissolve
    ev "Yeah... you can leave this one out."
    ev "If you come across more terms like this, just mark them down. I'll handle them."

    scene e5s21-47 with dissolve
    mc "Great!"

    scene e5s21-48 with dissolve
    ev "..."

    scene e5s21-49 with dissolve
    ev "You can continue."

    scene e5s21-50 with dissolve
    mc "Oh... yeah. Right!"
    mc "Thanks!"

    scene e5s21-51 with dissolve
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    $renpy.sound.play("audio/sfx/rain.ogg", loop=True)

    play music failures
    scene e5s21-52 with Dissolve(2.0)
    pause

    scene e5s21-53 with dissolve
    if affinity_spectrum > 0:
        mc "Holy shit, it's pouring out there?"
    else:
        mc "Is it raining?"

    scene e5s21-54 with dissolve
    ev "Looks like it, yeah."

    scene e5s21-56 with dissolve
    ev "Can you get home from here?"

    scene e5s21-55 with dissolve
    show e5s21_evelyn_blink3
    mc "Yeah, don't worry. I'll just call a cab."
    mc "If you need anything else, let me know. Otherwise, I'll get going."

    scene e5s21-57 with dissolve
    hide e5s21_evelyn_blink3
    ev "No, that's everything."

    scene e5s21-55 with dissolve
    show e5s21_evelyn_blink3
    mc "Alright, great then."
    mc "I'll uh... see you around!"

    scene e5s21-58 with dissolve
    pause

    scene e5s21-59 with dissolve
    ev "..."

    scene e5s21-60 with dissolve
    ev "Hey, [mc]..."

    scene e5s21-61 with dissolve
    ev "Thanks for helping tonight."
    ev "You did well."

    scene e5s21-62 with dissolve
    mc "Glad I could help."

    if evelyn_trust > 1:
        scene e5s21-63 with dissolve
        ev "You're sure you'll be okay?"

        scene e5s21-62 with dissolve
        mc "Yeah, don't worry. Worst case, I get a little wet."

        scene e5s21-65 with dissolve
        ev "..."
        ev "*I can't believe I'm about to say this...*"

        scene e5s21-66 with dissolve
        ev "The storm doesn't look like it's letting up anytime soon."

        scene e5s21-64 with dissolve
        ev "You should stay the night, or at least wait until it calms down."
        ev "I don't want you catching a cold because of me."

        scene e5s21-62 with dissolve
        mc "It doesn't look that bad out there."

        scene e5s21-65 with dissolve
        ev "*It's just one night... he helped me. The least I can do is offer.*"

        scene e5s21-63 with dissolve
        ev "I insist."

        scene e5s21-62 with dissolve
        mc "Wait... you're serious, aren't you?"

        scene e5s21-65 with dissolve
        ev "..."

        scene e5s21-66 with dissolve
        ev "I'll prepare the couch."

        scene e5s21-67 with dissolve
        mc "*Am I dreaming, or am I actually staying at [ev]'s place tonight?*"

        scene e5s21-68 with dissolve
        mc "*I seriously did not see this coming.*"
        mc "*Being inside her place already felt like science fiction, but this? This beats everything.*"

        jump e5s22
    else:
        scene e5s21-69 with dissolve
        mc "*Shit, shit!*"
        mc "*Fuck... I can't see a damn thing!*"

        scene e5s21-70 with dissolve
        mc "*Just get home in one piece...*"

        scene e5s21-71 with dissolve
        pause

        if e5s8_shelter_cleo == True:
            jump e5s23
        else:
            jump e5s24
return
