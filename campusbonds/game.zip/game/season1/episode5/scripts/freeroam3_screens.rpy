
# Freeroam 3 screens ###########################################################

# Living #######################################################################
screen e5f3_living():

    $ renpy.random.shuffle(e5f3_tracks)
    modal True

    if e5f3_roman1 == False:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            add "e5f3-01_4"
        else:
            add "e5f3-01"
    else:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            if e5f3_roman_return == False:
                add "e5f3-01_3"
            else:
                add "e5f3-01_5"
        else:
            if e5f3_roman_return == False:
                add "e5f3-01_2"
            else:
                add "e5f3-01_1"

    # Clickables
    if e5f3_roman1 == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/living/roman1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/living/roman1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f3_roman1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f3_roman1")

    if e5f3_roman_return == True:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/living/roman2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/living/roman2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f3_roman2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f3_roman2")

    if e5f3_ruby_choice == False and e5f3_tracy_choice == False:
        if e5f3_roman2 == False:
            if e5f3_ruby1 == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/ruby_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/ruby_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_ruby1")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_ruby1")
        else:
            if e5f3_ruby2 == False and e5f3_stripper_offer == True:
                pass
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/ruby_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/ruby_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_ruby1")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_ruby1")

    if e5f3_roman2 == False:
        if e5f3_roman_return == False:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/living/scarlett1_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/living/scarlett1_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_scarlett1")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_scarlett1")
    else:
        if e5f3_tracy_choice == False and e5f3_ruby_choice == False:
            if e5f3_scarlett2 == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/scarlett2_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/scarlett2_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_scarlett2")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_scarlett2")

    if e5f3_tracy_choice == False and e5f3_ruby_choice == False:
        if e5f3_tracy == False or e5f3_roman2 == True:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/living/tracy_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/living/tracy_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_tracy")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_tracy")

    # Map
    if e5f3_roman1 == False:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/living/bathroom3_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/living/bathroom3_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_bathroom")
        else:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/living/bathroom1_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/living/bathroom1_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_bathroom")
    else:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            if e5f3_roman_return == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/bathroom3_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/bathroom3_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_bathroom")
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/bathroom4_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/bathroom4_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_bathroom")
        else:
            if e5f3_roman_return == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/bathroom1_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/bathroom1_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_bathroom")
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/bathroom2_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/bathroom2_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_bathroom")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_bathroom")

    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam3/living/bedroom1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam3/living/bedroom1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f3_bedroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f3_bedroom")

    if e5f3_roman1 == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/living/kitchen1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/living/kitchen1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f3_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f3_kitchen")
    else:
        if e5f3_ruby2 == False and e5f3_stripper_offer == True:
            if e5f3_roman_return == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/kitchen1_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/kitchen1_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_kitchen")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_kitchen")
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/kitchen2_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/kitchen2_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_kitchen")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_kitchen")
        else:
            if e5f3_roman_return == False:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/kitchen1_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/kitchen1_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_kitchen")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_kitchen")
            else:
                imagebutton:
                    idle im.Scale("season1/episode5/images/freeroam3/living/kitchen2_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode5/images/freeroam3/living/kitchen2_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e5f3_kitchen")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e5f3_kitchen")

    # Collectibles

# Bathroom ########################################################################
screen e5f3_bathroom():

    $ renpy.random.shuffle(e5f3_tracks)
    modal True

    if e5f3_ruby2 == False and e5f3_stripper_offer == True:
        add "e5f3-03_1"
    else:
        add "e5f3-03"

    # Clickables
    if e5f3_ruby2 == False and e5f3_stripper_offer == True:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/bathroom/ruby_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/bathroom/ruby_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f3_ruby2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f3_ruby2")

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam3/bathroom/living1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam3/bathroom/living1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f3_living")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f3_living")

    # Collectibles
    if persistent.tf_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_9_unlocked", True), SetVariable("persistent.e5f3_collected_p", persistent.e5f3_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany9", True), Function(update_tiffany_list)]

# Bedroom ########################################################################
screen e5f3_bedroom():

    $ renpy.random.shuffle(e5f3_tracks)
    modal True

    add "e5f3-02"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode5/images/freeroam3/bedroom/living_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode5/images/freeroam3/bedroom/living_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e5f3_bedroom_leave")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e5f3_bedroom_leave")

    # Collectibles
    if persistent.ev_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/bedroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/bedroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_8_unlocked", True), SetVariable("persistent.e5f3_collected_p", persistent.e5f3_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn8", True), Function(update_evelyn_list)]

# Kitchen ########################################################################
screen e5f3_kitchen():

    $ renpy.random.shuffle(e5f3_tracks)
    modal True

    if e5f3_roman1 == False:
        add "e5f3-04"
    else:
        if e5f3_roman_return == False:
            add "e5f3-04_1"
        else:
            add "e5f3-04_2"

    # Clickables

    # Map
    if e5f3_roman1 == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/kitchen/living1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/kitchen/living1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e5f3_living")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e5f3_living")
    else:
        if e5f3_roman_return == False:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/kitchen/living2_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/kitchen/living2_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_living")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_living")
        else:
            imagebutton:
                idle im.Scale("season1/episode5/images/freeroam3/kitchen/living3_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode5/images/freeroam3/kitchen/living3_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e5f3_living")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e5f3_living")

    # Collectibles
    if persistent.cl_gallery_16_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode5/images/freeroam3/kitchen/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode5/images/freeroam3/kitchen/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_16_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_16_unlocked", True), SetVariable("persistent.e5f3_collected_p", persistent.e5f3_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo16", True), Function(update_cleo_list)]
