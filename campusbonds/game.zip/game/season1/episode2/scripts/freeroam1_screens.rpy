
# Freeroam #1 Screens ##########################################################

screen e2f1_main():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-main"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/main/bs_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/main/bs_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_left")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/main/tables_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/main/tables_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_tables")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_tables")

    if persistent.cl_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_5_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo5", True), Function(update_cleo_list)]

screen e2f1_tables():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-tables"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/tables/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/tables/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_main")

    # Clickables ###############################################################

    if e2f1_alice == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/tables/alice_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/tables/alice_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_alice")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_alice")
    if e2f1_alice == True and e2f1_books < 5:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/tables/alice_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/tables/alice_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_ask_alice")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_ask_alice")
    if e2f1_alice == True and e2f1_books == 5:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/tables/alice_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/tables/alice_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_alice_final")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_alice_final")

    if persistent.mixed_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/tables/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/tables/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_5_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed5", True), Function(update_mixed_list)]

    if e2f1_money == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/tables/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/tables/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e2f1_money", True)]

# Bookshelfs left #

screen e2f1_bs_left():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-bs_left"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_left/bs1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_left/bs1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs1")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_left/bs2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_left/bs2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs2")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_left/bs3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_left/bs3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs3")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_left/bs_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_left/bs_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_right")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_left/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_left/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_main")

    if persistent.sd_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs_left/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs_left/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_4_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie4", True), Function(update_sadie_list)]

screen e2f1_bs1():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-bs1"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs1/bs2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs1/bs2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs2")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs1/bs_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs1/bs_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_left")

    # Clickables ###############################################################

    if e2f1_math == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs1/book_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs1/book_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_ma_book")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_ma_book")

    if persistent.fr_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs1/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs1/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_5_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca5", True), Function(update_francesca_list)]

screen e2f1_bs2():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-bs2"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs2/bs_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs2/bs_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_left")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs2/bs1_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs2/bs1_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs1")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs1")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs2/bs3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs2/bs3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs3")

    # Clickables ###############################################################

    if e2f1_english == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs2/book_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs2/book_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_en_book")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_en_book")

    if persistent.tr_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs2/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs2/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_5_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy5", True), Function(update_tracy_list)]

screen e2f1_bs3():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-bs3"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs3/bs_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs3/bs_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_left")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs3/bs2_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs3/bs2_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs2")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs2")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs3/bs4_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs3/bs4_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs4")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs4")

    # Clickables ###############################################################

    if e2f1_history == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs3/cleo_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs3/cleo_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_cleo")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_cleo")

    if persistent.cl_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs3/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs3/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_6_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo6", True), Function(update_cleo_list)]

    if persistent.sd_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs3/magazine2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs3/magazine2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_5_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie5", True), Function(update_sadie_list)]

# Bookshelfs right #

screen e2f1_bs_right():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    add "e2f1-bs_right"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_right/bs4_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_right/bs4_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs4")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs4")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_right/bs5_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_right/bs5_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs5")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs5")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_right/bs_left_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_right/bs_left_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_left")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_left")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs_right/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs_right/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_main")

    if persistent.tr_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs_right/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs_right/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_4_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy4", True), Function(update_tracy_list)]

screen e2f1_bs4():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    if e2f1_ken == False:
        add "e2f1-bs4"
    else:
        add "e2f1-bs4-1"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs4/bs3_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs4/bs3_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs3")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs3")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs4/bs5_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs4/bs5_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs5")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs5")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs4/bs_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs4/bs_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_right")

    # Clickables ###############################################################

    if e2f1_ken == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs4/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs4/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_ken")

    if e2f1_geography == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs4/book_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs4/book_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_ge_book")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_ge_book")

    if persistent.fr_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs4/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs4/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_4_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca4", True), Function(update_francesca_list)]

screen e2f1_bs5():

    $ renpy.random.shuffle(e2f1_tracks)
    modal True

    if e2f1_evelyn == False:
        add "e2f1-bs5"
    else:
        add "e2f1-bs5-1"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs5/bs4_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs5/bs4_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs4")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs4")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam1/bs5/bs_right_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam1/bs5/bs_right_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f1_bs_right")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f1_bs_right")

    # Clickables ###############################################################

    if e2f1_evelyn == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs5/evelyn_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs5/evelyn_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_evelyn")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_evelyn")

    if e2f1_phy_sci == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs5/book_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs5/book_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f1_phy_sci_book")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f1_phy_sci_book")

    if persistent.sc_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam1/bs5/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam1/bs5/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_4_unlocked", True), SetVariable("persistent.e2f1_collected_p", persistent.e2f1_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett4", True), Function(update_scarlett_list)]
