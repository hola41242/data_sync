
# Scene 3 - Meeting Francesca ##################################################

label e2s3:
    $ config.rollback_enabled = True
    stop music fadeout 2.0

    scene black with Dissolve(2.0)
    pause(1.0)

    play music failures
    scene e2s3-04 with Dissolve(2.0)
    pause

    scene e2s3-03 with dissolve
    pause

    scene e2s3-02 with dissolve
    pause

    scene e2s3-01 with dissolve
    pause

    scene e2s3-05 with dissolve
    show e2s3-francesca_blink1
    mc "Hey!"

    scene e2s3-06 with dissolve
    hide e2s3-francesca_blink1
    fr "Hello [mc]."

    scene e2s3-07 with dissolve
    fr "Shall we take a walk?"

    scene e2s3-05 with dissolve
    show e2s3-francesca_blink1
    mc "Sure."

    scene e2s3-08 with dissolve
    hide e2s3-francesca_blink1
    pause

    scene e2s3-09 with wipeleft
    fr "..."

    scene e2s3-10 with dissolve
    mc "So, what's up [fr]?"

    scene e2s3-11 with dissolve
    fr "*Exhales.*"

    scene e2s3-12 with dissolve
    fr "I don't want to hurt you, [mc]."

    scene e2s3-13 with dissolve
    fr "But there are some things that I can't really explain to you right now."

    scene e2s3-14 with dissolve
    show e2s3-francesca_blink2
    mc "Tell me what you can."

    scene e2s3-15 with dissolve
    hide e2s3-francesca_blink2
    fr "I don't want to get attached to you, [mc]."

    scene e2s3-16 with dissolve
    fr "That night when we talked was amazing!"

    scene e2s3-17 with dissolve
    fr "I felt like for once someone was getting me."

    scene e2s3-18 with dissolve
    fr "I could finally disconnect from all the crap that was happening around me."

    scene e2s3-19 with dissolve
    if e1s11_kiss_her == False:
        fr "I guess that fear got the best of me when I left."
    else:
        fr "I guess that fear got the best of me when you kissed me."

    scene e2s3-20 with dissolve
    show e2s3-francesca_blink2
    mc "Fear of what, [fr]?"

    scene e2s3-21 with dissolve
    hide e2s3-francesca_blink2
    fr "Fear of hurting you..."

    scene e2s3-22 with dissolve
    fr "Fear of making stupid decisions and ruining everything."

    scene e2s3-23 with dissolve
    mc "Why would you say that?"

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Do you think it's better to just run away instead of trying?"

    scene e2s3-25 with dissolve
    hide e2s3-francesca_blink3
    fr "I don't think it's better to run away."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Then why did you do it?"

    scene e2s3-26 with dissolve
    hide e2s3-francesca_blink3
    fr "I don't like letting people down."

    scene e2s3-27 with dissolve
    fr "I thought that by leaving and trying to ignore you, you'd just disappear and everything would be ok again."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Ouch."

    scene e2s3-28 with dissolve
    hide e2s3-francesca_blink3
    fr "Oh shit!"
    fr "Sorry, I didn't mean it that way!"

    scene e2s3-29 with dissolve
    fr "You're a great guy [mc]!"
    fr "I don't want you to disappear!"

    scene e2s3-30 with dissolve
    mc "Hey, I get it [fr]."
    menu:
        "Reassure her":
            $ francesca_trust += 1

            scene e2s3-24 with dissolve
            show e2s3-francesca_blink3
            mc "For starters, I really think you're great."
            mc "I don't think you'd let me down."

            scene e2s3-31 with dissolve
            hide e2s3-francesca_blink3
            fr "Really?"

            scene e2s3-34 with dissolve
            show e2s3-francesca_blink4
            mc "Yeah."
            mc "I don't know you all that well but from the few words we've exchanged you seem like an awesome person."

            scene e2s3-31 with dissolve
            hide e2s3-francesca_blink4
            fr "Thanks [mc]!"

            scene e2s3-32 with dissolve
            fr "I feel a lot better after this."

            scene e2s3-34 with dissolve
            show e2s3-francesca_blink4
            mc "I'm glad!"

        "Be friendly":

            scene e2s3-24 with dissolve
            show e2s3-francesca_blink3
            mc "I really do!"
            mc "Don't worry, I know what you meant to say."
            mc "I was just messing with you."

            scene e2s3-31 with dissolve
            hide e2s3-francesca_blink3
            fr "Oh, haha, thanks [mc]."

    scene e2s3-33 with dissolve
    hide e2s3-francesca_blink4
    fr "So, did I answer your question?"

    scene e2s3-34 with dissolve
    show e2s3-francesca_blink4
    mc "More or less, yeah."
    mc "I seriously don't think you should run away."
    mc "Running away in life won't solve your problems and I know you know that."

    scene e2s3-25 with dissolve
    hide e2s3-francesca_blink4
    fr "Yeah... you're right."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Oh, also..."
    mc "You mentioned a fight with someone when we first met."

    scene e2s3-35 with dissolve
    hide e2s3-francesca_blink3
    fr "Yeah, it was with my dad."

    scene e2s3-26 with dissolve
    fr "Same old arguments..."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Didn't moving away to college solve your problems?"

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "Well, I didn't really move away."

    scene e2s3-37 with dissolve
    fr "I live pretty close to the university so I didn't get a dorm inside the campus."

    scene e2s3-26 with dissolve
    fr "My father obviously didn't see a need for me to move away."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "So did you try talking to him?"

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "Yeah, I did."

    scene e2s3-37 with dissolve
    fr "Back when I first got into college."

    scene e2s3-35 with dissolve
    fr "He said that he wouldn't want me to live in those filthy shared rooms."

    scene e2s3-37 with dissolve
    fr "Where people are drinking and doing drugs at every turn."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Did your father ever live on campus?"

    scene e2s3-27 with dissolve
    hide e2s3-francesca_blink3
    fr "He did, yeah."
    fr "Pretty hypocritical of him to tell me that when he himself chose to live in that environment."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Can't you move away now?"
    mc "Maybe switch universities or something?"

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "Well, it's a bit more complicated than that."

    scene e2s3-37 with dissolve
    fr "Plus that I'm year 3 so I've got just a bit left before graduation."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Yeah... you're right."

    scene e2s3-26 with dissolve
    hide e2s3-francesca_blink3
    fr "I gotta live with it now."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "What are you gonna do after college?"

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "I don't know to be honest."

    scene e2s3-37 with dissolve
    fr "All my life I've had someone to tell me what to do."

    scene e2s3-35 with dissolve
    fr "If my dad doesn't put any pressure on me, I can probably do whatever I want."

    scene e2s3-26 with dissolve
    fr "I just hope that finishing this stupid degree is going to be the end of it."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "I see."
    mc "Would you go back to becoming a dancer?"

    scene e2s3-25 with dissolve
    hide e2s3-francesca_blink3
    fr "I don't think so."

    scene e2s3-37 with dissolve
    fr "I think that I've already blown my shot at that."

    scene e2s3-36 with dissolve
    fr "I'll try and do something that I actually enjoy."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Yeah, it's better to find the thing that brings {b}you{/b} enjoyment, not others."

    scene e2s3-37 with dissolve
    hide e2s3-francesca_blink3
    fr "What are you gonna do after college?"

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "To be honest, I haven't thought that far ahead."
    mc "I just got here."
    mc "I'll probably go down the marketing route."
    mc "That seems pretty interesting."

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "What about the fighting route?"

    scene e2s3-35 with dissolve
    fr "Is that really not possible anymore?"

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "I mean, it could be possible to have surgery which will allow me to get back into it..."
    mc "But the cost of it all is just too much for me to afford."

    scene e2s3-25 with dissolve
    hide e2s3-francesca_blink3
    fr "I'm sorry [mc]!"

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "It's alright."
    mc "I've already accepted it."

    scene e2s3-36 with dissolve
    hide e2s3-francesca_blink3
    fr "I honestly really hope to see you fight again some day."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    mc "Haha, me too!"
    mc "Hey, also, I saw you at yesterday's party."
    mc "You were talking to a girl there."
    mc "I wanted to go and say hi but you left."

    scene e2s3-35 with dissolve
    hide e2s3-francesca_blink3
    fr "Yeah, I wasn't planning on staying."

    scene e2s3-37 with dissolve
    fr "I just came to-"

    scene e2s3-38 with dissolve
    play sound phone_buzz
    pause

    scene e2s3-39 with dissolve
    pause

    scene e2s3-37 with dissolve
    hide e2s3-francesca_blink3
    fr "Sorry [mc]!"

    scene e2s3-35 with dissolve
    fr "It's my father... we need to hurry."

    scene e2s3-24 with dissolve
    show e2s3-francesca_blink3
    if affinity_spectrum <= 0:
        mc "Okay okay, let's go!"
    else:
        mc "Shit, let's go!"

    stop music fadeout 1.0
    scene e2s3-40 with dissolve
    hide e2s3-francesca_blink3
    pause

    play music hey_ruth
    scene e2s3-41 with dissolve
    pause

    scene e2s3-43 with dissolve
    fr "Okay, we're here."

    scene e2s3-44 with dissolve
    fr "This is where I live."

    scene e2s3-42 with dissolve
    show e2s3-francesca_blink5
    mc "Thank you [fr] for explaining all of this."
    mc "I really hope that you won't run away again."

    scene e2s3-45 with dissolve
    hide e2s3-francesca_blink5
    fr "Haha, no promises made!"

    scene e2s3-47 with dissolve
    fr "And I should be the one thanking you!"

    scene e2s3-46 with dissolve
    fr "I'm not used to doing things like this..."

    scene e2s3-48 with dissolve
    fr "I like you, [mc]."

    scene e2s3-47 with dissolve
    fr "You seem like a genuinely good guy."

    scene e2s3-42 with dissolve
    show e2s3-francesca_blink5
    menu:
        "Propose to go out":
            $ francesca_trust += 1
            $ e2s3_hangout = True
            call extrovert_affinity_check from _call_extrovert_affinity_check_40
            call color_check from _call_color_check_76
            mc "Hey, how about we do something fun tomorrow?"

            scene e2s3-50 with dissolve
            hide e2s3-francesca_blink5
            fr "Uh..."

            scene e2s3-49 with dissolve
            mc "Come on!"
            mc "Don't overthink it."
            mc "It will make you feel better."

            scene e2s3-47 with dissolve
            fr "You know what?"
            fr "You're right."

            scene e2s3-46 with dissolve
            fr "I should stop overthinking so much."

            scene e2s3-43 with dissolve
            fr "Alright [mc]!"

            scene e2s3-48 with dissolve
            fr "I'll go out with you!"

            scene e2s3-42 with dissolve
            show e2s3-francesca_blink5
            mc "Great."
            mc "Could you give me your phone number so we can get in touch?"

            scene e2s3-48 with dissolve
            hide e2s3-francesca_blink5
            fr "Sure."

            scene e2s3-47 with dissolve
            fr "Give me your phone."

            scene e2s3-42 with dissolve
            show e2s3-francesca_blink5
            mc "I'll call you so you can save my number."

            scene e2s3-46 with dissolve
            fr "Alright."

            if francesca_trust >= 1:
                scene e2s3-42 with dissolve
                show e2s3-francesca_blink5
                mc "Alright, so it's a date!"

                scene e2s3-46 with dissolve
                hide e2s3-francesca_blink5
                fr "Hehe..."

        "Don't propose":
            call introvert_affinity_check from _call_introvert_affinity_check_33
            call color_check from _call_color_check_77

            scene e2s3-42 with dissolve
            show e2s3-francesca_blink5
            mc "Thank you!"

            scene e2s3-47 with dissolve
            hide e2s3-francesca_blink5
            fr "Here's my number, we'll stay in touch."

    scene e2s3-51 with dissolve
    hide e2s3-francesca_blink5
    fr "I should hurry inside."

    scene e2s3-47 with dissolve
    fr "Well, see you around [mc]!"

    scene e2s3-42 with dissolve
    show e2s3-francesca_blink5
    mc "See you [fr]!"

    scene e2s3-52 with dissolve
    hide e2s3-francesca_blink5
    pause
    if e1s11_kiss_her == False:
        mc "*Damn it, I should probably have kissed her, right?*"

        scene e2s3-53 with dissolve
        mc "*I can't believe I made the same mistake again.*"
        mc "*I'm such an idiot!*"
    else:
        mc "*Ain't no way I'm making the same mistake again.*"

    scene e2s3-54 with dissolve
    pause

    jump e2s4
return
