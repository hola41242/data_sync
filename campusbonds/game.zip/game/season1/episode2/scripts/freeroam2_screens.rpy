
# Freeroam #2 Screens ##########################################################

screen e2f2_main():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    if e2f2_second_part == False:
        add "e2f2-main"
    else:
        if e2f2_tracy == 2 or e2f2_tracy_sex == True:
            add "e2f2-main_1"
        else:
            add "e2f2-main_2"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/main/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/main/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_hallway")

    if e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/main/kitchen_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/main/kitchen_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_kitchen")
    else:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/main/kitchen_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/main/kitchen_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_kitchen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_kitchen")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/main/sofa_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/main/sofa_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_sofa")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_sofa")

    if e2f2_tracy == 2:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/main/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/main/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_tracy")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_tracy")

    if persistent.mixed_gallery_6_unlocked == False and e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_6_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed6", True), Function(update_mixed_list)]

    # Clickables ###############################################################

screen e2f2_sofa():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    if e2f2_second_part == False:
        add "e2f2-sofa"
    else:
        add "e2f2-sofa_1"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/sofa/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/sofa/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_main")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/sofa/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/sofa/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_hallway")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/sofa/kitchen_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/sofa/kitchen_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_kitchen")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_kitchen")

    if persistent.sc_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/sofa/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/sofa/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_6_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett6", True), Function(update_scarlett_list)]

    if e2f2_money2 == False and e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/sofa/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/sofa/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e2f2_money2", True)]

screen e2f2_kitchen():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    if e2f2_second_part == False:
        add "e2f2-kitchen"
    else:
        add "e2f2-kitchen_1"

    if e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/hallway_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/hallway_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_hallway")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_hallway")
    else:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/hallway_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/hallway_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_hallway")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_hallway")

    if e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/main_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/main_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_main")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_main")
    else:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/main_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/main_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_main")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_main")

    if e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/sofa_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/sofa_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_sofa")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_sofa")
    else:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/sofa_2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/sofa_2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_sofa")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_sofa")

    # Clickables ###############################################################

    if e2f2_scarlett1 == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/scarlett_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/scarlett_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_scarlett1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_scarlett1")

    if e2f2_jon_jordan == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/jon_jordan_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/jon_jordan_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_jon_jordan")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_jon_jordan")

    if e2f2_tiffany_drink == 1 and e2f2_jon_jordan == True:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/jon_jordan_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/jon_jordan_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_tiffany_drink")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_tiffany_drink")

    if persistent.fr_gallery_6_unlocked == False and e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/kitchen/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/kitchen/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_6_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca6", True), Function(update_francesca_list)]

screen e2f2_hallway():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    if e2f2_tiffany_drink == 3 or e2f2_ken == 3 and e2f2_tiffany_refuse == True:
        if e2f2_second_part == False:
            add "e2f2-hallway_1"
        else:
            if e2f2_ken_roman == False:
                add "e2f2-hallway_2"
            else:
                add "e2f2-hallway_1"
    else:
        add "e2f2-hallway"

    if e2f2_tracy == 4 and e2f2_tracy_sex == False:
        pass
    else:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/bedroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/bedroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_bedroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_bedroom")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/hallway/kitchen_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/hallway/kitchen_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_kitchen")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_kitchen")

    if e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/sofa_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/sofa_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_sofa")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_sofa")
    else:
        if e2f2_ken_roman == False:
            imagebutton:
                idle im.Scale("season1/episode2/images/freeroam2/hallway/sofa_2_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode2/images/freeroam2/hallway/sofa_2_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e2f2_sofa")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e2f2_sofa")
        else:
            imagebutton:
                idle im.Scale("season1/episode2/images/freeroam2/hallway/sofa_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode2/images/freeroam2/hallway/sofa_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e2f2_sofa")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e2f2_sofa")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/hallway/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/hallway/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_main")

    if e2f2_tiffany_drink == 3 or e2f2_ken == 3 and e2f2_tiffany_refuse == True:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/bathroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/bathroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_bathroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_bathroom")

    # Clickables ###############################################################

    if e2f2_ken == 0 or e2f2_ken == 2:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_ken")

    if e2f2_tiffany_drink == 2 and e2f2_ken == 3:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/tiffany_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/tiffany_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_tiffany")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_tiffany")

    if e2f2_second_part == True and e2f2_ken_roman == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/ken_roman_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/ken_roman_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_ken_roman")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_ken_roman")

    # End ######################################################################

    if e2f2_second_part == True and e2f2_ken_roman == True:
        if affinity_spectrum > 0:
            if e2f2_tracy > 2:
                imagebutton:
                    idle im.Scale("season1/episode2/images/freeroam2/hallway/exit_idle.webp", 1920, 1080)
                    hover im.Scale("season1/episode2/images/freeroam2/hallway/exit_hover.webp", 1920, 1080)
                    focus_mask True
                    hovered SetVariable("screen_tooltip", "e2f2_end")
                    unhovered SetVariable("screen_tooltip", "")
                    action Jump ("e2f2_end")
        else:
            imagebutton:
                idle im.Scale("season1/episode2/images/freeroam2/hallway/exit_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode2/images/freeroam2/hallway/exit_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e2f2_end")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e2f2_end")

    if persistent.tr_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_6_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy6", True), Function(update_tracy_list)]

    if e2f2_money1 == False and e2f2_second_part == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/hallway/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/hallway/money_idle.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e2f2_money1", True)]

screen e2f2_bedroom():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    if e2f2_tracy == 3:
        add "e2f2-bedroom_1"
    else:
        add "e2f2-bedroom"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/bedroom/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/bedroom/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_hallway")

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/bedroom/drawer_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/bedroom/drawer_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_drawer")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_drawer")

    if e2f2_tracy == 3:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/bedroom/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/bedroom/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e2f2_tracy_sex")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e2f2_tracy_sex")

    if persistent.sd_gallery_6_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/bedroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/bedroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_6_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_6_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie6", True), Function(update_sadie_list)]

screen e2f2_drawer():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    add "e2f2-drawer"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/drawer/bedroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/drawer/bedroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_bedroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_bedroom")

    if persistent.cl_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/drawer/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/drawer/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_7_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo7", True), Function(update_cleo_list)]

    if persistent.mixed_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/drawer/magazine2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/drawer/magazine2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_7_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed7", True), Function(update_mixed_list)]

screen e2f2_bathroom():

    $ renpy.random.shuffle(e2f2_tracks)
    modal True

    add "e2f2-bathroom"

    imagebutton:
        idle im.Scale("season1/episode2/images/freeroam2/bathroom/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/freeroam2/bathroom/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2f2_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2f2_hallway")

    if persistent.sc_gallery_5_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/freeroam2/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/freeroam2/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_5_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_5_unlocked", True), SetVariable("persistent.e2f2_collected_p", persistent.e2f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett5", True), Function(update_scarlett_list)]
