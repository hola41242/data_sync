
# Scene 9 - Ruined party #######################################################

default e2s9_francesca_call = False

label e2s9:
    scene e2s9-63 with dissolve
    pause

    scene e2s9-64 with dissolve
    jon "I'll get that!"

    scene e2s9-65 with dissolve
    jon "Hey guys, look who got here!"

    scene e2s9-66 with dissolve
    jd "Sweet! More drinks are here."

    scene e2s9-67 with dissolve
    jon "Come on, go ahead and enter, the kitchen is right around the corner."

    scene e2s9-68 with dissolve
    pause

    scene e2s9-69 with dissolve
    pause

    scene e2s9-70 with dissolve
    pause

    scene e2s9-71 with dissolve
    unknown "Hey, what the fuck are you looking at?"

    scene e2s9-72 with dissolve
    pause

    scene e2s9-73 with dissolve
    unknown "Yeah shit head! I'm talking to you!"
    unknown "You should have been here way sooner."
    unknown "The drinks were finished a long time ago."

    scene e2s9-74 with dissolve
    unknown "What did you just call me?"

    scene e2s9-73 with dissolve
    unknown "Shit head!"

    scene e2s9-75 with dissolve
    unknown "I'll show you who's the shit head!"

    play music nerve_damage
    play sound punch
    scene e2s9-76 with vpunch
    pause

    play sound punch
    scene e2s9-77 with vpunch
    pause

    play sound punch
    scene e2s9-78 with vpunch
    pause

    scene e2s9-79 with dissolve
    no "No...!!"
    no "What are you doing?"

    scene e2s9-80 with dissolve
    no "You're ruining the feng shui of the house!"

    play sound wood_hit
    scene e2s9-81 with vpunch
    pause

    scene e2s9-82 with dissolve
    pause

    scene e2s9-83 with dissolve
    pause

    play sound glass_shatter
    scene e2s9-84 with vpunch
    pause

    scene e2s9-85 with dissolve
    no "Oh my God guys, come on!"
    no "Cut it out!"

    scene e2s9-86 with dissolve
    jon "Hey buddy, it looks like you're having a bit of trouble handling things."

    scene e2s9-87 with dissolve
    jon "What do you say if you joined our partying group?"

    scene e2s9-88 with dissolve
    jon "I've seen the mistakes of the party ever since I walked through that front door."

    scene e2s9-89 with dissolve
    no "What the fuck do you mean?"
    no "You organized this shit!"

    scene e2s9-88 with dissolve
    jon "Now, now..."
    jon "Let's not get aggressive."

    scene e2s9-90 with dissolve
    jon "A little vase broken here, a little window broken there..."
    jon "It's all fixable, don't worry."

    scene e2s9-89 with dissolve
    no "I'm tired of this party shit!"

    scene e2s9-91 with dissolve
    no "I want you all gone, right now!"
    no "Come on, everyone out, the party is over!"

    scene e2s9-90 with dissolve
    jon "Just think about my offer, alright?"

    scene e2s9-92 with dissolve
    jon "Come on guys, we're leaving."

    scene e2s9-93 with dissolve
    no "Stop this madness!"

    stop music fadeout 1.0
    scene e2s9-01 with wipeleft
    play music frannie
    pause

    scene e2s9-02 with dissolve
    ro "[no] is gonna be so mad tomorrow."

    scene e2s9-03 with dissolve
    jon "He'll get over it."
    jon "It's moments like these that he'll look back to and remember how much fun he actually had."
    jon "He's just not realizing it now."

    scene e2s9-04 with wipeleft
    pause

    scene e2s9-05 with dissolve
    mc "How come all the recent parties have some sort of bad ending to them?"

    scene e2s9-06 with dissolve
    jd "I don't know about that, [mc]..."
    jd "Bad endings, or whatever you like to call them, are actually what make parties interesting."

    scene e2s9-07 with dissolve
    jon "Yeah, we should have stayed and watched the whole thing."

    scene e2s9-08 with dissolve
    ro "Why didn't we?"

    scene e2s9-07 with dissolve
    jon "It's not our business."

    scene e2s9-09 with dissolve
    ke "I don't think [no] will do a party ever again."

    scene e2s9-10 with dissolve
    jon "Nah, he'll come around, don't you guys worry."

    scene e2s9-11 with dissolve
    ro "I hope so..."

    scene e2s9-12 with dissolve
    mc "Alright, I think I'm gonna go back to my dorm now."

    scene e2s9-13 with dissolve
    jon "You're going already?"

    scene e2s9-14 with dissolve
    mc "Yeah, I'm pretty tired."

    scene e2s9-15 with dissolve
    ke "Alright man."
    ke "Take care."

    scene e2s9-16 with dissolve
    jd "See you dude!"

    scene e2s9-17 with dissolve
    ro "Take care!"

    scene e2s9-18 with dissolve
    jon "Hey [mc]."
    jon "Tomorrow we've got things to do."

    scene e2s9-19 with dissolve
    jon "Try not to sleep too much."

    scene e2s9-20 with dissolve
    mc "Sure, as long as you don't enter my dorm through the window again."

    scene e2s9-21 with dissolve
    jd "Haha, what?"

    scene e2s9-22 with dissolve
    jon "Long story..."

    scene e2s9-18 with dissolve
    jon "Alright [mc], see you tomorrow then."

    scene e2s9-20 with dissolve
    mc "Bye guys!"

    stop music fadeout 2.0
    scene e2s9-23 with dissolve
    pause

    scene e2s9-24 with wipeleft
    play music easy_cheesy
    pause

    scene e2s9-25 with dissolve
    mc "*Alright, let's see, where did I put my dorm key?*"

    scene e2s9-26 with dissolve
    pause

    scene e2s9-27 with dissolve
    mc "*Where the fuck are those keys?*"

    scene e2s9-26 with dissolve
    pause

    scene e2s9-25 with dissolve
    mc "*Don't tell me I lost them... fuck!*"

    scene e2s9-28 with dissolve
    mc "*I can't believe this.*"
    mc "*[nt]'s also gone for the weekend...*"
    mc "*What am I gonna do now?*"

    scene e2s9-29 with dissolve
    $ GameRunning = True
    while GameRunning:
        menu:
            "Francesca" if francesca_trust >= 1 and e2s9_francesca_call == False:
                $ e2s9_francesca_call = True
                mc "*Well... I don't know if this is going to work...*"
                mc "*But I guess it's worth a shot.*"

                scene e2s9-30 with dissolve
                mc "*Come on... answer please!*"

                scene e2s9-32 with dissolve
                fr "[mc]?"

                scene e2s9-31 with dissolve
                mc "Thank God!"
                mc "Hello [fr]."

                scene e2s9-35 with dissolve
                fr "What happened?"
                fr "Why are you calling me this late at night?"

                scene e2s9-34 with dissolve
                show e2s10-francesca_blink1
                mc "Well... funny situation I got myself into..."
                menu:
                    "Tell her the truth":
                        $ e2s9_francesca_lie = False

                        scene e2s9-37 with dissolve
                        hide e2s10-francesca_blink1
                        if e2s3_hangout == True:
                            mc "I'm sorry [fr]!"
                            mc "I couldn't get to our date because I was busy going to a party..."

                            scene e2s9-36 with dissolve
                            mc "I totally forgot about it."

                            scene e2s9-37 with dissolve
                            mc "And I didn't want to let my friends down."
                            mc "And now, as I was walking back home, I checked my pockets only to find that I've lost my dorm key."

                            scene e2s9-31 with dissolve
                        else:
                            mc "So, I went to a party..."
                            mc "And it didn't end all that well so I decided to walk back home."

                            scene e2s9-31 with dissolve
                            mc "But, as I was walking back, I checked my pockets and noticed that I've lost my dorm key."

                        mc "My dorm mate is also gone for the weekend."
                        mc "So, I have no way of getting inside my dorm."

                        scene e2s9-36 with dissolve
                        mc "I was thinking that maybe, just maybe, you could let me spend the night at your place..."
                        mc "I know, I know you might be mad!"

                        scene e2s9-37 with dissolve
                        mc "But I really don't have anywhere else to go!"

                        scene e2s9-31 with dissolve
                        mc "You were the first person that came to mind."

                        if e2s3_hangout == True:
                            scene e2s9-38 with dissolve
                            fr "Well, can't your friends help you?"
                            fr "You canceled our date so that you won't let them down."
                            fr "But in the process you've let me down."

                            scene e2s9-34 with dissolve
                            show e2s10-francesca_blink1
                            mc "Look [fr], I'm sorry, okay?"

                            scene e2s9-39 with dissolve
                            hide e2s10-francesca_blink1
                            if affinity_spectrum <= 0:
                                mc "I was stupid, I shouldn't have gone to that party."
                                mc "Or at least I shouldn't have organized 2 things at the same time."
                                mc "I don't even like parties all that much."
                            else:
                                $ francesca_trust -= 1
                                mc "I shouldn't have organized 2 things at the same time."

                    "Lie to her":
                        $ e2s9_francesca_lie = True

                        scene e2s9-37 with dissolve
                        hide e2s10-francesca_blink1
                        mc "I got locked out of my dorm!"
                        mc "And unfortunately, I don't have my key with me."
                        mc "My dorm mate is also gone for the weekend."

                        scene e2s9-31 with dissolve
                        if affinity_spectrum > 0:
                            mc "So I'm standing here butt naked outside my dorm with no way of getting in!"
                        else:
                            mc "So now I'm standing outside my dorm with no way of getting in!"

                        scene e2s9-40 with dissolve
                        fr "Uhh... alright?"

                        scene e2s9-34 with dissolve
                        show e2s10-francesca_blink1
                        mc "Yeah..."

                        scene e2s9-36 with dissolve
                        hide e2s10-francesca_blink1
                        mc "And I was thinking if you could maybe let me spend the night at your place?"
                        mc "I would be forever grateful."

                        scene e2s9-41 with dissolve
                        fr "Uh... damn [mc]..."
                        fr "I'm speechless..."

                        scene e2s9-34 with dissolve
                        show e2s10-francesca_blink1
                        mc "I know that we don't know each other all that well."

                        scene e2s9-31 with dissolve
                        hide e2s10-francesca_blink1
                        mc "And we didn't even get to hang out."
                        mc "But I don't have anywhere else to go and the only person that came to mind was you."

                if francesca_trust >= 2:
                    mc "Please [fr], just this once!"

                    scene e2s9-41 with dissolve
                    fr "[mc], it's not like I wouldn't want to..."

                    scene e2s9-40 with dissolve
                    fr "But I don't want to have problems with my dad..."
                    fr "Otherwise, I would gladly let you sleep here."

                    scene e2s9-34 with dissolve
                    show e2s10-francesca_blink1
                    mc "Are you sure there's nothing you can do?"

                    scene e2s9-44 with dissolve
                    hide e2s10-francesca_blink1
                    fr "Look... my dad said he's gonna be out late to work."

                    scene e2s9-40 with dissolve
                    fr "Most times he sleeps at either hotels or at random women's places."

                    scene e2s9-41 with dissolve
                    fr "If we're lucky enough, he won't be coming home tonight."

                    scene e2s9-45 with dissolve
                    mc "So this means that I can sleep the night?"

                    scene e2s9-44 with dissolve
                    fr "Yeah... you can."

                    scene e2s9-34 with dissolve
                    show e2s10-francesca_blink1
                    mc "Oh my God, thank you so much [fr]!"

                    scene e2s9-42 with dissolve
                    hide e2s10-francesca_blink1
                    mc "I'm gonna be forever grateful to you!"

                    scene e2s9-41 with dissolve
                    fr "Text me when you get here, alright?"

                    scene e2s9-34 with dissolve
                    show e2s10-francesca_blink1
                    mc "Okay!"

                    scene e2s9-40 with dissolve
                    hide e2s10-francesca_blink1
                    fr "Do you remember my address or do you want me to text it to you?"

                    scene e2s9-37 with dissolve
                    if affinity_spectrum < 0:
                        mc "Can you text it to me?"

                        scene e2s9-33 with dissolve
                        fr "Alright, here it is."

                        scene e2s9-37 with dissolve
                        mc "Thanks!"

                        scene e2s9-33 with dissolve
                        fr "Be careful!"
                    else:
                        mc "I remember it."
                        mc "I'll be there in 15 minutes."

                        scene e2s9-33 with dissolve
                        fr "Alright, be careful!"

                    scene e2s9-43 with dissolve
                    pause

                    scene e2s9-46 with dissolve
                    pause

                    scene e2s9-47 with dissolve
                    pause

                    scene e2s9-48 with dissolve
                    pause

                    $ e2s10_francesca = True

                    jump e2s10
                else:
                    mc "Can you help me just this once please?"

                    scene e2s9-33 with dissolve
                    fr "I'm sorry [mc], as much as I want to help you, I can't."
                    fr "I don't want any more problems with my dad."

                    scene e2s9-41 with dissolve
                    fr "I really can't help you..."
                    fr "You've got to search for another place to stay tonight."

                    scene e2s9-34 with dissolve
                    show e2s10-francesca_blink1
                    mc "Are you sure there's nothing you can do?"

                    scene e2s9-40 with dissolve
                    hide e2s10-francesca_blink1
                    fr "Unfortunately, yeah..."

                    scene e2s9-32 with dissolve
                    fr "He's gonna be home any minute now and if he sees you here, we'll both get in trouble."

                    scene e2s9-42 with dissolve
                    mc "I understand."
                    mc "Thanks anyways [fr]!"
                    mc "Also, sorry if I woke you up."

                    scene e2s9-40 with dissolve
                    fr "It's alright, don't worry."
                    fr "I hope that you can find a place, [mc]."

                    scene e2s9-34 with dissolve
                    show e2s10-francesca_blink1
                    mc "Yeah, me too."
                    mc "Bye [fr]!"

                    scene e2s9-35 with dissolve
                    hide e2s10-francesca_blink1
                    fr "Goodbye [mc]!"

                    scene e2s9-43 with dissolve
                    pause

                    scene e2s9-29 with dissolve
                    mc "*Well... at least I tried.*"
                    mc "*Who else should I call?*"
            "Sadie" if sadie_trust > 4 and e2s6_sadie_romance == True or sadie_trust > 3 and e2s6_sadie_fwb == True:
                mc "*Hmm... how am I even going to contact her?*"
                mc "*We've talked so much and we didn't even exchange contacts.*"
                mc "*I'm gonna talk to [jon] and see if he can help me.*"

                scene e2s9-30 with dissolve
                pause

                scene e2s9-31 with dissolve
                mc "Hey [jon]!"

                scene e2s9-55 with dissolve
                jon "[mc], what's up?"

                scene e2s9-57 with dissolve
                jon "Got lost on the way home?"

                scene e2s9-56 with dissolve
                show e2s10-jon_blink1
                mc "Haha, no!"

                scene e2s9-45 with dissolve
                hide e2s10-jon_blink1
                mc "I just need [sd]'s phone number if you have it."

                scene e2s9-33 with dissolve
                jon "Wow, I know I said that you should talk to her..."

                scene e2s9-55 with dissolve
                jon "But do you think this is the best time to call her?"

                scene e2s9-37 with dissolve
                mc "Shut up dude and just give me her number."

                scene e2s9-58 with dissolve
                jon "Alright, alright..."

                scene e2s9-59 with dissolve
                jon "Here, I'm gonna text it to you."

                scene e2s9-31 with dissolve
                mc "Thanks, you're a life saver!"

                scene e2s9-55 with dissolve
                jon "More like a dick saver!"

                scene e2s9-60 with dissolve
                jon "Wait, that didn't sound right..."

                scene e2s9-45 with dissolve
                mc "Bye [jon]!"

                scene e2s9-29 with dissolve
                pause

                scene e2s9-30 with dissolve
                mc "*Alright, let's see if this works.*"

                scene e2s9-49 with dissolve
                pause

                if persistent.disable_nsfw == True:
                    scene e2s9-50 with dissolve
                    play sound phone_buzz
                    pause

                    scene e2s9-31 with dissolve
                    mc "Hey [sd]!"
                    mc "Uhh, what's up?"

                    scene e2s9-52 with dissolve
                    sd "Who's this?"

                    scene e2s9-51 with dissolve
                    show e2s10-sadie_blink1
                    mc "It's me, [mc]."

                    scene e2s9-37 with dissolve
                    hide e2s10-sadie_blink1
                    mc "I got your phone number from [jon]."

                    scene e2s9-53 with dissolve
                    sd "Oh, [mc]!"
                    sd "What happened?"
                    sd "Why are you calling me this late at night?"

                    scene e2s9-37 with dissolve
                    mc "So... you know the party we went to, right?"

                    scene e2s9-54 with dissolve
                    sd "The one where [sp] somehow coincidentally showed up out of nowhere?"
                    sd "How could I forget it?"

                    scene e2s9-36 with dissolve
                    mc "Yeah... that one."

                    scene e2s9-54 with dissolve
                    sd "What about it?"

                    scene e2s9-51 with dissolve
                    show e2s10-sadie_blink1
                    mc "So... long story short..."

                    scene e2s9-37 with dissolve
                    hide e2s10-sadie_blink1
                    mc "Let's just say that things kind of got heated after you left."

                    scene e2s9-31 with dissolve
                    mc "And I've lost my dorm keys."
                    mc "And my dorm mate is gone for the weekend."
                    mc "And I'd rather sleep on the streets than sleep one more night on [jon]'s couch."

                    scene e2s9-45 with dissolve
                    if affinity_spectrum > 0:
                        mc "And... that's where you come in clutch!"
                    else:
                        mc "That's where you could help me."

                    scene e2s9-33 with dissolve
                    sd "Let me guess, you want to crash at my place."

                    scene e2s9-45 with dissolve
                    if affinity_spectrum > 0:
                        mc "Exactly!!"

                        scene e2s9-39 with dissolve
                        mc "I know you're the only one that gets me right now, [sd]!"

                        scene e2s9-36 with dissolve
                        mc "So... could you help me just this time, please?"
                        mc "I'd be forever grateful to you."

                        scene e2s9-33 with dissolve
                        sd "Alright, alright..."
                    else:
                        mc "Yeah, pretty much!"

                        scene e2s9-39 with dissolve
                        mc "I know that things seem a bit awkward between us..."
                        mc "But I'd be forever grateful if you could help me this once!"

                        scene e2s9-33 with dissolve
                        sd "Okay, okay..."

                    scene e2s9-53 with dissolve
                    sd "You can sleep the night at my place."

                    scene e2s9-42 with dissolve
                    if affinity_spectrum > 0:
                        mc "Oh my God, thank you so much!"

                        scene e2s9-51 with dissolve
                        show e2s10-sadie_blink1
                        mc "I'll be there in a bit."

                        scene e2s9-53 with dissolve
                        sd "Wait dude, do you even know where I live?"

                        scene e2s9-31 with dissolve
                        mc "Uh, no?"

                        scene e2s9-32 with dissolve
                        sd "Exactly, let me text you my address."

                        scene e2s9-37 with dissolve
                        mc "Alright, talk to you later then."

                        scene e2s9-52 with dissolve
                        sd "Bye!"
                    else:
                        mc "Thanks a lot [sd]!"

                        scene e2s9-51 with dissolve
                        show e2s10-sadie_blink1
                        mc "I knew I could count on you!"

                        scene e2s9-32 with dissolve
                        hide e2s10-sadie_blink1
                        sd "Here, let me text you my address."

                        scene e2s9-37 with dissolve
                        mc "Alright, talk to you when I arrive there."

                        scene e2s9-52 with dissolve
                        sd "Okay, bye!"
                else:
                    if persistent.type_nsfw == False:
                        scene e2s9-50_cen with dissolve
                        play sound phone_buzz
                        pause

                        scene e2s9-31 with dissolve
                        mc "Hey [sd]!"
                        mc "Uhh, what's up?"

                        scene e2s9-52_cen with dissolve
                        sd "Who's this?"

                        scene e2s9-51_cen with dissolve
                        show e2s10-sadie_blink1
                        mc "It's me, [mc]."

                        scene e2s9-37 with dissolve
                        hide e2s10-sadie_blink1
                        mc "I got your phone number from [jon]."

                        scene e2s9-53_cen with dissolve
                        sd "Oh, [mc]!"
                        sd "What happened?"
                        sd "Why are you calling me this late at night?"

                        scene e2s9-37 with dissolve
                        mc "So... you know the party we went to, right?"

                        scene e2s9-54_cen with dissolve
                        sd "The one where [sp] somehow coincidentally showed up out of nowhere?"
                        sd "How could I forget it?"

                        scene e2s9-36 with dissolve
                        mc "Yeah... that one."

                        scene e2s9-54_cen with dissolve
                        sd "What about it?"

                        scene e2s9-51_cen with dissolve
                        show e2s10-sadie_blink1
                        mc "So... long story short..."

                        scene e2s9-37 with dissolve
                        hide e2s10-sadie_blink1
                        mc "Let's just say that things kind of got heated after you left."

                        scene e2s9-31 with dissolve
                        mc "And I've lost my dorm keys."
                        mc "And my dorm mate is gone for the weekend."
                        mc "And I'd rather sleep on the streets than sleep one more night on [jon]'s couch."

                        scene e2s9-45 with dissolve
                        if affinity_spectrum > 0:
                            mc "And... that's where you come in clutch!"
                        else:
                            mc "That's where you could help me."

                        scene e2s9-33 with dissolve
                        sd "Let me guess, you want to crash at my place."

                        scene e2s9-45 with dissolve
                        if affinity_spectrum > 0:
                            mc "Exactly!!"

                            scene e2s9-39 with dissolve
                            mc "I know you're the only one that gets me right now, [sd]!"

                            scene e2s9-36 with dissolve
                            mc "So... could you help me just this time, please?"
                            mc "I'd be forever grateful to you."

                            scene e2s9-33 with dissolve
                            sd "Alright, alright..."
                        else:
                            mc "Yeah, pretty much!"

                            scene e2s9-39 with dissolve
                            mc "I know that things seem a bit awkward between us..."
                            mc "But I'd be forever grateful if you could help me this once!"

                            scene e2s9-33 with dissolve
                            sd "Okay, okay..."

                        scene e2s9-53_cen with dissolve
                        sd "You can sleep the night at my place."

                        scene e2s9-42 with dissolve
                        if affinity_spectrum > 0:
                            mc "Oh my God, thank you so much!"

                            scene e2s9-51_cen with dissolve
                            show e2s10-sadie_blink1
                            mc "I'll be there in a bit."

                            scene e2s9-53_cen with dissolve
                            sd "Wait dude, do you even know where I live?"

                            scene e2s9-31 with dissolve
                            mc "Uh, no?"

                            scene e2s9-32 with dissolve
                            sd "Exactly, let me text you my address."

                            scene e2s9-37 with dissolve
                            mc "Alright, talk to you later then."

                            scene e2s9-52_cen with dissolve
                            sd "Bye!"
                        else:
                            mc "Thanks a lot [sd]!"

                            scene e2s9-51_cen with dissolve
                            show e2s10-sadie_blink1
                            mc "I knew I could count on you!"

                            scene e2s9-32 with dissolve
                            hide e2s10-sadie_blink1
                            sd "Here, let me text you my address."

                            scene e2s9-37 with dissolve
                            mc "Alright, talk to you when I arrive there."

                            scene e2s9-52_cen with dissolve
                            sd "Okay, bye!"
                    else:
                        scene e2s9-31 with dissolve
                        mc "Hey [sd]!"
                        mc "Uhh, what's up?"

                        scene e2s9-32 with dissolve
                        sd "Who's this?"

                        scene e2s9-31 with dissolve
                        mc "It's me, [mc]."

                        scene e2s9-37 with dissolve
                        mc "I got your phone number from [jon]."

                        scene e2s9-33 with dissolve
                        sd "Oh, [mc]!"
                        sd "What happened?"
                        sd "Why are you calling me this late at night?"

                        scene e2s9-37 with dissolve
                        mc "So... you know the party we went to, right?"

                        scene e2s9-33 with dissolve
                        sd "The one where [sp] somehow coincidentally showed up out of nowhere?"
                        sd "How could I forget it?"

                        scene e2s9-36 with dissolve
                        mc "Yeah... that one."

                        scene e2s9-33 with dissolve
                        sd "What about it?"

                        scene e2s9-31 with dissolve
                        mc "So... long story short..."

                        scene e2s9-37 with dissolve
                        mc "Let's just say that things kind of got heated after you left."

                        scene e2s9-31 with dissolve
                        mc "And I've lost my dorm keys."
                        mc "And my dorm mate is gone for the weekend."
                        mc "And I'd rather sleep on the streets than sleep one more night on [jon]'s couch."

                        scene e2s9-45 with dissolve
                        if affinity_spectrum > 0:
                            mc "And... that's where you come in clutch!"
                        else:
                            mc "That's where you could help me."

                        scene e2s9-33 with dissolve
                        sd "Let me guess, you want to crash at my place."

                        scene e2s9-45 with dissolve
                        if affinity_spectrum > 0:
                            mc "Exactly!!"

                            scene e2s9-39 with dissolve
                            mc "I know you're the only one that gets me right now, [sd]!"

                            scene e2s9-36 with dissolve
                            mc "So... could you help me just this time, please?"
                            mc "I'd be forever grateful to you."

                            scene e2s9-33 with dissolve
                            sd "Alright, alright..."
                        else:
                            mc "Yeah, pretty much!"

                            scene e2s9-39 with dissolve
                            mc "I know that things seem a bit awkward between us..."
                            mc "But I'd be forever grateful if you could help me this once!"

                            scene e2s9-33 with dissolve
                            sd "Okay, okay..."

                        scene e2s9-33 with dissolve
                        sd "You can sleep the night at my place."

                        scene e2s9-42 with dissolve
                        if affinity_spectrum > 0:
                            mc "Oh my God, thank you so much!"

                            scene e2s9-31 with dissolve
                            mc "I'll be there in a bit."

                            scene e2s9-32 with dissolve
                            sd "Wait dude, do you even know where I live?"

                            scene e2s9-31 with dissolve
                            mc "Uh, no?"

                            scene e2s9-32 with dissolve
                            sd "Exactly, let me text you my address."

                            scene e2s9-37 with dissolve
                            mc "Alright, talk to you later then."

                            scene e2s9-33 with dissolve
                            sd "Bye!"
                        else:
                            mc "Thanks a lot [sd]!"

                            scene e2s9-31 with dissolve
                            mc "I knew I could count on you!"

                            scene e2s9-32 with dissolve
                            sd "Here, let me text you my address."

                            scene e2s9-37 with dissolve
                            mc "Alright, talk to you when I arrive there."

                            scene e2s9-33 with dissolve
                            sd "Okay, bye!"

                scene e2s9-29 with dissolve
                pause

                scene e2s9-48 with dissolve
                pause

                $ e2s10_sadie = True

                jump e2s10
            "Jon":
                mc "*Well... looks like there's no other option.*"

                scene e2s9-30 with dissolve
                pause

                scene e2s9-31 with dissolve
                mc "Hey [jon]!"

                scene e2s9-55 with dissolve
                jon "[mc], what's up?"

                scene e2s9-57 with dissolve
                jon "Got lost on the way home?"

                scene e2s9-56 with dissolve
                show e2s10-jon_blink1
                mc "That's the reason I'm calling you..."

                scene e2s9-31 with dissolve
                hide e2s10-jon_blink1
                mc "I think I lost my dorm keys back at the party."

                scene e2s9-33 with dissolve
                jon "Oh shit, really?"

                scene e2s9-37 with dissolve
                mc "Yeah..."

                scene e2s9-58 with dissolve
                jon "Do you wanna go back and search for them?"

                scene e2s9-37 with dissolve
                mc "I don't think [no]'s gonna be too eager to let us in again."

                scene e2s9-60 with dissolve
                jon "You're right."

                scene e2s9-58 with dissolve
                jon "Do you have anything of value in your dorm room?"

                scene e2s9-42 with dissolve
                mc "Nah, not really."

                scene e2s9-56 with dissolve
                show e2s10-jon_blink1
                mc "Just a bunch of clothes and books from college."

                scene e2s9-58 with dissolve
                hide e2s10-jon_blink1
                jon "I see, that's good!"

                scene e2s9-61 with dissolve
                jon "Well, me and the guys are out drinking."

                scene e2s9-55 with dissolve
                jon "Do you wanna join us?"

                scene e2s9-56 with dissolve
                show e2s10-jon_blink1
                if affinity_spectrum < 0:
                    mc "What other choice do I have?"

                    scene e2s9-32 with dissolve
                    hide e2s10-jon_blink1
                    jon "Hey, fuck you!"

                    scene e2s9-58 with dissolve
                    jon "Get your ass here and stop whining like a bitch."
                    jon "It's not like you have any better alternative."

                    scene e2s9-45 with dissolve
                    mc "Alright, alright, where can I find you?"
                else:
                    mc "Hell yeah!"
                    mc "Count me in!"

                    scene e2s9-45 with dissolve
                    mc "Where can I find you?"

                scene e2s9-55 with dissolve
                jon "I'm gonna text you the address now."

                scene e2s9-62 with dissolve
                mc "After this, do you think I could sleep at your place?"

                scene e2s9-33 with dissolve
                jon "Of course, [mc]!"

                scene e2s9-55 with dissolve
                jon "I won't let you sleep on the streets."

                scene e2s9-56 with dissolve
                show e2s10-jon_blink1
                mc "Thanks bro!"

                scene e2s9-57 with dissolve
                hide e2s10-jon_blink1
                jon "Don't mention it."

                scene e2s9-33 with dissolve
                jon "See you here, [mc]!"

                scene e2s9-45 with dissolve
                mc "Alright [jon], thanks!"

                scene e2s9-32 with dissolve
                pause

                scene e2s9-29 with dissolve
                pause

                scene e2s9-48 with dissolve
                pause

                $ e2s10_jon = True

                jump e2s10
return
