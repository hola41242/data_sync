
# Scene 13 - Getting ready #####################################################

label e2s13:
    scene black with Dissolve(2.0)

    scene e2s13-01 with Dissolve(2.0)
    play sound knock_knock
    pause

    play sound door_open
    scene e2s13-02 with dissolve
    play music aces_high
    jon "Hey bro, what's up?"

    scene e2s13-03 with dissolve
    show e2s13-jon_blink1
    if affinity_spectrum > 0:
        mc "What the hell bro, are you getting married?"
    else:
        mc "Where are you going?"

    scene e2s13-04 with dissolve
    hide e2s13-jon_blink1
    jon "What do you mean?"

    scene e2s13-03 with dissolve
    show e2s13-jon_blink1
    mc "Why are you dressed like that?"

    scene e2s13-05 with dissolve
    hide e2s13-jon_blink1
    jon "The better question here is, why are {b}you{/b} dressed like this?"

    scene e2s13-03 with dissolve
    show e2s13-jon_blink1
    mc "Dude, did we really just ask 5 questions in a row?"

    scene e2s13-04 with dissolve
    hide e2s13-jon_blink1
    jon "That's six questions in a row now."

    scene e2s13-03 with dissolve
    show e2s13-jon_blink1
    mc "Haha!"
    mc "No, but for real, what's up with the suit?"

    scene e2s13-06 with dissolve
    hide e2s13-jon_blink1
    jon "It's for [ke]'s party."

    play sound door_close
    scene e2s13-07 with dissolve
    mc "Is this a dress code or what?"

    scene e2s13-08 with dissolve
    jon "No bro, damn."
    jon "Do you really not know that he's having one of those rich parties?"

    scene e2s13-09 with dissolve
    mc "Wait, he's rich?"
    mc "How the hell am I supposed to know all of this?"

    scene e2s13-08 with dissolve
    jon "Of course he is."

    scene e2s13-10 with dissolve
    mc "I've barely known him for a week now."

    scene e2s13-11 with dissolve
    jon "I guess you're right."

    scene e2s13-12 with dissolve
    mc "What am I gonna do now?"
    mc "I don't have any suits with me."

    scene e2s13-13 with dissolve
    jon "Bro, don't worry... I got you!"

    scene e2s13-14 with dissolve
    mc "Okay, that's good."

    scene e2s13-15 with dissolve
    jon "So, what did you get him?"

    scene e2s13-16 with dissolve
    if affinity_spectrum > 0:
        mc "I got him a bottle of booze."

        scene e2s13-17 with dissolve
        jon "Dude... you got him a bottle of booze as well?"

        play sound punch
        scene e2s13-18 with vpunch
        jon "My man!"

        scene e2s13-15 with dissolve
    else:
        mc "I got him a t-shirt."

        scene e2s13-15 with dissolve
        jon "Alright, I think he will like it."

    jon "Just sit comfortably on the couch, I'll go and get the suit."

    scene e2s13-19 with dissolve
    jon "Not too comfortably though, I wouldn't want you falling asleep there."

    scene e2s13-20 with dissolve
    mc "Oh, don't worry."
    mc "I can get as comfortable as I want, I won't be able to fall asleep on this couch."

    scene e2s13-21 with dissolve
    jon "Haha!"

    play sound door_close
    scene e2s13-22 with dissolve
    pause

    scene e2s13-23 with dissolve
    pause

    play sound door_close
    scene e2s13-24 with dissolve
    jon "Here, try this one."

    scene e2s13-25 with dissolve
    mc "It looks a bit small."

    scene e2s13-26 with dissolve
    jon "It's not the time to pick and choose."
    jon "Last time I checked, you didn't have any alternatives."

    scene e2s13-27 with dissolve
    mc "Alright, alright, let me get changed."

    scene e2s13-28 with dissolve
    pause

    play sound door_close
    scene e2s13-29 with dissolve
    pause

    scene e2s13-30 with dissolve
    pause

    play sound door_close
    scene e2s13-31 with dissolve
    pause

    scene e2s13-32 with dissolve
    jon "Haha, dude, you weren't lying when you said that it's a bit small."

    scene e2s13-33 with dissolve
    mc "Oh, just shut up!"

    scene e2s13-32 with dissolve
    jon "Haha!"

    scene e2s13-34 with dissolve
    jon "I mean, it's not that bad honestly."
    jon "If you don't raise your arms up you'll be fine."

    scene e2s13-35 with dissolve
    mc "Oh, real nice what can I say..."

    scene e2s13-36 with dissolve
    jon "Alright, well... if you're ready we can get going."

    scene e2s13-37 with dissolve
    mc "Wait, do you have any cologne?"

    scene e2s13-38 with dissolve
    jon "Dude, you didn't come prepared at all."

    scene e2s13-39 with dissolve
    mc "I was busy, alright?"
    mc "I didn't have the time to get suits and smells and whatnot."

    scene e2s13-40 with dissolve
    jon "I've got some in the bathroom, you can use one of those."

    scene e2s13-41 with dissolve
    pause

    play sound door_close
    scene e2s13-42 with dissolve
    pause

    scene e2s13-43 with dissolve
    pause

    play sound door_close
    scene e2s13-44 with dissolve
    mc "Done, I'm ready to go."

    scene e2s13-45 with dissolve
    jon "Good, let's go!"

    play sound door_open
    scene e2s13-46 with dissolve
    pause

    jump e2s14
return
