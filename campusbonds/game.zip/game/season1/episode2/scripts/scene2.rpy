
# Scene 2 - Frog fight #########################################################

label e2s2:

    play music iwnlylmd
    scene e2s2-01 with wipeleft
    pause

    scene e2s2-02 with dissolve
    pause

    scene e2s2-03 with dissolve
    mc "Hi guys!"
    mc "What are you... doing?"

    scene e2s2-04 with dissolve
    jd "Hey [mc]!"
    jd "Come here."

    scene e2s2-05 with dissolve
    mc "You're watching frogs fight?"

    scene e2s2-06 with dissolve
    ke "Dude, shut up."
    ke "I placed a bet on the blue one."

    scene e2s2-07 with dissolve
    ro "Haha, I told you it's not a good idea!"

    scene e2s2-08 with dissolve
    ro "It looks like the blue frog is getting its ass kicked."

    scene e2s2-09 with dissolve
    show e2s2_roman_blink1
    mc "Did you also place a bet?"

    scene e2s2-10 with dissolve
    hide e2s2_roman_blink1
    ro "Yeah, on the red one."

    scene e2s2-11 with dissolve
    ro "Don't tell him I told you this but I actually heard a rumor about today's frog fight."

    scene e2s2-12 with dissolve
    ro "The red frog was rumored to have an 80 percent chance of winning that fight."

    scene e2s2-13 with dissolve
    "*THE BLUE FROG IS ELIMINATED!*"

    play sound weights
    scene e2s2-14 with vpunch
    ke "FUCK THIS SHIT!"

    scene e2s2-15 with dissolve
    ro "Told you so!"

    scene e2s2-16 with dissolve
    mc "Anyways, where's [jon]?"

    scene e2s2-17 with dissolve
    jd "He was at Eddy's last time we saw him."

    scene e2s2-18 with dissolve
    ro "Yeah, maybe he's still there."

    scene e2s2-19 with dissolve
    mc "Alright, thanks guys!"
    mc "Good luck with... whatever you are doing."

    scene e2s2-20 with dissolve
    pause

    scene e2s2-21 with dissolve
    pause

    scene e2s2-22 with dissolve
    play sound phone_buzz
    pause

    scene e2s2-23 with dissolve
    jon "Yoo, [mc]!"
    jon "What's up my dude?"

    scene e2s2-24 with dissolve
    mc "Hey [jon]!"
    mc "I was looking for you."

    scene e2s2-25 with dissolve
    jon "Great, me too!"
    jon "Listen, I need a favor."
    jon "I don't think I will be able to come to college today."
    jon "Can you take a few notes for me and give them to me tomorrow?"
    jon "I would be forever grateful to you my friend."

    scene e2s2-26 with dissolve
    mc "Alright bro, don't worry."

    scene e2s2-27 with dissolve
    jon "Thanks!"
    jon "I'll send you my schedule for today."
    jon "If we don't have shared classes, you can go to the library and take notes from there."

    scene e2s2-28 with dissolve
    mc "Can't you do that yourself on another day?"

    scene e2s2-29 with dissolve
    jon "Huh? Sorry, I'm in a tunnel, I can't hear you."

    scene e2s2-30 with dissolve
    mc "Ha ha, very funny."

    scene e2s2-31 with dissolve
    jon "No, but for real, I'll be grateful to you if you could do that."

    scene e2s2-32 with dissolve
    mc "Alright, alright, don't worry."

    scene e2s2-33 with dissolve
    jon "Thanks a lot!"
    jon "So, why were you looking for me?"

    scene e2s2-34 with dissolve
    mc "Just wanted to make sure everything is alright."

    scene e2s2-35 with dissolve
    jon "Except for the fact that everything is destroyed..."
    jon "Yeah, everything's fine."
    jon "Oh, and also, I want to talk to you about something."

    scene e2s2-36 with dissolve
    mc "What's up?"

    scene e2s2-37 with dissolve
    jon "I can't speak to you about this over the phone."
    jon "Meet me tonight at my place and we will talk."

    scene e2s2-38 with dissolve
    mc "I'm afraid I can't come tonight."
    mc "Are you free tomorrow?"

    scene e2s2-39 with dissolve
    jon "Why? You got a date?"

    scene e2s2-40 with dissolve
    mc "Yeah... actually I do."

    scene e2s2-41 with dissolve
    jon "I'm so proud of you!"
    jon "My eyes are tearing..."

    scene e2s2-42 with dissolve
    mc "Shut up, it's not that big of a deal."

    scene e2s2-43 with dissolve
    jon "Guess it's not that 'big' yet."

    if affinity_spectrum > 0:
        scene e2s2-45 with dissolve
        mc "Haha, that one was good!"
    else:
        scene e2s2-44 with dissolve
        mc "Oh, just shut up."

    scene e2s2-46 with dissolve
    jon "Haha!"
    jon "Alright then, we'll talk tomorrow."

    scene e2s2-47 with dissolve
    mc "Okay, see you!"

    scene e2s2-48 with dissolve
    pause

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    jump e2f1
return
