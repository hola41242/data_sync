
# Freeroam 1 ###################################################################

# Variables #

default e2f1_evelyn = False
default e2f1_eve_name = False

default e2f1_ken = False

default e2f1_alice = False
default e2f1_alice_asap = False

default e2f1_question = 0

default e2f1_books = 0
default e2f1_history = False
default e2f1_english = False
default e2f1_math = False
default e2f1_geography = False
default e2f1_phy_sci = False

default e2f1_money = False

default e2f1_explore = 0

# Freeroam Collected Photos #

default persistent.e2f1_collected_p = 0
default persistent.e2f1_collected_tp = 10

################################################################################

# Map ##########################################################################

label e2f1_main:
    scene e2f1-main
    call screen e2f1_main with dissolve
return

label e2f1_tables:
    scene e2f1-tables
    call screen e2f1_tables with dissolve
return

# Bookshelfs left #

label e2f1_bs_left:
    scene e2f1-bs_left
    call screen e2f1_bs_left with dissolve
return

label e2f1_bs1:
    scene e2f1-bs1
    call screen e2f1_bs1 with dissolve
return

label e2f1_bs2:
    scene e2f1-bs2
    call screen e2f1_bs2 with dissolve
return

label e2f1_bs3:
    scene e2f1-bs3
    call screen e2f1_bs3 with dissolve
return

# Bookshelfs right #

label e2f1_bs_right:
    scene e2f1-bs_right
    call screen e2f1_bs_right with dissolve
return

label e2f1_bs4:
    if e2f1_ken == False:
        scene e2f1-bs4
    else:
        scene e2f1-bs4-1
    call screen e2f1_bs4 with dissolve
return

label e2f1_bs5:
    if e2f1_evelyn == False:
        scene e2f1-bs5
    else:
        scene e2f1-bs5-1
    call screen e2f1_bs5 with dissolve
return

# Actions ######################################################################

# Bookshelfs left #
label e2f1_ma_book:
    mc "*Great, a math book.*"

    $ e2f1_books += 1

    $ current_quests.remove("Grab a Math book.")

    if e2f1_books == 5:
        if "Ask Alice about the books." in optional_quests:
            $ optional_quests.remove("Ask Alice about the books.")

    $ e2f1_math = True

    if e2f1_books < 4:
        mc "*Just a couple more left.*"
    if e2f1_books == 4:
        mc "*Just one more left.*"
    if e2f1_books == 5:
        mc "*Now I can make the notes.*"

    jump e2f1_bs1
return

label e2f1_en_book:
    mc "*Oh, an english book!*"
    mc "*Just what I was searching for.*"

    $ e2f1_books += 1

    $ current_quests.remove("Grab an English book.")

    if e2f1_books == 5:
        if "Ask Alice about the books." in optional_quests:
            $ optional_quests.remove("Ask Alice about the books.")

    $ e2f1_english = True

    if e2f1_books < 4:
        mc "*Just a couple more left.*"
    if e2f1_books == 4:
        mc "*Just one more left.*"
    if e2f1_books == 5:
        mc "*Now I can make the notes.*"

    jump e2f1_bs2
return

label e2f1_cleo:
    scene e2f1-cl_01 with dissolve
    pause

    scene e2f1-cl_02 with dissolve
    mc "Hey [cl]!"

    scene e2f1-cl_04 with dissolve
    cl "Hi [mc]!"

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "Still searching for history books?"

    scene e2f1-cl_05 with dissolve
    hide e2f1-cleo_blink1
    cl "Yeah..."

    scene e2f1-cl_06 with dissolve
    cl "What's up with you [mc]?"

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "I'm taking a couple of notes from today's classes for [jon]."
    mc "So I need to grab some books."

    scene e2f1-cl_07 with dissolve
    hide e2f1-cleo_blink1
    cl "Great!"

    scene e2f1-cl_08 with dissolve
    cl "Do you need a history book?"

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "As a matter of fact, yeah, I do."
    mc "Is this the history section?"

    scene e2f1-cl_07 with dissolve
    hide e2f1-cleo_blink1
    cl "Yup, you're in the right place."

    scene e2f1-cl_08 with dissolve
    cl "Which one do you need?"

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "I was hoping that you could help me."

    scene e2f1-cl_05 with dissolve
    hide e2f1-cleo_blink1
    cl "Is [jon] a freshman as well?"

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "Yup, he is."

    scene e2f1-cl_09 with dissolve
    hide e2f1-cleo_blink1
    pause

    scene e2f1-cl_10 with dissolve
    cl "Here, you can use this book."
    cl "It's for the first year of college and it contains pretty much all the subjects summarized."

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "Thank you very much [cl]!"

    scene e2f1-cl_08 with dissolve
    hide e2f1-cleo_blink1
    cl "No problem, [mc]!"

    scene e2f1-cl_07 with dissolve
    cl "You can return it to me whenever you're finished with it."

    scene e2f1-cl_03 with dissolve
    show e2f1-cleo_blink1
    mc "Alright, no problem."

    $ e2f1_explore += 1

    if e2f1_explore == 4:
        $ optional_quests.remove("Explore the place.")

    $ e2f1_books += 1

    $ e2f1_history = True

    $ current_quests.remove("Grab a History book.")

    if e2f1_books == 5:
        if "Ask Alice about the books." in optional_quests:
            $ optional_quests.remove("Ask Alice about the books.")

    scene e2f1-cl_11 with dissolve
    hide e2f1-cleo_blink1
    pause

    jump e2f1_bs3
return

# Bookshelfs right #
label e2f1_ge_book:
    mc "*Great, a geography book.*"

    $ e2f1_books += 1

    $ current_quests.remove("Grab a Geography book.")

    if e2f1_books == 5:
        if "Ask Alice about the books." in optional_quests:
            $ optional_quests.remove("Ask Alice about the books.")

    $ e2f1_geography = True

    if e2f1_books < 4:
        mc "*Just a couple more left.*"
    if e2f1_books == 4:
        mc "*Just one more left.*"
    if e2f1_books == 5:
        mc "*Now I can make the notes.*"

    jump e2f1_bs4
return

label e2f1_phy_sci_book:
    mc "*Great, a physics and science book.*"

    $ e2f1_books += 1

    $ current_quests.remove("Grab a Physics and Science book.")

    if e2f1_books == 5:
        if "Ask Alice about the books." in optional_quests:
            $ optional_quests.remove("Ask Alice about the books.")

    $ e2f1_phy_sci = True

    if e2f1_books < 4:
        mc "*Just a couple more left.*"
    if e2f1_books == 4:
        mc "*Just one more left.*"
    if e2f1_books == 5:
        mc "*Now I can make the notes.*"

    jump e2f1_bs5
return

label e2f1_ken:

    scene e2f1-ke_01 with dissolve
    pause

    scene e2f1-ke_02 with dissolve
    mc "Hey [ke]!"

    scene e2f1-ke_04 with dissolve
    ke "[mc], hello my friend!"

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "What brings you here?"

    scene e2f1-ke_05 with dissolve
    hide e2f1-ken_blink1
    ke "I need to borrow a book for one of my classes."

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "I see."
    mc "Weren't you with the guys?"

    scene e2f1-ke_06 with dissolve
    hide e2f1-ken_blink1
    ke "Fuck them guys."

    scene e2f1-ke_07 with dissolve
    ke "Did you know that [ro] kept from me the fact that the blue frog was going to lose?"

    scene e2f1-ke_08 with dissolve
    show e2f1-ken_blink2
    mc "I had no idea..."

    scene e2f1-ke_09 with dissolve
    hide e2f1-ken_blink2
    ke "Yeah well, he can kiss my ass."

    scene e2f1-ke_10 with dissolve
    ke "I'm gonna get him for that."

    scene e2f1-ke_08 with dissolve
    show e2f1-ken_blink2
    mc "Hey, what's up with the librarian?"

    scene e2f1-ke_11 with dissolve
    hide e2f1-ken_blink2
    ke "Who? Mommy milkers?"

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "Haha, that's what you call her?"

    scene e2f1-ke_12 with dissolve
    hide e2f1-ken_blink1
    ke "That's what everyone calls her."

    scene e2f1-ke_13 with dissolve
    ke "Bro, haven't you seen the milkers she's packing?"

    scene e2f1-ke_14 with dissolve
    ke "Look, check her out."

    scene e2f1-ke_15 with dissolve
    menu:
        "Approve":
            stop music fadeout 1.0
            if affinity_spectrum > 0:
                call e2f1_extrovert_daydream from _call_e2f1_extrovert_daydream
            else:
                call e2f1_introvert_daydream from _call_e2f1_introvert_daydream

        "Not my type":
            mc "Yeah... she's not really my type."
            ke "Dude... you're crazy."

    scene e2f1-ke_13 with dissolve
    ke "I would die to bury my face in those tits."

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "Haha, let's not get into details now."
    mc "Why is she so grumpy?"

    scene e2f1-ke_24 with dissolve
    hide e2f1-ken_blink1
    ke "I don't know to be honest."

    scene e2f1-ke_04 with dissolve
    ke "That's how she's been forever."

    scene e2f1-ke_24 with dissolve
    ke "I haven't really interacted with her to be honest."

    $ e2f1_eve_name = True
    scene e2f1-ke_11 with dissolve
    ke "I just know that her name is [ev]."

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "[ev]? Like Eve?"

    scene e2f1-ke_11 with dissolve
    hide e2f1-ken_blink1
    ke "Yeah... she doesn't really like being called Eve."

    scene e2f1-ke_04 with dissolve
    ke "Probably a past relationship gone wrong, who knows?"

    scene e2f1-ke_04 with dissolve
    ke "Don't get on her wrong side, she'll block your access to the library."

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "Duly noted."

    scene e2f1-ke_05 with dissolve
    hide e2f1-ken_blink1
    ke "I gotta run now, my class starts in a couple of minutes."

    scene e2f1-ke_11 with dissolve
    ke "See you [mc]!"

    scene e2f1-ke_03 with dissolve
    show e2f1-ken_blink1
    mc "Bye [ke]!"

    $ e2f1_explore += 1

    if e2f1_explore == 4:
        $ optional_quests.remove("Explore the place.")

    $ e2f1_ken = True

    scene e2f1-ke_25 with dissolve
    pause

    jump e2f1_bs4
return

label e2f1_extrovert_daydream:
    play music heartache
    scene e2f1-ke_16 with dissolve
    mc "Holy shit, you're right!"

    scene e2f1-ke_17 with dissolve
    mc "*What I wouldn't do to walk up to her right now...*"

    scene e2f1-ke_18 with dissolve
    mc "*Slowly undress her...*"

    scene e2f1-ke_19 with dissolve
    mc "*And fuck her brains out!*"

    if persistent.disable_nsfw == True:
        scene e2f1-ke_20 with dissolve
        pause

        scene e2f1-ke_doggy1 with dissolve
        unknown "*Oh, yeah [mc]!*"
        unknown "*Fuck me like I am your little slut.*"

        scene e2f1-ke_doggy2 with dissolve
        pause

        scene e2f1-ke_doggy3 with dissolve
        unknown "*Fuck... it feels so good.*"
        unknown "*Do you like these mommy milkers?*"

        scene e2f1-ke_doggy4 with dissolve
        pause

        scene e2f1-ke_21 with dissolve
        unknown "*Keep going...*"

        scene e2f1-ke_doggy1 with dissolve
        pause

        scene e2f1-ke_doggy2 with dissolve
        pause

        scene e2f1-ke_doggy3 with dissolve
        pause

        scene e2f1-ke_doggy4 with dissolve
        pause

        scene e2f1-ke_22 with dissolve
        unknown "*Ahh [mc], I'm cumming...*"

        scene e2f1-ke_23 with vpunch
        pause

    else:
        if persistent.type_nsfw == False:
            scene e2f1-ke_20_cen with dissolve
            pause

            scene e2f1-ke_doggy1_cen with dissolve
            unknown "*Oh, yeah [mc]!*"
            unknown "*Fuck me like I am your little slut.*"

            scene e2f1-ke_doggy2_cen with dissolve
            pause

            scene e2f1-ke_doggy3_cen with dissolve
            unknown "*Fuck... it feels so good.*"
            unknown "*Do you like these mommy milkers?*"

            scene e2f1-ke_doggy4_cen with dissolve
            pause

            scene e2f1-ke_21_cen with dissolve
            unknown "*Keep going...*"

            scene e2f1-ke_doggy1_cen with dissolve
            pause

            scene e2f1-ke_doggy2_cen with dissolve
            pause

            scene e2f1-ke_doggy3_cen with dissolve
            pause

            scene e2f1-ke_doggy4_cen with dissolve
            pause

            scene e2f1-ke_22_cen with dissolve
            unknown "*Ahh [mc], I'm cumming...*"

            scene e2f1-ke_23_cen with vpunch
            pause

    stop music fadeout 1.0
    scene e2f1-ke_15 with dissolve
    mc "Fuck me..."

    $ persistent.e2f1_daydream = 2

    $ renpy.end_replay()

    $ renpy.music.queue (e2f1_tracks, loop=True)
return

label e2f1_introvert_daydream:
    play music heartache
    scene e2f1-ke_16 with dissolve
    mc "Holy... you're right!"

    scene e2f1-ke_17 with dissolve
    mc "*What I wouldn't do to walk up to her right now...*"

    scene e2f1-ke_18 with dissolve
    mc "*And to slowly undress her...*"

    scene e2f1-ke_19 with dissolve
    pause

    if persistent.disable_nsfw == True:
        scene e2f1-ke_20 with dissolve
        pause

    else:
        if persistent.type_nsfw == False:
            scene e2f1-ke_20_cen with dissolve
            pause

    stop music fadeout 1.0
    scene e2f1-ke_15 with dissolve
    mc "Damn..."

    if persistent.e2f1_daydream < 2:
        $ persistent.e2f1_daydream = 1

    $ renpy.end_replay()

    $ renpy.music.queue (e2f1_tracks, loop=True)
return

label e2f1_evelyn:
    scene e2f1-ev_01 with dissolve
    pause

    scene e2f1-ev_02 with dissolve
    mc "Uh... hello?"

    scene e2f1-ev_03 with dissolve
    pause

    scene e2f1-ev_04 with dissolve
    if e2f1_eve_name == False:
        unknown "Hey?"
    else:
        ev "Hey?"

    scene e2f1-ev_05 with dissolve
    show e2f1-evelyn_blink1
    menu:
        "Check her out":
            scene e2f1-ev_12 with dissolve
            if affinity_spectrum >= 0:
                mc "*Holy fuck look at the milkers!*"
                mc "*I would give one of my nuts to fuck those tits.*"
            if e2f1_eve_name == False:
                unknown "Ahem..."
            else:
                ev "Ahem..."
            mc "*Shit!*"

            scene e2f1-ev_05 with dissolve
            show e2f1-evelyn_blink1

        "Don't risk it":
            pass

    mc "What's up?"

    scene e2f1-ev_06 with dissolve
    hide e2f1-evelyn_blink1
    if e2f1_eve_name == False:
        unknown "Do you need something?"
    else:
        ev "Do you need something?"

    scene e2f1-ev_05 with dissolve
    show e2f1-evelyn_blink1
    mc "I mean, not really."
    mc "I was just looking around to grab some books for my friend."
    mc "He can't come today so he asked me to make him some notes."

    scene e2f1-ev_07 with dissolve
    hide e2f1-evelyn_blink1
    if e2f1_eve_name == False:
        unknown "You should tell your friend that missing classes isn't advised."
    else:
        ev "You should tell your friend that missing classes isn't advised."

    scene e2f1-ev_08 with dissolve
    if e2f1_eve_name == False:
        unknown "He'll most likely fall behind and fail his exams if he continues this kind of attitude."
    else:
        ev "He'll most likely fall behind and fail his exams if he continues this kind of attitude."

    scene e2f1-ev_05 with dissolve
    show e2f1-evelyn_blink1
    mc "Uh, I will?"

    scene e2f1-ev_09 with dissolve
    hide e2f1-evelyn_blink1
    if e2f1_eve_name == False:
        unknown "Students these days..."
    else:
        ev "Students these days..."

    scene e2f1-ev_10 with dissolve
    pause

    $ e2f1_evelyn = True

    $ e2f1_explore += 1

    if e2f1_explore == 4:
        $ optional_quests.remove("Explore the place.")

    scene e2f1-ev_11 with dissolve
    mc "*That was... interesting?*"

    jump e2f1_bs5
return

# Tables #
label e2f1_alice:

    scene e2f1-al_01 with dissolve
    pause

    scene e2f1-al_02 with dissolve
    show e2f1-alice_blink1
    mc "Hello!"
    al "..."
    mc "*Is she not hearing me?*"
    mc "Hello?"
    al "..."
    mc "*Looks like she's stuck in that book.*"
    mc "*Maybe I should write a note and slowly slide it inside her book and see if she notices.*"

    scene e2f1-al_03 with dissolve
    hide e2f1-alice_blink1
    mc "*Hmm... what should the note say?*"
    menu:
        "Corny":
            $ alice_trust += 1
            $ e2f1_alice_note = 0
            call introvert_affinity_check from _call_introvert_affinity_check_20
            call color_check from _call_color_check_46
            mc "*I'll write something corny...*"

            scene e2f1-al_04 with dissolve
            mc "*Hehe...*"

            scene e2f1-al_02 with dissolve
            show e2f1-alice_blink1
            mc "..."

            scene e2f1-al_05 with dissolve
            hide e2f1-alice_blink1
            al "Huh, what's this?"

            scene e2f1-al_06 with dissolve
            al "You look really sweet when you read."

            scene e2f1-al_07 with dissolve
            al "Aww, thank you!"

        "Friendly":
            $ e2f1_alice_note = 1
            mc "*I know, I'll write something friendly.*"

            scene e2f1-al_04 with dissolve
            mc "*...*"

            scene e2f1-al_02 with dissolve
            show e2f1-alice_blink1
            mc "..."

            scene e2f1-al_05 with dissolve
            hide e2f1-alice_blink1
            al "Huh, what's this?"

            scene e2f1-al_06 with dissolve
            al "Didn't want to bother you so I left this note."

            scene e2f1-al_08 with dissolve
            al "This is so nice, thank you!"

        "Joke":
            $ e2f1_alice_note = 2
            $ alice_trust -= 1
            call extrovert_affinity_check from _call_extrovert_affinity_check_24
            call color_check from _call_color_check_48
            mc "*I think I'll write a joke.*"

            scene e2f1-al_04 with dissolve
            mc "*Hehe...*"

            scene e2f1-al_02 with dissolve
            show e2f1-alice_blink1
            mc "..."

            scene e2f1-al_05 with dissolve
            hide e2f1-alice_blink1
            al "Huh, what's this?"

            scene e2f1-al_06 with dissolve
            al "I took the liberty of stealing your stuff, I hope you don't mind."

            scene e2f1-al_09 with dissolve
            al "I don't really get it but fine."

    scene e2f1-al_10 with dissolve
    al "Sorry I didn't notice you, I was really captivated by this book."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Hey, it's alright."
    mc "[al], right?"

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Yup, that's me."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "What's up [al]?"
    mc "Remember me?"

    scene e2f1-al_13 with dissolve
    hide e2f1-alice_blink2
    al "You're the guy with Train Infection, right?"

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Haha, that's me!"
    mc "So, what are you up to?"

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Nothing much, just hanging around the library."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "This seems to be your favorite place to hang out."

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Yeah."

    scene e2f1-al_14 with dissolve
    al "Well... I love to read, so."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Haha, I see."

    scene e2f1-al_15 with dissolve
    hide e2f1-alice_blink2
    al "What are you doing here, [mc]?"

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Well, I'm trying to grab a couple of books for my friend [jon]."
    mc "He can't attend college today so he asked me to take a few notes for him."

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Oh, that's great."

    scene e2f1-al_14 with dissolve
    al "How's that going?"

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    if e2f1_books < 1:
        mc "Well... I just came here."
        mc "I haven't grabbed any books yet."

        scene e2f1-al_12 with dissolve
        hide e2f1-alice_blink2
        al "I understand."

    if e2f1_books >= 1 and e2f1_books < 5:
        mc "It's going alright."
        mc "It wasn't that hard to find them."
        mc "But I still need to grab a couple more."

        scene e2f1-al_12 with dissolve
        hide e2f1-alice_blink2
        al "Alright."

    if e2f1_books == 5:
        mc "Well, I grabbed everything I need."
        mc "I only need to find a table where I can start."

        scene e2f1-al_24 with dissolve
        hide e2f1-alice_blink2
        al "Hey, this seat is not taken."

        scene e2f1-al_13 with dissolve
        al "If you want, I could help you with your notes."

        scene e2f1-al_11 with dissolve
        show e2f1-alice_blink2
        mc "Really?"
        mc "Would you do that for me?"

        scene e2f1-al_14 with dissolve
        hide e2f1-alice_blink2
        al "Sure [mc]!"

        scene e2f1-al_12 with dissolve
        al "It's no big deal."

        scene e2f1-al_15 with dissolve
        al "Plus, I have a two hour window so I don't really have anything better to do until the next course."

        scene e2f1-al_11 with dissolve
        show e2f1-alice_blink2
        mc "That's awesome! Thanks a lot [al]!"

        scene e2f1-al_12 with dissolve
        hide e2f1-alice_blink2
        al "Haha, no problem."

        scene e2f1-al_15 with dissolve
        al "So... do you want to start now?"

        scene e2f1-al_11 with dissolve
        show e2f1-alice_blink2

        $ collected_p = persistent.e2f1_collected_p
        $ collected_tp = persistent.e2f1_collected_tp
        $ renpy.show_screen("render_count_notify_pers")

        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                $ e2f1_alice_asap = True

                jump e2f1_alice_final

            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                mc "I'd love to but I've got a couple more things to do."

                scene e2f1-al_12 with dissolve
                hide e2f1-alice_blink2
                al "Alright, no worries."

                scene e2f1-al_13 with dissolve
                al "You can find me here whenever you're done."

                $ e2f1_alice = True

                $ e2f1_explore += 1

                if e2f1_explore == 4:
                    $ optional_quests.remove("Explore the place.")

                $ current_quests.append("Return to Alice with the books.")

                scene e2f1-al_11 with dissolve
                show e2f1-alice_blink2
                mc "Alright [al], see you!"

                hide e2f1-alice_blink2
                jump e2f1_tables

    scene e2f1-al_13 with dissolve
    al "Hey, if you want I could help you around."

    scene e2f1-al_12 with dissolve
    al "And also help you with the notes."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Really? Would you do that for me?"

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Sure [mc]!"
    al "It's no big deal."

    scene e2f1-al_15 with dissolve
    al "Plus, I have a two hour window so I don't really have anything better to do until the next course."

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "That's awesome! Thanks a lot [al]!"

    scene e2f1-al_14 with dissolve
    hide e2f1-alice_blink2
    al "Haha, no problem!"

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Well, I'll be on my way to find the books."

    scene e2f1-al_12 with dissolve
    hide e2f1-alice_blink2
    al "Alright [mc]."

    scene e2f1-al_13 with dissolve
    al "If you need help in finding them, come and ask me and I'll try to help."

    $ e2f1_alice = True

    $ current_quests.append("Return to Alice with the books.")

    $ optional_quests.append("Ask Alice about the books.")

    $ e2f1_explore += 1

    if e2f1_explore == 4:
        $ optional_quests.remove("Explore the place.")

    scene e2f1-al_11 with dissolve
    show e2f1-alice_blink2
    mc "Okay [al], thank you!"

    jump e2f1_tables
return

label e2f1_ask_alice:

    if e2f1_books < 6:
        $ GameRunning = True

        scene e2f1-al_16 with dissolve
        show e2f1-alice_blink3
        mc "Hey [al]!"
        mc "I've got a question regarding the books."

        scene e2f1-al_19 with dissolve
        hide e2f1-alice_blink3
        al "Sure [mc]."

        scene e2f1-al_20 with dissolve
        al "What's up?"

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            scene e2f1-al_16 with dissolve
            show e2f1-alice_blink3
            menu:
                "History" if e2f1_history == False:
                    $ config.rollback_enabled = True
                    $ e2f1_question = 1

                    mc "Do you know where I could find a history book?"

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Sure [mc]!"

                    scene e2f1-al_17 with dissolve
                    al "The history books are all located on the middle bookshelfs, can't remember exactly which ones they were..."

                    scene e2f1-al_20 with dissolve
                    al "It shouldn't take too long to find."

                    scene e2f1-al_16 with dissolve
                    show e2f1-alice_blink3
                    mc "Alright, got it."

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Tell me [mc], do you need anything else?"

                "Math" if e2f1_math == False:
                    $ config.rollback_enabled = True
                    $ e2f1_question = 1

                    mc "Do you know where I could find a math book?"
                    al "Hmm..."

                    scene e2f1-al_17 with dissolve
                    hide e2f1-alice_blink3
                    al "Oh, it's on the first bookshelf."

                    scene e2f1-al_19 with dissolve
                    al "Bottom left corner."

                    scene e2f1-al_16 with dissolve
                    show e2f1-alice_blink3
                    mc "I got it."

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Okay!"

                    scene e2f1-al_20 with dissolve
                    hide e2f1-alice_blink3
                    al "Tell me [mc], do you need anything else?"

                "English" if e2f1_english == False:
                    $ config.rollback_enabled = True
                    $ e2f1_question = 1

                    mc "Do you know where I could find an English book?"

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Yeah!"

                    scene e2f1-al_17 with dissolve
                    al "English books are located on the second bookshelf from the left."

                    scene e2f1-al_16 with dissolve
                    show e2f1-alice_blink3
                    mc "Alright, got it."

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Tell me [mc], do you need anything else?"

                "Geography" if e2f1_geography == False:
                    $ config.rollback_enabled = True
                    $ e2f1_question = 1

                    mc "Do you know where I could find a geography book?"

                    scene e2f1-al_20 with dissolve
                    hide e2f1-alice_blink3
                    al "Hmm... they were located somewhere near the right side of the library."

                    scene e2f1-al_18 with dissolve
                    al "You should take a look there and see if you can find anything."

                    scene e2f1-al_16 with dissolve
                    show e2f1-alice_blink3
                    mc "Alright, got it."

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Tell me [mc], do you need anything else?"

                "Physics and Science" if e2f1_phy_sci == False:
                    $ config.rollback_enabled = True
                    $ e2f1_question = 1

                    mc "Do you know where I could find a physics and science book?"

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Sure!"

                    scene e2f1-al_17 with dissolve
                    al "It's located on the right bookshelf on the far right."

                    scene e2f1-al_18 with dissolve
                    al "It should be pretty easy to find!"

                    scene e2f1-al_16 with dissolve
                    show e2f1-alice_blink3
                    mc "Alright, got it."

                    scene e2f1-al_19 with dissolve
                    hide e2f1-alice_blink3
                    al "Tell me [mc], do you need anything else?"

                "Nothing":
                    $ config.rollback_enabled = True
                    if e2f1_question == 0:

                        mc "Actually... I don't need anything else."

                        scene e2f1-al_19 with dissolve
                        hide e2f1-alice_blink3
                        al "Oh, okay!"
                    if e2f1_question == 1:

                        mc "I don't need anything else."
                        mc "Thank you [al]!"

                        scene e2f1-al_19 with dissolve
                        hide e2f1-alice_blink3
                        al "No problem!"

                    scene e2f1-al_17 with dissolve
                    al "Make sure you come back to me once you have all the books."

                    $ e2f1_question = 0
                    $ GameRunning = False

        $ config.rollback_enabled = True

    if e2f1_books == 6:
        scene e2f1-al_16 with dissolve
        show e2f1-alice_blink3
        mc "Well, I grabbed everything we need."

        scene e2f1-al_19 with dissolve
        hide e2f1-alice_blink3
        al "Alright."

        scene e2f1-al_17 with dissolve
        al "Shall we get started?"

        scene e2f1-al_16 with dissolve
        show e2f1-alice_blink3

        $ collected_p = persistent.e2f1_collected_p
        $ collected_tp = persistent.e2f1_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                mc "Yeah..."
                mc "The sooner the better."

                scene e2f1-al_19 with dissolve
                hide e2f1-alice_blink3
                al "Alright then."

                jump e2f1_alice_final

            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                mc "I'd love to but I've got a couple more things to do."

                scene e2f1-al_19 with dissolve
                hide e2f1-alice_blink3
                al "Alright, no worries."

                scene e2f1-al_17 with dissolve
                al "You can find me here whenever you're done."

                scene e2f1-al_16 with dissolve
                show e2f1-alice_blink3
                mc "Alright [al], see you!"

                scene e2f1-tables
                call screen e2f1_tables with dissolve

    scene e2f1-tables
    call screen e2f1_tables with dissolve
return

label e2f1_alice_final:
    if e2f1_alice_asap == False:
        $ collected_p = persistent.e2f1_collected_p
        $ collected_tp = persistent.e2f1_collected_tp
        $ renpy.show_screen("render_count_notify_pers")
        menu:
            "End freeroam":
                if optional_quests:
                    $ optional_quests.clear()
                if current_quests:
                    $ current_quests.clear()

                $ renpy.hide_screen("questtracker_icon")

                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                stop music fadeout 2.0
                scene e2f1-al_16 with dissolve
                show e2f1-alice_blink3
                mc "Well, I grabbed everything we need."

                scene e2f1-al_19 with dissolve
                hide e2f1-alice_blink3
                al "Alright."

                scene e2f1-al_21 with dissolve
                pause

                scene e2f1-al_23 with dissolve
                al "Shall we get started?"

                scene e2f1-al_22 with dissolve
                show e2f1-alice_blink4
                mc "Yeah, the sooner the better."

                play music perfect_one
                scene e2f1-al_26 with dissolve
                hide e2f1-alice_blink4
                al "Alright then."

                ### Montage

                scene e2f1-al_29 with dissolve
                pause

                scene e2f1-al_30 with dissolve
                pause

                scene e2f1-al_36 with dissolve
                pause

                scene e2f1-al_45 with dissolve
                pause

                scene e2f1-al_38 with dissolve
                pause

                scene e2f1-al_35 with dissolve
                pause

                scene e2f1-al_40 with dissolve
                pause

                scene e2f1-al_31 with dissolve
                menu:
                    "Flirt with her":
                        $ alice_trust += 1
                        scene e2f1-al_32 with dissolve
                        pause

                        scene e2f1-al_31 with dissolve
                        pause

                        scene e2f1-al_33 with dissolve
                        pause

                        scene e2f1-al_34 with dissolve
                        pause
                    "Don't do it":
                        pass

                scene e2f1-al_41 with dissolve
                pause

                scene e2f1-al_45 with dissolve
                pause

                scene e2f1-al_37 with dissolve
                pause

                if persistent.e2f1_daydream > 0:
                    scene e2f1-al_42 with dissolve
                    pause

                    scene e2f1-al_43 with dissolve
                    pause

                    scene e2f1-al_46 with dissolve
                    pause

                    scene e2f1-al_47 with dissolve
                    pause

                    scene e2f1-al_48 with dissolve
                    pause
                else:
                    scene e2f1-al_44 with dissolve
                    pause

                scene e2f1-al_29 with dissolve
                pause

                scene e2f1-al_30 with dissolve
                pause

                scene e2f1-al_39 with dissolve
                pause

                ### Montage

                stop music fadeout 5.0
                scene e2f1-al_22 with dissolve
                show e2f1-alice_blink4
                mc "Well, thanks a lot [al]!"
                mc "This would have probably taken a lot longer without your help."

                scene e2f1-al_23 with dissolve
                hide e2f1-alice_blink4
                al "Glad to be of help, [mc]."

                scene e2f1-al_22 with dissolve
                show e2f1-alice_blink4
                mc "I owe you one."
                mc "I'm going to return the favor someday if you need something."

                scene e2f1-al_25 with dissolve
                hide e2f1-alice_blink4
                al "Thank you [mc]!"

                scene e2f1-al_28 with dissolve
                al "I'll let you know if I need your help."

                scene e2f1-al_22 with dissolve
                show e2f1-alice_blink4
                mc "Great!"
                mc "See you around [al]."

                scene e2f1-al_27 with dissolve
                hide e2f1-alice_blink4
                al "Good bye [mc]."

                scene e2f1-al_21 with dissolve
                pause

                jump e2s3
            "Explore more":
                $ renpy.show_screen("render_count_notify")
                pause(0.5)
                $ renpy.hide_screen("render_count_notify_pers")

                jump e2f1_tables
    else:
        stop music fadeout 2.0
        scene e2f1-al_21 with dissolve
        hide e2f1-alice_blink2
        pause

        scene e2f1-al_22 with dissolve
        show e2f1-alice_blink4
        mc "Yeah, the sooner the better."

        play music perfect_one
        scene e2f1-al_26 with dissolve
        hide e2f1-alice_blink4
        al "Alright then."

        ### Montage

        scene e2f1-al_29 with dissolve
        pause

        scene e2f1-al_30 with dissolve
        pause

        scene e2f1-al_36 with dissolve
        pause

        scene e2f1-al_45 with dissolve
        pause

        scene e2f1-al_38 with dissolve
        pause

        scene e2f1-al_35 with dissolve
        pause

        scene e2f1-al_40 with dissolve
        pause

        scene e2f1-al_31 with dissolve
        menu:
            "Flirt with her":
                $ alice_trust += 1
                scene e2f1-al_32 with dissolve
                pause

                scene e2f1-al_31 with dissolve
                pause

                scene e2f1-al_33 with dissolve
                pause

                scene e2f1-al_34 with dissolve
                pause
            "Don't do it":
                pass

        scene e2f1-al_41 with dissolve
        pause

        scene e2f1-al_45 with dissolve
        pause

        scene e2f1-al_37 with dissolve
        pause

        if persistent.e2f1_daydream > 0:
            scene e2f1-al_42 with dissolve
            pause

            scene e2f1-al_43 with dissolve
            pause

            scene e2f1-al_46 with dissolve
            pause

            scene e2f1-al_47 with dissolve
            pause

            scene e2f1-al_48 with dissolve
            pause
        else:
            scene e2f1-al_44 with dissolve
            pause

        scene e2f1-al_29 with dissolve
        pause

        scene e2f1-al_30 with dissolve
        pause

        scene e2f1-al_39 with dissolve
        pause

        ### Montage

        stop music fadeout 5.0
        scene e2f1-al_22 with dissolve
        show e2f1-alice_blink4
        mc "Well, thanks a lot [al]!"
        mc "This would have probably taken a lot longer without your help."

        scene e2f1-al_23 with dissolve
        hide e2f1-alice_blink4
        al "Glad to be of help, [mc]."

        scene e2f1-al_22 with dissolve
        show e2f1-alice_blink4
        mc "I owe you one."
        mc "I'm going to return the favor someday if you need something."

        scene e2f1-al_25 with dissolve
        hide e2f1-alice_blink4
        al "Thank you [mc]!"

        scene e2f1-al_28 with dissolve
        al "I'll let you know if I need you help."

        scene e2f1-al_22 with dissolve
        show e2f1-alice_blink4
        mc "Great!"
        mc "See you around [al]."

        scene e2f1-al_27 with dissolve
        hide e2f1-alice_blink4
        al "Good bye [mc]."

        scene e2f1-al_21 with dissolve
        pause

        jump e2s3
return

label e2f1:
    scene e2f1-01 with Dissolve(2.0)
    mc "*So... here am I.*"
    mc "*I should start grabbing all the books needed for [jon]'s notes.*"

    define e2f1_tracks = ["aces_high.ogg", "airplane_mode.ogg", "bloom.ogg", "border_blaster.ogg", "breathe.ogg", "circles.ogg", "crazy_glue.ogg", "darien_gap.ogg", "frannie.ogg", "heartless_man.ogg", "hey_ruth.ogg", "hi_as_hats.ogg", "inertia.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "killer_rabbit.ogg", "laurel_breeze.ogg", "mom_n_pa.ogg", "one_fine_day.ogg", "onfire.ogg", "pop_song.ogg", "punk_rock_holiday.ogg", "sun_sets_on_a_protagonist.ogg", "sundown.ogg", "the_pawnbrokers_stepdaughter.ogg", "tidalwave.ogg", "twenty_twenty.ogg", "welcome_to_zombie_coast.ogg", "with_a_whimper.ogg", "wonder_under.ogg"]
    $ renpy.music.queue (e2f1_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Grab a History book.")
    $ current_quests.append("Grab a Math book.")
    $ current_quests.append("Grab an English book.")
    $ current_quests.append("Grab a Geography book.")
    $ current_quests.append("Grab a Physics and Science book.")
    $ optional_quests.append("Explore the place.")

    scene e2f1-main with dissolve
    call screen e2f1_main
    hide e2f1-01
return
