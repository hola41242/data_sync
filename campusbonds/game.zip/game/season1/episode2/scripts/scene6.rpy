
# Scene 6 - CLassroom ##########################################################

label e2s6:
    play music sundown
    scene e2s6-01 with wipeleft
    pause

    play sound door_open
    scene e2s6-02 with dissolve
    pause

    scene e2s6-03 with dissolve
    pause

    scene e2s6-04 with dissolve
    jon "Hey [mc]..."
    jon "About those notes..."

    scene e2s6-05 with dissolve
    jon "They could have probably been useful now."

    scene e2s6-06 with dissolve
    mc "Well..."
    mc "You should have taken them."

    scene e2s6-07 with dissolve
    jon "Hey, is that [sd] and [tr]?"
    jon "Let's sit behind them."
    menu:
        "Good idea":
            call extrovert_affinity_check from _call_extrovert_affinity_check_41
            call color_check from _call_color_check_78
            mc "Cool! Let's go."

        "Bad idea":
            call introvert_affinity_check from _call_introvert_affinity_check_34
            call color_check from _call_color_check_79
            mc "I don't think that's such a good idea..."
            jon "Come on bro, it will be fun."

    scene e2s6-08 with dissolve
    jon "Hello girls!"

    scene e2s6-09 with dissolve
    tr "Hey [jon]!"

    if e1f5_refuse_sadie == True:
        scene e2s6-10 with dissolve
        sd "Hi [jon]!"
    else:
        scene e2s6-11 with dissolve
        sd "Hey guys!"

    if affinity_spectrum < 0:
        scene e2s6-12 with dissolve
        jon "What's up?"
    else:
        scene e2s6-13 with dissolve
        mc "What's up?"

    if e1f5_refuse_sadie == True:
        scene e2s6-14 with dissolve
        tr "We're revising for the upcoming test."
    else:
        scene e2s6-15 with dissolve
        sd "We're trying to revise for the upcoming test."

    scene e2s6-16 with dissolve
    mc "Fuck... I totally forgot about that."

    scene e2s6-17 with dissolve
    jon "Wait, there's a test today?"

    scene e2s6-16 with dissolve
    mc "Yeah man, sorry!"

    scene e2s6-18 with dissolve
    mc "I totally forgot about it."

    if e1f5_refuse_sadie == True:
        scene e2s6-19 with dissolve
        sd "Yeah well... we need to study, so..."

        scene e2s6-20 with dissolve
        pause

        scene e2s6-24 with dissolve
        jon "Weird..."

        scene e2s6-14 with dissolve
        tr "Good luck guys!"

        scene e2s6-24 with dissolve
        pause

        scene e2s6-39 with dissolve
        jon "Is it just me..."

        scene e2s6-40 with dissolve
        jon "Or does [sd] look pissed at you?"

        scene e2s6-36 with dissolve
        show e2s6-jon_blink2
        menu:
            "Tell him":
                $ jon_friendship += 1
                mc "She is pissed."

                scene e2s6-37 with dissolve
                hide e2s6-jon_blink2
                jon "Dude, what happened?"

                scene e2s6-36 with dissolve
                show e2s6-jon_blink2
                mc "Long story short... I refused her advances when we were at Cabanna's."
                mc "And now she hates my guts."

                scene e2s6-41 with dissolve
                hide e2s6-jon_blink2
                jon "Oh... sensible stuff."

                scene e2s6-37 with dissolve
                jon "I don't know man, if I were you I would talk to her and clear the air."

                scene e2s6-35 with dissolve
                jon "At least tell her straight to her face you're not interested."

                scene e2s6-37 with dissolve
                jon "Don't give her mixed feelings."

                scene e2s6-36 with dissolve
                show e2s6-jon_blink2
                menu:
                    "Talk to her":
                        mc "You're right..."
                        mc "I should talk to her and let her know how I feel."

                    "Don't make it worse":
                        mc "I don't know bro..."
                        mc "I don't want to make it worse."

                        scene e2s6-37 with dissolve
                        hide e2s6-jon_blink2
                        jon "Can it get any worse than this?"

                        scene e2s6-38 with dissolve
                        jon "She is pissed at you and won't even look at you."

                        scene e2s6-37 with dissolve
                        jon "How bad do you think it can get?"

                        scene e2s6-36 with dissolve
                        show e2s6-jon_blink2
                        mc "You might be right."
                        mc "Still... I don't know if I should really do it."

                        scene e2s6-37 with dissolve
                        hide e2s6-jon_blink2
                        jon "You do you bro."
                        jon "That's just my advice."

            "Not his business":
                mc "Isn't [sd] like this all the time?"

                scene e2s6-37 with dissolve
                hide e2s6-jon_blink2
                jon "I don't know bro."

                if sadie_trust >= 3:
                    jon "You're the one she used to talk about."

                    scene e2s6-36 with dissolve
                    show e2s6-jon_blink2
                    mc "She used to talk about me?"

                    scene e2s6-37 with dissolve
                    hide e2s6-jon_blink2
                    jon "Yeah, she mentioned you a couple of times."

                jon "If you did some shit, you should talk to her."

                scene e2s6-36 with dissolve
                show e2s6-jon_blink2
                menu:
                    "Talk to her":
                        mc "*[jon]'s right, I should probably talk to her...*"

                    "Don't make it worse":
                        mc "*Nah, I shouldn't talk to her.*"
                        mc "*I'm only going to make things worse.*"

    else:
        scene e2s6-15 with dissolve
        sd "Don't worry, we don't know anything either."

        scene e2s6-14 with dissolve
        tr "Yeah, if we hadn't spent all night taking pictures and joking around..."
        tr "Maybe we would have studied."

        scene e2s6-21 with dissolve
        jon "Hey, let's forget about this for a second."
        jon "I'm gonna give you some good news."

        scene e2s6-12 with dissolve
        jon "There's a party going on tonight!"

        scene e2s6-15 with dissolve
        sd "That's awesome!"

        scene e2s6-22 with dissolve
        sd "Where is it?"

        scene e2s6-21 with dissolve
        jon "It's at one of [ro]'s friends, I'm gonna text you all the details later."

        if sadie_trust >= 4:
            scene e2s6-15 with dissolve
            sd "You're coming too, right [mc]?"

        if tracy_trust >= 4 and affinity_spectrum > 0:
            if e1f5_tracy_sex == True:
                scene e2s6-25 with dissolve
                tr "We had a lot of fun at the last party, [mc]!"

                scene e2s6-26 with dissolve
                tr "Are you coming as well?"
            else:
                scene e2s6-26 with dissolve
                tr "Are you coming as well, [mc]?"

        if affinity_spectrum > 0:
            scene e2s6-27 with dissolve
            mc "Hell yeah I'm coming!"

            scene e2s6-13 with dissolve
            mc "I wouldn't miss it."

            scene e2s6-28 with dissolve
            jon "I'm so proud..."
        else:
            scene e2s6-23 with dissolve
            mc "Yeah, I'm coming too."

        scene e2s6-14 with dissolve
        tr "Great!"
        tr "We'll be there."

        scene e2s6-22 with dissolve
        sd "Thanks for the invitation [jon]."

        scene e2s6-12 with dissolve
        jon "See you there girls!"

        scene e2s6-29 with dissolve
        pause

        if sadie_trust >= 4 and tracy_trust < 4:
            scene e2s6-30 with dissolve
            jon "Hey, good job dude!"

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "What are you talking about?"

            scene e2s6-33 with dissolve
            hide e2s6-jon_blink1
            jon "[sd]'s been mentioning you quite a bit these last few days."

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "She has?"

            scene e2s6-32 with dissolve
            hide e2s6-jon_blink1
            jon "Yeah, I think you've piqued her interest."

            scene e2s6-30 with dissolve
            jon "You should talk to her if you're also interested."

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "Alright, thanks [jon]!"

        if tracy_trust >= 4 and sadie_trust < 4 and affinity_spectrum > 0:
            scene e2s6-30 with dissolve
            jon "Nice one bro!"

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "What are you talking about?"

            scene e2s6-32 with dissolve
            hide e2s6-jon_blink1
            jon "Didn't you see the way [tr] talked about you?"

            scene e2s6-30 with dissolve
            jon "I think she's interested."

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "Are you sure?"

            scene e2s6-32 with dissolve
            hide e2s6-jon_blink1
            jon "Yeah, she's picky about the guys she talks nice about."

            scene e2s6-30 with dissolve
            jon "She likes to have fun but I haven't really seen her be excited to party again with a guy."

            scene e2s6-34 with dissolve
            jon "And also say that straight to his face."

            scene e2s6-31 with dissolve
            show e2s6-jon_blink1
            mc "Interesting..."

        if sadie_trust >= 4 and tracy_trust >= 4:
            scene e2s6-35 with dissolve
            jon "Hey, be careful bro!"

            scene e2s6-36 with dissolve
            show e2s6-jon_blink2
            mc "What are you talking about?"

            scene e2s6-37 with dissolve
            hide e2s6-jon_blink2
            jon "I've heard good things about you from both girls."

            scene e2s6-36 with dissolve
            show e2s6-jon_blink2
            if affinity_spectrum > 0:
                mc "So... what should I be worried about then?"
            else:
                mc "What are you talking about?"

            scene e2s6-35 with dissolve
            hide e2s6-jon_blink2
            jon "I don't know about [tr] but I've known [sd] for a couple of years now."

            scene e2s6-37 with dissolve
            jon "She isn't really the type to get with a guy that has too many options."

            scene e2s6-38 with dissolve
            jon "If you're really interested about her, I would be careful if I were in your shoes."

            scene e2s6-35 with dissolve
            jon "She doesn't like a man whore."

            scene e2s6-36 with dissolve
            show e2s6-jon_blink2
            mc "But I haven't really decided which one I like."

            scene e2s6-37 with dissolve
            hide e2s6-jon_blink2
            jon "That's fine, but if you want something serious with her I'd advise you to take it slower with other girls, alright?"

            scene e2s6-38 with dissolve
            jon "If you don't really care about that, do whatever you want."

            scene e2s6-37 with dissolve
            jon "But just in case you want something more out of it, that's my advice."

            scene e2s6-36 with dissolve
            show e2s6-jon_blink2
            mc "I understand."
            mc "Thank you [jon] for the advice!"

            scene e2s6-37 with dissolve
            hide e2s6-jon_blink2
            jon "No problem bro!"

    scene e2s6-30 with dissolve
    hide e2s6-jon_blink1
    hide e2s6-jon_blink2
    jon "Anyways, let's get back to this test that you somehow forgot to tell me about."

    scene e2s6-31 with dissolve
    show e2s6-jon_blink1
    mc "I've already told you, I totally forgot about it!"

    scene e2s6-34 with dissolve
    hide e2s6-jon_blink1
    jon "It's alright, at least we're both gonna fail it."

    scene e2s6-31 with dissolve
    show e2s6-jon_blink1
    if affinity_spectrum > 0:
        mc "Haha, damn right we will!"
    else:
        mc "Yeah..."

    stop music fadeout 2.0
    scene e2s6-29 with dissolve
    hide e2s6-jon_blink1
    pause

    scene black with Dissolve(2.0)

    scene e2s6-42 with Dissolve(2.0)
    pause

    if e1f5_refuse_sadie == True:
        scene e2s6-43 with dissolve
        menu:
            "Talk to [sd]":
                jump e2s6_sadie

            "Don't make it worse":
                $ e2s6_talk = False
                scene e2s6-44 with dissolve
                mc "*Sorry [sd], maybe some other time.*"

    if sadie_trust >= 3:
        jump e2s6_sadie

    jump e2s7
return

label e2s6_sadie:
    $ e2s6_talk = True
    scene e2s6-31 with dissolve
    show e2s6-jon_blink1
    mc "Hey [jon]!"
    mc "I'm gonna go talk to [sd]."
    mc "Don't wait up for me."

    scene e2s6-34 with dissolve
    hide e2s6-jon_blink1
    jon "Alright bro."

    if e1f5_refuse_sadie == True:
        scene e2s6-30 with dissolve
        jon "Good luck!"

        scene e2s6-31 with dissolve
        show e2s6-jon_blink1
        mc "Thanks!"

    scene e2s6-45 with dissolve
    hide e2s6-jon_blink1
    pause

    scene e2s6-46 with dissolve
    mc "Hey [sd]!"

    if e1f5_refuse_sadie == True:
        scene e2s6-47 with dissolve
        mc "Wait!"
        mc "I want to talk."

        scene e2s6-48 with dissolve
        sd "What [mc]?"
        sd "What's there to talk about?"

        scene e2s6-49 with dissolve
        mc "Can we go somewhere else to talk about this?"

        scene e2s6-50 with dissolve
        sd "Uh... alright, fine."
    else:
        scene e2s6-51 with dissolve
        sd "Hey [mc]!"

        scene e2s6-52 with dissolve
        sd "What's up?"

        scene e2s6-53 with dissolve
        show e2s6-sadie_blink1
        mc "Just wanted to know if you'd like to hang out."

        scene e2s6-54 with dissolve
        hide e2s6-sadie_blink1
        sd "Sure, I've got some time to kill until I do my assignments."

        scene e2s6-51 with dissolve
        sd "What do you have in mind?"

        scene e2s6-53 with dissolve
        show e2s6-sadie_blink1
        mc "Do you want to go to a cafe?"
        mc "I know a place nearby."

        scene e2s6-55 with dissolve
        hide e2s6-sadie_blink1
        sd "Alright, let's go!"

    play music border_blaster
    scene e2s6-56 with dissolve
    pause

    if e1f5_refuse_sadie == True:
        scene e2s6-57 with dissolve
        mc "Ok..."
        mc "I know that things are kind of awkward between us right now..."

        scene e2s6-58 with dissolve
        show e2s6-sadie_blink2
        mc "But hear me out, alright?"

        menu:
            "Go for [sd]":
                $ sadie_trust += 1
                $ e2s6_sadie_romance = True

                mc "I really like you [sd]!"
                mc "I'm sorry that at the party I turned you down."

                if affinity_spectrum < 0:
                    mc "It didn't feel right to do things at the party."
                    mc "I want to get to know you outside of that environment."

                    scene e2s6-59 with dissolve
                    hide e2s6-sadie_blink2
                    sd "[mc], we weren't about to get married."
                    sd "It was supposed to be just casual stuff, no commitment."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "I'm not with the casual stuff [sd]!"
                    mc "I'm sorry if I came across as being into that stuff."
                    mc "I want to get to know you for who you are."
                else:
                    mc "I don't want to upset you..."
                    mc "That's just how I felt in the moment."
                    mc "But I've realized that I actually like you!"

                    scene e2s6-59 with dissolve
                    hide e2s6-sadie_blink2
                    sd "[mc], we weren't about to get married."
                    sd "It was supposed to be just casual stuff, no commitment."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "Yeah... I know."
                    mc "But I want a different side of you."
                    mc "I actually want to get to know you [sd]."

                scene e2s6-60 with dissolve
                hide e2s6-sadie_blink2
                sd "[mc]..."

                scene e2s6-59 with dissolve
                if e1s17_sadie == True:
                    sd "I've already told you that I just got out of a relationship."
                else:
                    sd "I've just got out of a relationship."

                scene e2s6-63 with dissolve
                sd "I don't know if I can be with you right now."

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                mc "I wasn't asking for a relationship."
                mc "I was just asking for a chance to get to know you."

                scene e2s6-60 with dissolve
                hide e2s6-sadie_blink2
                sd "I don't know [mc]..."

                scene e2s6-61 with dissolve
                sd "I've realized a couple of things about me..."

                scene e2s6-62 with dissolve
                sd "And I need a little bit of time to think."

                scene e2s6-63 with dissolve
                sd "Is it alright?"

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                if affinity_spectrum < 0:
                    mc "Yeah... sure!"
                    mc "Take as much as you need."
                else:
                    mc "It's alright."
                    mc "Take your time."

                scene e2s6-64 with dissolve
                hide e2s6-sadie_blink2
                sd "Thank you [mc]!"

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                mc "I'm going to be waiting [sd]."

                scene e2s6-63 with dissolve
                hide e2s6-sadie_blink2
                sd "Please, don't be upset, regardless of the answer."

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                if affinity_spectrum < 0:
                    mc "I will try..."
                else:
                    mc "I will respect it."

                scene e2s6-63 with dissolve
                hide e2s6-sadie_blink2
                sd "Thanks [mc]!"

            "Remain friends":
                $ e2s6_sadie_friends = True

                mc "So... the thing is..."
                mc "I know that we've been kind of getting along pretty well..."
                mc "And I like you [sd]..."
                mc "But, I don't think I want anything serious with you."
                mc "I refused you back at the party because it didn't feel right to do stuff with you."
                mc "When I don't even like you that way!"
                mc "And, I know that perhaps I gave you the wrong idea..."
                mc "But I'm not interested in any casual stuff or anything like that."

                scene e2s6-61 with dissolve
                hide e2s6-sadie_blink2
                sd "I understand [mc]."

                scene e2s6-63 with dissolve
                sd "Don't stress about it."

                scene e2s6-59 with dissolve
                sd "You're a fun person and I like to hang out with you."

                scene e2s6-61 with dissolve
                sd "Yeah, it hurts a bit to throw myself at you like that and then to be rejected..."

                scene e2s6-63 with dissolve
                sd "But I'll be fine."

                scene e2s6-64 with dissolve
                sd "Sorry for getting the wrong idea about the whole situation."

                scene e2s6-63 with dissolve
                sd "Thank you [mc] for making it clear to me."

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                mc "No problem [sd]!"
                mc "I'm glad we got to talk."

                scene e2s6-63 with dissolve
                hide e2s6-sadie_blink2
                sd "Yeah, me too."

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                mc "So... friends?"

                scene e2s6-63 with dissolve
                hide e2s6-sadie_blink2
                sd "Yeah."

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                mc "Great!"

    else:
        scene e2s6-65 with dissolve
        show e2s6-sadie_blink3
        mc "So... I actually wanted to talk to you about a couple of things."

        scene e2s6-66 with dissolve
        hide e2s6-sadie_blink3
        sd "Alright, hit me!"

        scene e2s6-65 with dissolve
        show e2s6-sadie_blink3
        mc "So..."

        menu:
            "Go for [sd]":
                $ sadie_trust += 1
                mc "*Well... here goes nothing!*"
                mc "*I hope that I won't scare her away.*"
                mc "I know that these last couple of days we've been getting along pretty well."
                mc "You're a really awesome person to be around and I really enjoy hanging out with you..."
                mc "I know this might be a little soon to say but..."
                mc "I'd like to get to know you better [sd]!"

                scene e2s6-58 with dissolve
                show e2s6-sadie_blink2
                hide e2s6-sadie_blink3
                if affinity_spectrum > 0:
                    mc "I'm not really interested in the casual stuff with you."
                else:
                    mc "I'm not really interested in the casual stuff."

                mc "I want a different side of you."
                mc "I want to get to know you as a possible partner."

                if sadie_trust > 4:
                    $ e2s6_sadie_romance = True

                    scene e2s6-64 with dissolve
                    hide e2s6-sadie_blink2
                    sd "That's really nice [mc]!"

                    scene e2s6-59 with dissolve
                    sd "I also feel the same way, it's been fun with you."

                    if e1s17_sadie == True:
                        sd "But, I've already told you that I just got out of a relationship."
                    else:
                        sd "But, I've just got out of a relationship."

                    scene e2s6-63 with dissolve
                    sd "I don't know if I can be with you right now..."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "I wasn't asking for a relationship."
                    mc "I was just asking for a chance to get to know you."

                    scene e2s6-60 with dissolve
                    hide e2s6-sadie_blink2
                    sd "I don't know [mc]..."

                    scene e2s6-61 with dissolve
                    sd "I've realised a couple of things about me..."

                    scene e2s6-62 with dissolve
                    sd "And I need a little bit of time to think."

                    scene e2s6-63 with dissolve
                    sd "Is it alright?"

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    if affinity_spectrum < 0:
                        mc "Yeah... sure!"
                        mc "Take as much as you need."
                    else:
                        mc "It's alright."
                        mc "Take your time."

                    scene e2s6-64 with dissolve
                    hide e2s6-sadie_blink2
                    sd "Thank you [mc]!"

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "I'm going to be waiting [sd]."

                    scene e2s6-63 with dissolve
                    hide e2s6-sadie_blink2
                    sd "Please, don't be upset, regardless of the answer."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    if affinity_spectrum < 0:
                        mc "I will try..."
                    else:
                        mc "I will respect it."

                    scene e2s6-63 with dissolve
                    hide e2s6-sadie_blink2
                    sd "Thanks [mc]!"

                if sadie_trust <= 4:
                    $ e2s6_sadie_fwb = True

                    scene e2s6-61 with dissolve
                    hide e2s6-sadie_blink2
                    sd "That's really nice [mc], but..."

                    scene e2s6-64 with dissolve
                    sd "I didn't want anything serious to begin with."
                    sd "It was just a bit of casual fun, that's all."

                    scene e2s6-63 with dissolve
                    sd "I'm sorry if I came across as liking you that way."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "It's okay."

                    scene e2s6-59 with dissolve
                    hide e2s6-sadie_blink2
                    sd "It's just that, I don't feel like we know each other all that well."

                    scene e2s6-64 with dissolve
                    if e1s17_sadie == True:
                        sd "Plus, you know that I've just got out of a relationship."
                    else:
                        sd "Plus, I've just got out of a relationship."

                    scene e2s6-63 with dissolve
                    sd "I don't think I'm ready for anything serious right now [mc]..."

                    scene e2s6-59 with dissolve
                    sd "Sorry to disappoint you."

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "It's alright [sd], I understand."
                    mc "Thank you for telling me the truth and not sugar coating it."

                    scene e2s6-64 with dissolve
                    hide e2s6-sadie_blink2
                    sd "Maybe in the future, if we get to know each other better."

                    scene e2s6-63 with dissolve
                    sd "But, until then, let's just remain friends, alright?"

                    scene e2s6-58 with dissolve
                    show e2s6-sadie_blink2
                    mc "Sure!"

            "Friends with benefits" if affinity_spectrum > 0:
                $ e2s6_sadie_fwb = True

                mc "So... I know that we've been kind of getting along pretty well."
                mc "And, I like you [sd]..."
                mc "But I don't think I want anything serious with you."
                mc "What do you say we become friends with benefits?."

                if e1f5_sadie_sex == True:
                    scene e2s6-67 with dissolve
                    hide e2s6-sadie_blink3
                    sd "Haha, I thought we were already friends with benefits!"

                scene e2s6-66 with dissolve
                hide e2s6-sadie_blink3
                sd "Relax dude."
                sd "I didn't want anything serious to begin with."
                sd "Fuck buddies is more than enough for me."

                scene e2s6-65 with dissolve
                show e2s6-sadie_blink3
                mc "Great! That's a relief."
                mc "It's just pleasure after all, I'm glad you understand."

                scene e2s6-66 with dissolve
                hide e2s6-sadie_blink3
                sd "Yeah, totally!"

                if e1f5_sadie_sex == False:
                    sd "I'm gonna be honest, this kind of came at a perfect time."

                    scene e2s6-65 with dissolve
                    show e2s6-sadie_blink3
                    mc "Haha, why is that?"

                    scene e2s6-66 with dissolve
                    hide e2s6-sadie_blink3
                    sd "I know most girls won't really admit this, but me personally I've been craving a bit of sex."

                    scene e2s6-65 with dissolve
                    show e2s6-sadie_blink3
                    mc "Woah, that's really straightforward!"
                    mc "We're in public [sd], at least wait until we get to my apartment."

                    scene e2s6-66 with dissolve
                    hide e2s6-sadie_blink3
                    sd "Shut up! You don't even have an apartment."

                    scene e2s6-67 with dissolve
                    sd "Wait, why am I even explaining myself to you?"
                    sd "We're fuck buddies, right?"

                    scene e2s6-65 with dissolve
                    show e2s6-sadie_blink3
                    mc "Yup, that's what we are, nothing more."

                    scene e2s6-66 with dissolve
                    hide e2s6-sadie_blink3
                    sd "Good! If I hear you catching feelings, I'm cutting your balls off."

                    scene e2s6-65 with dissolve
                    show e2s6-sadie_blink3
                    mc "Wait... what?"

                    scene e2s6-66 with dissolve
                    hide e2s6-sadie_blink3
                    sd "You heard me."

                    scene e2s6-65 with dissolve
                    show e2s6-sadie_blink3
                    mc "*Gulp.*"

            "Remain friends":
                $ e2s6_sadie_friends = True

                mc "So... I know that we've been kind of getting along pretty well."
                mc "And, I like you [sd]..."
                mc "But I don't think I want anything serious with you."

                scene e2s6-66 with dissolve
                hide e2s6-sadie_blink3
                sd "[mc]... relax dude!"
                sd "I didn't want anything serious to begin with."

                scene e2s6-67 with dissolve
                sd "It's just a bit of casual fun, that's all."
                sd "Don't stress your mind too much about this."

                scene e2s6-68 with dissolve
                sd "You're a fun person and I like to hang out with you."
                sd "But that's about it."

                scene e2s6-65 with dissolve
                show e2s6-sadie_blink3
                mc "Thank you [sd] for making it clear for me."
                mc "It could have turned into a pretty awkward situation."
                mc "I'm glad we got to talk!"

                scene e2s6-66 with dissolve
                hide e2s6-sadie_blink3
                sd "Yeah, me too!"

                scene e2s6-67 with dissolve
                sd "So... friends?"

                scene e2s6-65 with dissolve
                show e2s6-sadie_blink3
                mc "Yeah!"

                scene e2s6-68 with dissolve
                hide e2s6-sadie_blink3
                sd "Great!"

    scene e2s6-66 with dissolve
    hide e2s6-sadie_blink3
    hide e2s6-sadie_blink2
    sd "I'm gonna go now, I've got some assignments to do."

    scene e2s6-65 with dissolve
    show e2s6-sadie_blink3
    mc "Alright, take care [sd]!"

    scene e2s6-66 with dissolve
    hide e2s6-sadie_blink3
    sd "You too [mc]!"

    scene e2s6-69 with dissolve
    pause

    jump e2s7
return
