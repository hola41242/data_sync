
# Scene 5 - Pizza man ##########################################################

label e2s5:
    scene e2s5-01 with wipeleft
    pause

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e2s5-02 with dissolve
    mc "We're at a... pizzeria?"

    scene e2s5-03 with dissolve
    pause

    play music french_toast
    scene e2s5-04 with dissolve
    jon "Ayoo!"
    jon "What's up?"

    scene e2s5-05 with dissolve
    jd "Hey guys, how are you doing?"

    scene e2s5-06 with dissolve
    mc "[jd]?"

    scene e2s5-07 with dissolve
    mc "I didn't know you were working at a pizzeria."

    scene e2s5-08 with dissolve
    jd "It's my uncle's pizzeria."

    scene e2s5-09 with dissolve
    jd "I can't say I'm really a worker here."

    scene e2s5-10 with dissolve
    jd "But I do come from time to time to help around."

    scene e2s5-11 with dissolve
    jd "Plus that I can get free meals every time I come here."

    scene e2s5-12 with dissolve
    jd "Of course, if I cook them."

    scene e2s5-13 with dissolve
    jd "Like this pizza!"

    scene e2s5-14 with dissolve
    jd "Check this out!"

    scene e2s5-15 with dissolve
    pause

    scene e2s5-16 with dissolve
    pause

    scene e2s5-17 with dissolve
    pause

    play sound punch
    scene e2s5-18 with vpunch
    pause

    scene e2s5-19 with dissolve
    jon "Sweeet!"

    scene e2s5-20 with dissolve
    jd "So, what brings you to our pizzeria guys?"

    scene e2s5-21 with dissolve
    jon "Tonight we're gonna have a party."

    scene e2s5-22 with dissolve
    jd "Thank God!"
    jd "At last... some good news."

    scene e2s5-23 with dissolve
    jd "Where are we crashing?"

    scene e2s5-21 with dissolve
    jon "[ro] said that he wants to make up for his missed parties."

    scene e2s5-24 with dissolve
    jon "He knows a guy who has a house nearby."

    scene e2s5-21 with dissolve
    jon "[ro] convinced him to let us hold a party there."

    scene e2s5-25 with dissolve
    jd "That's awesome!"

    scene e2s5-26 with dissolve
    jon "Wait, that's not even the best part."
    jon "We don't even need to buy anything."

    scene e2s5-24 with dissolve
    jon "All drinks and food are provided by that guy."

    scene e2s5-27 with dissolve
    jd "Hold up..."

    scene e2s5-23 with dissolve
    jd "Is that guy some kind of wealthy man or how could he afford to pay for everything?"

    scene e2s5-21 with dissolve
    jon "His only condition was that we bring some chicks."

    scene e2s5-28 with dissolve
    jd "Haha, we both know that's not an issue."

    scene e2s5-20 with dissolve
    jd "I'm gonna start making some phone calls."

    scene e2s5-31 with dissolve
    pause

    play sound woosh
    scene e2s5-29 with dissolve
    pause

    play sound punch
    scene e2s5-30 with vpunch
    pause

    scene e2s5-32 with dissolve
    pause

    scene e2s5-33 with dissolve
    jd "Uhh... I think it will be better if you guys leave."

    scene e2s5-24 with dissolve
    jon "Alright, no worries."

    scene e2s5-21 with dissolve
    jon "We'll keep in touch."

    scene e2s5-34 with dissolve
    jd "Alright, catch you later!"

    scene e2s5-35 with dissolve
    if affinity_spectrum < 0:
        mc "Bye!"
    else:
        mc "See you!"

    scene e2s5-36 with dissolve
    pause

    scene e2s5-37 with dissolve
    pause

    scene e2s5-38 with dissolve
    jd "Good day, sir!"

    stop music fadeout 2.0
    stop sound fadeout 2.0
    scene e2s5-39 with dissolve
    pause

    play music sun_sets_on_a_protagonist
    scene e2s5-40 with dissolve
    mc "So does [jd] know about the Party Ragers?"

    scene e2s5-41 with dissolve
    jon "He knows but he doesn't really want to be involved."

    scene e2s5-42 with dissolve
    jon "He only likes to party."
    jon "His only request was that we invite him to our parties."

    scene e2s5-43 with dissolve
    show e2s5-jon_blink1
    mc "I see."
    mc "Are you coming to classes today?"

    scene e2s5-42 with dissolve
    hide e2s5-jon_blink1
    jon "Yeah, my job at Eddy's is done."

    scene e2s5-43 with dissolve
    show e2s5-jon_blink1
    mc "Oh, by the way..."
    mc "With that party ragers thing... where are you guys seeing each other?"

    scene e2s5-44 with dissolve
    hide e2s5-jon_blink1
    jon "Well, theoretically Eddy's was our place."
    jon "But since it's being fixed up now, unfortunately we can't go there."

    scene e2s5-42 with dissolve
    jon "We had to resign."

    scene e2s5-41 with dissolve
    jon "Everyone agreed that my place is the best fit for a replacement."

    scene e2s5-43 with dissolve
    show e2s5-jon_blink1
    mc "You can't be serious..."

    scene e2s5-45 with dissolve
    hide e2s5-jon_blink1
    jon "Nope, I can't!"

    scene e2s5-46 with dissolve
    jon "We talked to the college staff and they've let us borrow one of their classrooms."

    scene e2s5-47 with dissolve
    jon "We're technically a part of the college groups, so..."

    scene e2s5-48 with dissolve
    mc "I see."

    scene e2s5-49 with dissolve
    jon "Yeah... the only thing is that they have to set up the class in order to fit our criteria."

    scene e2s5-50 with dissolve
    jon "But they can handle that by themselves."

    scene e2s5-51 with dissolve
    mc "But how did the college agree to have you there with all the alcohol and stuff?"

    scene e2s5-52 with dissolve
    jon "We told them there won't be any partying or drinking going on in that class."

    scene e2s5-53 with dissolve
    jon "We lied of course, couldn't let such opportunity go to waste."

    scene e2s5-54 with dissolve
    jon "But imagine the amount of parties we can hold on campus grounds!"

    scene e2s5-55 with dissolve
    jon "And how many people could show up to them."

    stop music fadeout 2.0
    scene e2s5-56 with dissolve
    jon "Until Eddy's is ready again, we're gonna make the most of this time."

    jump e2s6
return
