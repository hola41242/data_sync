
# Variables ####################################################################

default e2s12_thumbs_up = 0
default e2s12_thumbs_down = 0

# Scene 12 - Cleo's hangout ####################################################

label e2s12:
    $ time_start = 0
    $ time_max = 1.0
    $ time_max = 0.01

    scene e2s12-01 with wipeleft
    mc "*Hmm... I wonder what [cl]'s been doing.*"
    mc "*It's been a while since we last hung out.*"
    mc "*Maybe she can help me pick a gift for [ke].*"

    scene e2s12-02 with dissolve
    nvl clear
    n_nvl "Hey [cl], what's up?"
    cl_nvl "Nothing much, at work."
    cl_nvl "Wbu?"
    n_nvl "Just got out of college."
    n_nvl "Wanna hang out later?"
    cl_nvl "Sure, come to the diner."
    cl_nvl "I'm gonna finish my shift in 20 minutes."
    n_nvl "Alright, I'll be there."
    cl_nvl ":)"

    play music laurel_breeze
    scene e2s12-03 with wipeleft
    mc "*Alright... I'm here.*"

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e2s12-04 with dissolve
    mc "I think I'm gonna sit here."

    scene e2s12-05 with dissolve
    pause

    scene e2s12-06 with dissolve
    pause

    scene e2s12-08 with dissolve
    cl "Hey [mc]!"

    scene e2s12-07 with dissolve
    show e2s12-cleo_blink1
    mc "Hello [cl]!"

    scene e2s12-08 with dissolve
    hide e2s12-cleo_blink1
    cl "Would you like to order something?"

    scene e2s12-07 with dissolve
    show e2s12-cleo_blink1
    mc "A coffee is fine."

    scene e2s12-09 with dissolve
    hide e2s12-cleo_blink1
    cl "Alright, let me know if you need anything else."

    scene e2s12-07 with dissolve
    show e2s12-cleo_blink1
    mc "Sure!"

    scene e2s12-10 with dissolve
    hide e2s12-cleo_blink1
    pause

    scene e2s12-11 with dissolve
    pause

    if e1s15_gfpretend == False:
        stop music fadeout 1.0
        unknown "Well, well..."

        scene e2s12-12 with dissolve
        play music dances_and_dames
        pause

        scene e2s12-14 with dissolve
        da "Look who's at my diner."

        scene e2s12-13 with dissolve
        show e2s12-darryl_blink1
        mc "Keep walking, I'm not in the mood."

        scene e2s12-15 with dissolve
        hide e2s12-darryl_blink1
        da "Oh, poor princess is scared of a little talk?"

        scene e2s12-16 with dissolve
        da "She's mine, you know?"

        scene e2s12-14 with dissolve
        da "It's only a matter of time until she sees that."

        scene e2s12-13 with dissolve
        show e2s12-darryl_blink1
        mc "Haha, she wouldn't go out with a scum like you even if you were the only man left in the world."

        scene e2s12-17 with dissolve
        hide e2s12-darryl_blink1
        da "You can talk as much as you want."

        scene e2s12-15 with dissolve
        da "But right now, I've got the upper hand."

        scene e2s12-13 with dissolve
        show e2s12-darryl_blink1
        mc "Haha, I can't believe there's actually a real human being talking like that!"
        mc "You're just living off of fantasies dude."

        stop music fadeout 2.0
        scene e2s12-18 with dissolve
        hide e2s12-darryl_blink1
        pause

        scene e2s12-11 with dissolve
        pause

        if affinity_spectrum > 0:
            scene e2s12-40 with dissolve
            mc "*Damn, I can't believe that guy!*"

    scene e2s12-19 with dissolve
    if e1s15_gfpretend == False:
        play music laurel_breeze
    pause

    scene e2s12-20 with dissolve
    cl "Here's your coffee!"

    scene e2s12-21 with dissolve
    pause

    scene e2s12-22 with dissolve
    show e2s12-cleo_blink1
    mc "Thank you [cl]."

    scene e2s12-23 with dissolve
    hide e2s12-cleo_blink1
    cl "You're welcome!"

    scene e2s12-24 with dissolve
    pause

    scene e2s12-25 with dissolve
    stop music fadeout 2.0
    unknown "Hey bitch, are you deaf?"

    play music rollin_at_5
    scene e2s12-26 with dissolve
    unknown "I've been calling you for a while to take my order."

    scene e2s12-27 with dissolve
    cl "I'm so sorry sir, please, what would you like to order?"

    scene e2s12-28 with dissolve
    unknown "They hire the worst fucking bike handles in this dump."

    scene e2s12-29 with dissolve
    mc "*What's wrong with that guy?*"
    menu:
        "Intervene":
            scene e2s12-30 with dissolve
            pause

            scene e2s12-31 with dissolve
            show e2s12-unknown_blink1
            mc "Hey, 'bike handle'."
            mc "This isn't your diner to scream at everyone however you want."
            mc "She was busy, if you can't wait 2 minutes then leave."

            scene e2s12-32 with dissolve
            hide e2s12-unknown_blink1
            unknown "What the fuck is your problem?"

            scene e2s12-34 with dissolve
            unknown "I was talking to her, not you."

            scene e2s12-31 with dissolve
            show e2s12-unknown_blink1
            mc "Yeah, but I can't just stand here while you scream and swear at her."

            scene e2s12-33 with dissolve
            hide e2s12-unknown_blink1
            cl "[mc]... that's enough."

            scene e2s12-32 with dissolve
            unknown "So you're telling me how to behave now?"

            scene e2s12-34 with dissolve
            unknown "Maybe you should be taught a lesson."

            scene e2s12-31 with dissolve
            show e2s12-unknown_blink1
            menu:
                "Back off":
                    $ cleo_trust += 1
                    mc "*Man, this guy is a bastard.*"
                    mc "*Fighting him is not worth it.*"
                    mc "There's no need for a fight."
                    mc "I've just asked you to stop swearing at the girl, alright?"
                    mc "Let's not escalate into something else."

                    scene e2s12-35 with dissolve
                    hide e2s12-unknown_blink1
                    unknown "Fucking morons running this place..."

                    scene e2s12-36 with dissolve
                    unknown "Just give me a burger menu with fries and coke."

                    scene e2s12-37 with dissolve
                    cl "Alright sir, coming right up!"
                    cl "Excuse me again for not hearing you."

                    scene e2s12-38 with dissolve
                    pause

                    scene e2s12-06 with dissolve
                    pause

                    scene e2s12-41 with dissolve
                    cl "[mc], what are you doing?"

                    scene e2s12-39 with dissolve
                    show e2s12-cleo_blink2
                    mc "That guy's an asshole, I couldn't just stand and watch."

                    scene e2s12-42 with dissolve
                    hide e2s12-cleo_blink2
                    cl "Look, I appreciate you trying to help and all..."

                    scene e2s12-43 with dissolve
                    cl "But you can't just start a fight with everyone you see."

                    scene e2s12-41 with dissolve
                    cl "Most of these guys are assholes and they talk like that and scream like that."
                    cl "Best thing I can do for my own and everyone else's good is to just apologise and go on with my day."

                    scene e2s12-44 with dissolve
                    cl "Please, don't do that ever again."

                    scene e2s12-42 with dissolve
                    cl "Especially at the diner, I don't want any trouble with my boss."

                    scene e2s12-39 with dissolve
                    show e2s12-cleo_blink2
                    mc "Alright [cl], I'm sorry!"
                    mc "I was just trying to help, you know the situation better than me."

                    scene e2s12-45 with dissolve
                    hide e2s12-cleo_blink2
                    cl "Thank you [mc]!"

                    scene e2s12-24 with dissolve
                    pause

                "Fight him" if affinity_spectrum >=0:
                    stop sound
                    play music welcome_to_zombie_coast
                    $ e2s12_fight = True
                    $ cleo_trust -= 1

                    mc "Alright fuck face, bring it on!"

                    scene e2s12-46 with dissolve

                    if persistent.fight == 0:
                        $ qte_pos_count = 0
                        $ qte_neg_count = 0

                        call qte from _call_qte_15

                        if qte == True:
                            play sound punch
                            scene e2s12-47 with vpunch
                            call qte from _call_qte_16
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-48 behind miss_screen with vpunch
                            call qte from _call_qte_17

                        if qte == True:
                            play sound woosh
                            scene e2s12-50 with vpunch
                            hide e2s12-48
                            call qte from _call_qte_18
                        else:
                            play sound punch
                            show miss_screen at miss_anim
                            show e2s12-49 behind miss_screen with vpunch
                            hide e2s12-48
                            call qte from _call_qte_19

                        if qte == True:
                            play sound punch
                            scene e2s12-51 with vpunch
                            hide e2s12-49
                            call qte from _call_qte_20
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-52 behind miss_screen with vpunch
                            hide e2s12-49
                            call qte from _call_qte_21

                        if qte == True:
                            play sound punch
                            scene e2s12-47 with vpunch
                            hide e2s12-52
                            call qte from _call_qte_22
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-48 behind miss_screen with vpunch
                            hide e2s12-52
                            call qte from _call_qte_23

                        if qte == True:
                            play sound punch
                            scene e2s12-53 with vpunch
                            hide e2s12-48
                            call qte from _call_qte_24
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-54 behind miss_screen with vpunch
                            hide e2s12-48
                            call qte from _call_qte_25

                        if qte == True:
                            play sound woosh
                            scene e2s12-50 with vpunch
                            hide e2s12-54
                            call qte from _call_qte_26
                        else:
                            play sound punch
                            show miss_screen at miss_anim
                            show e2s12-49 behind miss_screen with vpunch
                            hide e2s12-54
                            call qte from _call_qte_27

                        if qte == True:
                            play sound punch
                            scene e2s12-51 with vpunch
                            hide e2s12-49
                            call qte from _call_qte_28
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-52 behind miss_screen with vpunch
                            hide e2s12-49
                            call qte from _call_qte_29

                        if qte == True:
                            play sound punch
                            scene e2s12-47 with vpunch
                            hide e2s12-52
                            call qte from _call_qte_30
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-48 behind miss_screen with vpunch
                            hide e2s12-52
                            call qte from _call_qte_31

                        if qte == True:
                            play sound punch
                            scene e2s12-53 with vpunch
                            hide e2s12-48
                            pause(1.0)
                        else:
                            play sound woosh
                            show miss_screen at miss_anim
                            show e2s12-54 behind miss_screen with vpunch
                            hide e2s12-48
                            pause(1.0)

                        if qte_neg_count == 0:
                            $ strength += 1
                            if persistent.tr_gallery_7_unlocked == False:
                                $ persistent.tr_gallery_7_unlocked = True
                                $ renpy.show_screen("render_notify")
                                $ persistent.tracy7 = True
                                python:
                                    update_tracy_list()

                        if qte_pos_count > qte_neg_count:
                            $ qte_pos_count = 0
                            $ qte_neg_count = 0

                            play sound punch
                            scene e2s12-51 with vpunch
                            pause(1.0)

                            scene e2s12-55 with dissolve
                            pause

                            scene e2s12-57 with dissolve
                            cl "[mc], stop!!"

                        if qte_pos_count < qte_neg_count:
                            $ qte_pos_count = 0
                            $ qte_neg_count = 0

                            play sound punch
                            scene e2s12-49 with vpunch
                            pause(1.0)

                            scene e2s12-56 with dissolve
                            pause
                    else:
                        pause

                        play sound punch
                        scene e2s12-47 with vpunch
                        pause

                        play sound woosh
                        scene e2s12-48 with vpunch
                        pause

                        play sound punch
                        scene e2s12-49 with vpunch
                        pause

                        play sound woosh
                        scene e2s12-50 with vpunch
                        pause

                        play sound punch
                        scene e2s12-51 with vpunch
                        pause

                        play sound woosh
                        scene e2s12-52 with vpunch
                        pause

                        play sound punch
                        scene e2s12-53 with vpunch
                        pause

                        scene e2s12-55 with dissolve
                        pause

                        scene e2s12-57 with dissolve
                        cl "[mc], stop!!"

                    stop music fadeout 2.0
                    scene e2s12-58 with dissolve
                    da "Enough, break it up!"

                    scene e2s12-59 with dissolve
                    unknown "You're lucky this guy intervened."

                    scene e2s12-60 with dissolve
                    unknown "I would've beat your ass!"

                    scene e2s12-61 with dissolve
                    pause

                    scene e2s12-62 with dissolve
                    pause

                    scene e2s12-63 with dissolve
                    cl "[mc], what do you think you're doing?"

                    scene e2s12-64 with dissolve
                    show e2s12-cleo_blink3
                    mc "I couldn't just let him talk to you like that."

                    scene e2s12-65 with dissolve
                    hide e2s12-cleo_blink3
                    cl "Dude, you started that fight out of nothing, you need to take control of yourself!"

                    scene e2s12-66 with dissolve
                    cl "I just hope my boss isn't mad..."

                    scene e2s12-64 with dissolve
                    show e2s12-cleo_blink3
                    mc "[cl], I'm sorry..."

                    scene e2s12-67 with dissolve
                    hide e2s12-cleo_blink3
                    cl "Just leave!"

                    scene e2s12-66 with dissolve
                    cl "I will have to work overtime to fix this mess."

                    scene e2s12-68 with dissolve
                    pause

                    scene e2s12-69 with dissolve
                    mc "*Fuck... I messed this up big time, didn't I?*"

                    scene e2s12-70 with dissolve
                    pause

                    scene e2s12-71 with dissolve
                    da "Hey [cl], is everything alright?"

                    scene e2s12-72 with dissolve
                    cl "Go away [da], I don't wanna talk to you."

                    scene e2s12-73 with dissolve
                    pause

                    scene e2s12-74 with dissolve
                    pause

                    scene e2s12-75 with dissolve
                    mc "*Son of a bitch.*"
                    mc "*That's what you wanted, isn't it?*"

                    scene e2s12-76 with dissolve
                    pause

                    jump e2s13

        "Only if things escalate":
            $ cleo_trust += 1
            mc "*I'll wait and intervene only if things escalate.*"

            scene e2s12-28 with dissolve
            unknown "*Alright, uhh...*"

            scene e2s12-36 with dissolve
            unknown "Just give me a burger menu with fries and coke."

            scene e2s12-37 with dissolve
            cl "Alright sir, coming right up!"
            cl "Excuse me again for not hearing you."

    stop sound fadeout 2.0
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene e2s12-11 with Dissolve(2.0)
    $renpy.sound.play("audio/sfx/crowded_venue.ogg", loop=True)
    pause

    play music mom_n_pa
    scene e2s12-06 with dissolve
    pause

    scene e2s12-41 with dissolve
    cl "Alright, this is the end of my shift."

    scene e2s12-42 with dissolve
    cl "Thank God, finally!"

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "I get you've had a tough day, right?"

    scene e2s12-41 with dissolve
    hide e2s12-cleo_blink2
    cl "Every day is a tough day."

    scene e2s12-45 with dissolve
    cl "But anyways, how are you [mc]?"
    cl "How was the coffee?"

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "It was alright, thanks [cl]!"

    scene e2s12-41 with dissolve
    hide e2s12-cleo_blink2
    cl "Don't mention it."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "So, who's gonna take care of the remaining customers?"

    scene e2s12-43 with dissolve
    hide e2s12-cleo_blink2
    cl "[da], of course."

    scene e2s12-41 with dissolve
    cl "Also, this was someone else's shift but they couldn't make it today."
    cl "That's why I got off earlier."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "Oh, I understand."
    mc "So this means that for your shift you'll get off early again?"

    scene e2s12-41 with dissolve
    hide e2s12-cleo_blink2
    cl "I hope so."

    scene e2s12-42 with dissolve
    cl "In theory, that should be the case."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "I see."
    mc "So, should we go?"

    scene e2s12-45 with dissolve
    hide e2s12-cleo_blink2
    cl "Yeah, hold on!"

    scene e2s12-77 with dissolve
    cl "Let me grab my coat."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "Coat?"
    mc "Isn't it like 100 degrees outside?"

    scene e2s12-43 with dissolve
    hide e2s12-cleo_blink2
    cl "I'm not going out there dressed like this."

    scene e2s12-78 with dissolve
    cl "I'd rather sweat a little than have every pervert's eyes on me."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "Fair enough."

    scene e2s12-79 with dissolve
    hide e2s12-cleo_blink2
    cl "We could go to my apartment to get changed if that's okay with you."

    scene e2s12-39 with dissolve
    show e2s12-cleo_blink2
    mc "Alright, no problem."

    scene e2s12-45 with dissolve
    hide e2s12-cleo_blink2
    cl "Good, be right back!"

    stop sound fadeout 1.0

    scene e2s12-80 with wipeleft
    hide e2s12-cleo_blink2
    pause

    scene e2s12-81 with dissolve
    cl "So, how was your day [mc]?"
    cl "We've talked about mine, let's hear about yours."

    scene e2s12-82 with dissolve
    mc "It wasn't that bad to be honest."
    mc "Nothing out of the ordinary."
    mc "Just that I lost my keys last night and found them today."

    scene e2s12-83 with dissolve
    cl "Oh, how did that happen?"

    scene e2s12-84 with dissolve
    mc "I don't know to be honest..."
    mc "I remember that I went to a party and things kind of got out of hand and people started fighting."
    mc "But I didn't get involved so I don't know how I could have dropped them."

    scene e2s12-85 with dissolve
    cl "How did you find them?"

    scene e2s12-86 with dissolve
    mc "Today my friend [jon] wanted to introduce me to the party ragers."
    mc "Long story short things didn't really go according to plan but their president gave them back to me."

    scene e2s12-87 with dissolve
    cl "Haha, that's weird!"
    cl "How did they have them?"

    scene e2s12-88 with dissolve
    mc "That's what I've been asking myself."
    mc "But who knows?"
    mc "If they wanted to steal anything from me I didn't have anything precious to begin with."
    mc "My roommate wasn't home either so I don't know what their deal was."
    mc "But you know... anyways."

    scene e2s12-89 with dissolve
    cl "Wait, but, if you didn't have your key, where did you sleep?"

    scene e2s12-90 with dissolve
    if e2s10_jon == True:
        mc "Oh... well... I just slept at [jon]'s."
        mc "I was with him after all, so it was pretty convenient."

        scene e2s12-91 with dissolve
        cl "Haha, how was the couch?"

        scene e2s12-93 with dissolve
        mc "Oh, don't ask me about it."
        mc "I'm glad I found them this fast."

        scene e2s12-95 with dissolve
        cl "Haha, I'm happy to see you're having fun!"

        scene e2s12-98 with dissolve
        mc "Yeah, and what fun I've had..."

        scene e2s12-99 with dissolve
        cl "Haha!"
    else:
        menu:
            "Lie":
                $ e2s12_lie = True
                mc "Oh... well... I just slept at [jon]'s."
                mc "I was with him after all, so it was pretty convenient."

                scene e2s12-91 with dissolve
                cl "Haha, how was the couch?"

                scene e2s12-93 with dissolve
                mc "Oh, don't ask me about it."
                mc "I'm glad I found them this fast."

                scene e2s12-95 with dissolve
                cl "Haha, I'm happy to see you're having fun!"

                scene e2s12-98 with dissolve
                mc "Yeah, and what fun I've had..."

                scene e2s12-99 with dissolve
                cl "Haha!"
            "Truth":
                $ e2s12_lie = False
                mc "Oh... well... there was this girl friend that was pretty close to my place so I just slept at her place."

                if cleo_trust >= 3:
                    scene e2s12-92 with dissolve
                    cl "Oh, I see."

                    scene e2s12-94 with dissolve
                    cl "You know, I would have helped you as well."
                    cl "If you needed a place to sleep I could have helped you."

                    scene e2s12-96 with dissolve
                    mc "Wouldn't that have been a problem with your boss and [da]?"

                    scene e2s12-97 with dissolve
                    cl "Oh..."
                    cl "Uh... right."
                    cl "Yeah, I most probably couldn't have helped you anyways."
                    cl "That was stupid."
                else:
                    scene e2s12-91 with dissolve
                    cl "Oh, I see."
                    cl "Glad to hear you weren't homeless, [mc]."

                    scene e2s12-93 with dissolve
                    mc "Haha, I'm glad as well!"
                    mc "To be honest if I didn't have anyone's to sleep at I would have called [jon] as a last resort."
                    mc "So I wouldn't have been homeless."

                    scene e2s12-95 with dissolve
                    cl "I really don't think you would have preferred his couch."

                    scene e2s12-98 with dissolve
                    mc "Haha, totally wouldn't!"

    scene e2s12-100 with dissolve
    cl "Hey, we're here!"

    scene e2s12-101 with wipeleft
    pause

    scene e2s12-102 with dissolve
    mc "Hey [cl]!"
    mc "After this, if you don't mind, could you help me buy a gift for my friend?"
    mc "It's his birthday today and I don't really know what to get him."

    scene e2s12-103 with dissolve
    cl "Sure [mc], it's no problem."
    cl "I know a store nearby."

    scene e2s12-104 with dissolve
    mc "Alright, thanks!"

    scene e2s12-105 with dissolve
    pause

    stop music fadeout 2.0

    call e2s12_cleo_lewd from _call_e2s12_cleo_lewd

    scene black with Dissolve(2.0)

    scene e2s12-108 with Dissolve(2.0)
    pause

    scene e2s12-116 with dissolve
    cl "Alright, I'm ready!"

    play music the_pawnbrokers_stepdaughter
    scene e2s12-130 with dissolve
    menu:
        "Compliment her outfit":
            $ cleo_trust += 1
            mc "You look really cute in that outfit."

            scene e2s12-131 with dissolve
            cl "Hehe, thanks!"

            scene e2s12-130 with dissolve

        "Don't say anything":
            pass

    mc "Okay, let's go!"

    stop music fadeout 2.0
    scene e2s12-132 with dissolve
    pause

    scene e2s12-133 with wipeleft
    play music sun_sets_on_a_protagonist
    pause

    scene e2s12-135 with dissolve
    cl "Alright, so what does your friend like?"
    cl "Does he have any prefferences for a gift, or...?"

    scene e2s12-134 with dissolve
    show e2s12-cleo_blink4
    mc "Well... from what [jon] told me, he doesn't want money."
    mc "So we can tick that off the list."
    mc "He also said that I should get him something that he'll remember."

    scene e2s12-136 with dissolve
    hide e2s12-cleo_blink4
    cl "Hmmm..."

    scene e2s12-135 with dissolve
    cl "Anything else?"

    scene e2s12-134 with dissolve
    show e2s12-cleo_blink4
    mc "Well... nothing really."
    mc "He said to avoid basic stuff like mugs and things like that."

    scene e2s12-137 with dissolve
    hide e2s12-cleo_blink4
    cl "I understand."

    scene e2s12-135 with dissolve
    cl "Well... let's have a look around, shall we?"

    scene e2s12-134 with dissolve
    show e2s12-cleo_blink4
    mc "Alright!"

    scene e2s12-133 with dissolve
    hide e2s12-cleo_blink4
    pause

    scene e2s12-138 with dissolve
    pause

    scene e2s12-139 with dissolve
    cl "Hey, how about this one?"
    mc "Eh... I don't know."

    scene e2s12-140 with dissolve
    show e2s12-cleo_blink6
    mc "Seems a bit too casual for him."

    scene e2s12-141 with dissolve
    hide e2s12-cleo_blink6
    cl "Alright."

    scene e2s12-142 with dissolve
    pause

    scene e2s12-143 with dissolve
    pause

    scene e2s12-144 with dissolve
    pause

    if affinity_spectrum <= 0:
        $ e2s12_gift = True
        scene e2s12-145 with dissolve
        pause

        scene e2s12-146 with dissolve
        mc "Hey, look, I think this one would be great."

        scene e2s12-147 with dissolve
        pause

        scene e2s12-148 with dissolve
        cl "Do you think he'll like it?"

        scene e2s12-149 with dissolve
        mc "I mean, I think it's really funny."
        mc "And it does suit him."
        mc "It's something memorable."

        scene e2s12-150 with dissolve
        cl "Hmm, alright!"
        cl "Let's buy it."

        scene e2s12-151 with dissolve
        pause

        scene black with Dissolve(2.0)

        scene e2s12-152 with Dissolve(2.0)
        cl "Well, we got the t-shirt now."

        scene e2s12-153 with dissolve
        cl "What shall we do next?"

        scene e2s12-154 with dissolve
        show e2s12-cleo_blink5
        mc "I don't know."
        mc "I guess we could try some clothes ourselves while we're still here."

        scene e2s12-155 with dissolve
        hide e2s12-cleo_blink5
        cl "Haha, I'd like that!"

        scene e2s12-156 with dissolve
        pause

        scene e2s12-159 with dissolve
        cl "Hey, look at this one!"
    else:
        scene e2s12-159 with dissolve
        cl "How about this one?"

    scene e2s12-160 with dissolve
    mc "Haha, seems like something I would wear."

    scene e2s12-157 with dissolve
    cl "I'd love to see you try it then."

    scene e2s12-158 with dissolve
    mc "You really think it'd fit me?"

    scene e2s12-161 with dissolve
    cl "I don't know, that's what trying is for, right?"

    scene e2s12-158 with dissolve
    mc "I guess you're right."

    stop music fadeout 2.0
    scene e2s12-162 with dissolve
    pause

    scene e2s12-163 with wipeleft
    pause

    scene e2s12-164 with dissolve
    pause

    play music liar
    scene e2s12-168 with dissolve
    pause

    scene e2s12-171 with dissolve
    pause

    scene e2s12-169 with dissolve
    pause

    scene e2s12-170 with dissolve
    pause

    scene e2s12-166 with dissolve
    pause

    scene e2s12-165 with dissolve
    cl "*Damn...*"

    stop music
    scene e2s12-167 with vpunch
    pause

    scene e2s12-172 with dissolve
    pause

    scene e2s12-173 with dissolve
    pause

    scene e2s12-173-1 with dissolve
    pause

    play music sun_sets_on_a_protagonist
    scene e2s12-174 with dissolve
    pause

    scene e2s12-175 with dissolve
    cl "Hahaha, I don't think it fits you [mc]!"

    scene e2s12-176 with dissolve
    mc "Really?"
    mc "I didn't notice."

    scene e2s12-175 with dissolve
    cl "Haha, go get changed back."

    scene e2s12-177 with dissolve
    pause

    scene black with Dissolve(2.0)

    scene e2s12-178 with Dissolve(2.0)
    pause

    scene e2s12-179 with dissolve
    pause

    scene e2s12-180 with dissolve
    cl "Come on, let's look around."

    scene e2s12-181 with dissolve
    cl "I'd like to try some clothes as well."

    stop music fadeout 2.0
    scene e2s12-182 with dissolve
    mc "Okay."

    play music hi_as_hats
    scene e2s12-162 with wipeleft
    pause

    scene e2s12-156 with dissolve
    pause

    scene e2s12-211 with dissolve
    pause

    scene e2s12-212 with dissolve
    pause

    scene e2s12-213 with dissolve
    pause

    scene e2s12-214 with dissolve
    menu:
        "Thumbs up":
            $ e2s12_thumbs_up += 1
            scene e2s12-215 with dissolve
            pause

        "Thumbs down":
            $ e2s12_thumbs_down += 1
            scene e2s12-216 with dissolve
            pause

    scene e2s12-217 with dissolve
    menu:
        "Thumbs up":
            $ e2s12_thumbs_up += 1
            $ e2s12_cleo_dress = True
            scene e2s12-215 with dissolve
            pause

        "Thumbs down":
            $ e2s12_thumbs_down += 1
            scene e2s12-216 with dissolve
            pause

    scene e2s12-218 with dissolve
    menu:
        "Thumbs up":
            $ e2s12_thumbs_up += 1
            scene e2s12-215 with dissolve
            pause

        "Thumbs down":
            $ e2s12_thumbs_down += 1
            scene e2s12-216 with dissolve
            pause

    scene e2s12-219 with dissolve
    menu:
        "Thumbs up":
            $ e2s12_thumbs_up += 1
            scene e2s12-215 with dissolve
            pause

        "Thumbs down":
            $ e2s12_thumbs_down += 1
            scene e2s12-216 with dissolve
            pause

    scene e2s12-220 with dissolve
    menu:
        "Thumbs up":
            $ e2s12_thumbs_up += 1
            scene e2s12-215 with dissolve
            pause

        "Thumbs down":
            $ e2s12_thumbs_down += 1
            scene e2s12-216 with dissolve
            pause

    if e2s12_thumbs_up > e2s12_thumbs_down:
        call extrovert_affinity_check from _call_extrovert_affinity_check_39
        call color_check from _call_color_check_74
    else:
        call introvert_affinity_check from _call_introvert_affinity_check_32
        call color_check from _call_color_check_75

    if e2s12_thumbs_up == 5:
        scene e2s12-181 with dissolve
        cl "Damn, you really like all my outfits, don't you?"
    else:
        scene e2s12-181 with dissolve

    cl "Alright, now it's my turn to be the judge!"

    if affinity_spectrum > 0:
        scene e2s12-221 with dissolve
        pause

        scene e2s12-227 with dissolve
        pause

        scene e2s12-222 with dissolve
        pause

        scene e2s12-228 with dissolve
        pause

        scene e2s12-223 with dissolve
        pause

        scene e2s12-228 with dissolve
        pause
    else:
        scene e2s12-224 with dissolve
        pause

        scene e2s12-227 with dissolve
        pause

        scene e2s12-225 with dissolve
        pause

        scene e2s12-227 with dissolve
        pause

        scene e2s12-226 with dissolve
        pause

        scene e2s12-227 with dissolve
        pause

    scene e2s12-183 with dissolve
    pause

    scene e2s12-184 with dissolve
    pause

    scene e2s12-185 with vpunch
    cl "No, no, no!"

    scene e2s12-186 with dissolve
    cl "That one was for me, hahaha!"

    play sound clothes_rip
    scene e2s12-187 with dissolve
    mc "Oh shit, I think it ripped."

    scene e2s12-188 with dissolve
    cl "Oh my God, quick, put it back!"

    scene e2s12-206 with wipeleft
    pause

    play sound woosh
    scene e2s12-207 with vpunch
    pause

    scene e2s12-208 with dissolve
    pause

    scene e2s12-209 with dissolve
    pause

    scene e2s12-210 with dissolve
    pause

    scene e2s12-189 with wipeleft
    pause

    scene e2s12-190 with dissolve
    pause

    scene e2s12-191 with dissolve
    pause

    scene e2s12-192 with dissolve
    mc "*Hehehe...*"

    scene e2s12-193 with dissolve
    mc "Excuse me miss..."

    scene e2s12-194 with dissolve
    mc "Have you seen my pantaloons?"

    scene e2s12-195 with dissolve
    cl "Oh, my pleasure it is sir, absolutely, your pantaloons are right over there!"

    scene e2s12-196 with vpunch
    mc "Aaah!"

    scene e2s12-197 with dissolve
    cl "Haha, we both thought of the same thing!"

    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene e2s12-140 with Dissolve(2.0)
    show e2s12-cleo_blink6
    mc "Alright, thanks for the help [cl]!"
    if affinity_spectrum > 0:
        mc "Even if we didn't manage to buy anything... I really appreciate it."

        scene e2s12-198 with dissolve
        hide e2s12-cleo_blink6
        cl "Don't mention it, [mc]."
        cl "Have fun at the party!"

        scene e2s12-140 with dissolve
        show e2s12-cleo_blink6
    else:
        scene e2s12-198 with dissolve
        hide e2s12-cleo_blink6
        cl "Tell me if he likes what we got him, alright?"

        scene e2s12-140 with dissolve
        show e2s12-cleo_blink6
        mc "Haha, sure, I'll keep you posted!"

    mc "Bye [cl]!"

    scene e2s12-199 with dissolve
    hide e2s12-cleo_blink6
    cl "Good bye [mc]!"

    scene e2s12-200 with dissolve
    pause

    if affinity_spectrum > 0:
        scene e2s12-201 with wipeleft
        pause

        scene e2s12-202 with dissolve
        pause

        scene e2s12-203 with dissolve
        pause

        scene e2s12-204 with dissolve
        pause

        scene e2s12-205 with dissolve
        pause

    jump e2s13
return

label e2s12_cleo_lewd:
    play music one_fine_day
    play sound door_open
    scene e2s12-106 with dissolve
    cl "Alright so... this is where I live."

    scene e2s12-107 with dissolve
    cl "I'm gonna get changed, be right back."
    cl "You can take a seat on the couch."

    scene e2s12-109 with dissolve
    mc "Thanks [cl]!"

    scene e2s12-110 with dissolve
    pause

    scene e2s12-111 with dissolve
    cl "Hey, also, I know this might be a little weird."

    scene e2s12-112 with dissolve
    cl "But don't make any loud noises, alright?"
    cl "This apartment has really thin walls."

    scene e2s12-113 with dissolve
    cl "And I mean, literally, almost anything can be heard through them."

    scene e2s12-114 with dissolve
    mc "Don't worry, I'll be light as a feather!"

    scene e2s12-115 with dissolve
    pause

    scene e2s12-108 with dissolve
    pause
    mc "*Damn... I really need to pee.*"
    mc "*I should have asked her about the bathroom before she left to get changed.*"

    scene e2s12-116 with dissolve
    pause

    scene e2s12-117 with dissolve
    mc "*Hmm... is this the bathroom?*"
    mc "*I don't know where [cl] went and I don't want to shout for her.*"

    scene e2s12-118 with dissolve
    mc "*Let's try this door.*"

    stop music fadeout 2.0
    play sound door_open
    scene e2s12-119 with dissolve
    pause

    if persistent.disable_nsfw == True:
        scene e2s12-120 with dissolve
        pause
    else:
        if persistent.type_nsfw == False:
            scene e2s12-120_cen with dissolve
            pause

    play music electric_girlfriend
    scene e2s12-121 with vpunch
    cl "[mc]?!"

    scene e2s12-122 with dissolve
    mc "Oh my God, I'm so sorry!"

    scene e2s12-123 with dissolve
    mc "I was looking for the bathroom."

    scene e2s12-124 with dissolve
    cl "It's alright..."
    cl "The bathroom is right next door."

    scene e2s12-125 with dissolve
    mc "Ok... thanks!"
    mc "I'm sorry again, about barging in like this."

    scene e2s12-124 with dissolve
    cl "It's, uh... it's alright."

    scene e2s12-126 with dissolve
    pause

    play sound door_close
    scene e2s12-127 with dissolve
    pause

    stop music fadeout 2.0
    scene e2s12-128 with dissolve
    mc "*Damn, I didn't think she would be naked, holy fuck!*"

    scene e2s12-129 with dissolve
    pause

    $ renpy.end_replay()
return
