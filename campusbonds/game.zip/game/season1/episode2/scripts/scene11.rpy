
# Scene 11 - Club introduction (Sunday) ########################################

label e2s11:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e2s11-01 with Dissolve(2.0)
    define e2s11_tracks = ["marathon_man.ogg", "iwnlylmd.ogg"]
    $ renpy.music.queue (e2s11_tracks, loop=True)
    mc "So... tell me again."
    mc "Where are we going?"

    scene e2s11-02 with dissolve
    jon "Dude, I've already told you."
    jon "You're going to join The Party Ragers!"

    scene e2s11-03 with dissolve
    mc "Today?"

    scene e2s11-04 with dissolve
    jon "Today."

    scene e2s11-05 with dissolve
    mc "But it's Saturday."

    scene e2s11-06 with dissolve
    jon "Exactly, no classes today."

    scene e2s11-07 with dissolve
    jon "Perfect day for choosing the candidates."

    scene e2s11-08 with dissolve
    mc "How many pledges are there this year?"

    scene e2s11-09 with dissolve
    jon "I don't know."
    jon "I'm not the one responsible for that."

    scene e2s11-10 with dissolve
    jon "Come on, let's hurry up!"

    scene e2s11-11 with dissolve
    mc "Okay okay..."

    scene e2s11-12 with wipeleft
    $renpy.sound.play("audio/sfx/crowded_venue.ogg", loop=True)
    mc "Uhh... [jon]?"
    mc "Are we in the right place?"

    scene e2s11-13 with dissolve
    jon "Probably... yeah."

    scene e2s11-14 with dissolve
    jon "When they said that they found a class inside the college I didn't expect it to be the old cafeteria."

    scene e2s11-32 with dissolve
    jon "It looks like we're in Wonderland!"

    scene e2s11-15 with dissolve
    pause

    scene e2s11-16 with dissolve
    mc "Didn't you say they would renovate the place?"

    scene e2s11-17 with dissolve
    jon "Yeah... looks like they didn't even do that."
    jon "This does not look like a party place at all."

    scene e2s11-18 with dissolve
    mc "So... which guy is the president?"

    scene e2s11-19 with dissolve
    jon "Oh it's..."

    scene e2s11-20 with dissolve
    sc "...actually it's a her."

    scene e2s11-21 with dissolve
    sc "Is there a problem with a girl being the president?"

    scene e2s11-22 with dissolve
    show e2s11-scarlett_blink1
    menu:
        "Check her out" if affinity_spectrum > 0:
            $ scarlett_trust += 1
            scene e2s11-23 with dissolve
            hide e2s11-scarlett_blink1
            mc "*Look at those tits.*"

            scene e2s11-22 with dissolve
            show e2s11-scarlett_blink1
        "Don't risk it":
            pass
    mc "No, it's just that I didn't expect it."

    scene e2s11-24 with dissolve
    hide e2s11-scarlett_blink1
    jon "[sc], this is [mc], my good friend."

    scene e2s11-25 with dissolve
    sc "Yeah, we met at the party."
    sc "Kind of surprised to see you hang out with people like this."

    if affinity_spectrum > 0:
        scene e2s11-22 with dissolve
        show e2s11-scarlett_blink1
        mc "Hello? I'm here."

        scene e2s11-26 with dissolve
        hide e2s11-scarlett_blink1
        sc "I know, I wasn't talking to you."

    scene e2s11-27 with dissolve
    jon "Haha, ignore her."
    jon "She's just pulling your leg."

    scene e2s11-28 with dissolve
    jon "What's up with this place?"
    jon "It looks like a clown and a rainbow had sex."

    scene e2s11-25 with dissolve
    sc "Yeah, there's been complications with the college staff."
    sc "We'd agreed to be able to renovate the place but they changed their minds at the last minute."
    sc "We've just now agreed on mutual grounds and renovation will start tomorrow."

    scene e2s11-29 with dissolve
    jon "I see, I see."

    scene e2s11-25 with dissolve
    sc "Well, I'll see you later."
    sc "I'm gonna go and see what other suckers I'll be able to find."

    scene e2s11-26 with dissolve
    sc "This one didn't make an impression."

    scene e2s11-22 with dissolve
    show e2s11-scarlett_blink1
    menu:
        "Mock her":
            call extrovert_affinity_check from _call_extrovert_affinity_check_37
            call color_check from _call_color_check_71
            mc "*Sucker?*"
            mc "*You look like you'd suck a lot.*"

        "Let it slide":
            call introvert_affinity_check from _call_introvert_affinity_check_31
            call color_check from _call_color_check_72
            mc "*She's not worth the effort.*"

    scene e2s11-24 with dissolve
    hide e2s11-scarlett_blink1
    jon "Alright then, see you!"

    scene e2s11-30 with dissolve
    pause

    scene e2s11-31 with dissolve
    mc "What's up with her?"

    scene e2s11-34 with dissolve
    jon "What?"

    scene e2s11-33 with dissolve
    show e2s11-jon_blink1
    mc "Does she mock everyone like this?"

    scene e2s11-35 with dissolve
    hide e2s11-jon_blink1
    jon "Relax dude!"

    scene e2s11-36 with dissolve
    jon "She knows that you're my friend."

    scene e2s11-33 with dissolve
    show e2s11-jon_blink1
    mc "Alright I guess."
    mc "So... what's up with this group exactly?"
    mc "Do you guys only throw parties or what's going on?"

    scene e2s11-37 with dissolve
    hide e2s11-jon_blink1
    jon "Well, in theory, the 'party ragers' refers to people who like to party that get together to 'study'."

    scene e2s11-36 with dissolve
    jon "But they never do that."

    scene e2s11-37 with dissolve
    jon "Honestly, I don't think the college staff cares that much about it."

    scene e2s11-38 with dissolve
    jon "As long as they don't make them problems, they don't look too much into it."

    scene e2s11-33 with dissolve
    show e2s11-jon_blink1
    mc "So is this group only about partying?"
    mc "Like, do I need to do chores or what?"

    scene e2s11-35 with dissolve
    hide e2s11-jon_blink1
    jon "Dude, relax."
    jon "You're asking way too many questions."

    scene e2s11-36 with dissolve
    jon "Everything's gonna come naturally, don't stress your mind over it."

    scene e2s11-38 with dissolve
    jon "Some day you might need to do chores, on others you might need to steal a car..."

    scene e2s11-37 with dissolve
    jon "It's all part of the college experience."

    scene e2s11-33 with dissolve
    show e2s11-jon_blink1
    mc "Steal a car?"

    scene e2s11-39 with dissolve
    hide e2s11-jon_blink1
    jon "Come on, let's meet some people."

    stop music fadeout 1.0
    scene e2s11-40 with dissolve
    play music dances_and_dames
    unknown "So... what do you think about this club?"

    scene e2s11-41 with dissolve
    unknown "Honestly, it's pretty shit."

    scene e2s11-42 with dissolve
    unknown "I don't really understand the hype around it."

    scene e2s11-41 with dissolve
    unknown "Look at the place they got, this is nowhere near the place that was advertised."

    scene e2s11-42 with dissolve
    unknown "All this fuss about freshies not being invited so they can invite us later in a garbage can?"

    scene e2s11-40 with dissolve
    unknown "Yeah, I don't understand it either."

    scene e2s11-43 with dissolve
    unknown "If it weren't for it's reputation I wouldn't have spent a second in this dump."

    scene e2s11-44 with dissolve
    unknown "Honestly, to shit with them, I'm glad Eddy's was destroyed."

    scene e2s11-45 with dissolve
    unknown "Dude, not so loud, someone might hear..."

    stop music fadeout 1.0
    scene e2s11-46 with dissolve
    menu:
        "Intervene" if affinity_spectrum > 0:
            play music killer_rabbit
            $ jon_friendship -= 1
            call extrovert_affinity_check from _call_extrovert_affinity_check_38
            call color_check from _call_color_check_73
            mc "I'm sorry, who are you?"

            scene e2s11-47 with dissolve
            unknown "What?"

            scene e2s11-48 with dissolve
            show e2s11-unknown_blink1
            mc "What do you know about Eddy's?"
            mc "And if you don't like the place, why don't you just leave?"
            mc "No one's forcing you to join this group."

            scene e2s11-49 with dissolve
            hide e2s11-unknown_blink1
            unknown "Even the staff is shit."

            scene e2s11-50 with dissolve
            unknown "Come on guys, let's leave."

            scene e2s11-51 with dissolve
            pause

            scene e2s11-53 with dissolve
            jon "Hey dude, what are you doing?"

            scene e2s11-52 with dissolve
            show e2s11-jon_blink2
            mc "What?"
            mc "They were clearly looking for trouble."

            scene e2s11-53 with dissolve
            hide e2s11-jon_blink2
            jon "Yeah, and you just gave it to them."

            scene e2s11-52 with dissolve
            show e2s11-jon_blink2
            mc "Whatever dude."

            scene e2s11-54 with dissolve
            hide e2s11-jon_blink2
            mc "Sometimes it feels like you're taking everyone's side but mine."

            stop music fadeout 1.0
            scene e2s11-55 with dissolve
            jon "Come on bro, don't be like that, it's just..."
        "Not your business":
            mc "*They're just punks.*"

            scene e2s11-72 with dissolve
            jon "Idiots."

            scene e2s11-52 with dissolve
            show e2s11-jon_blink2
            mc "Huh?"

            scene e2s11-73 with dissolve
            hide e2s11-jon_blink2
            jon "Oh, I'm just talking about those idiots that were talking shit."
            jon "Don't mind me."

            scene e2s11-52 with dissolve
            show e2s11-jon_blink2
            mc "Oh, alright."

    scene e2s11-56 with dissolve
    hide e2s11-jon_blink2
    "{i}Muffled arguing.{/i}"

    scene e2s11-57 with dissolve
    play music rollin_at_5
    unknown "So, we're not allowed to bring our own drinks?"
    unknown "What kind of rule is that?"

    scene e2s11-58 with dissolve
    sc "The one that keeps the club going, punk!"
    sc "But I wouldn't expect someone like you to understand business."

    scene e2s11-57 with dissolve
    unknown "Business? You call this a business?"
    unknown "You didn't invite us to your great party but instead decided to invite us to this dump?"
    unknown "What kind of business is that?"

    scene e2s11-58 with dissolve
    sc "You gotta work to earn parties like that."
    sc "You really expect us to give you everything from day one?"

    scene e2s11-57 with dissolve
    unknown "So, why were other freshies invited then?"
    unknown "You talk about equality but clearly play favourites."

    scene e2s11-59 with dissolve
    sc "*How do these little shits know about that?*"

    scene e2s11-58 with dissolve
    sc "What the fuck is your problem?"
    sc "Is it my fault you're a punk and couldn't make any cool friends to invite you?"

    scene e2s11-60 with dissolve
    unknown "Come on guys, we're leaving."

    scene e2s11-61 with dissolve
    sc "Alright, good luck finding a better partying group than this."

    scene e2s11-62 with dissolve
    unknown "Oh, don't worry..."
    unknown "We will!"

    scene e2s11-63 with dissolve
    pause

    stop music fadeout 1.0

    scene e2s11-64 with dissolve
    sc "Now, who the hell revealed the party to the freshies?"

    if affinity_spectrum > 0:
        scene e2s11-66 with dissolve
    else:
        scene e2s11-65 with dissolve
    sc "That's why we don't tell them about it."

    scene e2s11-67 with dissolve
    sc "I told you [jon] it's not a good idea to let freshies in."

    scene e2s11-68 with dissolve
    jon "Eddy's was trashed, we sent them to Cabanna's."

    scene e2s11-69 with dissolve
    jon "How the hell did they find out?"
    jon "I didn't tell freshies."

    scene e2s11-68 with dissolve
    jon "The only ones I told about it were my friends but I trust them."

    scene e2s11-69 with dissolve
    jon "They wouldn't do that to me."

    scene e2s11-70 with dissolve
    sc "Maybe you don't know your friends all that well then."

    scene e2s11-71 with dissolve
    pause
    jon "Well... that was interesting."

    scene e2s11-74 with dissolve
    mc "[jon], you know that you're my friend."

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "I wouldn't do that to you."

    scene e2s11-76 with dissolve
    hide e2s11-jon_blink3
    jon "I know dude, don't worry."
    jon "I trust you, I know you wouldn't tell..."
    jon "None of you would have."

    scene e2s11-77 with dissolve
    jon "We might have some leakage inside our group."

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "There's a high probability."
    mc "So what are we gonna do now?"

    scene e2s11-79 with dissolve
    hide e2s11-jon_blink3
    jon "Well... we would have introduced everyone in The Party Ragers with a party, obviously..."

    scene e2s11-116 with dissolve
    jon "But since this place isn't finished yet, I guess that [sc] will have a speech about the group?"

    scene e2s11-77 with dissolve
    jon "I'm not sure."

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "I understand."
    mc "Hey bro, I've been wanting to talk to you about something."

    scene e2s11-78 with dissolve
    hide e2s11-jon_blink3
    jon "What's up?"

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "So, a couple of days ago [ke] texted me about his birthday party."
    mc "Said he's got my phone number from you."

    scene e2s11-78 with dissolve
    hide e2s11-jon_blink3
    jon "Yup, that's right!"

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "So... I get that you're coming as well?"

    scene e2s11-117 with dissolve
    hide e2s11-jon_blink3
    jon "Hell yeah I'm coming dude!"

    scene e2s11-118 with dissolve
    mc "Then what gift are you buying him?"
    mc "I barely know the guy so any suggestions would be welcomed."

    scene e2s11-78 with dissolve
    jon "He said he doesn't want any extravagant gifts."

    scene e2s11-117 with dissolve
    jon "I'm just gonna bring him a bottle of booze."

    scene e2s11-118 with dissolve
    mc "*Typical [jon].*"

    scene e2s11-116 with dissolve
    jon "Honestly, you shouldn't go for any expensive gifts."

    scene e2s11-78 with dissolve
    jon "Get him something that he'll remember."

    scene e2s11-77 with dissolve
    jon "Not the usual shit stuff like a mug or money."

    scene e2s11-78 with dissolve
    jon "Especially money."

    scene e2s11-118 with dissolve
    mc "Thanks man!"

    scene e2s11-117 with dissolve
    jon "Don't mention it."

    scene e2s11-80 with dissolve
    hide e2s11-jon_blink3
    jon "Now, if you'll excuse me, I'm gonna go to the bathroom really quick."
    jon "I gotta take a shit."

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "Okay, have fun!"

    scene e2s11-78 with dissolve
    hide e2s11-jon_blink3
    jon "Thanks."

    scene e2s11-81 with dissolve
    pause

    scene e2s11-82 with dissolve
    pause

    scene e2s11-83 with dissolve
    pause

    scene e2s11-84 with dissolve
    play music onfire
    unknown "Hey freshie."

    scene e2s11-85 with dissolve
    sc "Looking for something?"

    scene e2s11-86 with dissolve
    mc "Huh?"

    scene e2s11-87 with dissolve
    sc "Didn't you lose something?"

    scene e2s11-89 with dissolve
    sc "Perhaps, last night?"

    scene e2s11-86 with dissolve
    mc "My keys?"
    mc "How do you have them?"

    scene e2s11-88 with dissolve
    sc "Relax, I didn't say I have them."

    scene e2s11-86 with dissolve
    mc "Where are they then?"

    scene e2s11-89 with dissolve
    sc "I didn't say I don't have them though."

    scene e2s11-86 with dissolve
    if affinity_spectrum > 0:
        mc "Alright, I'm tired of your fucking games."
        mc "Just give me my keys already."

        scene e2s11-85 with dissolve
        sc "Oh, aggressive, aren't we?"

        scene e2s11-89 with dissolve
        sc "That's what I like to see."

        scene e2s11-86 with dissolve
        mc "You know what I would like to see?"
        mc "My keys."
        mc "So how about you give them back to me and we can call this a day, how about that?"

        scene e2s11-90 with dissolve
        sc "I wonder if you're the same in bed."

        scene e2s11-91 with dissolve
        mc "What?"

        scene e2s11-87 with dissolve
        sc "Hypothetically, let's say that I do have your keys on me."
        sc "What would I get in return for helping you get them back?"

        scene e2s11-86 with dissolve
        mc "A very respectful and warm 'thank you'!"

        scene e2s11-92 with dissolve
        sc "Ow, that's all?"

        scene e2s11-93 with dissolve
        mc "What the fuck do you expect me to give you?"
        mc "I don't have any money on me."

        scene e2s11-90 with dissolve
        sc "There are things more valuable in life than money, [mc]."

        scene e2s11-89 with dissolve
        sc "You could perhaps help me with some information..."

        scene e2s11-86 with dissolve
        mc "Some information?"
        mc "If you wanted to hear it from me personally that I didn't snitch, there it is."
        mc "I didn't snitch."
        mc "You didn't have to make such a drama out of it."

        scene e2s11-85 with dissolve
        sc "Nah, that would have been too easy."

        scene e2s11-87 with dissolve
        sc "I want to know who [jon] talked to about the party."

        scene e2s11-86 with dissolve
        mc "Hey, fuck you bitch, I'm no snitch!"
        mc "And for your information, [jon] only talked to us about it."
        mc "Me, [jd], [ro] and [ke], nobody else."
        mc "So, why don't you just figure your shit out and stop blaming [jon] for it?"

        scene e2s11-92 with dissolve
        sc "Fine, didn't have to be such a drama queen."
        sc "Here, this is your key."

        scene e2s11-94 with dissolve
        sc "You're no fun anyway."

        scene e2s11-95 with dissolve
        mc "Good luck being miserable."

        scene e2s11-96 with dissolve
        mc "*Bitch.*"
    else:
        mc "Then... where are my keys?"

        scene e2s11-89 with dissolve
        sc "It's not that easy..."

        scene e2s11-87 with dissolve
        sc "Hypothetically, let's say that I do have your keys on me."
        sc "What would I get in return for helping you get them back?"

        scene e2s11-86 with dissolve
        mc "Um? I don't have any money on me."

        scene e2s11-90 with dissolve
        sc "It's not money that I want [mc]..."

        scene e2s11-91 with dissolve
        mc "Then what do you want?"

        scene e2s11-90 with dissolve
        sc "Perhaps you could help me with some information..."

        scene e2s11-86 with dissolve
        mc "What? Do you want me to snitch on my friends?"
        mc "No thanks, I'm not interested."

        scene e2s11-93 with dissolve
        mc "You know, I could always go to the college staff and get my key back, right?"
        mc "I don't need you."

        scene e2s11-92 with dissolve
        sc "Take your key."

        scene e2s11-95 with dissolve
        mc "But hey, good talk!"

    scene e2s11-84 with dissolve
    pause

    scene e2s11-97 with dissolve
    pause

    scene e2s11-78 with dissolve
    jon "Hey man, what's up?"

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "Did you take a shit?"

    scene e2s11-77 with dissolve
    hide e2s11-jon_blink3
    jon "Honestly, I wanted to, but there was no toilet paper."

    scene e2s11-78 with dissolve
    jon "I'm not using my finger like last time."

    scene e2s11-75 with dissolve
    show e2s11-jon_blink3
    mc "Finger?"
    mc "Last time?"

    scene e2s11-77 with dissolve
    hide e2s11-jon_blink3
    jon "Don't ask."

    scene e2s11-78 with dissolve
    jon "Alright, let's gather up for [sc]'s speech!"

    scene e2s11-77 with dissolve
    jon "Damn this year is lame..."
    jon "Far from the stories I've heard from past years."

    stop music fadeout 1.0
    scene e2s11-98 with dissolve
    pause

    scene e2s11-99 with dissolve
    sc "Alright everyone, gather up!"
    sc "Welcome to our partying group, The Party Ragers!"

    scene e2s11-100 with dissolve
    sc "This club is not just about partying, but about making friends and..."

    scene e2s11-101 with dissolve
    sc "Wait, who the hell wrote this bullshit?"

    scene e2s11-100 with dissolve
    sc "It's about partying to and above the limit and having fun no matter what."

    scene e2s11-102 with dissolve
    sc "Hey, where's everyone going?"

    scene e2s11-103 with dissolve
    stop sound fadeout 1.0
    sc "I haven't finished the presentation."

    scene e2s11-104 with dissolve
    jon "Uh, [sc]?"
    jon "I think that we've advertised on the flyer that we're gonna make the initiation with a party."

    scene e2s11-105 with dissolve
    jon "They were expecting a party..."

    scene e2s11-106 with dissolve
    sc "Did we?"

    scene e2s11-107 with dissolve
    sc "Can this year get any worse?"

    scene e2s11-104 with dissolve
    jon "We're most likely gonna have to throw a party here in order to attract their attention."

    scene e2s11-106 with dissolve
    sc "It's going to take a while then."

    scene e2s11-108 with wipeleft
    play music sun_sets_on_a_protagonist
    mc "Hey man, I wanted to talk to you about those freshies at the group."

    scene e2s11-109 with dissolve
    jon "What's up?"

    scene e2s11-110 with dissolve
    show e2s11-jon_blink4
    mc "One of them talked about how Eddy's was destroyed."
    mc "Do you think they had anything to do with it?"

    scene e2s11-109 with dissolve
    hide e2s11-jon_blink4
    jon "Honestly, not really."

    scene e2s11-112 with dissolve
    jon "Rumors are spreading pretty fast and I don't think that they would be talking this freely about trashing a party."

    scene e2s11-110 with dissolve
    show e2s11-jon_blink4
    mc "So, what do you think happened?"
    mc "Have you found anything?"

    scene e2s11-109 with dissolve
    hide e2s11-jon_blink4
    jon "Nah, not really."
    jon "The people that did this left no trace behind."

    scene e2s11-111 with dissolve
    jon "They are still searching the place in case something pops up."

    scene e2s11-112 with dissolve
    jon "But as far as I'm concerned, everything's just speculation at this point."

    scene e2s11-110 with dissolve
    show e2s11-jon_blink4
    mc "Damn, who hired mercenaries to trash your party?"

    scene e2s11-113 with dissolve
    hide e2s11-jon_blink4
    jon "Haha, I don't know."

    scene e2s11-112 with dissolve
    jon "But they did one hell of a job."

    scene e2s11-110 with dissolve
    show e2s11-jon_blink4
    mc "I see."

    scene e2s11-114 with dissolve
    hide e2s11-jon_blink4
    jon "Hey man, I'm gonna go to the bathroom to take that shit."

    scene e2s11-112 with dissolve
    jon "It's probably going to take a while so I'll catch you later, alright?"

    scene e2s11-110 with dissolve
    show e2s11-jon_blink4
    mc "Alright bro, see you!"

    if affinity_spectrum > 0:
        mc "Good luck with your shit."

        scene e2s11-114 with dissolve
        hide e2s11-jon_blink4
        jon "Thanks!"

    stop music fadeout 1.0
    scene e2s11-115 with dissolve
    hide e2s11-jon_blink4
    pause

    jump e2s12
return
