
default e2s10_popcorn = False

# Scene 10 - Spending the night ################################################

label e2s10:
    nvl clear
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    # Francesca ################################################################
    if e2s10_francesca == True:
        scene e2s10_fr-01 with Dissolve(2.0)
        n_nvl "Hey, I'm here!"
        fr_nvl "Alright, I'm gonna open the door for you."

        play sound door_open
        play music solo_acoustic_guitar
        scene e2s10_fr-02 with dissolve
        pause

        scene e2s10_fr-03 with dissolve
        fr "Hey [mc]!"

        scene e2s10_fr-04 with dissolve
        show e2s10_fr-francesca_blink1
        mc "Hello [fr]!"
        mc "Thank you again for letting me spend the night here."

        scene e2s10_fr-05 with dissolve
        hide e2s10_fr-francesca_blink1
        fr "Come on in."

        scene e2s10_fr-06 with dissolve
        mc "So... what's up?"
        mc "I hope I didn't wake you up with my call."

        scene e2s10_fr-07 with dissolve
        fr "No, I was about to go to sleep."

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "I understand."

        scene e2s10_fr-09 with dissolve
        hide e2s10_fr-francesca_blink2
        mc "Nice house!"

        scene e2s10_fr-07 with dissolve
        fr "Thanks."
        fr "Would be nicer if I lived here alone."

        scene e2s10_fr-10 with dissolve
        fr "Are you hungry?"
        fr "Do you want to eat something?"

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "No, I'm okay, thanks."
        mc "A glass of water would be fine."

        scene e2s10_fr-07 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "Okay, no problem."

        scene e2s10_fr-11 with dissolve
        pause

        scene e2s10_fr-12 with dissolve
        pause

        scene e2s10_fr-13 with dissolve
        fr "Here."

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Thank you [fr]!"

        scene e2s10_fr-10 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "So... how are you [mc]?"

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "I'm alright."
        mc "I've had better days."

        scene e2s10_fr-10 with dissolve
        hide e2s10_fr-francesca_blink2
        if e2s9_francesca_lie == False:
            fr "How did you manage to lose your key?"

            scene e2s10_fr-08 with dissolve
            show e2s10_fr-francesca_blink2
            mc "I don't even know to be honest..."
            mc "I just know that I've had them before I left my house."

            scene e2s10_fr-07 with dissolve
            hide e2s10_fr-francesca_blink2
            fr "Do you think someone might have... stolen them?"

            scene e2s10_fr-08 with dissolve
            show e2s10_fr-francesca_blink2
            mc "I mean... I don't know..."
        else:
            fr "How did you even manage to lock yourself outside your dorm?"

            scene e2s10_fr-08 with dissolve
            show e2s10_fr-francesca_blink2
            mc "I didn't actually lock myself outside my dorm..."
            mc "I lost the key."

            scene e2s10_fr-07 with dissolve
            hide e2s10_fr-francesca_blink2
            fr "You lost the key?"

            scene e2s10_fr-08 with dissolve
            show e2s10_fr-francesca_blink2
            mc "Yeah..."

            scene e2s10_fr-07 with dissolve
            hide e2s10_fr-francesca_blink2
            fr "What if someone finds it?"
            fr "Won't they try to steal stuff from your dorm?"

            scene e2s10_fr-08 with dissolve
            show e2s10_fr-francesca_blink2

        mc "I'm going to report this incident tomorrow to the college staff."
        mc "If they're going to steal anything, they better do it tonight."
        mc "Although, they don't really have anything to steal."
        mc "I only have a couple of school books and some clothes."
        mc "So I'm not too worried about that."

        scene e2s10_fr-10 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "You mentioned a dorm mate..."

        scene e2s10_fr-07 with dissolve
        fr "What about his stuff?"

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "I don't think he left anything valuable in the dorm."
        mc "As I previously mentioned, he's gone for the weekend, so most probably he took everything with him."

        scene e2s10_fr-07 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "Then I think you're pretty safe."

        scene e2s10_fr-08 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Yeah..."

        scene e2s10_fr-15 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "Hey, let's get our minds off of this."

        scene e2s10_fr-14 with dissolve
        fr "Do you want to watch a movie?"

        scene e2s10_fr-16 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Sure!"
        mc "Do you have anything in mind?"

        scene e2s10_fr-17 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "I have a couple of titles that I've been eager to watch."
        fr "I mostly like to watch action movies."

        scene e2s10_fr-16 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Oh, really?"
        mc "I didn't see you as an action movie enjoyer."

        scene e2s10_fr-17 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "Perhaps you don't know a lot of things about me, [mc]."
        fr "Do you have any preferences?"

        scene e2s10_fr-16 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Not really, action movies are fine by me."

        scene e2s10_fr-15 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "Okay, great."

        scene e2s10_fr-14 with dissolve
        fr "Hey, could you go and make some popcorn while I set up the movie?"

        scene e2s10_fr-16 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Alright, just tell me where it is."

        scene e2s10_fr-17 with dissolve
        hide e2s10_fr-francesca_blink2
        fr "You can find it in the kitchen."

        stop music fadeout 2.0
        scene e2s10_fr-16 with dissolve
        show e2s10_fr-francesca_blink2
        mc "Okay, be right back!"

        call e2s10_freeroam from _call_e2s10_freeroam

        if e2s10_popcorn == True:
            scene e2s10_fr-18 with dissolve
            mc "Let's see if the popcorn is here."

            scene e2s10_fr-19 with dissolve
            pause
            mc "Bingo!"

            scene e2s10_fr-20 with dissolve
            pause

            scene e2s10_fr-21 with dissolve
            pause

            scene e2s10_fr-22 with dissolve
            mc "Hey, popcorn's ready."

            scene e2s10_fr-23 with dissolve
            fr "Great!"
            fr "I've set up the movie."

            scene e2s10_fr-24 with dissolve
            mc "Alright."
        else:
            scene e2s10_frfrimg-01 with dissolve
            fr "Hey, you were supposed to bring popcorn!"

            scene e2s10_frfrimg-02 with dissolve
            mc "Sorry, I got a little lost."

            scene e2s10_frfrimg-03 with dissolve
            fr "That's fine."

            scene e2s10_frfrimg-04 with dissolve
            fr "I've set up the movie, you can go sit on the couch."

            scene e2s10_frfrimg-03 with dissolve
            fr "I'll go and make popcorn."

            scene e2s10_frfrimg-02 with dissolve
            mc "Alright."

        stop music fadeout 1.0
        scene e2s10_fr-25 with wipeleft
        fr "Alright, everything is set."
        fr "We can start the movie now."

        scene e2s10_fr-06 with dissolve
        mc "Let me turn off the lights."

        play music river_view
        scene e2s10_fr-26 with dissolve
        pause
        mc "Hey, that guy looks familiar!"

        scene e2s10_fr-27 with dissolve
        mc "I think I've seen him in a couple of movies."

        scene e2s10_fr-26 with dissolve
        fr "Yeah, he's a pretty popular actor."
        fr "He's also played in a movie called Forced to Kill."
        mc "Oh, I remember that movie."

        scene e2s10_fr-28 with dissolve
        fr "You watched Forced to Kill?"

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "Oh yeah!"
        mc "I used to watch all kinds of movies with my father when I was younger."
        mc "He really knew how to pick the best movies."

        scene e2s10_fr-30 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "I'm glad you used to do that with your father, [mc]."

        scene e2s10_fr-31 with dissolve
        fr "Maybe you could show me some of the movies you watched with him."

        scene e2s10_fr-32 with dissolve
        show e2s10_fr-francesca_blink3
        mc "Yeah, that would be great!"
        mc "I haven't watched a movie in ages."

        scene e2s10_fr-28 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "Hey, sorry for asking this..."
        fr "You keep mentioning your father..."

        scene e2s10_fr-33 with dissolve
        fr "But I've never heard anything about your mother."

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "That's because I kind of hate talking about her..."

        scene e2s10_fr-28 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "What happened?"
        fr "You don't have to answer if you don't want to."

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "It's fine, I can talk about her."
        mc "She basically abandoned me when I was like 7."
        mc "I don't know the exact reason as to why she did that."
        mc "My father's also not helping because he refuses to talk to me about her every time I mention her."

        scene e2s10_fr-34 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "Oh, I'm sorry [mc]..."

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "It's okay."
        mc "I just don't understand why she would do that to me."

        scene e2s10_fr-33 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "Do you know where she is now?"

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "Not really..."
        mc "The last time I saw her was when my parents got divorced."
        mc "And we were living here."

        scene e2s10_fr-28 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "Did you come here in hopes of meeting her again?"

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "I mean, not really."
        mc "She burned that bridge the moment she abandoned me."
        mc "Although, I'm not gonna lie, there's a little part in me which wants to see her."

        scene e2s10_fr-34 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "I understand."

        scene e2s10_fr-28 with dissolve
        fr "Maybe you'll come to see her again one day."

        scene e2s10_fr-33 with dissolve
        fr "Whatever happens though, just know that everything is going to be alright."

        scene e2s10_fr-28 with dissolve
        fr "And I'm here if you ever need someone to talk to."

        scene e2s10_fr-29 with dissolve
        show e2s10_fr-francesca_blink3
        mc "Thank you [fr]!"
        mc "I really appreciate it."
        mc "Should we continue to watch the movie?"

        scene e2s10_fr-30 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "Yeah, sure!"

        scene e2s10_fr-32 with dissolve
        show e2s10_fr-francesca_blink3
        mc "Haha, I stopped paying attention to it, I don't even know what's happening anymore!"

        scene e2s10_fr-30 with dissolve
        hide e2s10_fr-francesca_blink3
        fr "I guess we'll have to figure it out!"

        scene e2s10_fr-35 with wipeleft
        pause
        mc "Hey, that's not fair!"
        mc "Look what they did to that guy."
        fr "Damn, that's really annoying."
        mc "Come on, beat him up!"
        fr "Yeah!!"

        scene e2s10_fr-36 with Dissolve(2.0)
        pause
        fr "No way!"
        fr "Did you see that?"
        pause
        scene e2s10_fr-37 with dissolve
        fr "[mc]?"

        scene e2s10_fr-38 with dissolve
        fr "*Is he sleeping?*"
        pause
        fr "*Yeah, he's most definitely sleeping.*"

        scene e2s10_fr-39 with dissolve
        pause

        scene e2s10_fr-40 with dissolve
        pause

        scene e2s10_fr-41 with dissolve
        pause

        stop music fadeout 2.0
        scene black with Dissolve(2.0)
        pause(2.0)

        if francesca_trust <= 2:
            fr "[mc], wake up!"

            play music coalescense
            scene e2s10_fr-42 with dissolve
            mc "Huh?"

            scene e2s10_fr-43 with dissolve
            fr "I thought I heard something..."

            scene e2s10_fr-44 with dissolve
            fr "Sorry to have woken you up but I think you need to go..."
            fr "If my dad's home, we're both screwed."

            scene e2s10_fr-45 with dissolve
            if affinity_spectrum >= 0:
                mc "Fuck, okay!"

            mc "What time is it?"

            scene e2s10_fr-47 with dissolve
            fr "It's almost 6 AM."

            scene e2s10_fr-46 with dissolve
            mc "Okay, that's fine."
            mc "The college is opening at 7 AM so I can hang around there."
            mc "Thank you very much [fr] for letting me stay the night."

            scene e2s10_fr-47 with dissolve
            fr "You're welcome [mc]!"

            scene e2s10_fr-46 with dissolve
            mc "Okay then, I'm gonna be on my way."

            scene e2s10_fr-45 with dissolve
            mc "See you around!"

            scene e2s10_fr-44 with dissolve
            fr "See you [mc]!"

            scene e2s10_fr-48 with dissolve
            fr "Could you also go through the back door, please?"

            scene e2s10_fr-49 with dissolve
            mc "Alright, no worries."

            scene e2s10_fr-50 with dissolve
            mc "I'll make sure no one sees me."

            scene e2s10_fr-51 with dissolve
            fr "Thank you [mc]!"

            scene e2s10_fr-52 with dissolve
            fr "Be careful, alright?"

            scene e2s10_fr-53 with dissolve
            mc "I will, see you!"

            scene e2s10_fr-52 with dissolve
            fr "Bye!"

            scene e2s10_fr-54 with dissolve
            pause

            jump e2s11

        if francesca_trust >= 3:
            scene e2s10_fr-55 with Dissolve(2.0)
            play music iwnlylmd
            pause

            scene e2s10_fr-56 with dissolve
            pause

            scene e2s10_fr-57 with dissolve
            fr "Morning!"

            scene e2s10_fr-58 with dissolve
            mc "Good morning."

            scene e2s10_fr-59 with dissolve
            mc "What time is it?"

            scene e2s10_fr-57 with dissolve
            fr "It's like 8 AM."

            scene e2s10_fr-59 with dissolve
            mc "How did I fall asleep last night?"

            scene e2s10_fr-57 with dissolve
            fr "You tell me."
            fr "One moment we were watching the movie and the next you were asleep."

            scene e2s10_fr-59 with dissolve
            mc "I was pretty tired."

            scene e2s10_fr-57 with dissolve
            fr "Yup!"

            scene e2s10_fr-60 with dissolve
            fr "At some point in the night I thought I heard something..."
            fr "But fortunately, it was nothing."

            scene e2s10_fr-61 with dissolve
            fr "I initially thought it was my dad, but it was some cat instead."

            scene e2s10_fr-59 with dissolve
            mc "I see."

            scene e2s10_fr-62 with dissolve
            fr "Want some coffee?"

            scene e2s10_fr-58 with dissolve
            mc "Sure."

            scene e2s10_fr-63 with dissolve
            fr "So, how did you sleep?"

            scene e2s10_fr-64 with dissolve
            mc "I slept alright."
            mc "Just woke up with this huge headache."

            scene e2s10_fr-65 with dissolve
            fr "Oh, I hope it's nothing serious!"

            if e2s9_francesca_lie == True:
                scene e2s10_fr-66 with dissolve
                pause

            scene e2s10_fr-64 with dissolve
            mc "Most probably isn't."

            scene e2s10_fr-67 with dissolve
            pause

            scene e2s10_fr-68 with dissolve
            pause

            scene e2s10_fr-65 with dissolve
            fr "Hey, are you hungry?"
            fr "I could cook you some bacon and eggs."

            scene e2s10_fr-69 with dissolve
            mc "Nah, thank you!"
            mc "The coffee is enough."
            mc "Plus that I should get going pretty soon."

            scene e2s10_fr-65 with dissolve
            fr "Alright, suit yourself."

            scene e2s10_fr-70 with dissolve
            play sound stomach_growl
            pause
            mc "On second thoughts, if you really want I could eat some bacon and eggs right now."

            scene e2s10_fr-71 with dissolve
            fr "Haha, needed approval from your stomach first?"

            scene e2s10_fr-69 with dissolve
            mc "Pretty much, yeah."

            scene e2s10_fr-72 with wipeleft
            show e2s10_fr-francesca_blink4
            mc "Alright, I'll be on my way now."
            mc "Thanks [fr] again for having me."
            mc "I don't know what I would have done without you!"

            scene e2s10_fr-73 with dissolve
            hide e2s10_fr-francesca_blink4
            fr "Haha, I'm glad I could be helpful!"

            scene e2s10_fr-72 with dissolve
            show e2s10_fr-francesca_blink4
            if affinity_spectrum > 0:
                mc "You know, if you ever need a place to crash, you can always call me, okay?"

                scene e2s10_fr-74 with dissolve
                hide e2s10_fr-francesca_blink4
                fr "Haha, duly noted!"
            else:
                mc "If you ever need to spend the night somewhere, you can always give me a call, alright?"

                scene e2s10_fr-73 with dissolve
                hide e2s10_fr-francesca_blink4
                fr "Okay [mc], thanks!"

            scene e2s10_fr-72 with dissolve
            show e2s10_fr-francesca_blink4
            mc "Bye [fr]!"
            mc "See you around."

            scene e2s10_fr-73 with dissolve
            hide e2s10_fr-francesca_blink4
            fr "See you [mc]!"

            scene e2s10_fr-75 with dissolve
            pause

            jump e2s11

    # Sadie ####################################################################
    if e2s10_sadie == True:
        scene e2s10_sd-01 with Dissolve(2.0)
        n_nvl "Hey [sd]!"
        n_nvl "I've arrived."
        sd_nvl "Okay, hang on a bit."

        scene e2s10_sd-02 with dissolve
        pause

        play sound door_open
        scene e2s10_sd-03 with dissolve
        play music serenity
        mc "Hello!"

        scene e2s10_sd-04 with dissolve
        sd "Hi!"

        scene e2s10_sd-05 with dissolve
        sd "Come on in."

        play sound door_close
        scene e2s10_sd-06 with dissolve
        mc "Nice apartment."

        scene e2s10_sd-07 with dissolve
        sd "Thanks!"

        scene e2s10_sd-08 with dissolve
        mc "Way bigger than [jon]'s."

        scene e2s10_sd-09 with dissolve
        sd "Well, it's a studio, so yeah."

        scene e2s10_sd-10 with dissolve
        mc "Wait so everything is in the same room?"

        scene e2s10_sd-11 with dissolve
        sd "Except for the bathroom, yeah."

        scene e2s10_sd-12 with dissolve
        mc "That's honestly pretty convenient."

        scene e2s10_sd-13 with dissolve
        sd "Actually, I don't know about that."

        scene e2s10_sd-14 with dissolve
        sd "It might seem like that at first, but the moment you start cooking something..."

        scene e2s10_sd-15 with dissolve
        sd "It's gonna smell everywhere."

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "Oh, I understand..."
        mc "So... how are you?"

        scene e2s10_sd-17 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "A little bit tired."

        scene e2s10_sd-18 with dissolve
        mc "I hope I didn't wake you up..."

        scene e2s10_sd-15 with dissolve
        sd "No, you didn't."

        scene e2s10_sd-19 with dissolve
        sd "I was getting changed when you called me."

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "I see."

        scene e2s10_sd-15 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "So... what happened exactly?"

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "Well, basically, after you left there were no more drinks..."
        mc "So, people started to get a little mad."
        mc "Everyone was on the edge because they wanted more alcohol."
        mc "So, me and [jon] got them some more drinks."
        mc "But unfortunately, they were a little too late."
        mc "So, people started fighting."
        mc "A random dude started the whole fight and the reason he did that was that he thought one of the guys who carried the alcohol inside looked at him weird."
        mc "What's weirder is that he was wearing sun glasses."

        if affinity_spectrum > 0:
            mc "How the fuck did he know where that guy was looking?"
            mc "Beats me..."
        else:
            mc "How did he even know where that guy was looking?"

        scene e2s10_sd-15 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "Maybe he wasn't even mad but wanted to start a fight out of nothing."

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "Most probably yeah, he was bored."
        mc "After that, [no] kicked us out."
        mc "Only us left the party, the other guys kept on fighting."
        mc "And as I was walking back to my dorm, I realized that I don't have my key on me anymore."

        scene e2s10_sd-19 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "You could have dropped them when the fight broke out."

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "I don't think so... I didn't get involved."

        scene e2s10_sd-15 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "So... what are you saying?"
        sd "Someone stole them?"

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "Could be..."
        mc "I have no idea to be fair."

        scene e2s10_sd-15 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "Well, if that's the case, you should report it first thing tomorrow."

        scene e2s10_sd-16 with dissolve
        show e2s10_sd-sadie_blink1
        mc "Yeah, I'm gonna do just that."

        scene e2s10_sd-20 with dissolve
        hide e2s10_sd-sadie_blink1
        sd "So... who the fuck invited [sp] then?"

        scene e2s10_sd-21 with dissolve
        show e2s10_sd-sadie_blink2
        if affinity_spectrum > 0:
            mc "Woah... pretty straightforward!"

        mc "I don't know to be honest..."
        mc "It was [no]'s party."
        mc "Maybe he's the one who invited him?"

        scene e2s10_sd-20 with dissolve
        hide e2s10_sd-sadie_blink2
        sd "The fuck is his problem?"

        scene e2s10_sd-22 with dissolve
        sd "Can't I have a good time without him sticking his nose in everything?"

        scene e2s10_sd-21 with dissolve
        show e2s10_sd-sadie_blink2
        mc "What I do know is that [sp] didn't know you were there as well."
        mc "When he saw you, he left."

        scene e2s10_sd-23 with dissolve
        hide e2s10_sd-sadie_blink2
        sd "..."
        mc "Well... that's a party ruined..."

        scene e2s10_sd-24 with dissolve
        sd "Yeah..."

        scene e2s10_sd-25 with dissolve
        sd "Hey, I think I know how to cheer up the mood!"

        scene e2s10_sd-26 with dissolve
        mc "How?"

        scene e2s10_sd-27 with dissolve
        sd "Hang on a bit."

        scene e2s10_sd-28 with dissolve
        sd "I think I still have it..."
        menu:
            "Check her out":
                scene e2s10_sd-29 with dissolve
                if affinity_spectrum > 0:
                    mc "Damn"
                else:
                    pause

            "Don't risk it":
                pass

        scene e2s10_sd-28 with dissolve
        sd "Ah, there it is!"

        scene e2s10_sd-30 with dissolve
        pause
        mc "A bottle of wine?"

        scene e2s10_sd-31 with dissolve
        sd "Yeah!"

        scene e2s10_sd-32 with dissolve
        sd "And let's make things interesting..."

        scene e2s10_sd-33 with dissolve
        pause

        scene e2s10_sd-34 with dissolve
        sd "We're not gonna go to sleep until we both finish this bottle."

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        if affinity_spectrum >= 0:
            mc "Alright, bet!"
        else:
            mc "Uh, are you sure [sd]?"
            mc "I've already had a couple of drinks beforehand..."

            scene e2s10_sd-36 with dissolve
            hide e2s10_sd-sadie_blink3
            sd "Relax dude, it's gonna be fine."
            sd "It's just a bottle of wine."

            scene e2s10_sd-37 with dissolve
            sd "Plus that if you can't go on, you can quit anytime you want and go to sleep."

            scene e2s10_sd-35 with dissolve
            show e2s10_sd-sadie_blink3
            mc "Alright then, bring it on!"

        scene e2s10_sd-38 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "Cheers [mc]!"

        scene e2s10_sd-39 with dissolve
        mc "Cheers [sd]!"

        scene e2s10_sd-40 with dissolve
        pause

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "That's some fine wine I'm not gonna lie!"

        scene e2s10_sd-36 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "I got this for my 18th birthday but never got the chance to open it."

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "Oh, cool!"

        scene e2s10_sd-37 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "What did you get for your 18th birthday?"

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "A couple of happy birthday wishes."
        mc "And some money from my father."

        scene e2s10_sd-41 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "That's all?"

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "Yeah, well..."
        mc "I didn't have that many friends growing up."
        mc "I had my friend [jon] but that was about it."

        scene e2s10_sd-43 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "How come?"

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "I don't know..."
        mc "People were very judgemental."
        mc "They always thought that if you were different you were weird and abnormal."

        scene e2s10_sd-44 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "What the fuck?"
        sd "That's honestly so shit!"

        scene e2s10_sd-43 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "I'm sorry dude."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "Hey, don't worry."
        mc "It's alright."
        mc "It's good that I've gone past that point in my life."

        scene e2s10_sd-45 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "Now I feel bad..."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "Don't feel bad."
        mc "I'm honestly pretty grateful for my past."
        mc "I've learned a lot of valuable lessons."
        mc "Also, my father's been by my side so yeah, it wasn't all bad."

        scene e2s10_sd-43 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "I'm glad you overcame that, [mc]."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "Tell me about you [sd]!"
        mc "What's your life story?"

        scene e2s10_sd-43 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "I don't really have a life story."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "What? Nothing bad ever happened to you in your life?"

        scene e2s10_sd-46 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "I mean, I've had some bad things happen to me..."

        scene e2s10_sd-43 with dissolve
        sd "But they don't even come close to what you or others have had."

        scene e2s10_sd-47 with dissolve
        sd "To be honest, I've lived a pretty privileged life."

        scene e2s10_sd-46 with dissolve
        sd "I've never felt the hardships of life."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "I mean, that's pretty great!"

        scene e2s10_sd-46 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "Yeah, unfortunately that quickly became boring and I started to hate it."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "You hated having a privileged life?"

        scene e2s10_sd-48 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "There were always people who had something to talk about and hardships to overcome."

        scene e2s10_sd-46 with dissolve
        sd "I had nothing, I was always the perfect kid."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "I understand..."

        scene e2s10_sd-48 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "So, eventually, I got fed up with everything and at 15 I ran away from home."

        scene e2s10_sd-43 with dissolve
        sd "Of course, that didn't last too long because just 3 days later they found me."

        scene e2s10_sd-48 with dissolve
        sd "And from that point onward, I started to live my life the way I wanted."

        scene e2s10_sd-46 with dissolve
        sd "I quickly turned to drugs, alcohol and partying."

        scene e2s10_sd-49 with dissolve
        sd "I wanted to do anything that would make me forget of the perfect life I had."

        scene e2s10_sd-43 with dissolve
        sd "Which of course, in my eyes was far from perfect."

        scene e2s10_sd-48 with dissolve
        sd "I learned my lesson the first time I ran away from home."

        scene e2s10_sd-46 with dissolve
        sd "If I gave my parents reasons to worry about me, I would be back to the fucking perfect life."

        scene e2s10_sd-49 with dissolve
        sd "So, I started doing things in secret and hiding everything from them."

        scene e2s10_sd-48 with dissolve
        sd "When I was with them, I would be this facade of the perfect kid again."

        scene e2s10_sd-49 with dissolve
        sd "But when I was with my friends or alone, I would do anything I wanted regardless of the consequences."

        scene e2s10_sd-42 with dissolve
        show e2s10_sd-sadie_blink4
        mc "Wow..."
        mc "I'm honestly shocked!"

        scene e2s10_sd-37 with dissolve
        hide e2s10_sd-sadie_blink4
        sd "Haha, why?"

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "Even people who have it perfect are miserable."

        scene e2s10_sd-49 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "Don't get me wrong, I'm grateful for everything my parents did for me."

        scene e2s10_sd-48 with dissolve
        sd "I'm grateful for the life I've had."

        scene e2s10_sd-46 with dissolve
        sd "But it's just that I wanted more out of it."

        scene e2s10_sd-37 with dissolve
        sd "You know how the saying goes, we only live once."

        scene e2s10_sd-49 with dissolve
        sd "Why waste my life on being perfect and always sticking to the rules?"

        scene e2s10_sd-36 with dissolve
        sd "When you can have a little fun and do stupid shit now and then?"

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "Yeah, you're right."

        scene e2s10_sd-36 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "Trust me, I would have given a lot to have a 'weird' and 'abnormal' person like you in my life, [mc]!"

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "And I would have given a lot to have a non-judgemental person like you in my life, [sd]!"

        scene e2s10_sd-37 with dissolve
        hide e2s10_sd-sadie_blink3
        sd "I say we drink to that!"

        scene e2s10_sd-35 with dissolve
        show e2s10_sd-sadie_blink3
        mc "Yeah, I agree."

        stop music fadeout 2.0
        scene e2s10_sd-40 with dissolve
        hide e2s10_sd-sadie_blink3
        pause

        play music bloom
        scene e2s10_sd-52 with wipeleft
        pause

        scene e2s10_sd-50 with dissolve
        sd "...and then, she finished her drink and said 'I'm fine guys, I'mma head out'."
        sd "I'm not even joking, right after she said that, she threw up."

        scene e2s10_sd-51 with dissolve
        mc "Haha, what a coincidence!"

        scene e2s10_sd-50 with dissolve
        sd "Yeah!"

        scene e2s10_sd-53 with dissolve
        sd "The worst part is that she threw up a couple more times until she just fell asleep on the floor."

        scene e2s10_sd-51 with dissolve
        mc "Yup, that's what a fine person would do."

        scene e2s10_sd-50 with dissolve
        sd "Totally!"

        scene e2s10_sd-53 with dissolve
        sd "After that incident, she took a break from drinking for like a week."

        scene e2s10_sd-51 with dissolve
        mc "One week?"

        if affinity_spectrum < 0:
            mc "That's not even that long."
        else:
            mc "How did she last that long without alcohol?"

        scene e2s10_sd-50 with dissolve
        sd "Haha, I know right?"

        scene e2s10_sd-53 with dissolve
        sd "It would have been nice to have a fun conclusion to the story..."
        sd "But she just kept on doing the same thing over and over again."

        scene e2s10_sd-54 with dissolve
        mc "Speaking of alcohol, this wine has really started to take a toll on me."

        scene e2s10_sd-53 with dissolve
        sd "I'm sure you're fine."

        scene e2s10_sd-55 with dissolve
        mc "Haha, maybe I should lie down for a bit."

        scene e2s10_sd-56 with dissolve
        if affinity_spectrum >= 0:
            mc "Holy shit, your bed is so comfy!"
        else:
            mc "My God... your bed is so comfy!"

        scene e2s10_sd-57 with dissolve
        sd "I know right?"
        sd "It's like you're sinking into it."

        scene e2s10_sd-56 with dissolve
        mc "Come join me."

        scene e2s10_sd-58 with dissolve
        sd "You're right, it really does feel very comfy."

        scene e2s10_sd-59 with dissolve
        menu:
            "Kiss her":
                $ sadie_trust += 1
                $ e2s10_sadie_sex = True
                call e2s10_sadie_sex from _call_e2s10_sadie_sex

            "Don't kiss her":
                $ sadie_trust -= 1
                scene e2s10_sd-58 with dissolve
                sd "Alright, I'm getting up."

                scene e2s10_sd-57 with dissolve
                sd "I'm starting to feel a little dizzy."

                scene e2s10_sd-56 with dissolve
                mc "So it's not just me?"

                scene e2s10_sd-50 with dissolve
                sd "It would be easier if the world wasn't spinning."

                scene e2s10_sd-51 with dissolve
                mc "Haha, for real!"

                scene e2s10_sd-50 with dissolve
                sd "I'm gonna go to the bathroom real quick."
                sd "When I come back I'm gonna prepare the couch for you."

                scene e2s10_sd-51 with dissolve
                mc "Alright, I'll be waiting."

                scene e2s10_sd-97 with dissolve
                pause

        scene e2s10_sd-98 with dissolve
        pause

        scene e2s10_sd-99 with dissolve
        sd "Okay, I'm done."

        if e2s10_sadie_sex == True:
            if persistent.disable_nsfw == True:
                scene e2s10_sd-109 with dissolve
            else:
                if persistent.type_nsfw == False:
                    scene e2s10_sd-109_cen with dissolve
            mc "Zzz..."
            sd "[mc]?"

            scene e2s10_sd-101 with dissolve
            sd "This dude's already asleep."

            scene e2s10_sd-102 with dissolve
            sd "[mc], wake up!"
            sd "You can't sleep in my bed!"

            if persistent.disable_nsfw == True:
                scene e2s10_sd-109 with dissolve
            else:
                if persistent.type_nsfw == False:
                    scene e2s10_sd-109_cen with dissolve
            mc "ZzzZz..."
            sd "..."

            scene e2s10_sd-107 with dissolve
            sd "Alright... I will let you sleep here just this once."
            sd "Don't think too highly of yourself, I'm only doing this because I'm tired."

            scene e2s10_sd-108 with dissolve
            pause

            scene e2s10_sd-107 with dissolve
            sd "Yeah..."

            if persistent.disable_nsfw == True:
                scene e2s10_sd-106 with vpunch
            else:
                if persistent.type_nsfw == False:
                    scene e2s10_sd-106_cen with vpunch
            pause

            stop music fadeout 2.0
            scene black with Dissolve(2.0)

            scene e2s10_sd-110 with Dissolve(2.0)
            play music little_tomcat
            pause

            scene e2s10_sd-111 with dissolve
            pause

            scene e2s10_sd-112 with dissolve
            pause

            scene e2s10_sd-113 with dissolve
            pause

            if persistent.disable_nsfw == True:
                scene e2s10_sd-114 with dissolve
            else:
                if persistent.type_nsfw == False:
                    scene e2s10_sd-114_cen with dissolve
            mc "Morning!"

            scene e2s10_sd-115 with dissolve
            sd "Good morning [mc]."

            scene e2s10_sd-116 with dissolve
            mc "You know, I could get used to this kind of treatment."

            scene e2s10_sd-117 with dissolve
            sd "Haha, don't get too comfy."

            scene e2s10_sd-118 with dissolve
            sd "You're not living at my place."

            scene e2s10_sd-119 with dissolve
            mc "Haha, fair enough."

            scene e2s10_sd-120 with dissolve
            mc "How did you sleep?"

            if persistent.disable_nsfw == True:
                scene e2s10_sd-121 with dissolve
            else:
                if persistent.type_nsfw == False:
                    scene e2s10_sd-121_cen with dissolve
            sd "Honestly, I haven't been this relaxed in a while."

            scene e2s10_sd-120 with dissolve
            mc "So I'm not the only one who had a great sleep last night."
            sd "Yeah, you could say that."

            scene e2s10_sd-122 with dissolve
            sd "I'll make some coffee, do you want some?"

            scene e2s10_sd-123 with dissolve
            mc "Sure, count me in."
        else:
            scene e2s10_sd-100 with dissolve
            mc "Zzz..."
            sd "[mc]?"

            scene e2s10_sd-101 with dissolve
            sd "This dude's already asleep."

            scene e2s10_sd-102 with dissolve
            sd "[mc], wake up!"
            sd "You can't sleep in my bed!"

            scene e2s10_sd-100 with dissolve
            mc "ZzzZz..."
            sd "..."

            scene e2s10_sd-103 with dissolve
            sd "Alright... I will let you sleep here just this once."
            sd "Don't think too highly of yourself, I'm only doing this because I'm tired."

            scene e2s10_sd-104 with dissolve
            pause

            scene e2s10_sd-103 with dissolve
            sd "Yeah..."

            scene e2s10_sd-105 with dissolve
            pause

            stop music fadeout 2.0
            scene black with Dissolve(2.0)

            scene e2s10_sd-120 with Dissolve(2.0)
            play music little_tomcat
            pause

            scene e2s10_sd-124 with dissolve
            mc "Good morning."

            scene e2s10_sd-120 with dissolve
            sd "Morning [mc]."

            scene e2s10_sd-125 with dissolve
            mc "What time is it?"

            scene e2s10_sd-126 with dissolve
            sd "Somewhere around 10 AM."

            scene e2s10_sd-127 with dissolve
            mc "My head hurts."

            scene e2s10_sd-125 with dissolve
            mc "How much did we drink?"

            scene e2s10_sd-128 with dissolve
            sd "We had a bottle of wine."
            sd "I don't know about your previous drinks though."

            scene e2s10_sd-125 with dissolve
            mc "I understand."

            scene e2s10_sd-129 with dissolve
            sd "Want some coffee?"

            scene e2s10_sd-130 with dissolve
            mc "Sure, count me in."

        scene e2s10_sd-131 with dissolve
        pause

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "So... what are your plans for the day?"

        scene e2s10_sd-133 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "I'll probably clean the apartment a little bit."
        sd "And maybe go out."

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "I see."
        mc "So, not a lot going on."

        scene e2s10_sd-134 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Yeah, not really."

        scene e2s10_sd-133 with dissolve
        sd "What about you?"

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "I don't know to be honest."
        mc "I'll have to check in with [jon] and see what he has planned."
        mc "He wanted to introduce me to some kind of group."

        scene e2s10_sd-135 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Oh, you're joining a group?"

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "Yeah."
        mc "They're good as time fillers."

        scene e2s10_sd-134 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "I was also asked to join a couple of groups but I don't know if I'll do it."

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "Why not?"

        scene e2s10_sd-134 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "I don't know..."

        scene e2s10_sd-133 with dissolve
        sd "I like to have my own free time and to choose what I want to do."

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "Fair enough."

        scene e2s10_sd-133 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "So... you were saying about how Eddy's was trashed."

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "Yeah, what about it?"

        scene e2s10_sd-133 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Is there any news?"

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "At the moment, I don't know."
        mc "I haven't asked [jon] about it."

        scene e2s10_sd-136 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Who would do that, though?"
        sd "I've always heard good things about that party."

        scene e2s10_sd-137 with dissolve
        sd "This is probably the first year in which they didn't hold it."

        scene e2s10_sd-138 with dissolve
        sd "People really loved it!"

        scene e2s10_sd-137 with dissolve
        sd "I wonder what changed..."

        scene e2s10_sd-139 with dissolve
        show e2s10_sd-sadie_blink5
        mc "Maybe their leadership team has changed."

        scene e2s10_sd-137 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Maybe... who knows?"

        if e1s18_sadie_greet == True:
            scene e2s10_sd-139 with dissolve
            show e2s10_sd-sadie_blink5
            mc "Hey, there's been something on my mind lately."

            scene e2s10_sd-133 with dissolve
            hide e2s10_sd-sadie_blink5
            sd "Shoot!"

            scene e2s10_sd-132 with dissolve
            show e2s10_sd-sadie_blink5
            mc "What did you ask the bouncer that night at Cabanna's?"

            scene e2s10_sd-135 with dissolve
            hide e2s10_sd-sadie_blink5
            sd "Oh, you're really curious, aren't you?"

            scene e2s10_sd-133 with dissolve
            sd "I promised him a couple of lap dances from the girls at Eddy's."

            scene e2s10_sd-134 with dissolve
            sd "I thought that I can call [jon] and arrange it."

            scene e2s10_sd-132 with dissolve
            show e2s10_sd-sadie_blink5
            mc "Haha, smart."
            mc "And, did you talk to [jon] about it?"

            scene e2s10_sd-134 with dissolve
            hide e2s10_sd-sadie_blink5
            sd "Nope."
            sd "And probably never will."

            scene e2s10_sd-132 with dissolve
            show e2s10_sd-sadie_blink5
            mc "Haha, you're crazy!"

            scene e2s10_sd-133 with dissolve
            hide e2s10_sd-sadie_blink5
            sd "If it works then why not?"

            scene e2s10_sd-132 with dissolve
            show e2s10_sd-sadie_blink5
            mc "I guess you're right."
        else:
            scene e2s10_sd-132 with dissolve
            show e2s10_sd-sadie_blink5
        mc "Thanks [sd] for having me, I'll be on my way."

        scene e2s10_sd-133 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "No problem dude."

        scene e2s10_sd-135 with dissolve
        sd "Take care on the way back, alright?"

        scene e2s10_sd-132 with dissolve
        show e2s10_sd-sadie_blink5
        mc "I will."
        mc "See you around!"

        scene e2s10_sd-133 with dissolve
        hide e2s10_sd-sadie_blink5
        sd "Bye!"

        scene e2s10_sd-140 with dissolve
        pause

        scene e2s10_sd-141 with dissolve
        jon "[mc]?"

        scene e2s10_sd-142 with dissolve
        mc "[jon]?"

        scene e2s10_sd-143 with dissolve
        jon "What are you doing here?"

        scene e2s10_sd-144 with dissolve
        show e2s10_sd-jon_blink1
        mc "I crashed at [sd]'s."

        scene e2s10_sd-145 with dissolve
        hide e2s10_sd-jon_blink1
        jon "Damn, already?"

        scene e2s10_sd-146 with dissolve
        show e2s10_sd-jon_blink1
        if affinity_spectrum <= 0:
            mc "Don't get any wrong ideas."
        else:
            mc "Yeah dude!"
            mc "We're also getting married next week."

            scene e2s10_sd-147 with dissolve
            hide e2s10_sd-jon_blink1
            jon "Great dude, I'm happy for you!"

            scene e2s10_sd-146 with dissolve
            show e2s10_sd-jon_blink1
            mc "You can also be my best man."

            scene e2s10_sd-143 with dissolve
            hide e2s10_sd-jon_blink1
            jon "You know I would do that for you."

            scene e2s10_sd-144 with dissolve
            show e2s10_sd-jon_blink1
            mc "Sure, I know you would."

        mc "I've lost my dorm key and she said I could sleep the night at her place."

        scene e2s10_sd-145 with dissolve
        hide e2s10_sd-jon_blink1
        jon "Damn, you're moving fast, aren't you?"

        scene e2s10_sd-147 with dissolve
        jon "First... she talks about you a lot, and now you're sleeping together."

        scene e2s10_sd-148 with dissolve
        jon "That's my boy!"

        scene e2s10_sd-146 with dissolve
        show e2s10_sd-jon_blink1
        mc "Haha, shut up!"
        mc "Let's get going."

        scene e2s10_sd-149 with dissolve
        pause

        jump e2s11

    # Jon ######################################################################
    if e2s10_jon == True:
        scene e2s10_jon-29 with Dissolve(2.0)
        play music open_inside
        define e2s10_tracks = ["party/instrumentals/area_51.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/encryption.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/random_drop.ogg", "party/instrumentals/turn_up.ogg"]
        $ renpy.music.queue (e2s10_tracks, loop=True)

        $ renpy.random.shuffle(e2s10_tracks)
        mc "*So... here I am.*"
        mc "*Is this a club?*"
        mc "*What are they doing here?*"

        scene e2s10_jon-27 with dissolve
        pause
        jon "Hey [mc]!"

        scene e2s10_jon-28 with dissolve
        jon "Over here!"

        scene e2s10_jon-34 with dissolve
        mc "Hey guys, what's up?"

        scene e2s10_jon-30 with dissolve
        jon "Nothing, we're just chilling."
        jon "Waiting for some pussy to show up."

        scene e2s10_jon-31 with dissolve
        mc "Why do I feel like I'm sitting at a mafia table?"

        scene e2s10_jon-33 with dissolve
        ke "Maybe because you are?"

        scene e2s10_jon-32 with dissolve
        mc "Oh, okay."

        scene e2s10_jon-30 with dissolve
        jon "So, listen up [mc]."
        jon "I've got a good idea to end this night on a high note."

        scene e2s10_jon-35 with dissolve
        jon "The rules are simple..."
        jon "Whoever goes home with a chick tonight wins {color=#4CBB17}5${/color}."

        scene e2s10_jon-30 with dissolve
        jon "But the catch is that we all add {color=#4CBB17}$1{/color} to the bet."

        scene e2s10_jon-35 with dissolve
        jon "And we're gonna choose which chick you're gonna talk to."
        jon "Are you in?"

        if affinity_spectrum > 0:
            scene e2s10_jon-32 with dissolve
            mc "So... do I only need to go home with her?"
            mc "Or should I bang her as well?"

            scene e2s10_jon-36 with dissolve
            jon "Honestly, it's your choice."

            scene e2s10_jon-37 with dissolve
            mc "Hmm... interesting offer..."
            mc "Wait... hold on."
            mc "How the fuck am I gonna take a chick home?"
        else:
            scene e2s10_jon-37 with dissolve
            mc "Wait... hold on."
            mc "How am I even gonna take a chick home?"

        mc "I don't have my keys on me and I'm gonna sleep at [jon]'s."

        scene e2s10_jon-38 with dissolve
        jon "Alright, alright."
        jon "You can either get their number or sleep at their place, your call."

        scene e2s10_jon-39 with dissolve
        jon "Everyone else, the rules are the same as before."

        scene e2s10_jon-37 with dissolve
        mc "Let me think..."
        mc "What if there's more than one of us that goes home with a chick?"

        scene e2s10_jon-36 with dissolve
        jon "The money is split into equal parts."

        scene e2s10_jon-37 with dissolve
        mc "So... if we all go home with a chick, we're basically getting our money back?"

        scene e2s10_jon-40 with dissolve
        jon "That, and a pussy!"

        scene e2s10_jon-41 with dissolve
        jon "Isn't it a deal?"

        $ GameRunning = True

        while GameRunning:
            $ renpy.show_screen("money_notify_pers")
            scene e2s10_jon-32 with dissolve
            menu:
                "I'm in {color=#f00}(-$1){/color}" if money >= 1:
                    call extrovert_affinity_check from _call_extrovert_affinity_check_27
                    call color_check from _call_color_check_53
                    $ e2s10_seduce = True
                    $ money -= 1
                    $ jon_friendship += 1
                    $ GameRunning = False

                    scene e2s10_jon-32 with dissolve
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    mc "I'm in!"

                "Explain the rules again":
                    scene e2s10_jon-32 with dissolve
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    mc "Hey, can you explain the rules again?"

                    scene e2s10_jon-36 with dissolve
                    jon "So, [mc]..."

                    scene e2s10_jon-38 with dissolve
                    jon "The rules are simple..."

                    scene e2s10_jon-36 with dissolve
                    jon "Whoever goes home with a chick tonight wins {color=#4CBB17}5${/color}."
                    jon "But the catch is that we all add {color=#4CBB17}$1{/color} to the bet."
                    jon "And we're gonna choose which chick you're gonna talk to."

                    scene e2s10_jon-38 with dissolve
                    jon "Also, if there's more than one of us that goes home with a chick..."
                    jon "...the money is split into equal parts."

                    scene e2s10_jon-37 with dissolve
                    mc "So... if we all go home with a chick, we're basically getting our money back?"

                    scene e2s10_jon-40 with dissolve
                    jon "That, and a pussy!"

                    scene e2s10_jon-41 with dissolve
                    jon "Isn't it a deal?"
                "I'm out":
                    $ GameRunning = False

                    scene e2s10_jon-32 with dissolve
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")
                    mc "Sorry guys... I'm out."

                    scene e2s10_jon-42 with dissolve
                    jon "Booo!"

                    scene e2s10_jon-43 with dissolve
                    jd "Are you kidding me?"
                    jd "We've spent all this time planning this awesome activity..."
                    jd "And you're just gonna say no?"

                    scene e2s10_jon-44 with dissolve
                    menu:
                        "No money":
                            $ jon_friendship += 1
                            $ e2s10_seduce = True
                            $ e2s10_no_money = True
                            scene e2s10_jon-37 with dissolve
                            mc "I'm sorry guys..."
                            mc "I don't have any money on me..."

                            scene e2s10_jon-38 with dissolve
                            jon "Bro..."

                            scene e2s10_jon-35 with dissolve
                            jon "Why didn't you say so?"

                            scene e2s10_jon-30 with dissolve
                            jon "Come on, I'm gonna give you {color=#4CBB17}$1{/color} to add to the bet."

                            $ money += 1
                            $ renpy.show_screen("money_notify_pers")
                            scene e2s10_jon-32 with dissolve
                            pause(0.5)
                            $ money -= 1
                            pause(0.5)
                            $ renpy.show_screen("money_notify")
                            $ renpy.hide_screen("money_notify_pers")
                            mc "Alright, alright."

                        "Not interested":
                            call introvert_affinity_check from _call_introvert_affinity_check_23
                            call color_check from _call_color_check_54
                            scene e2s10_jon-37 with dissolve
                            mc "Yeah, I'm not really interested in this..."
                            mc "I'm sorry!"

                            scene e2s10_jon-45 with dissolve
                            ro "It's alright bro, don't worry."
                            ro "I wasn't interested either when I heard about this idea."
                            ro "Let's just drink and enjoy the rest of the night, alright?"

                            scene e2s10_jon-46 with dissolve
                            mc "Sure, that sounds like a better idea."

        scene black with Dissolve(2.0)

        if e2s10_seduce == False:
            scene e2s10_jon-32 with dissolve
            mc "Hey guys, I'm gonna go to the bathroom."

            scene e2s10_jon-35 with dissolve
            jon "Alright, don't be long!"
            jon "You wouldn't want to miss the cold approaches."

            scene e2s10_jon-32 with dissolve
            mc "Haha, yeah!"

            scene e2s10_jon-47 with dissolve
            pause

            scene e2s10_jon-48 with dissolve
            pause

            scene e2s10_jon-49 with dissolve
            pause

            if affinity_spectrum > 0:
                scene e2s10_jon-50 with dissolve
                unknown "Hey sweetie!"
                unknown "You look like you'd need a release."

                scene e2s10_jon-52 with dissolve
                unknown "How about I offer you a dance?"

                scene e2s10_jon-52 with dissolve
                unknown "You're pretty cute so I'm going to give you a discount."
                unknown "{color=#4CBB17}$1{/color} for a lap dance with no touching and {color=#4CBB17}$2{/color} for touching."

                scene e2s10_jon-53 with dissolve
                unknown "So... what do you say?"

                scene e2s10_jon-51 with dissolve
                show e2s10_jon-candance_blink1
                $ renpy.show_screen("money_notify_pers")
                menu:
                    "Accept her first offer {color=#f00}(-$1){/color}" if money > 0:
                        $ e2s10_lap_dance = 1
                        $ money -= 1
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Alright, I'll take your {color=#4CBB17}$1{/color} lap dance."

                        scene e2s10_jon-52 with dissolve
                        unknown "Okay sweetie, go to the third private dance room and wait for me there."
                        unknown "I'll be there in a second."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Okay."

                        scene black with Dissolve(2.0)
                        hide e2s10_jon-candance_blink1
                        call e2s10_lap_dance from _call_e2s10_lap_dance
                    "Accept her second offer {color=#f00}(-$2){/color}" if money > 1:
                        $ candance_trust += 1
                        $ e2s10_lap_dance = 2
                        $ persistent.e2s10_lap_dance = 2
                        $ money -= 2
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Alright, I'll take your {color=#4CBB17}$2{/color} dance."

                        scene e2s10_jon-53 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "You like to touch, don't you?"
                        unknown "I like a man who knows what he wants!"

                        scene e2s10_jon-52 with dissolve
                        unknown "go to the third private dance room and wait for me there."
                        unknown "I'll be there in a second."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Okay."

                        scene black with Dissolve(2.0)
                        hide e2s10_jon-candance_blink1
                        call e2s10_lap_dance from _call_e2s10_lap_dance_1
                    "Refuse her offer":
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Sorry, I'm not interested."
                        mc "Thank you for your offer."

                        scene e2s10_jon-52 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "Don't worry sweetie."

                        scene e2s10_jon-53 with dissolve
                        unknown "If you change your mind, you know where to find me."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Alright, thank you!"

                        scene e2s10_jon-54 with dissolve
                        hide e2s10_jon-candance_blink1
                        pause
                    "Ask [jon] for some money" if jon_friendship > 3:
                        $ e2s10_lap_dance = 3
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Hey, I'm gonna be right back."
                        mc "Gotta do something real quick."

                        scene e2s10_jon-52 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "Alright sweetie, I'll be waiting."

                        scene e2s10_jon-106 with dissolve
                        pause

                        scene e2s10_jon-47 with dissolve
                        mc "Hey [jon]."

                        scene e2s10_jon-103 with dissolve
                        jon "[mc], what's up my friend?"
                        jon "Are you back already from the bathroom?"

                        scene e2s10_jon-105 with dissolve
                        mc "No... that's the thing."
                        menu:
                            "Tell him":
                                call extrovert_affinity_check from _call_extrovert_affinity_check_28
                                call color_check from _call_color_check_55
                                mc "I was wondering if you could lend me {color=#4CBB17}$1{/color} or {color=#4CBB17}$2{/color} to get a lap dance."

                                $ persistent.e2s10_lap_dance = 2

                            "Lie":
                                call introvert_affinity_check from _call_introvert_affinity_check_24
                                call color_check from _call_color_check_56
                                mc "I need {color=#4CBB17}$1{/color} to enter the bathroom."

                                scene e2s10_jon-104 with dissolve
                                jon "Don't be silly [mc]..."
                                jon "There's no entry fee to the bathroom."

                                scene e2s10_jon-103 with dissolve
                                jon "Tell me, why do you really need the money?"

                                scene e2s10_jon-105 with dissolve
                                mc "I wanted to get a lap dance."

                                scene e2s10_jon-107 with dissolve
                                jon "Why didn't you say so?"

                                $ persistent.e2s10_lap_dance = 1

                        scene e2s10_jon-103 with dissolve
                        jon "Of course I'll give you money bro, go enjoy yourself!"

                        scene e2s10_jon-105 with dissolve
                        mc "Thanks dude!"

                        scene e2s10_jon-103 with dissolve
                        jon "No problem bro."

                        scene e2s10_jon-104 with dissolve
                        jon "Now go and have a good time!"

                        scene e2s10_jon-105 with dissolve
                        mc "Alright, be right back."

                        scene e2s10_jon-48 with dissolve
                        pause

                        call e2s10_lap_dance from _call_e2s10_lap_dance_2

        if e2s10_seduce == True:
            scene e2s10_jon-37 with Dissolve(2.0)

            scene e2s10_jon-39 with dissolve
            jon "Alright guys."
            jon "Let's decide who goes first."

            if e2s10_no_money == True:
                scene e2s10_jon-38 with dissolve
                jon "Obviously, since [mc] didn't add anything to the bet..."

                scene e2s10_jon-36 with dissolve
                jon "I'd say it's fair that he should go first."

                scene e2s10_jon-43 with dissolve
                jd "Seems pretty fair to me."

                scene e2s10_jon-32 with dissolve
                mc "Alright, fair enough."
                mc "I'll go first."

                scene e2s10_jon-30 with dissolve
                jon "Good!"

                scene e2s10_jon-35 with dissolve
                jon "Now, hang on a little bit, I'm gonna talk to the guys to choose who you should talk to tonight."

                scene e2s10_jon-32 with dissolve
                mc "Alright."
                mc "While you decide, I'm gonna go to the bathroom."

                scene e2s10_jon-35 with dissolve
                jon "Alright, don't be long."

                scene e2s10_jon-47 with dissolve
                pause

                scene e2s10_jon-48 with dissolve
                pause
            else:
                scene e2s10_jon-116 with dissolve
                ro "How are we gonna do that exactly?"

                scene e2s10_jon-117 with dissolve
                jon "I'm glad you asked!"

                scene e2s10_jon-118 with dissolve
                jon "There's 5 beers on the table right now."

                scene e2s10_jon-117 with dissolve
                jon "They're all full so there's no unfair advantage."

                scene e2s10_jon-30 with dissolve
                jon "Last to finish their beer goes first!"

                scene e2s10_jon-117 with dissolve
                jon "We're gonna do that every single time someone needs to go..."

                scene e2s10_jon-41 with dissolve
                jon "...so if you're last, you might be a little dizzy."

                scene e2s10_jon-40 with dissolve
                jon "But don't worry, that will make the game even funnier!"

                scene e2s10_jon-117 with dissolve
                jon "Alright, shall we start?"
                jon "Did you guys get it?"

                scene e2s10_jon-108 with dissolve
                jd "Seems pretty easy to me!"

                scene e2s10_jon-33 with dissolve
                ke "Alright, let's do it!"

                scene e2s10_jon-41 with dissolve
                jon "That's what I like to hear!"

                scene e2s10_jon-40 with dissolve
                jon "Are you ready [mc]?"

                scene e2s10_jon-32 with dissolve
                if affinity_spectrum > 0:
                    mc "I was born ready."
                else:
                    mc "Yeah, I think I'm ready."

                scene e2s10_jon-119 with dissolve
                jon "Alright, let's get this beer down!"

                scene e2s10_jon-120 with dissolve
                menu:
                    "Try not to finish last":
                        call extrovert_affinity_check from _call_extrovert_affinity_check_29
                        call color_check from _call_color_check_57
                        scene e2s10_jon-121 with dissolve
                        pause

                        scene e2s10_jon-122 with dissolve
                        pause

                        scene e2s10_jon-123 with vpunch
                        jd "Haha, that's how you do it!"

                        scene e2s10_jon-124 with dissolve
                        jon "I'm just getting started."

                        scene e2s10_jon-126 with dissolve
                        pause

                        scene e2s10_jon-127 with dissolve
                        jon "Oww... looks like you're gonna go first my dude."

                        scene e2s10_jon-30 with dissolve
                        jon "Your drinking game isn't that great but don't worry, we'll take care of that!"

                        scene e2s10_jon-128 with dissolve
                        ro "Haha, I thought I was gonna finish last!"

                        scene e2s10_jon-117 with dissolve
                        jon "[ro], in life, you need to know that there's always someone worse."

                        scene e2s10_jon-32 with dissolve
                        if affinity_spectrum < 0:
                            mc "Thanks?"
                        else:
                            mc "Ha ha, fuck you!"

                        scene e2s10_jon-30 with dissolve
                        jon "Anyways..."

                        scene e2s10_jon-35 with dissolve
                        jon "Now, hang on a little bit, I'm gonna talk to the guys to choose who you should talk to tonight."

                        scene e2s10_jon-32 with dissolve
                        mc "Alright."
                        mc "While you decide, I'm gonna go to the bathroom."

                        scene e2s10_jon-35 with dissolve
                        jon "Alright, don't be long."

                        scene e2s10_jon-130 with dissolve
                        pause

                        scene e2s10_jon-132 with dissolve
                        pause
                    "Finish last and get it over with":
                        $ jon_friendship -= 1
                        call introvert_affinity_check from _call_introvert_affinity_check_25
                        call color_check from _call_color_check_58
                        scene e2s10_jon-121 with dissolve
                        pause

                        scene e2s10_jon-122 with dissolve
                        pause

                        scene e2s10_jon-123 with vpunch
                        jd "Haha, that's how you do it!"

                        scene e2s10_jon-124 with dissolve
                        jon "I'm just getting started."

                        scene e2s10_jon-125 with dissolve
                        pause

                        scene e2s10_jon-126 with dissolve
                        pause

                        scene e2s10_jon-36 with dissolve
                        jon "What the fuck dude?"

                        scene e2s10_jon-38 with dissolve
                        jon "Looks like you didn't even try."

                        scene e2s10_jon-37 with dissolve
                        mc "I'm just bad at this, what can I say?"

                        scene e2s10_jon-129 with dissolve
                        jon "Whatever."
                        jon "You go first [mc]... if that's what you want."

                        scene e2s10_jon-38 with dissolve
                        jon "I'm gonna talk to the guys to choose who you should talk to tonight."
                        jon "Hang on a little bit."

                        scene e2s10_jon-37 with dissolve
                        mc "Alright."
                        mc "While you decide, I'm gonna go to the bathroom."

                        scene e2s10_jon-38 with dissolve
                        jon "Alright, don't be long."

                        scene e2s10_jon-131 with dissolve
                        pause

                        scene e2s10_jon-133 with dissolve
                        pause

            scene e2s10_jon-49 with dissolve
            pause

            if affinity_spectrum > 0:
                scene e2s10_jon-50 with dissolve
                unknown "Hey sweetie!"
                unknown "You look like you'd need a release."

                scene e2s10_jon-52 with dissolve
                unknown "How about I offer you a dance?"

                scene e2s10_jon-52 with dissolve
                unknown "You're pretty cute so I'm going to give you a discount."
                unknown "{color=#4CBB17}$1{/color} for a lap dance with no touching and {color=#4CBB17}$2{/color} for touching."

                scene e2s10_jon-53 with dissolve
                unknown "So... what do you say?"

                scene e2s10_jon-51 with dissolve
                show e2s10_jon-candance_blink1
                $ renpy.show_screen("money_notify_pers")
                menu:
                    "Accept her first offer {color=#f00}(-$1){/color}" if money > 0:
                        $ e2s10_lap_dance = 1
                        $ money -= 1
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Alright, I'll take your {color=#4CBB17}$1{/color} lap dance."

                        scene e2s10_jon-52 with dissolve
                        unknown "Okay sweetie, go to the third private dance room and wait for me there."
                        unknown "I'll be there in a second."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Okay."

                        scene black with Dissolve(2.0)
                        hide e2s10_jon-candance_blink1
                        call e2s10_lap_dance from _call_e2s10_lap_dance_3
                    "Accept her second offer {color=#f00}(-$2){/color}" if money > 1:
                        $ candance_trust += 1
                        $ e2s10_lap_dance = 2
                        $ persistent.e2s10_lap_dance = 2
                        $ money -= 2
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Alright, I'll take your {color=#4CBB17}$2{/color} dance."

                        scene e2s10_jon-53 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "You like to touch, don't you?"
                        unknown "I like a man who knows what he wants!"

                        scene e2s10_jon-52 with dissolve
                        unknown "go to the third private dance room and wait for me there."
                        unknown "I'll be there in a second."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Okay."

                        scene black with Dissolve(2.0)
                        hide e2s10_jon-candance_blink1
                        call e2s10_lap_dance from _call_e2s10_lap_dance_4
                    "Refuse her offer":
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Sorry, I'm not interested."
                        mc "Thank you for your offer."

                        scene e2s10_jon-52 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "Don't worry sweetie."

                        scene e2s10_jon-53 with dissolve
                        unknown "If you change your mind, you know where to find me."

                        scene e2s10_jon-51 with dissolve
                        show e2s10_jon-candance_blink1
                        mc "Alright, thank you!"

                        scene e2s10_jon-54 with dissolve
                        hide e2s10_jon-candance_blink1
                        pause
                    "Ask [jon] for some money" if jon_friendship > 3:
                        $ e2s10_lap_dance = 3
                        $ persistent.e2s10_lap_dance = 2
                        $ renpy.show_screen("money_notify")
                        $ renpy.hide_screen("money_notify_pers")
                        mc "Hey, I'm gonna be right back."
                        mc "Gotta do something real quick."

                        scene e2s10_jon-52 with dissolve
                        hide e2s10_jon-candance_blink1
                        unknown "Alright sweetie, I'll be waiting."

                        scene e2s10_jon-106 with dissolve
                        pause

                        scene e2s10_jon-47 with dissolve
                        mc "Hey [jon]."

                        scene e2s10_jon-103 with dissolve
                        jon "[mc], what's up my friend?"
                        jon "Are you back already from the bathroom?"

                        scene e2s10_jon-105 with dissolve
                        mc "No... that's the thing."
                        menu:
                            "Tell him":
                                call extrovert_affinity_check from _call_extrovert_affinity_check_30
                                call color_check from _call_color_check_59
                                mc "I was wondering if you could borrow me {color=#4CBB17}$1{/color} or {color=#4CBB17}$2{/color} to get a lap dance."

                            "Lie":
                                call introvert_affinity_check from _call_introvert_affinity_check_26
                                call color_check from _call_color_check_60
                                mc "I need {color=#4CBB17}$1{/color} to enter the bathroom."

                                scene e2s10_jon-104 with dissolve
                                jon "Don't be silly [mc]..."
                                jon "There's no entry fee to the bathroom."

                                scene e2s10_jon-103 with dissolve
                                jon "Tell me, why do you really need the money?"

                                scene e2s10_jon-105 with dissolve
                                mc "I wanted to get a lap dance."

                                scene e2s10_jon-107 with dissolve
                                jon "Why didn't you say so?"

                        scene e2s10_jon-103 with dissolve
                        jon "Of course I'll give you money bro, go enjoy yourself!"

                        scene e2s10_jon-108 with dissolve
                        jd "But, but..."
                        jd "What about our activity?"

                        scene e2s10_jon-109 with dissolve
                        jon "Don't worry about it [jd]."
                        jon "[mc]'s still going to cold approach someone."
                        jon "After he enjoys his little lap dance, he'll come back and do the challenge."

                        scene e2s10_jon-104 with dissolve
                        jon "If he doesn't, he'll have to pay {color=#4CBB17}3$.{/color}"

                        scene e2s10_jon-105 with dissolve
                        mc "Oh shit, alright."

                        scene e2s10_jon-105 with dissolve
                        mc "Thanks dude!"

                        scene e2s10_jon-103 with dissolve
                        jon "No problem bro."

                        scene e2s10_jon-104 with dissolve
                        jon "Now, go and have a good time!"

                        scene e2s10_jon-105 with dissolve
                        mc "Alright, be right back."

                        scene e2s10_jon-48 with dissolve
                        pause

                        call e2s10_lap_dance from _call_e2s10_lap_dance_5

                scene black with Dissolve(2.0)
            else:
                scene e2s10_jon-54 with dissolve
                pause

                scene black with Dissolve(2.0)

            scene e2s10_jon-106 with dissolve
            pause

            if e2s10_no_money == True:
                scene e2s10_jon-47 with dissolve
            else:
                scene e2s10_jon-130 with dissolve
            mc "Hey guys!"

            if e2s10_lap_dance == 0 or e2s10_lap_dance == 3:
                scene e2s10_jon-30 with dissolve
                jon "Hey [mc]!"
            else:
                scene e2s10_jon-36 with dissolve
                jon "Hey man, what took you so long?"

                scene e2s10_jon-37 with dissolve
                menu:
                    "Tell him about the lap dance":
                        call extrovert_affinity_check from _call_extrovert_affinity_check_31
                        call color_check from _call_color_check_61
                        mc "Sorry man, I got sidetracked on the way to the bathroom and got a lap dance."

                        scene e2s10_jon-40 with dissolve
                        jon "Hahaha, nice!"

                        scene e2s10_jon-30 with dissolve
                        jon "So that means that now you're in the mood for some cold approaching."

                    "Lie to him":
                        $ jon_friendship -= 1
                        mc "Sorry man, there was a huge waiting line at the bathroom."

                        scene e2s10_jon-38 with dissolve
                        jon "Oh, alright."

                        scene e2s10_jon-30 with dissolve
                        jon "Let's get back to our cold approaching, shall we?"

            scene e2s10_jon-35 with dissolve
            jon "You see that chick with curly hair sitting at the bar?"

            scene e2s10_jon-115 with dissolve
            jon "We've agreed that that's your target."

            scene e2s10_jon-32 with dissolve
            if affinity_spectrum < 0:
                mc "Alright, I guess."
            else:
                mc "Alright, alright."

            scene e2s10_jon-132 with dissolve
            pause

            scene e2s10_jon-49 with dissolve
            pause

            scene e2s10_jon-06 with dissolve
            mc "*Oh, what the f...*"
            mc "*You can't be serious...*"
            mc "*Our math teacher, in a club?*"
            mc "*Is she waiting to be hit on?*"
            menu:
                "Bail on them":
                    call introvert_affinity_check from _call_introvert_affinity_check_27
                    call color_check from _call_color_check_62
                    if affinity_spectrum > 0:
                        mc "*Nah, fuck it!*"
                        mc "*I might be crazy, but in no universe am I gonna hit on my teacher.*"
                    else:
                        mc "*Hell no, I'm not doing it!*"
                        mc "*Imagine the embarrassment I'll go through if I even try.*"

                    scene e2s10_jon-106 with dissolve
                    pause

                    scene e2s10_jon-130 with dissolve
                    pause

                    scene e2s10_jon-36 with dissolve
                    jon "Yo, what the fuck man?"

                    scene e2s10_jon-43 with dissolve
                    jd "Yeah, what are you doing?"

                    scene e2s10_jon-37 with dissolve
                    mc "Sorry guys, I'm not doing it."

                    scene e2s10_jon-36 with dissolve
                    jon "What? Why?"

                    scene e2s10_jon-37 with dissolve
                    if affinity_spectrum > 0:
                        mc "You know why, [jon]."
                        mc "That's our math teacher!"
                    else:
                        mc "Did you know that she's our math teacher?"

                        scene e2s10_jon-38 with dissolve
                        jon "She is?"

                        scene e2s10_jon-129 with dissolve
                        jon "Damn... I didn't even notice."

                        scene e2s10_jon-37 with dissolve
                        mc "Yeah, you totally knew."

                    scene e2s10_jon-36 with dissolve
                    jon "So what?"
                    jon "She's pretty hot, plus it would have been funny!"

                    scene e2s10_jon-37 with dissolve
                    mc "Nah, I'm not gonna hit on my math teacher, sorry guys."

                    scene e2s10_jon-108 with dissolve
                    jd "So, we have the first loser of the night!"

                    if e2s10_lap_dance == 3:
                        scene e2s10_jon-38 with dissolve
                        jon "Yup!"

                        scene e2s10_jon-36 with dissolve
                        jon "And you owe me {color=#4CBB17}3$.{/color}"

                        scene e2s10_jon-37 with dissolve
                        if money >= 3:
                            mc "Alright, here."
                            mc "You can have them."
                        else:
                            mc "Uh... sorry dude."
                            mc "I don't have any money on me right now."
                            mc "But I'll give it back."

                        scene e2s10_jon-30 with dissolve
                        jon "Relax dude, I'm joking."

                        scene e2s10_jon-35 with dissolve
                        jon "I'm not gonna rip you off {color=#4CBB17}3${/color}."

                        scene e2s10_jon-30 with dissolve
                        jon "So we're chill."

                        if e2s10_seduce == True:
                            scene e2s10_jon-36 with dissolve
                            jon "Although, it was not cool that you didn't do the dare."

                            scene e2s10_jon-38 with dissolve
                            jon "Even if she's our math teacher, a dare is a dare."
                        else:
                            scene e2s10_jon-38 with dissolve
                    jon "Anyways..."

                    scene e2s10_jon-117 with dissolve
                    jon "Let's see who goes next!"
                "Go for it":
                    call extrovert_affinity_check from _call_extrovert_affinity_check_32
                    call color_check from _call_color_check_63
                    if affinity_spectrum >= 0:
                        mc "*You know what?*"
                        mc "*Fuck it, I'm doing it!*"
                        mc "*What's the worst thing that could happen?*"
                    else:
                        mc "*I just hope this turns out for the best.*"

                    menu:
                        "Check her out":
                            scene e2s10_jon-15 with dissolve
                            pause

                            scene e2s10_jon-06 with dissolve
                        "Don't risk it":
                            pass

                    mc "*Let's evaluate my options here.*"
                    mc "*I'm like 99 percent certain she doesn't know that I'm her student.*"
                    mc "*If I lie to her just to win the bet, she is probably going to forget about it.*"
                    mc "*But if she doesn't, then I'm screwed...*"
                    mc "*I'll need to play my cards right.*"
                    mc "*I'm gonna worry about the details later, I've sat here for too long.*"

                    menu:
                        "Flirty approach" if affinity_spectrum > 0:
                            call extrovert_affinity_check from _call_extrovert_affinity_check_33
                            call color_check from _call_color_check_64

                            scene e2s10_jon-01 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "Hey!"

                            scene e2s10_jon-02 with dissolve
                            hide e2s10_jon-bridget_blink1
                            br "Hi!"

                            scene e2s10_jon-01 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "You wouldn't know it... but I got a thing for curly haired chicks."

                            scene e2s10_jon-02 with dissolve
                            hide e2s10_jon-bridget_blink1
                            br "Oh, really?"

                            scene e2s10_jon-01 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "For sure, they're my weakness."

                            scene e2s10_jon-03 with dissolve
                            hide e2s10_jon-bridget_blink1
                            br "Haha."

                            scene e2s10_jon-04 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "You know... you've got a lot of beautiful curves, but your smile is absolutely my favourite."

                            scene e2s10_jon-05 with dissolve
                            hide e2s10_jon-bridget_blink1
                            br "Aren't you Prince Charming?"

                            scene e2s10_jon-04 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "I wish..."
                            mc "Unfortunately, I'm just [mc]."

                            scene e2s10_jon-03 with dissolve
                            hide e2s10_jon-bridget_blink1
                            br "Haha, I'm [br]!"

                            scene e2s10_jon-04 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "So what brings you around here?"
                        "Friendly approach":
                            call introvert_affinity_check from _call_introvert_affinity_check_28
                            call color_check from _call_color_check_65

                            $ affinity_spectrum = -10

                            mc "Hi!"

                            scene e2s10_jon-07 with dissolve
                            mc "I'm [mc]."
                            mc "Mind if I join you?"

                            scene e2s10_jon-08 with dissolve
                            br "Fine by me."

                            scene e2s10_jon-02 with dissolve
                            br "My name's [br]."

                            scene e2s10_jon-01 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "Nice to meet you [br]."

                            scene e2s10_jon-02 with dissolve
                            br "You too, [mc]!"

                            scene e2s10_jon-01 with dissolve
                            show e2s10_jon-bridget_blink1
                            mc "So... what brings you around here?"

                    scene e2s10_jon-09 with dissolve
                    hide e2s10_jon-bridget_blink1
                    br "Nothing really, just wanted to enjoy a couple of drinks."

                    scene e2s10_jon-10 with dissolve
                    mc "Hey [ba], could you get me a glass of whiskey?"

                    if affinity_spectrum > 0:
                        scene e2s10_jon-11 with dissolve
                        mc "And one for the lady too."

                        scene e2s10_jon-12 with dissolve
                        ba "Sure thing."

                    scene e2s10_jon-13 with dissolve
                    br "What about you?"

                    scene e2s10_jon-14 with dissolve
                    show e2s10_jon-bridget_blink1
                    menu:
                        "Tell the full story":
                            mc "Me?"
                            mc "This is my first time coming here."

                            scene e2s10_jon-16 with dissolve
                            if affinity_spectrum > 0:
                                ba "Here's your drinks."
                                show e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                ba "Here's your drink."
                                show e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon_01drink
                            hide e2s10_jon_01drinks
                            br "Is it now?"

                            if affinity_spectrum > 0:
                                scene e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                scene e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-17
                            mc "Yeah."
                            mc "I've just been to a party."
                            mc "Long story short... there was a fight."
                            mc "And my plan was to head home and get some sleep."
                            mc "But the funny thing is that I lost my key back at the party."

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            br "How did that happen?"

                            if affinity_spectrum > 0:
                                scene e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                scene e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-02
                            mc "I honestly don't know, I either lost it or someone stole it..."

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            br "So how did you end up here?"

                            if affinity_spectrum > 0:
                                scene e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                scene e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-02
                            menu:
                                "Be playful":
                                    call extrovert_affinity_check from _call_extrovert_affinity_check_34
                                    call color_check from _call_color_check_66
                                    mc "Guess!"

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "You need a place to stay?"

                                    if affinity_spectrum > 0:
                                        scene e2s10_jon_01drinks with dissolve
                                        show e2s10_jon_drinks
                                    else:
                                        scene e2s10_jon_01drink with dissolve
                                        show e2s10_jon_drink
                                    show e2s10_jon-bridget_blink1
                                    hide e2s10_jon-17
                                    mc "As a matter of fact I do, yeah."
                                    mc "Thank you!"

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-05 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "Nice try!"

                                    if affinity_spectrum > 0:
                                        scene e2s10_jon_04drinks with dissolve
                                        show e2s10_jon_drinks
                                    else:
                                        scene e2s10_jon_04drink with dissolve
                                        show e2s10_jon_drink
                                    show e2s10_jon-bridget_blink1
                                    hide e2s10_jon-05
                                    mc "It was worth a shot."

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "Sweetie, I'm old enough to be your mother."

                                    if affinity_spectrum > 0:
                                        scene e2s10_jon_04drinks with dissolve
                                        show e2s10_jon_drinks
                                    else:
                                        scene e2s10_jon_04drink with dissolve
                                        show e2s10_jon_drink
                                    show e2s10_jon-bridget_blink1
                                    hide e2s10_jon-03
                                    mc "And I can make you feel like 18 again."
                                    mc "What's the problem?"

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "Smooth talker, huh?"
                                    br "Alright, let's say I take you back to my place."
                                "Be direct":
                                    call introvert_affinity_check from _call_introvert_affinity_check_29
                                    call color_check from _call_color_check_67
                                    mc "Well..."
                                    mc "Actually, I'm trying to win a bet."
                                    mc "My friends are back there."

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-05 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "Haha, you're cute!"

                                    hide e2s10_jon_drinks
                                    hide e2s10_jon_drink
                                    scene e2s10_jon-134 with dissolve
                                    jon "Hey, is he pointing at us?"
                                    jon "Son of a bitch!"
                                    hide e2s10_jon-05

                                    if affinity_spectrum > 0:
                                        scene e2s10_jon_01drinks with dissolve
                                        show e2s10_jon_drinks
                                        hide e2s10_jon-134
                                    else:
                                        scene e2s10_jon_01drink with dissolve
                                        show e2s10_jon_drink
                                        hide e2s10_jon-134

                                    show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon_01drinks
                                    hide e2s10_jon_01drink
                                    br "What's your deal, [mc]?"
                                    br "First, you say that you lost your key back at a party..."
                                    br "And now you need to win a bet?"

                                    if affinity_spectrum > 0:
                                        scene e2s10_jon_04drinks with dissolve
                                        show e2s10_jon_drinks
                                    else:
                                        scene e2s10_jon_04drink with dissolve
                                        show e2s10_jon_drink
                                    show e2s10_jon-bridget_blink1
                                    hide e2s10_jon-03
                                    mc "Weird night, right?"
                                    mc "I don't have a deal."
                                    mc "Just need somewhere to sleep."

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    br "Alright, let's say I take you back to my place."

                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon_03
                            br "What's going to happen next?"

                            if affinity_spectrum > 0:
                                scene e2s10_jon_04drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                scene e2s10_jon_04drink with dissolve
                                show e2s10_jon_drink
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-23
                            if affinity_spectrum <= 0:
                                $ bridget_trust += 1
                                $ e2s10_br_number = True
                                $ e2s10_br_interest = 1
                                mc "Nothing!"

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "Nothing?"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-17
                                mc "Nope."

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "So... if I were to invite you right now to my place, would you try to take things further?"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-02
                                mc "Honestly?"
                                mc "Not really."

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-26 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "Wow!"
                                br "I gotta say, I'm impressed."

                                show e2s10_jon-09 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                hide e2s10_jon_26
                                br "Men typically only want one thing when they hit on me in places like these."
                                br "And I always turn them down..."

                                show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                hide e2s10_jon_09
                                br "Here's the deal, I'm gonna give you my phone number..."
                                br "Unfortunately, I won't take you back to my place tonight."

                                show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                hide e2s10_jon_02
                                br "But, consider me interested, alright?"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-23
                                mc "Alright, thanks [br]!"
                                mc "It'll do."

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "See you [mc]!"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-02
                                mc "Bye!"
                            else:
                                mc "Nothing you don't want to happen."

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "So what?"
                                br "You're trying to hit on me just so you can sleep at my place?"
                                br "No other hidden intentions?"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-17
                                mc "So in your eyes every teen wants to get into your pants?"

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "Don't get me wrong [mc], we are in a club, sitting at a bar, drinking alcohol."

                                show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                hide e2s10_jon_02
                                br "What idea should I get?"

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-23
                                mc "Alright, fair enough."
                                mc "Then why did you come here if you didn't want to be hit on?"

                                hide e2s10_jon-bridget_blink1
                                show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                br "Can't I have a little fun?"
                                br "I'm not doing anything wrong."

                                if affinity_spectrum > 0:
                                    scene e2s10_jon_01drinks with dissolve
                                    show e2s10_jon_drinks
                                else:
                                    scene e2s10_jon_01drink with dissolve
                                    show e2s10_jon_drink
                                show e2s10_jon-bridget_blink1
                                hide e2s10_jon-17
                                menu:
                                    "Shoot your shot":
                                        $ bridget_trust += 1
                                        $ e2s10_br_number = True
                                        $ e2s10_br_interest = 1
                                        mc "You know... I believe me not having your number is what's wrong."

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-05 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "Alright, you win!"

                                        show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        hide e2s10_jon_05
                                        br "You can have my number."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_04drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_04drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-03
                                        mc "*Yes!*"

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "You were the most creative out of the bunch tonight, I'll give you that."

                                        show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        hide e2s10_jon_03
                                        br "Although, I'm not gonna let you sleep at my place..."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_03drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_03drink with dissolve
                                            show e2s10_jon_drink
                                        hide e2s10_jon_02
                                        br "Can't say I won't look forward to meeting you again, [mc]."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_04drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_04drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-03
                                        mc "Alright, good enough."
                                        mc "Thanks [br]!"

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-03 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "See you [mc]!"

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_04drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_04drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-03
                                        mc "Bye!"
                                    "Don't risk it":
                                        mc "Yeah... I guess you're not doing anything wrong."

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "Right."

                                        show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        hide e2s10_jon_17
                                        br "Sorry [mc], I'm not taking you home tonight."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_01drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_01drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-02
                                        mc "Dang it."

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "Although, good try!"
                                        br "You had me considering it for a second."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_01drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_01drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-02
                                        mc "Well, it is what it is."
                                        mc "If you change your mind, you can hit me up."

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "Yeah, probably not going to happen, but good to know."

                                        if affinity_spectrum > 0:
                                            scene e2s10_jon_01drinks with dissolve
                                            show e2s10_jon_drinks
                                        else:
                                            scene e2s10_jon_01drink with dissolve
                                            show e2s10_jon_drink
                                        show e2s10_jon-bridget_blink1
                                        hide e2s10_jon-02
                                        mc "Alright, see you [br]!"

                                        hide e2s10_jon-bridget_blink1
                                        show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                        br "Bye [mc]!"
                        "Be direct":
                            $ bridget_trust -= 1
                            mc "I'm gonna be honest..."
                            mc "I need a place to sleep."

                            scene e2s10_jon-16 with dissolve
                            if affinity_spectrum > 0:
                                ba "Here's your drinks."
                                show e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                ba "Here's your drink."
                                show e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon_01drink
                            hide e2s10_jon_01drinks
                            br "So what? You're homeless?"

                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-17
                            mc "Wait... it's nothing like that!"
                            mc "I've lost my dorm key and need a place to sleep."

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-24 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-01
                            br "Out of all the lies you could tell me..."

                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-24
                            br "This was your best?"

                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-23
                            mc "No!"
                            mc "I mean..."
                            mc "Wait, I'm not lying!"
                            mc "I'm serious, I lost them at a party tonight."

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-01
                            br "So... you're a student in a club, trying to hit on an older woman and this was your best shot?"

                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-23
                            mc "Um... no?"

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-09 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-01
                            br "Interesting story..."

                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-09
                            br "If you'll excuse me, I'm gonna go to the bathroom now."

                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-23
                            mc "Alright..."

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-25 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon-01
                            mc "*So... that's my cue to leave, right?*"
                            mc "*Damn... I don't think I could've messed it up more than this.*"
                        "Make up a story":
                            mc "To be fair, nothing brings me around here."
                            mc "Just wanted to grab a drink and talk to someone."
                            mc "And you just so happened to be that someone that I was looking for."

                            scene e2s10_jon-16 with dissolve
                            if affinity_spectrum > 0:
                                ba "Here's your drinks."
                                show e2s10_jon_01drinks with dissolve
                                show e2s10_jon_drinks
                            else:
                                ba "Here's your drink."
                                show e2s10_jon_01drink with dissolve
                                show e2s10_jon_drink

                            hide e2s10_jon-bridget_blink1
                            show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            hide e2s10_jon_01drink
                            hide e2s10_jon_01drinks
                            br "Is that so?"
                            br "Aren't you a little too young to be hanging around places like this?"

                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                            show e2s10_jon-bridget_blink1
                            hide e2s10_jon-17
                            menu:
                                "Make a joke" if affinity_spectrum > 0:
                                    $ bridget_trust -= 1
                                    call extrovert_affinity_check from _call_extrovert_affinity_check_35
                                    call color_check from _call_color_check_68
                                    mc "Aren't you too old to hang out in clubs?"

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-17 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-01
                                    br "Excuse me?"

                                    show e2s10_jon-19 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    show e2s10_jon-bridget_blink2
                                    hide e2s10_jon-17
                                    mc "What?"

                                    hide e2s10_jon-bridget_blink2
                                    show e2s10_jon-18 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-19
                                    br "Did you just call me old?"

                                    show e2s10_jon-19 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    show e2s10_jon-bridget_blink2
                                    hide e2s10_jon-18
                                    mc "No, I didn't."
                                    mc "It was a joke!"

                                    hide e2s10_jon-bridget_blink2
                                    show e2s10_jon-20 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-19
                                    br "Have some respect young man!"

                                    show e2s10_jon-18 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-20
                                    br "You want to hit on me but you're bringing these kind of jokes to the table."

                                    show e2s10_jon-19 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    show e2s10_jon-bridget_blink2
                                    hide e2s10_jon-18
                                    mc "Alright, I'm sorry!"

                                    hide e2s10_jon-bridget_blink2
                                    show e2s10_jon-21 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-19
                                    br "If you'll excuse me, I have to use the restrooms."
                                "Don't push it":
                                    mc "I'm not."

                                    hide e2s10_jon-bridget_blink1
                                    show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    hide e2s10_jon-01
                                    br "Interesting, that's the feeling I got."
                                    br "How old are you then?"

                                    show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                    show e2s10_jon-bridget_blink1
                                    hide e2s10_jon-02
                                    menu:
                                        "Lie":
                                            mc "Just turned 21."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Good for you then."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-02
                                            mc "So... do you think I could get your number?"

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-22 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Sorry, I'm not interested."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-22
                                            mc "Oh... alright then."
                                            mc "Good talk."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Yeah."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-02
                                            mc "Well... I'll leave you at it then."
                                            mc "Good bye [br]!"

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-22 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Bye [mc]."

                                            scene e2s10_jon-106 with dissolve
                                            hide e2s10_jon-22
                                            mc "*Well... that was awkward.*"
                                        "Tell her the truth":
                                            $ e2s10_br_number = True
                                            mc "You got me, I'm 18."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Appreciate the honesty, but I'm not interested in youngsters."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-02
                                            mc "Then who are you interested in?"

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "What makes you think I'm interested in anyone?"

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-23
                                            mc "You're sitting here all by yourself with an empty seat next to you..."
                                            mc "You're definitely waiting for someone."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Who says I can't enjoy a night out all by myself with a nice drink?"

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-23
                                            mc "Nobody says that."
                                            mc "But to me it's more obvious that you're waiting for someone."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "You might be right, but unfortunately you're not the person I'm expecting right now."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-02
                                            mc "That's alright, just needed to win a bet anyways."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "What was the bet about?"

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-23
                                            mc "We've all added {color=#4CBB17}$1{/color} to the bet and whoever manages to get a chick wins the bet."

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "I'll tell you what..."

                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-23
                                            br "I'll let you win the bet and give you my number."

                                            show e2s10_jon-23 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-02
                                            br "But that doesn't mean that you 'got' me."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-23
                                            mc "Thank you!"

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Now, if you'll excuse me, I have to go to the bathroom."

                                            show e2s10_jon-01 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            show e2s10_jon-bridget_blink1
                                            hide e2s10_jon-02
                                            mc "Alright, bye!"

                                            hide e2s10_jon-bridget_blink1
                                            show e2s10_jon-02 behind e2s10_jon_drink, e2s10_jon_drinks with dissolve
                                            hide e2s10_jon-01
                                            br "Good bye, [mc]!"

                    scene e2s10_jon-106 with dissolve
                    pause

                    scene e2s10_jon-130 with dissolve
                    pause

                    scene e2s10_jon-135 with dissolve
                    jon "So... what happened [mc]?"

                    scene e2s10_jon-136 with dissolve
                    jd "Yeah, tell us."
                    jd "How did it go?"

                    scene e2s10_jon-32 with dissolve
                    if e2s10_br_number == False:
                        mc "I didn't get her number..."

                        scene e2s10_jon-43 with dissolve
                        jd "Damn... really?"

                        scene e2s10_jon-37 with dissolve
                        mc "Unfortunately, yeah..."

                        scene e2s10_jon-36 with dissolve
                        jon "Damn man..."

                        scene e2s10_jon-37 with dissolve
                    else:
                        if affinity_spectrum < 0:
                            mc "I got her number!"

                            scene e2s10_jon-40 with dissolve
                            jon "Attaboy!"

                            scene e2s10_jon-33 with dissolve
                            ke "Nice, [mc]."

                            scene e2s10_jon-136 with dissolve
                            jd "At least someone pulled tonight."

                            scene e2s10_jon-32 with dissolve
                            mc "There's still time guys, it's your turns."

                            scene e2s10_jon-116 with dissolve
                            ro "Oh shit, right."
                        else:
                            mc "Well..."
                            mc "I GOT HER NUMBER!!"

                            scene e2s10_jon-135 with dissolve
                            jon "NICE MAN!"

                            scene e2s10_jon-137 with vpunch
                            pause

                            scene e2s10_jon-33 with dissolve
                            ke "Nice work, [mc]."

                            scene e2s10_jon-136 with dissolve
                            jd "You make this look easy bro."

                        scene e2s10_jon-32 with dissolve
                    mc "Hey [jon], did you know she's our math teacher?"

                    scene e2s10_jon-35 with dissolve
                    jon "Oh, she is?"

                    scene e2s10_jon-129 with dissolve
                    jon "I couldn't tell..."

                    scene e2s10_jon-32 with dissolve
                    mc "You did this on purpose, didn't you?"

                    scene e2s10_jon-35 with dissolve
                    jon "Maybe did, maybe didn't..."

                    scene e2s10_jon-40 with dissolve
                    jon "Point is, you still went ahead and did it."

                    scene e2s10_jon-135 with dissolve
                    jon "So what's the hurt now?"

                    scene e2s10_jon-32 with dissolve
                    mc "I hope she doesn't realise who I am later on..."

                    scene e2s10_jon-136 with dissolve
                    jd "That would be pretty funny I'm not gonna lie!"

                    scene e2s10_jon-41 with dissolve
                    jon "Alright ladies... so who goes next?"

        scene black with Dissolve(2.0)

        scene e2s10_jon-139 with Dissolve(2.0)
        pause

        scene e2s10_jon-138 with dissolve
        jd "Damn... I can't believe I didn't pull her!"

        scene e2s10_jon-109 with dissolve
        jon "Better luck next time."

        scene e2s10_jon-140 with dissolve
        ke "You were saying [jd]?"
        ke "At least you didn't get slapped."

        scene e2s10_jon-141 with dissolve
        ke "So, what do you think about today's weather?"

        scene e2s10_jon-142 with vpunch
        pause

        scene e2s10_jon-143 with dissolve
        unknown "Don't ever talk to me again!"

        scene e2s10_jon-144 with dissolve
        pause

        scene e2s10_jon-145 with dissolve
        ke "Can't believe you guys chose my ex for this..."

        if e2s10_br_number == True:
            scene e2s10_jon-116 with dissolve
            ro "Well... that's it guys."
            ro "Only [mc] managed to pull a chick tonight."

            scene e2s10_jon-30 with dissolve
            jon "Well... it's only fair that we give him all the money."

            $ renpy.show_screen("money_notify_pers")
            pause(0.2)

            $ money += 5

            scene e2s10_jon-32 with dissolve
            $ renpy.show_screen("money_notify")
            $ renpy.hide_screen("money_notify_pers")
            pause
        else:
            scene e2s10_jon-32 with dissolve
            if e2s10_seduce == True:
                mc "Wait, but none of us pulled a chick tonight..."
            else:
                mc "Wait, but none of you pulled a chick tonight..."
            mc "What happens now?"

            scene e2s10_jon-129 with dissolve
            jon "[mc], my friend..."

            scene e2s10_jon-36 with dissolve
            jon "If nobody pulled a chick, it's only fair that I take the money..."

            scene e2s10_jon-38 with dissolve
            jon "And give it back, meaning that everybody gets their dollar."

            scene e2s10_jon-146 with dissolve
            jd "I see what you did there!"

            if affinity_spectrum > 0:
                scene e2s10_jon-32 with dissolve
                mc "Well... that's pretty anticlimatic."

                scene e2s10_jon-36 with dissolve
                jon "Well, that's how it is [mc]."

                scene e2s10_jon-38 with dissolve
                jon "Sometimes things just go like that."

            if e2s10_seduce == True:
                if e2s10_no_money == False:
                    $ renpy.show_screen("money_notify_pers")
                    jon "Here's your dollar back."

                    $ money += 1
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")

                    scene e2s10_jon-37 with dissolve
                    mc "Thanks, I guess."

        if money > 1:
            if affinity_spectrum > 0:
                if e2s10_lap_dance == 0:
                    scene e2s10_jon-148 with dissolve
                    mc "*Hmm... now that I'm thinking about it...*"
                    mc "*Should I get that lap dance that I was offered or should I pass?*"
                    if e2s10_br_number == True:
                        mc "*Especially that now I have the money for it.*"
                    $ renpy.show_screen("money_notify_pers")
                    menu:
                        "Get the lap dance {color=#f00}(-$2){/color}":
                            $ money -= 2
                            $ renpy.show_screen("money_notify")
                            $ renpy.hide_screen("money_notify_pers")
                            mc "*You know what? I've earned it.*"
                            mc "*I'm gonna go and get it.*"
                            menu:
                                "Tell the guys":
                                    call extrovert_affinity_check from _call_extrovert_affinity_check_36
                                    call color_check from _call_color_check_69
                                    $ e2s10_lap_dance = 3
                                    $ persistent.e2s10_lap_dance = 2

                                    scene e2s10_jon-32 with dissolve
                                    mc "Hey guys!"
                                    mc "Some chick from here offered me to get a lap dance earlier."
                                    mc "Now that I've thought about it and I have the money, I think I'll go and get it."

                                    scene e2s10_jon-30 with dissolve
                                    jon "Haha, nice [mc]!"

                                    if e2s10_br_number == True:
                                        scene e2s10_jon-136 with dissolve
                                        jd "A chick's number and now a lap dance..."
                                        jd "You're rocking tonight man!"
                                    else:
                                        scene e2s10_jon-136 with dissolve
                                        jd "That's what I like to hear!"

                                    scene e2s10_jon-33 with dissolve
                                    ke "Have fun bro."

                                    scene e2s10_jon-32 with dissolve
                                    mc "Thanks guys."

                                    scene e2s10_jon-132 with dissolve
                                    pause

                                    scene e2s10_jon-49 with dissolve
                                    pause

                                    scene e2s10_jon-51 with dissolve
                                    show e2s10_jon-candance_blink1
                                    mc "Hey, I was thinking about your offer from before and I'd like to get a lap dance."

                                    scene e2s10_jon-52 with dissolve
                                    hide e2s10_jon-candance_blink1
                                    unknown "Okay sweetie, go to the third private dance room and wait for me there."
                                    unknown "I'll be there in a second."

                                    scene e2s10_jon-51 with dissolve
                                    show e2s10_jon-candance_blink1
                                    mc "Okay."

                                    scene black with Dissolve(2.0)
                                    hide e2s10_jon-candance_blink1
                                    call e2s10_lap_dance from _call_e2s10_lap_dance_6

                                    scene black with Dissolve(2.0)

                                    scene e2s10_jon-106 with Dissolve(2.0)
                                    pause
                                "Make an excuse":
                                    call introvert_affinity_check from _call_introvert_affinity_check_30
                                    call color_check from _call_color_check_70
                                    $ e2s10_lap_dance = 2
                                    $ persistent.e2s10_lap_dance = 2

                                    scene e2s10_jon-32 with dissolve
                                    mc "Hey guys!"
                                    mc "I need to go to the bathroom again."

                                    scene e2s10_jon-36 with dissolve
                                    jon "Alright bro."
                                    jon "No worries."

                                    scene e2s10_jon-132 with dissolve
                                    pause

                                    scene e2s10_jon-49 with dissolve
                                    pause

                                    scene e2s10_jon-51 with dissolve
                                    show e2s10_jon-candance_blink1
                                    mc "Hey, I was thinking about your offer from before and I'd like to get a lap dance."

                                    scene e2s10_jon-52 with dissolve
                                    hide e2s10_jon-candance_blink1
                                    unknown "Okay sweetie, go to the third private dance room and wait for me there."
                                    unknown "I'll be there in a second."

                                    scene e2s10_jon-51 with dissolve
                                    show e2s10_jon-candance_blink1
                                    mc "Okay."

                                    scene black with Dissolve(2.0)
                                    hide e2s10_jon-candance_blink1
                                    call e2s10_lap_dance from _call_e2s10_lap_dance_7

                                    scene black with Dissolve(2.0)

                                    scene e2s10_jon-106 with Dissolve(2.0)
                                    pause
                        "Pass it":
                            mc "*Nah, I better keep the money.*"
                            mc "*You never know when you'll need it.*"

        scene e2s10_jon-116 with dissolve
        ro "Alright guys... I think I'm gonna call it a night."
        ro "I'mma head back home."
        ro "It's getting pretty late."

        scene e2s10_jon-140 with dissolve
        ke "Yeah... I'm gonna go as well."

        scene e2s10_jon-39 with dissolve
        jon "Alright then, looks like this night is over."

        scene e2s10_jon-117 with dissolve
        jon "See you tomorrow, gentlemen!"

        scene e2s10_jon-30 with dissolve
        jon "Come on [mc], let's head back to my apartment."

        scene e2s10_jon-32 with dissolve
        mc "Oh... almost forgot about that part."
        mc "Catch you later guys!"

        scene e2s10_jon-33 with dissolve
        ke "Alright, bye everyone!"

        scene e2s10_jon-147 with dissolve
        pause

        jump e2s11
return

# Secondary labels #############################################################
# Sadie ###
label e2s10_sadie_sex:

    if not _in_replay:
        pass
    else:
        play music bloom

    scene e2s10_sd-kiss1 with dissolve
    pause

    scene e2s10_sd-kiss2 with dissolve
    pause

    scene e2s10_sd-60 with dissolve
    sd "Didn't know you could kiss this good when you're drunk."

    scene e2s10_sd-61 with dissolve
    mc "I've gotta be honest, that's an ability I didn't even know I had."

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e2s10_sd-60 with dissolve
        sd "I wonder what other abilities you have."

        scene e2s10_sd-61 with dissolve
        mc "Try me."

        scene e2s10_sd-62 with dissolve
        sd "Alright, bet!"
        sd "First, let's start with the basics."
        sd "Let's see your tongue work."

        scene e2s10_sd-63 with dissolve
        mc "I like where this is going."

        scene e2s10_sd-62 with dissolve
        sd "It might get even more interesting if you behave!"

        scene e2s10_sd-64 with dissolve
        pause

        scene e2s10_sd-65 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e2s10_sd-66 with dissolve
            pause

            scene e2s10_sd-67 with dissolve
            pause

            scene e2s10_sd-68 with dissolve
            if affinity_spectrum > 0:
                mc "*Holy fuck look at that ass!*"
            else:
                pause

            scene e2s10_sd-69 with dissolve
            pause

            scene e2s10_sd-70 with dissolve
            pause

            scene e2s10_sd-71 with dissolve
            pause

            # Pussy eating #########################################################
            scene e2s10_sd-pussy_eating1 with dissolve
            pause
            sd "Ahh, keep going [mc]!"
            sd "This feels really good."

            scene e2s10_sd-pussy_eating2 with dissolve
            pause
            mc "*Muffled speaking.*"

            scene e2s10_sd-72 with dissolve
            sd "Huh? What did you say?"

            scene e2s10_sd-73 with dissolve
            mc "You taste great [sd]!"

            scene e2s10_sd-74 with dissolve
            pause

            scene e2s10_sd-pussy_eating1 with dissolve
            pause
            sd "Uhh, you're hitting the spot just right."

            scene e2s10_sd-pussy_eating2 with dissolve
            pause

            scene e2s10_sd-pussy_eating1 with dissolve
            pause
            sd "Damn..."

            scene e2s10_sd-72 with dissolve
            sd "Al-alright, let's tie the game."

            scene e2s10_sd-75 with dissolve
            pause

            scene e2s10_sd-76 with dissolve
            sd "You're already hard, huh?"
            sd "Let's see how you like this."

            # Sixty nine ###########################################################
            scene e2s10_sd-sixty_nine1 with dissolve
            pause

            scene e2s10_sd-sixty_nine2 with dissolve
            pause

            scene e2s10_sd-sixty_nine3 with dissolve
            pause

            scene e2s10_sd-sixty_nine1 with dissolve
            pause
            mc "*Muffled speaking.*"

            scene e2s10_sd-72 with dissolve
            sd "What? I can't hear you."

            scene e2s10_sd-74 with dissolve
            pause

            scene e2s10_sd-77 with dissolve
            pause

            scene e2s10_sd-sixty_nine1 with dissolve
            pause

            scene e2s10_sd-sixty_nine2 with dissolve
            pause
            sd "Holy shit, this feels so good!"

            scene e2s10_sd-sixty_nine3 with dissolve
            pause
            sd "You're doing a great job [mc]!"
            menu:
                "Tease her ass":
                    mc "*Let's see how she reacts.*"

                    scene e2s10_sd-78 with dissolve

                    scene e2s10_sd-79 with dissolve
                    sd "Oh, no you don't!"
                    sd "Not that fast mister."
                    sd "We're not doing anal tonight."

                    mc "Tonight?"

                    sd "Oh just shut up."

                    scene e2s10_sd-77 with vpunch
                    pause

                "Don't risk it":
                    pass

            scene e2s10_sd-sixty_nine2 with dissolve
            pause

            scene e2s10_sd-sixty_nine1 with dissolve
            pause

            scene e2s10_sd-sixty_nine3 with dissolve
            pause
            sd "Ahh, keep going [mc]!"
            sd "I'm going to cum."
            mc "*Muffled speaking.*"
            sd "I'm cumming!!!"

            scene e2s10_sd-pussy_eating2 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)

            scene e2s10_sd-72 with dissolve
            sd "You were amazing [mc]!"

            scene e2s10_sd-81 with dissolve
            mc "I'm glad you liked it."

            scene e2s10_sd-80 with dissolve
            sd "Looks like you have more than one ability when you're drunk, [mc]."

            scene e2s10_sd-82 with dissolve
            mc "What can I say..."

            scene e2s10_sd-81 with dissolve
            mc "You also did a great job with that blowjob."

            scene e2s10_sd-82 with dissolve
            mc "You almost had made cum, I had to hold it in."

            scene e2s10_sd-80 with dissolve
            sd "Haha, unfortunately for you, I've got more things planned tonight."
            sd "Lose the clothes."
            sd "Lie back and enjoy."

            # Blowjob ##############################################################
            scene e2s10_sd-blowjob1 with dissolve
            pause
            mc "This feels really good [sd]!"
            mc "Keep going."

            scene e2s10_sd-blowjob2 with dissolve
            pause

            scene e2s10_sd-dick_licking1 with dissolve
            pause

            scene e2s10_sd-83 with dissolve
            sd "I've got a special trick prepared for you."

            # Handjob ##############################################################
            scene e2s10_sd-handjob1 with dissolve
            pause
            mc "This feels amazing!"

            scene e2s10_sd-handjob2 with dissolve
            pause
            mc "Oh my God."
            mc "Holy shit!"
            pause
            mc "[sd], I'm about to..."

            scene e2s10_sd-84 with dissolve
            sd "Not yet, [mc]."
            sd "This was just the warm up."
            mc "Oh my God, that felt amazing!"
            sd "Haha, I'm glad you liked it."
            sd "I knew you would get off by that."
            mc "If this was just the warm up..."
            mc "I'm really curious about what's coming next."
            sd "You're a bit impatient, [mc]."
            sd "Let's move to the next thing."

            scene e2s10_sd-85 with dissolve
            sd "Are you ready [mc]?"
            mc "I'm ready!"

            scene e2s10_sd-86 with dissolve
            pause

            # Cowgirl ##############################################################
            scene e2s10_sd-cowgirl1 with dissolve
            pause
            sd "Ahh!"
            mc "You're so tight, [sd]."

            scene e2s10_sd-cowgirl2 with dissolve
            pause
            sd "Oh my God [mc]."
            sd "This feels really fucking good!"

            scene e2s10_sd-cowgirl1 with dissolve
            pause

            scene e2s10_sd-cowgirl2 with dissolve
            pause
            mc "Keep going [sd]!"
            sd "Let's switch and see how you like it from behind."

            # Reverse cowgirl ######################################################
            scene e2s10_sd-reverse_cowgirl1 with dissolve
            pause
            mc "Oh shit!"
            mc "I love how your ass bounces."
            sd "Ahh, [mc]..."
            sd "I'll go faster."

            scene e2s10_sd-reverse_cowgirl2 with dissolve
            pause
            sd "Oh, fuck!"
            sd "That's the spot."
            mc "I love it [sd]!"

            scene e2s10_sd-reverse_cowgirl3 with dissolve
            sd "Ah, shit!"
            pause

            scene e2s10_sd-87 with dissolve
            sd "[mc], I'm getting tired."
            sd "Let's switch."
            mc "Alright."

            # Missionary ###########################################################
            scene e2s10_sd-missionary1 with dissolve
            pause

            scene e2s10_sd-missionary2 with dissolve
            sd "Oh yeah, [mc]!"
            sd "Take me."
            sd "Fuck my pussy."

            scene e2s10_sd-missionary1 with dissolve
            pause

            # Doggy ###########################################################
            scene e2s10_sd-doggy1 with dissolve
            sd "Holy fuck, you're going so deep inside me!"
            mc "This feels heavenly."

            scene e2s10_sd-doggy2 with dissolve
            sd "Fuck..."
            mc "I don't think I'll be able to hold it that much in this position."
            sd "You've earned it, [mc]!"
            sd "Cum whenever you want."
        else:
            if persistent.type_nsfw == False:
                scene e2s10_sd-66_cen with dissolve
                pause

                scene e2s10_sd-67_cen with dissolve
                pause

                scene e2s10_sd-68_cen with dissolve
                if affinity_spectrum > 0:
                    mc "*Holy fuck look at that ass!*"
                else:
                    pause

                scene e2s10_sd-69_cen with dissolve
                pause

                scene e2s10_sd-70_cen with dissolve
                pause

                scene e2s10_sd-71_cen with dissolve
                pause

                # Pussy eating #########################################################
                scene e2s10_sd-pussy_eating1_cen with dissolve
                pause
                sd "Ahh, keep going [mc]!"
                sd "This feels really good."

                scene e2s10_sd-pussy_eating2_cen with dissolve
                pause
                mc "*Muffled speaking.*"

                scene e2s10_sd-72_cen with dissolve
                sd "Huh? What did you say?"

                scene e2s10_sd-73_cen with dissolve
                mc "You taste great [sd]!"

                scene e2s10_sd-74_cen with dissolve
                pause

                scene e2s10_sd-pussy_eating1_cen with dissolve
                pause
                sd "Uhh, you're hitting the spot just right."

                scene e2s10_sd-pussy_eating2_cen with dissolve
                pause

                scene e2s10_sd-pussy_eating1_cen with dissolve
                pause
                sd "Damn..."

                scene e2s10_sd-72_cen with dissolve
                sd "Al-alright, let's tie the game."

                scene e2s10_sd-75_cen with dissolve
                pause

                scene e2s10_sd-76_cen with dissolve
                sd "You're already hard, huh?"
                sd "Let's see how you like this."

                # Sixty nine ###########################################################
                scene e2s10_sd-sixty_nine1_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine2_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine3_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine1_cen with dissolve
                pause
                mc "*Muffled speaking.*"

                scene e2s10_sd-72_cen with dissolve
                sd "What? I can't hear you."

                scene e2s10_sd-74_cen with dissolve
                pause

                scene e2s10_sd-77_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine1_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine2_cen with dissolve
                pause
                sd "Holy shit, this feels so good!"

                scene e2s10_sd-sixty_nine3_cen with dissolve
                pause
                sd "You're doing a great job [mc]!"
                menu:
                    "Tease her ass":
                        mc "*Let's see how she reacts.*"

                        scene e2s10_sd-78_cen with dissolve

                        scene e2s10_sd-79_cen with dissolve
                        sd "Oh, no you don't!"
                        sd "Not that fast mister."
                        sd "We're not doing anal tonight."

                        mc "Tonight?"

                        sd "Oh just shut up."

                        scene e2s10_sd-77_cen with vpunch
                        pause

                    "Don't risk it":
                        pass

                scene e2s10_sd-sixty_nine2_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine1_cen with dissolve
                pause

                scene e2s10_sd-sixty_nine3_cen with dissolve
                pause
                sd "Ahh, keep going [mc]!"
                sd "I'm going to cum."
                mc "*Muffled speaking.*"
                sd "I'm cumming!!!"

                scene e2s10_sd-pussy_eating2_cen with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)

                scene e2s10_sd-72_cen with dissolve
                sd "You were amazing [mc]!"

                scene e2s10_sd-81 with dissolve
                mc "I'm glad you liked it."

                scene e2s10_sd-80 with dissolve
                sd "Looks like you have more than one ability when you're drunk, [mc]."

                scene e2s10_sd-82 with dissolve
                mc "What can I say..."

                scene e2s10_sd-81 with dissolve
                mc "You also did a great job with that blowjob."

                scene e2s10_sd-82 with dissolve
                mc "You almost had made cum, I had to hold it in."

                scene e2s10_sd-80 with dissolve
                sd "Haha, unfortunately for you, I've got more things planned tonight."
                sd "Lose the clothes."
                sd "Lie back and enjoy."

                # Blowjob ##############################################################
                scene e2s10_sd-blowjob1_cen with dissolve
                pause
                mc "This feels really good [sd]!"
                mc "Keep going."

                scene e2s10_sd-blowjob2_cen with dissolve
                pause

                scene e2s10_sd-dick_licking1_cen with dissolve
                pause

                scene e2s10_sd-83_cen with dissolve
                sd "I've got a special trick prepared for you."

                # Handjob ##############################################################
                scene e2s10_sd-handjob1_cen with dissolve
                pause
                mc "This feels amazing!"

                scene e2s10_sd-handjob2_cen with dissolve
                pause
                mc "Oh my God."
                mc "Holy shit!"
                pause
                mc "[sd], I'm about to..."

                scene e2s10_sd-84_cen with dissolve
                sd "Not yet, [mc]."
                sd "This was just the warm up."
                mc "Oh my God, that felt amazing!"
                sd "Haha, I'm glad you liked it."
                sd "I knew you would get off by that."
                mc "If this was just the warm up..."
                mc "I'm really curious about what's coming next."
                sd "You're a bit impatient, [mc]."
                sd "Let's move to the next thing."

                scene e2s10_sd-85_cen with dissolve
                sd "Are you ready [mc]?"
                mc "I'm ready!"

                scene e2s10_sd-86_cen with dissolve
                pause

                # Cowgirl ##############################################################
                scene e2s10_sd-cowgirl1_cen with dissolve
                pause
                sd "Ahh!"
                mc "You're so tight, [sd]."

                scene e2s10_sd-cowgirl2_cen with dissolve
                pause
                sd "Oh my God [mc]."
                sd "This feels really fucking good!"

                scene e2s10_sd-cowgirl1_cen with dissolve
                pause

                scene e2s10_sd-cowgirl2_cen with dissolve
                pause
                mc "Keep going [sd]!"
                sd "Let's switch and see how you like it from behind."

                # Reverse cowgirl ######################################################
                scene e2s10_sd-reverse_cowgirl1_cen with dissolve
                pause
                mc "Oh shit!"
                mc "I love how your ass bounces."
                sd "Ahh, [mc]..."
                sd "I'll go faster."

                scene e2s10_sd-reverse_cowgirl2_cen with dissolve
                pause
                sd "Oh, fuck!"
                sd "That's the spot."
                mc "I love it [sd]!"

                scene e2s10_sd-reverse_cowgirl3_cen with dissolve
                sd "Ah, shit!"
                pause

                scene e2s10_sd-87_cen with dissolve
                sd "[mc], I'm getting tired."
                sd "Let's switch."
                mc "Alright."

                # Missionary ###########################################################
                scene e2s10_sd-missionary1_cen with dissolve
                pause

                scene e2s10_sd-missionary2_cen with dissolve
                sd "Oh yeah, [mc]!"
                sd "Take me."
                sd "Fuck my pussy."

                scene e2s10_sd-missionary1_cen with dissolve
                pause

                # Doggy ###########################################################
                scene e2s10_sd-doggy1_cen with dissolve
                sd "Holy fuck, you're going so deep inside me!"
                mc "This feels heavenly."

                scene e2s10_sd-doggy2_cen with dissolve
                sd "Fuck..."
                mc "I don't think I'll be able to hold it that much in this position."
                sd "You've earned it, [mc]!"
                sd "Cum whenever you want."


        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Pussy eating":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-pussy_eating1 with dissolve
                        pause
                        sd "Ahh, keep going [mc]!"
                        sd "This feels really good."

                        scene e2s10_sd-pussy_eating2 with dissolve
                        pause
                        mc "*Muffled speaking.*"

                        scene e2s10_sd-72 with dissolve
                        sd "Huh? What did you say?"

                        scene e2s10_sd-73 with dissolve
                        mc "You taste great [sd]!"

                        scene e2s10_sd-74 with dissolve
                        pause

                        scene e2s10_sd-pussy_eating1 with dissolve
                        pause
                        sd "Uhh, you're hitting the spot just right."

                        scene e2s10_sd-pussy_eating2 with dissolve
                        pause

                        scene e2s10_sd-pussy_eating1 with dissolve
                        pause
                        sd "Damn..."

                        scene e2s10_sd-sixty_nine1 with dissolve
                        pause
                        mc "*Muffled speaking.*"

                        scene e2s10_sd-72 with dissolve
                        sd "What? I can't hear you."

                        scene e2s10_sd-74 with dissolve
                        pause

                        scene e2s10_sd-77 with dissolve
                        pause

                        scene e2s10_sd-sixty_nine1 with dissolve
                        pause

                        scene e2s10_sd-sixty_nine2 with dissolve
                        pause
                        sd "Holy shit, this feels so good!"

                        scene e2s10_sd-sixty_nine3 with dissolve
                        pause
                        sd "You're doing a great job [mc]!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-pussy_eating1_cen with dissolve
                            pause
                            sd "Ahh, keep going [mc]!"
                            sd "This feels really good."

                            scene e2s10_sd-pussy_eating2_cen with dissolve
                            pause
                            mc "*Muffled speaking.*"

                            scene e2s10_sd-72_cen with dissolve
                            sd "Huh? What did you say?"

                            scene e2s10_sd-73_cen with dissolve
                            mc "You taste great [sd]!"

                            scene e2s10_sd-74_cen with dissolve
                            pause

                            scene e2s10_sd-pussy_eating1_cen with dissolve
                            pause
                            sd "Uhh, you're hitting the spot just right."

                            scene e2s10_sd-pussy_eating2_cen with dissolve
                            pause

                            scene e2s10_sd-pussy_eating1_cen with dissolve
                            pause
                            sd "Damn..."

                            scene e2s10_sd-sixty_nine1_cen with dissolve
                            pause
                            mc "*Muffled speaking.*"

                            scene e2s10_sd-72_cen with dissolve
                            sd "What? I can't hear you."

                            scene e2s10_sd-74_cen with dissolve
                            pause

                            scene e2s10_sd-77_cen with dissolve
                            pause

                            scene e2s10_sd-sixty_nine1_cen with dissolve
                            pause

                            scene e2s10_sd-sixty_nine2_cen with dissolve
                            pause
                            sd "Holy shit, this feels so good!"

                            scene e2s10_sd-sixty_nine3_cen with dissolve
                            pause
                            sd "You're doing a great job [mc]!"

                "Blowjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-blowjob1 with dissolve
                        pause
                        mc "This feels really good [sd]!"
                        mc "Keep going."

                        scene e2s10_sd-blowjob2 with dissolve
                        pause

                        scene e2s10_sd-dick_licking1 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-blowjob1_cen with dissolve
                            pause
                            mc "This feels really good [sd]!"
                            mc "Keep going."

                            scene e2s10_sd-blowjob2_cen with dissolve
                            pause

                            scene e2s10_sd-dick_licking1_cen with dissolve
                            pause

                "Handjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-handjob1 with dissolve
                        pause
                        mc "This feels amazing!"

                        scene e2s10_sd-handjob2 with dissolve
                        pause
                        mc "Oh my God."
                        mc "Holy shit!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-handjob1_cen with dissolve
                            pause
                            mc "This feels amazing!"

                            scene e2s10_sd-handjob2_cen with dissolve
                            pause
                            mc "Oh my God."
                            mc "Holy shit!"

                "Cowgirl":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-cowgirl1 with dissolve
                        pause
                        sd "Ahh!"
                        mc "You're so tight, [sd]."

                        scene e2s10_sd-cowgirl2 with dissolve
                        pause
                        sd "Oh my God [mc]."
                        sd "This feels really fucking good!"

                        scene e2s10_sd-cowgirl1 with dissolve
                        pause

                        scene e2s10_sd-cowgirl2 with dissolve
                        pause
                        mc "Keep going [sd]!"

                        scene e2s10_sd-reverse_cowgirl1 with dissolve
                        pause
                        mc "Oh shit!"
                        mc "I love how your ass bounces."
                        sd "Ahh, [mc]..."
                        sd "I'll go faster."

                        scene e2s10_sd-reverse_cowgirl2 with dissolve
                        pause
                        sd "Oh, fuck!"
                        sd "That's the spot."
                        mc "I love it [sd]!"

                        scene e2s10_sd-reverse_cowgirl3 with dissolve
                        sd "Ah, shit!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-cowgirl1_cen with dissolve
                            pause
                            sd "Ahh!"
                            mc "You're so tight, [sd]."

                            scene e2s10_sd-cowgirl2_cen with dissolve
                            pause
                            sd "Oh my God [mc]."
                            sd "This feels really fucking good!"

                            scene e2s10_sd-cowgirl1_cen with dissolve
                            pause

                            scene e2s10_sd-cowgirl2_cen with dissolve
                            pause
                            mc "Keep going [sd]!"

                            scene e2s10_sd-reverse_cowgirl1_cen with dissolve
                            pause
                            mc "Oh shit!"
                            mc "I love how your ass bounces."
                            sd "Ahh, [mc]..."
                            sd "I'll go faster."

                            scene e2s10_sd-reverse_cowgirl2_cen with dissolve
                            pause
                            sd "Oh, fuck!"
                            sd "That's the spot."
                            mc "I love it [sd]!"

                            scene e2s10_sd-reverse_cowgirl3_cen with dissolve
                            sd "Ah, shit!"

                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-doggy1 with dissolve
                        sd "Holy fuck, you're going so deep inside me!"
                        mc "This feels heavenly."

                        scene e2s10_sd-doggy2 with dissolve
                        sd "Fuck..."
                        mc "I don't think I'll be able to hold it that much in this position."
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-doggy1_cen with dissolve
                            sd "Holy fuck, you're going so deep inside me!"
                            mc "This feels heavenly."

                            scene e2s10_sd-doggy2_cen with dissolve
                            sd "Fuck..."
                            mc "I don't think I'll be able to hold it that much in this position."

                "Missionary":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2s10_sd-missionary1 with dissolve
                        pause

                        scene e2s10_sd-missionary2 with dissolve
                        sd "Oh yeah, [mc]!"
                        sd "Take me."
                        sd "Fuck my pussy."

                        scene e2s10_sd-missionary1 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2s10_sd-missionary1_cen with dissolve
                            pause

                            scene e2s10_sd-missionary2_cen with dissolve
                            sd "Oh yeah, [mc]!"
                            sd "Take me."
                            sd "Fuck my pussy."

                            scene e2s10_sd-missionary1_cen with dissolve
                            pause

                "Cum":
                    $ GameRunning = False

        $ config.rollback_enabled = True

        if persistent.disable_nsfw == True:
            mc "[sd], I'm about to cum!"
            sd "Cum wherever you want, [mc]!"
            sd "I'm on the pill."

            menu:
                "Creampie":
                    scene e2s10_sd-reverse_cowgirl3 with dissolve
                    mc "Oh, fuck!"
                    mc "I'm cumming [sd]!"
                    sd "Do it inside [mc]."
                    sd "Fill my pussy with your semen."
                    mc "Ohh, here it goes!"

                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)

                    scene e2s10_sd-87 with dissolve
                    pause

                    scene e2s10_sd-88 with dissolve
                    mc "Holy shit."
                    sd "Damn [mc]!"
                    sd "That was really fucking good."
                    mc "I'm wasted holy crap."
                    sd "Yeah, for sure."

                    scene e2s10_sd-92 with dissolve
                    sd "I'm gonna go to the bathroom real quick."
                    sd "When I come back I'm gonna prepare the couch for you."

                    scene e2s10_sd-93 with dissolve
                    mc "Alright, I'll be waiting."

                "Facial":
                    scene e2s10_sd-cum1 with dissolve
                    pause
                    mc "I'm cumming [sd]!"
                    sd "Do it, [mc]!"
                    sd "Cum on my pretty fucking face."
                    mc "Oh... here it goes!"

                    show white with Dissolve(0.25)
                    scene e2s10_sd-89
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)

                    scene e2s10_sd-90 with dissolve
                    mc "Holy shit!"

                    scene e2s10_sd-91 with dissolve
                    sd "Damn [mc]!"
                    sd "That was really fucking good."

                    scene e2s10_sd-90 with dissolve
                    mc "I'm wasted holy crap."

                    scene e2s10_sd-91 with dissolve
                    sd "Yeah, for sure."

                    scene e2s10_sd-94 with dissolve
                    sd "I'm gonna go to the bathroom real quick."
                    sd "When I come back I'm gonna prepare the couch for you."

                    scene e2s10_sd-95 with dissolve
                    mc "Alright, I'll be waiting."

            scene e2s10_sd-96 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                mc "[sd], I'm about to cum!"
                sd "Cum wherever you want, [mc]!"
                sd "I'm on the pill."

                menu:
                    "Creampie":
                        scene e2s10_sd-reverse_cowgirl3_cen with dissolve
                        mc "Oh, fuck!"
                        mc "I'm cumming [sd]!"
                        sd "Do it inside [mc]."
                        sd "Fill my pussy with your semen."
                        mc "Ohh, here it goes!"

                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e2s10_sd-87_cen with dissolve
                        pause

                        scene e2s10_sd-88_cen with dissolve
                        mc "Holy shit."
                        sd "Damn [mc]!"
                        sd "That was really fucking good."
                        mc "I'm wasted holy crap."
                        sd "Yeah, for sure."

                        scene e2s10_sd-92_cen with dissolve
                        sd "I'm gonna go to the bathroom real quick."
                        sd "When I come back I'm gonna prepare the couch for you."

                        scene e2s10_sd-93_cen with dissolve
                        mc "Alright, I'll be waiting."

                    "Facial":
                        scene e2s10_sd-cum1_cen with dissolve
                        pause
                        mc "I'm cumming [sd]!"
                        sd "Do it, [mc]!"
                        sd "Cum on my pretty fucking face."
                        mc "Oh... here it goes!"

                        show white with Dissolve(0.25)
                        scene e2s10_sd-89_cen
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e2s10_sd-90_cen with dissolve
                        mc "Holy shit!"

                        scene e2s10_sd-91_cen with dissolve
                        sd "Damn [mc]!"
                        sd "That was really fucking good."

                        scene e2s10_sd-90_cen with dissolve
                        mc "I'm wasted holy crap."

                        scene e2s10_sd-91_cen with dissolve
                        sd "Yeah, for sure."

                        scene e2s10_sd-92_cen with dissolve
                        sd "I'm gonna go to the bathroom real quick."
                        sd "When I come back I'm gonna prepare the couch for you."

                        scene e2s10_sd-93_cen with dissolve
                        mc "Alright, I'll be waiting."

                scene e2s10_sd-96_cen with dissolve
                pause

    if not _in_replay:
        pass
    else:
        stop music fadeout 2.0
    $ renpy.end_replay()
return

# Freeroam Collected Photos #

default persistent.e2s10_collected_p = 0
default persistent.e2s10_collected_tp = 7

# Francesca ###
label e2s10_freeroam:
    scene e2s10_frfr-01 with dissolve
    hide e2s10_fr-francesca_blink2

    define e2s10_fr_frtracks = ["bloom.ogg", "border_blaster.ogg", "crazy_glue.ogg", "darien_gap.ogg", "failures.ogg", "frannie.ogg", "hey_ruth.ogg", "hollow_grove.ogg", "laurel_breeze.ogg", "mom_n_pa.ogg", "one_fine_day.ogg", "release.ogg", "serenity.ogg", "thanks_for_coming.ogg", "the_pawnbrokers_stepdaughter.ogg"]
    $ renpy.music.queue (e2s10_fr_frtracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Get the popcorn from the kitchen.")

    scene e2s10_frfr-01 with Dissolve(0.1)

    call screen e2s10_fr_main
    hide e2s10_frfr-01
return

# Rooms

label e2s10_fr_main:
    scene e2s10_frfr-01
    call screen e2s10_fr_main with dissolve
return

label e2s10_fr_dining_room:
    scene e2s10_frfr-07
    call screen e2s10_fr_dining_room with dissolve
return

label e2s10_fr_hallway:
    scene e2s10_frfr-04
    call screen e2s10_fr_hallway with dissolve
return

label e2s10_fr_stairs:
    scene e2s10_frfr-02
    call screen e2s10_fr_stairs with dissolve
return

label e2s10_fr_kitchen:
    scene e2s10_frfr-08
    call screen e2s10_fr_kitchen with dissolve
return

label e2s10_fr_bathroom:
    scene e2s10_frfr-06
    call screen e2s10_fr_bathroom with dissolve
return

label e2s10_fr_bedroom:
    scene e2s10_frfr-05
    call screen e2s10_fr_bedroom with dissolve
return

label e2s10_fr_upstairs:
    scene e2s10_frfr-03
    call screen e2s10_fr_upstairs with dissolve
return

# Clickables
label e2s10_fr_francesca:
    scene e2s10_fr-16 with dissolve
    show e2s10_fr-francesca_blink2
    mc "Hey [fr]!"
    mc "Could you tell me again where the popcorn is?"

    scene e2s10_fr-17 with dissolve
    hide e2s10_fr-francesca_blink2
    fr "Sure [mc]!"

    scene e2s10_fr-15 with dissolve
    fr "It's in the kitchen."

    scene e2s10_fr-16 with dissolve
    show e2s10_fr-francesca_blink2
    mc "Got it, thanks!"

    scene e2s10_frfr-01 with dissolve
    call screen e2s10_fr_main with dissolve
return

label e2s10_fr_cabinet:
    $ current_quests.remove("Get the popcorn from the kitchen.")
    $ renpy.hide_screen("questtracker_icon")

    $ e2s10_popcorn = True
    pass
return

label e2s10_fr_left_door:
    $ current_quests.remove("Get the popcorn from the kitchen.")
    $ renpy.hide_screen("questtracker_icon")
    pass
return

label e2s10_fr_middle_door:
    $ current_quests.remove("Get the popcorn from the kitchen.")
    $ renpy.hide_screen("questtracker_icon")
    pass
return

label e2s10_fr_right_door:
    $ current_quests.remove("Get the popcorn from the kitchen.")
    $ renpy.hide_screen("questtracker_icon")
    pass
return

# Jon ###

label e2s10_lap_dance:
    scene e2s10_jon-55 with Dissolve(2.0)
    if not _in_replay:
        pass
    else:
        play music open_inside
    pause

    scene e2s10_jon-56 with dissolve
    pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e2s10_jon-57 with dissolve
            pause

            scene e2s10_jon-58 with dissolve
            mc "*Holy fuck...*"

            scene e2s10_jon-59 with dissolve
            pause

            scene e2s10_jon-60 with dissolve
            unknown "Lose the jacket sweetie, you won't need it here."

            if not _in_replay:
                if e2s10_lap_dance == 2 or e2s10_lap_dance == 3:
                    if persistent.e2s10_lap_dance < 2:
                        $ persistent.e2s10_lap_dance = 2
                    scene e2s10_jon-61 with dissolve
                    unknown "Now sit back, and relax."

                    scene e2s10_jon-62 with dissolve
                    pause

                    scene e2s10_jon-63 with dissolve
                    pause

                    scene e2s10_jon-64 with dissolve
                    pause

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-66 with dissolve
                    pause

                    scene e2s10_jon-65 with dissolve
                    unknown "You are touchy, aren't you?"

                    scene e2s10_jon-66 with dissolve
                    menu:
                        "Slap her":
                            $ candance_trust += 1
                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-67 with dissolve
                            unknown "Ah... fuck!"
                            unknown "Do it again."

                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-65 with dissolve
                            unknown "Let's see how you like this."

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-65 with dissolve
                            unknown "Do you like it?"

                            scene e2s10_jon-66 with dissolve
                            mc "I love it!"
                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            unknown "Ahh, fuck!"

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-100 with dissolve
                            pause

                            scene e2s10_jon-99 with dissolve
                            pause

                            scene e2s10_jon-98 with dissolve
                            pause

                            scene e2s10_jon-97 with dissolve
                            pause

                            scene e2s10_jon-80 with dissolve
                            unknown "I see you have a little something down there..."

                            scene e2s10_jon-114 with dissolve
                            pause

                            scene e2s10_jon-61 with dissolve
                            pause

                            scene e2s10_jon-68 with dissolve
                            unknown "You know... I don't usually do this but I like you."

                            scene e2s10_jon-69 with dissolve
                            unknown "You know how to get what you like and I like that about you."

                            scene e2s10_jon-81 with dissolve
                            unknown "Now... I know how hard it must be for you to watch this show without any action."

                            scene e2s10_jon-69 with dissolve
                            unknown "So, I could offer you a blowjob for just {color=#4CBB17}$1{/color}."
                            unknown "But don't tell anyone about this, alright?"

                            scene e2s10_jon-70 with dissolve
                            $ renpy.show_screen("money_notify_pers")
                            menu:
                                "Accept her offer {color=#f00}(-$1){/color}" if money > 0:
                                    $ persistent.e2s10_lap_dance = 3
                                    $ money -= 1

                                    $ renpy.show_screen("money_notify")
                                    $ renpy.hide_screen("money_notify_pers")
                                    mc "Alright, give me a blowjob."
                                    mc "I'm exploding right now!"

                                    scene e2s10_jon-68 with dissolve
                                    unknown "Haha, I thought you might like it!"

                                    scene e2s10_jon-82 with dissolve
                                    unknown "Let's see what you're hiding under there."

                                    scene e2s10_jon-83 with dissolve
                                    unknown "*Smack*"

                                    scene e2s10_jon-84 with dissolve
                                    unknown "I see that your pants are going to explode if we keep your dick in there for much longer."

                                    scene e2s10_jon-85 with dissolve
                                    pause

                                    scene e2s10_jon-86 with dissolve
                                    unknown "How have you been keeping this down there?"

                                    scene e2s10_jon-85 with dissolve
                                    unknown "I'm honestly surprised."

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-blowjob1 with dissolve
                                    mc "Holy fuck that feels awesome!"
                                    unknown "I'm glad you like it."

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-handjob1 with dissolve
                                    unknown "Do you like it when I use my hand?"
                                    mc "Oh, yes, keep going!"

                                    scene e2s10_jon-handjob2 with dissolve
                                    mc "*Holy shit, she smells so good.*"
                                    mc "*And her hand is gripping my cock just right.*"

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-blowjob1 with dissolve
                                    pause

                                    scene e2s10_jon-handjob2 with dissolve
                                    unknown "Tell me when you want to cum, alright?"
                                    mc "Okay."

                                    scene e2s10_jon-handjob1 with dissolve
                                    pause

                                    $ GameRunning = True

                                    while GameRunning == True:
                                        menu:
                                            "Cum":
                                                $ GameRunning = False
                                                mc "Fuck... I'm coming!"

                                                scene e2s10_jon-handjob3 with dissolve
                                                unknown "Come on!"
                                                unknown "Give me your cum."
                                                unknown "I want to see you cum on my big tits by my small hands."
                                                mc "Ohh... here it goes!"

                                                show white with Dissolve(0.25)
                                                scene e2s10_jon-87
                                                show white with vpunch
                                                hide white with Dissolve(0.25)
                                                show white with Dissolve(0.25)
                                                show white with vpunch
                                                hide white with Dissolve(0.25)
                                                show white with Dissolve(0.25)
                                                show white with vpunch
                                                hide white with Dissolve(0.25)

                                                scene e2s10_jon-88 with dissolve
                                                unknown "Damn... you came a lot."

                                                scene e2s10_jon-89 with dissolve
                                                unknown "How long has it been since you've last ejaculated?"

                                                scene e2s10_jon-88 with dissolve
                                                if e2f2_tracy_sex == True or e2f2_tiffany_sex == True:
                                                    mc "I don't know... a couple of hours maybe."
                                                    unknown "A couple of hours?"
                                                    unknown "Boy you've got stamina, I'll give you that."
                                                else:
                                                    mc "It's been a while."
                                                    unknown "Haha, I can see!"

                                                unknown "Let me clean you up."

                                                scene e2s10_jon-90 with dissolve
                                                mc "Ah, fuck!"

                                                scene black with Dissolve(2.0)

                                                scene e2s10_jon-91 with Dissolve(2.0)
                                                unknown "Alright, it was fun but now I'll have to go."

                                                scene e2s10_jon-96 with dissolve
                                                unknown "You know, we did all these things and I don't even know your name."

                                                scene e2s10_jon-95 with dissolve
                                                mc "Haha, I'm [mc]!"

                                                scene e2s10_jon-96 with dissolve
                                                unknown "I'm [ca], nice to meet you."
                                                ca "Hey, [mc], I'm gonna give you my phone number."
                                                ca "In case you need a release or something, you can call me."

                                                scene e2s10_jon-95 with dissolve
                                                mc "Alright [ca], thanks!"

                                                scene e2s10_jon-92 with dissolve
                                                ca "See you [mc]!"
                                                mc "I will miss that."

                                                scene e2s10_jon-93 with dissolve
                                                pause

                                                scene e2s10_jon-94 with dissolve
                                                mc "*Damn... she really was amazing.*"
                                                mc "*I'll definitely visit her again.*"
                                            "Keep going":
                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-blowjob1 with dissolve
                                                mc "Holy fuck that feels awesome!"
                                                unknown "I'm glad you like it."

                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-handjob1 with dissolve
                                                mc "Oh, yes, keep going!"

                                                scene e2s10_jon-handjob2 with dissolve
                                                mc "*Holy shit, she smells so good.*"
                                                mc "*And her hand is gripping my cock just right.*"

                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-blowjob1 with dissolve
                                                pause

                                                scene e2s10_jon-handjob2 with dissolve
                                                unknown "Tell me when you want to cum, alright?"
                                                mc "Okay."

                                                scene e2s10_jon-handjob1 with dissolve
                                                pause

                                    $ renpy.end_replay()
                                    return
                                "Refuse her":
                                    $ renpy.show_screen("money_notify")
                                    $ renpy.hide_screen("money_notify_pers")
                                    mc "I'm okay, thank you."

                                    scene e2s10_jon-69 with dissolve
                                    unknown "Alright, whatever you want sweetie!"
                        "Don't risk it":
                            mc "*I better not...*"
                            mc "*I don't know how she'll react.*"

                    scene e2s10_jon-62 with dissolve
                    pause

                    scene e2s10_jon-61 with dissolve
                    pause

                    scene e2s10_jon-114 with dissolve
                    pause

                    scene e2s10_jon-63 with dissolve
                    pause

                    scene e2s10_jon-64 with dissolve
                    pause

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-98 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    pause

                    scene e2s10_jon-101 with dissolve
                    pause

                    scene e2s10_jon-91 with dissolve
                    unknown "I hope you enjoyed my show sweetie."

                    scene e2s10_jon-95 with dissolve
                    mc "Thank you for the lap dance."
                    mc "It was really hot."

                    scene e2s10_jon-96 with dissolve
                    unknown "You're welcome."

                    scene e2s10_jon-113 with dissolve
                    unknown "I didn't catch your name."

                    scene e2s10_jon-95 with dissolve
                    mc "I'm [mc]."

                    scene e2s10_jon-96 with dissolve
                    unknown "Cute name, I'm [ca]."
                    ca "I hope to see you again here, sweetie!"

                    scene e2s10_jon-113 with dissolve
                    ca "Maybe for some more exciting things next time."

                    scene e2s10_jon-95 with dissolve
                    mc "Haha, for sure."

                    scene e2s10_jon-96 with dissolve
                    ca "Bye [mc]!"

                    scene e2s10_jon-95 with dissolve
                    mc "Bye [ca]!"

                    scene e2s10_jon-92 with dissolve
                    pause

                    scene e2s10_jon-93 with dissolve
                    pause

                    scene e2s10_jon-94 with dissolve
                    pause
                else:
                    if persistent.e2s10_lap_dance < 1:
                        $ persistent.e2s10_lap_dance = 1

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-80 with dissolve
                    mc "*Oh... shit!*"

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-98 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    menu:
                        "Touch her":
                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-102 with dissolve
                            unknown "Umm... hey..."
                            unknown "Touching wasn't available in our deal."

                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-110 with dissolve
                            pause
                            mc "You're right, I'm sorry."
                        "Don't risk it":
                            scene e2s10_jon-110 with dissolve
                            pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    menu:
                        "Touch her":
                            $ candance_trust -= 1
                            scene e2s10_jon-101 with dissolve
                            pause
                            unknown "Hey!"

                            scene e2s10_jon-111 with dissolve
                            unknown "I thought I told you not to touch."

                            scene e2s10_jon-110 with dissolve
                            mc "You're right, I'm sorry."
                            mc "It won't happen again."

                            scene e2s10_jon-111 with dissolve
                            unknown "Show's over."
                            unknown "Time is up."

                            scene e2s10_jon-112 with dissolve
                            mc "Hey, I'm sorry!"
                            mc "Didn't mean to offend you."

                            scene e2s10_jon-93 with dissolve
                            pause

                            scene e2s10_jon-94 with dissolve
                            mc "*Damn... I blew this.*"
                            mc "*Didn't I?*"

                            return
                        "Don't risk it":
                            scene e2s10_jon-110 with dissolve
                            pause

                            scene e2s10_jon-76 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-74 with dissolve
                            pause

                            scene e2s10_jon-73 with dissolve
                            pause

                            scene e2s10_jon-71 with dissolve
                            pause

                            scene e2s10_jon-75 with dissolve
                            pause

                            scene e2s10_jon-100 with dissolve
                            pause

                            scene e2s10_jon-97 with dissolve
                            pause

                            scene e2s10_jon-77 with dissolve
                            pause

                            scene e2s10_jon-78 with dissolve
                            pause

                            scene e2s10_jon-79 with dissolve
                            pause

                            scene e2s10_jon-91 with dissolve
                            unknown "I hope you enjoyed my show sweetie."

                            scene e2s10_jon-95 with dissolve
                            mc "Thank you for the lap dance."
                            mc "It was really hot."

                            scene e2s10_jon-96 with dissolve
                            unknown "You're welcome."

                            scene e2s10_jon-113 with dissolve
                            unknown "I didn't catch your name."

                            scene e2s10_jon-95 with dissolve
                            mc "I'm [mc]."

                            scene e2s10_jon-96 with dissolve
                            unknown "Cute name, I'm [ca]."
                            ca "I hope to see you again here, sweetie!"

                            scene e2s10_jon-113 with dissolve
                            ca "Maybe for some more exciting things next time."

                            scene e2s10_jon-95 with dissolve
                            mc "Haha, for sure."

                            scene e2s10_jon-96 with dissolve
                            ca "Bye [mc]!"

                            scene e2s10_jon-95 with dissolve
                            mc "Bye [ca]!"

                            scene e2s10_jon-92 with dissolve
                            pause

                            scene e2s10_jon-93 with dissolve
                            pause

                            scene e2s10_jon-94 with dissolve
                            pause
            else:
                if persistent.e2s10_lap_dance >= 2:
                    scene e2s10_jon-61 with dissolve
                    unknown "Now sit back, and relax."

                    scene e2s10_jon-62 with dissolve
                    pause

                    scene e2s10_jon-63 with dissolve
                    pause

                    scene e2s10_jon-64 with dissolve
                    pause

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-66 with dissolve
                    pause

                    scene e2s10_jon-65 with dissolve
                    unknown "You are touchy, aren't you?"

                    scene e2s10_jon-66 with dissolve
                    menu:
                        "Slap her":
                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-67 with dissolve
                            unknown "Ah... fuck!"
                            unknown "Do it again."

                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-65 with dissolve
                            unknown "Let's see how you like this."

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-65 with dissolve
                            unknown "Do you like it?"

                            scene e2s10_jon-66 with dissolve
                            mc "I love it!"
                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-slap with dissolve
                            pause(1.05)
                            scene e2s10_jon-66 with dissolve
                            unknown "Ahh, fuck!"

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-100 with dissolve
                            pause

                            scene e2s10_jon-99 with dissolve
                            pause

                            scene e2s10_jon-98 with dissolve
                            pause

                            scene e2s10_jon-97 with dissolve
                            pause

                            scene e2s10_jon-80 with dissolve
                            unknown "I see you have a little something down there..."

                            scene e2s10_jon-114 with dissolve
                            pause

                            scene e2s10_jon-61 with dissolve
                            pause

                            scene e2s10_jon-68 with dissolve
                            unknown "You know... I don't usually do this but I like you."

                            scene e2s10_jon-69 with dissolve
                            unknown "You know how to get what you like and I like that about you."

                            scene e2s10_jon-81 with dissolve
                            unknown "Now... I know how hard it must be for you to watch this show without any action."

                            scene e2s10_jon-69 with dissolve
                            unknown "So, I could offer you a blowjob for just {color=#4CBB17}$1{/color}."
                            unknown "But don't tell anyone about this, alright?"

                            scene e2s10_jon-70 with dissolve
                            menu:
                                "Accept her offer" if persistent.e2s10_lap_dance == 3:
                                    mc "Alright, give me a blowjob."
                                    mc "I'm exploding right now!"

                                    scene e2s10_jon-68 with dissolve
                                    unknown "Haha, I thought you might like it!"

                                    scene e2s10_jon-82 with dissolve
                                    unknown "Let's see what you're hiding under there."

                                    scene e2s10_jon-83 with dissolve
                                    unknown "*Smack*"

                                    scene e2s10_jon-84 with dissolve
                                    unknown "I see that your pants are going to explode if we keep your dick in there for much longer."

                                    scene e2s10_jon-85 with dissolve
                                    pause

                                    scene e2s10_jon-86 with dissolve
                                    unknown "How have you been keeping this down there?"

                                    scene e2s10_jon-85 with dissolve
                                    unknown "I'm honestly surprised."

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-blowjob1 with dissolve
                                    mc "Holy fuck that feels awesome!"
                                    unknown "I'm glad you like it."

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-handjob1 with dissolve
                                    unknown "Do you like it when I use my hand?"
                                    mc "Oh, yes, keep going!"

                                    scene e2s10_jon-handjob2 with dissolve
                                    mc "*Holy shit, she smells so good.*"
                                    mc "*And her hand is gripping my cock just right.*"

                                    scene e2s10_jon-blowjob2 with dissolve
                                    pause

                                    scene e2s10_jon-blowjob1 with dissolve
                                    pause

                                    scene e2s10_jon-handjob2 with dissolve
                                    unknown "Tell me when you want to cum, alright?"
                                    mc "Okay."

                                    scene e2s10_jon-handjob1 with dissolve
                                    pause

                                    $ GameRunning = True

                                    while GameRunning == True:
                                        menu:
                                            "Cum":
                                                $ GameRunning = False
                                                mc "Fuck... I'm coming!"

                                                scene e2s10_jon-handjob3 with dissolve
                                                unknown "Come on!"
                                                unknown "Give me your cum."
                                                unknown "I want to see you cum on my big tits by my small hands."
                                                mc "Ohh... here it goes!"

                                                show white with Dissolve(0.25)
                                                scene e2s10_jon-87
                                                show white with vpunch
                                                hide white with Dissolve(0.25)
                                                show white with Dissolve(0.25)
                                                show white with vpunch
                                                hide white with Dissolve(0.25)
                                                show white with Dissolve(0.25)
                                                show white with vpunch
                                                hide white with Dissolve(0.25)

                                                scene e2s10_jon-88 with dissolve
                                                unknown "Damn... you came a lot."

                                                scene e2s10_jon-89 with dissolve
                                                unknown "How long has it been since you've last ejaculated?"

                                                scene e2s10_jon-88 with dissolve
                                                if e2f2_tracy_sex == True or e2f2_tiffany_sex == True:
                                                    mc "I don't know... a couple of hours maybe."
                                                    unknown "A couple of hours?"
                                                    unknown "Boy you've got stamina, I'll give you that."
                                                else:
                                                    mc "It's been a while."
                                                    unknown "Haha, I can see!"

                                                unknown "Let me clean you up."

                                                scene e2s10_jon-90 with dissolve
                                                mc "Ah, fuck!"

                                                scene black with Dissolve(2.0)

                                                scene e2s10_jon-91 with Dissolve(2.0)
                                                unknown "Alright, it was fun but now I'll have to go."

                                                scene e2s10_jon-96 with dissolve
                                                unknown "You know, we did all these things and I don't even know your name."

                                                scene e2s10_jon-95 with dissolve
                                                mc "Haha, I'm [mc]!"

                                                scene e2s10_jon-96 with dissolve
                                                unknown "I'm [ca], nice to meet you."
                                                ca "Hey, [mc], I'm gonna give you my phone number."
                                                ca "In case you need a release or something, you can call me."

                                                scene e2s10_jon-95 with dissolve
                                                mc "Alright [ca], thanks!"

                                                scene e2s10_jon-92 with dissolve
                                                ca "See you [mc]!"
                                                mc "I will miss that."

                                                scene e2s10_jon-93 with dissolve
                                                pause

                                                scene e2s10_jon-94 with dissolve
                                                mc "*Damn... she really was amazing.*"
                                                mc "*I'll definitely visit her again.*"
                                            "Keep going":
                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-blowjob1 with dissolve
                                                mc "Holy fuck that feels awesome!"
                                                unknown "I'm glad you like it."

                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-handjob1 with dissolve
                                                mc "Oh, yes, keep going!"

                                                scene e2s10_jon-handjob2 with dissolve
                                                mc "*Holy shit, she smells so good.*"
                                                mc "*And her hand is gripping my cock just right.*"

                                                scene e2s10_jon-blowjob2 with dissolve
                                                pause

                                                scene e2s10_jon-blowjob1 with dissolve
                                                pause

                                                scene e2s10_jon-handjob2 with dissolve
                                                unknown "Tell me when you want to cum, alright?"
                                                mc "Okay."

                                                scene e2s10_jon-handjob1 with dissolve
                                                pause

                                    $ renpy.end_replay()
                                    return
                                "Refuse her" if persistent.e2s10_lap_dance >= 2:
                                    mc "I'm okay, thank you."

                                    scene e2s10_jon-69 with dissolve
                                    unknown "Alright, whatever you want sweetie!"
                        "Don't risk it":
                            pass

                    scene e2s10_jon-62 with dissolve
                    pause

                    scene e2s10_jon-61 with dissolve
                    pause

                    scene e2s10_jon-114 with dissolve
                    pause

                    scene e2s10_jon-63 with dissolve
                    pause

                    scene e2s10_jon-64 with dissolve
                    pause

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-98 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    pause

                    scene e2s10_jon-101 with dissolve
                    pause

                    scene e2s10_jon-91 with dissolve
                    unknown "I hope you enjoyed my show sweetie."

                    scene e2s10_jon-95 with dissolve
                    mc "Thank you for the lap dance."
                    mc "It was really hot."

                    scene e2s10_jon-96 with dissolve
                    unknown "You're welcome."

                    scene e2s10_jon-113 with dissolve
                    unknown "I didn't catch your name."

                    scene e2s10_jon-95 with dissolve
                    mc "I'm [mc]."

                    scene e2s10_jon-96 with dissolve
                    unknown "Cute name, I'm [ca]."
                    ca "I hope to see you again here, sweetie!"

                    scene e2s10_jon-113 with dissolve
                    ca "Maybe for some more exciting things next time."

                    scene e2s10_jon-95 with dissolve
                    mc "Haha, for sure."

                    scene e2s10_jon-96 with dissolve
                    ca "Bye [mc]!"

                    scene e2s10_jon-95 with dissolve
                    mc "Bye [ca]!"

                    scene e2s10_jon-92 with dissolve
                    pause

                    scene e2s10_jon-93 with dissolve
                    pause

                    scene e2s10_jon-94 with dissolve
                    pause
                else:
                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-80 with dissolve
                    mc "*Oh... shit!*"

                    scene e2s10_jon-71 with dissolve
                    pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-98 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    menu:
                        "Touch her":
                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-102 with dissolve
                            unknown "Umm... hey..."
                            unknown "Touching wasn't available in our deal."

                            scene e2s10_jon-101 with dissolve
                            pause

                            scene e2s10_jon-110 with dissolve
                            pause
                            mc "You're right, I'm sorry."
                        "Don't risk it":
                            scene e2s10_jon-110 with dissolve
                            pause

                    scene e2s10_jon-76 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-twerk2 with dissolve
                    pause

                    scene e2s10_jon-twerk1 with dissolve
                    pause

                    scene e2s10_jon-74 with dissolve
                    pause

                    scene e2s10_jon-72 with dissolve
                    pause

                    scene e2s10_jon-75 with dissolve
                    pause

                    scene e2s10_jon-97 with dissolve
                    pause

                    scene e2s10_jon-77 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-79 with dissolve
                    pause

                    scene e2s10_jon-73 with dissolve
                    pause

                    scene e2s10_jon-78 with dissolve
                    pause

                    scene e2s10_jon-99 with dissolve
                    pause

                    scene e2s10_jon-100 with dissolve
                    menu:
                        "Touch her":
                            $ candance_trust -= 1
                            scene e2s10_jon-101 with dissolve
                            pause
                            unknown "Hey!"

                            scene e2s10_jon-111 with dissolve
                            unknown "I thought I told you not to touch."

                            scene e2s10_jon-110 with dissolve
                            mc "You're right, I'm sorry."
                            mc "It won't happen again."

                            scene e2s10_jon-111 with dissolve
                            unknown "Show's over."
                            unknown "Time is up."

                            scene e2s10_jon-112 with dissolve
                            mc "Hey, I'm sorry!"
                            mc "Didn't mean to offend you."

                            scene e2s10_jon-93 with dissolve
                            pause

                            scene e2s10_jon-94 with dissolve
                            mc "*Damn... I blew this.*"
                            mc "*Didn't I?*"
                        "Don't risk it":
                            scene e2s10_jon-110 with dissolve
                            pause

                            scene e2s10_jon-76 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-twerk2 with dissolve
                            pause

                            scene e2s10_jon-twerk1 with dissolve
                            pause

                            scene e2s10_jon-74 with dissolve
                            pause

                            scene e2s10_jon-73 with dissolve
                            pause

                            scene e2s10_jon-71 with dissolve
                            pause

                            scene e2s10_jon-75 with dissolve
                            pause

                            scene e2s10_jon-100 with dissolve
                            pause

                            scene e2s10_jon-97 with dissolve
                            pause

                            scene e2s10_jon-77 with dissolve
                            pause

                            scene e2s10_jon-78 with dissolve
                            pause

                            scene e2s10_jon-79 with dissolve
                            pause

                            scene e2s10_jon-91 with dissolve
                            unknown "I hope you enjoyed my show sweetie."

                            scene e2s10_jon-95 with dissolve
                            mc "Thank you for the lap dance."
                            mc "It was really hot."

                            scene e2s10_jon-96 with dissolve
                            unknown "You're welcome."

                            scene e2s10_jon-113 with dissolve
                            unknown "I didn't catch your name."

                            scene e2s10_jon-95 with dissolve
                            mc "I'm [mc]."

                            scene e2s10_jon-96 with dissolve
                            unknown "Cute name, I'm [ca]."
                            ca "I hope to see you again here, sweetie!"

                            scene e2s10_jon-113 with dissolve
                            ca "Maybe for some more exciting things next time."

                            scene e2s10_jon-95 with dissolve
                            mc "Haha, for sure."

                            scene e2s10_jon-96 with dissolve
                            ca "Bye [mc]!"

                            scene e2s10_jon-95 with dissolve
                            mc "Bye [ca]!"

                            scene e2s10_jon-92 with dissolve
                            pause

                            scene e2s10_jon-93 with dissolve
                            pause

                            scene e2s10_jon-94 with dissolve
                            pause
        else:
            if persistent.type_nsfw == False:
                scene e2s10_jon-57_cen with dissolve
                pause

                scene e2s10_jon-58 with dissolve
                mc "*Holy fuck...*"

                scene e2s10_jon-59_cen with dissolve
                pause

                scene e2s10_jon-60_cen with dissolve
                unknown "Lose the jacket sweetie, you won't need it here."

                if not _in_replay:
                    if e2s10_lap_dance == 2 or e2s10_lap_dance == 3:
                        if persistent.e2s10_lap_dance < 2:
                            $ persistent.e2s10_lap_dance = 2
                        scene e2s10_jon-61_cen with dissolve
                        unknown "Now sit back, and relax."

                        scene e2s10_jon-62_cen with dissolve
                        pause

                        scene e2s10_jon-63_cen with dissolve
                        pause

                        scene e2s10_jon-64 with dissolve
                        pause

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-66_cen with dissolve
                        pause

                        scene e2s10_jon-65_cen with dissolve
                        unknown "You are touchy, aren't you?"

                        scene e2s10_jon-66_cen with dissolve
                        menu:
                            "Slap her":
                                $ candance_trust += 1
                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-67_cen with dissolve
                                unknown "Ah... fuck!"
                                unknown "Do it again."

                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-65_cen with dissolve
                                unknown "Let's see how you like this."

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-65_cen with dissolve
                                unknown "Do you like it?"

                                scene e2s10_jon-66_cen with dissolve
                                mc "I love it!"
                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                unknown "Ahh, fuck!"

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-100 with dissolve
                                pause

                                scene e2s10_jon-99 with dissolve
                                pause

                                scene e2s10_jon-98 with dissolve
                                pause

                                scene e2s10_jon-97_cen with dissolve
                                pause

                                scene e2s10_jon-80 with dissolve
                                unknown "I see you have a little something down there..."

                                scene e2s10_jon-114_cen with dissolve
                                pause

                                scene e2s10_jon-61_cen with dissolve
                                pause

                                scene e2s10_jon-68_cen with dissolve
                                unknown "You know... I don't usually do this but I like you."

                                scene e2s10_jon-69 with dissolve
                                unknown "You know how to get what you like and I like that about you."

                                scene e2s10_jon-81 with dissolve
                                unknown "Now... I know how hard it must be for you to watch this show without any action."

                                scene e2s10_jon-69 with dissolve
                                unknown "So, I could offer you a blowjob for just {color=#4CBB17}$1{/color}."
                                unknown "But don't tell anyone about this, alright?"

                                scene e2s10_jon-70 with dissolve
                                $ renpy.show_screen("money_notify_pers")
                                menu:
                                    "Accept her offer {color=#f00}(-$1){/color}" if money > 0:
                                        $ persistent.e2s10_lap_dance = 3
                                        $ money -= 1

                                        $ renpy.show_screen("money_notify")
                                        $ renpy.hide_screen("money_notify_pers")
                                        mc "Alright, give me a blowjob."
                                        mc "I'm exploding right now!"

                                        scene e2s10_jon-68_cen with dissolve
                                        unknown "Haha, I thought you might like it!"

                                        scene e2s10_jon-82_cen with dissolve
                                        unknown "Let's see what you're hiding under there."

                                        scene e2s10_jon-83 with dissolve
                                        unknown "*Smack*"

                                        scene e2s10_jon-84 with dissolve
                                        unknown "I see that your pants are going to explode if we keep your dick in there for much longer."

                                        scene e2s10_jon-85_cen with dissolve
                                        pause

                                        scene e2s10_jon-86_cen with dissolve
                                        unknown "How have you been keeping this down there?"

                                        scene e2s10_jon-85_cen with dissolve
                                        unknown "I'm honestly surprised."

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-blowjob1_cen with dissolve
                                        mc "Holy fuck that feels awesome!"
                                        unknown "I'm glad you like it."

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-handjob1_cen with dissolve
                                        unknown "Do you like it when I use my hand?"
                                        mc "Oh, yes, keep going!"

                                        scene e2s10_jon-handjob2_cen with dissolve
                                        mc "*Holy shit, she smells so good.*"
                                        mc "*And her hand is gripping my cock just right.*"

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-blowjob1_cen with dissolve
                                        pause

                                        scene e2s10_jon-handjob2_cen with dissolve
                                        unknown "Tell me when you want to cum, alright?"
                                        mc "Okay."

                                        scene e2s10_jon-handjob1_cen with dissolve
                                        pause

                                        $ GameRunning = True

                                        while GameRunning == True:
                                            menu:
                                                "Cum":
                                                    $ GameRunning = False
                                                    mc "Fuck... I'm coming!"

                                                    scene e2s10_jon-handjob3_cen with dissolve
                                                    unknown "Come on!"
                                                    unknown "Give me your cum."
                                                    unknown "I want to see you cum on my big tits by my small hands."
                                                    mc "Ohh... here it goes!"

                                                    show white with Dissolve(0.25)
                                                    scene e2s10_jon-87_cen
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)
                                                    show white with Dissolve(0.25)
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)
                                                    show white with Dissolve(0.25)
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)

                                                    scene e2s10_jon-88_cen with dissolve
                                                    unknown "Damn... you came a lot."

                                                    scene e2s10_jon-89_cen with dissolve
                                                    unknown "How long has it been since you've last ejaculated?"

                                                    scene e2s10_jon-88_cen with dissolve
                                                    if e2f2_tracy_sex == True or e2f2_tiffany_sex == True:
                                                        mc "I don't know... a couple of hours maybe."
                                                        unknown "A couple of hours?"
                                                        unknown "Boy you've got stamina, I'll give you that."
                                                    else:
                                                        mc "It's been a while."
                                                        unknown "Haha, I can see!"

                                                    unknown "Let me clean you up."

                                                    scene e2s10_jon-90_cen with dissolve
                                                    mc "Ah, fuck!"

                                                    scene black with Dissolve(2.0)

                                                    scene e2s10_jon-91 with Dissolve(2.0)
                                                    unknown "Alright, it was fun but now I'll have to go."

                                                    scene e2s10_jon-96 with dissolve
                                                    unknown "You know, we did all these things and I don't even know your name."

                                                    scene e2s10_jon-95 with dissolve
                                                    mc "Haha, I'm [mc]!"

                                                    scene e2s10_jon-96 with dissolve
                                                    unknown "I'm [ca], nice to meet you."
                                                    ca "Hey, [mc], I'm gonna give you my phone number."
                                                    ca "In case you need a release or something, you can call me."

                                                    scene e2s10_jon-95 with dissolve
                                                    mc "Alright [ca], thanks!"

                                                    scene e2s10_jon-92 with dissolve
                                                    ca "See you [mc]!"
                                                    mc "I will miss that."

                                                    scene e2s10_jon-93 with dissolve
                                                    pause

                                                    scene e2s10_jon-94 with dissolve
                                                    mc "*Damn... she really was amazing.*"
                                                    mc "*I'll definitely visit her again.*"
                                                "Keep going":
                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-blowjob1_cen with dissolve
                                                    mc "Holy fuck that feels awesome!"
                                                    unknown "I'm glad you like it."

                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-handjob1_cen with dissolve
                                                    mc "Oh, yes, keep going!"

                                                    scene e2s10_jon-handjob2_cen with dissolve
                                                    mc "*Holy shit, she smells so good.*"
                                                    mc "*And her hand is gripping my cock just right.*"

                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-blowjob1_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-handjob2_cen with dissolve
                                                    unknown "Tell me when you want to cum, alright?"
                                                    mc "Okay."

                                                    scene e2s10_jon-handjob1_cen with dissolve
                                                    pause

                                        $ renpy.end_replay()
                                        return
                                    "Refuse her":
                                        $ renpy.show_screen("money_notify")
                                        $ renpy.hide_screen("money_notify_pers")
                                        mc "I'm okay, thank you."

                                        scene e2s10_jon-69 with dissolve
                                        unknown "Alright, whatever you want sweetie!"
                            "Don't risk it":
                                mc "*I better not...*"
                                mc "*I don't know how she'll react.*"

                        scene e2s10_jon-62_cen with dissolve
                        pause

                        scene e2s10_jon-61_cen with dissolve
                        pause

                        scene e2s10_jon-114_cen with dissolve
                        pause

                        scene e2s10_jon-63_cen with dissolve
                        pause

                        scene e2s10_jon-64 with dissolve
                        pause

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-98 with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        pause

                        scene e2s10_jon-101 with dissolve
                        pause

                        scene e2s10_jon-91 with dissolve
                        unknown "I hope you enjoyed my show sweetie."

                        scene e2s10_jon-95 with dissolve
                        mc "Thank you for the lap dance."
                        mc "It was really hot."

                        scene e2s10_jon-96 with dissolve
                        unknown "You're welcome."

                        scene e2s10_jon-113 with dissolve
                        unknown "I didn't catch your name."

                        scene e2s10_jon-95 with dissolve
                        mc "I'm [mc]."

                        scene e2s10_jon-96 with dissolve
                        unknown "Cute name, I'm [ca]."
                        ca "I hope to see you again here, sweetie!"

                        scene e2s10_jon-113 with dissolve
                        ca "Maybe for some more exciting things next time."

                        scene e2s10_jon-95 with dissolve
                        mc "Haha, for sure."

                        scene e2s10_jon-96 with dissolve
                        ca "Bye [mc]!"

                        scene e2s10_jon-95 with dissolve
                        mc "Bye [ca]!"

                        scene e2s10_jon-92 with dissolve
                        pause

                        scene e2s10_jon-93 with dissolve
                        pause

                        scene e2s10_jon-94 with dissolve
                        pause
                    else:
                        if persistent.e2s10_lap_dance < 1:
                            $ persistent.e2s10_lap_dance = 1

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-80 with dissolve
                        mc "*Oh... shit!*"

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-98 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        menu:
                            "Touch her":
                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-102_cen with dissolve
                                unknown "Umm... hey..."
                                unknown "Touching wasn't available in our deal."

                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-110 with dissolve
                                pause
                                mc "You're right, I'm sorry."
                            "Don't risk it":
                                scene e2s10_jon-110 with dissolve
                                pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        menu:
                            "Touch her":
                                $ candance_trust -= 1
                                scene e2s10_jon-101 with dissolve
                                pause
                                unknown "Hey!"

                                scene e2s10_jon-111_cen with dissolve
                                unknown "I thought I told you not to touch."

                                scene e2s10_jon-110 with dissolve
                                mc "You're right, I'm sorry."
                                mc "It won't happen again."

                                scene e2s10_jon-111_cen with dissolve
                                unknown "Show's over."
                                unknown "Time is up."

                                scene e2s10_jon-112 with dissolve
                                mc "Hey, I'm sorry!"
                                mc "Didn't mean to offend you."

                                scene e2s10_jon-93 with dissolve
                                pause

                                scene e2s10_jon-94 with dissolve
                                mc "*Damn... I blew this.*"
                                mc "*Didn't I?*"

                                return
                            "Don't risk it":
                                scene e2s10_jon-110 with dissolve
                                pause

                                scene e2s10_jon-76 with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-74_cen with dissolve
                                pause

                                scene e2s10_jon-73_cen with dissolve
                                pause

                                scene e2s10_jon-71_cen with dissolve
                                pause

                                scene e2s10_jon-75 with dissolve
                                pause

                                scene e2s10_jon-100 with dissolve
                                pause

                                scene e2s10_jon-97_cen with dissolve
                                pause

                                scene e2s10_jon-77_cen with dissolve
                                pause

                                scene e2s10_jon-78_cen with dissolve
                                pause

                                scene e2s10_jon-79_cen with dissolve
                                pause

                                scene e2s10_jon-91 with dissolve
                                unknown "I hope you enjoyed my show sweetie."

                                scene e2s10_jon-95 with dissolve
                                mc "Thank you for the lap dance."
                                mc "It was really hot."

                                scene e2s10_jon-96 with dissolve
                                unknown "You're welcome."

                                scene e2s10_jon-113 with dissolve
                                unknown "I didn't catch your name."

                                scene e2s10_jon-95 with dissolve
                                mc "I'm [mc]."

                                scene e2s10_jon-96 with dissolve
                                unknown "Cute name, I'm [ca]."
                                ca "I hope to see you again here, sweetie!"

                                scene e2s10_jon-113 with dissolve
                                ca "Maybe for some more exciting things next time."

                                scene e2s10_jon-95 with dissolve
                                mc "Haha, for sure."

                                scene e2s10_jon-96 with dissolve
                                ca "Bye [mc]!"

                                scene e2s10_jon-95 with dissolve
                                mc "Bye [ca]!"

                                scene e2s10_jon-92 with dissolve
                                pause

                                scene e2s10_jon-93 with dissolve
                                pause

                                scene e2s10_jon-94 with dissolve
                                pause
                else:
                    if persistent.e2s10_lap_dance >= 2:
                        scene e2s10_jon-61_cen with dissolve
                        unknown "Now sit back, and relax."

                        scene e2s10_jon-62_cen with dissolve
                        pause

                        scene e2s10_jon-63_cen with dissolve
                        pause

                        scene e2s10_jon-64 with dissolve
                        pause

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-66_cen with dissolve
                        pause

                        scene e2s10_jon-65_cen with dissolve
                        unknown "You are touchy, aren't you?"

                        scene e2s10_jon-66_cen with dissolve
                        menu:
                            "Slap her":
                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-67_cen with dissolve
                                unknown "Ah... fuck!"
                                unknown "Do it again."

                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-65_cen with dissolve
                                unknown "Let's see how you like this."

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-65_cen with dissolve
                                unknown "Do you like it?"

                                scene e2s10_jon-66_cen with dissolve
                                mc "I love it!"
                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-slap_cen with dissolve
                                pause(1.05)
                                scene e2s10_jon-66_cen with dissolve
                                unknown "Ahh, fuck!"

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-100 with dissolve
                                pause

                                scene e2s10_jon-99 with dissolve
                                pause

                                scene e2s10_jon-98 with dissolve
                                pause

                                scene e2s10_jon-97_cen with dissolve
                                pause

                                scene e2s10_jon-80 with dissolve
                                unknown "I see you have a little something down there..."

                                scene e2s10_jon-114_cen with dissolve
                                pause

                                scene e2s10_jon-61_cen with dissolve
                                pause

                                scene e2s10_jon-68_cen with dissolve
                                unknown "You know... I don't usually do this but I like you."

                                scene e2s10_jon-69 with dissolve
                                unknown "You know how to get what you like and I like that about you."

                                scene e2s10_jon-81 with dissolve
                                unknown "Now... I know how hard it must be for you to watch this show without any action."

                                scene e2s10_jon-69 with dissolve
                                unknown "So, I could offer you a blowjob for just {color=#4CBB17}$1{/color}."
                                unknown "But don't tell anyone about this, alright?"

                                scene e2s10_jon-70 with dissolve
                                menu:
                                    "Accept her offer" if persistent.e2s10_lap_dance == 3:
                                        mc "Alright, give me a blowjob."
                                        mc "I'm exploding right now!"

                                        scene e2s10_jon-68_cen with dissolve
                                        unknown "Haha, I thought you might like it!"

                                        scene e2s10_jon-82_cen with dissolve
                                        unknown "Let's see what you're hiding under there."

                                        scene e2s10_jon-83 with dissolve
                                        unknown "*Smack*"

                                        scene e2s10_jon-84 with dissolve
                                        unknown "I see that your pants are going to explode if we keep your dick in there for much longer."

                                        scene e2s10_jon-85_cen with dissolve
                                        pause

                                        scene e2s10_jon-86_cen with dissolve
                                        unknown "How have you been keeping this down there?"

                                        scene e2s10_jon-85_cen with dissolve
                                        unknown "I'm honestly surprised."

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-blowjob1_cen with dissolve
                                        mc "Holy fuck that feels awesome!"
                                        unknown "I'm glad you like it."

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-handjob1_cen with dissolve
                                        unknown "Do you like it when I use my hand?"
                                        mc "Oh, yes, keep going!"

                                        scene e2s10_jon-handjob2_cen with dissolve
                                        mc "*Holy shit, she smells so good.*"
                                        mc "*And her hand is gripping my cock just right.*"

                                        scene e2s10_jon-blowjob2_cen with dissolve
                                        pause

                                        scene e2s10_jon-blowjob1_cen with dissolve
                                        pause

                                        scene e2s10_jon-handjob2_cen with dissolve
                                        unknown "Tell me when you want to cum, alright?"
                                        mc "Okay."

                                        scene e2s10_jon-handjob1_cen with dissolve
                                        pause

                                        $ GameRunning = True

                                        while GameRunning == True:
                                            menu:
                                                "Cum":
                                                    $ GameRunning = False
                                                    mc "Fuck... I'm coming!"

                                                    scene e2s10_jon-handjob3_cen with dissolve
                                                    unknown "Come on!"
                                                    unknown "Give me your cum."
                                                    unknown "I want to see you cum on my big tits by my small hands."
                                                    mc "Ohh... here it goes!"

                                                    show white with Dissolve(0.25)
                                                    scene e2s10_jon-87_cen
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)
                                                    show white with Dissolve(0.25)
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)
                                                    show white with Dissolve(0.25)
                                                    show white with vpunch
                                                    hide white with Dissolve(0.25)

                                                    scene e2s10_jon-88_cen with dissolve
                                                    unknown "Damn... you came a lot."

                                                    scene e2s10_jon-89_cen with dissolve
                                                    unknown "How long has it been since you've last ejaculated?"

                                                    scene e2s10_jon-88_cen with dissolve
                                                    if e2f2_tracy_sex == True or e2f2_tiffany_sex == True:
                                                        mc "I don't know... a couple of hours maybe."
                                                        unknown "A couple of hours?"
                                                        unknown "Boy you've got stamina, I'll give you that."
                                                    else:
                                                        mc "It's been a while."
                                                        unknown "Haha, I can see!"

                                                    unknown "Let me clean you up."

                                                    scene e2s10_jon-90_cen with dissolve
                                                    mc "Ah, fuck!"

                                                    scene black with Dissolve(2.0)

                                                    scene e2s10_jon-91 with Dissolve(2.0)
                                                    unknown "Alright, it was fun but now I'll have to go."

                                                    scene e2s10_jon-96 with dissolve
                                                    unknown "You know, we did all these things and I don't even know your name."

                                                    scene e2s10_jon-95 with dissolve
                                                    mc "Haha, I'm [mc]!"

                                                    scene e2s10_jon-96 with dissolve
                                                    unknown "I'm [ca], nice to meet you."
                                                    ca "Hey, [mc], I'm gonna give you my phone number."
                                                    ca "In case you need a release or something, you can call me."

                                                    scene e2s10_jon-95 with dissolve
                                                    mc "Alright [ca], thanks!"

                                                    scene e2s10_jon-92 with dissolve
                                                    ca "See you [mc]!"
                                                    mc "I will miss that."

                                                    scene e2s10_jon-93 with dissolve
                                                    pause

                                                    scene e2s10_jon-94 with dissolve
                                                    mc "*Damn... she really was amazing.*"
                                                    mc "*I'll definitely visit her again.*"
                                                "Keep going":
                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-blowjob1_cen with dissolve
                                                    mc "Holy fuck that feels awesome!"
                                                    unknown "I'm glad you like it."

                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-handjob1_cen with dissolve
                                                    mc "Oh, yes, keep going!"

                                                    scene e2s10_jon-handjob2_cen with dissolve
                                                    mc "*Holy shit, she smells so good.*"
                                                    mc "*And her hand is gripping my cock just right.*"

                                                    scene e2s10_jon-blowjob2_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-blowjob1_cen with dissolve
                                                    pause

                                                    scene e2s10_jon-handjob2_cen with dissolve
                                                    unknown "Tell me when you want to cum, alright?"
                                                    mc "Okay."

                                                    scene e2s10_jon-handjob1_cen with dissolve
                                                    pause

                                        $ renpy.end_replay()
                                        return
                                    "Refuse her" if persistent.e2s10_lap_dance >= 2:
                                        mc "I'm okay, thank you."

                                        scene e2s10_jon-69 with dissolve
                                        unknown "Alright, whatever you want sweetie!"
                            "Don't risk it":
                                pass

                        scene e2s10_jon-62_cen with dissolve
                        pause

                        scene e2s10_jon-61_cen with dissolve
                        pause

                        scene e2s10_jon-114_cen with dissolve
                        pause

                        scene e2s10_jon-63_cen with dissolve
                        pause

                        scene e2s10_jon-64 with dissolve
                        pause

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-98 with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        pause

                        scene e2s10_jon-101 with dissolve
                        pause

                        scene e2s10_jon-91 with dissolve
                        unknown "I hope you enjoyed my show sweetie."

                        scene e2s10_jon-95 with dissolve
                        mc "Thank you for the lap dance."
                        mc "It was really hot."

                        scene e2s10_jon-96 with dissolve
                        unknown "You're welcome."

                        scene e2s10_jon-113 with dissolve
                        unknown "I didn't catch your name."

                        scene e2s10_jon-95 with dissolve
                        mc "I'm [mc]."

                        scene e2s10_jon-96 with dissolve
                        unknown "Cute name, I'm [ca]."
                        ca "I hope to see you again here, sweetie!"

                        scene e2s10_jon-113 with dissolve
                        ca "Maybe for some more exciting things next time."

                        scene e2s10_jon-95 with dissolve
                        mc "Haha, for sure."

                        scene e2s10_jon-96 with dissolve
                        ca "Bye [mc]!"

                        scene e2s10_jon-95 with dissolve
                        mc "Bye [ca]!"

                        scene e2s10_jon-92 with dissolve
                        pause

                        scene e2s10_jon-93 with dissolve
                        pause

                        scene e2s10_jon-94 with dissolve
                        pause
                    else:
                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-80 with dissolve
                        mc "*Oh... shit!*"

                        scene e2s10_jon-71_cen with dissolve
                        pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-98 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        menu:
                            "Touch her":
                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-102_cen with dissolve
                                unknown "Umm... hey..."
                                unknown "Touching wasn't available in our deal."

                                scene e2s10_jon-101 with dissolve
                                pause

                                scene e2s10_jon-110 with dissolve
                                pause
                                mc "You're right, I'm sorry."
                            "Don't risk it":
                                scene e2s10_jon-110 with dissolve
                                pause

                        scene e2s10_jon-76 with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-twerk2_cen with dissolve
                        pause

                        scene e2s10_jon-twerk1_cen with dissolve
                        pause

                        scene e2s10_jon-74_cen with dissolve
                        pause

                        scene e2s10_jon-72 with dissolve
                        pause

                        scene e2s10_jon-75 with dissolve
                        pause

                        scene e2s10_jon-97_cen with dissolve
                        pause

                        scene e2s10_jon-77_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-79_cen with dissolve
                        pause

                        scene e2s10_jon-73_cen with dissolve
                        pause

                        scene e2s10_jon-78_cen with dissolve
                        pause

                        scene e2s10_jon-99 with dissolve
                        pause

                        scene e2s10_jon-100 with dissolve
                        menu:
                            "Touch her":
                                $ candance_trust -= 1
                                scene e2s10_jon-101 with dissolve
                                pause
                                unknown "Hey!"

                                scene e2s10_jon-111_cen with dissolve
                                unknown "I thought I told you not to touch."

                                scene e2s10_jon-110 with dissolve
                                mc "You're right, I'm sorry."
                                mc "It won't happen again."

                                scene e2s10_jon-111_cen with dissolve
                                unknown "Show's over."
                                unknown "Time is up."

                                scene e2s10_jon-112 with dissolve
                                mc "Hey, I'm sorry!"
                                mc "Didn't mean to offend you."

                                scene e2s10_jon-93 with dissolve
                                pause

                                scene e2s10_jon-94 with dissolve
                                mc "*Damn... I blew this.*"
                                mc "*Didn't I?*"
                            "Don't risk it":
                                scene e2s10_jon-110 with dissolve
                                pause

                                scene e2s10_jon-76 with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-twerk2_cen with dissolve
                                pause

                                scene e2s10_jon-twerk1_cen with dissolve
                                pause

                                scene e2s10_jon-74_cen with dissolve
                                pause

                                scene e2s10_jon-73_cen with dissolve
                                pause

                                scene e2s10_jon-71_cen with dissolve
                                pause

                                scene e2s10_jon-75 with dissolve
                                pause

                                scene e2s10_jon-100 with dissolve
                                pause

                                scene e2s10_jon-97_cen with dissolve
                                pause

                                scene e2s10_jon-77_cen with dissolve
                                pause

                                scene e2s10_jon-78_cen with dissolve
                                pause

                                scene e2s10_jon-79_cen with dissolve
                                pause

                                scene e2s10_jon-91 with dissolve
                                unknown "I hope you enjoyed my show sweetie."

                                scene e2s10_jon-95 with dissolve
                                mc "Thank you for the lap dance."
                                mc "It was really hot."

                                scene e2s10_jon-96 with dissolve
                                unknown "You're welcome."

                                scene e2s10_jon-113 with dissolve
                                unknown "I didn't catch your name."

                                scene e2s10_jon-95 with dissolve
                                mc "I'm [mc]."

                                scene e2s10_jon-96 with dissolve
                                unknown "Cute name, I'm [ca]."
                                ca "I hope to see you again here, sweetie!"

                                scene e2s10_jon-113 with dissolve
                                ca "Maybe for some more exciting things next time."

                                scene e2s10_jon-95 with dissolve
                                mc "Haha, for sure."

                                scene e2s10_jon-96 with dissolve
                                ca "Bye [mc]!"

                                scene e2s10_jon-95 with dissolve
                                mc "Bye [ca]!"

                                scene e2s10_jon-92 with dissolve
                                pause

                                scene e2s10_jon-93 with dissolve
                                pause

                                scene e2s10_jon-94 with dissolve
                                pause

    if not _in_replay:
        pass
    else:
        stop music fadeout 2.0

    $ renpy.end_replay()
return
