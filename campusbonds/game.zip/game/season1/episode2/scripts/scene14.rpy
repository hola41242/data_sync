
# Scene 14 - Birthday party ####################################################

label e2s14:
    stop music fadeout 2.0

    scene black with Dissolve(2.0)

    scene e2s14-01 with Dissolve(2.0)
    play music bad_sexy_dad_vibes
    pause

    scene e2s14-03 with dissolve
    jon "Okay, now, [mc]..."

    scene e2s14-04 with dissolve
    jon "There might be some really arrogant people at the party."
    jon "Just try to act like a rich brat, okay?"

    scene e2s14-02 with dissolve
    show e2s14-jon_blink1
    mc "How does one act like a rich brat?"

    scene e2s14-04 with dissolve
    hide e2s14-jon_blink1
    jon "I don't know dude, just brag about shit you own."

    scene e2s14-03 with dissolve
    jon "Tell them how rich you are and they will love you."

    scene e2s14-02 with dissolve
    show e2s14-jon_blink1
    mc "Alright?"

    play sound door_open
    scene e2s14-05 with dissolve
    hide e2s14-jon_blink1
    ke "Hey guys, glad to see you could make it!"

    scene e2s14-06 with dissolve
    jon "We couldn't miss your birthday party, bro."

    scene e2s14-07 with dissolve
    jon "Here, this is a little something from me."
    jon "One of the finest wines I know, it's really good trust me."

    scene e2s14-08 with dissolve
    ke "You shouldn't have... thanks [jon]!"

    scene e2s14-09 with dissolve
    mc "I've also got you something, [ke]."

    scene e2s14-10 with dissolve
    ke "Oh, come on dude..."
    ke "You didn't have to."

    scene e2s14-09 with dissolve
    mc "Hey, it's not much, but I did my best!"

    scene e2s14-10 with dissolve
    ke "Thanks [mc], seriously."
    ke "You shouldn't have worried about it."

    scene e2s14-11 with dissolve
    ke "Come on in!"

    play sound door_close
    scene e2s14-12 with dissolve
    pause

    scene e2s14-13 with dissolve
    mc "Damn... this place is huge!"

    scene e2s14-14 with dissolve
    jon "I know right?"
    jon "I can't believe [ke] doesn't want to live in this house."

    scene e2s14-15 with dissolve
    mc "*Huh?*"
    mc "*Is that [ov]?*"

    scene e2s14-16 with dissolve
    pause

    scene e2s14-17 with dissolve
    mc "Hey [jon], you go ahead."
    mc "I'll catch up with you later."

    scene e2s14-18 with dissolve
    jon "Alright, don't get lost."

    scene e2s14-19 with dissolve
    mc "Sure thing!"

    scene e2s14-20 with dissolve
    pause

    scene e2s14-21 with dissolve
    mc "[ov]?"
    mc "What are you doing here?"

    scene e2s14-22 with dissolve
    ov "[mc]?"

    scene e2s14-24 with dissolve
    ov "Haha, I could ask you the same thing."

    scene e2s14-25 with dissolve
    ov "Didn't know you had a rich family."

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Well, that's the funny thing, I don't!"
    mc "It's my friend [ke]'s birthday party."

    scene e2s14-26 with dissolve
    hide e2s14-olivia_blink1
    ov "[ke]?"
    ov "My cousin?"

    scene e2s14-27 with dissolve
    show e2s14-olivia_blink1
    mc "Wait a minute..."
    mc "You guys are cousins?"

    scene e2s14-24 with dissolve
    hide e2s14-olivia_blink1
    ov "Haha, small world, right?"

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Well, I was expecting to see his family here and all."
    mc "After all, I've only known him for a week."
    mc "But you? I wouldn't have seen it coming."

    scene e2s14-24 with dissolve
    hide e2s14-olivia_blink1
    ov "Haha, do we not look alike?"

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Not one bit..."
    mc "So, how have you been?"

    scene e2s14-28 with dissolve
    hide e2s14-olivia_blink1
    ov "Well, I've just found a job recently and started working."

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Oh, cool."
    mc "What about your other thing?"
    mc "The social media stuff."

    scene e2s14-26 with dissolve
    hide e2s14-olivia_blink1
    ov "Oh, well, it's been getting some exposure here and there."

    scene e2s14-28 with dissolve
    ov "Nothing too crazy though."

    scene e2s14-27 with dissolve
    show e2s14-olivia_blink1
    mc "Keep going, you don't know where you could get with it."

    scene e2s14-29 with dissolve
    hide e2s14-olivia_blink1
    ov "How have you been [mc]?"
    ov "It's been some time since I've seen you at the gym."

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Oh, yeah..."
    mc "I've been busy with getting through my first week of college."
    mc "Meeting people and all."

    scene e2s14-25 with dissolve
    hide e2s14-olivia_blink1
    ov "Oh, I see!"

    scene e2s14-29 with dissolve
    ov "So, I guess I'll be seeing you more often in the gym then, right?"

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "Haha, yeah, you will!"
    jon "[mc], come on bro!"

    scene e2s14-30 with dissolve
    hide e2s14-olivia_blink1
    jon "We're gonna have a photoshoot."

    scene e2s14-33 with dissolve
    mc "Alright, coming!"

    scene e2s14-31 with dissolve
    jon "Don't forget to get a glass of champagne as well."

    scene e2s14-32 with dissolve
    pause

    scene e2s14-23 with dissolve
    show e2s14-olivia_blink1
    mc "I'll be seeing you around, [ov]!"
    mc "Looks like I'm needed for a photoshoot."

    scene e2s14-24 with dissolve
    hide e2s14-olivia_blink1
    ov "Haha, alright, have fun!"

    scene e2s14-25 with dissolve
    ov "See you!"

    scene e2s14-34 with dissolve
    pause

    scene e2s14-35 with dissolve
    pause

    scene e2s14-36 with dissolve
    pause

    scene e2s14-37 with dissolve
    mc "Hi guys!"

    scene e2s14-38 with dissolve
    ro "[mc]!"

    scene e2s14-39 with dissolve
    jd "Damn that suit looks tight on you."

    scene e2s14-40 with dissolve
    mc "Tell me about it."

    scene e2s14-39 with dissolve
    jd "It's making your muscles pop tho!"

    stop music fadeout 2.0
    scene e2s14-41 with dissolve
    play music brighter
    jon "Alright everyone, pay attention to the camera!"

    scene e2s14-42 with dissolve
    mc "*Friends...*"

    scene e2s14-43 with dissolve
    mc "*People that you spend time with, that you have fun with...*"

    scene e2s14-44 with dissolve
    mc "*Those people that help you when in need.*"

    scene e2s14-45 with dissolve
    mc "*Can we live without them? Probably... but we would be miserable.*"

    play sound camera_shutter
    scene white
    pause(0.1)
    scene e2s14-46 with dissolve
    mc "*I'm grateful to have them by my side.*"

    play sound camera_shutter
    scene white
    pause(0.1)
    scene e2s14-48 with dissolve
    mc "*I've realized that my life would have probably been a lot darker without them.*"

    play sound camera_shutter
    scene white
    pause(0.1)
    scene e2s14-47 with dissolve
    mc "*I like to think of my close friends as like my brothers.*"

    play sound camera_shutter
    scene white
    pause(0.1)
    scene e2s14-49 with dissolve
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(0.5)
    mc "*Unfortunately, nobody could've foreseen what was coming next...*"

    pause(1.0)

    scene e2s14-50 with Dissolve(2.0)
    pause

    scene e2s14-51 with dissolve
    pause

    scene black
    pause(1.0)
    $ episode_count += 1
    jump credits
return
