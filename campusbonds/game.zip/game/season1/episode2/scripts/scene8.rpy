
# Scene 8 - House party ########################################################

label e2s8:
    scene e2s8-01 with wipeleft
    play music piano
    pause

    scene e2s8-02 with dissolve
    ro "Finally, a house party!"
    ro "Looked forward to this one."

    scene e2s8-03 with dissolve
    jon "Haha, yeah!"

    if affinity_spectrum < 0:
        scene e2s8-04 with dissolve
        mc "What's so cool about house parties?"

        scene e2s8-05 with dissolve
        jd "You will see my friend."
    if affinity_spectrum > 0:
        scene e2s8-06 with dissolve
        mc "Can't believe you actually pulled this off."

        scene e2s8-08 with dissolve
        jon "Me neither!"

    if affinity_spectrum == 0:
        scene e2s8-07 with dissolve
        ke "Can't believe you actually pulled this off."

    scene e2s8-09 with dissolve
    jon "It's all thanks to [ro]'s friend."

    scene e2s8-10 with dissolve
    ro "Don't sell yourself short."
    ro "What would a party be without chicks?"

    scene e2s8-11 with dissolve
    jon "You're right on that regard, [ro]."

    scene e2s8-12 with dissolve
    mc "You know [jon], sometimes I wonder how you are only a freshman..."

    scene e2s8-13 with dissolve
    jon "[mc]... I live in this town."
    jon "I've made plenty of connections throughout the years."

    scene e2s8-14 with dissolve
    ke "He loved to be the popular kid in high school."

    scene e2s8-15 with dissolve
    jon "I wouldn't call myself that..."
    jon "I just liked to stand out and make people laugh."

    scene e2s8-16 with dissolve
    mc "Tell me about it..."

    scene e2s8-17 with dissolve
    pause

    play sound door_close
    scene e2s8-18 with dissolve
    no "Hello guys, come on in!"

    scene e2s8-20 with dissolve
    ro "Hey [no]!"

    scene e2s8-19 with dissolve
    no "Glad to see you could make it."
    no "I'm [no]."

    scene e2s8-21 with dissolve
    ke "Nice to meet you [no], I'm [ke]."

    scene e2s8-22 with dissolve
    jd "[jd]."

    scene e2s8-23 with dissolve
    if affinity_spectrum < 0:
        mc "My name is [mc]."
    else:
        mc "I'm [mc]."

    scene e2s8-24 with dissolve
    no "Welcome!"

    play sound door_close
    scene e2s8-25 with dissolve
    jon "Alright guys, let's get settled in."

    scene e2s8-26 with dissolve
    jon "You know the rule..."

    scene e2s8-27 with dissolve
    jon "Party like there's no tomorrow!"
    jon "Do whatever you want regardless of what that guy says."

    scene e2s8-28 with dissolve
    ro "He won't be too happy about that."
    ro "But he'll get over it."

    jump e2f2
return
