
# Scene 7 - Harbinger ##########################################################

label e2s7:
    stop music fadeout 1.0

    if e2s6_talk == False:
        scene e2s7-01 with wipeleft
        play music breathe
        pause

        scene e2s7-02 with dissolve
        unknown "Come on everyone!"
        unknown "Join the best partying group, THE PARTY RAGERS!"

        scene e2s7-03 with dissolve
        unknown "There is a limited amount of people accepted so hurry up and join now."

        scene e2s7-04 with dissolve
        jon "Look, the dirty work I've told you about."

        scene e2s7-05 with dissolve
        jon "Hey there, would you mind giving me a flyer?"

        scene e2s7-06 with dissolve
        pause

        scene e2s7-07 with dissolve
        unknown "Of course, here."

        scene e2s7-08 with dissolve
        unknown "Do you want a flyer too?"

        scene e2s7-09 with dissolve
        if affinity_spectrum > 0:
            mc "No thanks, I'm good."
        else:
            mc "Sure, give me one."

            scene e2s7-10 with dissolve
            unknown "Alright, here it is."

        scene e2s7-11 with dissolve
        pause

        scene e2s7-12 with dissolve
        pause

        scene e2s7-13 with dissolve
        rv "HEY, STOP RIGHT THERE!"

        scene e2s7-14 with dissolve
        rv "YOU AREN'T ALLOWED TO DO THAT!"

        scene e2s7-15 with dissolve
        rv "Who gave you permission to hand out these flyers?"
        unknown "Uhh..."

        scene e2s7-16 with dissolve
        jon "The Party Ragers, the best party club in town."
        jon "They messed this part, it should have been 'in the whole world'."

        scene e2s7-17 with dissolve
        jon "Learn how to party like there's no tomorrow in this special activity group."

        scene e2s7-18 with dissolve
        jon "This part is acceptable."

        scene e2s7-19 with dissolve
        mc "Are you gonna read all of it?"

        scene e2s7-20 with dissolve
        jon "No, these were the only parts that I was interested in."

        scene e2s7-21 with dissolve
        jon "I would have probably done a much better job if I were in their marketing team."

        scene e2s7-19 with dissolve
        mc "Haha, I'm sure you would have."
        mc "The whole flyer would have been covered with asses and boobs."

        scene e2s7-22 with dissolve
        jon "Sometimes you know me better than I do myself!"

        scene e2s7-23 with dissolve
        mc "Haha, yeah."
        mc "Hey, catch you later [jon]!"
        mc "I'm gonna go back to my dorm."

        scene e2s7-24 with dissolve
        jon "Alright, see you!"
    else:
        scene e2s7-25 with wipeleft
        play music breathe
        pause

        scene e2s7-02 with dissolve
        unknown "Come on everyone!"
        unknown "Join the best partying group, THE PARTY RAGERS!"

        scene e2s7-03 with dissolve
        unknown "There is a limited amount of people accepted so hurry up and join now."

        scene e2s7-26 with dissolve
        pause

        scene e2s7-45 with dissolve
        unknown "Hey there fellow student!"
        unknown "Would you like a flyer about the coolest party group?"

        scene e2s7-46 with dissolve
        mc "Sure, give me one."

        scene e2s7-10 with dissolve
        unknown "Alright, here it is."

        scene e2s7-46 with dissolve
        mc "Thanks!"

        scene e2s7-11 with dissolve
        pause

        scene e2s7-27 with dissolve
        pause

        scene e2s7-28 with dissolve
        rv "HEY, STOP RIGHT THERE!"
        rv "YOU AREN'T ALLOWED TO DO THAT!"

        scene e2s7-29 with dissolve
        rv "Who gave you permission to hand out these flyers?"
        unknown "Uhh..."

        scene e2s7-30 with dissolve
        mc "*The Party Ragers.*"
        mc "*The best party club in town.*"
        mc "*Learn how to party like there's no tomorrow in this special activity group.*"
        mc "*That's the thing [jon] was telling me about.*"
        mc "*Hmm... pretty interesting.*"

    stop music fadeout 1.0
    scene e2s7-31 with dissolve
    pause

    play sound door_close
    scene e2s7-32 with dissolve
    play music invisible_light
    pause

    scene e2s7-33 with dissolve
    mc "Hey [nt]!"
    mc "What's up?"

    scene e2s7-34 with dissolve
    nt "Hi [mc]!"

    if affinity_spectrum >= 0:
        scene e2s7-35 with dissolve
        mc "Dude... you're going back home?"
        mc "You're gonna miss your first weekend in college."

        scene e2s7-36 with dissolve
        nt "Unfortunately, yeah."
        nt "As much as I want to stay, I really need to go."
    else:
        scene e2s7-33 with dissolve
        mc "You're going back home for the weekend?"

        scene e2s7-36 with dissolve
        nt "Yeah."

    if affinity_spectrum > 0:
        scene e2s7-37 with dissolve
        mc "Damn it, tonight we have another party."
        mc "Too bad you can't attend it."

        scene e2s7-33 with dissolve
        mc "But it's alright bro, take care."
    else:
        scene e2s7-33 with dissolve
        mc "Well, I wanted to let you know that there's another party tonight."

        scene e2s7-36 with dissolve
        nt "As much as I want to stay, I really need to go."

        scene e2s7-33 with dissolve
        mc "It's alright bro, take care."

    scene e2s7-38 with dissolve
    nt "Thanks dude!"
    nt "Have fun then."

    scene e2s7-33 with dissolve
    mc "Thank you!"

    play sound phone_buzz
    scene e2s7-39 with dissolve
    pause

    play sound door_close
    scene e2s7-41 with dissolve
    jon "What's up bro?"

    scene e2s7-40 with dissolve
    mc "Hey [jon]!"

    scene e2s7-41 with dissolve
    jon "Hey, could you meet me at my apartment?"

    scene e2s7-42 with dissolve
    mc "Sure, why?"

    scene e2s7-41 with dissolve
    jon "I need some help with buying the drinks."

    scene e2s7-42 with dissolve
    mc "Wait, wasn't that guy supposed to buy the drinks?"

    scene e2s7-41 with dissolve
    jon "Yeah, we're not gonna rely on that."
    jon "We're gonna bring some special drinks."

    scene e2s7-40 with dissolve
    mc "Are you not gonna apply your magician tricks anymore?"

    scene e2s7-42 with dissolve
    mc "Like you did with the beer?"

    scene e2s7-41 with dissolve
    jon "Haha, no, it doesn't work all the time."
    jon "Although, we're gonna have another trick here."

    scene e2s7-42 with dissolve
    mc "What are you talking about?"

    scene e2s7-41 with dissolve
    jon "We're gonna have them delivered to us in the middle of the party."
    jon "So, if people don't like the standard drinks..."
    jon "We're gonna spike their happiness with good drinks."

    scene e2s7-42 with dissolve
    mc "Alright bro, don't worry!"

    scene e2s7-40 with dissolve
    mc "I'll be there."

    scene e2s7-41 with dissolve
    jon "Alright, see you!"

    scene e2s7-43 with dissolve
    pause

    scene e2s7-44 with wipeleft
    play sound knock_knock
    pause

    play sound door_open
    scene e2s7-47 with dissolve
    jon "So, are you ready to go?"

    scene e2s7-48 with dissolve
    show e2s7-jon_blink1
    mc "Sure dude."

    scene e2s7-49 with dissolve
    hide e2s7-jon_blink1
    jon "After this, we're gonna go and get the guys."

    scene e2s7-48 with dissolve
    show e2s7-jon_blink1
    mc "Alright, let's go then."

    scene e2s7-50 with dissolve
    hide e2s7-jon_blink1
    jon "Give me a second to grab my wallet."

    scene e2s7-48 with dissolve
    show e2s7-jon_blink1

    scene e2s7-51 with wipeleft
    hide e2s7-jon_blink1
    jon "Alright, now that the alcohol problem has been solved."

    scene e2s7-52 with dissolve
    jon "There's just one more thing left to do."

    stop music
    play sound door_open
    scene e2s7-53
    pause

    scene e2s7-54 with dissolve
    pause

    scene e2s7-55 with dissolve
    jon "What the fuck are you guys doing?"
    jon "Stop playing these pussy ass games, let's get going!"

    scene e2s7-56 with dissolve
    ke "Fuck you, [ro]!"
    ke "You don't know how to explain shit."

    scene e2s7-57 with dissolve
    ro "It's not my fault you're bad at this."

    scene e2s7-58 with dissolve
    jd "Guys, come on, stop fighting."
    jd "Let's go and party!"

    scene e2s7-59 with dissolve
    ke "Sure, whatever."
    ke "Like I wanted to play this in the first place."

    if e2s3_hangout == True:
        play sound phone_buzz
        scene e2s7-65 with dissolve
        pause

        nvl clear

        scene e2s7-60 with dissolve
        fr_nvl "Hey [mc]!"
        fr_nvl "Just wanted to know if the date is still on."

        scene e2s7-61 with dissolve
        jon "Come on [mc]!"
        jon "Are you coming?"

        scene e2s7-62 with dissolve
        mc "*Shit!*"
        mc "*I totally forgot about the date.*"

        scene e2s7-63 with dissolve
        mc "Yeah, I'm coming."

        scene e2s7-60 with dissolve
        n_nvl "Sorry [fr], something came up and I won't be able to make it."

    scene e2s7-64 with dissolve
    pause

    jump e2s8
return
