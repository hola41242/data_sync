
# Freeroam 2 - House party rocks ###############################################

# Variables #

default e2f2_scarlett1 = False
default e2f2_ken = 0
default e2f2_jon_jordan = False
default e2f2_tiffany = False
default e2f2_tiffany_drink = 0
default e2f2_tracy = 0
default e2f2_second_part = False
default e2f2_ken_roman = False

default e2f2_money1 = False
default e2f2_money2 = False

default e2f2_explore = 0

# Freeroam Collected Photos #

default persistent.e2f2_collected_p = 0
default persistent.e2f2_collected_tp = 8

################################################################################

# Map ##########################################################################

label e2f2_main:
    if e2f2_second_part == False:
        scene e2f2-main
    else:
        if e2f2_tracy == 2 or e2f2_tracy_sex == True:
            scene e2f2-main_1
        else:
            scene e2f2-main_2
    call screen e2f2_main with dissolve
return

label e2f2_sofa:
    if e2f2_second_part == False:
        scene e2f2-sofa
    else:
        scene e2f2-sofa_1
    call screen e2f2_sofa with dissolve
return

label e2f2_kitchen:
    if e2f2_tiffany_refuse == True or e2f2_tiffany_drink == 3:
        if e2f2_jon_jordan == True and e2f2_ken == 3 and e2f2_scarlett1 == True and e2f2_second_part == False:
            scene e2f2-sp_03 with dissolve
            ke "Hey guys, looks like there's more people joining the party."

            play sound door_close
            scene e2f2-sp_01 with dissolve
            unknown "What's going on everybody?"

            scene e2f2-sp_02 with dissolve
            unknown "Who's ready to partyyy!"

            scene e2f2-sp_04 with dissolve
            ro "Guys, there's no more drinks!"

            scene e2f2-sp_05 with dissolve
            ro "Where are the drinks, bro?"
            ro "Things are starting to get out of hand."

            scene e2f2-sp_06 with dissolve
            jon "Relax dude, they should be here any minute now."

            scene e2f2-sp_07 with dissolve
            mc "What's going on guys?"

            scene e2f2-sp_08 with dissolve
            ro "The drinks aren't enough for everyone in here."
            ro "They were quickly finished and now people are demanding alcohol."

            scene e2f2-sp_09 with dissolve
            mc "That's fine then, me and [jon] took care of that."

            $ current_quests.remove("Go to the kitchen.")
            $ current_quests.append("Interact with people.")

            $ e2f2_explore = 0
            $ e2f2_second_part = True

            scene e2f2-sp_10 with dissolve
            ro "Let's hope that they get here in time..."

    if e2f2_second_part == False:
        scene e2f2-kitchen
    else:
        scene e2f2-kitchen_1
    call screen e2f2_kitchen with dissolve
return

label e2f2_hallway:
    if e2f2_tiffany == False:
        scene e2f2-tf_01 with dissolve
        unknown "Hey, you!"

        scene e2f2-tf_02 with dissolve
        mc "Me?"

        scene e2f2-tf_04 with dissolve
        unknown "Yeah, you!"

        scene e2f2-tf_07 with dissolve
        unknown "Could you get me a drink, please?"

        scene e2f2-tf_03 with dissolve
        show e2f2-tf_tiffany_blink1
        menu:
            "Accept":
                mc "Sure, what would you like?"

                scene e2f2-tf_04 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "Just a cocktail, please!"

                scene e2f2-tf_03 with dissolve
                show e2f2-tf_tiffany_blink1
                mc "Alright, be right back."

                scene e2f2-tf_09 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "Thank you!"

                $ current_quests.append("Get a drink for the girl.")

                $ e2f2_tiffany_drink = 1

                scene e2f2-tf_03 with dissolve
                show e2f2-tf_tiffany_blink1
                mc "Don't mention it."

            "Refuse":
                mc "Sorry, I'm not interested."

                scene e2f2-tf_08 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "Come on dude, it's just a drink."

                scene e2f2-tf_03 with dissolve
                show e2f2-tf_tiffany_blink1
                mc "I've already said no, leave me alone."

                scene e2f2-tf_10 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "Fine, you're no fun."

                $ e2f2_explore += 1

                if e2f2_explore == 4:
                    $ current_quests.remove("Interact with people.")
                    $ current_quests.append("Go to the kitchen.")

                $ e2f2_tiffany_refuse = True

                scene e2f2-tf_11 with dissolve
                mc "*Damn, I wonder who invited this one.*"

            "Get a drink herself":
                mc "Can't you get one yourself?"

                scene e2f2-tf_06 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "No!"

                scene e2f2-tf_05 with dissolve
                unknown "I mean..."

                scene e2f2-tf_04 with dissolve
                unknown "Yeah, I can get one myself."

                scene e2f2-tf_07 with dissolve
                unknown "Just wanted to hit on you."

                scene e2f2-tf_03 with dissolve
                show e2f2-tf_tiffany_blink1
                mc "Oh, alright?"

                scene e2f2-tf_04 with dissolve
                hide e2f2-tf_tiffany_blink1
                unknown "So, what do you say?"

                scene e2f2-tf_07 with dissolve
                unknown "Would you get me one?"

                scene e2f2-tf_03 with dissolve
                show e2f2-tf_tiffany_blink1
                menu:
                    "Accept":
                        mc "Sure, what would you like?"

                        scene e2f2-tf_04 with dissolve
                        hide e2f2-tf_tiffany_blink1
                        unknown "Just a cocktail, please!"

                        scene e2f2-tf_03 with dissolve
                        show e2f2-tf_tiffany_blink1
                        mc "Alright, be right back."

                        scene e2f2-tf_09 with dissolve
                        hide e2f2-tf_tiffany_blink1
                        unknown "Thank you!"

                        $ current_quests.append("Get a drink for the girl.")

                        $ e2f2_tiffany_drink = 1

                        scene e2f2-tf_03 with dissolve
                        show e2f2-tf_tiffany_blink1
                        mc "Don't mention it."

                    "Refuse":
                        mc "Sorry, I'm not interested."

                        scene e2f2-tf_08 with dissolve
                        hide e2f2-tf_tiffany_blink1
                        unknown "Come on dude, it's just a drink."

                        scene e2f2-tf_03 with dissolve
                        show e2f2-tf_tiffany_blink1
                        mc "I've already said no, leave me alone."

                        scene e2f2-tf_10 with dissolve
                        hide e2f2-tf_tiffany_blink1
                        unknown "Fine, you're no fun."

                        $ e2f2_explore += 1

                        if e2f2_explore == 4:
                            $ current_quests.remove("Interact with people.")
                            $ current_quests.append("Go to the kitchen.")

                        $ e2f2_tiffany_refuse = True

                        scene e2f2-tf_11 with dissolve
                        mc "*Damn, I wonder who invited this one.*"

    $ e2f2_tiffany = True

    if e2f2_tiffany_drink == 3 or e2f2_ken == 3 and e2f2_tiffany_refuse == True:
        if e2f2_second_part == False:
            scene e2f2-hallway_1
        else:
            if e2f2_tracy == 1:
                scene e2f2-tr1_01 with dissolve
                pause

                play sound door_close
                scene e2f2-tr1_02 with dissolve
                mc "Hey [tr]!"
                mc "You came back."

                scene e2f2-tr1_03 with dissolve
                tr "Yeah, I did."

                scene e2f2-tr1_04 with dissolve
                tr "Unfortunately, I couldn't convince [sd] to do the same thing."

                scene e2f2-tr1_02 with dissolve
                mc "I understand."

                scene e2f2-tr1_06 with dissolve
                tr "Well, we're at a party, so shall we have some fun?"

                scene e2f2-tr1_05 with dissolve
                mc "Haha, damn right we should!"

                $ e2f2_tracy = 2

            if e2f2_ken_roman == False:
                scene e2f2-hallway_2
            else:
                if affinity_spectrum > 0:
                    if e2f2_tracy > 2:
                        play sound ding_dong
                else:
                    play sound ding_dong
                scene e2f2-hallway_1
    else:
        scene e2f2-hallway
    call screen e2f2_hallway with dissolve
return

label e2f2_bedroom:
    if e2f2_tracy == 3:
        scene e2f2-bedroom_1
    else:
        scene e2f2-bedroom
    call screen e2f2_bedroom with dissolve
return

label e2f2_drawer:
    scene e2f2-drawer
    call screen e2f2_drawer with dissolve
return

label e2f2_bathroom:
    scene e2f2-bathroom
    call screen e2f2_bathroom with dissolve
return

# Clickables ###################################################################

# Main #*

label e2f2_tracy:
    scene e2f2-tr2_01 with dissolve
    mc "Hey [tr], having fun?"

    scene e2f2-tr2_02 with dissolve
    tr "Haha, come here [mc]!"

    scene e2f2-tr2_03 with dissolve
    pause

    scene e2f2-tr2_04 with dissolve
    pause

    scene e2f2-tr2_05 with dissolve
    pause

    scene e2f2-tr2_06 with dissolve
    pause

    scene e2f2-tr2_07 with dissolve
    pause

    scene e2f2-tr2_08 with dissolve
    pause

    if tracy_trust > 2:
        menu:
            "Kiss her":
                $ tracy_trust += 1
                scene e2f2-tr2_10 with dissolve
                pause

                scene e2f2-tr2_09 with dissolve
                pause

                scene e2f2-tr2_11 with dissolve
                tr "Damn, naughty aren't you?"

                scene e2f2-tr2_09 with dissolve
                mc "Couldn't resist such an ass."

                scene e2f2-tr2_10 with dissolve
                pause

            "Don't kiss her":
                pass

    scene e2f2-tr2_03 with dissolve
    pause

    scene e2f2-tr2_12 with dissolve
    pause

    scene e2f2-tr2_05 with dissolve
    pause

    scene e2f2-tr2_04 with dissolve
    pause

    scene e2f2-tr2_13 with dissolve
    pause

    scene e2f2-tr2_14 with dissolve
    tr "Didn't think you were such a dancer [mc]."

    scene e2f2-tr2_15 with dissolve
    mc "Haha, I wouldn't call myself a dancer..."
    mc "But it's nothing a little alcohol can't fix."

    scene e2f2-tr2_14 with dissolve
    tr "Haha!"

    scene e2f2-tr2_16 with dissolve
    tr "Speaking of alcohol, would you like to have a drink?"

    scene e2f2-tr2_17 with dissolve
    menu:
        "Drink with her":
            $ tracy_trust += 1
            mc "Sure!"
            mc "Although, I've gotta warn you, they aren't that good."

            scene e2f2-tr2_18 with dissolve
            tr "We'll find something."

            scene e2f2-tr2_17 with dissolve
            jon "Greetings people of the night!"

            scene e2f2-tr2_21 with dissolve
            jon "Perhaps, I could serve you a drink...?"

            scene e2f2-tr2_22 with dissolve
            mc "Hey [jon]!"
            mc "Haha, where'd you get that apron from?"

            scene e2f2-tr2_23 with dissolve
            jon "It was just lying around here."

            scene e2f2-tr2_21 with dissolve
            jon "So, what would you like?"

            scene e2f2-tr2_22 with dissolve
            mc "Is there something half decent here?"

            scene e2f2-tr2_24 with dissolve
            jon "Oh, don't you guys worry, I'm gonna serve you my specialty!"

            scene e2f2-tr2_25 with dissolve
            jon "Be right back humans."

            scene e2f2-tr2_16 with dissolve
            tr "Haha, what's gotten into him?"

            scene e2f2-tr2_17 with dissolve
            mc "I have no idea."

            scene e2f2-tr2_26 with dissolve
            jon "Here mortals, drink this!"

            scene e2f2-tr2_27 with dissolve
            jon "You won't find anything remotely close to this."

            scene e2f2-tr2_28 with dissolve
            tr "Uh... wow!"

            scene e2f2-tr2_22 with dissolve
            mc "Damn dude, you're completely right!"
            mc "I don't think we'll ever find something even remotely close to how bad this is."

            scene e2f2-tr2_29 with dissolve
            tr "I thought I was the only one!"

            scene e2f2-tr2_30 with dissolve
            tr "Didn't want to be rude."

            scene e2f2-tr2_31 with dissolve
            jon "You don't like it?"

            scene e2f2-tr2_32 with dissolve
            mc "Dude, what did you even put in it?"

            scene e2f2-tr2_33 with dissolve
            jon "Who thought that bad drinks could also result in bad combinations."

            scene e2f2-tr2_34 with dissolve
            jon "Sorry guys, it's either this or the other crap this guy has in stock."

            scene e2f2-tr2_32 with dissolve
            mc "We're gonna drink this, it's fine."

            scene e2f2-tr2_23 with dissolve
            jon "Alright, if you need anything else, you know who to call!"

            scene e2f2-tr2_25 with dissolve
            pause

            scene e2f2-tr2_20 with dissolve
            mc "I'm honestly curious, didn't he take a sip of whatever he cooked in there?"

            scene e2f2-tr2_16 with dissolve
            tr "Haha, I don't know."
            tr "Even if he did, you've heard him, there isn't any other option."

            scene e2f2-tr2_17 with dissolve
            mc "Yeah..."

            if tracy_trust > 3:
                $ e2f2_tracy = 3
                scene e2f2-tr2_14 with dissolve
                tr "Hey [mc]!"
                tr "Do you wanna have something good tonight?"

                scene e2f2-tr2_15 with dissolve
                mc "What do you mean?"

                scene e2f2-tr2_35 with dissolve
                tr "Well, certainly, these drinks aren't gonna cut it."
                tr "They're pretty bad."

                scene e2f2-tr2_14 with dissolve
                tr "So, if you want something truly good, I'll be waiting for you in the bedroom."

                scene e2f2-tr2_15 with dissolve
                mc "Me, you and a bedroom?"
                mc "That's something that won't ever go bad."

                scene e2f2-tr2_14 with dissolve
                tr "Haha, think about my offer, okay?"

                $ optional_quests.append("Follow Tracy to the bedroom.")

                scene e2f2-tr2_15 with dissolve
                mc "Sure thing."

            else:
                $ e2f2_tracy = 4
                scene e2f2-tr2_18 with dissolve
                tr "I've gotta use the restroom."

                scene e2f2-tr2_16 with dissolve
                tr "I'll see you around [mc]!"

                scene e2f2-tr2_36 with dissolve
                pause

        "Don't drink with her":
            $ tracy_trust -= 1
            mc "I'm good, thanks!"

            scene e2f2-tr2_19 with dissolve
            tr "Oh, alright."
            tr "I'm gonna have a drink alone then."

            scene e2f2-tr2_20 with dissolve
            mc "Well, I've gotta warn you, they aren't that good."

            $ e2f2_explore += 1

            if e2f2_explore == 2:
                $ current_quests.remove("Interact with people.")
                $ current_quests.append("Answer the front door.")

            scene e2f2-tr2_16 with dissolve
            tr "Haha, I'll find something, don't worry."

            $ e2f2_tracy = 4

            jump e2f2_main

    $ e2f2_explore += 1

    if e2f2_explore == 2:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Answer the front door.")

    if e2f2_second_part == False:
        scene e2f2-main with Dissolve(0.5)
    else:
        if e2f2_tracy == 2 or e2f2_tracy_sex == True:
            scene e2f2-main_1 with Dissolve(0.5)
        else:
            scene e2f2-main_2 with Dissolve(0.5)

    jump e2f2_main
return

# Sofa #

# Kitchen #

label e2f2_scarlett1:
    scene e2f2-sc_01 with dissolve
    mc "Hey!"

    scene e2f2-sc_02 with dissolve
    show e2f2-sc_scarlett_blink1
    sc "Hm?"
    menu:
        "Flirty approach" if affinity_spectrum > 0:
            call extrovert_affinity_check from _call_extrovert_affinity_check_25
            call color_check from _call_color_check_49
            mc "I was going to ask you about a wi-fi signal, but looks like there's a strong connection over here."

            scene e2f2-sc_06 with dissolve
            hide e2f2-sc_scarlett_blink1
            sc "That's so lame."

            scene e2f2-sc_04 with dissolve
            sc "Keep moving virgin."

        "Friendly approach":
            call introvert_affinity_check from _call_introvert_affinity_check_21
            call color_check from _call_color_check_50
            mc "What's up?"

            scene e2f2-sc_03 with dissolve
            hide e2f2-sc_scarlett_blink1
            sc "Are you talking to me?"

            scene e2f2-sc_02 with dissolve
            show e2f2-sc_scarlett_blink1
            mc "Uhh... yeah?"
            mc "Who else would I be talking to?"

            scene e2f2-sc_05 with dissolve
            hide e2f2-sc_scarlett_blink1
            sc "There's a lot of people around here."

            scene e2f2-sc_02 with dissolve
            show e2f2-sc_scarlett_blink1
            mc "Yet you're the only one that caught my attention."

            scene e2f2-sc_06 with dissolve
            hide e2f2-sc_scarlett_blink1
            sc "Haha, keep moving virgin."

    scene e2f2-sc_09 with dissolve
    sc "I'm not interested."

    scene e2f2-sc_01 with dissolve
    mc "At least my body count isn't in triple digits."

    scene e2f2-sc_07 with dissolve
    sc "You didn't deny it though."

    scene e2f2-sc_12 with dissolve
    show e2f2-sc_scarlett_blink1
    mc "You didn't either."

    scene e2f2-sc_06 with dissolve
    sc "Heh, you're kinda fun."

    scene e2f2-sc_09 with dissolve
    sc "Unfortunately, I'm still not interested."

    scene e2f2-sc_08 with dissolve
    sc "You can leave now, I've had my fun."

    scene e2f2-sc_09 with dissolve
    sc "Bye!"

    $ e2f2_scarlett1 = True

    $ e2f2_explore += 1

    if e2f2_explore == 4:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Go to the kitchen.")

    if affinity_spectrum > 0:
        scene e2f2-sc_11 with dissolve
        mc "*What a bitch.*"
    else:
        scene e2f2-sc_10 with dissolve
        mc "*Damn she's annoying.*"

    scene e2f2-kitchen
    call screen e2f2_kitchen with dissolve
return

label e2f2_jon_jordan:
    scene e2f2-jj_01 with dissolve
    jon "Now... let's see what's going on here..."

    scene e2f2-jj_02 with dissolve
    mc "Hey guys, what's up?"

    scene e2f2-jj_07 with dissolve
    jon "Hey [mc]!"

    scene e2f2-jj_04 with dissolve
    jon "We're trying to find some drinks."

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "I see."

    scene e2f2-jj_05 with dissolve
    hide e2f2-jj_jordan_blink1
    jd "Honestly, the drinks that we've found were so shit... I almost threw up."

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    if e2f2_ken == 1:
        mc "Haha, that's what [ke] told me."

        scene e2f2-jj_05 with dissolve
        hide e2f2-jj_jordan_blink1
        jd "Well, he's right."
        jd "We shouldn't have let him buy the drinks."
    else:
        mc "Really?"

        scene e2f2-jj_05 with dissolve
        hide e2f2-jj_jordan_blink1
        jd "Yeah, we shouldn't have let him buy the drinks."

    scene e2f2-jj_07 with dissolve
    jon "Relax guys, I'm gonna make a bomb drink."

    scene e2f2-jj_06 with dissolve
    jd "Do you even have the right drinks?"

    scene e2f2-jj_08 with dissolve
    jon "No..."

    scene e2f2-jj_07 with dissolve
    jon "...but I'll improvise!"

    scene e2f2-jj_04 with dissolve
    jon "Trust me, this will be 1000 times better than the drinks from here."

    scene e2f2-jj_06 with dissolve
    jd "If you say so..."

    scene e2f2-jj_08 with dissolve
    jon "Hey [mc]..."
    if e2f2_ken == 1:
        $ e2f2_ken = 2
        jon "If you come across [ke] again, could you tell him to come to the kitchen and help me?"
    else:
        jon "If you come across [ke], could you tell him to come to the kitchen and help me?"
    jon "I need his taste expertise here."

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "Sure, no problem."

    $ e2f2_jon_jordan = True

    $ e2f2_explore += 1

    $ current_quests.append("Ask Ken to join Jon in the kitchen.")

    scene e2f2-jj_04 with dissolve
    hide e2f2-jj_jordan_blink1
    jon "Alright then, let's start cooking!"

    jump e2f2_kitchen
return

label e2f2_tiffany_drink:
    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "Hey guys, what's up?"

    scene e2f2-jj_07 with dissolve
    hide e2f2-jj_jordan_blink1
    jon "Hey [mc]."

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "Could you help me with a drink?"

    scene e2f2-jj_07 with dissolve
    hide e2f2-jj_jordan_blink1
    jon "You've come to the right place, my friend."

    scene e2f2-jj_05 with dissolve
    jd "Tell us, what do you need?"

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "Just a cocktail please."

    scene e2f2-jj_07 with dissolve
    hide e2f2-jj_jordan_blink1
    jon "Don't worry, I'll make it fast."

    scene e2f2-jj_04 with dissolve
    jon "Hey, also, did you talk to [ke]?"

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    if e2f2_ken == 3:
        mc "Yeah, I did."
        mc "He's keeping the bathroom door closed for [ro]."
        mc "Heard the door's lock doesn't work."
    else:
        mc "No, not yet."
        mc "After you prepare this drink, I'll be on my way to speak to him."

    scene e2f2-jj_04 with dissolve
    hide e2f2-jj_jordan_blink1
    jon "Alright, no worries."

    scene e2f2-tf_56 with dissolve
    jon "Well, here's your drink [mc]!"

    scene e2f2-tf_57 with dissolve
    mc "Thanks, I owe you one."

    scene e2f2-jj_03 with dissolve
    show e2f2-jj_jordan_blink1
    mc "Good luck with your drinks."

    $ current_quests.remove("Get a drink for the girl.")
    $ current_quests.append("Give the drink to the girl.")

    $ e2f2_tiffany_drink = 2

    scene e2f2-jj_05 with dissolve
    hide e2f2-jj_jordan_blink1
    jd "Thanks!"

    jump e2f2_kitchen
return

# Hallway #

label e2f2_ken:
    if e2f2_ken == 0:
        scene e2f2-ke_01 with dissolve
        show e2f2-ke_ken_blink1
        mc "Hey bro, what's up?"
        mc "Waiting in line?"

        scene e2f2-ke_02 with dissolve
        hide e2f2-ke_ken_blink1
        ke "No, not really."

        scene e2f2-ke_03 with dissolve
        ke "The bathroom door has no lock and [ro]'s inside."

        scene e2f2-ke_02 with dissolve
        ke "He asked me to keep the door closed for him."

        scene e2f2-ke_01 with dissolve
        show e2f2-ke_ken_blink1
        mc "Oh, I understand."

        scene e2f2-ke_02 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Yeah."

        scene e2f2-ke_03 with dissolve
        ke "What's up with you?"

        scene e2f2-ke_04 with dissolve
        ke "Are you waiting in line?"

        scene e2f2-ke_05 with dissolve
        show e2f2-ke_ken_blink1
        mc "Haha, no!"
        mc "Just came to see what's up."

        if affinity_spectrum > 0:
            scene e2f2-ke_06 with dissolve
            hide e2f2-ke_ken_blink1
            ke "Oh, that's too bad."
            ke "I would have let you pass."

            scene e2f2-ke_05 with dissolve
            show e2f2-ke_ken_blink1
            mc "Haha, [ro] wouldn't have been happy about it."

            scene e2f2-ke_07 with dissolve
            hide e2f2-ke_ken_blink1
            ke "That would be a good prank if I think about it..."
            ke "Anyways..."

        if e2f2_jon_jordan == True:
            scene e2f2-ke_01 with dissolve
            show e2f2-ke_ken_blink1
            mc "Hey, also, [jon] needs your help in the kitchen."
            mc "He said he needs your taste expertise."
            mc "Whatever that means..."

            scene e2f2-ke_06 with dissolve
            hide e2f2-ke_ken_blink1
            ke "Haha, alright, no worries."

            scene e2f2-ke_04 with dissolve
            ke "When [ro] gets out, I'll go and help him."

            scene e2f2-ke_05 with dissolve
            show e2f2-ke_ken_blink1
            mc "Okay."

            $ current_quests.remove("Ask Ken to join Jon in the kitchen.")

        scene e2f2-ke_03 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Have you drunk anything tonight?"

        scene e2f2-ke_01 with dissolve
        show e2f2-ke_ken_blink1
        mc "Nope, not yet."
        mc "We just got here, there's still time."
        mc "Have you?"

        scene e2f2-ke_02 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Yeah, and it's shit."

        scene e2f2-ke_03 with dissolve
        ke "This guy has the shittiest cheapest drinks someone could buy."
        ke "I tried one and almost threw up."

        scene e2f2-ke_01 with dissolve
        show e2f2-ke_ken_blink1
        mc "Is that the reason [ro]'s in the bathroom?"

        scene e2f2-ke_07 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Could be... but no."

        scene e2f2-ke_04 with dissolve
        ke "He's taking a shit."

        scene e2f2-ke_08 with dissolve
        ro "Come on bro!"
        ro "Not so loud..."

        scene e2f2-ke_09 with dissolve
        ke "Oh, come on bro..."

        scene e2f2-ke_10 with dissolve
        ke "Nobody can hear {b}that you're taking a shit{/b}!"

        scene e2f2-ke_05 with dissolve
        show e2f2-ke_ken_blink1
        ro "Sigh..."
        mc "Haha, yeah!"
        mc "Hey, I'm gonna go see what people are up to."
        mc "See you later!"

        if e2f2_jon_jordan == True:
            $ e2f2_ken = 3
        else:
            $ e2f2_ken = 1

        $ e2f2_explore += 1

        if e2f2_explore == 4:
            $ current_quests.remove("Interact with people.")
            $ current_quests.append("Go to the kitchen.")

        scene e2f2-ke_06 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Alright, see you!"

    if e2f2_ken == 2:
        scene e2f2-ke_05 with dissolve
        show e2f2-ke_ken_blink1
        mc "Hey [ke]!"

        scene e2f2-ke_06 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Sup [mc]!"

        scene e2f2-ke_05 with dissolve
        show e2f2-ke_ken_blink1
        mc "[jon] asked me to tell you that he needs your expertise in the kitchen."

        scene e2f2-ke_06 with dissolve
        hide e2f2-ke_ken_blink1
        ke "Alright, no worries."

        scene e2f2-ke_04 with dissolve
        ke "Right after [ro] finishes up, I'll go and help him."

        $ current_quests.remove("Ask Ken to join Jon in the kitchen.")

        $ e2f2_ken = 3

        scene e2f2-ke_05 with dissolve
        show e2f2-ke_ken_blink1
        mc "Okay, great!"

    jump e2f2_hallway
return

label e2f2_tiffany:
    scene e2f2-tf_12 with dissolve
    mc "Hey, here's your drink!"

    scene e2f2-tf_13 with dissolve
    unknown "Yoo, thank you!"

    scene e2f2-tf_14 with dissolve
    mc "So, what's up?"

    scene e2f2-tf_16 with dissolve
    unknown "Nothing much, just enjoying the party."

    scene e2f2-tf_17 with dissolve
    unknown "Didn't you get a drink?"

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Well, I didn't think about getting one."

    scene e2f2-tf_18 with dissolve
    hide e2f2-tf_tiffany_blink2
    unknown "Here, take a sip from mine."

    scene e2f2-tf_19 with dissolve
    menu:
        "Drink from her":
            $ tiffany_trust += 1

            scene e2f2-tf_20 with dissolve
            pause

            scene e2f2-tf_19 with dissolve
            mc "Hey, this is actually pretty good!"

            scene e2f2-tf_21 with dissolve
            unknown "I know, right?"

            scene e2f2-tf_17 with dissolve
            unknown "Be careful though, it's very deceiving."

            scene e2f2-tf_16 with dissolve
            unknown "While it might seem sweet and all, it can get you very drunk fast."

            scene e2f2-tf_15 with dissolve
            show e2f2-tf_tiffany_blink2
            mc "Thanks for the heads up!"

            scene e2f2-tf_21 with dissolve
            hide e2f2-tf_tiffany_blink2
            unknown "You're welcome!"

            scene e2f2-tf_15 with dissolve
            show e2f2-tf_tiffany_blink2
            pause

        "Don't drink":
            mc "I'm good, thanks."

            scene e2f2-tf_17 with dissolve
            unknown "Your loss."

            scene e2f2-tf_14 with dissolve
            pause

    scene e2f2-tf_22 with dissolve
    unknown "[tf]."
    tf "My name's [tf]."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Cool, I'm [mc]!"

    scene e2f2-tf_24 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "So, how did you end up at this house party, [mc]?"

    scene e2f2-tf_25 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Haha, I could ask you the same thing!"
    mc "We have this friend [ro] who's almost always missing our parties."
    mc "He wanted to make it up to us by asking his friend to hold a house party."
    mc "Which is [no] in this case."

    scene e2f2-tf_21 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "Haha, that's pretty funny!"

    scene e2f2-tf_24 with dissolve
    tf "What's funnier is that I don't even know anyone from here."

    scene e2f2-tf_16 with dissolve
    tf "I think [no] posted about this party on the college wall."

    scene e2f2-tf_17 with dissolve
    tf "At least that's where I heard about it."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "That's interesting."
    mc "Why aren't there more people if he posted about it?"

    scene e2f2-tf_16 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "I think we're just early to the party."

    scene e2f2-tf_22 with dissolve
    tf "Perhaps more people will show up later."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Yeah, let's hope so."

    scene e2f2-tf_16 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "Honestly, most of the food and drinks from tonight are horrible."
    tf "God, this guy is a rookie."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Haha, even the food?"

    scene e2f2-tf_17 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "Yeah."

    scene e2f2-tf_22 with dissolve
    tf "What's even crazier is that we're talking about pizza here."

    scene e2f2-tf_23 with dissolve
    tf "I didn't know you could mess up pizza this bad because yeah, it's pizza..."

    scene e2f2-tf_17 with dissolve
    tf "But there we go, he did it."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "I've seen a couple of slices in the kitchen."

    scene e2f2-tf_16 with dissolve
    tf "Yeah, only a few people tried the pizza and didn't like it."

    scene e2f2-tf_22 with dissolve
    tf "A couple of them ate it because they were really hungry."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Now I probably understand why more people haven't showed up."

    scene e2f2-tf_16 with dissolve
    hide e2f2-tf_tiffany_blink2
    tf "People don't really care that much about food or drinks, they just wanna have a good time."

    scene e2f2-tf_24 with dissolve
    tf "Some of them would drink anything."

    scene e2f2-tf_25 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Haha, true that!"

    scene e2f2-tf_24 with dissolve
    tf "Hey, wanna go outside?"

    scene e2f2-tf_23 with dissolve
    tf "It's getting hot in here and I like to enjoy my drinks under the moonlight."

    scene e2f2-tf_15 with dissolve
    show e2f2-tf_tiffany_blink2
    mc "Sure, let's go!"

    scene e2f2-tf_26 with dissolve
    hide e2f2-tf_tiffany_blink2
    pause

    scene e2f2-tf_27 with wipeleft
    tf "And then she said, 'How do you make them last an hour?'"

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "No... you can't be for real..."
    mc "Did she really ask that?"

    scene e2f2-tf_29 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Haha, yeah!"

    scene e2f2-tf_30 with dissolve
    tf "The whole class was shocked."

    scene e2f2-tf_31 with dissolve
    tf "Not even the teacher expected the lesson to turn into a joke."

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Your class was wild."

    scene e2f2-tf_30 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "So that's why, [mc], you'd need to drop out of college."

    scene e2f2-tf_31 with dissolve
    tf "Because of that less than an hour of pleasure that could get you pregnant."

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Wait, how would I get pregnant?"

    scene e2f2-tf_31 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "No, silly!"

    scene e2f2-tf_29 with dissolve
    tf "Haha, stop!"
    tf "You're fucking with me."

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "No but that's actually a pretty valid and rational question."

    scene e2f2-tf_31 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Just shut up."

    scene e2f2-tf_32 with dissolve
    tf "Where have you been all this time?"

    scene e2f2-tf_33 with dissolve
    tf "I'm gonna be honest, I was pretty shy when I got here."

    scene e2f2-tf_35 with dissolve
    tf "I couldn't just go in the kitchen with everyone there and get a drink like that."

    scene e2f2-tf_32 with dissolve
    tf "You seemed easygoing, which is why I asked."
    tf "You're so fun to hang out with I can't believe we didn't meet earlier."

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Haha, I'm not from here, I just came here for college."

    scene e2f2-tf_34 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Ah, that explains it!"

    scene e2f2-tf_36 with dissolve
    tf "Looks like my drink is finished."

    scene e2f2-tf_37 with dissolve
    tf "Damn, it's hot tonight."

    scene e2f2-tf_38 with dissolve
    show e2f2-tf_tiffany_blink4
    mc "It's pretty warm."

    scene e2f2-tf_39 with dissolve
    hide e2f2-tf_tiffany_blink4
    tf "Warm?"

    scene e2f2-tf_37 with dissolve
    tf "This is honestly one of the hottest nights this year."

    scene e2f2-tf_38 with dissolve
    show e2f2-tf_tiffany_blink4
    mc "Are you sure it's not the alcohol in you speaking?"

    scene e2f2-tf_40 with dissolve
    hide e2f2-tf_tiffany_blink4
    tf "Haha, nah!"

    scene e2f2-tf_34 with dissolve
    tf "I don't really get drunk that easily."

    if affinity_spectrum > 0 and tiffany_trust >= 1:
        scene e2f2-tf_41 with dissolve
        tf "On another note, I've got a pretty crazy idea if you're interested."

        scene e2f2-tf_28 with dissolve
        show e2f2-tf_tiffany_blink3
        mc "I'm all ears."

        scene e2f2-tf_30 with dissolve
        hide e2f2-tf_tiffany_blink3
        tf "I know you've basically eyeballed my tits all night."

        scene e2f2-tf_31 with dissolve
        tf "Don't try to play it down, girls notice it."

        scene e2f2-tf_32 with dissolve
        tf "So... to repay the favor..."
        tf "How about you and me, go into the bathroom and cool down a bit?"

        scene e2f2-tf_28 with dissolve
        show e2f2-tf_tiffany_blink3
        menu:
            "Go with her":
                $ tiffany_trust += 1
                $ e2f2_tiffany_sex = True
                $ e2f2_tiffany_drink = 3

                $ current_quests.remove("Give the drink to the girl.")

                $ e2f2_explore += 1

                if e2f2_explore == 4:
                    $ current_quests.remove("Interact with people.")
                    $ current_quests.append("Go to the kitchen.")

                call e2f2_tiffany_sex from _call_e2f2_tiffany_sex

                jump e2f2_bathroom
            "Turn her down":
                mc "You know, that sounds pretty good and all..."
                mc "But I'm not really interested."
                mc "I'm sorry!"

                scene e2f2-tf_32 with dissolve
                hide e2f2-tf_tiffany_blink3
                tf "Haha, relax, I can take no for an answer."

                scene e2f2-tf_36 with dissolve
                tf "This is my number, if you want to stay in touch."
    else:
        scene e2f2-tf_36 with dissolve
        tf "Anyways, this is my number, in case you want to stay in touch."

    scene e2f2-tf_38 with dissolve
    show e2f2-tf_tiffany_blink4
    mc "Wait, you're leaving already?"

    scene e2f2-tf_37 with dissolve
    hide e2f2-tf_tiffany_blink4
    tf "Yeah, it doesn't look like any more people will show up."

    scene e2f2-tf_32 with dissolve
    tf "Plus that I've hit my goal for this night, talk to a cute guy."
    tf "I've also had a drink, better end it on a high note, right?"

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Oh, that's a bummer."
    mc "Alright then, it was nice meeting you [tf]!"

    scene e2f2-tf_34 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Thanks for the drink [mc]!"

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Don't mention it."

    scene e2f2-tf_30 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "I'll be seeing you around... bye!"

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Bye [tf]!"

    $ e2f2_explore += 1

    if e2f2_explore == 4:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Go to the kitchen.")

    $ current_quests.remove("Give the drink to the girl.")

    $ e2f2_tiffany_drink = 3

    scene e2f2-tf_42 with dissolve
    hide e2f2-tf_tiffany_blink3
    pause

    jump e2f2_hallway
return

label e2f2_tiffany_sex:
    if not _in_replay:
        pass
    else:
        scene e2f2-tf_28 with dissolve
        show e2f2-tf_tiffany_blink3
    mc "I couldn't say no to that!"

    scene e2f2-tf_40 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Haha, awesome!"

    scene e2f2-tf_32 with dissolve
    tf "This drink has really made me horny."

    scene e2f2-tf_28 with dissolve
    show e2f2-tf_tiffany_blink3
    mc "Tell me about it."
    mc "I've been trying to hide my boner for a while now."

    stop music fadeout 2.0
    scene e2f2-tf_41 with dissolve
    hide e2f2-tf_tiffany_blink3
    tf "Good thing I'm here then, eh?"

    play music heartache
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e2f2-tf_43 with wipeleft
            tf "Tell me, how does this feel?"

            scene e2f2-tf-handjob1 with dissolve
            mc "It feels pretty good, [tf]."
            mc "Keep going."

            scene e2f2-tf-handjob2 with dissolve
            pause
            tf "I'm sorry if I'm a little rough."
            tf "I'm starting to feel a bit dizzy."
            mc "Don't worry, it feels great."

            scene e2f2-tf-handjob1 with dissolve
            pause

            scene e2f2-tf-handjob2 with dissolve
            pause

            scene e2f2-tf-blowjob1 with dissolve
            mc "Ahh, fuck!"
            mc "It feels really good [tf]."

            scene e2f2-tf-blowjob2 with dissolve
            pause

            scene e2f2-tf-blowjob3 with dissolve
            pause

            scene e2f2-tf-blowjob4 with dissolve
            pause

            scene e2f2-tf-blowjob1 with dissolve
            pause

            scene e2f2-tf-blowjob2 with dissolve
            pause

            scene e2f2-tf_43 with dissolve
            tf "Maybe this will make you feel better."

            scene e2f2-tf_44 with dissolve
            mc "*God, her tits are so hot.*"

            scene e2f2-tf-handjob4 with dissolve
            tf "Do you like it when I go faster?"

            scene e2f2-tf-handjob3 with dissolve
            mc "Damn... yeah, I do!"

            scene e2f2-tf-handjob4 with dissolve
            pause

            scene e2f2-tf-handjob3 with dissolve
            pause

            scene e2f2-tf_45 with dissolve
            tf "Tell me when you want to cum, alright [mc]?"

            scene e2f2-tf-handjob4 with dissolve
            mc "Yeah [tf]."

            $ GameRunning = True

            while GameRunning:
                menu:
                    "Cum":
                        $ GameRunning = False

                        scene e2f2-tf-handjob3 with dissolve
                        mc "Hey [tf], I'm about to cum."

                        scene e2f2-tf-handjob4 with dissolve
                        mc "Ahh, fuck [tf]!"
                        tf "Cum on my tits, [mc]."

                        show white with Dissolve(0.25)
                        scene e2f2-tf_46
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e2f2-tf_47 with dissolve
                        mc "Holy shit, that felt great!"
                        tf "I'm glad you enjoyed it."
                        tf "I liked it too."
                        mc "Thank you [tf]!"
                        tf "You're welcome [mc]."
                        tf "Let me get cleaned up."
                    "Keep going":
                        scene e2f2-tf-handjob1 with dissolve
                        pause

                        scene e2f2-tf-handjob2 with dissolve
                        pause

                        scene e2f2-tf-blowjob1 with dissolve
                        mc "Ahh, fuck!"
                        mc "It feels really good [tf]."

                        scene e2f2-tf-blowjob2 with dissolve
                        pause

                        scene e2f2-tf-blowjob3 with dissolve
                        pause

                        scene e2f2-tf-blowjob4 with dissolve
                        pause

                        scene e2f2-tf-blowjob1 with dissolve
                        pause

                        scene e2f2-tf-blowjob2 with dissolve
                        pause

                        scene e2f2-tf-handjob4 with dissolve
                        tf "Do you like it when I go faster?"

                        scene e2f2-tf-handjob3 with dissolve
                        mc "Damn... yeah, I do!"

                        scene e2f2-tf-handjob4 with dissolve
                        pause

                        scene e2f2-tf-handjob3 with dissolve
                        pause

                        scene e2f2-tf_45 with dissolve
                        tf "Tell me when you want to cum, alright [mc]?"

                        scene e2f2-tf-handjob4 with dissolve
                        mc "Yeah [tf]."

            scene e2f2-tf_48 with dissolve
            pause
            tf "Also, I'm gonna leave you my phone number in case you want to stay in touch."

            scene e2f2-tf_49 with dissolve
            mc "Wait, you're leaving already?"

            scene e2f2-tf_50 with dissolve
            tf "Yeah, it doesn't look like any more people will show up."

            scene e2f2-tf_51 with dissolve
            tf "Plus that I've hit my goal for this night, talk to a cute guy."

            scene e2f2-tf_52 with dissolve
            tf "Making him finish was a welcome bonus!"

            scene e2f2-tf_51 with dissolve
            tf "I've also had a drink, better end it on a high note, right?"

            scene e2f2-tf_53 with dissolve
            show e2f2-tf_tiffany_blink5
            mc "Oh, alright..."
            mc "That's a bummer."
            mc "I would've liked to spend more time with you but it's alright."
            mc "Nice to meet you [tf]!"
            mc "And thank you also for the release."

            scene e2f2-tf_52 with dissolve
            hide e2f2-tf_tiffany_blink5
            tf "Haha, happy to help!"

            scene e2f2-tf_51 with dissolve
            tf "Thanks for the drink."

            scene e2f2-tf_52 with dissolve
            tf "I'll see you around?"

            scene e2f2-tf_53 with dissolve
            show e2f2-tf_tiffany_blink5
            mc "Yeah, you will."
            mc "Bye!"
        else:
            if persistent.type_nsfw == False:
                scene e2f2-tf_43_cen with wipeleft
                tf "Tell me, how does this feel?"

                scene e2f2-tf-handjob1_cen with dissolve
                mc "It feels pretty good, [tf]."
                mc "Keep going."

                scene e2f2-tf-handjob2_cen with dissolve
                pause
                tf "I'm sorry if I'm a little rough."
                tf "I'm starting to feel a bit dizzy."
                mc "Don't worry, it feels great."

                scene e2f2-tf-handjob1_cen with dissolve
                pause

                scene e2f2-tf-handjob2_cen with dissolve
                pause

                scene e2f2-tf-blowjob1_cen with dissolve
                mc "Ahh, fuck!"
                mc "It feels really good [tf]."

                scene e2f2-tf-blowjob2_cen with dissolve
                pause

                scene e2f2-tf-blowjob3_cen with dissolve
                pause

                scene e2f2-tf-blowjob4_cen with dissolve
                pause

                scene e2f2-tf-blowjob1_cen with dissolve
                pause

                scene e2f2-tf-blowjob2_cen with dissolve
                pause

                scene e2f2-tf_43_cen with dissolve
                tf "Maybe this will make you feel better."

                scene e2f2-tf_44_cen with dissolve
                mc "*God, her tits are so hot.*"

                scene e2f2-tf-handjob4_cen with dissolve
                tf "Do you like it when I go faster?"

                scene e2f2-tf-handjob3_cen with dissolve
                mc "Damn... yeah, I do!"

                scene e2f2-tf-handjob4_cen with dissolve
                pause

                scene e2f2-tf-handjob3_cen with dissolve
                pause

                scene e2f2-tf_45_cen with dissolve
                tf "Tell me when you want to cum, alright [mc]?"

                scene e2f2-tf-handjob4_cen with dissolve
                mc "Yeah [tf]."

                $ GameRunning = True

                while GameRunning:
                    menu:
                        "Cum":
                            $ GameRunning = False

                            scene e2f2-tf-handjob3_cen with dissolve
                            mc "Hey [tf], I'm about to cum."

                            scene e2f2-tf-handjob4_cen with dissolve
                            mc "Ahh, fuck [tf]!"
                            tf "Cum on my tits, [mc]."

                            show white with Dissolve(0.25)
                            scene e2f2-tf_46_cen
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e2f2-tf_47_cen with dissolve
                            mc "Holy shit, that felt great!"
                            tf "I'm glad you enjoyed it."
                            tf "I liked it too."
                            mc "Thank you [tf]!"
                            tf "You're welcome [mc]."
                            tf "Let me get cleaned up."
                        "Keep going":
                            scene e2f2-tf-handjob1_cen with dissolve
                            pause

                            scene e2f2-tf-handjob2_cen with dissolve
                            pause

                            scene e2f2-tf-blowjob1_cen with dissolve
                            mc "Ahh, fuck!"
                            mc "It feels really good [tf]."

                            scene e2f2-tf-blowjob2_cen with dissolve
                            pause

                            scene e2f2-tf-blowjob3_cen with dissolve
                            pause

                            scene e2f2-tf-blowjob4_cen with dissolve
                            pause

                            scene e2f2-tf-blowjob1_cen with dissolve
                            pause

                            scene e2f2-tf-blowjob2_cen with dissolve
                            pause

                            scene e2f2-tf-handjob4_cen with dissolve
                            tf "Do you like it when I go faster?"

                            scene e2f2-tf-handjob3_cen with dissolve
                            mc "Damn... yeah, I do!"

                            scene e2f2-tf-handjob4_cen with dissolve
                            pause

                            scene e2f2-tf-handjob3_cen with dissolve
                            pause

                            scene e2f2-tf_45_cen with dissolve
                            tf "Tell me when you want to cum, alright [mc]?"

                            scene e2f2-tf-handjob4_cen with dissolve
                            mc "Yeah [tf]."

                scene e2f2-tf_48_cen with dissolve
                pause
                tf "Also, I'm gonna leave you my phone number in case you want to stay in touch."

                scene e2f2-tf_49_cen with dissolve
                mc "Wait, you're leaving already?"

                scene e2f2-tf_50_cen with dissolve
                tf "Yeah, it doesn't look like any more people will show up."

                scene e2f2-tf_51_cen with dissolve
                tf "Plus that I've hit my goal for this night, talk to a cute guy."

                scene e2f2-tf_52_cen with dissolve
                tf "Making him finish was a welcome bonus!"

                scene e2f2-tf_51_cen with dissolve
                tf "I've also had a drink, better end it on a high note, right?"

                scene e2f2-tf_53_cen with dissolve
                show e2f2-tf_tiffany_blink5
                mc "Oh, alright..."
                mc "That's a bummer."
                mc "I would've liked to spend more time with you but it's alright."
                mc "Nice to meet you [tf]!"
                mc "And thank you also for the release."

                scene e2f2-tf_52_cen with dissolve
                hide e2f2-tf_tiffany_blink5
                tf "Haha, happy to help!"

                scene e2f2-tf_51_cen with dissolve
                tf "Thanks for the drink."

                scene e2f2-tf_52_cen with dissolve
                tf "I'll see you around?"

                scene e2f2-tf_53_cen with dissolve
                show e2f2-tf_tiffany_blink5
                mc "Yeah, you will."
                mc "Bye!"

    scene e2f2-tf_54 with dissolve
    hide e2f2-tf_tiffany_blink5
    pause

    stop music fadeout 2.0
    scene e2f2-tf_55 with dissolve
    pause

    $ renpy.end_replay()

    $ renpy.music.queue (e2f2_tracks, loop=True)

    $ renpy.random.shuffle(e2f2_tracks)
return

label e2f2_end:
    $ collected_p = persistent.e2f2_collected_p
    $ collected_tp = persistent.e2f2_collected_tp
    $ renpy.show_screen("render_count_notify_pers")

    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e2s9
        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e2f2_hallway
return

label e2f2_ken_roman:
    scene e2f2-kr_01 with dissolve
    ke "Look bro, have you seen that one?"

    scene e2f2-kr_02 with dissolve
    ro "Damn dude, there's so many I don't even know who to choose."

    scene e2f2-kr_03 with dissolve
    mc "What are you guys doing?"

    scene e2f2-kr_04 with dissolve
    ke "Come here [mc]!"

    scene e2f2-kr_05 with dissolve
    mc "Damn dude, take it easy with the booze."
    mc "You smell from a mile away."

    scene e2f2-kr_06 with dissolve
    ke "We've been looking at some chicks that have shown up."

    scene e2f2-kr_07 with dissolve
    ke "We were thinking about hitting on them but couldn't quite choose which one to go for."
    ro "Yeah, there's a lot of great choices here."

    scene e2f2-kr_06 with dissolve
    ke "You know what?"
    ke "Think I'm gonna go for the brunette."
    ke "You can have the other one."

    scene e2f2-kr_08 with dissolve
    ro "Wait, are you going in now?"

    scene e2f2-kr_09 with dissolve
    ke "Yeah dude, don't let the anxiety creep in."
    ke "The sooner I do it the better chance of success I have."

    scene e2f2-kr_10 with dissolve
    pause

    scene e2f2-kr_11 with dissolve
    ro "Nah dude, you gotta give her some punch first!"

    scene e2f2-kr_12 with dissolve
    ro "[jon] said that it's the bomb."

    scene e2f2-kr_13 with dissolve
    ke "Hey, you might be right!"
    ke "That's a great opener, thanks dude!"

    scene e2f2-kr_14 with dissolve
    pause

    scene e2f2-kr_15 with dissolve
    jon "Hey my dudes, what's up?"

    scene e2f2-kr_16 with dissolve
    ro "Hey [jon], we're here for some punch."

    scene e2f2-kr_15 with dissolve
    jon "You're in the right place my friend!"
    jon "Who's in need of some very delicious punch?"

    scene e2f2-kr_16 with dissolve
    ro "[ke] right here is eager to hit on a girl."
    ro "Thought it might be a good idea to have him give her some punch."

    scene e2f2-kr_15 with dissolve
    jon "Excellent choice!"

    scene e2f2-kr_17 with dissolve
    jon "Here [ke], don't be shy."
    jon "Take some punch."

    scene e2f2-kr_18 with dissolve
    ke "Alright, alright."

    scene e2f2-kr_19 with dissolve
    ro "Dude, I've already tasted the punch."
    ro "It's so bad, oh my God."
    ro "I don't know what [jon] put in that punch but it's horrible."
    ro "This is going to be absolute fucking cinema, watch this."

    scene e2f2-kr_20 with dissolve
    ke "Hey [ro], just wanted to tell you that I'm really grateful for you my friend."
    ke "This is honestly a really good idea to give her punch."
    ke "I'm gonna go and give it to her, thanks!"

    scene e2f2-kr_21 with dissolve
    ro "Yeah, no problem dude!"

    scene e2f2-kr_22 with dissolve
    pause

    scene e2f2-kr_23 with dissolve
    ro "Watch this guys!"

    scene e2f2-kr_24 with dissolve
    ke "Hey girl, what's up?"

    scene e2f2-kr_25 with dissolve
    ke "I'm [ke]!"
    ke "I just wanted to tell you that I think you look pretty good."

    scene e2f2-kr_26 with dissolve
    unknown "Haha, thanks!"
    unknown "I'm Barbara."

    scene e2f2-kr_27 with dissolve
    ke "Nice to meet you Barbara!"
    ke "Is it cool if I call you Barb?"

    scene e2f2-kr_26 with dissolve
    brb "Sure thing, [ke]!"
    brb "I don't mind."

    scene e2f2-kr_27 with dissolve
    ke "Awesome!"

    scene e2f2-kr_28 with dissolve
    ke "Look, I just got you this punch right from the kitchen."
    ke "My friend made it and it's the bomb."

    scene e2f2-kr_26 with dissolve
    brb "Oh, interesting!"
    brb "Let me have a sip."
    brb "I didn't taste the punch yet and I was curious to see how it is."

    scene e2f2-kr_29 with dissolve
    pause

    scene e2f2-kr_30 with dissolve
    pause

    scene e2f2-kr_31 with dissolve
    jd "Ohh, damn!"
    jd "Looks like she didn't enjoy the punch."

    scene e2f2-kr_32 with dissolve
    jon "What's wrong with my punch...?"

    scene e2f2-kr_33 with dissolve
    brb "What the fuck is this??"

    scene e2f2-kr_34 with dissolve
    ke "Punch...?"

    scene e2f2-kr_33 with dissolve
    brb "It's horrible!"

    scene e2f2-kr_35 with dissolve
    brb "Tell your friend that his punch is not very good."

    scene e2f2-kr_36 with dissolve
    ke "Uh... I will..."

    scene e2f2-kr_37 with dissolve
    pause

    scene e2f2-kr_38 with dissolve
    ke "Really guys?"

    scene e2f2-kr_39 with dissolve
    jd "Why the hell are you looking at me like I did it?"

    scene e2f2-kr_40 with dissolve
    ke "Well, you guys cooked this thing."

    scene e2f2-kr_32 with dissolve
    jon "But I like it..."

    scene e2f2-kr_41 with dissolve
    ke "Yeah, looks like others don't enjoy it so much..."

    scene e2f2-kr_42 with dissolve
    pause

    scene e2f2-kr_43 with dissolve
    pause

    scene e2f2-kr_52 with dissolve
    ro "Haha, did you guys see that?"

    scene e2f2-kr_53 with dissolve
    ro "Best thing that happened tonight I swear."

    scene e2f2-kr_44 with dissolve
    pause

    scene e2f2-kr_45 with dissolve
    pause

    scene e2f2-kr_46 with dissolve
    unknown "This punch is... LEGENDARY!"

    scene e2f2-kr_47 with dissolve
    unknown "Come on, try some!"

    scene e2f2-kr_49 with dissolve
    pause

    scene e2f2-kr_50 with dissolve
    unknown "Woah, that's..."

    scene e2f2-kr_51 with dissolve
    unknown "Yeah, maybe don't try some."

    $ e2f2_explore += 1

    if affinity_spectrum > 0:
        if e2f2_explore == 2:
            $ current_quests.remove("Interact with people.")
            $ current_quests.append("Answer the front door.")
    else:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Answer the front door.")

    $ e2f2_ken_roman = True

    scene e2f2-kr_48 with dissolve
    sc "Are you done?"

    jump e2f2_hallway
return

# Bedroom #

label e2f2_tracy_sex:

    if not _in_replay:
        pass
    else:
        stop music fadeout 1.0

        $ renpy.random.shuffle(e2f2_tracks)

        $ renpy.music.queue (e2f2_tracks, loop=True)

    scene e2f2-ts_01 with dissolve
    mc "Hey [tr], what's up?"

    scene e2f2-ts_02 with dissolve
    tr "[mc]... hi!"
    tr "I didn't hear you come in."

    scene e2f2-ts_03 with dissolve
    tr "So... are you ready?"

    scene e2f2-ts_04 with dissolve
    show e2f2-ts_tracy_blink1
    mc "Sure, what's up?"

    scene e2f2-ts_05 with dissolve
    hide e2f2-ts_tracy_blink1
    pause

    scene e2f2-ts_06 with dissolve
    pause

    scene e2f2-ts_07 with dissolve
    pause

    if persistent.disable_nsfw == True:
        scene e2f2-ts_08 with dissolve
        pause
    else:
        if persistent.type_nsfw == False:
            scene e2f2-ts_08_cen with dissolve
            pause

    scene e2f2-ts_09 with dissolve
    pause

    scene e2f2-ts_10 with dissolve
    show e2f2-ts_tracy_blink1
    if e1f5_tracy_sex == True:
        $ persistent.e2f2_tracy_sex = True
        mc "Damn, weed again?"

        scene e2f2-ts_11 with dissolve
        hide e2f2-ts_tracy_blink1
        tr "Hell yeah, dude!"

        scene e2f2-ts_10 with dissolve
        show e2f2-ts_tracy_blink1
        mc "Why didn't you come with a joint?"

        scene e2f2-ts_12 with dissolve
        hide e2f2-ts_tracy_blink1
        tr "Well, I thought it would be more interesting if we built it right here."
        tr "From whatever we find."
    else:
        mc "What's that?"

        scene e2f2-ts_13 with dissolve
        hide e2f2-ts_tracy_blink1
        tr "Haha, don't you know what weed is?"

        scene e2f2-ts_10 with dissolve
        show e2f2-ts_tracy_blink1
        mc "Is that what it is?"

        scene e2f2-ts_14 with dissolve
        hide e2f2-ts_tracy_blink1
        tr "Yeah."

        scene e2f2-ts_10 with dissolve
        show e2f2-ts_tracy_blink1
        menu:
            "Get into drugs":
                $ persistent.e2f2_tracy_sex = True
                mc "Alright, so how are we gonna do it?"

                scene e2f2-ts_12 with dissolve
                hide e2f2-ts_tracy_blink1
                tr "Well, it's pretty easy."

                scene e2f2-ts_14 with dissolve
                tr "Usually I would have a joint with me but this time I wanted to make things more interesting."

                scene e2f2-ts_11 with dissolve
                tr "So we'll have to build it from whatever we can find around here."
            "Stay out of it" if not _in_replay:
                $ e2f2_tracy_refuse = True
                mc "I'm sorry [tr]!"
                mc "I'm not into drugs."
                mc "Thanks for the offer but I'll have to pass."

                scene e2f2-ts_15 with dissolve
                hide e2f2-ts_tracy_blink1
                tr "Oh, okay."

                scene e2f2-ts_16 with dissolve
                tr "Then can you not tell anyone you saw this?"

                scene e2f2-ts_10 with dissolve
                show e2f2-ts_tracy_blink1
                mc "Sure, don't worry."
                mc "I won't tell."
                mc "See you around [tr]!"

                scene e2f2-ts_17 with dissolve
                hide e2f2-ts_tracy_blink1
                tr "Bye [mc]!"

                $ e2f2_tracy = 4

                $ optional_quests.remove("Follow Tracy to the bedroom.")

                scene e2f2-ts_18 with dissolve
                pause

                jump e2f2_hallway

    scene e2f2-ts_10 with dissolve
    show e2f2-ts_tracy_blink1
    mc "Haha, sounds good!"
    mc "Alright, so where do we start?"

    scene e2f2-ts_12 with dissolve
    hide e2f2-ts_tracy_blink1
    tr "First of all, lock the door."

    scene e2f2-ts_11 with dissolve
    tr "We don't want any unwanted visitors."

    scene e2f2-ts_10 with dissolve
    show e2f2-ts_tracy_blink1
    mc "True that."

    scene e2f2-ts_18 with dissolve
    hide e2f2-ts_tracy_blink1
    pause

    scene e2f2-ts_19 with dissolve
    pause

    scene e2f2-ts_20 with dissolve
    tr "Now, go through some books from here until you find a thin piece of paper."

    scene e2f2-ts_21 with dissolve
    mc "Alright."

    scene e2f2-ts_22 with dissolve
    pause

    scene e2f2-ts_23 with dissolve
    pause

    scene e2f2-ts_24 with dissolve
    pause

    scene e2f2-ts_25 with dissolve
    pause

    scene e2f2-ts_10 with dissolve
    show e2f2-ts_tracy_blink1
    mc "Here, is this alright?"

    scene e2f2-ts_11 with dissolve
    hide e2f2-ts_tracy_blink1
    tr "Yeah, it's good."

    scene e2f2-ts_26 with dissolve
    tr "Now we just lay the paper on the bed."

    scene e2f2-ts_27 with dissolve
    tr "And put some weed on it."
    tr "Not too much, we don't want it too bulky."

    scene e2f2-ts_28 with dissolve
    pause

    scene e2f2-ts_29 with dissolve
    pause

    scene e2f2-ts_30 with dissolve
    tr "Congratulations [mc], now you know how to make a joint."

    scene e2f2-ts_31 with dissolve
    mc "Haha, cool!"

    scene e2f2-ts_32 with dissolve
    pause

    scene e2f2-ts_33 with dissolve
    tr "Here, take a hit."

    scene e2f2-ts_34 with dissolve
    pause

    scene e2f2-ts_35 with dissolve
    show e2f2-ts_tracy_blink2
    if e1f5_tracy_sex == True:
        mc "Damn, this is noticeably stronger than the one you brought at Cabanna's."

        scene e2f2-ts_36 with dissolve
        hide e2f2-ts_tracy_blink2
        tr "Haha, well, yeah!"

        scene e2f2-ts_37 with dissolve
        tr "This paper is from a book [mc], it is most probably bleached."

        scene e2f2-ts_38 with dissolve
        tr "And also slightly thicker than a normal rolling paper."
        tr "The paper I used for that one was a special one which didn't contain any bleach."

        scene e2f2-ts_35 with dissolve
        show e2f2-ts_tracy_blink2
        mc "I see."
    else:
        mc "Damn, this is strong!"

        scene e2f2-ts_36 with dissolve
        hide e2f2-ts_tracy_blink2
        tr "Haha, well, yeah!"

        scene e2f2-ts_37 with dissolve
        tr "This paper is from a book [mc], it is most probably bleached."

        scene e2f2-ts_38 with dissolve
        tr "And also slightly thicker than a normal rolling paper."

        scene e2f2-ts_35 with dissolve
        show e2f2-ts_tracy_blink2
        mc "I see."

        scene e2f2-ts_38 with dissolve
        hide e2f2-ts_tracy_blink2
        tr "Let me know when it hits you, alright?"

        scene e2f2-ts_35 with dissolve
        show e2f2-ts_tracy_blink2
        mc "Yeah, okay."

    scene e2f2-ts_53 with dissolve
    hide e2f2-ts_tracy_blink2
    tr "Give it to me."

    scene e2f2-ts_39 with dissolve
    pause

    scene e2f2-ts_40 with dissolve
    pause

    scene e2f2-ts_32 with dissolve
    pause

    scene e2f2-ts_33 with dissolve
    tr "Here."

    scene e2f2-ts_34 with dissolve
    pause

    if not _in_replay:
        scene e2f2-ts_35 with dissolve
        show e2f2-ts_tracy_blink2
        mc "So, how did you come in contact with these drugs, [tr]?"

        scene e2f2-ts_53 with dissolve
        hide e2f2-ts_tracy_blink2
        tr "What do you mean?"

        scene e2f2-ts_35 with dissolve
        show e2f2-ts_tracy_blink2
        mc "Like, why are you smoking weed?"

        scene e2f2-ts_54 with dissolve
        hide e2f2-ts_tracy_blink2
        tr "Well, first of all, I like the high it gives you."

        scene e2f2-ts_53 with dissolve
        tr "It makes me feel relaxed and lightens up my mood."

        scene e2f2-ts_54 with dissolve
        tr "I don't care about all that health crap people keep talking about."
        tr "I've seen people smoke it for 30 years and they haven't had a single problem."

        scene e2f2-ts_38 with dissolve
        tr "I don't know, it's not really that deep."
        tr "I'm not trying to escape anything or something like that."

        scene e2f2-ts_37 with dissolve
        tr "Just living my life, you know?"

        scene e2f2-ts_55 with dissolve
        show e2f2-ts_tracy_blink3
        mc "I understand."
        mc "So, it's just pleasure and nothing more."

        scene e2f2-ts_36 with dissolve
        hide e2f2-ts_tracy_blink3
        tr "Exactly!"

        scene e2f2-ts_55 with dissolve
        show e2f2-ts_tracy_blink3
        mc "I see, I see."
        mc "So... how did you and [sd] meet?"

        scene e2f2-ts_54 with dissolve
        hide e2f2-ts_tracy_blink3
        tr "Oh, we were actually in the same class in high school."

        scene e2f2-ts_38 with dissolve
        tr "We didn't really talk much back then."

        scene e2f2-ts_56 with dissolve
        tr "I was caught up in my things, she was caught up in hers..."

        scene e2f2-ts_57 with dissolve
        tr "We didn't really intersect."

        scene e2f2-ts_38 with dissolve
        tr "What's funny is that we both weren't really showing up to class."

        scene e2f2-ts_56 with dissolve
        tr "It was in 12th grade when we met in detention and started talking."

        scene e2f2-ts_57 with dissolve
        tr "Somehow, the principal managed to calm down all the other rebels, but not us."
        tr "We always just kind of did our own thing."

        scene e2f2-ts_38 with dissolve
        tr "Regardless of the consequences."
        tr "So, when we first talked, we just clicked instantly."

        scene e2f2-ts_56 with dissolve
        tr "Turns out me and her aren't so different after all."

        scene e2f2-ts_55 with dissolve
        show e2f2-ts_tracy_blink3
        mc "Haha, that's pretty nice!"
        mc "So, do you have any interesting stories together?"

        scene e2f2-ts_36 with dissolve
        hide e2f2-ts_tracy_blink3
        tr "Haha, we do have quite a bit."
        tr "But I'm not ready to share them with you yet."

        scene e2f2-ts_38 with dissolve
        tr "You know, you asked me about [sd], I'm wondering about how you and [jon] met."

        scene e2f2-ts_55 with dissolve
        show e2f2-ts_tracy_blink3
        mc "Fair enough."
        mc "Well, basically, when I was in first grade I met him."
        mc "We were also in the same class and got along pretty fast."
        mc "I believe it was in second grade when we really became best friends."
        mc "I mean, we used to hang out every day of the week."
        mc "Sleepovers at either my place or his."
        mc "They were really great times."
        mc "Been really good friends ever since."

        scene e2f2-ts_36 with dissolve
        hide e2f2-ts_tracy_blink3
        tr "Damn, I didn't know you guys go that far back."

        scene e2f2-ts_55 with dissolve
        show e2f2-ts_tracy_blink3
        mc "Yeah, well, most people don't know that."
        mc "Because most people don't know me."

        scene e2f2-ts_57 with dissolve
        hide e2f2-ts_tracy_blink3
        tr "Oh, I see."
    else:
        pass

    scene e2f2-ts_36 with dissolve
    tr "Hey, did the weed hit you yet?"

    scene e2f2-ts_55 with dissolve
    show e2f2-ts_tracy_blink3
    mc "Haha, yeah, it did!"
    mc "I think it was when you were talking about why you liked it."
    mc "I might have missed a part of what you've said."

    scene e2f2-ts_53 with dissolve
    hide e2f2-ts_tracy_blink3
    tr "So you're telling me you weren't really listening to what I was saying?"

    scene e2f2-ts_35 with dissolve
    show e2f2-ts_tracy_blink2
    mc "Haha, no, I mean, yeah, I was!"
    mc "It felt like you were talking in slow motion."
    mc "So I think I understood everything you said even better."

    scene e2f2-ts_36 with dissolve
    hide e2f2-ts_tracy_blink2
    tr "Haha! You have a way of getting yourself out of trouble [mc]..."
    tr "I'll give you that."

    scene e2f2-ts_55 with dissolve
    show e2f2-ts_tracy_blink3
    mc "A hard earned skill I must say!"

    scene e2f2-ts_58 with dissolve
    hide e2f2-ts_tracy_blink3
    pause

    scene e2f2-ts-kiss with dissolve
    pause

    scene e2f2-ts_59 with dissolve
    pause

    scene e2f2-ts_60 with dissolve
    tr "[mc], wanna know what's better than being high and kissing?"

    scene e2f2-ts_61 with dissolve
    mc "Haha, what?"

    scene e2f2-ts_62 with dissolve
    tr "Being high, kissing and fucking!"

    scene e2f2-ts_61 with dissolve
    mc "Haha, you're right!"

    scene e2f2-ts_63 with dissolve
    tr "Come on, take off your clothes."

    scene e2f2-ts_61 with dissolve
    scene black with Dissolve(2.0)

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            # Handjob and Blowjob ##################################################
            scene e2f2-ts-blowjob2 with Dissolve(2.0)
            mc "Fuck me, this feels so good!"

            scene e2f2-ts-blowjob3 with dissolve
            mc "Damn, keep going [tr]!"
            mc "You're doing a great job."

            scene e2f2-ts-blowjob1 with dissolve
            pause
            mc "Damn your tits are hot."

            scene e2f2-ts_50 with dissolve
            tr "Are they?"

            scene e2f2-ts_51 with dissolve
            tr "How would you feel about me giving you a tit job then?"

            scene e2f2-ts_52 with dissolve
            mc "I'd feel like I am in heaven."

            scene e2f2-ts-titjob1 with dissolve
            pause
            mc "*Holy shit, her tits are so warm.*"
            mc "*It's like I am inside her.*"
            mc "Your tits look so hot [tr]!"

            scene e2f2-ts-titjob2 with dissolve
            pause
            tr "Your dick looks hotter between them."

            scene e2f2-ts-titjob1 with dissolve
            pause
            mc "Ah, fuck!"

            scene e2f2-ts-titjob2 with dissolve
            pause

            scene e2f2-ts-titjob1 with dissolve
            pause

            scene e2f2-ts-titjob2 with dissolve
            pause

            scene e2f2-ts-handjob1 with dissolve
            pause

            scene e2f2-ts-handjob2 with dissolve
            tr "All this talk has made me very wet."
            mc "Are you touching yourself?"

            scene e2f2-ts-handjob3 with dissolve
            tr "Maybe I am..."
            tr "Ah..."

            scene e2f2-ts-handjob1 with dissolve
            pause
            mc "You're definitely touching yourself."

            scene e2f2-ts-blowjob2 with dissolve
            pause

            scene e2f2-ts-blowjob1 with dissolve
            pause
            mc "Damn [tr]..."
            mc "You give the best blowjobs."

            scene e2f2-ts-blowjob3 with dissolve
            pause

            scene e2f2-ts-handjob2 with dissolve
            pause

            scene e2f2-ts-handjob3 with dissolve
            pause
            tr "[mc]... I'm so wet right now."
            tr "Your dick would just slip right in."

            scene e2f2-ts-handjob1 with dissolve
            mc "Would it now?"

            scene e2f2-ts-handjob2 with dissolve
            tr "Don't try me."
            mc "What if I will then?"

            # Cowgirl ##############################################################
            scene e2f2-ts_44 with vpunch
            pause

            scene e2f2-ts_41 with dissolve
            pause

            scene e2f2-ts_42 with dissolve
            mc "Holy shit."

            scene e2f2-ts_43 with dissolve
            tr "You asked for it."

            scene e2f2-ts_45 with dissolve
            pause

            scene e2f2-ts-cowgirl_insert with dissolve
            pause(1.68)

            scene e2f2-ts_46 with dissolve
            tr "Fuuck! You're so big dude."
            mc "You're so fucking tight..."
            mc "Ah...!"

            scene e2f2-ts-cowgirl3 with dissolve
            pause

            scene e2f2-ts-cowgirl1 with dissolve
            pause
            mc "Your pussy feels so good [tr]."

            scene e2f2-ts-cowgirl2 with dissolve
            tr "You're going in so deep [mc]."
            tr "It barely fits in."

            scene e2f2-ts-cowgirl3 with dissolve
            pause

            scene e2f2-ts-cowgirl4 with dissolve
            pause
            tr "Fuuuck."

            scene e2f2-ts-cowgirl2 with dissolve
            pause

            scene e2f2-ts-cowgirl1 with dissolve
            pause

            scene e2f2-ts-cowgirl3 with dissolve
            pause

            scene e2f2-ts-cowgirl4 with dissolve
            pause

            # Missionary ###########################################################
            scene e2f2-ts-missionary3 with dissolve
            pause
            tr "Fuck [mc]..."
            tr "I love your dick so much!"

            scene e2f2-ts-missionary2 with dissolve
            pause

            scene e2f2-ts-missionary3 with dissolve
            pause

            scene e2f2-ts-missionary2 with dissolve
            pause

            scene e2f2-ts-missionary3 with dissolve
            pause

            scene e2f2-ts-missionary1 with dissolve
            pause

            scene e2f2-ts_45 with dissolve
            mc "Hey [tr]."
            mc "Let's switch."

            # Doggy ################################################################
            scene e2f2-ts-doggy5 with dissolve
            pause

            scene e2f2-ts-doggy4 with dissolve
            mc "Your ass is so hot [tr]."

            scene e2f2-ts-doggy5 with dissolve
            pause
            tr "Fuck me, you're so big..."

            scene e2f2-ts-doggy4 with dissolve
            pause

            scene e2f2-ts_47 with vpunch
            pause

            scene e2f2-ts_48 with dissolve
            tr "Holy shit, you're so rough."

            scene e2f2-ts_49 with dissolve
            mc "You asked for it."

            scene e2f2-ts-doggy1 with dissolve
            pause
            tr "Ah... uh..."

            scene e2f2-ts_48 with dissolve
            tr "I love it when you're like this."

            scene e2f2-ts-doggy6 with dissolve
            pause
            mc "*She looks so hot from this angle.*"

            scene e2f2-ts-doggy1 with dissolve
            pause

            scene e2f2-ts-doggy6 with dissolve
            pause

            scene e2f2-ts-doggy2 with dissolve
            pause

            scene e2f2-ts-doggy3 with dissolve
            pause
            tr "God damn it [mc], you're killing me!"

            scene e2f2-ts-doggy2 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                # Handjob and Blowjob ##################################################
                scene e2f2-ts-blowjob2_cen with Dissolve(2.0)
                mc "Fuck me, this feels so good!"

                scene e2f2-ts-blowjob3_cen with dissolve
                mc "Damn, keep going [tr]!"
                mc "You're doing a great job."

                scene e2f2-ts-blowjob1_cen with dissolve
                pause
                mc "Damn your tits are hot."

                scene e2f2-ts_50_cen with dissolve
                tr "Are they?"

                scene e2f2-ts_51_cen with dissolve
                tr "How would you feel about me giving you a tit job then?"

                scene e2f2-ts_52_cen with dissolve
                mc "I'd feel like I am in heaven."

                scene e2f2-ts-titjob1_cen with dissolve
                pause
                mc "*Holy shit, her tits are so warm.*"
                mc "*It's like I am inside her.*"
                mc "Your tits look so hot [tr]!"

                scene e2f2-ts-titjob2_cen with dissolve
                pause
                tr "Your dick looks hotter between them."

                scene e2f2-ts-titjob1_cen with dissolve
                pause
                mc "Ah, fuck!"

                scene e2f2-ts-titjob2_cen with dissolve
                pause

                scene e2f2-ts-titjob1_cen with dissolve
                pause

                scene e2f2-ts-titjob2_cen with dissolve
                pause

                scene e2f2-ts-handjob1_cen with dissolve
                pause

                scene e2f2-ts-handjob2_cen with dissolve
                tr "All this talk has made me very wet."
                mc "Are you touching yourself?"

                scene e2f2-ts-handjob3_cen with dissolve
                tr "Maybe I am..."
                tr "Ah..."

                scene e2f2-ts-handjob1_cen with dissolve
                pause
                mc "You're definitely touching yourself."

                scene e2f2-ts-blowjob2_cen with dissolve
                pause

                scene e2f2-ts-blowjob1_cen with dissolve
                pause
                mc "Damn [tr]..."
                mc "You give the best blowjobs."

                scene e2f2-ts-blowjob3_cen with dissolve
                pause

                scene e2f2-ts-handjob2_cen with dissolve
                pause

                scene e2f2-ts-handjob3_cen with dissolve
                pause
                tr "[mc]... I'm so wet right now."
                tr "Your dick would just slip right in."

                scene e2f2-ts-handjob1_cen with dissolve
                mc "Would it now?"

                scene e2f2-ts-handjob2_cen with dissolve
                tr "Don't try me."
                mc "What if I will then?"

                # Cowgirl ##############################################################
                scene e2f2-ts_44_cen with vpunch
                pause

                scene e2f2-ts_41_cen with dissolve
                pause

                scene e2f2-ts_42 with dissolve
                mc "Holy shit."

                scene e2f2-ts_43 with dissolve
                tr "You asked for it."

                scene e2f2-ts_45_cen with dissolve
                pause

                scene e2f2-ts-cowgirl_insert_cen with dissolve
                pause(1.68)

                scene e2f2-ts_46_cen with dissolve
                tr "Fuuck! You're so big dude."
                mc "You're so fucking tight..."
                mc "Ah...!"

                scene e2f2-ts-cowgirl3_cen with dissolve
                pause

                scene e2f2-ts-cowgirl1_cen with dissolve
                pause
                mc "Your pussy feels so good [tr]."

                scene e2f2-ts-cowgirl2_cen with dissolve
                tr "You're going in so deep [mc]."
                tr "It barely fits in."

                scene e2f2-ts-cowgirl3_cen with dissolve
                pause

                scene e2f2-ts-cowgirl4_cen with dissolve
                pause
                tr "Fuuuck."

                scene e2f2-ts-cowgirl2_cen with dissolve
                pause

                scene e2f2-ts-cowgirl1_cen with dissolve
                pause

                scene e2f2-ts-cowgirl3_cen with dissolve
                pause

                scene e2f2-ts-cowgirl4_cen with dissolve
                pause

                # Missionary ###########################################################
                scene e2f2-ts-missionary3_cen with dissolve
                pause
                tr "Fuck [mc]..."
                tr "I love your dick so much!"

                scene e2f2-ts-missionary2_cen with dissolve
                pause

                scene e2f2-ts-missionary3_cen with dissolve
                pause

                scene e2f2-ts-missionary2_cen with dissolve
                pause

                scene e2f2-ts-missionary3_cen with dissolve
                pause

                scene e2f2-ts-missionary1_cen with dissolve
                pause

                scene e2f2-ts_45_cen with dissolve
                mc "Hey [tr]."
                mc "Let's switch."

                # Doggy ################################################################
                scene e2f2-ts-doggy5_cen with dissolve
                pause

                scene e2f2-ts-doggy4_cen with dissolve
                mc "Your ass is so hot [tr]."

                scene e2f2-ts-doggy5_cen with dissolve
                pause
                tr "Fuck me, you're so big..."

                scene e2f2-ts-doggy4_cen with dissolve
                pause

                scene e2f2-ts_47 with vpunch
                pause

                scene e2f2-ts_48 with dissolve
                tr "Holy shit, you're so rough."

                scene e2f2-ts_49 with dissolve
                mc "You asked for it."

                scene e2f2-ts-doggy1_cen with dissolve
                pause
                tr "Ah... uh..."

                scene e2f2-ts_48 with dissolve
                tr "I love it when you're like this."

                scene e2f2-ts-doggy6 with dissolve
                pause
                mc "*She looks so hot from this angle.*"

                scene e2f2-ts-doggy1_cen with dissolve
                pause

                scene e2f2-ts-doggy6 with dissolve
                pause

                scene e2f2-ts-doggy2_cen with dissolve
                pause

                scene e2f2-ts-doggy3_cen with dissolve
                pause
                tr "God damn it [mc], you're killing me!"

                scene e2f2-ts-doggy2_cen with dissolve
                pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Blowjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts-blowjob2 with dissolve
                        mc "Fuck me, this feels so good!"

                        scene e2f2-ts-blowjob3 with dissolve
                        mc "Damn, keep going [tr]!"
                        mc "You're doing a great job."

                        scene e2f2-ts-blowjob1 with dissolve
                        pause
                        mc "Damn your tits are hot."

                        scene e2f2-ts-blowjob2 with dissolve
                        pause

                        scene e2f2-ts-blowjob1 with dissolve
                        pause
                        mc "Damn [tr]..."
                        mc "You give the best blowjobs."

                        scene e2f2-ts-blowjob3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts-blowjob2_cen with dissolve
                            mc "Fuck me, this feels so good!"

                            scene e2f2-ts-blowjob3_cen with dissolve
                            mc "Damn, keep going [tr]!"
                            mc "You're doing a great job."

                            scene e2f2-ts-blowjob1_cen with dissolve
                            pause
                            mc "Damn your tits are hot."

                            scene e2f2-ts-blowjob2_cen with dissolve
                            pause

                            scene e2f2-ts-blowjob1_cen with dissolve
                            pause
                            mc "Damn [tr]..."
                            mc "You give the best blowjobs."

                            scene e2f2-ts-blowjob3_cen with dissolve
                            pause
                "Handjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts-handjob1 with dissolve
                        pause

                        scene e2f2-ts-handjob2 with dissolve
                        tr "All this talk has made me very wet."
                        mc "Are you touching yourself?"

                        scene e2f2-ts-handjob3 with dissolve
                        tr "Maybe I am..."
                        tr "Ah..."

                        scene e2f2-ts-handjob1 with dissolve
                        pause
                        mc "You're definitely touching yourself."

                        scene e2f2-ts-handjob2 with dissolve
                        pause

                        scene e2f2-ts-handjob3 with dissolve
                        pause
                        tr "[mc]... I'm so wet right now."
                        tr "Your dick would just slip right in."

                        scene e2f2-ts-handjob1 with dissolve
                        mc "Would it now?"

                        scene e2f2-ts-handjob2 with dissolve
                        tr "Don't try me."
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts-handjob1_cen with dissolve
                            pause

                            scene e2f2-ts-handjob2_cen with dissolve
                            tr "All this talk has made me very wet."
                            mc "Are you touching yourself?"

                            scene e2f2-ts-handjob3_cen with dissolve
                            tr "Maybe I am..."
                            tr "Ah..."

                            scene e2f2-ts-handjob1_cen with dissolve
                            pause
                            mc "You're definitely touching yourself."

                            scene e2f2-ts-handjob2_cen with dissolve
                            pause

                            scene e2f2-ts-handjob3_cen with dissolve
                            pause
                            tr "[mc]... I'm so wet right now."
                            tr "Your dick would just slip right in."

                            scene e2f2-ts-handjob1_cen with dissolve
                            mc "Would it now?"

                            scene e2f2-ts-handjob2_cen with dissolve
                            tr "Don't try me."
                "Titjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts-titjob1 with dissolve
                        pause
                        mc "*Holy shit, her tits are so warm.*"
                        mc "*It's like I am inside her.*"
                        mc "Your tits look so hot [tr]!"

                        scene e2f2-ts-titjob2 with dissolve
                        pause
                        tr "Your dick looks hotter between them."

                        scene e2f2-ts-titjob1 with dissolve
                        pause
                        mc "Ah, fuck!"

                        scene e2f2-ts-titjob2 with dissolve
                        pause

                        scene e2f2-ts-titjob1 with dissolve
                        pause

                        scene e2f2-ts-titjob2 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts-titjob1_cen with dissolve
                            pause
                            mc "*Holy shit, her tits are so warm.*"
                            mc "*It's like I am inside her.*"
                            mc "Your tits look so hot [tr]!"

                            scene e2f2-ts-titjob2_cen with dissolve
                            pause
                            tr "Your dick looks hotter between them."

                            scene e2f2-ts-titjob1_cen with dissolve
                            pause
                            mc "Ah, fuck!"

                            scene e2f2-ts-titjob2_cen with dissolve
                            pause

                            scene e2f2-ts-titjob1_cen with dissolve
                            pause

                            scene e2f2-ts-titjob2_cen with dissolve
                            pause
                "Cowgirl":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts_44 with vpunch
                        pause

                        scene e2f2-ts_41 with dissolve
                        pause

                        scene e2f2-ts_42 with dissolve
                        mc "Holy shit."

                        scene e2f2-ts_43 with dissolve
                        tr "You asked for it."

                        scene e2f2-ts_45 with dissolve
                        pause

                        scene e2f2-ts-cowgirl_insert with dissolve
                        pause(1.68)

                        scene e2f2-ts_46 with dissolve
                        tr "Fuuck! You're so big dude."
                        mc "You're so fucking tight..."
                        mc "Ah...!"

                        scene e2f2-ts-cowgirl3 with dissolve
                        pause

                        scene e2f2-ts-cowgirl1 with dissolve
                        pause
                        mc "Your pussy feels so good [tr]."

                        scene e2f2-ts-cowgirl2 with dissolve
                        tr "You're going in so deep [mc]."
                        tr "It barely fits in."

                        scene e2f2-ts-cowgirl3 with dissolve
                        pause

                        scene e2f2-ts-cowgirl4 with dissolve
                        pause
                        tr "Fuuuck."

                        scene e2f2-ts-cowgirl2 with dissolve
                        pause

                        scene e2f2-ts-cowgirl1 with dissolve
                        pause

                        scene e2f2-ts-cowgirl3 with dissolve
                        pause

                        scene e2f2-ts-cowgirl4 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts_44_cen with vpunch
                            pause

                            scene e2f2-ts_41_cen with dissolve
                            pause

                            scene e2f2-ts_42 with dissolve
                            mc "Holy shit."

                            scene e2f2-ts_43 with dissolve
                            tr "You asked for it."

                            scene e2f2-ts_45_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl_insert_cen with dissolve
                            pause(1.68)

                            scene e2f2-ts_46_cen with dissolve
                            tr "Fuuck! You're so big dude."
                            mc "You're so fucking tight..."
                            mc "Ah...!"

                            scene e2f2-ts-cowgirl3_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl1_cen with dissolve
                            pause
                            mc "Your pussy feels so good [tr]."

                            scene e2f2-ts-cowgirl2_cen with dissolve
                            tr "You're going in so deep [mc]."
                            tr "It barely fits in."

                            scene e2f2-ts-cowgirl3_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl4_cen with dissolve
                            pause
                            tr "Fuuuck."

                            scene e2f2-ts-cowgirl2_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl1_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl3_cen with dissolve
                            pause

                            scene e2f2-ts-cowgirl4_cen with dissolve
                            pause
                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts-doggy5 with dissolve
                        pause

                        scene e2f2-ts-doggy4 with dissolve
                        mc "Your ass is so hot [tr]."

                        scene e2f2-ts-doggy5 with dissolve
                        pause
                        tr "Fuck me, you're so big..."

                        scene e2f2-ts-doggy4 with dissolve
                        pause

                        scene e2f2-ts_47 with vpunch
                        pause

                        scene e2f2-ts_48 with dissolve
                        tr "Holy shit, you're so rough."

                        scene e2f2-ts_49 with dissolve
                        mc "You asked for it."

                        scene e2f2-ts-doggy1 with dissolve
                        pause
                        tr "Ah... uh..."

                        scene e2f2-ts_48 with dissolve
                        tr "I love it when you're like this."

                        scene e2f2-ts-doggy6 with dissolve
                        pause
                        mc "*She looks so hot from this angle.*"

                        scene e2f2-ts-doggy1 with dissolve
                        pause

                        scene e2f2-ts-doggy6 with dissolve
                        pause

                        scene e2f2-ts-doggy2 with dissolve
                        pause

                        scene e2f2-ts-doggy3 with dissolve
                        pause
                        tr "God damn it [mc], you're killing me!"

                        scene e2f2-ts-doggy2 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts-doggy5_cen with dissolve
                            pause

                            scene e2f2-ts-doggy4_cen with dissolve
                            mc "Your ass is so hot [tr]."

                            scene e2f2-ts-doggy5_cen with dissolve
                            pause
                            tr "Fuck me, you're so big..."

                            scene e2f2-ts-doggy4_cen with dissolve
                            pause

                            scene e2f2-ts_47 with vpunch
                            pause

                            scene e2f2-ts_48 with dissolve
                            tr "Holy shit, you're so rough."

                            scene e2f2-ts_49 with dissolve
                            mc "You asked for it."

                            scene e2f2-ts-doggy1_cen with dissolve
                            pause
                            tr "Ah... uh..."

                            scene e2f2-ts_48 with dissolve
                            tr "I love it when you're like this."

                            scene e2f2-ts-doggy6 with dissolve
                            pause
                            mc "*She looks so hot from this angle.*"

                            scene e2f2-ts-doggy1_cen with dissolve
                            pause

                            scene e2f2-ts-doggy6 with dissolve
                            pause

                            scene e2f2-ts-doggy2_cen with dissolve
                            pause

                            scene e2f2-ts-doggy3_cen with dissolve
                            pause
                            tr "God damn it [mc], you're killing me!"

                            scene e2f2-ts-doggy2_cen with dissolve
                            pause
                "Missionary":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e2f2-ts-missionary3 with dissolve
                        pause
                        tr "Fuck [mc]..."
                        tr "I love your dick so much!"

                        scene e2f2-ts-missionary2 with dissolve
                        pause

                        scene e2f2-ts-missionary3 with dissolve
                        pause

                        scene e2f2-ts-missionary2 with dissolve
                        pause

                        scene e2f2-ts-missionary3 with dissolve
                        pause

                        scene e2f2-ts-missionary1 with dissolve
                        pause

                        scene e2f2-ts_45 with dissolve
                        mc "Hey [tr]."
                        mc "Let's switch."
                    else:
                        if persistent.type_nsfw == False:
                            scene e2f2-ts-missionary3_cen with dissolve
                            pause
                            tr "Fuck [mc]..."
                            tr "I love your dick so much!"

                            scene e2f2-ts-missionary2_cen with dissolve
                            pause

                            scene e2f2-ts-missionary3_cen with dissolve
                            pause

                            scene e2f2-ts-missionary2_cen with dissolve
                            pause

                            scene e2f2-ts-missionary3_cen with dissolve
                            pause

                            scene e2f2-ts-missionary1_cen with dissolve
                            pause

                            scene e2f2-ts_45_cen with dissolve
                            mc "Hey [tr]."
                            mc "Let's switch."
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        mc "Hey [tr], I think I'm about to cum."

                        scene e2f2-ts-titjob1 with dissolve
                        mc "Oh, fuck [tr]!"
                        mc "You really know how to move those tits."

                        scene e2f2-ts-titjob2 with dissolve
                        tr "Cum on them [mc]!"
                        mc "Ohh, here it comes!"

                        show white with Dissolve(0.25)
                        scene e2f2-ts_64
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)

                        scene e2f2-ts_65 with dissolve
                        pause
                        tr "Damn, that's a lot of cum."
                        mc "You know, your tits look really hot with my cum on them."
                        tr "Even hotter than with your dick between them?"
                        mc "I think they all work together to create a perfect portrait."
                        tr "Haha, alright artist!"

                        scene e2f2-ts_66 with dissolve
                        pause

                        scene black with Dissolve(2.0)
                    else:
                        if persistent.type_nsfw == False:
                            mc "Hey [tr], I think I'm about to cum."

                            scene e2f2-ts-titjob1_cen with dissolve
                            mc "Oh, fuck [tr]!"
                            mc "You really know how to move those tits."

                            scene e2f2-ts-titjob2_cen with dissolve
                            tr "Cum on them [mc]!"
                            mc "Ohh, here it comes!"

                            show white with Dissolve(0.25)
                            scene e2f2-ts_64_cen
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)

                            scene e2f2-ts_65_cen with dissolve
                            pause
                            tr "Damn, that's a lot of cum."
                            mc "You know, your tits look really hot with my cum on them."
                            tr "Even hotter than with your dick between them?"
                            mc "I think they all work together to create a perfect portrait."
                            tr "Haha, alright artist!"

                            scene e2f2-ts_66_cen with dissolve
                            pause

                            scene black with Dissolve(2.0)

                    $ GameRunning = False

    if persistent.disable_nsfw == True:
        scene e2f2-ts_67 with Dissolve(2.0)
        pause

        scene e2f2-ts_68 with dissolve
        mc "So, what are you gonna do after this?"

        scene e2f2-ts_69 with dissolve
        tr "Is this an invitation to go out?"

        scene e2f2-ts_70 with dissolve
        mc "Haha, no, it wasn't a question in that sense."
        mc "But if you're up to it, sure!"

        scene e2f2-ts_71 with dissolve
        tr "Haha!"

        scene e2f2-ts_72 with dissolve
        tr "I would've liked it but unfortunately I can't."
        tr "We're gonna have to leave it for another time."

        scene e2f2-ts_70 with dissolve
        mc "Alright then, no worries."

        if e1s18_tracy_greet == True:
            mc "Hey, you know... there's been something on my mind."

            scene e2f2-ts_72 with dissolve
            tr "What's up?"

            scene e2f2-ts_70 with dissolve
            mc "When we were at Cabanna's and you lured the bouncer away."
            mc "How did you do it?"

            scene e2f2-ts_71 with dissolve
            tr "Haha, it was pretty easy!"

            scene e2f2-ts_69 with dissolve
            tr "I told him I knew a strip club nearby and could get him a lap dance from one of the girls there."

            scene e2f2-ts_72 with dissolve
            tr "He wanted me to come with him to confirm so I wouldn't just lie to keep him away."

            scene e2f2-ts_70 with dissolve
            mc "Haha, I understand."
            mc "Did he get the lap dance?"

            scene e2f2-ts_73 with dissolve
            tr "Unfortunately, the club was closed."

            scene e2f2-ts_72 with dissolve
            tr "But it doesn't really matter because it was enough time for you guys to get in."

            scene e2f2-ts_70 with dissolve
            mc "Haha, yup!"
            mc "Thank you again."

            scene e2f2-ts_72 with dissolve
            tr "Don't mention it."
        else:
            scene e2f2-ts_72 with dissolve

        tr "Well, better get dressed."
        tr "We've been away for some time now and people are probably wondering where we are."

        scene e2f2-ts_70 with dissolve
        mc "Haha, yeah!"
        mc "The guys are probably already looking for me."
    else:
        if persistent.type_nsfw == False:
            scene e2f2-ts_67_cen with Dissolve(2.0)
            pause

            scene e2f2-ts_68 with dissolve
            mc "So, what are you gonna do after this?"

            scene e2f2-ts_69_cen with dissolve
            tr "Is this an invitation to go out?"

            scene e2f2-ts_70_cen with dissolve
            mc "Haha, no, it wasn't a question in that sense."
            mc "But if you're up to it, sure!"

            scene e2f2-ts_71_cen with dissolve
            tr "Haha!"

            scene e2f2-ts_72_cen with dissolve
            tr "I would've liked it but unfortunately I can't."
            tr "We're gonna have to leave it for another time."

            scene e2f2-ts_70_cen with dissolve
            mc "Alright then, no worries."

            if e1s18_ken_greet == False and tracy_trust >= 4 or tracy_trust > sadie_trust:
                mc "Hey, you know... there's been something on my mind."

                scene e2f2-ts_72_cen with dissolve
                tr "What's up?"

                scene e2f2-ts_70_cen with dissolve
                mc "When we were at Cabanna's and you lured the bouncer away."
                mc "How did you do it?"

                scene e2f2-ts_71_cen with dissolve
                tr "Haha, it was pretty easy!"

                scene e2f2-ts_69_cen with dissolve
                tr "I told him I knew a strip club nearby and could get him a lap dance from one of the girls there."

                scene e2f2-ts_72_cen with dissolve
                tr "He wanted me to come with him to confirm so I wouldn't just lie to keep him away."

                scene e2f2-ts_70_cen with dissolve
                mc "Haha, I understand."
                mc "Did he get the lap dance?"

                scene e2f2-ts_73_cen with dissolve
                tr "Unfortunately, the club was closed."

                scene e2f2-ts_72_cen with dissolve
                tr "But it doesn't really matter because it was enough time for you guys to get in."

                scene e2f2-ts_70_cen with dissolve
                mc "Haha, yup!"
                mc "Thank you again."

                scene e2f2-ts_72_cen with dissolve
                tr "Don't mention it."
            else:
                scene e2f2-ts_72_cen with dissolve

            tr "Well, better get dressed."
            tr "We've been away for some time now and people are probably wondering where we are."

            scene e2f2-ts_70_cen with dissolve
            mc "Haha, yeah!"
            mc "The guys are probably already looking for me."

    $ e2f2_tracy_sex = True

    $ e2f2_tracy = 4

    $ optional_quests.remove("Follow Tracy to the bedroom.")

    scene e2f2-ts_74 with dissolve
    pause

    $ renpy.end_replay()

    jump e2f2_bedroom
return

# Drawer #

# Bathroom #

################################################################################

label e2f2:
    define e2f2_tracks = ["party/i_wont_fall_in_love.ogg", "party/galaxies.ogg", "party/instrumentals/2010_pop.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/piano.ogg", "party/instrumentals/random_drop.ogg","party/instrumentals/rock_this_house.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/turn_up.ogg"]
    $ renpy.music.queue (e2f2_tracks, loop=True)

    $ renpy.random.shuffle(e2f2_tracks)

    scene e2f2-st_01 with dissolve
    mc "Hey girls!"

    scene e2f2-st_45 with dissolve
    mc "What's up?"

    if e1f5_refuse_sadie == True and e2s6_talk == False:
        scene e2f2-st_02 with dissolve
        pause

        scene e2f2-st_03 with dissolve
        pause

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Hello [tr]!"

        scene e2f2-st_05 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Uhh... hello?"

        scene e2f2-st_06 with dissolve
        tr "What's going on?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "What do you mean?"

        scene e2f2-st_07 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Did you seriously not notice how fast [sd] left when she saw you?"
        tr "Or how she turned you down in class."
        tr "Or how she avoids you at all costs?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Oh, that..."
        mc "Yeah, I know."
        mc "She's been mad for a while."

        scene e2f2-st_06 with dissolve
        hide e2f2-st_tracy_blink1
        tr "What happened?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "I'm honestly surprised you two haven't talked about this."
        mc "Basically, when we were at Cabanna's, she was flirting with me."
        mc "But, I kind of refused her advances and now she doesn't want to talk to me anymore."

        scene e2f2-st_06 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Have you talked to her about this?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "The question is, can I talk to her when all she does is leave the second she sees me?"

        scene e2f2-st_08 with dissolve
        hide e2f2-st_tracy_blink1
        tr "I mean, true that."

        scene e2f2-st_06 with dissolve
        tr "Hey, I could talk to her about this matter."

        scene e2f2-st_05 with dissolve
        tr "I get you're not interested in her to have refused her, right?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        menu:
            "Interested":
                $ e2f2_sdtr_interested = True
                mc "I am interested."

                scene e2f2-st_08 with dissolve
                hide e2f2-st_tracy_blink1
                tr "You make no sense."

                scene e2f2-st_06 with dissolve
                tr "Why did you refuse her then?"

                scene e2f2-st_04 with dissolve
                show e2f2-st_tracy_blink1
                mc "I don't know, okay?"
                mc "Just didn't feel right in the moment."
                mc "I want to get to know her outside of the party environment."

            "Not interested":
                mc "Yeah, I'm not interested."
                mc "I mean, I like her as a friend and all..."
                mc "But that's about it."
                mc "I really didn't want to give her the wrong idea."

        scene e2f2-st_05 with dissolve
        hide e2f2-st_tracy_blink1
        tr "I understand."

        scene e2f2-st_06 with dissolve
        tr "Don't worry, I'll talk to her about it."

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Thank you [tr]!"
        mc "You're a life saver."

        scene e2f2-st_09 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Haha, no problem [mc]!"

        if affinity_spectrum < 0:

            $ e2f2_sadie_tracy = 1

            $ renpy.show_screen("questtracker_icon")

            $ renpy.block_rollback()

            $ current_quests.append("Interact with people.")

            scene e2f2-st_09 with Dissolve(0.1)

            jump e2f2_main
    else:
        if tracy_trust > 3:
            scene e2f2-st_10 with dissolve
            tr "[mc]!!"

            scene e2f2-st_11 with dissolve
            tr "Glad to see you've finally arrived."

        scene e2f2-st_12 with dissolve
        sd "We've been sitting on this couch ever since we got here."

        scene e2f2-st_13 with dissolve
        sd "This party is kind of boring."

        scene e2f2-st_14 with dissolve
        mc "Well, it doesn't look like many people showed up."

        scene e2f2-st_12 with dissolve
        sd "Yeah, I don't know what's up with that."
        sd "I thought [jon] invited more people."

        scene e2f2-st_14 with dissolve
        mc "He probably did but they'll show up later, who knows?"

        scene e2f2-st_15 with dissolve
        sd "Hey guys, be right back!"
        sd "I'm gonna go to the bathroom really quick."

        if affinity_spectrum > 0:
            scene e2f2-st_14 with dissolve
            mc "Alright!"

            scene e2f2-st_16 with dissolve
            pause
        else:
            scene e2f2-st_16 with dissolve
            tr "Wait for me, I'm coming too!"

            scene e2f2-st_17 with dissolve
            pause

            scene e2f2-st_23 with dissolve
            mc "*Looks like they both left, huh?*"

    if affinity_spectrum > 0:
        scene e2f2-st_18 with dissolve
        mc "So, when did you girls arrive?"

        scene e2f2-st_20 with dissolve
        tr "I think maybe half an hour ago."

        scene e2f2-st_19 with dissolve
        tr "We were told to be here by 8 PM but people didn't really take this seriously."

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Interesting..."
        mc "So, what have you been up to?"

        scene e2f2-st_06 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Not a lot really."

        scene e2f2-st_19 with dissolve
        tr "I've been approached by a couple of clubs around the college but I'm not really interested."

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Why not?"

        scene e2f2-st_19 with dissolve
        hide e2f2-st_tracy_blink1
        tr "I don't know to be honest, the options aren't that appealing."

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Have you thought about The Party Ragers?"

        scene e2f2-st_05 with dissolve
        hide e2f2-st_tracy_blink1
        tr "The party what?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "Seriously? You haven't been approached by them?"

        scene e2f2-st_06 with dissolve
        hide e2f2-st_tracy_blink1
        tr "I might have but I don't remember."

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "[jon]'s pretty much an organizer there."

        scene e2f2-st_20 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Wait, really?"

        scene e2f2-st_21 with dissolve
        show e2f2-st_tracy_blink2
        mc "Haha, yeah!"
        mc "I think it would be pretty cool if you were to join that as well."

        scene e2f2-st_19 with dissolve
        hide e2f2-st_tracy_blink1
        tr "Well, that does sound like the kind of club I would be into."

        scene e2f2-st_22 with dissolve
        tr "You know what? I'll think about it."
        tr "Thanks for the tip!"

        scene e2f2-st_21 with dissolve
        show e2f2-st_tracy_blink2
        mc "Haha, you're welcome!"

    scene e2f2-st_30 with dissolve
    pause

    play sound door_close
    scene e2f2-st_24 with dissolve
    pause

    scene e2f2-st_23 with dissolve
    mc "Hey, I think more people are showing up."

    scene e2f2-st_25 with dissolve
    pause

    scene e2f2-st_26 with dissolve
    sd "What are you doing here?"

    scene e2f2-st_27 with dissolve
    sp "What are {b}you{/b} doing here?"

    scene e2f2-st_28 with dissolve
    sp "I heard about this house party and wanted to have a little bit of fun."

    scene e2f2-st_29 with dissolve
    sd "So what?"
    sd "Does that mean that you have to be at every party I'm at?"

    scene e2f2-st_31 with dissolve
    sd "God damn it, you're so childish."

    scene e2f2-st_29 with dissolve
    sd "Stop following me around or I'll call the cops."

    scene e2f2-st_28 with dissolve
    sp "Oh, don't worry."
    sp "I'm not following you."

    scene e2f2-st_32 with dissolve
    pause

    scene e2f2-st_33 with dissolve
    if affinity_spectrum > 0:
        tr "Hey, is that [sp]?"

        scene e2f2-st_05 with dissolve
        tr "What is he doing here?"

        scene e2f2-st_04 with dissolve
        show e2f2-st_tracy_blink1
        mc "I don't know, he just showed up out of the blue!"

        scene e2f2-st_19 with dissolve
        hide e2f2-st_tracy_blink1
        tr "I'm gonna go and check up on [sd], be right back."

        scene e2f2-st_35 with dissolve
        pause
    else:
        pause

    scene e2f2-st_34 with dissolve
    pause

    scene e2f2-st_36 with dissolve
    mc "*What the hell is this guy doing here...*"

    scene e2f2-st_37 with dissolve
    pause

    scene e2f2-st_38 with dissolve
    mc "*Wait, is he leaving already?*"

    scene e2f2-st_39 with dissolve
    mc "*That's weird...*"

    scene e2f2-st_40 with dissolve
    pause

    scene e2f2-st_41 with dissolve
    if affinity_spectrum > 0:
        mc "*Let me check what's going on.*"

        scene e2f2-st_42 with dissolve
        pause

        scene e2f2-st_43 with dissolve
        mc "Hey [tr], what's up?"

        scene e2f2-st_44 with dissolve
        show e2f2-st_tracy_blink3
        mc "Where's [sd]?"

        scene e2f2-st_47 with dissolve
        hide e2f2-st_tracy_blink3
        tr "She just left."

        scene e2f2-st_46 with dissolve
        tr "I wanted to convince her to stay but she didn't want to be in the same room as [sp]."

        scene e2f2-st_44 with dissolve
        show e2f2-st_tracy_blink3
        mc "That's something that I can understand."
        mc "But didn't [sp] leave as well?"

        scene e2f2-st_47 with dissolve
        hide e2f2-st_tracy_blink3
        tr "Yeah, he did."

        scene e2f2-st_46 with dissolve
        tr "That's what's weirder."

        scene e2f2-st_48 with dissolve
        tr "It's like he only came here to annoy her."

        scene e2f2-st_44 with dissolve
        show e2f2-st_tracy_blink3
        mc "Yeah!"

        scene e2f2-st_49 with dissolve
        hide e2f2-st_tracy_blink3
        tr "I'm gonna go outside for a little."
        tr "See if I can catch up to her and make her stay."

        scene e2f2-st_44 with dissolve
        show e2f2-st_tracy_blink3
        mc "Alright, see you later!"

        scene e2f2-st_50 with dissolve
        hide e2f2-st_tracy_blink3
        pause

        $ e2f2_tracy = 1

        $ renpy.show_screen("questtracker_icon")

        $ renpy.block_rollback()

        $ current_quests.append("Interact with people.")

        play sound door_close
        scene e2f2-st_51 with dissolve
        pause

        jump e2f2_main
        hide e2f2-main
    else:
        pass

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")

    scene e2f2-st_41 with Dissolve(0.1)

    jump e2f2_main
    hide e2f2-main
return
