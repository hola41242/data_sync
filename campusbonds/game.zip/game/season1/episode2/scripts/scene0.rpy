
image e2s0_text = ParameterizedText(xalign=0.5, yalign=0.5, font="fonts/celebes_light.otf", textalign = 0.5, size=40,)

# Scene 0 - Flashback ##########################################################

label e2s0:

    $ renpy.block_rollback()
    $ config.rollback_enabled = False

    hide screen recap_skip
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(2.0)

    $ config.rollback_enabled = True

    play crowd_normal "audio/sfx/crowded_venue.ogg" fadein 1.0
    scene e2s0-01 with Dissolve(2.0)
    play music coalescense
    pause

    scene e2s0-02 with dissolve
    pause

    scene e2s0-03 with dissolve
    pause

    scene e2s0-04 with vpunch
    ref "FIGHT!"

    scene e2s0-05 with dissolve

    if persistent.tutorial == True:
        show tutorial_background_menu with wiperight
        show dialogue_box with wiperight
        show e2s0_text "This is a Quick Time Event. \n This is how the in-game fighting will take place." with wiperight
        pause

        hide e2s0_text with wipeleft
        show e2s0_text "During this state of the game, you'll need \n to press the corresponding key displayed on the screen." with wiperight
        pause

        hide e2s0_text with wipeleft
        show e2s0_text "Keep an eye on the timer, as you must hit \n the key before time runs out." with wiperight
        pause

        hide e2s0_text with wipeleft
        call screen e2s0_combat with wiperight
        if persistent.fight == 0:
            hide screen e2s0_combat with wipeleft
            call screen e2s0_combat_input with wiperight

            hide screen e2s0_combat_input with wipeleft
            call screen e2s0_difficulty with wiperight

        hide e2s0_text with wipeleft
        hide dialogue_box with wipeleft
        hide tutorial_background_menu with wipeleft

    if persistent.fight == 0:

        $ time_start = 0
        $ time_max = 1.0
        $ time_max = 0.01

        call qte from _call_qte

        if qte == True:
            play sound punch
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            scene e2s0-06 with vpunch
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_1
        else:
            play sound punch
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            show miss_screen at miss_anim
            show e2s0-46 behind miss_screen with vpunch
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_2

        if qte == True:
            play sound punch
            scene e2s0-07 with vpunch
            hide e2s0-46
            pause(1.0)
        else:
            play sound punch
            show miss_screen at miss_anim
            show e2s0-47 behind miss_screen with vpunch
            hide e2s0-46
            pause(1.0)

        play crowd_normal "audio/sfx/crowded_venue.ogg" fadein 1.0
        scene e2s0-08 with dissolve
        stop crowd_cheering fadeout 1.0
        pause(1.0)

        scene e2s0-09 with dissolve
        call qte from _call_qte_3

        if qte == True:
            play sound punch
            scene e2s0-48 with vpunch
            hide e2s0-47
            call qte from _call_qte_4
        else:
            play sound woosh
            show miss_screen at miss_anim
            show e2s0-10 behind miss_screen with vpunch
            hide e2s0-47
            call qte from _call_qte_5

        if qte == True:
            play sound punch
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            scene e2s0-49 with vpunch
            hide e2s0-10
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_6
        else:
            play sound punch
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            show miss_screen at miss_anim
            show e2s0-11 behind miss_screen with vpunch
            hide e2s0-10
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_7

        if qte == True:
            play sound punch
            scene e2s0-50 with vpunch
            hide e2s0-11
            pause(1.0)
        else:
            play sound punch
            show miss_screen at miss_anim
            show e2s0-12 behind miss_screen with vpunch
            hide e2s0-11
            pause(1.0)

        play sound punch
        scene e2s0-13 with vpunch
        hide e2s0-12
        pause(1.0)

        scene e2s0-14 with dissolve
        call qte from _call_qte_8

        if qte == True:
            play sound punch
            scene e2s0-15 with vpunch
            call qte from _call_qte_9
        else:
            play sound woosh
            show miss_screen at miss_anim
            show e2s0-17 behind miss_screen with vpunch
            pause(1.0)
            $ qte_stop = True

        if qte_stop == False:
            if qte == True:
                play sound punch
                scene e2s0-16 with vpunch
                call qte from _call_qte_10
            else:
                play sound woosh
                show miss_screen at miss_anim
                show e2s0-17 behind miss_screen with vpunch
                pause(1.0)
                $ qte_stop = True

            if qte_stop == False:
                if qte == True:
                    play sound punch
                    scene e2s0-15 with vpunch
                    call qte from _call_qte_11
                else:
                    play sound woosh
                    show miss_screen at miss_anim
                    show e2s0-17 behind miss_screen with vpunch
                    pause(1.0)
                    $ qte_stop = True

                if qte_stop == False:
                    if qte == True:
                        play sound punch
                        scene e2s0-16 with vpunch
                        pause(1.0)

                        play sound woosh
                        scene e2s0-17 with dissolve
                        pause(1.0)
                    else:
                        play sound woosh
                        show miss_screen at miss_anim
                        show e2s0-17 behind miss_screen with vpunch
                        pause(1.0)
    else:
        pause

        play sound punch
        play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
        scene e2s0-06 with vpunch
        stop crowd_normal fadeout 1.0
        pause

        play sound punch
        scene e2s0-07 with vpunch
        hide e2s0-46
        pause

        play crowd_normal "audio/sfx/crowded_venue.ogg" fadein 1.0
        scene e2s0-08 with dissolve
        stop crowd_cheering fadeout 1.0
        pause

        scene e2s0-09 with dissolve
        pause

        play sound woosh
        scene e2s0-10 with vpunch
        pause

        play sound punch
        play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
        scene e2s0-11 with vpunch
        stop crowd_normal fadeout 1.0
        pause

        play sound punch
        scene e2s0-12 with vpunch
        pause

        play sound punch
        scene e2s0-13 with vpunch
        pause

        scene e2s0-14 with dissolve
        pause

        play sound punch
        scene e2s0-15 with vpunch
        pause

        play sound punch
        scene e2s0-16 with vpunch
        pause

        play sound punch
        scene e2s0-15 with vpunch
        pause

        play sound punch
        scene e2s0-16 with vpunch
        pause

        play sound woosh
        scene e2s0-17 with vpunch
        pause

    scene e2s0-18 with dissolve
    hide e2s0-17
    pause

    scene e2s0-19 with dissolve
    pause

    play crowd_normal "audio/sfx/crowded_venue.ogg" fadein 1.0
    scene e2s0-20 with dissolve
    stop crowd_cheering fadeout 1.0
    ref "Back to your corners, gentlemen!"

    scene e2s0-21 with dissolve
    pause

    scene e2s0-22 with dissolve
    ref "Alright, gentlemen!"
    ref "Rest time's up."

    scene e2s0-23 with dissolve
    ref "Let's go!"

    scene e2s0-24 with dissolve
    ref "You ready?"
    mc "Ready!"

    scene e2s0-25 with dissolve
    ref "You ready?"
    unknown "Ready!"

    scene e2s0-24 with dissolve
    ref "Now, gentlemen, I want a clean fight!"

    scene e2s0-25 with dissolve
    ref "No illegal shots!"

    scene e2s0-24 with dissolve
    ref "Keep your guard up at all times..."

    scene e2s0-25 with dissolve
    ref "...and may the best man win!"

    scene e2s0-26 with vpunch
    ref "FIGHT!"

    scene e2s0-27 with dissolve

    if persistent.fight == 0:
        call qte from _call_qte_12

        if qte == True:
            play sound woosh
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            scene e2s0-28 with vpunch
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_13
        else:
            play sound punch
            play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
            show miss_screen at miss_anim
            show e2s0-51 behind miss_screen with vpunch
            stop crowd_normal fadeout 1.0
            call qte from _call_qte_14

        if qte == True:
            play sound punch
            scene e2s0-29 with vpunch
            hide e2s0-51
            pause(1.0)
        else:
            play sound punch
            show miss_screen at miss_anim
            show e2s0-52 behind miss_screen with vpunch
            hide e2s0-51
            pause(1.0)

        if qte_pos_count > qte_neg_count:
            $ e2s0_fight = True
        else:
            $ e2s0_fight = False

        if qte_neg_count == 0:
            $ strength += 1
            if persistent.sd_gallery_8_unlocked == False:
                $ persistent.sd_gallery_8_unlocked = True
                $ renpy.show_screen("render_notify")
                $ persistent.sadie8 = True
                python:
                    update_sadie_list()
    else:
        play sound woosh
        play crowd_cheering "audio/sfx/crowd_cheering.ogg" fadein 1.0
        scene e2s0-28 with vpunch
        stop crowd_normal fadeout 1.0
        pause

        play sound punch
        scene e2s0-29 with vpunch
        pause

    play sound punch
    scene e2s0-30 with vpunch
    hide e2s0-52
    pause(1.0)

    scene e2s0-31 with dissolve
    pause(1.0)

    scene e2s0-32 with dissolve
    pause

    scene e2s0-33 with dissolve
    pause

    scene e2s0-34 with dissolve
    pause

    scene e2s0-35 with dissolve
    pause

    scene e2s0-36 with dissolve
    pause

    scene e2s0-37 with dissolve
    pause

    play sound woosh
    scene e2s0-38 with dissolve
    pause

    scene e2s0-39 with dissolve
    pause

    scene e2s0-40 with dissolve
    pause

    scene e2s0-41 with dissolve
    pause

    scene e2s0-42 with dissolve
    pause

    scene e2s0-43 with dissolve
    pause

    scene e2s0-44 with dissolve
    pause

    scene e2s0-45 with dissolve
    pause

    play sound punch
    stop music fadeout 4.0
    stop crowd_cheering fadeout 1.0
    scene white with dissolve
    stop crowd_normal fadeout 1.0
    pause(2.0)

    $ qte_pos_count = 0
    $ qte_neg_count = 0

    jump e2s1
return

init python:
    style.difficulty_button = Style(style.default)
    style.difficulty_button.font = "fonts/celebes_light.otf"
    style.difficulty_button.size = 35

screen e2s0_difficulty:
    vbox:
        xalign 0.5
        yalign 0.5
        text "Choose your difficulty:":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
        textbutton "Easy":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action SetVariable("persistent.fight_difficulty", 0)
        textbutton "Medium":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action SetVariable("persistent.fight_difficulty", 1)
        textbutton "Hard":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action SetVariable("persistent.fight_difficulty", 2)
        textbutton "Confirm":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action [Hide("e2s0_difficulty", wipeleft), Return()]
        text "(This can also be changed in the menu later on.)":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
return

screen e2s0_combat:
    vbox:
        xalign 0.5
        yalign 0.5
        text "Do you want combat on?":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
        hbox:
            xalign 0.5
            textbutton "Yes":
                style "difficulty_button"
                xalign 0.5
                yalign 0.5
                action SetVariable("persistent.fight", 0)
            null width 50
            textbutton "No":
                style "difficulty_button"
                xalign 0.5
                yalign 0.5
                action SetVariable("persistent.fight", 1)
        textbutton "Confirm":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action [Hide("e2s0_combat", wipeleft), Return()]
        text "(This can also be changed in the menu later on.)":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
return

screen e2s0_combat_input:
    vbox:
        xalign 0.5
        yalign 0.5
        text "What input do you prefer?":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
        hbox:
            xalign 0.5
            textbutton "Keyboard":
                style "difficulty_button"
                xalign 0.5
                yalign 0.5
                action SetVariable("persistent.fight_input", 0)
            null width 50
            textbutton "Mouse":
                style "difficulty_button"
                xalign 0.5
                yalign 0.5
                action SetVariable("persistent.fight_input", 1)
        textbutton "Confirm":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            action [Hide("e2s0_combat", wipeleft), Return()]
        text "(This can also be changed in the menu later on.)":
            style "difficulty_button"
            xalign 0.5
            yalign 0.5
            textalign 0.5
return
