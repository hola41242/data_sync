
# Episode 2 Recap ##############################################################

label e2re:
    $ quick_menu = True
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    show screen recap_skip
    play music careful
    show text "{size=80}Previously, on Campus Bonds...{/size}"
    pause(1.0)

    scene e2s4-48 with wipeleft
    jon "I'M GOING TO INVITE YOU TO A GROUP CALLED THE PARTY RAGERS.{w=1.2}{nw}"

    scene e2s4-49 with dissolve
    mc "Party ragers?{w=0.7}{nw}"

    scene e2s1-81 with wiperight
    mc "*Is that [fr]?*{w=0.7}{nw}"

    scene e2s1-83 with dissolve
    show e2s1_francesca_blink1
    mc "How long are you gonna ignore me for?{w=1.0}{nw}"

    scene e2s3-12 with dissolve
    fr "I don't want to hurt you, [mc].{w=0.8}{nw}"

    scene e2s3-13 with dissolve
    fr "There are some things that I can't really explain to you right now.{w=1.4}{nw}"

    scene e2s9-75 with wipeleft
    unknown "I'll show you who's the shit head!{w=1.1}{nw}"

    play sound punch
    scene e2s9-76 with vpunch
    pause(1.0)

    scene e2s9-91 with dissolve
    no "I want you all gone, right now!{w=0.9}{nw}"
    no "Come on, everyone out, the party is over!{w=1.2}{nw}"

    scene e2s7-55 with wiperight
    jon "What the fuck are you guys doing?{w=0.9}{nw}"
    jon "Stop playing these pussy ass games, let's get going!{w=1.2}{nw}"

    scene e2s7-56 with dissolve
    ke "Fuck you, [ro]!{w=0.7}{nw}"

    scene e2f1-al_02 with wipeleft
    show e2f1-alice_blink1
    mc "*Is she not hearing me?*{w=0.7}{nw}"

    scene e2f1-al_03 with dissolve
    hide e2f1-alice_blink1
    mc "*Hmm... what should the note say?*{w=0.8}{nw}"

    if e2f1_alice_note == 0:
        scene e2f1-al_06 with dissolve
        al "You look really sweet when you read.{w=0.8}{nw}"

        scene e2f1-al_07 with dissolve
        al "Aww, thank you!{w=0.7}{nw}"
    if e2f1_alice_note == 1:
        scene e2f1-al_06 with dissolve
        al "Didn't want to bother you so I left this note.{w=1.0}{nw}"

        scene e2f1-al_08 with dissolve
        al "This is so nice, thank you!{w=0.7}{nw}"
    if e2f1_alice_note == 2:
        scene e2f1-al_06 with dissolve
        al "I took the liberty of stealing your stuff, I hope you don't mind.{w=1.3}{nw}"

        scene e2f1-al_09 with dissolve
        al "I don't really get it but fine.{w=0.8}{nw}"

    scene e1s14-79 with wiperight
    sp "I should have known that he's not a trustworthy source from the moment I saw him hanging out with my brother...{w=2.5}{nw}"

    scene e2s13-03 with wipeleft
    show e2s13-jon_blink1
    if affinity_spectrum > 0:
        mc "What the hell bro, are you getting married?{w=1.1}{nw}"
    else:
        mc "Where are you going?{w=0.7}{nw}"

    scene e2s13-06 with dissolve
    hide e2s13-jon_blink1
    jon "It's for [ke]'s party.{w=0.7}{nw}"

    scene e2s13-09 with dissolve
    mc "Wait, he's rich?{w=0.7}{nw}"

    scene e2s9-25 with wipeleft
    mc "*Don't tell me I lost them... fuck!*{w=0.8}{nw}"

    scene e2s9-27 with dissolve
    mc "*Where the fuck are those keys?*{w=0.8}{nw}"

    if e2s9_francesca_call == True:
        scene e2s9-35 with dissolve
        fr "Why are you calling me this late at night?{w=0.8}{nw}"

        scene e2s9-37 with dissolve
        if e2s9_francesca_lie == False:
            if e2s3_hangout == True:
                mc "I couldn't get to our date because I was busy going to a party...{w=1.0}{nw}"
            else:
                mc "So, I went to a party...{w=0.7}{nw}"
        else:
            scene e2s9-37 with dissolve
            mc "I got locked out of my dorm!{w=0.7}{nw}"

        scene e2s9-34 with dissolve
        show e2s10-francesca_blink1
        mc "Please [fr], just this once!{w=0.7}{nw}"

        if e2s10_francesca == False:
            scene e2s9-38 with dissolve
            hide e2s10-francesca_blink1
            fr "Well, can't your friends help you?{w=0.7}{nw}"
        else:
            scene e2s10_fr-05 with dissolve
            hide e2s10-francesca_blink1
            fr "Come on in.{w=0.7}{nw}"
    if e2s10_sadie == True:
        scene e2s9-37 with dissolve
        mc "So... you know the party we went to, right?{w=0.8}{nw}"

        scene e2s9-31 with dissolve
        mc "I lost my dorm keys.{w=0.7}{nw}"

        scene e2s9-33 with dissolve
        sd "Let me guess, you want to crash at my place.{w=0.8}{nw}"

        if e2s10_sadie_sex == True:
            scene e2s10_sd-kiss1 with dissolve
            pause(1.0)
    if e2s10_jon == True:
        scene e2s9-57 with dissolve
        jon "Got lost on the way home?{w=0.7}{nw}"

        scene e2s9-61 with dissolve
        jon "Me and the guys are out drinking.{w=0.7}{nw}"

        scene e2s9-55 with dissolve
        jon "Do you wanna join us?{w=0.7}{nw}"

        scene e2s10_jon-30 with dissolve
        jon "I've got a good idea to end this night on a high note.{w=1.0}{nw}"

        if e2s10_seduce == True:
            scene e2s10_jon-32 with dissolve
            mc "I'm in!{w=0.7}{nw}"

            scene e2s10_jon-06 with dissolve
            mc "*Oh, what the f...*{w=0.7}{nw}"
            mc "*Our math teacher, in a club?*{w=0.8}{nw}"
        else:
            scene e2s10_jon-32 with dissolve
            mc "Sorry guys... I'm out.{w=0.7}{nw}"

    scene e2s11-86 with wiperight
    mc "My keys?{w=0.7}{nw}"
    mc "How do you have them?{w=0.7}{nw}"

    scene e2s11-89 with dissolve
    sc "You could perhaps help me with some information...{w=1.0}{nw}"

    scene e2s12-28 with wipeleft
    unknown "They hire the worst fucking bike handles in this dump.{w=1.2}{nw}"

    scene e2s12-29 with dissolve
    mc "*What's wrong with that guy?*{w=0.8}{nw}"

    if e2s12_fight == True:
        scene e2s12-34 with dissolve
        unknown "Maybe you should be taught a lesson.{w=1.0}{nw}"
        mc "Alright fuck face, bring it on!{w=1.0}{nw}"

        scene e2s12-58 with dissolve
        da "Enough, break it up!{w=0.7}{nw}"

        scene e2s12-67 with dissolve
        cl "Just leave!{w=0.7}{nw}"

    scene e2s14-15 with wiperight
    mc "*Huh?*{w=0.7}{nw}"
    mc "*Is that [ov]?*{w=0.7}{nw}"

    scene e2s14-27 with dissolve
    show e2s14-olivia_blink1
    mc "Wait a minute...{w=0.7}{nw}"
    mc "You guys are cousins?{w=0.7}{nw}"

    scene e2s14-30 with dissolve
    hide e2s14-olivia_blink1
    jon "We're gonna have a photoshoot.{w=0.7}{nw}"

    scene e2s14-42 with dissolve
    mc "Alright, coming!{w=0.7}{nw}"

    jump e3s0
return
