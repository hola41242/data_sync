
# Scene 4 - Unexpected guest (Friday) ##########################################

label e2s4:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e2s4-01 with Dissolve(2.0)
    pause

    scene e2s4-02 with dissolve
    pause

    scene e2s4-03 with dissolve
    pause

    scene e2s4-04
    pause

    define e2s4_tracks = ["college_rock.ogg", "marathon_man.ogg"]
    $ renpy.music.queue (e2s4_tracks, loop=True)
    scene e2s4-05 with dissolve
    mc "[jon]...?"

    scene e2s4-06 with dissolve
    pause

    scene e2s4-07 with dissolve
    jon "[mc], wake up!!"

    scene e2s4-08 with dissolve
    jon "Come on, how long are you gonna sleep for?"
    mc "What the..."

    scene e2s4-09 with dissolve
    mc "How did you get in here?"

    scene e2s4-10 with dissolve
    jon "First of all, it's not about the 'how', it's more about the 'when'."

    scene e2s4-11 with dissolve
    jon "And besides, you left your window open dumbass!"

    scene e2s4-12 with dissolve
    mc "I didn't..."

    scene e2s4-10 with dissolve
    jon "Do you have my notes?"

    scene e2s4-13 with dissolve
    show e2s4-jon_blink1
    mc "Yeah, they're on the table."

    scene e2s4-10 with dissolve
    hide e2s4-jon_blink1
    jon "Forget them."

    scene e2s4-14 with dissolve
    jon "Come on, change of plans."
    jon "We've gotta talk."

    scene e2s4-15 with dissolve
    nt "Can you do this somewhere else, please?"
    nt "I'm trying to get some sleep here."

    scene e2s4-16 with wipeleft
    mc "So, what's up bro?"

    scene e2s4-17 with dissolve
    mc "Why did you feel the need to wake me up at this hour of the day?"

    scene e2s4-18 with dissolve
    jon "Dude, you don't sleep that much!"

    scene e2s4-19 with dissolve
    jon "Especially when you're in college."

    scene e2s4-20 with dissolve
    jon "We're having another party tonight."

    scene e2s4-21 with dissolve
    mc "Another one?"
    mc "But we just went to one."

    scene e2s4-22 with dissolve
    jon "You're in college bro!"
    jon "Get used to it."

    scene e2s4-23 with dissolve
    jon "Besides, you went to a party, I didn't."
    jon "We're gonna have to do something about that."

    scene e2s4-24 with dissolve
    mc "What do you have in mind?"

    scene e2s4-25 with dissolve
    jon "Let's leave this aside for a moment."
    jon "First of all..."

    scene e2s4-26 with dissolve
    jon "I'd like to present you the biggest best oportunity you've ever had since you joined this college."

    scene e2s4-27 with dissolve
    mc "Not me who joined a couple of days ago."

    scene e2s4-28 with dissolve
    jon "Dude, shut up."

    scene e2s4-29 with dissolve
    jon "You're gonna start receiving a lot of invitations to different clubs."

    scene e2s4-30 with dissolve
    jon "Now's the time when everyone is basically settled in."
    jon "So the group leaders will send their little pawns to do the dirty work."

    scene e2s4-31 with dissolve
    mc "Dirty work?"

    scene e2s4-32 with dissolve
    jon "Yeah man!"

    scene e2s4-33 with dissolve
    jon "With invites and stuff."

    scene e2s4-34 with dissolve
    jon "You really aren't good at this."

    scene e2s4-35 with dissolve
    jon "Alright, where was I?"

    scene e2s4-36 with dissolve
    mc "You were about to present me the biggest best oportunity of my life."

    scene e2s4-37 with dissolve
    jon "I like that!"
    jon "That's the spirit."
    jon "We should keep that."

    scene e2s4-38 with dissolve
    jon "Biggest best oportunity of your 'life'."

    scene e2s4-39 with dissolve
    mc "What are you talking about?"

    scene e2s4-40 with dissolve
    jon "Do you remember when I told you that I was invited to plan the party at Eddy's?"

    scene e2s4-41 with dissolve
    mc "Yeah?"

    scene e2s4-42 with dissolve
    jon "I lied!"

    scene e2s4-43 with dissolve
    jon "Well, technically, it wasn't a complete lie."

    scene e2s4-44 with dissolve
    jon "There really was a girl that introduced me to those people."

    scene e2s4-45 with dissolve
    jon "The point is that..."

    $renpy.sound.play("audio/sfx/drumrolls_loop.ogg", loop=True)
    scene e2s4-46 with dissolve
    jon "Drum rolls..."

    scene e2s4-47 with dissolve
    pause

    play sound drumrolls_end
    scene e2s4-48 with dissolve
    jon "I'M GOING TO INVITE YOU TO A GROUP CALLED THE PARTY RAGERS."

    scene e2s4-49 with dissolve
    mc "Party ragers?"

    scene e2s4-50 with dissolve
    jon "Dude, you don't get it."

    scene e2s4-51 with dissolve
    jon "I've waited for so long to tell you about this."

    scene e2s4-52 with dissolve
    jon "They have their stupid policies where the freshies shouldn't know about it until the first party."

    scene e2s4-53 with dissolve
    mc "But the first party wasn't technically held."

    scene e2s4-54 with dissolve
    jon "You might be right on that regard."

    scene e2s4-55 with dissolve
    jon "Except that you aren't."
    mc "What the..."

    scene e2s4-56 with dissolve
    jon "The party at Cabanna's was still organised by us."

    scene e2s4-57 with dissolve
    jon "The guys agreed to count that as the first party of the year."

    scene e2s4-58 with dissolve
    mc "First party of the year?"
    mc "What if someone holds a party before you guys?"
    mc "Would that still count as the first party of the year?"

    scene e2s4-59 with dissolve
    jon "I mean... not really."
    jon "But the chances of that happening are pretty low."

    scene e2s4-60 with dissolve
    jon "Plus, we're the ones known for parties."

    scene e2s4-61 with dissolve
    mc "But you've said that everyone is invited although nobody knows about it."

    scene e2s4-62 with dissolve
    jon "I lied again!"

    scene e2s4-63 with dissolve
    jon "Haha, life's good."

    scene e2s4-64 with dissolve
    jon "Everyone agreed that we shouldn't tell freshies about this."
    jon "Only if we have some cool freshie friends who we can vouch for."

    scene e2s4-65 with dissolve
    jon "That's why it's such a secret."

    scene e2s4-66 with dissolve
    jon "The party ragers is amongst the most popular groups of this college."

    scene e2s4-67 with dissolve
    jon "If you were to ask any person who's at least year 2 everyone would tell you about them."

    scene e2s4-68 with dissolve
    jon "But yeah, of course, they don't let everyone in."
    jon "They want to have some kind of organization."

    scene e2s4-69 with dissolve
    jon "But, but..."
    jon "Here's the best part."

    scene e2s4-70 with dissolve
    jon "I can help you get in!"
    jon "Isn't that awesome?"

    scene e2s4-71 with dissolve
    mc "How exactly would you do that?"

    scene e2s4-72 with dissolve
    jon "I'm going to explain all of this later."
    jon "It's gonna be pretty fucking exciting, trust me."

    scene e2s4-73 with dissolve
    mc "So, where are we going?"

    stop music fadeout 2.0
    scene e2s4-74 with dissolve
    jon "You'll see."

    jump e2s5
return
