
# Scene 1 - After party (Thursday) #############################################

label e2s1:
    pause(1.0)

    play music mom_n_pa
    scene e2s1-01 with Dissolve(2.0)
    pause

    play sound door_open
    scene e2s1-02 with dissolve
    pause

    play sound door_close
    scene e2s1-03 with dissolve
    mc "Uhh... [nt]?"

    scene e2s1-04 with dissolve
    pause

    play sound wood_hit
    scene e2s1-05 with vpunch
    nt "Shit!"

    scene e2s1-06 with dissolve
    nt "[mc], hello!"

    scene e2s1-07 with dissolve
    mc "What's up?"

    scene e2s1-06 with dissolve
    nt "How did I end up under the bed?"

    scene e2s1-07 with dissolve
    mc "You ask me?"

    scene e2s1-08 with dissolve
    nt "Fuck... I drank so much last night."

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "Didn't you say you wouldn't?"

    scene e2s1-10 with dissolve
    hide e2s1_nate_blink1
    nt "Well... one drink led to another and..."

    play music aux_intro_cut
    scene e2s1-11
    nt "Oh yeah!"

    scene e2s1-12 with dissolve
    nt "Who likes to party?"

    scene e2s1-13 with dissolve
    nt "Maybe you?"

    scene e2s1-14 with dissolve
    nt "Or you?"

    scene e2s1-15 with dissolve
    nt "Hey guys, check out this trick!"

    play sound clothes_rip
    scene e2s1-16 with dissolve
    pause

    play sound punch
    scene e2s1-17 with vpunch
    bo "ALRIGHT, THAT'S ENOUGH!"

    scene e2s1-18 with dissolve
    pause

    scene e2s1-19 with dissolve
    nt "I'll live to drink another day!"

    scene e2s1-20 with dissolve
    pause

    play sound punch
    scene e2s1-21 with vpunch
    pause

    scene e2s1-22 with dissolve
    nt "ZzZzZz..."

    play music mom_n_pa
    scene e2s1-10 with dissolve
    nt "Yeah..."

    scene e2s1-23 with dissolve
    nt "Also, where were you bro?"

    scene e2s1-24 with dissolve
    nt "One second you were there, the next you were gone!"

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "Yeah, sorry man."
    mc "I went to help my friend [jon]!"
    mc "Figured he needed my help."

    scene e2s1-24 with dissolve
    hide e2s1_nate_blink1
    nt "Oh, I see!"

    scene e2s1-23 with dissolve
    nt "What did you find out?"

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "Well..."

    scene e2s1-25
    hide e2s1_nate_blink1
    mc "So, who would you guys say did this?"

    scene e2s1-26 with dissolve
    jon "Well, we're gonna start to narrow down the number of suspects."

    scene e2s1-27 with dissolve
    ke "I don't think any of the freshmen did this."

    scene e2s1-28 with dissolve
    ke "Who would be this stupid to do such a thing..."

    scene e2s1-27 with dissolve
    ke "...and also have the kind of connections to be able to trash such a party without leaving any trace."

    scene e2s1-29 with dissolve
    jd "Yeah, no freshman did this."

    scene e2s1-30 with dissolve
    jd "Whoever did this must have really hated this place."

    scene e2s1-31 with dissolve
    jon "Why would anyone hate this place..."

    scene e2s1-32 with dissolve
    mc "Maybe you don't know people all that well [jon]."

    scene e2s1-33 with dissolve
    jon "Hey, why are you saying this like they were my enemies?"

    scene e2s1-26 with dissolve
    jon "What if the person that did this came from someone else?"

    scene e2s1-27 with dissolve
    ke "Hey, good point!"

    scene e2s1-29 with dissolve
    jd "There's so many possible suspects, it's gonna take forever to find the culprit!"

    scene e2s1-26 with dissolve
    jon "Not if we find something that would trace them down."

    scene e2s1-25 with dissolve
    mc "Let's hope we're gonna find something..."

    scene e2s1-26 with dissolve
    jon "We're gonna have to call the investors tomorrow morning."
    jon "Tell them about what happened here..."

    scene e2s1-25 with dissolve
    mc "Wait, you have investors?"

    scene e2s1-33 with dissolve
    jon "Of course, dude!"
    jon "How do you think we managed to organise this party?"
    jon "I don't have enough pennies to do a party like this."

    scene e2s1-32 with dissolve
    mc "Shut up bro, my back still hurts after counting those pennies!"
    mc "My brain too!"

    scene e2s1-34 with dissolve
    jon "Haha, what a good life!"

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "Whoever did this must have been older."
    mc "And also, must have probably really hated that place."
    mc "They are going to investigate all of the possible suspects."
    mc "And hopefully find the culprits."

    scene e2s1-24 with dissolve
    hide e2s1_nate_blink1
    nt "Damn, this really sucks!"

    scene e2s1-23 with dissolve
    nt "Are there any guys that were perhaps rejected?"
    nt "So they wanted to trash the whole thing?"

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "Could be, but at the same time the number of people invited was really low."
    mc "And, as [jon] said, it's not something that was widely known."
    mc "So, who knows?"
    mc "Your theory is not completely ruled out."

    scene e2s1-08 with dissolve
    nt "Yeah..."

    scene e2s1-09 with dissolve
    show e2s1_nate_blink1
    mc "I'm gonna get changed."
    mc "I've got some classes to attend later."

    scene e2s1-23 with dissolve
    hide e2s1_nate_blink1
    nt "Alright, take care!"

    scene e2s1-93 with dissolve
    pause

    scene e2s1-94 with dissolve
    play sound phone_buzz
    pause

    scene e2s1-95 with dissolve
    pause

    nvl clear

    scene e2s1-96 with dissolve
    un_nvl "Hello [mc]!"
    un_nvl "This is [ke]."
    un_nvl "[jon] gave me your phone number."
    un_nvl "I was wondering if you'd like to attend my birthday party on Sunday this week."
    un_nvl "Also, sorry for the late invitation but I couldn't find the time to tell you."
    n_nvl "Hey [ke]!"
    n_nvl "It's alright, don't worry."
    n_nvl "Thanks for the invitation, yeah, I will attend your birthday party."
    un_nvl "Great! I will send you all of the details later about the location and everything."
    un_nvl "Peace!"

    scene e2s1-97 with dissolve
    pause

    scene e2s1-96 with dissolve
    mc "*Wait, let me save his number.*"

    stop music fadeout 2.0
    scene e2s1-35 with dissolve
    pause

    play music circles
    scene e2s1-36 with wipeleft
    pause

    scene e2s1-37 with dissolve
    mc "Hey [cl]!"

    scene e2s1-39 with dissolve
    cl "[mc], what's up?"

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Just walking to class."
    mc "What about you?"

    scene e2s1-40 with dissolve
    hide e2s1_cleo_blink1
    cl "I'm heading down to the library to grab a couple of books for my history test."

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Oh, a history test?"

    scene e2s1-39 with dissolve
    hide e2s1_cleo_blink1
    cl "Yup! I personally love history."

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Didn't the guide bore you on the first day of college?"

    scene e2s1-41 with dissolve
    hide e2s1_cleo_blink1
    cl "Yeah, there's a difference [mc]!"

    scene e2s1-42 with dissolve
    cl "When it is presented as a story and people talk about it passionately..."

    scene e2s1-43 with dissolve
    cl "...then it becomes beautiful and interesting!"

    scene e2s1-44 with dissolve
    cl "Just like a flower!"

    scene e2s1-45 with dissolve
    cl "If you take good care of it, the flower will bloom!"

    scene e2s1-46 with dissolve
    cl "But if you don't look after it and you're not caring enough, it will wither."

    scene e2s1-47 with dissolve
    cl "If there's no passion in it, it quickly becomes boring and uninteresting."

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "I haven't thought about this before."

    scene e2s1-40 with dissolve
    hide e2s1_cleo_blink1
    cl "This can work on almost everything, if there's passion then anything is doable."

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Haha, you're such a walking positive!"

    scene e2s1-48 with dissolve
    hide e2s1_cleo_blink1
    cl "By the way, tomorrow we're having a test."

    scene e2s1-49 with dissolve
    show e2s1_cleo_blink2
    mc "Huh?"
    mc "Why?"
    mc "What subject are we having the test for?"

    scene e2s1-48 with dissolve
    hide e2s1_cleo_blink2
    cl "Math."
    cl "She announced it through the e-mail."

    scene e2s1-49 with dissolve
    show e2s1_cleo_blink2
    if affinity_spectrum > 0:
        mc "Shit, I'm not prepared for it."
    else:
        mc "I'm not prepared for it."

    scene e2s1-47 with dissolve
    hide e2s1_cleo_blink2
    cl "Me neither..."

    scene e2s1-48 with dissolve
    cl "But we'll manage!"

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Haha, yeah!"

    scene e2s1-40 with dissolve
    hide e2s1_cleo_blink1
    cl "So, how was the party at Eddy's?"

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "Yeah... here's the thing."
    mc "The whole place was trashed before we even got there."

    scene e2s1-46 with dissolve
    hide e2s1_cleo_blink1
    cl "Trashed? How?"

    scene e2s1-49 with dissolve
    show e2s1_cleo_blink2
    mc "They don't know yet."
    mc "My friend [jon] said he's gonna have some people look into it."
    mc "Hopefully they get to the bottom of it all."

    scene e2s1-47 with dissolve
    hide e2s1_cleo_blink2
    cl "Oh, I'm sorry [mc]!"

    scene e2s1-49 with dissolve
    show e2s1_cleo_blink2
    mc "It's alright."
    mc "We actually went to another party as a last resort."

    scene e2s1-39 with dissolve
    hide e2s1_cleo_blink2
    cl "Nice, where did you go?"

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    mc "There was a place called Cabanna's."

    scene e2s1-40 with dissolve
    hide e2s1_cleo_blink1
    cl "How was it?"

    scene e2s1-38 with dissolve
    show e2s1_cleo_blink1
    if affinity_spectrum >= 0:
        mc "It was pretty nice!"
        mc "I met some fun people there."

        scene e2s1-39 with dissolve
        hide e2s1_cleo_blink1
        cl "I see! That's nice!"
    else:
        mc "It was alright."

        scene e2s1-48 with dissolve
        hide e2s1_cleo_blink1
        cl "Just alright?"

        scene e2s1-49 with dissolve
        show e2s1_cleo_blink2
        mc "Yeah... you know... partying is not really my thing."

        scene e2s1-47 with dissolve
        hide e2s1_cleo_blink2
        cl "Yeah but still, didn't you have fun?"

    scene e2s1-50 with dissolve
    pause

    scene e2s1-51 with dissolve
    pause

    # Negative #################################################################
    if sadie_trust < 3 and tracy_trust < 3:
        scene e2s1-52 with dissolve
        pause

    if tracy_trust < 3 and e1f5_refuse_sadie == True:
        scene e2s1-53 with dissolve
        pause

        scene e2s1-54 with dissolve
        pause

        scene e2s1-48 with dissolve
        cl "Do you know them?"

        scene e2s1-49 with dissolve
        show e2s1_cleo_blink2
        mc "Yeah... they went to a party organised by [jon]."
        mc "They were also at last night's party."

        scene e2s1-47 with dissolve
        hide e2s1_cleo_blink2
        cl "They didn't really seem to like you."

        scene e2s1-49 with dissolve
        show e2s1_cleo_blink2
        mc "Yeah..."
        mc "I guess we just don't get along that well."

    if affinity_spectrum >= 0 and tracy_trust >= 3 and e1f5_refuse_sadie == True:

        scene e2s1-55 with dissolve
        tr "[mc]! Hey!!"

        scene e2s1-57 with dissolve
        show e2s1_tracy_blink1
        mc "Hey girls!"

        scene e2s1-56 with dissolve
        hide e2s1_tracy_blink1
        tr "Where were you [mc]?"

        scene e2s1-58 with dissolve
        tr "You just disappeared from the party!"

        scene e2s1-57 with dissolve
        show e2s1_tracy_blink1
        mc "Yeah... sorry!"
        mc "I left to help my friend [jon] at Eddy's."

        scene e2s1-59 with dissolve
        hide e2s1_tracy_blink1
        tr "Oh, that's a bummer!"

        scene e2s1-60 with dissolve
        sd "Yeah, come on [tr]!"

        scene e2s1-61 with dissolve
        sd "Let's go."

        scene e2s1-54 with dissolve
        tr "Uh, alright?"

        scene e2s1-48 with dissolve
        cl "Do you know them?"

        scene e2s1-49 with dissolve
        show e2s1_cleo_blink2
        mc "Yeah... they went to a party organised by [jon]."
        mc "They were also at last night's party."

        scene e2s1-47 with dissolve
        hide e2s1_cleo_blink2
        cl "They didn't really seem to like you."

        scene e2s1-49 with dissolve
        show e2s1_cleo_blink2
        mc "Yeah..."
        mc "I guess we just don't get along that well."

    # Positive #################################################################

    if sadie_trust >= 3 and tracy_trust < 3 and e1s17_sadie == False and e1f5_refuse_sadie == False:
        scene e2s1-62 with dissolve
        sd "Hey [mc]!"

        scene e2s1-63 with dissolve
        sd "Missed you at the party, where did you go?"

        scene e2s1-64 with dissolve
        show e2s1_sadie_blink1
        mc "Hey girls!"
        mc "Sorry, I left to help [jon] clean up at Eddy's."

        scene e2s1-65 with dissolve
        hide e2s1_sadie_blink1
        sd "Oh, I understand!"

        scene e2s1-66 with dissolve
        sd "Hope he's alright."

        scene e2s1-67 with dissolve
        show e2s1_sadie_blink2
        mc "Yeah, he's fine."

        scene e2s1-63 with dissolve
        hide e2s1_sadie_blink2
        sd "Glad to hear that!"

        scene e2s1-68 with dissolve
        sd "We'll be on our way, it was nice talking to you [mc]!"

        scene e2s1-64 with dissolve
        show e2s1_sadie_blink1
        mc "Nice seeing you too girls, bye!"

        scene e2s1-54 with dissolve
        hide e2s1_sadie_blink1
        pause

        scene e2s1-39 with dissolve
        cl "So... they were from last night's party?"

        scene e2s1-38 with dissolve
        show e2s1_cleo_blink1
        mc "Yeah... I met those girls through [jon]."
        mc "They were at one of his parties before."

        scene e2s1-40 with dissolve
        hide e2s1_cleo_blink1
        cl "I see."

        scene e2s1-39 with dissolve
        cl "Glad to see you're having fun!"

        scene e2s1-38 with dissolve
        show e2s1_cleo_blink1
        mc "I really hope you'll come to a party sometime in the future."

        scene e2s1-77 with dissolve
        hide e2s1_cleo_blink1
        cl "Haha, we'll see!"

    if sadie_trust >= 3 and e1s17_sadie == True and e1f5_refuse_sadie == False and e1s17_cleo_choice == True:

        scene e2s1-71 with dissolve
        pause

        scene e2s1-72 with dissolve
        pause

        scene e2s1-52 with dissolve
        pause

        scene e2s1-39 with dissolve
        cl "So... shall we walk?"

        scene e2s1-38 with dissolve
        show e2s1_cleo_blink1
        mc "Sure, let's go!"

        hide e2s1_cleo_blink1

    if affinity_spectrum >= 0 and sadie_trust >= 3 and tracy_trust >= 3 and e1s17_sadie == False and e1f5_refuse_sadie == False:
        scene e2s1-62 with dissolve
        sd "Hey [mc]!"

        scene e2s1-63 with dissolve
        sd "Where did you go last night?"

        scene e2s1-70 with dissolve
        tr "Yeah, you just left without saying anything."

        scene e2s1-64 with dissolve
        show e2s1_sadie_blink1
        mc "Haha, sorry girls!"
        mc "I left to help [jon] clean up at Eddy's."

        scene e2s1-73 with dissolve
        hide e2s1_sadie_blink1
        tr "Oh, that's a bummer."

        scene e2s1-65 with dissolve
        sd "Yeah..."
        sd "I hope that [jon]'s alright."

        scene e2s1-67 with dissolve
        show e2s1_sadie_blink2
        mc "He's fine."

        scene e2s1-74 with dissolve
        hide e2s1_sadie_blink2
        tr "Anyways, we had a great time last night!"

        scene e2s1-63 with dissolve
        sd "Yeah..."

        scene e2s1-69 with dissolve
        pause

        scene e2s1-63 with dissolve
        sd "Well... we will leave you to it then, [mc]!"

        scene e2s1-75 with dissolve
        tr "Oh, okay?"

        scene e2s1-68 with dissolve
        sd "Catch you later [mc]!"

        scene e2s1-76 with dissolve
        sd "Come on [tr]!"

        scene e2s1-54 with dissolve
        pause

        scene e2s1-39 with dissolve
        cl "So... they were from last night's party?"

        scene e2s1-38 with dissolve
        show e2s1_cleo_blink1
        mc "Yeah... I met those girls through [jon]."
        mc "They were at one of his parties before."

        scene e2s1-40 with dissolve
        hide e2s1_cleo_blink1
        cl "I see."

        scene e2s1-39 with dissolve
        cl "Glad to see you're having fun!"

        scene e2s1-38 with dissolve
        show e2s1_cleo_blink1
        mc "I really hope you'll come to a party sometime in the future."

        scene e2s1-77 with dissolve
        hide e2s1_cleo_blink1
        cl "Haha, we'll see!"

    if affinity_spectrum >= 0 and sadie_trust >= 3 and tracy_trust >= 3 and e1s17_sadie == True and e1f5_refuse_sadie == False and e1s17_cleo_choice == False:
        scene e2s1-62 with dissolve
        sd "Hey [mc]!"

        scene e2s1-63 with dissolve
        sd "Where did you go last night?"

        scene e2s1-70 with dissolve
        tr "Yeah, you just left without saying anything."

        scene e2s1-64 with dissolve
        show e2s1_sadie_blink1
        mc "Haha, sorry girls!"
        mc "I left to help [jon] clean up at Eddy's."

        scene e2s1-73 with dissolve
        hide e2s1_sadie_blink1
        tr "Oh, that's a bummer."

        scene e2s1-65 with dissolve
        sd "Yeah..."
        sd "I hope that [jon]'s alright."

        scene e2s1-67 with dissolve
        show e2s1_sadie_blink2
        mc "He's fine."

        scene e2s1-74 with dissolve
        hide e2s1_sadie_blink2
        tr "Anyways, we had a great time last night!"

        scene e2s1-63 with dissolve
        sd "Yeah, we need to go to more parties together!"

        scene e2s1-64 with dissolve
        show e2s1_sadie_blink1
        menu:
            "Positive response":
                if cleo_trust >= 3:
                    $ e2s1_cleo_sad = True
                $ cleo_trust -= 1
                $ tracy_trust += 1
                $ sadie_trust += 1
                call extrovert_affinity_check from _call_extrovert_affinity_check_26
                call color_check from _call_color_check_51

                mc "Yeah, for sure!"
                mc "I had a great time last night as well."

                scene e2s1-74 with dissolve
                hide e2s1_sadie_blink1
                tr "Sure we {b}had{/b}..."

                scene e2s1-63 with dissolve
                sd "Haha, that's the spirit!"

            "Negative response":
                $ sadie_trust -= 1
                $ tracy_trust -= 1
                call introvert_affinity_check from _call_introvert_affinity_check_22
                call color_check from _call_color_check_52

                mc "I don't know about that..."
                mc "We'll have to see."

                scene e2s1-73 with dissolve
                hide e2s1_sadie_blink1
                tr "Mood killer..."

        scene e2s1-54 with dissolve
        pause

        if e2s1_cleo_sad == True:
            scene e2s1-47 with dissolve
            cl "Glad to see you had your fun..."

            scene e2s1-49 with dissolve
            show e2s1_cleo_blink2
            mc "Hey... it was nothing like that."

            scene e2s1-48 with dissolve
            hide e2s1_cleo_blink2
            cl "Whatever [mc]..."
            cl "Let's just walk."

            scene e2s1-49 with dissolve
            show e2s1_cleo_blink2
            mc "..."

            hide e2s1_cleo_blink2
        else:
            scene e2s1-39 with dissolve
            cl "They were from last night's party?"

            scene e2s1-38 with dissolve
            show e2s1_cleo_blink1
            mc "Yup!"

            scene e2s1-40 with dissolve
            hide e2s1_cleo_blink1
            cl "Nice! Glad to see you had fun."

            scene e2s1-38 with dissolve
            show e2s1_cleo_blink1
            mc "Thanks [cl]!"
            mc "I really hope you'll come to a party sometime in the future."

            scene e2s1-77 with dissolve
            hide e2s1_cleo_blink1
            cl "Haha, keep dreaming!"

    stop music fadeout 1.0
    scene e2s1-78 with wipeleft
    play music the_pawnbrokers_stepdaughter
    pause

    scene e2s1-79 with dissolve
    pause

    scene e2s1-81 with dissolve
    mc "*Is that [fr]?*"
    mc "*I'm gonna talk to her.*"

    scene e2s1-80 with dissolve
    pause

    scene e2s1-82 with dissolve
    fr "[mc]..."

    scene e2s1-83 with dissolve
    show e2s1_francesca_blink1
    mc "[fr], stop!"
    mc "How long are you gonna ignore me for?"

    if e1s11_kiss_her == False:
        scene e2s1-84 with dissolve
        hide e2s1_francesca_blink1
        fr "What do you mean?"

        scene e2s1-85 with dissolve
        fr "I wasn't ignoring you..."

        scene e2s1-83 with dissolve
        show e2s1_francesca_blink1
        if affinity_spectrum > 0:
            mc "Cut the crap, [fr]!"
        mc "You run away at every turn."

    scene e2s1-86 with dissolve
    hide e2s1_francesca_blink1
    fr "It's not like that... you don't understand!"

    scene e2s1-83 with dissolve
    show e2s1_francesca_blink1
    mc "What's to understand?"
    mc "Make me understand."
    mc "When we talked that night, I felt like we had a connection."
    mc "What's going on with you?"

    scene e2s1-86 with dissolve
    hide e2s1_francesca_blink1
    fr "Can we talk about this later, please?"

    scene e2s1-87 with dissolve
    fr "This is not the time nor the place for it."

    scene e2s1-83 with dissolve
    show e2s1_francesca_blink1
    mc "Then when should we talk?"

    scene e2s1-88 with dissolve
    hide e2s1_francesca_blink1
    fr "Meet me after school."

    scene e2s1-83 with dissolve
    show e2s1_francesca_blink1
    mc "Alright, but promise me that you'll answer my questions."

    scene e2s1-89 with dissolve
    hide e2s1_francesca_blink1
    fr "..."

    scene e2s1-90 with dissolve
    fr "I will try..."

    stop music fadeout 2.0
    if francesca_trust >= 1:
        scene e2s1-92 with dissolve
        pause
    else:
        scene e2s1-91 with dissolve
        pause

    jump e2s2

return
