
# Scene 11 Images ##############################################################

image e2s11-01 = im.Scale("season1/episode2/images/scene11/1.webp", 1920, 1080)
image e2s11-02 = im.Scale("season1/episode2/images/scene11/2.webp", 1920, 1080)
image e2s11-03 = im.Scale("season1/episode2/images/scene11/3.webp", 1920, 1080)
image e2s11-04 = im.Scale("season1/episode2/images/scene11/4.webp", 1920, 1080)
image e2s11-05 = im.Scale("season1/episode2/images/scene11/5.webp", 1920, 1080)
image e2s11-06 = im.Scale("season1/episode2/images/scene11/6.webp", 1920, 1080)
image e2s11-07 = im.Scale("season1/episode2/images/scene11/7.webp", 1920, 1080)
image e2s11-08 = im.Scale("season1/episode2/images/scene11/8.webp", 1920, 1080)
image e2s11-09 = im.Scale("season1/episode2/images/scene11/9.webp", 1920, 1080)
image e2s11-10 = im.Scale("season1/episode2/images/scene11/10.webp", 1920, 1080)
image e2s11-11 = im.Scale("season1/episode2/images/scene11/11.webp", 1920, 1080)
image e2s11-12 = im.Scale("season1/episode2/images/scene11/12.webp", 1920, 1080)
image e2s11-13 = im.Scale("season1/episode2/images/scene11/13.webp", 1920, 1080)
image e2s11-14 = im.Scale("season1/episode2/images/scene11/14.webp", 1920, 1080)
image e2s11-15 = im.Scale("season1/episode2/images/scene11/15.webp", 1920, 1080)
image e2s11-16 = im.Scale("season1/episode2/images/scene11/16.webp", 1920, 1080)
image e2s11-17 = im.Scale("season1/episode2/images/scene11/17.webp", 1920, 1080)
image e2s11-18 = im.Scale("season1/episode2/images/scene11/18.webp", 1920, 1080)
image e2s11-19 = im.Scale("season1/episode2/images/scene11/19.webp", 1920, 1080)
image e2s11-20 = im.Scale("season1/episode2/images/scene11/20.webp", 1920, 1080)
image e2s11-21 = im.Scale("season1/episode2/images/scene11/21.webp", 1920, 1080)
image e2s11-22 = im.Scale("season1/episode2/images/scene11/22.webp", 1920, 1080)
image e2s11-23 = im.Scale("season1/episode2/images/scene11/23.webp", 1920, 1080)
image e2s11-24 = im.Scale("season1/episode2/images/scene11/24.webp", 1920, 1080)
image e2s11-25 = im.Scale("season1/episode2/images/scene11/25.webp", 1920, 1080)
image e2s11-26 = im.Scale("season1/episode2/images/scene11/26.webp", 1920, 1080)
image e2s11-27 = im.Scale("season1/episode2/images/scene11/27.webp", 1920, 1080)
image e2s11-28 = im.Scale("season1/episode2/images/scene11/28.webp", 1920, 1080)
image e2s11-29 = im.Scale("season1/episode2/images/scene11/29.webp", 1920, 1080)
image e2s11-30 = im.Scale("season1/episode2/images/scene11/30.webp", 1920, 1080)
image e2s11-31 = im.Scale("season1/episode2/images/scene11/31.webp", 1920, 1080)
image e2s11-32 = im.Scale("season1/episode2/images/scene11/32.webp", 1920, 1080)
image e2s11-33 = im.Scale("season1/episode2/images/scene11/33.webp", 1920, 1080)
image e2s11-34 = im.Scale("season1/episode2/images/scene11/34.webp", 1920, 1080)
image e2s11-35 = im.Scale("season1/episode2/images/scene11/35.webp", 1920, 1080)
image e2s11-36 = im.Scale("season1/episode2/images/scene11/36.webp", 1920, 1080)
image e2s11-37 = im.Scale("season1/episode2/images/scene11/37.webp", 1920, 1080)
image e2s11-38 = im.Scale("season1/episode2/images/scene11/38.webp", 1920, 1080)
image e2s11-39 = im.Scale("season1/episode2/images/scene11/39.webp", 1920, 1080)
image e2s11-40 = im.Scale("season1/episode2/images/scene11/40.webp", 1920, 1080)
image e2s11-41 = im.Scale("season1/episode2/images/scene11/41.webp", 1920, 1080)
image e2s11-42 = im.Scale("season1/episode2/images/scene11/42.webp", 1920, 1080)
image e2s11-43 = im.Scale("season1/episode2/images/scene11/43.webp", 1920, 1080)
image e2s11-44 = im.Scale("season1/episode2/images/scene11/44.webp", 1920, 1080)
image e2s11-45 = im.Scale("season1/episode2/images/scene11/45.webp", 1920, 1080)
image e2s11-46 = im.Scale("season1/episode2/images/scene11/46.webp", 1920, 1080)
image e2s11-47 = im.Scale("season1/episode2/images/scene11/47.webp", 1920, 1080)
image e2s11-48 = im.Scale("season1/episode2/images/scene11/48.webp", 1920, 1080)
image e2s11-49 = im.Scale("season1/episode2/images/scene11/49.webp", 1920, 1080)
image e2s11-50 = im.Scale("season1/episode2/images/scene11/50.webp", 1920, 1080)
image e2s11-51 = im.Scale("season1/episode2/images/scene11/51.webp", 1920, 1080)
image e2s11-52 = im.Scale("season1/episode2/images/scene11/52.webp", 1920, 1080)
image e2s11-53 = im.Scale("season1/episode2/images/scene11/53.webp", 1920, 1080)
image e2s11-54 = im.Scale("season1/episode2/images/scene11/54.webp", 1920, 1080)
image e2s11-55 = im.Scale("season1/episode2/images/scene11/55.webp", 1920, 1080)
image e2s11-56 = im.Scale("season1/episode2/images/scene11/56.webp", 1920, 1080)
image e2s11-57 = im.Scale("season1/episode2/images/scene11/57.webp", 1920, 1080)
image e2s11-58 = im.Scale("season1/episode2/images/scene11/58.webp", 1920, 1080)
image e2s11-59 = im.Scale("season1/episode2/images/scene11/59.webp", 1920, 1080)
image e2s11-60 = im.Scale("season1/episode2/images/scene11/60.webp", 1920, 1080)
image e2s11-61 = im.Scale("season1/episode2/images/scene11/61.webp", 1920, 1080)
image e2s11-62 = im.Scale("season1/episode2/images/scene11/62.webp", 1920, 1080)
image e2s11-63 = im.Scale("season1/episode2/images/scene11/63.webp", 1920, 1080)
image e2s11-64 = im.Scale("season1/episode2/images/scene11/64.webp", 1920, 1080)
image e2s11-65 = im.Scale("season1/episode2/images/scene11/65.webp", 1920, 1080)
image e2s11-66 = im.Scale("season1/episode2/images/scene11/66.webp", 1920, 1080)
image e2s11-67 = im.Scale("season1/episode2/images/scene11/67.webp", 1920, 1080)
image e2s11-68 = im.Scale("season1/episode2/images/scene11/68.webp", 1920, 1080)
image e2s11-69 = im.Scale("season1/episode2/images/scene11/69.webp", 1920, 1080)
image e2s11-70 = im.Scale("season1/episode2/images/scene11/70.webp", 1920, 1080)
image e2s11-71 = im.Scale("season1/episode2/images/scene11/71.webp", 1920, 1080)
image e2s11-72 = im.Scale("season1/episode2/images/scene11/72.webp", 1920, 1080)
image e2s11-73 = im.Scale("season1/episode2/images/scene11/73.webp", 1920, 1080)
image e2s11-74 = im.Scale("season1/episode2/images/scene11/74.webp", 1920, 1080)
image e2s11-75 = im.Scale("season1/episode2/images/scene11/75.webp", 1920, 1080)
image e2s11-76 = im.Scale("season1/episode2/images/scene11/76.webp", 1920, 1080)
image e2s11-77 = im.Scale("season1/episode2/images/scene11/77.webp", 1920, 1080)
image e2s11-78 = im.Scale("season1/episode2/images/scene11/78.webp", 1920, 1080)
image e2s11-79 = im.Scale("season1/episode2/images/scene11/79.webp", 1920, 1080)
image e2s11-80 = im.Scale("season1/episode2/images/scene11/80.webp", 1920, 1080)
image e2s11-81 = im.Scale("season1/episode2/images/scene11/81.webp", 1920, 1080)
image e2s11-82 = im.Scale("season1/episode2/images/scene11/82.webp", 1920, 1080)
image e2s11-83 = im.Scale("season1/episode2/images/scene11/83.webp", 1920, 1080)
image e2s11-84 = im.Scale("season1/episode2/images/scene11/84.webp", 1920, 1080)
image e2s11-85 = im.Scale("season1/episode2/images/scene11/85.webp", 1920, 1080)
image e2s11-86 = im.Scale("season1/episode2/images/scene11/86.webp", 1920, 1080)
image e2s11-87 = im.Scale("season1/episode2/images/scene11/87.webp", 1920, 1080)
image e2s11-88 = im.Scale("season1/episode2/images/scene11/88.webp", 1920, 1080)
image e2s11-89 = im.Scale("season1/episode2/images/scene11/89.webp", 1920, 1080)
image e2s11-90 = im.Scale("season1/episode2/images/scene11/90.webp", 1920, 1080)
image e2s11-91 = im.Scale("season1/episode2/images/scene11/91.webp", 1920, 1080)
image e2s11-92 = im.Scale("season1/episode2/images/scene11/92.webp", 1920, 1080)
image e2s11-93 = im.Scale("season1/episode2/images/scene11/93.webp", 1920, 1080)
image e2s11-94 = im.Scale("season1/episode2/images/scene11/94.webp", 1920, 1080)
image e2s11-95 = im.Scale("season1/episode2/images/scene11/95.webp", 1920, 1080)
image e2s11-96 = im.Scale("season1/episode2/images/scene11/96.webp", 1920, 1080)
image e2s11-97 = im.Scale("season1/episode2/images/scene11/97.webp", 1920, 1080)
image e2s11-98 = im.Scale("season1/episode2/images/scene11/98.webp", 1920, 1080)
image e2s11-99 = im.Scale("season1/episode2/images/scene11/99.webp", 1920, 1080)
image e2s11-100 = im.Scale("season1/episode2/images/scene11/100.webp", 1920, 1080)
image e2s11-101 = im.Scale("season1/episode2/images/scene11/101.webp", 1920, 1080)
image e2s11-102 = im.Scale("season1/episode2/images/scene11/102.webp", 1920, 1080)
image e2s11-103 = im.Scale("season1/episode2/images/scene11/103.webp", 1920, 1080)
image e2s11-104 = im.Scale("season1/episode2/images/scene11/104.webp", 1920, 1080)
image e2s11-105 = im.Scale("season1/episode2/images/scene11/105.webp", 1920, 1080)
image e2s11-106 = im.Scale("season1/episode2/images/scene11/106.webp", 1920, 1080)
image e2s11-107 = im.Scale("season1/episode2/images/scene11/107.webp", 1920, 1080)
image e2s11-108 = im.Scale("season1/episode2/images/scene11/108.webp", 1920, 1080)
image e2s11-109 = im.Scale("season1/episode2/images/scene11/109.webp", 1920, 1080)
image e2s11-110 = im.Scale("season1/episode2/images/scene11/110.webp", 1920, 1080)
image e2s11-111 = im.Scale("season1/episode2/images/scene11/111.webp", 1920, 1080)
image e2s11-112 = im.Scale("season1/episode2/images/scene11/112.webp", 1920, 1080)
image e2s11-113 = im.Scale("season1/episode2/images/scene11/113.webp", 1920, 1080)
image e2s11-114 = im.Scale("season1/episode2/images/scene11/114.webp", 1920, 1080)
image e2s11-115 = im.Scale("season1/episode2/images/scene11/115.webp", 1920, 1080)
image e2s11-116 = im.Scale("season1/episode2/images/scene11/116.webp", 1920, 1080)
image e2s11-117 = im.Scale("season1/episode2/images/scene11/117.webp", 1920, 1080)
image e2s11-118 = im.Scale("season1/episode2/images/scene11/118.webp", 1920, 1080)

image e2s11-jon_blink1:
    im.Scale("season1/episode2/images/scene11/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s11-jon_blink2:
    im.Scale("season1/episode2/images/scene11/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s11-jon_blink3:
    im.Scale("season1/episode2/images/scene11/jon_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s11-jon_blink4:
    im.Scale("season1/episode2/images/scene11/jon_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/jon_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s11-scarlett_blink1:
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s11-unknown_blink1:
    im.Scale("season1/episode2/images/scene11/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene11/unknown_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
