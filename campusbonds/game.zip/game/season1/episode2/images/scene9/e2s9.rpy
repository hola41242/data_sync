
# Scene 9 Images ##############################################################

image e2s9-01 = im.Scale("season1/episode2/images/scene9/1.webp", 1920, 1080)
image e2s9-02 = im.Scale("season1/episode2/images/scene9/2.webp", 1920, 1080)
image e2s9-03 = im.Scale("season1/episode2/images/scene9/3.webp", 1920, 1080)
image e2s9-04 = im.Scale("season1/episode2/images/scene9/4.webp", 1920, 1080)
image e2s9-05 = im.Scale("season1/episode2/images/scene9/5.webp", 1920, 1080)
image e2s9-06 = im.Scale("season1/episode2/images/scene9/6.webp", 1920, 1080)
image e2s9-07 = im.Scale("season1/episode2/images/scene9/7.webp", 1920, 1080)
image e2s9-08 = im.Scale("season1/episode2/images/scene9/8.webp", 1920, 1080)
image e2s9-09 = im.Scale("season1/episode2/images/scene9/9.webp", 1920, 1080)
image e2s9-10 = im.Scale("season1/episode2/images/scene9/10.webp", 1920, 1080)
image e2s9-11 = im.Scale("season1/episode2/images/scene9/11.webp", 1920, 1080)
image e2s9-12 = im.Scale("season1/episode2/images/scene9/12.webp", 1920, 1080)
image e2s9-13 = im.Scale("season1/episode2/images/scene9/13.webp", 1920, 1080)
image e2s9-14 = im.Scale("season1/episode2/images/scene9/14.webp", 1920, 1080)
image e2s9-15 = im.Scale("season1/episode2/images/scene9/15.webp", 1920, 1080)
image e2s9-16 = im.Scale("season1/episode2/images/scene9/16.webp", 1920, 1080)
image e2s9-17 = im.Scale("season1/episode2/images/scene9/17.webp", 1920, 1080)
image e2s9-18 = im.Scale("season1/episode2/images/scene9/18.webp", 1920, 1080)
image e2s9-19 = im.Scale("season1/episode2/images/scene9/19.webp", 1920, 1080)
image e2s9-20 = im.Scale("season1/episode2/images/scene9/20.webp", 1920, 1080)
image e2s9-21 = im.Scale("season1/episode2/images/scene9/21.webp", 1920, 1080)
image e2s9-22 = im.Scale("season1/episode2/images/scene9/22.webp", 1920, 1080)
image e2s9-23 = im.Scale("season1/episode2/images/scene9/23.webp", 1920, 1080)
image e2s9-24 = im.Scale("season1/episode2/images/scene9/24.webp", 1920, 1080)
image e2s9-25 = im.Scale("season1/episode2/images/scene9/25.webp", 1920, 1080)
image e2s9-26 = im.Scale("season1/episode2/images/scene9/26.webp", 1920, 1080)
image e2s9-27 = im.Scale("season1/episode2/images/scene9/27.webp", 1920, 1080)
image e2s9-28 = im.Scale("season1/episode2/images/scene9/28.webp", 1920, 1080)
image e2s9-29 = im.Scale("season1/episode2/images/scene9/29.webp", 1920, 1080)
image e2s9-30 = im.Scale("season1/episode2/images/scene9/30.webp", 1920, 1080)
image e2s9-31 = im.Scale("season1/episode2/images/scene9/31.webp", 1920, 1080)
image e2s9-32 = im.Scale("season1/episode2/images/scene9/32.webp", 1920, 1080)
image e2s9-33 = im.Scale("season1/episode2/images/scene9/33.webp", 1920, 1080)
image e2s9-34 = im.Scale("season1/episode2/images/scene9/34.webp", 1920, 1080)
image e2s9-35 = im.Scale("season1/episode2/images/scene9/35.webp", 1920, 1080)
image e2s9-36 = im.Scale("season1/episode2/images/scene9/36.webp", 1920, 1080)
image e2s9-37 = im.Scale("season1/episode2/images/scene9/37.webp", 1920, 1080)
image e2s9-38 = im.Scale("season1/episode2/images/scene9/38.webp", 1920, 1080)
image e2s9-39 = im.Scale("season1/episode2/images/scene9/39.webp", 1920, 1080)
image e2s9-40 = im.Scale("season1/episode2/images/scene9/40.webp", 1920, 1080)
image e2s9-41 = im.Scale("season1/episode2/images/scene9/41.webp", 1920, 1080)
image e2s9-42 = im.Scale("season1/episode2/images/scene9/42.webp", 1920, 1080)
image e2s9-43 = im.Scale("season1/episode2/images/scene9/43.webp", 1920, 1080)
image e2s9-44 = im.Scale("season1/episode2/images/scene9/44.webp", 1920, 1080)
image e2s9-45 = im.Scale("season1/episode2/images/scene9/45.webp", 1920, 1080)
image e2s9-46 = im.Scale("season1/episode2/images/scene9/46.webp", 1920, 1080)
image e2s9-47 = im.Scale("season1/episode2/images/scene9/47.webp", 1920, 1080)
image e2s9-48 = im.Scale("season1/episode2/images/scene9/48.webp", 1920, 1080)
image e2s9-49 = im.Scale("season1/episode2/images/scene9/49.webp", 1920, 1080)
image e2s9-50 = im.Scale("season1/episode2/images/scene9/50.webp", 1920, 1080)
image e2s9-51 = im.Scale("season1/episode2/images/scene9/51.webp", 1920, 1080)
image e2s9-52 = im.Scale("season1/episode2/images/scene9/52.webp", 1920, 1080)
image e2s9-53 = im.Scale("season1/episode2/images/scene9/53.webp", 1920, 1080)
image e2s9-54 = im.Scale("season1/episode2/images/scene9/54.webp", 1920, 1080)
image e2s9-55 = im.Scale("season1/episode2/images/scene9/55.webp", 1920, 1080)
image e2s9-56 = im.Scale("season1/episode2/images/scene9/56.webp", 1920, 1080)
image e2s9-57 = im.Scale("season1/episode2/images/scene9/57.webp", 1920, 1080)
image e2s9-58 = im.Scale("season1/episode2/images/scene9/58.webp", 1920, 1080)
image e2s9-59 = im.Scale("season1/episode2/images/scene9/59.webp", 1920, 1080)
image e2s9-60 = im.Scale("season1/episode2/images/scene9/60.webp", 1920, 1080)
image e2s9-61 = im.Scale("season1/episode2/images/scene9/61.webp", 1920, 1080)
image e2s9-62 = im.Scale("season1/episode2/images/scene9/62.webp", 1920, 1080)
image e2s9-63 = im.Scale("season1/episode2/images/scene9/63.webp", 1920, 1080)
image e2s9-64 = im.Scale("season1/episode2/images/scene9/64.webp", 1920, 1080)
image e2s9-65 = im.Scale("season1/episode2/images/scene9/65.webp", 1920, 1080)
image e2s9-66 = im.Scale("season1/episode2/images/scene9/66.webp", 1920, 1080)
image e2s9-67 = im.Scale("season1/episode2/images/scene9/67.webp", 1920, 1080)
image e2s9-68 = im.Scale("season1/episode2/images/scene9/68.webp", 1920, 1080)
image e2s9-69 = im.Scale("season1/episode2/images/scene9/69.webp", 1920, 1080)
image e2s9-70 = im.Scale("season1/episode2/images/scene9/70.webp", 1920, 1080)
image e2s9-71 = im.Scale("season1/episode2/images/scene9/71.webp", 1920, 1080)
image e2s9-72 = im.Scale("season1/episode2/images/scene9/72.webp", 1920, 1080)
image e2s9-73 = im.Scale("season1/episode2/images/scene9/73.webp", 1920, 1080)
image e2s9-74 = im.Scale("season1/episode2/images/scene9/74.webp", 1920, 1080)
image e2s9-75 = im.Scale("season1/episode2/images/scene9/75.webp", 1920, 1080)
image e2s9-76 = im.Scale("season1/episode2/images/scene9/76.webp", 1920, 1080)
image e2s9-77 = im.Scale("season1/episode2/images/scene9/77.webp", 1920, 1080)
image e2s9-78 = im.Scale("season1/episode2/images/scene9/78.webp", 1920, 1080)
image e2s9-79 = im.Scale("season1/episode2/images/scene9/79.webp", 1920, 1080)
image e2s9-80 = im.Scale("season1/episode2/images/scene9/80.webp", 1920, 1080)
image e2s9-81 = im.Scale("season1/episode2/images/scene9/81.webp", 1920, 1080)
image e2s9-82 = im.Scale("season1/episode2/images/scene9/82.webp", 1920, 1080)
image e2s9-83 = im.Scale("season1/episode2/images/scene9/83.webp", 1920, 1080)
image e2s9-84 = im.Scale("season1/episode2/images/scene9/84.webp", 1920, 1080)
image e2s9-85 = im.Scale("season1/episode2/images/scene9/85.webp", 1920, 1080)
image e2s9-86 = im.Scale("season1/episode2/images/scene9/86.webp", 1920, 1080)
image e2s9-87 = im.Scale("season1/episode2/images/scene9/87.webp", 1920, 1080)
image e2s9-88 = im.Scale("season1/episode2/images/scene9/88.webp", 1920, 1080)
image e2s9-89 = im.Scale("season1/episode2/images/scene9/89.webp", 1920, 1080)
image e2s9-90 = im.Scale("season1/episode2/images/scene9/90.webp", 1920, 1080)
image e2s9-91 = im.Scale("season1/episode2/images/scene9/91.webp", 1920, 1080)
image e2s9-92 = im.Scale("season1/episode2/images/scene9/92.webp", 1920, 1080)
image e2s9-93 = im.Scale("season1/episode2/images/scene9/93.webp", 1920, 1080)

# Censored #

image e2s9-50_cen = im.Scale("season1/episode2/images/scene9/censored/50.webp", 1920, 1080)
image e2s9-51_cen = im.Scale("season1/episode2/images/scene9/censored/51.webp", 1920, 1080)
image e2s9-52_cen = im.Scale("season1/episode2/images/scene9/censored/52.webp", 1920, 1080)
image e2s9-53_cen = im.Scale("season1/episode2/images/scene9/censored/53.webp", 1920, 1080)
image e2s9-54_cen = im.Scale("season1/episode2/images/scene9/censored/54.webp", 1920, 1080)

image e2s10-francesca_blink1:
    im.Scale("season1/episode2/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10-sadie_blink1:
    im.Scale("season1/episode2/images/scene9/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10-jon_blink1:
    im.Scale("season1/episode2/images/scene9/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene9/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
