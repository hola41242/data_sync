
# Scene 3 images ###############################################################

image e2s3-01 = im.Scale("season1/episode2/images/scene3/1.webp", 1920, 1080)
image e2s3-02 = im.Scale("season1/episode2/images/scene3/2.webp", 1920, 1080)
image e2s3-03 = im.Scale("season1/episode2/images/scene3/3.webp", 1920, 1080)
image e2s3-04 = im.Scale("season1/episode2/images/scene3/4.webp", 1920, 1080)
image e2s3-05 = im.Scale("season1/episode2/images/scene3/5.webp", 1920, 1080)
image e2s3-06 = im.Scale("season1/episode2/images/scene3/6.webp", 1920, 1080)
image e2s3-07 = im.Scale("season1/episode2/images/scene3/7.webp", 1920, 1080)
image e2s3-08 = im.Scale("season1/episode2/images/scene3/8.webp", 1920, 1080)
image e2s3-09 = im.Scale("season1/episode2/images/scene3/9.webp", 1920, 1080)
image e2s3-10 = im.Scale("season1/episode2/images/scene3/10.webp", 1920, 1080)
image e2s3-11 = im.Scale("season1/episode2/images/scene3/11.webp", 1920, 1080)
image e2s3-12 = im.Scale("season1/episode2/images/scene3/12.webp", 1920, 1080)
image e2s3-13 = im.Scale("season1/episode2/images/scene3/13.webp", 1920, 1080)
image e2s3-14 = im.Scale("season1/episode2/images/scene3/14.webp", 1920, 1080)
image e2s3-15 = im.Scale("season1/episode2/images/scene3/15.webp", 1920, 1080)
image e2s3-16 = im.Scale("season1/episode2/images/scene3/16.webp", 1920, 1080)
image e2s3-17 = im.Scale("season1/episode2/images/scene3/17.webp", 1920, 1080)
image e2s3-18 = im.Scale("season1/episode2/images/scene3/18.webp", 1920, 1080)
image e2s3-19 = im.Scale("season1/episode2/images/scene3/19.webp", 1920, 1080)
image e2s3-20 = im.Scale("season1/episode2/images/scene3/20.webp", 1920, 1080)
image e2s3-21 = im.Scale("season1/episode2/images/scene3/21.webp", 1920, 1080)
image e2s3-22 = im.Scale("season1/episode2/images/scene3/22.webp", 1920, 1080)
image e2s3-23 = im.Scale("season1/episode2/images/scene3/23.webp", 1920, 1080)
image e2s3-24 = im.Scale("season1/episode2/images/scene3/24.webp", 1920, 1080)
image e2s3-25 = im.Scale("season1/episode2/images/scene3/25.webp", 1920, 1080)
image e2s3-26 = im.Scale("season1/episode2/images/scene3/26.webp", 1920, 1080)
image e2s3-27 = im.Scale("season1/episode2/images/scene3/27.webp", 1920, 1080)
image e2s3-28 = im.Scale("season1/episode2/images/scene3/28.webp", 1920, 1080)
image e2s3-29 = im.Scale("season1/episode2/images/scene3/29.webp", 1920, 1080)
image e2s3-30 = im.Scale("season1/episode2/images/scene3/30.webp", 1920, 1080)
image e2s3-31 = im.Scale("season1/episode2/images/scene3/31.webp", 1920, 1080)
image e2s3-32 = im.Scale("season1/episode2/images/scene3/32.webp", 1920, 1080)
image e2s3-33 = im.Scale("season1/episode2/images/scene3/33.webp", 1920, 1080)
image e2s3-34 = im.Scale("season1/episode2/images/scene3/34.webp", 1920, 1080)
image e2s3-35 = im.Scale("season1/episode2/images/scene3/35.webp", 1920, 1080)
image e2s3-36 = im.Scale("season1/episode2/images/scene3/36.webp", 1920, 1080)
image e2s3-37 = im.Scale("season1/episode2/images/scene3/37.webp", 1920, 1080)
image e2s3-38 = im.Scale("season1/episode2/images/scene3/38.webp", 1920, 1080)
image e2s3-39 = im.Scale("season1/episode2/images/scene3/39.webp", 1920, 1080)
image e2s3-40 = im.Scale("season1/episode2/images/scene3/40.webp", 1920, 1080)
image e2s3-41 = im.Scale("season1/episode2/images/scene3/41.webp", 1920, 1080)
image e2s3-42 = im.Scale("season1/episode2/images/scene3/42.webp", 1920, 1080)
image e2s3-43 = im.Scale("season1/episode2/images/scene3/43.webp", 1920, 1080)
image e2s3-44 = im.Scale("season1/episode2/images/scene3/44.webp", 1920, 1080)
image e2s3-45 = im.Scale("season1/episode2/images/scene3/45.webp", 1920, 1080)
image e2s3-46 = im.Scale("season1/episode2/images/scene3/46.webp", 1920, 1080)
image e2s3-47 = im.Scale("season1/episode2/images/scene3/47.webp", 1920, 1080)
image e2s3-48 = im.Scale("season1/episode2/images/scene3/48.webp", 1920, 1080)
image e2s3-49 = im.Scale("season1/episode2/images/scene3/49.webp", 1920, 1080)
image e2s3-50 = im.Scale("season1/episode2/images/scene3/50.webp", 1920, 1080)
image e2s3-51 = im.Scale("season1/episode2/images/scene3/51.webp", 1920, 1080)
image e2s3-52 = im.Scale("season1/episode2/images/scene3/52.webp", 1920, 1080)
image e2s3-53 = im.Scale("season1/episode2/images/scene3/53.webp", 1920, 1080)
image e2s3-54 = im.Scale("season1/episode2/images/scene3/54.webp", 1920, 1080)

image e2s3-francesca_blink1:
    im.Scale("season1/episode2/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s3-francesca_blink2:
    im.Scale("season1/episode2/images/scene3/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s3-francesca_blink3:
    im.Scale("season1/episode2/images/scene3/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s3-francesca_blink4:
    im.Scale("season1/episode2/images/scene3/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s3-francesca_blink5:
    im.Scale("season1/episode2/images/scene3/francesca_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene3/francesca_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat
