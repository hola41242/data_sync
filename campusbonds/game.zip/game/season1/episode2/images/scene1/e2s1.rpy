
# Scene 1 images ###############################################################

image e2s1-01 = im.Scale("season1/episode2/images/scene1/1.webp", 1920, 1080)
image e2s1-02 = im.Scale("season1/episode2/images/scene1/2.webp", 1920, 1080)
image e2s1-03 = im.Scale("season1/episode2/images/scene1/3.webp", 1920, 1080)
image e2s1-04 = im.Scale("season1/episode2/images/scene1/4.webp", 1920, 1080)
image e2s1-05 = im.Scale("season1/episode2/images/scene1/5.webp", 1920, 1080)
image e2s1-06 = im.Scale("season1/episode2/images/scene1/6.webp", 1920, 1080)
image e2s1-07 = im.Scale("season1/episode2/images/scene1/7.webp", 1920, 1080)
image e2s1-08 = im.Scale("season1/episode2/images/scene1/8.webp", 1920, 1080)
image e2s1-09 = im.Scale("season1/episode2/images/scene1/9.webp", 1920, 1080)
image e2s1-10 = im.Scale("season1/episode2/images/scene1/10.webp", 1920, 1080)
image e2s1-11 = im.Scale("season1/episode2/images/scene1/11.webp", 1920, 1080)
image e2s1-12 = im.Scale("season1/episode2/images/scene1/12.webp", 1920, 1080)
image e2s1-13 = im.Scale("season1/episode2/images/scene1/13.webp", 1920, 1080)
image e2s1-14 = im.Scale("season1/episode2/images/scene1/14.webp", 1920, 1080)
image e2s1-15 = im.Scale("season1/episode2/images/scene1/15.webp", 1920, 1080)
image e2s1-16 = im.Scale("season1/episode2/images/scene1/16.webp", 1920, 1080)
image e2s1-17 = im.Scale("season1/episode2/images/scene1/17.webp", 1920, 1080)
image e2s1-18 = im.Scale("season1/episode2/images/scene1/18.webp", 1920, 1080)
image e2s1-19 = im.Scale("season1/episode2/images/scene1/19.webp", 1920, 1080)
image e2s1-20 = im.Scale("season1/episode2/images/scene1/20.webp", 1920, 1080)
image e2s1-21 = im.Scale("season1/episode2/images/scene1/21.webp", 1920, 1080)
image e2s1-22 = im.Scale("season1/episode2/images/scene1/22.webp", 1920, 1080)
image e2s1-23 = im.Scale("season1/episode2/images/scene1/23.webp", 1920, 1080)
image e2s1-24 = im.Scale("season1/episode2/images/scene1/24.webp", 1920, 1080)
image e2s1-25 = im.Scale("season1/episode2/images/scene1/25.webp", 1920, 1080)
image e2s1-26 = im.Scale("season1/episode2/images/scene1/26.webp", 1920, 1080)
image e2s1-27 = im.Scale("season1/episode2/images/scene1/27.webp", 1920, 1080)
image e2s1-28 = im.Scale("season1/episode2/images/scene1/28.webp", 1920, 1080)
image e2s1-29 = im.Scale("season1/episode2/images/scene1/29.webp", 1920, 1080)
image e2s1-30 = im.Scale("season1/episode2/images/scene1/30.webp", 1920, 1080)
image e2s1-31 = im.Scale("season1/episode2/images/scene1/31.webp", 1920, 1080)
image e2s1-32 = im.Scale("season1/episode2/images/scene1/32.webp", 1920, 1080)
image e2s1-33 = im.Scale("season1/episode2/images/scene1/33.webp", 1920, 1080)
image e2s1-34 = im.Scale("season1/episode2/images/scene1/34.webp", 1920, 1080)
image e2s1-35 = im.Scale("season1/episode2/images/scene1/35.webp", 1920, 1080)
image e2s1-36 = im.Scale("season1/episode2/images/scene1/36.webp", 1920, 1080)
image e2s1-37 = im.Scale("season1/episode2/images/scene1/37.webp", 1920, 1080)
image e2s1-38 = im.Scale("season1/episode2/images/scene1/38.webp", 1920, 1080)
image e2s1-39 = im.Scale("season1/episode2/images/scene1/39.webp", 1920, 1080)
image e2s1-40 = im.Scale("season1/episode2/images/scene1/40.webp", 1920, 1080)
image e2s1-41 = im.Scale("season1/episode2/images/scene1/41.webp", 1920, 1080)
image e2s1-42 = im.Scale("season1/episode2/images/scene1/42.webp", 1920, 1080)
image e2s1-43 = im.Scale("season1/episode2/images/scene1/43.webp", 1920, 1080)
image e2s1-44 = im.Scale("season1/episode2/images/scene1/44.webp", 1920, 1080)
image e2s1-45 = im.Scale("season1/episode2/images/scene1/45.webp", 1920, 1080)
image e2s1-46 = im.Scale("season1/episode2/images/scene1/46.webp", 1920, 1080)
image e2s1-47 = im.Scale("season1/episode2/images/scene1/47.webp", 1920, 1080)
image e2s1-48 = im.Scale("season1/episode2/images/scene1/48.webp", 1920, 1080)
image e2s1-49 = im.Scale("season1/episode2/images/scene1/49.webp", 1920, 1080)
image e2s1-50 = im.Scale("season1/episode2/images/scene1/50.webp", 1920, 1080)
image e2s1-51 = im.Scale("season1/episode2/images/scene1/51.webp", 1920, 1080)
image e2s1-52 = im.Scale("season1/episode2/images/scene1/52.webp", 1920, 1080)
image e2s1-53 = im.Scale("season1/episode2/images/scene1/53.webp", 1920, 1080)
image e2s1-54 = im.Scale("season1/episode2/images/scene1/54.webp", 1920, 1080)
image e2s1-55 = im.Scale("season1/episode2/images/scene1/55.webp", 1920, 1080)
image e2s1-56 = im.Scale("season1/episode2/images/scene1/56.webp", 1920, 1080)
image e2s1-57 = im.Scale("season1/episode2/images/scene1/57.webp", 1920, 1080)
image e2s1-58 = im.Scale("season1/episode2/images/scene1/58.webp", 1920, 1080)
image e2s1-59 = im.Scale("season1/episode2/images/scene1/59.webp", 1920, 1080)
image e2s1-60 = im.Scale("season1/episode2/images/scene1/60.webp", 1920, 1080)
image e2s1-61 = im.Scale("season1/episode2/images/scene1/61.webp", 1920, 1080)
image e2s1-62 = im.Scale("season1/episode2/images/scene1/62.webp", 1920, 1080)
image e2s1-63 = im.Scale("season1/episode2/images/scene1/63.webp", 1920, 1080)
image e2s1-64 = im.Scale("season1/episode2/images/scene1/64.webp", 1920, 1080)
image e2s1-65 = im.Scale("season1/episode2/images/scene1/65.webp", 1920, 1080)
image e2s1-66 = im.Scale("season1/episode2/images/scene1/66.webp", 1920, 1080)
image e2s1-67 = im.Scale("season1/episode2/images/scene1/67.webp", 1920, 1080)
image e2s1-68 = im.Scale("season1/episode2/images/scene1/68.webp", 1920, 1080)
image e2s1-69 = im.Scale("season1/episode2/images/scene1/69.webp", 1920, 1080)
image e2s1-70 = im.Scale("season1/episode2/images/scene1/70.webp", 1920, 1080)
image e2s1-71 = im.Scale("season1/episode2/images/scene1/71.webp", 1920, 1080)
image e2s1-72 = im.Scale("season1/episode2/images/scene1/72.webp", 1920, 1080)
image e2s1-73 = im.Scale("season1/episode2/images/scene1/73.webp", 1920, 1080)
image e2s1-74 = im.Scale("season1/episode2/images/scene1/74.webp", 1920, 1080)
image e2s1-75 = im.Scale("season1/episode2/images/scene1/75.webp", 1920, 1080)
image e2s1-76 = im.Scale("season1/episode2/images/scene1/76.webp", 1920, 1080)
image e2s1-77 = im.Scale("season1/episode2/images/scene1/77.webp", 1920, 1080)
image e2s1-78 = im.Scale("season1/episode2/images/scene1/78.webp", 1920, 1080)
image e2s1-79 = im.Scale("season1/episode2/images/scene1/79.webp", 1920, 1080)
image e2s1-80 = im.Scale("season1/episode2/images/scene1/80.webp", 1920, 1080)
image e2s1-81 = im.Scale("season1/episode2/images/scene1/81.webp", 1920, 1080)
image e2s1-82 = im.Scale("season1/episode2/images/scene1/82.webp", 1920, 1080)
image e2s1-83 = im.Scale("season1/episode2/images/scene1/83.webp", 1920, 1080)
image e2s1-84 = im.Scale("season1/episode2/images/scene1/84.webp", 1920, 1080)
image e2s1-85 = im.Scale("season1/episode2/images/scene1/85.webp", 1920, 1080)
image e2s1-86 = im.Scale("season1/episode2/images/scene1/86.webp", 1920, 1080)
image e2s1-87 = im.Scale("season1/episode2/images/scene1/87.webp", 1920, 1080)
image e2s1-88 = im.Scale("season1/episode2/images/scene1/88.webp", 1920, 1080)
image e2s1-89 = im.Scale("season1/episode2/images/scene1/89.webp", 1920, 1080)
image e2s1-90 = im.Scale("season1/episode2/images/scene1/90.webp", 1920, 1080)
image e2s1-91 = im.Scale("season1/episode2/images/scene1/91.webp", 1920, 1080)
image e2s1-92 = im.Scale("season1/episode2/images/scene1/92.webp", 1920, 1080)
image e2s1-93 = im.Scale("season1/episode2/images/scene1/93.webp", 1920, 1080)
image e2s1-94 = im.Scale("season1/episode2/images/scene1/94.webp", 1920, 1080)
image e2s1-95 = im.Scale("season1/episode2/images/scene1/95.webp", 1920, 1080)
image e2s1-96 = im.Scale("season1/episode2/images/scene1/96.webp", 1920, 1080)
image e2s1-97 = im.Scale("season1/episode2/images/scene1/97.webp", 1920, 1080)

# Nate Blink ###################################################################

image e2s1_nate_blink1:
    im.Scale("season1/episode2/images/scene1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/nate_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Cleo Blink ###################################################################

image e2s1_cleo_blink1:
    im.Scale("season1/episode2/images/scene1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s1_cleo_blink2:
    im.Scale("season1/episode2/images/scene1/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy Blink ##################################################################

image e2s1_tracy_blink1:
    im.Scale("season1/episode2/images/scene1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s1_tracy_blink2:
    im.Scale("season1/episode2/images/scene1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie Blink ##################################################################

image e2s1_sadie_blink1:
    im.Scale("season1/episode2/images/scene1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s1_sadie_blink2:
    im.Scale("season1/episode2/images/scene1/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Francesca Blink ##############################################################

image e2s1_francesca_blink1:
    im.Scale("season1/episode2/images/scene1/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene1/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
