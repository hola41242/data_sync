
# Scene 7 images ###############################################################

image e2s7-01 = im.Scale("season1/episode2/images/scene7/1.webp", 1920, 1080)
image e2s7-02 = im.Scale("season1/episode2/images/scene7/2.webp", 1920, 1080)
image e2s7-03 = im.Scale("season1/episode2/images/scene7/3.webp", 1920, 1080)
image e2s7-04 = im.Scale("season1/episode2/images/scene7/4.webp", 1920, 1080)
image e2s7-05 = im.Scale("season1/episode2/images/scene7/5.webp", 1920, 1080)
image e2s7-06 = im.Scale("season1/episode2/images/scene7/6.webp", 1920, 1080)
image e2s7-07 = im.Scale("season1/episode2/images/scene7/7.webp", 1920, 1080)
image e2s7-08 = im.Scale("season1/episode2/images/scene7/8.webp", 1920, 1080)
image e2s7-09 = im.Scale("season1/episode2/images/scene7/9.webp", 1920, 1080)
image e2s7-10 = im.Scale("season1/episode2/images/scene7/10.webp", 1920, 1080)
image e2s7-11 = im.Scale("season1/episode2/images/scene7/11.webp", 1920, 1080)
image e2s7-12 = im.Scale("season1/episode2/images/scene7/12.webp", 1920, 1080)
image e2s7-13 = im.Scale("season1/episode2/images/scene7/13.webp", 1920, 1080)
image e2s7-14 = im.Scale("season1/episode2/images/scene7/14.webp", 1920, 1080)
image e2s7-15 = im.Scale("season1/episode2/images/scene7/15.webp", 1920, 1080)
image e2s7-16 = im.Scale("season1/episode2/images/scene7/16.webp", 1920, 1080)
image e2s7-17 = im.Scale("season1/episode2/images/scene7/17.webp", 1920, 1080)
image e2s7-18 = im.Scale("season1/episode2/images/scene7/18.webp", 1920, 1080)
image e2s7-19 = im.Scale("season1/episode2/images/scene7/19.webp", 1920, 1080)
image e2s7-20 = im.Scale("season1/episode2/images/scene7/20.webp", 1920, 1080)
image e2s7-21 = im.Scale("season1/episode2/images/scene7/21.webp", 1920, 1080)
image e2s7-22 = im.Scale("season1/episode2/images/scene7/22.webp", 1920, 1080)
image e2s7-23 = im.Scale("season1/episode2/images/scene7/23.webp", 1920, 1080)
image e2s7-24 = im.Scale("season1/episode2/images/scene7/24.webp", 1920, 1080)
image e2s7-25 = im.Scale("season1/episode2/images/scene7/25.webp", 1920, 1080)
image e2s7-26 = im.Scale("season1/episode2/images/scene7/26.webp", 1920, 1080)
image e2s7-27 = im.Scale("season1/episode2/images/scene7/27.webp", 1920, 1080)
image e2s7-28 = im.Scale("season1/episode2/images/scene7/28.webp", 1920, 1080)
image e2s7-29 = im.Scale("season1/episode2/images/scene7/29.webp", 1920, 1080)
image e2s7-30 = im.Scale("season1/episode2/images/scene7/30.webp", 1920, 1080)
image e2s7-31 = im.Scale("season1/episode2/images/scene7/31.webp", 1920, 1080)
image e2s7-32 = im.Scale("season1/episode2/images/scene7/32.webp", 1920, 1080)
image e2s7-33 = im.Scale("season1/episode2/images/scene7/33.webp", 1920, 1080)
image e2s7-34 = im.Scale("season1/episode2/images/scene7/34.webp", 1920, 1080)
image e2s7-35 = im.Scale("season1/episode2/images/scene7/35.webp", 1920, 1080)
image e2s7-36 = im.Scale("season1/episode2/images/scene7/36.webp", 1920, 1080)
image e2s7-37 = im.Scale("season1/episode2/images/scene7/37.webp", 1920, 1080)
image e2s7-38 = im.Scale("season1/episode2/images/scene7/38.webp", 1920, 1080)
image e2s7-39 = im.Scale("season1/episode2/images/scene7/39.webp", 1920, 1080)
image e2s7-40 = im.Scale("season1/episode2/images/scene7/40.webp", 1920, 1080)
image e2s7-41 = im.Scale("season1/episode2/images/scene7/41.webp", 1920, 1080)
image e2s7-42 = im.Scale("season1/episode2/images/scene7/42.webp", 1920, 1080)
image e2s7-43 = im.Scale("season1/episode2/images/scene7/43.webp", 1920, 1080)
image e2s7-44 = im.Scale("season1/episode2/images/scene7/44.webp", 1920, 1080)
image e2s7-45 = im.Scale("season1/episode2/images/scene7/45.webp", 1920, 1080)
image e2s7-46 = im.Scale("season1/episode2/images/scene7/46.webp", 1920, 1080)
image e2s7-47 = im.Scale("season1/episode2/images/scene7/47.webp", 1920, 1080)
image e2s7-48 = im.Scale("season1/episode2/images/scene7/48.webp", 1920, 1080)
image e2s7-49 = im.Scale("season1/episode2/images/scene7/49.webp", 1920, 1080)
image e2s7-50 = im.Scale("season1/episode2/images/scene7/50.webp", 1920, 1080)
image e2s7-51 = im.Scale("season1/episode2/images/scene7/51.webp", 1920, 1080)
image e2s7-52 = im.Scale("season1/episode2/images/scene7/52.webp", 1920, 1080)
image e2s7-53 = im.Scale("season1/episode2/images/scene7/53.webp", 1920, 1080)
image e2s7-54 = im.Scale("season1/episode2/images/scene7/54.webp", 1920, 1080)
image e2s7-55 = im.Scale("season1/episode2/images/scene7/55.webp", 1920, 1080)
image e2s7-56 = im.Scale("season1/episode2/images/scene7/56.webp", 1920, 1080)
image e2s7-57 = im.Scale("season1/episode2/images/scene7/57.webp", 1920, 1080)
image e2s7-58 = im.Scale("season1/episode2/images/scene7/58.webp", 1920, 1080)
image e2s7-59 = im.Scale("season1/episode2/images/scene7/59.webp", 1920, 1080)
image e2s7-60 = im.Scale("season1/episode2/images/scene7/60.webp", 1920, 1080)
image e2s7-61 = im.Scale("season1/episode2/images/scene7/61.webp", 1920, 1080)
image e2s7-62 = im.Scale("season1/episode2/images/scene7/62.webp", 1920, 1080)
image e2s7-63 = im.Scale("season1/episode2/images/scene7/63.webp", 1920, 1080)
image e2s7-64 = im.Scale("season1/episode2/images/scene7/64.webp", 1920, 1080)
image e2s7-65 = im.Scale("season1/episode2/images/scene7/65.webp", 1920, 1080)

image e2s7-jon_blink1:
    im.Scale("season1/episode2/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene7/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
