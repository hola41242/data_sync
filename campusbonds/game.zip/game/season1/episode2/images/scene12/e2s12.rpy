
# Scene 12 Images ##############################################################

image e2s12-01 = im.Scale("season1/episode2/images/scene12/1.webp", 1920, 1080)
image e2s12-02 = im.Scale("season1/episode2/images/scene12/2.webp", 1920, 1080)
image e2s12-03 = im.Scale("season1/episode2/images/scene12/3.webp", 1920, 1080)
image e2s12-04 = im.Scale("season1/episode2/images/scene12/4.webp", 1920, 1080)
image e2s12-05 = im.Scale("season1/episode2/images/scene12/5.webp", 1920, 1080)
image e2s12-06 = im.Scale("season1/episode2/images/scene12/6.webp", 1920, 1080)
image e2s12-07 = im.Scale("season1/episode2/images/scene12/7.webp", 1920, 1080)
image e2s12-08 = im.Scale("season1/episode2/images/scene12/8.webp", 1920, 1080)
image e2s12-09 = im.Scale("season1/episode2/images/scene12/9.webp", 1920, 1080)
image e2s12-10 = im.Scale("season1/episode2/images/scene12/10.webp", 1920, 1080)
image e2s12-11 = im.Scale("season1/episode2/images/scene12/11.webp", 1920, 1080)
image e2s12-12 = im.Scale("season1/episode2/images/scene12/12.webp", 1920, 1080)
image e2s12-13 = im.Scale("season1/episode2/images/scene12/13.webp", 1920, 1080)
image e2s12-14 = im.Scale("season1/episode2/images/scene12/14.webp", 1920, 1080)
image e2s12-15 = im.Scale("season1/episode2/images/scene12/15.webp", 1920, 1080)
image e2s12-16 = im.Scale("season1/episode2/images/scene12/16.webp", 1920, 1080)
image e2s12-17 = im.Scale("season1/episode2/images/scene12/17.webp", 1920, 1080)
image e2s12-18 = im.Scale("season1/episode2/images/scene12/18.webp", 1920, 1080)
image e2s12-19 = im.Scale("season1/episode2/images/scene12/19.webp", 1920, 1080)
image e2s12-20 = im.Scale("season1/episode2/images/scene12/20.webp", 1920, 1080)
image e2s12-21 = im.Scale("season1/episode2/images/scene12/21.webp", 1920, 1080)
image e2s12-22 = im.Scale("season1/episode2/images/scene12/22.webp", 1920, 1080)
image e2s12-23 = im.Scale("season1/episode2/images/scene12/23.webp", 1920, 1080)
image e2s12-24 = im.Scale("season1/episode2/images/scene12/24.webp", 1920, 1080)
image e2s12-25 = im.Scale("season1/episode2/images/scene12/25.webp", 1920, 1080)
image e2s12-26 = im.Scale("season1/episode2/images/scene12/26.webp", 1920, 1080)
image e2s12-27 = im.Scale("season1/episode2/images/scene12/27.webp", 1920, 1080)
image e2s12-28 = im.Scale("season1/episode2/images/scene12/28.webp", 1920, 1080)
image e2s12-29 = im.Scale("season1/episode2/images/scene12/29.webp", 1920, 1080)
image e2s12-30 = im.Scale("season1/episode2/images/scene12/30.webp", 1920, 1080)
image e2s12-31 = im.Scale("season1/episode2/images/scene12/31.webp", 1920, 1080)
image e2s12-32 = im.Scale("season1/episode2/images/scene12/32.webp", 1920, 1080)
image e2s12-33 = im.Scale("season1/episode2/images/scene12/33.webp", 1920, 1080)
image e2s12-34 = im.Scale("season1/episode2/images/scene12/34.webp", 1920, 1080)
image e2s12-35 = im.Scale("season1/episode2/images/scene12/35.webp", 1920, 1080)
image e2s12-36 = im.Scale("season1/episode2/images/scene12/36.webp", 1920, 1080)
image e2s12-37 = im.Scale("season1/episode2/images/scene12/37.webp", 1920, 1080)
image e2s12-38 = im.Scale("season1/episode2/images/scene12/38.webp", 1920, 1080)
image e2s12-39 = im.Scale("season1/episode2/images/scene12/39.webp", 1920, 1080)
image e2s12-40 = im.Scale("season1/episode2/images/scene12/40.webp", 1920, 1080)
image e2s12-41 = im.Scale("season1/episode2/images/scene12/41.webp", 1920, 1080)
image e2s12-42 = im.Scale("season1/episode2/images/scene12/42.webp", 1920, 1080)
image e2s12-43 = im.Scale("season1/episode2/images/scene12/43.webp", 1920, 1080)
image e2s12-44 = im.Scale("season1/episode2/images/scene12/44.webp", 1920, 1080)
image e2s12-45 = im.Scale("season1/episode2/images/scene12/45.webp", 1920, 1080)
image e2s12-46 = im.Scale("season1/episode2/images/scene12/46.webp", 1920, 1080)
image e2s12-47 = im.Scale("season1/episode2/images/scene12/47.webp", 1920, 1080)
image e2s12-48 = im.Scale("season1/episode2/images/scene12/48.webp", 1920, 1080)
image e2s12-49 = im.Scale("season1/episode2/images/scene12/49.webp", 1920, 1080)
image e2s12-50 = im.Scale("season1/episode2/images/scene12/50.webp", 1920, 1080)
image e2s12-51 = im.Scale("season1/episode2/images/scene12/51.webp", 1920, 1080)
image e2s12-52 = im.Scale("season1/episode2/images/scene12/52.webp", 1920, 1080)
image e2s12-53 = im.Scale("season1/episode2/images/scene12/53.webp", 1920, 1080)
image e2s12-54 = im.Scale("season1/episode2/images/scene12/54.webp", 1920, 1080)
image e2s12-55 = im.Scale("season1/episode2/images/scene12/55.webp", 1920, 1080)
image e2s12-56 = im.Scale("season1/episode2/images/scene12/56.webp", 1920, 1080)
image e2s12-57 = im.Scale("season1/episode2/images/scene12/57.webp", 1920, 1080)
image e2s12-58 = im.Scale("season1/episode2/images/scene12/58.webp", 1920, 1080)
image e2s12-59 = im.Scale("season1/episode2/images/scene12/59.webp", 1920, 1080)
image e2s12-60 = im.Scale("season1/episode2/images/scene12/60.webp", 1920, 1080)
image e2s12-61 = im.Scale("season1/episode2/images/scene12/61.webp", 1920, 1080)
image e2s12-62 = im.Scale("season1/episode2/images/scene12/62.webp", 1920, 1080)
image e2s12-63 = im.Scale("season1/episode2/images/scene12/63.webp", 1920, 1080)
image e2s12-64 = im.Scale("season1/episode2/images/scene12/64.webp", 1920, 1080)
image e2s12-65 = im.Scale("season1/episode2/images/scene12/65.webp", 1920, 1080)
image e2s12-66 = im.Scale("season1/episode2/images/scene12/66.webp", 1920, 1080)
image e2s12-67 = im.Scale("season1/episode2/images/scene12/67.webp", 1920, 1080)
image e2s12-68 = im.Scale("season1/episode2/images/scene12/68.webp", 1920, 1080)
image e2s12-69 = im.Scale("season1/episode2/images/scene12/69.webp", 1920, 1080)
image e2s12-70 = im.Scale("season1/episode2/images/scene12/70.webp", 1920, 1080)
image e2s12-71 = im.Scale("season1/episode2/images/scene12/71.webp", 1920, 1080)
image e2s12-72 = im.Scale("season1/episode2/images/scene12/72.webp", 1920, 1080)
image e2s12-73 = im.Scale("season1/episode2/images/scene12/73.webp", 1920, 1080)
image e2s12-74 = im.Scale("season1/episode2/images/scene12/74.webp", 1920, 1080)
image e2s12-75 = im.Scale("season1/episode2/images/scene12/75.webp", 1920, 1080)
image e2s12-76 = im.Scale("season1/episode2/images/scene12/76.webp", 1920, 1080)
image e2s12-77 = im.Scale("season1/episode2/images/scene12/77.webp", 1920, 1080)
image e2s12-78 = im.Scale("season1/episode2/images/scene12/78.webp", 1920, 1080)
image e2s12-79 = im.Scale("season1/episode2/images/scene12/79.webp", 1920, 1080)
image e2s12-80 = im.Scale("season1/episode2/images/scene12/80.webp", 1920, 1080)
image e2s12-81 = im.Scale("season1/episode2/images/scene12/81.webp", 1920, 1080)
image e2s12-82 = im.Scale("season1/episode2/images/scene12/82.webp", 1920, 1080)
image e2s12-83 = im.Scale("season1/episode2/images/scene12/83.webp", 1920, 1080)
image e2s12-84 = im.Scale("season1/episode2/images/scene12/84.webp", 1920, 1080)
image e2s12-85 = im.Scale("season1/episode2/images/scene12/85.webp", 1920, 1080)
image e2s12-86 = im.Scale("season1/episode2/images/scene12/86.webp", 1920, 1080)
image e2s12-87 = im.Scale("season1/episode2/images/scene12/87.webp", 1920, 1080)
image e2s12-88 = im.Scale("season1/episode2/images/scene12/88.webp", 1920, 1080)
image e2s12-89 = im.Scale("season1/episode2/images/scene12/89.webp", 1920, 1080)
image e2s12-90 = im.Scale("season1/episode2/images/scene12/90.webp", 1920, 1080)
image e2s12-91 = im.Scale("season1/episode2/images/scene12/91.webp", 1920, 1080)
image e2s12-92 = im.Scale("season1/episode2/images/scene12/92.webp", 1920, 1080)
image e2s12-93 = im.Scale("season1/episode2/images/scene12/93.webp", 1920, 1080)
image e2s12-94 = im.Scale("season1/episode2/images/scene12/94.webp", 1920, 1080)
image e2s12-95 = im.Scale("season1/episode2/images/scene12/95.webp", 1920, 1080)
image e2s12-96 = im.Scale("season1/episode2/images/scene12/96.webp", 1920, 1080)
image e2s12-97 = im.Scale("season1/episode2/images/scene12/97.webp", 1920, 1080)
image e2s12-98 = im.Scale("season1/episode2/images/scene12/98.webp", 1920, 1080)
image e2s12-99 = im.Scale("season1/episode2/images/scene12/99.webp", 1920, 1080)
image e2s12-100 = im.Scale("season1/episode2/images/scene12/100.webp", 1920, 1080)
image e2s12-101 = im.Scale("season1/episode2/images/scene12/101.webp", 1920, 1080)
image e2s12-102 = im.Scale("season1/episode2/images/scene12/102.webp", 1920, 1080)
image e2s12-103 = im.Scale("season1/episode2/images/scene12/103.webp", 1920, 1080)
image e2s12-104 = im.Scale("season1/episode2/images/scene12/104.webp", 1920, 1080)
image e2s12-105 = im.Scale("season1/episode2/images/scene12/105.webp", 1920, 1080)
image e2s12-106 = im.Scale("season1/episode2/images/scene12/106.webp", 1920, 1080)
image e2s12-107 = im.Scale("season1/episode2/images/scene12/107.webp", 1920, 1080)
image e2s12-108 = im.Scale("season1/episode2/images/scene12/108.webp", 1920, 1080)
image e2s12-109 = im.Scale("season1/episode2/images/scene12/109.webp", 1920, 1080)
image e2s12-110 = im.Scale("season1/episode2/images/scene12/110.webp", 1920, 1080)
image e2s12-111 = im.Scale("season1/episode2/images/scene12/111.webp", 1920, 1080)
image e2s12-112 = im.Scale("season1/episode2/images/scene12/112.webp", 1920, 1080)
image e2s12-113 = im.Scale("season1/episode2/images/scene12/113.webp", 1920, 1080)
image e2s12-114 = im.Scale("season1/episode2/images/scene12/114.webp", 1920, 1080)
image e2s12-115 = im.Scale("season1/episode2/images/scene12/115.webp", 1920, 1080)
image e2s12-116 = im.Scale("season1/episode2/images/scene12/116.webp", 1920, 1080)
image e2s12-117 = im.Scale("season1/episode2/images/scene12/117.webp", 1920, 1080)
image e2s12-118 = im.Scale("season1/episode2/images/scene12/118.webp", 1920, 1080)
image e2s12-119 = im.Scale("season1/episode2/images/scene12/119.webp", 1920, 1080)
image e2s12-120 = im.Scale("season1/episode2/images/scene12/120.webp", 1920, 1080)
image e2s12-121 = im.Scale("season1/episode2/images/scene12/121.webp", 1920, 1080)
image e2s12-122 = im.Scale("season1/episode2/images/scene12/122.webp", 1920, 1080)
image e2s12-123 = im.Scale("season1/episode2/images/scene12/123.webp", 1920, 1080)
image e2s12-124 = im.Scale("season1/episode2/images/scene12/124.webp", 1920, 1080)
image e2s12-125 = im.Scale("season1/episode2/images/scene12/125.webp", 1920, 1080)
image e2s12-126 = im.Scale("season1/episode2/images/scene12/126.webp", 1920, 1080)
image e2s12-127 = im.Scale("season1/episode2/images/scene12/127.webp", 1920, 1080)
image e2s12-128 = im.Scale("season1/episode2/images/scene12/128.webp", 1920, 1080)
image e2s12-129 = im.Scale("season1/episode2/images/scene12/129.webp", 1920, 1080)
image e2s12-130 = im.Scale("season1/episode2/images/scene12/130.webp", 1920, 1080)
image e2s12-131 = im.Scale("season1/episode2/images/scene12/131.webp", 1920, 1080)
image e2s12-132 = im.Scale("season1/episode2/images/scene12/132.webp", 1920, 1080)
image e2s12-133 = im.Scale("season1/episode2/images/scene12/133.webp", 1920, 1080)
image e2s12-134 = im.Scale("season1/episode2/images/scene12/134.webp", 1920, 1080)
image e2s12-135 = im.Scale("season1/episode2/images/scene12/135.webp", 1920, 1080)
image e2s12-136 = im.Scale("season1/episode2/images/scene12/136.webp", 1920, 1080)
image e2s12-137 = im.Scale("season1/episode2/images/scene12/137.webp", 1920, 1080)
image e2s12-138 = im.Scale("season1/episode2/images/scene12/138.webp", 1920, 1080)
image e2s12-139 = im.Scale("season1/episode2/images/scene12/139.webp", 1920, 1080)
image e2s12-140 = im.Scale("season1/episode2/images/scene12/140.webp", 1920, 1080)
image e2s12-141 = im.Scale("season1/episode2/images/scene12/141.webp", 1920, 1080)
image e2s12-142 = im.Scale("season1/episode2/images/scene12/142.webp", 1920, 1080)
image e2s12-143 = im.Scale("season1/episode2/images/scene12/143.webp", 1920, 1080)
image e2s12-144 = im.Scale("season1/episode2/images/scene12/144.webp", 1920, 1080)
image e2s12-145 = im.Scale("season1/episode2/images/scene12/145.webp", 1920, 1080)
image e2s12-146 = im.Scale("season1/episode2/images/scene12/146.webp", 1920, 1080)
image e2s12-147 = im.Scale("season1/episode2/images/scene12/147.webp", 1920, 1080)
image e2s12-148 = im.Scale("season1/episode2/images/scene12/148.webp", 1920, 1080)
image e2s12-149 = im.Scale("season1/episode2/images/scene12/149.webp", 1920, 1080)
image e2s12-150 = im.Scale("season1/episode2/images/scene12/150.webp", 1920, 1080)
image e2s12-151 = im.Scale("season1/episode2/images/scene12/151.webp", 1920, 1080)
image e2s12-152 = im.Scale("season1/episode2/images/scene12/152.webp", 1920, 1080)
image e2s12-153 = im.Scale("season1/episode2/images/scene12/153.webp", 1920, 1080)
image e2s12-154 = im.Scale("season1/episode2/images/scene12/154.webp", 1920, 1080)
image e2s12-155 = im.Scale("season1/episode2/images/scene12/155.webp", 1920, 1080)
image e2s12-156 = im.Scale("season1/episode2/images/scene12/156.webp", 1920, 1080)
image e2s12-157 = im.Scale("season1/episode2/images/scene12/157.webp", 1920, 1080)
image e2s12-158 = im.Scale("season1/episode2/images/scene12/158.webp", 1920, 1080)
image e2s12-159 = im.Scale("season1/episode2/images/scene12/159.webp", 1920, 1080)
image e2s12-160 = im.Scale("season1/episode2/images/scene12/160.webp", 1920, 1080)
image e2s12-161 = im.Scale("season1/episode2/images/scene12/161.webp", 1920, 1080)
image e2s12-162 = im.Scale("season1/episode2/images/scene12/162.webp", 1920, 1080)
image e2s12-163 = im.Scale("season1/episode2/images/scene12/163.webp", 1920, 1080)
image e2s12-164 = im.Scale("season1/episode2/images/scene12/164.webp", 1920, 1080)
image e2s12-165 = im.Scale("season1/episode2/images/scene12/165.webp", 1920, 1080)
image e2s12-166 = im.Scale("season1/episode2/images/scene12/166.webp", 1920, 1080)
image e2s12-167 = im.Scale("season1/episode2/images/scene12/167.webp", 1920, 1080)
image e2s12-168 = im.Scale("season1/episode2/images/scene12/168.webp", 1920, 1080)
image e2s12-169 = im.Scale("season1/episode2/images/scene12/169.webp", 1920, 1080)
image e2s12-170 = im.Scale("season1/episode2/images/scene12/170.webp", 1920, 1080)
image e2s12-171 = im.Scale("season1/episode2/images/scene12/171.webp", 1920, 1080)
image e2s12-172 = im.Scale("season1/episode2/images/scene12/172.webp", 1920, 1080)
image e2s12-173 = im.Scale("season1/episode2/images/scene12/173.webp", 1920, 1080)
image e2s12-173-1 = im.Scale("season1/episode2/images/scene12/173.1.webp", 1920, 1080)
image e2s12-174 = im.Scale("season1/episode2/images/scene12/174.webp", 1920, 1080)
image e2s12-175 = im.Scale("season1/episode2/images/scene12/175.webp", 1920, 1080)
image e2s12-176 = im.Scale("season1/episode2/images/scene12/176.webp", 1920, 1080)
image e2s12-177 = im.Scale("season1/episode2/images/scene12/177.webp", 1920, 1080)
image e2s12-178 = im.Scale("season1/episode2/images/scene12/178.webp", 1920, 1080)
image e2s12-179 = im.Scale("season1/episode2/images/scene12/179.webp", 1920, 1080)
image e2s12-180 = im.Scale("season1/episode2/images/scene12/180.webp", 1920, 1080)
image e2s12-181 = im.Scale("season1/episode2/images/scene12/181.webp", 1920, 1080)
image e2s12-182 = im.Scale("season1/episode2/images/scene12/182.webp", 1920, 1080)
image e2s12-183 = im.Scale("season1/episode2/images/scene12/183.webp", 1920, 1080)
image e2s12-184 = im.Scale("season1/episode2/images/scene12/184.webp", 1920, 1080)
image e2s12-185 = im.Scale("season1/episode2/images/scene12/185.webp", 1920, 1080)
image e2s12-186 = im.Scale("season1/episode2/images/scene12/186.webp", 1920, 1080)
image e2s12-187 = im.Scale("season1/episode2/images/scene12/187.webp", 1920, 1080)
image e2s12-188 = im.Scale("season1/episode2/images/scene12/188.webp", 1920, 1080)
image e2s12-189 = im.Scale("season1/episode2/images/scene12/189.webp", 1920, 1080)
image e2s12-190 = im.Scale("season1/episode2/images/scene12/190.webp", 1920, 1080)
image e2s12-191 = im.Scale("season1/episode2/images/scene12/191.webp", 1920, 1080)
image e2s12-192 = im.Scale("season1/episode2/images/scene12/192.webp", 1920, 1080)
image e2s12-193 = im.Scale("season1/episode2/images/scene12/193.webp", 1920, 1080)
image e2s12-194 = im.Scale("season1/episode2/images/scene12/194.webp", 1920, 1080)
image e2s12-195 = im.Scale("season1/episode2/images/scene12/195.webp", 1920, 1080)
image e2s12-196 = im.Scale("season1/episode2/images/scene12/196.webp", 1920, 1080)
image e2s12-197 = im.Scale("season1/episode2/images/scene12/197.webp", 1920, 1080)
image e2s12-198 = im.Scale("season1/episode2/images/scene12/198.webp", 1920, 1080)
image e2s12-199 = im.Scale("season1/episode2/images/scene12/199.webp", 1920, 1080)
image e2s12-200 = im.Scale("season1/episode2/images/scene12/200.webp", 1920, 1080)
image e2s12-201 = im.Scale("season1/episode2/images/scene12/201.webp", 1920, 1080)
image e2s12-202 = im.Scale("season1/episode2/images/scene12/202.webp", 1920, 1080)
image e2s12-203 = im.Scale("season1/episode2/images/scene12/203.webp", 1920, 1080)
image e2s12-204 = im.Scale("season1/episode2/images/scene12/204.webp", 1920, 1080)
image e2s12-205 = im.Scale("season1/episode2/images/scene12/205.webp", 1920, 1080)
image e2s12-206 = im.Scale("season1/episode2/images/scene12/206.webp", 1920, 1080)
image e2s12-207 = im.Scale("season1/episode2/images/scene12/207.webp", 1920, 1080)
image e2s12-208 = im.Scale("season1/episode2/images/scene12/208.webp", 1920, 1080)
image e2s12-209 = im.Scale("season1/episode2/images/scene12/209.webp", 1920, 1080)
image e2s12-210 = im.Scale("season1/episode2/images/scene12/210.webp", 1920, 1080)
image e2s12-211 = im.Scale("season1/episode2/images/scene12/211.webp", 1920, 1080)
image e2s12-212 = im.Scale("season1/episode2/images/scene12/212.webp", 1920, 1080)
image e2s12-213 = im.Scale("season1/episode2/images/scene12/213.webp", 1920, 1080)
image e2s12-214 = im.Scale("season1/episode2/images/scene12/214.webp", 1920, 1080)
image e2s12-215 = im.Scale("season1/episode2/images/scene12/215.webp", 1920, 1080)
image e2s12-216 = im.Scale("season1/episode2/images/scene12/216.webp", 1920, 1080)
image e2s12-217 = im.Scale("season1/episode2/images/scene12/217.webp", 1920, 1080)
image e2s12-218 = im.Scale("season1/episode2/images/scene12/218.webp", 1920, 1080)
image e2s12-219 = im.Scale("season1/episode2/images/scene12/219.webp", 1920, 1080)
image e2s12-220 = im.Scale("season1/episode2/images/scene12/220.webp", 1920, 1080)
image e2s12-221 = im.Scale("season1/episode2/images/scene12/221.webp", 1920, 1080)
image e2s12-222 = im.Scale("season1/episode2/images/scene12/222.webp", 1920, 1080)
image e2s12-223 = im.Scale("season1/episode2/images/scene12/223.webp", 1920, 1080)
image e2s12-224 = im.Scale("season1/episode2/images/scene12/224.webp", 1920, 1080)
image e2s12-225 = im.Scale("season1/episode2/images/scene12/225.webp", 1920, 1080)
image e2s12-226 = im.Scale("season1/episode2/images/scene12/226.webp", 1920, 1080)
image e2s12-227 = im.Scale("season1/episode2/images/scene12/227.webp", 1920, 1080)
image e2s12-228 = im.Scale("season1/episode2/images/scene12/228.webp", 1920, 1080)

image e2s12-120_cen = im.Scale("season1/episode2/images/scene12/censored/120.webp", 1920, 1080)

image e2s12-cleo_blink1:
    im.Scale("season1/episode2/images/scene12/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-cleo_blink2:
    im.Scale("season1/episode2/images/scene12/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-cleo_blink3:
    im.Scale("season1/episode2/images/scene12/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-cleo_blink4:
    im.Scale("season1/episode2/images/scene12/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-cleo_blink5:
    im.Scale("season1/episode2/images/scene12/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-cleo_blink6:
    im.Scale("season1/episode2/images/scene12/cleo_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/cleo_blink6/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-darryl_blink1:
    im.Scale("season1/episode2/images/scene12/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/darryl_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s12-unknown_blink1:
    im.Scale("season1/episode2/images/scene12/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene12/unknown_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
