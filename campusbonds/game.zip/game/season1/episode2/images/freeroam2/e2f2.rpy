
# Freeroam 2 - House party rocks ###############################################

# Map ##########################################################################
# Main #
image e2f2-main = im.Scale("season1/episode2/images/freeroam2/1.webp", 1920, 1080)
image e2f2-main_1 = im.Scale("season1/episode2/images/freeroam2/1.1.webp", 1920, 1080)
image e2f2-main_2 = im.Scale("season1/episode2/images/freeroam2/1.2.webp", 1920, 1080)

# Sofa #
image e2f2-sofa = im.Scale("season1/episode2/images/freeroam2/2.webp", 1920, 1080)
image e2f2-sofa_1 = im.Scale("season1/episode2/images/freeroam2/2.1.webp", 1920, 1080)

# Kitchen #
image e2f2-kitchen = im.Scale("season1/episode2/images/freeroam2/3.webp", 1920, 1080)
image e2f2-kitchen_1 = im.Scale("season1/episode2/images/freeroam2/3.1.webp", 1920, 1080)

# Hallway #
image e2f2-hallway = im.Scale("season1/episode2/images/freeroam2/4.webp", 1920, 1080)
image e2f2-hallway_1 = im.Scale("season1/episode2/images/freeroam2/4.1.webp", 1920, 1080)
image e2f2-hallway_2 = im.Scale("season1/episode2/images/freeroam2/4.2.webp", 1920, 1080)

# Bedroom #
image e2f2-bedroom = im.Scale("season1/episode2/images/freeroam2/5.webp", 1920, 1080)
image e2f2-bedroom_1 = im.Scale("season1/episode2/images/freeroam2/5.1.webp", 1920, 1080)

# Drawer #
image e2f2-drawer = im.Scale("season1/episode2/images/freeroam2/6.webp", 1920, 1080)

# Bathroom #
image e2f2-bathroom = im.Scale("season1/episode2/images/freeroam2/7.webp", 1920, 1080)

# Images #######################################################################
# Second part #
image e2f2-sp_01 = im.Scale("season1/episode2/images/freeroam2/images/second_part/1.webp", 1920, 1080)
image e2f2-sp_02 = im.Scale("season1/episode2/images/freeroam2/images/second_part/2.webp", 1920, 1080)
image e2f2-sp_03 = im.Scale("season1/episode2/images/freeroam2/images/second_part/3.webp", 1920, 1080)
image e2f2-sp_04 = im.Scale("season1/episode2/images/freeroam2/images/second_part/4.webp", 1920, 1080)
image e2f2-sp_05 = im.Scale("season1/episode2/images/freeroam2/images/second_part/5.webp", 1920, 1080)
image e2f2-sp_06 = im.Scale("season1/episode2/images/freeroam2/images/second_part/6.webp", 1920, 1080)
image e2f2-sp_07 = im.Scale("season1/episode2/images/freeroam2/images/second_part/7.webp", 1920, 1080)
image e2f2-sp_08 = im.Scale("season1/episode2/images/freeroam2/images/second_part/8.webp", 1920, 1080)
image e2f2-sp_09 = im.Scale("season1/episode2/images/freeroam2/images/second_part/9.webp", 1920, 1080)
image e2f2-sp_10 = im.Scale("season1/episode2/images/freeroam2/images/second_part/10.webp", 1920, 1080)

# Sadie Tracy #
image e2f2-st_01 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/1.webp", 1920, 1080)
image e2f2-st_02 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/2.webp", 1920, 1080)
image e2f2-st_03 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/3.webp", 1920, 1080)
image e2f2-st_04 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/4.webp", 1920, 1080)
image e2f2-st_05 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/5.webp", 1920, 1080)
image e2f2-st_06 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/6.webp", 1920, 1080)
image e2f2-st_07 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/7.webp", 1920, 1080)
image e2f2-st_08 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/8.webp", 1920, 1080)
image e2f2-st_09 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/9.webp", 1920, 1080)
image e2f2-st_10 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/10.webp", 1920, 1080)
image e2f2-st_11 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/11.webp", 1920, 1080)
image e2f2-st_12 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/12.webp", 1920, 1080)
image e2f2-st_13 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/13.webp", 1920, 1080)
image e2f2-st_14 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/14.webp", 1920, 1080)
image e2f2-st_15 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/15.webp", 1920, 1080)
image e2f2-st_16 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/16.webp", 1920, 1080)
image e2f2-st_17 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/17.webp", 1920, 1080)
image e2f2-st_18 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/18.webp", 1920, 1080)
image e2f2-st_19 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/19.webp", 1920, 1080)
image e2f2-st_20 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/20.webp", 1920, 1080)
image e2f2-st_21 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/21.webp", 1920, 1080)
image e2f2-st_22 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/22.webp", 1920, 1080)
image e2f2-st_23 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/23.webp", 1920, 1080)
image e2f2-st_24 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/24.webp", 1920, 1080)
image e2f2-st_25 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/25.webp", 1920, 1080)
image e2f2-st_26 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/26.webp", 1920, 1080)
image e2f2-st_27 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/27.webp", 1920, 1080)
image e2f2-st_28 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/28.webp", 1920, 1080)
image e2f2-st_29 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/29.webp", 1920, 1080)
image e2f2-st_30 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/30.webp", 1920, 1080)
image e2f2-st_31 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/31.webp", 1920, 1080)
image e2f2-st_32 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/32.webp", 1920, 1080)
image e2f2-st_33 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/33.webp", 1920, 1080)
image e2f2-st_34 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/34.webp", 1920, 1080)
image e2f2-st_35 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/35.webp", 1920, 1080)
image e2f2-st_36 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/36.webp", 1920, 1080)
image e2f2-st_37 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/37.webp", 1920, 1080)
image e2f2-st_38 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/38.webp", 1920, 1080)
image e2f2-st_39 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/39.webp", 1920, 1080)
image e2f2-st_40 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/40.webp", 1920, 1080)
image e2f2-st_41 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/41.webp", 1920, 1080)
image e2f2-st_42 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/42.webp", 1920, 1080)
image e2f2-st_43 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/43.webp", 1920, 1080)
image e2f2-st_44 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/44.webp", 1920, 1080)
image e2f2-st_45 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/45.webp", 1920, 1080)
image e2f2-st_46 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/46.webp", 1920, 1080)
image e2f2-st_47 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/47.webp", 1920, 1080)
image e2f2-st_48 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/48.webp", 1920, 1080)
image e2f2-st_49 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/49.webp", 1920, 1080)
image e2f2-st_50 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/50.webp", 1920, 1080)
image e2f2-st_51 = im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/51.webp", 1920, 1080)

image e2f2-st_tracy_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-st_tracy_blink2:
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-st_tracy_blink3:
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/sadie_tracy1/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy Sex #
image e2f2-ts_01 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/1.webp", 1920, 1080)
image e2f2-ts_02 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/2.webp", 1920, 1080)
image e2f2-ts_03 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/3.webp", 1920, 1080)
image e2f2-ts_04 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/4.webp", 1920, 1080)
image e2f2-ts_05 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/5.webp", 1920, 1080)
image e2f2-ts_06 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/6.webp", 1920, 1080)
image e2f2-ts_07 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/7.webp", 1920, 1080)
image e2f2-ts_08 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/8.webp", 1920, 1080)
image e2f2-ts_09 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/9.webp", 1920, 1080)
image e2f2-ts_10 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/10.webp", 1920, 1080)
image e2f2-ts_11 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/11.webp", 1920, 1080)
image e2f2-ts_12 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/12.webp", 1920, 1080)
image e2f2-ts_13 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/13.webp", 1920, 1080)
image e2f2-ts_14 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/14.webp", 1920, 1080)
image e2f2-ts_15 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/15.webp", 1920, 1080)
image e2f2-ts_16 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/16.webp", 1920, 1080)
image e2f2-ts_17 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/17.webp", 1920, 1080)
image e2f2-ts_18 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/18.webp", 1920, 1080)
image e2f2-ts_19 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/19.webp", 1920, 1080)
image e2f2-ts_20 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/20.webp", 1920, 1080)
image e2f2-ts_21 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/21.webp", 1920, 1080)
image e2f2-ts_22 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/22.webp", 1920, 1080)
image e2f2-ts_23 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/23.webp", 1920, 1080)
image e2f2-ts_24 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/24.webp", 1920, 1080)
image e2f2-ts_25 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/25.webp", 1920, 1080)
image e2f2-ts_26 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/26.webp", 1920, 1080)
image e2f2-ts_27 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/27.webp", 1920, 1080)
image e2f2-ts_28 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/28.webp", 1920, 1080)
image e2f2-ts_29 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/29.webp", 1920, 1080)
image e2f2-ts_30 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/30.webp", 1920, 1080)
image e2f2-ts_31 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/31.webp", 1920, 1080)
image e2f2-ts_32 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/32.webp", 1920, 1080)
image e2f2-ts_33 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/33.webp", 1920, 1080)
image e2f2-ts_34 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/34.webp", 1920, 1080)
image e2f2-ts_35 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/35.webp", 1920, 1080)
image e2f2-ts_36 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/36.webp", 1920, 1080)
image e2f2-ts_37 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/37.webp", 1920, 1080)
image e2f2-ts_38 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/38.webp", 1920, 1080)
image e2f2-ts_39 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/39.webp", 1920, 1080)
image e2f2-ts_40 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/40.webp", 1920, 1080)
image e2f2-ts_41 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/41.webp", 1920, 1080)
image e2f2-ts_42 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/42.webp", 1920, 1080)
image e2f2-ts_43 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/43.webp", 1920, 1080)
image e2f2-ts_44 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/44.webp", 1920, 1080)
image e2f2-ts_45 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/45.webp", 1920, 1080)
image e2f2-ts_46 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/46.webp", 1920, 1080)
image e2f2-ts_47 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/47.webp", 1920, 1080)
image e2f2-ts_48 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/48.webp", 1920, 1080)
image e2f2-ts_49 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/49.webp", 1920, 1080)
image e2f2-ts_50 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/50.webp", 1920, 1080)
image e2f2-ts_51 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/51.webp", 1920, 1080)
image e2f2-ts_52 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/52.webp", 1920, 1080)
image e2f2-ts_53 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/53.webp", 1920, 1080)
image e2f2-ts_54 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/54.webp", 1920, 1080)
image e2f2-ts_55 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/55.webp", 1920, 1080)
image e2f2-ts_56 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/56.webp", 1920, 1080)
image e2f2-ts_57 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/57.webp", 1920, 1080)
image e2f2-ts_58 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/58.webp", 1920, 1080)
image e2f2-ts_59 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/59.webp", 1920, 1080)
image e2f2-ts_60 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/60.webp", 1920, 1080)
image e2f2-ts_61 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/61.webp", 1920, 1080)
image e2f2-ts_62 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/62.webp", 1920, 1080)
image e2f2-ts_63 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/63.webp", 1920, 1080)
image e2f2-ts_64 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/64.webp", 1920, 1080)
image e2f2-ts_65 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/65.webp", 1920, 1080)
image e2f2-ts_66 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/66.webp", 1920, 1080)
image e2f2-ts_67 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/67.webp", 1920, 1080)
image e2f2-ts_68 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/68.webp", 1920, 1080)
image e2f2-ts_69 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/69.webp", 1920, 1080)
image e2f2-ts_70 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/70.webp", 1920, 1080)
image e2f2-ts_71 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/71.webp", 1920, 1080)
image e2f2-ts_72 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/72.webp", 1920, 1080)
image e2f2-ts_73 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/73.webp", 1920, 1080)
image e2f2-ts_74 = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/74.webp", 1920, 1080)

# Animations #

image e2f2-ts_tracy_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-ts_tracy_blink2:
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-ts_tracy_blink3:
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/tracy_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Uncensored #
image e2f2-ts-blowjob1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/blowjob1.webm")
image e2f2-ts-blowjob2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/blowjob2.webm")
image e2f2-ts-blowjob3 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/blowjob3.webm")
image e2f2-ts-cowgirl1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/cowgirl1.webm")
image e2f2-ts-cowgirl2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/cowgirl2.webm")
image e2f2-ts-cowgirl3 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/cowgirl3.webm")
image e2f2-ts-cowgirl4 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/cowgirl4.webm")
image e2f2-ts-doggy1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy1.webm")
image e2f2-ts-doggy2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy2.webm")
image e2f2-ts-doggy3 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy3.webm")
image e2f2-ts-doggy4 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy4.webm")
image e2f2-ts-doggy5 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy5.webm")
image e2f2-ts-doggy6 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/doggy6.webm")
image e2f2-ts-handjob1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/handjob1.webm")
image e2f2-ts-handjob2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/handjob2.webm")
image e2f2-ts-handjob3 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/handjob3.webm")
image e2f2-ts-missionary1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/missionary1.webm")
image e2f2-ts-missionary2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/missionary2.webm")
image e2f2-ts-missionary3 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/missionary3.webm")
image e2f2-ts-titjob1 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/titjob1.webm")
image e2f2-ts-titjob2 = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/titjob2.webm")

image e2f2-ts-kiss = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/kiss.webm")
image e2f2-ts-cowgirl_insert = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/cowgirl_insert.webm")

# Censored #
# Images #
image e2f2-ts_08_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/8.webp", 1920, 1080)
image e2f2-ts_41_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/41.webp", 1920, 1080)
image e2f2-ts_44_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/44.webp", 1920, 1080)
image e2f2-ts_45_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/45.webp", 1920, 1080)
image e2f2-ts_46_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/46.webp", 1920, 1080)
image e2f2-ts_50_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/50.webp", 1920, 1080)
image e2f2-ts_51_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/51.webp", 1920, 1080)
image e2f2-ts_52_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/52.webp", 1920, 1080)
image e2f2-ts_64_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/64.webp", 1920, 1080)
image e2f2-ts_65_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/65.webp", 1920, 1080)
image e2f2-ts_66_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/66.webp", 1920, 1080)
image e2f2-ts_67_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/67.webp", 1920, 1080)
image e2f2-ts_69_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/69.webp", 1920, 1080)
image e2f2-ts_70_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/70.webp", 1920, 1080)
image e2f2-ts_71_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/71.webp", 1920, 1080)
image e2f2-ts_72_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/72.webp", 1920, 1080)
image e2f2-ts_73_cen = im.Scale("season1/episode2/images/freeroam2/images/tracy_sex/censored/73.webp", 1920, 1080)

# Animations #
image e2f2-ts-blowjob1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/blowjob1.webm")
image e2f2-ts-blowjob2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/blowjob2.webm")
image e2f2-ts-blowjob3_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/blowjob3.webm")
image e2f2-ts-cowgirl1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/cowgirl1.webm")
image e2f2-ts-cowgirl2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/cowgirl2.webm")
image e2f2-ts-cowgirl3_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/cowgirl3.webm")
image e2f2-ts-cowgirl4_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/cowgirl4.webm")
image e2f2-ts-doggy1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/doggy1.webm")
image e2f2-ts-doggy2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/doggy2.webm")
image e2f2-ts-doggy3_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/doggy3.webm")
image e2f2-ts-doggy4_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/doggy4.webm")
image e2f2-ts-doggy5_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/doggy5.webm")
image e2f2-ts-handjob1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/handjob1.webm")
image e2f2-ts-handjob2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/handjob2.webm")
image e2f2-ts-handjob3_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/handjob3.webm")
image e2f2-ts-missionary1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/missionary1.webm")
image e2f2-ts-missionary2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/missionary2.webm")
image e2f2-ts-missionary3_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/missionary3.webm")
image e2f2-ts-titjob1_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/titjob1.webm")
image e2f2-ts-titjob2_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/titjob2.webm")

image e2f2-ts-cowgirl_insert_cen = Movie(play="season1/episode2/images/freeroam2/images/tracy_sex/censored/cowgirl_insert.webm")

# Tracy1 #
image e2f2-tr1_01 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/1.webp", 1920, 1080)
image e2f2-tr1_02 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/2.webp", 1920, 1080)
image e2f2-tr1_03 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/3.webp", 1920, 1080)
image e2f2-tr1_04 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/4.webp", 1920, 1080)
image e2f2-tr1_05 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/5.webp", 1920, 1080)
image e2f2-tr1_06 = im.Scale("season1/episode2/images/freeroam2/images/tracy1/6.webp", 1920, 1080)

# Tracy2 #
image e2f2-tr2_01 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/1.webp", 1920, 1080)
image e2f2-tr2_02 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/2.webp", 1920, 1080)
image e2f2-tr2_03 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/3.webp", 1920, 1080)
image e2f2-tr2_04 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/4.webp", 1920, 1080)
image e2f2-tr2_05 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/5.webp", 1920, 1080)
image e2f2-tr2_06 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/6.webp", 1920, 1080)
image e2f2-tr2_07 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/7.webp", 1920, 1080)
image e2f2-tr2_08 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/8.webp", 1920, 1080)
image e2f2-tr2_09 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/9.webp", 1920, 1080)
image e2f2-tr2_10 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/10.webp", 1920, 1080)
image e2f2-tr2_11 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/11.webp", 1920, 1080)
image e2f2-tr2_12 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/12.webp", 1920, 1080)
image e2f2-tr2_13 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/13.webp", 1920, 1080)
image e2f2-tr2_14 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/14.webp", 1920, 1080)
image e2f2-tr2_15 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/15.webp", 1920, 1080)
image e2f2-tr2_16 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/16.webp", 1920, 1080)
image e2f2-tr2_17 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/17.webp", 1920, 1080)
image e2f2-tr2_18 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/18.webp", 1920, 1080)
image e2f2-tr2_19 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/19.webp", 1920, 1080)
image e2f2-tr2_20 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/20.webp", 1920, 1080)
image e2f2-tr2_21 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/21.webp", 1920, 1080)
image e2f2-tr2_22 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/22.webp", 1920, 1080)
image e2f2-tr2_23 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/23.webp", 1920, 1080)
image e2f2-tr2_24 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/24.webp", 1920, 1080)
image e2f2-tr2_25 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/25.webp", 1920, 1080)
image e2f2-tr2_26 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/26.webp", 1920, 1080)
image e2f2-tr2_27 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/27.webp", 1920, 1080)
image e2f2-tr2_28 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/28.webp", 1920, 1080)
image e2f2-tr2_29 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/29.webp", 1920, 1080)
image e2f2-tr2_30 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/30.webp", 1920, 1080)
image e2f2-tr2_31 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/31.webp", 1920, 1080)
image e2f2-tr2_32 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/32.webp", 1920, 1080)
image e2f2-tr2_33 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/33.webp", 1920, 1080)
image e2f2-tr2_34 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/34.webp", 1920, 1080)
image e2f2-tr2_35 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/35.webp", 1920, 1080)
image e2f2-tr2_36 = im.Scale("season1/episode2/images/freeroam2/images/tracy2/36.webp", 1920, 1080)

image e2f2-tr2_tracy_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-tr2_tracy_blink2:
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tracy2/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Scarlett #
image e2f2-sc_01 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/1.webp", 1920, 1080)
image e2f2-sc_02 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/2.webp", 1920, 1080)
image e2f2-sc_03 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/3.webp", 1920, 1080)
image e2f2-sc_04 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/4.webp", 1920, 1080)
image e2f2-sc_05 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/5.webp", 1920, 1080)
image e2f2-sc_06 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/6.webp", 1920, 1080)
image e2f2-sc_07 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/7.webp", 1920, 1080)
image e2f2-sc_08 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/8.webp", 1920, 1080)
image e2f2-sc_09 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/9.webp", 1920, 1080)
image e2f2-sc_10 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/10.webp", 1920, 1080)
image e2f2-sc_11 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/11.webp", 1920, 1080)
image e2f2-sc_12 = im.Scale("season1/episode2/images/freeroam2/images/scarlett1/12.webp", 1920, 1080)

image e2f2-sc_scarlett_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/scarlett1/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Jon Jordan #
image e2f2-jj_01 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/1.webp", 1920, 1080)
image e2f2-jj_02 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/2.webp", 1920, 1080)
image e2f2-jj_03 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/3.webp", 1920, 1080)
image e2f2-jj_04 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/4.webp", 1920, 1080)
image e2f2-jj_05 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/5.webp", 1920, 1080)
image e2f2-jj_06 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/6.webp", 1920, 1080)
image e2f2-jj_07 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/7.webp", 1920, 1080)
image e2f2-jj_08 = im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/8.webp", 1920, 1080)

image e2f2-jj_jordan_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/jon_jordan/jordan_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tiffany #
# Images #
# Uncensored
image e2f2-tf_01 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/1.webp", 1920, 1080)
image e2f2-tf_02 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/2.webp", 1920, 1080)
image e2f2-tf_03 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/3.webp", 1920, 1080)
image e2f2-tf_04 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/4.webp", 1920, 1080)
image e2f2-tf_05 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/5.webp", 1920, 1080)
image e2f2-tf_06 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/6.webp", 1920, 1080)
image e2f2-tf_07 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/7.webp", 1920, 1080)
image e2f2-tf_08 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/8.webp", 1920, 1080)
image e2f2-tf_09 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/9.webp", 1920, 1080)
image e2f2-tf_10 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/10.webp", 1920, 1080)
image e2f2-tf_11 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/11.webp", 1920, 1080)
image e2f2-tf_12 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/12.webp", 1920, 1080)
image e2f2-tf_13 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/13.webp", 1920, 1080)
image e2f2-tf_14 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/14.webp", 1920, 1080)
image e2f2-tf_15 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/15.webp", 1920, 1080)
image e2f2-tf_16 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/16.webp", 1920, 1080)
image e2f2-tf_17 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/17.webp", 1920, 1080)
image e2f2-tf_18 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/18.webp", 1920, 1080)
image e2f2-tf_19 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/19.webp", 1920, 1080)
image e2f2-tf_20 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/20.webp", 1920, 1080)
image e2f2-tf_21 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/21.webp", 1920, 1080)
image e2f2-tf_22 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/22.webp", 1920, 1080)
image e2f2-tf_23 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/23.webp", 1920, 1080)
image e2f2-tf_24 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/24.webp", 1920, 1080)
image e2f2-tf_25 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/25.webp", 1920, 1080)
image e2f2-tf_26 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/26.webp", 1920, 1080)
image e2f2-tf_27 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/27.webp", 1920, 1080)
image e2f2-tf_28 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/28.webp", 1920, 1080)
image e2f2-tf_29 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/29.webp", 1920, 1080)
image e2f2-tf_30 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/30.webp", 1920, 1080)
image e2f2-tf_31 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/31.webp", 1920, 1080)
image e2f2-tf_32 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/32.webp", 1920, 1080)
image e2f2-tf_33 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/33.webp", 1920, 1080)
image e2f2-tf_34 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/34.webp", 1920, 1080)
image e2f2-tf_35 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/35.webp", 1920, 1080)
image e2f2-tf_36 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/36.webp", 1920, 1080)
image e2f2-tf_37 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/37.webp", 1920, 1080)
image e2f2-tf_38 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/38.webp", 1920, 1080)
image e2f2-tf_39 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/39.webp", 1920, 1080)
image e2f2-tf_40 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/40.webp", 1920, 1080)
image e2f2-tf_41 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/41.webp", 1920, 1080)
image e2f2-tf_42 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/42.webp", 1920, 1080)
image e2f2-tf_43 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/43.webp", 1920, 1080)
image e2f2-tf_44 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/44.webp", 1920, 1080)
image e2f2-tf_45 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/45.webp", 1920, 1080)
image e2f2-tf_46 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/46.webp", 1920, 1080)
image e2f2-tf_47 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/47.webp", 1920, 1080)
image e2f2-tf_48 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/48.webp", 1920, 1080)
image e2f2-tf_49 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/49.webp", 1920, 1080)
image e2f2-tf_50 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/50.webp", 1920, 1080)
image e2f2-tf_51 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/51.webp", 1920, 1080)
image e2f2-tf_52 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/52.webp", 1920, 1080)
image e2f2-tf_53 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/53.webp", 1920, 1080)
image e2f2-tf_54 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/54.webp", 1920, 1080)
image e2f2-tf_55 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/55.webp", 1920, 1080)
image e2f2-tf_56 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/56.webp", 1920, 1080)
image e2f2-tf_57 = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/57.webp", 1920, 1080)

# Censored
image e2f2-tf_43_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/43.webp", 1920, 1080)
image e2f2-tf_44_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/44.webp", 1920, 1080)
image e2f2-tf_45_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/45.webp", 1920, 1080)
image e2f2-tf_46_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/46.webp", 1920, 1080)
image e2f2-tf_47_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/47.webp", 1920, 1080)
image e2f2-tf_48_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/48.webp", 1920, 1080)
image e2f2-tf_49_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/49.webp", 1920, 1080)
image e2f2-tf_50_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/50.webp", 1920, 1080)
image e2f2-tf_51_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/51.webp", 1920, 1080)
image e2f2-tf_52_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/52.webp", 1920, 1080)
image e2f2-tf_53_cen = im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/censored/53.webp", 1920, 1080)

# Animations #
# Uncensored
image e2f2-tf-blowjob1 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/blowjob1.webm")
image e2f2-tf-blowjob2 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/blowjob2.webm")
image e2f2-tf-blowjob3 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/blowjob3.webm")
image e2f2-tf-blowjob4 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/blowjob4.webm")
image e2f2-tf-handjob1 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/handjob1.webm")
image e2f2-tf-handjob2 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/handjob2.webm")
image e2f2-tf-handjob3 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/handjob3.webm")
image e2f2-tf-handjob4 = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/handjob4.webm")

# Censored
image e2f2-tf-blowjob1_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/blowjob1.webm")
image e2f2-tf-blowjob2_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/blowjob2.webm")
image e2f2-tf-blowjob3_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/blowjob3.webm")
image e2f2-tf-blowjob4_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/blowjob4.webm")
image e2f2-tf-handjob1_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/handjob1.webm")
image e2f2-tf-handjob2_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/handjob2.webm")
image e2f2-tf-handjob3_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/handjob3.webm")
image e2f2-tf-handjob4_cen = Movie(play="season1/episode2/images/freeroam2/images/tiffany_sex/censored/handjob4.webm")

# Blink
image e2f2-tf_tiffany_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-tf_tiffany_blink2:
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-tf_tiffany_blink3:
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-tf_tiffany_blink4:
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f2-tf_tiffany_blink5:
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/tiffany_sex/tiffany_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ken Roman # ##################################################################
image e2f2-kr_01 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/1.webp", 1920, 1080)
image e2f2-kr_02 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/2.webp", 1920, 1080)
image e2f2-kr_03 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/3.webp", 1920, 1080)
image e2f2-kr_04 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/4.webp", 1920, 1080)
image e2f2-kr_05 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/5.webp", 1920, 1080)
image e2f2-kr_06 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/6.webp", 1920, 1080)
image e2f2-kr_07 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/7.webp", 1920, 1080)
image e2f2-kr_08 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/8.webp", 1920, 1080)
image e2f2-kr_09 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/9.webp", 1920, 1080)
image e2f2-kr_10 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/10.webp", 1920, 1080)
image e2f2-kr_11 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/11.webp", 1920, 1080)
image e2f2-kr_12 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/12.webp", 1920, 1080)
image e2f2-kr_13 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/13.webp", 1920, 1080)
image e2f2-kr_14 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/14.webp", 1920, 1080)
image e2f2-kr_15 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/15.webp", 1920, 1080)
image e2f2-kr_16 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/16.webp", 1920, 1080)
image e2f2-kr_17 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/17.webp", 1920, 1080)
image e2f2-kr_18 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/18.webp", 1920, 1080)
image e2f2-kr_19 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/19.webp", 1920, 1080)
image e2f2-kr_20 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/20.webp", 1920, 1080)
image e2f2-kr_21 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/21.webp", 1920, 1080)
image e2f2-kr_22 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/22.webp", 1920, 1080)
image e2f2-kr_23 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/23.webp", 1920, 1080)
image e2f2-kr_24 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/24.webp", 1920, 1080)
image e2f2-kr_25 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/25.webp", 1920, 1080)
image e2f2-kr_26 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/26.webp", 1920, 1080)
image e2f2-kr_27 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/27.webp", 1920, 1080)
image e2f2-kr_28 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/28.webp", 1920, 1080)
image e2f2-kr_29 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/29.webp", 1920, 1080)
image e2f2-kr_30 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/30.webp", 1920, 1080)
image e2f2-kr_31 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/31.webp", 1920, 1080)
image e2f2-kr_32 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/32.webp", 1920, 1080)
image e2f2-kr_33 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/33.webp", 1920, 1080)
image e2f2-kr_34 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/34.webp", 1920, 1080)
image e2f2-kr_35 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/35.webp", 1920, 1080)
image e2f2-kr_36 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/36.webp", 1920, 1080)
image e2f2-kr_37 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/37.webp", 1920, 1080)
image e2f2-kr_38 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/38.webp", 1920, 1080)
image e2f2-kr_39 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/39.webp", 1920, 1080)
image e2f2-kr_40 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/40.webp", 1920, 1080)
image e2f2-kr_41 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/41.webp", 1920, 1080)
image e2f2-kr_42 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/42.webp", 1920, 1080)
image e2f2-kr_43 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/43.webp", 1920, 1080)
image e2f2-kr_44 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/44.webp", 1920, 1080)
image e2f2-kr_45 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/45.webp", 1920, 1080)
image e2f2-kr_46 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/46.webp", 1920, 1080)
image e2f2-kr_47 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/47.webp", 1920, 1080)
image e2f2-kr_48 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/48.webp", 1920, 1080)
image e2f2-kr_49 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/49.webp", 1920, 1080)
image e2f2-kr_50 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/50.webp", 1920, 1080)
image e2f2-kr_51 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/51.webp", 1920, 1080)
image e2f2-kr_52 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/52.webp", 1920, 1080)
image e2f2-kr_53 = im.Scale("season1/episode2/images/freeroam2/images/ken_roman/53.webp", 1920, 1080)

# Ken # ########################################################################
image e2f2-ke_01 = im.Scale("season1/episode2/images/freeroam2/images/ken1/1.webp", 1920, 1080)
image e2f2-ke_02 = im.Scale("season1/episode2/images/freeroam2/images/ken1/2.webp", 1920, 1080)
image e2f2-ke_03 = im.Scale("season1/episode2/images/freeroam2/images/ken1/3.webp", 1920, 1080)
image e2f2-ke_04 = im.Scale("season1/episode2/images/freeroam2/images/ken1/4.webp", 1920, 1080)
image e2f2-ke_05 = im.Scale("season1/episode2/images/freeroam2/images/ken1/5.webp", 1920, 1080)
image e2f2-ke_06 = im.Scale("season1/episode2/images/freeroam2/images/ken1/6.webp", 1920, 1080)
image e2f2-ke_07 = im.Scale("season1/episode2/images/freeroam2/images/ken1/7.webp", 1920, 1080)
image e2f2-ke_08 = im.Scale("season1/episode2/images/freeroam2/images/ken1/8.webp", 1920, 1080)
image e2f2-ke_09 = im.Scale("season1/episode2/images/freeroam2/images/ken1/9.webp", 1920, 1080)
image e2f2-ke_10 = im.Scale("season1/episode2/images/freeroam2/images/ken1/10.webp", 1920, 1080)

image e2f2-ke_ken_blink1:
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy ########################################################################
