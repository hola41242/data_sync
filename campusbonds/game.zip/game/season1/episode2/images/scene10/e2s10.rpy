
# Scene 10 images ##############################################################

### Francesca ###
# Images ##
image e2s10_fr-01 = im.Scale("season1/episode2/images/scene10/francesca/1.webp", 1920, 1080)
image e2s10_fr-02 = im.Scale("season1/episode2/images/scene10/francesca/2.webp", 1920, 1080)
image e2s10_fr-03 = im.Scale("season1/episode2/images/scene10/francesca/3.webp", 1920, 1080)
image e2s10_fr-04 = im.Scale("season1/episode2/images/scene10/francesca/4.webp", 1920, 1080)
image e2s10_fr-05 = im.Scale("season1/episode2/images/scene10/francesca/5.webp", 1920, 1080)
image e2s10_fr-06 = im.Scale("season1/episode2/images/scene10/francesca/6.webp", 1920, 1080)
image e2s10_fr-07 = im.Scale("season1/episode2/images/scene10/francesca/7.webp", 1920, 1080)
image e2s10_fr-08 = im.Scale("season1/episode2/images/scene10/francesca/8.webp", 1920, 1080)
image e2s10_fr-09 = im.Scale("season1/episode2/images/scene10/francesca/9.webp", 1920, 1080)
image e2s10_fr-10 = im.Scale("season1/episode2/images/scene10/francesca/10.webp", 1920, 1080)
image e2s10_fr-11 = im.Scale("season1/episode2/images/scene10/francesca/11.webp", 1920, 1080)
image e2s10_fr-12 = im.Scale("season1/episode2/images/scene10/francesca/12.webp", 1920, 1080)
image e2s10_fr-13 = im.Scale("season1/episode2/images/scene10/francesca/13.webp", 1920, 1080)
image e2s10_fr-14 = im.Scale("season1/episode2/images/scene10/francesca/14.webp", 1920, 1080)
image e2s10_fr-15 = im.Scale("season1/episode2/images/scene10/francesca/15.webp", 1920, 1080)
image e2s10_fr-16 = im.Scale("season1/episode2/images/scene10/francesca/16.webp", 1920, 1080)
image e2s10_fr-17 = im.Scale("season1/episode2/images/scene10/francesca/17.webp", 1920, 1080)
image e2s10_fr-18 = im.Scale("season1/episode2/images/scene10/francesca/18.webp", 1920, 1080)
image e2s10_fr-19 = im.Scale("season1/episode2/images/scene10/francesca/19.webp", 1920, 1080)
image e2s10_fr-20 = im.Scale("season1/episode2/images/scene10/francesca/20.webp", 1920, 1080)
image e2s10_fr-21 = im.Scale("season1/episode2/images/scene10/francesca/21.webp", 1920, 1080)
image e2s10_fr-22 = im.Scale("season1/episode2/images/scene10/francesca/22.webp", 1920, 1080)
image e2s10_fr-23 = im.Scale("season1/episode2/images/scene10/francesca/23.webp", 1920, 1080)
image e2s10_fr-24 = im.Scale("season1/episode2/images/scene10/francesca/24.webp", 1920, 1080)
image e2s10_fr-25 = im.Scale("season1/episode2/images/scene10/francesca/25.webp", 1920, 1080)
image e2s10_fr-26 = im.Scale("season1/episode2/images/scene10/francesca/26.webp", 1920, 1080)
image e2s10_fr-27 = im.Scale("season1/episode2/images/scene10/francesca/27.webp", 1920, 1080)
image e2s10_fr-28 = im.Scale("season1/episode2/images/scene10/francesca/28.webp", 1920, 1080)
image e2s10_fr-29 = im.Scale("season1/episode2/images/scene10/francesca/29.webp", 1920, 1080)
image e2s10_fr-30 = im.Scale("season1/episode2/images/scene10/francesca/30.webp", 1920, 1080)
image e2s10_fr-31 = im.Scale("season1/episode2/images/scene10/francesca/31.webp", 1920, 1080)
image e2s10_fr-32 = im.Scale("season1/episode2/images/scene10/francesca/32.webp", 1920, 1080)
image e2s10_fr-33 = im.Scale("season1/episode2/images/scene10/francesca/33.webp", 1920, 1080)
image e2s10_fr-34 = im.Scale("season1/episode2/images/scene10/francesca/34.webp", 1920, 1080)
image e2s10_fr-35 = im.Scale("season1/episode2/images/scene10/francesca/35.webp", 1920, 1080)
image e2s10_fr-36 = im.Scale("season1/episode2/images/scene10/francesca/36.webp", 1920, 1080)
image e2s10_fr-37 = im.Scale("season1/episode2/images/scene10/francesca/37.webp", 1920, 1080)
image e2s10_fr-38 = im.Scale("season1/episode2/images/scene10/francesca/38.webp", 1920, 1080)
image e2s10_fr-39 = im.Scale("season1/episode2/images/scene10/francesca/39.webp", 1920, 1080)
image e2s10_fr-40 = im.Scale("season1/episode2/images/scene10/francesca/40.webp", 1920, 1080)
image e2s10_fr-41 = im.Scale("season1/episode2/images/scene10/francesca/41.webp", 1920, 1080)
image e2s10_fr-42 = im.Scale("season1/episode2/images/scene10/francesca/42.webp", 1920, 1080)
image e2s10_fr-43 = im.Scale("season1/episode2/images/scene10/francesca/43.webp", 1920, 1080)
image e2s10_fr-44 = im.Scale("season1/episode2/images/scene10/francesca/44.webp", 1920, 1080)
image e2s10_fr-45 = im.Scale("season1/episode2/images/scene10/francesca/45.webp", 1920, 1080)
image e2s10_fr-46 = im.Scale("season1/episode2/images/scene10/francesca/46.webp", 1920, 1080)
image e2s10_fr-47 = im.Scale("season1/episode2/images/scene10/francesca/47.webp", 1920, 1080)
image e2s10_fr-48 = im.Scale("season1/episode2/images/scene10/francesca/48.webp", 1920, 1080)
image e2s10_fr-49 = im.Scale("season1/episode2/images/scene10/francesca/49.webp", 1920, 1080)
image e2s10_fr-50 = im.Scale("season1/episode2/images/scene10/francesca/50.webp", 1920, 1080)
image e2s10_fr-51 = im.Scale("season1/episode2/images/scene10/francesca/51.webp", 1920, 1080)
image e2s10_fr-52 = im.Scale("season1/episode2/images/scene10/francesca/52.webp", 1920, 1080)
image e2s10_fr-53 = im.Scale("season1/episode2/images/scene10/francesca/53.webp", 1920, 1080)
image e2s10_fr-54 = im.Scale("season1/episode2/images/scene10/francesca/54.webp", 1920, 1080)
image e2s10_fr-55 = im.Scale("season1/episode2/images/scene10/francesca/55.webp", 1920, 1080)
image e2s10_fr-56 = im.Scale("season1/episode2/images/scene10/francesca/56.webp", 1920, 1080)
image e2s10_fr-57 = im.Scale("season1/episode2/images/scene10/francesca/57.webp", 1920, 1080)
image e2s10_fr-58 = im.Scale("season1/episode2/images/scene10/francesca/58.webp", 1920, 1080)
image e2s10_fr-59 = im.Scale("season1/episode2/images/scene10/francesca/59.webp", 1920, 1080)
image e2s10_fr-60 = im.Scale("season1/episode2/images/scene10/francesca/60.webp", 1920, 1080)
image e2s10_fr-61 = im.Scale("season1/episode2/images/scene10/francesca/61.webp", 1920, 1080)
image e2s10_fr-62 = im.Scale("season1/episode2/images/scene10/francesca/62.webp", 1920, 1080)
image e2s10_fr-63 = im.Scale("season1/episode2/images/scene10/francesca/63.webp", 1920, 1080)
image e2s10_fr-64 = im.Scale("season1/episode2/images/scene10/francesca/64.webp", 1920, 1080)
image e2s10_fr-65 = im.Scale("season1/episode2/images/scene10/francesca/65.webp", 1920, 1080)
image e2s10_fr-66 = im.Scale("season1/episode2/images/scene10/francesca/66.webp", 1920, 1080)
image e2s10_fr-67 = im.Scale("season1/episode2/images/scene10/francesca/67.webp", 1920, 1080)
image e2s10_fr-68 = im.Scale("season1/episode2/images/scene10/francesca/68.webp", 1920, 1080)
image e2s10_fr-69 = im.Scale("season1/episode2/images/scene10/francesca/69.webp", 1920, 1080)
image e2s10_fr-70 = im.Scale("season1/episode2/images/scene10/francesca/70.webp", 1920, 1080)
image e2s10_fr-71 = im.Scale("season1/episode2/images/scene10/francesca/71.webp", 1920, 1080)
image e2s10_fr-72 = im.Scale("season1/episode2/images/scene10/francesca/72.webp", 1920, 1080)
image e2s10_fr-73 = im.Scale("season1/episode2/images/scene10/francesca/73.webp", 1920, 1080)
image e2s10_fr-74 = im.Scale("season1/episode2/images/scene10/francesca/74.webp", 1920, 1080)
image e2s10_fr-75 = im.Scale("season1/episode2/images/scene10/francesca/75.webp", 1920, 1080)

# Animations ##

# Blink #
image e2s10_fr-francesca_blink1:
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_fr-francesca_blink2:
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_fr-francesca_blink3:
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_fr-francesca_blink4:
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/francesca/francesca_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Freeroam #######################
# Freeroam Images #

#Main
image e2s10_frfr-01 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/1.webp", 1920, 1080)

#Stairs
image e2s10_frfr-02 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/2.webp", 1920, 1080)

#Upstairs
image e2s10_frfr-03 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/3.webp", 1920, 1080)

#Hallway
image e2s10_frfr-04 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/4.webp", 1920, 1080)

#Bedroom
image e2s10_frfr-05 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/5.webp", 1920, 1080)

#Bathroom
image e2s10_frfr-06 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/6.webp", 1920, 1080)

#Dining_room
image e2s10_frfr-07 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/7.webp", 1920, 1080)

#Kitchen
image e2s10_frfr-08 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/8.webp", 1920, 1080)

image e2s10_frfrimg-01 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/images/1.webp", 1920, 1080)
image e2s10_frfrimg-02 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/images/2.webp", 1920, 1080)
image e2s10_frfrimg-03 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/images/3.webp", 1920, 1080)
image e2s10_frfrimg-04 = im.Scale("season1/episode2/images/scene10/francesca/freeroam/images/4.webp", 1920, 1080)

# Freeroam Screens #
screen e2s10_fr_main():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-01"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/dining_room_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/dining_room_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_dining_room")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_dining_room")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_hallway")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/stairs_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/stairs_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_stairs")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_stairs")

    # Clickables ###############################################################
    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/francesca_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/francesca_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_francesca")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_francesca")

    if persistent.cl_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/main/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_8_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo8", True), Function(update_cleo_list)]

screen e2s10_fr_dining_room():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-07"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/kitchen_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/kitchen_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_kitchen")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_kitchen")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_main")

    if persistent.sd_gallery_9_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/dining_room/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_9_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_9_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie9", True), Function(update_sadie_list)]

screen e2s10_fr_hallway():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-04"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/bathroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/bathroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_bathroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_bathroom")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/bedroom_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/bedroom_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_bedroom")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_bedroom")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_main")

    if persistent.fr_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/hallway/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_7_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca7", True), Function(update_francesca_list)]

screen e2s10_fr_stairs():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-02"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_main")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/upstairs_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/upstairs_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_upstairs")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_upstairs")

    if persistent.tr_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/stairs/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_8_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy8", True), Function(update_tracy_list)]

screen e2s10_fr_upstairs():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-03"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/main_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/main_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_main")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_main")

    # Clickables ###############################################################
    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/left_door_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/left_door_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_left_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_left_door")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/middle_door_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/middle_door_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_middle_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_middle_door")

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/right_door_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/upstairs/right_door_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_right_door")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_right_door")

screen e2s10_fr_kitchen():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-08"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/dining_room_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/dining_room_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_dining_room")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_dining_room")

    # Clickables ###############################################################
    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/cabinet_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/cabinet_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_cabinet")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_cabinet")

    if persistent.sc_gallery_8_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/kitchen/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_8_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_8_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett8", True), Function(update_scarlett_list)]

screen e2s10_fr_bathroom():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-06"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/bathroom/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/bathroom/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_hallway")

    if persistent.sc_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/bathroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/bathroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_7_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett7", True), Function(update_scarlett_list)]

screen e2s10_fr_bedroom():

    $ renpy.random.shuffle(e2s10_fr_frtracks)
    modal True

    add "e2s10_frfr-05"

    imagebutton:
        idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/bedroom/hallway_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/bedroom/hallway_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e2s10_fr_hallway")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e2s10_fr_hallway")

    if persistent.sd_gallery_7_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode2/images/scene10/francesca/freeroam/bedroom/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode2/images/scene10/francesca/freeroam/bedroom/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sd_gallery_7_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sd_gallery_7_unlocked", True), SetVariable("persistent.e2s10_collected_p", persistent.e2s10_collected_p+1), Show("render_notify"), SetVariable("persistent.sadie7", True), Function(update_sadie_list)]

################################################################################

### Sadie ###
# Images ##
# Uncensored
image e2s10_sd-01 = im.Scale("season1/episode2/images/scene10/sadie/1.webp", 1920, 1080)
image e2s10_sd-02 = im.Scale("season1/episode2/images/scene10/sadie/2.webp", 1920, 1080)
image e2s10_sd-03 = im.Scale("season1/episode2/images/scene10/sadie/3.webp", 1920, 1080)
image e2s10_sd-04 = im.Scale("season1/episode2/images/scene10/sadie/4.webp", 1920, 1080)
image e2s10_sd-05 = im.Scale("season1/episode2/images/scene10/sadie/5.webp", 1920, 1080)
image e2s10_sd-06 = im.Scale("season1/episode2/images/scene10/sadie/6.webp", 1920, 1080)
image e2s10_sd-07 = im.Scale("season1/episode2/images/scene10/sadie/7.webp", 1920, 1080)
image e2s10_sd-08 = im.Scale("season1/episode2/images/scene10/sadie/8.webp", 1920, 1080)
image e2s10_sd-09 = im.Scale("season1/episode2/images/scene10/sadie/9.webp", 1920, 1080)
image e2s10_sd-10 = im.Scale("season1/episode2/images/scene10/sadie/10.webp", 1920, 1080)
image e2s10_sd-11 = im.Scale("season1/episode2/images/scene10/sadie/11.webp", 1920, 1080)
image e2s10_sd-12 = im.Scale("season1/episode2/images/scene10/sadie/12.webp", 1920, 1080)
image e2s10_sd-13 = im.Scale("season1/episode2/images/scene10/sadie/13.webp", 1920, 1080)
image e2s10_sd-14 = im.Scale("season1/episode2/images/scene10/sadie/14.webp", 1920, 1080)
image e2s10_sd-15 = im.Scale("season1/episode2/images/scene10/sadie/15.webp", 1920, 1080)
image e2s10_sd-16 = im.Scale("season1/episode2/images/scene10/sadie/16.webp", 1920, 1080)
image e2s10_sd-17 = im.Scale("season1/episode2/images/scene10/sadie/17.webp", 1920, 1080)
image e2s10_sd-18 = im.Scale("season1/episode2/images/scene10/sadie/18.webp", 1920, 1080)
image e2s10_sd-19 = im.Scale("season1/episode2/images/scene10/sadie/19.webp", 1920, 1080)
image e2s10_sd-20 = im.Scale("season1/episode2/images/scene10/sadie/20.webp", 1920, 1080)
image e2s10_sd-21 = im.Scale("season1/episode2/images/scene10/sadie/21.webp", 1920, 1080)
image e2s10_sd-22 = im.Scale("season1/episode2/images/scene10/sadie/22.webp", 1920, 1080)
image e2s10_sd-23 = im.Scale("season1/episode2/images/scene10/sadie/23.webp", 1920, 1080)
image e2s10_sd-24 = im.Scale("season1/episode2/images/scene10/sadie/24.webp", 1920, 1080)
image e2s10_sd-25 = im.Scale("season1/episode2/images/scene10/sadie/25.webp", 1920, 1080)
image e2s10_sd-26 = im.Scale("season1/episode2/images/scene10/sadie/26.webp", 1920, 1080)
image e2s10_sd-27 = im.Scale("season1/episode2/images/scene10/sadie/27.webp", 1920, 1080)
image e2s10_sd-28 = im.Scale("season1/episode2/images/scene10/sadie/28.webp", 1920, 1080)
image e2s10_sd-29 = im.Scale("season1/episode2/images/scene10/sadie/29.webp", 1920, 1080)
image e2s10_sd-30 = im.Scale("season1/episode2/images/scene10/sadie/30.webp", 1920, 1080)
image e2s10_sd-31 = im.Scale("season1/episode2/images/scene10/sadie/31.webp", 1920, 1080)
image e2s10_sd-32 = im.Scale("season1/episode2/images/scene10/sadie/32.webp", 1920, 1080)
image e2s10_sd-33 = im.Scale("season1/episode2/images/scene10/sadie/33.webp", 1920, 1080)
image e2s10_sd-34 = im.Scale("season1/episode2/images/scene10/sadie/34.webp", 1920, 1080)
image e2s10_sd-35 = im.Scale("season1/episode2/images/scene10/sadie/35.webp", 1920, 1080)
image e2s10_sd-36 = im.Scale("season1/episode2/images/scene10/sadie/36.webp", 1920, 1080)
image e2s10_sd-37 = im.Scale("season1/episode2/images/scene10/sadie/37.webp", 1920, 1080)
image e2s10_sd-38 = im.Scale("season1/episode2/images/scene10/sadie/38.webp", 1920, 1080)
image e2s10_sd-39 = im.Scale("season1/episode2/images/scene10/sadie/39.webp", 1920, 1080)
image e2s10_sd-40 = im.Scale("season1/episode2/images/scene10/sadie/40.webp", 1920, 1080)
image e2s10_sd-41 = im.Scale("season1/episode2/images/scene10/sadie/41.webp", 1920, 1080)
image e2s10_sd-42 = im.Scale("season1/episode2/images/scene10/sadie/42.webp", 1920, 1080)
image e2s10_sd-43 = im.Scale("season1/episode2/images/scene10/sadie/43.webp", 1920, 1080)
image e2s10_sd-44 = im.Scale("season1/episode2/images/scene10/sadie/44.webp", 1920, 1080)
image e2s10_sd-45 = im.Scale("season1/episode2/images/scene10/sadie/45.webp", 1920, 1080)
image e2s10_sd-46 = im.Scale("season1/episode2/images/scene10/sadie/46.webp", 1920, 1080)
image e2s10_sd-47 = im.Scale("season1/episode2/images/scene10/sadie/47.webp", 1920, 1080)
image e2s10_sd-48 = im.Scale("season1/episode2/images/scene10/sadie/48.webp", 1920, 1080)
image e2s10_sd-49 = im.Scale("season1/episode2/images/scene10/sadie/49.webp", 1920, 1080)
image e2s10_sd-50 = im.Scale("season1/episode2/images/scene10/sadie/50.webp", 1920, 1080)
image e2s10_sd-51 = im.Scale("season1/episode2/images/scene10/sadie/51.webp", 1920, 1080)
image e2s10_sd-52 = im.Scale("season1/episode2/images/scene10/sadie/52.webp", 1920, 1080)
image e2s10_sd-53 = im.Scale("season1/episode2/images/scene10/sadie/53.webp", 1920, 1080)
image e2s10_sd-54 = im.Scale("season1/episode2/images/scene10/sadie/54.webp", 1920, 1080)
image e2s10_sd-55 = im.Scale("season1/episode2/images/scene10/sadie/55.webp", 1920, 1080)
image e2s10_sd-56 = im.Scale("season1/episode2/images/scene10/sadie/56.webp", 1920, 1080)
image e2s10_sd-57 = im.Scale("season1/episode2/images/scene10/sadie/57.webp", 1920, 1080)
image e2s10_sd-58 = im.Scale("season1/episode2/images/scene10/sadie/58.webp", 1920, 1080)
image e2s10_sd-59 = im.Scale("season1/episode2/images/scene10/sadie/59.webp", 1920, 1080)
image e2s10_sd-60 = im.Scale("season1/episode2/images/scene10/sadie/60.webp", 1920, 1080)
image e2s10_sd-61 = im.Scale("season1/episode2/images/scene10/sadie/61.webp", 1920, 1080)
image e2s10_sd-62 = im.Scale("season1/episode2/images/scene10/sadie/62.webp", 1920, 1080)
image e2s10_sd-63 = im.Scale("season1/episode2/images/scene10/sadie/63.webp", 1920, 1080)
image e2s10_sd-64 = im.Scale("season1/episode2/images/scene10/sadie/64.webp", 1920, 1080)
image e2s10_sd-65 = im.Scale("season1/episode2/images/scene10/sadie/65.webp", 1920, 1080)
image e2s10_sd-66 = im.Scale("season1/episode2/images/scene10/sadie/66.webp", 1920, 1080)
image e2s10_sd-67 = im.Scale("season1/episode2/images/scene10/sadie/67.webp", 1920, 1080)
image e2s10_sd-68 = im.Scale("season1/episode2/images/scene10/sadie/68.webp", 1920, 1080)
image e2s10_sd-69 = im.Scale("season1/episode2/images/scene10/sadie/69.webp", 1920, 1080)
image e2s10_sd-70 = im.Scale("season1/episode2/images/scene10/sadie/70.webp", 1920, 1080)
image e2s10_sd-71 = im.Scale("season1/episode2/images/scene10/sadie/71.webp", 1920, 1080)
image e2s10_sd-72 = im.Scale("season1/episode2/images/scene10/sadie/72.webp", 1920, 1080)
image e2s10_sd-73 = im.Scale("season1/episode2/images/scene10/sadie/73.webp", 1920, 1080)
image e2s10_sd-74 = im.Scale("season1/episode2/images/scene10/sadie/74.webp", 1920, 1080)
image e2s10_sd-75 = im.Scale("season1/episode2/images/scene10/sadie/75.webp", 1920, 1080)
image e2s10_sd-76 = im.Scale("season1/episode2/images/scene10/sadie/76.webp", 1920, 1080)
image e2s10_sd-77 = im.Scale("season1/episode2/images/scene10/sadie/77.webp", 1920, 1080)
image e2s10_sd-78 = im.Scale("season1/episode2/images/scene10/sadie/78.webp", 1920, 1080)
image e2s10_sd-79 = im.Scale("season1/episode2/images/scene10/sadie/79.webp", 1920, 1080)
image e2s10_sd-80 = im.Scale("season1/episode2/images/scene10/sadie/80.webp", 1920, 1080)
image e2s10_sd-81 = im.Scale("season1/episode2/images/scene10/sadie/81.webp", 1920, 1080)
image e2s10_sd-82 = im.Scale("season1/episode2/images/scene10/sadie/82.webp", 1920, 1080)
image e2s10_sd-83 = im.Scale("season1/episode2/images/scene10/sadie/83.webp", 1920, 1080)
image e2s10_sd-84 = im.Scale("season1/episode2/images/scene10/sadie/84.webp", 1920, 1080)
image e2s10_sd-85 = im.Scale("season1/episode2/images/scene10/sadie/85.webp", 1920, 1080)
image e2s10_sd-86 = im.Scale("season1/episode2/images/scene10/sadie/86.webp", 1920, 1080)
image e2s10_sd-87 = im.Scale("season1/episode2/images/scene10/sadie/87.webp", 1920, 1080)
image e2s10_sd-88 = im.Scale("season1/episode2/images/scene10/sadie/88.webp", 1920, 1080)
image e2s10_sd-89 = im.Scale("season1/episode2/images/scene10/sadie/89.webp", 1920, 1080)
image e2s10_sd-90 = im.Scale("season1/episode2/images/scene10/sadie/90.webp", 1920, 1080)
image e2s10_sd-91 = im.Scale("season1/episode2/images/scene10/sadie/91.webp", 1920, 1080)
image e2s10_sd-92 = im.Scale("season1/episode2/images/scene10/sadie/92.webp", 1920, 1080)
image e2s10_sd-93 = im.Scale("season1/episode2/images/scene10/sadie/93.webp", 1920, 1080)
image e2s10_sd-94 = im.Scale("season1/episode2/images/scene10/sadie/94.webp", 1920, 1080)
image e2s10_sd-95 = im.Scale("season1/episode2/images/scene10/sadie/95.webp", 1920, 1080)
image e2s10_sd-96 = im.Scale("season1/episode2/images/scene10/sadie/96.webp", 1920, 1080)
image e2s10_sd-97 = im.Scale("season1/episode2/images/scene10/sadie/97.webp", 1920, 1080)
image e2s10_sd-98 = im.Scale("season1/episode2/images/scene10/sadie/98.webp", 1920, 1080)
image e2s10_sd-99 = im.Scale("season1/episode2/images/scene10/sadie/99.webp", 1920, 1080)
image e2s10_sd-100 = im.Scale("season1/episode2/images/scene10/sadie/100.webp", 1920, 1080)
image e2s10_sd-101 = im.Scale("season1/episode2/images/scene10/sadie/101.webp", 1920, 1080)
image e2s10_sd-102 = im.Scale("season1/episode2/images/scene10/sadie/102.webp", 1920, 1080)
image e2s10_sd-103 = im.Scale("season1/episode2/images/scene10/sadie/103.webp", 1920, 1080)
image e2s10_sd-104 = im.Scale("season1/episode2/images/scene10/sadie/104.webp", 1920, 1080)
image e2s10_sd-105 = im.Scale("season1/episode2/images/scene10/sadie/105.webp", 1920, 1080)
image e2s10_sd-106 = im.Scale("season1/episode2/images/scene10/sadie/106.webp", 1920, 1080)
image e2s10_sd-107 = im.Scale("season1/episode2/images/scene10/sadie/107.webp", 1920, 1080)
image e2s10_sd-108 = im.Scale("season1/episode2/images/scene10/sadie/108.webp", 1920, 1080)
image e2s10_sd-109 = im.Scale("season1/episode2/images/scene10/sadie/109.webp", 1920, 1080)
image e2s10_sd-110 = im.Scale("season1/episode2/images/scene10/sadie/110.webp", 1920, 1080)
image e2s10_sd-111 = im.Scale("season1/episode2/images/scene10/sadie/111.webp", 1920, 1080)
image e2s10_sd-112 = im.Scale("season1/episode2/images/scene10/sadie/112.webp", 1920, 1080)
image e2s10_sd-113 = im.Scale("season1/episode2/images/scene10/sadie/113.webp", 1920, 1080)
image e2s10_sd-114 = im.Scale("season1/episode2/images/scene10/sadie/114.webp", 1920, 1080)
image e2s10_sd-115 = im.Scale("season1/episode2/images/scene10/sadie/115.webp", 1920, 1080)
image e2s10_sd-116 = im.Scale("season1/episode2/images/scene10/sadie/116.webp", 1920, 1080)
image e2s10_sd-117 = im.Scale("season1/episode2/images/scene10/sadie/117.webp", 1920, 1080)
image e2s10_sd-118 = im.Scale("season1/episode2/images/scene10/sadie/118.webp", 1920, 1080)
image e2s10_sd-119 = im.Scale("season1/episode2/images/scene10/sadie/119.webp", 1920, 1080)
image e2s10_sd-120 = im.Scale("season1/episode2/images/scene10/sadie/120.webp", 1920, 1080)
image e2s10_sd-121 = im.Scale("season1/episode2/images/scene10/sadie/121.webp", 1920, 1080)
image e2s10_sd-122 = im.Scale("season1/episode2/images/scene10/sadie/122.webp", 1920, 1080)
image e2s10_sd-123 = im.Scale("season1/episode2/images/scene10/sadie/123.webp", 1920, 1080)
image e2s10_sd-124 = im.Scale("season1/episode2/images/scene10/sadie/124.webp", 1920, 1080)
image e2s10_sd-125 = im.Scale("season1/episode2/images/scene10/sadie/125.webp", 1920, 1080)
image e2s10_sd-126 = im.Scale("season1/episode2/images/scene10/sadie/126.webp", 1920, 1080)
image e2s10_sd-127 = im.Scale("season1/episode2/images/scene10/sadie/127.webp", 1920, 1080)
image e2s10_sd-128 = im.Scale("season1/episode2/images/scene10/sadie/128.webp", 1920, 1080)
image e2s10_sd-129 = im.Scale("season1/episode2/images/scene10/sadie/129.webp", 1920, 1080)
image e2s10_sd-130 = im.Scale("season1/episode2/images/scene10/sadie/130.webp", 1920, 1080)
image e2s10_sd-131 = im.Scale("season1/episode2/images/scene10/sadie/131.webp", 1920, 1080)
image e2s10_sd-132 = im.Scale("season1/episode2/images/scene10/sadie/132.webp", 1920, 1080)
image e2s10_sd-133 = im.Scale("season1/episode2/images/scene10/sadie/133.webp", 1920, 1080)
image e2s10_sd-134 = im.Scale("season1/episode2/images/scene10/sadie/134.webp", 1920, 1080)
image e2s10_sd-135 = im.Scale("season1/episode2/images/scene10/sadie/135.webp", 1920, 1080)
image e2s10_sd-136 = im.Scale("season1/episode2/images/scene10/sadie/136.webp", 1920, 1080)
image e2s10_sd-137 = im.Scale("season1/episode2/images/scene10/sadie/137.webp", 1920, 1080)
image e2s10_sd-138 = im.Scale("season1/episode2/images/scene10/sadie/138.webp", 1920, 1080)
image e2s10_sd-139 = im.Scale("season1/episode2/images/scene10/sadie/139.webp", 1920, 1080)
image e2s10_sd-140 = im.Scale("season1/episode2/images/scene10/sadie/140.webp", 1920, 1080)
image e2s10_sd-141 = im.Scale("season1/episode2/images/scene10/sadie/141.webp", 1920, 1080)
image e2s10_sd-142 = im.Scale("season1/episode2/images/scene10/sadie/142.webp", 1920, 1080)
image e2s10_sd-143 = im.Scale("season1/episode2/images/scene10/sadie/143.webp", 1920, 1080)
image e2s10_sd-144 = im.Scale("season1/episode2/images/scene10/sadie/144.webp", 1920, 1080)
image e2s10_sd-145 = im.Scale("season1/episode2/images/scene10/sadie/145.webp", 1920, 1080)
image e2s10_sd-146 = im.Scale("season1/episode2/images/scene10/sadie/146.webp", 1920, 1080)
image e2s10_sd-147 = im.Scale("season1/episode2/images/scene10/sadie/147.webp", 1920, 1080)
image e2s10_sd-148 = im.Scale("season1/episode2/images/scene10/sadie/148.webp", 1920, 1080)
image e2s10_sd-149 = im.Scale("season1/episode2/images/scene10/sadie/149.webp", 1920, 1080)

# Censored
image e2s10_sd-66_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/66.webp", 1920, 1080)
image e2s10_sd-67_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/67.webp", 1920, 1080)
image e2s10_sd-68_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/68.webp", 1920, 1080)
image e2s10_sd-69_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/69.webp", 1920, 1080)
image e2s10_sd-70_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/70.webp", 1920, 1080)
image e2s10_sd-71_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/71.webp", 1920, 1080)
image e2s10_sd-72_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/72.webp", 1920, 1080)
image e2s10_sd-73_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/73.webp", 1920, 1080)
image e2s10_sd-74_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/74.webp", 1920, 1080)
image e2s10_sd-75_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/75.webp", 1920, 1080)
image e2s10_sd-76_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/76.webp", 1920, 1080)
image e2s10_sd-77_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/77.webp", 1920, 1080)
image e2s10_sd-78_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/78.webp", 1920, 1080)
image e2s10_sd-79_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/79.webp", 1920, 1080)
image e2s10_sd-83_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/83.webp", 1920, 1080)
image e2s10_sd-84_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/84.webp", 1920, 1080)
image e2s10_sd-85_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/85.webp", 1920, 1080)
image e2s10_sd-86_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/86.webp", 1920, 1080)
image e2s10_sd-87_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/87.webp", 1920, 1080)
image e2s10_sd-88_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/88.webp", 1920, 1080)
image e2s10_sd-89_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/89.webp", 1920, 1080)
image e2s10_sd-90_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/90.webp", 1920, 1080)
image e2s10_sd-91_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/91.webp", 1920, 1080)
image e2s10_sd-92_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/92.webp", 1920, 1080)
image e2s10_sd-93_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/93.webp", 1920, 1080)
image e2s10_sd-96_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/96.webp", 1920, 1080)
image e2s10_sd-106_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/106.webp", 1920, 1080)
image e2s10_sd-109_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/109.webp", 1920, 1080)
image e2s10_sd-114_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/114.webp", 1920, 1080)
image e2s10_sd-121_cen = im.Scale("season1/episode2/images/scene10/sadie/censored/121.webp", 1920, 1080)

# Animations ##

# Blink #
image e2s10_sd-sadie_blink1:
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_sd-sadie_blink2:
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_sd-sadie_blink3:
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_sd-sadie_blink4:
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_sd-sadie_blink5:
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/sadie_blink5/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_sd-jon_blink1:
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/sadie/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Lewd #

# Uncensored
image e2s10_sd-blowjob1 = Movie(play="season1/episode2/images/scene10/sadie/blowjob1.webm")
image e2s10_sd-blowjob2 = Movie(play="season1/episode2/images/scene10/sadie/blowjob2.webm")
image e2s10_sd-cowgirl1 = Movie(play="season1/episode2/images/scene10/sadie/cowgirl1.webm")
image e2s10_sd-cowgirl2 = Movie(play="season1/episode2/images/scene10/sadie/cowgirl2.webm")
image e2s10_sd-doggy1 = Movie(play="season1/episode2/images/scene10/sadie/doggy1.webm")
image e2s10_sd-doggy2 = Movie(play="season1/episode2/images/scene10/sadie/doggy2.webm")
image e2s10_sd-handjob1 = Movie(play="season1/episode2/images/scene10/sadie/handjob1.webm")
image e2s10_sd-handjob2 = Movie(play="season1/episode2/images/scene10/sadie/handjob2.webm")
image e2s10_sd-missionary1 = Movie(play="season1/episode2/images/scene10/sadie/missionary1.webm")
image e2s10_sd-missionary2 = Movie(play="season1/episode2/images/scene10/sadie/missionary2.webm")
image e2s10_sd-reverse_cowgirl1 = Movie(play="season1/episode2/images/scene10/sadie/reverse_cowgirl1.webm")
image e2s10_sd-reverse_cowgirl2 = Movie(play="season1/episode2/images/scene10/sadie/reverse_cowgirl2.webm")
image e2s10_sd-reverse_cowgirl3 = Movie(play="season1/episode2/images/scene10/sadie/reverse_cowgirl3.webm")
image e2s10_sd-pussy_eating1 = Movie(play="season1/episode2/images/scene10/sadie/pussy_eating1.webm")
image e2s10_sd-pussy_eating2 = Movie(play="season1/episode2/images/scene10/sadie/pussy_eating2.webm")
image e2s10_sd-sixty_nine1 = Movie(play="season1/episode2/images/scene10/sadie/sixty_nine1.webm")
image e2s10_sd-sixty_nine2 = Movie(play="season1/episode2/images/scene10/sadie/sixty_nine2.webm")
image e2s10_sd-sixty_nine3 = Movie(play="season1/episode2/images/scene10/sadie/sixty_nine3.webm")
image e2s10_sd-dick_licking1 = Movie(play="season1/episode2/images/scene10/sadie/dick_licking1.webm")
image e2s10_sd-cum1 = Movie(play="season1/episode2/images/scene10/sadie/cum1.webm")
image e2s10_sd-kiss1 = Movie(play="season1/episode2/images/scene10/sadie/kiss1.webm")
image e2s10_sd-kiss2 = Movie(play="season1/episode2/images/scene10/sadie/kiss2.webm")

# Censored
image e2s10_sd-blowjob1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/blowjob1.webm")
image e2s10_sd-blowjob2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/blowjob2.webm")
image e2s10_sd-cowgirl1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/cowgirl1.webm")
image e2s10_sd-cowgirl2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/cowgirl2.webm")
image e2s10_sd-doggy1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/doggy1.webm")
image e2s10_sd-doggy2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/doggy2.webm")
image e2s10_sd-handjob1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/handjob1.webm")
image e2s10_sd-handjob2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/handjob2.webm")
image e2s10_sd-missionary1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/missionary1.webm")
image e2s10_sd-missionary2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/missionary2.webm")
image e2s10_sd-reverse_cowgirl1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/reverse_cowgirl1.webm")
image e2s10_sd-reverse_cowgirl2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/reverse_cowgirl2.webm")
image e2s10_sd-reverse_cowgirl3_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/reverse_cowgirl3.webm")
image e2s10_sd-pussy_eating1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/pussy_eating1.webm")
image e2s10_sd-pussy_eating2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/pussy_eating2.webm")
image e2s10_sd-sixty_nine1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/sixty_nine1.webm")
image e2s10_sd-sixty_nine2_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/sixty_nine2.webm")
image e2s10_sd-sixty_nine3_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/sixty_nine3.webm")
image e2s10_sd-dick_licking1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/dick_licking1.webm")
image e2s10_sd-cum1_cen = Movie(play="season1/episode2/images/scene10/sadie/censored/cum1.webm")

################################################################################

### Jon ###
# Images ##
image e2s10_jon-01 = im.Scale("season1/episode2/images/scene10/jon/1.webp", 1920, 1080)
image e2s10_jon-02 = im.Scale("season1/episode2/images/scene10/jon/2.webp", 1920, 1080)
image e2s10_jon-03 = im.Scale("season1/episode2/images/scene10/jon/3.webp", 1920, 1080)
image e2s10_jon-04 = im.Scale("season1/episode2/images/scene10/jon/4.webp", 1920, 1080)
image e2s10_jon-05 = im.Scale("season1/episode2/images/scene10/jon/5.webp", 1920, 1080)
image e2s10_jon-06 = im.Scale("season1/episode2/images/scene10/jon/6.webp", 1920, 1080)
image e2s10_jon-07 = im.Scale("season1/episode2/images/scene10/jon/7.webp", 1920, 1080)
image e2s10_jon-08 = im.Scale("season1/episode2/images/scene10/jon/8.webp", 1920, 1080)
image e2s10_jon-09 = im.Scale("season1/episode2/images/scene10/jon/9.webp", 1920, 1080)
image e2s10_jon-10 = im.Scale("season1/episode2/images/scene10/jon/10.webp", 1920, 1080)
image e2s10_jon-11 = im.Scale("season1/episode2/images/scene10/jon/11.webp", 1920, 1080)
image e2s10_jon-12 = im.Scale("season1/episode2/images/scene10/jon/12.webp", 1920, 1080)
image e2s10_jon-13 = im.Scale("season1/episode2/images/scene10/jon/13.webp", 1920, 1080)
image e2s10_jon-14 = im.Scale("season1/episode2/images/scene10/jon/14.webp", 1920, 1080)
image e2s10_jon-15 = im.Scale("season1/episode2/images/scene10/jon/15.webp", 1920, 1080)
image e2s10_jon-16 = im.Scale("season1/episode2/images/scene10/jon/16.webp", 1920, 1080)
image e2s10_jon-17 = im.Scale("season1/episode2/images/scene10/jon/17.webp", 1920, 1080)
image e2s10_jon-18 = im.Scale("season1/episode2/images/scene10/jon/18.webp", 1920, 1080)
image e2s10_jon-19 = im.Scale("season1/episode2/images/scene10/jon/19.webp", 1920, 1080)
image e2s10_jon-20 = im.Scale("season1/episode2/images/scene10/jon/20.webp", 1920, 1080)
image e2s10_jon-21 = im.Scale("season1/episode2/images/scene10/jon/21.webp", 1920, 1080)
image e2s10_jon-22 = im.Scale("season1/episode2/images/scene10/jon/22.webp", 1920, 1080)
image e2s10_jon-23 = im.Scale("season1/episode2/images/scene10/jon/23.webp", 1920, 1080)
image e2s10_jon-24 = im.Scale("season1/episode2/images/scene10/jon/24.webp", 1920, 1080)
image e2s10_jon-25 = im.Scale("season1/episode2/images/scene10/jon/25.webp", 1920, 1080)
image e2s10_jon-26 = im.Scale("season1/episode2/images/scene10/jon/26.webp", 1920, 1080)
image e2s10_jon-27 = im.Scale("season1/episode2/images/scene10/jon/27.webp", 1920, 1080)
image e2s10_jon-28 = im.Scale("season1/episode2/images/scene10/jon/28.webp", 1920, 1080)
image e2s10_jon-29 = im.Scale("season1/episode2/images/scene10/jon/29.webp", 1920, 1080)
image e2s10_jon-30 = im.Scale("season1/episode2/images/scene10/jon/30.webp", 1920, 1080)
image e2s10_jon-31 = im.Scale("season1/episode2/images/scene10/jon/31.webp", 1920, 1080)
image e2s10_jon-32 = im.Scale("season1/episode2/images/scene10/jon/32.webp", 1920, 1080)
image e2s10_jon-33 = im.Scale("season1/episode2/images/scene10/jon/33.webp", 1920, 1080)
image e2s10_jon-34 = im.Scale("season1/episode2/images/scene10/jon/34.webp", 1920, 1080)
image e2s10_jon-35 = im.Scale("season1/episode2/images/scene10/jon/35.webp", 1920, 1080)
image e2s10_jon-36 = im.Scale("season1/episode2/images/scene10/jon/36.webp", 1920, 1080)
image e2s10_jon-37 = im.Scale("season1/episode2/images/scene10/jon/37.webp", 1920, 1080)
image e2s10_jon-38 = im.Scale("season1/episode2/images/scene10/jon/38.webp", 1920, 1080)
image e2s10_jon-39 = im.Scale("season1/episode2/images/scene10/jon/39.webp", 1920, 1080)
image e2s10_jon-40 = im.Scale("season1/episode2/images/scene10/jon/40.webp", 1920, 1080)
image e2s10_jon-41 = im.Scale("season1/episode2/images/scene10/jon/41.webp", 1920, 1080)
image e2s10_jon-42 = im.Scale("season1/episode2/images/scene10/jon/42.webp", 1920, 1080)
image e2s10_jon-43 = im.Scale("season1/episode2/images/scene10/jon/43.webp", 1920, 1080)
image e2s10_jon-44 = im.Scale("season1/episode2/images/scene10/jon/44.webp", 1920, 1080)
image e2s10_jon-45 = im.Scale("season1/episode2/images/scene10/jon/45.webp", 1920, 1080)
image e2s10_jon-46 = im.Scale("season1/episode2/images/scene10/jon/46.webp", 1920, 1080)
image e2s10_jon-47 = im.Scale("season1/episode2/images/scene10/jon/47.webp", 1920, 1080)
image e2s10_jon-48 = im.Scale("season1/episode2/images/scene10/jon/48.webp", 1920, 1080)
image e2s10_jon-49 = im.Scale("season1/episode2/images/scene10/jon/49.webp", 1920, 1080)
image e2s10_jon-50 = im.Scale("season1/episode2/images/scene10/jon/50.webp", 1920, 1080)
image e2s10_jon-51 = im.Scale("season1/episode2/images/scene10/jon/51.webp", 1920, 1080)
image e2s10_jon-52 = im.Scale("season1/episode2/images/scene10/jon/52.webp", 1920, 1080)
image e2s10_jon-53 = im.Scale("season1/episode2/images/scene10/jon/53.webp", 1920, 1080)
image e2s10_jon-54 = im.Scale("season1/episode2/images/scene10/jon/54.webp", 1920, 1080)
image e2s10_jon-55 = im.Scale("season1/episode2/images/scene10/jon/55.webp", 1920, 1080)
image e2s10_jon-56 = im.Scale("season1/episode2/images/scene10/jon/56.webp", 1920, 1080)
image e2s10_jon-57 = im.Scale("season1/episode2/images/scene10/jon/57.webp", 1920, 1080)
image e2s10_jon-58 = im.Scale("season1/episode2/images/scene10/jon/58.webp", 1920, 1080)
image e2s10_jon-59 = im.Scale("season1/episode2/images/scene10/jon/59.webp", 1920, 1080)
image e2s10_jon-60 = im.Scale("season1/episode2/images/scene10/jon/60.webp", 1920, 1080)
image e2s10_jon-61 = im.Scale("season1/episode2/images/scene10/jon/61.webp", 1920, 1080)
image e2s10_jon-62 = im.Scale("season1/episode2/images/scene10/jon/62.webp", 1920, 1080)
image e2s10_jon-63 = im.Scale("season1/episode2/images/scene10/jon/63.webp", 1920, 1080)
image e2s10_jon-64 = im.Scale("season1/episode2/images/scene10/jon/64.webp", 1920, 1080)
image e2s10_jon-65 = im.Scale("season1/episode2/images/scene10/jon/65.webp", 1920, 1080)
image e2s10_jon-66 = im.Scale("season1/episode2/images/scene10/jon/66.webp", 1920, 1080)
image e2s10_jon-67 = im.Scale("season1/episode2/images/scene10/jon/67.webp", 1920, 1080)
image e2s10_jon-68 = im.Scale("season1/episode2/images/scene10/jon/68.webp", 1920, 1080)
image e2s10_jon-69 = im.Scale("season1/episode2/images/scene10/jon/69.webp", 1920, 1080)
image e2s10_jon-70 = im.Scale("season1/episode2/images/scene10/jon/70.webp", 1920, 1080)
image e2s10_jon-71 = im.Scale("season1/episode2/images/scene10/jon/71.webp", 1920, 1080)
image e2s10_jon-72 = im.Scale("season1/episode2/images/scene10/jon/72.webp", 1920, 1080)
image e2s10_jon-73 = im.Scale("season1/episode2/images/scene10/jon/73.webp", 1920, 1080)
image e2s10_jon-74 = im.Scale("season1/episode2/images/scene10/jon/74.webp", 1920, 1080)
image e2s10_jon-75 = im.Scale("season1/episode2/images/scene10/jon/75.webp", 1920, 1080)
image e2s10_jon-76 = im.Scale("season1/episode2/images/scene10/jon/76.webp", 1920, 1080)
image e2s10_jon-77 = im.Scale("season1/episode2/images/scene10/jon/77.webp", 1920, 1080)
image e2s10_jon-78 = im.Scale("season1/episode2/images/scene10/jon/78.webp", 1920, 1080)
image e2s10_jon-79 = im.Scale("season1/episode2/images/scene10/jon/79.webp", 1920, 1080)
image e2s10_jon-80 = im.Scale("season1/episode2/images/scene10/jon/80.webp", 1920, 1080)
image e2s10_jon-81 = im.Scale("season1/episode2/images/scene10/jon/81.webp", 1920, 1080)
image e2s10_jon-82 = im.Scale("season1/episode2/images/scene10/jon/82.webp", 1920, 1080)
image e2s10_jon-83 = im.Scale("season1/episode2/images/scene10/jon/83.webp", 1920, 1080)
image e2s10_jon-84 = im.Scale("season1/episode2/images/scene10/jon/84.webp", 1920, 1080)
image e2s10_jon-85 = im.Scale("season1/episode2/images/scene10/jon/85.webp", 1920, 1080)
image e2s10_jon-86 = im.Scale("season1/episode2/images/scene10/jon/86.webp", 1920, 1080)
image e2s10_jon-87 = im.Scale("season1/episode2/images/scene10/jon/87.webp", 1920, 1080)
image e2s10_jon-88 = im.Scale("season1/episode2/images/scene10/jon/88.webp", 1920, 1080)
image e2s10_jon-89 = im.Scale("season1/episode2/images/scene10/jon/89.webp", 1920, 1080)
image e2s10_jon-90 = im.Scale("season1/episode2/images/scene10/jon/90.webp", 1920, 1080)
image e2s10_jon-91 = im.Scale("season1/episode2/images/scene10/jon/91.webp", 1920, 1080)
image e2s10_jon-92 = im.Scale("season1/episode2/images/scene10/jon/92.webp", 1920, 1080)
image e2s10_jon-93 = im.Scale("season1/episode2/images/scene10/jon/93.webp", 1920, 1080)
image e2s10_jon-94 = im.Scale("season1/episode2/images/scene10/jon/94.webp", 1920, 1080)
image e2s10_jon-95 = im.Scale("season1/episode2/images/scene10/jon/95.webp", 1920, 1080)
image e2s10_jon-96 = im.Scale("season1/episode2/images/scene10/jon/96.webp", 1920, 1080)
image e2s10_jon-97 = im.Scale("season1/episode2/images/scene10/jon/97.webp", 1920, 1080)
image e2s10_jon-98 = im.Scale("season1/episode2/images/scene10/jon/98.webp", 1920, 1080)
image e2s10_jon-99 = im.Scale("season1/episode2/images/scene10/jon/99.webp", 1920, 1080)
image e2s10_jon-100 = im.Scale("season1/episode2/images/scene10/jon/100.webp", 1920, 1080)
image e2s10_jon-101 = im.Scale("season1/episode2/images/scene10/jon/101.webp", 1920, 1080)
image e2s10_jon-102 = im.Scale("season1/episode2/images/scene10/jon/102.webp", 1920, 1080)
image e2s10_jon-103 = im.Scale("season1/episode2/images/scene10/jon/103.webp", 1920, 1080)
image e2s10_jon-104 = im.Scale("season1/episode2/images/scene10/jon/104.webp", 1920, 1080)
image e2s10_jon-105 = im.Scale("season1/episode2/images/scene10/jon/105.webp", 1920, 1080)
image e2s10_jon-106 = im.Scale("season1/episode2/images/scene10/jon/106.webp", 1920, 1080)
image e2s10_jon-107 = im.Scale("season1/episode2/images/scene10/jon/107.webp", 1920, 1080)
image e2s10_jon-108 = im.Scale("season1/episode2/images/scene10/jon/108.webp", 1920, 1080)
image e2s10_jon-109 = im.Scale("season1/episode2/images/scene10/jon/109.webp", 1920, 1080)
image e2s10_jon-110 = im.Scale("season1/episode2/images/scene10/jon/110.webp", 1920, 1080)
image e2s10_jon-111 = im.Scale("season1/episode2/images/scene10/jon/111.webp", 1920, 1080)
image e2s10_jon-112 = im.Scale("season1/episode2/images/scene10/jon/112.webp", 1920, 1080)
image e2s10_jon-113 = im.Scale("season1/episode2/images/scene10/jon/113.webp", 1920, 1080)
image e2s10_jon-114 = im.Scale("season1/episode2/images/scene10/jon/114.webp", 1920, 1080)
image e2s10_jon-115 = im.Scale("season1/episode2/images/scene10/jon/115.webp", 1920, 1080)
image e2s10_jon-116 = im.Scale("season1/episode2/images/scene10/jon/116.webp", 1920, 1080)
image e2s10_jon-117 = im.Scale("season1/episode2/images/scene10/jon/117.webp", 1920, 1080)
image e2s10_jon-118 = im.Scale("season1/episode2/images/scene10/jon/118.webp", 1920, 1080)
image e2s10_jon-119 = im.Scale("season1/episode2/images/scene10/jon/119.webp", 1920, 1080)
image e2s10_jon-120 = im.Scale("season1/episode2/images/scene10/jon/120.webp", 1920, 1080)
image e2s10_jon-121 = im.Scale("season1/episode2/images/scene10/jon/121.webp", 1920, 1080)
image e2s10_jon-122 = im.Scale("season1/episode2/images/scene10/jon/122.webp", 1920, 1080)
image e2s10_jon-123 = im.Scale("season1/episode2/images/scene10/jon/123.webp", 1920, 1080)
image e2s10_jon-124 = im.Scale("season1/episode2/images/scene10/jon/124.webp", 1920, 1080)
image e2s10_jon-125 = im.Scale("season1/episode2/images/scene10/jon/125.webp", 1920, 1080)
image e2s10_jon-126 = im.Scale("season1/episode2/images/scene10/jon/126.webp", 1920, 1080)
image e2s10_jon-127 = im.Scale("season1/episode2/images/scene10/jon/127.webp", 1920, 1080)
image e2s10_jon-128 = im.Scale("season1/episode2/images/scene10/jon/128.webp", 1920, 1080)
image e2s10_jon-129 = im.Scale("season1/episode2/images/scene10/jon/129.webp", 1920, 1080)
image e2s10_jon-130 = im.Scale("season1/episode2/images/scene10/jon/130.webp", 1920, 1080)
image e2s10_jon-131 = im.Scale("season1/episode2/images/scene10/jon/131.webp", 1920, 1080)
image e2s10_jon-132 = im.Scale("season1/episode2/images/scene10/jon/132.webp", 1920, 1080)
image e2s10_jon-133 = im.Scale("season1/episode2/images/scene10/jon/133.webp", 1920, 1080)
image e2s10_jon-134 = im.Scale("season1/episode2/images/scene10/jon/134.webp", 1920, 1080)
image e2s10_jon-135 = im.Scale("season1/episode2/images/scene10/jon/135.webp", 1920, 1080)
image e2s10_jon-136 = im.Scale("season1/episode2/images/scene10/jon/136.webp", 1920, 1080)
image e2s10_jon-137 = im.Scale("season1/episode2/images/scene10/jon/137.webp", 1920, 1080)
image e2s10_jon-138 = im.Scale("season1/episode2/images/scene10/jon/138.webp", 1920, 1080)
image e2s10_jon-139 = im.Scale("season1/episode2/images/scene10/jon/139.webp", 1920, 1080)
image e2s10_jon-140 = im.Scale("season1/episode2/images/scene10/jon/140.webp", 1920, 1080)
image e2s10_jon-141 = im.Scale("season1/episode2/images/scene10/jon/141.webp", 1920, 1080)
image e2s10_jon-142 = im.Scale("season1/episode2/images/scene10/jon/142.webp", 1920, 1080)
image e2s10_jon-143 = im.Scale("season1/episode2/images/scene10/jon/143.webp", 1920, 1080)
image e2s10_jon-144 = im.Scale("season1/episode2/images/scene10/jon/144.webp", 1920, 1080)
image e2s10_jon-145 = im.Scale("season1/episode2/images/scene10/jon/145.webp", 1920, 1080)
image e2s10_jon-146 = im.Scale("season1/episode2/images/scene10/jon/146.webp", 1920, 1080)
image e2s10_jon-147 = im.Scale("season1/episode2/images/scene10/jon/147.webp", 1920, 1080)
image e2s10_jon-148 = im.Scale("season1/episode2/images/scene10/jon/148.webp", 1920, 1080)

image e2s10_jon_01drink = im.Scale("season1/episode2/images/scene10/jon/1_drink.webp", 1920, 1080)
image e2s10_jon_01drinks = im.Scale("season1/episode2/images/scene10/jon/1_drinks.webp", 1920, 1080)

image e2s10_jon_03drink = im.Scale("season1/episode2/images/scene10/jon/3_drink.webp", 1920, 1080)
image e2s10_jon_03drinks = im.Scale("season1/episode2/images/scene10/jon/3_drinks.webp", 1920, 1080)

image e2s10_jon_04drink = im.Scale("season1/episode2/images/scene10/jon/4_drink.webp", 1920, 1080)
image e2s10_jon_04drinks = im.Scale("season1/episode2/images/scene10/jon/4_drinks.webp", 1920, 1080)

image e2s10_jon_drink = im.Scale("season1/episode2/images/scene10/jon/drink.webp", 1920, 1080)
image e2s10_jon_drinks = im.Scale("season1/episode2/images/scene10/jon/drinks.webp", 1920, 1080)

# Animations ##

# Blink #
image e2s10_jon-bridget_blink1:
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_jon-bridget_blink2:
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/bridget_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2s10_jon-candance_blink1:
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene10/jon/candance_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Lewd #

# Uncensored
image e2s10_jon-blowjob1 = Movie(play="season1/episode2/images/scene10/jon/blowjob1.webm")
image e2s10_jon-blowjob2 = Movie(play="season1/episode2/images/scene10/jon/blowjob2.webm")
image e2s10_jon-handjob1 = Movie(play="season1/episode2/images/scene10/jon/handjob1.webm")
image e2s10_jon-handjob2 = Movie(play="season1/episode2/images/scene10/jon/handjob2.webm")
image e2s10_jon-handjob3 = Movie(play="season1/episode2/images/scene10/jon/handjob3.webm")

image e2s10_jon-slap = Movie(play="season1/episode2/images/scene10/jon/slap1.webm")
image e2s10_jon-twerk1 = Movie(play="season1/episode2/images/scene10/jon/twerk1.webm")
image e2s10_jon-twerk2 = Movie(play="season1/episode2/images/scene10/jon/twerk2.webm")

# Censored
image e2s10_jon-57_cen = im.Scale("season1/episode2/images/scene10/jon/censored/57.webp", 1920, 1080)
image e2s10_jon-59_cen = im.Scale("season1/episode2/images/scene10/jon/censored/59.webp", 1920, 1080)
image e2s10_jon-60_cen = im.Scale("season1/episode2/images/scene10/jon/censored/60.webp", 1920, 1080)
image e2s10_jon-61_cen = im.Scale("season1/episode2/images/scene10/jon/censored/61.webp", 1920, 1080)
image e2s10_jon-62_cen = im.Scale("season1/episode2/images/scene10/jon/censored/62.webp", 1920, 1080)
image e2s10_jon-63_cen = im.Scale("season1/episode2/images/scene10/jon/censored/63.webp", 1920, 1080)
image e2s10_jon-65_cen = im.Scale("season1/episode2/images/scene10/jon/censored/65.webp", 1920, 1080)
image e2s10_jon-66_cen = im.Scale("season1/episode2/images/scene10/jon/censored/66.webp", 1920, 1080)
image e2s10_jon-67_cen = im.Scale("season1/episode2/images/scene10/jon/censored/67.webp", 1920, 1080)
image e2s10_jon-68_cen = im.Scale("season1/episode2/images/scene10/jon/censored/68.webp", 1920, 1080)
image e2s10_jon-71_cen = im.Scale("season1/episode2/images/scene10/jon/censored/71.webp", 1920, 1080)
image e2s10_jon-73_cen = im.Scale("season1/episode2/images/scene10/jon/censored/73.webp", 1920, 1080)
image e2s10_jon-74_cen = im.Scale("season1/episode2/images/scene10/jon/censored/74.webp", 1920, 1080)
image e2s10_jon-77_cen = im.Scale("season1/episode2/images/scene10/jon/censored/77.webp", 1920, 1080)
image e2s10_jon-78_cen = im.Scale("season1/episode2/images/scene10/jon/censored/78.webp", 1920, 1080)
image e2s10_jon-79_cen = im.Scale("season1/episode2/images/scene10/jon/censored/79.webp", 1920, 1080)
image e2s10_jon-82_cen = im.Scale("season1/episode2/images/scene10/jon/censored/82.webp", 1920, 1080)
image e2s10_jon-85_cen = im.Scale("season1/episode2/images/scene10/jon/censored/85.webp", 1920, 1080)
image e2s10_jon-86_cen = im.Scale("season1/episode2/images/scene10/jon/censored/86.webp", 1920, 1080)
image e2s10_jon-87_cen = im.Scale("season1/episode2/images/scene10/jon/censored/87.webp", 1920, 1080)
image e2s10_jon-88_cen = im.Scale("season1/episode2/images/scene10/jon/censored/88.webp", 1920, 1080)
image e2s10_jon-89_cen = im.Scale("season1/episode2/images/scene10/jon/censored/89.webp", 1920, 1080)
image e2s10_jon-90_cen = im.Scale("season1/episode2/images/scene10/jon/censored/90.webp", 1920, 1080)
image e2s10_jon-97_cen = im.Scale("season1/episode2/images/scene10/jon/censored/97.webp", 1920, 1080)
image e2s10_jon-102_cen = im.Scale("season1/episode2/images/scene10/jon/censored/102.webp", 1920, 1080)
image e2s10_jon-111_cen = im.Scale("season1/episode2/images/scene10/jon/censored/111.webp", 1920, 1080)
image e2s10_jon-114_cen = im.Scale("season1/episode2/images/scene10/jon/censored/114.webp", 1920, 1080)

image e2s10_jon-blowjob1_cen = Movie(play="season1/episode2/images/scene10/jon/censored/blowjob1.webm")
image e2s10_jon-blowjob2_cen = Movie(play="season1/episode2/images/scene10/jon/censored/blowjob2.webm")
image e2s10_jon-handjob1_cen = Movie(play="season1/episode2/images/scene10/jon/censored/handjob1.webm")
image e2s10_jon-handjob2_cen = Movie(play="season1/episode2/images/scene10/jon/censored/handjob2.webm")
image e2s10_jon-handjob3_cen = Movie(play="season1/episode2/images/scene10/jon/censored/handjob3.webm")

image e2s10_jon-slap_cen = Movie(play="season1/episode2/images/scene10/jon/censored/slap1.webm")
image e2s10_jon-twerk1_cen = Movie(play="season1/episode2/images/scene10/jon/censored/twerk1.webm")
image e2s10_jon-twerk2_cen = Movie(play="season1/episode2/images/scene10/jon/censored/twerk2.webm")

################################################################################
