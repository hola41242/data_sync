
# Scene 2 images ###############################################################

image e2s2-01 = im.Scale("season1/episode2/images/scene2/1.webp", 1920, 1080)
image e2s2-02 = im.Scale("season1/episode2/images/scene2/2.webp", 1920, 1080)
image e2s2-03 = im.Scale("season1/episode2/images/scene2/3.webp", 1920, 1080)
image e2s2-04 = im.Scale("season1/episode2/images/scene2/4.webp", 1920, 1080)
image e2s2-05 = im.Scale("season1/episode2/images/scene2/5.webp", 1920, 1080)
image e2s2-06 = im.Scale("season1/episode2/images/scene2/6.webp", 1920, 1080)
image e2s2-07 = im.Scale("season1/episode2/images/scene2/7.webp", 1920, 1080)
image e2s2-08 = im.Scale("season1/episode2/images/scene2/8.webp", 1920, 1080)
image e2s2-09 = im.Scale("season1/episode2/images/scene2/9.webp", 1920, 1080)
image e2s2-10 = im.Scale("season1/episode2/images/scene2/10.webp", 1920, 1080)
image e2s2-11 = im.Scale("season1/episode2/images/scene2/11.webp", 1920, 1080)
image e2s2-12 = im.Scale("season1/episode2/images/scene2/12.webp", 1920, 1080)
image e2s2-13 = im.Scale("season1/episode2/images/scene2/13.webp", 1920, 1080)
image e2s2-14 = im.Scale("season1/episode2/images/scene2/14.webp", 1920, 1080)
image e2s2-15 = im.Scale("season1/episode2/images/scene2/15.webp", 1920, 1080)
image e2s2-16 = im.Scale("season1/episode2/images/scene2/16.webp", 1920, 1080)
image e2s2-17 = im.Scale("season1/episode2/images/scene2/17.webp", 1920, 1080)
image e2s2-18 = im.Scale("season1/episode2/images/scene2/18.webp", 1920, 1080)
image e2s2-19 = im.Scale("season1/episode2/images/scene2/19.webp", 1920, 1080)
image e2s2-20 = im.Scale("season1/episode2/images/scene2/20.webp", 1920, 1080)
image e2s2-21 = im.Scale("season1/episode2/images/scene2/21.webp", 1920, 1080)
image e2s2-22 = im.Scale("season1/episode2/images/scene2/22.webp", 1920, 1080)
image e2s2-23 = im.Scale("season1/episode2/images/scene2/23.webp", 1920, 1080)
image e2s2-24 = im.Scale("season1/episode2/images/scene2/24.webp", 1920, 1080)
image e2s2-25 = im.Scale("season1/episode2/images/scene2/25.webp", 1920, 1080)
image e2s2-26 = im.Scale("season1/episode2/images/scene2/26.webp", 1920, 1080)
image e2s2-27 = im.Scale("season1/episode2/images/scene2/27.webp", 1920, 1080)
image e2s2-28 = im.Scale("season1/episode2/images/scene2/28.webp", 1920, 1080)
image e2s2-29 = im.Scale("season1/episode2/images/scene2/29.webp", 1920, 1080)
image e2s2-30 = im.Scale("season1/episode2/images/scene2/30.webp", 1920, 1080)
image e2s2-31 = im.Scale("season1/episode2/images/scene2/31.webp", 1920, 1080)
image e2s2-32 = im.Scale("season1/episode2/images/scene2/32.webp", 1920, 1080)
image e2s2-33 = im.Scale("season1/episode2/images/scene2/33.webp", 1920, 1080)
image e2s2-34 = im.Scale("season1/episode2/images/scene2/34.webp", 1920, 1080)
image e2s2-35 = im.Scale("season1/episode2/images/scene2/35.webp", 1920, 1080)
image e2s2-36 = im.Scale("season1/episode2/images/scene2/36.webp", 1920, 1080)
image e2s2-37 = im.Scale("season1/episode2/images/scene2/37.webp", 1920, 1080)
image e2s2-38 = im.Scale("season1/episode2/images/scene2/38.webp", 1920, 1080)
image e2s2-39 = im.Scale("season1/episode2/images/scene2/39.webp", 1920, 1080)
image e2s2-40 = im.Scale("season1/episode2/images/scene2/40.webp", 1920, 1080)
image e2s2-41 = im.Scale("season1/episode2/images/scene2/41.webp", 1920, 1080)
image e2s2-42 = im.Scale("season1/episode2/images/scene2/42.webp", 1920, 1080)
image e2s2-43 = im.Scale("season1/episode2/images/scene2/43.webp", 1920, 1080)
image e2s2-44 = im.Scale("season1/episode2/images/scene2/44.webp", 1920, 1080)
image e2s2-45 = im.Scale("season1/episode2/images/scene2/45.webp", 1920, 1080)
image e2s2-46 = im.Scale("season1/episode2/images/scene2/46.webp", 1920, 1080)
image e2s2-47 = im.Scale("season1/episode2/images/scene2/47.webp", 1920, 1080)
image e2s2-48 = im.Scale("season1/episode2/images/scene2/48.webp", 1920, 1080)

# Roman Blink ###################################################################

image e2s2_roman_blink1:
    im.Scale("season1/episode2/images/scene2/roman_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene2/roman_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
