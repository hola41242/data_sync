
# Scene 6 images ###############################################################

image e2s6-01 = im.Scale("season1/episode2/images/scene6/1.webp", 1920, 1080)
image e2s6-02 = im.Scale("season1/episode2/images/scene6/2.webp", 1920, 1080)
image e2s6-03 = im.Scale("season1/episode2/images/scene6/3.webp", 1920, 1080)
image e2s6-04 = im.Scale("season1/episode2/images/scene6/4.webp", 1920, 1080)
image e2s6-05 = im.Scale("season1/episode2/images/scene6/5.webp", 1920, 1080)
image e2s6-06 = im.Scale("season1/episode2/images/scene6/6.webp", 1920, 1080)
image e2s6-07 = im.Scale("season1/episode2/images/scene6/7.webp", 1920, 1080)
image e2s6-08 = im.Scale("season1/episode2/images/scene6/8.webp", 1920, 1080)
image e2s6-09 = im.Scale("season1/episode2/images/scene6/9.webp", 1920, 1080)
image e2s6-10 = im.Scale("season1/episode2/images/scene6/10.webp", 1920, 1080)
image e2s6-11 = im.Scale("season1/episode2/images/scene6/11.webp", 1920, 1080)
image e2s6-12 = im.Scale("season1/episode2/images/scene6/12.webp", 1920, 1080)
image e2s6-13 = im.Scale("season1/episode2/images/scene6/13.webp", 1920, 1080)
image e2s6-14 = im.Scale("season1/episode2/images/scene6/14.webp", 1920, 1080)
image e2s6-15 = im.Scale("season1/episode2/images/scene6/15.webp", 1920, 1080)
image e2s6-16 = im.Scale("season1/episode2/images/scene6/16.webp", 1920, 1080)
image e2s6-17 = im.Scale("season1/episode2/images/scene6/17.webp", 1920, 1080)
image e2s6-18 = im.Scale("season1/episode2/images/scene6/18.webp", 1920, 1080)
image e2s6-19 = im.Scale("season1/episode2/images/scene6/19.webp", 1920, 1080)
image e2s6-20 = im.Scale("season1/episode2/images/scene6/20.webp", 1920, 1080)
image e2s6-21 = im.Scale("season1/episode2/images/scene6/21.webp", 1920, 1080)
image e2s6-22 = im.Scale("season1/episode2/images/scene6/22.webp", 1920, 1080)
image e2s6-23 = im.Scale("season1/episode2/images/scene6/23.webp", 1920, 1080)
image e2s6-24 = im.Scale("season1/episode2/images/scene6/24.webp", 1920, 1080)
image e2s6-25 = im.Scale("season1/episode2/images/scene6/25.webp", 1920, 1080)
image e2s6-26 = im.Scale("season1/episode2/images/scene6/26.webp", 1920, 1080)
image e2s6-27 = im.Scale("season1/episode2/images/scene6/27.webp", 1920, 1080)
image e2s6-28 = im.Scale("season1/episode2/images/scene6/28.webp", 1920, 1080)
image e2s6-29 = im.Scale("season1/episode2/images/scene6/29.webp", 1920, 1080)
image e2s6-30 = im.Scale("season1/episode2/images/scene6/30.webp", 1920, 1080)
image e2s6-31 = im.Scale("season1/episode2/images/scene6/31.webp", 1920, 1080)
image e2s6-32 = im.Scale("season1/episode2/images/scene6/32.webp", 1920, 1080)
image e2s6-33 = im.Scale("season1/episode2/images/scene6/33.webp", 1920, 1080)
image e2s6-34 = im.Scale("season1/episode2/images/scene6/34.webp", 1920, 1080)
image e2s6-35 = im.Scale("season1/episode2/images/scene6/35.webp", 1920, 1080)
image e2s6-36 = im.Scale("season1/episode2/images/scene6/36.webp", 1920, 1080)
image e2s6-37 = im.Scale("season1/episode2/images/scene6/37.webp", 1920, 1080)
image e2s6-38 = im.Scale("season1/episode2/images/scene6/38.webp", 1920, 1080)
image e2s6-39 = im.Scale("season1/episode2/images/scene6/39.webp", 1920, 1080)
image e2s6-40 = im.Scale("season1/episode2/images/scene6/40.webp", 1920, 1080)
image e2s6-41 = im.Scale("season1/episode2/images/scene6/41.webp", 1920, 1080)
image e2s6-42 = im.Scale("season1/episode2/images/scene6/42.webp", 1920, 1080)
image e2s6-43 = im.Scale("season1/episode2/images/scene6/43.webp", 1920, 1080)
image e2s6-44 = im.Scale("season1/episode2/images/scene6/44.webp", 1920, 1080)
image e2s6-45 = im.Scale("season1/episode2/images/scene6/45.webp", 1920, 1080)
image e2s6-46 = im.Scale("season1/episode2/images/scene6/46.webp", 1920, 1080)
image e2s6-47 = im.Scale("season1/episode2/images/scene6/47.webp", 1920, 1080)
image e2s6-48 = im.Scale("season1/episode2/images/scene6/48.webp", 1920, 1080)
image e2s6-49 = im.Scale("season1/episode2/images/scene6/49.webp", 1920, 1080)
image e2s6-50 = im.Scale("season1/episode2/images/scene6/50.webp", 1920, 1080)
image e2s6-51 = im.Scale("season1/episode2/images/scene6/51.webp", 1920, 1080)
image e2s6-52 = im.Scale("season1/episode2/images/scene6/52.webp", 1920, 1080)
image e2s6-53 = im.Scale("season1/episode2/images/scene6/53.webp", 1920, 1080)
image e2s6-54 = im.Scale("season1/episode2/images/scene6/54.webp", 1920, 1080)
image e2s6-55 = im.Scale("season1/episode2/images/scene6/55.webp", 1920, 1080)
image e2s6-56 = im.Scale("season1/episode2/images/scene6/56.webp", 1920, 1080)
image e2s6-57 = im.Scale("season1/episode2/images/scene6/57.webp", 1920, 1080)
image e2s6-58 = im.Scale("season1/episode2/images/scene6/58.webp", 1920, 1080)
image e2s6-59 = im.Scale("season1/episode2/images/scene6/59.webp", 1920, 1080)
image e2s6-60 = im.Scale("season1/episode2/images/scene6/60.webp", 1920, 1080)
image e2s6-61 = im.Scale("season1/episode2/images/scene6/61.webp", 1920, 1080)
image e2s6-62 = im.Scale("season1/episode2/images/scene6/62.webp", 1920, 1080)
image e2s6-63 = im.Scale("season1/episode2/images/scene6/63.webp", 1920, 1080)
image e2s6-64 = im.Scale("season1/episode2/images/scene6/64.webp", 1920, 1080)
image e2s6-65 = im.Scale("season1/episode2/images/scene6/65.webp", 1920, 1080)
image e2s6-66 = im.Scale("season1/episode2/images/scene6/66.webp", 1920, 1080)
image e2s6-67 = im.Scale("season1/episode2/images/scene6/67.webp", 1920, 1080)
image e2s6-68 = im.Scale("season1/episode2/images/scene6/68.webp", 1920, 1080)
image e2s6-69 = im.Scale("season1/episode2/images/scene6/69.webp", 1920, 1080)

image e2s6-jon_blink1:
    im.Scale("season1/episode2/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s6-jon_blink2:
    im.Scale("season1/episode2/images/scene6/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/jon_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s6-sadie_blink1:
    im.Scale("season1/episode2/images/scene6/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s6-sadie_blink2:
    im.Scale("season1/episode2/images/scene6/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e2s6-sadie_blink3:
    im.Scale("season1/episode2/images/scene6/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/scene6/sadie_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
