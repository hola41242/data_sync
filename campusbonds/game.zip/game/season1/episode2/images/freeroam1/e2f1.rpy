
# Freeroam 1 - Library appearance ##############################################

# Map ##########################################################################
# Main #
image e2f1-main = im.Scale("season1/episode2/images/freeroam1/1.webp", 1920, 1080)

# Bookshelfs #
image e2f1-bs_left = im.Scale("season1/episode2/images/freeroam1/3.webp", 1920, 1080)
image e2f1-bs_right = im.Scale("season1/episode2/images/freeroam1/2.webp", 1920, 1080)
image e2f1-bs1 = im.Scale("season1/episode2/images/freeroam1/5.webp", 1920, 1080)
image e2f1-bs2 = im.Scale("season1/episode2/images/freeroam1/6.webp", 1920, 1080)
image e2f1-bs3 = im.Scale("season1/episode2/images/freeroam1/7.webp", 1920, 1080)
image e2f1-bs4 = im.Scale("season1/episode2/images/freeroam1/8.webp", 1920, 1080)
image e2f1-bs4-1 = im.Scale("season1/episode2/images/freeroam1/8.1.webp", 1920, 1080)
image e2f1-bs5 = im.Scale("season1/episode2/images/freeroam1/9.webp", 1920, 1080)
image e2f1-bs5-1 = im.Scale("season1/episode2/images/freeroam1/9.1.webp", 1920, 1080)

# Tables #
image e2f1-tables = im.Scale("season1/episode2/images/freeroam1/4.webp", 1920, 1080)



# Images #######################################################################
image e2f1-01 = im.Scale("season1/episode2/images/freeroam1/images/1.webp", 1920, 1080)

# Evelyn #######################################################################
image e2f1-ev_01 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/1.webp", 1920, 1080)
image e2f1-ev_02 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/2.webp", 1920, 1080)
image e2f1-ev_03 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/3.webp", 1920, 1080)
image e2f1-ev_04 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/4.webp", 1920, 1080)
image e2f1-ev_05 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/5.webp", 1920, 1080)
image e2f1-ev_06 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/6.webp", 1920, 1080)
image e2f1-ev_07 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/7.webp", 1920, 1080)
image e2f1-ev_08 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/8.webp", 1920, 1080)
image e2f1-ev_09 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/9.webp", 1920, 1080)
image e2f1-ev_10 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/10.webp", 1920, 1080)
image e2f1-ev_11 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/11.webp", 1920, 1080)
image e2f1-ev_12 = im.Scale("season1/episode2/images/freeroam1/images/evelyn/12.webp", 1920, 1080)

image e2f1-evelyn_blink1:
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/evelyn/evelyn_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Cleo #########################################################################
image e2f1-cl_01 = im.Scale("season1/episode2/images/freeroam1/images/cleo/1.webp", 1920, 1080)
image e2f1-cl_02 = im.Scale("season1/episode2/images/freeroam1/images/cleo/2.webp", 1920, 1080)
image e2f1-cl_03 = im.Scale("season1/episode2/images/freeroam1/images/cleo/3.webp", 1920, 1080)
image e2f1-cl_04 = im.Scale("season1/episode2/images/freeroam1/images/cleo/4.webp", 1920, 1080)
image e2f1-cl_05 = im.Scale("season1/episode2/images/freeroam1/images/cleo/5.webp", 1920, 1080)
image e2f1-cl_06 = im.Scale("season1/episode2/images/freeroam1/images/cleo/6.webp", 1920, 1080)
image e2f1-cl_07 = im.Scale("season1/episode2/images/freeroam1/images/cleo/7.webp", 1920, 1080)
image e2f1-cl_08 = im.Scale("season1/episode2/images/freeroam1/images/cleo/8.webp", 1920, 1080)
image e2f1-cl_09 = im.Scale("season1/episode2/images/freeroam1/images/cleo/9.webp", 1920, 1080)
image e2f1-cl_10 = im.Scale("season1/episode2/images/freeroam1/images/cleo/10.webp", 1920, 1080)
image e2f1-cl_11 = im.Scale("season1/episode2/images/freeroam1/images/cleo/11.webp", 1920, 1080)

image e2f1-cleo_blink1:
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/cleo/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Ken ##########################################################################
# Images #
image e2f1-ke_01 = im.Scale("season1/episode2/images/freeroam1/images/ken/1.webp", 1920, 1080)
image e2f1-ke_02 = im.Scale("season1/episode2/images/freeroam1/images/ken/2.webp", 1920, 1080)
image e2f1-ke_03 = im.Scale("season1/episode2/images/freeroam1/images/ken/3.webp", 1920, 1080)
image e2f1-ke_04 = im.Scale("season1/episode2/images/freeroam1/images/ken/4.webp", 1920, 1080)
image e2f1-ke_05 = im.Scale("season1/episode2/images/freeroam1/images/ken/5.webp", 1920, 1080)
image e2f1-ke_06 = im.Scale("season1/episode2/images/freeroam1/images/ken/6.webp", 1920, 1080)
image e2f1-ke_07 = im.Scale("season1/episode2/images/freeroam1/images/ken/7.webp", 1920, 1080)
image e2f1-ke_08 = im.Scale("season1/episode2/images/freeroam1/images/ken/8.webp", 1920, 1080)
image e2f1-ke_09 = im.Scale("season1/episode2/images/freeroam1/images/ken/9.webp", 1920, 1080)
image e2f1-ke_10 = im.Scale("season1/episode2/images/freeroam1/images/ken/10.webp", 1920, 1080)
image e2f1-ke_11 = im.Scale("season1/episode2/images/freeroam1/images/ken/11.webp", 1920, 1080)
image e2f1-ke_12 = im.Scale("season1/episode2/images/freeroam1/images/ken/12.webp", 1920, 1080)
image e2f1-ke_13 = im.Scale("season1/episode2/images/freeroam1/images/ken/13.webp", 1920, 1080)
image e2f1-ke_14 = im.Scale("season1/episode2/images/freeroam1/images/ken/14.webp", 1920, 1080)
image e2f1-ke_15 = im.Scale("season1/episode2/images/freeroam1/images/ken/15.webp", 1920, 1080)
image e2f1-ke_16 = im.Scale("season1/episode2/images/freeroam1/images/ken/16.webp", 1920, 1080)
image e2f1-ke_17 = im.Scale("season1/episode2/images/freeroam1/images/ken/17.webp", 1920, 1080)
image e2f1-ke_18 = im.Scale("season1/episode2/images/freeroam1/images/ken/18.webp", 1920, 1080)
image e2f1-ke_19 = im.Scale("season1/episode2/images/freeroam1/images/ken/19.webp", 1920, 1080)
image e2f1-ke_20 = im.Scale("season1/episode2/images/freeroam1/images/ken/20.webp", 1920, 1080)
image e2f1-ke_21 = im.Scale("season1/episode2/images/freeroam1/images/ken/21.webp", 1920, 1080)
image e2f1-ke_22 = im.Scale("season1/episode2/images/freeroam1/images/ken/22.webp", 1920, 1080)
image e2f1-ke_23 = im.Scale("season1/episode2/images/freeroam1/images/ken/23.webp", 1920, 1080)
image e2f1-ke_24 = im.Scale("season1/episode2/images/freeroam1/images/ken/24.webp", 1920, 1080)
image e2f1-ke_25 = im.Scale("season1/episode2/images/freeroam1/images/ken/25.webp", 1920, 1080)


# Animations #
image e2f1-ke_doggy1 = Movie(play="season1/episode2/images/freeroam1/images/ken/doggy1.webm")
image e2f1-ke_doggy2 = Movie(play="season1/episode2/images/freeroam1/images/ken/doggy2.webm")
image e2f1-ke_doggy3 = Movie(play="season1/episode2/images/freeroam1/images/ken/doggy3.webm")
image e2f1-ke_doggy4 = Movie(play="season1/episode2/images/freeroam1/images/ken/doggy4.webm")

# Censored #
# Images #
image e2f1-ke_20_cen = im.Scale("season1/episode2/images/freeroam1/images/ken/censored/20.webp", 1920, 1080)
image e2f1-ke_21_cen = im.Scale("season1/episode2/images/freeroam1/images/ken/censored/21.webp", 1920, 1080)
image e2f1-ke_22_cen = im.Scale("season1/episode2/images/freeroam1/images/ken/censored/22.webp", 1920, 1080)
image e2f1-ke_23_cen = im.Scale("season1/episode2/images/freeroam1/images/ken/censored/23.webp", 1920, 1080)

# Animations #
image e2f1-ke_doggy1_cen = Movie(play="season1/episode2/images/freeroam1/images/ken/censored/doggy1.webm")
image e2f1-ke_doggy2_cen = Movie(play="season1/episode2/images/freeroam1/images/ken/censored/doggy2.webm")
image e2f1-ke_doggy3_cen = Movie(play="season1/episode2/images/freeroam1/images/ken/censored/doggy3.webm")
image e2f1-ke_doggy4_cen = Movie(play="season1/episode2/images/freeroam1/images/ken/censored/doggy4.webm")

image e2f1-ken_blink1:
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f1-ken_blink2:
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/ken/ken_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Alice ########################################################################

image e2f1-al_01 = im.Scale("season1/episode2/images/freeroam1/images/alice/1.webp", 1920, 1080)
image e2f1-al_02 = im.Scale("season1/episode2/images/freeroam1/images/alice/2.webp", 1920, 1080)
image e2f1-al_03 = im.Scale("season1/episode2/images/freeroam1/images/alice/3.webp", 1920, 1080)
image e2f1-al_04 = im.Scale("season1/episode2/images/freeroam1/images/alice/4.webp", 1920, 1080)
image e2f1-al_05 = im.Scale("season1/episode2/images/freeroam1/images/alice/5.webp", 1920, 1080)
image e2f1-al_06 = im.Scale("season1/episode2/images/freeroam1/images/alice/6.webp", 1920, 1080)
image e2f1-al_07 = im.Scale("season1/episode2/images/freeroam1/images/alice/7.webp", 1920, 1080)
image e2f1-al_08 = im.Scale("season1/episode2/images/freeroam1/images/alice/8.webp", 1920, 1080)
image e2f1-al_09 = im.Scale("season1/episode2/images/freeroam1/images/alice/9.webp", 1920, 1080)
image e2f1-al_10 = im.Scale("season1/episode2/images/freeroam1/images/alice/10.webp", 1920, 1080)
image e2f1-al_11 = im.Scale("season1/episode2/images/freeroam1/images/alice/11.webp", 1920, 1080)
image e2f1-al_12 = im.Scale("season1/episode2/images/freeroam1/images/alice/12.webp", 1920, 1080)
image e2f1-al_13 = im.Scale("season1/episode2/images/freeroam1/images/alice/13.webp", 1920, 1080)
image e2f1-al_14 = im.Scale("season1/episode2/images/freeroam1/images/alice/14.webp", 1920, 1080)
image e2f1-al_15 = im.Scale("season1/episode2/images/freeroam1/images/alice/15.webp", 1920, 1080)
image e2f1-al_16 = im.Scale("season1/episode2/images/freeroam1/images/alice/16.webp", 1920, 1080)
image e2f1-al_17 = im.Scale("season1/episode2/images/freeroam1/images/alice/17.webp", 1920, 1080)
image e2f1-al_18 = im.Scale("season1/episode2/images/freeroam1/images/alice/18.webp", 1920, 1080)
image e2f1-al_19 = im.Scale("season1/episode2/images/freeroam1/images/alice/19.webp", 1920, 1080)
image e2f1-al_20 = im.Scale("season1/episode2/images/freeroam1/images/alice/20.webp", 1920, 1080)
image e2f1-al_21 = im.Scale("season1/episode2/images/freeroam1/images/alice/21.webp", 1920, 1080)
image e2f1-al_22 = im.Scale("season1/episode2/images/freeroam1/images/alice/22.webp", 1920, 1080)
image e2f1-al_23 = im.Scale("season1/episode2/images/freeroam1/images/alice/23.webp", 1920, 1080)
image e2f1-al_24 = im.Scale("season1/episode2/images/freeroam1/images/alice/24.webp", 1920, 1080)
image e2f1-al_25 = im.Scale("season1/episode2/images/freeroam1/images/alice/25.webp", 1920, 1080)
image e2f1-al_26 = im.Scale("season1/episode2/images/freeroam1/images/alice/26.webp", 1920, 1080)
image e2f1-al_27 = im.Scale("season1/episode2/images/freeroam1/images/alice/27.webp", 1920, 1080)
image e2f1-al_28 = im.Scale("season1/episode2/images/freeroam1/images/alice/28.webp", 1920, 1080)
image e2f1-al_29 = im.Scale("season1/episode2/images/freeroam1/images/alice/29.webp", 1920, 1080)
image e2f1-al_30 = im.Scale("season1/episode2/images/freeroam1/images/alice/30.webp", 1920, 1080)
image e2f1-al_31 = im.Scale("season1/episode2/images/freeroam1/images/alice/31.webp", 1920, 1080)
image e2f1-al_32 = im.Scale("season1/episode2/images/freeroam1/images/alice/32.webp", 1920, 1080)
image e2f1-al_33 = im.Scale("season1/episode2/images/freeroam1/images/alice/33.webp", 1920, 1080)
image e2f1-al_34 = im.Scale("season1/episode2/images/freeroam1/images/alice/34.webp", 1920, 1080)
image e2f1-al_35 = im.Scale("season1/episode2/images/freeroam1/images/alice/35.webp", 1920, 1080)
image e2f1-al_36 = im.Scale("season1/episode2/images/freeroam1/images/alice/36.webp", 1920, 1080)
image e2f1-al_37 = im.Scale("season1/episode2/images/freeroam1/images/alice/37.webp", 1920, 1080)
image e2f1-al_38 = im.Scale("season1/episode2/images/freeroam1/images/alice/38.webp", 1920, 1080)
image e2f1-al_39 = im.Scale("season1/episode2/images/freeroam1/images/alice/39.webp", 1920, 1080)
image e2f1-al_40 = im.Scale("season1/episode2/images/freeroam1/images/alice/40.webp", 1920, 1080)
image e2f1-al_41 = im.Scale("season1/episode2/images/freeroam1/images/alice/41.webp", 1920, 1080)
image e2f1-al_42 = im.Scale("season1/episode2/images/freeroam1/images/alice/42.webp", 1920, 1080)
image e2f1-al_43 = im.Scale("season1/episode2/images/freeroam1/images/alice/43.webp", 1920, 1080)
image e2f1-al_44 = im.Scale("season1/episode2/images/freeroam1/images/alice/44.webp", 1920, 1080)
image e2f1-al_45 = im.Scale("season1/episode2/images/freeroam1/images/alice/45.webp", 1920, 1080)
image e2f1-al_46 = im.Scale("season1/episode2/images/freeroam1/images/alice/46.webp", 1920, 1080)
image e2f1-al_47 = im.Scale("season1/episode2/images/freeroam1/images/alice/47.webp", 1920, 1080)
image e2f1-al_48 = im.Scale("season1/episode2/images/freeroam1/images/alice/48.webp", 1920, 1080)

image e2f1-alice_blink1:
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f1-alice_blink2:
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f1-alice_blink3:
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e2f1-alice_blink4:
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode2/images/freeroam1/images/alice/alice_blink4/0.webp", 1920, 1080) with dissolve
    4
    repeat
