
# Scene 11 images ##############################################################

image e4s11-01 = im.Scale("season1/episode4/images/scene11/1.webp", 1920, 1080)
image e4s11-02 = im.Scale("season1/episode4/images/scene11/2.webp", 1920, 1080)
image e4s11-03 = im.Scale("season1/episode4/images/scene11/3.webp", 1920, 1080)
image e4s11-04 = im.Scale("season1/episode4/images/scene11/4.webp", 1920, 1080)
image e4s11-05 = im.Scale("season1/episode4/images/scene11/5.webp", 1920, 1080)
image e4s11-06 = im.Scale("season1/episode4/images/scene11/6.webp", 1920, 1080)
image e4s11-07 = im.Scale("season1/episode4/images/scene11/7.webp", 1920, 1080)
image e4s11-08 = im.Scale("season1/episode4/images/scene11/8.webp", 1920, 1080)
image e4s11-09 = im.Scale("season1/episode4/images/scene11/9.webp", 1920, 1080)
image e4s11-10 = im.Scale("season1/episode4/images/scene11/10.webp", 1920, 1080)
image e4s11-11 = im.Scale("season1/episode4/images/scene11/11.webp", 1920, 1080)
image e4s11-12 = im.Scale("season1/episode4/images/scene11/12.webp", 1920, 1080)
image e4s11-13 = im.Scale("season1/episode4/images/scene11/13.webp", 1920, 1080)
image e4s11-14 = im.Scale("season1/episode4/images/scene11/14.webp", 1920, 1080)
image e4s11-15 = im.Scale("season1/episode4/images/scene11/15.webp", 1920, 1080)
image e4s11-16 = im.Scale("season1/episode4/images/scene11/16.webp", 1920, 1080)
image e4s11-17 = im.Scale("season1/episode4/images/scene11/17.webp", 1920, 1080)
image e4s11-18 = im.Scale("season1/episode4/images/scene11/18.webp", 1920, 1080)
image e4s11-19 = im.Scale("season1/episode4/images/scene11/19.webp", 1920, 1080)
image e4s11-20 = im.Scale("season1/episode4/images/scene11/20.webp", 1920, 1080)
image e4s11-21 = im.Scale("season1/episode4/images/scene11/21.webp", 1920, 1080)
image e4s11-22 = im.Scale("season1/episode4/images/scene11/22.webp", 1920, 1080)
image e4s11-23 = im.Scale("season1/episode4/images/scene11/23.webp", 1920, 1080)
image e4s11-24 = im.Scale("season1/episode4/images/scene11/24.webp", 1920, 1080)
image e4s11-25 = im.Scale("season1/episode4/images/scene11/25.webp", 1920, 1080)
image e4s11-26 = im.Scale("season1/episode4/images/scene11/26.webp", 1920, 1080)
image e4s11-27 = im.Scale("season1/episode4/images/scene11/27.webp", 1920, 1080)
image e4s11-28 = im.Scale("season1/episode4/images/scene11/28.webp", 1920, 1080)
image e4s11-29 = im.Scale("season1/episode4/images/scene11/29.webp", 1920, 1080)
image e4s11-30 = im.Scale("season1/episode4/images/scene11/30.webp", 1920, 1080)
image e4s11-31 = im.Scale("season1/episode4/images/scene11/31.webp", 1920, 1080)
image e4s11-32 = im.Scale("season1/episode4/images/scene11/32.webp", 1920, 1080)
image e4s11-33 = im.Scale("season1/episode4/images/scene11/33.webp", 1920, 1080)
image e4s11-34 = im.Scale("season1/episode4/images/scene11/34.webp", 1920, 1080)
image e4s11-35 = im.Scale("season1/episode4/images/scene11/35.webp", 1920, 1080)
image e4s11-36 = im.Scale("season1/episode4/images/scene11/36.webp", 1920, 1080)
image e4s11-37 = im.Scale("season1/episode4/images/scene11/37.webp", 1920, 1080)
image e4s11-38 = im.Scale("season1/episode4/images/scene11/38.webp", 1920, 1080)
image e4s11-39 = im.Scale("season1/episode4/images/scene11/39.webp", 1920, 1080)
image e4s11-40 = im.Scale("season1/episode4/images/scene11/40.webp", 1920, 1080)
image e4s11-41 = im.Scale("season1/episode4/images/scene11/41.webp", 1920, 1080)

# Animations #
# Static
image e4s11_francesca_blink1:
    im.Scale("season1/episode4/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene11/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
