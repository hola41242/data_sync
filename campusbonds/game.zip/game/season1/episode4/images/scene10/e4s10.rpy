
# Scene 10 images ##############################################################

image e4s10-01 = im.Scale("season1/episode4/images/scene10/1.webp", 1920, 1080)
image e4s10-02 = im.Scale("season1/episode4/images/scene10/2.webp", 1920, 1080)
image e4s10-03 = im.Scale("season1/episode4/images/scene10/3.webp", 1920, 1080)
image e4s10-04 = im.Scale("season1/episode4/images/scene10/4.webp", 1920, 1080)
image e4s10-05 = im.Scale("season1/episode4/images/scene10/5.webp", 1920, 1080)
image e4s10-06 = im.Scale("season1/episode4/images/scene10/6.webp", 1920, 1080)
image e4s10-07 = im.Scale("season1/episode4/images/scene10/7.webp", 1920, 1080)
image e4s10-08 = im.Scale("season1/episode4/images/scene10/8.webp", 1920, 1080)
image e4s10-09 = im.Scale("season1/episode4/images/scene10/9.webp", 1920, 1080)
image e4s10-10 = im.Scale("season1/episode4/images/scene10/10.webp", 1920, 1080)
image e4s10-11 = im.Scale("season1/episode4/images/scene10/11.webp", 1920, 1080)
image e4s10-12 = im.Scale("season1/episode4/images/scene10/12.webp", 1920, 1080)
image e4s10-13 = im.Scale("season1/episode4/images/scene10/13.webp", 1920, 1080)
image e4s10-14 = im.Scale("season1/episode4/images/scene10/14.webp", 1920, 1080)
image e4s10-15 = im.Scale("season1/episode4/images/scene10/15.webp", 1920, 1080)
image e4s10-16 = im.Scale("season1/episode4/images/scene10/16.webp", 1920, 1080)
image e4s10-17 = im.Scale("season1/episode4/images/scene10/17.webp", 1920, 1080)
image e4s10-18 = im.Scale("season1/episode4/images/scene10/18.webp", 1920, 1080)
image e4s10-19 = im.Scale("season1/episode4/images/scene10/19.webp", 1920, 1080)
image e4s10-20 = im.Scale("season1/episode4/images/scene10/20.webp", 1920, 1080)
image e4s10-21 = im.Scale("season1/episode4/images/scene10/21.webp", 1920, 1080)
image e4s10-22 = im.Scale("season1/episode4/images/scene10/22.webp", 1920, 1080)
image e4s10-23 = im.Scale("season1/episode4/images/scene10/23.webp", 1920, 1080)
image e4s10-24 = im.Scale("season1/episode4/images/scene10/24.webp", 1920, 1080)
image e4s10-25 = im.Scale("season1/episode4/images/scene10/25.webp", 1920, 1080)
image e4s10-26 = im.Scale("season1/episode4/images/scene10/26.webp", 1920, 1080)
image e4s10-27 = im.Scale("season1/episode4/images/scene10/27.webp", 1920, 1080)
image e4s10-28 = im.Scale("season1/episode4/images/scene10/28.webp", 1920, 1080)
image e4s10-29 = im.Scale("season1/episode4/images/scene10/29.webp", 1920, 1080)
image e4s10-30 = im.Scale("season1/episode4/images/scene10/30.webp", 1920, 1080)
image e4s10-31 = im.Scale("season1/episode4/images/scene10/31.webp", 1920, 1080)
image e4s10-32 = im.Scale("season1/episode4/images/scene10/32.webp", 1920, 1080)
image e4s10-33 = im.Scale("season1/episode4/images/scene10/33.webp", 1920, 1080)
image e4s10-34 = im.Scale("season1/episode4/images/scene10/34.webp", 1920, 1080)
image e4s10-35 = im.Scale("season1/episode4/images/scene10/35.webp", 1920, 1080)
image e4s10-36 = im.Scale("season1/episode4/images/scene10/36.webp", 1920, 1080)
image e4s10-37 = im.Scale("season1/episode4/images/scene10/37.webp", 1920, 1080)
image e4s10-38 = im.Scale("season1/episode4/images/scene10/38.webp", 1920, 1080)
image e4s10-39 = im.Scale("season1/episode4/images/scene10/39.webp", 1920, 1080)
image e4s10-40 = im.Scale("season1/episode4/images/scene10/40.webp", 1920, 1080)
image e4s10-41 = im.Scale("season1/episode4/images/scene10/41.webp", 1920, 1080)
image e4s10-42 = im.Scale("season1/episode4/images/scene10/42.webp", 1920, 1080)
image e4s10-43 = im.Scale("season1/episode4/images/scene10/43.webp", 1920, 1080)

image e4s10_jon_blink1:
    im.Scale("season1/episode4/images/scene10/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene10/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
