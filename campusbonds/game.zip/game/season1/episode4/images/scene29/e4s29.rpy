
# Scene 29 images ###############################################################

image e4s29-01 = im.Scale("season1/episode4/images/scene29/1.webp", 1920, 1080)
image e4s29-02 = im.Scale("season1/episode4/images/scene29/2.webp", 1920, 1080)
image e4s29-03 = im.Scale("season1/episode4/images/scene29/3.webp", 1920, 1080)
image e4s29-04 = im.Scale("season1/episode4/images/scene29/4.webp", 1920, 1080)
image e4s29-05 = im.Scale("season1/episode4/images/scene29/5.webp", 1920, 1080)
image e4s29-06 = im.Scale("season1/episode4/images/scene29/6.webp", 1920, 1080)
image e4s29-07 = im.Scale("season1/episode4/images/scene29/7.webp", 1920, 1080)
image e4s29-08 = im.Scale("season1/episode4/images/scene29/8.webp", 1920, 1080)
image e4s29-09 = im.Scale("season1/episode4/images/scene29/9.webp", 1920, 1080)
image e4s29-10 = im.Scale("season1/episode4/images/scene29/10.webp", 1920, 1080)
image e4s29-11 = im.Scale("season1/episode4/images/scene29/11.webp", 1920, 1080)
image e4s29-12 = im.Scale("season1/episode4/images/scene29/12.webp", 1920, 1080)
image e4s29-13 = im.Scale("season1/episode4/images/scene29/13.webp", 1920, 1080)
image e4s29-14 = im.Scale("season1/episode4/images/scene29/14.webp", 1920, 1080)
image e4s29-15 = im.Scale("season1/episode4/images/scene29/15.webp", 1920, 1080)
image e4s29-16 = im.Scale("season1/episode4/images/scene29/16.webp", 1920, 1080)
image e4s29-17 = im.Scale("season1/episode4/images/scene29/17.webp", 1920, 1080)

image e4s29_olivia_blink1:
    im.Scale("season1/episode4/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene29/olivia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
