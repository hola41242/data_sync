
# Scene 36 images ##############################################################

image e4s36-01 = im.Scale("season1/episode4/images/scene36/1.webp", 1920, 1080)
image e4s36-02 = im.Scale("season1/episode4/images/scene36/2.webp", 1920, 1080)
image e4s36-03 = im.Scale("season1/episode4/images/scene36/3.webp", 1920, 1080)
image e4s36-04 = im.Scale("season1/episode4/images/scene36/4.webp", 1920, 1080)
image e4s36-05 = im.Scale("season1/episode4/images/scene36/5.webp", 1920, 1080)
image e4s36-06 = im.Scale("season1/episode4/images/scene36/6.webp", 1920, 1080)
image e4s36-07 = im.Scale("season1/episode4/images/scene36/7.webp", 1920, 1080)
image e4s36-08 = im.Scale("season1/episode4/images/scene36/8.webp", 1920, 1080)
image e4s36-09 = im.Scale("season1/episode4/images/scene36/9.webp", 1920, 1080)
image e4s36-10 = im.Scale("season1/episode4/images/scene36/10.webp", 1920, 1080)
image e4s36-11 = im.Scale("season1/episode4/images/scene36/11.webp", 1920, 1080)
image e4s36-12 = im.Scale("season1/episode4/images/scene36/12.webp", 1920, 1080)
image e4s36-13 = im.Scale("season1/episode4/images/scene36/13.webp", 1920, 1080)
