
# Scene 35 images ##############################################################

image e4s35-01 = im.Scale("season1/episode4/images/scene35/1.webp", 1920, 1080)
image e4s35-02 = im.Scale("season1/episode4/images/scene35/2.webp", 1920, 1080)
image e4s35-03 = im.Scale("season1/episode4/images/scene35/3.webp", 1920, 1080)
image e4s35-04 = im.Scale("season1/episode4/images/scene35/4.webp", 1920, 1080)
image e4s35-05 = im.Scale("season1/episode4/images/scene35/5.webp", 1920, 1080)
image e4s35-06 = im.Scale("season1/episode4/images/scene35/6.webp", 1920, 1080)
image e4s35-07 = im.Scale("season1/episode4/images/scene35/7.webp", 1920, 1080)
image e4s35-08 = im.Scale("season1/episode4/images/scene35/8.webp", 1920, 1080)
image e4s35-09 = im.Scale("season1/episode4/images/scene35/9.webp", 1920, 1080)
image e4s35-10 = im.Scale("season1/episode4/images/scene35/10.webp", 1920, 1080)
image e4s35-11 = im.Scale("season1/episode4/images/scene35/11.webp", 1920, 1080)
image e4s35-12 = im.Scale("season1/episode4/images/scene35/12.webp", 1920, 1080)
image e4s35-13 = im.Scale("season1/episode4/images/scene35/13.webp", 1920, 1080)
image e4s35-14 = im.Scale("season1/episode4/images/scene35/14.webp", 1920, 1080)
image e4s35-15 = im.Scale("season1/episode4/images/scene35/15.webp", 1920, 1080)
image e4s35-16 = im.Scale("season1/episode4/images/scene35/16.webp", 1920, 1080)
image e4s35-17 = im.Scale("season1/episode4/images/scene35/17.webp", 1920, 1080)
image e4s35-18 = im.Scale("season1/episode4/images/scene35/18.webp", 1920, 1080)
image e4s35-19 = im.Scale("season1/episode4/images/scene35/19.webp", 1920, 1080)
image e4s35-20 = im.Scale("season1/episode4/images/scene35/20.webp", 1920, 1080)
image e4s35-21 = im.Scale("season1/episode4/images/scene35/21.webp", 1920, 1080)
image e4s35-22 = im.Scale("season1/episode4/images/scene35/22.webp", 1920, 1080)
image e4s35-23 = im.Scale("season1/episode4/images/scene35/23.webp", 1920, 1080)
image e4s35-24 = im.Scale("season1/episode4/images/scene35/24.webp", 1920, 1080)
image e4s35-25 = im.Scale("season1/episode4/images/scene35/25.webp", 1920, 1080)
image e4s35-26 = im.Scale("season1/episode4/images/scene35/26.webp", 1920, 1080)
image e4s35-27 = im.Scale("season1/episode4/images/scene35/27.webp", 1920, 1080)
image e4s35-28 = im.Scale("season1/episode4/images/scene35/28.webp", 1920, 1080)
image e4s35-29 = im.Scale("season1/episode4/images/scene35/29.webp", 1920, 1080)
image e4s35-30 = im.Scale("season1/episode4/images/scene35/30.webp", 1920, 1080)
image e4s35-31 = im.Scale("season1/episode4/images/scene35/31.webp", 1920, 1080)
image e4s35-32 = im.Scale("season1/episode4/images/scene35/32.webp", 1920, 1080)
image e4s35-33 = im.Scale("season1/episode4/images/scene35/33.webp", 1920, 1080)
image e4s35-34 = im.Scale("season1/episode4/images/scene35/34.webp", 1920, 1080)
image e4s35-35 = im.Scale("season1/episode4/images/scene35/35.webp", 1920, 1080)
image e4s35-36 = im.Scale("season1/episode4/images/scene35/36.webp", 1920, 1080)
image e4s35-37 = im.Scale("season1/episode4/images/scene35/37.webp", 1920, 1080)
image e4s35-38 = im.Scale("season1/episode4/images/scene35/38.webp", 1920, 1080)
image e4s35-39 = im.Scale("season1/episode4/images/scene35/39.webp", 1920, 1080)
image e4s35-40 = im.Scale("season1/episode4/images/scene35/40.webp", 1920, 1080)
image e4s35-41 = im.Scale("season1/episode4/images/scene35/41.webp", 1920, 1080)
image e4s35-42 = im.Scale("season1/episode4/images/scene35/42.webp", 1920, 1080)
image e4s35-43 = im.Scale("season1/episode4/images/scene35/43.webp", 1920, 1080)
image e4s35-44 = im.Scale("season1/episode4/images/scene35/44.webp", 1920, 1080)
image e4s35-45 = im.Scale("season1/episode4/images/scene35/45.webp", 1920, 1080)
image e4s35-46 = im.Scale("season1/episode4/images/scene35/46.webp", 1920, 1080)
image e4s35-47 = im.Scale("season1/episode4/images/scene35/47.webp", 1920, 1080)
image e4s35-48 = im.Scale("season1/episode4/images/scene35/48.webp", 1920, 1080)
image e4s35-49 = im.Scale("season1/episode4/images/scene35/49.webp", 1920, 1080)
image e4s35-50 = im.Scale("season1/episode4/images/scene35/50.webp", 1920, 1080)
image e4s35-51 = im.Scale("season1/episode4/images/scene35/51.webp", 1920, 1080)
image e4s35-52 = im.Scale("season1/episode4/images/scene35/52.webp", 1920, 1080)
image e4s35-53 = im.Scale("season1/episode4/images/scene35/53.webp", 1920, 1080)
image e4s35-54 = im.Scale("season1/episode4/images/scene35/54.webp", 1920, 1080)
image e4s35-55 = im.Scale("season1/episode4/images/scene35/55.webp", 1920, 1080)
image e4s35-56 = im.Scale("season1/episode4/images/scene35/56.webp", 1920, 1080)
image e4s35-57 = im.Scale("season1/episode4/images/scene35/57.webp", 1920, 1080)
image e4s35-58 = im.Scale("season1/episode4/images/scene35/58.webp", 1920, 1080)
image e4s35-59 = im.Scale("season1/episode4/images/scene35/59.webp", 1920, 1080)
image e4s35-60 = im.Scale("season1/episode4/images/scene35/60.webp", 1920, 1080)
image e4s35-61 = im.Scale("season1/episode4/images/scene35/61.webp", 1920, 1080)
image e4s35-62 = im.Scale("season1/episode4/images/scene35/62.webp", 1920, 1080)
image e4s35-63 = im.Scale("season1/episode4/images/scene35/63.webp", 1920, 1080)
image e4s35-64 = im.Scale("season1/episode4/images/scene35/64.webp", 1920, 1080)
image e4s35-65 = im.Scale("season1/episode4/images/scene35/65.webp", 1920, 1080)
image e4s35-66 = im.Scale("season1/episode4/images/scene35/66.webp", 1920, 1080)
image e4s35-67 = im.Scale("season1/episode4/images/scene35/67.webp", 1920, 1080)
image e4s35-68 = im.Scale("season1/episode4/images/scene35/68.webp", 1920, 1080)
image e4s35-69 = im.Scale("season1/episode4/images/scene35/69.webp", 1920, 1080)
image e4s35-70 = im.Scale("season1/episode4/images/scene35/70.webp", 1920, 1080)
image e4s35-71 = im.Scale("season1/episode4/images/scene35/71.webp", 1920, 1080)
image e4s35-72 = im.Scale("season1/episode4/images/scene35/72.webp", 1920, 1080)
image e4s35-73 = im.Scale("season1/episode4/images/scene35/73.webp", 1920, 1080)
image e4s35-74 = im.Scale("season1/episode4/images/scene35/74.webp", 1920, 1080)
image e4s35-75 = im.Scale("season1/episode4/images/scene35/75.webp", 1920, 1080)
image e4s35-76 = im.Scale("season1/episode4/images/scene35/76.webp", 1920, 1080)
image e4s35-77 = im.Scale("season1/episode4/images/scene35/77.webp", 1920, 1080)
image e4s35-78 = im.Scale("season1/episode4/images/scene35/78.webp", 1920, 1080)
image e4s35-79 = im.Scale("season1/episode4/images/scene35/79.webp", 1920, 1080)

# Animations #
# Static
image e4s35_sadie_blink1:
    im.Scale("season1/episode4/images/scene35/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene35/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e4s35-cowgirl1 = Movie(play="season1/episode4/images/scene35/cowgirl1.webm")
image e4s35-cowgirl2 = Movie(play="season1/episode4/images/scene35/cowgirl2.webm")
image e4s35-cowgirl3 = Movie(play="season1/episode4/images/scene35/cowgirl3.webm")
image e4s35-cowgirl4 = Movie(play="season1/episode4/images/scene35/cowgirl4.webm")
image e4s35-cowgirl5 = Movie(play="season1/episode4/images/scene35/cowgirl5.webm")
image e4s35-cowgirl6 = Movie(play="season1/episode4/images/scene35/cowgirl6.webm")
image e4s35-cowgirl7 = Movie(play="season1/episode4/images/scene35/cowgirl7.webm")
image e4s35-cowgirl8 = Movie(play="season1/episode4/images/scene35/cowgirl8.webm")
image e4s35-cowgirl9 = Movie(play="season1/episode4/images/scene35/cowgirl9.webm")
image e4s35-fingering1 = Movie(play="season1/episode4/images/scene35/fingering1.webm")
image e4s35-fingering2 = Movie(play="season1/episode4/images/scene35/fingering2.webm")
image e4s35-fingering3 = Movie(play="season1/episode4/images/scene35/fingering3.webm")
image e4s35-fingering4 = Movie(play="season1/episode4/images/scene35/fingering4.webm")
image e4s35-fingering5 = Movie(play="season1/episode4/images/scene35/fingering5.webm")
image e4s35-fingering6 = Movie(play="season1/episode4/images/scene35/fingering6.webm")
image e4s35-fingering7 = Movie(play="season1/episode4/images/scene35/fingering7.webm")
image e4s35-kiss1 = Movie(play="season1/episode4/images/scene35/kiss1.webm")
image e4s35-kiss2 = Movie(play="season1/episode4/images/scene35/kiss2.webm")
image e4s35-kiss3 = Movie(play="season1/episode4/images/scene35/kiss3.webm")
image e4s35-pussy_eating1 = Movie(play="season1/episode4/images/scene35/pussy_eating1.webm")
image e4s35-pussy_eating2 = Movie(play="season1/episode4/images/scene35/pussy_eating2.webm")

# Censored
# Images
image e4s35-36_cen = im.Scale("season1/episode4/images/scene35/censored/36.webp", 1920, 1080)
image e4s35-37_cen = im.Scale("season1/episode4/images/scene35/censored/37.webp", 1920, 1080)
image e4s35-38_cen = im.Scale("season1/episode4/images/scene35/censored/38.webp", 1920, 1080)
image e4s35-39_cen = im.Scale("season1/episode4/images/scene35/censored/39.webp", 1920, 1080)
image e4s35-40_cen = im.Scale("season1/episode4/images/scene35/censored/40.webp", 1920, 1080)
image e4s35-41_cen = im.Scale("season1/episode4/images/scene35/censored/41.webp", 1920, 1080)
image e4s35-42_cen = im.Scale("season1/episode4/images/scene35/censored/42.webp", 1920, 1080)
image e4s35-43_cen = im.Scale("season1/episode4/images/scene35/censored/43.webp", 1920, 1080)
image e4s35-44_cen = im.Scale("season1/episode4/images/scene35/censored/44.webp", 1920, 1080)
image e4s35-45_cen = im.Scale("season1/episode4/images/scene35/censored/45.webp", 1920, 1080)
image e4s35-46_cen = im.Scale("season1/episode4/images/scene35/censored/46.webp", 1920, 1080)
image e4s35-47_cen = im.Scale("season1/episode4/images/scene35/censored/47.webp", 1920, 1080)
image e4s35-48_cen = im.Scale("season1/episode4/images/scene35/censored/48.webp", 1920, 1080)
image e4s35-49_cen = im.Scale("season1/episode4/images/scene35/censored/49.webp", 1920, 1080)
image e4s35-50_cen = im.Scale("season1/episode4/images/scene35/censored/50.webp", 1920, 1080)
image e4s35-51_cen = im.Scale("season1/episode4/images/scene35/censored/51.webp", 1920, 1080)
image e4s35-52_cen = im.Scale("season1/episode4/images/scene35/censored/52.webp", 1920, 1080)
image e4s35-53_cen = im.Scale("season1/episode4/images/scene35/censored/53.webp", 1920, 1080)
image e4s35-54_cen = im.Scale("season1/episode4/images/scene35/censored/54.webp", 1920, 1080)
image e4s35-55_cen = im.Scale("season1/episode4/images/scene35/censored/55.webp", 1920, 1080)
image e4s35-56_cen = im.Scale("season1/episode4/images/scene35/censored/56.webp", 1920, 1080)
image e4s35-57_cen = im.Scale("season1/episode4/images/scene35/censored/57.webp", 1920, 1080)
image e4s35-58_cen = im.Scale("season1/episode4/images/scene35/censored/58.webp", 1920, 1080)
image e4s35-59_cen = im.Scale("season1/episode4/images/scene35/censored/59.webp", 1920, 1080)
image e4s35-60_cen = im.Scale("season1/episode4/images/scene35/censored/60.webp", 1920, 1080)
image e4s35-61_cen = im.Scale("season1/episode4/images/scene35/censored/61.webp", 1920, 1080)
image e4s35-62_cen = im.Scale("season1/episode4/images/scene35/censored/62.webp", 1920, 1080)
image e4s35-63_cen = im.Scale("season1/episode4/images/scene35/censored/63.webp", 1920, 1080)
image e4s35-64_cen = im.Scale("season1/episode4/images/scene35/censored/64.webp", 1920, 1080)
image e4s35-65_cen = im.Scale("season1/episode4/images/scene35/censored/65.webp", 1920, 1080)
image e4s35-66_cen = im.Scale("season1/episode4/images/scene35/censored/66.webp", 1920, 1080)
image e4s35-67_cen = im.Scale("season1/episode4/images/scene35/censored/67.webp", 1920, 1080)
image e4s35-68_cen = im.Scale("season1/episode4/images/scene35/censored/68.webp", 1920, 1080)
image e4s35-69_cen = im.Scale("season1/episode4/images/scene35/censored/69.webp", 1920, 1080)
image e4s35-70_cen = im.Scale("season1/episode4/images/scene35/censored/70.webp", 1920, 1080)
image e4s35-79_cen = im.Scale("season1/episode4/images/scene35/censored/79.webp", 1920, 1080)

# Videos
image e4s35-cowgirl1_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl1.webm")
image e4s35-cowgirl2_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl2.webm")
image e4s35-cowgirl3_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl3.webm")
image e4s35-cowgirl4_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl4.webm")
image e4s35-cowgirl5_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl5.webm")
image e4s35-cowgirl6_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl6.webm")
image e4s35-cowgirl7_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl7.webm")
image e4s35-cowgirl8_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl8.webm")
image e4s35-cowgirl9_cen = Movie(play="season1/episode4/images/scene35/censored/cowgirl9.webm")
image e4s35-fingering1_cen = Movie(play="season1/episode4/images/scene35/censored/fingering1.webm")
image e4s35-fingering2_cen = Movie(play="season1/episode4/images/scene35/censored/fingering2.webm")
image e4s35-fingering3_cen = Movie(play="season1/episode4/images/scene35/censored/fingering3.webm")
image e4s35-fingering4_cen = Movie(play="season1/episode4/images/scene35/censored/fingering4.webm")
image e4s35-fingering5_cen = Movie(play="season1/episode4/images/scene35/censored/fingering5.webm")
image e4s35-fingering6_cen = Movie(play="season1/episode4/images/scene35/censored/fingering6.webm")
image e4s35-fingering7_cen = Movie(play="season1/episode4/images/scene35/censored/fingering7.webm")
image e4s35-pussy_eating1_cen = Movie(play="season1/episode4/images/scene35/censored/pussy_eating1.webm")
image e4s35-pussy_eating2_cen = Movie(play="season1/episode4/images/scene35/censored/pussy_eating2.webm")
