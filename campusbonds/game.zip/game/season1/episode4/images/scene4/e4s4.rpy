
# Scene 4 images ###############################################################

image e4s4-01 = im.Scale("season1/episode4/images/scene4/1.webp", 1920, 1080)
image e4s4-02 = im.Scale("season1/episode4/images/scene4/2.webp", 1920, 1080)
image e4s4-03 = im.Scale("season1/episode4/images/scene4/3.webp", 1920, 1080)
image e4s4-04 = im.Scale("season1/episode4/images/scene4/4.webp", 1920, 1080)
image e4s4-05 = im.Scale("season1/episode4/images/scene4/5.webp", 1920, 1080)
image e4s4-06 = im.Scale("season1/episode4/images/scene4/6.webp", 1920, 1080)
image e4s4-07 = im.Scale("season1/episode4/images/scene4/7.webp", 1920, 1080)
image e4s4-08 = im.Scale("season1/episode4/images/scene4/8.webp", 1920, 1080)
image e4s4-09 = im.Scale("season1/episode4/images/scene4/9.webp", 1920, 1080)
image e4s4-10 = im.Scale("season1/episode4/images/scene4/10.webp", 1920, 1080)
image e4s4-11 = im.Scale("season1/episode4/images/scene4/11.webp", 1920, 1080)
image e4s4-12 = im.Scale("season1/episode4/images/scene4/12.webp", 1920, 1080)
image e4s4-13 = im.Scale("season1/episode4/images/scene4/13.webp", 1920, 1080)
image e4s4-14 = im.Scale("season1/episode4/images/scene4/14.webp", 1920, 1080)
image e4s4-15 = im.Scale("season1/episode4/images/scene4/15.webp", 1920, 1080)

image e4s4_tiffany_blink1:
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene4/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
