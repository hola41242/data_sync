
# Scene 17 images ##############################################################

image e4s17-01 = im.Scale("season1/episode4/images/scene17/1.webp", 1920, 1080)
image e4s17-02 = im.Scale("season1/episode4/images/scene17/2.webp", 1920, 1080)
image e4s17-03 = im.Scale("season1/episode4/images/scene17/3.webp", 1920, 1080)
image e4s17-04 = im.Scale("season1/episode4/images/scene17/4.webp", 1920, 1080)
image e4s17-05 = im.Scale("season1/episode4/images/scene17/5.webp", 1920, 1080)
