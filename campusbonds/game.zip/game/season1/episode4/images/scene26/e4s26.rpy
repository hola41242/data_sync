
# Scene 26 images ##############################################################

image e4s26-01 = im.Scale("season1/episode4/images/scene26/1.webp", 1920, 1080)
image e4s26-02 = im.Scale("season1/episode4/images/scene26/2.webp", 1920, 1080)
image e4s26-03 = im.Scale("season1/episode4/images/scene26/3.webp", 1920, 1080)
image e4s26-04 = im.Scale("season1/episode4/images/scene26/4.webp", 1920, 1080)
image e4s26-05 = im.Scale("season1/episode4/images/scene26/5.webp", 1920, 1080)
image e4s26-06 = im.Scale("season1/episode4/images/scene26/6.webp", 1920, 1080)
image e4s26-07 = im.Scale("season1/episode4/images/scene26/7.webp", 1920, 1080)
image e4s26-08 = im.Scale("season1/episode4/images/scene26/8.webp", 1920, 1080)
image e4s26-09 = im.Scale("season1/episode4/images/scene26/9.webp", 1920, 1080)
image e4s26-10 = im.Scale("season1/episode4/images/scene26/10.webp", 1920, 1080)
image e4s26-11 = im.Scale("season1/episode4/images/scene26/11.webp", 1920, 1080)
image e4s26-12 = im.Scale("season1/episode4/images/scene26/12.webp", 1920, 1080)
image e4s26-13 = im.Scale("season1/episode4/images/scene26/13.webp", 1920, 1080)
image e4s26-14 = im.Scale("season1/episode4/images/scene26/14.webp", 1920, 1080)
image e4s26-15 = im.Scale("season1/episode4/images/scene26/15.webp", 1920, 1080)
image e4s26-16 = im.Scale("season1/episode4/images/scene26/16.webp", 1920, 1080)
image e4s26-17 = im.Scale("season1/episode4/images/scene26/17.webp", 1920, 1080)
image e4s26-18 = im.Scale("season1/episode4/images/scene26/18.webp", 1920, 1080)
image e4s26-19 = im.Scale("season1/episode4/images/scene26/19.webp", 1920, 1080)
image e4s26-20 = im.Scale("season1/episode4/images/scene26/20.webp", 1920, 1080)
image e4s26-21 = im.Scale("season1/episode4/images/scene26/21.webp", 1920, 1080)
image e4s26-22 = im.Scale("season1/episode4/images/scene26/22.webp", 1920, 1080)
image e4s26-23 = im.Scale("season1/episode4/images/scene26/23.webp", 1920, 1080)
image e4s26-24 = im.Scale("season1/episode4/images/scene26/24.webp", 1920, 1080)
image e4s26-25 = im.Scale("season1/episode4/images/scene26/25.webp", 1920, 1080)
image e4s26-26 = im.Scale("season1/episode4/images/scene26/26.webp", 1920, 1080)
image e4s26-27 = im.Scale("season1/episode4/images/scene26/27.webp", 1920, 1080)
image e4s26-28 = im.Scale("season1/episode4/images/scene26/28.webp", 1920, 1080)
image e4s26-29 = im.Scale("season1/episode4/images/scene26/29.webp", 1920, 1080)
image e4s26-30 = im.Scale("season1/episode4/images/scene26/30.webp", 1920, 1080)
image e4s26-31 = im.Scale("season1/episode4/images/scene26/31.webp", 1920, 1080)
image e4s26-32 = im.Scale("season1/episode4/images/scene26/32.webp", 1920, 1080)
image e4s26-33 = im.Scale("season1/episode4/images/scene26/33.webp", 1920, 1080)
image e4s26-34 = im.Scale("season1/episode4/images/scene26/34.webp", 1920, 1080)
image e4s26-35 = im.Scale("season1/episode4/images/scene26/35.webp", 1920, 1080)
image e4s26-36 = im.Scale("season1/episode4/images/scene26/36.webp", 1920, 1080)
image e4s26-37 = im.Scale("season1/episode4/images/scene26/37.webp", 1920, 1080)
image e4s26-38 = im.Scale("season1/episode4/images/scene26/38.webp", 1920, 1080)
image e4s26-39 = im.Scale("season1/episode4/images/scene26/39.webp", 1920, 1080)
image e4s26-40 = im.Scale("season1/episode4/images/scene26/40.webp", 1920, 1080)
image e4s26-41 = im.Scale("season1/episode4/images/scene26/41.webp", 1920, 1080)
image e4s26-42 = im.Scale("season1/episode4/images/scene26/42.webp", 1920, 1080)
image e4s26-43 = im.Scale("season1/episode4/images/scene26/43.webp", 1920, 1080)
image e4s26-44 = im.Scale("season1/episode4/images/scene26/44.webp", 1920, 1080)
image e4s26-45 = im.Scale("season1/episode4/images/scene26/45.webp", 1920, 1080)
image e4s26-46 = im.Scale("season1/episode4/images/scene26/46.webp", 1920, 1080)
image e4s26-47 = im.Scale("season1/episode4/images/scene26/47.webp", 1920, 1080)
image e4s26-48 = im.Scale("season1/episode4/images/scene26/48.webp", 1920, 1080)
image e4s26-49 = im.Scale("season1/episode4/images/scene26/49.webp", 1920, 1080)
image e4s26-50 = im.Scale("season1/episode4/images/scene26/50.webp", 1920, 1080)
image e4s26-51 = im.Scale("season1/episode4/images/scene26/51.webp", 1920, 1080)
image e4s26-52 = im.Scale("season1/episode4/images/scene26/52.webp", 1920, 1080)
image e4s26-53 = im.Scale("season1/episode4/images/scene26/53.webp", 1920, 1080)
image e4s26-54 = im.Scale("season1/episode4/images/scene26/54.webp", 1920, 1080)
image e4s26-55 = im.Scale("season1/episode4/images/scene26/55.webp", 1920, 1080)
image e4s26-56 = im.Scale("season1/episode4/images/scene26/56.webp", 1920, 1080)
image e4s26-57 = im.Scale("season1/episode4/images/scene26/57.webp", 1920, 1080)
image e4s26-58 = im.Scale("season1/episode4/images/scene26/58.webp", 1920, 1080)

image e4s26_cleo_blink1:
    im.Scale("season1/episode4/images/scene26/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e4s26_darryl_blink1:
    im.Scale("season1/episode4/images/scene26/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene26/darryl_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
