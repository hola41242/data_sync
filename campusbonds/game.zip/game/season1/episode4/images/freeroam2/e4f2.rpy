
# Freeroam 2 Images ############################################################
# Dance Floor
image e4f2-01 = im.Scale("season1/episode4/images/freeroam2/1.webp", 1920, 1080)
image e4f2-01_1 = im.Scale("season1/episode4/images/freeroam2/1.1.webp", 1920, 1080)
image e4f2-01_2 = im.Scale("season1/episode4/images/freeroam2/1.2.webp", 1920, 1080)
image e4f2-01_3 = im.Scale("season1/episode4/images/freeroam2/1.3.webp", 1920, 1080)

# Couch
image e4f2-02 = im.Scale("season1/episode4/images/freeroam2/2.webp", 1920, 1080)
image e4f2-02_1 = im.Scale("season1/episode4/images/freeroam2/2.1.webp", 1920, 1080)
image e4f2-02_2 = im.Scale("season1/episode4/images/freeroam2/2.2.webp", 1920, 1080)

# DJ
image e4f2-03 = im.Scale("season1/episode4/images/freeroam2/3.webp", 1920, 1080)

# Vending
image e4f2-04 = im.Scale("season1/episode4/images/freeroam2/4.webp", 1920, 1080)
image e4f2-04_1 = im.Scale("season1/episode4/images/freeroam2/4.1.webp", 1920, 1080)
image e4f2-04_2 = im.Scale("season1/episode4/images/freeroam2/4.2.webp", 1920, 1080)

# Pool
image e4f2-05 = im.Scale("season1/episode4/images/freeroam2/5.webp", 1920, 1080)
image e4f2-05_1 = im.Scale("season1/episode4/images/freeroam2/5.1.webp", 1920, 1080)
image e4f2-05_2 = im.Scale("season1/episode4/images/freeroam2/5.2.webp", 1920, 1080)

# Staff
image e4f2-06 = im.Scale("season1/episode4/images/freeroam2/6.webp", 1920, 1080)

# Bar
image e4f2-07 = im.Scale("season1/episode4/images/freeroam2/7.webp", 1920, 1080)
image e4f2-07_1 = im.Scale("season1/episode4/images/freeroam2/7.1.webp", 1920, 1080)

# Pool Couch
image e4f2-08 = im.Scale("season1/episode4/images/freeroam2/8.webp", 1920, 1080)

# Vending Table
image e4f2-09 = im.Scale("season1/episode4/images/freeroam2/9.webp", 1920, 1080)

# Ken
image e4f2-ken_01 = im.Scale("season1/episode4/images/freeroam2/images/ken1/1.webp", 1920, 1080)
image e4f2-ken_02 = im.Scale("season1/episode4/images/freeroam2/images/ken1/2.webp", 1920, 1080)
image e4f2-ken_03 = im.Scale("season1/episode4/images/freeroam2/images/ken1/3.webp", 1920, 1080)
image e4f2-ken_04 = im.Scale("season1/episode4/images/freeroam2/images/ken1/4.webp", 1920, 1080)
image e4f2-ken_05 = im.Scale("season1/episode4/images/freeroam2/images/ken1/5.webp", 1920, 1080)
image e4f2-ken_06 = im.Scale("season1/episode4/images/freeroam2/images/ken1/6.webp", 1920, 1080)
image e4f2-ken_07 = im.Scale("season1/episode4/images/freeroam2/images/ken1/7.webp", 1920, 1080)

image e4f2_ken_blink1:
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/ken1/ken_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Mia
image e4f2-mia_01 = im.Scale("season1/episode4/images/freeroam2/images/mia1/1.webp", 1920, 1080)
image e4f2-mia_02 = im.Scale("season1/episode4/images/freeroam2/images/mia1/2.webp", 1920, 1080)
image e4f2-mia_03 = im.Scale("season1/episode4/images/freeroam2/images/mia1/3.webp", 1920, 1080)
image e4f2-mia_04 = im.Scale("season1/episode4/images/freeroam2/images/mia1/4.webp", 1920, 1080)
image e4f2-mia_05 = im.Scale("season1/episode4/images/freeroam2/images/mia1/5.webp", 1920, 1080)
image e4f2-mia_06 = im.Scale("season1/episode4/images/freeroam2/images/mia1/6.webp", 1920, 1080)
image e4f2-mia_07 = im.Scale("season1/episode4/images/freeroam2/images/mia1/7.webp", 1920, 1080)
image e4f2-mia_08 = im.Scale("season1/episode4/images/freeroam2/images/mia1/8.webp", 1920, 1080)
image e4f2-mia_09 = im.Scale("season1/episode4/images/freeroam2/images/mia1/9.webp", 1920, 1080)
image e4f2-mia_10 = im.Scale("season1/episode4/images/freeroam2/images/mia1/10.webp", 1920, 1080)
image e4f2-mia_11 = im.Scale("season1/episode4/images/freeroam2/images/mia1/11.webp", 1920, 1080)
image e4f2-mia_12 = im.Scale("season1/episode4/images/freeroam2/images/mia1/12.webp", 1920, 1080)
image e4f2-mia_13 = im.Scale("season1/episode4/images/freeroam2/images/mia1/13.webp", 1920, 1080)
image e4f2-mia_14 = im.Scale("season1/episode4/images/freeroam2/images/mia1/14.webp", 1920, 1080)
image e4f2-mia_15 = im.Scale("season1/episode4/images/freeroam2/images/mia1/15.webp", 1920, 1080)
image e4f2-mia_16 = im.Scale("season1/episode4/images/freeroam2/images/mia1/16.webp", 1920, 1080)

image e4f2_mia_blink1:
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/mia1/mia_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Mia
image e4f2-sc_01 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/1.webp", 1920, 1080)
image e4f2-sc_02 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/2.webp", 1920, 1080)
image e4f2-sc_03 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/3.webp", 1920, 1080)
image e4f2-sc_04 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/4.webp", 1920, 1080)
image e4f2-sc_05 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/5.webp", 1920, 1080)
image e4f2-sc_06 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/6.webp", 1920, 1080)
image e4f2-sc_07 = im.Scale("season1/episode4/images/freeroam2/images/scarlett1/7.webp", 1920, 1080)

# Candance
image e4f2-ca_01 = im.Scale("season1/episode4/images/freeroam2/images/candance1/1.webp", 1920, 1080)
image e4f2-ca_02 = im.Scale("season1/episode4/images/freeroam2/images/candance1/2.webp", 1920, 1080)
image e4f2-ca_03 = im.Scale("season1/episode4/images/freeroam2/images/candance1/3.webp", 1920, 1080)
image e4f2-ca_04 = im.Scale("season1/episode4/images/freeroam2/images/candance1/4.webp", 1920, 1080)
image e4f2-ca_05 = im.Scale("season1/episode4/images/freeroam2/images/candance1/5.webp", 1920, 1080)
image e4f2-ca_06 = im.Scale("season1/episode4/images/freeroam2/images/candance1/6.webp", 1920, 1080)
image e4f2-ca_07 = im.Scale("season1/episode4/images/freeroam2/images/candance1/7.webp", 1920, 1080)
image e4f2-ca_08 = im.Scale("season1/episode4/images/freeroam2/images/candance1/8.webp", 1920, 1080)
image e4f2-ca_09 = im.Scale("season1/episode4/images/freeroam2/images/candance1/9.webp", 1920, 1080)
image e4f2-ca_10 = im.Scale("season1/episode4/images/freeroam2/images/candance1/10.webp", 1920, 1080)

# Couch
image e4f2-ch_01 = im.Scale("season1/episode4/images/freeroam2/images/couch1/1.webp", 1920, 1080)
image e4f2-ch_02 = im.Scale("season1/episode4/images/freeroam2/images/couch1/2.webp", 1920, 1080)
image e4f2-ch_03 = im.Scale("season1/episode4/images/freeroam2/images/couch1/3.webp", 1920, 1080)
image e4f2-ch_04 = im.Scale("season1/episode4/images/freeroam2/images/couch1/4.webp", 1920, 1080)
image e4f2-ch_05 = im.Scale("season1/episode4/images/freeroam2/images/couch1/5.webp", 1920, 1080)
image e4f2-ch_06 = im.Scale("season1/episode4/images/freeroam2/images/couch1/6.webp", 1920, 1080)
image e4f2-ch_07 = im.Scale("season1/episode4/images/freeroam2/images/couch1/7.webp", 1920, 1080)
image e4f2-ch_08 = im.Scale("season1/episode4/images/freeroam2/images/couch1/8.webp", 1920, 1080)
image e4f2-ch_09 = im.Scale("season1/episode4/images/freeroam2/images/couch1/9.webp", 1920, 1080)
image e4f2-ch_10 = im.Scale("season1/episode4/images/freeroam2/images/couch1/10.webp", 1920, 1080)
image e4f2-ch_11 = im.Scale("season1/episode4/images/freeroam2/images/couch1/11.webp", 1920, 1080)
image e4f2-ch_12 = im.Scale("season1/episode4/images/freeroam2/images/couch1/12.webp", 1920, 1080)
image e4f2-ch_13 = im.Scale("season1/episode4/images/freeroam2/images/couch1/13.webp", 1920, 1080)
image e4f2-ch_14 = im.Scale("season1/episode4/images/freeroam2/images/couch1/14.webp", 1920, 1080)
image e4f2-ch_15 = im.Scale("season1/episode4/images/freeroam2/images/couch1/15.webp", 1920, 1080)
image e4f2-ch_16 = im.Scale("season1/episode4/images/freeroam2/images/couch1/16.webp", 1920, 1080)
image e4f2-ch_17 = im.Scale("season1/episode4/images/freeroam2/images/couch1/17.webp", 1920, 1080)
image e4f2-ch_18 = im.Scale("season1/episode4/images/freeroam2/images/couch1/18.webp", 1920, 1080)
image e4f2-ch_19 = im.Scale("season1/episode4/images/freeroam2/images/couch1/19.webp", 1920, 1080)
image e4f2-ch_20 = im.Scale("season1/episode4/images/freeroam2/images/couch1/20.webp", 1920, 1080)
image e4f2-ch_21 = im.Scale("season1/episode4/images/freeroam2/images/couch1/21.webp", 1920, 1080)
image e4f2-ch_22 = im.Scale("season1/episode4/images/freeroam2/images/couch1/22.webp", 1920, 1080)
image e4f2-ch_23 = im.Scale("season1/episode4/images/freeroam2/images/couch1/23.webp", 1920, 1080)
image e4f2-ch_24 = im.Scale("season1/episode4/images/freeroam2/images/couch1/24.webp", 1920, 1080)
image e4f2-ch_25 = im.Scale("season1/episode4/images/freeroam2/images/couch1/25.webp", 1920, 1080)
image e4f2-ch_26 = im.Scale("season1/episode4/images/freeroam2/images/couch1/26.webp", 1920, 1080)
image e4f2-ch_27 = im.Scale("season1/episode4/images/freeroam2/images/couch1/27.webp", 1920, 1080)
image e4f2-ch_28 = im.Scale("season1/episode4/images/freeroam2/images/couch1/28.webp", 1920, 1080)
image e4f2-ch_29 = im.Scale("season1/episode4/images/freeroam2/images/couch1/29.webp", 1920, 1080)
image e4f2-ch_30 = im.Scale("season1/episode4/images/freeroam2/images/couch1/30.webp", 1920, 1080)
image e4f2-ch_31 = im.Scale("season1/episode4/images/freeroam2/images/couch1/31.webp", 1920, 1080)
image e4f2-ch_32 = im.Scale("season1/episode4/images/freeroam2/images/couch1/32.webp", 1920, 1080)
image e4f2-ch_33 = im.Scale("season1/episode4/images/freeroam2/images/couch1/33.webp", 1920, 1080)
image e4f2-ch_34 = im.Scale("season1/episode4/images/freeroam2/images/couch1/34.webp", 1920, 1080)
image e4f2-ch_35 = im.Scale("season1/episode4/images/freeroam2/images/couch1/35.webp", 1920, 1080)
image e4f2-ch_36 = im.Scale("season1/episode4/images/freeroam2/images/couch1/36.webp", 1920, 1080)
image e4f2-ch_37 = im.Scale("season1/episode4/images/freeroam2/images/couch1/37.webp", 1920, 1080)
image e4f2-ch_38 = im.Scale("season1/episode4/images/freeroam2/images/couch1/38.webp", 1920, 1080)
image e4f2-ch_39 = im.Scale("season1/episode4/images/freeroam2/images/couch1/39.webp", 1920, 1080)
image e4f2-ch_40 = im.Scale("season1/episode4/images/freeroam2/images/couch1/40.webp", 1920, 1080)
image e4f2-ch_41 = im.Scale("season1/episode4/images/freeroam2/images/couch1/41.webp", 1920, 1080)
image e4f2-ch_42 = im.Scale("season1/episode4/images/freeroam2/images/couch1/42.webp", 1920, 1080)
image e4f2-ch_43 = im.Scale("season1/episode4/images/freeroam2/images/couch1/43.webp", 1920, 1080)
image e4f2-ch_44 = im.Scale("season1/episode4/images/freeroam2/images/couch1/44.webp", 1920, 1080)
image e4f2-ch_45 = im.Scale("season1/episode4/images/freeroam2/images/couch1/45.webp", 1920, 1080)
image e4f2-ch_46 = im.Scale("season1/episode4/images/freeroam2/images/couch1/46.webp", 1920, 1080)

image e4f2-couch_anim:
    im.Scale("season1/episode4/images/freeroam2/images/couch1/24.webp", 1920, 1080) with dissolve
    0.7
    im.Scale("season1/episode4/images/freeroam2/images/couch1/27.webp", 1920, 1080) with dissolve
    0.7
    repeat

image e4f2_unknown_blink1:
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/freeroam2/images/couch1/unknown_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Stripper1
image e4f2-str1_01 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/1.webp", 1920, 1080)
image e4f2-str1_02 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/2.webp", 1920, 1080)
image e4f2-str1_03 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/3.webp", 1920, 1080)
image e4f2-str1_04 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/4.webp", 1920, 1080)
image e4f2-str1_05 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/5.webp", 1920, 1080)
image e4f2-str1_06 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/6.webp", 1920, 1080)
image e4f2-str1_07 = im.Scale("season1/episode4/images/freeroam2/images/stripper1/7.webp", 1920, 1080)

# Stripper2
image e4f2-str2_01 = im.Scale("season1/episode4/images/freeroam2/images/stripper2/1.webp", 1920, 1080)
image e4f2-str2_02 = im.Scale("season1/episode4/images/freeroam2/images/stripper2/2.webp", 1920, 1080)
image e4f2-str2_03 = im.Scale("season1/episode4/images/freeroam2/images/stripper2/3.webp", 1920, 1080)
image e4f2-str2_04 = im.Scale("season1/episode4/images/freeroam2/images/stripper2/4.webp", 1920, 1080)
image e4f2-str2_05 = im.Scale("season1/episode4/images/freeroam2/images/stripper2/5.webp", 1920, 1080)

# Stripper3
image e4f2-str3_01 = im.Scale("season1/episode4/images/freeroam2/images/stripper3/1.webp", 1920, 1080)
image e4f2-str3_02 = im.Scale("season1/episode4/images/freeroam2/images/stripper3/2.webp", 1920, 1080)
image e4f2-str3_03 = im.Scale("season1/episode4/images/freeroam2/images/stripper3/3.webp", 1920, 1080)

# Stripper4
image e4f2-str4_01 = im.Scale("season1/episode4/images/freeroam2/images/stripper4/1.webp", 1920, 1080)
image e4f2-str4_02 = im.Scale("season1/episode4/images/freeroam2/images/stripper4/2.webp", 1920, 1080)
image e4f2-str4_03 = im.Scale("season1/episode4/images/freeroam2/images/stripper4/3.webp", 1920, 1080)
image e4f2-str4_04 = im.Scale("season1/episode4/images/freeroam2/images/stripper4/4.webp", 1920, 1080)
