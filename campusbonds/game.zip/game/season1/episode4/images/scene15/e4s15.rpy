
# Scene 15 images ##############################################################

image e4s15-01 = im.Scale("season1/episode4/images/scene15/1.webp", 1920, 1080)
image e4s15-02 = im.Scale("season1/episode4/images/scene15/2.webp", 1920, 1080)
image e4s15-03 = im.Scale("season1/episode4/images/scene15/3.webp", 1920, 1080)
image e4s15-04 = im.Scale("season1/episode4/images/scene15/4.webp", 1920, 1080)
image e4s15-05 = im.Scale("season1/episode4/images/scene15/5.webp", 1920, 1080)
image e4s15-06 = im.Scale("season1/episode4/images/scene15/6.webp", 1920, 1080)
image e4s15-07 = im.Scale("season1/episode4/images/scene15/7.webp", 1920, 1080)
image e4s15-08 = im.Scale("season1/episode4/images/scene15/8.webp", 1920, 1080)
image e4s15-09 = im.Scale("season1/episode4/images/scene15/9.webp", 1920, 1080)
image e4s15-10 = im.Scale("season1/episode4/images/scene15/10.webp", 1920, 1080)
image e4s15-11 = im.Scale("season1/episode4/images/scene15/11.webp", 1920, 1080)
image e4s15-12 = im.Scale("season1/episode4/images/scene15/12.webp", 1920, 1080)
image e4s15-13 = im.Scale("season1/episode4/images/scene15/13.webp", 1920, 1080)
image e4s15-14 = im.Scale("season1/episode4/images/scene15/14.webp", 1920, 1080)
image e4s15-15 = im.Scale("season1/episode4/images/scene15/15.webp", 1920, 1080)
image e4s15-16 = im.Scale("season1/episode4/images/scene15/16.webp", 1920, 1080)
image e4s15-17 = im.Scale("season1/episode4/images/scene15/17.webp", 1920, 1080)
image e4s15-18 = im.Scale("season1/episode4/images/scene15/18.webp", 1920, 1080)
image e4s15-19 = im.Scale("season1/episode4/images/scene15/19.webp", 1920, 1080)
image e4s15-20 = im.Scale("season1/episode4/images/scene15/20.webp", 1920, 1080)
image e4s15-21 = im.Scale("season1/episode4/images/scene15/21.webp", 1920, 1080)
image e4s15-22 = im.Scale("season1/episode4/images/scene15/22.webp", 1920, 1080)
image e4s15-23 = im.Scale("season1/episode4/images/scene15/23.webp", 1920, 1080)
image e4s15-24 = im.Scale("season1/episode4/images/scene15/24.webp", 1920, 1080)
image e4s15-25 = im.Scale("season1/episode4/images/scene15/25.webp", 1920, 1080)
image e4s15-26 = im.Scale("season1/episode4/images/scene15/26.webp", 1920, 1080)
image e4s15-27 = im.Scale("season1/episode4/images/scene15/27.webp", 1920, 1080)
image e4s15-28 = im.Scale("season1/episode4/images/scene15/28.webp", 1920, 1080)
image e4s15-29 = im.Scale("season1/episode4/images/scene15/29.webp", 1920, 1080)
image e4s15-30 = im.Scale("season1/episode4/images/scene15/30.webp", 1920, 1080)
image e4s15-31 = im.Scale("season1/episode4/images/scene15/31.webp", 1920, 1080)
image e4s15-32 = im.Scale("season1/episode4/images/scene15/32.webp", 1920, 1080)
image e4s15-33 = im.Scale("season1/episode4/images/scene15/33.webp", 1920, 1080)
image e4s15-34 = im.Scale("season1/episode4/images/scene15/34.webp", 1920, 1080)
image e4s15-35 = im.Scale("season1/episode4/images/scene15/35.webp", 1920, 1080)
image e4s15-36 = im.Scale("season1/episode4/images/scene15/36.webp", 1920, 1080)
image e4s15-37 = im.Scale("season1/episode4/images/scene15/37.webp", 1920, 1080)
image e4s15-38 = im.Scale("season1/episode4/images/scene15/38.webp", 1920, 1080)
image e4s15-39 = im.Scale("season1/episode4/images/scene15/39.webp", 1920, 1080)
image e4s15-40 = im.Scale("season1/episode4/images/scene15/40.webp", 1920, 1080)
image e4s15-41 = im.Scale("season1/episode4/images/scene15/41.webp", 1920, 1080)
image e4s15-42 = im.Scale("season1/episode4/images/scene15/42.webp", 1920, 1080)
image e4s15-43 = im.Scale("season1/episode4/images/scene15/43.webp", 1920, 1080)
image e4s15-44 = im.Scale("season1/episode4/images/scene15/44.webp", 1920, 1080)
image e4s15-45 = im.Scale("season1/episode4/images/scene15/45.webp", 1920, 1080)
image e4s15-46 = im.Scale("season1/episode4/images/scene15/46.webp", 1920, 1080)
image e4s15-47 = im.Scale("season1/episode4/images/scene15/47.webp", 1920, 1080)
image e4s15-48 = im.Scale("season1/episode4/images/scene15/48.webp", 1920, 1080)
image e4s15-49 = im.Scale("season1/episode4/images/scene15/49.webp", 1920, 1080)
image e4s15-50 = im.Scale("season1/episode4/images/scene15/50.webp", 1920, 1080)
image e4s15-51 = im.Scale("season1/episode4/images/scene15/51.webp", 1920, 1080)
image e4s15-52 = im.Scale("season1/episode4/images/scene15/52.webp", 1920, 1080)
image e4s15-53 = im.Scale("season1/episode4/images/scene15/53.webp", 1920, 1080)
image e4s15-54 = im.Scale("season1/episode4/images/scene15/54.webp", 1920, 1080)
image e4s15-55 = im.Scale("season1/episode4/images/scene15/55.webp", 1920, 1080)
image e4s15-56 = im.Scale("season1/episode4/images/scene15/56.webp", 1920, 1080)
image e4s15-57 = im.Scale("season1/episode4/images/scene15/57.webp", 1920, 1080)
image e4s15-58 = im.Scale("season1/episode4/images/scene15/58.webp", 1920, 1080)
image e4s15-59 = im.Scale("season1/episode4/images/scene15/59.webp", 1920, 1080)
image e4s15-60 = im.Scale("season1/episode4/images/scene15/60.webp", 1920, 1080)
image e4s15-61 = im.Scale("season1/episode4/images/scene15/61.webp", 1920, 1080)
image e4s15-62 = im.Scale("season1/episode4/images/scene15/62.webp", 1920, 1080)
image e4s15-63 = im.Scale("season1/episode4/images/scene15/63.webp", 1920, 1080)
image e4s15-64 = im.Scale("season1/episode4/images/scene15/64.webp", 1920, 1080)
image e4s15-65 = im.Scale("season1/episode4/images/scene15/65.webp", 1920, 1080)
image e4s15-66 = im.Scale("season1/episode4/images/scene15/66.webp", 1920, 1080)
image e4s15-67 = im.Scale("season1/episode4/images/scene15/67.webp", 1920, 1080)
image e4s15-68 = im.Scale("season1/episode4/images/scene15/68.webp", 1920, 1080)
image e4s15-69 = im.Scale("season1/episode4/images/scene15/69.webp", 1920, 1080)
image e4s15-70 = im.Scale("season1/episode4/images/scene15/70.webp", 1920, 1080)
image e4s15-71 = im.Scale("season1/episode4/images/scene15/71.webp", 1920, 1080)
image e4s15-72 = im.Scale("season1/episode4/images/scene15/72.webp", 1920, 1080)
image e4s15-73 = im.Scale("season1/episode4/images/scene15/73.webp", 1920, 1080)
image e4s15-74 = im.Scale("season1/episode4/images/scene15/74.webp", 1920, 1080)
image e4s15-75 = im.Scale("season1/episode4/images/scene15/75.webp", 1920, 1080)
image e4s15-76 = im.Scale("season1/episode4/images/scene15/76.webp", 1920, 1080)
image e4s15-77 = im.Scale("season1/episode4/images/scene15/77.webp", 1920, 1080)
image e4s15-78 = im.Scale("season1/episode4/images/scene15/78.webp", 1920, 1080)
image e4s15-79 = im.Scale("season1/episode4/images/scene15/79.webp", 1920, 1080)
image e4s15-80 = im.Scale("season1/episode4/images/scene15/80.webp", 1920, 1080)
image e4s15-81 = im.Scale("season1/episode4/images/scene15/81.webp", 1920, 1080)
image e4s15-82 = im.Scale("season1/episode4/images/scene15/82.webp", 1920, 1080)
image e4s15-83 = im.Scale("season1/episode4/images/scene15/83.webp", 1920, 1080)
image e4s15-84 = im.Scale("season1/episode4/images/scene15/84.webp", 1920, 1080)
image e4s15-85 = im.Scale("season1/episode4/images/scene15/85.webp", 1920, 1080)
image e4s15-86 = im.Scale("season1/episode4/images/scene15/86.webp", 1920, 1080)
image e4s15-87 = im.Scale("season1/episode4/images/scene15/87.webp", 1920, 1080)
image e4s15-88 = im.Scale("season1/episode4/images/scene15/88.webp", 1920, 1080)
image e4s15-89 = im.Scale("season1/episode4/images/scene15/89.webp", 1920, 1080)
image e4s15-90 = im.Scale("season1/episode4/images/scene15/90.webp", 1920, 1080)
image e4s15-91 = im.Scale("season1/episode4/images/scene15/91.webp", 1920, 1080)
image e4s15-92 = im.Scale("season1/episode4/images/scene15/92.webp", 1920, 1080)
image e4s15-93 = im.Scale("season1/episode4/images/scene15/93.webp", 1920, 1080)
image e4s15-94 = im.Scale("season1/episode4/images/scene15/94.webp", 1920, 1080)
image e4s15-95 = im.Scale("season1/episode4/images/scene15/95.webp", 1920, 1080)
image e4s15-96 = im.Scale("season1/episode4/images/scene15/96.webp", 1920, 1080)
image e4s15-97 = im.Scale("season1/episode4/images/scene15/97.webp", 1920, 1080)
image e4s15-98 = im.Scale("season1/episode4/images/scene15/98.webp", 1920, 1080)
image e4s15-99 = im.Scale("season1/episode4/images/scene15/99.webp", 1920, 1080)
image e4s15-100 = im.Scale("season1/episode4/images/scene15/100.webp", 1920, 1080)
image e4s15-101 = im.Scale("season1/episode4/images/scene15/101.webp", 1920, 1080)
image e4s15-102 = im.Scale("season1/episode4/images/scene15/102.webp", 1920, 1080)
image e4s15-103 = im.Scale("season1/episode4/images/scene15/103.webp", 1920, 1080)
image e4s15-104 = im.Scale("season1/episode4/images/scene15/104.webp", 1920, 1080)
image e4s15-105 = im.Scale("season1/episode4/images/scene15/105.webp", 1920, 1080)
image e4s15-106 = im.Scale("season1/episode4/images/scene15/106.webp", 1920, 1080)
image e4s15-107 = im.Scale("season1/episode4/images/scene15/107.webp", 1920, 1080)
image e4s15-108 = im.Scale("season1/episode4/images/scene15/108.webp", 1920, 1080)
image e4s15-109 = im.Scale("season1/episode4/images/scene15/109.webp", 1920, 1080)

# Animations #
# Static
image e4s15_cleo_blink1:
    im.Scale("season1/episode4/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e4s15_cleo_blink2:
    im.Scale("season1/episode4/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene15/cleo_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
