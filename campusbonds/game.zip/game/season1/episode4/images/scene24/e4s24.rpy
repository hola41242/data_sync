
# Scene 24 images ##############################################################

image e4s24-01 = im.Scale("season1/episode4/images/scene24/1.webp", 1920, 1080)
image e4s24-02 = im.Scale("season1/episode4/images/scene24/2.webp", 1920, 1080)
image e4s24-03 = im.Scale("season1/episode4/images/scene24/3.webp", 1920, 1080)
image e4s24-04 = im.Scale("season1/episode4/images/scene24/4.webp", 1920, 1080)
image e4s24-05 = im.Scale("season1/episode4/images/scene24/5.webp", 1920, 1080)
image e4s24-06 = im.Scale("season1/episode4/images/scene24/6.webp", 1920, 1080)
image e4s24-07 = im.Scale("season1/episode4/images/scene24/7.webp", 1920, 1080)
image e4s24-08 = im.Scale("season1/episode4/images/scene24/8.webp", 1920, 1080)
image e4s24-09 = im.Scale("season1/episode4/images/scene24/9.webp", 1920, 1080)
image e4s24-10 = im.Scale("season1/episode4/images/scene24/10.webp", 1920, 1080)
image e4s24-11 = im.Scale("season1/episode4/images/scene24/11.webp", 1920, 1080)
image e4s24-12 = im.Scale("season1/episode4/images/scene24/12.webp", 1920, 1080)
image e4s24-13 = im.Scale("season1/episode4/images/scene24/13.webp", 1920, 1080)
image e4s24-14 = im.Scale("season1/episode4/images/scene24/14.webp", 1920, 1080)
image e4s24-15 = im.Scale("season1/episode4/images/scene24/15.webp", 1920, 1080)
image e4s24-16 = im.Scale("season1/episode4/images/scene24/16.webp", 1920, 1080)
image e4s24-17 = im.Scale("season1/episode4/images/scene24/17.webp", 1920, 1080)
image e4s24-18 = im.Scale("season1/episode4/images/scene24/18.webp", 1920, 1080)
image e4s24-19 = im.Scale("season1/episode4/images/scene24/19.webp", 1920, 1080)
image e4s24-20 = im.Scale("season1/episode4/images/scene24/20.webp", 1920, 1080)
image e4s24-21 = im.Scale("season1/episode4/images/scene24/21.webp", 1920, 1080)
image e4s24-22 = im.Scale("season1/episode4/images/scene24/22.webp", 1920, 1080)
image e4s24-23 = im.Scale("season1/episode4/images/scene24/23.webp", 1920, 1080)
image e4s24-24 = im.Scale("season1/episode4/images/scene24/24.webp", 1920, 1080)
image e4s24-25 = im.Scale("season1/episode4/images/scene24/25.webp", 1920, 1080)
image e4s24-26 = im.Scale("season1/episode4/images/scene24/26.webp", 1920, 1080)
image e4s24-27 = im.Scale("season1/episode4/images/scene24/27.webp", 1920, 1080)
image e4s24-28 = im.Scale("season1/episode4/images/scene24/28.webp", 1920, 1080)
image e4s24-29 = im.Scale("season1/episode4/images/scene24/29.webp", 1920, 1080)
image e4s24-30 = im.Scale("season1/episode4/images/scene24/30.webp", 1920, 1080)
image e4s24-31 = im.Scale("season1/episode4/images/scene24/31.webp", 1920, 1080)
image e4s24-32 = im.Scale("season1/episode4/images/scene24/32.webp", 1920, 1080)
image e4s24-33 = im.Scale("season1/episode4/images/scene24/33.webp", 1920, 1080)
image e4s24-34 = im.Scale("season1/episode4/images/scene24/34.webp", 1920, 1080)
image e4s24-35 = im.Scale("season1/episode4/images/scene24/35.webp", 1920, 1080)
image e4s24-36 = im.Scale("season1/episode4/images/scene24/36.webp", 1920, 1080)
image e4s24-37 = im.Scale("season1/episode4/images/scene24/37.webp", 1920, 1080)
image e4s24-38 = im.Scale("season1/episode4/images/scene24/38.webp", 1920, 1080)
image e4s24-39 = im.Scale("season1/episode4/images/scene24/39.webp", 1920, 1080)
image e4s24-40 = im.Scale("season1/episode4/images/scene24/40.webp", 1920, 1080)
image e4s24-41 = im.Scale("season1/episode4/images/scene24/41.webp", 1920, 1080)
image e4s24-42 = im.Scale("season1/episode4/images/scene24/42.webp", 1920, 1080)
image e4s24-43 = im.Scale("season1/episode4/images/scene24/43.webp", 1920, 1080)
image e4s24-44 = im.Scale("season1/episode4/images/scene24/44.webp", 1920, 1080)
image e4s24-45 = im.Scale("season1/episode4/images/scene24/45.webp", 1920, 1080)
image e4s24-46 = im.Scale("season1/episode4/images/scene24/46.webp", 1920, 1080)
image e4s24-47 = im.Scale("season1/episode4/images/scene24/47.webp", 1920, 1080)
image e4s24-48 = im.Scale("season1/episode4/images/scene24/48.webp", 1920, 1080)
image e4s24-49 = im.Scale("season1/episode4/images/scene24/49.webp", 1920, 1080)
image e4s24-50 = im.Scale("season1/episode4/images/scene24/50.webp", 1920, 1080)
image e4s24-51 = im.Scale("season1/episode4/images/scene24/51.webp", 1920, 1080)
image e4s24-52 = im.Scale("season1/episode4/images/scene24/52.webp", 1920, 1080)
image e4s24-53 = im.Scale("season1/episode4/images/scene24/53.webp", 1920, 1080)
image e4s24-54 = im.Scale("season1/episode4/images/scene24/54.webp", 1920, 1080)
image e4s24-55 = im.Scale("season1/episode4/images/scene24/55.webp", 1920, 1080)
image e4s24-56 = im.Scale("season1/episode4/images/scene24/56.webp", 1920, 1080)
image e4s24-57 = im.Scale("season1/episode4/images/scene24/57.webp", 1920, 1080)
image e4s24-58 = im.Scale("season1/episode4/images/scene24/58.webp", 1920, 1080)
image e4s24-59 = im.Scale("season1/episode4/images/scene24/59.webp", 1920, 1080)
image e4s24-60 = im.Scale("season1/episode4/images/scene24/60.webp", 1920, 1080)
image e4s24-61 = im.Scale("season1/episode4/images/scene24/61.webp", 1920, 1080)
image e4s24-62 = im.Scale("season1/episode4/images/scene24/62.webp", 1920, 1080)
image e4s24-63 = im.Scale("season1/episode4/images/scene24/63.webp", 1920, 1080)
image e4s24-64 = im.Scale("season1/episode4/images/scene24/64.webp", 1920, 1080)
image e4s24-65 = im.Scale("season1/episode4/images/scene24/65.webp", 1920, 1080)
image e4s24-66 = im.Scale("season1/episode4/images/scene24/66.webp", 1920, 1080)
image e4s24-67 = im.Scale("season1/episode4/images/scene24/67.webp", 1920, 1080)
image e4s24-68 = im.Scale("season1/episode4/images/scene24/68.webp", 1920, 1080)
image e4s24-69 = im.Scale("season1/episode4/images/scene24/69.webp", 1920, 1080)
image e4s24-70 = im.Scale("season1/episode4/images/scene24/70.webp", 1920, 1080)
image e4s24-71 = im.Scale("season1/episode4/images/scene24/71.webp", 1920, 1080)
image e4s24-72 = im.Scale("season1/episode4/images/scene24/72.webp", 1920, 1080)
image e4s24-73 = im.Scale("season1/episode4/images/scene24/73.webp", 1920, 1080)
image e4s24-74 = im.Scale("season1/episode4/images/scene24/74.webp", 1920, 1080)
image e4s24-75 = im.Scale("season1/episode4/images/scene24/75.webp", 1920, 1080)

image e4s24_scarlett_blink1:
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene24/scarlett_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
