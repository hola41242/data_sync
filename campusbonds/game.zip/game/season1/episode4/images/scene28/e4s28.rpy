
# Scene 28 images ##############################################################

image e4s28-01 = im.Scale("season1/episode4/images/scene28/1.webp", 1920, 1080)
image e4s28-02 = im.Scale("season1/episode4/images/scene28/2.webp", 1920, 1080)
image e4s28-03 = im.Scale("season1/episode4/images/scene28/3.webp", 1920, 1080)
image e4s28-04 = im.Scale("season1/episode4/images/scene28/4.webp", 1920, 1080)
image e4s28-05 = im.Scale("season1/episode4/images/scene28/5.webp", 1920, 1080)
image e4s28-06 = im.Scale("season1/episode4/images/scene28/6.webp", 1920, 1080)
image e4s28-07 = im.Scale("season1/episode4/images/scene28/7.webp", 1920, 1080)
image e4s28-08 = im.Scale("season1/episode4/images/scene28/8.webp", 1920, 1080)
image e4s28-09 = im.Scale("season1/episode4/images/scene28/9.webp", 1920, 1080)
image e4s28-10 = im.Scale("season1/episode4/images/scene28/10.webp", 1920, 1080)
image e4s28-11 = im.Scale("season1/episode4/images/scene28/11.webp", 1920, 1080)
image e4s28-12 = im.Scale("season1/episode4/images/scene28/12.webp", 1920, 1080)
image e4s28-13 = im.Scale("season1/episode4/images/scene28/13.webp", 1920, 1080)
image e4s28-14 = im.Scale("season1/episode4/images/scene28/14.webp", 1920, 1080)
image e4s28-15 = im.Scale("season1/episode4/images/scene28/15.webp", 1920, 1080)
image e4s28-16 = im.Scale("season1/episode4/images/scene28/16.webp", 1920, 1080)
image e4s28-17 = im.Scale("season1/episode4/images/scene28/17.webp", 1920, 1080)
image e4s28-18 = im.Scale("season1/episode4/images/scene28/18.webp", 1920, 1080)
image e4s28-19 = im.Scale("season1/episode4/images/scene28/19.webp", 1920, 1080)
image e4s28-20 = im.Scale("season1/episode4/images/scene28/20.webp", 1920, 1080)
image e4s28-21 = im.Scale("season1/episode4/images/scene28/21.webp", 1920, 1080)
image e4s28-22 = im.Scale("season1/episode4/images/scene28/22.webp", 1920, 1080)
image e4s28-23 = im.Scale("season1/episode4/images/scene28/23.webp", 1920, 1080)
image e4s28-24 = im.Scale("season1/episode4/images/scene28/24.webp", 1920, 1080)
image e4s28-25 = im.Scale("season1/episode4/images/scene28/25.webp", 1920, 1080)
image e4s28-26 = im.Scale("season1/episode4/images/scene28/26.webp", 1920, 1080)
image e4s28-27 = im.Scale("season1/episode4/images/scene28/27.webp", 1920, 1080)
image e4s28-28 = im.Scale("season1/episode4/images/scene28/28.webp", 1920, 1080)
image e4s28-29 = im.Scale("season1/episode4/images/scene28/29.webp", 1920, 1080)
image e4s28-30 = im.Scale("season1/episode4/images/scene28/30.webp", 1920, 1080)
image e4s28-31 = im.Scale("season1/episode4/images/scene28/31.webp", 1920, 1080)
image e4s28-32 = im.Scale("season1/episode4/images/scene28/32.webp", 1920, 1080)
image e4s28-33 = im.Scale("season1/episode4/images/scene28/33.webp", 1920, 1080)
image e4s28-34 = im.Scale("season1/episode4/images/scene28/34.webp", 1920, 1080)
image e4s28-35 = im.Scale("season1/episode4/images/scene28/35.webp", 1920, 1080)
image e4s28-36 = im.Scale("season1/episode4/images/scene28/36.webp", 1920, 1080)
image e4s28-37 = im.Scale("season1/episode4/images/scene28/37.webp", 1920, 1080)
image e4s28-38 = im.Scale("season1/episode4/images/scene28/38.webp", 1920, 1080)
image e4s28-39 = im.Scale("season1/episode4/images/scene28/39.webp", 1920, 1080)
image e4s28-40 = im.Scale("season1/episode4/images/scene28/40.webp", 1920, 1080)
image e4s28-41 = im.Scale("season1/episode4/images/scene28/41.webp", 1920, 1080)
image e4s28-42 = im.Scale("season1/episode4/images/scene28/42.webp", 1920, 1080)
image e4s28-43 = im.Scale("season1/episode4/images/scene28/43.webp", 1920, 1080)
image e4s28-44 = im.Scale("season1/episode4/images/scene28/44.webp", 1920, 1080)
image e4s28-45 = im.Scale("season1/episode4/images/scene28/45.webp", 1920, 1080)
image e4s28-46 = im.Scale("season1/episode4/images/scene28/46.webp", 1920, 1080)
image e4s28-47 = im.Scale("season1/episode4/images/scene28/47.webp", 1920, 1080)
image e4s28-48 = im.Scale("season1/episode4/images/scene28/48.webp", 1920, 1080)
image e4s28-49 = im.Scale("season1/episode4/images/scene28/49.webp", 1920, 1080)

image e4s28_francesca_blink1:
    im.Scale("season1/episode4/images/scene28/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene28/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
