
# Scene 33 images ##############################################################

image e4s33-01 = im.Scale("season1/episode4/images/scene33/1.webp", 1920, 1080)
image e4s33-02 = im.Scale("season1/episode4/images/scene33/2.webp", 1920, 1080)
image e4s33-03 = im.Scale("season1/episode4/images/scene33/3.webp", 1920, 1080)
image e4s33-04 = im.Scale("season1/episode4/images/scene33/4.webp", 1920, 1080)
image e4s33-05 = im.Scale("season1/episode4/images/scene33/5.webp", 1920, 1080)
image e4s33-06 = im.Scale("season1/episode4/images/scene33/6.webp", 1920, 1080)
image e4s33-07 = im.Scale("season1/episode4/images/scene33/7.webp", 1920, 1080)
image e4s33-08 = im.Scale("season1/episode4/images/scene33/8.webp", 1920, 1080)
image e4s33-09 = im.Scale("season1/episode4/images/scene33/9.webp", 1920, 1080)
image e4s33-10 = im.Scale("season1/episode4/images/scene33/10.webp", 1920, 1080)
image e4s33-11 = im.Scale("season1/episode4/images/scene33/11.webp", 1920, 1080)
image e4s33-12 = im.Scale("season1/episode4/images/scene33/12.webp", 1920, 1080)
image e4s33-13 = im.Scale("season1/episode4/images/scene33/13.webp", 1920, 1080)
image e4s33-14 = im.Scale("season1/episode4/images/scene33/14.webp", 1920, 1080)
image e4s33-15 = im.Scale("season1/episode4/images/scene33/15.webp", 1920, 1080)
image e4s33-16 = im.Scale("season1/episode4/images/scene33/16.webp", 1920, 1080)
image e4s33-17 = im.Scale("season1/episode4/images/scene33/17.webp", 1920, 1080)
image e4s33-18 = im.Scale("season1/episode4/images/scene33/18.webp", 1920, 1080)
image e4s33-19 = im.Scale("season1/episode4/images/scene33/19.webp", 1920, 1080)
image e4s33-20 = im.Scale("season1/episode4/images/scene33/20.webp", 1920, 1080)
image e4s33-21 = im.Scale("season1/episode4/images/scene33/21.webp", 1920, 1080)
image e4s33-22 = im.Scale("season1/episode4/images/scene33/22.webp", 1920, 1080)
image e4s33-23 = im.Scale("season1/episode4/images/scene33/23.webp", 1920, 1080)
image e4s33-24 = im.Scale("season1/episode4/images/scene33/24.webp", 1920, 1080)
image e4s33-25 = im.Scale("season1/episode4/images/scene33/25.webp", 1920, 1080)
image e4s33-26 = im.Scale("season1/episode4/images/scene33/26.webp", 1920, 1080)
image e4s33-27 = im.Scale("season1/episode4/images/scene33/27.webp", 1920, 1080)
image e4s33-28 = im.Scale("season1/episode4/images/scene33/28.webp", 1920, 1080)
image e4s33-29 = im.Scale("season1/episode4/images/scene33/29.webp", 1920, 1080)
image e4s33-30 = im.Scale("season1/episode4/images/scene33/30.webp", 1920, 1080)
image e4s33-31 = im.Scale("season1/episode4/images/scene33/31.webp", 1920, 1080)
image e4s33-32 = im.Scale("season1/episode4/images/scene33/32.webp", 1920, 1080)
image e4s33-33 = im.Scale("season1/episode4/images/scene33/33.webp", 1920, 1080)
image e4s33-34 = im.Scale("season1/episode4/images/scene33/34.webp", 1920, 1080)
image e4s33-35 = im.Scale("season1/episode4/images/scene33/35.webp", 1920, 1080)
image e4s33-36 = im.Scale("season1/episode4/images/scene33/36.webp", 1920, 1080)
image e4s33-37 = im.Scale("season1/episode4/images/scene33/37.webp", 1920, 1080)
image e4s33-38 = im.Scale("season1/episode4/images/scene33/38.webp", 1920, 1080)
image e4s33-39 = im.Scale("season1/episode4/images/scene33/39.webp", 1920, 1080)
image e4s33-40 = im.Scale("season1/episode4/images/scene33/40.webp", 1920, 1080)
image e4s33-41 = im.Scale("season1/episode4/images/scene33/41.webp", 1920, 1080)
image e4s33-42 = im.Scale("season1/episode4/images/scene33/42.webp", 1920, 1080)
image e4s33-43 = im.Scale("season1/episode4/images/scene33/43.webp", 1920, 1080)
image e4s33-44 = im.Scale("season1/episode4/images/scene33/44.webp", 1920, 1080)
image e4s33-45 = im.Scale("season1/episode4/images/scene33/45.webp", 1920, 1080)
image e4s33-46 = im.Scale("season1/episode4/images/scene33/46.webp", 1920, 1080)
image e4s33-47 = im.Scale("season1/episode4/images/scene33/47.webp", 1920, 1080)
image e4s33-48 = im.Scale("season1/episode4/images/scene33/48.webp", 1920, 1080)
image e4s33-49 = im.Scale("season1/episode4/images/scene33/49.webp", 1920, 1080)
image e4s33-50 = im.Scale("season1/episode4/images/scene33/50.webp", 1920, 1080)
image e4s33-51 = im.Scale("season1/episode4/images/scene33/51.webp", 1920, 1080)
image e4s33-52 = im.Scale("season1/episode4/images/scene33/52.webp", 1920, 1080)
image e4s33-53 = im.Scale("season1/episode4/images/scene33/53.webp", 1920, 1080)
image e4s33-54 = im.Scale("season1/episode4/images/scene33/54.webp", 1920, 1080)
image e4s33-55 = im.Scale("season1/episode4/images/scene33/55.webp", 1920, 1080)

image e4s33_sadie_blink1:
    im.Scale("season1/episode4/images/scene33/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene33/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
