
# Scene 22 images ##############################################################

image e4s22-01 = im.Scale("season1/episode4/images/scene22/1.webp", 1920, 1080)
image e4s22-02 = im.Scale("season1/episode4/images/scene22/2.webp", 1920, 1080)
image e4s22-03 = im.Scale("season1/episode4/images/scene22/3.webp", 1920, 1080)
image e4s22-04 = im.Scale("season1/episode4/images/scene22/4.webp", 1920, 1080)
image e4s22-05 = im.Scale("season1/episode4/images/scene22/5.webp", 1920, 1080)
image e4s22-06 = im.Scale("season1/episode4/images/scene22/6.webp", 1920, 1080)
image e4s22-07 = im.Scale("season1/episode4/images/scene22/7.webp", 1920, 1080)
image e4s22-08 = im.Scale("season1/episode4/images/scene22/8.webp", 1920, 1080)
image e4s22-09 = im.Scale("season1/episode4/images/scene22/9.webp", 1920, 1080)
image e4s22-10 = im.Scale("season1/episode4/images/scene22/10.webp", 1920, 1080)
image e4s22-11 = im.Scale("season1/episode4/images/scene22/11.webp", 1920, 1080)
image e4s22-12 = im.Scale("season1/episode4/images/scene22/12.webp", 1920, 1080)
image e4s22-13 = im.Scale("season1/episode4/images/scene22/13.webp", 1920, 1080)
image e4s22-14 = im.Scale("season1/episode4/images/scene22/14.webp", 1920, 1080)
image e4s22-15 = im.Scale("season1/episode4/images/scene22/15.webp", 1920, 1080)
image e4s22-16 = im.Scale("season1/episode4/images/scene22/16.webp", 1920, 1080)
image e4s22-17 = im.Scale("season1/episode4/images/scene22/17.webp", 1920, 1080)
image e4s22-18 = im.Scale("season1/episode4/images/scene22/18.webp", 1920, 1080)
image e4s22-19 = im.Scale("season1/episode4/images/scene22/19.webp", 1920, 1080)
image e4s22-20 = im.Scale("season1/episode4/images/scene22/20.webp", 1920, 1080)
image e4s22-21 = im.Scale("season1/episode4/images/scene22/21.webp", 1920, 1080)
image e4s22-22 = im.Scale("season1/episode4/images/scene22/22.webp", 1920, 1080)
image e4s22-23 = im.Scale("season1/episode4/images/scene22/23.webp", 1920, 1080)
image e4s22-24 = im.Scale("season1/episode4/images/scene22/24.webp", 1920, 1080)
image e4s22-25 = im.Scale("season1/episode4/images/scene22/25.webp", 1920, 1080)
image e4s22-26 = im.Scale("season1/episode4/images/scene22/26.webp", 1920, 1080)
image e4s22-27 = im.Scale("season1/episode4/images/scene22/27.webp", 1920, 1080)
image e4s22-28 = im.Scale("season1/episode4/images/scene22/28.webp", 1920, 1080)
image e4s22-29 = im.Scale("season1/episode4/images/scene22/29.webp", 1920, 1080)
image e4s22-30 = im.Scale("season1/episode4/images/scene22/30.webp", 1920, 1080)
image e4s22-31 = im.Scale("season1/episode4/images/scene22/31.webp", 1920, 1080)
image e4s22-32 = im.Scale("season1/episode4/images/scene22/32.webp", 1920, 1080)
image e4s22-33 = im.Scale("season1/episode4/images/scene22/33.webp", 1920, 1080)
image e4s22-34 = im.Scale("season1/episode4/images/scene22/34.webp", 1920, 1080)
image e4s22-35 = im.Scale("season1/episode4/images/scene22/35.webp", 1920, 1080)
image e4s22-36 = im.Scale("season1/episode4/images/scene22/36.webp", 1920, 1080)
image e4s22-37 = im.Scale("season1/episode4/images/scene22/37.webp", 1920, 1080)
image e4s22-38 = im.Scale("season1/episode4/images/scene22/38.webp", 1920, 1080)
image e4s22-39 = im.Scale("season1/episode4/images/scene22/39.webp", 1920, 1080)
image e4s22-40 = im.Scale("season1/episode4/images/scene22/40.webp", 1920, 1080)
image e4s22-41 = im.Scale("season1/episode4/images/scene22/41.webp", 1920, 1080)
image e4s22-42 = im.Scale("season1/episode4/images/scene22/42.webp", 1920, 1080)
image e4s22-43 = im.Scale("season1/episode4/images/scene22/43.webp", 1920, 1080)

image e4s22_tiffany_blink1:
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e4s22_tiffany_blink2:
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene22/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
