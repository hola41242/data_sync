
# Scene 18 images ##############################################################

image e4s18-01 = im.Scale("season1/episode4/images/scene18/1.webp", 1920, 1080)
image e4s18-02 = im.Scale("season1/episode4/images/scene18/2.webp", 1920, 1080)
image e4s18-03 = im.Scale("season1/episode4/images/scene18/3.webp", 1920, 1080)
image e4s18-04 = im.Scale("season1/episode4/images/scene18/4.webp", 1920, 1080)
image e4s18-05 = im.Scale("season1/episode4/images/scene18/5.webp", 1920, 1080)
image e4s18-06 = im.Scale("season1/episode4/images/scene18/6.webp", 1920, 1080)
image e4s18-07 = im.Scale("season1/episode4/images/scene18/7.webp", 1920, 1080)
image e4s18-08 = im.Scale("season1/episode4/images/scene18/8.webp", 1920, 1080)
image e4s18-09 = im.Scale("season1/episode4/images/scene18/9.webp", 1920, 1080)
image e4s18-10 = im.Scale("season1/episode4/images/scene18/10.webp", 1920, 1080)
image e4s18-11 = im.Scale("season1/episode4/images/scene18/11.webp", 1920, 1080)
image e4s18-12 = im.Scale("season1/episode4/images/scene18/12.webp", 1920, 1080)
image e4s18-13 = im.Scale("season1/episode4/images/scene18/13.webp", 1920, 1080)
image e4s18-14 = im.Scale("season1/episode4/images/scene18/14.webp", 1920, 1080)
image e4s18-15 = im.Scale("season1/episode4/images/scene18/15.webp", 1920, 1080)
image e4s18-16 = im.Scale("season1/episode4/images/scene18/16.webp", 1920, 1080)
image e4s18-17 = im.Scale("season1/episode4/images/scene18/17.webp", 1920, 1080)
image e4s18-18 = im.Scale("season1/episode4/images/scene18/18.webp", 1920, 1080)
image e4s18-19 = im.Scale("season1/episode4/images/scene18/19.webp", 1920, 1080)
image e4s18-20 = im.Scale("season1/episode4/images/scene18/20.webp", 1920, 1080)
image e4s18-21 = im.Scale("season1/episode4/images/scene18/21.webp", 1920, 1080)
image e4s18-22 = im.Scale("season1/episode4/images/scene18/22.webp", 1920, 1080)
image e4s18-23 = im.Scale("season1/episode4/images/scene18/23.webp", 1920, 1080)
image e4s18-24 = im.Scale("season1/episode4/images/scene18/24.webp", 1920, 1080)
image e4s18-25 = im.Scale("season1/episode4/images/scene18/25.webp", 1920, 1080)
image e4s18-26 = im.Scale("season1/episode4/images/scene18/26.webp", 1920, 1080)
image e4s18-27 = im.Scale("season1/episode4/images/scene18/27.webp", 1920, 1080)
image e4s18-28 = im.Scale("season1/episode4/images/scene18/28.webp", 1920, 1080)
image e4s18-29 = im.Scale("season1/episode4/images/scene18/29.webp", 1920, 1080)
image e4s18-30 = im.Scale("season1/episode4/images/scene18/30.webp", 1920, 1080)
image e4s18-31 = im.Scale("season1/episode4/images/scene18/31.webp", 1920, 1080)
image e4s18-32 = im.Scale("season1/episode4/images/scene18/32.webp", 1920, 1080)
image e4s18-33 = im.Scale("season1/episode4/images/scene18/33.webp", 1920, 1080)
image e4s18-34 = im.Scale("season1/episode4/images/scene18/34.webp", 1920, 1080)
image e4s18-35 = im.Scale("season1/episode4/images/scene18/35.webp", 1920, 1080)
image e4s18-36 = im.Scale("season1/episode4/images/scene18/36.webp", 1920, 1080)
image e4s18-37 = im.Scale("season1/episode4/images/scene18/37.webp", 1920, 1080)
image e4s18-38 = im.Scale("season1/episode4/images/scene18/38.webp", 1920, 1080)
image e4s18-39 = im.Scale("season1/episode4/images/scene18/39.webp", 1920, 1080)
image e4s18-40 = im.Scale("season1/episode4/images/scene18/40.webp", 1920, 1080)
image e4s18-41 = im.Scale("season1/episode4/images/scene18/41.webp", 1920, 1080)
image e4s18-42 = im.Scale("season1/episode4/images/scene18/42.webp", 1920, 1080)
image e4s18-43 = im.Scale("season1/episode4/images/scene18/43.webp", 1920, 1080)
image e4s18-44 = im.Scale("season1/episode4/images/scene18/44.webp", 1920, 1080)
image e4s18-45 = im.Scale("season1/episode4/images/scene18/45.webp", 1920, 1080)
image e4s18-46 = im.Scale("season1/episode4/images/scene18/46.webp", 1920, 1080)
image e4s18-47 = im.Scale("season1/episode4/images/scene18/47.webp", 1920, 1080)
image e4s18-48 = im.Scale("season1/episode4/images/scene18/48.webp", 1920, 1080)
image e4s18-49 = im.Scale("season1/episode4/images/scene18/49.webp", 1920, 1080)
image e4s18-50 = im.Scale("season1/episode4/images/scene18/50.webp", 1920, 1080)
image e4s18-51 = im.Scale("season1/episode4/images/scene18/51.webp", 1920, 1080)
image e4s18-52 = im.Scale("season1/episode4/images/scene18/52.webp", 1920, 1080)
image e4s18-53 = im.Scale("season1/episode4/images/scene18/53.webp", 1920, 1080)
image e4s18-54 = im.Scale("season1/episode4/images/scene18/54.webp", 1920, 1080)
image e4s18-55 = im.Scale("season1/episode4/images/scene18/55.webp", 1920, 1080)
image e4s18-56 = im.Scale("season1/episode4/images/scene18/56.webp", 1920, 1080)
image e4s18-57 = im.Scale("season1/episode4/images/scene18/57.webp", 1920, 1080)
image e4s18-58 = im.Scale("season1/episode4/images/scene18/58.webp", 1920, 1080)
image e4s18-59 = im.Scale("season1/episode4/images/scene18/59.webp", 1920, 1080)
image e4s18-60 = im.Scale("season1/episode4/images/scene18/60.webp", 1920, 1080)
image e4s18-61 = im.Scale("season1/episode4/images/scene18/61.webp", 1920, 1080)
image e4s18-62 = im.Scale("season1/episode4/images/scene18/62.webp", 1920, 1080)
image e4s18-63 = im.Scale("season1/episode4/images/scene18/63.webp", 1920, 1080)
image e4s18-64 = im.Scale("season1/episode4/images/scene18/64.webp", 1920, 1080)
image e4s18-65 = im.Scale("season1/episode4/images/scene18/65.webp", 1920, 1080)
image e4s18-66 = im.Scale("season1/episode4/images/scene18/66.webp", 1920, 1080)
image e4s18-67 = im.Scale("season1/episode4/images/scene18/67.webp", 1920, 1080)
image e4s18-68 = im.Scale("season1/episode4/images/scene18/68.webp", 1920, 1080)

image e4s18_jon_blink1:
    im.Scale("season1/episode4/images/scene18/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene18/jon_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
