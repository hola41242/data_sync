
# Scene 5 images ###############################################################

image e4s5-01 = im.Scale("season1/episode4/images/scene5/1.webp", 1920, 1080)
image e4s5-02 = im.Scale("season1/episode4/images/scene5/2.webp", 1920, 1080)
image e4s5-03 = im.Scale("season1/episode4/images/scene5/3.webp", 1920, 1080)
image e4s5-04 = im.Scale("season1/episode4/images/scene5/4.webp", 1920, 1080)
image e4s5-05 = im.Scale("season1/episode4/images/scene5/5.webp", 1920, 1080)
image e4s5-06 = im.Scale("season1/episode4/images/scene5/6.webp", 1920, 1080)
image e4s5-07 = im.Scale("season1/episode4/images/scene5/7.webp", 1920, 1080)
image e4s5-08 = im.Scale("season1/episode4/images/scene5/8.webp", 1920, 1080)
image e4s5-09 = im.Scale("season1/episode4/images/scene5/9.webp", 1920, 1080)
image e4s5-10 = im.Scale("season1/episode4/images/scene5/10.webp", 1920, 1080)
image e4s5-11 = im.Scale("season1/episode4/images/scene5/11.webp", 1920, 1080)
image e4s5-12 = im.Scale("season1/episode4/images/scene5/12.webp", 1920, 1080)
image e4s5-13 = im.Scale("season1/episode4/images/scene5/13.webp", 1920, 1080)
image e4s5-14 = im.Scale("season1/episode4/images/scene5/14.webp", 1920, 1080)
image e4s5-15 = im.Scale("season1/episode4/images/scene5/15.webp", 1920, 1080)
image e4s5-16 = im.Scale("season1/episode4/images/scene5/16.webp", 1920, 1080)

# Bridget ######################################################################
image e4s5-br_01 = im.Scale("season1/episode4/images/scene5/bridget1/1.webp", 1920, 1080)
image e4s5-br_02 = im.Scale("season1/episode4/images/scene5/bridget1/2.webp", 1920, 1080)
image e4s5-br_03 = im.Scale("season1/episode4/images/scene5/bridget1/3.webp", 1920, 1080)
image e4s5-br_04 = im.Scale("season1/episode4/images/scene5/bridget1/4.webp", 1920, 1080)
image e4s5-br_05 = im.Scale("season1/episode4/images/scene5/bridget1/5.webp", 1920, 1080)
image e4s5-br_06 = im.Scale("season1/episode4/images/scene5/bridget1/6.webp", 1920, 1080)
image e4s5-br_07 = im.Scale("season1/episode4/images/scene5/bridget1/7.webp", 1920, 1080)
image e4s5-br_08 = im.Scale("season1/episode4/images/scene5/bridget1/8.webp", 1920, 1080)
image e4s5-br_09 = im.Scale("season1/episode4/images/scene5/bridget1/9.webp", 1920, 1080)
image e4s5-br_10 = im.Scale("season1/episode4/images/scene5/bridget1/10.webp", 1920, 1080)

image e4s5_bridget_blink1:
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/bridget1/bridget_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Sadie ########################################################################
image e4s5-sd_01 = im.Scale("season1/episode4/images/scene5/sadie1/1.webp", 1920, 1080)
image e4s5-sd_02 = im.Scale("season1/episode4/images/scene5/sadie1/2.webp", 1920, 1080)
image e4s5-sd_03 = im.Scale("season1/episode4/images/scene5/sadie1/3.webp", 1920, 1080)
image e4s5-sd_04 = im.Scale("season1/episode4/images/scene5/sadie1/4.webp", 1920, 1080)
image e4s5-sd_05 = im.Scale("season1/episode4/images/scene5/sadie1/5.webp", 1920, 1080)
image e4s5-sd_06 = im.Scale("season1/episode4/images/scene5/sadie1/6.webp", 1920, 1080)
image e4s5-sd_07 = im.Scale("season1/episode4/images/scene5/sadie1/7.webp", 1920, 1080)
image e4s5-sd_08 = im.Scale("season1/episode4/images/scene5/sadie1/8.webp", 1920, 1080)
image e4s5-sd_09 = im.Scale("season1/episode4/images/scene5/sadie1/9.webp", 1920, 1080)
image e4s5-sd_10 = im.Scale("season1/episode4/images/scene5/sadie1/10.webp", 1920, 1080)
image e4s5-sd_11 = im.Scale("season1/episode4/images/scene5/sadie1/11.webp", 1920, 1080)
image e4s5-sd_12 = im.Scale("season1/episode4/images/scene5/sadie1/12.webp", 1920, 1080)
image e4s5-sd_13 = im.Scale("season1/episode4/images/scene5/sadie1/13.webp", 1920, 1080)
image e4s5-sd_14 = im.Scale("season1/episode4/images/scene5/sadie1/14.webp", 1920, 1080)
image e4s5-sd_15 = im.Scale("season1/episode4/images/scene5/sadie1/15.webp", 1920, 1080)
image e4s5-sd_16 = im.Scale("season1/episode4/images/scene5/sadie1/16.webp", 1920, 1080)
image e4s5-sd_17 = im.Scale("season1/episode4/images/scene5/sadie1/17.webp", 1920, 1080)
image e4s5-sd_18 = im.Scale("season1/episode4/images/scene5/sadie1/18.webp", 1920, 1080)
image e4s5-sd_19 = im.Scale("season1/episode4/images/scene5/sadie1/19.webp", 1920, 1080)
image e4s5-sd_20 = im.Scale("season1/episode4/images/scene5/sadie1/20.webp", 1920, 1080)
image e4s5-sd_21 = im.Scale("season1/episode4/images/scene5/sadie1/21.webp", 1920, 1080)
image e4s5-sd_22 = im.Scale("season1/episode4/images/scene5/sadie1/22.webp", 1920, 1080)
image e4s5-sd_23 = im.Scale("season1/episode4/images/scene5/sadie1/23.webp", 1920, 1080)
image e4s5-sd_24 = im.Scale("season1/episode4/images/scene5/sadie1/24.webp", 1920, 1080)
image e4s5-sd_25 = im.Scale("season1/episode4/images/scene5/sadie1/25.webp", 1920, 1080)
image e4s5-sd_26 = im.Scale("season1/episode4/images/scene5/sadie1/26.webp", 1920, 1080)
image e4s5-sd_27 = im.Scale("season1/episode4/images/scene5/sadie1/27.webp", 1920, 1080)
image e4s5-sd_28 = im.Scale("season1/episode4/images/scene5/sadie1/28.webp", 1920, 1080)
image e4s5-sd_29 = im.Scale("season1/episode4/images/scene5/sadie1/29.webp", 1920, 1080)
image e4s5-sd_30 = im.Scale("season1/episode4/images/scene5/sadie1/30.webp", 1920, 1080)
image e4s5-sd_31 = im.Scale("season1/episode4/images/scene5/sadie1/31.webp", 1920, 1080)
image e4s5-sd_32 = im.Scale("season1/episode4/images/scene5/sadie1/32.webp", 1920, 1080)
image e4s5-sd_33 = im.Scale("season1/episode4/images/scene5/sadie1/33.webp", 1920, 1080)
image e4s5-sd_34 = im.Scale("season1/episode4/images/scene5/sadie1/34.webp", 1920, 1080)
image e4s5-sd_35 = im.Scale("season1/episode4/images/scene5/sadie1/35.webp", 1920, 1080)
image e4s5-sd_36 = im.Scale("season1/episode4/images/scene5/sadie1/36.webp", 1920, 1080)
image e4s5-sd_37 = im.Scale("season1/episode4/images/scene5/sadie1/37.webp", 1920, 1080)
image e4s5-sd_38 = im.Scale("season1/episode4/images/scene5/sadie1/38.webp", 1920, 1080)
image e4s5-sd_39 = im.Scale("season1/episode4/images/scene5/sadie1/39.webp", 1920, 1080)
image e4s5-sd_40 = im.Scale("season1/episode4/images/scene5/sadie1/40.webp", 1920, 1080)

image e4s5_sadie_blink1:
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/sadie1/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Tracy ########################################################################
image e4s5-tr_01 = im.Scale("season1/episode4/images/scene5/tracy1/1.webp", 1920, 1080)
image e4s5-tr_02 = im.Scale("season1/episode4/images/scene5/tracy1/2.webp", 1920, 1080)
image e4s5-tr_03 = im.Scale("season1/episode4/images/scene5/tracy1/3.webp", 1920, 1080)
image e4s5-tr_04 = im.Scale("season1/episode4/images/scene5/tracy1/4.webp", 1920, 1080)
image e4s5-tr_05 = im.Scale("season1/episode4/images/scene5/tracy1/5.webp", 1920, 1080)
image e4s5-tr_06 = im.Scale("season1/episode4/images/scene5/tracy1/6.webp", 1920, 1080)
image e4s5-tr_07 = im.Scale("season1/episode4/images/scene5/tracy1/7.webp", 1920, 1080)
image e4s5-tr_08 = im.Scale("season1/episode4/images/scene5/tracy1/8.webp", 1920, 1080)
image e4s5-tr_09 = im.Scale("season1/episode4/images/scene5/tracy1/9.webp", 1920, 1080)
image e4s5-tr_10 = im.Scale("season1/episode4/images/scene5/tracy1/10.webp", 1920, 1080)
image e4s5-tr_11 = im.Scale("season1/episode4/images/scene5/tracy1/11.webp", 1920, 1080)
image e4s5-tr_12 = im.Scale("season1/episode4/images/scene5/tracy1/12.webp", 1920, 1080)
image e4s5-tr_13 = im.Scale("season1/episode4/images/scene5/tracy1/13.webp", 1920, 1080)
image e4s5-tr_14 = im.Scale("season1/episode4/images/scene5/tracy1/14.webp", 1920, 1080)
image e4s5-tr_15 = im.Scale("season1/episode4/images/scene5/tracy1/15.webp", 1920, 1080)
image e4s5-tr_16 = im.Scale("season1/episode4/images/scene5/tracy1/16.webp", 1920, 1080)
image e4s5-tr_17 = im.Scale("season1/episode4/images/scene5/tracy1/17.webp", 1920, 1080)
image e4s5-tr_18 = im.Scale("season1/episode4/images/scene5/tracy1/18.webp", 1920, 1080)
image e4s5-tr_19 = im.Scale("season1/episode4/images/scene5/tracy1/19.webp", 1920, 1080)
image e4s5-tr_20 = im.Scale("season1/episode4/images/scene5/tracy1/20.webp", 1920, 1080)

image e4s5_tracy_blink1:
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/tracy1/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Lyla ########################################################################
image e4s5-ly_01 = im.Scale("season1/episode4/images/scene5/lyla1/1.webp", 1920, 1080)
image e4s5-ly_02 = im.Scale("season1/episode4/images/scene5/lyla1/2.webp", 1920, 1080)
image e4s5-ly_03 = im.Scale("season1/episode4/images/scene5/lyla1/3.webp", 1920, 1080)
image e4s5-ly_04 = im.Scale("season1/episode4/images/scene5/lyla1/4.webp", 1920, 1080)
image e4s5-ly_05 = im.Scale("season1/episode4/images/scene5/lyla1/5.webp", 1920, 1080)
image e4s5-ly_06 = im.Scale("season1/episode4/images/scene5/lyla1/6.webp", 1920, 1080)
image e4s5-ly_07 = im.Scale("season1/episode4/images/scene5/lyla1/7.webp", 1920, 1080)
image e4s5-ly_08 = im.Scale("season1/episode4/images/scene5/lyla1/8.webp", 1920, 1080)
image e4s5-ly_09 = im.Scale("season1/episode4/images/scene5/lyla1/9.webp", 1920, 1080)
image e4s5-ly_10 = im.Scale("season1/episode4/images/scene5/lyla1/10.webp", 1920, 1080)
image e4s5-ly_11 = im.Scale("season1/episode4/images/scene5/lyla1/11.webp", 1920, 1080)
image e4s5-ly_12 = im.Scale("season1/episode4/images/scene5/lyla1/12.webp", 1920, 1080)
image e4s5-ly_13 = im.Scale("season1/episode4/images/scene5/lyla1/13.webp", 1920, 1080)
image e4s5-ly_14 = im.Scale("season1/episode4/images/scene5/lyla1/14.webp", 1920, 1080)
image e4s5-ly_15 = im.Scale("season1/episode4/images/scene5/lyla1/15.webp", 1920, 1080)

image e4s5_lyla_blink1:
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene5/lyla1/lyla_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
