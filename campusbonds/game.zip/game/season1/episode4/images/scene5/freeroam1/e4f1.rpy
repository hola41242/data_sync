
# Freeroam 1 Images ############################################################
# Jon
image e4f1-01 = im.Scale("season1/episode4/images/scene5/freeroam1/1.webp", 1920, 1080)

# Tracy Sadie
image e4f1-02 = im.Scale("season1/episode4/images/scene5/freeroam1/2.webp", 1920, 1080)
image e4f1-02_1 = im.Scale("season1/episode4/images/scene5/freeroam1/2.1.webp", 1920, 1080)

# Bridget
image e4f1-03 = im.Scale("season1/episode4/images/scene5/freeroam1/3.webp", 1920, 1080)

# Corner
image e4f1-04 = im.Scale("season1/episode4/images/scene5/freeroam1/4.webp", 1920, 1080)

# Lyla
image e4f1-05 = im.Scale("season1/episode4/images/scene5/freeroam1/5.webp", 1920, 1080)

# Bridget
image e4f1-br_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/1.webp", 1920, 1080)
image e4f1-br_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/2.webp", 1920, 1080)
image e4f1-br_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/3.webp", 1920, 1080)
image e4f1-br_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/4.webp", 1920, 1080)
image e4f1-br_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/5.webp", 1920, 1080)
image e4f1-br_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/bridget1/6.webp", 1920, 1080)

# Jon
image e4f1-jon_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/1.webp", 1920, 1080)
image e4f1-jon_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/2.webp", 1920, 1080)
image e4f1-jon_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/3.webp", 1920, 1080)
image e4f1-jon_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/4.webp", 1920, 1080)
image e4f1-jon_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/5.webp", 1920, 1080)
image e4f1-jon_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/jon1/6.webp", 1920, 1080)

# Lyla 1
image e4f1-ly1_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/1.webp", 1920, 1080)
image e4f1-ly1_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/2.webp", 1920, 1080)
image e4f1-ly1_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/3.webp", 1920, 1080)
image e4f1-ly1_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/4.webp", 1920, 1080)
image e4f1-ly1_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/5.webp", 1920, 1080)
image e4f1-ly1_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/6.webp", 1920, 1080)
image e4f1-ly1_07 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/7.webp", 1920, 1080)
image e4f1-ly1_08 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/8.webp", 1920, 1080)
image e4f1-ly1_09 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/9.webp", 1920, 1080)
image e4f1-ly1_10 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla1/10.webp", 1920, 1080)

# Lyla 2
image e4f1-ly2_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/1.webp", 1920, 1080)
image e4f1-ly2_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/2.webp", 1920, 1080)
image e4f1-ly2_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/3.webp", 1920, 1080)
image e4f1-ly2_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/4.webp", 1920, 1080)
image e4f1-ly2_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/5.webp", 1920, 1080)
image e4f1-ly2_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/6.webp", 1920, 1080)
image e4f1-ly2_07 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/7.webp", 1920, 1080)
image e4f1-ly2_08 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/8.webp", 1920, 1080)
image e4f1-ly2_09 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/9.webp", 1920, 1080)
image e4f1-ly2_10 = im.Scale("season1/episode4/images/scene5/freeroam1/images/lyla2/10.webp", 1920, 1080)

# Sadie
image e4f1-sd_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/1.webp", 1920, 1080)
image e4f1-sd_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/2.webp", 1920, 1080)
image e4f1-sd_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/3.webp", 1920, 1080)
image e4f1-sd_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/4.webp", 1920, 1080)
image e4f1-sd_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/5.webp", 1920, 1080)
image e4f1-sd_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/6.webp", 1920, 1080)
image e4f1-sd_07 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/7.webp", 1920, 1080)
image e4f1-sd_08 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/8.webp", 1920, 1080)
image e4f1-sd_09 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/9.webp", 1920, 1080)
image e4f1-sd_10 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/10.webp", 1920, 1080)
image e4f1-sd_11 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/11.webp", 1920, 1080)
image e4f1-sd_12 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/12.webp", 1920, 1080)
image e4f1-sd_13 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/13.webp", 1920, 1080)
image e4f1-sd_14 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/14.webp", 1920, 1080)
image e4f1-sd_15 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/15.webp", 1920, 1080)
image e4f1-sd_16 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/16.webp", 1920, 1080)
image e4f1-sd_17 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/17.webp", 1920, 1080)
image e4f1-sd_18 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/18.webp", 1920, 1080)
image e4f1-sd_19 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/19.webp", 1920, 1080)
image e4f1-sd_20 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/20.webp", 1920, 1080)
image e4f1-sd_21 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/21.webp", 1920, 1080)
image e4f1-sd_22 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/22.webp", 1920, 1080)
image e4f1-sd_23 = im.Scale("season1/episode4/images/scene5/freeroam1/images/sadie1/23.webp", 1920, 1080)

# Tracy
image e4f1-tr_01 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/1.webp", 1920, 1080)
image e4f1-tr_02 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/2.webp", 1920, 1080)
image e4f1-tr_03 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/3.webp", 1920, 1080)
image e4f1-tr_04 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/4.webp", 1920, 1080)
image e4f1-tr_05 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/5.webp", 1920, 1080)
image e4f1-tr_06 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/6.webp", 1920, 1080)
image e4f1-tr_07 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/7.webp", 1920, 1080)
image e4f1-tr_08 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/8.webp", 1920, 1080)
image e4f1-tr_09 = im.Scale("season1/episode4/images/scene5/freeroam1/images/tracy1/9.webp", 1920, 1080)
