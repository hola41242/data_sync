
# Scene 25 images ##############################################################

image e4s25-01 = im.Scale("season1/episode4/images/scene25/1.webp", 1920, 1080)
image e4s25-02 = im.Scale("season1/episode4/images/scene25/2.webp", 1920, 1080)
image e4s25-03 = im.Scale("season1/episode4/images/scene25/3.webp", 1920, 1080)
image e4s25-04 = im.Scale("season1/episode4/images/scene25/4.webp", 1920, 1080)
image e4s25-05 = im.Scale("season1/episode4/images/scene25/5.webp", 1920, 1080)
image e4s25-06 = im.Scale("season1/episode4/images/scene25/6.webp", 1920, 1080)
image e4s25-07 = im.Scale("season1/episode4/images/scene25/7.webp", 1920, 1080)
image e4s25-08 = im.Scale("season1/episode4/images/scene25/8.webp", 1920, 1080)
image e4s25-09 = im.Scale("season1/episode4/images/scene25/9.webp", 1920, 1080)
image e4s25-10 = im.Scale("season1/episode4/images/scene25/10.webp", 1920, 1080)
image e4s25-11 = im.Scale("season1/episode4/images/scene25/11.webp", 1920, 1080)
image e4s25-12 = im.Scale("season1/episode4/images/scene25/12.webp", 1920, 1080)
image e4s25-13 = im.Scale("season1/episode4/images/scene25/13.webp", 1920, 1080)
image e4s25-14 = im.Scale("season1/episode4/images/scene25/14.webp", 1920, 1080)
image e4s25-15 = im.Scale("season1/episode4/images/scene25/15.webp", 1920, 1080)
image e4s25-16 = im.Scale("season1/episode4/images/scene25/16.webp", 1920, 1080)
image e4s25-17 = im.Scale("season1/episode4/images/scene25/17.webp", 1920, 1080)
image e4s25-18 = im.Scale("season1/episode4/images/scene25/18.webp", 1920, 1080)
image e4s25-19 = im.Scale("season1/episode4/images/scene25/19.webp", 1920, 1080)
image e4s25-20 = im.Scale("season1/episode4/images/scene25/20.webp", 1920, 1080)
image e4s25-21 = im.Scale("season1/episode4/images/scene25/21.webp", 1920, 1080)
image e4s25-22 = im.Scale("season1/episode4/images/scene25/22.webp", 1920, 1080)
image e4s25-23 = im.Scale("season1/episode4/images/scene25/23.webp", 1920, 1080)
image e4s25-24 = im.Scale("season1/episode4/images/scene25/24.webp", 1920, 1080)
image e4s25-25 = im.Scale("season1/episode4/images/scene25/25.webp", 1920, 1080)
image e4s25-26 = im.Scale("season1/episode4/images/scene25/26.webp", 1920, 1080)
image e4s25-27 = im.Scale("season1/episode4/images/scene25/27.webp", 1920, 1080)
image e4s25-28 = im.Scale("season1/episode4/images/scene25/28.webp", 1920, 1080)

image e4s25_sadie_blink1:
    im.Scale("season1/episode4/images/scene25/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e4s25_sadie_blink2:
    im.Scale("season1/episode4/images/scene25/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/sadie_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e4s25_tracy_blink1:
    im.Scale("season1/episode4/images/scene25/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e4s25_tracy_blink2:
    im.Scale("season1/episode4/images/scene25/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene25/tracy_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
