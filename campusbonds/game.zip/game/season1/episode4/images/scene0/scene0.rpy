
# Scene 0 images ###############################################################

image e4s0-01 = im.Scale("season1/episode4/images/scene0/1.webp", 1920, 1080)
image e4s0-02 = im.Scale("season1/episode4/images/scene0/2.webp", 1920, 1080)
image e4s0-03 = im.Scale("season1/episode4/images/scene0/3.webp", 1920, 1080)
image e4s0-04 = im.Scale("season1/episode4/images/scene0/4.webp", 1920, 1080)
image e4s0-05 = im.Scale("season1/episode4/images/scene0/5.webp", 1920, 1080)
image e4s0-06 = im.Scale("season1/episode4/images/scene0/6.webp", 1920, 1080)
image e4s0-07 = im.Scale("season1/episode4/images/scene0/7.webp", 1920, 1080)
image e4s0-08 = im.Scale("season1/episode4/images/scene0/8.webp", 1920, 1080)
image e4s0-09 = im.Scale("season1/episode4/images/scene0/9.webp", 1920, 1080)
image e4s0-10 = im.Scale("season1/episode4/images/scene0/10.webp", 1920, 1080)
image e4s0-11 = im.Scale("season1/episode4/images/scene0/11.webp", 1920, 1080)
image e4s0-12 = im.Scale("season1/episode4/images/scene0/12.webp", 1920, 1080)
image e4s0-13 = im.Scale("season1/episode4/images/scene0/13.webp", 1920, 1080)
