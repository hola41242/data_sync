
# Scene 16 images ##############################################################

image e4s16-01 = im.Scale("season1/episode4/images/scene16/1.webp", 1920, 1080)
image e4s16-02 = im.Scale("season1/episode4/images/scene16/2.webp", 1920, 1080)
image e4s16-03 = im.Scale("season1/episode4/images/scene16/3.webp", 1920, 1080)
image e4s16-04 = im.Scale("season1/episode4/images/scene16/4.webp", 1920, 1080)
image e4s16-05 = im.Scale("season1/episode4/images/scene16/5.webp", 1920, 1080)
image e4s16-06 = im.Scale("season1/episode4/images/scene16/6.webp", 1920, 1080)
image e4s16-07 = im.Scale("season1/episode4/images/scene16/7.webp", 1920, 1080)
image e4s16-08 = im.Scale("season1/episode4/images/scene16/8.webp", 1920, 1080)
image e4s16-09 = im.Scale("season1/episode4/images/scene16/9.webp", 1920, 1080)
image e4s16-10 = im.Scale("season1/episode4/images/scene16/10.webp", 1920, 1080)
image e4s16-11 = im.Scale("season1/episode4/images/scene16/11.webp", 1920, 1080)
image e4s16-12 = im.Scale("season1/episode4/images/scene16/12.webp", 1920, 1080)
image e4s16-13 = im.Scale("season1/episode4/images/scene16/13.webp", 1920, 1080)
image e4s16-14 = im.Scale("season1/episode4/images/scene16/14.webp", 1920, 1080)
image e4s16-15 = im.Scale("season1/episode4/images/scene16/15.webp", 1920, 1080)
image e4s16-16 = im.Scale("season1/episode4/images/scene16/16.webp", 1920, 1080)
image e4s16-17 = im.Scale("season1/episode4/images/scene16/17.webp", 1920, 1080)
image e4s16-18 = im.Scale("season1/episode4/images/scene16/18.webp", 1920, 1080)
image e4s16-19 = im.Scale("season1/episode4/images/scene16/19.webp", 1920, 1080)
image e4s16-20 = im.Scale("season1/episode4/images/scene16/20.webp", 1920, 1080)
image e4s16-21 = im.Scale("season1/episode4/images/scene16/21.webp", 1920, 1080)
image e4s16-22 = im.Scale("season1/episode4/images/scene16/22.webp", 1920, 1080)
image e4s16-23 = im.Scale("season1/episode4/images/scene16/23.webp", 1920, 1080)
image e4s16-24 = im.Scale("season1/episode4/images/scene16/24.webp", 1920, 1080)
image e4s16-25 = im.Scale("season1/episode4/images/scene16/25.webp", 1920, 1080)
image e4s16-26 = im.Scale("season1/episode4/images/scene16/26.webp", 1920, 1080)
image e4s16-27 = im.Scale("season1/episode4/images/scene16/27.webp", 1920, 1080)
image e4s16-28 = im.Scale("season1/episode4/images/scene16/28.webp", 1920, 1080)
image e4s16-29 = im.Scale("season1/episode4/images/scene16/29.webp", 1920, 1080)
image e4s16-30 = im.Scale("season1/episode4/images/scene16/30.webp", 1920, 1080)
image e4s16-31 = im.Scale("season1/episode4/images/scene16/31.webp", 1920, 1080)
image e4s16-32 = im.Scale("season1/episode4/images/scene16/32.webp", 1920, 1080)
image e4s16-33 = im.Scale("season1/episode4/images/scene16/33.webp", 1920, 1080)
image e4s16-34 = im.Scale("season1/episode4/images/scene16/34.webp", 1920, 1080)
image e4s16-35 = im.Scale("season1/episode4/images/scene16/35.webp", 1920, 1080)
image e4s16-36 = im.Scale("season1/episode4/images/scene16/36.webp", 1920, 1080)
image e4s16-37 = im.Scale("season1/episode4/images/scene16/37.webp", 1920, 1080)
image e4s16-38 = im.Scale("season1/episode4/images/scene16/38.webp", 1920, 1080)
image e4s16-39 = im.Scale("season1/episode4/images/scene16/39.webp", 1920, 1080)
image e4s16-40 = im.Scale("season1/episode4/images/scene16/40.webp", 1920, 1080)
image e4s16-41 = im.Scale("season1/episode4/images/scene16/41.webp", 1920, 1080)
image e4s16-42 = im.Scale("season1/episode4/images/scene16/42.webp", 1920, 1080)
image e4s16-43 = im.Scale("season1/episode4/images/scene16/43.webp", 1920, 1080)
image e4s16-44 = im.Scale("season1/episode4/images/scene16/44.webp", 1920, 1080)
image e4s16-45 = im.Scale("season1/episode4/images/scene16/45.webp", 1920, 1080)
image e4s16-46 = im.Scale("season1/episode4/images/scene16/46.webp", 1920, 1080)
image e4s16-47 = im.Scale("season1/episode4/images/scene16/47.webp", 1920, 1080)
image e4s16-48 = im.Scale("season1/episode4/images/scene16/48.webp", 1920, 1080)
image e4s16-49 = im.Scale("season1/episode4/images/scene16/49.webp", 1920, 1080)
image e4s16-50 = im.Scale("season1/episode4/images/scene16/50.webp", 1920, 1080)
image e4s16-51 = im.Scale("season1/episode4/images/scene16/51.webp", 1920, 1080)
image e4s16-52 = im.Scale("season1/episode4/images/scene16/52.webp", 1920, 1080)
image e4s16-53 = im.Scale("season1/episode4/images/scene16/53.webp", 1920, 1080)
image e4s16-54 = im.Scale("season1/episode4/images/scene16/54.webp", 1920, 1080)
image e4s16-55 = im.Scale("season1/episode4/images/scene16/55.webp", 1920, 1080)
image e4s16-56 = im.Scale("season1/episode4/images/scene16/56.webp", 1920, 1080)
image e4s16-57 = im.Scale("season1/episode4/images/scene16/57.webp", 1920, 1080)
image e4s16-58 = im.Scale("season1/episode4/images/scene16/58.webp", 1920, 1080)
image e4s16-59 = im.Scale("season1/episode4/images/scene16/59.webp", 1920, 1080)
image e4s16-60 = im.Scale("season1/episode4/images/scene16/60.webp", 1920, 1080)
image e4s16-61 = im.Scale("season1/episode4/images/scene16/61.webp", 1920, 1080)
image e4s16-62 = im.Scale("season1/episode4/images/scene16/62.webp", 1920, 1080)
image e4s16-63 = im.Scale("season1/episode4/images/scene16/63.webp", 1920, 1080)
image e4s16-64 = im.Scale("season1/episode4/images/scene16/64.webp", 1920, 1080)
image e4s16-65 = im.Scale("season1/episode4/images/scene16/65.webp", 1920, 1080)
image e4s16-66 = im.Scale("season1/episode4/images/scene16/66.webp", 1920, 1080)
image e4s16-67 = im.Scale("season1/episode4/images/scene16/67.webp", 1920, 1080)
image e4s16-68 = im.Scale("season1/episode4/images/scene16/68.webp", 1920, 1080)
image e4s16-69 = im.Scale("season1/episode4/images/scene16/69.webp", 1920, 1080)

# Animations #
# Static
image e4s16_tiffany_blink1:
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e4s16_tiffany_blink2:
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene16/tiffany_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
