
# Scene 7 images ###############################################################

image e4s7-01 = im.Scale("season1/episode4/images/scene7/1.webp", 1920, 1080)
image e4s7-02 = im.Scale("season1/episode4/images/scene7/2.webp", 1920, 1080)
image e4s7-03 = im.Scale("season1/episode4/images/scene7/3.webp", 1920, 1080)
image e4s7-04 = im.Scale("season1/episode4/images/scene7/4.webp", 1920, 1080)
image e4s7-05 = im.Scale("season1/episode4/images/scene7/5.webp", 1920, 1080)
image e4s7-06 = im.Scale("season1/episode4/images/scene7/6.webp", 1920, 1080)
image e4s7-07 = im.Scale("season1/episode4/images/scene7/7.webp", 1920, 1080)
image e4s7-08 = im.Scale("season1/episode4/images/scene7/8.webp", 1920, 1080)
image e4s7-09 = im.Scale("season1/episode4/images/scene7/9.webp", 1920, 1080)
image e4s7-10 = im.Scale("season1/episode4/images/scene7/10.webp", 1920, 1080)

# Animations #
# Static
image e4s7_tiffany_blink1:
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene7/tiffany_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
