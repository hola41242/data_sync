
# Scene 13 images ###############################################################

image e4s13-01 = im.Scale("season1/episode4/images/scene13/1.webp", 1920, 1080)
image e4s13-02 = im.Scale("season1/episode4/images/scene13/2.webp", 1920, 1080)
image e4s13-03 = im.Scale("season1/episode4/images/scene13/3.webp", 1920, 1080)
image e4s13-04 = im.Scale("season1/episode4/images/scene13/4.webp", 1920, 1080)
image e4s13-05 = im.Scale("season1/episode4/images/scene13/5.webp", 1920, 1080)
image e4s13-06 = im.Scale("season1/episode4/images/scene13/6.webp", 1920, 1080)
image e4s13-07 = im.Scale("season1/episode4/images/scene13/7.webp", 1920, 1080)
image e4s13-08 = im.Scale("season1/episode4/images/scene13/8.webp", 1920, 1080)
image e4s13-09 = im.Scale("season1/episode4/images/scene13/9.webp", 1920, 1080)
image e4s13-10 = im.Scale("season1/episode4/images/scene13/10.webp", 1920, 1080)
image e4s13-11 = im.Scale("season1/episode4/images/scene13/11.webp", 1920, 1080)
image e4s13-12 = im.Scale("season1/episode4/images/scene13/12.webp", 1920, 1080)

image e4s13_cleo_blink1:
    im.Scale("season1/episode4/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene13/cleo_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
