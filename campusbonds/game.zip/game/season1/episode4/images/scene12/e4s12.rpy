
# Scene 12 images ##############################################################

image e4s12-01 = im.Scale("season1/episode4/images/scene12/1.webp", 1920, 1080)
image e4s12-02 = im.Scale("season1/episode4/images/scene12/2.webp", 1920, 1080)
image e4s12-03 = im.Scale("season1/episode4/images/scene12/3.webp", 1920, 1080)
image e4s12-04 = im.Scale("season1/episode4/images/scene12/4.webp", 1920, 1080)
image e4s12-05 = im.Scale("season1/episode4/images/scene12/5.webp", 1920, 1080)
image e4s12-06 = im.Scale("season1/episode4/images/scene12/6.webp", 1920, 1080)
image e4s12-07 = im.Scale("season1/episode4/images/scene12/7.webp", 1920, 1080)
image e4s12-08 = im.Scale("season1/episode4/images/scene12/8.webp", 1920, 1080)
image e4s12-09 = im.Scale("season1/episode4/images/scene12/9.webp", 1920, 1080)
image e4s12-10 = im.Scale("season1/episode4/images/scene12/10.webp", 1920, 1080)
image e4s12-11 = im.Scale("season1/episode4/images/scene12/11.webp", 1920, 1080)
image e4s12-12 = im.Scale("season1/episode4/images/scene12/12.webp", 1920, 1080)
image e4s12-13 = im.Scale("season1/episode4/images/scene12/13.webp", 1920, 1080)
image e4s12-14 = im.Scale("season1/episode4/images/scene12/14.webp", 1920, 1080)
image e4s12-15 = im.Scale("season1/episode4/images/scene12/15.webp", 1920, 1080)
image e4s12-16 = im.Scale("season1/episode4/images/scene12/16.webp", 1920, 1080)
image e4s12-17 = im.Scale("season1/episode4/images/scene12/17.webp", 1920, 1080)
image e4s12-18 = im.Scale("season1/episode4/images/scene12/18.webp", 1920, 1080)
image e4s12-19 = im.Scale("season1/episode4/images/scene12/19.webp", 1920, 1080)
image e4s12-20 = im.Scale("season1/episode4/images/scene12/20.webp", 1920, 1080)
image e4s12-21 = im.Scale("season1/episode4/images/scene12/21.webp", 1920, 1080)
image e4s12-22 = im.Scale("season1/episode4/images/scene12/22.webp", 1920, 1080)
image e4s12-23 = im.Scale("season1/episode4/images/scene12/23.webp", 1920, 1080)
image e4s12-24 = im.Scale("season1/episode4/images/scene12/24.webp", 1920, 1080)
image e4s12-25 = im.Scale("season1/episode4/images/scene12/25.webp", 1920, 1080)
image e4s12-26 = im.Scale("season1/episode4/images/scene12/26.webp", 1920, 1080)
image e4s12-27 = im.Scale("season1/episode4/images/scene12/27.webp", 1920, 1080)
image e4s12-28 = im.Scale("season1/episode4/images/scene12/28.webp", 1920, 1080)
image e4s12-29 = im.Scale("season1/episode4/images/scene12/29.webp", 1920, 1080)
image e4s12-30 = im.Scale("season1/episode4/images/scene12/30.webp", 1920, 1080)
image e4s12-31 = im.Scale("season1/episode4/images/scene12/31.webp", 1920, 1080)
image e4s12-32 = im.Scale("season1/episode4/images/scene12/32.webp", 1920, 1080)
image e4s12-33 = im.Scale("season1/episode4/images/scene12/33.webp", 1920, 1080)
image e4s12-34 = im.Scale("season1/episode4/images/scene12/34.webp", 1920, 1080)
image e4s12-35 = im.Scale("season1/episode4/images/scene12/35.webp", 1920, 1080)
image e4s12-36 = im.Scale("season1/episode4/images/scene12/36.webp", 1920, 1080)
image e4s12-37 = im.Scale("season1/episode4/images/scene12/37.webp", 1920, 1080)
image e4s12-38 = im.Scale("season1/episode4/images/scene12/38.webp", 1920, 1080)
image e4s12-39 = im.Scale("season1/episode4/images/scene12/39.webp", 1920, 1080)
image e4s12-40 = im.Scale("season1/episode4/images/scene12/40.webp", 1920, 1080)
image e4s12-41 = im.Scale("season1/episode4/images/scene12/41.webp", 1920, 1080)
image e4s12-42 = im.Scale("season1/episode4/images/scene12/42.webp", 1920, 1080)
image e4s12-43 = im.Scale("season1/episode4/images/scene12/43.webp", 1920, 1080)
image e4s12-44 = im.Scale("season1/episode4/images/scene12/44.webp", 1920, 1080)
image e4s12-45 = im.Scale("season1/episode4/images/scene12/45.webp", 1920, 1080)
image e4s12-46 = im.Scale("season1/episode4/images/scene12/46.webp", 1920, 1080)
image e4s12-47 = im.Scale("season1/episode4/images/scene12/47.webp", 1920, 1080)
image e4s12-48 = im.Scale("season1/episode4/images/scene12/48.webp", 1920, 1080)
image e4s12-49 = im.Scale("season1/episode4/images/scene12/49.webp", 1920, 1080)
image e4s12-50 = im.Scale("season1/episode4/images/scene12/50.webp", 1920, 1080)
image e4s12-51 = im.Scale("season1/episode4/images/scene12/51.webp", 1920, 1080)
image e4s12-52 = im.Scale("season1/episode4/images/scene12/52.webp", 1920, 1080)
image e4s12-53 = im.Scale("season1/episode4/images/scene12/53.webp", 1920, 1080)
image e4s12-54 = im.Scale("season1/episode4/images/scene12/54.webp", 1920, 1080)
image e4s12-55 = im.Scale("season1/episode4/images/scene12/55.webp", 1920, 1080)
image e4s12-56 = im.Scale("season1/episode4/images/scene12/56.webp", 1920, 1080)
image e4s12-57 = im.Scale("season1/episode4/images/scene12/57.webp", 1920, 1080)
image e4s12-58 = im.Scale("season1/episode4/images/scene12/58.webp", 1920, 1080)
image e4s12-59 = im.Scale("season1/episode4/images/scene12/59.webp", 1920, 1080)
image e4s12-60 = im.Scale("season1/episode4/images/scene12/60.webp", 1920, 1080)
image e4s12-61 = im.Scale("season1/episode4/images/scene12/61.webp", 1920, 1080)
image e4s12-62 = im.Scale("season1/episode4/images/scene12/62.webp", 1920, 1080)
image e4s12-63 = im.Scale("season1/episode4/images/scene12/63.webp", 1920, 1080)
image e4s12-64 = im.Scale("season1/episode4/images/scene12/64.webp", 1920, 1080)
image e4s12-65 = im.Scale("season1/episode4/images/scene12/65.webp", 1920, 1080)
image e4s12-66 = im.Scale("season1/episode4/images/scene12/66.webp", 1920, 1080)
image e4s12-67 = im.Scale("season1/episode4/images/scene12/67.webp", 1920, 1080)
image e4s12-68 = im.Scale("season1/episode4/images/scene12/68.webp", 1920, 1080)
image e4s12-69 = im.Scale("season1/episode4/images/scene12/69.webp", 1920, 1080)
image e4s12-70 = im.Scale("season1/episode4/images/scene12/70.webp", 1920, 1080)
image e4s12-71 = im.Scale("season1/episode4/images/scene12/71.webp", 1920, 1080)
image e4s12-72 = im.Scale("season1/episode4/images/scene12/72.webp", 1920, 1080)
image e4s12-73 = im.Scale("season1/episode4/images/scene12/73.webp", 1920, 1080)
image e4s12-74 = im.Scale("season1/episode4/images/scene12/74.webp", 1920, 1080)
image e4s12-75 = im.Scale("season1/episode4/images/scene12/75.webp", 1920, 1080)
image e4s12-76 = im.Scale("season1/episode4/images/scene12/76.webp", 1920, 1080)
image e4s12-77 = im.Scale("season1/episode4/images/scene12/77.webp", 1920, 1080)
image e4s12-78 = im.Scale("season1/episode4/images/scene12/78.webp", 1920, 1080)
image e4s12-79 = im.Scale("season1/episode4/images/scene12/79.webp", 1920, 1080)
image e4s12-80 = im.Scale("season1/episode4/images/scene12/80.webp", 1920, 1080)

# Animations #
# Static
image e4s12_tracy_blink1:
    im.Scale("season1/episode4/images/scene12/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene12/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
