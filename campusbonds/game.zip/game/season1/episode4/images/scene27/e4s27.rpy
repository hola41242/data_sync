
# Scene 27 images ##############################################################

# Uncensored
# Images
image e4s27-01 = im.Scale("season1/episode4/images/scene27/1.webp", 1920, 1080)
image e4s27-02 = im.Scale("season1/episode4/images/scene27/2.webp", 1920, 1080)
image e4s27-03 = im.Scale("season1/episode4/images/scene27/3.webp", 1920, 1080)
image e4s27-04 = im.Scale("season1/episode4/images/scene27/4.webp", 1920, 1080)
image e4s27-05 = im.Scale("season1/episode4/images/scene27/5.webp", 1920, 1080)
image e4s27-06 = im.Scale("season1/episode4/images/scene27/6.webp", 1920, 1080)
image e4s27-07 = im.Scale("season1/episode4/images/scene27/7.webp", 1920, 1080)
image e4s27-08 = im.Scale("season1/episode4/images/scene27/8.webp", 1920, 1080)
image e4s27-09 = im.Scale("season1/episode4/images/scene27/9.webp", 1920, 1080)
image e4s27-10 = im.Scale("season1/episode4/images/scene27/10.webp", 1920, 1080)
image e4s27-11 = im.Scale("season1/episode4/images/scene27/11.webp", 1920, 1080)
image e4s27-12 = im.Scale("season1/episode4/images/scene27/12.webp", 1920, 1080)
image e4s27-13 = im.Scale("season1/episode4/images/scene27/13.webp", 1920, 1080)
image e4s27-14 = im.Scale("season1/episode4/images/scene27/14.webp", 1920, 1080)
image e4s27-15 = im.Scale("season1/episode4/images/scene27/15.webp", 1920, 1080)
image e4s27-16 = im.Scale("season1/episode4/images/scene27/16.webp", 1920, 1080)
image e4s27-17 = im.Scale("season1/episode4/images/scene27/17.webp", 1920, 1080)
image e4s27-18 = im.Scale("season1/episode4/images/scene27/18.webp", 1920, 1080)
image e4s27-19 = im.Scale("season1/episode4/images/scene27/19.webp", 1920, 1080)
image e4s27-20 = im.Scale("season1/episode4/images/scene27/20.webp", 1920, 1080)
image e4s27-21 = im.Scale("season1/episode4/images/scene27/21.webp", 1920, 1080)
image e4s27-22 = im.Scale("season1/episode4/images/scene27/22.webp", 1920, 1080)
image e4s27-23 = im.Scale("season1/episode4/images/scene27/23.webp", 1920, 1080)
image e4s27-24 = im.Scale("season1/episode4/images/scene27/24.webp", 1920, 1080)
image e4s27-25 = im.Scale("season1/episode4/images/scene27/25.webp", 1920, 1080)
image e4s27-26 = im.Scale("season1/episode4/images/scene27/26.webp", 1920, 1080)
image e4s27-27 = im.Scale("season1/episode4/images/scene27/27.webp", 1920, 1080)
image e4s27-28 = im.Scale("season1/episode4/images/scene27/28.webp", 1920, 1080)
image e4s27-29 = im.Scale("season1/episode4/images/scene27/29.webp", 1920, 1080)
image e4s27-30 = im.Scale("season1/episode4/images/scene27/30.webp", 1920, 1080)
image e4s27-31 = im.Scale("season1/episode4/images/scene27/31.webp", 1920, 1080)
image e4s27-32 = im.Scale("season1/episode4/images/scene27/32.webp", 1920, 1080)
image e4s27-33 = im.Scale("season1/episode4/images/scene27/33.webp", 1920, 1080)
image e4s27-34 = im.Scale("season1/episode4/images/scene27/34.webp", 1920, 1080)
image e4s27-35 = im.Scale("season1/episode4/images/scene27/35.webp", 1920, 1080)
image e4s27-36 = im.Scale("season1/episode4/images/scene27/36.webp", 1920, 1080)
image e4s27-37 = im.Scale("season1/episode4/images/scene27/37.webp", 1920, 1080)
image e4s27-38 = im.Scale("season1/episode4/images/scene27/38.webp", 1920, 1080)
image e4s27-39 = im.Scale("season1/episode4/images/scene27/39.webp", 1920, 1080)
image e4s27-40 = im.Scale("season1/episode4/images/scene27/40.webp", 1920, 1080)
image e4s27-41 = im.Scale("season1/episode4/images/scene27/41.webp", 1920, 1080)
image e4s27-42 = im.Scale("season1/episode4/images/scene27/42.webp", 1920, 1080)
image e4s27-43 = im.Scale("season1/episode4/images/scene27/43.webp", 1920, 1080)
image e4s27-44 = im.Scale("season1/episode4/images/scene27/44.webp", 1920, 1080)
image e4s27-45 = im.Scale("season1/episode4/images/scene27/45.webp", 1920, 1080)
image e4s27-46 = im.Scale("season1/episode4/images/scene27/46.webp", 1920, 1080)
image e4s27-47 = im.Scale("season1/episode4/images/scene27/47.webp", 1920, 1080)
image e4s27-48 = im.Scale("season1/episode4/images/scene27/48.webp", 1920, 1080)
image e4s27-49 = im.Scale("season1/episode4/images/scene27/49.webp", 1920, 1080)
image e4s27-50 = im.Scale("season1/episode4/images/scene27/50.webp", 1920, 1080)
image e4s27-51 = im.Scale("season1/episode4/images/scene27/51.webp", 1920, 1080)
image e4s27-52 = im.Scale("season1/episode4/images/scene27/52.webp", 1920, 1080)
image e4s27-53 = im.Scale("season1/episode4/images/scene27/53.webp", 1920, 1080)
image e4s27-54 = im.Scale("season1/episode4/images/scene27/54.webp", 1920, 1080)
image e4s27-55 = im.Scale("season1/episode4/images/scene27/55.webp", 1920, 1080)
image e4s27-56 = im.Scale("season1/episode4/images/scene27/56.webp", 1920, 1080)
image e4s27-57 = im.Scale("season1/episode4/images/scene27/57.webp", 1920, 1080)
image e4s27-58 = im.Scale("season1/episode4/images/scene27/58.webp", 1920, 1080)
image e4s27-59 = im.Scale("season1/episode4/images/scene27/59.webp", 1920, 1080)
image e4s27-60 = im.Scale("season1/episode4/images/scene27/60.webp", 1920, 1080)
image e4s27-61 = im.Scale("season1/episode4/images/scene27/61.webp", 1920, 1080)
image e4s27-62 = im.Scale("season1/episode4/images/scene27/62.webp", 1920, 1080)
image e4s27-63 = im.Scale("season1/episode4/images/scene27/63.webp", 1920, 1080)
image e4s27-64 = im.Scale("season1/episode4/images/scene27/64.webp", 1920, 1080)
image e4s27-65 = im.Scale("season1/episode4/images/scene27/65.webp", 1920, 1080)
image e4s27-66 = im.Scale("season1/episode4/images/scene27/66.webp", 1920, 1080)
image e4s27-67 = im.Scale("season1/episode4/images/scene27/67.webp", 1920, 1080)
image e4s27-68 = im.Scale("season1/episode4/images/scene27/68.webp", 1920, 1080)
image e4s27-69 = im.Scale("season1/episode4/images/scene27/69.webp", 1920, 1080)
image e4s27-70 = im.Scale("season1/episode4/images/scene27/70.webp", 1920, 1080)
image e4s27-71 = im.Scale("season1/episode4/images/scene27/71.webp", 1920, 1080)
image e4s27-72 = im.Scale("season1/episode4/images/scene27/72.webp", 1920, 1080)
image e4s27-73 = im.Scale("season1/episode4/images/scene27/73.webp", 1920, 1080)
image e4s27-74 = im.Scale("season1/episode4/images/scene27/74.webp", 1920, 1080)
image e4s27-75 = im.Scale("season1/episode4/images/scene27/75.webp", 1920, 1080)
image e4s27-76 = im.Scale("season1/episode4/images/scene27/76.webp", 1920, 1080)
image e4s27-77 = im.Scale("season1/episode4/images/scene27/77.webp", 1920, 1080)
image e4s27-78 = im.Scale("season1/episode4/images/scene27/78.webp", 1920, 1080)
image e4s27-79 = im.Scale("season1/episode4/images/scene27/79.webp", 1920, 1080)
image e4s27-80 = im.Scale("season1/episode4/images/scene27/80.webp", 1920, 1080)
image e4s27-81 = im.Scale("season1/episode4/images/scene27/81.webp", 1920, 1080)
image e4s27-82 = im.Scale("season1/episode4/images/scene27/82.webp", 1920, 1080)
image e4s27-83 = im.Scale("season1/episode4/images/scene27/83.webp", 1920, 1080)
image e4s27-84 = im.Scale("season1/episode4/images/scene27/84.webp", 1920, 1080)
image e4s27-85 = im.Scale("season1/episode4/images/scene27/85.webp", 1920, 1080)
image e4s27-86 = im.Scale("season1/episode4/images/scene27/86.webp", 1920, 1080)
image e4s27-87 = im.Scale("season1/episode4/images/scene27/87.webp", 1920, 1080)
image e4s27-88 = im.Scale("season1/episode4/images/scene27/88.webp", 1920, 1080)
image e4s27-89 = im.Scale("season1/episode4/images/scene27/89.webp", 1920, 1080)
image e4s27-90 = im.Scale("season1/episode4/images/scene27/90.webp", 1920, 1080)
image e4s27-91 = im.Scale("season1/episode4/images/scene27/91.webp", 1920, 1080)
image e4s27-92 = im.Scale("season1/episode4/images/scene27/92.webp", 1920, 1080)
image e4s27-93 = im.Scale("season1/episode4/images/scene27/93.webp", 1920, 1080)
image e4s27-94 = im.Scale("season1/episode4/images/scene27/94.webp", 1920, 1080)
image e4s27-95 = im.Scale("season1/episode4/images/scene27/95.webp", 1920, 1080)
image e4s27-96 = im.Scale("season1/episode4/images/scene27/96.webp", 1920, 1080)
image e4s27-97 = im.Scale("season1/episode4/images/scene27/97.webp", 1920, 1080)
image e4s27-98 = im.Scale("season1/episode4/images/scene27/98.webp", 1920, 1080)
image e4s27-99 = im.Scale("season1/episode4/images/scene27/99.webp", 1920, 1080)
image e4s27-100 = im.Scale("season1/episode4/images/scene27/100.webp", 1920, 1080)
image e4s27-101 = im.Scale("season1/episode4/images/scene27/101.webp", 1920, 1080)
image e4s27-102 = im.Scale("season1/episode4/images/scene27/102.webp", 1920, 1080)
image e4s27-103 = im.Scale("season1/episode4/images/scene27/103.webp", 1920, 1080)
image e4s27-104 = im.Scale("season1/episode4/images/scene27/104.webp", 1920, 1080)
image e4s27-105 = im.Scale("season1/episode4/images/scene27/105.webp", 1920, 1080)
image e4s27-106 = im.Scale("season1/episode4/images/scene27/106.webp", 1920, 1080)
image e4s27-107 = im.Scale("season1/episode4/images/scene27/107.webp", 1920, 1080)
image e4s27-108 = im.Scale("season1/episode4/images/scene27/108.webp", 1920, 1080)
image e4s27-109 = im.Scale("season1/episode4/images/scene27/109.webp", 1920, 1080)
image e4s27-110 = im.Scale("season1/episode4/images/scene27/110.webp", 1920, 1080)
image e4s27-111 = im.Scale("season1/episode4/images/scene27/111.webp", 1920, 1080)
image e4s27-112 = im.Scale("season1/episode4/images/scene27/112.webp", 1920, 1080)
image e4s27-113 = im.Scale("season1/episode4/images/scene27/113.webp", 1920, 1080)
image e4s27-114 = im.Scale("season1/episode4/images/scene27/114.webp", 1920, 1080)
image e4s27-115 = im.Scale("season1/episode4/images/scene27/115.webp", 1920, 1080)
image e4s27-116 = im.Scale("season1/episode4/images/scene27/116.webp", 1920, 1080)
image e4s27-117 = im.Scale("season1/episode4/images/scene27/117.webp", 1920, 1080)
image e4s27-118 = im.Scale("season1/episode4/images/scene27/118.webp", 1920, 1080)
image e4s27-119 = im.Scale("season1/episode4/images/scene27/119.webp", 1920, 1080)
image e4s27-120 = im.Scale("season1/episode4/images/scene27/120.webp", 1920, 1080)
image e4s27-121 = im.Scale("season1/episode4/images/scene27/121.webp", 1920, 1080)
image e4s27-122 = im.Scale("season1/episode4/images/scene27/122.webp", 1920, 1080)
image e4s27-123 = im.Scale("season1/episode4/images/scene27/123.webp", 1920, 1080)
image e4s27-124 = im.Scale("season1/episode4/images/scene27/124.webp", 1920, 1080)
image e4s27-125 = im.Scale("season1/episode4/images/scene27/125.webp", 1920, 1080)
image e4s27-126 = im.Scale("season1/episode4/images/scene27/126.webp", 1920, 1080)
image e4s27-127 = im.Scale("season1/episode4/images/scene27/127.webp", 1920, 1080)
image e4s27-128 = im.Scale("season1/episode4/images/scene27/128.webp", 1920, 1080)
image e4s27-129 = im.Scale("season1/episode4/images/scene27/129.webp", 1920, 1080)
image e4s27-130 = im.Scale("season1/episode4/images/scene27/130.webp", 1920, 1080)
image e4s27-131 = im.Scale("season1/episode4/images/scene27/131.webp", 1920, 1080)
image e4s27-132 = im.Scale("season1/episode4/images/scene27/132.webp", 1920, 1080)
image e4s27-133 = im.Scale("season1/episode4/images/scene27/133.webp", 1920, 1080)
image e4s27-134 = im.Scale("season1/episode4/images/scene27/134.webp", 1920, 1080)
image e4s27-135 = im.Scale("season1/episode4/images/scene27/135.webp", 1920, 1080)
image e4s27-136 = im.Scale("season1/episode4/images/scene27/136.webp", 1920, 1080)
image e4s27-137 = im.Scale("season1/episode4/images/scene27/137.webp", 1920, 1080)
image e4s27-138 = im.Scale("season1/episode4/images/scene27/138.webp", 1920, 1080)
image e4s27-139 = im.Scale("season1/episode4/images/scene27/139.webp", 1920, 1080)
image e4s27-140 = im.Scale("season1/episode4/images/scene27/140.webp", 1920, 1080)
image e4s27-141 = im.Scale("season1/episode4/images/scene27/141.webp", 1920, 1080)
image e4s27-142 = im.Scale("season1/episode4/images/scene27/142.webp", 1920, 1080)
image e4s27-143 = im.Scale("season1/episode4/images/scene27/143.webp", 1920, 1080)
image e4s27-144 = im.Scale("season1/episode4/images/scene27/144.webp", 1920, 1080)
image e4s27-145 = im.Scale("season1/episode4/images/scene27/145.webp", 1920, 1080)
image e4s27-146 = im.Scale("season1/episode4/images/scene27/146.webp", 1920, 1080)
image e4s27-147 = im.Scale("season1/episode4/images/scene27/147.webp", 1920, 1080)
image e4s27-148 = im.Scale("season1/episode4/images/scene27/148.webp", 1920, 1080)
image e4s27-149 = im.Scale("season1/episode4/images/scene27/149.webp", 1920, 1080)
image e4s27-150 = im.Scale("season1/episode4/images/scene27/150.webp", 1920, 1080)
image e4s27-151 = im.Scale("season1/episode4/images/scene27/151.webp", 1920, 1080)
image e4s27-152 = im.Scale("season1/episode4/images/scene27/152.webp", 1920, 1080)
image e4s27-153 = im.Scale("season1/episode4/images/scene27/153.webp", 1920, 1080)
image e4s27-154 = im.Scale("season1/episode4/images/scene27/154.webp", 1920, 1080)
image e4s27-155 = im.Scale("season1/episode4/images/scene27/155.webp", 1920, 1080)
image e4s27-156 = im.Scale("season1/episode4/images/scene27/156.webp", 1920, 1080)
image e4s27-157 = im.Scale("season1/episode4/images/scene27/157.webp", 1920, 1080)
image e4s27-158 = im.Scale("season1/episode4/images/scene27/158.webp", 1920, 1080)
image e4s27-159 = im.Scale("season1/episode4/images/scene27/159.webp", 1920, 1080)
image e4s27-160 = im.Scale("season1/episode4/images/scene27/160.webp", 1920, 1080)
image e4s27-161 = im.Scale("season1/episode4/images/scene27/161.webp", 1920, 1080)
image e4s27-162 = im.Scale("season1/episode4/images/scene27/162.webp", 1920, 1080)
image e4s27-163 = im.Scale("season1/episode4/images/scene27/163.webp", 1920, 1080)
image e4s27-164 = im.Scale("season1/episode4/images/scene27/164.webp", 1920, 1080)
image e4s27-165 = im.Scale("season1/episode4/images/scene27/165.webp", 1920, 1080)
image e4s27-166 = im.Scale("season1/episode4/images/scene27/166.webp", 1920, 1080)

# Animations #
# Static
image e4s27_amber_blink1:
    im.Scale("season1/episode4/images/scene27/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

image e4s27_amber_blink2:
    im.Scale("season1/episode4/images/scene27/amber_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene27/amber_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e4s27-blowjob1 = Movie(play="season1/episode4/images/scene27/blowjob1.webm")
image e4s27-blowjob2 = Movie(play="season1/episode4/images/scene27/blowjob2.webm")
image e4s27-blowjob3 = Movie(play="season1/episode4/images/scene27/blowjob3.webm")
image e4s27-blowjob4 = Movie(play="season1/episode4/images/scene27/blowjob4.webm")
image e4s27-blowjob5 = Movie(play="season1/episode4/images/scene27/blowjob5.webm")
image e4s27-blowjob6 = Movie(play="season1/episode4/images/scene27/blowjob6.webm")
image e4s27-blowjob7 = Movie(play="season1/episode4/images/scene27/blowjob7.webm")
image e4s27-blowjob8 = Movie(play="season1/episode4/images/scene27/blowjob8.webm")
image e4s27-doggy1 = Movie(play="season1/episode4/images/scene27/doggy1.webm")
image e4s27-doggy2 = Movie(play="season1/episode4/images/scene27/doggy2.webm")
image e4s27-doggy3 = Movie(play="season1/episode4/images/scene27/doggy3.webm")
image e4s27-doggy4 = Movie(play="season1/episode4/images/scene27/doggy4.webm")
image e4s27-doggy5 = Movie(play="season1/episode4/images/scene27/doggy5.webm")
image e4s27-doggy6 = Movie(play="season1/episode4/images/scene27/doggy6.webm")
image e4s27-handjob1 = Movie(play="season1/episode4/images/scene27/handjob1.webm")
image e4s27-handjob2 = Movie(play="season1/episode4/images/scene27/handjob2.webm")
image e4s27-handjob3 = Movie(play="season1/episode4/images/scene27/handjob3.webm")
image e4s27-kiss1 = Movie(play="season1/episode4/images/scene27/kiss1.webm")
image e4s27-kiss2 = Movie(play="season1/episode4/images/scene27/kiss2.webm")
image e4s27-missionary1 = Movie(play="season1/episode4/images/scene27/missionary1.webm")
image e4s27-missionary2 = Movie(play="season1/episode4/images/scene27/missionary2.webm")
image e4s27-missionary3 = Movie(play="season1/episode4/images/scene27/missionary3.webm")
image e4s27-missionary4 = Movie(play="season1/episode4/images/scene27/missionary4.webm")
image e4s27-missionary5 = Movie(play="season1/episode4/images/scene27/missionary5.webm")
image e4s27-standing_doggy1 = Movie(play="season1/episode4/images/scene27/standing_doggy1.webm")
image e4s27-standing_doggy2 = Movie(play="season1/episode4/images/scene27/standing_doggy2.webm")
image e4s27-standing_doggy3 = Movie(play="season1/episode4/images/scene27/standing_doggy3.webm")
image e4s27-standing_doggy4 = Movie(play="season1/episode4/images/scene27/standing_doggy4.webm")
image e4s27-standing_doggy5 = Movie(play="season1/episode4/images/scene27/standing_doggy5.webm")

# Censored
# Images
image e4s27-29_cen = im.Scale("season1/episode4/images/scene27/censored/29.webp", 1920, 1080)
image e4s27-35_cen = im.Scale("season1/episode4/images/scene27/censored/35.webp", 1920, 1080)
image e4s27-36_cen = im.Scale("season1/episode4/images/scene27/censored/36.webp", 1920, 1080)
image e4s27-37_cen = im.Scale("season1/episode4/images/scene27/censored/37.webp", 1920, 1080)
image e4s27-38_cen = im.Scale("season1/episode4/images/scene27/censored/38.webp", 1920, 1080)
image e4s27-41_cen = im.Scale("season1/episode4/images/scene27/censored/41.webp", 1920, 1080)
image e4s27-42_cen = im.Scale("season1/episode4/images/scene27/censored/42.webp", 1920, 1080)
image e4s27-43_cen = im.Scale("season1/episode4/images/scene27/censored/43.webp", 1920, 1080)
image e4s27-44_cen = im.Scale("season1/episode4/images/scene27/censored/44.webp", 1920, 1080)
image e4s27-45_cen = im.Scale("season1/episode4/images/scene27/censored/45.webp", 1920, 1080)
image e4s27-46_cen = im.Scale("season1/episode4/images/scene27/censored/46.webp", 1920, 1080)
image e4s27-47_cen = im.Scale("season1/episode4/images/scene27/censored/47.webp", 1920, 1080)
image e4s27-48_cen = im.Scale("season1/episode4/images/scene27/censored/48.webp", 1920, 1080)
image e4s27-49_cen = im.Scale("season1/episode4/images/scene27/censored/49.webp", 1920, 1080)
image e4s27-50_cen = im.Scale("season1/episode4/images/scene27/censored/50.webp", 1920, 1080)
image e4s27-51_cen = im.Scale("season1/episode4/images/scene27/censored/51.webp", 1920, 1080)
image e4s27-52_cen = im.Scale("season1/episode4/images/scene27/censored/52.webp", 1920, 1080)
image e4s27-69_cen = im.Scale("season1/episode4/images/scene27/censored/69.webp", 1920, 1080)
image e4s27-70_cen = im.Scale("season1/episode4/images/scene27/censored/70.webp", 1920, 1080)
image e4s27-71_cen = im.Scale("season1/episode4/images/scene27/censored/71.webp", 1920, 1080)
image e4s27-85_cen = im.Scale("season1/episode4/images/scene27/censored/85.webp", 1920, 1080)
image e4s27-87_cen = im.Scale("season1/episode4/images/scene27/censored/87.webp", 1920, 1080)
image e4s27-88_cen = im.Scale("season1/episode4/images/scene27/censored/88.webp", 1920, 1080)
image e4s27-89_cen = im.Scale("season1/episode4/images/scene27/censored/89.webp", 1920, 1080)
image e4s27-90_cen = im.Scale("season1/episode4/images/scene27/censored/90.webp", 1920, 1080)
image e4s27-91_cen = im.Scale("season1/episode4/images/scene27/censored/91.webp", 1920, 1080)
image e4s27-92_cen = im.Scale("season1/episode4/images/scene27/censored/92.webp", 1920, 1080)
image e4s27-96_cen = im.Scale("season1/episode4/images/scene27/censored/96.webp", 1920, 1080)
image e4s27-97_cen = im.Scale("season1/episode4/images/scene27/censored/97.webp", 1920, 1080)
image e4s27-100_cen = im.Scale("season1/episode4/images/scene27/censored/100.webp", 1920, 1080)
image e4s27-101_cen = im.Scale("season1/episode4/images/scene27/censored/101.webp", 1920, 1080)
image e4s27-102_cen = im.Scale("season1/episode4/images/scene27/censored/102.webp", 1920, 1080)
image e4s27-105_cen = im.Scale("season1/episode4/images/scene27/censored/105.webp", 1920, 1080)
image e4s27-106_cen = im.Scale("season1/episode4/images/scene27/censored/106.webp", 1920, 1080)
image e4s27-107_cen = im.Scale("season1/episode4/images/scene27/censored/107.webp", 1920, 1080)
image e4s27-109_cen = im.Scale("season1/episode4/images/scene27/censored/109.webp", 1920, 1080)
image e4s27-114_cen = im.Scale("season1/episode4/images/scene27/censored/114.webp", 1920, 1080)
image e4s27-118_cen = im.Scale("season1/episode4/images/scene27/censored/118.webp", 1920, 1080)
image e4s27-120_cen = im.Scale("season1/episode4/images/scene27/censored/120.webp", 1920, 1080)

# Videos
image e4s27-blowjob1_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob1.webm")
image e4s27-blowjob2_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob2.webm")
image e4s27-blowjob3_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob3.webm")
image e4s27-blowjob4_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob4.webm")
image e4s27-blowjob5_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob5.webm")
image e4s27-blowjob6_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob6.webm")
image e4s27-blowjob7_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob7.webm")
image e4s27-blowjob8_cen = Movie(play="season1/episode4/images/scene27/censored/blowjob8.webm")
image e4s27-doggy1_cen = Movie(play="season1/episode4/images/scene27/censored/doggy1.webm")
image e4s27-doggy2_cen = Movie(play="season1/episode4/images/scene27/censored/doggy2.webm")
image e4s27-doggy3_cen = Movie(play="season1/episode4/images/scene27/censored/doggy3.webm")
image e4s27-doggy4_cen = Movie(play="season1/episode4/images/scene27/censored/doggy4.webm")
image e4s27-doggy5_cen = Movie(play="season1/episode4/images/scene27/censored/doggy5.webm")
image e4s27-doggy6_cen = Movie(play="season1/episode4/images/scene27/censored/doggy6.webm")
image e4s27-handjob1_cen = Movie(play="season1/episode4/images/scene27/censored/handjob1.webm")
image e4s27-handjob2_cen = Movie(play="season1/episode4/images/scene27/censored/handjob2.webm")
image e4s27-handjob3_cen = Movie(play="season1/episode4/images/scene27/censored/handjob3.webm")
image e4s27-kiss1_cen = Movie(play="season1/episode4/images/scene27/censored/kiss1.webm")
image e4s27-kiss2_cen = Movie(play="season1/episode4/images/scene27/censored/kiss2.webm")
image e4s27-missionary1_cen = Movie(play="season1/episode4/images/scene27/censored/missionary1.webm")
image e4s27-missionary2_cen = Movie(play="season1/episode4/images/scene27/censored/missionary2.webm")
image e4s27-missionary3_cen = Movie(play="season1/episode4/images/scene27/censored/missionary3.webm")
image e4s27-missionary4_cen = Movie(play="season1/episode4/images/scene27/censored/missionary4.webm")
image e4s27-missionary5_cen = Movie(play="season1/episode4/images/scene27/censored/missionary5.webm")
image e4s27-standing_doggy1_cen = Movie(play="season1/episode4/images/scene27/censored/standing_doggy1.webm")
image e4s27-standing_doggy2_cen = Movie(play="season1/episode4/images/scene27/censored/standing_doggy2.webm")
image e4s27-standing_doggy3_cen = Movie(play="season1/episode4/images/scene27/censored/standing_doggy3.webm")
image e4s27-standing_doggy4_cen = Movie(play="season1/episode4/images/scene27/censored/standing_doggy4.webm")
image e4s27-standing_doggy5_cen = Movie(play="season1/episode4/images/scene27/censored/standing_doggy5.webm")
