
# Scene 20 images ##############################################################

image e4s20-01 = im.Scale("season1/episode4/images/scene20/1.webp", 1920, 1080)
image e4s20-02 = im.Scale("season1/episode4/images/scene20/2.webp", 1920, 1080)
image e4s20-03 = im.Scale("season1/episode4/images/scene20/3.webp", 1920, 1080)
image e4s20-04 = im.Scale("season1/episode4/images/scene20/4.webp", 1920, 1080)
image e4s20-05 = im.Scale("season1/episode4/images/scene20/5.webp", 1920, 1080)
image e4s20-06 = im.Scale("season1/episode4/images/scene20/6.webp", 1920, 1080)
image e4s20-07 = im.Scale("season1/episode4/images/scene20/7.webp", 1920, 1080)
image e4s20-08 = im.Scale("season1/episode4/images/scene20/8.webp", 1920, 1080)
image e4s20-09 = im.Scale("season1/episode4/images/scene20/9.webp", 1920, 1080)
image e4s20-10 = im.Scale("season1/episode4/images/scene20/10.webp", 1920, 1080)
image e4s20-11 = im.Scale("season1/episode4/images/scene20/11.webp", 1920, 1080)
image e4s20-12 = im.Scale("season1/episode4/images/scene20/12.webp", 1920, 1080)
image e4s20-13 = im.Scale("season1/episode4/images/scene20/13.webp", 1920, 1080)
image e4s20-14 = im.Scale("season1/episode4/images/scene20/14.webp", 1920, 1080)
image e4s20-15 = im.Scale("season1/episode4/images/scene20/15.webp", 1920, 1080)
image e4s20-16 = im.Scale("season1/episode4/images/scene20/16.webp", 1920, 1080)
image e4s20-17 = im.Scale("season1/episode4/images/scene20/17.webp", 1920, 1080)
image e4s20-18 = im.Scale("season1/episode4/images/scene20/18.webp", 1920, 1080)
image e4s20-19 = im.Scale("season1/episode4/images/scene20/19.webp", 1920, 1080)
image e4s20-20 = im.Scale("season1/episode4/images/scene20/20.webp", 1920, 1080)
image e4s20-21 = im.Scale("season1/episode4/images/scene20/21.webp", 1920, 1080)

image e4s20_mc_blink1:
    im.Scale("season1/episode4/images/scene20/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene20/mc_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
