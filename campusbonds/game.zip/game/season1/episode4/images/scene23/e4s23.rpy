
init python:
    import random

# Scene 23 images ##############################################################

# Tracy ########################################################################
# Images
image e4s23-tr_01 = im.Scale("season1/episode4/images/scene23/tracy/1.webp", 1920, 1080)
image e4s23-tr_02 = im.Scale("season1/episode4/images/scene23/tracy/2.webp", 1920, 1080)
image e4s23-tr_03 = im.Scale("season1/episode4/images/scene23/tracy/3.webp", 1920, 1080)
image e4s23-tr_04 = im.Scale("season1/episode4/images/scene23/tracy/4.webp", 1920, 1080)
image e4s23-tr_05 = im.Scale("season1/episode4/images/scene23/tracy/5.webp", 1920, 1080)
image e4s23-tr_06 = im.Scale("season1/episode4/images/scene23/tracy/6.webp", 1920, 1080)
image e4s23-tr_07 = im.Scale("season1/episode4/images/scene23/tracy/7.webp", 1920, 1080)
image e4s23-tr_08 = im.Scale("season1/episode4/images/scene23/tracy/8.webp", 1920, 1080)
image e4s23-tr_09 = im.Scale("season1/episode4/images/scene23/tracy/9.webp", 1920, 1080)
image e4s23-tr_10 = im.Scale("season1/episode4/images/scene23/tracy/10.webp", 1920, 1080)
image e4s23-tr_11 = im.Scale("season1/episode4/images/scene23/tracy/11.webp", 1920, 1080)
image e4s23-tr_12 = im.Scale("season1/episode4/images/scene23/tracy/12.webp", 1920, 1080)
image e4s23-tr_13 = im.Scale("season1/episode4/images/scene23/tracy/13.webp", 1920, 1080)
image e4s23-tr_14 = im.Scale("season1/episode4/images/scene23/tracy/14.webp", 1920, 1080)
image e4s23-tr_15 = im.Scale("season1/episode4/images/scene23/tracy/15.webp", 1920, 1080)
image e4s23-tr_16 = im.Scale("season1/episode4/images/scene23/tracy/16.webp", 1920, 1080)
image e4s23-tr_17 = im.Scale("season1/episode4/images/scene23/tracy/17.webp", 1920, 1080)
image e4s23-tr_18 = im.Scale("season1/episode4/images/scene23/tracy/18.webp", 1920, 1080)
image e4s23-tr_19 = im.Scale("season1/episode4/images/scene23/tracy/19.webp", 1920, 1080)
image e4s23-tr_20 = im.Scale("season1/episode4/images/scene23/tracy/20.webp", 1920, 1080)
image e4s23-tr_21 = im.Scale("season1/episode4/images/scene23/tracy/21.webp", 1920, 1080)
image e4s23-tr_22 = im.Scale("season1/episode4/images/scene23/tracy/22.webp", 1920, 1080)
image e4s23-tr_23 = im.Scale("season1/episode4/images/scene23/tracy/23.webp", 1920, 1080)
image e4s23-tr_24 = im.Scale("season1/episode4/images/scene23/tracy/24.webp", 1920, 1080)
image e4s23-tr_25 = im.Scale("season1/episode4/images/scene23/tracy/25.webp", 1920, 1080)
image e4s23-tr_26 = im.Scale("season1/episode4/images/scene23/tracy/26.webp", 1920, 1080)
image e4s23-tr_27 = im.Scale("season1/episode4/images/scene23/tracy/27.webp", 1920, 1080)
image e4s23-tr_28 = im.Scale("season1/episode4/images/scene23/tracy/28.webp", 1920, 1080)
image e4s23-tr_29 = im.Scale("season1/episode4/images/scene23/tracy/29.webp", 1920, 1080)
image e4s23-tr_30 = im.Scale("season1/episode4/images/scene23/tracy/30.webp", 1920, 1080)
image e4s23-tr_31 = im.Scale("season1/episode4/images/scene23/tracy/31.webp", 1920, 1080)
image e4s23-tr_32 = im.Scale("season1/episode4/images/scene23/tracy/32.webp", 1920, 1080)
image e4s23-tr_33 = im.Scale("season1/episode4/images/scene23/tracy/33.webp", 1920, 1080)
image e4s23-tr_34 = im.Scale("season1/episode4/images/scene23/tracy/34.webp", 1920, 1080)
image e4s23-tr_35 = im.Scale("season1/episode4/images/scene23/tracy/35.webp", 1920, 1080)
image e4s23-tr_36 = im.Scale("season1/episode4/images/scene23/tracy/36.webp", 1920, 1080)
image e4s23-tr_37 = im.Scale("season1/episode4/images/scene23/tracy/37.webp", 1920, 1080)
image e4s23-tr_38 = im.Scale("season1/episode4/images/scene23/tracy/38.webp", 1920, 1080)
image e4s23-tr_39 = im.Scale("season1/episode4/images/scene23/tracy/39.webp", 1920, 1080)
image e4s23-tr_40 = im.Scale("season1/episode4/images/scene23/tracy/40.webp", 1920, 1080)
image e4s23-tr_41 = im.Scale("season1/episode4/images/scene23/tracy/41.webp", 1920, 1080)
image e4s23-tr_42 = im.Scale("season1/episode4/images/scene23/tracy/42.webp", 1920, 1080)
image e4s23-tr_43 = im.Scale("season1/episode4/images/scene23/tracy/43.webp", 1920, 1080)
image e4s23-tr_44 = im.Scale("season1/episode4/images/scene23/tracy/44.webp", 1920, 1080)
image e4s23-tr_45 = im.Scale("season1/episode4/images/scene23/tracy/45.webp", 1920, 1080)
image e4s23-tr_46 = im.Scale("season1/episode4/images/scene23/tracy/46.webp", 1920, 1080)
image e4s23-tr_47 = im.Scale("season1/episode4/images/scene23/tracy/47.webp", 1920, 1080)
image e4s23-tr_48 = im.Scale("season1/episode4/images/scene23/tracy/48.webp", 1920, 1080)
image e4s23-tr_49 = im.Scale("season1/episode4/images/scene23/tracy/49.webp", 1920, 1080)
image e4s23-tr_50 = im.Scale("season1/episode4/images/scene23/tracy/50.webp", 1920, 1080)
image e4s23-tr_51 = im.Scale("season1/episode4/images/scene23/tracy/51.webp", 1920, 1080)
image e4s23-tr_52 = im.Scale("season1/episode4/images/scene23/tracy/52.webp", 1920, 1080)
image e4s23-tr_53 = im.Scale("season1/episode4/images/scene23/tracy/53.webp", 1920, 1080)
image e4s23-tr_54 = im.Scale("season1/episode4/images/scene23/tracy/54.webp", 1920, 1080)
image e4s23-tr_55 = im.Scale("season1/episode4/images/scene23/tracy/55.webp", 1920, 1080)
image e4s23-tr_56 = im.Scale("season1/episode4/images/scene23/tracy/56.webp", 1920, 1080)
image e4s23-tr_57 = im.Scale("season1/episode4/images/scene23/tracy/57.webp", 1920, 1080)
image e4s23-tr_58 = im.Scale("season1/episode4/images/scene23/tracy/58.webp", 1920, 1080)
image e4s23-tr_59 = im.Scale("season1/episode4/images/scene23/tracy/59.webp", 1920, 1080)
image e4s23-tr_60 = im.Scale("season1/episode4/images/scene23/tracy/60.webp", 1920, 1080)
image e4s23-tr_61 = im.Scale("season1/episode4/images/scene23/tracy/61.webp", 1920, 1080)
image e4s23-tr_62 = im.Scale("season1/episode4/images/scene23/tracy/62.webp", 1920, 1080)
image e4s23-tr_63 = im.Scale("season1/episode4/images/scene23/tracy/63.webp", 1920, 1080)
image e4s23-tr_64 = im.Scale("season1/episode4/images/scene23/tracy/64.webp", 1920, 1080)
image e4s23-tr_65 = im.Scale("season1/episode4/images/scene23/tracy/65.webp", 1920, 1080)
image e4s23-tr_66 = im.Scale("season1/episode4/images/scene23/tracy/66.webp", 1920, 1080)
image e4s23-tr_67 = im.Scale("season1/episode4/images/scene23/tracy/67.webp", 1920, 1080)
image e4s23-tr_68 = im.Scale("season1/episode4/images/scene23/tracy/68.webp", 1920, 1080)
image e4s23-tr_69 = im.Scale("season1/episode4/images/scene23/tracy/69.webp", 1920, 1080)
image e4s23-tr_70 = im.Scale("season1/episode4/images/scene23/tracy/70.webp", 1920, 1080)
image e4s23-tr_71 = im.Scale("season1/episode4/images/scene23/tracy/71.webp", 1920, 1080)
image e4s23-tr_72 = im.Scale("season1/episode4/images/scene23/tracy/72.webp", 1920, 1080)
image e4s23-tr_73 = im.Scale("season1/episode4/images/scene23/tracy/73.webp", 1920, 1080)
image e4s23-tr_74 = im.Scale("season1/episode4/images/scene23/tracy/74.webp", 1920, 1080)
image e4s23-tr_75 = im.Scale("season1/episode4/images/scene23/tracy/75.webp", 1920, 1080)
image e4s23-tr_76 = im.Scale("season1/episode4/images/scene23/tracy/76.webp", 1920, 1080)
image e4s23-tr_77 = im.Scale("season1/episode4/images/scene23/tracy/77.webp", 1920, 1080)
image e4s23-tr_78 = im.Scale("season1/episode4/images/scene23/tracy/78.webp", 1920, 1080)
image e4s23-tr_79 = im.Scale("season1/episode4/images/scene23/tracy/79.webp", 1920, 1080)
image e4s23-tr_80 = im.Scale("season1/episode4/images/scene23/tracy/80.webp", 1920, 1080)
image e4s23-tr_81 = im.Scale("season1/episode4/images/scene23/tracy/81.webp", 1920, 1080)
image e4s23-tr_82 = im.Scale("season1/episode4/images/scene23/tracy/82.webp", 1920, 1080)
image e4s23-tr_83 = im.Scale("season1/episode4/images/scene23/tracy/83.webp", 1920, 1080)
image e4s23-tr_84 = im.Scale("season1/episode4/images/scene23/tracy/84.webp", 1920, 1080)
image e4s23-tr_85 = im.Scale("season1/episode4/images/scene23/tracy/85.webp", 1920, 1080)
image e4s23-tr_86 = im.Scale("season1/episode4/images/scene23/tracy/86.webp", 1920, 1080)
image e4s23-tr_87 = im.Scale("season1/episode4/images/scene23/tracy/87.webp", 1920, 1080)
image e4s23-tr_88 = im.Scale("season1/episode4/images/scene23/tracy/88.webp", 1920, 1080)
image e4s23-tr_89 = im.Scale("season1/episode4/images/scene23/tracy/89.webp", 1920, 1080)
image e4s23-tr_90 = im.Scale("season1/episode4/images/scene23/tracy/90.webp", 1920, 1080)
image e4s23-tr_91 = im.Scale("season1/episode4/images/scene23/tracy/91.webp", 1920, 1080)
image e4s23-tr_92 = im.Scale("season1/episode4/images/scene23/tracy/92.webp", 1920, 1080)
image e4s23-tr_93 = im.Scale("season1/episode4/images/scene23/tracy/93.webp", 1920, 1080)
image e4s23-tr_94 = im.Scale("season1/episode4/images/scene23/tracy/94.webp", 1920, 1080)
image e4s23-tr_95 = im.Scale("season1/episode4/images/scene23/tracy/95.webp", 1920, 1080)
image e4s23-tr_96 = im.Scale("season1/episode4/images/scene23/tracy/96.webp", 1920, 1080)
image e4s23-tr_97 = im.Scale("season1/episode4/images/scene23/tracy/97.webp", 1920, 1080)
image e4s23-tr_98 = im.Scale("season1/episode4/images/scene23/tracy/98.webp", 1920, 1080)
image e4s23-tr_99 = im.Scale("season1/episode4/images/scene23/tracy/99.webp", 1920, 1080)
image e4s23-tr_100 = im.Scale("season1/episode4/images/scene23/tracy/100.webp", 1920, 1080)
image e4s23-tr_101 = im.Scale("season1/episode4/images/scene23/tracy/101.webp", 1920, 1080)
image e4s23-tr_102 = im.Scale("season1/episode4/images/scene23/tracy/102.webp", 1920, 1080)
image e4s23-tr_103 = im.Scale("season1/episode4/images/scene23/tracy/103.webp", 1920, 1080)
image e4s23-tr_104 = im.Scale("season1/episode4/images/scene23/tracy/104.webp", 1920, 1080)
image e4s23-tr_105 = im.Scale("season1/episode4/images/scene23/tracy/105.webp", 1920, 1080)
image e4s23-tr_106 = im.Scale("season1/episode4/images/scene23/tracy/106.webp", 1920, 1080)
image e4s23-tr_107 = im.Scale("season1/episode4/images/scene23/tracy/107.webp", 1920, 1080)
image e4s23-tr_108 = im.Scale("season1/episode4/images/scene23/tracy/108.webp", 1920, 1080)
image e4s23-tr_109 = im.Scale("season1/episode4/images/scene23/tracy/109.webp", 1920, 1080)
image e4s23-tr_110 = im.Scale("season1/episode4/images/scene23/tracy/110.webp", 1920, 1080)
image e4s23-tr_111 = im.Scale("season1/episode4/images/scene23/tracy/111.webp", 1920, 1080)
image e4s23-tr_112 = im.Scale("season1/episode4/images/scene23/tracy/112.webp", 1920, 1080)
image e4s23-tr_113 = im.Scale("season1/episode4/images/scene23/tracy/113.webp", 1920, 1080)
image e4s23-tr_114 = im.Scale("season1/episode4/images/scene23/tracy/114.webp", 1920, 1080)
image e4s23-tr_115 = im.Scale("season1/episode4/images/scene23/tracy/115.webp", 1920, 1080)

# Animations #
# Static
image e4s23-tracy_blink1:
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/tracy/tracy_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Pizza
image e4s23_current_pizza_1 = im.Scale("season1/episode4/images/scene23/tracy/current_pizza1.webp", 1920, 1080)
image e4s23_current_pizza_2 = im.Scale("season1/episode4/images/scene23/tracy/current_pizza2.webp", 1920, 1080)

image e4s23_pizza_1:
    im.Scale("season1/episode4/images/scene23/tracy/25.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/26.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/27.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/28.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/29.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/28.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/27.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/28.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/29.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/38.webp", 1920, 1080) with dissolve
    0.0
image e4s23_pizza_2:
    im.Scale("season1/episode4/images/scene23/tracy/30.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/32.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/33.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/34.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/33.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/32.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/33.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/34.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/39.webp", 1920, 1080) with dissolve
    0.0
image e4s23_pizza_3:
    im.Scale("season1/episode4/images/scene23/tracy/31.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/35.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/36.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/37.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/36.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/35.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/36.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/37.webp", 1920, 1080) with dissolve
    0.5
    im.Scale("season1/episode4/images/scene23/tracy/21.webp", 1920, 1080) with dissolve
    0.0

# Sitting
label e4s23_sitting:
    $ e4s23_tracy_sitting = random.randint(0, 1)

    if e4s23_tracy_sitting == 0:
        scene e4s23_sitting_1 with dissolve
    else:
        scene e4s23_sitting_2 with dissolve
return

image e4s23_sitting_talking1 = im.Scale("season1/episode4/images/scene23/tracy/sitting_talking1.webp", 1920, 1080)

image e4s23_sitting_1:
    im.Scale("season1/episode4/images/scene23/tracy/60.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/61.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/62.webp", 1920, 1080) with dissolve
    1.0
    repeat

image e4s23_sitting_2:
    im.Scale("season1/episode4/images/scene23/tracy/60.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/63.webp", 1920, 1080) with dissolve
    1.0
    im.Scale("season1/episode4/images/scene23/tracy/64.webp", 1920, 1080) with dissolve
    1.0
    repeat

# Videos
image e4s23-tr_assgrab1 = Movie(play="season1/episode4/images/scene23/tracy/assgrab1.webm")
image e4s23-tr_assgrab2 = Movie(play="season1/episode4/images/scene23/tracy/assgrab2.webm")
image e4s23-tr_cowgirl1 = Movie(play="season1/episode4/images/scene23/tracy/cowgirl1.webm")
image e4s23-tr_cowgirl2 = Movie(play="season1/episode4/images/scene23/tracy/cowgirl2.webm")
image e4s23-tr_cowgirl3 = Movie(play="season1/episode4/images/scene23/tracy/cowgirl3.webm")
image e4s23-tr_cowgirl4 = Movie(play="season1/episode4/images/scene23/tracy/cowgirl4.webm")
image e4s23-tr_cowgirl5 = Movie(play="season1/episode4/images/scene23/tracy/cowgirl5.webm")
image e4s23-tr_cum1 = Movie(play="season1/episode4/images/scene23/tracy/cum1.webm")
image e4s23-tr_cum2 = Movie(play="season1/episode4/images/scene23/tracy/cum2.webm")
image e4s23-tr_cum3 = Movie(play="season1/episode4/images/scene23/tracy/cum3.webm")
image e4s23-tr_doggy1 = Movie(play="season1/episode4/images/scene23/tracy/doggy1.webm")
image e4s23-tr_doggy2 = Movie(play="season1/episode4/images/scene23/tracy/doggy2.webm")
image e4s23-tr_doggy3 = Movie(play="season1/episode4/images/scene23/tracy/doggy3.webm")
image e4s23-tr_doggy4 = Movie(play="season1/episode4/images/scene23/tracy/doggy4.webm")
image e4s23-tr_doggy5 = Movie(play="season1/episode4/images/scene23/tracy/doggy5.webm")
image e4s23-tr_reverse_cowgirl1 = Movie(play="season1/episode4/images/scene23/tracy/reverse_cowgirl1.webm")
image e4s23-tr_reverse_cowgirl2 = Movie(play="season1/episode4/images/scene23/tracy/reverse_cowgirl2.webm")
image e4s23-tr_reverse_cowgirl3 = Movie(play="season1/episode4/images/scene23/tracy/reverse_cowgirl3.webm")
image e4s23-tr_reverse_cowgirl4 = Movie(play="season1/episode4/images/scene23/tracy/reverse_cowgirl4.webm")
image e4s23-tr_reverse_cowgirl5 = Movie(play="season1/episode4/images/scene23/tracy/reverse_cowgirl5.webm")
image e4s23-tr_squirt1 = Movie(play="season1/episode4/images/scene23/tracy/squirt1.webm")
image e4s23-tr_titjob1 = Movie(play="season1/episode4/images/scene23/tracy/titjob1.webm")
image e4s23-tr_titjob2 = Movie(play="season1/episode4/images/scene23/tracy/titjob2.webm")
image e4s23-tr_titjob3 = Movie(play="season1/episode4/images/scene23/tracy/titjob3.webm")
image e4s23-tr_titjob4 = Movie(play="season1/episode4/images/scene23/tracy/titjob4.webm")
image e4s23-tr_titjob5 = Movie(play="season1/episode4/images/scene23/tracy/titjob5.webm")
image e4s23-tr_titjob6 = Movie(play="season1/episode4/images/scene23/tracy/titjob6.webm")

# Censored
# Images
image e4s23-tr_67_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/67.webp", 1920, 1080)
image e4s23-tr_68_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/68.webp", 1920, 1080)
image e4s23-tr_69_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/69.webp", 1920, 1080)
image e4s23-tr_70_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/70.webp", 1920, 1080)
image e4s23-tr_71_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/71.webp", 1920, 1080)
image e4s23-tr_72_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/72.webp", 1920, 1080)
image e4s23-tr_73_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/73.webp", 1920, 1080)
image e4s23-tr_75_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/75.webp", 1920, 1080)
image e4s23-tr_77_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/77.webp", 1920, 1080)
image e4s23-tr_78_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/78.webp", 1920, 1080)
image e4s23-tr_79_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/79.webp", 1920, 1080)
image e4s23-tr_80_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/80.webp", 1920, 1080)
image e4s23-tr_81_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/81.webp", 1920, 1080)
image e4s23-tr_82_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/82.webp", 1920, 1080)
image e4s23-tr_85_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/85.webp", 1920, 1080)
image e4s23-tr_87_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/87.webp", 1920, 1080)
image e4s23-tr_88_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/88.webp", 1920, 1080)
image e4s23-tr_90_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/90.webp", 1920, 1080)
image e4s23-tr_91_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/91.webp", 1920, 1080)
image e4s23-tr_92_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/92.webp", 1920, 1080)
image e4s23-tr_93_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/93.webp", 1920, 1080)
image e4s23-tr_94_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/94.webp", 1920, 1080)
image e4s23-tr_95_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/95.webp", 1920, 1080)
image e4s23-tr_96_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/96.webp", 1920, 1080)
image e4s23-tr_97_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/97.webp", 1920, 1080)
image e4s23-tr_98_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/98.webp", 1920, 1080)
image e4s23-tr_99_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/99.webp", 1920, 1080)
image e4s23-tr_100_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/100.webp", 1920, 1080)
image e4s23-tr_101_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/101.webp", 1920, 1080)
image e4s23-tr_102_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/102.webp", 1920, 1080)
image e4s23-tr_103_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/103.webp", 1920, 1080)
image e4s23-tr_104_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/104.webp", 1920, 1080)
image e4s23-tr_105_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/105.webp", 1920, 1080)
image e4s23-tr_106_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/106.webp", 1920, 1080)
image e4s23-tr_107_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/107.webp", 1920, 1080)
image e4s23-tr_108_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/108.webp", 1920, 1080)
image e4s23-tr_109_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/109.webp", 1920, 1080)
image e4s23-tr_110_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/110.webp", 1920, 1080)
image e4s23-tr_111_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/111.webp", 1920, 1080)
image e4s23-tr_112_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/112.webp", 1920, 1080)
image e4s23-tr_113_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/113.webp", 1920, 1080)
image e4s23-tr_114_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/114.webp", 1920, 1080)
image e4s23-tr_115_cen = im.Scale("season1/episode4/images/scene23/tracy/censored/115.webp", 1920, 1080)

# Animations
image e4s23-tr_assgrab1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/assgrab1.webm")
image e4s23-tr_assgrab2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/assgrab2.webm")
image e4s23-tr_cowgirl1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cowgirl1.webm")
image e4s23-tr_cowgirl2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cowgirl2.webm")
image e4s23-tr_cowgirl3_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cowgirl3.webm")
image e4s23-tr_cowgirl4_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cowgirl4.webm")
image e4s23-tr_cowgirl5_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cowgirl5.webm")
image e4s23-tr_cum1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cum1.webm")
image e4s23-tr_cum2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cum2.webm")
image e4s23-tr_cum3_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/cum3.webm")
image e4s23-tr_doggy1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/doggy1.webm")
image e4s23-tr_doggy2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/doggy2.webm")
image e4s23-tr_doggy3_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/doggy3.webm")
image e4s23-tr_doggy4_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/doggy4.webm")
image e4s23-tr_doggy5_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/doggy5.webm")
image e4s23-tr_reverse_cowgirl1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/reverse_cowgirl1.webm")
image e4s23-tr_reverse_cowgirl2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/reverse_cowgirl2.webm")
image e4s23-tr_reverse_cowgirl3_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/reverse_cowgirl3.webm")
image e4s23-tr_reverse_cowgirl4_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/reverse_cowgirl4.webm")
image e4s23-tr_reverse_cowgirl5_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/reverse_cowgirl5.webm")
image e4s23-tr_squirt1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/squirt1.webm")
image e4s23-tr_titjob1_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob1.webm")
image e4s23-tr_titjob2_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob2.webm")
image e4s23-tr_titjob3_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob3.webm")
image e4s23-tr_titjob4_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob4.webm")
image e4s23-tr_titjob5_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob5.webm")
image e4s23-tr_titjob6_cen = Movie(play="season1/episode4/images/scene23/tracy/censored/titjob6.webm")



# Francesca ####################################################################

# Uncensored
# Images
image e4s23-fr_01 = im.Scale("season1/episode4/images/scene23/francesca/1.webp", 1920, 1080)
image e4s23-fr_02 = im.Scale("season1/episode4/images/scene23/francesca/2.webp", 1920, 1080)
image e4s23-fr_03 = im.Scale("season1/episode4/images/scene23/francesca/3.webp", 1920, 1080)
image e4s23-fr_04 = im.Scale("season1/episode4/images/scene23/francesca/4.webp", 1920, 1080)
image e4s23-fr_05 = im.Scale("season1/episode4/images/scene23/francesca/5.webp", 1920, 1080)
image e4s23-fr_06 = im.Scale("season1/episode4/images/scene23/francesca/6.webp", 1920, 1080)
image e4s23-fr_07 = im.Scale("season1/episode4/images/scene23/francesca/7.webp", 1920, 1080)
image e4s23-fr_08 = im.Scale("season1/episode4/images/scene23/francesca/8.webp", 1920, 1080)
image e4s23-fr_09 = im.Scale("season1/episode4/images/scene23/francesca/9.webp", 1920, 1080)
image e4s23-fr_10 = im.Scale("season1/episode4/images/scene23/francesca/10.webp", 1920, 1080)
image e4s23-fr_11 = im.Scale("season1/episode4/images/scene23/francesca/11.webp", 1920, 1080)
image e4s23-fr_12 = im.Scale("season1/episode4/images/scene23/francesca/12.webp", 1920, 1080)
image e4s23-fr_13 = im.Scale("season1/episode4/images/scene23/francesca/13.webp", 1920, 1080)
image e4s23-fr_14 = im.Scale("season1/episode4/images/scene23/francesca/14.webp", 1920, 1080)
image e4s23-fr_15 = im.Scale("season1/episode4/images/scene23/francesca/15.webp", 1920, 1080)
image e4s23-fr_16 = im.Scale("season1/episode4/images/scene23/francesca/16.webp", 1920, 1080)
image e4s23-fr_17 = im.Scale("season1/episode4/images/scene23/francesca/17.webp", 1920, 1080)
image e4s23-fr_18 = im.Scale("season1/episode4/images/scene23/francesca/18.webp", 1920, 1080)
image e4s23-fr_19 = im.Scale("season1/episode4/images/scene23/francesca/19.webp", 1920, 1080)
image e4s23-fr_20 = im.Scale("season1/episode4/images/scene23/francesca/20.webp", 1920, 1080)
image e4s23-fr_21 = im.Scale("season1/episode4/images/scene23/francesca/21.webp", 1920, 1080)
image e4s23-fr_22 = im.Scale("season1/episode4/images/scene23/francesca/22.webp", 1920, 1080)
image e4s23-fr_23 = im.Scale("season1/episode4/images/scene23/francesca/23.webp", 1920, 1080)
image e4s23-fr_24 = im.Scale("season1/episode4/images/scene23/francesca/24.webp", 1920, 1080)
image e4s23-fr_25 = im.Scale("season1/episode4/images/scene23/francesca/25.webp", 1920, 1080)
image e4s23-fr_26 = im.Scale("season1/episode4/images/scene23/francesca/26.webp", 1920, 1080)
image e4s23-fr_27 = im.Scale("season1/episode4/images/scene23/francesca/27.webp", 1920, 1080)
image e4s23-fr_28 = im.Scale("season1/episode4/images/scene23/francesca/28.webp", 1920, 1080)
image e4s23-fr_29 = im.Scale("season1/episode4/images/scene23/francesca/29.webp", 1920, 1080)
image e4s23-fr_30 = im.Scale("season1/episode4/images/scene23/francesca/30.webp", 1920, 1080)
image e4s23-fr_31 = im.Scale("season1/episode4/images/scene23/francesca/31.webp", 1920, 1080)
image e4s23-fr_32 = im.Scale("season1/episode4/images/scene23/francesca/32.webp", 1920, 1080)
image e4s23-fr_33 = im.Scale("season1/episode4/images/scene23/francesca/33.webp", 1920, 1080)
image e4s23-fr_34 = im.Scale("season1/episode4/images/scene23/francesca/34.webp", 1920, 1080)
image e4s23-fr_35 = im.Scale("season1/episode4/images/scene23/francesca/35.webp", 1920, 1080)
image e4s23-fr_36 = im.Scale("season1/episode4/images/scene23/francesca/36.webp", 1920, 1080)
image e4s23-fr_37 = im.Scale("season1/episode4/images/scene23/francesca/37.webp", 1920, 1080)
image e4s23-fr_38 = im.Scale("season1/episode4/images/scene23/francesca/38.webp", 1920, 1080)
image e4s23-fr_39 = im.Scale("season1/episode4/images/scene23/francesca/39.webp", 1920, 1080)
image e4s23-fr_40 = im.Scale("season1/episode4/images/scene23/francesca/40.webp", 1920, 1080)
image e4s23-fr_41 = im.Scale("season1/episode4/images/scene23/francesca/41.webp", 1920, 1080)
image e4s23-fr_42 = im.Scale("season1/episode4/images/scene23/francesca/42.webp", 1920, 1080)
image e4s23-fr_43 = im.Scale("season1/episode4/images/scene23/francesca/43.webp", 1920, 1080)
image e4s23-fr_44 = im.Scale("season1/episode4/images/scene23/francesca/44.webp", 1920, 1080)
image e4s23-fr_45 = im.Scale("season1/episode4/images/scene23/francesca/45.webp", 1920, 1080)
image e4s23-fr_46 = im.Scale("season1/episode4/images/scene23/francesca/46.webp", 1920, 1080)
image e4s23-fr_47 = im.Scale("season1/episode4/images/scene23/francesca/47.webp", 1920, 1080)
image e4s23-fr_48 = im.Scale("season1/episode4/images/scene23/francesca/48.webp", 1920, 1080)
image e4s23-fr_49 = im.Scale("season1/episode4/images/scene23/francesca/49.webp", 1920, 1080)
image e4s23-fr_50 = im.Scale("season1/episode4/images/scene23/francesca/50.webp", 1920, 1080)
image e4s23-fr_51 = im.Scale("season1/episode4/images/scene23/francesca/51.webp", 1920, 1080)
image e4s23-fr_52 = im.Scale("season1/episode4/images/scene23/francesca/52.webp", 1920, 1080)
image e4s23-fr_53 = im.Scale("season1/episode4/images/scene23/francesca/53.webp", 1920, 1080)
image e4s23-fr_54 = im.Scale("season1/episode4/images/scene23/francesca/54.webp", 1920, 1080)
image e4s23-fr_55 = im.Scale("season1/episode4/images/scene23/francesca/55.webp", 1920, 1080)
image e4s23-fr_56 = im.Scale("season1/episode4/images/scene23/francesca/56.webp", 1920, 1080)
image e4s23-fr_57 = im.Scale("season1/episode4/images/scene23/francesca/57.webp", 1920, 1080)
image e4s23-fr_58 = im.Scale("season1/episode4/images/scene23/francesca/58.webp", 1920, 1080)
image e4s23-fr_59 = im.Scale("season1/episode4/images/scene23/francesca/59.webp", 1920, 1080)
image e4s23-fr_60 = im.Scale("season1/episode4/images/scene23/francesca/60.webp", 1920, 1080)
image e4s23-fr_61 = im.Scale("season1/episode4/images/scene23/francesca/61.webp", 1920, 1080)
image e4s23-fr_62 = im.Scale("season1/episode4/images/scene23/francesca/62.webp", 1920, 1080)
image e4s23-fr_63 = im.Scale("season1/episode4/images/scene23/francesca/63.webp", 1920, 1080)
image e4s23-fr_64 = im.Scale("season1/episode4/images/scene23/francesca/64.webp", 1920, 1080)
image e4s23-fr_65 = im.Scale("season1/episode4/images/scene23/francesca/65.webp", 1920, 1080)
image e4s23-fr_66 = im.Scale("season1/episode4/images/scene23/francesca/66.webp", 1920, 1080)
image e4s23-fr_67 = im.Scale("season1/episode4/images/scene23/francesca/67.webp", 1920, 1080)
image e4s23-fr_68 = im.Scale("season1/episode4/images/scene23/francesca/68.webp", 1920, 1080)
image e4s23-fr_69 = im.Scale("season1/episode4/images/scene23/francesca/69.webp", 1920, 1080)
image e4s23-fr_70 = im.Scale("season1/episode4/images/scene23/francesca/70.webp", 1920, 1080)
image e4s23-fr_71 = im.Scale("season1/episode4/images/scene23/francesca/71.webp", 1920, 1080)
image e4s23-fr_72 = im.Scale("season1/episode4/images/scene23/francesca/72.webp", 1920, 1080)
image e4s23-fr_73 = im.Scale("season1/episode4/images/scene23/francesca/73.webp", 1920, 1080)
image e4s23-fr_74 = im.Scale("season1/episode4/images/scene23/francesca/74.webp", 1920, 1080)
image e4s23-fr_75 = im.Scale("season1/episode4/images/scene23/francesca/75.webp", 1920, 1080)
image e4s23-fr_76 = im.Scale("season1/episode4/images/scene23/francesca/76.webp", 1920, 1080)
image e4s23-fr_77 = im.Scale("season1/episode4/images/scene23/francesca/77.webp", 1920, 1080)
image e4s23-fr_78 = im.Scale("season1/episode4/images/scene23/francesca/78.webp", 1920, 1080)
image e4s23-fr_79 = im.Scale("season1/episode4/images/scene23/francesca/79.webp", 1920, 1080)
image e4s23-fr_80 = im.Scale("season1/episode4/images/scene23/francesca/80.webp", 1920, 1080)
image e4s23-fr_81 = im.Scale("season1/episode4/images/scene23/francesca/81.webp", 1920, 1080)
image e4s23-fr_82 = im.Scale("season1/episode4/images/scene23/francesca/82.webp", 1920, 1080)
image e4s23-fr_83 = im.Scale("season1/episode4/images/scene23/francesca/83.webp", 1920, 1080)
image e4s23-fr_84 = im.Scale("season1/episode4/images/scene23/francesca/84.webp", 1920, 1080)
image e4s23-fr_85 = im.Scale("season1/episode4/images/scene23/francesca/85.webp", 1920, 1080)
image e4s23-fr_86 = im.Scale("season1/episode4/images/scene23/francesca/86.webp", 1920, 1080)
image e4s23-fr_87 = im.Scale("season1/episode4/images/scene23/francesca/87.webp", 1920, 1080)
image e4s23-fr_88 = im.Scale("season1/episode4/images/scene23/francesca/88.webp", 1920, 1080)
image e4s23-fr_89 = im.Scale("season1/episode4/images/scene23/francesca/89.webp", 1920, 1080)
image e4s23-fr_90 = im.Scale("season1/episode4/images/scene23/francesca/90.webp", 1920, 1080)
image e4s23-fr_91 = im.Scale("season1/episode4/images/scene23/francesca/91.webp", 1920, 1080)
image e4s23-fr_92 = im.Scale("season1/episode4/images/scene23/francesca/92.webp", 1920, 1080)
image e4s23-fr_93 = im.Scale("season1/episode4/images/scene23/francesca/93.webp", 1920, 1080)
image e4s23-fr_94 = im.Scale("season1/episode4/images/scene23/francesca/94.webp", 1920, 1080)
image e4s23-fr_95 = im.Scale("season1/episode4/images/scene23/francesca/95.webp", 1920, 1080)
image e4s23-fr_96 = im.Scale("season1/episode4/images/scene23/francesca/96.webp", 1920, 1080)
image e4s23-fr_97 = im.Scale("season1/episode4/images/scene23/francesca/97.webp", 1920, 1080)
image e4s23-fr_98 = im.Scale("season1/episode4/images/scene23/francesca/98.webp", 1920, 1080)
image e4s23-fr_99 = im.Scale("season1/episode4/images/scene23/francesca/99.webp", 1920, 1080)
image e4s23-fr_100 = im.Scale("season1/episode4/images/scene23/francesca/100.webp", 1920, 1080)
image e4s23-fr_101 = im.Scale("season1/episode4/images/scene23/francesca/101.webp", 1920, 1080)
image e4s23-fr_102 = im.Scale("season1/episode4/images/scene23/francesca/102.webp", 1920, 1080)
image e4s23-fr_103 = im.Scale("season1/episode4/images/scene23/francesca/103.webp", 1920, 1080)
image e4s23-fr_104 = im.Scale("season1/episode4/images/scene23/francesca/104.webp", 1920, 1080)
image e4s23-fr_105 = im.Scale("season1/episode4/images/scene23/francesca/105.webp", 1920, 1080)
image e4s23-fr_106 = im.Scale("season1/episode4/images/scene23/francesca/106.webp", 1920, 1080)
image e4s23-fr_107 = im.Scale("season1/episode4/images/scene23/francesca/107.webp", 1920, 1080)
image e4s23-fr_108 = im.Scale("season1/episode4/images/scene23/francesca/108.webp", 1920, 1080)
image e4s23-fr_109 = im.Scale("season1/episode4/images/scene23/francesca/109.webp", 1920, 1080)
image e4s23-fr_110 = im.Scale("season1/episode4/images/scene23/francesca/110.webp", 1920, 1080)
image e4s23-fr_111 = im.Scale("season1/episode4/images/scene23/francesca/111.webp", 1920, 1080)
image e4s23-fr_112 = im.Scale("season1/episode4/images/scene23/francesca/112.webp", 1920, 1080)
image e4s23-fr_113 = im.Scale("season1/episode4/images/scene23/francesca/113.webp", 1920, 1080)
image e4s23-fr_114 = im.Scale("season1/episode4/images/scene23/francesca/114.webp", 1920, 1080)
image e4s23-fr_115 = im.Scale("season1/episode4/images/scene23/francesca/115.webp", 1920, 1080)
image e4s23-fr_116 = im.Scale("season1/episode4/images/scene23/francesca/116.webp", 1920, 1080)
image e4s23-fr_117 = im.Scale("season1/episode4/images/scene23/francesca/117.webp", 1920, 1080)
image e4s23-fr_118 = im.Scale("season1/episode4/images/scene23/francesca/118.webp", 1920, 1080)
image e4s23-fr_119 = im.Scale("season1/episode4/images/scene23/francesca/119.webp", 1920, 1080)
image e4s23-fr_120 = im.Scale("season1/episode4/images/scene23/francesca/120.webp", 1920, 1080)
image e4s23-fr_121 = im.Scale("season1/episode4/images/scene23/francesca/121.webp", 1920, 1080)

# Animations #
# Static
image e4s23_francesca_blink1:
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca/francesca_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e4s23_francesca_blink2:
    im.Scale("season1/episode4/images/scene23/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink2/0.webp", 1920, 1080) with dissolve
    4
    repeat
image e4s23_francesca_blink3:
    im.Scale("season1/episode4/images/scene23/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene23/francesca_blink3/0.webp", 1920, 1080) with dissolve
    4
    repeat

# Videos
image e4s23-fr_handjob1 = Movie(play="season1/episode4/images/scene23/francesca/handjob1.webm")
image e4s23-fr_handjob2 = Movie(play="season1/episode4/images/scene23/francesca/handjob2.webm")
image e4s23-fr_handjob3 = Movie(play="season1/episode4/images/scene23/francesca/handjob3.webm")
image e4s23-fr_handjob4 = Movie(play="season1/episode4/images/scene23/francesca/handjob4.webm")
image e4s23-fr_handjob5 = Movie(play="season1/episode4/images/scene23/francesca/handjob5.webm")
image e4s23-fr_kiss1 = Movie(play="season1/episode4/images/scene23/francesca/kiss1.webm")
image e4s23-fr_kiss2 = Movie(play="season1/episode4/images/scene23/francesca/kiss2.webm")
image e4s23-fr_rubbing1 = Movie(play="season1/episode4/images/scene23/francesca/rubbing1.webm")
image e4s23-fr_rubbing2 = Movie(play="season1/episode4/images/scene23/francesca/rubbing2.webm")
image e4s23-fr_rubbing3 = Movie(play="season1/episode4/images/scene23/francesca/rubbing3.webm")
image e4s23-fr_rubbing4 = Movie(play="season1/episode4/images/scene23/francesca/rubbing4.webm")
image e4s23-fr_rubbing5 = Movie(play="season1/episode4/images/scene23/francesca/rubbing5.webm")
image e4s23-fr_rubbing6 = Movie(play="season1/episode4/images/scene23/francesca/rubbing6.webm")
image e4s23-fr_rubbing7 = Movie(play="season1/episode4/images/scene23/francesca/rubbing7.webm")
image e4s23-fr_rubbing8 = Movie(play="season1/episode4/images/scene23/francesca/rubbing8.webm")
image e4s23-fr_rubbing9 = Movie(play="season1/episode4/images/scene23/francesca/rubbing9.webm")

# Censored
# Images
image e4s23-fr_75_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/75.webp", 1920, 1080)
image e4s23-fr_76_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/76.webp", 1920, 1080)
image e4s23-fr_77_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/77.webp", 1920, 1080)
image e4s23-fr_78_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/78.webp", 1920, 1080)
image e4s23-fr_79_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/79.webp", 1920, 1080)
image e4s23-fr_80_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/80.webp", 1920, 1080)
image e4s23-fr_81_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/81.webp", 1920, 1080)
image e4s23-fr_82_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/82.webp", 1920, 1080)
image e4s23-fr_83_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/83.webp", 1920, 1080)
image e4s23-fr_84_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/84.webp", 1920, 1080)
image e4s23-fr_85_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/85.webp", 1920, 1080)
image e4s23-fr_86_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/86.webp", 1920, 1080)
image e4s23-fr_93_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/93.webp", 1920, 1080)
image e4s23-fr_94_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/94.webp", 1920, 1080)
image e4s23-fr_95_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/95.webp", 1920, 1080)
image e4s23-fr_96_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/96.webp", 1920, 1080)
image e4s23-fr_97_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/97.webp", 1920, 1080)
image e4s23-fr_98_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/98.webp", 1920, 1080)
image e4s23-fr_99_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/99.webp", 1920, 1080)
image e4s23-fr_107_cen = im.Scale("season1/episode4/images/scene23/francesca/censored/107.webp", 1920, 1080)

# Videos
image e4s23-fr_handjob1_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/handjob1.webm")
image e4s23-fr_handjob2_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/handjob2.webm")
image e4s23-fr_handjob3_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/handjob3.webm")
image e4s23-fr_handjob4_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/handjob4.webm")
image e4s23-fr_handjob5_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/handjob5.webm")
image e4s23-fr_kiss1_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/kiss1.webm")
image e4s23-fr_kiss2_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/kiss2.webm")
image e4s23-fr_rubbing1_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing1.webm")
image e4s23-fr_rubbing2_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing2.webm")
image e4s23-fr_rubbing3_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing3.webm")
image e4s23-fr_rubbing4_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing4.webm")
image e4s23-fr_rubbing5_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing5.webm")
image e4s23-fr_rubbing6_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing6.webm")
image e4s23-fr_rubbing7_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing7.webm")
image e4s23-fr_rubbing8_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing8.webm")
image e4s23-fr_rubbing9_cen = Movie(play="season1/episode4/images/scene23/francesca/censored/rubbing9.webm")
