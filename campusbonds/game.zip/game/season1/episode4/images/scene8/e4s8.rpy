
# Scene 8 images ###############################################################

image e4s8-01 = im.Scale("season1/episode4/images/scene8/1.webp", 1920, 1080)
image e4s8-02 = im.Scale("season1/episode4/images/scene8/2.webp", 1920, 1080)
image e4s8-03 = im.Scale("season1/episode4/images/scene8/3.webp", 1920, 1080)
image e4s8-04 = im.Scale("season1/episode4/images/scene8/4.webp", 1920, 1080)
image e4s8-05 = im.Scale("season1/episode4/images/scene8/5.webp", 1920, 1080)
image e4s8-06 = im.Scale("season1/episode4/images/scene8/6.webp", 1920, 1080)
image e4s8-07 = im.Scale("season1/episode4/images/scene8/7.webp", 1920, 1080)
image e4s8-08 = im.Scale("season1/episode4/images/scene8/8.webp", 1920, 1080)
image e4s8-09 = im.Scale("season1/episode4/images/scene8/9.webp", 1920, 1080)
image e4s8-10 = im.Scale("season1/episode4/images/scene8/10.webp", 1920, 1080)
image e4s8-11 = im.Scale("season1/episode4/images/scene8/11.webp", 1920, 1080)
image e4s8-12 = im.Scale("season1/episode4/images/scene8/12.webp", 1920, 1080)
image e4s8-13 = im.Scale("season1/episode4/images/scene8/13.webp", 1920, 1080)
image e4s8-14 = im.Scale("season1/episode4/images/scene8/14.webp", 1920, 1080)
image e4s8-15 = im.Scale("season1/episode4/images/scene8/15.webp", 1920, 1080)
image e4s8-16 = im.Scale("season1/episode4/images/scene8/16.webp", 1920, 1080)
image e4s8-17 = im.Scale("season1/episode4/images/scene8/17.webp", 1920, 1080)
image e4s8-18 = im.Scale("season1/episode4/images/scene8/18.webp", 1920, 1080)
image e4s8-19 = im.Scale("season1/episode4/images/scene8/19.webp", 1920, 1080)
image e4s8-20 = im.Scale("season1/episode4/images/scene8/20.webp", 1920, 1080)
image e4s8-21 = im.Scale("season1/episode4/images/scene8/21.webp", 1920, 1080)
image e4s8-22 = im.Scale("season1/episode4/images/scene8/22.webp", 1920, 1080)
image e4s8-23 = im.Scale("season1/episode4/images/scene8/23.webp", 1920, 1080)
image e4s8-24 = im.Scale("season1/episode4/images/scene8/24.webp", 1920, 1080)
image e4s8-25 = im.Scale("season1/episode4/images/scene8/25.webp", 1920, 1080)
image e4s8-26 = im.Scale("season1/episode4/images/scene8/26.webp", 1920, 1080)
image e4s8-27 = im.Scale("season1/episode4/images/scene8/27.webp", 1920, 1080)
image e4s8-28 = im.Scale("season1/episode4/images/scene8/28.webp", 1920, 1080)
image e4s8-29 = im.Scale("season1/episode4/images/scene8/29.webp", 1920, 1080)
image e4s8-30 = im.Scale("season1/episode4/images/scene8/30.webp", 1920, 1080)
image e4s8-31 = im.Scale("season1/episode4/images/scene8/31.webp", 1920, 1080)
image e4s8-32 = im.Scale("season1/episode4/images/scene8/32.webp", 1920, 1080)
image e4s8-33 = im.Scale("season1/episode4/images/scene8/33.webp", 1920, 1080)
image e4s8-34 = im.Scale("season1/episode4/images/scene8/34.webp", 1920, 1080)
image e4s8-35 = im.Scale("season1/episode4/images/scene8/35.webp", 1920, 1080)
image e4s8-36 = im.Scale("season1/episode4/images/scene8/36.webp", 1920, 1080)
image e4s8-37 = im.Scale("season1/episode4/images/scene8/37.webp", 1920, 1080)
image e4s8-38 = im.Scale("season1/episode4/images/scene8/38.webp", 1920, 1080)
image e4s8-39 = im.Scale("season1/episode4/images/scene8/39.webp", 1920, 1080)
image e4s8-40 = im.Scale("season1/episode4/images/scene8/40.webp", 1920, 1080)
image e4s8-41 = im.Scale("season1/episode4/images/scene8/41.webp", 1920, 1080)
image e4s8-42 = im.Scale("season1/episode4/images/scene8/42.webp", 1920, 1080)
image e4s8-43 = im.Scale("season1/episode4/images/scene8/43.webp", 1920, 1080)
image e4s8-44 = im.Scale("season1/episode4/images/scene8/44.webp", 1920, 1080)
image e4s8-45 = im.Scale("season1/episode4/images/scene8/45.webp", 1920, 1080)
image e4s8-46 = im.Scale("season1/episode4/images/scene8/46.webp", 1920, 1080)
image e4s8-47 = im.Scale("season1/episode4/images/scene8/47.webp", 1920, 1080)
image e4s8-48 = im.Scale("season1/episode4/images/scene8/48.webp", 1920, 1080)
image e4s8-49 = im.Scale("season1/episode4/images/scene8/49.webp", 1920, 1080)
image e4s8-50 = im.Scale("season1/episode4/images/scene8/50.webp", 1920, 1080)
image e4s8-51 = im.Scale("season1/episode4/images/scene8/51.webp", 1920, 1080)
image e4s8-52 = im.Scale("season1/episode4/images/scene8/52.webp", 1920, 1080)
image e4s8-53 = im.Scale("season1/episode4/images/scene8/53.webp", 1920, 1080)
image e4s8-54 = im.Scale("season1/episode4/images/scene8/54.webp", 1920, 1080)
image e4s8-55 = im.Scale("season1/episode4/images/scene8/55.webp", 1920, 1080)
image e4s8-56 = im.Scale("season1/episode4/images/scene8/56.webp", 1920, 1080)
image e4s8-57 = im.Scale("season1/episode4/images/scene8/57.webp", 1920, 1080)
image e4s8-58 = im.Scale("season1/episode4/images/scene8/58.webp", 1920, 1080)
image e4s8-59 = im.Scale("season1/episode4/images/scene8/59.webp", 1920, 1080)
image e4s8-60 = im.Scale("season1/episode4/images/scene8/60.webp", 1920, 1080)
image e4s8-61 = im.Scale("season1/episode4/images/scene8/61.webp", 1920, 1080)
image e4s8-62 = im.Scale("season1/episode4/images/scene8/62.webp", 1920, 1080)
image e4s8-63 = im.Scale("season1/episode4/images/scene8/63.webp", 1920, 1080)
image e4s8-64 = im.Scale("season1/episode4/images/scene8/64.webp", 1920, 1080)
image e4s8-65 = im.Scale("season1/episode4/images/scene8/65.webp", 1920, 1080)
image e4s8-66 = im.Scale("season1/episode4/images/scene8/66.webp", 1920, 1080)
image e4s8-67 = im.Scale("season1/episode4/images/scene8/67.webp", 1920, 1080)
image e4s8-68 = im.Scale("season1/episode4/images/scene8/68.webp", 1920, 1080)
image e4s8-69 = im.Scale("season1/episode4/images/scene8/69.webp", 1920, 1080)
image e4s8-70 = im.Scale("season1/episode4/images/scene8/70.webp", 1920, 1080)
image e4s8-71 = im.Scale("season1/episode4/images/scene8/71.webp", 1920, 1080)

# Animations #
# Static
image e4s8_alice_blink1:
    im.Scale("season1/episode4/images/scene8/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/6.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/5.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/4.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/3.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/2.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/1.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/0.webp", 1920, 1080) with dissolve
    0.05
    im.Scale("season1/episode4/images/scene8/alice_blink1/0.webp", 1920, 1080) with dissolve
    4
    repeat
