
# Scene 1 - Jon's confession. (Sunday) #########################################

label e4s1:
    play music travel_light
    scene e4s1-01 with Dissolve(2.0)
    jon "So... he's sort of like my stepcousin."
    jon "We're not blood related."

    scene e4s1-02 with dissolve
    mc "Still, bro, how does that even work?"

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "I mean, we've known each other for so long, how did I not know that?"

    scene e4s1-04 with dissolve
    hide e4s1_jon_blink1
    jon "What do you mean you didn't know?"

    scene e4s1-05 with dissolve
    jon "Whenever he came over while we were playing video games, I'd always let you know my cousin was here."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Yeah... but like, I didn't expect him to be [sp]."
    mc "Didn't you say he moved away or something?"

    scene e4s1-06 with dissolve
    hide e4s1_jon_blink1
    jon "Look, [mc], my family is a bit complicated, alright?"

    scene e4s1-07 with dissolve
    jon "I'm sorry for not telling you and all, I know you're my best friend."

    scene e4s1-08 with dissolve
    jon "I just... didn't see the need for anyone to know that he's my cousin."
    jon "It's complicated."

    scene e4s1-05 with dissolve
    jon "He doesn't like people knowing, and honestly... it's not my story to tell."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "I get that... but damn, [jon], that's a lot to take in."

    scene e4s1-04 with dissolve
    hide e4s1_jon_blink1
    jon "All I can say is that he was sort of adopted by my aunt and uncle."

    scene e4s1-05 with dissolve
    jon "And... as you probably have seen already, he's not very fond of me."
    jon "He despises me, he thinks I don't deserve the life I have."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "So... it all comes down to jealousy?"

    scene e4s1-05 with dissolve
    hide e4s1_jon_blink1
    jon "More or so... yeah."

    scene e4s1-07 with dissolve
    jon "I can't blame him, not because what he's saying is right, but because his life wasn't exactly great."

    scene e4s1-05 with dissolve
    jon "So, I just try to be empathetic."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Can't say the same about him."

    scene e4s1-07 with dissolve
    hide e4s1_jon_blink1
    jon "I try not to think about it too much."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "So, what happened to him moving away?"

    scene e4s1-05 with dissolve
    hide e4s1_jon_blink1
    jon "He actually ran away from home. He wanted to live life on his own terms."

    scene e4s1-07 with dissolve
    jon "Looks like college has brought us all together."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Wait, wait, wait..."
    mc "If you're his cousin... then who's his brother?"

    scene e4s1-04 with dissolve
    hide e4s1_jon_blink1
    jon "Brother? What are you talking about?"

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "I overheard [sp] in the library once."
    mc "He was talking about someone who lost something valuable to him."
    mc "At the time, I didn't think much of it."
    mc "But then he said something about [jd] hanging out with his brother, which made him unreliable."
    mc "It didn't make sense for you to be the brother, but now that you revealed to me that you're his cousin..."
    mc "Who is his brother?"

    scene e4s1-07 with dissolve
    hide e4s1_jon_blink1
    jon "Man, as far as I know, [sp] doesn't have a brother."

    scene e4s1-05 with dissolve
    jon "My aunt and uncle adopted him because they couldn't have kids."
    jon "If he had a brother, I've never heard a damn thing about it."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "So... maybe it's someone from before he was adopted?"

    scene e4s1-05 with dissolve
    hide e4s1_jon_blink1
    jon "Maybe. But if [sp] never mentioned him to me, there's probably a reason."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Right..."

    scene e4s1-09 with dissolve
    hide e4s1_jon_blink1
    jon "Also, why the hell did you not talk to me about it bro?"

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "I tried to, but every time I tried you turned me down, wanting to party instead."

    scene e4s1-10 with dissolve
    hide e4s1_jon_blink1
    jon "So I was a shithead after all, huh?"

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Yeah, I wasn't thinking straight either."
    mc "You know how I deal with betrayal..."
    mc "It's hard not to take it personal when the people you trust keep secrets."
    mc "That thing pretty much derailed the whole week for me."

    scene e4s1-05 with dissolve
    hide e4s1_jon_blink1
    jon "Yeah, I understand."

    scene e4s1-08 with dissolve
    jon "Learning that your friend secretly works behind your back with your arch-nemesis isn't a good feeling."

    scene e4s1-07 with dissolve
    jon "Anyways, leaving this aside..."

    scene e4s1-04 with dissolve
    jon "We've got some problems."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "What's up?"

    scene e4s1-04 with dissolve
    hide e4s1_jon_blink1
    jon "Some private investigator at Eddy's discovered something."

    scene e4s1-05 with dissolve
    jon "But if word got out, this is something that would probably put [jd] six feet under."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "They found drugs?"

    scene e4s1-07 with dissolve
    hide e4s1_jon_blink1
    jon "Yeah... weed."

    scene e4s1-05 with dissolve
    jon "All the signs point towards Jordan but what if there was someone else?"

    scene e4s1-08 with dissolve
    jon "I know he's got all the reasons to look guilty and all..."
    jon "But I feel like they're making it too obvious."
    jon "It's like they're looking for a scapegoat."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "Wait, but did you know he was smoking weed?"

    scene e4s1-05 with dissolve
    hide e4s1_jon_blink1
    jon "Yeah bro, who doesn't?"

    scene e4s1-11 with dissolve
    jon "Have you seen the guy? His face screams 'I'm a stoner'."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "So what are we gonna do about it?"

    scene e4s1-07 with dissolve
    hide e4s1_jon_blink1
    jon "Well... it's the only evidence we've got."
    jon "And something tells me that it's been purposefully planted there."

    scene e4s1-08 with dissolve
    jon "We'll have to wait and see what happens next."

    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "On another note, I've got some bad news myself."

    scene e4s1-09 with dissolve
    hide e4s1_jon_blink1
    jon "Oh, wonderful. Everything was going so well anyway, what's a little more bad news gonna do?"

    scene e4s1-06 with dissolve
    jon "What's up?"

    stop music fadeout 1.0
    scene e4s1-03 with dissolve
    show e4s1_jon_blink1
    mc "I think you'll probably want to discuss this with [sc] as well."

    play music rollin_at_5
    scene e4s1-12 with dissolve
    hide e4s1_jon_blink1
    sc "What do you mean [kv] wants to take control of the college clubs?"

    scene e4s1-13 with dissolve
    show e4s1_scarlett_blink1
    mc "Dominate, rule over them, take over the world, how many more definitions do you need?"

    scene e4s1-14 with dissolve
    hide e4s1_scarlett_blink1
    sc "No, shithead!"
    sc "I mean, what's he actually planning? Does he want to abolish them or make a profit off them?"

    if affinity_spectrum > 0:
        scene e4s1-15 with dissolve
        mc "Oh sure, let me just go ask him about his exact plans."

        scene e4s1-16 with dissolve
        mc "How the fuck am I supposed to know?"
        mc "And how the fuck is that relevant anyway?"

    scene e4s1-13 with dissolve
    show e4s1_scarlett_blink1
    mc "Do you think he'd really include whatever plans he has with them in his public speech?"
    mc "He just told people what they wanted to hear."

    scene e4s1-17 with dissolve
    hide e4s1_scarlett_blink1
    sc "You're useless."

    scene e4s1-18 with dissolve
    mc "So, what are we gonna do about them?"
    mc "We need to stop them, right?"

    scene e4s1-14 with dissolve
    sc "We?"
    sc "I'm not gonna get involved in this crap, I got better things to do."

    scene e4s1-19 with dissolve
    sc "You two are gonna take care of this."

    scene e4s1-13 with dissolve
    show e4s1_scarlett_blink1
    mc "Real helpful [sc]."

    scene e4s1-20 with dissolve
    hide e4s1_scarlett_blink1
    mc "Now that I think about it, why did we bring this up to her?"

    scene e4s1-21 with dissolve
    jon "Uh, dude?"
    jon "You're the one that came up with the idea."

    scene e4s1-22 with dissolve
    mc "Then stop me from making stupid decisions."

    scene e4s1-23 with dissolve
    jon "Who am I, your nanny?"
    jon "You're an adult for all I know."

    scene e4s1-24 with dissolve
    sc "If you don't have anything else for me, I'm gonna get going."

    scene e4s1-13 with dissolve
    show e4s1_scarlett_blink1
    menu:
        "Make a joke" if affinity_spectrum > 0:
            call extrovert_affinity_check from _call_extrovert_affinity_check_60
            call color_check from _call_color_check_116
            $ scarlett_trust += 1
            $ e4s1_joke = True
            mc "Yeah [sc], I got something else."

            scene e4s1-25 with dissolve
            hide e4s1_scarlett_blink1
            mc "It's right down here if you're interested."

            scene e4s1-26 with dissolve
            jon "Haha, nice one!"

            stop music
            scene e4s1-29 with vpunch
            play sound door_close
            pause

        "Keep quiet":
            call introvert_affinity_check from _call_introvert_affinity_check_52
            call color_check from _call_color_check_117
            mc "..."

            scene e4s1-27 with dissolve
            pause

            scene e4s1-28 with dissolve
            pause

            stop music fadeout 2.0
            scene e4s1-29 with dissolve
            play sound door_close
            pause

    jump e4s2
return
