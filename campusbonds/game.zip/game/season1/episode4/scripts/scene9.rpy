
# Scene 9 - No tears left to cry ###############################################

label e4s9:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s9-01 with Dissolve(2.0)
    pause

    scene e4s9-02 with dissolve
    "{i}Sobbing...{/i}"

    scene e4s9-03 with dissolve
    pause

    play music river_view
    scene e4s9-04 with dissolve
    if e2f2_tiffany_refuse == False:
        mc "[tf]?"

        scene e4s9-06 with dissolve
        tf "[mc]? What are you doing here?"

        scene e4s9-07 with dissolve
        mc "Are you crying?"

        scene e4s9-08 with dissolve
        tf "No."

        scene e4s9-09 with dissolve
        tf "..."

        scene e4s9-10 with dissolve
        tf "Yes..."

        scene e4s9-11 with dissolve
        mc "What's wrong?"

        scene e4s9-12 with dissolve
        hide e4s9_tiffany_blink1
        tf "It's... nothing."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "Come on, you can tell me."
        mc "Did something happen?"

        scene e4s9-13 with dissolve
        hide e4s9_tiffany_blink1
        tf "Yes and no."

        scene e4s9-16 with dissolve
        tf "I mean, it's not like someone close to me died or anything."

        scene e4s9-17 with dissolve
        tf "I've just been rejected by the third club in a row."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        if affinity_spectrum < 0:
            mc "Oh... I'm really sorry to hear that."

        mc "How did that happen?"

        scene e4s9-16 with dissolve
        hide e4s9_tiffany_blink1
        tf "I don't know, they just don't like me."

        scene e4s9-12 with dissolve
        tf "I don't get it. I don't know what I'm doing wrong."

        scene e4s9-16 with dissolve
        tf "They all give the same vague excuses, that the club's full, or that I don't meet the criteria, or something dumb like that."
        tf "But I know it's bullshit. I just know it."

        scene e4s9-17 with dissolve
        tf "I mean, if others got in, why not me?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "What clubs did you try?"

        scene e4s9-16 with dissolve
        hide e4s9_tiffany_blink1
        tf "One was called something like 'Fake it 'til you make it'."
        tf "It was about faking confidence and playing personas, but I don't know how to do that so I tried being myself."

        scene e4s9-12 with dissolve
        tf "But they didn't like it."

        scene e4s9-17 with dissolve
        tf "I even stayed up the night before rehearsing what to say... and they still turned me down."

        scene e4s9-13 with dissolve
        tf "Heck, even The Apology Club rejected me."

        scene e4s9-12 with dissolve
        tf "I thought college would be different."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        if affinity_spectrum < 0:
            mc "Honestly? That sounds like their loss."
            mc "You were just being real with them. Not everyone can do that."

        mc "Have you tried The Party Ragers?"

        if affinity_spectrum < 0:
            mc "Well... I mean, it's loud and kinda crazy, but maybe you'd surprise yourself?"

        scene e4s9-18 with dissolve
        hide e4s9_tiffany_blink1
        tf "The Party Ragers? Haha, not a chance."

        scene e4s9-12 with dissolve
        tf "If even the Apology Club doesn't want me, what makes you think they would?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "Well, I don't know a whole lot about the other clubs."
        mc "But one of my friends is in the Party Ragers, he helped me get in."
        mc "Maybe I can talk to him. Maybe we can figure something out for you too."

        scene e4s9-13 with dissolve
        hide e4s9_tiffany_blink1
        tf "What if they hate me too?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "They won't."
        mc "The guys there are actually pretty chill."

        if introvert > extrovert:
            mc "Even someone like me who's more on the introverted side made it there."

        scene e4s9-18 with dissolve
        hide e4s9_tiffany_blink1
        tf "You're sure about this?"

        scene e4s9-19 with dissolve
        mc "Yeah, why not?"
        mc "One more member can't hurt."

        scene e4s9-16 with dissolve
        tf "Okay..."
        tf "Maybe one more try won't hurt."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        menu:
            "Invite her tonight":
                $ tiffany_trust += 1
                mc "I was just on my way to their place now."

                scene e4s9-24 with dissolve
                hide e4s9_tiffany_blink1
                mc "If you'd like we could go together, introduce you to the people there."

                scene e4s9-18 with dissolve
                tf "Tonight? Holy shit."
                tf "I don't know if I can..."

                scene e4s9-19 with dissolve
                mc "No pressure, the choice is yours."

                scene e4s9-31 with dissolve
                tf "..."

                scene e4s9-20 with dissolve
                tf "Thank you for the offer [mc], but I think I'll pass."

                scene e4s9-12 with dissolve
                tf "I don't think I'm in the right state of mind tonight."

                scene e4s9-21 with dissolve
                mc "No worries, if you change your mind I'll be here."

            "Leave it for another time":
                mc "Yeah..."

        scene e4s9-20 with dissolve
        tf "Thank you for listening to me."
    else:
        mc "Uh... hey?"

        scene e4s9-05 with dissolve
        mc "Are you okay?"

        scene e4s9-06 with dissolve
        unknown "Huh?"

        scene e4s9-14 with dissolve
        mc "I heard you crying... Just wanted to check if you're alright."

        scene e4s9-15 with dissolve
        unknown "Yeah... sorry."

        scene e4s9-08 with dissolve
        unknown "I'm not really okay at the moment."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "May I ask why?"

        scene e4s9-12 with dissolve
        hide e4s9_tiffany_blink1
        unknown "Do you actually want to know, or are you just being polite?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "Yeah, what's going on?"

        scene e4s9-11 with dissolve
        hide e4s9_tiffany_blink1
        if affinity_spectrum > 0:
            mc "I don't really know you... but maybe I can help you in some way."
        else:
            mc "Maybe I can help."

        scene e4s9-17 with dissolve
        unknown "I've just been rejected by the third club in a row."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        if affinity_spectrum < 0:
            mc "Oh... I'm really sorry to hear that."

        mc "How did that happen?"

        scene e4s9-16 with dissolve
        hide e4s9_tiffany_blink1
        unknown "I don't know, they just don't like me."

        scene e4s9-12 with dissolve
        unknown "I don't get it. I don't know what I'm doing wrong."

        scene e4s9-16 with dissolve
        unknown "They all give the same vague excuses, that the club's full, or that I don't meet the criteria, or something dumb like that."
        unknown "But I know it's bullshit. I just know it."

        scene e4s9-17 with dissolve
        unknown "I mean, if others got in, why not me?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "What clubs did you try?"

        scene e4s9-16 with dissolve
        hide e4s9_tiffany_blink1
        unknown "One was called something like 'Fake it 'til you make it'."
        unknown "It was about faking confidence and playing personas, but I don't know how to do that so I tried being myself."

        scene e4s9-12 with dissolve
        unknown "But they didn't like it."

        scene e4s9-17 with dissolve
        unknown "I even stayed up the night before rehearsing what to say... and they still turned me down."

        scene e4s9-13 with dissolve
        unknown "Heck, even The Apology Club rejected me."

        scene e4s9-12 with dissolve
        unknown "I thought college would be different."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        if affinity_spectrum < 0:
            mc "Honestly? That sounds like their loss."
            mc "You were just being real with them. Not everyone can do that."

        mc "Have you tried The Party Ragers?"

        if affinity_spectrum < 0:
            mc "Well... I mean, it's loud and kinda crazy, but maybe you'd surprise yourself?"

        scene e4s9-18 with dissolve
        hide e4s9_tiffany_blink1
        unknown "The Party Ragers? Haha, not a chance."

        scene e4s9-12 with dissolve
        unknown "If even the Apology Club doesn't want me, what makes you think they would?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "Well, I don't know a whole lot about the other clubs."
        mc "But one of my friends is in the Party Ragers, he helped me get in."
        mc "Maybe I can talk to him. Maybe we can figure something out for you too."

        scene e4s9-13 with dissolve
        hide e4s9_tiffany_blink1
        unknown "What if they hate me too?"

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        mc "They won't."
        mc "The guys there are actually pretty chill."

        if introvert > extrovert:
            mc "Even someone like me who's more on the introverted side made it there."

        scene e4s9-18 with dissolve
        hide e4s9_tiffany_blink1
        unknown "You're sure about this?"

        scene e4s9-19 with dissolve
        mc "Yeah, why not?"
        mc "One more member can't hurt."

        scene e4s9-16 with dissolve
        unknown "Okay..."
        unknown "Maybe one more try won't hurt."

        scene e4s9-09 with dissolve
        show e4s9_tiffany_blink1
        menu:
            "Invite her tonight":
                $ tiffany_trust += 1
                mc "I was just on my way to their place now."

                scene e4s9-24 with dissolve
                hide e4s9_tiffany_blink1
                mc "If you'd like we could go together, introduce you to the people there."

                scene e4s9-18 with dissolve
                unknown "Tonight? Holy shit."
                unknown "I don't know if I can..."

                scene e4s9-19 with dissolve
                mc "No pressure, the choice is yours."

                scene e4s9-31 with dissolve
                unknown "..."

                scene e4s9-20 with dissolve
                unknown "Thank you for the offer [mc], but I think I'll pass."

                scene e4s9-12 with dissolve
                unknown "I don't think I'm in the right state of mind tonight."

                scene e4s9-21 with dissolve
                mc "No worries, if you change your mind I'll be here."

            "Leave it for another time":
                mc "Yeah..."

        scene e4s9-20 with dissolve
        unknown "Thank you for listening to me."

        scene e4s9-22 with dissolve
        unknown "I didn't quite catch your name."

        scene e4s9-21 with dissolve
        mc "It's [mc]."

        scene e4s9-22 with dissolve
        unknown "Cool!"
        unknown "I'm [tf]."

        scene e4s9-21 with dissolve
        mc "Cool."

    scene e4s9-16 with dissolve
    tf "If you don't mind, I'd like to sit in silence for now."

    scene e4s9-29 with dissolve
    menu:
        "Stay with her" if e2f2_tiffany_refuse == False:
            $ e4s9_stay = True
            scene e4s9-24 with dissolve
            mc "I could sit in silence with you if that's alright."

            scene e4s9-13 with dissolve
            tf "You don't have to..."

            scene e4s9-09 with dissolve
            show e4s9_tiffany_blink1
            mc "You're right, I don't, but I'd like to."

            scene e4s9-18 with dissolve
            hide e4s9_tiffany_blink1
            tf "Thank you [mc]."

            scene e4s9-12 with dissolve
            tf "You don't know how much this means to me."

            scene e4s9-29 with dissolve
            menu:
                "Put your arm around her":
                    $ tiffany_trust += 1

                    scene e4s9-25 with dissolve
                    pause

                    scene e4s9-26 with dissolve
                    pause

                    scene e4s9-27 with dissolve
                    pause

                    scene e4s9-28 with dissolve
                    pause

                "Just sit":
                    mc "..."

            menu:
                "Talk about your past":
                    $ tiffany_trust += 1
                    $ e4s9_past = True
                    scene e4s9-37 with dissolve
                    mc "You know... I didn't belong either."

                    scene e4s9-18 with dissolve
                    tf "Huh?"

                    scene e4s9-19 with dissolve
                    mc "I had a tough childhood."

                    if introvert > extrovert:
                        mc "After my mom left, I became reserved, introverted."
                        mc "To a point where I was antisocial, I didn't like people."
                        mc "My dad tried his best but I didn't want to open up anymore."
                        mc "Thankfully I met my friend [jon], he helped me in my darkest times."
                        mc "He taught me how to fight."
                    else:
                        mc "After my mom left, I became impulsive."
                        mc "I was trying to cope with what happened."
                        mc "My dad wasn't helping either, he refused to talk about her and I started lashing out at other people."
                        mc "Thankfully, I met my friend [jon], he helped me in my darkest times."
                        mc "He helped me with self control, taught me how to fight and when to use the skills I learned."

                    mc "It gave me a purpose, I was deeply in love with it."
                    mc "But then, something else happened."
                    mc "I was a part of this tournament, one of the biggest junior tournaments in the city."

                    scene e4s9-32 with dissolve
                    mc "I got to the final, beating everyone."

                    scene e4s9-33 with dissolve
                    mc "I was deeply motivated, I wanted to win it."

                    if e2s0_fight == True:
                        scene e4s9-34 with dissolve
                        mc "I almost beat my last opponent."
                        mc "It was an easy fight."
                    else:
                        scene e4s9-19 with dissolve
                        mc "The last fight wasn't easy."
                        mc "I was on the losing side, I took some good blows."

                        scene e4s9-34 with dissolve
                        mc "But in the end, I took control of the fight."
                        mc "I almost won it."

                    scene e4s9-19 with dissolve
                    mc "Unfortunately, I was knocked out."

                    scene e4s9-35 with dissolve
                    mc "Illegal shot to the back of my head."

                    scene e4s9-36 with dissolve
                    mc "The referee hadn't even contested the shot, my opponent was declared the winner of the tournament."
                    mc "I was left unconscious, on the floor, I couldn't even breathe."

                    scene e4s9-37 with dissolve
                    mc "I woke up after a week, unable to talk, unable to walk, my life was taken away from me."

                    scene e4s9-18 with dissolve
                    tf "Oh my God..."
                    tf "I'm really sorry about that."

                    scene e4s9-19 with dissolve
                    mc "Yeah, after that I couldn't live a normal life in school."
                    mc "People were making fun of me, it took me a long time to be able to live a normal life again."
                    mc "But fortunately it's all in the past now, I try to see it as a chapter that shaped me."
                    mc "But what I'm trying to say is that, I get it, you know?"
                    mc "That feeling of giving everything you've got and still getting shut down."

                    scene e4s9-17 with dissolve
                    tf "Thank you for sharing that with me, seriously."
                    tf "I can't imagine how tough it must have been for you."

                    scene e4s9-09 with dissolve
                    show e4s9_tiffany_blink1
                    mc "It was, yeah."
                    mc "But I got over it with the help of others."
                    mc "So, let me help you as well."

                "Talk about a funny memory" if affinity_spectrum > 0:
                    $ tiffany_trust += 1
                    $ e4s9_memory = True
                    call extrovert_affinity_check from _call_extrovert_affinity_check_75
                    call color_check from _call_color_check_146

                    scene e4s9-37 with dissolve
                    mc "You know... I just remembered now."

                    scene e4s9-21 with dissolve
                    mc "There's this funny story with my dad."

                    if e4s4_hangout == True:
                        mc "Just to show he's not all bad."

                    mc "I got a skateboard for my eleventh birthday from [jon]."
                    mc "He was into that sort of stuff and wanted to convince me to join him as well."

                    scene e4s9-23 with dissolve
                    tf "Oh, a skateboard? That's so cool."
                    tf "I remember having one of those myself."

                    scene e4s9-21 with dissolve
                    mc "I admit it was a pretty cool gift, but I was just terrible at it."
                    mc "For the love of God my two feet couldn't be on that thing for more than 2 seconds."
                    mc "And I remember my dad seeing the struggles and thinking, 'is it really that bad?'"
                    mc "He then gets on the board, tries to skate and has the worst fall ever."
                    mc "Straight out of a cartoon."
                    mc "His left foot got into the paint bucket he had just freshly opened to finish the exterior of the house."
                    mc "While his right, still on the board, made him slide and fall."
                    mc "The bucket flew right onto his head... full of paint."
                    mc "He didn't even want to admit it until I was older."
                    mc "He felt so ashamed that day, swore he'd never set foot on another skating board ever again."

                    scene e4s9-23 with dissolve
                    tf "Haha, poor man."

                    scene e4s9-22 with dissolve
                    tf "Did you manage to learn to skate in the end?"

                    scene e4s9-21 with dissolve
                    mc "Nah, not really."
                    mc "I kind of dumped the whole idea."
                    mc "It's probably sitting somewhere in a drawer back home."
                    mc "[jon] had also quit by that time so I didn't have any reason to get back to it."

                    scene e4s9-22 with dissolve
                    tf "Yeah, it kind of went out of style at some point."
                    tf "I can't even remember when I quit skating."

                    scene e4s9-23 with dissolve
                    tf "It was so cool back then, I had the same problem as you, haha!"

                    scene e4s9-22 with dissolve
                    tf "I got pretty good at it, I felt so proud when I learned to slide on iron bars."

                    scene e4s9-12 with dissolve
                    tf "Although some of the falls were really not that pretty."

                    scene e4s9-22 with dissolve
                    tf "I had many scars but they eventually healed."

                    scene e4s9-21 with dissolve
                    mc "Haha, I'm glad!"

                "Just sit in silence":
                    call introvert_affinity_check from _call_introvert_affinity_check_67
                    call color_check from _call_color_check_147

                    mc "..."

            scene e4s9-29 with dissolve
            play sound phone_buzz
            pause

            scene e4s9-30 with dissolve
            pause

            scene e4s9-24 with dissolve
            mc "Sorry, I gotta take this."

            scene e4s9-20 with dissolve
            tf "It's okay, go ahead."

            scene e4s9-38 with dissolve
            jon "Yo bro, where you at?"

            scene e4s9-39 with dissolve
            mc "Sorry, I couldn't make it."

            scene e4s9-40 with dissolve
            jon "We really need you here, come on!"

            scene e4s9-41 with dissolve
            mc "I'm not sure I can make it tonight."

            scene e4s9-38 with dissolve
            jon "The fuck do you mean you can't?"
            jon "Not even for 5 minutes?"

            scene e4s9-42 with dissolve
            mc "5 minutes?"
            mc "Why am I even coming if it's only for 5 minutes?"

            scene e4s9-40 with dissolve
            jon "Just... get here!"

            scene e4s9-43 with dissolve
            mc "Guh..."

            scene e4s9-20 with dissolve
            tf "Maybe you should go."

            scene e4s9-21 with dissolve
            mc "Are you sure?"

            scene e4s9-20 with dissolve
            tf "Yeah, thank you for staying a bit longer with me."
            tf "I really appreciate it."
            tf "It sounds like they need you."

            scene e4s9-21 with dissolve
            if affinity_spectrum > 0:
                mc "Yeah, probably for some stupid shit again."
            else:
                mc "I don't know what for honestly."

            mc "But anyway, I'll get going now."

            scene e4s9-22 with dissolve
            tf "Alright, see you around!"

            scene e4s9-21 with dissolve
            mc "Bye!"

        "Go to the Party Ragers":
            scene e4s9-09 with dissolve
            show e4s9_tiffany_blink1
            mc "Alright [tf], I'll get going then."
            mc "We'll keep in touch, alright?"
            mc "Here's my number, I'll talk to the guys about you."

            scene e4s9-13 with dissolve
            hide e4s9_tiffany_blink1
            tf "Okay, thank you!"

            scene e4s9-16 with dissolve
            tf "I really mean it, you didn't have to do this."

            scene e4s9-13 with dissolve
            tf "Thanks for stopping by. Even if it was just for a minute... it helped."

            scene e4s9-09 with dissolve
            show e4s9_tiffany_blink1
            mc "It's alright, I like helping people."
            mc "Bye!"

            scene e4s9-13 with dissolve
            hide e4s9_tiffany_blink1
            tf "Bye [mc]."

    stop music fadeout 1.0
    scene e4s9-44 with dissolve
    pause

    jump e4s10
return
