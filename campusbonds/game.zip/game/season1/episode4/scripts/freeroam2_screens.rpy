
# Freeroam 2 screens ###########################################################

# Dance Floor ##################################################################
screen e4f2_dance_floor():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    if e4f2_strippers == False:
        if e4f2_ken == False:
            add "e4f2-01"
        else:
            add "e4f2-01_1"
    else:
        if e4f2_stripper1 == False:
            add "e4f2-01_2"
        else:
            add "e4f2-01_3"

    # Clickables
    if e4f2_candance == False and affinity_spectrum >= 0 and e4f2_strippers == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/candance_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/candance_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_candance")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_candance")

    if e4f2_stripper1 == False and e4f2_strippers == True:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/candance_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/candance_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_stripper1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_stripper1")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/dance_floor/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/dance_floor/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_vending")

    if e4f2_strippers == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/bar_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/bar_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_bar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_bar")
    else:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/bar2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/bar2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_bar")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_bar")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/dance_floor/staff_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/dance_floor/staff_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_staff")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_staff")

    # Collectibles
    if persistent.cl_gallery_13_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_13_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_13_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo13", True), Function(update_cleo_list)]

    if e4f2_money1 == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dance_floor/money_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dance_floor/money_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "money")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("money", money+1), Show("money_notify"), SetVariable("e4f2_money1", True)]

# Couch ########################################################################
screen e4f2_couch():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    if e3f3_help_mia == True:
        if e4f2_strippers == False:
            if e4f2_mia == False:
                add "e4f2-02"
            else:
                add "e4f2-02_1"
        else:
            if e4f2_stripper3 == False:
                add "e4f2-02_2"
            else:
                add "e4f2-02_1"
    else:
        if e4f2_strippers == False:
            add "e4f2-02_1"
        else:
            if e4f2_stripper3 == False:
                add "e4f2-02_2"
            else:
                add "e4f2-02_1"

    # Clickables
    if e4f2_mia == False and e3f3_help_mia == True and e4f2_strippers == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/couch/mia_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/couch/mia_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_mia")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_mia")

    if e4f2_strippers == True and e4f2_stripper3 == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/couch/stripper3_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/couch/stripper3_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_stripper3")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_stripper3")

    if e3f3_help_mia == True and e4f2_strippers == False:
        if e4f2_mia == True and e4f2_ken == True:
            imagebutton:
                idle im.Scale("season1/episode4/images/freeroam2/couch/couch_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode4/images/freeroam2/couch/couch_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e4f2_couch_clickable")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e4f2_couch_clickable")
    else:
        if e4f2_ken == True and e4f2_strippers == False:
            imagebutton:
                idle im.Scale("season1/episode4/images/freeroam2/couch/couch_idle.webp", 1920, 1080)
                hover im.Scale("season1/episode4/images/freeroam2/couch/couch_hover.webp", 1920, 1080)
                focus_mask True
                hovered SetVariable("screen_tooltip", "e4f2_couch_clickable")
                unhovered SetVariable("screen_tooltip", "")
                action Jump ("e4f2_couch_clickable")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/couch/dj_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/couch/dj_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_dj")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_dj")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/couch/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/couch/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_pool")

    # Collectibles
    if persistent.sc_gallery_12_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/couch/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/couch/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_12_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_12_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett12", True), Function(update_scarlett_list)]

# DJ ###########################################################################
screen e4f2_dj():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    add "e4f2-03"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/dj/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/dj/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_vending")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/dj/couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/dj/couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_couch")

    # Collectibles
    if persistent.tf_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/dj/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/dj/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_2_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany2", True), Function(update_tiffany_list)]

# Vending ######################################################################
screen e4f2_vending():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    if e4f2_strippers == False:
        add "e4f2-04"
    else:
        if e4f2_stripper4 == False:
            add "e4f2-04_2"
        else:
            add "e4f2-04_1"

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/vending/bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/vending/bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_bar")

    if e4f2_strippers == False or e4f2_stripper4 == True:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/vending/vending_table_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/vending/vending_table_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_vending_table")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_vending_table")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/vending/dj_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/vending/dj_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_dj")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_dj")

    # Clickables
    if e4f2_strippers == True and e4f2_stripper4 == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/vending/stripper4_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/vending/stripper4_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_stripper4")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_stripper4")

    # Collectibles
    if persistent.tr_gallery_13_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/vending/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/vending/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tr_gallery_13_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tr_gallery_13_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tracy13", True), Function(update_tracy_list)]

# Pool #########################################################################
screen e4f2_pool():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    if e4f2_strippers == False:
        if e4f2_ken == False:
            add "e4f2-05"
        else:
            add "e4f2-05_1"
    else:
        if e4f2_stripper2 == False:
            add "e4f2-05_2"
        else:
            add "e4f2-05_1"

    # Clickables
    if e4f2_ken == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/pool/ken_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/pool/ken_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_ken")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_ken")

    if e4f2_strippers == True and e4f2_stripper2 == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/pool/stripper2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/pool/stripper2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_stripper2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_stripper2")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/pool/couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/pool/couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_couch")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/pool/pool_couch_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/pool/pool_couch_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_pool_couch")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_pool_couch")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/pool/staff_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/pool/staff_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_staff")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_staff")

    # Collectibles
    if persistent.sc_gallery_13_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/pool/magazine1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/pool/magazine1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.sc_gallery_13_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.sc_gallery_13_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.scarlett13", True), Function(update_scarlett_list)]

    if persistent.tf_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/pool/magazine2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/pool/magazine2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.tf_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.tf_gallery_3_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.tiffany3", True), Function(update_tiffany_list)]

# Staff ########################################################################
screen e4f2_staff():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    add "e4f2-06"

    # Clickables
    if e4f2_stripper1 == True and e4f2_stripper2 == True and e4f2_stripper3 == True and e4f2_stripper4 == True:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/staff/bathroom_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/staff/bathroom_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_bathroom")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_bathroom")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/staff/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/staff/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_pool")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/staff/bar_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/staff/bar_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_bar")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_bar")

    # Collectibles
    if persistent.ev_gallery_2_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/staff/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/staff/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_2_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_2_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn2", True), Function(update_evelyn_list)]

# Bar ##########################################################################
screen e4f2_bar():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    if e4f2_strippers == False:
        add "e4f2-07"
    else:
        add "e4f2-07_1"

    # Clickables
    if e4f2_strippers == False and e4f2_scarlett == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/bar/scarlett_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/bar/scarlett_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_scarlett")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_scarlett")

    # Map
    if e4f2_strippers == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/bar/vending_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/bar/vending_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_vending")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_vending")
    else:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/bar/vending2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/bar/vending2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f2_vending")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f2_vending")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/bar/dance_floor_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/bar/dance_floor_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_dance_floor")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_dance_floor")

    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/bar/staff_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/bar/staff_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_staff")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_staff")

    # Collectibles
    if persistent.ev_gallery_3_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/bar/magazine1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/bar/magazine1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_3_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_3_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn3", True), Function(update_evelyn_list)]

    if persistent.ev_gallery_4_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/bar/magazine2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/bar/magazine2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.ev_gallery_4_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.ev_gallery_4_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.evelyn4", True), Function(update_evelyn_list)]

# Pool Couch ###################################################################
screen e4f2_pool_couch():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    add "e4f2-08"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/pool_couch/pool_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/pool_couch/pool_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_pool")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_pool")

    # Collectibles
    if persistent.fr_gallery_12_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/pool_couch/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/pool_couch/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_12_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_12_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca12", True), Function(update_francesca_list)]

# Vending Table ################################################################
screen e4f2_vending_table():

    $ renpy.random.shuffle(e4f2_tracks)
    modal True

    add "e4f2-09"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/freeroam2/vending_table/vending_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/freeroam2/vending_table/vending_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f2_vending")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f2_vending")

    # Collectibles
    if persistent.fr_gallery_13_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/freeroam2/vending_table/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/freeroam2/vending_table/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_13_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_13_unlocked", True), SetVariable("persistent.e4f2_collected_p", persistent.e4f2_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca13", True), Function(update_francesca_list)]
