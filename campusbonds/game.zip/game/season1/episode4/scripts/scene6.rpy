
# Scene 6 - Rager Trouble ######################################################

label e4s6:
    stop music fadeout 1.0
    scene e4s6-01 with wipeleft
    pause

    scene e4s6-02 with dissolve
    pause

    play music hi_as_hats
    scene e4s6-03 with dissolve
    play sound door_close
    pause

    scene e4s6-04 with dissolve
    pause

    if scarlett_trust > 2 or e4s3_kiss == True:
        scene e4s6-05 with dissolve
        sc "..."
    else:
        scene e4s6-06 with dissolve
        sc "*Oh great... not this prick again!*"

    scene e4s6-07 with dissolve
    mc "What's up [sc]?"

    scene e4s6-05 with dissolve
    sc "..."

    scene e4s6-08 with dissolve
    mc "Not much of a talker today, huh?"

    scene e4s6-09 with dissolve
    mc "Did you wake up on the wrong side of the bed?"

    if scarlett_trust > 2 or e4s3_kiss == True:
        scene e4s6-05 with dissolve
        sc "..."
    else:
        scene e4s6-06 with dissolve
        sc "..."

    scene e4s6-10 with dissolve
    sc "What do you want?"

    scene e4s6-11 with dissolve
    mc "Me? You're the one who just showed up, I was here before you."

    scene e4s6-12 with dissolve
    sc "So fucking what?"
    sc "It's my club!"

    scene e4s6-13 with dissolve
    pause

    scene e4s6-14 with dissolve
    mc "Alright, fair enough then."

    scene e4s6-15 with dissolve
    sc "What are you doing here?"

    scene e4s6-16 with dissolve
    show e4s6_scarlett_blink1
    mc "I'm supposed to meet [jon] but I don't know where he is."

    scene e4s6-17 with dissolve
    hide e4s6_scarlett_blink1
    sc "Okay."

    scene e4s6-16 with dissolve
    show e4s6_scarlett_blink1
    mc "..."
    mc "So like, do you ever have fun?"

    scene e4s6-17 with dissolve
    hide e4s6_scarlett_blink1
    sc "What do you mean?"

    scene e4s6-18 with dissolve
    mc "Like, at every party I went to, you were just sitting on your phone."
    mc "Are you antisocial or something?"

    scene e4s6-19 with dissolve
    sc "What's wrong with you?"

    scene e4s6-20 with dissolve
    if affinity_spectrum > 0:
        mc "No, like, not in a bad way, I'm just asking, you know?"
        mc "It comes from a place of worry, alright?"
    else:
        mc "Sorry, I didn't mean to be offensive."

    mc "I'm just trying to get to know you."

    scene e4s6-17 with dissolve
    sc "And why is that?"

    scene e4s6-18 with dissolve
    mc "If I'm gonna join this club then that means we'll see each other more than we'd like, right?"
    mc "Better learn to coexist."

    scene e4s6-21 with dissolve
    sc "Who says I'm letting you join this club?"

    scene e4s6-18 with dissolve
    mc "I mean, I'm already here, but whatever floats your boat."

    menu:
        "Ask about the kiss":
            $ e4s6_ask = True
            $ scarlett_trust += 1
            mc "So... about last night..."

            scene e4s6-19 with dissolve
            sc "What happened last night?"

            scene e4s6-20 with dissolve
            mc "Well... you were pretty drunk."
            mc "And, don't be annoyed, but..."

            scene e4s6-19 with dissolve
            sc "But what?"

            scene e4s6-24 with dissolve
            sc "Fucking tell me already."

            scene e4s6-20 with dissolve
            mc "Well, how do I put this..."
            mc "You... kinda kissed me."

            scene e4s6-21 with dissolve
            sc "Kissed? You?"
            sc "You must have been the one drunk, I don't recall doing anything like that."

            scene e4s6-22 with dissolve
            mc "*Yeah, she's not reacting well to this information.*"

            if e4s3_kiss == True:
                mc "*If I mention to her that she wanted to take my clothes off, she'd call me crazy.*"

            sc "Uh, hello?"

            scene e4s6-19 with dissolve
            sc "Are you still here?"

            scene e4s6-18 with dissolve
            mc "Yeah, what's up?"

            scene e4s6-24 with dissolve
            sc "You can't just tell me something like that and then shut up."

            scene e4s6-20 with dissolve
            mc "Why?"
            mc "Do you feel intimidated by that?"

            scene e4s6-21 with dissolve
            sc "Why would I be intimidated?"

            scene e4s6-18 with dissolve
            mc "I don't know, maybe you're scared to admit that you kissed me."

            scene e4s6-21 with dissolve
            sc "Scared of who? Of you?"

            scene e4s6-18 with dissolve
            mc "Of yourself."

            scene e4s6-17 with dissolve
            sc "I am not scared of myself."

            scene e4s6-16 with dissolve
            mc "Sure, whatever you say [sc]."

            scene e4s6-25 with dissolve
            sc "Guh...!"

        "Be quiet":
            scene e4s6-22 with dissolve
            mc "*...*"

    scene e4s6-24 with dissolve
    sc "Do you ever stop being annoying?"
    sc "You're like a 5-year-old in a candy shop."

    scene e4s6-23 with dissolve
    sc "Asking about this, asking about that."

    scene e4s6-24 with dissolve
    sc "Are you ever quiet?"

    scene e4s6-20 with dissolve
    mc "I can be quiet, yeah."
    mc "If that's what you want."

    stop music fadeout 1.0
    scene e4s6-25 with dissolve
    sc "Finally, a sign of intelligence in that head of yours."

    scene e4s6-26 with dissolve
    pause

    if affinity_spectrum > 0:
        play music milkshake
        scene e4s6-27 with dissolve
        pause

        scene e4s6-28 with dissolve
        pause

        scene e4s6-30 with dissolve
        pause

        scene e4s6-31 with dissolve
        mc "Come on [sc], dance a little!"
        mc "Stop being so moody all the time."

        scene e4s6-33 with dissolve
        sc "Dude, what the hell is wrong with you?"

        scene e4s6-32 with dissolve
        sc "Legit, it's only been 5 seconds, that's how long you can last?"

        menu:
            "Flirt with her":
                $ scarlett_trust += 1

                scene e4s6-31 with dissolve
                mc "I can {b}definitely{/b} last longer than 5 seconds."

                scene e4s6-33 with dissolve
                sc "Oh my fucking God..."

            "Don't push it":
                scene e4s6-34 with dissolve
                mc "Wow, harsh."
                mc "Remind me never to be on your bad side."

        scene e4s6-35 with dissolve
        sc "Just turn off the fucking music, I'm not in the mood."

        scene e4s6-36 with dissolve
        show e4s6_scarlett_blink2
        mc "Why not?"

        scene e4s6-37 with dissolve
        hide e4s6_scarlett_blink2
        sc "I'm just... not."

        scene e4s6-38 with dissolve
        sc "Plus, people are having classes now, we could get in trouble."

        scene e4s6-36 with dissolve
        show e4s6_scarlett_blink2
        mc "Trouble?"
        mc "I didn't know you were the careful type."

        scene e4s6-39 with dissolve
        hide e4s6_scarlett_blink2
        sc "Maybe I'm just looking out for my club?"

        scene e4s6-40 with dissolve
        sc "Gosh, you can be so irresponsible sometimes."

        scene e4s6-36 with dissolve
        show e4s6_scarlett_blink2
        menu:
            "Turn off the music":
                mc "Fine, if that's what you want."

                scene e4s6-40 with dissolve
                hide e4s6_scarlett_blink2
                sc "Finally."

                stop music fadeout 1.0
                scene e4s6-27 with dissolve
                pause

                scene e4s6-29 with dissolve
                pause

                scene e4s6-28 with dissolve
                pause

            "Let it play":
                $ scarlett_trust -= 1
                mc "You'll have to turn it off yourself because I'm not touching it."

                scene e4s6-41 with dissolve
                sc "Fine shithead, you want me to turn it off?"
                sc "I'll fucking do it."

                scene e4s6-42 with dissolve
                pause

                stop music fadeout 1.0
                scene e4s6-43 with dissolve
                pause

                scene e4s6-44 with dissolve
                sc "Now, stop bothering me and mind your own damn business."

                scene e4s6-45 with vpunch
                play sound punch
                pause

                scene e4s6-46 with dissolve
                pause

                scene e4s6-47 with dissolve
                mc "*Hard ass...*"

                scene e4s6-72 with dissolve
                pause

                scene e4s6-75 with dissolve
                pause

                scene e4s6-73 with dissolve
                pause

                scene e4s6-29 with dissolve
                pause

                scene e4s6-70 with dissolve
                jon "Uhh... is everything alright?"

                scene e4s6-71 with dissolve
                jon "I could feel the tension way before entering this room."

                scene e4s6-29 with dissolve
                sc "..."

                scene e4s6-70 with dissolve
                jon "Why do I get the feeling that you guys are mad at each other?"

                scene e4s6-74 with dissolve
                sc "I'm not mad at anybody, alright?"

                scene e4s6-70 with dissolve
                jon "Oookay...?"

            "Approach Scarlett":
                scene e4s6-48 with dissolve
                pause

                scene e4s6-49 with dissolve
                sc "What are you..."

                scene e4s6-50 with dissolve
                pause

                if scarlett_trust < 3:
                    scene e4s6-52 with vpunch
                    play sound slap
                    pause

                    scene e4s6-51 with dissolve
                    sc "Leave me the fuck alone, prick!"

                    scene e4s6-53 with dissolve
                    sc "What the hell's your problem?"
                    sc "Can't you see that I want to be left alone?"

                    scene e4s6-54 with dissolve
                    mc "Alright, sorry, jeez."

                    scene e4s6-46 with dissolve
                    menu:
                        "Talk back":
                            call extrovert_affinity_check from _call_extrovert_affinity_check_72
                            call color_check from _call_color_check_140
                            mc "Hard ass!"

                        "Keep it to yourself":
                            call introvert_affinity_check from _call_introvert_affinity_check_64
                            call color_check from _call_color_check_141
                            mc "*Hard ass...*"

                    scene e4s6-72 with dissolve
                    pause

                    scene e4s6-75 with dissolve
                    pause

                    scene e4s6-73 with dissolve
                    pause

                    scene e4s6-29 with dissolve
                    pause

                    scene e4s6-70 with dissolve
                    jon "Uhh... is everything alright?"

                    scene e4s6-71 with dissolve
                    jon "I could feel the tension way before entering this room."

                    scene e4s6-29 with dissolve
                    sc "..."

                    scene e4s6-70 with dissolve
                    jon "Why do I get the feeling that you guys are mad at each other?"

                    scene e4s6-74 with dissolve
                    sc "I'm not mad at anybody, alright?"

                    scene e4s6-70 with dissolve
                    jon "Oookay...?"
                else:
                    $ e4s6_scarlett_dance = True
                    $ scarlett_trust += 1

                    scene e4s6-62 with dissolve
                    pause

                    scene e4s6-55 with dissolve
                    mc "Hey, you're getting the rhythm!"

                    scene e4s6-56 with dissolve
                    sc "That's because you're making me dance, idiot!"

                    scene e4s6-57 with dissolve
                    mc "I'm not sensing much resistance on your part."

                    scene e4s6-58 with dissolve
                    mc "You could have stopped at any time, but you didn't."
                    mc "It seems to me like you're enjoying this."

                    scene e4s6-59 with dissolve
                    sc "It doesn't seem like I have much of a choice."

                    scene e4s6-58 with dissolve
                    mc "You really like playing hard to get, don't you?"

                    scene e4s6-60 with dissolve
                    sc "More like impossible to get, because me and you?"
                    sc "Never in a million years."
                    sc "I don't know what you're trying to do, but it's not it."

                    scene e4s6-63 with dissolve
                    mc "Sure [sc], keep talking while your feet are dancing."
                    mc "You're not fooling anyone."

                    scene e4s6-61 with dissolve
                    pause

                    scene e4s6-63 with dissolve
                    pause

                    scene e4s6-64 with dissolve
                    sc "What the..."

                    scene e4s6-65 with dissolve
                    sc "What are you doing?"

                    scene e4s6-63 with dissolve
                    mc "What does it look like?"

                    if e4s6_ask == True:
                        scene e4s6-60 with dissolve
                        sc "Even if the kiss from last night happened, it's the last one you'll get."

                    scene e4s6-66 with dissolve
                    jon "Uh... I-"
                    jon "Am I... interrupting something?"

                    scene e4s6-67 with vpunch
                    play sound woosh
                    pause

                    scene e4s6-69 with dissolve
                    jon "Do you want me to give you guys more time?"

                    scene e4s6-68 with dissolve
                    jon "I can come back later, don't worry."

                    scene e4s6-67 with dissolve
                    sc "No wonder you two braindeads are best friends."
    else:
        scene e4s6-72 with dissolve
        pause

        scene e4s6-75 with dissolve
        pause

        scene e4s6-73 with dissolve
        pause

        scene e4s6-29 with dissolve
        pause

        scene e4s6-70 with dissolve
        jon "Uhh... is everything alright?"

        scene e4s6-71 with dissolve
        jon "I could feel the tension way before entering this room."

        scene e4s6-29 with dissolve
        sc "..."

        scene e4s6-70 with dissolve
        jon "Why do I get the feeling that you guys are mad at each other?"

        scene e4s6-74 with dissolve
        sc "I'm not mad at anybody, alright?"

        scene e4s6-70 with dissolve
        jon "Oookay...?"

    play music dances_and_dames
    scene e4s6-76 with dissolve
    jon "Okay, now that you guys are both here, let's talk business."

    scene e4s6-77 with dissolve
    mc "What's up?"

    scene e4s6-79 with dissolve
    sc "Wait a minute, why does he have to be here?"
    sc "He's not even a part of this club yet."

    if affinity_spectrum > 0 and scarlett_trust > 2:
        scene e4s6-78 with dissolve
        mc "Yet..."
        mc "I like that!"

    scene e4s6-80 with dissolve
    jon "He's the one who discovered [kv]'s plan, right?"
    jon "That means he can help us."

    scene e4s6-81 with dissolve
    sc "I suppose you're right."

    scene e4s6-82 with dissolve
    jon "I found out that in a couple of weeks from now, there's gonna be the elections."
    jon "We have until then to stop him."

    scene e4s6-77 with dissolve
    mc "So, what are we gonna do?"

    scene e4s6-82 with dissolve
    jon "Right now?"
    jon "Not much we can do right now, I'll have to find his meeting schedules."

    scene e4s6-77 with dissolve
    mc "What for?"

    scene e4s6-83 with dissolve
    jon "Oh, you'll see!"

    scene e4s6-84 with dissolve
    jon "Now, I'd like to discuss that other problem."
    jon "The... uh, [jd] problem."

    scene e4s6-90 with dissolve
    sc "It doesn't concern us, he's not part of the club."

    scene e4s6-84 with dissolve
    jon "Normally, that would have been the case."

    scene e4s6-89 with dissolve
    jon "If they hadn't found weed in our club, which he used to attend."

    scene e4s6-85 with dissolve
    mc "Holy shit, what's gonna happen to him?"

    scene e4s6-86 with dissolve
    jon "Relax, it's not that big of a deal."
    jon "Worst case scenario, he gets expelled and our club gets disbanded."

    scene e4s6-87 with dissolve
    jon "But I doubt it will get to that."

    scene e4s6-88 with dissolve
    jon "We have to make sure he gets a tap on the shoulder at most, for the sake of us all."

    scene e4s6-85 with dissolve
    mc "I don't wanna be an asshole, but as [sc] said, what does he have to do with us?"
    mc "I mean, let's say they find him guilty and he gets expelled, what does it have to do with us?"

    scene e4s6-83 with dissolve
    jon "I'm glad you asked my friend."

    scene e4s6-82 with dissolve
    jon "We're directly responsible for our club."

    scene e4s6-89 with dissolve
    jon "Which means that if someone gets thrown under the bus, we all suffer."

    scene e4s6-88 with dissolve
    jon "Even if I were to consider leaving him hanging, he would drag us with him."

    scene e4s6-86 with dissolve
    jon "And unwillingly so, trust me I know him."

    scene e4s6-85 with dissolve
    menu:
        "Doubt him":
            $ e4s6_doubt = True
            mc "Yeah... I don't know about that."
            mc "The [sp] incident still leaves me in doubt."

            scene e4s6-86 with dissolve
            jon "It was just a mistake, I talked to him."
            jon "He wanted to get out but couldn't."

            scene e4s6-85 with dissolve
            mc "Didn't sound like that to me."
            mc "He sounded pretty excited when he found that other supply for [sp]."
            mc "But you know him better I guess, no point in arguing."

            scene e4s6-91 with dissolve
            sc "As much as I hate to agree with the scum, he has a point."

        "Trust him":
            mc "I guess you know him better."

    scene e4s6-92 with dissolve
    sc "Also, what was the deal with [jd] and [sp] anyway?"
    sc "I didn't think he'd stoop that low."

    scene e4s6-80 with dissolve
    jon "How many dealers are around anyway?"
    jon "I don't think he had much of a choice."

    scene e4s6-91 with dissolve
    sc "Fair enough."

    scene e4s6-85 with dissolve
    mc "So, still no news on who trashed Eddy's?"

    scene e4s6-86 with dissolve
    jon "Nope, the only thing they found is that small chunk of weed."

    scene e4s6-89 with dissolve
    jon "Which is a bit weird considering we weren't even there with weed that night."

    scene e4s6-85 with dissolve
    mc "Yeah... weird..."
    sc "Anyway, I'll have to get going."

    scene e4s6-92 with dissolve
    sc "Let me know if anything else pops up, alright?"

    scene e4s6-93 with dissolve
    jon "Sure."

    if e4s4_hangout == True:
        scene e4s6-77 with dissolve
        mc "Yeah, me too."
        mc "I'm having lunch with someone."

        scene e4s6-82 with dissolve
        jon "Alright, see you later then."
        jon "We'll keep in touch."

        jump e4s7
    else:
        jump e4s8
return
