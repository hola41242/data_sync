
# Variables

default e4f1_jon = False
default e4f1_tracy = False
default e4f1_sadie = False
default e4f1_lyla = False

# Freeroam Collected Photos #

default persistent.e4f1_collected_p = 0
default persistent.e4f1_collected_tp = 6

# Freeroam 1 ###################################################################
label e4f1:
    define e4f1_tracks = ["aces_high.ogg", "bad_sexy_dad_vibes.ogg", "breathe.ogg", "heartless_man.ogg", "hi_as_hats.ogg", "inertia.ogg", "invisible_light.ogg", "iwnlylmd.ogg", "marathon_man.ogg", "motown_rehearsal.ogg", "onfire.ogg", "pioneers.ogg", "pop_song.ogg", "tidalwave.ogg", "travel_light.ogg", "with_a_whimper.ogg", "wonder_under.ogg", "write_hear_right_now.ogg"]
    $ renpy.random.shuffle(e4f1_tracks)
    $ renpy.music.queue (e4f1_tracks, loop=True)

    scene e4f1-ly1_01 with dissolve
    unknown "Hello!"

    scene e4f1-ly1_02 with dissolve
    unknown "Do you have a partner?"

    scene e4f1-ly1_03 with dissolve
    menu:
        "Partner with her":
            $ lyla_trust += 2
            $ e4f1_lyla_partner = True
            mc "No... I haven't found anyone to pair with."

            scene e4f1-ly1_04 with dissolve
            unknown "Awesome! You can pair with me if you'd like."

            if affinity_spectrum > 0:
                scene e4f1-ly1_01 with dissolve
                mc "*It's not like I have anyone better anyway.*"
            else:
                scene e4f1-ly1_03 with dissolve
                mc "Sure."

            scene e4f1-ly1_02 with dissolve
            unknown "I'm [ly], by the way."

            scene e4f1-ly1_06 with dissolve
            ly "I'm really good at this subject!"

            scene e4f1-ly1_03 with dissolve
            mc "Good to know."
            mc "I'm [mc]."

            scene e4f1-ly1_04 with dissolve
            ly "Great! We're gonna have a lot of fun."

            if affinity_spectrum > 0:
                scene e4f1-ly1_01 with dissolve
                mc "*Yeah... I bet.*"

                scene e4f1-ly1_03 with dissolve
                mc "So... that means you'll do most of the work, right?"

                scene e4f1-ly1_05 with dissolve
                ly "Yeah, don't worry about it."

        "Partner with someone else":
            mc "Yeah, I was just on my way to them."

            if affinity_spectrum < 0:
                scene e4f1-ly1_07 with dissolve
                mc "Sorry!"

            scene e4f1-ly1_08 with dissolve
            ly "Oh... alright then."

            if affinity_spectrum > 0:
                scene e4f1-ly1_09 with dissolve
                pause
            else:
                scene e4f1-ly1_10 with dissolve
                pause

    if e4f1_lyla_partner == False:
        $ renpy.show_screen("questtracker_icon")

        $ renpy.block_rollback()

        $ current_quests.append("Find a partner.")

        scene e4f1-01 with dissolve
        call screen e4f1_jon
        hide e4f1-01
return

# Map ##########################################################################

# Jon ###
label e4f1_jon:
    scene e4f1-01
    call screen e4f1_jon with dissolve
return

label e4f1_jon_clickable:
    scene e4f1-jon_01 with dissolve
    mc "Yo, what's up, bro?"

    scene e4f1-jon_03 with dissolve
    jon "Hey, dude."

    scene e4f1-jon_04 with dissolve
    jon "Just talking to this chick here."

    scene e4f1-jon_05 with dissolve
    jon "I think we'll be partnering up."

    scene e4f1-jon_06 with dissolve
    jon "Did you find a partner yet?"

    scene e4f1-jon_02 with dissolve
    mc "No... I was on my way to find one."

    scene e4f1-jon_03 with dissolve
    jon "Oh, I see."

    scene e4f1-jon_04 with dissolve
    jon "Good luck with that!"

    scene e4f1-jon_03 with dissolve
    jon "The class is full of students, I'm sure you'll find someone."

    scene e4f1-jon_02 with dissolve
    if affinity_spectrum > 0:
        mc "For sure!"
    else:
        mc "Yeah, I guess so."

    $ e4f1_jon = True
    jump e4f1_jon
return

# Tracy Sadie ###
label e4f1_trsd:
    scene e4f1-02
    call screen e4f1_trsd with dissolve
return

label e4f1_tracy_clickable:
    $ e4f1_tracy = True

    scene e4f1-tr_01 with dissolve
    pause

    scene e4f1-tr_02 with dissolve
    mc "Hey [tr]!"

    scene e4f1-tr_04 with dissolve
    tr "Hey."

    scene e4f1-tr_03 with dissolve
    mc "Found a partner yet?"

    scene e4f1-tr_04 with dissolve
    tr "No, not really."

    if tracy_trust <= 6:
        scene e4f1-tr_05 with dissolve
        tr "I'm waiting for [sd] to show up, she went to the bathroom."

    scene e4f1-tr_03 with dissolve
    mc "You can pair up with me if you'd like."
    mc "I don't have a partner either."

    if e3s23_tracy_feelings == True:
        scene e4f1-tr_07 with dissolve
        tr "Sure [mc], I'll be your partner."

        scene e4f1-tr_03 with dissolve
        mc "Awesome!"
        mc "Now... do you have any idea how we're gonna go about this project?"

        scene e4f1-tr_05 with dissolve
        tr "Nope, not a single clue."

        scene e4f1-tr_03 with dissolve
        mc "We're cooked."

        if optional_quests:
            $ optional_quests.clear()
        if current_quests:
            $ current_quests.clear()

        $ renpy.hide_screen("questtracker_icon")

        $ e4f1_tracy_partner = True
    else:
        if tracy_trust > 3 and e3s23_sadie_feelings == False:
            scene e4f1-tr_08 with dissolve
            tr "I don't know... I was going to ask [sd] once she comes back from the bathroom."

            scene e4f1-tr_09 with dissolve
            tr "I want to partner with you, but what about her?"

            scene e4f1-tr_03 with dissolve
            menu:
                "Try to push it":
                    mc "I think she'll be fine."
                    mc "Worst case, she'll partner up with [br] if she can't find someone else."

                    if tracy_trust > 6:
                        scene e4f1-tr_07 with dissolve
                        tr "Yeah, you're right."
                        tr "Alright [mc], I'll partner with you."

                        scene e4f1-tr_03 with dissolve
                        mc "Great!"

                        if optional_quests:
                            $ optional_quests.clear()
                        if current_quests:
                            $ current_quests.clear()

                        $ renpy.hide_screen("questtracker_icon")

                        $ e4f1_tracy_partner = True
                    else:
                        if sadie_trust <= 6:
                            if e2s6_sadie_romance == False or e2s6_sadie_fwb == True:
                                $ e4f1_trsd_partners = True

                        scene e4f1-tr_05 with dissolve
                        tr "Yeah... I don't know."

                        scene e4f1-tr_09 with dissolve
                        tr "I'd like to partner with her for this one, I'm sorry."

                        scene e4f1-tr_03 with dissolve
                        mc "Alright, I understand."
                        mc "I'll go look for someone else."

                        scene e4f1-tr_08 with dissolve
                        tr "Thank you, good luck!"

                        scene e4f1-tr_03 with dissolve
                        mc "Thanks."

                        jump e4f1_trsd

                "Find another partner":
                    if sadie_trust <= 5:
                        if e2s6_sadie_romance == False or e2s6_sadie_fwb == True:
                            $ e4f1_trsd_partners = True

                    mc "I see, that's alright."
                    mc "I'll go look for someone else then."

                    scene e4f1-tr_09 with dissolve
                    tr "Alright, good luck!"

                    jump e4f1_trsd
        else:
            if sadie_trust <= 5:
                if e2s6_sadie_romance == False or e2s6_sadie_fwb == False:
                    $ e4f1_trsd_partners = True

            scene e4f1-tr_05 with dissolve
            tr "Sorry, I was going to ask [sd] once she comes back from the bathroom."

            scene e4f1-tr_06 with dissolve
            tr "Maybe some other time?"

            scene e4f1-tr_03 with dissolve
            mc "Alright."
            mc "I'll go look for someone else."

            scene e4f1-tr_04 with dissolve
            tr "Alright, good luck!"

            scene e4f1-tr_03 with dissolve
            mc "Thanks."

            jump e4f1_trsd
return

label e4f1_sadie_clickable:
    $ e4f1_sadie = True

    if e4f1_tracy == False:
        mc "*[sd] would be good to pair with.*"
        mc "*But I can't seem to find her.*"

        scene e4f1-sd_14 with dissolve
        pause

        scene e4f1-sd_15 with dissolve
        mc "Hey, [tr]!"

        scene e4f1-sd_16 with dissolve
        tr "Hello."

        scene e4f1-sd_17 with dissolve
        mc "What's up?"

        scene e4f1-sd_18 with dissolve
        tr "Waiting for [sd] to return from the bathroom."

        scene e4f1-sd_17 with dissolve
        mc "Oh, she went to the bathroom?"

        scene e4f1-sd_19 with dissolve
        tr "Yeah, were you looking for her?"

        scene e4f1-sd_17 with dissolve
        mc "Yeah, I wanted to partner with her."
        mc "Thanks for letting me know!"

        if e3s23_tracy_feelings == True:
            scene e4f1-sd_20 with dissolve
            tr "Oh... alright then."

            scene e4f1-sd_23 with dissolve
            pause
        else:
            scene e4f1-sd_21 with dissolve
            tr "Oh... alright then."

            scene e4f1-sd_22 with dissolve
            pause
    else:
        mc "*[tr] said [sd] went to the bathroom.*"
        mc "*Maybe I should wait for her to return.*"

    scene e4f1-sd_01 with dissolve
    pause

    scene e4f1-sd_07 with dissolve
    pause

    scene e4f1-sd_08 with dissolve
    pause

    scene e4f1-sd_09 with dissolve
    pause

    scene e4f1-sd_02 with dissolve
    play sound door_close
    pause

    scene e4f1-sd_03 with dissolve
    mc "Hey [sd]!"

    scene e4f1-sd_04 with dissolve
    sd "Hey, what's up?"

    scene e4f1-sd_03 with dissolve
    mc "So, [br] assigned us to work in pairs."
    mc "And I was going to ask you to be my partner."

    scene e4f1-sd_05 with dissolve
    sd "Be your partner?"

    if sadie_trust > 5:
        if e2s6_sadie_romance == True:
            $ e4f1_sadie_partner = True

            scene e4f1-sd_04 with dissolve
            sd "Sure [mc], I'd love to be your partner!"

            scene e4f1-sd_03 with dissolve
            mc "Awesome, we'll make such a good pair."

            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")
        elif e2s6_sadie_fwb == True and sadie_trust > 6:
            $ e4f1_sadie_partner = True

            scene e4f1-sd_04 with dissolve
            sd "Sure [mc], I'd love to be your partner!"

            scene e4f1-sd_03 with dissolve
            mc "Awesome, we'll make such a good pair."

            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")
        else:
            $ e4f1_trsd_partners = True

            scene e4f1-sd_06 with dissolve
            sd "I'd love that [mc], but I think I'm going to partner with [tr]."

            scene e4f1-sd_11 with dissolve
            sd "She's probably waiting for me."

            scene e4f1-sd_12 with dissolve
            sd "Sorry!"

            scene e4f1-sd_10 with dissolve
            mc "Oh, I understand..."
            mc "Alright then, I'll find someone else."

            scene e4f1-sd_11 with dissolve
            sd "Don't be upset, alright?"

            scene e4f1-sd_10 with dissolve
            mc "It's fine, don't worry, I'm not."

            scene e4f1-sd_04 with dissolve
            sd "Alright, thanks!"

            scene e4f1-sd_13 with dissolve
            pause

            jump e4f1_trsd
    else:
        $ e4f1_trsd_partners = True

        scene e4f1-sd_06 with dissolve
        sd "I'd love that [mc], but I think I'm going to partner with [tr]."

        scene e4f1-sd_11 with dissolve
        sd "She's probably waiting for me."

        scene e4f1-sd_12 with dissolve
        sd "Sorry!"

        scene e4f1-sd_10 with dissolve
        mc "Oh, I understand..."
        mc "Alright then, I'll find someone else."

        scene e4f1-sd_11 with dissolve
        sd "Don't be upset, alright?"

        scene e4f1-sd_10 with dissolve
        mc "It's fine, don't worry, I'm not."

        scene e4f1-sd_04 with dissolve
        sd "Alright, thanks!"

        scene e4f1-sd_13 with dissolve
        pause

        jump e4f1_trsd
return

# Bridget ###
label e4f1_bridget:
    scene e4f1-03
    call screen e4f1_bridget with dissolve
return

label e4f1_bridget_clickable:
    scene e4f1-br_01 with dissolve
    mc "Hey Bridget!"

    scene e4f1-br_02 with dissolve
    br "Hello [mc], have you found a partner yet?"

    scene e4f1-br_03 with dissolve
    mc "No... not really. Everyone else got snatched up fast."

    scene e4f1-br_04 with dissolve
    br "This class is full of students."

    scene e4f1-br_03 with dissolve
    mc "Yeah, and yet I'm the only one left standing."
    mc "Go figure."

    scene e4f1-br_05 with dissolve
    br "Well, that's unfortunate."

    scene e4f1-br_01 with dissolve
    mc "Would you like to be my partner?"

    scene e4f1-br_02 with dissolve
    br "I don't usually take part in these exercises."

    scene e4f1-br_03 with dissolve
    mc "Then this could be a first."
    mc "You might even enjoy it."

    scene e4f1-br_05 with dissolve
    br "If you really can't find anyone else... I suppose I could partner with you."
    br "But that doesn't mean I'll give you any unfair advantages."

    scene e4f1-br_01 with dissolve
    mc "Fine by me."

    if optional_quests:
        $ optional_quests.clear()
    if current_quests:
        $ current_quests.clear()

    $ renpy.hide_screen("questtracker_icon")

    $ e4f1_bridget_partner = True
return

# Corner ###
label e4f1_corner:
    scene e4f1-04
    call screen e4f1_corner with dissolve
return

# Lyla ###
label e4f1_lyla:
    scene e4f1-05
    call screen e4f1_lyla with dissolve
return

label e4f1_lyla_clickable:
    $ e4f1_lyla = True

    mc "*Looks like I have no one to pair with, huh?*"

    scene e4f1-ly2_01 with dissolve
    mc "Hey!"

    scene e4f1-ly2_02 with dissolve
    unknown "Hello!"

    scene e4f1-ly2_03 with dissolve
    mc "Did you find a partner yet?"

    scene e4f1-ly2_02 with dissolve
    unknown "No, not really."

    scene e4f1-ly2_04 with dissolve
    unknown "Everyone else seems to have found their pair already."

    scene e4f1-ly2_01 with dissolve
    mc "You can partner with me if you want."

    scene e4f1-ly2_05 with dissolve
    unknown "What happened to your partner?"

    scene e4f1-ly2_03 with dissolve
    menu:
        "Be honest":
            $ lyla_trust += 1
            mc "I didn't have a partner to begin with."
            mc "I thought I could pair with a friend."

            scene e4f1-ly2_04 with dissolve
            unknown "I understand."

            scene e4f1-ly2_06 with dissolve
            unknown "Well... I'm free!"

            scene e4f1-ly2_07 with dissolve
            mc "Great, then we'll partner up."

            scene e4f1-ly2_06 with dissolve
            unknown "Nice!"

        "Lie to her":
            mc "We just didn't work out."
            mc "So, do you want to be my partner or not?"

            scene e4f1-ly2_01 with dissolve
            unknown "Hm..."

            scene e4f1-ly2_06 with dissolve
            unknown "Alright, sure."

    scene e4f1-ly2_08 with dissolve
    unknown "I'm [ly]."

    scene e4f1-ly2_07 with dissolve
    mc "[mc]."

    scene e4f1-ly2_06 with dissolve
    ly "I'm really good at this subject!"

    scene e4f1-ly2_07 with dissolve
    mc "Good to know."

    scene e4f1-ly2_09 with dissolve
    ly "We're gonna have a lot of fun."

    if affinity_spectrum > 0:
        scene e4f1-ly2_07 with dissolve
        mc "*Yeah... I bet.*"
        mc "So... that means you'll do most of the work, right?"

        scene e4f1-ly2_10 with dissolve
        ly "Yeah, don't worry about it."

    if optional_quests:
        $ optional_quests.clear()
    if current_quests:
        $ current_quests.clear()

    $ renpy.hide_screen("questtracker_icon")

    $ e4f1_lyla_partner = True
return
