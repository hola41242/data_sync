
# Scene 12 - A new dynamic #####################################################

label e4s12:
    scene e4s12-01 with wipeleft
    pause

    play music college_rock
    scene e4s12-02 with vpunch
    play sound punch
    jon "What's up, bro?"

    scene e4s12-03 with dissolve
    menu:
        "Hit back":
            call extrovert_affinity_check from _call_extrovert_affinity_check_61
            call color_check from _call_color_check_118

            scene e4s12-05 with vpunch
            play sound punch
            pause

            scene e4s12-07 with dissolve
            jon "That all you got?"

            scene e4s12-08 with dissolve
            mc "Step into the ring and I'll show you what I got."

            scene e4s12-06 with dissolve
            jon "Chill, tough guy, I'm not looking for a fight."

        "Be hurt":
            call introvert_affinity_check from _call_introvert_affinity_check_53
            call color_check from _call_color_check_119

            scene e4s12-04 with dissolve
            mc "Ow, what the hell, man?"

            scene e4s12-09 with dissolve
            jon "Chill, dude, no need to be such a wuss."

    scene e4s12-10 with dissolve
    jon "Anyway, I wanted to talk about last night."

    scene e4s12-11 with dissolve
    mc "Yeah, what's up?"

    scene e4s12-13 with dissolve
    jon "We need a new plan."

    scene e4s12-15 with dissolve
    jon "Strippers, amazing idea, don't get me wrong, but not exactly practical long-term."

    scene e4s12-12 with dissolve
    jon "We need something else, someone from the inside."

    scene e4s12-11 with dissolve
    mc "Like what?"

    scene e4s12-14 with dissolve
    jon "A group of girls who'll actually party with us. Regulars. Not just one-offs."

    scene e4s12-10 with dissolve
    jon "We could still bring in strippers once in a while, but we need that consistent vibe."

    scene e4s12-15 with dissolve
    jon "How else are we gonna attract students?"

    scene e4s12-11 with dissolve
    mc "Didn't you say we couldn't hold parties anymore?"

    scene e4s12-10 with dissolve
    jon "Well... I hope this gets sorted out quick."

    scene e4s12-17 with dissolve
    jon "Maybe [sc] can pull some strings or something, we'll see."

    scene e4s12-10 with dissolve
    jon "For now, we only need to focus on bringing in girls."

    scene e4s12-11 with dissolve
    mc "You're right, but who?"

    if affinity_spectrum > 0:
        mc "I only know one group of girls, but I doubt they'd be interested."

    scene e4s12-16 with dissolve
    jon "I'm glad you asked that, my friend."

    scene e4s12-17 with dissolve
    jon "I heard the cheerleading squad isn't doing so hot lately. Budget's tight or something."

    scene e4s12-11 with dissolve
    mc "The cheerleaders?"
    mc "Isn't [tr] one of them now?"

    scene e4s12-10 with dissolve
    jon "She made the team?"

    scene e4s12-11 with dissolve
    mc "That's why I'm asking you."
    mc "I only know she took some kind of auditions."
    mc "But we haven't talked about it since then."

    scene e4s12-16 with dissolve
    jon "Only one way to find out."

    stop music
    scene e4s12-18 with wipeleft
    tr "No, absolutely not."

    play music punk_rock_holiday
    scene e4s12-19 with dissolve
    jon "Why not?"

    scene e4s12-20 with dissolve
    tr "I'm not going to ask the girls to be your personal eye candy."

    scene e4s12-21 with dissolve
    jon "No, no, no!"
    jon "I think you misunderstood me."

    scene e4s12-22 with dissolve
    jon "We just want them to hang out. You know, be part of the party scene."
    jon "What's a party without some chicks?"

    scene e4s12-23 with dissolve
    tr "Look, I get the idea. I really do."

    scene e4s12-24 with dissolve
    tr "But what makes you think they'd even listen to me?"

    scene e4s12-25 with dissolve
    tr "I just got in."

    scene e4s12-26 with dissolve
    jon "Yeah, but you've got more access than we do. That must count for something."

    scene e4s12-27 with dissolve
    menu:
        "Mock [jon]":
            call extrovert_affinity_check from _call_extrovert_affinity_check_62
            call color_check from _call_color_check_120
            $ tracy_trust += 1
            $ e4s12_mock = True
            mc "I never thought talking to girls would be a problem for you, bro!"

            scene e4s12-28 with dissolve
            mc "What's wrong, you scared?"

            scene e4s12-29 with dissolve
            jon "Dude, shut up."

            if e4s5_tracy_mad == False:
                scene e4s12-30 with dissolve
                tr "Haha!"

        "Stay quiet":
            call introvert_affinity_check from _call_introvert_affinity_check_54
            call color_check from _call_color_check_121

            mc "..."

    scene e4s12-26 with dissolve
    jon "Just present it as a business opportunity."
    jon "Easy money, cool vibe, exposure. What's not to like?"

    scene e4s12-23 with dissolve
    tr "Sorry, I can't do it."

    scene e4s12-18 with dissolve
    tr "You'll have to do it yourself."

    scene e4s12-31 with dissolve
    jon "Fuck, okay."

    scene e4s12-32 with dissolve
    jon "I'll go see who I can talk to."

    scene e4s12-33 with dissolve
    jon "[mc], you coming?"

    if e4s12_mock == True:
        scene e4s12-29 with dissolve
        jon "Actually, you know what?"
        jon "You can stay here, I'll go talk to the girls myself."

        scene e4s12-39 with dissolve
        pause

        if e4s5_tracy_mad == False:
            scene e4s12-30 with dissolve
            tr "Haha, looks like he really took it to heart, didn't he?"

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "Yeah... you're right."

            if e3s23_tracy_feelings == True or tracy_trust > 5:
                pass
            else:
                mc "Anyway, I'll go check up on him."

                scene e4s12-36 with dissolve
                hide e4s12_tracy_blink1
                tr "Alright, good luck."

                scene e4s12-35 with dissolve
                show e4s12_tracy_blink1
                mc "Thanks!"

                scene e4s12-41 with dissolve
                hide e4s12_tracy_blink1
                pause
    else:
        if e3s23_tracy_feelings == True or tracy_trust > 5:
            if e4s5_tracy_mad == False:
                scene e4s12-34 with dissolve
                mc "You go ahead, I'll catch up in a bit."

                scene e4s12-39 with dissolve
                pause

                scene e4s12-35 with dissolve
            else:
                scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
        else:
            scene e4s12-34 with dissolve
            mc "Yeah, sure."

            scene e4s12-40 with dissolve
            pause

    if e3s23_tracy_feelings == True or tracy_trust > 5:
        if e4s5_tracy_mad == False:
            mc "So, the cheerleaders, huh?"

            scene e4s12-38 with dissolve
            hide e4s12_tracy_blink1
            tr "Yeah, right?"
            tr "I finally got in."

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "You didn't like the Party Ragers?"

            scene e4s12-38 with dissolve
            hide e4s12_tracy_blink1
            tr "It's not that, I still love those parties."

            scene e4s12-37 with dissolve
            tr "That's one of the reasons why I think this deal would be great."

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "Oh yeah? What are the other reasons, then?"
            mc "Anyone... someone in particular?"

            scene e4s12-30 with dissolve
            hide e4s12_tracy_blink1
            tr "It seems to me like someone's horny!"

            scene e4s12-38 with dissolve
            tr "In a place full of girls like this, I'm not surprised."

            scene e4s12-30 with dissolve
            tr "It seems to me like you'd benefit greatly from this deal as well, haha!"

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "Haha, it's not like that."
            mc "I'm just trying to help [jon]."
            mc "Although, having girls there is not a bad thing at all."

            scene e4s12-37 with dissolve
            hide e4s12_tracy_blink1
            tr "Some of them are smoking hot, I'm assuming that's a lot to handle."

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "Yeah, you could say that."
            mc "Let's see if he manages to get anything done."
            mc "Speaking of that, I better check up on him."

            scene e4s12-36 with dissolve
            hide e4s12_tracy_blink1
            tr "Alright, see you around!"
            tr "Don't screw it up."

            scene e4s12-35 with dissolve
            show e4s12_tracy_blink1
            mc "No promises."

            scene e4s12-41 with dissolve
            hide e4s12_tracy_blink1
            pause
        else:
            mc "Hey [tr]!"

            scene e4s12-81 with dissolve
            hide e4s12_tracy_blink1
            tr "Go away, [mc]!"
            tr "I don't want to talk to you."

            scene e4s12-82 with dissolve
            mc "But why? What's wrong?"

            scene e4s12-81 with dissolve
            tr "I'm just... not in the mood, alright?"
            tr "Can you leave me alone?"

            scene e4s12-82 with dissolve
            mc "Okay, okay..."

            scene e4s12-41 with dissolve
            pause

    scene e4s12-42 with dissolve
    pause

    if e4s12_mock == True or e3s23_tracy_feelings == True or tracy_trust > 5:
        scene e4s12-43 with dissolve
        jon "Hey, who can I talk to around here about a business proposal?"
    else:
        scene e4s12-44 with dissolve
        jon "Hey, who can I talk to around here about a business proposal?"

    if e4s5_tracy_mad == False:
        scene e4s12-45 with dissolve
        mc "Really, a business proposal?"

        scene e4s12-46 with dissolve
        mc "You make it sound like we're selling stocks."

        scene e4s12-47 with dissolve
        jon "Dude, shut up."
        jon "Don't fuck up my plans."

    scene e4s12-48 with dissolve
    unknown "Yeah, you can talk to [ci]."

    scene e4s12-49 with dissolve
    unknown "She's around here somewhere."

    scene e4s12-50 with dissolve
    jon "Okay, thanks!"

    scene e4s12-46 with dissolve
    mc "Wait, [ci]?"

    scene e4s12-51 with dissolve
    jon "You know her?"

    scene e4s12-46 with dissolve
    mc "You don't?"
    mc "She came to one of our parties."

    scene e4s12-53 with dissolve
    jon "Dude, I don't remember everyone."

    scene e4s12-52 with dissolve
    jon "She probably wasn't hot enough to stand out."

    scene e4s12-46 with dissolve
    mc "That's your metric for remembering people?"

    scene e4s12-53 with dissolve
    jon "How else would I do it?"

    scene e4s12-46 with dissolve
    mc "..."
    mc "Let's just find her."

    scene e4s12-54 with dissolve
    mc "I know what she looks like."

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s12-55 with Dissolve(2.0)
    mc "That's her, right there."

    scene e4s12-56 with dissolve
    jon "Huh?"
    jon "Are you sure she's been to one of our parties?"
    jon "She looks hot, there's no way I wouldn't have noticed her."

    scene e4s12-57 with dissolve
    mc "I don't know man, you must have been too drunk or something."

    play music breathe
    scene e4s12-58 with dissolve
    jon "Hey, [ci], right?"
    jon "I was told I could talk to you about a business proposal."

    scene e4s12-59 with dissolve
    ci "Yep, that's me."

    scene e4s12-60 with dissolve
    if e4s2_greet == True:
        mc "What's up?"

        scene e4s12-61 with dissolve
        ci "Hey!"
        ci "[mc], was it?"

        scene e4s12-60 with dissolve
        mc "Yeah, that's me."
        mc "Nice seeing you again."
    else:
        if affinity_spectrum > 0:
            mc "Remember me?"

            scene e4s12-72 with dissolve
            ci "Uh... no?"

            scene e4s12-61 with dissolve
            ci "Sorry, have we met before?"

            scene e4s12-60 with dissolve
            mc "Yeah, but we didn't talk a lot."

            scene e4s12-61 with dissolve
            ci "I must have been drunk then."
            ci "What's your name?"

            scene e4s12-60 with dissolve
            mc "It's [mc]."

    scene e4s12-59 with dissolve
    ci "So, what's this business proposal?"

    scene e4s12-62 with dissolve
    jon "We run a club called The Party Ragers."
    jon "And we're in need of some chicks to party with us."

    scene e4s12-63 with dissolve
    ci "Oh yeah! I remember that party."

    scene e4s12-64 with dissolve
    mc "See? Told you."

    scene e4s12-65 with dissolve
    jon "There's no way..."

    scene e4s12-63 with dissolve
    ci "Great place you got there, guys!"

    scene e4s12-62 with dissolve
    jon "Thanks!"

    scene e4s12-66 with dissolve
    jon "So... can you help us out?"

    scene e4s12-67 with dissolve
    ci "I wish."

    scene e4s12-68 with dissolve
    ci "I actually tried proposing something similar."
    ci "But our club president shot it down hard."

    scene e4s12-69 with dissolve
    jon "Wait, you're not the president?"

    scene e4s12-68 with dissolve
    ci "Nope, I'm the vice president."

    scene e4s12-70 with dissolve
    jon "Where is she, then?"

    scene e4s12-68 with dissolve
    ci "Not here, obviously."

    scene e4s12-73 with dissolve
    ci "She barely shows up."

    scene e4s12-72 with dissolve
    ci "Honestly, I don't even know why she's still in charge."

    scene e4s12-69 with dissolve
    jon "Couldn't you talk to her again?"

    scene e4s12-71 with dissolve
    ci "Dude, are you deaf?"
    ci "I already told you I tried it before and it didn't work."

    scene e4s12-74 with dissolve
    ci "As long as she's president, my hands are tied up."

    scene e4s12-75 with dissolve
    jon "Fuck..."

    scene e4s12-70 with dissolve
    jon "What if it's not official? Just a few girls dropping by sometimes?"

    scene e4s12-67 with dissolve
    ci "Yeah, she still doesn't approve it."
    ci "Still a no-go."

    scene e4s12-71 with dissolve
    ci "She made it clear: if we want to stay on the squad, no parties."

    scene e4s12-69 with dissolve
    jon "She sounds like the biggest pain in the ass."

    scene e4s12-72 with dissolve
    ci "Yeah, tell me about it."

    scene e4s12-71 with dissolve
    ci "I would have loved to help you guys, but it's not my call to make."

    scene e4s12-68 with dissolve
    ci "I'll keep trying to convince her though, maybe she softens up."

    scene e4s12-66 with dissolve
    jon "You'd do that?"

    scene e4s12-59 with dissolve
    ci "As long as you guys are gonna pay us, yeah, I'll do it."

    scene e4s12-62 with dissolve
    jon "Money's not an issue."

    scene e4s12-63 with dissolve
    ci "Great!"

    scene e4s12-66 with dissolve
    jon "Well, keep us posted, alright?"

    scene e4s12-62 with dissolve
    jon "We'll get going."

    scene e4s12-63 with dissolve
    ci "Sure, I'll let you know if anything changes."

    scene e4s12-66 with dissolve
    jon "Thanks!"

    scene e4s12-76 with wipeleft
    jon "What are you up to later?"

    scene e4s12-77 with dissolve
    mc "I'm gonna go to my usual classes."
    mc "Then I'll attend College Rock."

    scene e4s12-78 with dissolve
    jon "College Rock?"
    jon "What's that?"

    scene e4s12-79 with dissolve
    mc "A club."

    scene e4s12-80 with dissolve
    mc "It's a long story, I'll tell you on the way."
    jon "Damn, you wanted to replace us already?"

    if cleo_trust > 2 and e3s21_mad == False:
        if e3s10_cleo_hangout == False or e3s24_cleo_path == True:
            jump e4s13
        else:
            jump e4s14
    else:
        jump e4s14
return
