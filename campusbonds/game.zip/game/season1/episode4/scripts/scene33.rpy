
# Scene 33 - Getting ready #####################################################

label e4s33:
    $ e4s33_sadie_place = True
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s33-01 with Dissolve(2.0)
    play sound knock_knock
    pause

    scene e4s33-02 with dissolve
    sd "Come on in!"
    mc "Oh... okay."

    play music onfire
    scene e4s33-03 with dissolve
    mc "Wow, what happened here?"

    scene e4s33-04 with dissolve
    pause

    scene e4s33-05 with dissolve
    sd "I couldn't find anything to wear."

    if affinity_spectrum > 0:
        scene e4s33-06 with dissolve
        mc "I wouldn't mind seeing you naked."

        scene e4s33-05 with dissolve
        sd "Ha, ha, really funny."

    scene e4s33-07 with dissolve
    pause

    scene e4s33-08 with dissolve
    menu:
        "Whistle":
            call extrovert_affinity_check from _call_extrovert_affinity_check_70
            call color_check from _call_color_check_136

            scene e4s33-09 with dissolve
            play sound sexy_whistle
            mc "{i}Whistles.{/i}"

            scene e4s33-11 with dissolve
            sd "Come on..."
            sd "Don't make me laugh, you're gonna mess up my make up."

            scene e4s33-10 with dissolve
            mc "You're sexy, I can't help it."

            scene e4s33-12 with dissolve
            sd "How about you help me with something else then?"

            scene e4s33-10 with dissolve
            mc "What's up?"
        "Compliment her":
            call introvert_affinity_check from _call_introvert_affinity_check_62
            call color_check from _call_color_check_137

            scene e4s33-10 with dissolve
            mc "Wow... you look really pretty!"

            scene e4s33-13 with dissolve
            sd "Aw, thank you!"
            sd "You're really sweet when you're like this, you know?"

            scene e4s33-14 with dissolve
            sd "Although, I'm still not finished."

            scene e4s33-19 with dissolve
            pause

            scene e4s33-20 with dissolve
            pause

    scene e4s33-15 with dissolve
    sd "Could you help me with the dress?"

    scene e4s33-16 with dissolve
    if affinity_spectrum > 0:
        mc "I'm not sure I'm the best person to..."

        scene e4s33-18 with dissolve
        sd "Shut up and go get it!"

        scene e4s33-16 with dissolve
        mc "Got it!"
    else:
        mc "Sure, what do you need?"

    scene e4s33-17 with dissolve
    sd "It's sitting on the couch, a dark one, you should be able to see it easily."

    scene e4s33-16 with dissolve
    mc "Alright, let's have a look."

    scene e4s33-21 with dissolve
    pause

    scene e4s33-22 with dissolve
    pause

    $ GameRunning = True

    scene e4s33-23 with dissolve
    while GameRunning:
        menu:
            "Take pink dress" if e4s33_pink_dress == False:
                $ e4s33_pink_dress = True
                scene e4s33-24 with dissolve
                mc "Let's see if this is the right one."

                scene e4s33-26 with dissolve
                pause

                scene e4s33-25 with dissolve
                sd "Are you back with my dress?"

                scene e4s33-28 with dissolve
                mc "Yup, all ready to go!"

                scene e4s33-30 with dissolve
                sd "[mc], what's that?"
                sd "I said black, not pink."

                scene e4s33-31 with dissolve
                mc "I thought this one would suit you better."

                scene e4s33-30 with dissolve
                sd "Yeah, unfortunately there's a tear in the back. I'll have to go and get it fixed."

                scene e4s33-31 with dissolve
                mc "I understand."
                mc "I'll go and get your black dress."

                scene e4s33-25 with dissolve
                sd "Thanks!"

                scene e4s33-21 with dissolve
                pause

                scene e4s33-23 with dissolve
                pause
            "Take lingerie" if affinity_spectrum > 0 and e4s33_lingerie == False:
                $ e4s33_lingerie = True
                scene e4s33-24 with dissolve
                mc "This should be interesting."

                scene e4s33-26 with dissolve
                pause

                scene e4s33-25 with dissolve
                sd "Are you back with my dress?"

                scene e4s33-27 with dissolve
                mc "Yup, all ready to go!"

                scene e4s33-32 with dissolve
                sd "Really?"

                scene e4s33-33 with dissolve
                mc "You're really gonna blame me for wanting to see you in this?"

                scene e4s33-34 with dissolve
                sd "I guess not."

                if sadie_trust > 7:
                    scene e4s33-15 with dissolve
                    sd "I guess you do deserve a little reward."

                    scene e4s33-17 with dissolve
                    sd "Get out, let me change into it."
                    sd "You're lucky I like you."

                    scene e4s33-16 with dissolve
                    mc "Really?"

                    scene e4s33-18 with dissolve
                    sd "Go, before I change my mind! It's late already."

                    scene e4s33-21 with dissolve
                    mc "Alright, I'm gone!"

                    scene e4s33-22 with dissolve
                    pause

                    scene black with Dissolve(2.0)
                    pause(1.0)

                    scene e4s33-36 with Dissolve(2.0)
                    pause

                    scene e4s33-37 with dissolve
                    pause

                    scene e4s33-38 with dissolve
                    mc "Woah..."

                    scene e4s33-39 with dissolve
                    sd "Calm down, Romeo."
                    sd "We've got dinner first."

                    scene e4s33-38 with dissolve
                    mc "Spin around."

                    scene e4s33-40 with dissolve
                    sd "Come on, you're seriously gonna make me do a fashion show?"

                    scene e4s33-38 with dissolve
                    mc "What would be the point of you wearing the lingerie then?"

                    scene e4s33-41 with dissolve
                    sd "I don't know, maybe you taking it off?"
                    sd "I'm just saying..."

                    scene e4s33-38 with dissolve
                    mc "Hey can we skip the date?"
                    mc "I think we're gonna have more fun here at home."

                    scene e4s33-42 with dissolve
                    sd "Haha, nice try, it's gonna have to wait until after it."

                    scene e4s33-43 with dissolve
                    pause

                    scene e4s33-44 with dissolve
                    mc "I think I'm gonna pass out."

                    scene e4s33-42 with dissolve
                    sd "Alright, enough fun for you, I've got to get ready."

                    scene e4s33-45 with dissolve
                    mc "That's a bummer..."

                    $ GameRunning = False
                else:
                    scene e4s33-35 with dissolve
                    sd "Unfortunately, we don't have time for it now."
                    sd "Maybe I'll let you see it in the future."

                    scene e4s33-25 with dissolve
                    sd "For now, just go and bring me the black dress please."

                    scene e4s33-21 with dissolve
                    mc "Pfft, okay."

                    scene e4s33-23 with dissolve
                    pause
            "Take black dress":
                scene e4s33-24 with dissolve
                mc "She said black, so I guess this is the one."

                scene e4s33-26 with dissolve
                pause

                scene e4s33-25 with dissolve
                sd "Are you back with my dress?"

                scene e4s33-29 with dissolve
                mc "Yup, all ready to go!"

                scene e4s33-15 with dissolve
                sd "Thanks [mc]."

                scene e4s33-17 with dissolve
                sd "You can leave it here, I'll get dressed in a bit."

                scene e4s33-26 with dissolve
                mc "Want some help with that?"

                scene e4s33-46 with dissolve
                sd "Yeah, I don't trust you not to 'accidentally' tug the wrong way."

                scene e4s33-21 with dissolve
                mc "You got me on this one..."

                $ GameRunning = False

    stop music fadeout 1.0
    scene e4s33-36 with wipeleft
    pause

    play music satfes
    scene e4s33-37 with dissolve
    pause

    scene e4s33-47 with dissolve
    show e4s33_sadie_blink1
    mc "Wow..."
    mc "You look..."
    menu:
        "Stunning":
            $ sadie_trust += 1
            mc "You look stunning!"

            scene e4s33-48 with dissolve
            hide e4s33_sadie_blink1
            sd "Come on, it's not that big of a deal."

            scene e4s33-47 with dissolve
            show e4s33_sadie_blink1
            mc "No, really! I mean it."

            scene e4s33-49 with dissolve
            hide e4s33_sadie_blink1
            sd "Thank you!"
        "Classy":
            mc "You look classy."

            scene e4s33-51 with dissolve
            hide e4s33_sadie_blink1
            sd "Classy? I was going for a sexy look."

            scene e4s33-47 with dissolve
            show e4s33_sadie_blink1
            mc "Who says classy can't be sexy?"

            scene e4s33-48 with dissolve
            hide e4s33_sadie_blink1
            sd "You and your words..."
        "Nice":
            $ sadie_trust -= 1

            mc "You look nice!"

            scene e4s33-50 with dissolve
            hide e4s33_sadie_blink1
            sd "Thanks, I guess."

    if affinity_spectrum > 0:
        scene e4s33-47 with dissolve
        show e4s33_sadie_blink1
        mc "I'm looking forward to removing that dress once we get back home."

        scene e4s33-51 with dissolve
        hide e4s33_sadie_blink1
        sd "There it is, the [mc] I know."

        scene e4s33-47 with dissolve
        show e4s33_sadie_blink1
        mc "Haha, sorry!"
        mc "It's hard not to think about that when you look this good."

        scene e4s33-52 with dissolve
        hide e4s33_sadie_blink1
        sd "You'll get your piece, don't worry."

    scene e4s33-53 with dissolve
    sd "So, you ready to go?"

    scene e4s33-54 with dissolve
    mc "Yup, let's go!"

    scene e4s33-55 with dissolve
    pause

    jump e4s34
return
