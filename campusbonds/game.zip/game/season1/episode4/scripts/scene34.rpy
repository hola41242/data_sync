
# Scene 34 - A dinner out ######################################################

label e4s34:
    stop music fadeout 1.0
    scene e4s34-02 with wipeleft
    pause

    play music evening_jazz
    scene e4s34-01 with dissolve
    sd "So... here we are."
    sd "Which table is ours?"

    scene e4s34-03 with dissolve
    mc "I think it's that one."

    scene e4s34-04 with dissolve
    menu:
        "Pull her chair":
            $ sadie_trust += 1

            scene e4s34-06 with dissolve
            mc "Have a seat!"

            scene e4s34-07 with dissolve
            sd "Oh, what a gentleman!"

            scene e4s34-08 with dissolve
            mc "Of course, m'lady."
        "Let her do it":
            scene e4s34-05 with dissolve
            pause

    if affinity_spectrum < 0:
        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1
        mc "I've got to admit, I'm a bit nervous."

        scene e4s34-10 with dissolve
        hide e4s34_sadie_blink1
        sd "Haha, why?"

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "I don't think I ever went to any fancy restaurants."

    scene e4s34-11 with dissolve
    hide e4s34_sadie_blink1
    sd "Oh, don't worry, it's not a big deal."

    scene e4s34-12 with dissolve
    sd "Especially when you're with people you don't like."

    scene e4s34-13 with dissolve
    sd "But I think being with you is going to change my mind."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "Did anything happen?"

    scene e4s34-12 with dissolve
    hide e4s34_sadie_blink1
    sd "Just getting dragged by my parents in fancy locals like these."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "Oh, I should have made a reservation somewhere else."

    scene e4s34-14 with dissolve
    hide e4s34_sadie_blink1
    sd "No, it's fine, it's perfect"

    scene e4s34-15 with dissolve
    sd "It's a great opportunity to make something nice out of this."

    scene e4s34-13 with dissolve
    sd "Don't stress about it."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "So... what really happened back then?"
    mc "With your family and all, if you don't mind me asking."

    scene e4s34-12 with dissolve
    hide e4s34_sadie_blink1
    sd "Nothing terrible really, but it was just the thought that I was kind of forced to attend these gatherings."

    scene e4s34-16 with dissolve
    sd "Like, I wasn't really allowed to do anything."
    sd "All I wanted to do was to run around, do shit you know?"

    scene e4s34-12 with dissolve
    sd "I was an active kid and having to sit like that at a table was very frustrating."

    scene e4s34-11 with dissolve
    sd "Like most of the time it just felt boring, I didn't have anyone to spend my time with."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "Oh... I understand."
    mc "Do you feel like running around now?"
    mc "I won't stop you."

    scene e4s34-10 with dissolve
    hide e4s34_sadie_blink1
    sd "Haha, really funny."

    scene e4s34-17 with dissolve
    sd "Maybe if we run together I'll think about it."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "That would be a rather quick way to get kicked out, haha!"

    scene e4s34-18 with dissolve
    hide e4s34_sadie_blink1
    sd "You know what? We should totally do that if we don't like the food."

    if affinity_spectrum > 0:
        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1
        mc "Speaking of food, what would you like to order?"

        scene e4s34-10 with dissolve
        hide e4s34_sadie_blink1
        sd "Keeping up the gentleman persona tonight, huh?"

        scene e4s34-17 with dissolve
        sd "The grilled salmon looks interesting, I'll go with that."
    else:
        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1
        mc "Haha, totally!"

    scene e4s34-19 with dissolve
    hide e4s34_sadie_blink1
    wa "Welcome. I hope you're having a delightful evening."

    scene e4s34-20 with dissolve
    wa "Would you care to place your order now?"

    if affinity_spectrum > 0:
        scene e4s34-21 with dissolve
        mc "Hi, yes, we're ready."
    else:
        scene e4s34-21 with dissolve
        mc "Hi, yes."

    scene e4s34-22 with dissolve
    mc "I'll have the grilled ribeye with the roasted garlic mashed potatoes on the side."

    if e3s10_sadie_feet == True:
        $ persistent.e4s34_table_lewd = True
        call e4s34_table_lewd from _call_e4s34_table_lewd

        play music evening_jazz
    else:
        if affinity_spectrum > 0:
            mc "And for her, she'd like the grilled salmon with roasted vegetables."
        else:
            scene e4s34-20 with dissolve
            wa "And for the lady?"

            scene e4s34-28 with dissolve
            sd "I'd like to have the grilled salmon with roasted vegetables on the side."

        scene e4s34-19 with dissolve
        wa "May I start you off with something to drink?"

        scene e4s34-37 with dissolve
        mc "I'll do the orange juice."

        scene e4s34-28 with dissolve
        sd "And I'll have the same thing he's having."

        scene e4s34-20 with dissolve
        wa "Excellent choices. I'll get that started for you right away."

        scene e4s34-19 with dissolve
        wa "Please let me know if there's anything else you need in the meantime."

        scene e4s34-30 with dissolve
        pause

    scene e4s34-10 with dissolve
    sd "So... how are you enjoying it so far?"

    if e4s34_table_lewd == True and affinity_spectrum > 0:
        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1
        mc "What? The footjob?"
        mc "It was great, almost had me finish."
        mc "A solid 8/10."

        scene e4s34-38 with dissolve
        hide e4s34_sadie_blink1
        sd "No silly, I was talking about the place!"

        scene e4s34-39 with dissolve
        sd "Wait a minute, did you just say 8/10?"

        scene e4s34-40 with dissolve
        mc "Yeah... you kinda have to step up your game, you know?"
        mc "I mean, great all around yeah, but there's still room for improvement."

        scene e4s34-16 with dissolve
        sd "Yeah? Like what?"

        scene e4s34-40 with dissolve
        mc "I'm not telling you."
        mc "You'll have to figure that out on your own."

        scene e4s34-43 with dissolve
        sd "Fine Mr. Mysterious, keep it to yourself."

        scene e4s34-12 with dissolve
        sd "Didn't want the advice anyway."

        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1
        mc "Sour grapes, huh?"
        mc "Now... about the place."
    else:
        scene e4s34-09 with dissolve
        show e4s34_sadie_blink1

    mc "It's nice I'm not going to lie."
    mc "I'm excited about the food, I've been living on Dad's food for most of my life."

    scene e4s34-10 with dissolve
    hide e4s34_sadie_blink1
    sd "That's nice!"

    scene e4s34-17 with dissolve
    sd "The food is usually pretty great in places like this, I'll give them that."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "So... how's classes going for you?"

    scene e4s34-11 with dissolve
    hide e4s34_sadie_blink1
    sd "You really want to talk about college here?"

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "I was just trying to make small talk."

    scene e4s34-12 with dissolve
    hide e4s34_sadie_blink1
    sd "Well, let's talk about something else."

    scene e4s34-13 with dissolve
    sd "Like how that little trip of yours went back home."

    scene e4s34-09 with dissolve
    show e4s34_sadie_blink1
    mc "Oh yeah, that one."
    mc "Well... how do I start..."

    scene black with Dissolve(2.0)
    hide e4s34_sadie_blink1
    pause(1.0)

    scene e4s34-15 with Dissolve(2.0)
    sd "No way!"
    sd "All that happened in the span of two days?"

    scene e4s34-40 with dissolve
    mc "Yup, it hit me like a train."

    scene e4s34-41 with dissolve
    sd "Damn... I'm sorry to hear that."

    scene e4s34-42 with dissolve
    sd "So, it was your father, huh?"

    scene e4s34-40 with dissolve
    mc "Unfortunately, yeah..."
    mc "I'll have to see how I'm gonna deal with this."

    scene e4s34-42 with dissolve
    sd "You're gonna confront him?"

    scene e4s34-40 with dissolve
    mc "You think I should?"

    scene e4s34-16 with dissolve
    sd "Yeah, of course, you should ask him."

    scene e4s34-43 with dissolve
    sd "I sure as hell wouldn't be able to sleep at night with so many unanswered questions."

    scene e4s34-42 with dissolve
    sd "I think it'll give you closure and probably a chance to talk things over."
    sd "I've jumped the gun before, I know how it goes."

    scene e4s34-16 with dissolve
    sd "But after you calm down, maybe the best thing to do is to talk."
    sd "At least try to understand what happened."

    stop music fadeout 1.0
    scene e4s34-40 with dissolve
    mc "Yeah... I think you're right."

    if e3s10_sadie_feet == False or e4s34_sadie_refuse == False:
        $ e4s34_blowjob = True
        call e4s34_table_lewd from _call_e4s34_table_lewd_1

    play music orbiting_a_distant_planet
    scene e4s34-87 with wipeleft
    pause

    scene e4s34-89 with dissolve
    sd "Oh... that was really good."
    sd "I'm full!"

    scene e4s34-88 with dissolve
    mc "Yeah, for sure."
    mc "I didn't know steak could be so juicy until now."
    mc "My dad has always kind of made it dry."
    mc "I thought this was undercooked but it really tasted great."

    scene e4s34-90 with dissolve
    sd "Haha, yeah."

    scene e4s34-91 with dissolve
    sd "Told you the food is gonna be great."

    if e4s34_blowjob == True and affinity_spectrum > 0:
        scene e4s34-86 with dissolve
        show e4s34_sadie_blink1
        mc "As for the other services..."

        scene e4s34-90 with dissolve
        hide e4s34_sadie_blink1
        sd "Haha, you don't have to say anything, you're welcome!"

        scene e4s34-86 with dissolve
        show e4s34_sadie_blink1
        mc "Damn, you're amazing."

    scene e4s34-92 with dissolve
    hide e4s34_sadie_blink1
    sd "Anyway, I need to use the restroom."

    scene e4s34-91 with dissolve
    sd "Don't get into trouble while I'm gone."

    scene e4s34-86 with dissolve
    show e4s34_sadie_blink1
    mc "Into what more trouble could I possibly get already?"

    scene e4s34-90 with dissolve
    hide e4s34_sadie_blink1
    sd "Haha, that's why I like you."

    scene e4s34-93 with dissolve
    pause

    scene e4s34-94 with dissolve
    pause

    if e4s34_blowjob == True:
        scene e4s34-95 with dissolve
        mc "*Damn... tonight has been really great.*"
        mc "*So many things have happened.*"
        mc "*I can't believe [sd] just did that, haha!*"
        mc "*It was really hot, I'll give her that.*"
        mc "..."

        scene e4s34-96 with dissolve
        mc "*I wonder when she'll be back.*"

        scene e4s34-97 with dissolve
        pause

        if affinity_spectrum > 0:
            scene e4s34-95 with dissolve
            mc "*Hmm... this really got me thinking about something.*"
            mc "*She made me feel great from under the table.*"

            scene e4s34-96 with dissolve
            mc "*Maybe I should I give [sd] the same treatment she gave me.*"

            scene e4s34-97 with dissolve
            if e2s6_sadie_romance == True:
                menu:
                    "Follow her to the bathroom":
                        $ e4s34_bathroom_lewd = True

                        stop music fadeout 1.0
                        scene e4s34-96 with dissolve
                        mc "*Screw it, I'm walking up to her.*"
                        mc "*She's not the only one who can dominate.*"

                        call e4s34_bathroom_lewd from _call_e4s34_bathroom_lewd

                        stop music fadeout 1.0
                        scene e4s34-141 with dissolve
                        pause

                        scene e4s34-142 with dissolve
                        wa "I'm sorry, but you have to leave!"

                        scene e4s34-143 with dissolve
                        pause
                    "Wait for her":
                        scene e4s34-96 with dissolve
                        mc "..."

                        scene e4s34-95 with dissolve
                        mc "*Naah, let's wait for her here.*"
                        mc "*I won't fall for her trap.*"
            else:
                $ e4s34_bathroom_lewd = True

                stop music fadeout 1.0
                scene e4s34-96 with dissolve
                mc "*Screw it, I'm walking up to her.*"
                mc "*She's not the only one who can dominate.*"

                call e4s34_bathroom_lewd from _call_e4s34_bathroom_lewd_1

                stop music fadeout 1.0
                scene e4s34-141 with dissolve
                pause

                scene e4s34-142 with dissolve
                wa "I'm sorry, but you have to leave!"

                scene e4s34-143 with dissolve
                pause
    jump e4s35
return


label e4s34_table_lewd:
    if _in_replay:
        if persistent.e4s34_table_lewd == True:
            $ e3s10_sadie_feet = True
        $ e4s34_table_lewd = False

    # Footjob
    if e3s10_sadie_feet == True and e4s34_table_lewd == False:
        if _in_replay:
            scene e4s34-19 with dissolve
            wa "Welcome. I hope you're having a delightful evening."

            scene e4s34-20 with dissolve
            wa "Would you care to place your order now?"

            if affinity_spectrum > 0:
                scene e4s34-21 with dissolve
                mc "Hi, yes, we're ready."
            else:
                scene e4s34-21 with dissolve
                mc "Hi, yes."

            scene e4s34-22 with dissolve
            mc "I'll have the grilled ribeye with the roasted garlic mashed potatoes on the side."

        stop music fadeout 1.0
        scene e4s34-23 with dissolve
        mc "..."

        if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
            play music blues_of_t
            scene e4s34-24 with dissolve
            if persistent.disable_nsfw == True:
                if affinity_spectrum > 0:
                    mc "*Holy shit... what's she doing?*"

                    scene e4s34-26 with dissolve
                    pause

                    scene e4s34-25 with vpunch
                    pause

                    scene e4s34-19 with dissolve
                    wa "And for the lady?"

                    scene e4s34-27 with dissolve
                    mc "*Fuck...*"

                    scene e4s34-footjob5 with dissolve
                    mc "And for her, she'd... uh- like the grilled salmon with ah- roasted vegetables."
                else:
                    mc "*Ah... what's she doing?*"

                    scene e4s34-26 with dissolve
                    pause

                    scene e4s34-25 with vpunch
                    pause

                    scene e4s34-20 with dissolve
                    wa "And for the lady?"

                    scene e4s34-footjob5 with dissolve
                    sd "I'd like to have the grilled salmon, and could I also get a side of roasted vegetables?"

                scene e4s34-28 with dissolve
                sd "I've heard it's really good."

                scene e4s34-20 with dissolve
                wa "Indeed it is!"

                scene e4s34-footjob5 with dissolve
                wa "We take pride in every dish we serve, and our chef puts a lot of care into everything, especially the salmon."

                scene e4s34-28 with dissolve
                sd "Amazing!"

                scene e4s34-18 with dissolve
                sd "Isn't that so, darling?"

                scene e4s34-footjob5 with dissolve
                mc "*Oh my God...*"

                scene e4s34-29 with dissolve
                mc "Yup, really great!"

                scene e4s34-footjob6 with dissolve
                wa "May I start you off with something to drink?"

                scene e4s34-18 with dissolve
                sd "[mc]?"
                sd "Is there a drink you'd like to order?"

                scene e4s34-27 with dissolve
                mc "*Fuck...*"

                scene e4s34-29 with dissolve
                mc "I uh... yeah."
                mc "Sorry, I'm feeling a bit dizzy tonight."

                scene e4s34-19 with dissolve
                wa "No worries sir, take your time."

                scene e4s34-footjob7 with dissolve
                mc "Yeah, it's... a bit, overwhelming."

                scene e4s34-29 with dissolve
                mc "I'll do the... uh- I'll do just an orange juice."

                scene e4s34-20 with dissolve
                wa "Alright, and for the lady?"

                scene e4s34-footjob8 with dissolve
                sd "I'll have the same thing he's having."

                scene e4s34-19 with dissolve
                wa "Excellent choices. I'll get that started for you right away."

                scene e4s34-20 with dissolve
                wa "Please let me know if there's anything else you need in the meantime."

                scene e4s34-footjob9 with dissolve
                sd "Sure, do you need anything else, darling?"

                scene e4s34-29 with dissolve
                mc "No... I- I think we're good for now."

                scene e4s34-31 with dissolve
                pause

                scene e4s34-32 with dissolve
                pause

                scene e4s34-09 with dissolve
                show e4s34_sadie_blink1
                mc "What are you doing?!"

                scene e4s34-15 with dissolve
                hide e4s34_sadie_blink1
                sd "What?"
                sd "It was getting a bit boring."

                scene e4s34-12 with dissolve
                sd "You said if I wanted to run you'd let me."

                scene e4s34-13 with dissolve
                sd "Consider this running."

                scene e4s34-09 with dissolve
                show e4s34_sadie_blink1
                mc "Yeah, but it's not the same thing! We could get kicked out."

                scene e4s34-10 with dissolve
                hide e4s34_sadie_blink1
                sd "I seriously doubt they'd let us run around without any repercussions either, haha!"

                scene e4s34-11 with dissolve
                sd "Would you like me to stop?"

                scene e4s34-33 with dissolve
                if not _in_replay:
                    menu:
                        "Let it continue":
                            $ e4s34_table_lewd = True

                            if persistent.e4s34_sadie_refuse == True:
                                $ persistent.e4s34_sadie_refuse = False

                            mc "..."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Go on..."

                            scene e4s34-36 with dissolve
                            hide e4s34_sadie_blink1
                            sd "He folded under zero pressure, haha!"

                            scene e4s34-10 with dissolve
                            sd "Alright, let me work my magic!"

                            scene e4s34-33 with dissolve
                            sd "I don't want you to cum yet, we shouldn't leave any clues."

                            scene e4s34-footjob1 with dissolve
                            mc "Ahh... it will be oh- seriously hard to... not do that... when you're doing such ah- good job."

                            scene e4s34-10 with dissolve
                            sd "Haha, I love to hear you moan."

                            scene e4s34-footjob2 with dissolve
                            sd "It turns me on so badly."

                            scene e4s34-footjob1 with dissolve
                            mc "Does it uh- now?"

                            scene e4s34-18 with dissolve
                            sd "Careful, or I might take this even further."

                            scene e4s34-footjob2 with dissolve
                            mc "Oh, yeah? I'd ah- like to see you try."

                            scene e4s34-33 with dissolve
                            mc "Huh? Why'd you stop?"

                            scene e4s34-18 with dissolve
                            sd "Didn't know you wanted this so badly."

                            scene e4s34-33 with dissolve
                            mc "Now that you started..."
                            mc "Can you continue?"
                            sd "Alright darling, anything for you."

                            scene e4s34-footjob3 with dissolve
                            mc "Ah... you really know how to work your feet."

                            scene e4s34-footjob4 with dissolve
                            sd "I didn't know you were this much into them."

                            scene e4s34-footjob3 with dissolve
                            mc "Oh... Ahhh..."
                            mc "[sd]... I am going to-"

                            scene e4s34-34 with dissolve
                            mc "Ah... fuck."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Good call!"
                            mc "You almost had me busting."
                            mc "The euphoria still hasn't worn off..."

                            scene e4s34-10 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Haha, that's okay!"
                            sd "I'll let you recharge."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Damn, you know how to make me feel good."

                            scene e4s34-17 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Can't wait for you to do the same thing to me."

                            if affinity_spectrum > 0:
                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Wait, am I supposed to return the favor with my feet?"
                                mc "That's kinda hard, don't you think?"

                                scene e4s34-36 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Haha, no! Not so loud."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "I thought you didn't have a problem with having a public."
                                mc "Why the change of heart all of a sudden?"

                                scene e4s34-10 with dissolve
                                hide e4s34_sadie_blink1
                                sd "I hate you!"

                            if not _in_replay:
                                return
                        "Stop her":
                            $ e4s34_sadie_refuse = True

                            if persistent.e4s34_table_lewd == False:
                                $ persistent.e4s34_sadie_refuse = True
                            mc "Yeah... I think it's better if you stop."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "I don't want us to get kicked out."
                            mc "I'm sorry, it's not like I wouldn't want to."
                            mc "But let's not risk it all just for a bit of pleasure."

                            scene e4s34-13 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Alright, your call."

                            scene e4s34-33 with dissolve
                            pause

                            scene e4s34-34 with dissolve
                            pause

                            scene e4s34-35 with dissolve
                            pause

                            $ renpy.end_replay()

                            return
                else:
                    menu:
                        "Let it continue" if persistent.e4s34_sadie_refuse == False:
                            $ e4s34_table_lewd = True

                            if persistent.e4s34_sadie_refuse == True:
                                $ persistent.e4s34_sadie_refuse = False

                            mc "..."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Go on..."

                            scene e4s34-36 with dissolve
                            hide e4s34_sadie_blink1
                            sd "He folded under zero pressure, haha!"

                            scene e4s34-10 with dissolve
                            sd "Alright, let me work my magic!"

                            scene e4s34-33 with dissolve
                            sd "I don't want you to cum yet, we shouldn't leave any clues."

                            scene e4s34-footjob1 with dissolve
                            mc "Ahh... it will be oh- seriously hard to... not do that... when you're doing such ah- good job."

                            scene e4s34-10 with dissolve
                            sd "Haha, I love to hear you moan."

                            scene e4s34-footjob2 with dissolve
                            sd "It turns me on so badly."

                            scene e4s34-footjob1 with dissolve
                            mc "Does it uh- now?"

                            scene e4s34-18 with dissolve
                            sd "Careful, or I might take this even further."

                            scene e4s34-footjob2 with dissolve
                            mc "Oh, yeah? I'd ah- like to see you try."

                            scene e4s34-33 with dissolve
                            mc "Huh? Why'd you stop?"

                            scene e4s34-18 with dissolve
                            sd "Didn't know you wanted this so badly."

                            scene e4s34-33 with dissolve
                            mc "Now that you started..."
                            mc "Can you continue?"
                            sd "Alright darling, anything for you."

                            scene e4s34-footjob3 with dissolve
                            mc "Ah... you really know how to work your feet."

                            scene e4s34-footjob4 with dissolve
                            sd "I didn't know you were this much into them."

                            scene e4s34-footjob3 with dissolve
                            mc "Oh... Ahhh..."
                            mc "[sd]... I am going to-"

                            scene e4s34-34 with dissolve
                            mc "Ah... fuck."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Good call!"
                            mc "You almost had me busting."
                            mc "The euphoria still hasn't worn off..."

                            scene e4s34-10 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Haha, that's okay!"
                            sd "I'll let you recharge."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "Damn, you know how to make me feel good."

                            scene e4s34-17 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Can't wait for you to do the same thing to me."

                            if affinity_spectrum > 0:
                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Wait, am I supposed to return the favor with my feet?"
                                mc "That's kinda hard, don't you think?"

                                scene e4s34-36 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Haha, no! Not so loud."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "I thought you didn't have a problem with having a public."
                                mc "Why the change of heart all of a sudden?"

                                scene e4s34-10 with dissolve
                                hide e4s34_sadie_blink1
                                sd "I hate you!"

                        "Stop her" if persistent.e4s34_sadie_refuse == True:
                            $ e4s34_sadie_refuse = True

                            if persistent.e4s34_table_lewd == False:
                                $ persistent.e4s34_sadie_refuse = True

                            mc "Yeah... I think it's better if you stop."

                            scene e4s34-09 with dissolve
                            show e4s34_sadie_blink1
                            mc "I don't want us to get kicked out."
                            mc "I'm sorry, it's not like I wouldn't want to."
                            mc "But let's not risk it all just for a bit of pleasure."

                            scene e4s34-13 with dissolve
                            hide e4s34_sadie_blink1
                            sd "Alright, your call."

                            scene e4s34-33 with dissolve
                            pause

                            scene e4s34-34 with dissolve
                            pause

                            scene e4s34-35 with dissolve
                            pause

                            $ renpy.end_replay()

                            return
            else:
                if persistent.type_nsfw == False:
                    if affinity_spectrum > 0:
                        mc "*Holy shit... what's she doing?*"

                        scene e4s34-26 with dissolve
                        pause

                        scene e4s34-25 with vpunch
                        pause

                        scene e4s34-19 with dissolve
                        wa "And for the lady?"

                        scene e4s34-27 with dissolve
                        mc "*Fuck...*"

                        scene e4s34-footjob5_cen with dissolve
                        mc "And for her, she'd... uh- like the grilled salmon with ah- roasted vegetables."
                    else:
                        mc "*Ah... what's she doing?*"

                        scene e4s34-26 with dissolve
                        pause

                        scene e4s34-25 with vpunch
                        pause

                        scene e4s34-20 with dissolve
                        wa "And for the lady?"

                        scene e4s34-footjob5_cen with dissolve
                        sd "I'd like to have the grilled salmon, and could I also get a side of roasted vegetables?"

                    scene e4s34-28 with dissolve
                    sd "I've heard it's really good."

                    scene e4s34-20 with dissolve
                    wa "Indeed it is!"

                    scene e4s34-footjob5_cen with dissolve
                    wa "We take pride in every dish we serve, and our chef puts a lot of care into everything, especially the salmon."

                    scene e4s34-28 with dissolve
                    sd "Amazing!"

                    scene e4s34-18 with dissolve
                    sd "Isn't that so, darling?"

                    scene e4s34-footjob5_cen with dissolve
                    mc "*Oh my God...*"

                    scene e4s34-29 with dissolve
                    mc "Yup, really great!"

                    scene e4s34-footjob6_cen with dissolve
                    wa "May I start you off with something to drink?"

                    scene e4s34-18 with dissolve
                    sd "[mc]?"
                    sd "Is there a drink you'd like to order?"

                    scene e4s34-27 with dissolve
                    mc "*Fuck...*"

                    scene e4s34-29 with dissolve
                    mc "I uh... yeah."
                    mc "Sorry, I'm feeling a bit dizzy tonight."

                    scene e4s34-19 with dissolve
                    wa "No worries sir, take your time."

                    scene e4s34-footjob7_cen with dissolve
                    mc "Yeah, it's... a bit, overwhelming."

                    scene e4s34-29 with dissolve
                    mc "I'll do the... uh- I'll do just an orange juice."

                    scene e4s34-20 with dissolve
                    wa "Alright, and for the lady?"

                    scene e4s34-footjob8_cen with dissolve
                    sd "I'll have the same thing he's having."

                    scene e4s34-19 with dissolve
                    wa "Excellent choices. I'll get that started for you right away."

                    scene e4s34-20 with dissolve
                    wa "Please let me know if there's anything else you need in the meantime."

                    scene e4s34-footjob9_cen with dissolve
                    sd "Sure, do you need anything else, darling?"

                    scene e4s34-29 with dissolve
                    mc "No... I- I think we're good for now."

                    scene e4s34-31 with dissolve
                    pause

                    scene e4s34-32 with dissolve
                    pause

                    scene e4s34-09 with dissolve
                    show e4s34_sadie_blink1
                    mc "What are you doing?!"

                    scene e4s34-15 with dissolve
                    hide e4s34_sadie_blink1
                    sd "What?"
                    sd "It was getting a bit boring."

                    scene e4s34-12 with dissolve
                    sd "You said if I wanted to run you'd let me."

                    scene e4s34-13 with dissolve
                    sd "Consider this running."

                    scene e4s34-09 with dissolve
                    show e4s34_sadie_blink1
                    mc "Yeah, but it's not the same thing! We could get kicked out."

                    scene e4s34-10 with dissolve
                    hide e4s34_sadie_blink1
                    sd "I seriously doubt they'd let us run around without any repercussions either, haha!"

                    scene e4s34-11 with dissolve
                    sd "Would you like me to stop?"

                    scene e4s34-33_cen with dissolve
                    if not _in_replay:
                        menu:
                            "Let it continue":
                                $ e4s34_table_lewd = True
                                mc "..."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Go on..."

                                scene e4s34-36 with dissolve
                                hide e4s34_sadie_blink1
                                sd "He folded under zero pressure, haha!"

                                scene e4s34-10 with dissolve
                                sd "Alright, let me work my magic!"

                                scene e4s34-33_cen with dissolve
                                sd "I don't want you to cum yet, we shouldn't leave any clues."

                                scene e4s34-footjob1_cen with dissolve
                                mc "Ahh... it will be oh- seriously hard to... not do that... when you're doing such ah- good job."

                                scene e4s34-10 with dissolve
                                sd "Haha, I love to hear you moan."

                                scene e4s34-footjob2_cen with dissolve
                                sd "It turns me on so badly."

                                scene e4s34-footjob1_cen with dissolve
                                mc "Does it uh- now?"

                                scene e4s34-18 with dissolve
                                sd "Careful, or I might take this even further."

                                scene e4s34-footjob2_cen with dissolve
                                mc "Oh, yeah? I'd ah- like to see you try."

                                scene e4s34-33_cen with dissolve
                                mc "Huh? Why'd you stop?"

                                scene e4s34-18 with dissolve
                                sd "Didn't know you wanted this so badly."

                                scene e4s34-33_cen with dissolve
                                mc "Now that you started..."
                                mc "Can you continue?"
                                sd "Alright darling, anything for you."

                                scene e4s34-footjob3_cen with dissolve
                                mc "Ah... you really know how to work your feet."

                                scene e4s34-footjob4_cen with dissolve
                                sd "I didn't know you were this much into them."

                                scene e4s34-footjob3_cen with dissolve
                                mc "Oh... Ahhh..."
                                mc "[sd]... I am going to-"

                                scene e4s34-34_cen with dissolve
                                mc "Ah... fuck."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Good call!"
                                mc "You almost had me busting."
                                mc "The euphoria still hasn't worn off..."

                                scene e4s34-10 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Haha, that's okay!"
                                sd "I'll let you recharge."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Damn, you know how to make me feel good."

                                stop music fadeout 1.0
                                scene e4s34-17 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Can't wait for you to do the same thing to me."

                                if affinity_spectrum > 0:
                                    scene e4s34-09 with dissolve
                                    show e4s34_sadie_blink1
                                    mc "Wait, am I supposed to return the favor with my feet?"
                                    mc "That's kinda hard, don't you think?"

                                    scene e4s34-36 with dissolve
                                    hide e4s34_sadie_blink1
                                    sd "Haha, no! Not so loud."

                                    scene e4s34-09 with dissolve
                                    show e4s34_sadie_blink1
                                    mc "I thought you didn't have a problem with having a public."
                                    mc "Why the change of heart all of a sudden?"

                                    scene e4s34-10 with dissolve
                                    hide e4s34_sadie_blink1
                                    sd "I hate you!"

                                if not _in_replay:
                                    return
                            "Stop her":
                                $ e4s34_sadie_refuse = True
                                $ persistent.e4s34_sadie_refuse = True
                                mc "Yeah... I think it's better if you stop."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "I don't want us to get kicked out."
                                mc "I'm sorry, it's not like I wouldn't want to."
                                mc "But let's not risk it all just for a bit of pleasure."

                                scene e4s34-13 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Alright, your call."

                                scene e4s34-33_cen with dissolve
                                pause

                                scene e4s34-34_cen with dissolve
                                pause

                                stop music fadeout 1.0
                                scene e4s34-35 with dissolve
                                pause

                                $ renpy.end_replay()

                                return
                    else:
                        menu:
                            "Let it continue" if persistent.e4s34_sadie_refuse == False:
                                $ e4s34_table_lewd = True
                                mc "..."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Go on..."

                                scene e4s34-36 with dissolve
                                hide e4s34_sadie_blink1
                                sd "He folded under zero pressure, haha!"

                                scene e4s34-10 with dissolve
                                sd "Alright, let me work my magic!"

                                scene e4s34-33_cen with dissolve
                                sd "I don't want you to cum yet, we shouldn't leave any clues."

                                scene e4s34-footjob1_cen with dissolve
                                mc "Ahh... it will be oh- seriously hard to... not do that... when you're doing such ah- good job."

                                scene e4s34-10 with dissolve
                                sd "Haha, I love to hear you moan."

                                scene e4s34-footjob2_cen with dissolve
                                sd "It turns me on so badly."

                                scene e4s34-footjob1_cen with dissolve
                                mc "Does it uh- now?"

                                scene e4s34-18 with dissolve
                                sd "Careful, or I might take this even further."

                                scene e4s34-footjob2_cen with dissolve
                                mc "Oh, yeah? I'd ah- like to see you try."

                                scene e4s34-33_cen with dissolve
                                mc "Huh? Why'd you stop?"

                                scene e4s34-18 with dissolve
                                sd "Didn't know you wanted this so badly."

                                scene e4s34-33_cen with dissolve
                                mc "Now that you started..."
                                mc "Can you continue?"
                                sd "Alright darling, anything for you."

                                scene e4s34-footjob3_cen with dissolve
                                mc "Ah... you really know how to work your feet."

                                scene e4s34-footjob4_cen with dissolve
                                sd "I didn't know you were this much into them."

                                scene e4s34-footjob3_cen with dissolve
                                mc "Oh... Ahhh..."
                                mc "[sd]... I am going to-"

                                scene e4s34-34_cen with dissolve
                                mc "Ah... fuck."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Good call!"
                                mc "You almost had me busting."
                                mc "The euphoria still hasn't worn off..."

                                scene e4s34-10 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Haha, that's okay!"
                                sd "I'll let you recharge."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "Damn, you know how to make me feel good."

                                stop music fadeout 1.0
                                scene e4s34-17 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Can't wait for you to do the same thing to me."

                                if affinity_spectrum > 0:
                                    scene e4s34-09 with dissolve
                                    show e4s34_sadie_blink1
                                    mc "Wait, am I supposed to return the favor with my feet?"
                                    mc "That's kinda hard, don't you think?"

                                    scene e4s34-36 with dissolve
                                    hide e4s34_sadie_blink1
                                    sd "Haha, no! Not so loud."

                                    scene e4s34-09 with dissolve
                                    show e4s34_sadie_blink1
                                    mc "I thought you didn't have a problem with having a public."
                                    mc "Why the change of heart all of a sudden?"

                                    scene e4s34-10 with dissolve
                                    hide e4s34_sadie_blink1
                                    sd "I hate you!"

                            "Stop her" if persistent.e4s34_sadie_refuse == True:
                                $ e4s34_sadie_refuse = True
                                $ persistent.e4s34_sadie_refuse = True
                                mc "Yeah... I think it's better if you stop."

                                scene e4s34-09 with dissolve
                                show e4s34_sadie_blink1
                                mc "I don't want us to get kicked out."
                                mc "I'm sorry, it's not like I wouldn't want to."
                                mc "But let's not risk it all just for a bit of pleasure."

                                scene e4s34-13 with dissolve
                                hide e4s34_sadie_blink1
                                sd "Alright, your call."

                                scene e4s34-33_cen with dissolve
                                pause

                                scene e4s34-34_cen with dissolve
                                pause

                                stop music fadeout 1.0
                                scene e4s34-35 with dissolve
                                pause

                                $ renpy.end_replay()

                                return

    # Blowjob
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if _in_replay:
            scene e4s34-67 with wipeleft
            pause
        else:
            scene e4s34-67 with dissolve
            pause

        stop music fadeout 1.0
        scene e4s34-44 with dissolve
        pause

        play music inhale
        scene e4s34-45 with dissolve
        sd "Whoops! Dropped my fork."

        scene e4s34-46 with dissolve
        sd "Silly me, let me get it back."

        scene e4s34-47 with dissolve
        pause

        scene e4s34-48 with dissolve
        pause

        scene e4s34-49 with dissolve
        pause

        scene e4s34-50 with dissolve
        mc "*She's been under there for a bit, is she alright?*"

        scene e4s34-51 with dissolve
        mc "[sd]? Are you alright?"

        if persistent.disable_nsfw == True:
            scene e4s34-52 with vpunch
            mc "[sd]?!"
            mc "What are you doing under there?"

            scene e4s34-53 with dissolve
            sd "Just checking something out."

            scene e4s34-51 with dissolve
            mc "What are you checking?"

            if e4s34_table_lewd == False:
                mc "We're in public, what if someone catches us?"

                scene e4s34-54 with dissolve
                sd "I doubt that."
                sd "People are too full of themselves in places like this to notice."

                scene e4s34-53 with dissolve
                sd "We'll be fine."

                scene e4s34-51 with dissolve
                mc "Are you sure?"
                mc "I seriously don't wanna get kicked out."

                scene e4s34-56 with dissolve
                sd "We won't, don't worry."

                scene e4s34-57 with dissolve
                sd "If you're gonna keep quiet, we'll be just fine."
            else:
                scene e4s34-57 with dissolve
                sd "Wow, you're still hard!"

                scene e4s34-55 with dissolve
                mc "What? You wanna make me cum now?"

                scene e4s34-56 with dissolve
                sd "I'll just eat the evidence."

                scene e4s34-57 with dissolve
                sd "If you're gonna keep quiet, we'll be fine."

            scene e4s34-51 with dissolve
            mc "Keep quiet?"

            scene e4s34-58 with dissolve
            if affinity_spectrum > 0:
                mc "Fuuuck..."
            else:
                mc "Ohhh..."

            scene e4s34-blowjob1 with dissolve
            pause

            scene e4s34-56 with dissolve
            sd "Keep it to yourself, remember?"

            scene e4s34-55 with dissolve
            mc "I can't when it feels that good."

            scene e4s34-57 with dissolve
            sd "Don't flatter me, boy."

            scene e4s34-blowjob2 with dissolve
            pause

            scene e4s34-blowjob1 with dissolve
            if affinity_spectrum > 0:
                mc "*Holy shit, that feels so good!*"
                mc "*I remember she said we're gonna do crazy things, but I never expected this.*"
                mc "Ahh..."
            else:
                mc "*Damn, this girl is crazy!*"
                mc "*She is gonna get us kicked out.*"
                mc "*But it feels so good, ah...*"

            scene e4s34-59 with dissolve
            mc "*Oh... shit!*"
            mc "*Not a good time at all...*"

            scene e4s34-60 with dissolve
            pause

            scene e4s34-61 with dissolve
            pause

            scene e4s34-62 with dissolve
            pause

            scene e4s34-63 with vpunch
            pause

            scene e4s34-64 with dissolve
            wa "Here we are, your ribeye."

            scene e4s34-65 with dissolve
            mc "Th-thank you..."

            scene e4s34-68 with dissolve
            wa "My apologies, the salmon is taking just a moment longer to finish."

            scene e4s34-blowjob2 with dissolve
            wa "The kitchen's giving it a little extra care, and it should be out shortly."

            scene e4s34-66 with dissolve
            mc "Yeah... it's uh- it's... no problem."

            scene e4s34-blowjob1 with dissolve
            mc "My lady is... not here anyway!"

            scene e4s34-69 with dissolve
            wa "Would you like some fresh ground pepper with that?"

            scene e4s34-66 with dissolve
            mc "Uh... no, I'm good, thanks."

            scene e4s34-71 with dissolve
            wa "Do let me know if the temperature's right, sometimes the kitchen overshoots rare to medium rare depending on the cut, should be perfect though."

            scene e4s34-blowjob3 with dissolve
            mc "Yeah uh- will... will do!"

            scene e4s34-65 with dissolve
            mc "I'll... uh... let you know if ah- I need anything else."

            scene e4s34-70 with dissolve
            mc "*How long is this guy fucking staying?*"

            scene e4s34-71 with dissolve
            wa "Sure thing, sir!"
            wa "Enjoy your ribeye."

            scene e4s34-blowjob4 with dissolve
            wa "And please let the lady know it'll just be a bit longer for her salmon."

            scene e4s34-73 with dissolve
            mc "Yeah... yeah... will do!"

            scene e4s34-blowjob3 with dissolve
            wa "Are you visiting from out of town, or just enjoying a night out?"

            scene e4s34-65 with dissolve
            mc "No... uh- just enjoying a night out."

            scene e4s34-72 with dissolve
            wa "Oh! Almost forgot the steak knife. One moment."

            scene e4s34-70 with dissolve
            mc "*Fucking hell...*"

            scene e4s34-74 with dissolve
            mc "*At least he's gone for now.*"

            scene e4s34-56 with dissolve
            sd "How are you doing up there?"

            scene e4s34-55 with dissolve
            mc "I'm gonna cum very soon if you keep it-"

            scene e4s34-75 with dissolve
            pause

            scene e4s34-76 with dissolve
            wa "There we are."

            scene e4s34-77 with dissolve
            wa "Can't believe I almost let you use the butter knife on a ribeye!"

            scene e4s34-blowjob4 with dissolve
            mc "*Fuckk... I can't hold it anymore!*"

            scene e4s34-blowjob3 with dissolve
            mc "*What are you doing to me [sd]...*"
            mc "*Shit...*"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e4s34-78 with vpunch
            mc "Nghh!"

            scene e4s34-79 with dissolve
            wa "Are you alright, sir?"

            scene e4s34-80 with dissolve
            mc "Yeah, yeah..."
            mc "Thanks for everything, I will let you know if I need anything else."

            scene e4s34-81 with dissolve
            pause

            scene e4s34-60 with dissolve
            mc "*Oh my God...*"

            scene e4s34-83 with dissolve
            sd "You weren't lying, haha!"

            scene e4s34-82 with dissolve
            mc "You're gonna be the end of me, [sd]!"
            mc "But fuck, was that good..."

            scene e4s34-83 with dissolve
            sd "Haha, I can tell from the amount you shot out!"

            scene e4s34-84 with dissolve
            sd "I could barely swallow it all."

            scene e4s34-85 with dissolve
            sd "Damn, looks like I had my meal already, huh?"

            scene e4s34-82 with dissolve
            mc "You're crazy..."
            mc "I won't ever get tired of repeating that."

            scene e4s34-83 with dissolve
            sd "And I'll give you plenty of reasons to believe that, haha!"
        else:
            if persistent.type_nsfw == False:
                scene e4s34-52_cen with vpunch
                mc "[sd]?!"
                mc "What are you doing under there?"

                scene e4s34-53_cen with dissolve
                sd "Just checking something out."

                scene e4s34-51 with dissolve
                mc "What are you checking?"

                if e4s34_table_lewd == False:
                    mc "We're in public, what if someone catches us?"

                    scene e4s34-54_cen with dissolve
                    sd "I doubt that."
                    sd "People are too full of themselves in places like this to notice."

                    scene e4s34-53_cen with dissolve
                    sd "We'll be fine."

                    scene e4s34-51 with dissolve
                    mc "Are you sure?"
                    mc "I seriously don't wanna get kicked out."

                    scene e4s34-56_cen with dissolve
                    sd "We won't, don't worry."

                    scene e4s34-57_cen with dissolve
                    sd "If you're gonna keep quiet, we'll be just fine."
                else:
                    scene e4s34-57_cen with dissolve
                    sd "Wow, you're still hard!"

                    scene e4s34-55_cen with dissolve
                    mc "What? You wanna make me cum now?"

                    scene e4s34-56_cen with dissolve
                    sd "I'll just eat the evidence."

                    scene e4s34-57_cen with dissolve
                    sd "If you're gonna keep quiet, we'll be fine."

                scene e4s34-51 with dissolve
                mc "Keep quiet?"

                scene e4s34-58 with dissolve
                if affinity_spectrum > 0:
                    mc "Fuuuck..."
                else:
                    mc "Ohhh..."

                scene e4s34-blowjob1_cen with dissolve
                pause

                scene e4s34-56_cen with dissolve
                sd "Keep it to yourself, remember?"

                scene e4s34-55_cen with dissolve
                mc "I can't when it feels that good."

                scene e4s34-57_cen with dissolve
                sd "Don't flatter me, boy."

                scene e4s34-blowjob2_cen with dissolve
                pause

                scene e4s34-blowjob1_cen with dissolve
                if affinity_spectrum > 0:
                    mc "*Holy shit, that feels so good!*"
                    mc "*I remember she said we're gonna do crazy things, but I never expected this.*"
                    mc "Ahh..."
                else:
                    mc "*Damn, this girl is crazy!*"
                    mc "*She is gonna get us kicked out.*"
                    mc "*But it feels so good, ah...*"

                scene e4s34-59 with dissolve
                mc "*Oh... shit!*"
                mc "*Not a good time at all...*"

                scene e4s34-60 with dissolve
                pause

                scene e4s34-61 with dissolve
                pause

                scene e4s34-62_cen with dissolve
                pause

                scene e4s34-63_cen with vpunch
                pause

                scene e4s34-64 with dissolve
                wa "Here we are, your ribeye."

                scene e4s34-65 with dissolve
                mc "Th-thank you..."

                scene e4s34-68 with dissolve
                wa "My apologies, the salmon is taking just a moment longer to finish."

                scene e4s34-blowjob2_cen with dissolve
                wa "The kitchen's giving it a little extra care, and it should be out shortly."

                scene e4s34-66 with dissolve
                mc "Yeah... it's uh- it's... no problem."

                scene e4s34-blowjob1_cen with dissolve
                mc "My lady is... not here anyway!"

                scene e4s34-69 with dissolve
                wa "Would you like some fresh ground pepper with that?"

                scene e4s34-66 with dissolve
                mc "Uh... no, I'm good, thanks."

                scene e4s34-71 with dissolve
                wa "Do let me know if the temperature's right, sometimes the kitchen overshoots rare to medium rare depending on the cut, should be perfect though."

                scene e4s34-blowjob3_cen with dissolve
                mc "Yeah uh- will... will do!"

                scene e4s34-65 with dissolve
                mc "I'll... uh... let you know if ah- I need anything else."

                scene e4s34-70 with dissolve
                mc "*How long is this guy fucking staying?*"

                scene e4s34-71 with dissolve
                wa "Sure thing, sir!"
                wa "Enjoy your ribeye."

                scene e4s34-blowjob4_cen with dissolve
                wa "And please let the lady know it'll just be a bit longer for her salmon."

                scene e4s34-73 with dissolve
                mc "Yeah... yeah... will do!"

                scene e4s34-blowjob3_cen with dissolve
                wa "Are you visiting from out of town, or just enjoying a night out?"

                scene e4s34-65 with dissolve
                mc "No... uh- just enjoying a night out."

                scene e4s34-72 with dissolve
                wa "Oh! Almost forgot the steak knife. One moment."

                scene e4s34-70 with dissolve
                mc "*Fucking hell...*"

                scene e4s34-74 with dissolve
                mc "*At least he's gone for now.*"

                scene e4s34-56_cen with dissolve
                sd "How are you doing up there?"

                scene e4s34-55_cen with dissolve
                mc "I'm gonna cum very soon if you keep it-"

                scene e4s34-75 with dissolve
                pause

                scene e4s34-76 with dissolve
                wa "There we are."

                scene e4s34-77 with dissolve
                wa "Can't believe I almost let you use the butter knife on a ribeye!"

                scene e4s34-blowjob4_cen with dissolve
                mc "*Fuckk... I can't hold it anymore!*"

                scene e4s34-blowjob3_cen with dissolve
                mc "*What are you doing to me [sd]...*"
                mc "*Shit...*"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e4s34-78 with vpunch
                mc "Nghh!"

                scene e4s34-79 with dissolve
                wa "Are you alright, sir?"

                scene e4s34-80 with dissolve
                mc "Yeah, yeah..."
                mc "Thanks for everything, I will let you know if I need anything else."

                scene e4s34-81 with dissolve
                pause

                scene e4s34-60 with dissolve
                mc "*Oh my God...*"

                scene e4s34-83_cen with dissolve
                sd "You weren't lying, haha!"

                scene e4s34-82_cen with dissolve
                mc "You're gonna be the end of me, [sd]!"
                mc "But fuck, was that good..."

                scene e4s34-83_cen with dissolve
                sd "Haha, I can tell from the amount you shot out!"

                scene e4s34-84_cen with dissolve
                sd "I could barely swallow it all."

                scene e4s34-85_cen with dissolve
                sd "Damn, looks like I had my meal already, huh?"

                scene e4s34-82_cen with dissolve
                mc "You're crazy..."
                mc "I won't ever get tired of repeating that."

                scene e4s34-83_cen with dissolve
                sd "And I'll give you plenty of reasons to believe that, haha!"

    $ renpy.end_replay()
return


label e4s34_bathroom_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        play music heartache
        scene e4s34-98 with dissolve
        pause

        scene e4s34-99 with dissolve
        play sound door_open
        pause

        scene e4s34-100 with dissolve
        play sound door_close
        sd "[mc]?"

        scene e4s34-101 with dissolve
        sd "What are you doing here?"

        scene e4s34-102 with dissolve
        pause

        scene e4s34-missionary8 with dissolve
        pause

        scene e4s34-104 with dissolve
        sd "Wow..."

        scene e4s34-103 with dissolve
        mc "You can't tease me like that and expect it not to backfire."

        scene e4s34-105 with dissolve
        sd "We're gonna do it here?"
        sd "What if we get caught?"

        scene e4s34-106 with dissolve
        mc "I didn't hear you complain about risks when you got under the table."
        mc "I don't see why it would be an issue now."

        scene e4s34-107 with dissolve
        sd "Yeah, but it was different."

        scene e4s34-108 with dissolve
        sd "People can just walk in here."

        scene e4s34-106 with dissolve
        mc "Then, we better do it fast."
        mc "The more time we waste, the bigger the risk."

        scene e4s34-104 with dissolve
        sd "Fuck... just thinking about your dick inside of me makes me so wet."

        scene e4s34-108 with dissolve
        sd "Fine, hurry up!"

        scene e4s34-106 with dissolve
        mc "Say no more."

        scene e4s34-110 with dissolve
        pause

        if persistent.disable_nsfw == True:
            if e4s33_lingerie == True:
                scene e4s34-128 with dissolve
                pause

                scene e4s34-127 with dissolve
                mc "You haven't taken off the lingerie from back home?"

                scene e4s34-129 with dissolve
                sd "..."

                scene e4s34-130 with dissolve
                sd "Just shut up and put it in."

                scene e4s34-127 with dissolve
                mc "When were you gonna show me?"

                scene e4s34-131 with dissolve
                sd "Back home, obviously."
                sd "I wasn't gonna flash you in front of the whole world."

                scene e4s34-132 with dissolve
            else:
                scene e4s34-109 with dissolve
                pause

                scene e4s34-132 with dissolve
            menu:
                "Tease her":
                    scene e4s34-133 with dissolve
                    sd "Fuck..."

                    scene e4s34-132 with dissolve
                    sd "Stop teasing me and put it in already!"

                    scene e4s34-133 with dissolve
                    mc "Or what?"

                    scene e4s34-132 with dissolve
                    pause

                    scene e4s34-134 with vpunch
                    mc "Holy shit!"

                    scene e4s34-135 with dissolve
                    sd "If you don't wanna do it, I will."
                "Put it in":
                    scene e4s34-111 with dissolve
                    sd "Holy shit, I can't believe this is happening."

            # Doggy

            scene e4s34-doggy2 with dissolve
            sd "Oh my God..."

            scene e4s34-doggy1 with dissolve
            sd "It feels so good."

            scene e4s34-doggy2 with dissolve
            mc "Fuck [sd]..."

            scene e4s34-doggy1 with dissolve
            mc "Ah shit, you're so tight."

            scene e4s34-113 with dissolve
            sd "I've waited the whole night for this moment."

            scene e4s34-112 with dissolve
            sd "Fuck..."

            scene e4s34-114 with dissolve
            mc "Sounds to me like you were too scared to do it."

            scene e4s34-131 with dissolve
            sd "Scared?"

            scene e4s34-doggy3 with dissolve
            sd "I wasn't scared."
            mc "Sure you... ah... weren't."

            scene e4s34-114 with dissolve
            mc "Almost chickened out on me."

            scene e4s34-doggy4 with dissolve
            sd "Ah... oh..."

            scene e4s34-doggy3 with dissolve
            sd "Just... shut up and don't cum!"

            scene e4s34-113 with dissolve
            sd "I want to enjoy this."

            scene e4s34-doggy4 with dissolve
            pause

            scene e4s34-doggy3 with dissolve
            mc "I thought you wanted to be quick."
            mc "To not get caught."

            scene e4s34-115 with dissolve
            pause

            scene e4s34-116 with dissolve
            sd "You think you can handle me?"

            scene e4s34-117 with dissolve
            sd "You got a very big mouth tonight mister."

            scene e4s34-116 with dissolve
            sd "I don't like your tone."

            scene e4s34-118 with dissolve
            mc "And what are you gonna do about it?"

            scene e4s34-119 with dissolve
            pause

            scene e4s34-120 with dissolve
            pause

            scene e4s34-121 with dissolve
            mc "Wow..."

            scene e4s34-122 with dissolve
            sd "I haven't even started yet."

            scene e4s34-123 with dissolve
            pause

            scene e4s34-125 with dissolve
            mc "Holy shit."

            scene e4s34-124 with dissolve
            sd "Oh yeah, you like that?"

            scene e4s34-136 with dissolve
            sd "Ah..."

            # Missionary

            scene e4s34-missionary3 with dissolve
            sd "You're hitting all the right spots in this position."

            scene e4s34-missionary2 with dissolve
            mc "Fuck... it feels so good."

            scene e4s34-missionary1 with dissolve
            pause

            scene e4s34-126 with dissolve
            mc "You look so hot in this position [sd]."

            scene e4s34-missionary2 with dissolve
            pause

            scene e4s34-missionary3 with dissolve
            sd "Oh my God... I'm so horny right now."

            scene e4s34-missionary1 with dissolve
            pause

            scene e4s34-137 with dissolve
            sd "Fuck... speed up the pace [mc]."

            scene e4s34-missionary4 with dissolve
            sd "I want to feel you."

            scene e4s34-missionary5 with dissolve
            pause

            scene e4s34-126 with dissolve
            mc "Ah... why does it feel like you're getting tighter?"

            scene e4s34-missionary4 with dissolve
            mc "Holy shit, the faster I go the better it feels."

            scene e4s34-missionary5 with dissolve
            pause

            scene e4s34-missionary6 with dissolve
            sd "Ah... oh... fuck!"

            scene e4s34-missionary7 with dissolve
            sd "Damn... you're hitting every right spot."

            scene e4s34-missionary8 with dissolve
            pause

            scene e4s34-missionary6 with dissolve
            pause

            scene e4s34-missionary7 with dissolve
            sd "You can cum whenever you want, alright?"

            scene e4s34-missionary9 with dissolve
            mc "Since when were you in control?"

            scene e4s34-138 with dissolve
            sd "Since I am ah... fucking you!"

            scene e4s34-missionary10 with dissolve
            mc "Who says you're fucking me?"

            scene e4s34-doggy3 with vpunch
            sd "Fuckkk..."
        else:
            if persistent.type_nsfw == False:
                if e4s33_lingerie == True:
                    scene e4s34-128_cen with dissolve
                    pause

                    scene e4s34-127_cen with dissolve
                    mc "You haven't taken off the lingerie from back home?"

                    scene e4s34-129 with dissolve
                    sd "..."

                    scene e4s34-130 with dissolve
                    sd "Just shut up and put it in."

                    scene e4s34-127_cen with dissolve
                    mc "When were you gonna show me?"

                    scene e4s34-131 with dissolve
                    sd "Back home, obviously."
                    sd "I wasn't gonna flash you in front of the whole world."

                    scene e4s34-132_cen with dissolve
                else:
                    scene e4s34-109_cen with dissolve
                    pause

                    scene e4s34-132_cen with dissolve
                menu:
                    "Tease her":
                        scene e4s34-133_cen with dissolve
                        sd "Fuck..."

                        scene e4s34-132_cen with dissolve
                        sd "Stop teasing me and put it in already!"

                        scene e4s34-133_cen with dissolve
                        mc "Or what?"

                        scene e4s34-132_cen with dissolve
                        pause

                        scene e4s34-134_cen with vpunch
                        mc "Holy shit!"

                        scene e4s34-135 with dissolve
                        sd "If you don't wanna do it, I will."
                    "Put it in":
                        scene e4s34-111 with dissolve
                        sd "Holy shit, I can't believe this is happening."

                # Doggy

                scene e4s34-doggy2_cen with dissolve
                sd "Oh my God..."

                scene e4s34-doggy1_cen with dissolve
                sd "It feels so good."

                scene e4s34-doggy2_cen with dissolve
                mc "Fuck [sd]..."

                scene e4s34-doggy1_cen with dissolve
                mc "Ah shit, you're so tight."

                scene e4s34-113 with dissolve
                sd "I've waited the whole night for this moment."

                scene e4s34-112 with dissolve
                sd "Fuck..."

                scene e4s34-114 with dissolve
                mc "Sounds to me like you were too scared to do it."

                scene e4s34-131 with dissolve
                sd "Scared?"

                scene e4s34-doggy3_cen with dissolve
                sd "I wasn't scared."
                mc "Sure you... ah... weren't."

                scene e4s34-114 with dissolve
                mc "Almost chickened out on me."

                scene e4s34-doggy4_cen with dissolve
                sd "Ah... oh..."

                scene e4s34-doggy3_cen with dissolve
                sd "Just... shut up and don't cum!"

                scene e4s34-113 with dissolve
                sd "I want to enjoy this."

                scene e4s34-doggy4_cen with dissolve
                pause

                scene e4s34-doggy3_cen with dissolve
                mc "I thought you wanted to be quick."
                mc "To not get caught."

                scene e4s34-115 with dissolve
                pause

                scene e4s34-116 with dissolve
                sd "You think you can handle me?"

                scene e4s34-117 with dissolve
                sd "You got a very big mouth tonight mister."

                scene e4s34-116 with dissolve
                sd "I don't like your tone."

                scene e4s34-118 with dissolve
                mc "And what are you gonna do about it?"

                scene e4s34-119_cen with dissolve
                pause

                scene e4s34-120 with dissolve
                pause

                scene e4s34-121 with dissolve
                mc "Wow..."

                scene e4s34-122 with dissolve
                sd "I haven't even started yet."

                scene e4s34-123_cen with dissolve
                pause

                scene e4s34-125_cen with dissolve
                mc "Holy shit."

                scene e4s34-124 with dissolve
                sd "Oh yeah, you like that?"

                scene e4s34-136 with dissolve
                sd "Ah..."

                # Missionary

                scene e4s34-missionary3_cen with dissolve
                sd "You're hitting all the right spots in this position."

                scene e4s34-missionary2_cen with dissolve
                mc "Fuck... it feels so good."

                scene e4s34-missionary1 with dissolve
                pause

                scene e4s34-126 with dissolve
                mc "You look so hot in this position [sd]."

                scene e4s34-missionary2_cen with dissolve
                pause

                scene e4s34-missionary3_cen with dissolve
                sd "Oh my God... I'm so horny right now."

                scene e4s34-missionary1 with dissolve
                pause

                scene e4s34-137 with dissolve
                sd "Fuck... speed up the pace [mc]."

                scene e4s34-missionary4_cen with dissolve
                sd "I want to feel you."

                scene e4s34-missionary5_cen with dissolve
                pause

                scene e4s34-126 with dissolve
                mc "Ah... why does it feel like you're getting tighter?"

                scene e4s34-missionary4_cen with dissolve
                mc "Holy shit, the faster I go the better it feels."

                scene e4s34-missionary5_cen with dissolve
                pause

                scene e4s34-missionary6_cen with dissolve
                sd "Ah... oh... fuck!"

                scene e4s34-missionary7_cen with dissolve
                sd "Damn... you're hitting every right spot."

                scene e4s34-missionary8 with dissolve
                pause

                scene e4s34-missionary6_cen with dissolve
                pause

                scene e4s34-missionary7_cen with dissolve
                sd "You can cum whenever you want, alright?"

                scene e4s34-missionary9_cen with dissolve
                mc "Since when were you in control?"

                scene e4s34-138 with dissolve
                sd "Since I am ah... fucking you!"

                scene e4s34-missionary10_cen with dissolve
                mc "Who says you're fucking me?"

                scene e4s34-doggy3_cen with vpunch
                sd "Fuckkk..."

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s34-doggy2 with dissolve
                        sd "Oh my God..."

                        scene e4s34-doggy1 with dissolve
                        sd "It feels so good."

                        scene e4s34-doggy2 with dissolve
                        mc "Fuck [sd]..."

                        scene e4s34-doggy1 with dissolve
                        mc "Ah shit, you're so tight."

                        scene e4s34-112 with dissolve
                        sd "Fuck..."

                        scene e4s34-114 with dissolve
                        mc "Sounds to me like you were too scared to do it."

                        scene e4s34-131 with dissolve
                        sd "Scared?"

                        scene e4s34-doggy3 with dissolve
                        sd "I wasn't scared."
                        mc "Sure you... ah... weren't."

                        scene e4s34-114 with dissolve
                        mc "Almost chickened out on me."

                        scene e4s34-doggy4 with dissolve
                        sd "Ah... oh..."

                        scene e4s34-doggy3 with dissolve
                        sd "Just... shut up and don't cum!"

                        scene e4s34-113 with dissolve
                        sd "I want to enjoy this."

                        scene e4s34-doggy4 with dissolve
                        pause

                        scene e4s34-doggy3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s34-doggy2_cen with dissolve
                            sd "Oh my God..."

                            scene e4s34-doggy1_cen with dissolve
                            sd "It feels so good."

                            scene e4s34-doggy2_cen with dissolve
                            mc "Fuck [sd]..."

                            scene e4s34-doggy1_cen with dissolve
                            mc "Ah shit, you're so tight."

                            scene e4s34-112 with dissolve
                            sd "Fuck..."

                            scene e4s34-114 with dissolve
                            mc "Sounds to me like you were too scared to do it."

                            scene e4s34-131 with dissolve
                            sd "Scared?"

                            scene e4s34-doggy3_cen with dissolve
                            sd "I wasn't scared."
                            mc "Sure you... ah... weren't."

                            scene e4s34-114 with dissolve
                            mc "Almost chickened out on me."

                            scene e4s34-doggy4_cen with dissolve
                            sd "Ah... oh..."

                            scene e4s34-doggy3_cen with dissolve
                            sd "Just... shut up and don't cum!"

                            scene e4s34-113 with dissolve
                            sd "I want to enjoy this."

                            scene e4s34-doggy4_cen with dissolve
                            pause

                            scene e4s34-doggy3_cen with dissolve
                            pause
                "Missionary":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s34-missionary3 with dissolve
                        sd "You're hitting all the right spots in this position."

                        scene e4s34-missionary2 with dissolve
                        mc "Fuck... it feels so good."

                        scene e4s34-missionary1 with dissolve
                        pause

                        scene e4s34-126 with dissolve
                        mc "You look so hot in this position [sd]."

                        scene e4s34-missionary2 with dissolve
                        pause

                        scene e4s34-missionary3 with dissolve
                        sd "Oh my God... I'm so horny right now."

                        scene e4s34-missionary1 with dissolve
                        pause

                        scene e4s34-137 with dissolve
                        sd "Fuck... speed up the pace [mc]."

                        scene e4s34-missionary4 with dissolve
                        sd "I want to feel you."

                        scene e4s34-missionary5 with dissolve
                        pause

                        scene e4s34-missionary4 with dissolve
                        mc "Holy shit, the faster I go the better it feels."

                        scene e4s34-missionary5 with dissolve
                        pause

                        scene e4s34-missionary6 with dissolve
                        sd "Ah... oh... fuck!"

                        scene e4s34-missionary7 with dissolve
                        sd "Damn... you're hitting every right spot."

                        scene e4s34-missionary8 with dissolve
                        pause

                        scene e4s34-missionary6 with dissolve
                        pause

                        scene e4s34-missionary9 with dissolve
                        pause

                        scene e4s34-missionary10 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s34-missionary3_cen with dissolve
                            sd "You're hitting all the right spots in this position."

                            scene e4s34-missionary2_cen with dissolve
                            mc "Fuck... it feels so good."

                            scene e4s34-missionary1 with dissolve
                            pause

                            scene e4s34-126 with dissolve
                            mc "You look so hot in this position [sd]."

                            scene e4s34-missionary2_cen with dissolve
                            pause

                            scene e4s34-missionary3_cen with dissolve
                            sd "Oh my God... I'm so horny right now."

                            scene e4s34-missionary1 with dissolve
                            pause

                            scene e4s34-137 with dissolve
                            sd "Fuck... speed up the pace [mc]."

                            scene e4s34-missionary4_cen with dissolve
                            sd "I want to feel you."

                            scene e4s34-missionary5_cen with dissolve
                            pause

                            scene e4s34-missionary4_cen with dissolve
                            mc "Holy shit, the faster I go the better it feels."

                            scene e4s34-missionary5_cen with dissolve
                            pause

                            scene e4s34-missionary6_cen with dissolve
                            sd "Ah... oh... fuck!"

                            scene e4s34-missionary7_cen with dissolve
                            sd "Damn... you're hitting every right spot."

                            scene e4s34-missionary8 with dissolve
                            pause

                            scene e4s34-missionary6_cen with dissolve
                            pause

                            scene e4s34-missionary9_cen with dissolve
                            pause

                            scene e4s34-missionary10_cen with dissolve
                            pause
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s34-missionary4 with dissolve
                        mc "Shit [sd]... I'm getting close!"

                        scene e4s34-137 with dissolve
                        sd "Fuck... a second time tonight?"
                        sd "You are something else."

                        scene e4s34-missionary4 with dissolve
                        sd "Cum inside me [mc], fill up my pussy."
                        mc "Ah shit... I'm gonna do it!"
                        mc "I'm gonna cum!"
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        scene e4s34-123 with dissolve
                        mc "Holy shit, you drained me!"
                        sd "Of every last drop, haha!"

                        scene e4s34-121 with dissolve
                        mc "Crap, we've been missing for too long."
                        mc "Hopefully they don't think we left without paying."

                        scene e4s34-122 with dissolve
                        sd "So, what?"
                        sd "A little adrenaline won't hurt."

                        scene e4s34-139 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s34-missionary4_cen with dissolve
                            mc "Shit [sd]... I'm getting close!"

                            scene e4s34-137 with dissolve
                            sd "Fuck... a second time tonight?"
                            sd "You are something else."

                            scene e4s34-missionary4_cen with dissolve
                            sd "Cum inside me [mc], fill up my pussy."
                            mc "Ah shit... I'm gonna do it!"
                            mc "I'm gonna cum!"
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            scene e4s34-123_cen with dissolve
                            mc "Holy shit, you drained me!"
                            sd "Of every last drop, haha!"

                            scene e4s34-121 with dissolve
                            mc "Crap, we've been missing for too long."
                            mc "Hopefully they don't think we left without paying."

                            scene e4s34-122 with dissolve
                            sd "So, what?"
                            sd "A little adrenaline won't hurt."

                            scene e4s34-139_cen with dissolve
                            pause

                    scene e4s34-140 with dissolve
                    pause

                    $ GameRunning = False

    $ renpy.end_replay()
return
