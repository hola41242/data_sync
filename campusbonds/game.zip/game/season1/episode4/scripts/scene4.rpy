
# Scene 4 - One friendly face (Monday) #########################################

label e4s4:
    play music one_fine_day
    scene e4s4-01 with wipeleft
    pause

    if e3s13_tiffany_hangout == True:
        $ e4s4_hangout = True
        mc "Hi [tf]."

        scene e4s4-02 with dissolve
        pause

        scene e4s4-03 with dissolve
        tf "Oh, [mc]!"
        tf "Hello!"

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "What's up?"

        scene e4s4-05 with dissolve
        hide e4s4_tiffany_blink1
        tf "Just grabbing my book from the locker."

        scene e4s4-06 with dissolve
        tf "What's up with you?"

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "I'm doing fine."
        mc "Listen, about last time..."

        scene e4s4-07 with dissolve
        hide e4s4_tiffany_blink1
        tf "It's alright, I'm sorry I pushed it."

        scene e4s4-08 with dissolve
        tf "I... I shouldn't have gotten involved in your family stuff."
        tf "That was over the line."

        scene e4s4-09 with dissolve
        mc "You were right."
        mc "There really was something more to the story."

        scene e4s4-10 with dissolve
        tf "Wait, really?"

        scene e4s4-09 with dissolve
        mc "Yeah, let's grab some lunch later and I'll tell you all about it, alright?"

        scene e4s4-13 with dissolve
        tf "Yeah, sure!"

        scene e4s4-12 with dissolve
        tf "Now you've made me a bit curious, haha!"

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "Haha, great!"
        mc "See you then."

        scene e4s4-11 with dissolve
        hide e4s4_tiffany_blink1
        tf "Alright, bye [mc]!"

        stop music fadeout 1.0
        scene e4s4-14 with dissolve
        pause

    else:
        mc "Hey Tiffany!"

        scene e4s4-03 with dissolve
        tf "Oh, hey! What's up?"

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "I'm fine, I have my class in a couple of minutes."
        mc "And I thought I might stop by and say hi."
        mc "What about you?"

        scene e4s4-05 with dissolve
        hide e4s4_tiffany_blink1
        tf "Just grabbing my book from the locker."

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "Cool!"

        scene e4s4-06 with dissolve
        hide e4s4_tiffany_blink1
        tf "Yeah. This hallway always smells like coffee and stress."

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "Haha, sounds like midterm season already."

        scene e4s4-13 with dissolve
        hide e4s4_tiffany_blink1
        tf "Right? Everyone's running on caffeine and vibes at this point."

        scene e4s4-04 with dissolve
        show e4s4_tiffany_blink1
        mc "Yeah... it's been kind of a weird week for me too, honestly."

        scene e4s4-07 with dissolve
        hide e4s4_tiffany_blink1
        tf "You okay?"

        scene e4s4-09 with dissolve
        mc "*Hmm... should I talk to [tf] about what happened back home?*"

        menu:
            "Talk to [tf]":
                $ e4s4_hangout = True
                $ tiffany_trust += 1
                mc "Kind of, I guess."
                mc "If you'd like, we can grab some lunch later and talk about it."

                scene e4s4-05 with dissolve
                tf "Sure, I'm free after class."

                scene e4s4-04 with dissolve
                show e4s4_tiffany_blink1
                mc "Awesome! I'll text you after, alright?"

                scene e4s4-11 with dissolve
                hide e4s4_tiffany_blink1
                tf "Okay, see you then."

                scene e4s4-04 with dissolve
                show e4s4_tiffany_blink1
                mc "Bye!"

                stop muysic fadeout 1.0
                scene e4s4-14 with dissolve
                hide e4s4_tiffany_blink1
                pause
            "Don't tell her":
                mc "..."
                mc "Yeah, everything's fine."
                mc "Anyway, I'll see you around!"
                mc "Gotta get to my class."

                scene e4s4-11 with dissolve
                tf "Alright, see you [mc]."

                stop music fadeout 1.0
                scene e4s4-15 with dissolve
                pause

    jump e4s5
return
