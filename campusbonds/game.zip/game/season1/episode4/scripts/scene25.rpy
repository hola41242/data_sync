
# Scene 25 - Making up #########################################################

label e4s25:
    if e4s5_sadie_mad == True or e4s5_tracy_mad == True:
        play music serenity
        if e4s5_sadie_mad == True:
            scene e4s25-01 with wipeleft
            pause

            scene e4s25-03 with dissolve
            mc "Hey!"

            scene e4s25-04 with dissolve
            show e4s25_sadie_blink1
            mc "What's up?"

            scene e4s25-05 with dissolve
            hide e4s25_sadie_blink1
            sd "Getting my book, you?"

            scene e4s25-04 with dissolve
            show e4s25_sadie_blink1
            mc "I'm okay, getting ready for my next class."
            mc "Are you still mad?"

            scene e4s25-06 with dissolve
            hide e4s25_sadie_blink1
            sd "..."

            scene e4s25-05 with dissolve
            sd "Listen... I don't really want to talk to you now."

            scene e4s25-04 with dissolve
            show e4s25_sadie_blink1
            mc "Then when?"
            mc "I gave you space, how long are you gonna ignore me for?"

            scene e4s25-07 with dissolve
            hide e4s25_sadie_blink1
            sd "Until I feel it's enough."

            scene e4s25-05 with dissolve
            sd "[tr]'s waiting for me, bye [mc]."

            scene e4s25-04 with dissolve
            show e4s25_sadie_blink1
            mc "See you."

            scene e4s25-08 with dissolve
            hide e4s25_sadie_blink1
            pause
        elif e4s5_tracy_mad == True:
            scene e4s25-02 with wipeleft
            pause

            scene e4s25-09 with dissolve
            mc "Hey!"

            scene e4s25-10 with dissolve
            show e4s25_tracy_blink1
            mc "What's up?"

            scene e4s25-11 with dissolve
            hide e4s25_tracy_blink1
            tr "What do you want, [mc]?"

            scene e4s25-10 with dissolve
            show e4s25_tracy_blink1
            mc "Woah, just trying to talk to you."

            scene e4s25-11 with dissolve
            hide e4s25_tracy_blink1
            tr "Well, I obviously don't want to."

            scene e4s25-10 with dissolve
            show e4s25_tracy_blink1
            mc "Why? What's wrong?"

            scene e4s25-14 with dissolve
            hide e4s25_tracy_blink1
            tr "Dude, are you that clueless?"

            scene e4s25-13 with dissolve
            tr "Holy shit."

            scene e4s25-12 with dissolve
            tr "I shouldn't even have this conversation with you."

            scene e4s25-10 with dissolve
            show e4s25_tracy_blink1
            mc "Is it about what happened in class with the projects?"

            scene e4s25-12 with dissolve
            hide e4s25_tracy_blink1
            tr "Good, you're starting to realize."

            scene e4s25-10 with dissolve
            show e4s25_tracy_blink1
            mc "No, I'm not! Are you mad because I didn't pick you?"

            if e4s5_tracy_path_throw == True:
                scene e4s25-14 with dissolve
                hide e4s25_tracy_blink1
                tr "No dude, what the fuck!"

                scene e4s25-16 with dissolve
                tr "{b}You{/b} told me you had feelings for me, that you wanted to try."
                tr "You told me you don't have any feelings for [sd], but then you go ahead and pick her over me?"

                scene e4s25-14 with dissolve
                tr "That's just messed up."

                scene e4s25-15 with dissolve
                mc "..."

                scene e4s25-14 with dissolve
                tr "What? You don't have anything to say now?"

                scene e4s25-13 with dissolve
                tr "I should have fucking known."

                scene e4s25-17 with vpunch
                tr "Move!"
            else:
                scene e4s25-13 with dissolve
                tr "It's not just that, jeez."

                scene e4s25-12 with dissolve
                tr "I thought that conversation we had earlier mattered to you... when you said you had feelings for me."
                tr "It's not just about a stupid class project, it's about us getting closer."

                scene e4s25-10 with dissolve
                show e4s25_tracy_blink1
                mc "I'm sorry... I didn't know you feel like that."

                scene e4s25-13 with dissolve
                hide e4s25_tracy_blink1
                tr "Well, I thought you felt the same but it looks like I'm the only fool here."

                scene e4s25-12 with dissolve
                tr "Anyway, I gotta get to my class."
                tr "If you'll excuse me."

                scene e4s25-18 with dissolve
                pause

        stop music fadeout 1.0
        scene e4s25-19 with dissolve
        pause

        jump e4s26
    else:
        if e4s5_sadie_path_throw == False and e4s5_tracy_path_throw == False:
            play music serenity
            if sadie_trust > tracy_trust:
                scene e4s25-01 with wipeleft
                pause

                scene e4s25-03 with dissolve
                mc "Hey!"

                scene e4s25-26 with dissolve
                sd "Hi [mc]!"

                scene e4s25-20 with dissolve
                show e4s25_sadie_blink2
                mc "What's up?"

                scene e4s25-27 with dissolve
                hide e4s25_sadie_blink2
                sd "Just getting my book for my next class."

                scene e4s25-26 with dissolve
                sd "You?"

                scene e4s25-20 with dissolve
                show e4s25_sadie_blink2
                mc "Wandering aimlessly."

                scene e4s25-28 with dissolve
                hide e4s25_sadie_blink2
                sd "Don't you have classes?"

                scene e4s25-20 with dissolve
                show e4s25_sadie_blink2
                mc "Not really, I'm free today."

                scene e4s25-27 with dissolve
                hide e4s25_sadie_blink2
                sd "Damn, I'm a bit jealous, you know?"

                scene e4s25-20 with dissolve
                show e4s25_sadie_blink2
                mc "Well, better make the most out of it, I don't know how long it'll last."

                if e4s5_date == True:
                    scene e4s25-28 with dissolve
                    hide e4s25_sadie_blink2
                    sd "You know... I just wanted to say that I'm really excited for our date."

                    scene e4s25-27 with dissolve
                    sd "I didn't think I'd be like this, but God is it lingering in my mind."

                    scene e4s25-20 with dissolve
                    show e4s25_sadie_blink2
                    mc "Really?"

                    scene e4s25-26 with dissolve
                    hide e4s25_sadie_blink2
                    sd "Yeah dude, it's been so long since I went on a proper date."
                    sd "I wanted something a little different."

                    scene e4s25-20 with dissolve
                    show e4s25_sadie_blink2
                    mc "That's great to hear!"
                    mc "I'm excited about it as well."
                    mc "I don't think I ever went on a date like this."

                    scene e4s25-26 with dissolve
                    hide e4s25_sadie_blink2
                    sd "You make it sound like you have something big planned."

                    scene e4s25-20 with dissolve
                    show e4s25_sadie_blink2
                    mc "Haha, maybe I do, we'll have to see."

                    scene e4s25-27 with dissolve
                    hide e4s25_sadie_blink2
                    sd "Okay, okay."
                else:
                    scene e4s25-26 with dissolve
                    hide e4s25_sadie_blink2
                    sd "Yup, for sure."

                    scene e4s25-27 with dissolve
                    sd "Anyway..."

                scene e4s25-26 with dissolve
                sd "I'll get to my class now, see you around!"

                scene e4s25-20 with dissolve
                show e4s25_sadie_blink2
                mc "See you [sd]."

                stop music fadeout 2.0
                scene e4s25-08 with dissolve
                hide e4s25_sadie_blink2
                pause
            elif tracy_trust > sadie_trust and affinity_spectrum > 0:
                scene e4s25-02 with wipeleft
                pause

                scene e4s25-09 with dissolve
                mc "Hey there, [tr]!"

                scene e4s25-22 with dissolve
                tr "What's up?"

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Just wandering aimlessly."
                mc "You?"

                scene e4s25-25 with dissolve
                hide e4s25_tracy_blink2
                tr "Damn, talk about how good others have it."

                scene e4s25-24 with dissolve
                tr "Some people have classes around this hour, you know?"
                tr "Myself included."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Well, it's my lucky day I guess."
                mc "Come to think of it, I don't think I ever saw you on these hallways."
                mc "Did you start taking college seriously?"

                scene e4s25-23 with dissolve
                hide e4s25_tracy_blink2
                tr "Haha, a bit."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "How so?"

                scene e4s25-25 with dissolve
                hide e4s25_tracy_blink2
                tr "I don't know... just like that."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "No deeper motivations?"

                scene e4s25-24 with dissolve
                hide e4s25_tracy_blink2
                tr "Can't someone just study for the sake of it?"

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "They can, don't get me wrong, but I didn't think you were a nerd."

                scene e4s25-23 with dissolve
                hide e4s25_tracy_blink2
                tr "I'm not a nerd!"

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "No... but you're getting there."

                scene e4s25-25 with dissolve
                hide e4s25_tracy_blink2
                tr "Come on, just let me be."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Sure, sure."
                mc "How's the cheerleaders?"

                scene e4s25-22 with dissolve
                hide e4s25_tracy_blink2
                tr "They're alright, no real activities so far."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Is it true that they're not doing well?"

                scene e4s25-25 with dissolve
                hide e4s25_tracy_blink2
                tr "Yeah, kind of."

                scene e4s25-22 with dissolve
                tr "With no sports to cheer, they're working with the college staff now."
                tr "Organizing and planning shit."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "That sounds a bit lame."

                scene e4s25-25 with dissolve
                hide e4s25_tracy_blink2
                tr "That's because it is, but they don't have any other alternatives."

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Yeah, I guess you're right."
                mc "We'll have to see how it goes from here."

                if e4s23_tracy_hangout == True and e4s23_tracy_lewd == False:
                    mc "Also, I really enjoyed last night."
                    mc "It was nice seeing another side of you."

                    scene e4s25-25 with dissolve
                    hide e4s25_tracy_blink2
                    tr "I didn't think you'd like it."

                    scene e4s25-21 with dissolve
                    show e4s25_tracy_blink2
                    mc "Why not?"

                    scene e4s25-24 with dissolve
                    hide e4s25_tracy_blink2
                    tr "I don't know, most people wouldn't."

                    scene e4s25-21 with dissolve
                    show e4s25_tracy_blink2
                    mc "Who are those? Asking for a friend."

                    scene e4s25-23 with dissolve
                    hide e4s25_tracy_blink2
                    tr "Haha, shut up!"

                scene e4s25-22 with dissolve
                hide e4s25_tracy_blink2
                tr "Listen, I gotta get to my class."
                tr "I'll see you around, alright?"

                scene e4s25-21 with dissolve
                show e4s25_tracy_blink2
                mc "Sure, sure, good luck."
                mc "See you!"

                stop music fadeout 2.0
                scene e4s25-18 with dissolve
                hide e4s25_tracy_blink2
                pause

            jump e4s26
        else:
            jump e4s26
return
