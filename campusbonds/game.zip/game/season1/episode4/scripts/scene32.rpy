
# Scene 32 - Sausage talk ######################################################

label e4s32:
    if e4s31_fail == False:
        stop music fadeout 1.0
        scene e4s32-32 with wipeleft
        pause
    else:
        stop music fadeout 1.0
        scene e4s32-01 with wipeleft
        pause

    scene e4s32-02 with dissolve
    play sound door_close
    pause

    play music hi_as_hats
    scene e4s32-03 with dissolve
    jon "Hey, look who's finally here to join the party!"

    scene e4s32-04 with dissolve
    ke "Why haven't you guys told me that Ellie is also part of College Rock?"

    scene e4s32-05 with dissolve
    mc "Wait, you went to College Rock?"

    scene e4s32-06 with dissolve
    ke "Yeah, I was supposed to fill in for you."

    scene e4s32-07 with dissolve
    mc "That's how you told me you were gonna take care of the problem?"

    scene e4s32-08 with dissolve
    pause

    scene e4s32-07 with dissolve
    mc "What exactly did you tell Ken?"

    scene e4s32-09 with dissolve
    jon "Listen up, dude."
    jon "Me and [mc] gotta take care of a problem."

    scene e4s32-11 with dissolve
    jon "It's a pretty serious matter so we really need your help."

    scene e4s32-10 with dissolve
    ke "Sure dude, don't keep me waiting, what's up?"

    scene e4s32-09 with dissolve
    jon "So... [mc]'s basically juggling between two clubs, one being ours and one being a music club."
    jon "And tonight he's needed for both."

    scene e4s32-11 with dissolve
    jon "I started weighing the importance of both of them and came to the conclusion that what we're doing is for the greater good."

    scene e4s32-09 with dissolve
    jon "So... what I'd like you to do is fill in his place at his club."

    scene e4s32-12 with dissolve
    jon "Be ecstatic, like you just found gold or something."
    jon "Oh... and also, tell them you'd like to play the drums."
    jon "They'll love you for it."

    scene e4s32-10 with dissolve
    ke "Anything else?"

    scene e4s32-13 with dissolve
    pause

    scene e4s32-14 with dissolve
    mc "That still doesn't explain why you're wearing my clothes."

    scene e4s32-06 with dissolve
    ke "[jon] here thought that if I confuse the shit out of them they'll forget about you or something."

    scene e4s32-15 with dissolve
    ro "Yeah dude... fucked up."

    scene e4s32-16 with dissolve
    ke "If I knew she would also be there I wouldn't have taken up on your offer."

    if e4s31_fail == False:
        scene e4s32-18 with dissolve
        jon "Oh, relax. Another piece of the plan is complete."
        jon "Sacrifices must be made. This is war."
    else:
        scene e4s32-17 with dissolve
        jon "Yeah, well, it was for nothing anyway."
        jon "We didn't manage to go through with the plan."
        jon "The war continues."

        scene e4s32-30 with dissolve
        ke "So I did that for fucking nothing?"

    scene e4s32-15 with dissolve
    ro "Speaking of war... [mc], what's your battle history looking like?"
    ro "Never seen you with a lady."

    scene e4s32-18 with dissolve
    jon "Oh, don't hold your breath waiting for that answer."
    jon "My guy here is, uh... let's just say he's not on the same line when it comes to women."
    jon "And that's fine! No shame in that."

    scene e4s32-19 with dissolve
    jon "I'm not gonna be too direct about it, but he hasn't really had that experience yet."

    scene e4s32-20 with dissolve
    play sound glass_shatter
    mc "Wait, what?"

    scene e4s32-21 with dissolve
    jon "I mean, bro, be honest."
    jon "Even if you had a woman in your bed, you'd probably shake her hand and thank her for her time."

    scene e4s32-22 with dissolve
    jon "Even I, when I lost my virginity, I had the girl take over and do most of the stuff."
    jon "I wasn't as easy-going as I am now."

    scene e4s32-26 with dissolve
    mc "Dude... but I'm not a virgin."

    scene e4s32-17 with dissolve
    jon "So what if the guy is not fully cut out for this yet?"

    scene e4s32-26 with dissolve
    mc "Bro, I literally just said I'm not a virgin."

    scene e4s32-17 with dissolve
    jon "We need to understand him. He's our friend after all."

    scene e4s32-15 with dissolve
    ro "It's okay, man."
    ro "No need to prove anything to us."

    scene e4s32-23 with dissolve
    mc "WHAT AM I EVEN PROVING?!"

    scene e4s32-24 with dissolve
    jon "Bro, it's been three weeks, and the only thing I've seen in your hands is a plate of sausages."

    scene e4s32-21 with dissolve
    jon "I haven't seen you speak to any lady."

    scene e4s32-26 with dissolve
    mc "What do you mean?"

    menu:
        "[sd]" if sadie_trust > 4:
            $ e4s32_option = 1
            mc "Don't you remember [sd] talking about me?"

            if e2s10_sadie == True:
                mc "I slept at her place..."

            if e4s18_sadie_introvert == True:
                mc "I even asked you for advice to take her out."
            elif e4s18_sadie_extrovert == True:
                mc "I even asked you for money to take her out."

            mc "What are you on?"

            scene e4s32-22 with dissolve
            jon "Oh, yeah..."
        "[tr]" if tracy_trust > 4:
            $ e4s32_option = 2
            mc "Don't you remember [tr] talking about me?"

            scene e4s32-22 with dissolve
            jon "Oh, yeah..."
        "[cl]" if cleo_trust > 2:
            $ e4s32_option = 3
            mc "Don't you remember the girl from the diner?"
            mc "[cl]?"

            scene e4s32-22 with dissolve
            jon "Oh, yeah..."
        "[fr]":
            $ e4s32_option = 4
            mc "Don't you remember my weird encounter?"
            mc "From that night with the hot dog?"

            scene e4s32-22 with dissolve
            jon "Oh, yeah..."
        "Someone else":
            $ e4s32_option = 5
            mc "Even if you didn't see me, that doesn't mean I didn't talk to anyone."

            scene e4s32-24 with dissolve
            jon "Pfft, great excuse dude."

    scene e4s32-25 with dissolve
    mc "And what about you, dude?"
    mc "Who have you spoken to that makes you Minister of Pussy?"

    scene e4s32-21 with dissolve
    jon "Uh... I have a network, remember?"
    jon "Who do you think invites all the women to Party Ragers?"

    scene e4s32-05 with dissolve
    mc "Ohhh, so THAT'S why this place looks like a sausage convention."
    mc "It all makes sense now."

    scene e4s32-27 with dissolve
    ro "How did this conversation go from relationships to a goddamn butcher shop?!"
    ro "Why the fuck are we talking about sausages all of a sudden?"
    ro "I was asking about women, not about how many dicks you've held in your hands."

    scene e4s32-28 with dissolve
    jon "Well... [ro]..."
    jon "At the end of the day, a firm grip is a firm grip... who cares what it's holding?"

    scene e4s32-29 with dissolve
    ro "WHAT THE FUCK DOES THAT EVEN MEAN, MAN?!"

    scene e4s32-30 with dissolve
    ke "Damn, bro... and I thought [mc] was the gay one here."

    scene e4s32-18 with dissolve
    jon "Anyway, I'm outta here."
    jon "I've got some better things to do at home."

    scene e4s32-07 with dissolve
    mc "Yeah? Like what, shake Mr. President's hand?"

    scene e4s32-21 with dissolve
    jon "How did you know I call him that?"

    scene e4s32-05 with dissolve
    mc "I didn't, and I regret saying that."

    scene e4s32-18 with dissolve
    jon "Have a good one guys!"

    scene e4s32-31 with dissolve
    pause

    if e4s5_date == True:
        if e2s6_sadie_romance == True:
            jump e4s33
        else:
            jump e4s34
    else:
        jump e4s36
return
