
default e4s22_tiffany_upset = False

# Scene 22 - Sweet sweet chocolate #############################################

label e4s22:
    stop music fadeout 1.0
    scene e4s22-01 with wipeleft
    pause

    play music which_that_is_this
    scene e4s22-02 with dissolve
    pause

    scene e4s22-03 with dissolve
    pause

    scene e4s22-04 with dissolve
    mc "Hi!"

    scene e4s22-05 with dissolve
    tf "Oh, hello [mc]."

    scene e4s22-08 with dissolve
    mc "Didn't expect to see you here."

    scene e4s22-06 with dissolve
    tf "Me neither honestly, haha."

    scene e4s22-07 with dissolve
    tf "Want to sit?"

    scene e4s22-08 with dissolve
    mc "Yeah, sure."
    mc "Got some time to kill before my next class."

    scene e4s22-09 with dissolve
    pause

    scene e4s22-10 with dissolve
    tf "The weather's really nice today."
    tf "I wonder how long until it gets all cold and ugly again."

    scene e4s22-11 with dissolve
    mc "You don't like winters?"

    scene e4s22-12 with dissolve
    tf "Nah, not really."

    scene e4s22-14 with dissolve
    tf "I hate how cold it gets around here."

    scene e4s22-15 with dissolve
    tf "I tend to stay inside most of the season."

    scene e4s22-12 with dissolve
    tf "Do you like winters?"

    scene e4s22-13 with dissolve
    show e4s22_tiffany_blink1
    menu:
        "Like them":
            call extrovert_affinity_check from _call_extrovert_affinity_check_68
            call color_check from _call_color_check_132
            mc "I do like them."
            mc "Winter has its charm like other seasons, a certain feeling."
            mc "I like the activities you can do and the gifts on Christmas Eve."

            scene e4s22-16 with dissolve
            hide e4s22_tiffany_blink1
            tf "Haha, I like gifts too."

            scene e4s22-12 with dissolve
            tf "One thing I really dislike is getting hit in the face by a snowball."

            scene e4s22-14 with dissolve
            tf "I hope you're not gonna do that to me."

            scene e4s22-13 with dissolve
            show e4s22_tiffany_blink1
            if affinity_spectrum > 0:
                mc "We'll have to see until then."

                scene e4s22-16 with dissolve
                hide e4s22_tiffany_blink1
                tf "Hey!!"

                scene e4s22-17 with dissolve
                show e4s22_tiffany_blink2
                mc "Haha!"

                hide e4s22_tiffany_blink2
            else:
                mc "No, no, don't worry."
                mc "I won't."

                scene e4s22-18 with dissolve
                hide e4s22_tiffany_blink1
                tf "Great, thank you!"

        "Dislike them":
            call introvert_affinity_check from _call_introvert_affinity_check_60
            call color_check from _call_color_check_133
            mc "I don't really like them either."
            mc "You're right in what you said, they are pretty cold."
            mc "I like summer more."

            scene e4s22-16 with dissolve
            hide e4s22_tiffany_blink1
            tf "So I don't have to worry about getting hit with snowballs then, haha!"

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            mc "That's like the worst thing about winter."
            mc "Don't worry, you're safe around me."

            scene e4s22-18 with dissolve
            hide e4s22_tiffany_blink2
            tf "Thanks!"

    if e3s9_tiffany_sex == True:
        scene e4s22-20 with dissolve
        pause

        scene e4s22-21 with dissolve
        pause

        scene e4s22-22 with dissolve
        tf "Something has been on my mind for a little while."

        scene e4s22-13 with dissolve
        show e4s22_tiffany_blink1
        mc "What's up?"

        scene e4s22-14 with dissolve
        hide e4s22_tiffany_blink1
        tf "Do you remember when we did it?"
        tf "Like, had sex?"

        scene e4s22-13 with dissolve
        show e4s22_tiffany_blink1
        mc "Yeah, I remember."
        mc "What's up?"

        scene e4s22-14 with dissolve
        hide e4s22_tiffany_blink1
        tf "Nothing bad or anything."

        scene e4s22-15 with dissolve
        tf "I was just... thinking that..."
        tf "Maybe we could talk about it?"

        scene e4s22-13 with dissolve
        show e4s22_tiffany_blink1
        menu:
            "Listen to her":
                $ tiffany_trust += 1
                mc "Sure [tf], what's up?"

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink1
                tf "It felt a bit like it just happened, like it wasn't a big deal."

                scene e4s22-25 with dissolve
                tf "I don't know, I don't want you to get the wrong idea."

                scene e4s22-24 with dissolve
                tf "But... I guess we didn't really evolve into something more, you know?"

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Did you want to evolve into something more?"

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink1
                tf "I mean... of course I didn't expect us to get together that fast."

                scene e4s22-23 with dissolve
                tf "But... I guess I hoped we might grow a little closer, you know?"

                scene e4s22-29 with dissolve
                tf "Sorry, I don't mean to be weird about it."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "No, you're not weird."
                mc "Thanks for bringing it up."
                mc "I just didn't expect you to feel like that."

                scene e4s22-12 with dissolve
                hide e4s22_tiffany_blink1
                tf "Well... I'm not really the 'one night stand' kind of girl."
                tf "I like having deeper connections, sex isn't really my thing without feelings."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "I understand."
                mc "I don't want you to feel like it was just a one-night stand."
                mc "But I guess the circumstances haven't been exactly right for us to grow closer."

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink1
                tf "Yeah..."

                if e3s13_tiffany_hangout == True or e4s4_hangout == True:
                    scene e4s22-20 with dissolve
                    pause

                    scene e4s22-22 with dissolve
                    tf "We could talk about it now, if you'd like."

                    scene e4s22-13 with dissolve
                    show e4s22_tiffany_blink1
                    mc "Of course!"

                    scene e4s22-28 with dissolve
                    hide e4s22_tiffany_blink1
                    tf "I think I'm developing a little crush on you."

                    scene e4s22-17 with dissolve
                    show e4s22_tiffany_blink2
                    mc "You are?"

                    scene e4s22-14 with dissolve
                    hide e4s22_tiffany_blink2
                    tf "Yeah..."

                    scene e4s22-24 with dissolve
                    tf "It's been kind of hard to be honest with myself, but here we are."

                    scene e4s22-25 with dissolve
                    tf "And of course, I'm not expecting a relationship right away, I don't want to rush into it either."

                    scene e4s22-28 with dissolve
                    tf "But I'd like to know if there's a chance we could become more."

                    scene e4s22-17 with dissolve
                    show e4s22_tiffany_blink2
                    menu:
                        "Feel the same":
                            $ e4s22_tiffany_path = True
                            $ tiffany_intimacy += 1
                            $ tiffany_trust += 1

                            mc "You know... I feel the same."
                            mc "I know circumstances haven't been the nicest to both of us."
                            mc "But I've been really enjoying your presence... and I think I'd like to get to know you more."

                            scene e4s22-26 with dissolve
                            hide e4s22_tiffany_blink2
                            tf "Really?"

                            scene e4s22-17 with dissolve
                            show e4s22_tiffany_blink2
                            mc "Yeah."
                            mc "I've been feeling like this for a bit and I'm glad you brought it up."

                            scene e4s22-27 with dissolve
                            hide e4s22_tiffany_blink2
                            tf "Haha, that's such a relief!"

                            scene e4s22-16 with dissolve
                            tf "I'm really glad we feel the same way."

                            scene e4s22-27 with dissolve
                            tf "You have no idea how easy my shoulders feel right now, haha!"

                            scene e4s22-28 with dissolve
                            tf "That's a weight off my heart."

                            scene e4s22-17 with dissolve
                            show e4s22_tiffany_blink2
                            mc "Haha!"

                            scene e4s22-32 with dissolve
                            hide e4s22_tiffany_blink2
                            tf "I can't wait for what's next."

                            scene e4s22-33 with dissolve
                            tf "It's nice to know we're both on the same page."

                            scene e4s22-17 with dissolve
                            show e4s22_tiffany_blink2
                            mc "Yeah, me too."
                            mc "It will have to wait a bit though, I'm still busy with some other stuff."

                            scene e4s22-19 with dissolve
                            hide e4s22_tiffany_blink2
                            tf "No worries, it's enough for me."

                            scene e4s22-34 with dissolve
                            pause

                        "No feelings for [tf]":
                            $ tiffany_trust -= 1

                            $ e4s22_tiffany_upset = True

                            if affinity_spectrum > 0:
                                mc "I'm sorry [tf], but I don't feel the same."
                            else:
                                mc "I'm sorry [tf], I don't want to hurt you... but I don't really feel the same."

                            hide e4s22_tiffany_blink2
                            scene e4s22-13 with dissolve
                            show e4s22_tiffany_blink1
                            mc "Yeah, we had fun together, but I always felt we did it as friends."
                            mc "I'm not really looking for anything more."

                            scene e4s22-29 with dissolve
                            hide e4s22_tiffany_blink1
                            tf "Oh... okay."

                            scene e4s22-30 with dissolve
                            tf "Well, I guess I just needed to know."
                            tf "It is what it is."

                            scene e4s22-29 with dissolve
                            tf "Thanks for being honest [mc]."

                            scene e4s22-30 with dissolve
                            tf "I hope this doesn't change the friendship between us."

                            scene e4s22-13 with dissolve
                            show e4s22_tiffany_blink1
                            mc "Well... as long as you're fine with it, I don't think it will."
                            mc "If it makes you feel uncomfortable, we can stop here."

                            scene e4s22-26 with dissolve
                            hide e4s22_tiffany_blink1
                            tf "No, no, it's fine!"

                            scene e4s22-30 with dissolve
                            tf "As I said, it was just a little crush, haha!"
                            tf "It's better to be honest upfront."

                            scene e4s22-13 with dissolve
                            show e4s22_tiffany_blink1
                            mc "Yeah..."

                            scene e4s22-35 with dissolve
                            hide e4s22_tiffany_blink1
                            pause
            "Downplay it":
                $ tiffany_trust -= 1

                $ e4s22_tiffany_upset = True

                mc "Talk about it?"
                mc "What's there to talk about?"

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink1
                tf "I don't know... I just..."

                scene e4s22-25 with dissolve
                tf "I'm not really the 'one night stand' kind of girl, you know?"

                scene e4s22-29 with dissolve
                tf "But yeah, I think you might be right."
                tf "It was just sex."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "..."

                scene e4s22-29 with dissolve
                hide e4s22_tiffany_blink1
                tf "Anyway..."

                scene e4s22-35 with dissolve
                pause
    else:
        if e2f2_tiffany_refuse == False:
            if e3s8_tiffany_hangout == True or e3s13_tiffany_hangout == True or e4s4_hangout == True:
                scene e4s22-19 with dissolve
                tf "So... how have you been, [mc]?"

                scene e4s22-17 with dissolve
                show e4s22_tiffany_blink2
                mc "I've been fine, what about you?"

                scene e4s22-33 with dissolve
                hide e4s22_tiffany_blink2
                tf "I've been keeping myself busy with classes and such."

                scene e4s22-12 with dissolve
                tf "Listen... I've been meaning to talk to you about something."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Sure, what's up?"

                scene e4s22-15 with dissolve
                hide e4s22_tiffany_blink1
                tf "So... you know how we've been hanging out ever since that house party?"

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Yeah, what about it?"

                scene e4s22-23 with dissolve
                hide e4s22_tiffany_blink1
                tf "I've been wondering how you feel."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Feel? About what?"

                scene e4s22-25 with dissolve
                hide e4s22_tiffany_blink1
                tf "About... this whole situation."

                scene e4s22-12 with dissolve
                tf "About me?"

                scene e4s22-14 with dissolve
                tf "I know we didn't hang out a whole lot."
                tf "And, it's a bit hard for me to say this..."

                scene e4s22-12 with dissolve
                tf "I don't know if I should even tell you this..."

                scene e4s22-23 with dissolve
                tf "But I've noticed I feel a certain way when I'm near you."

                scene e4s22-28 with dissolve
                tf "I think I'm developing a little crush on you."

                scene e4s22-17 with dissolve
                show e4s22_tiffany_blink2
                mc "You are?"

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink2
                tf "Yeah..."

                scene e4s22-24 with dissolve
                tf "It's been kind of hard to be honest with myself, but here we are."

                scene e4s22-25 with dissolve
                tf "And of course, I'm not expecting a relationship right away, I don't want to rush into it either."

                scene e4s22-28 with dissolve
                tf "But I'd like to know if there's a chance we could become more."

                scene e4s22-17 with dissolve
                show e4s22_tiffany_blink2
                menu:
                    "Feel the same":
                        $ e4s22_tiffany_path = True
                        $ tiffany_intimacy += 1
                        $ tiffany_trust += 1

                        mc "You know... I feel the same."
                        mc "I know circumstances haven't been the nicest to both of us."
                        mc "But I've been really enjoying your presence... and I think I'd like to get to know you more."

                        scene e4s22-26 with dissolve
                        hide e4s22_tiffany_blink2
                        tf "Really?"

                        scene e4s22-17 with dissolve
                        show e4s22_tiffany_blink2
                        mc "Yeah."
                        mc "I've been feeling like this for a bit and I'm glad you brought it up."

                        scene e4s22-27 with dissolve
                        hide e4s22_tiffany_blink2
                        tf "Haha, that's such a relief!"

                        scene e4s22-16 with dissolve
                        tf "I'm really glad we feel the same way."

                        scene e4s22-27 with dissolve
                        tf "You have no idea how easy my shoulders feel right now, haha!"

                        scene e4s22-28 with dissolve
                        tf "That's a weight off my heart."

                        scene e4s22-17 with dissolve
                        show e4s22_tiffany_blink2
                        mc "Haha!"

                        scene e4s22-32 with dissolve
                        hide e4s22_tiffany_blink2
                        tf "I can't wait for what's next."

                        scene e4s22-33 with dissolve
                        tf "It's nice to know we're both on the same page."

                        scene e4s22-17 with dissolve
                        show e4s22_tiffany_blink2
                        mc "Yeah, me too."
                        mc "It will have to wait a bit though, I'm still busy with some other stuff."

                        scene e4s22-19 with dissolve
                        hide e4s22_tiffany_blink2
                        tf "No worries, it's enough for me."

                        scene e4s22-34 with dissolve
                        pause

                    "No feelings for [tf]":
                        $ tiffany_trust -= 1

                        $ e4s22_tiffany_upset = True

                        if affinity_spectrum > 0:
                            mc "I'm sorry [tf], but I don't feel the same."
                        else:
                            mc "I'm sorry [tf], I don't want to hurt you... but I don't really feel the same."

                        scene e4s22-13 with dissolve
                        hide e4s22_tiffany_blink2
                        show e4s22_tiffany_blink1
                        mc "Yeah, we had fun together, but I always felt we did it as friends."
                        mc "I'm not really looking for anything more."

                        scene e4s22-29 with dissolve
                        hide e4s22_tiffany_blink1
                        tf "Oh... okay."

                        scene e4s22-30 with dissolve
                        tf "Well, I guess I just needed to know."
                        tf "It is what it is."

                        scene e4s22-29 with dissolve
                        tf "Thanks for being honest [mc]."

                        scene e4s22-30 with dissolve
                        tf "I hope this doesn't change the friendship between us."

                        scene e4s22-13 with dissolve
                        show e4s22_tiffany_blink1
                        mc "Well... as long as you're fine with it, I don't think it will."
                        mc "If it makes you feel uncomfortable, we can stop here."

                        scene e4s22-26 with dissolve
                        hide e4s22_tiffany_blink1
                        tf "No, no, it's fine!"

                        scene e4s22-30 with dissolve
                        tf "As I said, it was just a little crush, haha!"
                        tf "It's better to be honest upfront."

                        scene e4s22-13 with dissolve
                        show e4s22_tiffany_blink1
                        mc "Yeah..."

                        scene e4s22-35 with dissolve
                        hide e4s22_tiffany_blink1
                        pause
        else:
            scene e4s22-34 with dissolve
            pause

            scene e4s22-31 with dissolve
            tf "You know what's funny?"

            scene e4s22-19 with dissolve
            tf "We actually met earlier at that house party from two weeks ago."
            tf "Do you remember?"

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            menu:
                "Remember her":
                    mc "Yeah, I remember!"
                    mc "We didn't talk much."

                "No clue":
                    mc "Wait, really?"

                    scene e4s22-16 with dissolve
                    hide e4s22_tiffany_blink2
                    tf "Haha, yeah!"
                    tf "Did you really forget?"

                    scene e4s22-17 with dissolve
                    show e4s22_tiffany_blink2
                    mc "Yeah, we probably didn't talk a lot, so..."

            scene e4s22-33 with dissolve
            hide e4s22_tiffany_blink2
            tf "Yup, we didn't."

            scene e4s22-32 with dissolve
            tf "I asked you for a drink but you didn't want to get me one."

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            mc "Wait, now that I think about it, why didn't you just grab one yourself?"
            mc "The kitchen was just around the corner."

            scene e4s22-19 with dissolve
            hide e4s22_tiffany_blink2
            tf "I'm gonna be honest, I was a bit shy."
            tf "I didn't know anyone at that party."

            scene e4s22-32 with dissolve
            tf "It took me a while to build up the courage to ask you for one."

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            mc "And... on top of that I said no."
            mc "Was it really as bad as I imagine it right now?"

            scene e4s22-33 with dissolve
            hide e4s22_tiffany_blink2
            tf "No, not really."
            tf "Yeah, the rejection was tough to swallow."

            scene e4s22-19 with dissolve
            tf "But I'm really happy because I managed to move out of my comfort zone."
            tf "I see it as a win rather than a rejection."

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            mc "I guess I just wasn't interested, I'm sorry."

            scene e4s22-28 with dissolve
            hide e4s22_tiffany_blink2
            tf "Fair enough, I appreciate your honesty."

            scene e4s22-17 with dissolve
            show e4s22_tiffany_blink2
            mc "We still met after all, huh?"

            scene e4s22-16 with dissolve
            hide e4s22_tiffany_blink2
            tf "Haha, yeah! We did."

            scene e4s22-34 with dissolve
            pause

    if e4s16_lie == True:
        scene e4s22-22 with dissolve
        tf "Hey so, I don't mean to stress you or something..."

        scene e4s22-12 with dissolve
        tf "But, did you manage to talk to the people at Party Ragers?"
        tf "You haven't told me anything about them yet, so I was curious about what's happening."

        scene e4s22-13 with dissolve
        show e4s22_tiffany_blink1
        menu:
            "Lie to her further":
                $ e4s22_tiffany_lie = True
                if e4s22_tiffany_path == False:
                    $ e4s22_tiffany_upset = True

                mc "No... not really."

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink1
                tf "I understand."

                scene e4s22-12 with dissolve
                tf "I... I think it's best if we leave it at that."
                tf "It sounds like your club isn't open to accepting new members."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "No... it's not that."
                mc "I-"
                mc "You know what? I'll talk to them today."
                mc "You're right, I've been postponing this for too long."
                mc "It's not fair towards you."

                scene e4s22-18 with dissolve
                hide e4s22_tiffany_blink1
                tf "Thank you."

                scene e4s22-23 with dissolve
                tf "I just... really want an answer."

                scene e4s22-25 with dissolve
                tf "It feels like the situation is pretty uncertain right now."

                scene e4s22-24 with dissolve
                tf "And even if it is a no, at least I'll know."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Yeah, I'll bring it up to them."

                scene e4s22-35 with dissolve
                hide e4s22_tiffany_blink1
                pause

            "Tell her the truth":
                mc "Yeah... I'm sorry, it's a no-go."
                mc "There's a situation with a professor going on in there and they can't really take new members."
                mc "They can't even hold parties anymore."

                scene e4s22-26 with dissolve
                hide e4s22_tiffany_blink1
                tf "Oh, I hope it's nothing serious."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "It kind of is."
                mc "Their club might even get dissolved if not taken care of."

                scene e4s22-26 with dissolve
                hide e4s22_tiffany_blink1
                tf "I'm sorry about that."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "Yeah... I hope you understand the stakes now."

                scene e4s22-19 with dissolve
                hide e4s22_tiffany_blink1
                tf "I do, don't worry."

                scene e4s22-17 with dissolve
                show e4s22_tiffany_blink2
                mc "What are you gonna do now?"

                scene e4s22-14 with dissolve
                hide e4s22_tiffany_blink2
                tf "I don't know... I'll probably just focus on my classes for now."

                scene e4s22-12 with dissolve
                tf "I'm done looking for a club."

                scene e4s22-13 with dissolve
                show e4s22_tiffany_blink1
                mc "I'm sorry it got to his."

                scene e4s22-12 with dissolve
                hide e4s22_tiffany_blink1
                tf "It's fine, don't worry."

                scene e4s22-34 with dissolve
                pause

    scene e4s22-36 with dissolve
    mc "Well... I'm gonna be on my way now."

    if e4s22_tiffany_upset == True:
        scene e4s22-37 with dissolve
        mc "I think my next class is starting up soon."

        scene e4s22-38 with dissolve
        tf "Alright [mc], I'll see you around."
    else:
        scene e4s22-39 with dissolve
        mc "I think my next class is starting up soon."

        scene e4s22-40 with dissolve
        tf "Alright [mc], I'll see you around."

        scene e4s22-39 with dissolve
        if affinity_spectrum > 0 and e4s22_tiffany_path == True:
            mc "See you future girlfriend."

            scene e4s22-41 with dissolve
            tf "Haha, nooo! Stop it."

            scene e4s22-42 with dissolve
            pause
        else:
            mc "See you!"

    scene e4s22-43 with dissolve
    pause

    if e4s11_help == True or e3s23_tracy_feelings == True:
        jump e4s23
    else:
        jump e4s24
return
