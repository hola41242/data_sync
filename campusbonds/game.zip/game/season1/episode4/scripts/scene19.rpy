
default e4s19_qte = ["e4s19-36", "e4s19-37", "e4s19-38"]

if persistent.fight_difficulty == 0:
    default e4s19_qte_count = 5
    default e4s19_fail_count = 3
if persistent.fight_difficulty == 1:
    default e4s19_qte_count = 6
    default e4s19_fail_count = 2
if persistent.fight_difficulty == 2:
    default e4s19_qte_count = 8
    default e4s19_fail_count = 1

default last_fight_scene = 0
default fight_scene = 0

# Scene 19 - Turbulent trouble. ################################################

label e4s19:
    stop music fadeout 1.0
    scene e4s19-01 with wipeleft
    pause

    play music bad_sexy_dad_vibes
    scene e4s19-02 with dissolve
    jon "Alright, this is the place."

    scene e4s19-03 with dissolve
    mc "How do you even know where this guy lives?"

    scene e4s19-02 with dissolve
    jon "Did you already forget the '[sp] is my cousin' soap opera?"

    scene e4s19-04 with dissolve
    mc "Step-cousin. And what does [kv] have to do with this?"

    scene e4s19-05 with dissolve
    jon "[sp] and [kv] have been childhood BFFs since before they grew a single brain fart."
    jon "So, naturally, I got dragged along to this dipshit's house more times than I'd like to admit."

    scene e4s19-06 with dissolve
    mc "That explains a lot."

    scene e4s19-07 with dissolve
    mc "So, what exactly are we doing here?"

    scene e4s19-09 with dissolve
    jon "[mc], my dear naive friend, welcome to Plan A!"

    scene e4s19-10 with dissolve
    jon "We take his car, do a bunch of crimes, and return it like nothing ever happened."

    scene e4s19-11 with dissolve
    jon "Nobody gets hurt and it will definitely be a lot of fun."

    scene e4s19-08 with dissolve
    mc "You know, back when you first introduced me to the Party Ragers and told me that I'd have to steal a car..."
    mc "I didn't think you'd mean to 'literally' steal a car."
    mc "I thought it was like... a metaphor or something."

    scene e4s19-10 with dissolve
    jon "This will be the least weird thing you do by the time we graduate, trust me."

    scene e4s19-08 with dissolve
    mc "So, how exactly are we doing this?"

    scene e4s19-10 with dissolve
    jon "Easy, my uncle taught me when I was 8."
    jon "We lockpick the door and hotwire the car."

    scene e4s19-08 with dissolve
    mc "Isn't that illegal?"

    scene e4s19-12 with dissolve
    jon "'Isn't that illegal'?"

    scene e4s19-13 with dissolve
    jon "What are you? 10?"
    jon "Pull your shit together man, stop whining like a pussy."
    jon "Nothing's gonna happen anyway."

    scene e4s19-14 with dissolve
    mc "Alright 'pussy', let's see you do it."

    scene e4s19-15 with dissolve
    jon "Oh, I don't think I made myself clear."

    scene e4s19-16 with dissolve
    jon "{b}You{/b} are gonna do it."

    scene e4s19-08 with dissolve
    mc "Me? But I've never hijacked a car before."

    scene e4s19-11 with dissolve
    jon "Exactly!"
    jon "Perfect time to learn!"

    scene e4s19-10 with dissolve
    jon "Don't worry, I'll help you."

    scene e4s19-17 with dissolve
    pause

    scene e4s19-18 with dissolve
    pause

    scene e4s19-19 with dissolve
    pause

    scene e4s19-20 with dissolve
    pause

    scene e4s19-25 with dissolve
    kv "[ge]!"
    kv "Have you brought my shirt yet?"

    scene e4s19-24 with dissolve
    ge "Not yet sir, it's currently being ironed."

    scene e4s19-23 with dissolve
    kv "What?"
    kv "It should have been ironed by now!"
    kv "What is my father even paying you for?"

    scene e4s19-21 with dissolve
    ge "I'm terribly sorry for the inconvenience, please be assured that we're going to arrive just in time for your presentation."

    scene e4s19-22 with dissolve
    kv "Thank you [ge]!"

    scene e4s19-26 with dissolve
    pause

    scene e4s19-27 with dissolve
    jon "Alright, first step, 'The Lockpick Wiggle'."

    scene e4s19-30 with dissolve
    jon "Now, some pros use actual lockpicks."
    jon "But there wasn't a lot of time to plan this properly so I just thought a screwdriver will work just fine."

    scene e4s19-28 with dissolve
    mc "A screwdriver?"

    scene e4s19-29 with dissolve
    jon "Yeah dude, the thing you use to screw in screws?"

    scene e4s19-31 with dissolve
    jon "Anyway, just stick it in there and give it a little wiggle."

    if affinity_spectrum > 0:
        scene e4s19-32 with dissolve
        mc "Never been a problem for me."
    else:
        scene e4s19-28 with dissolve
        mc "..."

    scene e4s19-33 with dissolve
    mc "Man... this doesn't even look like it will fit in there."

    scene e4s19-34 with dissolve
    jon "Oh, oh... [mc] my friend."
    jon "Isn't it ironic?"

    scene e4s19-35 with dissolve
    jon "It's like a girl's first time, you think 'Oh... it won't fit, it's too tight.'"

    scene e4s19-33 with dissolve
    if persistent.fight == 0:
        while e4s19_qte_count > 0 and e4s19_fail_count > 0:
            call qte from _call_qte_34

            if qte == True:
                $ e4s19_qte_count -= 1

                $ fight_scene = renpy.random.choice(e4s19_qte)

                while last_fight_scene == fight_scene:
                    $ fight_scene = renpy.random.choice(e4s19_qte)

                scene expression fight_scene with dissolve

                $ last_fight_scene = fight_scene
            else:
                $ e4s19_fail_count -= 1

                $ fight_scene = renpy.random.choice(e4s19_qte)

                while last_fight_scene == fight_scene:
                    $ fight_scene = renpy.random.choice(e4s19_qte)

                show miss_screen at miss_anim
                show expression fight_scene behind miss_screen with dissolve

                $ last_fight_scene = fight_scene

        if qte_neg_count == 0:
            if persistent.tr_gallery_12_unlocked == False:
                $ persistent.tr_gallery_12_unlocked = True
                $ renpy.show_screen("render_notify")
                $ persistent.tracy12 = True
                python:
                    update_tracy_list()

        if e4s19_qte_count == 0:
            $ qte_neg_count = 0
            $ qte_pos_count = 0

            $ e4s19_qte1 = True
            pause (1.0)

            scene e4s19-39 with dissolve
            pause

            scene e4s19-40 with dissolve
            jon "Holy shit, dude, you did it!"

            scene e4s19-28 with dissolve
            mc "Haha, yeah, I did!"

            scene e4s19-45 with dissolve
            jon "I'm a bit jealous, I couldn't do it on my first try."

            scene e4s19-46 with dissolve
            mc "Beginner's luck, I guess?"

            scene e4s19-31 with dissolve
            jon "Sweet, get in."

        if e4s19_fail_count == 0:
            $ qte_neg_count = 0
            $ qte_pos_count = 0

            $ e4s19_qte1 = False
            pause (1.0)

            scene e4s19-28 with dissolve
            mc "Gah... it didn't work!"
            mc "Why on earth did you bring a freaking screwdriver for this?"

            scene e4s19-30 with dissolve
            jon "Come on, dude, it's not the end of the world."

            scene e4s19-31 with dissolve
            jon "Let me do it."

            scene e4s19-41 with dissolve
            pause

            scene e4s19-42 with dissolve
            pause

            scene e4s19-43 with dissolve
            pause

            scene e4s19-41 with dissolve
            pause

            scene e4s19-43 with dissolve
            pause

            scene e4s19-42 with dissolve
            pause

            scene e4s19-44 with dissolve
            pause

            scene e4s19-28 with dissolve
            mc "Seriously?"
            mc "How did you even do it?"

            scene e4s19-34 with dissolve
            jon "Dude, it's all about being gentle here."
            jon "You've gotta take it slow, with a delicate touch."

            scene e4s19-46 with dissolve
            mc "You ain't got a clue what you're doing, are you?"

            scene e4s19-45 with dissolve
            jon "Nope, just luck!"
            jon "Alright, now get in."
    else:
        scene e4s19-36 with dissolve
        pause

        scene e4s19-37 with dissolve
        pause

        scene e4s19-38 with dissolve
        pause

        scene e4s19-36 with dissolve
        pause

        scene e4s19-38 with dissolve
        pause

        scene e4s19-37 with dissolve
        pause

        $ e4s19_qte1 = True

        scene e4s19-39 with dissolve
        pause

        scene e4s19-40 with dissolve
        jon "Holy shit, dude, you did it!"

        scene e4s19-28 with dissolve
        mc "Haha, yeah, I did!"

        scene e4s19-45 with dissolve
        jon "I'm a bit jealous, I couldn't do it on my first try."

        scene e4s19-46 with dissolve
        mc "Beginner's luck, I guess?"

        scene e4s19-31 with dissolve
        jon "Sweet, get in."

    scene e4s19-46 with dissolve
    mc "Wait, I'm the one driving?"

    scene e4s19-45 with dissolve
    jon "Hell yeah you are!"
    jon "You're also gonna hotwire it."

    scene e4s19-46 with dissolve
    menu:
        "Be excited":
            call extrovert_affinity_check from _call_extrovert_affinity_check_65
            call color_check from _call_color_check_125
            mc "Alright dude, let's do this."

            scene e4s19-45 with dissolve
            jon "You're finally getting it!"

        "Be worried":
            call introvert_affinity_check from _call_introvert_affinity_check_56
            call color_check from _call_color_check_126
            mc "I don't know man..."
            mc "What if I mess something up with the wires and it blows up or something?"

            scene e4s19-29 with dissolve
            jon "Blows up?"
            jon "Are you even listening to yourself?"

            scene e4s19-30 with dissolve
            jon "Come on, get in. You sound ridiculous."

    scene e4s19-47 with dissolve
    pause

    scene e4s19-48 with dissolve
    jon "Alright, second step of the operation, hotwiring!"
    jon "I like to call this... the Turn-On."
    jon "Find the wires under the steering column."
    jon "They're usually all tucked up in there."

    scene e4s19-49 with dissolve
    mc "I can't see shit!"

    scene e4s19-48 with dissolve
    jon "Right... let me turn on the lights."

    scene e4s19-50 with dissolve
    pause

    scene e4s19-51 with dissolve
    jon "Now comes the fun part."

    scene e4s19-52 with dissolve
    jon "You grab the red wire and the green wire, those are your power and ignition wires."

    scene e4s19-51 with dissolve
    jon "Not the blue one, or you'll fry the system, and we don't need that kind of heat."
    jon "Twist them a little, then give it a little spark."

    scene e4s19-53 with dissolve
    mc "Just like that?"

    scene e4s19-51 with dissolve
    jon "Yup!"

    scene e4s19-54 with dissolve
    mc "*Seems easy enough.*"

    scene e4s19-55 with dissolve
    pause

    scene e4s19-56 with dissolve
    pause

    scene e4s19-57 with dissolve
    pause

    scene e4s19-58 with dissolve
    pause

    scene e4s19-59 with dissolve
    jon "Wow, you actually did it."

    scene e4s19-63 with dissolve
    mc "Was I supposed to fail or what?"

    scene e4s19-60 with dissolve
    jon "No... it's just..."

    scene e4s19-59 with dissolve
    jon "You know what? Nevermind."

    scene e4s19-61 with dissolve
    jon "The sooner we get out of here, the better."

    scene e4s19-62 with dissolve
    jon "Come on, let's go!"

    scene e4s19-64 with dissolve
    pause

    scene e4s19-65 with dissolve
    pause

    stop music fadeout 1.0
    scene e4s19-66 with dissolve
    pause

    play music liar
    scene e4s19-67 with wipeleft
    pause

    scene e4s19-68 with dissolve
    jon "Come on, man, speed it up!"
    jon "You're driving like my grandma."

    scene e4s19-69 with dissolve
    mc "Uh... sorry dude?"
    mc "I don't even have a license."

    scene e4s19-70 with dissolve
    jon "You don-"
    jon "You don't have a license?"

    scene e4s19-71 with dissolve
    jon "This is gold!"

    scene e4s19-72 with dissolve
    jon "Step on the gas then, let's have some fun!"

    scene e4s19-73 with dissolve
    jon "This shall mark your first ever over-the-speed-limit experience."

    scene e4s19-74 with dissolve
    pause

    scene e4s19-75 with dissolve
    pause

    play music nerve_damage
    scene e4s19-76 with vpunch
    pause

    scene e4s19-77 with dissolve
    pause

    scene e4s19-78 with dissolve
    pause

    scene e4s19-79 with dissolve
    pause

    scene e4s19-80 with dissolve
    jon "Looks like we're picking up some heat."

    scene e4s19-81 with dissolve
    mc "Oh shit, cops!"

    scene e4s19-80 with dissolve
    jon "That's exactly what we wanted."

    scene e4s19-82 with dissolve
    jon "Now... at any point, if this is too much for you, tell me and I will take over, alright?"

    scene e4s19-83 with dissolve
    menu:
        "Too much":
            call introvert_affinity_check from _call_introvert_affinity_check_57
            call color_check from _call_color_check_127
            mc "It's a bit too much for me, you can take over."

            scene e4s19-82 with dissolve
            jon "Alright, move over."

            scene e4s19-83 with dissolve
            mc "What, now?"

            scene e4s19-82 with dissolve
            jon "Yup, just keep her steady."

            scene e4s19-84 with dissolve
            mc "Oh my God..."

            scene e4s19-85 with dissolve
            jon "You feel that? The adrenaline?"

            scene e4s19-86 with dissolve
            jon "It's like nothing else."

            scene e4s19-87 with dissolve
            mc "This was a horrible idea."
            mc "We could really get arrested. Or worse."

            scene e4s19-85 with dissolve
            jon "Relax, we'll be fine."
            jon "I got this."
        "Keep going":
            call extrovert_affinity_check from _call_extrovert_affinity_check_66
            call color_check from _call_color_check_128
            scene e4s19-88 with dissolve
            mc "Nah, I'll keep going."
            mc "I'm actually enjoying this!"

            scene e4s19-89 with dissolve
            jon "Haha, attaboy!"
            jon "You feel that? The adrenaline?"
            jon "It's like nothing else."

            scene e4s19-81 with dissolve
            mc "Are they still on us?"

            scene e4s19-92 with dissolve
            jon "Yup, still behind."

            scene e4s19-90 with dissolve
            jon "Here, make a turn to the right."

            scene e4s19-91 with dissolve
            if persistent.fight == 0:
                call qte from _call_qte_35
                if qte_neg_count == 0:
                    $ qte_neg_count == 0
                    $ qte_pos_count == 0

                    scene e4s19-67 with dissolve
                    pause

                    scene e4s19-70 with dissolve
                    jon "Come on, hit the gas!"
                    jon "They're right behind us."

                    scene e4s19-81 with dissolve
                    mc "This fucking piece of trash doesn't go any faster."

                    scene e4s19-92 with dissolve
                    jon "We're gonna have to improvise."

                    scene e4s19-93 with dissolve
                    jon "Shit, blockage."
                    jon "Quick, to the right!"

                    scene e4s19-91 with dissolve
                    call qte from _call_qte_36

                    if qte_neg_count == 0:
                        $ qte_neg_count == 0
                        $ qte_pos_count == 0

                        scene e4s19-67 with dissolve
                        mc "Fuck... I hope I didn't hit anything."
                    else:
                        $ e4s19_fail = True
                        $ qte_neg_count == 0
                        $ qte_pos_count == 0

                        play sound weights
                        scene e4s19-67 with vpunch
                        mc "Fuck!"

                        scene e4s19-70 with dissolve
                        jon "Dude, what happened?"

                        scene e4s19-69 with dissolve
                        mc "I think I hit a curb when I was taking the turn."

                        scene e4s19-70 with dissolve
                        jon "That didn't sound good."

                    scene e4s19-70 with dissolve
                    jon "Let me take over."

                    scene e4s19-69 with dissolve
                    mc "What, now?"

                    scene e4s19-70 with dissolve
                    jon "Yup, just keep her steady."

                    scene e4s19-84 with dissolve
                    mc "Oh my God..."
                else:
                    $ e4s19_fail = True
                    $ qte_neg_count == 0
                    $ qte_pos_count == 0

                    play sound weights
                    scene e4s19-67 with vpunch
                    mc "Oh shit!"

                    scene e4s19-70 with dissolve
                    jon "Dude, what happened?"

                    scene e4s19-69 with dissolve
                    mc "I think I hit a curb when I was taking the turn."

                    scene e4s19-70 with dissolve
                    jon "That didn't sound good."
                    jon "Let me take over."

                    scene e4s19-69 with dissolve
                    mc "What, now?"

                    scene e4s19-70 with dissolve
                    jon "Yup, just keep her steady."

                    scene e4s19-84 with dissolve
                    mc "Oh my God..."
            else:
                $ e4s19_fail = True
                pause

                play sound weights
                scene e4s19-67 with vpunch
                mc "Oh shit!"

                scene e4s19-70 with dissolve
                jon "Dude, what happened?"

                scene e4s19-69 with dissolve
                mc "I think I hit a curb when I was taking the turn."

                scene e4s19-70 with dissolve
                jon "That didn't sound good."
                jon "Let me take over."

                scene e4s19-69 with dissolve
                mc "What, now?"

                scene e4s19-70 with dissolve
                jon "Yup, just keep her steady."

                scene e4s19-84 with dissolve
                mc "Oh my God..."

    stop music fadeout 1.0
    scene e4s19-85 with dissolve
    jon "Alright, let's see how we're gonna lose the cops."
    jon "I think I know a way around here."

    scene e4s19-94 with wipeleft
    pause

    scene e4s19-96 with dissolve
    jon "There, I bought us enough time."
    jon "Let's get out of here."
    mc "Holy shit..."

    scene e4s19-95 with dissolve
    pause

    scene e4s19-97 with dissolve
    pause

    if e4s19_fail == True:
        scene e4s19-98 with dissolve
        mc "What about the curb?"

        scene e4s19-101 with dissolve
        jon "Chances are he won't even notice it!"

    scene e4s19-100 with dissolve
    pause

    scene e4s19-102 with dissolve
    pause

    scene e4s19-103 with dissolve
    play sound door_open
    kv "Can I help you with something?"

    play music nerve_damage
    scene e4s19-104 with vpunch
    unknown "ON THE GROUND, NOW!"
    kv "What? But- but... what did I do?"

    stop music fadeout 2.0
    scene e4s19-105 with dissolve
    jon "Haha, worked like a charm!"
    jon "This should keep him away from candidating."

    scene e4s19-98 with dissolve
    mc "Man, that was crazy, we could have been caught!"

    scene e4s19-99 with dissolve
    jon "But we weren't, were we?"

    scene e4s19-105 with dissolve
    jon "Come on, he's gonna get a slap on the wrist at most."
    jon "He'll be fine."

    if affinity_spectrum < 0:
        scene e4s19-106 with dissolve
        mc "How can you be sure?"

        scene e4s19-99 with dissolve
        jon "His parents are rich, they're gonna bail him out."

        scene e4s19-106 with dissolve
        jon "Let's go."

    jump e4s20
return
