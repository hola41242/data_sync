
default e4s35_sadie_position = False

# Scene 35 - Emotional love ####################################################

label e4s35:
    stop music fadeout 1.0
    scene e4s35-01 with wipeleft
    pause

    play music border_blaster
    scene e4s35-03 with dissolve
    sd "I had a great time tonight!"
    sd "Thank you for taking me out."

    scene e4s35-02 with dissolve
    show e4s35_sadie_blink1
    mc "Thank you for joining me."
    mc "It was certainly great."

    scene e4s35-04 with dissolve
    hide e4s35_sadie_blink1
    sd "It was a much needed break from all this monotony."

    scene e4s35-02 with dissolve
    show e4s35_sadie_blink1
    mc "Yeah, for sure."

    if e4s34_bathroom_lewd == True or e4s34_blowjob == False:
        mc "Well, I'll see you around."
        mc "Good night [sd]!"

        scene e4s35-03 with dissolve
        hide e4s35_sadie_blink1
        sd "Night [mc], see you!"

        scene e4s35-05 with dissolve
        pause

        jump e4s36

    $ sadie_intimacy += 1

    scene e4s35-06 with dissolve
    sd "Would you like to grab one more drink inside?"

    scene e4s35-07 with dissolve
    sd "Maybe you can sleep the night at my place."

    scene e4s35-02 with dissolve
    show e4s35_sadie_blink1
    mc "Really?"

    scene e4s35-08 with dissolve
    hide e4s35_sadie_blink1
    sd "Yeah, dude."
    sd "Don't make me ask you twice, haha!"

    scene e4s35-02 with dissolve
    show e4s35_sadie_blink1
    mc "Yeah, I'd love to."
    mc "Let's go."

    scene e4s35-09 with dissolve
    hide e4s35_sadie_blink1
    pause

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music snowday
    scene e4s35-10 with Dissolve(2.0)
    pause

    scene e4s35-11 with dissolve
    pause

    scene e4s35-12 with dissolve
    sd "Finally, managed to take this make up off."
    sd "Remind me to never go overboard again."

    scene e4s35-13 with dissolve
    mc "Haha, duly noted."

    if e2s10_sadie == True:
        mc "So... you're not gonna make me take the couch again?"

        scene e4s35-14 with dissolve
        sd "Again?"
        sd "Like you even slept there, haha!"

        scene e4s35-15 with dissolve
        sd "But no, I will not make you take it."
        sd "You're fine to sleep next to."

    scene e4s35-16 with dissolve
    pause

    call e4s35_lewd from _call_e4s35_lewd

    jump e4s36
return


label e4s35_lewd:
    scene e4s35-17 with dissolve
    mc "I'm wasted, tonight was so nice."
    mc "It really felt like that fancy experience."

    scene e4s35-18 with dissolve
    mc "With... the added experience."

    scene e4s35-20 with dissolve
    sd "Haha!"

    scene e4s35-22 with dissolve
    sd "So, I get that you enjoyed my services."

    scene e4s35-19 with dissolve
    mc "I enjoyed you more than your services."
    mc "Thank you, again, for joining me."
    mc "You're really great."
    mc "And I'm glad we got to spend this time together."

    scene e4s35-21 with dissolve
    sd "You're really sweet, [mc]."

    scene e4s35-23 with dissolve
    sd "I can't remember the last time I felt so good like this."

    scene e4s35-22 with dissolve
    sd "You make me feel truly special."

    scene e4s35-24 with dissolve
    sd "I appreciate you for that, you know?"
    sd "You're a great guy."

    scene e4s35-25 with dissolve
    pause

    scene e4s35-26 with dissolve
    pause

    scene e4s35-kiss1 with dissolve
    pause

    scene e4s35-kiss2 with dissolve
    pause

    scene e4s35-kiss3 with dissolve
    pause

    scene e4s35-27 with dissolve
    pause

    scene e4s35-30 with dissolve
    pause

    scene e4s35-28 with dissolve
    sd "I've waited the whole night for this."

    scene e4s35-29 with dissolve
    mc "Then, let's do it right."

    scene e4s35-kiss1 with dissolve
    pause

    scene e4s35-kiss2 with dissolve
    pause

    scene e4s35-kiss3 with dissolve
    pause

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        scene e4s35-31 with dissolve
        pause

        scene e4s35-32 with dissolve
        sd "Oh..."

        scene e4s35-33 with dissolve
        pause

        scene e4s35-34 with dissolve
        pause

        scene e4s35-35 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e4s35-36 with dissolve
            pause

            scene e4s35-37 with dissolve
            pause

            scene e4s35-38 with dissolve
            sd "Damn... you're making me so wet."

            scene e4s35-40 with dissolve
            mc "Let's check it out, then."

            scene e4s35-39 with dissolve
            pause

            if e4s33_lingerie == True:
                scene e4s35-44 with dissolve
                pause

                scene e4s35-42 with dissolve
                mc "Wait, you didn't take the lingerie off?"

                scene e4s35-46 with dissolve
                sd "Of course not, silly."
                sd "I saved it for you."

                scene e4s35-47 with dissolve
                sd "It seemed like you really liked it so decided to keep it."

                scene e4s35-49 with dissolve
                mc "You're amazing!"
            else:
                scene e4s35-41 with dissolve
                pause

            scene e4s35-42 with dissolve
            mc "Does this feel good?"

            scene e4s35-50 with dissolve
            pause

            # Fingering

            scene e4s35-fingering1 with dissolve
            sd "Oh... yeah!"

            scene e4s35-45 with dissolve
            sd "It feels... uh- really good."

            scene e4s35-fingering2 with dissolve
            sd "Ah..."

            scene e4s35-fingering1 with dissolve
            pause

            scene e4s35-fingering2 with dissolve
            pause

            scene e4s35-pussy_eating1 with dissolve
            sd "Fuck..."

            scene e4s35-pussy_eating2 with dissolve
            pause

            scene e4s35-pussy_eating1 with dissolve
            sd "Uhh!"

            scene e4s35-52 with dissolve
            sd "[mc]..."

            scene e4s35-50 with dissolve
            mc "Yeah?"

            scene e4s35-52 with dissolve
            sd "Stick a finger in..."

            scene e4s35-48 with dissolve
            mc "Like this?"

            scene e4s35-53 with dissolve
            pause

            scene e4s35-54 with dissolve
            sd "Oh my God..."

            scene e4s35-51 with dissolve
            sd "Damn, that feels really good!"

            scene e4s35-fingering3 with dissolve
            pause

            scene e4s35-fingering4 with dissolve
            sd "Ah... keep going."

            scene e4s35-fingering3 with dissolve
            pause

            scene e4s35-fingering4 with dissolve
            pause

            scene e4s35-43 with dissolve
            sd "Oh... that's so... uh- hot."

            scene e4s35-fingering5 with dissolve
            sd "Uh..."

            scene e4s35-52 with dissolve
            sd "Yeah... keep eating me."

            scene e4s35-fingering6 with dissolve
            sd "Ah... [mc]!"

            scene e4s35-fingering5 with dissolve
            pause

            scene e4s35-fingering6 with dissolve
            sd "If you keep going on like this..."
            sd "Uh..."

            scene e4s35-fingering7 with dissolve
            sd "Ahhh!"
            sd "[mc], I'm-"
            sd "I'm gonna cum!"
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e4s35-55 with dissolve
            sd "Oh... fuck!"

            scene e4s35-56 with dissolve
            sd "Damn, that felt amazing."

            scene e4s35-49 with dissolve
            mc "I'm glad you enjoyed it!"

            scene e4s35-57 with dissolve
            pause

            scene e4s35-58 with dissolve
            pause

            scene e4s35-59 with dissolve
            pause

            scene e4s35-60 with dissolve
            pause

            scene e4s35-61 with dissolve
            pause

            scene e4s35-62 with dissolve
            pause

            scene e4s35-63 with dissolve
            sd "Looks like he's been waiting for his chance as well, huh?"

            scene e4s35-64 with dissolve
            mc "Can you really blame him?"

            scene e4s35-65 with dissolve
            sd "Haha, I guess not!"

            scene e4s35-66 with dissolve
            pause

            scene e4s35-67 with dissolve
            pause

            scene e4s35-68 with dissolve
            pause

            scene e4s35-69 with dissolve
            pause

            scene e4s35-70 with dissolve
            sd "Fuuuck!"

            # Cowgirl

            scene e4s35-cowgirl1 with dissolve
            pause

            scene e4s35-cowgirl2 with dissolve
            sd "Ah... oh my God."

            scene e4s35-cowgirl3 with dissolve
            pause

            scene e4s35-cowgirl1 with dissolve
            sd "My pussy is so sensitive, oh!"

            scene e4s35-cowgirl2 with dissolve
            pause

            scene e4s35-cowgirl3 with dissolve
            mc "Damn... you're so tight."
            mc "Fuck..."

            scene e4s35-cowgirl4 with dissolve
            mc "It feels amazing!"

            scene e4s35-cowgirl5 with dissolve
            pause

            scene e4s35-cowgirl3 with dissolve
            mc "You are so beautiful, [sd]."

            scene e4s35-cowgirl4 with dissolve
            sd "Oh..."

            scene e4s35-cowgirl8 with dissolve
            pause

            scene e4s35-cowgirl6 with dissolve
            pause

            scene e4s35-cowgirl7 with dissolve
            pause

            scene e4s35-cowgirl9 with dissolve
            sd "Oh... [mc]..."

            scene e4s35-71 with dissolve
            sd "You can cum whenever you want."

            scene e4s35-cowgirl6 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e4s35-36_cen with dissolve
                pause

                scene e4s35-37_cen with dissolve
                pause

                scene e4s35-38_cen with dissolve
                sd "Damn... you're making me so wet."

                scene e4s35-40_cen with dissolve
                mc "Let's check it out, then."

                scene e4s35-39_cen with dissolve
                pause

                if e4s33_lingerie == True:
                    scene e4s35-44_cen with dissolve
                    pause

                    scene e4s35-42_cen with dissolve
                    mc "Wait, you didn't take the lingerie off?"

                    scene e4s35-46_cen with dissolve
                    sd "Of course not, silly."
                    sd "I saved it for you."

                    scene e4s35-47_cen with dissolve
                    sd "It seemed like you really liked it so decided to keep it."

                    scene e4s35-49_cen with dissolve
                    mc "You're amazing!"
                else:
                    scene e4s35-41_cen with dissolve
                    pause

                scene e4s35-42_cen with dissolve
                mc "Does this feel good?"

                scene e4s35-50_cen with dissolve
                pause

                # Fingering

                scene e4s35-fingering1_cen with dissolve
                sd "Oh... yeah!"

                scene e4s35-45_cen with dissolve
                sd "It feels... uh- really good."

                scene e4s35-fingering2_cen with dissolve
                sd "Ah..."

                scene e4s35-fingering1_cen with dissolve
                pause

                scene e4s35-fingering2_cen with dissolve
                pause

                scene e4s35-pussy_eating1_cen with dissolve
                sd "Fuck..."

                scene e4s35-pussy_eating2_cen with dissolve
                pause

                scene e4s35-pussy_eating1_cen with dissolve
                sd "Uhh!"

                scene e4s35-52_cen with dissolve
                sd "[mc]..."

                scene e4s35-50_cen with dissolve
                mc "Yeah?"

                scene e4s35-52_cen with dissolve
                sd "Stick a finger in..."

                scene e4s35-48_cen with dissolve
                mc "Like this?"

                scene e4s35-53_cen with dissolve
                pause

                scene e4s35-54_cen with dissolve
                sd "Oh my God..."

                scene e4s35-51_cen with dissolve
                sd "Damn, that feels really good!"

                scene e4s35-fingering3_cen with dissolve
                pause

                scene e4s35-fingering4_cen with dissolve
                sd "Ah... keep going."

                scene e4s35-fingering3_cen with dissolve
                pause

                scene e4s35-fingering4_cen with dissolve
                pause

                scene e4s35-43_cen with dissolve
                sd "Oh... that's so... uh- hot."

                scene e4s35-fingering5_cen with dissolve
                sd "Uh..."

                scene e4s35-52_cen with dissolve
                sd "Yeah... keep eating me."

                scene e4s35-fingering6_cen with dissolve
                sd "Ah... [mc]!"

                scene e4s35-fingering5_cen with dissolve
                pause

                scene e4s35-fingering6_cen with dissolve
                sd "If you keep going on like this..."
                sd "Uh..."

                scene e4s35-fingering7_cen with dissolve
                sd "Ahhh!"
                sd "[mc], I'm-"
                sd "I'm gonna cum!"
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e4s35-55_cen with dissolve
                sd "Oh... fuck!"

                scene e4s35-56_cen with dissolve
                sd "Damn, that felt amazing."

                scene e4s35-49_cen with dissolve
                mc "I'm glad you enjoyed it!"

                scene e4s35-57_cen with dissolve
                pause

                scene e4s35-58_cen with dissolve
                pause

                scene e4s35-59 with dissolve
                pause

                scene e4s35-60_cen with dissolve
                pause

                scene e4s35-61_cen with dissolve
                pause

                scene e4s35-62_cen with dissolve
                pause

                scene e4s35-63_cen with dissolve
                sd "Looks like he's been waiting for his chance as well, huh?"

                scene e4s35-64_cen with dissolve
                mc "Can you really blame him?"

                scene e4s35-65_cen with dissolve
                sd "Haha, I guess not!"

                scene e4s35-66_cen with dissolve
                pause

                scene e4s35-67_cen with dissolve
                pause

                scene e4s35-68_cen with dissolve
                pause

                scene e4s35-69_cen with dissolve
                pause

                scene e4s35-70_cen with dissolve
                sd "Fuuuck!"

                # Cowgirl

                scene e4s35-cowgirl1_cen with dissolve
                pause

                scene e4s35-cowgirl2_cen with dissolve
                sd "Ah... oh my God."

                scene e4s35-cowgirl3_cen with dissolve
                pause

                scene e4s35-cowgirl1_cen with dissolve
                sd "My pussy is so sensitive, oh!"

                scene e4s35-cowgirl2_cen with dissolve
                pause

                scene e4s35-cowgirl3_cen with dissolve
                mc "Damn... you're so tight."
                mc "Fuck..."

                scene e4s35-cowgirl4_cen with dissolve
                mc "It feels amazing!"

                scene e4s35-cowgirl5_cen with dissolve
                pause

                scene e4s35-cowgirl3_cen with dissolve
                mc "You are so beautiful, [sd]."

                scene e4s35-cowgirl4_cen with dissolve
                sd "Oh..."

                scene e4s35-cowgirl8_cen with dissolve
                pause

                scene e4s35-cowgirl6_cen with dissolve
                pause

                scene e4s35-cowgirl7_cen with dissolve
                pause

                scene e4s35-cowgirl9_cen with dissolve
                sd "Oh... [mc]..."

                scene e4s35-71 with dissolve
                sd "You can cum whenever you want."

                scene e4s35-cowgirl6_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Fingering":
                    $ config.rollback_enabled = True

                    $ e4s35_sadie_position = True

                    if persistent.disable_nsfw == True:
                        scene e4s35-fingering1 with dissolve
                        sd "Oh... yeah!"
                        sd "It feels... uh- really good."

                        scene e4s35-fingering2 with dissolve
                        sd "Ah..."

                        scene e4s35-fingering1 with dissolve
                        pause

                        scene e4s35-fingering2 with dissolve
                        pause

                        scene e4s35-pussy_eating1 with dissolve
                        sd "Fuck..."

                        scene e4s35-pussy_eating2 with dissolve
                        pause

                        scene e4s35-pussy_eating1 with dissolve
                        sd "Uhh!"

                        scene e4s35-fingering3 with dissolve
                        sd "Damn, that feels really good!"

                        scene e4s35-fingering4 with dissolve
                        sd "Ah... keep going."

                        scene e4s35-fingering3 with dissolve
                        pause

                        scene e4s35-fingering4 with dissolve
                        sd "Oh... that's so... uh- hot."

                        scene e4s35-fingering5 with dissolve
                        sd "Uh..."
                        sd "Yeah... keep eating me."

                        scene e4s35-fingering6 with dissolve
                        sd "Ah... [mc]!"

                        scene e4s35-fingering5 with dissolve
                        pause

                        scene e4s35-fingering6 with dissolve
                        sd "Uh..."

                        scene e4s35-fingering7 with dissolve
                        sd "Ahhh!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s35-fingering1_cen with dissolve
                            sd "Oh... yeah!"
                            sd "It feels... uh- really good."

                            scene e4s35-fingering2_cen with dissolve
                            sd "Ah..."

                            scene e4s35-fingering1_cen with dissolve
                            pause

                            scene e4s35-fingering2_cen with dissolve
                            pause

                            scene e4s35-pussy_eating1_cen with dissolve
                            sd "Fuck..."

                            scene e4s35-pussy_eating2_cen with dissolve
                            pause

                            scene e4s35-pussy_eating1_cen with dissolve
                            sd "Uhh!"

                            scene e4s35-fingering3_cen with dissolve
                            sd "Damn, that feels really good!"

                            scene e4s35-fingering4_cen with dissolve
                            sd "Ah... keep going."

                            scene e4s35-fingering3_cen with dissolve
                            pause

                            scene e4s35-fingering4_cen with dissolve
                            sd "Oh... that's so... uh- hot."

                            scene e4s35-fingering5_cen with dissolve
                            sd "Uh..."
                            sd "Yeah... keep eating me."

                            scene e4s35-fingering6_cen with dissolve
                            sd "Ah... [mc]!"

                            scene e4s35-fingering5_cen with dissolve
                            pause

                            scene e4s35-fingering6_cen with dissolve
                            sd "Uh..."

                            scene e4s35-fingering7_cen with dissolve
                            sd "Ahhh!"
                "Cowgirl":
                    $ config.rollback_enabled = True

                    $ e4s35_sadie_position = True

                    if persistent.disable_nsfw == True:
                        scene e4s35-cowgirl1 with dissolve
                        pause

                        scene e4s35-cowgirl2 with dissolve
                        sd "Ah... oh my God."

                        scene e4s35-cowgirl3 with dissolve
                        pause

                        scene e4s35-cowgirl1 with dissolve
                        sd "My pussy is so sensitive, oh!"

                        scene e4s35-cowgirl2 with dissolve
                        pause

                        scene e4s35-cowgirl3 with dissolve
                        mc "Damn... you're so tight."
                        mc "Fuck..."

                        scene e4s35-cowgirl4 with dissolve
                        mc "It feels amazing!"

                        scene e4s35-cowgirl5 with dissolve
                        pause

                        scene e4s35-cowgirl3 with dissolve
                        mc "You are so beautiful, [sd]."

                        scene e4s35-cowgirl4 with dissolve
                        sd "Oh..."

                        scene e4s35-cowgirl8 with dissolve
                        pause

                        scene e4s35-cowgirl6 with dissolve
                        pause

                        scene e4s35-cowgirl7 with dissolve
                        pause

                        scene e4s35-cowgirl9 with dissolve
                        sd "Oh... [mc]..."
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s35-cowgirl1_cen with dissolve
                            pause

                            scene e4s35-cowgirl2_cen with dissolve
                            sd "Ah... oh my God."

                            scene e4s35-cowgirl3_cen with dissolve
                            pause

                            scene e4s35-cowgirl1_cen with dissolve
                            sd "My pussy is so sensitive, oh!"

                            scene e4s35-cowgirl2_cen with dissolve
                            pause

                            scene e4s35-cowgirl3_cen with dissolve
                            mc "Damn... you're so tight."
                            mc "Fuck..."

                            scene e4s35-cowgirl4_cen with dissolve
                            mc "It feels amazing!"

                            scene e4s35-cowgirl5_cen with dissolve
                            pause

                            scene e4s35-cowgirl3_cen with dissolve
                            mc "You are so beautiful, [sd]."

                            scene e4s35-cowgirl4_cen with dissolve
                            sd "Oh..."

                            scene e4s35-cowgirl8_cen with dissolve
                            pause

                            scene e4s35-cowgirl6_cen with dissolve
                            pause

                            scene e4s35-cowgirl7_cen with dissolve
                            pause

                            scene e4s35-cowgirl9_cen with dissolve
                            sd "Oh... [mc]..."
                "Cum":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s35-cowgirl6 with dissolve
                        mc "[sd]... I'm going to cum."

                        scene e4s35-71 with dissolve
                        sd "Do it inside me..."

                        scene e4s35-cowgirl7 with dissolve
                        sd "Ah..."

                        scene e4s35-cowgirl9 with dissolve
                        mc "Fuck... here it comes..."

                        scene e4s35-cowgirl6 with dissolve
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s35-cowgirl6_cen with dissolve
                            mc "[sd]... I'm going to cum."

                            scene e4s35-71 with dissolve
                            sd "Do it inside me..."

                            scene e4s35-cowgirl7_cen with dissolve
                            sd "Ah..."

                            scene e4s35-cowgirl9_cen with dissolve
                            mc "Fuck... here it comes..."

                            scene e4s35-cowgirl6_cen with dissolve
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)

                    scene e4s35-72 with dissolve
                    mc "Ah... fuck!"

                    scene e4s35-73 with dissolve
                    mc "You were amazing [sd]."
                    mc "I could barely last."

                    scene e4s35-74 with dissolve
                    sd "You're telling me?"

                    if e4s35_sadie_position == True:
                        sd "I think I came a second time."

                    scene e4s35-75 with dissolve
                    sd "That was out of this world."

                    scene e4s35-73 with dissolve
                    mc "Haven't heard that one before, haha!"

                    scene e4s35-76 with dissolve
                    sd "Shit... now your ego's gonna get too inflated."

                    scene e4s35-74 with dissolve
                    sd "I cracked, what can I say."

                    scene e4s35-77 with dissolve
                    mc "You can allow yourself to crack around me."
                    mc "You don't need to keep your walls up."

                    scene e4s35-75 with dissolve
                    sd "I know... it's still a bit hard, you know?"

                    scene e4s35-76 with dissolve
                    sd "I'm not used to this type of love."

                    scene e4s35-77 with dissolve
                    mc "I'd be more than happy to be on your side and teach you all about it."
                    mc "I promise it's the greatest."

                    scene e4s35-78 with dissolve
                    sd "Okay... I trust you."

                    if persistent.disable_nsfw == True:
                        scene e4s35-79 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s35-79_cen with dissolve
                            pause

                    $ GameRunning = False

    $ renpy.end_replay()
return
