
# Scene 7 - Lunch with Tiffany #################################################

label e4s7:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music the_pawnbrokers_stepdaughter
    scene e4s7-02 with Dissolve(2.0)
    tf "So... your father actually divorced your mother?"

    scene e4s7-01 with dissolve
    show e4s7_tiffany_blink1
    mc "Yup."

    scene e4s7-02 with dissolve
    hide e4s7_tiffany_blink1
    tf "How did that happen?"

    scene e4s7-01 with dissolve
    show e4s7_tiffany_blink1
    mc "He basically said he overworked himself and mom was never happy about it."
    mc "He decided it was best to leave."

    scene e4s7-03 with dissolve
    hide e4s7_tiffany_blink1
    tf "I'm sorry, [mc]."
    tf "I know this must be hard to take in."

    scene e4s7-01 with dissolve
    show e4s7_tiffany_blink1
    mc "Yeah, it is."
    mc "There are still some unanswered questions I'll have to dig into."
    mc "One of my friends recommended that I do some therapy, but I'm not a hundred percent sure I'll follow up with it."

    menu:
        "Open to therapy":
            $ e4s7_therapy_open = True
            mc "I went once and it felt alright, might have to give it another shot."

            scene e4s7-08 with dissolve
            tf "That's really good, I'm glad!"

            scene e4s7-09 with dissolve
            tf "And I'm also glad you opened up to me."

            scene e4s7-08 with dissolve

        "Hesitant about therapy":
            mc "I went once but so far I'm not convinced."

            scene e4s7-02 with dissolve
            tf "That's okay too."

            scene e4s7-03 with dissolve
            tf "You'll know when it feels right."

            scene e4s7-02 with dissolve
            tf "Just... don't close yourself off forever, alright?"

            scene e4s7-08 with dissolve
            tf "I'm so glad you opened up to me."

    tf "Just know that I'm here, alright?"

    scene e4s7-09 with dissolve
    tf "With or without your therapy, you can talk to me about your problems."

    scene e4s7-07 with dissolve
    tf "Even though I might not have the answer, at least you'll have someone to speak to."

    scene e4s7-06 with dissolve
    show e4s7_tiffany_blink1
    mc "Thanks, [tf], that means a lot to me."
    mc "It's a bit hard to trust him now."

    scene e4s7-05 with dissolve
    hide e4s7_tiffany_blink1
    tf "Give it time, the wound is still fresh."

    scene e4s7-04 with dissolve
    tf "I'm sure your dad is not a bad person, just hurt like you are."

    scene e4s7-06 with dissolve
    show e4s7_tiffany_blink1
    mc "Yeah, he's not."
    mc "But anyway, I'll get going, thanks for listening to me."

    scene e4s7-05 with dissolve
    hide e4s7_tiffany_blink1
    tf "No problem!"

    scene e4s7-06 with dissolve
    show e4s7_tiffany_blink1
    menu:
        "Listen to her too":
            $ tiffany_trust += 1
            mc "This goes both ways, I'm more than happy to listen to you too."
            mc "If you ever run into any problem whatsoever, I'm here."

            scene e4s7-09 with dissolve
            hide e4s7_tiffany_blink1
            tf "Thank you, [mc]!"

        "Say goodbye":
            mc "See you later!"

            scene e4s7-08 with dissolve
            hide e4s7_tiffany_blink1
            tf "Bye."

    stop music fadeout 1.0
    scene e4s7-10 with dissolve
    pause

    jump e4s8
return
