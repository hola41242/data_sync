
# Scene 5 - Class ##############################################################

label e4s5:
    play music little_tomcat
    scene e4s5-01 with wipeleft
    br "Good morning class!"
    br "Today's lesson is going to be a bit different and will require you to work in pairs."

    scene e4s5-06 with dissolve
    jon "Yo!"

    scene e4s5-02 with dissolve
    pause

    scene e4s5-07 with dissolve
    mc "What's up?"

    scene e4s5-09 with dissolve
    jon "Just sitting through this boring class."

    scene e4s5-08 with dissolve
    jon "Listen, I gotta tell you something."
    jon "Meet me after class at Party Ragers, alright?"

    scene e4s5-05 with dissolve
    br "Quiet, please!"

    if affinity_spectrum > 0:
        scene e4s5-04 with dissolve
        mc "Sorry."
    else:
        scene e4s5-03 with dissolve
        mc "Sorry."

    scene e4s5-10 with dissolve
    mc "Okay bro, see you there."

    scene e4s5-11 with dissolve
    br "With that being said, go ahead and choose a partner, when you're ready we'll begin."

    scene e4s5-06 with dissolve
    mc "*[br] said we should work in pairs.*"
    mc "*I should go ahead and find someone to partner with.*"

    call e4f1 from _call_e4f1

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music write_hear_right_now
    scene e4s5-11 with Dissolve(2.0)
    br "Alright, now that everyone has a partner, let's begin."
    br "I'm going to hand each of you a note containing a theme."

    scene e4s5-12 with dissolve
    pause

    scene e4s5-13 with dissolve
    br "You'll make the best of your ability to create and present that project in front of the class."
    br "Try to make it as interesting as possible."

    if e4f1_bridget_partner == True:
        scene e4s5-br_07 with dissolve
        br "Here's our note, [mc]."

        scene e4s5-br_08 with dissolve
        mc "Let's see what we got."

        scene e4s5-br_09 with dissolve
        mc "*Education Systems and Their Impact on Creativity.*"
        mc "*That's ironic. Guess I'm about to learn from the teacher herself.*"

        scene black with Dissolve(2.0)

        scene e4s5-br_01 with Dissolve(2.0)
        show e4s5_bridget_blink1
        mc "So... how do we go about this one?"

        scene e4s5-br_02 with dissolve
        hide e4s5_bridget_blink1
        br "Well, it's pretty easy."

        scene e4s5-br_03 with dissolve
        br "I'd say we approach this with facts, show them how it doesn't affect creativity all that much."

        scene e4s5-br_04 with dissolve
        br "But it's your call, you're taking full control on this."

        scene e4s5-br_01 with dissolve
        show e4s5_bridget_blink1
        mc "So, you're not even helping?"

        scene e4s5-br_04 with dissolve
        hide e4s5_bridget_blink1
        br "I'm guiding, not helping."

        if affinity_spectrum > 0:
            scene e4s5-br_05 with dissolve
            mc "*Then why did I even pair with you...*"

        scene e4s5-br_01 with dissolve
        show e4s5_bridget_blink1
        mc "Okay, anyway."

        scene e4s5-br_06 with dissolve
        hide e4s5_bridget_blink1
        menu:
            "Go with [br]'s approach":
                scene e4s5-br_01 with dissolve
                show e4s5_bridget_blink1
                mc "Let's go with your approach."

                scene e4s5-br_02 with dissolve
                hide e4s5_bridget_blink1
                br "Alright, then you better get started on it."

                scene e4s5-br_01 with dissolve
                show e4s5_bridget_blink1
                mc "What?"
                mc "What are you gonna do, then?"

                scene e4s5-br_03 with dissolve
                hide e4s5_bridget_blink1
                br "Watch and guide, like I said."

                scene e4s5-br_08 with dissolve
                mc "Okay..."

            "Doubt her":
                scene e4s5-br_01 with dissolve
                show e4s5_bridget_blink1
                mc "Really? It doesn't affect creativity all that much?"
                mc "I don't think you believe that either."

                scene e4s5-br_04 with dissolve
                hide e4s5_bridget_blink1
                br "It's not about what I believe, it's what you make them believe."

                scene e4s5-br_05 with dissolve
                mc "*Wow... philosophical much.*"

                scene e4s5-br_08 with dissolve
                mc "Okay then, we'll go with..."

                scene e4s5-br_06 with dissolve
                menu:
                    "It affects creativity":
                        scene e4s5-br_01 with dissolve
                        show e4s5_bridget_blink1
                        mc "It affects creativity!"
                        mc "We're gonna document on how the education system can be harmful to one's creativity and exploration."

                    "It enhances skills":
                        scene e4s5-br_01 with dissolve
                        show e4s5_bridget_blink1
                        mc "We'll talk about how it enhances skills and decision-making."
                        mc "Helping the creative part flourish with solutions."

                scene e4s5-br_02 with dissolve
                hide e4s5_bridget_blink1
                br "Alright, then you better get started on it."

                scene e4s5-br_01 with dissolve
                show e4s5_bridget_blink1
                mc "What?"
                mc "What are you gonna do, then?"

                scene e4s5-br_03 with dissolve
                hide e4s5_bridget_blink1
                br "Watch and guide, like I said."

                scene e4s5-br_08 with dissolve
                mc "Okay..."

        scene e4s5-br_06 with dissolve
        pause

        scene black with Dissolve(2.0)
        pause(1.0)

        scene e4s5-br_10 with Dissolve(2.0)
        mc "And this was our project, thank you!"

        scene e4s5-06 with dissolve
        pause

    if e4f1_sadie_partner == True:
        scene e4s5-sd_02 with dissolve
        sd "What do you think we'll get?"

        scene e4s5-sd_10 with dissolve
        if affinity_spectrum > 0:
            mc "Anything that's easy, hopefully."
        else:
            mc "Hmm... let's hope something we have a clue about."

        scene e4s5-sd_03 with dissolve
        mc "Let's see what we got."

        scene e4s5-sd_12 with dissolve
        mc "The Role of Emotional Intelligence in Modern Relationships."

        scene e4s5-sd_07 with dissolve
        sd "Damn, she read us like a book!"
        sd "I don't think there could have been a theme any more fitting than this one."

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "Do you think she did it on purpose?"

        scene e4s5-sd_02 with dissolve
        hide e4s5_sadie_blink1
        sd "Probably, yeah."

        scene e4s5-sd_04 with dissolve
        sd "Emotional intelligence, huh? Think you have any of that?"

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "Only when you're around."

        scene e4s5-sd_02 with dissolve
        hide e4s5_sadie_blink1
        sd "That's sweet... but this topic could actually be kinda fun."

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "What about you?"

        scene e4s5-sd_05 with dissolve
        hide e4s5_sadie_blink1
        sd "I might... slip up from time to time, but I have good intentions, I promise!"

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "If that means I get a happy ending every time then I'm all for it, make mistakes all you want."

        scene e4s5-sd_06 with dissolve
        hide e4s5_sadie_blink1
        sd "You won't get away that easily, haha!"

        scene e4s5-sd_08 with dissolve
        sd "Okay, okay, let's start actually working and stop slacking."

        scene e4s5-sd_07 with dissolve
        sd "We're gonna worry about those things later."

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "Yeah, everyone's already kind of started working on their projects."

        scene e4s5-sd_02 with dissolve
        hide e4s5_sadie_blink1
        sd "So, how do you say we approach this one?"

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        menu:
            "Keep it academic":
                $ e4s5_pass = True

                mc "I say we go with a pretty straightforward approach."
                mc "Keep it academic if you will."
                mc "Define emotional intelligence, talk about studies on relationships, that kind of stuff."

                scene e4s5-sd_07 with dissolve
                hide e4s5_sadie_blink1
                sd "Straight to facts? Let's see how that plays out."

            "Turn it into a debate":
                $ sadie_trust += 1

                mc "What if we make it a debate format?"
                mc "You take one stance, I take the other, and we clash over what emotional intelligence really means."

                scene e4s5-sd_04 with dissolve
                hide e4s5_sadie_blink1
                sd "Now {b}that{/b} could be fun!"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "I'm not sure this will end up winning, but boy, will it be fun."

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "So you do like arguing with me."

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Only when I'm right."

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "I hate you!"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Haha!"

            "Make up a research":
                $ sadie_trust += 1

                mc "Okay, hear me out, what if we design a fake study?"
                mc "Like, 'How emotionally intelligent are people in long-distance relationships versus in-person ones?'"

                scene e4s5-sd_04 with dissolve
                hide e4s5_sadie_blink1
                sd "Ooh, I love that!"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "We could lay out the hypothesis, describe the method, expected results..."

                scene e4s5-sd_02 with dissolve
                hide e4s5_sadie_blink1
                sd "Totally, make it feel like we're presenting cutting-edge research."

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "And, at the end, we'd just be like 'So yeah, truth is, we made it all the fuck up'!"

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "How long until [br] kicks us out?"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "I'd give her a solid 5 minutes."

                scene e4s5-sd_04 with dissolve
                hide e4s5_sadie_blink1
                sd "Then we better make them the best 5 minutes of our lives."

        scene e4s5-sd_11 with dissolve
        hide e4s5_sadie_blink1
        pause

        scene black with Dissolve(2.0)
        pause(1.0)

        if e4s5_pass == True:
            scene e4s5-sd_13 with dissolve
            mc "And this was our project, thank you!"
        else:
            scene e4s5-sd_14 with dissolve
            mc "And this was our project, thank you!"

        scene e4s5-sd_11 with dissolve
        pause

        if e4s5_pass == True:
            scene e4s5-sd_09 with dissolve
            mc "Totally crushed it."
            mc "We're starting to get the hang of these presentations."

    if e4f1_tracy_partner == True:
        scene e4s5-tr_04 with dissolve
        tr "I've never been excited about these types of projects."

        scene e4s5-tr_05 with dissolve
        tr "Why would we need to present something in front of people who don't even give a shit about what we have to say?"

        scene e4s5-tr_04 with dissolve
        tr "It beats me."

        scene e4s5-tr_02 with dissolve
        mc "Yeah, you're right."
        mc "If it weren't for the grading system, none of us would actually care about what's being presented in this class."

        scene e4s5-tr_04 with dissolve
        tr "Well, let's just get this over with."

        scene e4s5-tr_03 with dissolve
        mc "Let's see what we got."

        scene e4s5-tr_11 with dissolve
        mc "How Media Shapes Our Identity."

        scene e4s5-tr_06 with dissolve
        mc "*Huh, kinda fitting.*"

        scene e4s5-tr_07 with dissolve
        tr "This one's interesting."
        tr "Media is kind of all around us these days."

        scene e4s5-tr_08 with dissolve
        tr "We probably got the more interesting theme out of the bunch."

        scene e4s5-tr_01 with dissolve
        show e4s5_tracy_blink1
        mc "You could say that, yeah."

        scene e4s5-tr_07 with dissolve
        hide e4s5_tracy_blink1
        tr "Now, the real question is, how do we approach it?"

        scene e4s5-tr_11 with dissolve
        menu:
            "Deconstruct the system":
                $ e4s5_pass = True
                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "Why don't we just expose it for what it is?"
                mc "The media shapes identity because it benefits someone. It sells. It controls."

                scene e4s5-tr_09 with dissolve
                hide e4s5_tracy_blink1
                tr "Damn, we're diving into deep conspiracy theories."

                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "Don't you think this will make the class a bit more interesting?"

                scene e4s5-tr_09 with dissolve
                hide e4s5_tracy_blink1
                tr "Haha, maybe people will actually give a shit about what we have to say."

                scene e4s5-tr_10 with dissolve
                tr "I doubt most of them will actually care anyway, they're too deep into it."

                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "We'll just have to find out."

            "Break the fourth wall":
                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "What if we just make the whole presentation feel like media itself?"
                mc "Like, we structure it like a clickbait video or a fake social media feed."

                scene e4s5-tr_08 with dissolve
                hide e4s5_tracy_blink1
                tr "So, instead of explaining it, we are it."

                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "Maybe have some gameplay in the background?"

                scene e4s5-tr_09 with dissolve
                hide e4s5_tracy_blink1
                tr "Haha, we're trying to explain the matter, not brainwash them!"

                scene e4s5-tr_01 with dissolve
                show e4s5_tracy_blink1
                mc "I say we do both."

        scene e4s5-tr_06 with dissolve
        hide e4s5_tracy_blink1
        pause

        scene black with Dissolve(2.0)
        pause(1.0)

        scene e4s5-tr_12 with Dissolve(2.0)
        mc "And this was our project, thank you!"

        scene e4s5-tr_18 with dissolve
        pause

        if e4s5_pass == False:
            scene e4s5-tr_01 with dissolve
            show e4s5_tracy_blink1
            mc "Man... I can't believe they didn't like our presentation."
            mc "It felt like it had everything!"

            hide e4s5_tracy_blink1
        else:
            scene e4s5-tr_02 with dissolve
            mc "Totally crushed it."
            mc "We're starting to get the hang of these presentations."

    if e4f1_lyla_partner == True:
        scene e4s5-ly_02 with dissolve
        mc "Let's see what we got."

        scene e4s5-ly_11 with dissolve
        mc "The Psychology of Isolation in the Digital Age."

        scene e4s5-ly_05 with dissolve
        mc "*Alone in class and doing a project on isolation, nice.*"

        scene e4s5-ly_03 with dissolve
        ly "Ooh, I love this topic! So many angles we could take!"

        if affinity_spectrum > 0:
            scene e4s5-ly_05 with dissolve
            mc "*Of course you do...*"

        scene e4s5-ly_01 with dissolve
        show e4s5_lyla_blink1
        mc "So, how would you like to approach this one?"

        scene e4s5-ly_04 with dissolve
        hide e4s5_lyla_blink1
        ly "Hmm..."

        scene e4s5-ly_06 with dissolve
        ly "Maybe we could talk about real life experiences?"

        scene e4s5-ly_07 with dissolve
        ly "I once heard about a man who experienced lots of different things because of isolation."

        scene e4s5-ly_01 with dissolve
        show e4s5_lyla_blink1
        menu:
            "Let her do the work":
                mc "Sure... whatever you think works best."

                scene e4s5-ly_08 with dissolve
                hide e4s5_lyla_blink1
                ly "Okay, the experience it is."

                scene e4s5-ly_10 with dissolve
                ly "You can get started on it, I'll take care of the informational details."

            "Give a different input":
                $ e4s5_pass = True
                mc "That could work, but I was maybe thinking about something else."

                scene e4s5-ly_10 with dissolve
                ly "I'm listening."

                scene e4s5-ly_01 with dissolve
                show e4s5_lyla_blink1
                mc "So, it's about psychology, right? That means side effects."
                mc "What if we talk about the side effects of it?"
                mc "Like, sort of how it shapes the man and how he acts because of it."

                scene e4s5-ly_08 with dissolve
                hide e4s5_lyla_blink1
                ly "I love it! It ties exactly into what I was thinking about."

                scene e4s5-ly_06 with dissolve
                ly "We're already making such a great team!"

                scene e4s5-ly_10 with dissolve
                ly "Okay, you can get started on it, I'll take care of the informational details."

        scene e4s5-ly_09 with dissolve
        mc "*That seems easy enough.*"

        scene black with Dissolve(2.0)
        pause(1.0)

        scene e4s5-ly_12 with Dissolve(2.0)
        mc "And this was our project, thank you!"

        scene e4s5-ly_09 with dissolve
        pause

        if e4s5_pass == False:
            scene e4s5-ly_13 with dissolve
            ly "How did we fail? My plan was perfect."

            scene e4s5-ly_14 with dissolve
            ly "I had everything in motion, it doesn't make sense!"

            scene e4s5-ly_13 with dissolve
            ly "I thought the theme we got would be much easier..."
        else:
            scene e4s5-ly_15 with dissolve
            ly "We did it!!"
            ly "They loved it!"

            scene e4s5-ly_06 with dissolve
            ly "We make such a good team, oh my God."

    scene e4s5-11 with dissolve
    br "That was very good, class."
    br "Some of you had fantastic answers and presentations."

    if e4s5_pass == False:
        scene e4s5-06 with dissolve
        br "Others... not quite there yet."

    scene e4s5-14 with dissolve
    br "But that's okay, you'll have plenty of time to improve."
    br "Today was just a preview of what this semester will look like."

    scene e4s5-01 with dissolve
    br "By the end, you'll be presenting a major project just like you did today."
    br "You'll be working with your chosen partner on a topic I assign, and that project will make up your entire grade."
    br "If you have any questions, feel free to come see me after class, I'm happy to talk."

    scene e4s5-15 with dissolve
    unknown "Wait, with the same partner from today?"

    scene e4s5-16 with dissolve
    br "Yes, the partner you picked today."
    br "You'll be working together for the whole project."

    if e4f1_sadie_partner == True:

        if e3s23_tracy_feelings == True:
            $ e4s5_tracy_mad = True
            $ e4s5_tracy_path_throw = True

        scene e4s5-sd_02 with dissolve
        sd "So... looks like we're gonna be partners, huh?"
        sd "We made a good team back there."

        if e2s6_sadie_romance == True:
            scene e4s5-sd_06 with dissolve
            sd "I'm glad we get to work on this for the whole semester."

            scene e4s5-sd_01 with dissolve
            show e4s5_sadie_blink1
            mc "Yeah, me too!"
            mc "Although, I'm not sure when she's gonna give us the themes."
        else:
            scene e4s5-sd_01 with dissolve
            show e4s5_sadie_blink1
            mc "Yeah, for sure!"
            mc "I wonder when is she gonna give us the main themes."

        scene e4s5-sd_07 with dissolve
        hide e4s5_sadie_blink1
        sd "Hopefully not too soon."
        sd "I'm drowning in assignments."

        scene e4s5-sd_01 with dissolve
        show e4s5_sadie_blink1
        mc "Yeah, I know, right?"
        mc "Looks like the fun's over."

        if e2s6_sadie_romance == True or e2s6_sadie_fwb == True:
            if e2s6_sadie_fwb == True:
                mc "*Should I ask [sd] out this weekend?*"

                menu:
                    "Ask her out":
                        pass

                    "Don't do it":
                        mc "*Nah... maybe some other time.*"

                        jump e4s6

            if affinity_spectrum > 0:
                $ e4s5_date = True
                mc "Hey, I got an idea!"

                scene e4s5-sd_02 with dissolve
                hide e4s5_sadie_blink1
                sd "What's up?"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "What do you say we go out on a date sometime this week, after we're both free, of course."

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "Are you asking me out, for real?"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Guess I am!"

                scene e4s5-sd_02 with dissolve
                hide e4s5_sadie_blink1
                sd "You know? I really like the sound of that."
                sd "Do you have anything in mind?"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "I've got a few ideas."
                mc "How does Saturday night sound?"

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "Perfect."

                scene e4s5-sd_02 with dissolve
                sd "That should give me just enough time to finish."

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                menu:
                    "Make a joke":
                        call extrovert_affinity_check from _call_extrovert_affinity_check_71
                        call color_check from _call_color_check_138

                        mc "Damn... it takes you that long to finish?"
                        mc "Someone clearly isn't treating you right."

                        scene e4s5-sd_06 with dissolve
                        hide e4s5_sadie_blink1
                        sd "Haha, stop!"
                        sd "Where's this coming from, Mr. Charming?"
                        sd "That's so corny."

                        scene e4s5-sd_01 with dissolve
                        show e4s5_sadie_blink1
                        mc "Not as corny as you making me finish."

                        scene e4s5-sd_02 with dissolve
                        hide e4s5_sadie_blink1
                        sd "See you on Saturday!"

                        scene e4s5-sd_37 with vpunch
                        pause

                        scene e4s5-sd_40 with dissolve
                        pause

                        scene e4s5-sd_38 with dissolve
                        sd "Maybe you're crazier than I thought."

                    "Be serious":
                        call introvert_affinity_check from _call_introvert_affinity_check_63
                        call color_check from _call_color_check_139

                        mc "Alright then, we'll keep in touch!"
                        mc "See you around, [sd]!"

                        scene e4s5-sd_02 with dissolve
                        sd "See you, [mc]."

                        scene e4s5-sd_40 with dissolve
                        pause
            else:
                $ e4s5_date = True
                scene e4s5-sd_07 with dissolve
                sd "Yeah..."

                scene e4s5-sd_02 with dissolve
                sd "Hey, how about we do something fun over the weekend?"
                sd "To catch up a bit."

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "That sounds awesome!"
                mc "When would you say is the best time?"

                scene e4s5-sd_05 with dissolve
                hide e4s5_sadie_blink1
                sd "Hmm... is Saturday okay for you?"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Yeah, I think I'm free."

                scene e4s5-sd_02 with dissolve
                hide e4s5_sadie_blink1
                sd "Great, cutie!"

                scene e4s5-sd_04 with dissolve
                sd "Because you're in charge of planning it."

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Me?"

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "Haha, yeah."
                sd "You look like you've seen a ghost."

                scene e4s5-sd_02 with dissolve
                sd "Come on, man up, show me what you're made of."

                scene e4s5-sd_15 with dissolve
                mc "*Shit... I don't know any places where I could take her out.*"

                scene e4s5-sd_01 with dissolve
                show e4s5_sadie_blink1
                mc "Alright, it's a date!"

                scene e4s5-sd_06 with dissolve
                hide e4s5_sadie_blink1
                sd "That's the spirit!"

                scene e4s5-sd_40 with dissolve
                pause

                scene e4s5-sd_38 with dissolve
                sd "I'll see you around."

        scene e4s5-sd_39 with dissolve
        pause

    if e4f1_bridget_partner == True:
        scene e4f1-br_06 with dissolve
        pause

        scene e4f1-br_01 with dissolve
        mc "Hey, [br]!"

        scene e4f1-br_03 with dissolve
        mc "So, about what you said earlier, that means we'll be partners for the rest of the semester, right?"

        scene e4f1-br_04 with dissolve
        br "I'm not sure how that would be fair to the rest of the students."

        scene e4f1-br_03 with dissolve
        mc "Yeah, but who am I gonna choose then?"
        mc "Everyone else has a partner already."
        mc "And it's not like you did a whole lot today either, as far as I'm concerned there's no real unfairness present."

        scene e4f1-br_05 with dissolve
        br "I suppose you might be right."
        br "We'll talk about this later on, when I hand out the themes."

        scene e4f1-br_01 with dissolve
        mc "Alright, good enough for me."

    if e4f1_lyla_partner == True:
        scene e4s5-ly_15 with dissolve
        ly "Awesome! Partners for the rest of the semester."
        ly "We'll have so much fun!"

        scene e4s5-ly_01 with dissolve
        show e4s5_lyla_blink1
        mc "Hey... listen, I've got to get going."
        mc "We'll... uh- talk when we get the themes, right?"

        scene e4s5-ly_14 with dissolve
        hide e4s5_lyla_blink1
        ly "What? What about until then?"

        scene e4s5-ly_10 with dissolve
        ly "Shouldn't we make plans about our approach?"

        scene e4s5-ly_01 with dissolve
        show e4s5_lyla_blink1
        mc "Why don't you work on those yourself, and we'll apply them when the themes come, okay?"

        scene e4s5-ly_06 with dissolve
        hide e4s5_lyla_blink1
        ly "Hey, that's such a good idea! You're right, we'll talk then."
        ly "See ya!"

        scene e4s5-ly_05 with dissolve
        if affinity_spectrum > 0:
            mc "*What have I gotten myself into...*"
        else:
            pause

    if e4f1_tracy_partner == True:
        if sadie_trust > 5 and e2s6_sadie_romance == True and e2s6_sadie_fwb == False:
            $ e4s5_sadie_mad = True
            $ e4s5_sadie_path_throw = True

            scene e4s5-sd_24 with dissolve
            sd "Seriously?"

            scene e4s5-sd_25 with dissolve
            tr "Oh... [sd], I-"

            scene e4s5-sd_26 with dissolve
            sd "Just... wow."

            scene e4s5-sd_27 with dissolve
            mc "Can we talk somewhere more private?"

            scene e4s5-sd_28 with dissolve
            sd "You shut up!"

            scene e4s5-sd_29 with dissolve
            sd "I'm not mad that my crush partnered with someone else."

            scene e4s5-sd_36 with dissolve
            sd "I'm not mad that my friend partnered with someone else."

            scene e4s5-sd_31 with dissolve
            sd "But both together?"

            scene e4s5-sd_28 with dissolve
            sd "That's just shitty from the two of you."

            scene e4s5-sd_30 with dissolve
            sd "What's the deal between you two, anyway?"

            scene e4s5-sd_27 with dissolve
            mc "What deal? There's no deal."

            scene e4s5-sd_31 with dissolve
            sd "Sure there isn't, else why would you partner with her instead of me, or someone else for that matter."

            scene e4s5-sd_26 with dissolve
            sd "We're done, [mc], for good."

            scene e4s5-sd_35 with dissolve
            pause

            scene e4s5-sd_32 with dissolve
            mc "Holy shit... what just happened?"

            scene e4s5-sd_33 with dissolve
            tr "I thought you already talked to her about it!"

            scene e4s5-sd_34 with dissolve
            tr "Fucking shit."

            scene e4s5-sd_36 with dissolve
            pause

            scene e4s5-sd_29 with dissolve
            mc "*Fuck... I think I fucked up...*"
        else:
            scene e4s5-tr_04 with dissolve
            tr "Damn... glad this is over."
            tr "I didn't really like it."

            scene e4s5-tr_02 with dissolve
            mc "Yeah... me neither."

            if e4s5_pass == False:
                mc "Especially since we failed."

            scene e4s5-tr_04 with dissolve
            tr "This class looks like it's gonna be a pain in the ass, but I guess there isn't a whole lot we can do about it."

            scene e4s5-tr_02 with dissolve
            mc "At least we're working together, that makes it a bit more enjoyable."

            scene e4s5-tr_09 with dissolve
            tr "Haha, yeah! Those all-nighters we're gonna pull are gonna be something."

            scene e4s5-tr_01 with dissolve
            show e4s5_tracy_blink1
            mc "Are you thinking about what I'm thinking?"

            scene e4s5-tr_09 with dissolve
            hide e4s5_tracy_blink1
            tr "Hopefully, or else I might have to ditch you for another partner."

            scene e4s5-tr_01 with dissolve
            show e4s5_tracy_blink1
            mc "Wait... come on, you're not serious, are you?"

            scene e4s5-tr_08 with dissolve
            hide e4s5_tracy_blink1
            tr "I'll let you find out on your own."

            scene e4s5-tr_01 with dissolve
            show e4s5_tracy_blink1
            mc "Come on, you..."

            scene e4s5-tr_19 with dissolve
            pause

            scene e4s5-tr_20 with dissolve
            mc "She's..."
            mc "She's not serious, is she?"

    if e4f1_tracy_partner == False and e4f1_trsd_partners == False:
        if sadie_trust > 5 and e2s6_sadie_romance == True and e2s6_sadie_fwb == False and e4f1_sadie_partner == False:
            $ e4s5_sadie_mad = True

            scene e4s5-sd_15 with dissolve
            sd "Hey!"

            scene e4s5-sd_16 with dissolve
            pause

            scene e4s5-sd_17 with dissolve
            mc "Hey?"

            scene e4s5-sd_18 with dissolve
            sd "Why didn't you partner with me?"

            scene e4s5-sd_19 with dissolve
            mc "I thought you wanted to do the project with [tr]."

            scene e4s5-sd_20 with dissolve
            sd "Yeah, maybe today, not the whole fucking semester!"

            scene e4s5-sd_21 with dissolve
            sd "I thought we were closer than that."

            scene e4s5-sd_19 with dissolve
            mc "But we are! I just..."

            scene e4s5-sd_22 with dissolve
            sd "You didn't even ask... you just made the assumption that I didn't want to."

            scene e4s5-sd_18 with dissolve
            sd "It's not fair, you know?"

            scene e4s5-sd_19 with dissolve
            mc "But you didn't ask me either."

            scene e4s5-sd_20 with dissolve
            sd "Yeah, because you had another partner already."

            scene e4s5-sd_22 with dissolve
            sd "What was I supposed to do? Make a scene in front of the whole class?"

            scene e4s5-sd_19 with dissolve
            mc "Look... I'm sorry, I just didn't think it through."

            scene e4s5-sd_22 with dissolve
            sd "Yeah, well, to me it looks like you've already made up your mind."

            scene e4s5-sd_21 with dissolve
            sd "I know it's just a school project, but I would have preferred to spend it with the guy I've been building toward a relationship with."

            scene e4s5-sd_19 with dissolve
            mc "I'm sorry, I didn't know it meant so much to you."

            scene e4s5-sd_21 with dissolve
            sd "Yeah..."

            scene e4s5-sd_23 with dissolve
            mc "*God... did I mess up?*"

        if e3s23_tracy_feelings == True and e4f1_sadie_partner == True:
            $ e4s5_tracy_mad = True

            scene e4s5-tr_13 with dissolve
            pause

            scene e4s5-tr_14 with dissolve
            mc "Hey [tr]! Nice work there."
            mc "I liked your project."

            scene e4s5-tr_15 with dissolve
            tr "Oh... thanks."

            scene e4s5-tr_16 with dissolve
            tr "I've got to go."

            scene e4s5-tr_17 with dissolve
            mc "*Huh? Why is she acting like that?*"

    jump e4s6
return
