
# Scene 21 - Asking for help ###################################################

label e4s21:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music invisible_light
    scene e4s21-01 with Dissolve(2.0)
    pause

    if e4s18_ask_option == 3:
        scene e4s21-02 with dissolve
        mc "*I can't believe I'm gonna call dad to ask him for cash.*"
        mc "*I feel a bit ashamed about it...*"

        if e3s29_hate == False:
            mc "*I hope he's doing well.*"

        scene e4s21-03 with dissolve
        pause

        scene e4s21-04 with dissolve
        mc "*He's not picking up.*"
        mc "*Maybe he's busy?*"

        scene e4s21-05 with dissolve
        pause

        scene e4s21-04 with dissolve
        mc "*He usually picks up after my second call...*"
        mc "*I'm starting to get a bit worried.*"
        mc "*What's he doing?*"

        scene e4s21-06 with dissolve
        jo "Hey son, what's up?"

        scene e4s21-07 with dissolve
        mc "Where were you, Dad?"
        mc "You had me worried for a bit."

        scene e4s21-08 with dissolve
        jo "Sorry, I was out to grab a coffee and left my phone at work."

        scene e4s21-10 with dissolve
        mc "Oh... alright."

        scene e4s21-08 with dissolve
        jo "Yeah..."

        scene e4s21-09 with dissolve
        jo "So... how have you been, son?"

        scene e4s21-10 with dissolve
        mc "I've been okay..."

        scene e4s21-11 with dissolve
        mc "You know... with the news, I'm still processing."

        scene e4s21-12 with dissolve
        jo "I understand, don't rush it son."

        scene e4s21-13 with dissolve
        jo "I'm sorry it happened the way it did, if I could I'd take back what I did."

        scene e4s21-10 with dissolve
        mc "Yeah... I appreciate that Dad."

        scene e4s21-14 with dissolve
        mc "Listen, that's not the reason I really called you."

        scene e4s21-13 with dissolve
        jo "Then what's going on?"

        if affinity_spectrum < 0:
            scene e4s21-11 with dissolve
            mc "I'm feeling a bit ashamed that I have to do this."

        scene e4s21-14 with dissolve
        mc "I was wondering if you could lend me some money."

        scene e4s21-13 with dissolve
        jo "Lend you money?"
        jo "Come on son, you don't have to feel ashamed for asking that."

        scene e4s21-12 with dissolve
        jo "And you don't have to give it back, you don't even have a job."

        scene e4s21-10 with dissolve
        mc "Yeah, but still I feel bad."
        mc "You work so much, and yeah..."

        scene e4s21-12 with dissolve
        jo "Not a single word more, I'm sending you some money right now."

        scene e4s21-05 with dissolve
        $ renpy.show_screen("money_notify_pers")
        jo "And don't you dare give it back, alright?"
        $ money += 3
        $ renpy.show_screen("money_notify")
        $ renpy.hide_screen("money_notify_pers")
        jo "It's yours to use, don't expect me to leave you there without anything."

        scene e4s21-07 with dissolve
        mc "Thanks Dad, I really appreciate it."
        mc "I didn't think you would actually send me."

        scene e4s21-09 with dissolve
        jo "You're my son, of course I will."

        scene e4s21-08 with dissolve
        jo "You didn't do anything wrong."

        scene e4s21-12 with dissolve
        jo "You never need to feel bad about asking me for help."
        jo "I'm always here for you, no matter what."

        scene e4s21-05 with dissolve
        jo "Listen, I'm getting off to my shift now, I can't talk for long."
        jo "Just know that I love you, alright?"
        jo "And I hope we can meet again soon to talk things through."

        scene e4s21-11 with dissolve
        mc "Yeah... we'll see Dad."

        scene e4s21-12 with dissolve
        jo "Bye [mc]!"

        scene e4s21-11 with dissolve
        mc "Bye!"

        scene e4s21-15 with dissolve
        pause

    if e4s18_ask_option == 2:
        scene e4s21-02 with dissolve
        mc "*Alright... let's see if [jd]'s uncle has any work for me.*"
        mc "*I need to earn some money for the date with [sd] somehow.*"

        scene e4s21-03 with dissolve
        pause

        scene e4s21-23 with dissolve
        jd "Yo, [mc], what's up my dude?"

        scene e4s21-21 with dissolve
        mc "Hey dude!"
        mc "I'm fine, I'm fine."
        mc "Just sitting in my room."

        scene e4s21-22 with dissolve
        mc "Listen, I need a favor."

        scene e4s21-19 with dissolve
        jd "Sure bro, what's up?"

        scene e4s21-24 with dissolve
        mc "Does your uncle need any help around the pizzeria?"

        scene e4s21-20 with dissolve
        mc "Just for a day or two, I need to earn some money."

        scene e4s21-23 with dissolve
        jd "Money? For what?"

        scene e4s21-21 with dissolve
        mc "Just a date."

        scene e4s21-25 with dissolve
        $ renpy.show_screen("money_notify_pers")
        jd "Say no more fam."

        scene e4s21-15 with dissolve
        $ money += 3
        $ renpy.show_screen("money_notify")
        $ renpy.hide_screen("money_notify_pers")
        pause

        scene e4s21-20 with dissolve
        mc "Yo, what's that?"

        scene e4s21-25 with dissolve
        jd "The money you said you needed, obviously."

        scene e4s21-22 with dissolve
        mc "How does that work?"
        mc "Is this payment upfront?"

        scene e4s21-25 with dissolve
        jd "Haha, no dude."
        jd "Come on man, I'm not gonna put you in that kitchen to work for a bit of cash for a date."

        scene e4s21-03 with dissolve
        jd "I know we're not even, but call this even, alright?"
        jd "For the shit I did with [sp]."

        scene e4s21-21 with dissolve
        mc "The hell we are even!"
        mc "Send me ten times more the amount and I'll maybe reconsider."

        scene e4s21-20 with dissolve
        mc "My forgiveness comes at a cost."

        scene e4s21-25 with dissolve
        jd "Damn you are expensive."
        jd "It probably costs me less if you're still angry at me so be my guest, haha!"

        scene e4s21-21 with dissolve
        mc "No, seriously now, I really appreciate it."
        mc "Thanks for the money and for not putting me to work."

        scene e4s21-23 with dissolve
        jd "If you keep asking for more I might eventually do."

        scene e4s21-24 with dissolve
        mc "Haha, we'll see, we'll see."

        scene e4s21-15 with dissolve
        pause

    if e4s18_ask_option <= 1 or e4s18_ask_option == 4 or e4s18_ask_option == 2:
        play sound phone_buzz
        pause

        scene e4s21-04 with dissolve
        mc "*It's Dad...*"

        if e3s29_hate == True:
            scene e4s21-16 with dissolve
            mc "*Great... what does he want know?*"
        else:
            mc "..."

        menu:
            "Answer":
                $ e4s21_answer = True
                scene e4s21-08 with dissolve
                jo "Hey son!"

                scene e4s21-09 with dissolve
                jo "I just got a short break at work right now and I've been wondering how you've been."

                scene e4s21-10 with dissolve
                mc "Hey, just... hanging around."

                scene e4s21-08 with dissolve
                jo "Nice, that's nice."

                scene e4s21-09 with dissolve
                jo "Is college okay?"

                scene e4s21-10 with dissolve
                mc "Yeah... it's fine."

                scene e4s21-09 with dissolve
                jo "I'm glad! Last time it kind of sounded like you were caught in the middle of something, haha!"

                scene e4s21-10 with dissolve
                mc "Haha, yeah..."

                scene e4s21-08 with dissolve
                jo "Heh..."

                scene e4s21-12 with dissolve
                jo "Listen... son, about last time."
                jo "I'm sorry it happened the way it did, if I could I'd take back what I did."

                scene e4s21-13 with dissolve
                jo "I'm not expecting you to forgive me and I don't want to push you."
                jo "I just wanted to hear from you because you left in such a hurry, I was a bit worried."

                if e3s29_hate == True:
                    scene e4s21-10 with dissolve
                    mc "Yeah... I'm fine."
                else:
                    scene e4s21-05 with dissolve
                    mc "..."

                    scene e4s21-10 with dissolve
                    mc "Thanks for checking up."

                    scene e4s21-08 with dissolve
                    jo "You don't have to thank me for that, son."

                scene e4s21-12 with dissolve
                jo "I'm gonna send you some money, you're probably out by now."

                scene e4s21-13 with dissolve
                jo "Don't think of this as me trying to fix my mistakes with money, trust me I've tried it before."
                jo "It's just some pocket money, alright?"

                if e3s29_hate == True:
                    scene e4s21-17 with dissolve
                    mc "You seriously think a bit of money is gonna fix this?"

                    scene e4s21-18 with dissolve
                    jo "No, no son!"
                    jo "That was not my intention, I'm sorry."
                else:
                    scene e4s21-10 with dissolve
                    mc "Yeah... alright Dad."

                scene e4s21-13 with dissolve
                jo "Listen... my shift is about to start, I can't talk for long."

                scene e4s21-12 with dissolve
                jo "Just know that I love you, alright?"
                jo "And I hope we can meet again soon to talk things through."

                scene e4s21-10 with dissolve
                mc "Yeah... we'll see."

                scene e4s21-08 with dissolve
                jo "Bye [mc]!"

                scene e4s21-02 with dissolve
                $ renpy.show_screen("money_notify_pers")
                pause
                $ money += 3
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")

                if e4s18_ask_option == 4:
                    scene e4s21-29 with dissolve
                    mc "*Well... at least with the money from Dad I'll be able to afford the date with [sd].*"
            "Hang up":
                scene e4s21-02 with dissolve
                mc "*I'm not ready to talk to him...*"

                scene e4s21-01 with dissolve
                $ renpy.show_screen("money_notify_pers")
                pause
                $ money += 3
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")
                mc "*Huh? Money?*"

                if e4s18_ask_option == 4:
                    scene e4s21-29 with dissolve
                    mc "*I guess that came at a perfect time, I need it for the date with [sd].*"
                    mc "*But don't think I've forgotten you just because you gave me a bit of cash.*"
                else:
                    menu:
                        "Keep it":
                            $ e4s21_keep_it = True
                            mc "*I guess they could come in handy...*"

                        "Give it back":
                            mc "*To hell with his money.*"

                            scene e4s21-15 with dissolve
                            $ renpy.show_screen("money_notify_pers")
                            pause
                            $ money -= 3
                            $ renpy.show_screen("money_notify")
                            $ renpy.hide_screen("money_notify_pers")

    if e3s11_phone_right == True:
        scene e4s21-26 with dissolve
        pause

        scene e4s21-29 with dissolve
        mc "*I still don't know what to do with this phone.*"
        mc "*And I haven't returned it to [ev] yet.*"
        mc "*Probably she doesn't even know it's missing.*"
        mc "*Should I charge it and try to track the owner down?*"

        menu:
            "Charge it":
                $ e4s21_use_phone = 1
                scene e4s21-28 with dissolve
                mc "*Let's see what's on it.*"

                scene black with Dissolve(2.0)
                pause(1.0)

                scene e4s21-01 with Dissolve(2.0)
                pause

                scene e4s21-27 with dissolve
                mc "*Holy shit, I can't believe it!*"
                mc "*It's [am]'s phone.*"
                mc "*And it's got no password either, should I go through it?*"

                scene e4s21-29 with dissolve
                menu:
                    "Check [am]'s phone":
                        $ e4s21_use_phone = 2
                        mc "*Let's just check it, see if I can find anything.*"

                        if e3s19_amber_lewd == False:
                            mc "*If she keeps bothering us maybe I can make her back off.*"

                        scene e4s21-01 with dissolve
                        pause

                        scene e4s21-29 with dissolve
                        mc "*Okay, nothing interesting so far.*"
                        mc "*Let's check out the gallery.*"
                        mc "*Damn, how much does this girl travel?*"
                        mc "*It's honestly crazy.*"
                        mc "*Let's scroll further.*"

                        scene e4s21-27 with dissolve
                        mc "*Wait... holy shit!*"
                        mc "*Is that what I think it is?*"

                        if affinity_spectrum > 0:
                            scene e4s21-28 with dissolve
                            mc "*Oh my God, [am], you slut.*"
                        else:
                            mc "*Oh my God...*"

                        if persistent.disable_nsfw == True:
                            scene e4s21-30 with dissolve
                        else:
                            scene e4s21-30_cen with dissolve

                        if persistent.mixed_gallery_6_unlocked == False:
                            $ persistent.mixed_gallery_6_unlocked = True
                            $ renpy.show_screen("render_notify")
                            $ persistent.mixed6 = True
                            python:
                                update_mixed_list()

                        mc "*It's a nude picture with her.*"
                        mc "*And what a striking one!*"

                        scene e4s21-28 with dissolve
                        mc "*Should I save it?*"

                        menu:
                            "Send it to your phone":
                                $ e4s21_use_phone = 3
                                if persistent.disable_nsfw == True:
                                    scene e4s21-30 with dissolve
                                else:
                                    scene e4s21-30_cen with dissolve
                                mc "*No way I'm not saving this.*"

                                if e3s19_amber_lewd == False:
                                    mc "*If she tries some shit with us, maybe this will stop her.*"

                            "Respect her privacy":
                                scene e4s21-29 with dissolve
                                mc "*Maybe I shouldn't go that far.*"
                                mc "*Not that I respected much of her privacy anyway.*"

                    "Return it":
                        mc "*Better just return it to [ev].*"

            "Return it to [ev]":
                call introvert_affinity_check from _call_introvert_affinity_check_59
                call color_check from _call_color_check_131
                mc "*Better just return it to [ev].*"
                mc "*The owner will ask for it at some point and I wouldn't want to cause any trouble.*"

    jump e4s22
return
