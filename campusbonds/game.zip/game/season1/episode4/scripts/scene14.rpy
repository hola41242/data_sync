
# Scene 14 - Asserting dominance ###############################################

label e4s14:
    stop music fadeout 1.0
    stop sound fadeout 1.0
    scene black with Dissolve(2.0)
    hide e4s13_cleo_blink1
    pause(1.0)

    play music pioneers
    scene e4s14-05 with Dissolve(2.0)
    pause

    scene e4s14-01 with dissolve
    ke "So, what are we gonna do now?"

    scene e4s14-02 with dissolve
    jon "What do you mean?"

    scene e4s14-03 with dissolve
    ke "With [br] and stuff."

    scene e4s14-04 with dissolve
    jon "Right... that thing."

    scene e4s14-06 with dissolve
    jon "Okay, we can start talking business then."

    scene e4s14-03 with dissolve
    ke "Wait, but where's [jd]?"

    menu:
        "Be against [jd]":
            $ scarlett_trust += 1
            $ jordan_friendship -= 1

            scene e4s14-07 with dissolve
            mc "Wait, why would [jd] be here?"

            scene e4s14-08 with dissolve
            mc "I'm not trying to be a bad friend or something, but he kind of conspired with [sp]."

            scene e4s14-09 with dissolve
            mc "What if he gives our plans away?"

            scene e4s14-10 with dissolve
            jon "Come on, man..."
            jon "It was just a mistake, people deserve second chances."

            scene e4s14-11 with dissolve
            jon "I get that it's hard to trust him right now, but just give him some time."

            scene e4s14-12 with dissolve
            jon "You'll see he's not a bad guy."

            scene e4s14-13 with dissolve
            sc "Sorry [jon], but I might have to side with the shithead on this one."

            scene e4s14-14 with dissolve
            pause

            scene e4s14-15 with dissolve
            sc "It's a bit too soon to include him in everything we do, especially when it has to do with [kv] and [sp]."

            scene e4s14-17 with dissolve
            jon "He was only doing deals with [sp], not with [kv]."
            jon "I'm not excusing his actions, just saying."

            scene e4s14-16 with dissolve
            sc "[kv], [sp], whatever."

            scene e4s14-18 with dissolve
            sc "To me, they're both the same."
        "Keep quiet":
            $ jon_friendship += 1
            $ jordan_friendship += 1
            scene e4s14-19 with dissolve
            mc "..."

            scene e4s14-20 with dissolve
            jon "He said he'll be here any minute now."
            jon "Let's just wait for him."

    scene e4s14-09 with dissolve
    mc "Hey guys, I've been meaning to ask you something."

    scene e4s14-21 with dissolve
    jon "What's up?"

    scene e4s14-07 with dissolve
    mc "So, I've been talking to this girl and she's really eager to join the Party Ragers."
    mc "I was wondering if that would be alright with you."

    scene e4s14-06 with dissolve
    jon "Sure thing, dude!"
    jon "More chicks, more party!"

    scene e4s14-22 with dissolve
    sc "No, absolutely not."

    scene e4s14-10 with dissolve
    jon "Why not?"

    if affinity_spectrum > 0:
        scene e4s14-23 with dissolve
        mc "Are you afraid you're not gonna be the only girl here anymore?"

        scene e4s14-24 with dissolve
        sc "Really funny, jackass."

    scene e4s14-18 with dissolve
    sc "With how things are going right now with [br], I don't think we can afford new people."

    scene e4s14-15 with dissolve
    sc "Plus, I don't think we'll be able to hold a party here anytime soon."

    scene e4s14-17 with dissolve
    jon "Does that mean the thing with the cheerleaders collapses?"

    scene e4s14-18 with dissolve
    sc "It wouldn't have worked anyway."

    scene e4s14-23 with dissolve
    mc "So, what does it have to do with her?"

    scene e4s14-25 with dissolve
    sc "It has everything to do with her."

    scene e4s14-26 with dissolve
    sc "I'm already stuck with you here, I don't want another you."

    scene e4s14-24 with dissolve
    sc "Plus, we're already short on money, another member means another dollar spent."

    scene e4s14-23 with dissolve
    menu:
        "Defend [tf]":
            $ tiffany_trust += 1
            $ e4s14_defend = True
            mc "Hey, leave her alone."
            mc "Just because you hate me doesn't mean you have to hate her as well."

            scene e4s14-27 with dissolve
            sc "Oh, got the poor guy's feelings hurt?"
            sc "Don't worry, you'll get over it."

        "Stay quiet":
            mc "..."

    stop music fadeout 1.0
    scene e4s14-28 with dissolve
    pause

    play music darien_gap
    scene e4s14-26 with dissolve
    sc "Great, what does she want now?"

    scene e4s14-11 with dissolve
    jon "Never mind..."

    scene e4s14-29 with dissolve
    br "Hello!"
    br "Where is everyone?"

    scene e4s14-30 with dissolve
    sc "It's just us today."

    scene e4s14-31 with dissolve
    br "Alright, I guess that will do."

    scene e4s14-29 with dissolve
    br "I don't think we had a proper introduction, so now would be a great time to start on the right foot."

    play music aux_intro_cut
    scene e4s14-32 with dissolve
    jd "Ayoo, where the chicks at?"

    stop music
    scene e4s14-33
    pause

    play music darien_gap
    scene e4s14-34 with dissolve
    jd "Oh, shit- I mean..."

    scene e4s14-35 with dissolve
    jd "Hi, uh..."

    scene e4s14-36 with dissolve
    jd "I apologize for barging in like that."

    scene e4s14-37 with dissolve
    br "Go ahead."

    scene e4s14-38 with dissolve
    pause

    scene e4s14-39 with dissolve
    pause

    scene e4s14-40 with dissolve
    jd "What is happening here?"

    scene e4s14-41 with dissolve
    jon "We'll talk about this later."

    scene e4s14-42 with dissolve
    br "What do you usually do here?"

    scene e4s14-44 with dissolve
    sc "I mean... the name should say it all."
    sc "We organize parties."

    scene e4s14-43 with dissolve
    br "So, why is there no party here?"

    scene e4s14-44 with dissolve
    sc "We're not allowed to have parties on campus grounds, right?"
    sc "We organize them outside of the college."

    scene e4s14-45 with dissolve
    br "Alright then."

    scene e4s14-46 with dissolve
    br "Until your next party, I guess we could use the time to study."

    scene e4s14-11 with dissolve
    jon "Wonderful..."

    scene e4s14-19 with dissolve
    menu:
        "Stay for the lecture":
            $ e4s14_stay = True
            $ jon_friendship += 1

            stop music fadeout 1.0
            scene black with Dissolve(2.0)
            pause(1.0)

            play music inertia
            scene e4s14-55 with dissolve
            pause

            scene e4s14-56 with dissolve
            jon "Finally, she's gone."

            scene e4s14-57 with dissolve
            ke "Fuck... I need some fresh air."

            scene e4s14-58 with dissolve
            ke "What do you say we grab a beer?"

            scene e4s14-59 with dissolve
            jon "Don't have to tell me twice."

            scene e4s14-61 with dissolve
            jon "[mc]..."

            scene e4s14-60 with dissolve
            jon "[jd]..."

            scene e4s14-62 with dissolve
            jon "You guys coming?"

            scene e4s14-63 with dissolve
            mc "Sure, just got to wrap this up and I'll be with you in a minute."

            scene e4s14-64 with dissolve
            jd "You guys go ahead, I'll also be there."

            scene e4s14-65 with dissolve
            jon "Alright, we'll wait outside."

            scene e4s14-66 with dissolve
            jon "Just being in this place makes me go crazy."

            scene e4s14-67 with dissolve
            pause

            scene e4s14-68 with dissolve
            pause
            jd "Hey... uh-"

            scene e4s14-69 with dissolve
            jd "Just wanted to say sorry for before."

            scene e4s14-71 with dissolve
            jd "I know we haven't spoken to each other since... that incident."

            scene e4s14-70 with dissolve
            jd "But I just wanted to say that I appreciate you not telling the guys about it."

            scene e4s14-71 with dissolve
            jd "Even if they eventually found out, I know it wasn't from you."

            scene e4s14-70 with dissolve
            jd "So thanks, and I hope things will be fine between us again."

            scene e4s14-72 with dissolve
            menu:
                "Forgive [jd]":
                    $ e4s14_forgive = True
                    mc "Yeah dude, we're cool."
                    mc "I'm sorry for lashing out and all."

                    scene e4s14-70 with dissolve
                    jd "Nah, you were completely justified to do so, don't worry."

                    scene e4s14-73 with dissolve
                    jd "Thanks for trusting me."

                "Not yet":
                    mc "I'm sorry... but I haven't forgiven you yet."
                    mc "I need some time, I'm not sure I will ever be able to."

                    scene e4s14-71 with dissolve
                    jd "I understand."

            stop music fadeout 1.0
            scene e4s14-74 with dissolve
            pause

            play music dances_and_dames
            scene e4s14-68 with dissolve
            pause
            sc "I thought we had a deal!"

            scene e4s14-75 with dissolve
            sc "No, you're not listening!"
            sc "I'm doing what you wanted, right?"
            sc "I put my ass on the line."

            scene e4s14-76 with dissolve
            pause

            scene e4s14-77 with dissolve
            sc "No... I thought I made it clear, no professors here."

            scene e4s14-78 with dissolve
            pause

            scene e4s14-79 with dissolve
            sc "What do you mean you don't have the power?"
            sc "When she asked you for a favor, you were the first to help."
            sc "But when I do that, you don't move a finger."

            scene e4s14-78 with dissolve
            pause

            scene e4s14-80 with dissolve
            sc "I don't care how much she's helped you! I helped you more, okay?"
            sc "I'm starting to think you only need me when I'm useful."

            scene e4s14-81 with dissolve
            pause

            scene e4s14-82 with dissolve
            sc "Yeah... sure... you can't."

            scene e4s14-80 with dissolve
            sc "You know what? I'm sick and tired of your lies."
            sc "I will not forget this."
            sc "Let's see if you can handle this without my help."

            scene e4s14-83 with dissolve
            menu:
                "Say something":
                    call extrovert_affinity_check from _call_extrovert_affinity_check_63
                    call color_check from _call_color_check_122
                    mc "Wow..."

                    scene e4s14-84 with dissolve
                    mc "Is everything okay?"

                    scene e4s14-85 with dissolve
                    sc "Huh?"

                    scene e4s14-86 with dissolve
                    sc "What the hell are you still doing here?"

                    scene e4s14-87 with dissolve
                    mc "I mean... I was wrapping up what [br] gave us."

                    scene e4s14-86 with dissolve
                    sc "Don't you know it's not nice to spy on people's conversations?"

                    scene e4s14-88 with dissolve
                    mc "But I was just sitting here, it's not like I wanted to."

                    scene e4s14-89 with dissolve
                    sc "Whatever... I tried to fix the problem."
                    sc "Clearly, it didn't work, so we're on our own."

                    scene e4s14-90 with dissolve
                    sc "Does this answer satisfy your curiosity?"

                "Stay quiet":
                    call introvert_affinity_check from _call_introvert_affinity_check_55
                    call color_check from _call_color_check_123
                    $ scarlett_trust -= 1

                    scene e4s14-68 with dissolve
                    mc "..."
                    sc "The fuck... are you spying on me?"

                    scene e4s14-88 with dissolve
                    mc "Huh? No!"

                    scene e4s14-87 with dissolve
                    mc "I was just wrapping up what [br] gave us."
                    mc "I would have been on my way after that."

                    scene e4s14-86 with dissolve
                    sc "Learn to mind your own business!"

            scene e4s14-91 with dissolve
            pause

            scene e4s14-92 with dissolve
            mc "But I didn't mean to..."

        "Leave":
            call extrovert_affinity_check from _call_extrovert_affinity_check_64
            call color_check from _call_color_check_124

            scene e4s14-08 with dissolve
            mc "Yeah, I'm out of here."

            scene e4s14-07 with dissolve
            mc "Good luck with whatever's going on here."

            scene e4s14-47 with dissolve
            pause

            scene e4s14-48 with dissolve
            pause

            scene e4s14-49 with dissolve
            br "Where are you going?"

            scene e4s14-51 with dissolve
            mc "I was just passing by..."

            scene e4s14-50 with dissolve
            mc "I'm not actually a part of this club."

            scene e4s14-52 with dissolve
            br "You know strangers shouldn't wander around clubs, right?"

            scene e4s14-53 with dissolve
            br "They should be members only."

            scene e4s14-11 with dissolve
            jon "She's even making the rules now..."

            scene e4s14-54 with dissolve
            pause

    if e4s13_cleo_hangout == True:
        jump e4s15
    else:
        jump e4s16
return
