
# Episode 4 Recap ##############################################################

label e4re:
    $ quick_menu = True
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    show screen recap_skip
    play music careful
    show text "{size=80}Previously, on Campus Bonds...{/size}"
    pause(1.0)

    scene e2s4-48 with wipeleft
    jon "I'M GOING TO INVITE YOU TO A GROUP CALLED THE PARTY RAGERS.{w=1.8}{nw}"

    scene e3f3-jd_17 with wiperight
    unknown "Look... [sp]...{w=1.0}{nw}"
    unknown "I've got you a new deal!{w=1.2}{nw}"

    scene e3f3-jd_18
    mc "[sp]?{w=1.0}{nw}"

    scene e3f3-jd_26 with dissolve
    jd "Please bro, just don't tell the guys about it...{w=1.8}{nw}"

    scene e1s14-79
    sp "I should have known that he's not a trustworthy source from the moment I saw him hanging out with my brother...{w=4.0}{nw}"

    scene e3s4-14 with wipeleft
    sp "Hello, freshie!{w=1.0}{nw}"

    play sound punch
    scene e3s4-38 with vpunch
    "{w=1.0}{nw}"

    scene e3s4-52 with dissolve
    mi "I'm [mi].{w=1.0}{nw}"

    scene e3s5-07 with wiperight
    fr "I managed to do a couple of activities here and there.{w=2.0}{nw}"

    scene e3s5-04 with dissolve
    show e3s5_francesca_blink1
    mc "Like those tattoos on your arm?{w=1.4}{nw}"

    scene e3s5-08 with dissolve
    hide e3s5_francesca_blink1
    fr "The most important one to me is this one which represents College Rock.{w=2.8}{nw}"

    scene e3s10-03 with dissolve
    show e3s10_francesca_blink1
    mc "I was actually wondering if you could give me a tour.{w=2.0}{nw}"

    if e2s6_sadie_romance == True:
        scene e3s6-39 with wiperight
        mc "Woah... what's gotten into you?{w=1.2}{nw}"

        scene e3s6-41 with dissolve
        sd "You don't call, you don't text.{w=1.2}{nw}"

        scene e3s6-42 with dissolve
        sd "I've been wondering where the hell you are.{w=1.8}{nw}"

    scene e3s7-13 with wipeleft
    kv "So, as the students' president, I promise to give you back what you have lost.{w=3.0}{nw}"

    scene e3s7-16 with dissolve
    kv "I also know that some clubs have overstepped and are not in our control anymore.{w=3.0}{nw}"

    scene e3s7-22
    mc "*This guy is going for the students' presidency?*{w=1.8}{nw}"
    mc "*They think I'm a threat to their operation or something.*{w=2.0}{nw}"
    mc "*Now I really have to tell [jon] about it.*{w=1.8}{nw}"

    scene e3s8-07 with dissolve
    jon "I don't wanna hear any bad news.{w=1.4}{nw}"

    if e3s8_candance == True and e3s9_intervene == True:
        scene e3s9_ca-02 with wipeleft
        mc "*I wonder where [ca] is...*{w=1.2}{nw}"

        scene e3s9_ca-24 with dissolve
        unknown "Where's my money, bitch?{w=1.0}{nw}"

        scene e3s9_ca-23 with dissolve
        mc "Hey, get off of her!{w=1.0}{nw}"

        if e3s9_fight == True:
            scene e3s9_ca-50 with dissolve
            "{w=1.0}{nw}"

            scene e3s9_ca-51 with dissolve
            unknown "Ah... fuck!{w=1.0}{nw}"

            scene e3s9_ca-49 with dissolve
        else:
            scene e3s9_ca-36 with dissolve
            unknown "I told you to stay the fuck out of my business prick!{w=2.0}{nw}"

            play sound punch
            scene e3s9_ca-37 with vpunch
            "{w=1.0}{nw}"

            scene e3s9_ca-45 with dissolve
        unknown "This isn't over you fuckers!{w=1.2}{nw}"

        scene e3s9_ca-46 with dissolve
        unknown "You better have my money next time I come in here bitch.{w=2.4}{nw}"
        unknown "Or else I'll just finish what I started!{w=1.8}{nw}"

    scene e3s10-13 with wiperight
    fr "[mc]...{w=1.0}{nw}"
    fr "I present to you... College Rock!{w=1.4}{nw}"

    scene e3s10-23 with dissolve
    unknown "Damn, are you really gonna keep him all to yourself?{w=1.8}{nw}"

    scene e3s10-73 with wipeleft
    hide e3s10_sadie_blink2
    sd "The librarian has confiscated my phone.{w=1.4}{nw}"

    scene e3s10-75 with dissolve
    sd "So, I'd like to know if you could help me get it back by sneaking in her office and taking it from there.{w=3.0}{nw}"

    scene e3s11-03 with wiperight
    show e3s11_olivia_blink1
    mc "So what?{w=1.0}{nw}"
    mc "You're the new librarian now?{w=1.2}{nw}"

    scene e3s11-08 with dissolve
    ov "I'm teaching foreign students English.{w=1.4}{nw}"

    scene e3s11-24 with wipeleft
    mc "*Now... where would a woman like this keep her confiscated phones?*{w=2.0}{nw}"

    if e3s11_phone_left == False or e3s11_phone_right == False:
        scene e3s11-29 with dissolve
        mc "*Shit! I don't have time.*{w=1.2}{nw}"
        mc "*I'm hearing footsteps.*{w=1.0}{nw}"
        mc "*Better get out of here.*{w=1.0}{nw}"
    else:
        scene e3s11-26 with dissolve
        mc "*I’m grabbing this one, hopefully it's hers.*{w=1.6}{nw}"

    scene e3s11-31
    ev "Ahem?{w=1.0}{nw}"
    ev "What are you doing here?{w=1.2}{nw}"

    scene e3s11-51 with dissolve
    "{w=1.0}{nw}"

    if e3s10_cleo_hangout == True:
        scene e3s12-21 with wipeleft
        cl "Oh. My. God...{w=1.0}{nw}"

        scene e3s12-29 with dissolve
        mc "[cl] wait!{w=1.0}{nw}"

        scene e3s12-30 with dissolve
        mc "What did I do wrong?{w=1.0}{nw}"

        scene e3s25-18 with dissolve
        cl "It's about my parents...{w=1.2}{nw}"
        cl "They were killed in a car accident.{w=1.4}{nw}"

    if e3s13_tiffany_hangout == True:
        scene e3s13-22 with wipeleft
        tf "Oh... I'm sorry.{w=1.0}{nw}"
        tf "I didn't want to strike a chord.{w=1.4}{nw}"

        scene e3s13-32 with dissolve
        mc "I need some air.{w=1.0}{nw}"

    scene e3s13-46 with wiperight
    mc "*Where is that damn phone.*{w=1.2}{nw}"

    scene e3s13-47 with dissolve
    mc "*God damn it, I left it at the librarian's desk didn't I?*{w=2.0}{nw}"

    scene e3s15-14 with wipeleft
    fr "Let's get settled for our repetitions.{w=1.6}{nw}"
    fr "[ev] is going to be here in a bit.{w=1.4}{nw}"

    scene e3s15-15 with dissolve
    mc "[ev]?{w=1.0}{nw}"

    scene e3s15-16
    mc "*Oh shit.*{w=1.0}{nw}"

    scene e3s15-55 with dissolve
    ev "You know, I found it weird how one of the drawers from my office was slightly opened.{w=2.6}{nw}"

    scene e3s15-57 with dissolve
    ev "How dare you go through my stuff?{w=1.4}{nw}"

    if e2s10_br_number == True:
        scene e3s16-05 with wipeleft
        br "Wait... [mc]?{w=1.0}{nw}"

        scene e3s16-15 with dissolve
        br "Listen, you have to delete that number from your phone.{w=2.0}{nw}"

        if e3s16_bridget_path == True:
            scene e3s16-27 with dissolve
            mc "*Hell no, I'm not deleting her number.*{w=1.6}{nw}"
            mc "*I don't even have my phone with me.*{w=1.6}{nw}"
        else:
            scene e3s16-28 with dissolve
            mc "*I better delete it when I get my phone back, it's not like anything's going to happen after that.*{w=3.0}{nw}"

    scene e3s17-02 with wiperight
    mc "*Can't believe I'm doing this for the second time.*{w=2.0}{nw}"

    scene e3s17-06 with dissolve
    ev "Looking for something?{w=1.2}{nw}"

    scene e3s18-07 with wipeleft
    sc "Come with me.{w=1.0}{nw}"
    sc "I wanna take you somewhere.{w=1.4}{nw}"

    scene e3s18-19 with dissolve
    show e3s18_scarlett_blink2
    mc "I don't even know who I can trust and who I can't.{w=1.8}{nw}"

    scene e3s18-22 with dissolve
    sc "How do you expect [jon] to know about all of this if you don't tell him?{w=2.2}{nw}"

    scene e3s19-15 with wiperight
    am "Hey, what do we have here?{w=1.4}{nw}"
    mc "Huh?{w=1.0}{nw}"

    if e3s19_amber_lewd == True:
        scene e3s19-24 with vpunch
        am "I wouldn't want anything happening to this big gem here.{w=1.8}{nw}"

        scene e3s19-27 with dissolve
        am "I'll just... move my hand up and down.{w=1.6}{nw}"
    else:
        scene e3s19-59 with dissolve
        mc "Get the hell out!{w=1.2}{nw}"
        mc "You're lucky you're not knocked on the floor by now!{w=1.6}{nw}"

    scene e3s20-15 with wipeleft
    ev "What are you doing here!{w=1.2}{nw}"

    scene e3s20-16 with dissolve
    ev "I told you to stay away from College Rock.{w=1.4}{nw}"

    scene e3s20-65 with dissolve
    ev "Alright, I've had enough!{w=1.2}{nw}"
    ev "I want him out of here!{w=1.2}{nw}"

    scene e3s20-67 with dissolve
    mc "I'm done with [ev]!{w=1.0}{nw}"
    mc "I'm done with College Rock!{w=1.2}{nw}"
    mc "And I'm done with this stupid guitar!{w=1.4}{nw}"

    if e1f5_tracy_sex == True or e2f2_tracy_sex == True or e3f3_tracy_sex == True:
        scene e3s23-10 with wipeleft
        tr "What's your relationship with [sd] exactly?{w=1.4}{nw}"

        scene e3s23-08 with dissolve
        show e3s23_tracy_blink2
        if e3s23_tracy_feelings == True:
            mc "What if I have feelings for you?{w=1.4}{nw}"
        elif e3s23_sadie_feelings == True:
            mc "I guess you're right.{w=1.2}{nw}"
            mc "I do have feelings for [sd].{w=1.4}{nw}"

    scene e3s24-85 with wiperight
    fr "Hey, I managed to get your phone back!{w=1.6}{nw}"

    scene e3s24-86 with dissolve
    fr "Also, I talked to [ev] about this situation.{w=1.8}{nw}"

    scene e3s24-37 with dissolve
    fr "She's gonna cut you some slack from now on.{w=1.6}{nw}"

    scene e3s27-62 with wipeleft
    jo "My son!{w=1.0}{nw}"

    scene e3s27-63 with dissolve
    jo "Welcome back.{w=1.0}{nw}"

    scene e3s27-47
    hl "Holy mother of God, that movie was boring.{w=1.4}{nw}"

    scene e3s28-23 with wiperight
    show e3s28_joel_blink3
    mc "So... you're telling me that the whole reason Mom left was... because of you?{w=2.4}{nw}"

    scene e3s28-17 with dissolve
    hide e3s28_joel_blink3
    jo "Listen son, now you're grown up.{w=1.4}{nw}"
    jo "You're old enough to learn how the world works.{w=1.6}{nw}"

    scene e3s28-29 with dissolve
    mc "I'm going back to college.{w=1.2}{nw}"
    mc "I don't feel like I belong here.{w=1.4}{nw}"

    scene e3s29-22 with wipeleft
    ov "I know you said you're not gonna take it easy with the fighting bit.{w=1.8}{nw}"
    ov "But this is not fighting, this is raging.{w=1.6}{nw}"

    scene e3s29-22 with dissolve
    ov "I haven't seen you talk like that ever.{w=1.6}{nw}"

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "I'm also a therapist.{w=1.0}{nw}"

    scene e3s29-22 with dissolve
    hide e3s29_olivia_blink3
    ov "What do you say we schedule an appointment?{w=1.6}{nw}"

    scene e3s30-31 with wiperight
    mc "[sp] is your cousin?{w=1.0}{nw}"
    mc "What??{w=1.0}{nw}"

    jump e5s1
return
