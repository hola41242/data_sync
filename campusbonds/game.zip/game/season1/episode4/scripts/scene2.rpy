
# Scene 2 - Gym is my therapy ##################################################

label e4s2:
    scene e4s2-01 with wipeleft
    show e4s2_mc_blink1
    play music punk_rock_holiday
    pause

    scene e4s2-02 with dissolve
    hide e4s2_mc_blink1
    mc "Hey [mi], it's [mc]."

    scene e4s2-03 with dissolve
    mc "I'm calling you about those sparring sessions we talked about."

    scene e4s2-01 with dissolve
    show e4s2_mc_blink1
    mi "Oh, hi [mc]!"
    mi "Sure, I'm down for it."
    mi "I'll just send you the gym address where I train."
    mi "But, before that, let's grab a drink."
    mi "I work better when I have something in my system."

    scene e4s2-04 with dissolve
    hide e4s2_mc_blink1
    mc "Haha, alright!"

    scene e4s2-05 with dissolve
    pause

    scene e4s2-06 with dissolve
    pause

    scene e4s2-07 with dissolve
    pause

    scene e4s2-08 with wipeleft
    mc "Damn, I really needed to release this built-up stress."

    scene e4s2-10 with dissolve
    mi "Stress?"
    mi "About what?"

    scene e4s2-09 with dissolve
    mc "Just some shit that's been happening lately."

    scene e4s2-11 with dissolve
    mi "I hope it's not about the [sp] thing."
    mi "The knife trick was just to scare you, he wouldn't have used it."

    scene e4s2-09 with dissolve
    mc "Haha, no, don't worry."
    mc "Just some family trauma, that's all."
    mc "It's all probably gonna work out in the end."

    scene e4s2-12 with dissolve
    mi "I hope so, friend."

    scene e4s2-13 with dissolve
    mi "Emotions are not good motivators when fighting, I think you know that as well."

    scene e4s2-14 with dissolve
    mi "Keep them in check, don't let them influence your life."

    scene e4s2-15 with dissolve
    mc "Yeah, I'll do just that, thanks [mi]!"

    scene e4s2-16 with dissolve
    mi "No worries."

    scene e4s2-17 with dissolve
    pause

    scene e4s2-18 with dissolve
    mi "I'll just go to the bathroom real quick, be right back."

    scene e4s2-19 with dissolve
    pause

    scene e4s2-20 with dissolve
    pause

    scene e4s2-21 with dissolve
    pause

    scene e4s2-22 with dissolve
    mc "*Hey, is that [ci]?*"
    mc "*What is she doing here?*"

    scene e4s2-23 with dissolve
    mc "*It looks like she's training here.*"

    scene e4s2-24 with dissolve
    mc "*Maybe I should go say hi.*"

    menu:
        "Say hi":
            call extrovert_affinity_check from _call_extrovert_affinity_check_67
            call color_check from _call_color_check_129

            $ e4s2_greet = True
            $ claire_trust += 1

            scene e4s2-25 with dissolve
            pause

            scene e4s2-26 with dissolve
            mc "Hi [ci]."

            scene e4s2-27 with dissolve
            ci "Hey, what do you need?"

            scene e4s2-28 with dissolve
            mc "Oh, nothing. Just wanted to say hi."
            mc "I recognized you from our party."

            scene e4s2-29 with dissolve
            pause

            scene e4s2-31 with dissolve
            ci "Wait, which one?"

            scene e4s2-30 with dissolve
            show e4s2_claire_blink1
            mc "Uh... the opening one?"
            mc "That one in the cafeteria?"

            scene e4s2-33 with dissolve
            hide e4s2_claire_blink1
            ci "Ohh... yeah, I remember now."

            scene e4s2-32 with dissolve
            ci "Well, not entirely, but I remember some of it."

            if e3f3_claire_drink == True:
                scene e4s2-34 with dissolve
                ci "Some scumbag gave me a tequila shot which made me puke all over the place."

                scene e4s2-35 with dissolve
                ci "If you happen to know who that is, please let me know."

                scene e4s2-34 with dissolve
                ci "He's ruined my reputation!"

                scene e4s2-36 with dissolve
                mc "*Shit...*"
                mc "Uh... yeah... will do!"

            scene e4s2-37 with dissolve
            ci "Anyway, I was extremely drunk."

            scene e4s2-32 with dissolve
            ci "I spent the whole night sitting on that damn couch."

            scene e4s2-34 with dissolve
            ci "My back still hurts."

            scene e4s2-36 with dissolve
            mc "Haha, I know!"
            mc "Probably the reason you don't remember me."

            scene e4s2-31 with dissolve
            ci "Wait, did we talk?"

            scene e4s2-30 with dissolve
            show e4s2_claire_blink1
            mc "Yeah, not a lot though."
            mc "Just enough to know that your name is [ci]."

            scene e4s2-31 with dissolve
            hide e4s2_claire_blink1
            ci "Oh, alright."

            scene e4s2-34 with dissolve
            ci "And your name is...?"

            scene e4s2-32 with dissolve
            ci "Sorry, as I said, I don't remember much from that night."

            scene e4s2-36 with dissolve
            mc "Don't worry, I'm [mc]."

            scene e4s2-33 with dissolve
            ci "Cool, nice to re-meet you!"

            scene e4s2-30 with dissolve
            show e4s2_claire_blink1
            mc "Cool."
            mc "..."
            mc "So... I guess I'll see you around?"

            scene e4s2-33 with dissolve
            hide e4s2_claire_blink1
            ci "Hopefully, in better circumstances than the ones at the party, haha!"

            scene e4s2-30 with dissolve
            show e4s2_claire_blink1
            mc "Haha, yeah!"

            scene e4s2-38 with dissolve
            hide e4s2_claire_blink1
            pause

        "Stay put":
            call introvert_affinity_check from _call_introvert_affinity_check_58
            call color_check from _call_color_check_130

            scene e4s2-21 with dissolve
            mc "*It might be a bit awkward, let's not.*"

            scene e4s2-39 with dissolve
            mc "*I'll just wait for [mi] to return.*"

    jump e4s3
return
