
default e4s36_song = False
default e4s36_olivia_cutscene = False

# Scene 36 - The making of a president (Sunday) ################################

label e4s36:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s36-01 with Dissolve(2.0)
    pause

    scene e4s36-02 with dissolve
    mc "I can't believe this didn't work either!"

    scene e4s36-03 with dissolve
    mc "He was... literally just standing on that scene, shitting himself."
    mc "He can't keep getting away with it!"

    scene e4s36-04 with dissolve
    jon "He will not, at least not for long."

    scene e4s36-05 with dissolve
    jon "Whatever we throw at him, it will not work."
    jon "He keeps on throwing it under the rug."

    $ e4s36_song = True
    play music everything_will_be_alright
    scene e4s36-06 with dissolve
    jon "We need a different approach, something that could shake him up for good."
    jon "A change of strategies."

    scene e4s36-07 with dissolve
    mc "Yeah? Like what?"

    scene e4s36-06 with dissolve
    jon "Something I should have probably done from the start."

    scene e4s36-08 with dissolve
    jon "Let's go, we've got a president to make."

    scene e4s36-09 with dissolve
    pause

    scene black with Dissolve(2.0)
    pause(1.0)

    $ episode_count += 1
    jump credits
return
