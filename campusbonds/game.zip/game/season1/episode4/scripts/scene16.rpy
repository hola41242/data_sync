
# Scene 16 - Tiffany's club ####################################################

label e4s16:
    scene black with Dissolve(2.0)
    pause(1.0)

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    play music crazy_glue
    scene e4s16-01 with Dissolve(2.0)
    pause

    scene e4s16-02 with dissolve
    pause

    scene e4s16-03 with dissolve
    mc "*Yeah... I don't think I'm hungry today.*"
    tf "Hey [mc]!"

    scene e4s16-04 with dissolve
    pause

    scene e4s16-05 with dissolve
    tf "Is it okay if I sit here?"

    scene e4s16-06 with dissolve
    mc "Sure, go ahead."

    scene e4s16-07 with dissolve
    tf "How have you been?"

    scene e4s16-08 with dissolve
    show e4s16_tiffany_blink1
    mc "Pretty fine, a little tired though."

    if e3s13_tiffany_hangout == True or e4s4_hangout == True:
        scene e4s16-09 with dissolve
        hide e4s16_tiffany_blink1
        tf "How's the situation with your father?"
        tf "Did you manage to talk to him?"

        scene e4s16-08 with dissolve
        show e4s16_tiffany_blink1
        mc "Nah... not really."
        mc "He hasn't been on my mind lately."
        mc "I'm pretty busy with other stuff right now."

        scene e4s16-10 with dissolve
        hide e4s16_tiffany_blink1
        tf "Oh, okay."

        scene e4s16-08 with dissolve
        show e4s16_tiffany_blink1
        mc "What about you?"
        mc "What have you been up to?"
    else:
        scene e4s16-11 with dissolve
        hide e4s16_tiffany_blink1
        tf "Didn't get much sleep?"

        scene e4s16-08 with dissolve
        show e4s16_tiffany_blink1
        mc "Nah, it's not that."
        mc "Just been busy with some stuff."

        scene e4s16-10 with dissolve
        hide e4s16_tiffany_blink1
        tf "I see."

        scene e4s16-08 with dissolve
        show e4s16_tiffany_blink1
        mc "What about you?"

        scene e4s16-09 with dissolve
        hide e4s16_tiffany_blink1
        tf "I'm feeling fine."

    scene e4s16-12 with dissolve
    tf "Just had this really cool class today."

    scene e4s16-13 with dissolve
    tf "It was a bit off topic, but we talked about the universe and space."

    scene e4s16-11 with dissolve
    tf "I thought it was really interesting."

    scene e4s16-08 with dissolve
    show e4s16_tiffany_blink1
    mc "Oh, that's nice!"
    mc "It's a subject that has a lot to it."

    scene e4s16-11 with dissolve
    hide e4s16_tiffany_blink1
    tf "Yeah."

    scene e4s16-13 with dissolve
    tf "I see you got the goo soup too."

    scene e4s16-14 with dissolve
    mc "Yeah... today's special, apparently."
    mc "So much for the good food, huh?"

    scene e4s16-15 with dissolve
    tf "Haha, yeah!"

    scene e4s16-16 with dissolve
    tf "I'm not that hungry anyway, you can have my bowl."

    scene e4s16-08 with dissolve
    show e4s16_tiffany_blink1
    mc "Yeah... thanks, but I already ate back home."
    mc "Not really hungry either."

    scene e4s16-17 with dissolve
    hide e4s16_tiffany_blink1
    tf "Haha, fair enough."

    scene e4s16-09 with dissolve
    tf "Hey so, what happened with the Party Ragers?"
    tf "Did you manage to talk to them about it?"

    scene e4s16-08 with dissolve
    show e4s16_tiffany_blink1
    menu:
        "Lie":
            $ e4s16_lie = True
            mc "No... not really."

            scene e4s16-18 with dissolve
            hide e4s16_tiffany_blink1
            show e4s16_tiffany_blink2
            mc "There's a bit of a situation there, and I didn't think it was the best time to talk."

            scene e4s16-69 with dissolve
            hide e4s16_tiffany_blink2
            tf "Oh, alright."

            scene e4s16-19 with dissolve
            tf "Just let me know when you do, alright?"

            scene e4s16-18 with dissolve
            show e4s16_tiffany_blink2
            mc "Yeah, don't worry about it."
            mc "I'll talk to them once things settle down a bit."

            scene e4s16-21 with dissolve
            hide e4s16_tiffany_blink2
            tf "Thank you, [mc], for doing this."

            scene e4s16-19 with dissolve
            tf "You really didn't have to."

            scene e4s16-18 with dissolve
            show e4s16_tiffany_blink2
            mc "It's no problem!"
            mc "What do you say?"
            mc "Are you ready to dive into the 'goo' soup?"

            scene e4s16-17 with dissolve
            hide e4s16_tiffany_blink2
            tf "Haha, I hoped you wouldn't say that."
        "Truth":
            mc "Yeah... I talked to them."
            mc "I'm sorry, it's a no go."

            scene e4s16-18 with dissolve
            hide e4s16_tiffany_blink1
            show e4s16_tiffany_blink2
            mc "They've got a bit of a situation with a professor that probably won't go away anytime soon."
            mc "They can't even hold parties there anymore."

            scene e4s16-20 with dissolve
            hide e4s16_tiffany_blink2
            tf "Oh... I understand."

            scene e4s16-18 with dissolve
            show e4s16_tiffany_blink2
            mc "I'm really sorry, I tried."

            scene e4s16-21 with dissolve
            hide e4s16_tiffany_blink2
            tf "Hey, it's alright, don't worry."

            scene e4s16-22 with dissolve
            tf "That matters to me the most."

            scene e4s16-19 with dissolve
            tf "Thank you for trying!"

            scene e4s16-18 with dissolve
            show e4s16_tiffany_blink2
            menu:
                "Try with College Rock" if e4s14_defend == True:
                    $ tiffany_trust += 1
                    $ e4s16_try = True
                    mc "Hey, I got another idea."
                    mc "If it didn't work with them, maybe it will work with others."
                    mc "I have another club in mind which could be a fit for you, although you'll need to learn some instruments."

                    scene e4s16-23 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "A music club?"

                    scene e4s16-20 with dissolve
                    tf "Holy shit, I don't know, I never touched an instrument in my life."

                    scene e4s16-18 with dissolve
                    show e4s16_tiffany_blink2
                    mc "Haha, it's gonna be fine."
                    mc "I went there a couple of times myself, maybe they could accept you as well."

                    scene e4s16-19 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "You think that's gonna work?"

                    scene e4s16-18 with dissolve
                    show e4s16_tiffany_blink2
                    mc "Sure, why not?"
                    mc "I'm off to it now, you can join me."

                    scene e4s16-23 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "Oh my God, really?"

                    scene e4s16-24 with dissolve
                    tf "Wait, how do I look?"
                    tf "Am I fine?"

                    scene e4s16-25 with dissolve
                    mc "Haha, yeah, don't worry."
                    mc "There's no dress code in there or anything."

                    scene e4s16-18 with dissolve
                    show e4s16_tiffany_blink2
                    mc "Just, be yourself, alright?"
                    mc "I'm sure they'll love you."

                    stop music fadeout 1.0
                    scene e4s16-16 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "Okay... okay."
                    tf "I trust you."

                    play music sun_sets_on_a_protagonist
                    scene e4s16-26 with wipeleft
                    mc "So... here we are!"

                    scene e4s16-27 with dissolve
                    mc "College Rock."

                    scene e4s16-28 with dissolve
                    tf "This is so cool!"

                    scene e4s16-29 with dissolve
                    tf "I love the cozy vibe this place gives."
                    tf "Sort of like a garage band or something."

                    scene e4s16-30 with dissolve
                    pause

                    scene e4s16-31 with dissolve
                    mc "Haha!"

                    scene e4s16-32 with dissolve
                    pause

                    scene e4s16-33 with dissolve
                    pause

                    scene e4s16-37 with dissolve
                    ev "Wait a moment."

                    scene e4s16-34 with dissolve
                    pause

                    scene e4s16-38 with dissolve
                    ev "Hello!"

                    scene e4s16-39 with dissolve
                    ev "Is there something wrong?"

                    if francesca_trust > 3:
                        scene e4s16-35 with dissolve
                        pause

                        scene e4s16-36 with dissolve
                        pause

                    scene e4s16-40 with dissolve
                    mc "No, I was just presenting [tf] the club."

                    scene e4s16-41 with dissolve
                    mc "She was looking for one to join, so I thought you might benefit from another member."
                    mc "Can't hurt to have more, right?"

                    scene e4s16-42 with dissolve
                    ev "Hello [tf], my name is [ev]."

                    if francesca_trust > 3:
                        scene e4s16-43 with dissolve
                        pause

                        scene e4s16-44 with dissolve
                        pause

                        scene e4s16-45 with dissolve
                        pause

                        scene e4s16-46 with dissolve
                        pause

                        scene e4s16-47 with dissolve
                        pause

                        scene e4s16-48 with dissolve
                        pause

                        scene e4s16-49 with dissolve
                        pause

                    scene e4s16-50 with dissolve
                    tf "Nice to meet you!"

                    scene e4s16-51 with dissolve
                    tf "Your club is really nice."

                    scene e4s16-42 with dissolve
                    ev "Thank you!"
                    ev "We all worked very hard to bring it into its current shape."

                    scene e4s16-50 with dissolve
                    tf "Yeah, I can tell."

                    scene e4s16-52 with dissolve
                    mc "So... what do you think, [ev]?"
                    mc "You think she can join us?"

                    scene e4s16-53 with dissolve
                    pause

                    scene e4s16-54 with dissolve
                    ev "I'm sorry darling, but we can't really take new members right now."

                    scene e4s16-55 with dissolve
                    ev "The competition window closed this week."

                    scene e4s16-54 with dissolve
                    ev "I would have loved to have a new member, but it's just not possible at the moment."

                    scene e4s16-40 with dissolve
                    mc "Can't she just, hang around here?"
                    mc "Learn a couple of instruments, just be a part of the group."
                    mc "She doesn't have to get involved in the competition."

                    scene e4s16-56 with dissolve
                    ev "We have a lot of practices to do before the deadline arrives."
                    ev "Nobody would have time to teach her the basics and to keep an eye on her."

                    scene e4s16-54 with dissolve
                    ev "Maybe after the competiton is over?"

                    scene e4s16-57 with dissolve
                    mc "I understand."

                    scene e4s16-58 with dissolve
                    mc "What do you say, [tf]?"
                    mc "Does that sound alright?"

                    scene e4s16-61 with dissolve
                    tf "..."

                    scene e4s16-60 with dissolve
                    tf "Yeah, it's fine."

                    scene e4s16-59 with dissolve
                    tf "I don't want to be an obstacle, plus I don't really know how to play instruments, so I guess it's better this way."

                    scene e4s16-62 with dissolve
                    tf "Good luck with your competition!"

                    scene e4s16-54 with dissolve
                    ev "Thank you! And again, I'm sorry."

                    scene e4s16-63 with dissolve
                    ev "If you're willing to wait until after the competition, we'd be more than happy to take you in."

                    scene e4s16-59 with dissolve
                    tf "Thank you!"

                    scene e4s16-56 with dissolve
                    ev "[mc], can I have a few words with you?"

                    scene e4s16-58 with dissolve
                    mc "[tf]?"

                    scene e4s16-64 with dissolve
                    tf "Go ahead [mc], I'll wait for you outside."

                    scene e4s16-65 with dissolve
                    pause

                    scene e4s16-40 with dissolve
                    mc "What's up?"

                    scene e4s16-66 with dissolve
                    ev "Just wanted to say thank you for looking out for the club."

                    scene e4s16-67 with dissolve
                    ev "We don't usually get new members, so any effort is deeply appreciated."

                    scene e4s16-68 with dissolve
                    ev "If it weren't for the competition, we would have received her with open arms."

                    scene e4s16-40 with dissolve
                    mc "*Damn... I didn't know Evelyn could be this nice to someone.*"
                    mc "*I expected her to at least have a reaction that I tried bringing in someone new without talking to her.*"
                    mc "Yeah, we understand the situation."
                    mc "It is unfortunate, but at least I tried."

                    scene e4s16-39 with dissolve
                    ev "To us, that's what matters the most."

                    scene e4s16-68 with dissolve
                    ev "If it's okay with her, she can attend today's class."
                    ev "See if she likes it here."

                    scene e4s16-67 with dissolve
                    ev "It would be a shame to see her leave on her own."

                    scene e4s16-40 with dissolve
                    mc "Yeah... I think that will be great."
                    mc "Thanks, [ev]!"

                    scene e4s16-66 with dissolve
                    ev "Don't mention it."

                    jump e4s17
                "Drop the idea":
                    mc "I hope you're gonna find the right club for you."

                    scene e4s16-20 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "Yeah, I'll probably stop trying."

                    scene e4s16-19 with dissolve
                    tf "Maybe I'm just not made for it."

                    scene e4s16-69 with dissolve
                    tf "I'll just keep hanging out with this girl friend I made a while ago."
                    tf "Maybe make some other friends along the way, college clubs aren't the only thing out there, right?"

                    scene e4s16-19 with dissolve
                    tf "Life's more than that."

                    scene e4s16-18 with dissolve
                    show e4s16_tiffany_blink2
                    mc "Yeah, that's a great way to look at it."
                    mc "I'm glad you're seeing this optimistically!"

                    scene e4s16-20 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "Yeah..."

                    scene e4s16-18 with dissolve
                    show e4s16_tiffany_blink2
                    mc "Anyway, what do you say?"
                    mc "Are you ready to dive into the 'goo' soup?"

                    scene e4s16-17 with dissolve
                    hide e4s16_tiffany_blink2
                    tf "Haha, I hoped you wouldn't say that."
    jump e4s17
return
