
default e4s23_tracy_sitting = 0

default e4s23_tracy_cowgirl = 0
default e4s23_tracy_position = 0

# Scene 23 - Night beat ########################################################

label e4s23:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    if e4s11_help == True:
        play music words_fall_apart
        scene e4s23-fr_01 with wipeleft
        fr "So... here we are."

        scene e4s23-fr_02 with dissolve
        pause

        scene e4s23-fr_03 with dissolve
        pause

        scene e4s23-fr_04 with vpunch
        mc "Damn, that's a big dog!"

        scene e4s23-fr_05 with dissolve
        fr "Haha, don't worry."
        fr "He doesn't bite, especially that you're with me."

        scene e4s23-fr_06 with dissolve
        "{i}Sniff Sniff.{/i}"

        scene e4s23-fr_07 with dissolve
        mc "Here... doggo..."
        mc "Good boy!"

        if affinity_spectrum > 0:
            scene e4s23-fr_08 with dissolve
            pause

        scene e4s23-fr_09 with dissolve
        fr "His name is Husk."

        scene e4s23-fr_10 with dissolve
        fr "Haha, I think he likes you. "

        if affinity_spectrum > 0:
            scene e4s23-fr_11 with dissolve
            mc "Either that, or he wants to take a bite."

        scene e4s23-fr_12 with dissolve
        pause

        scene e4s23-fr_13 with dissolve
        mc "Hey, I didn't know you have a dog."

        scene e4s23-fr_14 with dissolve
        fr "You never asked."

        if e2s10_francesca == True:
            scene e4s23-fr_15 with dissolve
            mc "Yeah, but last time I've been here there was no dog."

            scene e4s23-fr_16 with dissolve
            fr "That's because he was at my sister's place."
            fr "She took him to the vet."
        else:
            scene e4s23-fr_16 with dissolve
            fr "Anyway, my sister had him for a couple of days."
            fr "She had to take him to the vet."

        scene e4s23-fr_17 with dissolve
        mc "Wait, you also have a sister?"
        mc "That's a lot of unknown information here."

        scene e4s23-fr_18 with dissolve
        fr "Haha, shut up!"
        fr "We're bonding."

        scene e4s23-fr_17 with dissolve
        mc "I mean, what's next, your father is the president?"

        scene e4s23-fr_19 with dissolve
        fr "If it were up to him, he'd already be running this country."

        scene e4s23-fr_17 with dissolve
        mc "Controlling and a big ego, sounds about right."

        scene e4s23-fr_20 with dissolve
        fr "Let's go upstairs, we're gonna study in my room."

        if e2s10_francesca == False:
            scene e4s23-fr_21 with dissolve
            mc "Damn... this is a big house."

            scene e4s23-fr_22 with dissolve
            fr "A big and empty house, yeah."

        if e3s23_tracy_feelings == True and e4s5_tracy_mad == False:
            scene e4s23-fr_111 with dissolve
            play sound phone_buzz
            pause

            nvl clear

            scene e4s23-fr_112 with dissolve
            tr_nvl "Hey, you up?"
            n_nvl "Yeah, what's up?"
            tr_nvl "So, funny situation I'm in right now."
            tr_nvl "I ordered a pizza because I was really craving one..."
            tr_nvl "And somehow they messed it up and got two instead of one."
            tr_nvl "And I was maybe thinking you could join me for one."

            menu (nvl = True):
                "Stay and Study with [fr]":
                    $ e4s23_stay = True

                    $ francesca_trust += 1
                    $ tracy_trust -= 1
                    n_nvl "Sorry [tr], I can't right now."
                    n_nvl "I'm having a study night with a friend, maybe some other time?"
                    tr_nvl "Alright, have fun."

                "Leave and Hang Out with [tr]":
                    $ e4s23_tracy_hangout = True
                    $ e4s23_leave = True
                    $ e4s11_help = False

                    $ francesca_trust -= 2
                    $ francesca_intimacy -= 1
                    $ tracy_trust += 1
                    n_nvl "Yeah, that sounds good."
                    n_nvl "Way better than the studying night I was about to have."
                    tr_nvl "Hope it's nothing important."
                    n_nvl "No, not really."
                    n_nvl "I'll see you in half an hour!"
                    n_nvl "Don't eat it all."
                    tr_nvl "I promise not to eat all the pizza."

            scene e4s23-fr_113 with dissolve
            pause

            if e4s23_leave == True:
                scene e4s23-fr_114 with dissolve
                show e4s23_francesca_blink2
                mc "Hey... [fr], I don't think I can stay."

                scene e4s23-fr_115 with dissolve
                hide e4s23_francesca_blink2
                fr "Huh? Why?"
                fr "What's wrong?"

                scene e4s23-fr_114 with dissolve
                show e4s23_francesca_blink2
                mc "Well... I have this other thing... and I totally forgot about it."
                mc "I'm sorry."

                scene e4s23-fr_116 with dissolve
                hide e4s23_francesca_blink2
                fr "...you forgot about tonight?"

                scene e4s23-fr_117 with dissolve
                fr "You could've just said you didn't want to come."

                scene e4s23-fr_114 with dissolve
                show e4s23_francesca_blink2
                mc "It's not like that."

                if francesca_trust > 3:
                    scene e4s23-fr_117 with dissolve
                    hide e4s23_francesca_blink2
                    fr "Really?"
                    fr "Because right now it really feels like it is."

                    scene e4s23-fr_118 with dissolve
                    show e4s23_francesca_blink3
                    mc "..."

                    scene e4s23-fr_119 with dissolve
                    hide e4s23_francesca_blink3
                    fr "Ok... whatever, do what you want."

                    scene e4s23-fr_118 with dissolve
                    show e4s23_francesca_blink3
                    mc "Come on..."

                    scene e4s23-fr_117 with dissolve
                    hide e4s23_francesca_blink3
                    fr "Well, obviously, you don't want to tell me what's going on, so why bother anymore"

                    if e2s9_francesca_call == True:
                        if e2s9_francesca_lie == False and e2s3_hangout == True:
                            fr "This is the second time you've put me off for one of your parties."

                            scene e4s23-fr_118 with dissolve
                            show e4s23_francesca_blink3
                            mc "Wait, but it's not like that!"

                            scene e4s23-fr_120 with dissolve
                            hide e4s23_francesca_blink3
                            fr "Then what is it?"
                            fr "Another 'study night' conveniently scheduled on the same night as ours?"
                            fr "Come on, I saw you texting."
                        else:
                            fr "I'm wondering if you were ever honest with me."

                            scene e4s23-fr_118 with dissolve
                            show e4s23_francesca_blink3
                            mc "Huh? About what?"

                            scene e4s23-fr_116 with dissolve
                            hide e4s23_francesca_blink3
                            fr "When you called asking to stay over... was it really because you locked yourself out?"

                            scene e4s23-fr_118 with dissolve
                            show e4s23_francesca_blink3
                            mc "What other reason would there be?"

                            scene e4s23-fr_117 with dissolve
                            hide e4s23_francesca_blink3
                            fr "You tell me."
                    else:
                        if e2s3_hangout == True:
                            scene e4s23-fr_118 with dissolve
                            show e4s23_francesca_blink3
                            mc "..."

                            scene e4s23-fr_117 with dissolve
                            hide e4s23_francesca_blink3
                            fr "This is the second time you put me off."
                            fr "Is it really a coincidence that something always comes up?"

                    scene e4s23-fr_118 with dissolve
                    show e4s23_francesca_blink3
                    mc "..."

                    scene e4s23-fr_119 with dissolve
                    hide e4s23_francesca_blink3
                    fr "Just... go already."
                else:
                    scene e4s23-fr_117 with dissolve
                    fr "That's... okay, I guess."
                    fr "Things happen."

                    scene e4s23-fr_114 with dissolve
                    show e4s23_francesca_blink2
                    mc "I really am sorry."

                    if e2s3_hangout == True:
                        scene e4s23-fr_116 with dissolve
                        hide e4s23_francesca_blink2
                        fr "It's fine."

                        scene e4s23-fr_117 with dissolve
                        fr "I mean, it's not the first time something's come up, right?"

                    scene e4s23-fr_116 with dissolve
                    fr "We can just do this another time... or not. Whatever."

                    scene e4s23-fr_114 with dissolve
                    show e4s23_francesca_blink2
                    mc "Yeah..."
                    fr "..."
                    mc "I should probably go."

                    scene e4s23-fr_119 with dissolve
                    hide e4s23_francesca_blink2
                    fr "Yeah... you should."

                scene e4s23-fr_121 with dissolve
                pause

            if e4s23_stay == True:
                scene e4s23-fr_116 with dissolve
                fr "Is there something wrong?"

                scene e4s23-fr_117 with dissolve
                fr "I saw you on your phone."

                scene e4s23-fr_115 with dissolve
                fr "Sorry, I don't mean to be intrusive or anything."

                scene e4s23-fr_114 with dissolve
                show e4s23_francesca_blink2
                mc "Nah, everything's alright, don't worry."

                menu:
                    "Lie":
                        $ e4s23_francesca_lie = True
                        mc "Just [jon] sending me a text about tomorrow's class."

                        scene e4s23-fr_116 with dissolve
                        hide e4s23_francesca_blink2
                        fr "Okay."

                    "Tell the truth":
                        $ francesca_intimacy += 1
                        $ e4s23_francesca_truth = True

                        mc "It was a friend, she wanted me to come over for pizza."
                        mc "But I told her no, we had a study night planned."
                        mc "I couldn't just ditch you like that."

                        scene e4s23-fr_116 with dissolve
                        hide e4s23_francesca_blink2
                        fr "You could've gone if you really wanted to."

                        scene e4s23-fr_114 with dissolve
                        show e4s23_francesca_blink2
                        mc "Nah, I wanted to be here, this matters too."

                        scene e4s23-fr_117 with dissolve
                        hide e4s23_francesca_blink2
                        fr "Thanks [mc]! I really appreciate that."

                        scene e4s23-fr_114 with dissolve
                        show e4s23_francesca_blink2
                        mc "Don't worry about it."
        else:
            scene e4s23-fr_23 with dissolve
            pause

        stop music fadeout 1.0
        scene black with Dissolve(2.0)
        hide e4s23_francesca_blink2
        pause(1.0)

        if francesca_trust > 3 and e4s23_leave == False:
            scene e4s23-fr_24 with Dissolve(1.0)
            pause

            play music solo_acoustic_guitar
            scene e4s23-fr_25 with dissolve
            pause

            if e4s16_try == True:
                scene e4s23-fr_30 with dissolve
                fr "So..."
                fr "Who's the girl from a couple of days ago?"

                scene e4s23-fr_29 with dissolve
                show e4s23_francesca_blink1
                mc "Haha, what girl?"

                scene e4s23-fr_109 with dissolve
                hide e4s23_francesca_blink1
                fr "You know... the one you wanted to introduce to College Rock."

                scene e4s23-fr_29 with dissolve
                show e4s23_francesca_blink1
                mc "I didn't take you as the jealous one."

                scene e4s23-fr_110 with dissolve
                hide e4s23_francesca_blink1
                fr "I'm not!"
                fr "Just... curious that's all."

                scene e4s23-fr_29 with dissolve
                show e4s23_francesca_blink1
                if e2f2_tiffany_refuse == False:
                    mc "I met her at a house party a few weeks back."
                    mc "Not a lot happened between us until I heard her sobbing in one of the classes a couple of days ago."
                else:
                    mc "A few days back I heard a person sobbing in one of the classes."

                mc "When I went to check it out, she was there."
                mc "She felt really bad because every club she had applied to rejected her."
                mc "So, I thought I'd help her join the Party Ragers."
                mc "Unfortunately, that was a big fail, so I thought I'd try with your club as well."
                mc "But it didn't work out either, so yeah..."

                scene e4s23-fr_109 with dissolve
                hide e4s23_francesca_blink1
                fr "I'm really sorry to hear that... I didn't know."

                scene e4s23-fr_31 with dissolve
                fr "Maybe I could talk to [ev] and see if we can make room for her?"

                scene e4s23-fr_29 with dissolve
                show e4s23_francesca_blink1
                mc "That would be great, thank you."
                mc "Although, she said she's gonna take some time off from them."

                scene e4s23-fr_109 with dissolve
                hide e4s23_francesca_blink1
                fr "Poor girl, I can only imagine."

                scene e4s23-fr_31 with dissolve
                fr "I'll see what I can do."

                scene e4s23-fr_29 with dissolve
                show e4s23_francesca_blink1
                mc "Thanks!"

                scene e4s23-fr_25 with dissolve
                hide e4s23_francesca_blink1
                pause

            scene e4s23-fr_26 with dissolve
            mc "Could this subject be any more boring?"

            scene e4s23-fr_27 with dissolve
            fr "Haha, I'm totally with you on this one."

            scene e4s23-fr_28 with dissolve
            fr "Now you understand why I put it off?"

            scene e4s23-fr_29 with dissolve
            show e4s23_francesca_blink1
            mc "Yeah... it all makes sense now."

            scene e4s23-fr_30 with dissolve
            hide e4s23_francesca_blink1
            fr "Well, let's not repeat my mistake with you."

            scene e4s23-fr_31 with dissolve
            fr "The sooner we get this over, the better."

            scene e4s23-fr_29 with dissolve
            show e4s23_francesca_blink1
            mc "Come on... we've been studying for the past 2 hours, let's take a break."

            scene e4s23-fr_31 with dissolve
            hide e4s23_francesca_blink1
            fr "There's not long left, we can do this."

            scene e4s23-fr_32 with dissolve
            pause

            scene e4s23-fr_33 with dissolve
            pause

            scene e4s23-fr_34 with dissolve
            pause

            scene e4s23-fr_35 with dissolve
            pause

            scene e4s23-fr_36 with dissolve
            pause

            scene e4s23-fr_37 with dissolve
            pause

            scene e4s23-fr_38 with dissolve
            pause

            scene e4s23-fr_40 with dissolve
            mc "Here, don't you wanna see what I learned so far in College Rock?"

            scene e4s23-fr_39 with dissolve
            fr "Haha, I hear you play it everyday, what do you mean?"

            scene e4s23-fr_40 with dissolve
            mc "Yeah but it's random notes that I have to learn."
            mc "Let me play a song or something."

            scene e4s23-fr_39 with dissolve
            fr "Do you even know how to play a full song?"

            scene e4s23-fr_40 with dissolve
            mc "No... but I'll improvise!"

            scene e4s23-fr_39 with dissolve
            fr "Alright then, I'd love to hear you play it."

            scene e4s23-fr_41 with dissolve
            pause

            scene black with Dissolve(2.0)
            pause(1.0)

            scene e4s23-fr_41 with Dissolve(2.0)
            pause

            if music_skills > 4 or guitar_skills > 1:
                scene e4s23-fr_42 with dissolve
                fr "Oh my God, [mc], you're really improving!"

                scene e4s23-fr_43 with dissolve
                fr "That was great."

                scene e4s23-fr_40 with dissolve
                mc "Thank you!"

                scene e4s23-fr_39 with dissolve
                fr "With a bit more practice, I'm sure you could help us in the competition."
            else:
                scene e4s23-fr_51 with dissolve
                mc "Wow... did it really sound as bad as I played it?"

                scene e4s23-fr_39 with dissolve
                fr "Haha, you're still not there, but you have time to practice."
                fr "I'm not sure it will be in time for our competition, but never say never, right?"

                scene e4s23-fr_40 with dissolve
                mc "Haha, I guess you're right."

            scene e4s23-fr_37 with dissolve
            pause

            scene e4s23-fr_44 with dissolve
            fr "Let's get back to our studying, shall we?"

            scene e4s23-fr_45 with dissolve
            mc "Pfft, I guess..."

            scene e4s23-fr_32 with dissolve
            pause

            stop music fadeout 1.0
            scene black with Dissolve(2.0)
            pause(1.0)

            play music satfes
            scene e4s23-fr_25 with Dissolve(2.0)
            pause

            scene e4s23-fr_26 with dissolve
            mc "Finally, it's over."

            scene e4s23-fr_46 with dissolve
            fr "My mind hurts, this better be worth it."
            fr "We could really use a break."

            scene e4s23-fr_47 with dissolve
            mc "Well... I've already played the guitar, so there aren't many activities left, haha!"

            scene e4s23-fr_48 with dissolve
            fr "Haha, I guess you're right."

            scene e4s23-fr_49 with dissolve
            fr "I'm just gonnna lay flat for a bit."

            scene e4s23-fr_50 with dissolve
            mc "Alright."

            scene e4s23-fr_51 with dissolve
            menu:
                "Make a move" if francesca_trust > 4:
                    if affinity_spectrum <= 0 and e3s24_francesca_lewd == True:
                        $ e4s23_francesca_lewd = 1
                        $ persistent.e4s23_francesca_lewd = 1
                        call e4s23_francesca_lewd from _call_e4s23_francesca_lewd
                    elif affinity_spectrum <= 0:
                        $ e4s23_francesca_lewd = 2
                        $ persistent.e4s23_francesca_lewd = 2
                        call e4s23_francesca_lewd from _call_e4s23_francesca_lewd_1
                    elif affinity_spectrum > 0 and e4s23_francesca_truth == True:
                        $ e4s23_francesca_lewd = 2
                        $ persistent.e4s23_francesca_lewd = 2
                        call e4s23_francesca_lewd from _call_e4s23_francesca_lewd_2
                    elif affinity_spectrum > 0 and e4s11_tell == True:
                        $ e4s23_francesca_lewd = 2
                        $ persistent.e4s23_francesca_lewd = 2
                        call e4s23_francesca_lewd from _call_e4s23_francesca_lewd_3
                    else:
                        scene e4s23-fr_52 with dissolve
                        pause

                        scene e4s23-fr_53 with vpunch
                        pause

                        scene e4s23-fr_54 with dissolve
                        pause

                        scene e4s23-fr_55 with dissolve
                        fr "Oh, sorry, that's Husk."

                        scene e4s23-fr_56 with dissolve
                        fr "I think he's hungry."

                        scene e4s23-fr_57 with dissolve
                        mc "Oh, okay."

                        scene e4s23-fr_58 with dissolve
                        fr "It's getting a bit late, do you want me to prepare the couch for you?"

                        scene e4s23-fr_57 with dissolve
                        mc "Yeah, sure."

                        scene e4s23-fr_55 with dissolve
                        fr "Alright."

                        scene e4s23-fr_60 with dissolve
                        mc "*Damn Husk... you ruined the moment.*"

                        jump e4s24

                "Don't escalate":
                    scene e4s23-fr_59 with dissolve
                    pause

                    scene e4s23-fr_56 with dissolve
                    fr "It's getting a bit late, do you want me to prepare the couch for you?"

                    scene e4s23-fr_57 with dissolve
                    mc "Yeah, sure."

                    scene e4s23-fr_55 with dissolve
                    fr "Alright."

                    jump e4s24
        else:
            if e4s23_leave == False:
                jump e4s24

    if e3s23_tracy_feelings == True and e4s11_help == False:
        if e4s5_tracy_mad == False:
            if e4s23_tracy_hangout == False:
                play music brighter
                scene e4s23-tr_01 with Dissolve(2.0)
                play sound phone_buzz
                pause

                scene e4s23-tr_02 with dissolve
                pause

                scene e4s23-tr_03 with dissolve
                nvl clear

                tr_nvl "Hey, you up?"

                menu (nvl = True):
                    "Just respond":
                        n_nvl "Yeah, what's up?"

                    "Tease her":
                        scene e4s23-tr_04 with dissolve
                        n_nvl "Zzz..."
                        tr_nvl "Ha ha, real funny!"
                        n_nvl "Zzz..."
                        tr_nvl "Come on, I'm serious."

                        menu (nvl = True):
                            "Zzz...":
                                n_nvl "Zzz..."

                                if tracy_trust > 6:
                                    tr_nvl "Maybe this will wake you up."

                                    scene e4s23-tr_05 with dissolve
                                    n_nvl "Yup, I'm up, I'm up!"
                                else:
                                    scene e4s23-tr_05 with dissolve

                                n_nvl "[tr]?"
                                mc "*I don't think she's gonna respond anymore.*"
                                n_nvl "You there?"
                                tr_nvl "Zzz..."

                                if tracy_trust > 6:
                                    n_nvl "Come on... you can't do this to me."
                                    n_nvl "Not after you sent me that picture."
                                    tr_nvl "Zzz..."

                                scene e4s23-tr_03 with dissolve
                                n_nvl "Ok, for real now, what's up?"
                            "What's up?":
                                scene e4s23-tr_03 with dissolve
                                n_nvl "What's up?"

                tr_nvl "So, funny situation I'm in right now."
                tr_nvl "I ordered a pizza because I was really craving one..."
                tr_nvl "And somehow they messed it up and got two instead of one."
                tr_nvl "And I was maybe thinking you could join me for one."

                menu (nvl = True):
                    "Did you pay for both?":
                        n_nvl "Did you pay for both?"
                        n_nvl "How did they mess it up?"
                        tr_nvl "Haha, really?"
                        tr_nvl "That's your concern?"
                        tr_nvl "I got two for one somehow."
                        tr_nvl "I played along and got both, I didn't tell him I only had one ordered."
                        scene e4s23-tr_04 with dissolve
                        n_nvl "Haha, I see."

                    "Two for one?":
                        n_nvl "Two for one?"
                        tr_nvl "Yup! Lucky me."
                        n_nvl "Lucky us!"

                    "Zzz...":
                        $ tracy_trust -= 1
                        scene e4s23-tr_04 with dissolve
                        n_nvl "Zzz..."
                        tr_nvl "Fine, Sleeping Beauty can stay in bed."
                        tr_nvl "More pizza for me."
                        n_nvl "Sorry, sorry, I'm serious."
                        scene e4s23-tr_05 with dissolve
                        n_nvl "[tr]?"
                        n_nvl "You still there?"
                        n_nvl "*Shit, I think I went too far.*"

                        jump e4s24

                    "Maybe some other time":
                        $ tracy_trust -= 1
                        n_nvl "As much as I'd like to join you, I can't tonight, I'm sorry."
                        n_nvl "Maybe some other time."
                        tr_nvl "Alright then."
                        tr_nvl "I'm next door if you change your mind."

                        jump e4s24

                $ e4s23_tracy_hangout = True
                tr_nvl "So, you're coming?"
                n_nvl "Sure, just give me a sec to get ready."
                tr_nvl "Alright, I'm waiting for you."

                stop music fadeout 1.0
                scene e4s23-tr_07 with dissolve
                pause
            if e4s23_tracy_hangout == True:
                scene e4s23-tr_06 with wipeleft
                pause(1.0)

                menu:
                    "Knock":
                        $ tracy_trust += 1
                        scene e4s23-tr_08 with dissolve
                        play sound knock_knock
                        pause

                        play music satfes
                        scene e4s23-tr_13 with dissolve
                        if e1s17_tracy == True:
                            tr "Hey, you remembered to knock!"
                        else:
                            tr "Come on in."

                    "Just enter":
                        scene e4s23-tr_09 with dissolve
                        pause

                        scene e4s23-tr_10 with dissolve
                        mc "*Huh? It's locked.*"

                        scene e4s23-tr_11 with dissolve
                        nvl clear

                        n_nvl "Hey, I'm at your door."
                        tr_nvl "Alright, be there in a second."

                        play music satfes
                        scene e4s23-tr_12 with dissolve
                        tr "Come on in."

                        scene e4s23-tr_14 with dissolve
                        tr "Next time knock, alright?"
                        tr "I keep my door locked."

                        scene e4s23-tr_15 with dissolve
                        tr "Alright, no worries."

                scene e4s23-tr_17 with dissolve
                tr "So... unfortunately I don't have anything to watch a movie on."

                if e2f2_tracy_sex == True or e1f5_tracy_sex == True:
                    scene e4s23-tr_18 with dissolve
                    tr "Or any pot for that matter, so we'll have to do with just the pizza."
                else:
                    scene e4s23-tr_18 with dissolve

                tr "Hope you don't mind it..."

                scene e4s23-tr_16 with dissolve
                menu:
                    "Don't mind it":
                        mc "I don't mind it."

                    "Too bad":
                        $ tracy_trust -= 1
                        $ tracy_intimacy -= 1
                        mc "Oh... that's too bad."
                        mc "I guess we'll have to do with just the pizza then."

                        scene e4s23-tr_18 with dissolve
                        tr "Yeah..."

                        scene e4s23-tr_16 with dissolve

                    "Better this way":
                        $ tracy_trust += 1
                        mc "I think it's better this way."

                        scene e4s23-tr_19 with dissolve
                        tr "Really?"

                        scene e4s23-tr_16 with dissolve
                        mc "Yeah, we don't need constant stimulation to be around each other."
                        mc "Pizza and chilling sounds good to me."

                        scene e4s23-tr_17 with dissolve
                        tr "Isn't that boring?"

                        scene e4s23-tr_16 with dissolve
                        mc "Silence isn't always boring."
                        mc "Not when you're with the right person."

                mc "Come on, let's dig in."

                scene e4s23-tr_20 with wipeleft
                mc "So what's your deal, anyway?"

                scene e4s23-tr_22 with dissolve
                tr "What do you mean?"

                scene e4s23_pizza_1 with dissolve
                mc "I barely know you, you gotta have a story or something."
                mc "We didn't really get to have a heart to heart yet."

                show e4s23_current_pizza_1
                show e4s23-tr_50 behind e4s23_current_pizza_1
                with dissolve
                tr "So, the interrogation starts, huh?"

                scene e4s23-tr_38 with dissolve
                hide e4s23_current_pizza_1
                hide e4s23-tr_50
                show e4s23-tracy_blink1
                mc "Haha, don't take it as that."
                mc "Take it as a bonding moment."
                mc "Here, if you want I can start first."
                mc "Maybe it will ease a bit of the tension."

                show e4s23_current_pizza_1
                show e4s23-tr_24 behind e4s23_current_pizza_1
                with dissolve
                hide e4s23-tracy_blink1
                tr "Sure, go ahead."

                show e4s23-tr_40 behind e4s23_current_pizza_1 with dissolve
                hide e4s23-tr_24
                tr "Now that I think about it, I don't know anything about you either."

                scene e4s23_pizza_2 with dissolve
                hide e4s23_current_pizza_1
                hide e4s23-tr_40
                mc "See? That's what I mean."
                mc "Anyway, where do I start."
                mc "Do you want to know anything in particular?"

                show e4s23_current_pizza_2
                show e4s23-tr_24 behind e4s23_current_pizza_2
                with dissolve
                tr "I guess we should start with what brought us together in the first place."

                show e4s23-tr_22 behind e4s23_current_pizza_2 with dissolve
                tr "How did you and [jon] meet?"

                scene e4s23-tr_39 with dissolve
                hide e4s23_current_pizza_2
                hide e4s23-tr_22
                show e4s23-tracy_blink1
                mc "Well... we go way back."
                mc "I used to live here in Underport when I was younger but I eventually moved out due to financial constraints."
                mc "Me and [jon] met in elementary school."
                mc "I was this impulsive kid."
                mc "I was lashing out at other people, I was a bit of a bully."
                mc "But it all kind of changed when I met him."
                mc "He showed me how to fight, not like fight my demons or anything."
                mc "But like fight fight, like in tournaments and shit."
                mc "And it changed me, it gave me a purpose."
                mc "Unfortunately though, it was taken away just as fast as it was given."

                show e4s23_current_pizza_2
                show e4s23-tr_40 behind e4s23_current_pizza_2
                with dissolve
                hide e4s23-tracy_blink1
                tr "What happened?"

                scene e4s23_pizza_3 with dissolve
                hide e4s23_current_pizza_2
                hide e4s23-tr_40
                mc "I participated in this tournament where I made my way to the final."
                mc "But unfortunately, I didn't see the end of it."
                mc "There was a cheap illegal shot to the back of my head which made me unconscious."
                mc "And eventually left me paralyzed for a whole year."

                scene e4s23-tr_40 with dissolve
                tr "Holy shit, was it that serious?"

                scene e4s23-tr_21 with dissolve
                show e4s23-tracy_blink1
                mc "Yeah, I honestly believed I wouldn't be able to live a normal life anymore."

                scene e4s23-tr_24 with dissolve
                hide e4s23-tracy_blink1
                tr "You're lucky to be here then."

                scene e4s23_pizza_1 with dissolve
                mc "Yeah, I very much am so."
                mc "I can't have a career in fighting anymore."
                mc "I don't even want to think about how people would take advantage of this injury if I were to fight professionally again."

                show e4s23_current_pizza_1
                show e4s23-tr_23 behind e4s23_current_pizza_1
                with dissolve
                tr "Shitty world we live in, huh?"

                scene e4s23-tr_38 with dissolve
                hide e4s23_current_pizza_1
                hide e4s23-tr_23
                show e4s23-tracy_blink1
                mc "Yeah..."
                mc "But anyway, that's all in the past now."

                show e4s23_current_pizza_1
                show e4s23-tr_41 behind e4s23_current_pizza_1
                with dissolve
                hide e4s23-tracy_blink1
                tr "..."

                show e4s23-tr_40 behind e4s23_current_pizza_1 with dissolve
                hide e4s23-tr_41
                tr "How is it so easy for you to open up?"

                scene e4s23_pizza_2 with dissolve
                hide e4s23_current_pizza_1
                hide e4s23-tr_40
                mc "What do you mean?"

                show e4s23_current_pizza_2
                show e4s23-tr_23 behind e4s23_current_pizza_2
                with dissolve
                tr "I don't know... it's like you talk about it like it doesn't bother you."

                scene e4s23-tr_39 with dissolve
                hide e4s23_current_pizza_2
                hide e4s23-tr_23
                show e4s23-tracy_blink1
                mc "Yeah, because it kind of doesn't."
                mc "I learned to make peace with it, even if it might still hurt from time to time."
                mc "Talking about it more and more kind of eases that pain, you know?"

                show e4s23_current_pizza_2
                show e4s23-tr_22 behind e4s23_current_pizza_2
                with dissolve
                hide e4s23-tracy_blink1
                tr "I kind of wish I could be like you, haha!"

                scene e4s23_pizza_3 with dissolve
                hide e4s23_current_pizza_2
                hide e4s23-tr_22
                mc "Well, you can start now."
                mc "The sooner the better."

                scene e4s23-tr_23 with dissolve
                tr "It's weird because I never felt like I could just talk to someone about deeper stuff."

                scene e4s23-tr_24 with dissolve
                tr "Like, most of the time there were just surface level talks."

                scene e4s23-tr_40 with dissolve
                tr "Sometimes, I get thoughts and try to reflect on them, but it would be easier to have someone to share them with, right?"

                scene e4s23-tr_21 with dissolve
                show e4s23-tracy_blink1
                mc "Not even with [sd]?"

                scene e4s23-tr_23 with dissolve
                hide e4s23-tracy_blink1
                tr "Well, she's the closest I've gotten to having those types of conversation."
                tr "But even then sometimes it seems like she's mostly interested in the surface things."

                scene e4s23-tr_24 with dissolve
                tr "And I'm not saying that's a bad thing, some people might just be like that."
                tr "But I like to think a bit deeper."

                scene e4s23-tr_21 with dissolve
                show e4s23-tracy_blink1
                mc "I didn't know you were like this."

                scene e4s23-tr_23 with dissolve
                hide e4s23-tracy_blink1
                tr "Yeah, most people don't I guess."

                scene e4s23-tr_21 with dissolve
                show e4s23-tracy_blink1
                mc "But you're not making it easier for them either."
                mc "If even I didn't know, how can you expect them to know?"

                scene e4s23-tr_23 with dissolve
                hide e4s23-tracy_blink1
                tr "I guess... it just comes harder than expected."

                scene e4s23-tr_21 with dissolve
                show e4s23-tracy_blink1
                mc "The good thing is that what you're doing now, speaking to me about this is opening up."

                scene e4s23-tr_23 with dissolve
                hide e4s23-tracy_blink1
                tr "Yeah..."

                scene e4s23-tr_42 with dissolve
                pause

                scene e4s23-tr_43 with dissolve
                tr "You know... I used this pizza story as a pre-text."

                scene e4s23-tr_44 with dissolve
                tr "They didn't give me two pizzas, I ordered two."
                tr "I wanted to invite you here but I didn't know how."

                scene e4s23-tr_54 with dissolve
                menu:
                    "Make a joke":
                        $ tracy_trust -= 1
                        scene e4s23-tr_47 with dissolve
                        mc "Damn, maybe not so much opening up!"

                        scene e4s23-tr_48 with dissolve
                        mc "Sorry, that was a bad joke."

                    "Don't push it":
                        mc "..."

                scene e4s23-tr_45 with dissolve
                mc "You could have just asked."

                scene e4s23-tr_44 with dissolve
                tr "Yeah, but it's a bit weird."

                scene e4s23-tr_46 with dissolve
                tr "I don't know, it's easier when there's a reason."

                scene e4s23-tr_48 with dissolve
                mc "Well, I'm glad you did."

                scene e4s23-tr_54 with dissolve
                pause

                scene e4s23-tr_53 with dissolve
                tr "Would you like a tit job?"

                scene e4s23-tr_47 with dissolve
                mc "Haha, what?"

                scene e4s23-tr_49 with dissolve
                tr "What? I'm being serious."

                scene e4s23-tr_44 with dissolve
                tr "You told me to just ask."

                scene e4s23-tr_46 with dissolve
                tr "This part's easier than just... sitting and talking, you know?"

                scene e4s23-tr_47 with dissolve
                mc "Haha, I guess you're not wrong."

                scene e4s23-tr_54 with dissolve
                menu:
                    "Do it":
                        $ e4s23_tracy_lewd = True
                        $ tracy_trust += 1
                        scene e4s23-tr_47 with dissolve
                        mc "Can't say no to that though!"

                        stop music fadeout 1.0
                        scene e4s23-tr_49 with dissolve
                        tr "Haha, alright!"

                        call e4s23_tracy_lewd from _call_e4s23_tracy_lewd

                    "Not tonight":
                        $ tracy_trust += 2
                        $ tracy_intimacy += 1
                        scene e4s23-tr_48 with dissolve
                        mc "Not tonight though, let's just sit here."
                        mc "I'm sure it will help."

                        scene e4s23-tr_55 with dissolve
                        mc "You don't need to offer me that, you know."

                        scene e4s23-tr_56 with dissolve
                        tr "I know..."

                        scene e4s23-tr_57 with dissolve
                        tr "Just feels like the one thing I can do right."

                        call e4s23_sitting from _call_e4s23_sitting
                        pause

                        scene e4s23-tr_58 with dissolve
                        tr "Hey, [mc]."
                        tr "Do you believe people can change?"

                        scene e4s23-tr_55 with dissolve
                        mc "Change? In what context?"

                        scene e4s23-tr_56 with dissolve
                        tr "I don't know, like in relationships."

                        show e4s23_sitting_talking1
                        show e4s23_sitting_2 behind e4s23_sitting_talking1
                        with dissolve
                        tr "Like, change for a person."
                        tr "Finding someone so good that they change you, or you change for the sake of keeping them."

                        scene e4s23-tr_55 with dissolve
                        hide e4s23_sitting_talking1
                        hide e4s23_sitting_2
                        mc "You know, I've been thinking a lot about change lately."
                        mc "Not just for someone else, but for myself."

                        call e4s23_sitting from _call_e4s23_sitting_1
                        menu:
                            "Believe in change":
                                $ e4s23_tracy_change = 0
                                mc "Yeah, I believe that special person can truly change you."
                                mc "I also believe in choosing to change for that person."
                                mc "Of course, you shouldn't change things that make you."
                                mc "Rather, toxic parts, like getting upset over no reason or gaslighting."
                                mc "Nobody is born perfect, but we don't have to be."
                                mc "I think that can only drag you down, the pursuit of perfection."

                                scene e4s23-tr_59 with dissolve
                                tr "I want to believe that too."

                                scene e4s23-tr_65 with dissolve
                                tr "I think people don't really change."

                                scene e4s23-tr_56 with dissolve
                                tr "I mean, they kind of always change, everyone is in constant changing."

                                show e4s23_sitting_talking1
                                show e4s23_sitting_2 behind e4s23_sitting_talking1
                                with dissolve
                                tr "From their style, to their tastes, their personality, all at some point get changed."

                            "Unsure":
                                $ e4s23_tracy_change = 1
                                scene e4s23-tr_55 with dissolve
                                mc "I-"
                                mc "I'm not really sure..."

                                call e4s23_sitting from _call_e4s23_sitting_2
                                mc "I think people can change, but... maybe not always in the way we want."
                                mc "Sometimes it's hard to tell if it's real change or just temporary."

                                scene e4s23-tr_56 with dissolve
                                tr "Yeah... it's confusing, huh?"

                                scene e4s23-tr_57 with dissolve
                                tr "I mean, people change all the time throughout their lives."

                                show e4s23_sitting_talking1
                                show e4s23_sitting_2 behind e4s23_sitting_talking1
                                with dissolve
                                tr "Their style, their tastes, their personality, all at some point get changed."

                            "Don't believe in change":
                                $ e4s23_tracy_change = 2
                                mc "I don't really believe it."
                                mc "I think people can want to change, and maybe they even try..."
                                mc "But deep down, they often fall back into old patterns."
                                mc "And that can hurt the people around them."
                                mc "I think they get better at hiding whatever they're trying to change."
                                mc "Very few people actually take the time to reflect or try to fix themselves."
                                mc "And even then I don't think it's a guarantee."
                                mc "It probably happens so rarely that it doesn't matter, the vast majority will never change."
                                mc "They can keep lying to themselves, or to change temporarily to fit a criteria."
                                mc "But deep down they're still the same person with the same unresolved traits that will probably get passed down."
                                mc "Maybe we just need to accept that we're all broken in our own ways."
                                mc "But is that really okay?"

                                scene e4s23-tr_66 with dissolve
                                tr "That sounds a bit depressing to be honest."
                                tr "But... you're not wrong."

                                scene e4s23-tr_57 with dissolve
                                tr "I think people change all the time throughout their lives."

                                show e4s23_sitting_talking1
                                show e4s23_sitting_2 behind e4s23_sitting_talking1
                                with dissolve
                                tr "Their style, their tastes, their personality, all at some point get changed."

                        tr "But, on a deeper level, unresolved stuff kind of stays the same."
                        tr "That's why you might hear the same person going through the same break ups blaming the same people."

                        scene e4s23-tr_58 with dissolve
                        hide e4s23_sitting_talking1
                        hide e4s23_sitting_2
                        tr "I guess, it's like a pattern, you know?"
                        tr "Something they subconsciously look for in their next partner."

                        scene e4s23-tr_55 with dissolve
                        mc "It's a bit weird to hear your opinion on subjects like these."
                        mc "I've always seen you as this lively party girl, I didn't think you'd go that deep in talks."

                        scene e4s23-tr_56 with dissolve
                        tr "You know... I don't usually talk like this."

                        scene e4s23-tr_57 with dissolve
                        tr "Most people don't really care what's under the surface."

                        scene e4s23-tr_59 with dissolve
                        tr "But you're just... sitting here."
                        tr "Not asking for anything. Not judging."

                        scene e4s23-tr_65 with dissolve
                        tr "Kinda makes it easier to breathe, you know?"

                        scene e4s23_sitting_1 with dissolve
                        mc "Yeah, I get it."
                        mc "It's honestly really nice for me too."

                        scene e4s23-tr_42 with dissolve
                        pause
    jump e4s24
return

label e4s23_tracy_lewd:
    play music blues_of_t
    scene e4s23-tr_50 with dissolve
    tr "Lay there, let me show you something."

    scene e4s23-tr_51 with dissolve
    mc "Free food and pleasure? You're spoiling me."

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e4s23-tr_52 with dissolve
            tr "Haha, stop being so corny!"
            tr "Just enjoy the moment."

            # Titjob
            scene e4s23-tr_titjob1 with dissolve
            mc "Damn... that's hot!"

            scene e4s23-tr_titjob2 with dissolve
            pause

            scene e4s23-tr_titjob3 with dissolve
            mc "It feels so good."
            mc "Ah..."

            scene e4s23-tr_52 with dissolve
            tr "I'm glad you're enjoying yourself."

            scene e4s23-tr_titjob1 with dissolve
            mc "After a full day, this is exactly what I needed."

            scene e4s23-tr_52 with dissolve
            tr "Haha, busy day, huh?"

            scene e4s23-tr_titjob1 with dissolve
            mc "You have no idea."

            scene e4s23-tr_68 with dissolve
            tr "Then I better speed up the pace a little."

            scene e4s23-tr_titjob4 with dissolve
            mc "Ah... shit!"

            scene e4s23-tr_titjob5 with dissolve
            mc "You're not planning to make me cum, are you?"

            scene e4s23-tr_67 with dissolve
            tr "What if I am?"

            scene e4s23-tr_titjob4 with dissolve
            mc "Well, I thought we'd do more tonight."

            scene e4s23-tr_titjob6 with dissolve
            tr "Didn't you say you were tired?"

            scene e4s23-tr_titjob4 with dissolve
            mc "Haha, I never said I'm 'tired'."

            scene e4s23-tr_titjob5 with dissolve
            mc "Just said I had a long day."

            scene e4s23-tr_titjob6 with dissolve
            tr "I'm up for it if you are!"

            scene e4s23-tr_titjob4 with dissolve
            mc "Great!"

            scene e4s23-tr_71 with dissolve
            pause

            scene e4s23-tr_69 with dissolve
            tr "Ah..."

            scene e4s23-tr_assgrab2 with dissolve
            mc "You're so hot, [tr]."

            scene e4s23-tr_assgrab1 with dissolve
            tr "Your hand there... it's making me so horny."
            mc "Is it now?"

            scene e4s23-tr_71 with dissolve
            pause

            scene e4s23-tr_72 with dissolve
            pause

            scene e4s23-tr_69 with dissolve
            tr "Ahh..."

            scene e4s23-tr_assgrab2 with dissolve
            mc "It seems like you're also enjoying yourself."

            scene e4s23-tr_70 with dissolve
            tr "It was supposed to be for you."

            scene e4s23-tr_assgrab1 with dissolve
            mc "Then let's make it for you, too!"

            scene e4s23-tr_73 with dissolve
            tr "And how do you plan to do that?"

            scene e4s23-tr_titjob1 with dissolve
            mc "Just come here."

            scene e4s23-tr_75 with dissolve
            pause

            scene e4s23-tr_74 with dissolve
            tr "Oh... damn!"

            scene e4s23-tr_76 with dissolve
            mc "Relax and let me do the trick."

            scene e4s23-tr_80 with dissolve
            pause

            # Cowgirl
            scene e4s23-tr_cowgirl1 with dissolve
            tr "Ah..."

            scene e4s23-tr_cowgirl2 with dissolve
            pause

            scene e4s23-tr_cowgirl3 with dissolve
            tr "Fuck... that feels so good."

            scene e4s23-tr_76 with dissolve
            mc "Shit!"
            mc "Your pussy's really wet."

            scene e4s23-tr_77 with dissolve
            tr "I told you the ass grab made me horny."

            scene e4s23-tr_76 with dissolve
            mc "I thought you were just being playful."

            scene e4s23-tr_77 with dissolve
            tr "A little bit of both."

            scene e4s23-tr_cowgirl1 with dissolve
            mc "Oh, fuck!"

            scene e4s23-tr_cowgirl4 with dissolve
            tr "Fuuuck!"

            scene e4s23-tr_79 with dissolve
            tr "You're going in so deep."

            scene e4s23-tr_76 with dissolve
            mc "You tell me, it's sucking me right in."

            scene e4s23-tr_cowgirl5 with dissolve
            tr "Ah, shit!"

            scene e4s23-tr_79 with dissolve
            tr "Fuck... this position hits perfectly."
            tr "Ahhh!"

            scene e4s23-tr_cowgirl4 with dissolve
            mc "Fuck... I won't last long with your moans."

            scene e4s23-tr_77 with dissolve
            tr "Do they turn you on?"

            scene e4s23-tr_cowgirl4 with dissolve
            mc "Of course they do."
            mc "Uh!"

            scene e4s23-tr_77 with dissolve
            tr "You know... ah! Your moans are not so bad either."

            scene e4s23-tr_76 with dissolve
            mc "Haha, thanks?"

            scene e4s23-tr_77 with dissolve
            tr "I mean it."
            tr "Here, let me take over."

            scene e4s23-tr_81 with dissolve
            mc "Damn, this is a hot sight!"

            scene e4s23-tr_82 with dissolve
            pause

            # Reverse Cowgirl
            scene e4s23-tr_reverse_cowgirl1 with dissolve
            mc "Fuck!"

            scene e4s23-tr_reverse_cowgirl2 with dissolve
            mc "Yeah [tr], keep going."

            scene e4s23-tr_83 with dissolve
            tr "Your dick feels so good inside me."

            scene e4s23-tr_reverse_cowgirl1 with dissolve
            tr "Ahh, damn."

            scene e4s23-tr_reverse_cowgirl3 with dissolve
            mc "Uh- you're killing me!"

            scene e4s23-tr_83 with dissolve
            tr "What a fun way to die, huh?"

            scene e4s23-tr_reverse_cowgirl4 with dissolve
            mc "Oh, yeah!"

            scene e4s23-tr_reverse_cowgirl5 with dissolve
            pause

            scene e4s23-tr_reverse_cowgirl3 with dissolve
            tr "Ah... [mc]!"
            tr "You are so hard."

            # Doggy
            scene e4s23-tr_doggy1 with dissolve
            pause

            scene e4s23-tr_doggy3 with dissolve
            tr "Ah, yeah! Keep fucking me [mc]."
            tr "I love how your dick feels."

            scene e4s23-tr_doggy2 with dissolve
            pause

            scene e4s23-tr_doggy3 with dissolve
            mc "Aren't you, ah- worried your roommate will be back?"
            tr "Haha, ah!"
            tr "Not tonight."

            scene e4s23-tr_84 with dissolve
            tr "We couldn't have done it otherwise."

            scene e4s23-tr_doggy4 with dissolve
            tr "Ahh!!"

            scene e4s23-tr_doggy5 with dissolve
            mc "My place would have been perfectly fine."
            tr "Don't you also have a roomie?"
            mc "I could have just asked him to come back later."

            scene e4s23-tr_84 with dissolve
            tr "And he'd just listen like that?"

            scene e4s23-tr_doggy4 with dissolve
            mc "I don't know, never tried it before."
            tr "Next time that's what we'll do!"

            scene e4s23-tr_doggy5 with dissolve
            mc "Fuck!"
            tr "Ahh!"
        else:
            if persistent.type_nsfw == False:
                scene e4s23-tr_52_cen with dissolve
                tr "Haha, stop being so corny!"
                tr "Just enjoy the moment."

                # Titjob
                scene e4s23-tr_titjob1_cen with dissolve
                mc "Damn... that's hot!"

                scene e4s23-tr_titjob2_cen with dissolve
                pause

                scene e4s23-tr_titjob3_cen with dissolve
                mc "It feels so good."
                mc "Ah..."

                scene e4s23-tr_52_cen with dissolve
                tr "I'm glad you're enjoying yourself."

                scene e4s23-tr_titjob1_cen with dissolve
                mc "After a full day, this is exactly what I needed."

                scene e4s23-tr_52_cen with dissolve
                tr "Haha, busy day, huh?"

                scene e4s23-tr_titjob1_cen with dissolve
                mc "You have no idea."

                scene e4s23-tr_68_cen with dissolve
                tr "Then I better speed up the pace a little."

                scene e4s23-tr_titjob4_cen with dissolve
                mc "Ah... shit!"

                scene e4s23-tr_titjob5_cen with dissolve
                mc "You're not planning to make me cum, are you?"

                scene e4s23-tr_67_cen with dissolve
                tr "What if I am?"

                scene e4s23-tr_titjob4_cen with dissolve
                mc "Well, I thought we'd do more tonight."

                scene e4s23-tr_titjob6_cen with dissolve
                tr "Didn't you say you were tired?"

                scene e4s23-tr_titjob4_cen with dissolve
                mc "Haha, I never said I'm 'tired'."

                scene e4s23-tr_titjob5_cen with dissolve
                mc "Just said I had a long day."

                scene e4s23-tr_titjob6_cen with dissolve
                tr "I'm up for it if you are!"

                scene e4s23-tr_titjob4_cen with dissolve
                mc "Great!"

                scene e4s23-tr_71_cen with dissolve
                pause

                scene e4s23-tr_69_cen with dissolve
                tr "Ah..."

                scene e4s23-tr_assgrab2_cen with dissolve
                mc "You're so hot, [tr]."

                scene e4s23-tr_assgrab1_cen with dissolve
                tr "Your hand there... it's making me so horny."
                mc "Is it now?"

                scene e4s23-tr_71_cen with dissolve
                pause

                scene e4s23-tr_72_cen with dissolve
                pause

                scene e4s23-tr_69_cen with dissolve
                tr "Ahh..."

                scene e4s23-tr_assgrab2_cen with dissolve
                mc "It seems like you're also enjoying yourself."

                scene e4s23-tr_70_cen with dissolve
                tr "It was supposed to be for you."

                scene e4s23-tr_assgrab1_cen with dissolve
                mc "Then let's make it for you, too!"

                scene e4s23-tr_73_cen with dissolve
                tr "And how do you plan to do that?"

                scene e4s23-tr_titjob1_cen with dissolve
                mc "Just come here."

                scene e4s23-tr_75_cen with dissolve
                pause

                scene e4s23-tr_74 with dissolve
                tr "Oh... damn!"

                scene e4s23-tr_76 with dissolve
                mc "Relax and let me do the trick."

                scene e4s23-tr_80_cen with dissolve
                pause

                # Cowgirl
                scene e4s23-tr_cowgirl1_cen with dissolve
                tr "Ah..."

                scene e4s23-tr_cowgirl2_cen with dissolve
                pause

                scene e4s23-tr_cowgirl3_cen with dissolve
                tr "Fuck... that feels so good."

                scene e4s23-tr_76 with dissolve
                mc "Shit!"
                mc "Your pussy's really wet."

                scene e4s23-tr_77_cen with dissolve
                tr "I told you the ass grab made me horny."

                scene e4s23-tr_76 with dissolve
                mc "I thought you were just being playful."

                scene e4s23-tr_77_cen with dissolve
                tr "A little bit of both."

                scene e4s23-tr_cowgirl1_cen with dissolve
                mc "Oh, fuck!"

                scene e4s23-tr_cowgirl4_cen with dissolve
                tr "Fuuuck!"

                scene e4s23-tr_79_cen with dissolve
                tr "You're going in so deep."

                scene e4s23-tr_76 with dissolve
                mc "You tell me, it's sucking me right in."

                scene e4s23-tr_cowgirl5_cen with dissolve
                tr "Ah, shit!"

                scene e4s23-tr_79_cen with dissolve
                tr "Fuck... this position hits perfectly."
                tr "Ahhh!"

                scene e4s23-tr_cowgirl4_cen with dissolve
                mc "Fuck... I won't last long with your moans."

                scene e4s23-tr_77_cen with dissolve
                tr "Do they turn you on?"

                scene e4s23-tr_cowgirl4_cen with dissolve
                mc "Of course they do."
                mc "Uh!"

                scene e4s23-tr_77_cen with dissolve
                tr "You know... ah! Your moans are not so bad either."

                scene e4s23-tr_76 with dissolve
                mc "Haha, thanks?"

                scene e4s23-tr_77_cen with dissolve
                tr "I mean it."
                tr "Here, let me take over."

                scene e4s23-tr_81_cen with dissolve
                mc "Damn, this is a hot sight!"

                scene e4s23-tr_82_cen with dissolve
                pause

                # Reverse Cowgirl
                scene e4s23-tr_reverse_cowgirl1_cen with dissolve
                mc "Fuck!"

                scene e4s23-tr_reverse_cowgirl2_cen with dissolve
                mc "Yeah [tr], keep going."

                scene e4s23-tr_83 with dissolve
                tr "Your dick feels so good inside me."

                scene e4s23-tr_reverse_cowgirl1_cen with dissolve
                tr "Ahh, damn."

                scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                mc "Uh- you're killing me!"

                scene e4s23-tr_83 with dissolve
                tr "What a fun way to die, huh?"

                scene e4s23-tr_reverse_cowgirl4_cen with dissolve
                mc "Oh, yeah!"

                scene e4s23-tr_reverse_cowgirl5_cen with dissolve
                pause

                scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                tr "Ah... [mc]!"
                tr "You are so hard."

                # Doggy
                scene e4s23-tr_doggy1_cen with dissolve
                pause

                scene e4s23-tr_doggy3_cen with dissolve
                tr "Ah, yeah! Keep fucking me [mc]."
                tr "I love how your dick feels."

                scene e4s23-tr_doggy2_cen with dissolve
                pause

                scene e4s23-tr_doggy3_cen with dissolve
                mc "Aren't you, ah- worried your roommate will be back?"
                tr "Haha, ah!"
                tr "Not tonight."

                scene e4s23-tr_84 with dissolve
                tr "We couldn't have done it otherwise."

                scene e4s23-tr_doggy4_cen with dissolve
                tr "Ahh!!"

                scene e4s23-tr_doggy5_cen with dissolve
                mc "My place would have been perfectly fine."
                tr "Don't you also have a roomie?"
                mc "I could have just asked him to come back later."

                scene e4s23-tr_84 with dissolve
                tr "And he'd just listen like that?"

                scene e4s23-tr_doggy4_cen with dissolve
                mc "I don't know, never tried it before."
                tr "Next time that's what we'll do!"

                scene e4s23-tr_doggy5_cen with dissolve
                mc "Fuck!"
                tr "Ahh!"

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Titjob":
                    $ config.rollback_enabled = True

                    $ e4s23_tracy_position = 0

                    if e4s23_tracy_cowgirl == 1:
                        $ e4s23_tracy_cowgirl = 2

                    if persistent.disable_nsfw == True:
                        scene e4s23-tr_titjob1 with dissolve
                        mc "Damn... that's hot!"

                        scene e4s23-tr_titjob2 with dissolve
                        mc "It feels so good."

                        scene e4s23-tr_titjob3 with dissolve
                        mc "Ah..."

                        scene e4s23-tr_titjob1 with dissolve
                        mc "After a full day, this is exactly what I needed."

                        scene e4s23-tr_52 with dissolve
                        tr "Haha, busy day, huh?"

                        scene e4s23-tr_titjob1 with dissolve
                        mc "You have no idea."

                        scene e4s23-tr_titjob4 with dissolve
                        mc "Ah... shit!"

                        scene e4s23-tr_titjob5 with dissolve
                        mc "You're not planning to make me cum, are you?"

                        scene e4s23-tr_67 with dissolve
                        tr "What if I am?"

                        scene e4s23-tr_titjob4 with dissolve
                        pause

                        scene e4s23-tr_titjob6 with dissolve
                        pause

                        scene e4s23-tr_assgrab2 with dissolve
                        mc "You're so hot, [tr]."

                        scene e4s23-tr_assgrab1 with dissolve
                        tr "Your hand there... it's making me so horny."
                        mc "Is it now?"

                        scene e4s23-tr_assgrab2 with dissolve
                        mc "It seems like you're also enjoying yourself."
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s23-tr_titjob1_cen with dissolve
                            mc "Damn... that's hot!"

                            scene e4s23-tr_titjob2_cen with dissolve
                            mc "It feels so good."

                            scene e4s23-tr_titjob3_cen with dissolve
                            mc "Ah..."

                            scene e4s23-tr_titjob1_cen with dissolve
                            mc "After a full day, this is exactly what I needed."

                            scene e4s23-tr_52_cen with dissolve
                            tr "Haha, busy day, huh?"

                            scene e4s23-tr_titjob1_cen with dissolve
                            mc "You have no idea."

                            scene e4s23-tr_titjob4_cen with dissolve
                            mc "Ah... shit!"

                            scene e4s23-tr_titjob5_cen with dissolve
                            mc "You're not planning to make me cum, are you?"

                            scene e4s23-tr_67_cen with dissolve
                            tr "What if I am?"

                            scene e4s23-tr_titjob4_cen with dissolve
                            pause

                            scene e4s23-tr_titjob6_cen with dissolve
                            pause

                            scene e4s23-tr_assgrab2_cen with dissolve
                            mc "You're so hot, [tr]."

                            scene e4s23-tr_assgrab1_cen with dissolve
                            tr "Your hand there... it's making me so horny."
                            mc "Is it now?"

                            scene e4s23-tr_assgrab2_cen with dissolve
                            mc "It seems like you're also enjoying yourself."
                "Cowgirl":
                    $ config.rollback_enabled = True

                    $ e4s23_tracy_position = 1

                    if e4s23_tracy_cowgirl == 1:
                        if persistent.disable_nsfw == True:
                            scene e4s23-tr_cowgirl4 with dissolve
                            tr "Oh, fuck!"
                            tr "Ahhh...[mc]!"

                            scene e4s23-tr_86 with dissolve
                            mc "Holy shit, you're tightening up."

                            scene e4s23-tr_78 with dissolve
                            tr "Fuuuuck!"

                            scene e4s23-tr_squirt1 with dissolve
                            pause(6.0)

                            scene e4s23-tr_85 with dissolve
                            tr "Oh my God..."

                            scene e4s23-tr_88 with dissolve
                            tr "Let me just... ah- catch my breath."

                            scene e4s23-tr_89 with dissolve
                            tr "Fuck..."

                            scene e4s23-tr_87 with dissolve
                            mc "Damn, did you just squirt?"

                            scene e4s23-tr_91 with dissolve
                            mc "I know you said this position hits, but I didn't think it was enough to make you squirt."

                            scene e4s23-tr_90 with dissolve
                            tr "Then you really... underestimate yourself."

                            scene e4s23-tr_87 with dissolve
                            mc "You ready to keep going?"

                            scene e4s23-tr_89 with dissolve
                            tr "..."

                            scene e4s23-tr_93 with dissolve
                            tr "Yeah, let's go."
                        else:
                            if persistent.type_nsfw == False:
                                scene e4s23-tr_cowgirl4_cen with dissolve
                                tr "Oh, fuck!"
                                tr "Ahhh... [mc]!"

                                scene e4s23-tr_86 with dissolve
                                mc "Holy shit, you're tightening up."

                                scene e4s23-tr_78_cen with dissolve
                                tr "Fuuuuck!"

                                scene e4s23-tr_squirt1_cen with dissolve
                                pause(6.0)

                                scene e4s23-tr_85_cen with dissolve
                                tr "Oh my God..."

                                scene e4s23-tr_88_cen with dissolve
                                tr "Let me just... ah- catch my breath."

                                scene e4s23-tr_89 with dissolve
                                tr "Fuck..."

                                scene e4s23-tr_87_cen with dissolve
                                mc "Damn, did you just squirt?"

                                scene e4s23-tr_91_cen with dissolve
                                mc "I know you said this position hits, but I didn't think it was enough to make you squirt."

                                scene e4s23-tr_90_cen with dissolve
                                tr "Then you really... underestimate yourself."

                                scene e4s23-tr_87_cen with dissolve
                                mc "You ready to keep going?"

                                scene e4s23-tr_89 with dissolve
                                tr "..."

                                scene e4s23-tr_93_cen with dissolve
                                tr "Yeah, let's go."

                    if e4s23_tracy_cowgirl == 2:
                        if persistent.disable_nsfw == True:
                            scene e4s23-tr_cowgirl1 with dissolve
                            tr "Ah..."

                            scene e4s23-tr_cowgirl2 with dissolve
                            pause

                            scene e4s23-tr_cowgirl3 with dissolve
                            tr "Fuck... that feels so good."

                            scene e4s23-tr_76 with dissolve
                            mc "Shit!"
                            mc "Your pussy's really wet."

                            scene e4s23-tr_77 with dissolve
                            tr "I told you the ass grab made me horny."

                            scene e4s23-tr_cowgirl1 with dissolve
                            mc "Oh, fuck!"

                            scene e4s23-tr_cowgirl4 with dissolve
                            tr "Fuuuck!"

                            scene e4s23-tr_79 with dissolve
                            tr "You're going in so deep."

                            scene e4s23-tr_cowgirl5 with dissolve
                            tr "Ah, shit!"
                            tr "Fuck... this position hits perfectly."
                            tr "Ahhh!"

                            scene e4s23-tr_cowgirl4 with dissolve
                            mc "Fuck... I won't last long with your moans."

                            scene e4s23-tr_77 with dissolve
                            tr "Do they turn you on?"

                            scene e4s23-tr_cowgirl4 with dissolve
                            mc "Of course they do."
                            mc "Uh!"
                        else:
                            if persistent.type_nsfw == False:
                                scene e4s23-tr_cowgirl1_cen with dissolve
                                tr "Ah..."

                                scene e4s23-tr_cowgirl2_cen with dissolve
                                pause

                                scene e4s23-tr_cowgirl3_cen with dissolve
                                tr "Fuck... that feels so good."

                                scene e4s23-tr_76 with dissolve
                                mc "Shit!"
                                mc "Your pussy's really wet."

                                scene e4s23-tr_77_cen with dissolve
                                tr "I told you the ass grab made me horny."

                                scene e4s23-tr_cowgirl1_cen with dissolve
                                mc "Oh, fuck!"

                                scene e4s23-tr_cowgirl4_cen with dissolve
                                tr "Fuuuck!"

                                scene e4s23-tr_79_cen with dissolve
                                tr "You're going in so deep."

                                scene e4s23-tr_cowgirl5_cen with dissolve
                                tr "Ah, shit!"
                                tr "Fuck... this position hits perfectly."
                                tr "Ahhh!"

                                scene e4s23-tr_cowgirl4_cen with dissolve
                                mc "Fuck... I won't last long with your moans."

                                scene e4s23-tr_77_cen with dissolve
                                tr "Do they turn you on?"

                                scene e4s23-tr_cowgirl4_cen with dissolve
                                mc "Of course they do."
                                mc "Uh!"

                    if e4s23_tracy_cowgirl == 0:
                        $ e4s23_tracy_cowgirl = 1

                        if persistent.disable_nsfw == True:
                            scene e4s23-tr_cowgirl1 with dissolve
                            tr "Ah..."

                            scene e4s23-tr_cowgirl2 with dissolve
                            pause

                            scene e4s23-tr_cowgirl3 with dissolve
                            tr "Fuck... that feels so good."

                            scene e4s23-tr_76 with dissolve
                            mc "Your pussy's really wet."

                            scene e4s23-tr_cowgirl1 with dissolve
                            mc "Oh, fuck!"

                            scene e4s23-tr_cowgirl4 with dissolve
                            tr "Fuuuck!"

                            scene e4s23-tr_79 with dissolve
                            tr "You're going in so deep."

                            scene e4s23-tr_cowgirl5 with dissolve
                            mc "You tell me, it's sucking me right in."

                            scene e4s23-tr_cowgirl4 with dissolve
                            tr "Fuck... this position hits perfectly."
                            tr "Ahhh!"
                            tr "I think I'm getting really close now."
                        else:
                            if persistent.type_nsfw == False:
                                scene e4s23-tr_cowgirl1_cen with dissolve
                                tr "Ah..."

                                scene e4s23-tr_cowgirl2_cen with dissolve
                                pause

                                scene e4s23-tr_cowgirl3_cen with dissolve
                                tr "Fuck... that feels so good."

                                scene e4s23-tr_76 with dissolve
                                mc "Your pussy's really wet."

                                scene e4s23-tr_cowgirl1_cen with dissolve
                                mc "Oh, fuck!"

                                scene e4s23-tr_cowgirl4_cen with dissolve
                                tr "Fuuuck!"

                                scene e4s23-tr_79_cen with dissolve
                                tr "You're going in so deep."

                                scene e4s23-tr_cowgirl5_cen with dissolve
                                mc "You tell me, it's sucking me right in."

                                scene e4s23-tr_cowgirl4_cen with dissolve
                                tr "Fuck... this position hits perfectly."
                                tr "Ahhh!"
                                tr "I think I'm getting really close now."
                "Reverse Cowgirl":
                    $ config.rollback_enabled = True

                    $ e4s23_tracy_position = 2

                    if e4s23_tracy_cowgirl == 1:
                        $ e4s23_tracy_cowgirl = 2

                    if persistent.disable_nsfw == True:
                        scene e4s23-tr_reverse_cowgirl1 with dissolve
                        mc "Fuck!"

                        scene e4s23-tr_reverse_cowgirl2 with dissolve
                        mc "Yeah [tr], keep going."

                        scene e4s23-tr_83 with dissolve
                        tr "Your dick feels so good inside me."

                        scene e4s23-tr_reverse_cowgirl1 with dissolve
                        tr "Ahh, damn."

                        scene e4s23-tr_reverse_cowgirl3 with dissolve
                        mc "Uh- you're killing me!"

                        scene e4s23-tr_83 with dissolve
                        tr "What a fun way to die, huh?"

                        scene e4s23-tr_reverse_cowgirl4 with dissolve
                        mc "Oh, yeah!"

                        scene e4s23-tr_reverse_cowgirl5 with dissolve
                        pause

                        scene e4s23-tr_reverse_cowgirl3 with dissolve
                        tr "Ah... [mc]!"
                        tr "You are so hard."
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s23-tr_reverse_cowgirl1_cen with dissolve
                            mc "Fuck!"

                            scene e4s23-tr_reverse_cowgirl2_cen with dissolve
                            mc "Yeah [tr], keep going."

                            scene e4s23-tr_83 with dissolve
                            tr "Your dick feels so good inside me."

                            scene e4s23-tr_reverse_cowgirl1_cen with dissolve
                            tr "Ahh, damn."

                            scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                            mc "Uh- you're killing me!"

                            scene e4s23-tr_83 with dissolve
                            tr "What a fun way to die, huh?"

                            scene e4s23-tr_reverse_cowgirl4_cen with dissolve
                            mc "Oh, yeah!"

                            scene e4s23-tr_reverse_cowgirl5_cen with dissolve
                            pause

                            scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                            tr "Ah... [mc]!"
                            tr "You are so hard."
                "Doggy":
                    $ config.rollback_enabled = True

                    $ e4s23_tracy_position = 3

                    if e4s23_tracy_cowgirl == 1:
                        $ e4s23_tracy_cowgirl = 2

                    if persistent.disable_nsfw == True:
                        scene e4s23-tr_doggy1 with dissolve
                        pause

                        scene e4s23-tr_doggy3 with dissolve
                        tr "Ah, yeah! Keep fucking me [mc]."
                        tr "I love how your dick feels."

                        scene e4s23-tr_doggy2 with dissolve
                        pause

                        scene e4s23-tr_doggy3 with dissolve
                        mc "Aren't you, ah- worried your roommate will be back?"
                        tr "Haha, ah!"
                        tr "Not tonight."

                        scene e4s23-tr_doggy4 with dissolve
                        tr "Ahh!!"

                        scene e4s23-tr_doggy5 with dissolve
                        pause

                        scene e4s23-tr_doggy4 with dissolve
                        pause

                        scene e4s23-tr_doggy5 with dissolve
                        mc "Fuck!"
                        tr "Ahh!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s23-tr_doggy1_cen with dissolve
                            pause

                            scene e4s23-tr_doggy3_cen with dissolve
                            tr "Ah, yeah! Keep fucking me [mc]."
                            tr "I love how your dick feels."

                            scene e4s23-tr_doggy2_cen with dissolve
                            pause

                            scene e4s23-tr_doggy3_cen with dissolve
                            mc "Aren't you, ah- worried your roommate will be back?"
                            tr "Haha, ah!"
                            tr "Not tonight."

                            scene e4s23-tr_doggy4_cen with dissolve
                            tr "Ahh!!"

                            scene e4s23-tr_doggy5_cen with dissolve
                            pause

                            scene e4s23-tr_doggy4_cen with dissolve
                            pause

                            scene e4s23-tr_doggy5_cen with dissolve
                            mc "Fuck!"
                            tr "Ahh!"
                "Cum":
                    $ config.rollback_enabled = True

                    if e4s23_tracy_position == 0:
                        scene e4s23-tr_assgrab1 with dissolve
                    if e4s23_tracy_position == 1:
                        scene e4s23-tr_cowgirl5 with dissolve
                    if e4s23_tracy_position == 2:
                        scene e4s23-tr_reverse_cowgirl4 with dissolve
                    if e4s23_tracy_position == 3:
                        scene e4s23-tr_doggy5 with dissolve

                    mc "Oh, I'm getting close."
                    tr "Ah... where do you wanna do it?"

                    menu:
                        "Inside":
                            mc "Ahh, I'll do it inside."

                            if e4s23_tracy_position == 0:
                                $ e4s23_tracy_position = random.randint(1, 3)

                            if persistent.disable_nsfw == True:
                                if e4s23_tracy_position == 1:
                                    scene e4s23-tr_cowgirl4 with dissolve
                                    tr "Do it [mc]!"
                                    tr "I wanna feel your hot cum inside me."

                                    scene e4s23-tr_cowgirl5 with dissolve
                                    mc "Fuuck! Here it comes."

                                    scene e4s23-tr_cowgirl4 with dissolve
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_96 with dissolve
                                    mc "Ahh... holy shit [tr]."
                                    mc "Fuck, you drained me."
                                    tr "You came so much!"

                                    scene e4s23-tr_76 with dissolve
                                    mc "Maybe you believe me now about my day."
                                if e4s23_tracy_position == 2:
                                    scene e4s23-tr_reverse_cowgirl3 with dissolve
                                    tr "Do it [mc]!"
                                    tr "I wanna feel your hot cum inside me."

                                    scene e4s23-tr_reverse_cowgirl4 with dissolve
                                    mc "Fuuck! Here it comes."

                                    scene e4s23-tr_reverse_cowgirl3 with dissolve
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_100 with dissolve
                                    mc "Ahh... holy shit [tr]."
                                    mc "Fuck, you drained me."
                                    tr "You came so much!"

                                    scene e4s23-tr_101 with dissolve
                                    mc "Maybe you believe me now about my day."
                                if e4s23_tracy_position == 3:
                                    scene e4s23-tr_doggy4 with dissolve
                                    tr "Do it [mc]!"
                                    tr "I wanna feel your hot cum inside me."

                                    scene e4s23-tr_doggy5 with dissolve
                                    mc "Fuuck! Here it comes."

                                    scene e4s23-tr_doggy4 with dissolve
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_97 with dissolve
                                    mc "Ahh... holy shit [tr]."
                                    mc "Fuck, you drained me."

                                    scene e4s23-tr_98 with dissolve
                                    tr "You came so much!"

                                    scene e4s23-tr_99 with dissolve
                                    mc "Maybe you believe me now about my day."
                            else:
                                if persistent.type_nsfw == False:
                                    if e4s23_tracy_position == 1:
                                        scene e4s23-tr_cowgirl4_cen with dissolve
                                        tr "Do it [mc]!"
                                        tr "I wanna feel your hot cum inside me."

                                        scene e4s23-tr_cowgirl5_cen with dissolve
                                        mc "Fuuck! Here it comes."

                                        scene e4s23-tr_cowgirl4_cen with dissolve
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        scene e4s23-tr_96_cen with dissolve
                                        mc "Ahh... holy shit [tr]."
                                        mc "Fuck, you drained me."
                                        tr "You came so much!"

                                        scene e4s23-tr_76 with dissolve
                                        mc "Maybe you believe me now about my day."
                                    if e4s23_tracy_position == 2:
                                        scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                                        tr "Do it [mc]!"
                                        tr "I wanna feel your hot cum inside me."

                                        scene e4s23-tr_reverse_cowgirl4_cen with dissolve
                                        mc "Fuuck! Here it comes."

                                        scene e4s23-tr_reverse_cowgirl3_cen with dissolve
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        scene e4s23-tr_100_cen with dissolve
                                        mc "Ahh... holy shit [tr]."
                                        mc "Fuck, you drained me."
                                        tr "You came so much!"

                                        scene e4s23-tr_101_cen with dissolve
                                        mc "Maybe you believe me now about my day."
                                    if e4s23_tracy_position == 3:
                                        scene e4s23-tr_doggy4_cen with dissolve
                                        tr "Do it [mc]!"
                                        tr "I wanna feel your hot cum inside me."

                                        scene e4s23-tr_doggy5_cen with dissolve
                                        mc "Fuuck! Here it comes."

                                        scene e4s23-tr_doggy4_cen with dissolve
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        show white with Dissolve(0.25)
                                        show white with vpunch
                                        hide white with Dissolve(0.25)
                                        scene e4s23-tr_97_cen with dissolve
                                        mc "Ahh... holy shit [tr]."
                                        mc "Fuck, you drained me."

                                        scene e4s23-tr_98_cen with dissolve
                                        tr "You came so much!"

                                        scene e4s23-tr_99_cen with dissolve
                                        mc "Maybe you believe me now about my day."
                        "On her tits":
                            mc "On your tits."
                            if persistent.disable_nsfw == True:
                                scene e4s23-tr_titjob5 with dissolve
                                mc "Oh [tr], keep going!"
                                mc "I'm so close."

                                scene e4s23-tr_titjob6 with dissolve
                                tr "Ahh, you like these big tits, don't you?"
                                tr "Cum on them [mc], cover them in your cum."

                                scene e4s23-tr_titjob5 with dissolve
                                mc "Fuuck! Here it comes."

                                show white with Dissolve(0.25)
                                scene e4s23-tr_113 with dissolve
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                scene e4s23-tr_94 with dissolve
                                mc "Ahh... holy shit [tr]."
                                mc "Fuck, you drained me."

                                scene e4s23-tr_95 with dissolve
                                tr "You came so much!"

                                scene e4s23-tr_94 with dissolve
                                mc "Maybe you believe me now about my day."
                            else:
                                if persistent.type_nsfw == False:
                                    scene e4s23-tr_titjob5_cen with dissolve
                                    mc "Oh [tr], keep going!"
                                    mc "I'm so close."

                                    scene e4s23-tr_titjob6_cen with dissolve
                                    tr "Ahh, you like these big tits, don't you?"
                                    tr "Cum on them [mc], cover them in your cum."

                                    scene e4s23-tr_titjob5_cen with dissolve
                                    mc "Fuuck! Here it comes."

                                    show white with Dissolve(0.25)
                                    scene e4s23-tr_113_cen with dissolve
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_94_cen with dissolve
                                    mc "Ahh... holy shit [tr]."
                                    mc "Fuck, you drained me."

                                    scene e4s23-tr_95_cen with dissolve
                                    tr "You came so much!"

                                    scene e4s23-tr_94_cen with dissolve
                                    mc "Maybe you believe me now about my day."
                        "On her face":
                            mc "Get on your knees."
                            if persistent.disable_nsfw == True:
                                scene e4s23-tr_cum1 with dissolve
                                mc "Oh... I'm really close!"

                                scene e4s23-tr_cum2 with dissolve
                                tr "Cover my face in your cum, [mc]."

                                scene e4s23-tr_cum1 with dissolve
                                mc "Fuuck! Here it comes."

                                show white with Dissolve(0.25)
                                scene e4s23-tr_108 with dissolve
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                scene e4s23-tr_109 with dissolve
                                mc "Ahh... holy shit [tr]."
                                mc "Fuck, you drained me."

                                scene e4s23-tr_110 with dissolve
                                tr "You came so much!"

                                scene e4s23-tr_112 with dissolve
                                mc "Maybe you believe me now about my day."
                            else:
                                if persistent.type_nsfw == False:
                                    scene e4s23-tr_cum1 with dissolve
                                    mc "Oh... I'm really close!"

                                    scene e4s23-tr_cum2 with dissolve
                                    tr "Cover my face in your cum, [mc]."

                                    scene e4s23-tr_cum1 with dissolve
                                    mc "Fuuck! Here it comes."

                                    show white with Dissolve(0.25)
                                    scene e4s23-tr_108 with dissolve
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_109_cen with dissolve
                                    mc "Ahh... holy shit [tr]."
                                    mc "Fuck, you drained me."

                                    scene e4s23-tr_105_cen with dissolve
                                    tr "You came so much!"

                                    scene e4s23-tr_107_cen with dissolve
                                    mc "Maybe you believe me now about my day."

                        "In her mouth":
                            mc "Get on your knees."
                            if persistent.disable_nsfw == True:
                                scene e4s23-tr_cum1 with dissolve
                                mc "Oh... I'm really close!"

                                scene e4s23-tr_cum2 with dissolve
                                tr "Cum in my mouth, [mc]."

                                scene e4s23-tr_cum3 with dissolve
                                mc "Fuuck! Here it comes."
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                show white with Dissolve(0.25)
                                show white with vpunch
                                hide white with Dissolve(0.25)
                                scene e4s23-tr_102 with dissolve
                                pause

                                scene e4s23-tr_103 with dissolve
                                mc "Ahh... holy shit [tr]."

                                scene e4s23-tr_104 with dissolve
                                mc "Fuck, you drained me."

                                scene e4s23-tr_105 with dissolve
                                tr "You came so much!"

                                scene e4s23-tr_107 with dissolve
                                mc "Maybe you believe me now about my day."
                            else:
                                if persistent.type_nsfw == False:
                                    scene e4s23-tr_cum1_cen with dissolve
                                    mc "Oh... I'm really close!"

                                    scene e4s23-tr_cum2_cen with dissolve
                                    tr "Cum in my mouth, [mc]."

                                    scene e4s23-tr_cum3_cen with dissolve
                                    mc "Fuuck! Here it comes."
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    show white with Dissolve(0.25)
                                    show white with vpunch
                                    hide white with Dissolve(0.25)
                                    scene e4s23-tr_102_cen with dissolve
                                    pause

                                    scene e4s23-tr_103_cen with dissolve
                                    mc "Ahh... holy shit [tr]."

                                    scene e4s23-tr_104_cen with dissolve
                                    mc "Fuck, you drained me."

                                    scene e4s23-tr_105_cen with dissolve
                                    tr "You came so much!"

                                    scene e4s23-tr_107_cen with dissolve
                                    mc "Maybe you believe me now about my day."

                    scene e4s23-tr_89 with dissolve
                    pause

                    if persistent.disable_nsfw == True:
                        scene e4s23-tr_93 with dissolve
                        tr "You know..."
                        tr "I never doubted you, though."

                        scene e4s23-tr_114 with dissolve
                        mc "Huh?"

                        scene e4s23-tr_93 with dissolve
                        tr "About your day."
                        tr "I'm glad you got to relax a bit."

                        scene e4s23-tr_114 with dissolve
                        mc "Thanks [tr] for tonight!"

                        scene e4s23-tr_115 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s23-tr_93_cen with dissolve
                            tr "You know..."
                            tr "I never doubted you, though."

                            scene e4s23-tr_114_cen with dissolve
                            mc "Huh?"

                            scene e4s23-tr_93_cen with dissolve
                            tr "About your day."
                            tr "I'm glad you got to relax a bit."

                            scene e4s23-tr_114_cen with dissolve
                            mc "Thanks [tr] for tonight!"

                            scene e4s23-tr_115_cen with dissolve
                            pause

                    $ GameRunning = False

    $ renpy.end_replay()
return

label e4s23_francesca_lewd:
    if _in_replay:
        play music satfes

    scene e4s23-fr_52 with dissolve
    pause

    scene e4s23-fr_61 with dissolve
    pause

    scene e4s23-fr_kiss1 with dissolve
    pause

    scene e4s23-fr_62 with dissolve
    pause

    scene e4s23-fr_kiss2 with dissolve
    pause

    scene e4s23-fr_63 with dissolve
    mc "You are so pretty [fr]."
    mc "Your kisses are the sweetest."

    scene e4s23-fr_kiss1 with dissolve
    pause

    scene e4s23-fr_kiss2 with dissolve
    pause

    scene e4s23-fr_64 with dissolve
    mc "*Her smell is driving me crazy.*"

    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        if persistent.disable_nsfw == True:
            scene e4s23-fr_65 with dissolve
            pause

            scene e4s23-fr_66 with dissolve
            pause

            scene e4s23-fr_67 with dissolve
            mc "Uh... hi?"

            scene e4s23-fr_68 with dissolve
            fr "Your thing... is poking me."

            scene e4s23-fr_69 with dissolve
            mc "Oh, I'm sorry."
            mc "I didn't-"

            scene e4s23-fr_rubbing1 with dissolve
            pause

            scene e4s23-fr_70 with dissolve
            fr "Ah... it feels so good..."

            scene e4s23-fr_rubbing2 with dissolve
            mc "*Ah shit, I'm so hard right now.*"
            mc "*Her rubbing on my dick is so hot.*"

            scene e4s23-fr_71 with dissolve
            fr "Is this okay?"
            mc "Yeah [fr], it's very good."
            mc "Keep going."

            scene e4s23-fr_rubbing3 with dissolve
            pause

            scene e4s23-fr_72 with dissolve
            fr "Does it feel as good as it does for me?"

            scene e4s23-fr_rubbing4 with dissolve
            mc "It does."

            scene e4s23-fr_73 with dissolve
            pause

            scene e4s23-fr_rubbing5 with dissolve
            fr "Oh..."

            scene e4s23-fr_72 with dissolve
            fr "I'm so wet right now."

            scene e4s23-fr_rubbing6 with dissolve
            mc "You're driving me crazy."
            mc "Ahh..."

            scene e4s23-fr_73 with dissolve
            mc "Can I see your boobs?"

            scene e4s23-fr_68 with dissolve
            fr "Of course!"

            scene e4s23-fr_74 with dissolve
            pause

            scene e4s23-fr_75 with dissolve
            pause

            scene e4s23-fr_76 with dissolve
            pause

            scene e4s23-fr_77 with dissolve
            mc "Damn, those are absolutely perfect!"

            scene e4s23-fr_78 with dissolve
            mc "You have no idea what you're doing to me right now."

            scene e4s23-fr_79 with dissolve
            fr "I didn't know you liked them that much!"

            scene e4s23-fr_78 with dissolve
            mc "I'd die for them."

            scene e4s23-fr_81 with dissolve
            pause

            scene e4s23-fr_80 with dissolve
            fr "Do you like it when I touch myself?"

            scene e4s23-fr_rubbing7 with dissolve
            pause

            scene e4s23-fr_rubbing8 with dissolve
            mc "Yes [fr], keep going."

            scene e4s23-fr_rubbing9 with dissolve
            fr "Ohh..."
            fr "*It's even better than when I do it alone.*"

            scene e4s23-fr_rubbing8 with dissolve
            fr "*His... thing is hitting all the right places.*"
            fr "*I wonder how it would feel inside.*"

            scene e4s23-fr_rubbing7 with dissolve
            fr "Oh... [mc]!"
            fr "I... I-"

            scene e4s23-fr_82 with dissolve
            mc "Are you okay?"

            scene e4s23-fr_83 with dissolve
            fr "Shiiit!"

            scene e4s23-fr_rubbing9 with dissolve
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            show white with Dissolve(0.25)
            show white with vpunch
            hide white with Dissolve(0.25)
            scene e4s23-fr_84 with dissolve
            mc "*Holy shit, she just came!*"

            scene e4s23-fr_85 with dissolve
            pause

            scene e4s23-fr_86 with dissolve
            pause

            scene e4s23-fr_87 with dissolve
            fr "Oh, I'm so sorry..."

            scene e4s23-fr_88 with dissolve
            fr "I got carried away a bit, haha!"

            scene e4s23-fr_89 with dissolve
            mc "I enjoyed it a lot."

            if not _in_replay:
                if e4s23_francesca_lewd == 2:
                    $ persistent.e4s23_francesca_lewd = 2
                    mc "You must have enjoyed it as well."

                    scene e4s23-fr_90 with dissolve
                    fr "Yeah... I did..."

                    scene e4s23-fr_89 with dissolve
                    mc "Well, there goes our break, haha!"
                    mc "Looks like we filled the time with something."

                    scene e4s23-fr_88 with dissolve
                    fr "Haha!"
                    fr "I'm not going to lie, I feel a lot more relaxed now."

                    scene e4s23-fr_89 with dissolve
                    mc "I'm glad!"

                    scene e4s23-fr_92 with dissolve
                    fr "So... uh, would you like me to prepare you the couch?"

                    scene e4s23-fr_89 with dissolve
                    mc "Yeah, sure."
                    mc "I could use some sleep after all this studying."

                    scene e4s23-fr_86 with dissolve
                    mc "*Damn it... looks like I didn't get more, huh?*"
                if e4s23_francesca_lewd == 1:
                    $ persistent.e4s23_francesca_lewd = 1
                    scene e4s23-fr_90 with dissolve
                    fr "You are so hard..."

                    scene e4s23-fr_91 with dissolve
                    mc "Well... it's kind of your fault."

                    scene e4s23-fr_92 with dissolve
                    fr "How about I fix it, then?"

                    scene e4s23-fr_93 with dissolve
                    pause

                    scene e4s23-fr_94 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "Oh, [fr]..."

                    scene e4s23-fr_95 with dissolve
                    fr "Is this right?"

                    scene e4s23-fr_96 with dissolve
                    fr "I hope I'm not too rough with it."

                    scene e4s23-fr_handjob2 with dissolve
                    mc "It's perfect, keep doing it."

                    scene e4s23-fr_handjob3 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "Ah!"

                    scene e4s23-fr_96 with dissolve
                    fr "Damn..."
                    fr "You are... rock hard!"

                    scene e4s23-fr_95 with dissolve
                    fr "Sorry, I can't help it."

                    scene e4s23-fr_handjob2 with dissolve
                    mc "It's fine, do it all you want."
                    mc "I like it."

                    scene e4s23-fr_handjob3 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "You can pick up the pace if you want."
                    mc "It doesn't hurt me."

                    scene e4s23-fr_95 with dissolve
                    fr "Oh... okay."

                    scene e4s23-fr_handjob4 with dissolve
                    mc "Ah... just like that."
                    mc "It feels so good."

                    scene e4s23-fr_handjob5 with dissolve
                    mc "You're doing a great job [fr]."

                    scene e4s23-fr_95 with dissolve
                    fr "My hand is getting a bit tired, haha!"

                    scene e4s23-fr_96 with dissolve
                    fr "I'll... definitely have to do this more."

                    scene e4s23-fr_handjob4 with dissolve
                    mc "Don't worry, I'm getting pretty close."
                    mc "If you keep up this pace..."
                    mc "I'll..."

                    scene e4s23-fr_handjob5 with dissolve
                    mc "Ahh... I'm going to cum [fr]!"

                    scene e4s23-fr_handjob4 with dissolve
                    fr "O-okay!"
                    mc "Ahh!"
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    scene e4s23-fr_97 with dissolve
                    mc "Oh my God, that felt amazing!"

                    scene e4s23-fr_98 with dissolve
                    fr "I'm really glad you enjoyed it."
                    fr "I don't think I could have done it for much longer, haha!"

                    scene e4s23-fr_99 with dissolve
                    pause

                    scene e4s23-fr_100 with dissolve
                    mc "I'm wasted."
                    mc "This was a much needed release after all that work we did."

                    scene e4s23-fr_101 with dissolve
                    fr "Yeah... I'm getting so sleepy."

                    scene e4s23-fr_102 with dissolve
                    mc "Would you like me to go... or?"

                    scene e4s23-fr_103 with dissolve
                    fr "No... I-"

                    scene e4s23-fr_104 with dissolve
                    fr "I'd like you to sleep with me tonight."
                    fr "If that's okay with you, of course."

                    scene e4s23-fr_105 with dissolve
                    mc "I'd love to."

                    scene e4s23-fr_106 with dissolve
                    pause

                    scene e4s23-fr_107 with dissolve
                    pause

                    scene e4s23-fr_108 with dissolve
                    pause
            else:
                if persistent.e4s23_francesca_lewd == 2:
                    mc "You must have enjoyed it as well."

                    scene e4s23-fr_90 with dissolve
                    fr "Yeah... I did..."

                    scene e4s23-fr_89 with dissolve
                    mc "Well, there goes our break, haha!"
                    mc "Looks like we filled the time with something."

                    scene e4s23-fr_88 with dissolve
                    fr "Haha!"
                    fr "I'm not going to lie, I feel a lot more relaxed now."

                    scene e4s23-fr_89 with dissolve
                    mc "I'm glad!"

                    scene e4s23-fr_92 with dissolve
                    fr "So... uh, would you like me to prepare you the couch?"

                    scene e4s23-fr_89 with dissolve
                    mc "Yeah, sure."
                    mc "I could use some sleep after all this studying."

                    scene e4s23-fr_86 with dissolve
                    mc "*Damn it... looks like I didn't get more, huh?*"
                if persistent.e4s23_francesca_lewd == 1:
                    scene e4s23-fr_90 with dissolve
                    fr "You are so hard..."

                    scene e4s23-fr_91 with dissolve
                    mc "Well... it's kind of your fault."

                    scene e4s23-fr_92 with dissolve
                    fr "How about I fix it, then?"

                    scene e4s23-fr_93 with dissolve
                    pause

                    scene e4s23-fr_94 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "Oh, [fr]..."

                    scene e4s23-fr_95 with dissolve
                    fr "Is this right?"

                    scene e4s23-fr_96 with dissolve
                    fr "I hope I'm not too rough with it."

                    scene e4s23-fr_handjob2 with dissolve
                    mc "It's perfect, keep doing it."

                    scene e4s23-fr_handjob3 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "Ah!"

                    scene e4s23-fr_96 with dissolve
                    fr "Damn..."
                    fr "You are... rock hard!"

                    scene e4s23-fr_95 with dissolve
                    fr "Sorry, I can't help it."

                    scene e4s23-fr_handjob2 with dissolve
                    mc "It's fine, do it all you want."
                    mc "I like it."

                    scene e4s23-fr_handjob3 with dissolve
                    pause

                    scene e4s23-fr_handjob1 with dissolve
                    mc "You can pick up the pace if you want."
                    mc "It doesn't hurt me."

                    scene e4s23-fr_95 with dissolve
                    fr "Oh... okay."

                    scene e4s23-fr_handjob4 with dissolve
                    mc "Ah... just like that."
                    mc "It feels so good."

                    scene e4s23-fr_handjob5 with dissolve
                    mc "You're doing a great job [fr]."

                    scene e4s23-fr_95 with dissolve
                    fr "My hand is getting a bit tired, haha!"

                    scene e4s23-fr_96 with dissolve
                    fr "I'll... definitely have to do this more."

                    scene e4s23-fr_handjob4 with dissolve
                    mc "Don't worry, I'm getting pretty close."
                    mc "If you keep up this pace..."
                    mc "I'll..."

                    scene e4s23-fr_handjob5 with dissolve
                    mc "Ahh... I'm going to cum [fr]!"

                    scene e4s23-fr_handjob4 with dissolve
                    fr "O-okay!"
                    mc "Ahh!"
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    show white with Dissolve(0.25)
                    show white with vpunch
                    hide white with Dissolve(0.25)
                    scene e4s23-fr_97 with dissolve
                    mc "Oh my God, that felt amazing!"

                    scene e4s23-fr_98 with dissolve
                    fr "I'm really glad you enjoyed it."
                    fr "I don't think I could have done it for much longer, haha!"

                    scene e4s23-fr_99 with dissolve
                    pause

                    scene e4s23-fr_100 with dissolve
                    mc "I'm wasted."
                    mc "This was a much needed release after all that work we did."

                    scene e4s23-fr_101 with dissolve
                    fr "Yeah... I'm getting so sleepy."

                    scene e4s23-fr_102 with dissolve
                    mc "Would you like me to go... or?"

                    scene e4s23-fr_103 with dissolve
                    fr "No... I-"

                    scene e4s23-fr_104 with dissolve
                    fr "I'd like you to sleep with me tonight."
                    fr "If that's okay with you, of course."

                    scene e4s23-fr_105 with dissolve
                    mc "I'd love to."

                    scene e4s23-fr_106 with dissolve
                    pause

                    scene e4s23-fr_107 with dissolve
                    pause

                    scene e4s23-fr_108 with dissolve
                    pause
        else:
            if persistent.type_nsfw == False:
                scene e4s23-fr_65 with dissolve
                pause

                scene e4s23-fr_66 with dissolve
                pause

                scene e4s23-fr_67 with dissolve
                mc "Uh... hi?"

                scene e4s23-fr_68 with dissolve
                fr "Your thing... is poking me."

                scene e4s23-fr_69 with dissolve
                mc "Oh, I'm sorry."
                mc "I didn't-"

                scene e4s23-fr_rubbing1 with dissolve
                pause

                scene e4s23-fr_70 with dissolve
                fr "Ah... it feels so good..."

                scene e4s23-fr_rubbing2 with dissolve
                mc "*Ah shit, I'm so hard right now.*"
                mc "*Her rubbing on my dick is so hot.*"

                scene e4s23-fr_71 with dissolve
                fr "Is this okay?"
                mc "Yeah [fr], it's very good."
                mc "Keep going."

                scene e4s23-fr_rubbing3 with dissolve
                pause

                scene e4s23-fr_72 with dissolve
                fr "Does it feel as good as it does for me?"

                scene e4s23-fr_rubbing4 with dissolve
                mc "It does."

                scene e4s23-fr_73 with dissolve
                pause

                scene e4s23-fr_rubbing5 with dissolve
                fr "Oh..."

                scene e4s23-fr_72 with dissolve
                fr "I'm so wet right now."

                scene e4s23-fr_rubbing6 with dissolve
                mc "You're driving me crazy."
                mc "Ahh..."

                scene e4s23-fr_73 with dissolve
                mc "Can I see your boobs?"

                scene e4s23-fr_68 with dissolve
                fr "Of course!"

                scene e4s23-fr_74 with dissolve
                pause

                scene e4s23-fr_75_cen with dissolve
                pause

                scene e4s23-fr_76_cen with dissolve
                pause

                scene e4s23-fr_77_cen with dissolve
                mc "Damn, those are absolutely perfect!"

                scene e4s23-fr_78_cen with dissolve
                mc "You have no idea what you're doing to me right now."

                scene e4s23-fr_79_cen with dissolve
                fr "I didn't know you liked them that much!"

                scene e4s23-fr_78_cen with dissolve
                mc "I'd die for them."

                scene e4s23-fr_81_cen with dissolve
                pause

                scene e4s23-fr_80_cen with dissolve
                fr "Do you like it when I touch myself?"

                scene e4s23-fr_rubbing7_cen with dissolve
                pause

                scene e4s23-fr_rubbing8_cen with dissolve
                mc "Yes [fr], keep going."

                scene e4s23-fr_rubbing9 with dissolve
                fr "Ohh..."
                fr "*It's even better than when I do it alone.*"

                scene e4s23-fr_rubbing8_cen with dissolve
                fr "*His... thing is hitting all the right places.*"
                fr "*I wonder how it would feel inside.*"

                scene e4s23-fr_rubbing7_cen with dissolve
                fr "Oh... [mc]!"
                fr "I... I-"

                scene e4s23-fr_82_cen with dissolve
                mc "Are you okay?"

                scene e4s23-fr_83_cen with dissolve
                fr "Shiiit!"

                scene e4s23-fr_rubbing9 with dissolve
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                show white with Dissolve(0.25)
                show white with vpunch
                hide white with Dissolve(0.25)
                scene e4s23-fr_84_cen with dissolve
                mc "*Holy shit, she just came!*"

                scene e4s23-fr_85_cen with dissolve
                pause

                scene e4s23-fr_86_cen with dissolve
                pause

                scene e4s23-fr_87 with dissolve
                fr "Oh, I'm so sorry..."

                scene e4s23-fr_88 with dissolve
                fr "I got carried away a bit, haha!"

                scene e4s23-fr_89 with dissolve
                mc "I enjoyed it a lot."

                if not _in_replay:
                    if e4s23_francesca_lewd == 2:
                        mc "You must have enjoyed it as well."

                        scene e4s23-fr_90 with dissolve
                        fr "Yeah... I did..."

                        scene e4s23-fr_89 with dissolve
                        mc "Well, there goes our break, haha!"
                        mc "Looks like we filled the time with something."

                        scene e4s23-fr_88 with dissolve
                        fr "Haha!"
                        fr "I'm not going to lie, I feel a lot more relaxed now."

                        scene e4s23-fr_89 with dissolve
                        mc "I'm glad!"

                        scene e4s23-fr_92 with dissolve
                        fr "So... uh, would you like me to prepare you the couch?"

                        scene e4s23-fr_89 with dissolve
                        mc "Yeah, sure."
                        mc "I could use some sleep after all this studying."

                        scene e4s23-fr_86_cen with dissolve
                        mc "*Damn it... looks like I didn't get more, huh?*"
                    if e4s23_francesca_lewd == 1:
                        scene e4s23-fr_90 with dissolve
                        fr "You are so hard..."

                        scene e4s23-fr_91 with dissolve
                        mc "Well... it's kind of your fault."

                        scene e4s23-fr_92 with dissolve
                        fr "How about I fix it, then?"

                        scene e4s23-fr_93_cen with dissolve
                        pause

                        scene e4s23-fr_94_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "Oh, [fr]..."

                        scene e4s23-fr_95_cen with dissolve
                        fr "Is this right?"

                        scene e4s23-fr_96_cen with dissolve
                        fr "I hope I'm not too rough with it."

                        scene e4s23-fr_handjob2_cen with dissolve
                        mc "It's perfect, keep doing it."

                        scene e4s23-fr_handjob3_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "Ah!"

                        scene e4s23-fr_96_cen with dissolve
                        fr "Damn..."
                        fr "You are... rock hard!"

                        scene e4s23-fr_95_cen with dissolve
                        fr "Sorry, I can't help it."

                        scene e4s23-fr_handjob2_cen with dissolve
                        mc "It's fine, do it all you want."
                        mc "I like it."

                        scene e4s23-fr_handjob3_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "You can pick up the pace if you want."
                        mc "It doesn't hurt me."

                        scene e4s23-fr_95_cen with dissolve
                        fr "Oh... okay."

                        scene e4s23-fr_handjob4_cen with dissolve
                        mc "Ah... just like that."
                        mc "It feels so good."

                        scene e4s23-fr_handjob5_cen with dissolve
                        mc "You're doing a great job [fr]."

                        scene e4s23-fr_95_cen with dissolve
                        fr "My hand is getting a bit tired, haha!"

                        scene e4s23-fr_96_cen with dissolve
                        fr "I'll... definitely have to do this more."

                        scene e4s23-fr_handjob4_cen with dissolve
                        mc "Don't worry, I'm getting pretty close."
                        mc "If you keep up this pace..."
                        mc "I'll..."

                        scene e4s23-fr_handjob5_cen with dissolve
                        mc "Ahh... I'm going to cum [fr]!"

                        scene e4s23-fr_handjob4_cen with dissolve
                        fr "O-okay!"
                        mc "Ahh!"
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        scene e4s23-fr_97_cen with dissolve
                        mc "Oh my God, that felt amazing!"

                        scene e4s23-fr_98_cen with dissolve
                        fr "I'm really glad you enjoyed it."
                        fr "I don't think I could have done it for much longer, haha!"

                        scene e4s23-fr_99_cen with dissolve
                        pause

                        scene e4s23-fr_100 with dissolve
                        mc "I'm wasted."
                        mc "This was a much needed release after all that work we did."

                        scene e4s23-fr_101 with dissolve
                        fr "Yeah... I'm getting so sleepy."

                        scene e4s23-fr_102 with dissolve
                        mc "Would you like me to go... or?"

                        scene e4s23-fr_103 with dissolve
                        fr "No... I-"

                        scene e4s23-fr_104 with dissolve
                        fr "I'd like you to sleep with me tonight."
                        fr "If that's okay with you, of course."

                        scene e4s23-fr_105 with dissolve
                        mc "I'd love to."

                        scene e4s23-fr_106 with dissolve
                        pause

                        scene e4s23-fr_107_cen with dissolve
                        pause

                        scene e4s23-fr_108 with dissolve
                        pause
                else:
                    if persistent.e4s23_francesca_lewd == 2:
                        mc "You must have enjoyed it as well."

                        scene e4s23-fr_90 with dissolve
                        fr "Yeah... I did..."

                        scene e4s23-fr_89 with dissolve
                        mc "Well, there goes our break, haha!"
                        mc "Looks like we filled the time with something."

                        scene e4s23-fr_88 with dissolve
                        fr "Haha!"
                        fr "I'm not going to lie, I feel a lot more relaxed now."

                        scene e4s23-fr_89 with dissolve
                        mc "I'm glad!"

                        scene e4s23-fr_92 with dissolve
                        fr "So... uh, would you like me to prepare you the couch?"

                        scene e4s23-fr_89 with dissolve
                        mc "Yeah, sure."
                        mc "I could use some sleep after all this studying."

                        scene e4s23-fr_86_cen with dissolve
                        mc "*Damn it... looks like I didn't get more, huh?*"
                    if persistent.e4s23_francesca_lewd == 1:
                        scene e4s23-fr_90 with dissolve
                        fr "You are so hard..."

                        scene e4s23-fr_91 with dissolve
                        mc "Well... it's kind of your fault."

                        scene e4s23-fr_92 with dissolve
                        fr "How about I fix it, then?"

                        scene e4s23-fr_93_cen with dissolve
                        pause

                        scene e4s23-fr_94_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "Oh, [fr]..."

                        scene e4s23-fr_95_cen with dissolve
                        fr "Is this right?"

                        scene e4s23-fr_96_cen with dissolve
                        fr "I hope I'm not too rough with it."

                        scene e4s23-fr_handjob2_cen with dissolve
                        mc "It's perfect, keep doing it."

                        scene e4s23-fr_handjob3_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "Ah!"

                        scene e4s23-fr_96_cen with dissolve
                        fr "Damn..."
                        fr "You are... rock hard!"

                        scene e4s23-fr_95_cen with dissolve
                        fr "Sorry, I can't help it."

                        scene e4s23-fr_handjob2_cen with dissolve
                        mc "It's fine, do it all you want."
                        mc "I like it."

                        scene e4s23-fr_handjob3_cen with dissolve
                        pause

                        scene e4s23-fr_handjob1_cen with dissolve
                        mc "You can pick up the pace if you want."
                        mc "It doesn't hurt me."

                        scene e4s23-fr_95_cen with dissolve
                        fr "Oh... okay."

                        scene e4s23-fr_handjob4_cen with dissolve
                        mc "Ah... just like that."
                        mc "It feels so good."

                        scene e4s23-fr_handjob5_cen with dissolve
                        mc "You're doing a great job [fr]."

                        scene e4s23-fr_95_cen with dissolve
                        fr "My hand is getting a bit tired, haha!"

                        scene e4s23-fr_96_cen with dissolve
                        fr "I'll... definitely have to do this more."

                        scene e4s23-fr_handjob4_cen with dissolve
                        mc "Don't worry, I'm getting pretty close."
                        mc "If you keep up this pace..."
                        mc "I'll..."

                        scene e4s23-fr_handjob5_cen with dissolve
                        mc "Ahh... I'm going to cum [fr]!"

                        scene e4s23-fr_handjob4_cen with dissolve
                        fr "O-okay!"
                        mc "Ahh!"
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        scene e4s23-fr_97_cen with dissolve
                        mc "Oh my God, that felt amazing!"

                        scene e4s23-fr_98_cen with dissolve
                        fr "I'm really glad you enjoyed it."
                        fr "I don't think I could have done it for much longer, haha!"

                        scene e4s23-fr_99_cen with dissolve
                        pause

                        scene e4s23-fr_100 with dissolve
                        mc "I'm wasted."
                        mc "This was a much needed release after all that work we did."

                        scene e4s23-fr_101 with dissolve
                        fr "Yeah... I'm getting so sleepy."

                        scene e4s23-fr_102 with dissolve
                        mc "Would you like me to go... or?"

                        scene e4s23-fr_103 with dissolve
                        fr "No... I-"

                        scene e4s23-fr_104 with dissolve
                        fr "I'd like you to sleep with me tonight."
                        fr "If that's okay with you, of course."

                        scene e4s23-fr_105 with dissolve
                        mc "I'd love to."

                        scene e4s23-fr_106 with dissolve
                        pause

                        scene e4s23-fr_107_cen with dissolve
                        pause

                        scene e4s23-fr_108 with dissolve
                        pause
    $ renpy.end_replay()
return
