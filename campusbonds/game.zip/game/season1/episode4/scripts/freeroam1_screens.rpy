
# Freeroam 1 screens ###########################################################

# jon ##########################################################################
screen e4f1_jon():

    $ renpy.random.shuffle(e4f1_tracks)
    modal True

    add "e4f1-01"

    # Clickables
    if e4f1_jon == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/jon_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/jon_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f1_jon_clickable")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f1_jon_clickable")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/trsd_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/trsd_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_trsd")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_trsd")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/bridget_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/bridget_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_bridget")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_bridget")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/lyla_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/lyla_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_lyla")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_lyla")

    # Collectibles
    if persistent.mixed_gallery_15_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/jon_desk/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_15_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_15_unlocked", True), SetVariable("persistent.e4f1_collected_p", persistent.e4f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed15", True), Function(update_mixed_list)]

# tracy sadie ##################################################################
screen e4f1_trsd():

    $ renpy.random.shuffle(e4f1_tracks)
    modal True

    if e4f1_sadie == False:
        add "e4f1-02"
    else:
        add "e4f1-02_1"

    # Clickables
    if e4f1_tracy == False and e4f1_sadie == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/tracy_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/tracy_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f1_tracy_clickable")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f1_tracy_clickable")

    if e4f1_sadie == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/sadie_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/sadie_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f1_sadie_clickable")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f1_sadie_clickable")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/bridget_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/bridget_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_bridget")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_bridget")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/lyla_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/lyla_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_lyla")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_lyla")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/jon_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/jon_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_jon")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_jon")

    # Collectibles
    if persistent.cl_gallery_12_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/trsd_desk/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.cl_gallery_12_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.cl_gallery_12_unlocked", True), SetVariable("persistent.e4f1_collected_p", persistent.e4f1_collected_p+1), Show("render_notify"), SetVariable("persistent.cleo12", True), Function(update_cleo_list)]

# bridget ######################################################################
screen e4f1_bridget():

    $ renpy.random.shuffle(e4f1_tracks)
    modal True

    add "e4f1-03"

    # Clickables
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/bridget_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/bridget_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_bridget_clickable")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_bridget_clickable")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/corner_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/corner_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_corner")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_corner")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/jon_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/jon_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_jon")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_jon")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/trsd_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/trsd_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_trsd")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_trsd")

    # Collectibles
    if persistent.mixed_gallery_16_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/magazine_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/bridget_desk/magazine_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_16_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_16_unlocked", True), SetVariable("persistent.e4f1_collected_p", persistent.e4f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed16", True), Function(update_mixed_list)]

# corner ##########################################################################
screen e4f1_corner():

    $ renpy.random.shuffle(e4f1_tracks)
    modal True

    add "e4f1-04"

    # Clickables

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/corner/lyla_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/corner/lyla_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_lyla")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_lyla")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/corner/bridget_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/corner/bridget_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_bridget")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_bridget")

    # Collectibles
    if persistent.fr_gallery_11_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/corner/magazine1_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/corner/magazine1_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.fr_gallery_11_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.fr_gallery_11_unlocked", True), SetVariable("persistent.e4f1_collected_p", persistent.e4f1_collected_p+1), Show("render_notify"), SetVariable("persistent.francesca11", True), Function(update_francesca_list)]

    if persistent.mixed_gallery_17_unlocked == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/corner/magazine2_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/corner/magazine2_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "persistent.mixed_gallery_17_unlocked")
            unhovered SetVariable("screen_tooltip", "")
            action [SetVariable("persistent.mixed_gallery_17_unlocked", True), SetVariable("persistent.e4f1_collected_p", persistent.e4f1_collected_p+1), Show("render_notify"), SetVariable("persistent.mixed17", True), Function(update_mixed_list)]

# lyla ##########################################################################
screen e4f1_lyla():

    $ renpy.random.shuffle(e4f1_tracks)
    modal True

    add "e4f1-05"

    # Clickables
    if e4f1_lyla == False:
        imagebutton:
            idle im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/lyla_idle.webp", 1920, 1080)
            hover im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/lyla_hover.webp", 1920, 1080)
            focus_mask True
            hovered SetVariable("screen_tooltip", "e4f1_lyla_clickable")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("e4f1_lyla_clickable")

    # Map
    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/jon_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/jon_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_jon")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_jon")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/trsd_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/trsd_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_trsd")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_trsd")

    imagebutton:
        idle im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/corner_idle.webp", 1920, 1080)
        hover im.Scale("season1/episode4/images/scene5/freeroam1/lyla_desk/corner_hover.webp", 1920, 1080)
        focus_mask True
        hovered SetVariable("screen_tooltip", "e4f1_corner")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("e4f1_corner")
