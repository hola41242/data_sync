
# Scene 17 - The first rehearsal ###############################################

label e4s17:
    stop music fadeout 1.0
    stop sound fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s17-01 with Dissolve(2.0)
    ev "Okay, now that everyone's here, we should start our very first rehearsal."
    ev "With the competition being just around the corner, I'd say it's a great time to start."

    scene e4s17-03 with dissolve
    mc "What do we need to do?"

    scene e4s17-02 with dissolve
    ev "I'm glad you asked."
    ev "Basically, we're gonna combine everything you've all been learning by yourself."

    scene e4s17-01 with dissolve
    ev "Everything's part of the song we're gonna play on stage."
    ev "As you're doing that, I'll keep an eye on you and guide how the entire song goes."

    scene e4s17-02 with dissolve
    ev "So... everyone's ready to get started?"

    scene e4s17-04 with dissolve
    pe "Yeah, let's do it!"

    scene e4s17-05 with dissolve
    pause

    jump e4s18
return
