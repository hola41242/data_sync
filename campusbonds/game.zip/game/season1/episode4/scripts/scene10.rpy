
# Scene 10 - Surprise Party ####################################################

label e4s10:
    if e4s9_stay == False:
        play music turn_up
        scene e4s10-01 with wipeleft
        mc "Hey [jon], I got your message..."

        scene e4s10-02 with dissolve
        mc "Huh?"
        mc "What's going on here?"

        scene e4s10-03 with dissolve
        pause

        scene e4s10-04 with dissolve
        jon "Yo, what's going on my friend?"

        scene e4s10-05 with dissolve
        mc "What's this?"

        if affinity_spectrum > 0:
            mc "A party without me?"

        scene e4s10-06 with dissolve
        jon "A surprise party!"

        scene e4s10-07 with dissolve
        jon "I wanted to make sure you wouldn't walk in here while we were prepping it."

        scene e4s10-05 with dissolve
        mc "So, you organized a surprise party for me?"

        scene e4s10-08 with dissolve
        jon "Uh... yeah, for you."

        scene e4s10-06 with dissolve
        jon "It's a party, right?"
        jon "Come on, let's have fun."

        scene e4s10-07 with dissolve
        jon "We finally convinced the strippers to join us."

        scene e4s10-05 with dissolve
        mc "The strippers?"

        if affinity_spectrum < 0:
            mc "You know I'm not into that kind of stuff."

            scene e4s10-07 with dissolve
            jon "Come on, don't worry!"
            jon "We'll find something for you to do."
        else:
            scene e4s10-07 with dissolve
            jon "Yeah bro!"

        jon "Come on, grab a drink and join us!"

        call e4f2 from _call_e4f2

        stop music fadeout 1.0
        scene black with Dissolve(2.0)
        pause(1.0)

        play music dances_and_dames
        scene e4s10-09 with Dissolve(2.0)
        pause

        scene e4s10-10 with dissolve
        unknown "What's going on?"

        scene e4s10-11 with dissolve
        mc "There's a professor on the way. If she sees you, the whole party's screwed."

        scene e4s10-13 with dissolve
        unknown "I was told this wouldn't turn into a shitshow."

        scene e4s10-10 with dissolve
        unknown "What's going on?"
        unknown "Seriously. Are all college parties this shady?"

        scene e4s10-12 with dissolve
        mc "I don't know, maybe someone tipped them off."

        scene e4s10-13 with dissolve
        unknown "This is a mess. I should've stayed home."

        scene e4s10-11 with dissolve
        mc "Hey, hey, relax. It's probably nothing."
        mc "[jon]'s handling it as we speak, just chill here a few minutes and it'll be fine."

        scene e4s10-13 with dissolve
        unknown "This ruined the whole vibe..."

        menu:
            "Get angry" if affinity_spectrum > 0:
                call introvert_affinity_check from _call_introvert_affinity_check_68
                call color_check from _call_color_check_149

                scene e4s10-15 with dissolve
                mc "Stop bitching around."
                mc "You were paid to do your job, not to whine around."

                scene e4s10-12 with dissolve
                mc "This is just a misunderstanding."

                scene e4s10-11 with dissolve
                mc "No one's throwing you under the bus. We're the ones who'll get in trouble."
                mc "Pretend it's a scene, you know? Like part of the act."

                scene e4s10-16 with dissolve
                mc "I bet you've done worse roleplay than this."

                scene e4s10-14 with dissolve
                unknown "Roleplay? Fucking roleplay?"
                unknown "I didn't get paid to do roleplay, I got paid to dance."

                scene e4s10-17 with dissolve
                mc "Then dance on this fucking dick!"

                scene e4s10-15 with dissolve
                mc "What do you want me to say?"
                mc "Dance if you wanna dance."

                scene e4s10-18 with dissolve
                pause

            "Try to calm them down":
                scene e4s10-11 with dissolve
                mc "Come on, you don't have to leave."
                mc "Try to picture this as some sort of roleplay, right?"

                scene e4s10-16 with dissolve
                mc "I bet you've done worse roleplay than this."

                scene e4s10-14 with dissolve
                unknown "Roleplay? Fucking roleplay?"
                unknown "I didn't get paid to do roleplay, I got paid to dance."

                scene e4s10-16 with dissolve
                mc "..."

        if candance_trust > 1:
            $ e4s10_comfort = True
            scene e4s10-19 with dissolve
            ca "Come on girls, it's no big deal."
            ca "Worst case scenario, their club gets closed."
            ca "We're in the clear here."
            ca "We knew what we were getting into."

            scene e4s10-20 with dissolve
            ca "I trust [mc] here, everything is going to be fine."

            scene e4s10-13 with dissolve
            unknown "Alright... alright..."

            scene e4s10-21 with dissolve
            ca "So... is everything good?"

            scene e4s10-22 with dissolve
            mc "Yeah, I hope so."
            mc "I don't know what this is all about but [jon]'s gonna take care of it."
            mc "I really doubt they'll come in here."

            scene e4s10-23 with dissolve
            ca "Didn't he say no one would bother us here?"

            scene e4s10-22 with dissolve
            mc "Yeah, I thought so too."
            mc "But I guess being on campus grounds comes with its risks."
        else:
            scene e4s10-13 with dissolve
            unknown "This is a disaster, a disaster!"
            unknown "I can't wait to get out of here."

        stop music
        scene e4s10-26 with vpunch
        play sound door_open
        pause

        scene e4s10-24 with dissolve
        ke "Yo, guys!"
        ke "We're in the clear, let's go."
    else:
        scene e4s10-25 with wipeleft
        pause

        scene e4s10-02 with dissolve
        mc "Uh... hello?"
        mc "Is this a bad time?"

        scene e4s10-27 with dissolve
        br "Not at all, didn't mean to interrupt."
        br "Just gave your friends the news."
        br "I'll be on my way now, I'll let you do your thing."

        scene e4s10-28 with dissolve
        pause

        scene e4s10-29 with dissolve
        jon "Great, you finally showed up."

        scene e4s10-31 with dissolve
        jon "Unfortunately, it's kind of too late."

        scene e4s10-30 with dissolve
        show e4s10_jon_blink1
        mc "What do you mean?"

        scene e4s10-31 with dissolve
        hide e4s10_jon_blink1
        jon "[br] here came and ruined everything."
        jon "We had a party and now it's ruined."

        scene e4s10-30 with dissolve
        show e4s10_jon_blink1
        mc "Damn... what the hell happened while I was away?"

        scene e4s10-32 with dissolve
        hide e4s10_jon_blink1
        jon "A lot honestly."

    if e4s10_comfort == False:
        play music welcome_to_zombie_coast
        scene e4s10-34 with vpunch
        unknown "Alright, I've had enough of this place, I'm out of here."

        scene e4s10-35 with dissolve
        jon "Come on girls, don't leave!"
        jon "It was just a misunderstanding."

        scene e4s10-36 with dissolve
        unknown "The misunderstanding was that you told us there would be no problems."

        scene e4s10-35 with dissolve
        jon "Yeah, for you there will be no problems."
        jon "We're the ones getting screwed if it goes to shit."

        scene e4s10-36 with dissolve
        unknown "Well, screw this, we're out of here."
        unknown "I knew it would turn up like this, I just knew it."

        stop music fadeout 1.0
        scene e4s10-37 with dissolve
        pause
    else:
        scene e4s10-38 with dissolve
        mc "Yo, you guys alright?"

        scene e4s10-39 with dissolve
        jon "Yeah, it's fine."
        jon "You girls are alright?"

        scene e4s10-40 with dissolve
        unknown "Yeah..."

        scene e4s10-41 with dissolve
        unknown "I thought you said there would be no problems!"

        scene e4s10-42 with dissolve
        jon "I know, I know... I'm sorry."
        jon "I didn't foresee this."

        scene e4s10-39 with dissolve
        jon "But don't worry, it's alright, she's gone now."
        jon "We can get back to partying, she won't bother us tonight."
        jon "You have my word!"

    if e4s9_stay == False:
        scene e4s10-43 with dissolve
    else:
        scene e4s10-30 with dissolve
        show e4s10_jon_blink1

    mc "So, what did [br] want?"

    play music odesa
    scene e4s10-31 with dissolve
    hide e4s10_jon_blink1
    jon "We're fucked, dude."
    jon "Fucked, big time."

    scene e4s10-30 with dissolve
    show e4s10_jon_blink1
    mc "Wow, slow down dude, what happened?"

    scene e4s10-32 with dissolve
    hide e4s10_jon_blink1
    jon "Okay, first things first..."

    scene e4s10-31 with dissolve
    jon "Parties? Get that out of your head, these aren't possible anymore."

    scene e4s10-32 with dissolve
    jon "At least not here, no."

    scene e4s10-31 with dissolve
    jon "Second of all, [br]'s taken over this club."

    scene e4s10-30 with dissolve
    show e4s10_jon_blink1
    mc "Wait, what?"
    mc "Isn't [sc] the president?"

    scene e4s10-31 with dissolve
    hide e4s10_jon_blink1
    jon "Yeah well, it's this stupid policy that every club needs to have a professor if they're on college grounds."

    scene e4s10-33 with dissolve
    jon "Until now our club wasn't, but guess what?"
    jon "We're fucked."

    scene e4s10-31 with dissolve
    jon "She came in tonight to tell us the news."

    scene e4s10-30 with dissolve
    show e4s10_jon_blink1
    mc "Damn... I should have probably seen that coming."

    scene e4s10-31 with dissolve
    hide e4s10_jon_blink1
    jon "What do you mean?"

    scene e4s10-30 with dissolve
    show e4s10_jon_blink1
    mc "A friend told me about this policy a while ago but I didn't make too much of it."

    scene e4s10-32 with dissolve
    hide e4s10_jon_blink1
    jon "It wouldn't have mattered anyway, I don't think there's much we can do about it."

    scene e4s10-30 with dissolve
    show e4s10_jon_blink1
    mc "So... what now?"

    if e4s10_comfort == False:
        scene e4s10-32 with dissolve
        hide e4s10_jon_blink1
        jon "Well... everyone left so I guess it's over."

        scene e4s10-31 with dissolve
        jon "We should start packing."

        scene e4s10-30 with dissolve
        show e4s10_jon_blink1
        mc "Damn..."

        scene e4s10-32 with dissolve
        hide e4s10_jon_blink1
        jon "Yeah..."
    else:
        scene e4s10-31 with dissolve
        jon "Well... I think we should make the best out of this last party."
        jon "Who knows when's the next time we'll have something like this again?"

        scene e4s10-30 with dissolve
        show e4s10_jon_blink1
        mc "Yeah... I guess you're right."

        scene e4s10-31 with dissolve
        hide e4s10_jon_blink1
        jon "So, grab a drink and have some fun!"

    jump e4s11
return
