
# Scene 27 - Unexpected guest ##################################################

label e4s27:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s27-158 with Dissolve(2.0)
    ev "Alright everyone, I guess this wraps up our today's rehearsal."
    ev "We're doing great progress."
    ev "I'll see you tomorrow for another session."

    scene e4s27-159 with dissolve
    fr "[mc], you coming?"

    scene e4s27-160 with dissolve
    mc "Nah, you go ahead."
    mc "I'll stick around for a bit to mess with the guitar."

    scene e4s27-161 with dissolve
    fr "Okay... well, if everyone's gone, make sure to lock the door, alright?"

    scene e4s27-160 with dissolve
    mc "Yeah, no problem."

    scene e4s27-162 with dissolve
    pause

    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s27-163 with Dissolve(2.0)
    pause

    scene e4s27-164 with dissolve
    pause

    play sound heart_beat
    scene e4s27-165 with dissolve
    mc "*Shit! I forgot to lock the door.*"

    scene e4s27-166 with dissolve
    pause

    scene e4s27-01 with dissolve
    pause

    scene e4s27-02 with dissolve
    pause

    play music the_darker_side
    scene e4s27-03 with dissolve
    pause

    scene e4s27-04 with dissolve
    am "So... we're locking doors now, huh?"

    if e3s19_amber_lewd == True:
        scene e4s27-15 with dissolve
        mc "How did you know?"
        mc "And what are you doing here?"
    else:
        scene e4s27-05 with dissolve
        mc "How did you know?"
        mc "And what are you doing here?"

    scene e4s27-06 with dissolve
    am "I just really love the view from here."
    am "You really have one of the best classes, you know?"

    scene e4s27-07 with dissolve
    mc "Still haven't answered my question."

    scene e4s27-08 with dissolve
    mc "You shouldn't be here."

    scene e4s27-10 with dissolve
    am "Why not?"

    scene e4s27-11 with dissolve
    am "It's not like I'm doing anything wrong."

    if e4s11_confess == True:
        scene e4s27-09 with dissolve
        show e4s27_amber_blink1
        mc "You're up to something, you're always up to something."

        scene e4s27-13 with dissolve
        hide e4s27_amber_blink1
        am "What would I be up to?"

        scene e4s27-10 with dissolve
        am "I literally just got here and not a second after you were back."

        scene e4s27-12 with dissolve
        am "Even if I wanted to, I couldn't do it in time, chill."

    if e3s19_amber_lewd == True:
        scene e4s27-14 with dissolve
        am "Come on, you already forgot what we did?"

        scene e4s27-13 with dissolve
        am "I thought we had something going on."

        scene e4s27-09 with dissolve
        show e4s27_amber_blink1
        menu:
            "Agree":
                $ e4s27_amber_lewd = True
                mc "Yeah... we did!"
                mc "And I'd like to believe we still do because I enjoyed our last time."
                mc "But it's not such a secret when you keep coming here."
                mc "People will start suspecting us."

                scene e4s27-13 with dissolve
                hide e4s27_amber_blink1
                am "So what if they do?"

                scene e4s27-12 with dissolve
                am "Why would that be a problem to you?"

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "I won't be able to come here anymore?"

                scene e4s27-22 with dissolve
                hide e4s27_amber_blink1
                am "I still don't see the problem."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "You said you wanted this to be our little secret."
                mc "Why are you acting all public now?"

                scene e4s27-13 with dissolve
                hide e4s27_amber_blink1
                am "Relax, I'm just teasing you."
                am "As much as I'd like to show the world who I'm fucking, the backlash would be a bit too much."

                scene e4s27-21 with dissolve
                am "For now, I'm going to keep you for myself."
                am "Not that I mind, haha!"

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "So, why are you here?"

                scene e4s27-14 with dissolve
                hide e4s27_amber_blink1
                am "I'm here to see you!"

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "See me?"
                mc "You could have gone any other place to see me."
                mc "Do you really think this is the right one?"

                stop music fadeout 1.0
                scene e4s27-22 with dissolve
                hide e4s27_amber_blink1
                am "It does make it more exciting, doesn't it?"

                call e4s27_lewd from _call_e4s27_lewd
            "Reject her":
                mc "That was one time and it won't happen again."
                mc "It was a mistake."

                scene e4s27-13 with dissolve
                am "Hm... I don't recall you regretting it when I swallowed your cum."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Not so loud!"
                mc "Someone might hear."

                scene e4s27-21 with dissolve
                hide e4s27_amber_blink1
                am "Oh... what now?"
                am "You hiding what we did now?"

                scene e4s27-12 with dissolve
                am "Poor little guy."

                scene e4s27-39 with dissolve
                am "Looks like you're half the man I thought you were."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Yeah, boo hoo!"
                mc "You won."
                mc "Just leave now, okay?"
                mc "And don't come back, else I'll have to tell [ev]."

                scene e4s27-40 with dissolve
                hide e4s27_amber_blink1
                am "Oh... the boy's gonna go crying to mommy?"

                scene e4s27-16 with dissolve
                am "I thought I was your mommy..."

                scene e4s27-17 with dissolve
                am "Anyway, looks like we can't have fun anymore so I'll leave you to it."

                scene e4s27-21 with dissolve
                am "Thanks for the time, baby!"

                scene e4s27-16 with dissolve
                am "It's a shame it had to end like this."

                scene e4s27-18 with dissolve
                am "Hm... maybe in another life."

                scene e4s27-12 with dissolve
                am "Just... do me a favor, alright?"
                am "Ask [fr] about what really happened."

                scene e4s27-16 with dissolve
                am "If she's even capable of telling the truth without sugarcoating it. You might be surprised, or maybe not."
                am "I don't care at this point."

                scene e4s27-19 with dissolve
                pause

                scene e4s27-20 with dissolve
                mc "*Telling the truth?*"
                mc "*What is she on about?*"
    else:
        scene e4s27-09 with dissolve
        show e4s27_amber_blink1
        mc "I don't care, I want you gone."

        scene e4s27-23 with dissolve
        hide e4s27_amber_blink1
        am "Wow... chill there lover boy."

        scene e4s27-22 with dissolve
        am "Come on, what's the rush?"
        am "Don't you want to hear what I have to say?"

        scene e4s27-09 with dissolve
        show e4s27_amber_blink1
        mc "Honestly?"
        menu:
            "Hear her":
                $ e4s27_listen = True
                mc "Alright, let's hear it."

                scene e4s27-17 with dissolve
                hide e4s27_amber_blink1
                am "Good, there's some sense in there."
                am "That's a good start."

                scene e4s27-14 with dissolve
                am "I'm gonna be honest, I didn't expect it, but here we are."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Can you get started already?"

                scene e4s27-22 with dissolve
                hide e4s27_amber_blink1
                am "What's the rush?"
                am "It's not like anyone's coming here tonight anyway."

                scene e4s27-14 with dissolve
                am "Maybe you'd want us to sit down for this."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Sit down?"
                mc "I'm not doing anything with you."

                scene e4s27-23 with dissolve
                hide e4s27_amber_blink1
                am "Chill baby, not for that"

                scene e4s27-22 with dissolve
                am "You said you wanted to know the truth about [fr], right?"

                scene e4s27-10 with dissolve
                am "I say we sit down and I tell you my side of the story, okay?"

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Like there is one."
                mc "Alright, if that makes you feel better, we'll sit."

                hide e4s27_amber_blink1

            "Kick her out":
                if affinity_spectrum > 0:
                    mc "I don't give a shit."
                    mc "You can leave now."
                    mc "Don't make me kick you out."
                else:
                    mc "I don't care."
                    mc "You can just leave."

                scene e4s27-16 with dissolve
                hide e4s27_amber_blink1
                am "As hot as you are, boy are you lame..."

                scene e4s27-18 with dissolve
                am "I guess this club really does perfectly suit you."

                scene e4s27-13 with dissolve
                am "Alright then, I won't say anything."

                scene e4s27-12 with dissolve
                am "I'll just leave."

                scene e4s27-14 with dissolve
                am "Just... do me a favor, alright?"
                am "Ask [fr] about what really happened."

                scene e4s27-16 with dissolve
                am "If she's even capable of telling the truth without sugarcoating it. You might be surprised, or maybe not."

                scene e4s27-21 with dissolve
                am "Take care handsome!"

                scene e4s27-19 with dissolve
                pause

                scene e4s27-20 with dissolve
                mc "*Telling the truth?*"
                mc "*What is she on about?*"

    if e4s27_listen == True:
        stop music fadeout 1.0
        scene e4s27-124 with dissolve
        am "So, with me and [fr] it's always kind of been a weird dynamic."

        play music mpause
        scene e4s27-126 with dissolve
        am "Like, don't get me wrong, we were really good friends."

        scene e4s27-127 with dissolve
        am "Even now I kind of find myself missing some of those moments."

        scene e4s27-128 with dissolve
        am "But I don't think we were ever in a healthy friendship, you know?"

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "What does that even mean?"

        scene e4s27-129 with dissolve
        hide e4s27_amber_blink2
        am "We always wanted what each other had."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Seems to me like you were the one who wanted what she had."

        scene e4s27-130 with dissolve
        hide e4s27_amber_blink2
        am "I'm sorry you were led to believe that, but it's only half the story."

        scene e4s27-131 with dissolve
        am "The other half is that she also wanted what I had."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Come on, [fr] isn't like that."
        mc "What do you mean, she wanted what you had?"

        scene e4s27-132 with dissolve
        hide e4s27_amber_blink2
        am "I know it might come as a shocker, she really doesn't seem the type."

        scene e4s27-129 with dissolve
        am "But let me explain how the situation was."

        scene e4s27-126 with dissolve
        am "We basically completed each other, right?"

        scene e4s27-127 with dissolve
        am "She was a bit introverted, liked to spend time alone."
        am "I was quite the opposite, popular, extroverted, could talk to anyone."

        scene e4s27-133 with dissolve
        am "Just like I'm doing with you right now."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Yeah... I noticed."

        scene e4s27-131 with dissolve
        hide e4s27_amber_blink2
        am "And the thing is, our friendship was fine at first."

        scene e4s27-130 with dissolve
        am "We weren't perfect, but we were comfortable."

        scene e4s27-132 with dissolve
        am "But people change."
        am "We're always looking to grow, to evolve."

        scene e4s27-128 with dissolve
        am "Eventually, I started liking the things she had and vice versa."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Like what?"

        scene e4s27-129 with dissolve
        hide e4s27_amber_blink2
        am "Well, she's probably the best singer in this college."
        am "And I was proud of her... at first."

        scene e4s27-134 with dissolve
        am "But when she started impressing everyone, I couldn't help but feel invisible."

        scene e4s27-135 with dissolve
        am "I worked just as hard, maybe even harder, and somehow still came second to my best friend."

        scene e4s27-130 with dissolve
        am "Call me whatever you want, but I cared about her, more than she ever seemed to care about me."

        scene e4s27-131 with dissolve
        am "And the thing is, this wasn't even enough for her."
        am "She wanted to be popular too, as easy-going as I was."

        scene e4s27-134 with dissolve
        am "She started talking to my friends, tried to become better friends with them."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Did you ever talk to her about how that made you feel?"

        scene e4s27-132 with dissolve
        hide e4s27_amber_blink2
        am "Yeah, I tried to, but she always seemed to brush it off as if it were nothing."
        am "It felt like she was using her money to win people over."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "You really think she was trying to replace you?"

        scene e4s27-134 with dissolve
        hide e4s27_amber_blink2
        am "I don't know if that was her intent, but that's how it looked from my side."

        scene e4s27-135 with dissolve
        am "And you know... it's not fair for her to be spreading lies like those about me."

        scene e4s27-134 with dissolve
        am "Yeah, sure, I'm not perfect."
        am "I made mistakes in that friendship, ones I wish I could take back."

        scene e4s27-131 with dissolve
        am "But I can't, and I've had to own up to them."

        scene e4s27-132 with dissolve
        am "I'm not trying to excuse myself, but at least fucking tell the whole side of the story if you wanna tell it."

        scene e4s27-134 with dissolve
        am "Don't portray me as this shitty person who did all wrong... when in reality we were both broken."
        am "It's just not fair, you know?"

        scene e4s27-135 with dissolve
        am "I have lost... so many people because of this whole situation."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        menu:
            "Believe her":
                $ e4s27_believe = True
                mc "If this is really true, I'm sorry to hear that."
                mc "I didn't think [fr] would be capable of doing something like that."
                mc "I've only seen one side of her."
                mc "Maybe that's the problem."

            "Doubt her":
                mc "I don't know [am], hearing all this seems very surprising."
                mc "To the point where I'm not sure I believe it."

                scene e4s27-131 with dissolve
                hide e4s27_amber_blink2
                am "Of course, you can believe whatever you want."

                scene e4s27-125 with dissolve
                show e4s27_amber_blink2
                mc "Maybe you're right."
                mc "Maybe you're both to blame."
                mc "But it's hard for me to ignore how defensive this all sounds."

        scene e4s27-130 with dissolve
        hide e4s27_amber_blink2
        am "I don't want to change your mind about me, or about her."

        scene e4s27-129 with dissolve
        am "I just wanted you to hear everything."
        am "I couldn't do it right back then, maybe I can do it now with you."

        scene e4s27-131 with dissolve
        am "I just want you to know that I am not all bad, I just tend to take things too far sometimes."

        scene e4s27-132 with dissolve
        am "But that's just how I've always been."

        scene e4s27-133 with dissolve
        am "I don't mean half the shit I say most of the time, but I don't take life all that serious."

        scene e4s27-135 with dissolve
        am "Maybe that's why everything ended up so screwed."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Why are you telling me all this now?"

        scene e4s27-133 with dissolve
        hide e4s27_amber_blink2
        am "Because you're still willing to sit with me."

        scene e4s27-131 with dissolve
        am "That has to count for something."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "Oh..."
        am "..."

        scene e4s27-135 with dissolve
        hide e4s27_amber_blink2
        am "Anyway, enough with that sentimental crap."

        scene e4s27-134 with dissolve
        am "I don't like when I get emotional."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        if e4s27_believe == True:
            mc "I mean... it's good that you told me."
            mc "I kind of liked hearing it."

            scene e4s27-136 with dissolve
            hide e4s27_amber_blink2
            am "You're sweet."
        else:
            mc "Yeah well... I'm not sure whether to trust you or not."

            scene e4s27-132 with dissolve
            hide e4s27_amber_blink2
            am "That's fine."

        scene e4s27-126 with dissolve
        am "You know, I was worried you wouldn't even talk to me today."

        scene e4s27-125 with dissolve
        show e4s27_amber_blink2
        mc "I wasn't sure I should."

        if e3s19_amber_lewd == False:
            mc "Especially after what you did a few days ago in the bathroom."

            scene e4s27-130 with dissolve
            hide e4s27_amber_blink2
            am "Yeah, I'm sorry."

        scene e4s27-132 with dissolve
        hide e4s27_amber_blink2
        am "As I said, I tend to be a bit bold sometimes."

        scene e4s27-133 with dissolve
        am "But you sat, you listened, and now we're here..."
        am "And I'm glad you did."

        if e4s27_amber_lewd == True:
            scene e4s27-137 with dissolve
            mc "..."

            scene e4s27-135 with dissolve
            am "I should probably get going."

            scene e4s27-136 with dissolve
            am "We spent a lot of time in here tonight, haha!"

            scene e4s27-133 with dissolve
            am "Better not raise any suspicion."

            scene e4s27-137 with dissolve
            mc "Yeah, you're right."
            mc "I should be going as well."
            mc "I'm pretty wasted."

            scene e4s27-133 with dissolve
            am "I'll see you around, pretty!"

            scene e4s27-150 with dissolve
            pause

            scene e4s27-139 with dissolve
            pause

            scene e4s27-147 with dissolve
            pause

            scene e4s27-149 with dissolve
            pause
        else:
            scene e4s27-140 with dissolve
            am "It'd be a shame to waste the moment, don't you think?"

            scene e4s27-141 with dissolve
            mc "What are you doing?"

            scene e4s27-142 with dissolve
            am "I'm being honest for once..."
            am "And maybe a little selfish."

            scene e4s27-143 with dissolve
            am "I want you [mc]."
            am "Ever since the day I first saw you..."

            scene e4s27-144 with dissolve
            menu:
                "Kiss her":
                    $ e4s27_amber_lewd = True
                    scene e4s27-139 with dissolve
                    pause

                    scene e4s27-kiss1 with dissolve
                    pause

                    scene e4s27-kiss2 with dissolve
                    pause

                    scene e4s27-138 with dissolve
                    pause

                    scene e4s27-156 with dissolve
                    am "Damn... you're a good kisser, you know?"

                    scene e4s27-141 with dissolve
                    mc "You're not so bad yourself."

                    scene e4s27-157 with dissolve
                    am "Haha!"

                    scene e4s27-156 with dissolve
                    am "Here, come by the window, have a look."

                    scene e4s27-150 with dissolve
                    pause

                    scene e4s27-151 with dissolve
                    pause

                    scene e4s27-152 with dissolve
                    pause

                    scene e4s27-153 with dissolve
                    pause

                    scene e4s27-154 with dissolve
                    mc "What's up?"

                    scene e4s27-155 with dissolve
                    am "I really love this room because you have a clear view on the traffic and streets."
                    am "I've always loved the sound of cars passing by at night."
                    am "It's weirdly comforting, if you can believe it."

                    scene e4s27-154 with dissolve
                    mc "I can kind of see the vision, yeah."

                    stop music fadeout 1.0
                    scene e4s27-14 with dissolve
                    am "Sharing this moment with you... it made me so horny."
                    am "Especially that we're here now."

                    call e4s27_lewd from _call_e4s27_lewd_1
                "Pull away":
                    stop music fadeout 1.0
                    scene e4s27-145 with dissolve
                    pause

                    scene e4s27-146 with dissolve
                    mc "I'm sorry [am], but I don't feel the same way."

                    scene e4s27-125 with dissolve
                    show e4s27_amber_blink2
                    mc "I did what you wanted, I heard your story."
                    mc "Now, I'd like you to leave."

                    scene e4s27-130 with dissolve
                    hide e4s27_amber_blink2
                    am "I understand."

                    scene e4s27-150 with dissolve
                    pause

                    scene e4s27-147 with dissolve
                    pause

                    scene e4s27-148 with dissolve
                    pause
    jump e4s28
return

label e4s27_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        play music heartache
        scene e4s27-23 with dissolve
        am "The risk of getting caught... damn it excites me."

        scene e4s27-24 with dissolve
        am "Having you going down on me and [ev] catching us."

        scene e4s27-25 with dissolve
        am "Mmm..."

        scene e4s27-26 with dissolve
        am "Does thinking about her excite you as well?"

        scene e4s27-09 with dissolve
        show e4s27_amber_blink1
        menu:
            "Excites me":
                $ e4s27_evelyn_excite = True
                mc "It does excite me."

                scene e4s27-26 with dissolve
                hide e4s27_amber_blink1
                am "Tell me then..."

                scene e4s27-27 with dissolve
                am "What would you do..."

                scene e4s27-28 with vpunch
                am "If she grabbed your dick like that."

                if persistent.disable_nsfw == True:
                    scene e4s27-29 with dissolve
                else:
                    if persistent.type_nsfw == False:
                        scene e4s27-29_cen with dissolve
                am "And started moving her hand, up and down..."

                scene e4s27-30 with dissolve
                am "Up and down..."
                am "Teasing you like that."

                scene e4s27-31 with dissolve
                mc "I wouldn't be able to contain myself."

                scene e4s27-32 with dissolve
                am "What would you want to do to her?"

                scene e4s27-31 with dissolve
                menu:
                    "Dominate her" if affinity_spectrum >= 0:
                        $ e4s27_dom = True
                        call extrovert_affinity_check from _call_extrovert_affinity_check_69
                        call color_check from _call_color_check_134
                        mc "I'd dominate her."

                        scene e4s27-33 with dissolve
                        am "Oh... exciting!"
                        am "She strikes me as a dom, I wonder how you guys would fit together."

                    "Submit to her" if affinity_spectrum <= 0:
                        $ e4s27_dom = False
                        call introvert_affinity_check from _call_introvert_affinity_check_61
                        call color_check from _call_color_check_135
                        mc "I'd submit to her."

                        scene e4s27-32 with dissolve
                        am "Oh... a momma's boy?"

                        scene e4s27-33 with dissolve
                        am "Don't worry, I'll take good care of you."

            "Doesn't excite me":
                mc "I don't really think of [ev] like that."

                scene e4s27-22 with dissolve
                am "Oh... that's a shame."
                am "Why not?"

                scene e4s27-14 with dissolve
                am "She's got really beautiful curves."

                scene e4s27-13 with dissolve
                am "She looks so good for her age, any girl would want to be her."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "I guess she just isn't my type."

                scene e4s27-10 with dissolve
                hide e4s27_amber_blink1
                am "Oh... you don't like them bossy?"

                scene e4s27-13 with dissolve
                am "Maybe that's what happens when you don't get any."

                scene e4s27-09 with dissolve
                show e4s27_amber_blink1
                mc "Yeah..."

                scene e4s27-28 with vpunch
                hide e4s27_amber_blink1
                pause

                scene e4s27-31 with dissolve
                mc "Wow, what are you doing?"

                scene e4s27-30 with dissolve
                am "[ev] might not excite you but boy do you excite me."

                scene e4s27-32 with dissolve
                am "What, you want me to stop?"

                scene e4s27-31 with dissolve
                mc "No, you just caught me by surprise."
                mc "Keep going..."

                if persistent.disable_nsfw == True:
                    scene e4s27-29 with dissolve
                else:
                    if persistent.type_nsfw == False:
                        scene e4s27-29_cen with dissolve
                am "Just feel my hand moving, up and down..."

                scene e4s27-30 with dissolve
                am "Up and down..."

                scene e4s27-33 with dissolve
                am "How does me taking control make you feel?"

                scene e4s27-31 with dissolve
                menu:
                    "Good":
                        $ e4s27_dom = False
                        mc "It feels pretty good!"

                        scene e4s27-32 with dissolve
                        am "Such a good boy... I bet you love being told what to do."

                        scene e4s27-33 with dissolve
                        am "Don't worry, I'll take good care of you."
                    "Bad":
                        $ e4s27_dom = True
                        mc "It would feel better if I were the one in control."

                        scene e4s27-33 with dissolve
                        am "Oh... exciting!"

                        scene e4s27-32 with dissolve
                        am "A helpless girl like me could really use some domination."

        scene e4s27-34 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e4s27-35 with dissolve
            pause

            # Handjob

            scene e4s27-handjob1 with dissolve
            pause

            scene e4s27-36 with dissolve
            am "You know? You really know how to make a girl wait."

            scene e4s27-37 with dissolve
            am "I've been thinking about this dick all weekend."

            scene e4s27-38 with dissolve
            am "You left quite the impression in the stall!"

            scene e4s27-handjob2 with dissolve
            mc "Did I?"

            scene e4s27-36 with dissolve
            am "Of course you did."

            scene e4s27-37 with dissolve
            am "I wouldn't be back here if you didn't."

            scene e4s27-41 with dissolve
            am "It's not that easy to impress me."

            scene e4s27-handjob3 with dissolve
            mc "So much talking from your part."
            mc "I'm starting to think you might be catching feelings."

            scene e4s27-36 with dissolve
            am "You're definitely gifted."

            scene e4s27-41 with dissolve
            am "I'm going to enjoy this..."

            # Blowjob

            scene e4s27-blowjob1 with dissolve
            mc "Ah... fuck!"

            scene e4s27-blowjob2 with dissolve
            pause

            scene e4s27-blowjob1 with dissolve
            mc "That feels really good."

            scene e4s27-38 with dissolve
            am "I bet none of these girls from here could make you feel as good as I do."

            scene e4s27-blowjob3 with dissolve
            pause

            scene e4s27-blowjob4 with dissolve
            pause

            scene e4s27-36 with dissolve
            am "You know, I think we're a match made in heaven."

            scene e4s27-37 with dissolve
            am "I have the skills, you have this juicy dick."
            am "It's perfect for making us both feel good."

            if e4s27_dom == True:
                scene e4s27-38 with dissolve
                am "What? I talk too much?"

                scene e4s27-41 with dissolve
                am "How about you shut my mouth, huh?"

                scene e4s27-36 with dissolve
                am "Or are you too scared to get your hands dirty?"

                scene e4s27-42 with dissolve
                mc "Don't taunt me."

                scene e4s27-43 with dissolve
                am "Or what?"
                am "You're gonna cry?"

                scene e4s27-44 with dissolve
                am "Come on, I thought you were better than that."
                am "Or maybe I was wrong?"

                scene e4s27-45 with dissolve
                am "Rough me up, I want it hard, I want you to fill my mouth."

                scene e4s27-50 with dissolve
                pause

                scene e4s27-blowjob5 with dissolve
                pause

                scene e4s27-blowjob6 with dissolve
                mc "That's what you want?"

                scene e4s27-blowjob5 with dissolve
                am "Guh, guh, guh!"

                scene e4s27-blowjob6 with dissolve
                mc "Ah, fuck!"

                scene e4s27-46 with dissolve
                pause

                scene e4s27-47 with dissolve
                pause

                scene e4s27-48 with dissolve
                pause

                scene e4s27-49 with dissolve
                am "That all you got?"

                scene e4s27-50 with dissolve
                mc "You really want it, huh?"

                scene e4s27-51 with dissolve
                am "Surprise, surprise."
                am "The boy finally thinks."

                scene e4s27-blowjob5 with dissolve
                pause

                scene e4s27-blowjob6 with dissolve
                pause

                scene e4s27-blowjob7 with dissolve
                pause

                scene e4s27-blowjob8 with dissolve
                mc "Holy shit."
                mc "How are you not ah- getting any gag reflexes?"

                scene e4s27-blowjob7 with dissolve
                mc "It's... uh- crazy honestly."

                scene e4s27-52 with dissolve
                am "Ah... fuck."

                scene e4s27-49 with dissolve
                am "You know how to fuck a girl's mouth."

                scene e4s27-51 with dissolve
                am "And it seems like you got stamina too, I like that."

                scene e4s27-50 with dissolve
                mc "Get up and lose the clothes."

                scene e4s27-51 with dissolve
                am "You're really getting into the role, huh?"
                am "Unfortunately, I decide when we do what."

                scene e4s27-50 with dissolve
                mc "You think you're in charge?"

                scene e4s27-49 with dissolve
                am "Of course I am, I can make you cum whenever I want."

                scene e4s27-53 with dissolve
                pause

                scene e4s27-54 with dissolve
                pause

                scene e4s27-55 with dissolve
                pause

                scene e4s27-56 with dissolve
                mc "Are we seriously not gonna continue?"

                scene e4s27-57 with dissolve
                am "Nope, until you learn how to behave, we won't go further."

                scene e4s27-58 with dissolve
                menu:
                    "Play into her game":
                        $ e4s27_dom2 = True
                        scene e4s27-59 with dissolve
                        pause

                        scene e4s27-60 with dissolve
                        am "Oh, no!"

                        scene e4s27-61 with dissolve
                        am "That's what you want me to say?"
                        am "You want me to scream?"

                        scene e4s27-62 with dissolve
                        am "At least hold me like you mean it, gosh."

                        scene e4s27-63 with dissolve
                        am "I'm enjoying this more than you are."

                        scene e4s27-64 with dissolve
                        mc "Then fucking show it."

                        scene e4s27-65 with dissolve
                        am "Hmmm..."

                        scene e4s27-66 with dissolve
                        am "No!"

                        scene e4s27-63 with dissolve
                        am "I'd like to see you take control."
                        am "You haven't been that active until now."
                        am "You said you'd dominate, then fuck me like never before!"

                        scene e4s27-64 with dissolve
                        mc "You want me to take control?"
                        mc "I'll do whatever I please with you."

                        scene e4s27-67 with dissolve
                        am "*Finally... this guy fucking got it.*"

                        scene e4s27-68 with dissolve
                        pause

                        scene e4s27-69 with dissolve
                        pause

                        scene e4s27-70 with dissolve
                        pause

                        scene e4s27-71 with dissolve
                        pause

                        # Standing Doggy

                        scene e4s27-standing_doggy1 with dissolve
                        am "Oh my fucking God..."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-standing_doggy1 with dissolve
                        am "Ah shit, that feels amazing!"

                        scene e4s27-72 with dissolve
                        am "Fuck, fuck, fuck..."

                        scene e4s27-73 with dissolve
                        mc "You were uh- right."
                        mc "You really are ah- enjoying this more than me."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-74 with dissolve
                        am "You don't... uh- know... how much I waited for this."

                        if e3s19_amber_lewd == True:
                            scene e4s27-75 with dissolve
                            am "It was very hard to contain myself in the uh- bathroom."

                            scene e4s27-74 with dissolve
                            am "When you wanted to take it further."

                        scene e4s27-standing_doggy1 with dissolve
                        pause

                        scene e4s27-73 with dissolve
                        mc "Looks like you're the one who needs to behave."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-standing_doggy3 with dissolve
                        am "Yes, I've been a bad girl."
                        am "Teach me some manners."

                        scene e4s27-standing_doggy4 with dissolve
                        am "Oh... fuck!"

                        scene e4s27-standing_doggy5 with dissolve
                        pause

                        scene e4s27-standing_doggy3 with dissolve
                        pause

                        scene e4s27-standing_doggy4 with dissolve
                        mc "Fuck... you feel so good!"

                        scene e4s27-standing_doggy5 with dissolve
                        pause
                    "Behave":
                        scene e4s27-76 with dissolve
                        mc "Okay..."

                        scene e4s27-77 with dissolve
                        am "Okay what?"

                        scene e4s27-76 with dissolve
                        mc "I'll behave."
                        mc "Let's just continue."

                        scene e4s27-23 with dissolve
                        am "Now you want it, huh?"

                        scene e4s27-78 with dissolve
                        mc "Yes..."

                        scene e4s27-79 with dissolve
                        am "I want to hear you say it."

                        scene e4s27-78 with dissolve
                        mc "I want it [am], I want to fuck you."

                        scene e4s27-26 with dissolve
                        am "Good, good!"

                        scene e4s27-27 with dissolve
                        am "Lose the clothes then, we'll have some real fun."

                        scene e4s27-94 with dissolve
                        pause
            else:
                scene e4s27-blowjob3 with dissolve
                mc "Ah..."

                scene e4s27-blowjob4 with dissolve
                pause

                scene e4s27-36 with dissolve
                am "How does it feel?"

                scene e4s27-handjob2 with dissolve
                mc "It feels amazing."

                scene e4s27-blowjob3 with dissolve
                pause

                scene e4s27-blowjob4 with dissolve
                mc "Uh... oh shit!"

                scene e4s27-blowjob3 with dissolve
                pause

                scene e4s27-42 with dissolve
                mc "Huh, why'd you stop?"

                scene e4s27-38 with dissolve
                am "Lose the clothes baby."
                am "I wanna try something different."

                scene e4s27-42 with dissolve
                mc "Okay..."

                scene e4s27-94 with dissolve
                pause
            if e4s27_dom2 == False:
                scene e4s27-80 with dissolve
                pause

                scene e4s27-81 with dissolve
                pause

                scene e4s27-82 with dissolve
                pause

                scene e4s27-83 with dissolve
                pause

                scene e4s27-84 with dissolve
                pause

                scene e4s27-85 with dissolve
                pause

                scene e4s27-86 with dissolve
                pause

                scene e4s27-87 with dissolve
                pause

                scene e4s27-88 with dissolve
                am "What are you waiting for?"
                am "Take me."

                scene e4s27-89 with dissolve
                mc "Damn..."

                scene e4s27-90 with dissolve
                pause

                scene e4s27-93 with dissolve
                mc "Uhh..."
                mc "How are we... how are we gonna do it?"

                scene e4s27-91 with dissolve
                mc "Right..."

                scene e4s27-92 with dissolve
                mc "In it goes."

                scene e4s27-95 with dissolve
                am "Ah... shit!"

                # Missionary

                scene e4s27-missionary2 with dissolve
                pause

                scene e4s27-missionary1 with dissolve
                am "I've waited so long for this, oh my God!"

                scene e4s27-missionary3 with dissolve
                mc "You tell me... you're so tight."

                scene e4s27-97 with dissolve
                mc "It feels really good."

                scene e4s27-missionary1 with dissolve
                am "Fuck..."

                scene e4s27-missionary2 with dissolve
                pause

                scene e4s27-missionary3 with dissolve
                pause

                scene e4s27-missionary4 with dissolve
                am "Yeah, just like that."
                am "Fuck my pussy."

                scene e4s27-missionary5 with dissolve
                pause

                scene e4s27-missionary4 with dissolve
                am "I want to see you desire it."
                am "Say you want it."

                scene e4s27-missionary5 with dissolve
                mc "I want it."
                mc "I want to fuck your pussy."

                scene e4s27-96 with dissolve
                am "Oh shit... ah!"
                am "Keep going, yeah!"

            # Doggy

            scene e4s27-doggy1 with dissolve
            pause

            scene e4s27-doggy3 with dissolve
            am "Ahh... [mc]!"

            scene e4s27-doggy2 with dissolve
            pause

            scene e4s27-doggy3 with dissolve
            am "You're going in so deep like that."

            scene e4s27-doggy1 with dissolve
            pause

            scene e4s27-doggy2 with dissolve
            pause

            scene e4s27-doggy4 with dissolve
            am "Fuck me..."

            scene e4s27-doggy5 with dissolve
            mc "Ah... you're so hot."

            scene e4s27-doggy6 with dissolve
            mc "It feels amazing!"

            scene e4s27-doggy4 with dissolve
            pause

            scene e4s27-doggy5 with dissolve
            am "I love being so close to you."

            scene e4s27-doggy6 with dissolve
            pause

            if e4s27_dom2 == True:
                scene e4s27-98 with dissolve
                am "Cum whenever you want, okay?"
            else:
                scene e4s27-99 with dissolve
                am "I'll tell you when you can cum."

            scene e4s27-doggy5 with dissolve
            pause
        else:
            if persistent.type_nsfw == False:
                scene e4s27-35_cen with dissolve
                pause

                # Handjob

                scene e4s27-handjob1_cen with dissolve
                pause

                scene e4s27-36_cen with dissolve
                am "You know? You really know how to make a girl wait."

                scene e4s27-37_cen with dissolve
                am "I've been thinking about this dick all weekend."

                scene e4s27-38_cen with dissolve
                am "You left quite the impression in the stall!"

                scene e4s27-handjob2_cen with dissolve
                mc "Did I?"

                scene e4s27-36_cen with dissolve
                am "Of course you did."

                scene e4s27-37_cen with dissolve
                am "I wouldn't be back here if you didn't."

                scene e4s27-41_cen with dissolve
                am "It's not that easy to impress me."

                scene e4s27-handjob3_cen with dissolve
                mc "So much talking from your part."
                mc "I'm starting to think you might be catching feelings."

                scene e4s27-36_cen with dissolve
                am "You're definitely gifted."

                scene e4s27-41_cen with dissolve
                am "I'm going to enjoy this..."

                # Blowjob

                scene e4s27-blowjob1_cen with dissolve
                mc "Ah... fuck!"

                scene e4s27-blowjob2_cen with dissolve
                pause

                scene e4s27-blowjob1_cen with dissolve
                mc "That feels really good."

                scene e4s27-38_cen with dissolve
                am "I bet none of these girls from here could make you feel as good as I do."

                scene e4s27-blowjob3_cen with dissolve
                pause

                scene e4s27-blowjob4_cen with dissolve
                pause

                scene e4s27-36_cen with dissolve
                am "You know, I think we're a match made in heaven."

                scene e4s27-37_cen with dissolve
                am "I have the skills, you have this juicy dick."
                am "It's perfect for making us both feel good."

                if e4s27_dom == True:
                    scene e4s27-38_cen with dissolve
                    am "What? I talk too much?"

                    scene e4s27-41_cen with dissolve
                    am "How about you shut my mouth, huh?"

                    scene e4s27-36_cen with dissolve
                    am "Or are you too scared to get your hands dirty?"

                    scene e4s27-42_cen with dissolve
                    mc "Don't taunt me."

                    scene e4s27-43_cen with dissolve
                    am "Or what?"
                    am "You're gonna cry?"

                    scene e4s27-44_cen with dissolve
                    am "Come on, I thought you were better than that."
                    am "Or maybe I was wrong?"

                    scene e4s27-45_cen with dissolve
                    am "Rough me up, I want it hard, I want you to fill my mouth."

                    scene e4s27-50_cen with dissolve
                    pause

                    scene e4s27-blowjob5_cen with dissolve
                    pause

                    scene e4s27-blowjob6_cen with dissolve
                    mc "That's what you want?"

                    scene e4s27-blowjob5_cen with dissolve
                    am "Guh, guh, guh!"

                    scene e4s27-blowjob6_cen with dissolve
                    mc "Ah, fuck!"

                    scene e4s27-46_cen with dissolve
                    pause

                    scene e4s27-47_cen with dissolve
                    pause

                    scene e4s27-48_cen with dissolve
                    pause

                    scene e4s27-49_cen with dissolve
                    am "That all you got?"

                    scene e4s27-50_cen with dissolve
                    mc "You really want it, huh?"

                    scene e4s27-51_cen with dissolve
                    am "Surprise, surprise."
                    am "The boy finally thinks."

                    scene e4s27-blowjob5_cen with dissolve
                    pause

                    scene e4s27-blowjob6_cen with dissolve
                    pause

                    scene e4s27-blowjob7_cen with dissolve
                    pause

                    scene e4s27-blowjob8_cen with dissolve
                    mc "Holy shit."
                    mc "How are you not ah- getting any gag reflexes?"

                    scene e4s27-blowjob7_cen with dissolve
                    mc "It's... uh- crazy honestly."

                    scene e4s27-52_cen with dissolve
                    am "Ah... fuck."

                    scene e4s27-49_cen with dissolve
                    am "You know how to fuck a girl's mouth."

                    scene e4s27-51_cen with dissolve
                    am "And it seems like you got stamina too, I like that."

                    scene e4s27-50_cen with dissolve
                    mc "Get up and lose the clothes."

                    scene e4s27-51_cen with dissolve
                    am "You're really getting into the role, huh?"
                    am "Unfortunately, I decide when we do what."

                    scene e4s27-50_cen with dissolve
                    mc "You think you're in charge?"

                    scene e4s27-49_cen with dissolve
                    am "Of course I am, I can make you cum whenever I want."

                    scene e4s27-53 with dissolve
                    pause

                    scene e4s27-54 with dissolve
                    pause

                    scene e4s27-55 with dissolve
                    pause

                    scene e4s27-56 with dissolve
                    mc "Are we seriously not gonna continue?"

                    scene e4s27-57 with dissolve
                    am "Nope, until you learn how to behave, we won't go further."

                    scene e4s27-58 with dissolve
                    menu:
                        "Play into her game":
                            $ e4s27_dom2 = True
                            scene e4s27-59 with dissolve
                            pause

                            scene e4s27-60 with dissolve
                            am "Oh, no!"

                            scene e4s27-61 with dissolve
                            am "That's what you want me to say?"
                            am "You want me to scream?"

                            scene e4s27-62 with dissolve
                            am "At least hold me like you mean it, gosh."

                            scene e4s27-63 with dissolve
                            am "I'm enjoying this more than you are."

                            scene e4s27-64 with dissolve
                            mc "Then fucking show it."

                            scene e4s27-65 with dissolve
                            am "Hmmm..."

                            scene e4s27-66 with dissolve
                            am "No!"

                            scene e4s27-63 with dissolve
                            am "I'd like to see you take control."
                            am "You haven't been that active until now."
                            am "You said you'd dominate, then fuck me like never before!"

                            scene e4s27-64 with dissolve
                            mc "You want me to take control?"
                            mc "I'll do whatever I please with you."

                            scene e4s27-67 with dissolve
                            am "*Finally... this guy fucking got it.*"

                            scene e4s27-68 with dissolve
                            pause

                            scene e4s27-69_cen with dissolve
                            pause

                            scene e4s27-70_cen with dissolve
                            pause

                            scene e4s27-71_cen with dissolve
                            pause

                            # Standing Doggy

                            scene e4s27-standing_doggy1_cen with dissolve
                            am "Oh my fucking God..."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-standing_doggy1_cen with dissolve
                            am "Ah shit, that feels amazing!"

                            scene e4s27-72 with dissolve
                            am "Fuck, fuck, fuck..."

                            scene e4s27-73 with dissolve
                            mc "You were uh- right."
                            mc "You really are ah- enjoying this more than me."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-74 with dissolve
                            am "You don't... uh- know... how much I waited for this."

                            if e3s19_amber_lewd == True:
                                scene e4s27-75 with dissolve
                                am "It was very hard to contain myself in the uh- bathroom."

                                scene e4s27-74 with dissolve
                                am "When you wanted to take it further."

                            scene e4s27-standing_doggy1_cen with dissolve
                            pause

                            scene e4s27-73 with dissolve
                            mc "Looks like you're the one who needs to behave."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-standing_doggy3_cen with dissolve
                            am "Yes, I've been a bad girl."
                            am "Teach me some manners."

                            scene e4s27-standing_doggy4_cen with dissolve
                            am "Oh... fuck!"

                            scene e4s27-standing_doggy5_cen with dissolve
                            pause

                            scene e4s27-standing_doggy3_cen with dissolve
                            pause

                            scene e4s27-standing_doggy4_cen with dissolve
                            mc "Fuck... you feel so good!"

                            scene e4s27-standing_doggy5_cen with dissolve
                            pause

                        "Behave":
                            scene e4s27-76 with dissolve
                            mc "Okay..."

                            scene e4s27-77 with dissolve
                            am "Okay what?"

                            scene e4s27-76 with dissolve
                            mc "I'll behave."
                            mc "Let's just continue."

                            scene e4s27-23 with dissolve
                            am "Now you want it, huh?"

                            scene e4s27-78 with dissolve
                            mc "Yes..."

                            scene e4s27-79 with dissolve
                            am "I want to hear you say it."

                            scene e4s27-78 with dissolve
                            mc "I want it [am], I want to fuck you."

                            scene e4s27-26 with dissolve
                            am "Good, good!"

                            scene e4s27-27 with dissolve
                            am "Lose the clothes then, we'll have some real fun."

                            scene e4s27-94 with dissolve
                            pause
                else:
                    scene e4s27-blowjob3_cen with dissolve
                    mc "Ah..."

                    scene e4s27-blowjob4_cen with dissolve
                    pause

                    scene e4s27-36_cen with dissolve
                    am "How does it feel?"

                    scene e4s27-handjob2_cen with dissolve
                    mc "It feels amazing."

                    scene e4s27-blowjob3_cen with dissolve
                    pause

                    scene e4s27-blowjob4_cen with dissolve
                    mc "Uh... oh shit!"

                    scene e4s27-blowjob3_cen with dissolve
                    pause

                    scene e4s27-42_cen with dissolve
                    mc "Huh, why'd you stop?"

                    scene e4s27-38_cen with dissolve
                    am "Lose the clothes baby."
                    am "I wanna try something different."

                    scene e4s27-42_cen with dissolve
                    mc "Okay..."

                    scene e4s27-94 with dissolve
                    pause
                if e4s27_dom2 == False:
                    scene e4s27-80 with dissolve
                    pause

                    scene e4s27-81 with dissolve
                    pause

                    scene e4s27-82 with dissolve
                    pause

                    scene e4s27-83 with dissolve
                    pause

                    scene e4s27-84 with dissolve
                    pause

                    scene e4s27-85_cen with dissolve
                    pause

                    scene e4s27-86 with dissolve
                    pause

                    scene e4s27-87_cen with dissolve
                    pause

                    scene e4s27-88_cen with dissolve
                    am "What are you waiting for?"
                    am "Take me."

                    scene e4s27-89_cen with dissolve
                    mc "Damn..."

                    scene e4s27-90_cen with dissolve
                    pause

                    scene e4s27-93 with dissolve
                    mc "Uhh..."
                    mc "How are we... how are we gonna do it?"

                    scene e4s27-91_cen with dissolve
                    mc "Right..."

                    scene e4s27-92_cen with dissolve
                    mc "In it goes."

                    scene e4s27-95 with dissolve
                    am "Ah... shit!"

                    # Missionary

                    scene e4s27-missionary2_cen with dissolve
                    pause

                    scene e4s27-missionary1_cen with dissolve
                    am "I've waited so long for this, oh my God!"

                    scene e4s27-missionary3_cen with dissolve
                    mc "You tell me... you're so tight."

                    scene e4s27-97_cen with dissolve
                    mc "It feels really good."

                    scene e4s27-missionary1_cen with dissolve
                    am "Fuck..."

                    scene e4s27-missionary2_cen with dissolve
                    pause

                    scene e4s27-missionary3_cen with dissolve
                    pause

                    scene e4s27-missionary4_cen with dissolve
                    am "Yeah, just like that."
                    am "Fuck my pussy."

                    scene e4s27-missionary5_cen with dissolve
                    pause

                    scene e4s27-missionary4_cen with dissolve
                    am "I want to see you desire it."
                    am "Say you want it."

                    scene e4s27-missionary5_cen with dissolve
                    mc "I want it."
                    mc "I want to fuck your pussy."

                    scene e4s27-96_cen with dissolve
                    am "Oh shit... ah!"
                    am "Keep going, yeah!"

                # Doggy

                scene e4s27-doggy1_cen with dissolve
                pause

                scene e4s27-doggy3_cen with dissolve
                am "Ahh... [mc]!"

                scene e4s27-doggy2_cen with dissolve
                pause

                scene e4s27-doggy3_cen with dissolve
                am "You're going in so deep like that."

                scene e4s27-doggy1_cen with dissolve
                pause

                scene e4s27-doggy2_cen with dissolve
                pause

                scene e4s27-doggy4_cen with dissolve
                am "Fuck me..."

                scene e4s27-doggy5_cen with dissolve
                mc "Ah... you're so hot."

                scene e4s27-doggy6_cen with dissolve
                mc "It feels amazing!"

                scene e4s27-doggy4_cen with dissolve
                pause

                scene e4s27-doggy5_cen with dissolve
                am "I love being so close to you."

                scene e4s27-doggy6_cen with dissolve
                pause

                if e4s27_dom2 == True:
                    scene e4s27-98 with dissolve
                    am "Cum whenever you want, okay?"
                else:
                    scene e4s27-99 with dissolve
                    am "I'll tell you when you can cum."

                scene e4s27-doggy5_cen with dissolve
                pause

        $ GameRunning = True

        while GameRunning:

            $ renpy.block_rollback()
            $ config.rollback_enabled = False

            menu:
                "Handjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s27-handjob1 with dissolve
                        pause

                        scene e4s27-36 with dissolve
                        am "You know? You really know how to make a girl wait."

                        scene e4s27-38 with dissolve
                        am "You left quite the impression in the stall!"

                        scene e4s27-handjob2 with dissolve
                        mc "Did I?"

                        scene e4s27-36 with dissolve
                        am "Of course you did."

                        scene e4s27-handjob3 with dissolve
                        mc "So much talking from your part."
                        mc "I'm starting to think you might be catching feelings."

                        scene e4s27-36 with dissolve
                        am "You're definitely gifted."

                        scene e4s27-handjob2 with dissolve
                        pause

                        scene e4s27-handjob1 with dissolve
                        pause

                        scene e4s27-handjob3 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-handjob1_cen with dissolve
                            pause

                            scene e4s27-36_cen with dissolve
                            am "You know? You really know how to make a girl wait."

                            scene e4s27-38_cen with dissolve
                            am "You left quite the impression in the stall!"

                            scene e4s27-handjob2_cen with dissolve
                            mc "Did I?"

                            scene e4s27-36_cen with dissolve
                            am "Of course you did."

                            scene e4s27-handjob3_cen with dissolve
                            mc "So much talking from your part."
                            mc "I'm starting to think you might be catching feelings."

                            scene e4s27-36_cen with dissolve
                            am "You're definitely gifted."

                            scene e4s27-handjob2_cen with dissolve
                            pause

                            scene e4s27-handjob1_cen with dissolve
                            pause

                            scene e4s27-handjob3_cen with dissolve
                            pause
                "Blowjob":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s27-blowjob1 with dissolve
                        mc "Ah... fuck!"

                        scene e4s27-blowjob2 with dissolve
                        pause

                        scene e4s27-blowjob1 with dissolve
                        mc "That feels really good."

                        scene e4s27-38 with dissolve
                        am "I bet none of these girls from here could make you feel as good as I do."

                        scene e4s27-blowjob3 with dissolve
                        pause

                        scene e4s27-blowjob4 with dissolve
                        pause

                        if e4s27_dom == True:
                            scene e4s27-blowjob5 with dissolve
                            am "Guh, guh, guh!"

                            scene e4s27-blowjob6 with dissolve
                            mc "That's what you want?"

                            scene e4s27-blowjob5 with dissolve
                            am "Guh, guh, guh!"

                            scene e4s27-blowjob6 with dissolve
                            mc "Ah, fuck!"

                            scene e4s27-46 with dissolve
                            pause

                            scene e4s27-47 with dissolve
                            pause

                            scene e4s27-48 with dissolve
                            pause

                            scene e4s27-49 with dissolve
                            am "That all you got?"

                            scene e4s27-blowjob5 with dissolve
                            pause

                            scene e4s27-blowjob6 with dissolve
                            pause

                            scene e4s27-blowjob7 with dissolve
                            pause

                            scene e4s27-blowjob8 with dissolve
                            mc "Holy shit."
                            mc "How are you not ah- getting any gag reflexes?"

                            scene e4s27-blowjob7 with dissolve
                            mc "It's... uh- crazy honestly."

                            scene e4s27-52 with dissolve
                            am "Ah... fuck."

                            scene e4s27-49 with dissolve
                            am "You know how to fuck a girl's mouth."

                            scene e4s27-51 with dissolve
                            am "And it seems like you got stamina too, I like that."

                            scene e4s27-blowjob5 with dissolve
                            pause
                        else:
                            scene e4s27-blowjob3 with dissolve
                            mc "Ah..."

                            scene e4s27-blowjob4 with dissolve
                            pause

                            scene e4s27-36 with dissolve
                            am "How does it feel?"

                            scene e4s27-handjob2 with dissolve
                            mc "It feels amazing."

                            scene e4s27-blowjob3 with dissolve
                            pause

                            scene e4s27-blowjob4 with dissolve
                            mc "Uh... oh shit!"

                            scene e4s27-blowjob3 with dissolve
                            pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-blowjob1_cen with dissolve
                            mc "Ah... fuck!"

                            scene e4s27-blowjob2_cen with dissolve
                            pause

                            scene e4s27-blowjob1_cen with dissolve
                            mc "That feels really good."

                            scene e4s27-38_cen with dissolve
                            am "I bet none of these girls from here could make you feel as good as I do."

                            scene e4s27-blowjob3_cen with dissolve
                            pause

                            scene e4s27-blowjob4_cen with dissolve
                            pause

                            if e4s27_dom == True:
                                scene e4s27-blowjob5_cen with dissolve
                                am "Guh, guh, guh!"

                                scene e4s27-blowjob6_cen with dissolve
                                mc "That's what you want?"

                                scene e4s27-blowjob5_cen with dissolve
                                am "Guh, guh, guh!"

                                scene e4s27-blowjob6_cen with dissolve
                                mc "Ah, fuck!"

                                scene e4s27-46_cen with dissolve
                                pause

                                scene e4s27-47_cen with dissolve
                                pause

                                scene e4s27-48_cen with dissolve
                                pause

                                scene e4s27-49_cen with dissolve
                                am "That all you got?"

                                scene e4s27-blowjob5_cen with dissolve
                                pause

                                scene e4s27-blowjob6_cen with dissolve
                                pause

                                scene e4s27-blowjob7_cen with dissolve
                                pause

                                scene e4s27-blowjob8_cen with dissolve
                                mc "Holy shit."
                                mc "How are you not ah- getting any gag reflexes?"

                                scene e4s27-blowjob7_cen with dissolve
                                mc "It's... uh- crazy honestly."

                                scene e4s27-52_cen with dissolve
                                am "Ah... fuck."

                                scene e4s27-49_cen with dissolve
                                am "You know how to fuck a girl's mouth."

                                scene e4s27-51_cen with dissolve
                                am "And it seems like you got stamina too, I like that."

                                scene e4s27-blowjob5_cen with dissolve
                                pause
                            else:
                                scene e4s27-blowjob3_cen with dissolve
                                mc "Ah..."

                                scene e4s27-blowjob4_cen with dissolve
                                pause

                                scene e4s27-36_cen with dissolve
                                am "How does it feel?"

                                scene e4s27-handjob2_cen with dissolve
                                mc "It feels amazing."

                                scene e4s27-blowjob3_cen with dissolve
                                pause

                                scene e4s27-blowjob4_cen with dissolve
                                mc "Uh... oh shit!"

                                scene e4s27-blowjob3_cen with dissolve
                                pause
                "Standing Doggy" if e4s27_dom2 == True:
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s27-standing_doggy1 with dissolve
                        am "Oh my fucking God..."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-standing_doggy1 with dissolve
                        am "Ah shit, that feels amazing!"

                        scene e4s27-72 with dissolve
                        am "Fuck, fuck, fuck..."

                        scene e4s27-73 with dissolve
                        mc "You were uh- right."
                        mc "You really are ah- enjoying this more than me."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-74 with dissolve
                        am "You don't... uh- know... how much I waited for this."

                        scene e4s27-standing_doggy1 with dissolve
                        pause

                        scene e4s27-73 with dissolve
                        mc "Looks like you're the one who needs to behave."

                        scene e4s27-standing_doggy2 with dissolve
                        pause

                        scene e4s27-standing_doggy3 with dissolve
                        am "Yes, I've been a bad girl."
                        am "Teach me some manners."

                        scene e4s27-standing_doggy4 with dissolve
                        am "Oh... fuck!"

                        scene e4s27-standing_doggy5 with dissolve
                        pause

                        scene e4s27-standing_doggy3 with dissolve
                        pause

                        scene e4s27-standing_doggy4 with dissolve
                        mc "Fuck... you feel so good!"

                        scene e4s27-standing_doggy5 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-standing_doggy1_cen with dissolve
                            am "Oh my fucking God..."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-standing_doggy1_cen with dissolve
                            am "Ah shit, that feels amazing!"

                            scene e4s27-72 with dissolve
                            am "Fuck, fuck, fuck..."

                            scene e4s27-73 with dissolve
                            mc "You were uh- right."
                            mc "You really are ah- enjoying this more than me."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-74 with dissolve
                            am "You don't... uh- know... how much I waited for this."

                            scene e4s27-standing_doggy1_cen with dissolve
                            pause

                            scene e4s27-73 with dissolve
                            mc "Looks like you're the one who needs to behave."

                            scene e4s27-standing_doggy2_cen with dissolve
                            pause

                            scene e4s27-standing_doggy3_cen with dissolve
                            am "Yes, I've been a bad girl."
                            am "Teach me some manners."

                            scene e4s27-standing_doggy4_cen with dissolve
                            am "Oh... fuck!"

                            scene e4s27-standing_doggy5_cen with dissolve
                            pause

                            scene e4s27-standing_doggy3_cen with dissolve
                            pause

                            scene e4s27-standing_doggy4_cen with dissolve
                            mc "Fuck... you feel so good!"

                            scene e4s27-standing_doggy5_cen with dissolve
                            pause
                "Missionary" if e4s27_dom2 == False:
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s27-missionary2 with dissolve
                        pause

                        scene e4s27-missionary1 with dissolve
                        am "I've waited so long for this, oh my God!"

                        scene e4s27-missionary3 with dissolve
                        mc "You tell me... you're so tight."

                        scene e4s27-97 with dissolve
                        mc "It feels really good."

                        scene e4s27-missionary1 with dissolve
                        am "Fuck..."

                        scene e4s27-missionary2 with dissolve
                        pause

                        scene e4s27-missionary3 with dissolve
                        pause

                        scene e4s27-missionary4 with dissolve
                        am "Yeah, just like that."
                        am "Fuck my pussy."

                        scene e4s27-missionary5 with dissolve
                        pause

                        scene e4s27-missionary4 with dissolve
                        am "I want to see you desire it."
                        am "Say you want it."

                        scene e4s27-missionary5 with dissolve
                        mc "I want it."
                        mc "I want to fuck your pussy."

                        scene e4s27-96 with dissolve
                        am "Oh shit... ah!"
                        am "Keep going, yeah!"

                        scene e4s27-missionary4 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-missionary2_cen with dissolve
                            pause

                            scene e4s27-missionary1_cen with dissolve
                            am "I've waited so long for this, oh my God!"

                            scene e4s27-missionary3_cen with dissolve
                            mc "You tell me... you're so tight."

                            scene e4s27-97_cen with dissolve
                            mc "It feels really good."

                            scene e4s27-missionary1_cen with dissolve
                            am "Fuck..."

                            scene e4s27-missionary2_cen with dissolve
                            pause

                            scene e4s27-missionary3_cen with dissolve
                            pause

                            scene e4s27-missionary4_cen with dissolve
                            am "Yeah, just like that."
                            am "Fuck my pussy."

                            scene e4s27-missionary5_cen with dissolve
                            pause

                            scene e4s27-missionary4_cen with dissolve
                            am "I want to see you desire it."
                            am "Say you want it."

                            scene e4s27-missionary5_cen with dissolve
                            mc "I want it."
                            mc "I want to fuck your pussy."

                            scene e4s27-96_cen with dissolve
                            am "Oh shit... ah!"
                            am "Keep going, yeah!"

                            scene e4s27-missionary4_cen with dissolve
                            pause
                "Doggy":
                    $ config.rollback_enabled = True

                    if persistent.disable_nsfw == True:
                        scene e4s27-doggy1 with dissolve
                        pause

                        scene e4s27-doggy3 with dissolve
                        am "Ahh... [mc]!"

                        scene e4s27-doggy2 with dissolve
                        pause

                        scene e4s27-doggy3 with dissolve
                        am "You're going in so deep like that."

                        scene e4s27-doggy1 with dissolve
                        pause

                        scene e4s27-doggy2 with dissolve
                        pause

                        scene e4s27-doggy4 with dissolve
                        am "Fuck me..."

                        scene e4s27-doggy5 with dissolve
                        mc "Ah... you're so hot."

                        scene e4s27-doggy6 with dissolve
                        mc "It feels amazing!"

                        scene e4s27-doggy4 with dissolve
                        pause

                        scene e4s27-doggy5 with dissolve
                        am "I love being so close to you."

                        scene e4s27-doggy6 with dissolve
                        pause
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-doggy1_cen with dissolve
                            pause

                            scene e4s27-doggy3_cen with dissolve
                            am "Ahh... [mc]!"

                            scene e4s27-doggy2_cen with dissolve
                            pause

                            scene e4s27-doggy3_cen with dissolve
                            am "You're going in so deep like that."

                            scene e4s27-doggy1_cen with dissolve
                            pause

                            scene e4s27-doggy2_cen with dissolve
                            pause

                            scene e4s27-doggy4_cen with dissolve
                            am "Fuck me..."

                            scene e4s27-doggy5_cen with dissolve
                            mc "Ah... you're so hot."

                            scene e4s27-doggy6_cen with dissolve
                            mc "It feels amazing!"

                            scene e4s27-doggy4_cen with dissolve
                            pause

                            scene e4s27-doggy5_cen with dissolve
                            am "I love being so close to you."

                            scene e4s27-doggy6_cen with dissolve
                            pause
                "Cum":
                    $ config.rollback_enabled = True

                    mc "Ahh, [am]!"
                    mc "I'm going to cum!"

                    if persistent.disable_nsfw == True:
                        scene e4s27-doggy5 with dissolve
                        am "Do it inside, baby."
                        am "I want to feel your semen inside me."
                        am "Fill me up, I'm on the pill."
                        mc "I can't hold it, here it comes!"
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        show white with Dissolve(0.25)
                        show white with vpunch
                        hide white with Dissolve(0.25)
                        scene e4s27-100 with dissolve
                        pause

                        scene e4s27-101 with dissolve
                        mc "Oh fuck... that was really good!"

                        if e4s27_dom2 == True:
                            scene e4s27-102 with dissolve
                            am "Fuuuck!"

                            scene e4s27-103 with dissolve
                            mc "Hey, you alright?"

                            scene e4s27-104 with dissolve
                            am "Yeah, sorry..."
                            am "I just... I need to... ah!"
                            am "Oh, fuck!"

                            scene e4s27-105 with dissolve
                            am "I need to lay down a bit."
                            mc "Did you just cum?"

                            scene e4s27-106 with dissolve
                            am "Haha, no!"
                            am "Of course not!"

                            scene e4s27-107 with dissolve
                            mc "I think you came and you don't want to admit it."

                            scene e4s27-108 with dissolve
                            am "You were good, but you weren't that good to make me cum."

                            scene e4s27-109 with dissolve
                            mc "Then what was all that about?"

                            scene e4s27-110 with dissolve
                            am "I just... you..."

                            scene e4s27-111 with dissolve
                            am "Ah!"

                            scene e4s27-112 with dissolve
                            am "You fucked me so hard."

                            scene e4s27-113 with dissolve
                            am "You left me breathless."

                            scene e4s27-109 with dissolve
                            mc "Yeah, yeah, sure."

                            scene e4s27-114 with dissolve
                            mc "You can tell yourself whatever you want."
                        else:
                            scene e4s27-115 with dissolve
                            mc "How was I?"

                            scene e4s27-116 with dissolve
                            am "Oh boy, you were amazing."

                            scene e4s27-117 with dissolve
                            am "Damn, you almost made me cum."
                            am "Don't worry, I will teach you how."

                            scene e4s27-116 with dissolve
                            am "But for a first time?"
                            am "Damn impressive."

                            scene e4s27-118 with dissolve
                            mc "Thanks! You were great as well."
                            mc "Extraordinary I might say."

                            scene e4s27-119 with dissolve
                            am "Haha, you're gonna make me blush with the compliments."

                            scene e4s27-120 with dissolve
                            mc "Yeah no, I'm not even lying."

                            scene e4s27-118 with dissolve
                            mc "It was great."

                            scene e4s27-121 with dissolve
                            am "I'm glad you enjoyed yourself sweetie!"
                    else:
                        if persistent.type_nsfw == False:
                            scene e4s27-doggy5_cen with dissolve
                            am "Do it inside, baby."
                            am "I want to feel your semen inside me."
                            am "Fill me up, I'm on the pill."
                            mc "I can't hold it, here it comes!"
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            show white with Dissolve(0.25)
                            show white with vpunch
                            hide white with Dissolve(0.25)
                            scene e4s27-100_cen with dissolve
                            pause

                            scene e4s27-101_cen with dissolve
                            mc "Oh fuck... that was really good!"

                            if e4s27_dom2 == True:
                                scene e4s27-102_cen with dissolve
                                am "Fuuuck!"

                                scene e4s27-103 with dissolve
                                mc "Hey, you alright?"

                                scene e4s27-104 with dissolve
                                am "Yeah, sorry..."
                                am "I just... I need to... ah!"
                                am "Oh, fuck!"

                                scene e4s27-105_cen with dissolve
                                am "I need to lay down a bit."
                                mc "Did you just cum?"

                                scene e4s27-106_cen with dissolve
                                am "Haha, no!"
                                am "Of course not!"

                                scene e4s27-107_cen with dissolve
                                mc "I think you came and you don't want to admit it."

                                scene e4s27-108 with dissolve
                                am "You were good, but you weren't that good to make me cum."

                                scene e4s27-109_cen with dissolve
                                mc "Then what was all that about?"

                                scene e4s27-110 with dissolve
                                am "I just... you..."

                                scene e4s27-111 with dissolve
                                am "Ah!"

                                scene e4s27-112 with dissolve
                                am "You fucked me so hard."

                                scene e4s27-113 with dissolve
                                am "You left me breathless."

                                scene e4s27-109_cen with dissolve
                                mc "Yeah, yeah, sure."

                                scene e4s27-114_cen with dissolve
                                mc "You can tell yourself whatever you want."
                            else:
                                scene e4s27-115 with dissolve
                                mc "How was I?"

                                scene e4s27-116 with dissolve
                                am "Oh boy, you were amazing."

                                scene e4s27-117 with dissolve
                                am "Damn, you almost made me cum."
                                am "Don't worry, I will teach you how."

                                scene e4s27-116 with dissolve
                                am "But for a first time?"
                                am "Damn impressive."

                                scene e4s27-118_cen with dissolve
                                mc "Thanks! You were great as well."
                                mc "Extraordinary I might say."

                                scene e4s27-119 with dissolve
                                am "Haha, you're gonna make me blush with the compliments."

                                scene e4s27-120_cen with dissolve
                                mc "Yeah no, I'm not even lying."

                                scene e4s27-118_cen with dissolve
                                mc "It was great."

                                scene e4s27-121 with dissolve
                                am "I'm glad you enjoyed yourself sweetie!"

                    if not _in_replay and e4s27_listen == False:
                        scene e4s27-113 with dissolve
                        am "Now... with this out of the way."

                        scene e4s27-122 with dissolve
                        am "How about we have a little talk?"

                        scene e4s27-123 with dissolve
                        mc "Huh? About what?"

                        scene e4s27-121 with dissolve
                        am "You said you wanted to know what I was doing here."
                        am "I want to come clean and tell you everything."

                        scene e4s27-113 with dissolve
                        am "You said you wanted to know the truth about [fr], right?"

                        scene e4s27-123 with dissolve
                        mc "Oh, right!"
                        mc "I forgot about that, haha!"

                        scene e4s27-122 with dissolve
                        am "Let's sit down and I will tell you my side of the story, okay?"

                        scene e4s27-123 with dissolve
                        mc "Yeah, sure."

                        $ e4s27_listen = True

                        scene black with Dissolve(2.0)
                        pause(1.0)

                    $ GameRunning = False

    $ renpy.end_replay()
return
