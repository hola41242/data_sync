
# Scene 29 - Another therapy ###################################################

label e4s29:
    scene e4s29-01 with wipeleft
    play sound door_open
    pause

    play music mom_n_pa
    scene e4s29-02 with dissolve
    mc "Hey!"

    scene e4s29-03 with dissolve
    ov "Hi!"

    scene e4s29-02 with dissolve
    mc "Thank you for having me on such short notice."

    scene e4s29-03 with dissolve
    ov "No problem!"

    scene e4s29-04 with dissolve
    ov "Come on in."

    scene e4s29-05 with dissolve
    mc "Thanks."

    scene e4s29-07 with dissolve
    ov "So... tell me [mc], what's going on?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    mc "I don't know..."
    mc "It's like I have this rage inside of me that I can't control sometimes."
    mc "Like, I just react to stuff instead of thinking things through."

    scene e4s29-10 with dissolve
    hide e4s29_olivia_blink1
    ov "What do you feel in those moments?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    mc "I don't know, like I'm losing control, like I'm reacting and then I regret how I reacted in that moment."
    mc "And I feel like that's affecting my life in some way because this didn't happen to me before."

    scene e4s29-07 with dissolve
    hide e4s29_olivia_blink1
    ov "Have you lashed out at someone recently?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    if e4s27_listen == True:
        mc "Yeah... that's mostly the reason why I called you."
    else:
        mc "No... but I just got really mad."

    mc "I just had an argument with a friend."
    mc "Her name's [fr]."

    scene e4s29-08 with dissolve
    hide e4s29_olivia_blink1
    ov "I understand."

    scene e4s29-10 with dissolve
    ov "Do you think something might have triggered some deep feelings inside of you?"

    scene e4s29-12 with dissolve
    mc "What do you mean?"

    scene e4s29-08 with dissolve
    ov "You said you weren't acting like this before."
    ov "Maybe something changed you, or rather triggered you in some way."

    scene e4s29-09 with dissolve
    ov "You know, I've been thinking about what you said last time, about your mom and [jd]."

    scene e4s29-07 with dissolve
    ov "Maybe there's a link there?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    mc "What link could there be?"

    scene e4s29-08 with dissolve
    hide e4s29_olivia_blink1
    ov "I think this is your way of trying to cope with what's happened in your childhood."
    ov "Feeling betrayed by your father maybe made you think that there's no one left to trust."

    scene e4s29-09 with dissolve
    ov "Maybe this anger, this need to react, is your brain's way of protecting itself."

    scene e4s29-10 with dissolve
    ov "When you're triggered, it feels like survival mode kicks in."

    scene e4s29-12 with dissolve
    mc "And how do I fix it?"
    mc "How do I make it stop protecting itself?"

    scene e4s29-08 with dissolve
    ov "It's not something you can just turn off, it's going to take time."
    ov "You shouldn't be too hard on yourself about it."

    scene e4s29-07 with dissolve
    ov "Tell me how it went with [fr]."

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    if e4s27_listen == True:
        mc "Well... there was this thing that happened... it made me question her."
        mc "She told me something, but it wasn't the whole truth, I found out from someone else."
        mc "She then acted weird, like I was wrong for even asking."
        mc "She didn't take any real responsibility for what she did."
        mc "It was like I was the problem for digging into it."

        scene e4s29-13 with dissolve
        hide e4s29_olivia_blink1
        ov "I understand."

        scene e4s29-06 with dissolve
        show e4s29_olivia_blink1
    else:
        mc "So, basically [fr] told me a story, right?"
        mc "And someone else told me to look deeper into it."
        mc "Like, she wasn't telling me the whole truth."
        mc "I didn't really care at first, but it was eating at me... so I wanted to convince myself by going to her and clearing the air."
        mc "I know people could just try to get between us, but I wanted to make sure."
        mc "And she didn't confirm or deny anything."
        mc "She was angrier at the fact that I had the audacity to look into it rather than to blindly trust her, you know?"
        mc "If it really wasn't a big deal, why not just tell me straight to my face?"

    mc "It just makes me so angry and so powerless."

    scene e4s29-14 with dissolve
    hide e4s29_olivia_blink1
    ov "Is this what you felt when your mother left?"

    scene e4s29-12 with dissolve
    mc "Yeah... kind of."
    mc "Obviously, I was younger and I didn't fully understand what was going on."
    mc "But, just like then, I wasn't left with any real explanation."
    mc "It feels like people just do stuff for the sake of doing them, like there's no reason behind their actions."

    scene e4s29-14 with dissolve
    ov "Have you tried to think about why they might do what they do?"

    scene e4s29-12 with dissolve
    mc "I tried, but I just couldn't come up with anything."
    mc "Maybe they're afraid of something? I don't know."

    scene e4s29-11 with dissolve
    ov "That's an interesting explanation."

    scene e4s29-07 with dissolve
    ov "What would they be afraid of?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    mc "Of their past?"
    mc "But as far as I know, mom's past isn't all that secret."
    mc "Maybe my memory is foggy, but I don't recall her actually doing anything wrong, like sleeping around or something."
    mc "With [fr], it's a different story because I don't know her past."
    mc "I can only see her for who she is now."

    scene e4s29-07 with dissolve
    hide e4s29_olivia_blink1
    ov "And who is she?"

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    menu:
        "Sweet person":
            $ e4s29_sweet = True
            mc "She's a pretty sweet person, despite what happened."

        "Bad person":
            $ francesca_trust -= 1
            mc "I don't think she's a good person."
            mc "Based on everything that's happened, my view of her has changed."

    mc "But until I hear the full story, I can never be so sure."

    scene e4s29-11 with dissolve
    hide e4s29_olivia_blink1
    ov "That's a great starting point, yeah."

    scene e4s29-07 with dissolve
    ov "What do you say we try some guided meditation next time you come around?"
    ov "It could help with keeping your emotions in check."

    scene e4s29-06 with dissolve
    show e4s29_olivia_blink1
    menu:
        "Continue with therapy":
            $ e4s29_olivia_path = True
            mc "Yeah... I think that would be great."
            mc "I probably need it."

            scene e4s29-15 with dissolve
            hide e4s29_olivia_blink1
            ov "Awesome!"
            ov "Just tell me when you're free next week and we can schedule a meeting."

            scene e4s29-06 with dissolve
            show e4s29_olivia_blink1
            mc "I'm not sure yet, but give me your number, I'll text you when I know."

            scene e4s29-11 with dissolve
            hide e4s29_olivia_blink1
            ov "Sure thing!"

            scene e4s29-15 with dissolve
            ov "I'm so glad you accepted my proposal."

            scene e4s29-06 with dissolve
            show e4s29_olivia_blink1
            mc "Haha, why's that?"

            scene e4s29-09 with dissolve
            hide e4s29_olivia_blink1
            ov "I have seen so many people turn down therapy before because they feel like it doesn't help them."

            scene e4s29-08 with dissolve
            ov "But it takes strength to recognize what's wrong in you and actually try to take steps toward healing."
            ov "I always get sad when I see them leave."

            scene e4s29-12 with dissolve
            mc "Oh, I see."
            mc "That puts me ahead then, huh?"

            scene e4s29-15 with dissolve
            ov "You have no idea, haha!"

            scene e4s29-17 with dissolve
            pause

        "Give up therapy":
            mc "I don't think this is for me, I'm sorry."
            mc "This is the second time I've tried it, and it doesn't feel like much."

            scene e4s29-08 with dissolve
            ov "It isn't supposed to do."

            scene e4s29-09 with dissolve
            ov "It takes time, like with most things in life."
            ov "You can't expect to change instantly just from two sessions."

            scene e4s29-08 with dissolve
            ov "But if you really don't enjoy it, I won't push you."

            scene e4s29-14 with dissolve
            ov "Just stating the fact."

            scene e4s29-09 with dissolve
            ov "Thank you for trying it, though."

            scene e4s29-12 with dissolve
            mc "Thanks for listening, and sorry for wasting your time."

            scene e4s29-14 with dissolve
            ov "It was not time wasted, if I managed to help you even just 1 percent, then I think I did my job."

            scene e4s29-12 with dissolve
            mc "Yeah..."
            mc "Well... I will see you around then."
            mc "Bye [ov]!"

            scene e4s29-08 with dissolve
            ov "Bye [mc]."

            scene e4s29-16 with dissolve
            pause

    jump e4s30
return
