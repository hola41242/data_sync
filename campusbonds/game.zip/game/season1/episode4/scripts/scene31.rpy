
if persistent.fight_difficulty == 0:
    default e4s31_mc_health = 7
    default e4s31_staff_health = 6
if persistent.fight_difficulty == 1:
    default e4s31_mc_health = 7
    default e4s31_staff_health = 8
if persistent.fight_difficulty == 2:
    default e4s31_mc_health = 6
    default e4s31_staff_health = 10

default e4s31_positive_fight = ["e4s31-52", "e4s31-53", "e4s31-54"]
default e4s31_negative_fight = ["e4s31-55", "e4s31-56", "e4s31-57"]

default e4s31_dialogue_continue = False

# Scene 31 - Kevin's servant ###################################################

label e4s31:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music french_toast
    scene e4s0-04 with Dissolve(2.0)
    play sound door_close
    pause

    scene e4s0-05 with dissolve
    fr "[mc]?"

    scene e4s0-06 with dissolve
    unknown "Hey, what's up?"

    scene e4s0-07 with dissolve
    ev "You're late."

    scene e4s0-08 with dissolve
    unknown "Sorry... had to make a pit stop."

    scene e4s0-07 with dissolve
    ev "Yeah, yeah. Just take a seat. We're starting soon."

    scene e4s0-09 with dissolve
    fr "Wait..."
    fr "You're not [mc]!"

    scene e4s0-10 with dissolve
    ev "Huh?"

    scene e4s0-11 with dissolve
    ke "What do you mean I'm not [mc]?"
    ke "I'm here to play the drums!"

    scene e4s0-12 with dissolve
    eva "The drums??"

    scene e4s0-13 with dissolve
    el "Wait a minute, [ke]?"

    scene e4s31-09 with wipeleft
    pause

    scene e4s31-10 with dissolve
    mc "Remind me again, why do I have to wear an earpiece?"

    scene e4s31-11 with dissolve
    jon "Dude, it's mandatory."
    jon "I have to guide you through, right?"
    jon "Plus, I like the vibe it brings."
    jon "We're like in those Jon Bond movies."

    scene e4s31-10 with dissolve
    mc "Except that you're supposed to be Jon, not me."
    mc "Like that's your actual name."

    scene e4s31-11 with dissolve
    jon "Yeah, yeah, yeah, stop yapping."
    jon "Staff incoming, act normal."

    scene e4s31-12 with dissolve
    pause

    scene e4s31-13 with dissolve
    pause

    scene e4s31-10 with dissolve
    mc "Okay, they're gone."
    mc "What do I do now?"

    scene e4s31-11 with dissolve
    jon "Okay, do you have the laxatives?"

    scene e4s31-10 with dissolve
    mc "Yeah, I got them in my pocket."

    scene e4s31-11 with dissolve
    jon "Alright, listen up."
    jon "To your left, there's a hallway."
    jon "Take that and then first on the left is the kitchen."
    jon "They should be making the coffees by now."

    scene e4s31-10 with dissolve
    mc "Okay, okay, I'm on my way."

    scene e4s31-14 with dissolve
    pause

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music dances_and_dames
    scene e4s31-15 with Dissolve(2.0)
    pause

    scene e4s31-16 with dissolve
    mc "Okay, I'm here."
    mc "I can't really see shit."

    scene e4s31-17 with dissolve
    jon "Wa- du- your signal is cutting off."

    scene e4s31-18 with dissolve
    mc "Shit man, not now!"
    mc "Do something to it."

    scene e4s31-17 with dissolve
    jon "I- I can hea- hear you from ti- time to time."
    jon "It's fine, ju- just go and pu- put in the laxatives."
    jon "The coffees shou- should be on one of th- the tables."
    jon "A pa- pair of three."

    scene e4s31-16 with dissolve
    mc "Three?"
    mc "What if he gets the wrong cup?"

    scene e4s31-17 with dissolve
    jon "He won't tru- trust me, we ha- have [ci]."
    jon "She'll ta- ke care of it."

    scene e4s31-18 with dissolve
    mc "Okay, okay."

    scene e4s31-19 with dissolve
    mc "Wait, which one is his?"

    scene e4s31-20 with dissolve
    jon "Th- the on- one on the right."

    scene e4s31-21 with dissolve
    mc "Shit, someone's coming my way!"

    scene e4s31-22 with dissolve
    mc "What do I tell them?"

    scene e4s31-23 with dissolve
    unknown "Hey, are you the waiter?"

    $ timed_max = 3.9
    $ timed_start = 4.00
    $ timed_interval = 0.01
    $ timed_choice = 1

    scene e4s31-24 with dissolve
    menu:
        "Don't say anything":
            $ e4s31_dialogue_continue = True
            $ renpy.block_rollback()
            scene e4s31-27 with dissolve
            mc "..."

            scene e4s31-25 with dissolve
            unknown "Hello? Did you hear me?"

            scene e4s31-24 with dissolve
            mc "..."

            scene e4s31-27 with dissolve
            mc "*Shit... come on [jon]!*"

            scene e4s31-24 with dissolve
            jon "Tell hi- him yo- u're the wa- iter!"
            mc "Sorry?"

            scene e4s31-26 with dissolve
            unknown "I asked if you're the waiter."

            scene e4s31-24 with dissolve
            mc "Yeah, I am."

            scene e4s31-28 with dissolve
            unknown "There's been a delay and I want these delivered in 7 minutes instead of 5."

            scene e4s31-25 with dissolve
            unknown "You got that?"

            scene e4s31-24 with dissolve
            mc "Yes, sir!"
        "Say yes":
            $ e4s31_dialogue_continue = True
            $ renpy.block_rollback()
            mc "Yes, I'm supposed to deliver these cups."

            scene e4s31-25 with dissolve
            unknown "Good, there's been a slight delay."

            scene e4s31-28 with dissolve
            unknown "I want these cups delivered in 7 minutes instead of 5, alright?"

            scene e4s31-24 with dissolve
            mc "Yes, sir!"

        "Say no":
            $ renpy.block_rollback()
            $ timed_choice = 0
            mc "No, I'm not."

            scene e4s31-26 with dissolve
            unknown "Then what are you doing here?"
            unknown "You aren't paid to slack off."

            scene e4s31-25 with dissolve
            unknown "What's your attribution?"

            scene e4s31-24 with dissolve
            mc "Uhh..."

            scene e4s31-27 with dissolve
            mc "*Shit, [jon]!*"
            mc "*Help...*"

            scene e4s31-24 with dissolve
            jon "Qui- ck tell the guy yo- you work at 60."
            mc "I work at 60?"

            scene e4s31-28 with dissolve
            unknown "Then get your ass out of here."
            unknown "Don't crowd the place."

            scene e4s31-29 with dissolve
            unknown "Pfft, nobody's doing their jobs anymore."

            scene e4s31-30 with dissolve
            pause

            scene e4s31-31 with dissolve
            mc "Okay... he's gone, let's put in the laxatives."

            scene e4s31-23 with dissolve
            unknown "Let me take the cups."

            scene e4s31-32 with dissolve
            mc "*Shit, he's taking the cups!*"
            mc "*What do I do?*"

            $ timed_max = 3.9
            $ timed_start = 4.00
            $ timed_interval = 0.01
            $ timed_choice = 1

            menu:
                "Stop him":
                    scene e4s31-33 with dissolve
                    mc "WAIT!"

                    scene e4s31-34 with dissolve
                    unknown "What now!"

                    scene e4s31-35 with dissolve
                    mc "They're uh- not done!"

                    scene e4s31-34 with dissolve
                    unknown "What do you mean not done?"

                    scene e4s31-35 with dissolve
                    mc "I... uh-"
                    mc "One of them specifically asked for brown sugar."
                    mc "They didn't have that here so they're put on standby."

                    scene e4s31-36 with dissolve
                    unknown "Guh..."

                    scene e4s31-34 with dissolve
                    unknown "Just... bring them to me when they're done, alright?"
                    unknown "I'll be by the door."

                    scene e4s31-35 with dissolve
                    mc "Yes, sir!"

                    scene e4s31-30 with dissolve
                    pause

                    scene e4s31-20 with dissolve
                    mc "*Fuck... which one is which?*"
                    mc "*Is it still on the right?*"

                    menu:
                        "Switch them":
                            $ e4s31_fail = True

                            scene e4s31-37 with dissolve
                            mc "*Fuck it... I'll switch.*"
                            mc "*I think I saw him rotating the plate.*"

                        "Leave them":
                            mc "*Gahh! I don't have time for that.*"
                            mc "*Let's leave them like so and get out of here.*"

                    scene e4s31-38 with dissolve
                    pause

                "Let him take them.":
                    $ e4s31_fight = True
                    mc "..."

                    scene e4s31-39 with dissolve
                    pause

                    scene e4s31-40 with dissolve
                    mc "Dude, he left with the cups!"
                    mc "What do I do?"

                    scene e4s31-41 with dissolve
                    jon "Follow him!"
                    jon "Get him alone and knock him out."

                    scene e4s31-42 with dissolve
                    mc "Dude, are you fucking serious?"

                    scene e4s31-41 with dissolve
                    jon "Yeah! Go!"

                    scene e4s31-43 with dissolve
                    mc "Fuck..."

                    scene e4s31-44 with dissolve
                    pause

                    scene e4s31-45 with dissolve
                    pause

                    stop music fadeout 1.0
                    scene e4s31-46 with dissolve
                    unknown "Hey, what the..."

                    play music electric_girlfriend
                    scene e4s31-47 with vpunch
                    play sound punch
                    pause

                    scene e4s31-48 with vpunch
                    play sound punch
                    pause

                    scene e4s31-49 with dissolve
                    unknown "What the fuck is wrong with you!"

                    scene e4s31-50 with dissolve
                    unknown "You spilled all the coffee on me."

                    scene e4s31-51 with dissolve
                    if persistent.fight == 0:
                        while e4s31_staff_health and e4s31_mc_health > 0:
                            call qte from _call_qte_37

                            if qte == True:
                                $ e4s31_staff_health = max(0, e4s31_staff_health - total_damage)

                                $ fight_scene = renpy.random.choice(e4s31_positive_fight)

                                while last_fight_scene == fight_scene:
                                    $ fight_scene = renpy.random.choice(e4s31_positive_fight)

                                play sound punch
                                scene expression fight_scene with vpunch

                                $ last_fight_scene = fight_scene
                            else:
                                $ e4s31_mc_health -= 1

                                $ fight_scene = renpy.random.choice(e4s31_negative_fight)

                                while last_fight_scene == fight_scene:
                                    $ fight_scene = renpy.random.choice(e4s31_negative_fight)

                                play sound punch
                                show miss_screen at miss_anim
                                show expression fight_scene behind miss_screen with vpunch

                                $ last_fight_scene = fight_scene

                        if qte_neg_count == 0:
                            $ strength += 1
                            if persistent.tf_gallery_4_unlocked == False:
                                $ persistent.tf_gallery_4_unlocked = True
                                $ renpy.show_screen("render_notify")
                                $ persistent.tiffany4 = True
                                python:
                                    update_tiffany_list()

                        if e4s31_staff_health == 0:
                            $ qte_neg_count = 0
                            $ qte_pos_count = 0

                            $ e4s31_fail = False
                            $ e4s31_fight_outcome = True
                            pause (1.0)

                            play sound punch
                            scene e4s31-54 with vpunch
                            pause

                            stop music fadeout 1.0
                            scene e4s31-58 with dissolve
                            pause

                            scene e4s31-60 with dissolve
                            mc "Dude, [jon]!"
                            mc "I knocked him out, what do I do now?"

                            scene e4s31-62 with dissolve
                            pause

                            scene e4s31-61 with dissolve
                            mc "[jon]?"

                            scene e4s31-62 with dissolve
                            mc "*Fucking bitch, he broke my earpiece.*"
                            mc "*Let's see if I can find [ci].*"

                            scene e4s31-63 with dissolve
                            pause

                            if affinity_spectrum > 0 and e4s2_greet == True:
                                scene e4s31-64 with dissolve
                                mc "Hey, nice outfit!"

                                scene e4s31-65 with dissolve
                                ci "Haha, thanks!"

                                scene e4s31-66 with dissolve
                                ci "Are you alright?"
                            else:
                                scene e4s31-67 with dissolve
                                ci "Hey, are you alright?"

                            scene e4s31-64 with dissolve
                            mc "Yeah, just knocked some bum out."
                            mc "Listen, the coffees are spilled."

                            scene e4s31-68 with dissolve
                            ci "Shit... we need new ones."

                            scene e4s31-67 with dissolve
                            ci "I can't be gone for too long, I'll signal them to prepare new ones."
                            ci "They should be done in an instant."
                            ci "Get to the kitchen, do what you have to do and get out of here."

                            scene e4s31-68 with dissolve
                            ci "That guy won't keep his mouth shut."

                            scene e4s31-64 with dissolve
                            mc "Alright, okay, I'm on my way."

                            scene black with Dissolve(2.0)
                            pause(1.0)

                        if e4s31_mc_health == 0:
                            $ qte_neg_count = 0
                            $ qte_pos_count = 0

                            $ e4s31_fail = True
                            $ e4s31_fight_outcome = False
                            pause (1.0)

                            play sound punch
                            scene e4s31-55 with vpunch
                            pause

                            scene e4s31-59 with dissolve
                            pause

                            scene e4s31-69 with dissolve
                            unknown "Stay down!"

                            scene e4s31-70 with dissolve
                            unknown "Code red, we've been compromised!"

                            scene e4s31-71 with dissolve
                            mc "*Shit, I think I blew it!*"

                            scene e4s31-72 with dissolve
                            mc "[jon]? You there?"

                            scene e4s31-73 with dissolve
                            jon "Yeah, what's up?"

                            scene e4s31-72 with dissolve
                            mc "I couldn't beat him."

                            scene e4s31-73 with dissolve
                            jon "What the fuck, dude?"
                            jon "You said you remembered how to fight."

                            scene e4s31-72 with dissolve
                            mc "I just couldn't do it, okay?"
                            mc "They went to signal my presence."

                            scene e4s31-73 with dissolve
                            jon "Shit, get out of there."
                            jon "I'll see if [ci] can erase your trace."

                            scene e4s31-72 with dissolve
                            mc "Shit... this didn't go as expected."

                            stop music fadeout 1.0
                            scene e4s31-74 with dissolve
                            pause

    if e4s31_dialogue_continue == True:
        unknown "..."

        scene e4s31-27 with dissolve
        pause

        scene e4s31-76 with dissolve
        unknown "Haha, don't be so serious."
        unknown "I was just pulling your leg."

        scene e4s31-78 with dissolve
        unknown "You don't have to call me sir."

        scene e4s31-75 with dissolve
        mc "Okay?"

        scene e4s31-77 with dissolve
        unknown "Yeah... nights like these in here can be quite intense."

        scene e4s31-78 with dissolve
        unknown "We don't really have the time to just sit back and relax, you know?"

        scene e4s31-27 with dissolve
        mc "*This guy wants to make small talk, ain't nobody got time for that!*"

        scene e4s31-78 with dissolve
        unknown "So... what's your story, man? You, uh, from around here?"

        scene e4s31-75 with dissolve
        if affinity_spectrum < 0:
            mc "Uh... yeah. I mean, no, I—uh, yeah, I'm from... over there."
        else:
            mc "Uh... nah, not really."

        jon "Yes! Say yes! The area!"

        scene e4s31-79 with dissolve
        mc "*What? The fuck he meant by serial?*"

        scene e4s31-75 with dissolve
        mc "I mean... yeah, I am from around, yeah, the serial is pretty nice."
        jon "AREA! AREA!"
        mc "Aerial, yeah, with birds, flying..."

        scene e4s31-77 with dissolve
        unknown "Right... interesting."

        scene e4s31-78 with dissolve
        unknown "You, uh, like working here, then?"

        scene e4s31-75 with dissolve
        mc "Yeah... it's pretty interesting."
        mc "I like it."

        scene e4s31-78 with dissolve
        unknown "I personally think it's pretty exhausting but it's good to see people are enjoying it."

        scene e4s31-75 with dissolve
        mc "Yeah..."

        scene e4s31-78 with dissolve
        unknown "What's your work number here?"

        scene e4s31-75 with dissolve
        mc "Number?"

        scene e4s31-27 with dissolve
        jon "Tell him 89!"

        scene e4s31-75 with dissolve
        mc "69!"

        scene e4s31-78 with dissolve
        unknown "Alright, alright... What are you doing after dealing with the cups? I could use a bit of help."

        scene e4s31-27 with dissolve
        mc "Uh... next?"

        scene e4s31-79 with dissolve
        jon "Te- tell him you're assi- gned to grab... some meat!"

        scene e4s31-27 with dissolve
        mc "To slap his meat?"

        scene e4s31-80 with dissolve
        unknown "To slap...?"

        scene e4s31-77 with dissolve
        unknown "Alright, man. You're... something else."

        scene e4s31-80 with dissolve
        unknown "Not judging! Of course."

        scene e4s31-76 with dissolve
        unknown "I gotta get back to work, but, uh... nice chatting, I guess."

        scene e4s31-27 with dissolve
        mc "Yeah, totally!"

        scene e4s31-30 with dissolve
        pause

        scene e4s31-43 with dissolve
        mc "Fucking finally."

        scene e4s31-37 with dissolve
        jon "He's gone?"

        scene e4s31-31 with dissolve
        mc "Yeah... I'm putting the laxatives in right now and I'm out of here."

        scene e4s31-38 with dissolve
        pause

        stop music fadeout 1.0
        scene black with Dissolve(2.0)
        pause(1.0)

    if e4s31_fail == False:
        play music orbiting_a_distant_planet
        scene e4s31-81 with dissolve
        kv "Good evening, everyone!"

        scene e4s31-82 with dissolve
        kv "First of all, I just want to say how great it feels to be here, standing in front of you all today."

        scene e4s31-83 with dissolve
        kv "We're all gathered here, not just as students, but as a community, a community that deserves a leader who truly gets it."

        stop music fadeout 1.0
        scene e4s31-84 with vpunch
        play sound stomach_growl
        kv "Ah...!"

        scene e4s31-85 with dissolve
        pause

        play sound heart_beat
        scene e4s31-86 with dissolve
        kv "*Oh... shit!*"
        kv "*Fuck... not now! What's wrong?*"

        play music orbiting_a_distant_planet
        scene e4s31-87 with dissolve
        kv "{i}Coughs{/i} sorry, everyone for that!"

        scene e4s31-82 with dissolve
        kv "Anyway, moving on..."

        stop music
        scene e4s31-85 with vpunch
        play sound stomach_growl
        pause

        play sound heart_beat
        scene e4s31-86 with dissolve
        kv "*Fuck, fuck, fuck!*"

        scene e4s31-88 with dissolve
        kv "I'm so sorry, if you'll uh- excuse me..."

        scene e4s31-89 with dissolve
        play sound stomach_growl
        pause

        scene e4s31-90 with dissolve
        pause

        scene e4s31-91 with vpunch
        play sound clothes_rip
        pause

        play music college_rock
        scene e4s31-92 with dissolve
        kv "Nooo!"

        scene e4s31-93 with dissolve
        kv "Ahhh!"

        scene e4s31-94 with dissolve
        jon "Haha! We did it."

    stop music fadeout 1.0
    scene e4s31-01 with wipeleft
    el "[ke]?"

    play music french_toast
    scene e4s31-02 with dissolve
    ev "You know this student?"

    scene e4s31-03 with dissolve
    el "Yeah... he's my ex."

    scene e4s31-04 with dissolve
    el "What are you doing here? Are you following me?"

    scene e4s31-05 with dissolve
    eva "And what was that about playing the drums?"

    scene e4s31-06 with dissolve
    fr "Where's [mc]?"

    scene e4s31-07 with dissolve
    ke "Wow, wow, chill, chill!"

    scene e4s31-08 with dissolve
    ke "*What did [jon] get me into...*"

    $ timed_max = 3.9
    $ timed_start = 4.00
    $ timed_interval = 0.01
    $ timed_choice = 0

    jump e4s32
return
