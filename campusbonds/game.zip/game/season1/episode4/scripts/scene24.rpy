
# Scene 24 - Lying snowball (Friday) ###########################################

label e4s24:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    if e4s22_tiffany_lie == True:
        play music iwnlylmd
        scene e4s24-71 with Dissolve(2.0)
        play sound phone_buzz
        pause

        scene e4s24-72 with dissolve
        pause

        scene e4s24-73 with dissolve
        nvl clear

        tf_nvl "Hey!"
        tf_nvl "How are you doing?"
        n_nvl "Hey [tf]!"
        n_nvl "I'm okay."
        n_nvl "Wbu?"
        tf_nvl "I'm fine, too."
        tf_nvl "Any news with the Party Ragers?"

        scene e4s24-74 with dissolve
        mc "*Shit... I told her I'd talk to them yesterday.*"
        mc "*Maybe lying wasn't such a great idea.*"
        mc "*What do I tell her now...*"

        scene e4s24-75 with dissolve
        n_nvl "Yeah, I talked to them."
        n_nvl "They accepted you."
        tf_nvl "Oh my God, really?"
        tf_nvl "That's awesome, I'm so excited."
        tf_nvl "When do you think you could give me a tour?"

        scene e4s24-74 with dissolve
        mc "*Shit... a tour?*"
        mc "*I haven't thought this through.*"
        mc "*If I get caught with her there, I'm screwed.*"
        mc "*Alright, let's do this quickly, before someone sees us.*"

        scene e4s24-75 with dissolve
        n_nvl "I can give you one now."
        n_nvl "I was on my way to their place anyway."
        tf_nvl "Now?"
        tf_nvl "But I'm not ready."
        tf_nvl "I need to apply some make up, to prepare myself."
        n_nvl "You don't need to, it's completely fine."
        n_nvl "Just be yourself."
        tf_nvl "Okay... okay."
        tf_nvl "I'll be on my way."

        stop music fadeout 1.0
        scene e4s24-01 with wipeleft
        pause

        scene e4s24-02 with dissolve
        mc "*Fuck... this was not a great idea at all.*"
        mc "*What have I gotten myself into?*"
        mc "*I'll think about this later, let's just give her a quick tour now.*"
        mc "*I just hope nobody catches us here.*"

        scene e4s24-03 with dissolve
        tf "Damn, this place rocks."
        tf "It's even better than I imagined."

        scene e4s24-04 with dissolve
        mc "Yeah, you should have seen it before, total mess."

        scene e4s24-05 with dissolve
        tf "Huh?"

        scene e4s24-06 with dissolve
        tf "How was it before?"

        scene e4s24-07 with dissolve
        mc "Well, it had tables all over the place, pretty ugly colors and I'm pretty sure something died in here."
        mc "It was basically the old cafeteria."

        scene e4s24-08 with dissolve
        tf "Damn, looks like they put in a lot of effort here."

        scene e4s24-09 with dissolve
        tf "So when are you guys holding the next party?"

        scene e4s24-07 with dissolve
        mc "That's the thing... we can't really do that anymore."
        mc "At least not here."
        mc "Remember the situation I told you about previously?"
        mc "It's with a professor."

        scene e4s24-10 with dissolve
        tf "Ah... I see."

        scene e4s24-09 with dissolve
        tf "Well, it's not a problem for me."
        tf "Hanging out is perfectly fine."

        scene e4s24-07 with dissolve
        mc "*Yeah...*"

        scene e4s24-11 with dissolve
        pause

        play music rollin_at_5
        scene e4s24-12 with dissolve
        sc "Huh?"

        if affinity_spectrum > 0 and scarlett_trust > 3:
            scene e4s24-14 with dissolve
            sc "*What do we have here?*"

            scene e4s24-13 with dissolve
            sc "*This is gonna be interesting.*"

            scene e4s24-16 with dissolve
            sc "Hey there!"
        else:
            scene e4s24-15 with dissolve
            sc "What are you doing here?"

        scene e4s24-17 with dissolve
        mc "*Shit... not now!*"

        scene e4s24-18 with dissolve
        mc "Oh... hi, [sc]!"

        scene e4s24-19 with dissolve
        mc "I'm giving Tiffany a tour of the club."

        scene e4s24-21 with dissolve
        sc "Oh, is that so?"
        sc "And why is that?"

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "Oh... well- I..."

        scene e4s24-22 with dissolve
        hide e4s24_scarlett_blink1
        tf "Hey, I'm [tf]!"
        tf "Nice to meet you."

        scene e4s24-23 with dissolve
        tf "I've been really eager to join your club and [mc] here has been really helpful."

        scene e4s24-24 with dissolve
        tf "So... yeah, thank you for letting me in."

        if affinity_spectrum > 0 and scarlett_trust > 3:
            scene e4s24-25 with dissolve
            sc "Ah ha!"
            sc "Interesting..."
            sc "I'm [sc]."

            scene e4s24-26 with dissolve
            sc "I see you have met [mc] by now."

            scene e4s24-22 with dissolve
            tf "Haha, yeah!"

            scene e4s24-27 with dissolve
            tf "He's the one giving me the tour after all, so."

            scene e4s24-25 with dissolve
            sc "Would you like me to continue the tour?"
            sc "I'm the president, after all..."

            scene e4s24-28 with dissolve
            tf "Oh, really?"

            scene e4s24-29 with dissolve
            sc "Mmhm."

            scene e4s24-25 with dissolve
            sc "Don't get me wrong, [mc] could definitely help you out."

            scene e4s24-30 with dissolve
            sc "He's great... at many things."

            scene e4s24-31 with dissolve
            sc "But today? I think I deserve a bit of the spotlight."

            scene e4s24-32 with vpunch
            mc "{i}Coughs.{/i}"

            scene e4s24-26 with dissolve
            sc "What? Is there a problem [mc]?"

            scene e4s24-38 with dissolve
            mc "Ah-ha- nope! Not at all!"

            scene e4s24-33 with dissolve
            mc "*I'm screwed.*"

            scene e4s24-34 with dissolve
            tf "Sooo... you two know each other pretty well, huh?"

            scene e4s24-35 with dissolve
            sc "Oh, you could say that, I believe we're pretty close."

            scene e4s24-36 with dissolve
            sc "We have spent... quite a bit of time together, after all."

            scene e4s24-37 with dissolve
            sc "Haven't we, [mc]?"

            scene e4s24-38 with dissolve
            mc "Haha.. yeah, no I- I wouldn't really say that."

            scene e4s24-37 with dissolve
            sc "Come on now... don't be shy!"

            scene e4s24-35 with dissolve
            sc "That's what I thought, actually."

            scene e4s24-40 with dissolve
            sc "He used to talk to me about stuff, you know?"

            scene e4s24-39 with dissolve
            sc "Today I feel a little... betrayed."

            scene e4s24-41 with dissolve
            tf "Oh... why is that?"

            scene e4s24-40 with dissolve
            sc "I mean... nothing, sorry."

            scene e4s24-42 with dissolve
            sc "I probably shouldn't have said anything."

            scene e4s24-43 with dissolve
            tf "No, no..."

            stop music fadeout 1.0
            scene e4s24-44 with dissolve
            tf "I want to know, what's up?"

            scene e4s24-45 with dissolve
            sc "Well... considering how {b}close{/b} I thought we were..."

            scene e4s24-40 with dissolve
            sc "I would've at least expected him to mention today's little tour."

            scene e4s24-39 with dissolve
            sc "I don't mind it, not really... I'm just a bit hurt, you know?"

            play music love
            scene e4s24-46 with dissolve
            tf "Wait... wait a minute."

            scene e4s24-41 with dissolve
            tf "What do you mean he didn't talk to you about it?"

            scene e4s24-47 with dissolve
            sc "Wait... he didn't tell you?"

            scene e4s24-48 with dissolve
            sc "Wow... he screwed both of us over. And not even in the fun way, shame..."

            scene e4s24-55 with dissolve
            tf "Wait... you told me I was in."
            tf "You knew I wasn't, didn't you?"
        else:
            scene e4s24-49 with dissolve
            sc "Wait a minute, let you in?"
            sc "I think there's been a misunderstanding."

            scene e4s24-50 with dissolve
            tf "Huh? What do you mean?"

            scene e4s24-51 with dissolve
            sc "Wait, he didn't tell you?"

            stop music fadeout 1.0
            scene e4s24-50 with dissolve
            tf "Tell me what?"

            scene e4s24-52 with dissolve
            sc "Oh my God, haha!"
            sc "I can't believe this."

            scene e4s24-26 with dissolve
            sc "The shit head thought he could sneak you in."

            play music love
            scene e4s24-53 with dissolve
            sc "Look, darling, I hate to be the one to break it to you, but I already told [mc] before that we can't take any more new members."

            scene e4s24-54 with dissolve
            sc "You want my opinion on the guy?"

            scene e4s24-21 with dissolve
            sc "Besides the fact that he lied to you, he's not really boyfriend material."

            scene e4s24-64 with dissolve
            sc "Just have a look at him and you'll be convinced."

            scene e4s24-56 with dissolve
            tf "Wait... you told me I was in."
            tf "You knew I wasn't, didn't you?"

        scene e4s24-57 with dissolve
        mc "I thought I could... I didn't want to just say no."

        scene e4s24-58 with dissolve
        tf "That's not how this works, [mc]..."

        scene e4s24-59 with dissolve
        tf "I can't believe you lied to me!"

        scene e4s24-60 with dissolve
        tf "Why would you do that?"

        scene e4s24-57 with dissolve
        mc "[tf] I... I'm sorry!"
        mc "I didn't mean it like that or to lie to you."
        mc "But [sc] here..."

        scene e4s24-61 with dissolve
        tf "I don't want to talk to you right now."

        scene e4s24-62 with dissolve
        tf "..."

        scene e4s24-59 with dissolve
        tf "I... I have to go."

        stop music fadeout 1.0
        scene e4s24-63 with dissolve
        pause

        scene e4s24-65 with dissolve
        sc "Damn... I almost feel bad for getting involved."

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "What the hell's the matter with you?"

        if affinity_spectrum > 0 and scarlett_trust > 3:
            mc "'Screwed both of us over, and not even in the fun way?'"

            scene e4s24-26 with dissolve
            hide e4s24_scarlett_blink1
            sc "I know right? Real shame."

            scene e4s24-20 with dissolve
            show e4s24_scarlett_blink1
            mc "Thought you'd never let me near your butt."

            scene e4s24-21 with dissolve
            hide e4s24_scarlett_blink1
            sc "And I thought you knew how to take a joke, jeez."

            scene e4s24-20 with dissolve
            show e4s24_scarlett_blink1
            mc "You didn't have to do that."
        else:
            scene e4s24-66 with dissolve
            hide e4s24_scarlett_blink1
            sc "What? Can't I run my own club?"
            sc "I think you're forgetting your place in here, boy."
            sc "You don't get to decide who joins or who doesn't."

            scene e4s24-20 with dissolve
            show e4s24_scarlett_blink1
            mc "But you didn't have to do that."

        scene e4s24-67 with dissolve
        hide e4s24_scarlett_blink1
        sc "Do what? As far as I'm concerned, I've been nothing but nice to the girl."

        scene e4s24-21 with dissolve
        sc "Why would she fall in love with a liar?"

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "But I'm not a liar."

        scene e4s24-21 with dissolve
        hide e4s24_scarlett_blink1
        sc "Then what are you?"
        sc "Didn't you lie to her just now?"

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "Yeah but I... I did it for her."
        mc "She couldn't join any other club and I felt bad for her."
        mc "I wanted to help her out."

        scene e4s24-26 with dissolve
        hide e4s24_scarlett_blink1
        sc "[mc] the savior, that's a new one."

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "Yeah well, it didn't work anyway so thank you."

        scene e4s24-67 with dissolve
        hide e4s24_scarlett_blink1
        sc "Don't thank me, thank yourself!"

        scene e4s24-20 with dissolve
        show e4s24_scarlett_blink1
        mc "Yeah... I'm out of here."

        if affinity_spectrum > 0 and scarlett_trust > 3:
            scene e4s24-69 with dissolve
            hide e4s24_scarlett_blink1
            pause

            scene e4s24-70 with dissolve
            mc "*What's wrong with her?*"

        stop music fadeout 1.0
        scene e4s24-68 with dissolve
        hide e4s24_scarlett_blink1
        pause

        jump e4s25
    else:
        jump e4s25
return
