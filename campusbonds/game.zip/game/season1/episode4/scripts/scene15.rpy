
# Scene 15 - Beach warmth ######################################################

label e4s15:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music river_meditation
    scene e4s15-01 with Dissolve(2.0)
    pause

    scene e4s15-03 with dissolve
    cl "Oh my God, [mc]..."

    scene e4s15-02 with dissolve
    cl "You took me to the beach?"

    scene e4s15-04 with dissolve
    mc "You said I should take you to my favorite place."

    scene e4s15-05 with dissolve
    mc "This... right here, this is it."

    scene e4s15-06 with dissolve
    cl "But nobody's here."

    scene e4s15-07 with dissolve
    mc "I know, right?"
    mc "Perfect timing, nobody's gonna bother us here."

    scene e4s15-09 with dissolve
    cl "Haha, fair enough."

    scene e4s15-08 with dissolve
    cl "This is really beautiful."

    scene e4s15-10 with dissolve
    mc "Yeah, I used to come here with my parents all the time."
    mc "We were living close by so I could come here whenever I wanted."

    scene e4s15-11 with dissolve
    cl "That must have been nice."
    cl "Talk about luck, haha!"

    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s15-15 with Dissolve(2.0)
    pause

    if e4s3_confide == True:
        $ e4s15_confide = True
        call e4s15_confide from _call_e4s15_confide
    else:
        scene e4s15-103 with dissolve
        cl "So... what did you do back home?"

        scene e4s15-13 with dissolve
        show e4s15_cleo_blink1
        mc "Well, I visited my father, went to the movies..."

        if e3s10_cleo_hangout == False and cleo_trust > 3 and e3s21_mad == False:
            pass
        else:
            scene e4s15-94 with dissolve
            hide e4s15_cleo_blink1
            cl "Ohh, what movie?"

            scene e4s15-13 with dissolve
            show e4s15_cleo_blink1
            mc "There's this title that just got a sequel called Forced to Kill."
            mc "My dad and I used to watch it when I was little."

            scene e4s15-95 with dissolve
            hide e4s15_cleo_blink1
            cl "That's so awesome!"

        scene e4s15-18 with dissolve
        cl "So, I take it you had fun?"

        scene e4s15-13 with dissolve
        show e4s15_cleo_blink1
        menu:
            "Tell her":
                $ cleo_intimacy += 1
                $ cleo_trust += 1
                $ e4s15_confide = True

                mc "Yeah... I did and I didn't."
                mc "There's this thing with my dad that happened."
                mc "It's a bit of a long story."

                scene e4s15-102 with dissolve
                hide e4s15_cleo_blink1
                cl "I'm not going anywhere, we have all the time in the world."
                cl "You can tell me."

                scene e4s15-13 with dissolve
                show e4s15_cleo_blink1
                mc "Alright... where do I start."

                scene black with Dissolve(2.0)
                pause(1.0)

                call e4s15_confide from _call_e4s15_confide_1

            "Keep it to yourself":
                mc "Yeah, it was fun."

    scene e4s15-15 with dissolve
    pause

    scene e4s15-104 with dissolve
    mc "Hey, I've been wondering about something."

    scene e4s15-12 with dissolve
    cl "Yeah, what's up?"

    scene e4s15-14 with dissolve
    mc "Your name, [cl], where does it come from?"

    scene e4s15-16 with dissolve
    mc "If you don't mind me asking."

    scene e4s15-17 with dissolve
    cl "It's short for Cleopatra."

    scene e4s15-18 with dissolve
    cl "My nationality is actually Greek, we moved to this country a few years after I was born."

    scene e4s15-13 with dissolve
    show e4s15_cleo_blink1
    mc "Oh, I see."

    scene e4s15-17 with dissolve
    hide e4s15_cleo_blink1
    cl "I don't have any memories from when I was in Greece, but I'd like to revisit my origins someday."

    scene e4s15-24 with dissolve
    mc "That would be really cool!"

    scene e4s15-13 with dissolve
    show e4s15_cleo_blink1
    mc "Do you have any kind of family back there?"

    scene e4s15-18 with dissolve
    hide e4s15_cleo_blink1
    cl "I'm not sure, maybe?"

    scene e4s15-17 with dissolve
    cl "I mean, I was never contacted by anyone from there."

    scene e4s15-12 with dissolve
    cl "But there must be someone who I can meet."

    scene e4s15-13 with dissolve
    show e4s15_cleo_blink1
    mc "Then what are you waiting for?"
    mc "Book a flight for the next break."

    scene e4s15-19 with dissolve
    hide e4s15_cleo_blink1
    cl "It's not that easy, with how busy my life is right now, I don't think that's gonna happen any time soon."

    scene e4s15-20 with dissolve
    cl "Plus, the trip would cost a bit."

    scene e4s15-19 with dissolve
    cl "And what if I don't find anyone there?"

    scene e4s15-96 with dissolve
    mc "I guess you're right..."
    mc "But you could just... you know?"
    mc "Just visit the places you didn't get to see."

    scene e4s15-100 with dissolve
    cl "I don't know..."
    cl "Maybe someday..."

    stop music fadeout 1.0
    scene e4s15-15 with dissolve
    pause

    if e3s24_cleo_path == True:
        play music release
        scene e4s15-21 with dissolve
        mc "Come on, let's get in."

        scene e4s15-22 with dissolve
        cl "Wait, you mean... in the water?"

        scene e4s15-23 with dissolve
        cl "Like, get in, get in?"

        scene e4s15-24 with dissolve
        mc "Haha, yeah, that's what get in means, right?"

        scene e4s15-25 with dissolve
        mc "Come on, it will be fun."

        scene e4s15-26 with dissolve
        cl "But the water must be freezing!"

        scene e4s15-31 with dissolve
        mc "You'll get used to it, trust me."

        scene e4s15-27 with dissolve
        cl "Okay... okay..."
        cl "Let me gather my courage."

        scene e4s15-28 with dissolve
        pause

        scene e4s15-29 with dissolve
        pause

        scene e4s15-30 with dissolve
        pause

        scene e4s15-31 with dissolve
        pause

        scene e4s15-32 with dissolve
        pause

        scene e4s15-33 with dissolve
        pause

        scene e4s15-34 with dissolve
        pause

        scene e4s15-35 with dissolve
        pause
        mc "Come on, you coming?"

        scene e4s15-36 with dissolve
        pause

        scene e4s15-37 with dissolve
        pause

        scene e4s15-38 with dissolve
        pause

        scene e4s15-39 with dissolve
        pause

        scene e4s15-40 with dissolve
        menu:
            "Look at her":
                scene e4s15-42 with dissolve
                pause

                scene e4s15-44 with dissolve
                pause

                scene e4s15-43 with dissolve
                pause

                scene e4s15-46 with dissolve
                pause

                scene e4s15-45 with dissolve
                cl "Hey... don't look at me like that."
                cl "I'm getting shy!"

                scene e4s15-48 with dissolve
                mc "Oh, shit, sorry!"

                scene e4s15-47 with dissolve
                mc "Yeah... take your time."
            "Wait for her":
                $ cleo_trust += 1

                scene e4s15-41 with dissolve
                pause

        scene e4s15-49 with dissolve
        pause

        scene e4s15-50 with dissolve
        mc "So, are you ready?"

        scene e4s15-51 with dissolve
        cl "Honestly? No..."

        scene e4s15-50 with dissolve
        mc "Perfect, let's go!"

        scene e4s15-52 with dissolve
        cl "Hey, it's not fair, you didn't give me a heads up!"

        scene e4s15-53 with dissolve
        pause

        scene black with Dissolve(2.0)
        pause(1.0)

        scene e4s15-55 with Dissolve(2.0)
        cl "[mc], it's freezing!"

        scene e4s15-54 with dissolve
        mc "Haha, don't stand still, put your muscles to work."

        scene e4s15-56 with vpunch
        mc "Warm up a bit."

        scene e4s15-57 with dissolve
        cl "Why did I listen to you..."

        scene e4s15-58 with dissolve
        play sound water_drop
        pause

        scene e4s15-60 with dissolve
        cl "Hey, don't do that!"

        if e4s3_confide == True or e4s15_confide == True:
            menu:
                "Splash her again":
                    $ cleo_intimacy += 1
                    $ cleo_trust += 1

                    scene e4s15-59 with dissolve
                    mc "Do what?"

                    scene e4s15-58 with dissolve
                    play sound water_drop
                    pause

                    scene e4s15-60 with dissolve
                    cl "You asked for it!"

                    scene e4s15-63 with vpunch
                    play sound splash
                    pause

                    scene e4s15-59 with dissolve
                    mc "Oh, yeah?"

                    scene e4s15-61 with dissolve
                    cl "No, no, I was joking!"

                    scene e4s15-62 with dissolve
                    cl "I was joking!!!"

                    scene e4s15-64 with dissolve
                    pause

                    scene e4s15-65 with dissolve
                    mc "Haha, I got you!"

                    scene e4s15-66 with dissolve
                    play sound splash
                    cl "Nooo!"

                    scene e4s15-67 with dissolve
                    play sound splash
                    cl "Aghhh!"
                    cl "Let me go!!"

                    scene e4s15-68 with dissolve
                    mc "How are you feeling up there?"

                    scene e4s15-69 with vpunch
                    play sound punch
                    pause

                    scene e4s15-71 with dissolve
                    pause

                    scene e4s15-72 with dissolve
                    pause

                    scene e4s15-70 with dissolve
                    cl "Oh, shit!!"

                    scene e4s15-73 with dissolve
                    cl "I'm so sorry..."

                    scene e4s15-81 with dissolve
                    cl "Are you alright?"
                    cl "I really didn't mean it."

                    scene e4s15-75 with dissolve
                    menu:
                        "Play it cool":
                            mc "Don't worry, I took harder blows."

                            scene e4s15-74 with dissolve
                            cl "Now I feel bad..."

                            scene e4s15-76 with dissolve
                            cl "It was an accident, I'm sorry."

                            scene e4s15-77 with dissolve
                            mc "Hey, don't worry."
                            mc "It's alright."

                            scene e4s15-75 with dissolve
                            mc "It all happened in the heat of the moment."
                            mc "I know you didn't want to hit me."
                            mc "Speaking of heat, did you manage to warm up a bit?"

                            scene e4s15-80 with dissolve
                            cl "Not really..."

                            scene e4s15-75 with dissolve
                            mc "Maybe a hug will help."

                        "Change the subject":
                            $ cleo_trust += 1

                            mc "Are you still cold?"

                            scene e4s15-77 with dissolve
                            pause

                            scene e4s15-78 with dissolve
                            cl "I hit you in the face and that's what you're gonna ask me?"

                            scene e4s15-79 with dissolve
                            cl "You're not normal..."

                            scene e4s15-77 with dissolve
                            mc "You didn't answer my question though."

                            scene e4s15-75 with dissolve
                            cl "..."

                            scene e4s15-80 with dissolve
                            cl "Yeah... a little bit."

                            scene e4s15-75 with dissolve
                            mc "Maybe it will help if I hug you."

                    scene e4s15-80 with dissolve
                    cl "I think that would be nice."

                    scene e4s15-82 with dissolve
                    pause

                    scene e4s15-83 with dissolve
                    mc "Is this better?"

                    scene e4s15-85 with dissolve
                    cl "A bit, yeah."

                    scene e4s15-86 with dissolve
                    cl "How are you so warm?"

                    scene e4s15-84 with dissolve
                    mc "As I said, you need to move your muscles."
                    mc "Try to get the blood flowing."

                    scene e4s15-85 with dissolve
                    cl "I'm really sorry about earlier."

                    scene e4s15-84 with dissolve
                    mc "Hey, stop stressing your mind over it."
                    mc "We were just having fun, you'd have to hit me harder to leave a dent, haha!"

                    scene e4s15-87 with dissolve
                    cl "Hehe..."

                    scene e4s15-89 with dissolve
                    cl "I really love spending time with you."

                    scene e4s15-90 with dissolve
                    cl "You... you make me feel safe."

                    scene e4s15-87 with dissolve
                    cl "You're... different."

                    scene e4s15-89 with dissolve
                    cl "You actually care, you want to know me."

                    scene e4s15-87 with dissolve
                    cl "It's something I haven't felt in a while."

                    scene e4s15-88 with dissolve
                    mc "I'm glad I can be that special one for you, [cl]."
                    mc "You also get me, I love how you're your own person."
                    mc "You have your dreams, your passions and you're following them."
                    mc "I just want you to know that I respect that."
                    mc "You give this cute warm aura that I just can't get enough of."
                    mc "I love being around you."

                    scene e4s15-91 with dissolve
                    pause

                    scene e4s15-92 with dissolve
                    pause

                    scene e4s15-93 with dissolve
                    pause

                    jump e4s16

                "Don't do it":
                    scene e4s15-59 with dissolve
                    mc "Sorry, I won't do it again."
        else:
            scene e4s15-59 with dissolve
            mc "Right, I'm sorry."

        scene e4s15-105 with dissolve
        cl "Thank you!"

        scene e4s15-106 with dissolve
        pause

        scene e4s15-107 with dissolve
        cl "Sorry... I don't want to seem like a bum."
        cl "But, do you wanna get out?"
        cl "The water is really cold."

        scene e4s15-108 with dissolve
        mc "Is it that cold?"

        scene e4s15-57 with dissolve
        cl "Yeah..."

        scene e4s15-108 with dissolve
        mc "Okay, let's get out."
        mc "You can use the towel on the sand to warm up a bit."

        scene e4s15-57 with dissolve
        cl "Thanks!"

        scene e4s15-109 with dissolve
        pause

    jump e4s16
return


label e4s15_confide:
    if e4s15_confide == True:
        scene e4s15-15 with Dissolve(2.0)
        pause

    scene e4s15-19 with dissolve
    cl "Wait... so you're telling me your father was behind it?"

    scene e4s15-96 with dissolve
    show e4s15_cleo_blink2
    mc "Yeah."

    scene e4s15-97 with dissolve
    hide e4s15_cleo_blink2
    cl "Holy shit, I'm sorry."

    scene e4s15-99 with dissolve
    cl "But talk about the twist."

    scene e4s15-96 with dissolve
    show e4s15_cleo_blink2
    mc "Yeah, I know right?"
    mc "I didn't expect it."
    mc "But maybe I should have seen it coming considering how he'd never talk about her."

    scene e4s15-101 with dissolve
    hide e4s15_cleo_blink2
    cl "You couldn't have known."

    scene e4s15-96 with dissolve
    show e4s15_cleo_blink2
    mc "I don't know what to do with him now."
    mc "Do you think I should forgive him?"

    scene e4s15-97 with dissolve
    hide e4s15_cleo_blink2
    cl "I don't want to sound like I'm downplaying the problem or anything, but I think you should make things right with him."

    scene e4s15-99 with dissolve
    cl "Or, at least, be in a neutral relationship with him."

    scene e4s15-100 with dissolve
    cl "When they're gone, it hurts, really, really bad."

    scene e4s15-98 with dissolve
    cl "You have no idea how many things I have that I wish I could tell my parents right now."
    cl "But I can't, and that hurts like hell."

    scene e4s15-101 with dissolve
    cl "If you don't want it to be like it was before, then don't."

    scene e4s15-19 with dissolve
    cl "But at least stop being mad at him, I think you're hurting yourself more than he's hurting you."

    scene e4s15-100 with dissolve
    cl "From what you told me, he doesn't seem like a terrible father."

    scene e4s15-99 with dissolve
    cl "It seems like he really really cares about you."

    scene e4s15-101 with dissolve
    cl "Maybe give him another chance, let him speak his mind."

    scene e4s15-19 with dissolve
    cl "If that would have been the last day you talked to him, you would have blamed yourself for it."
    cl "And I think that's not fair."

    scene e4s15-100 with dissolve
    cl "You don't have to forgive him right away... but maybe just try to... not hold onto it forever."

    scene e4s15-96 with dissolve
    show e4s15_cleo_blink2
    mc "Thank you [cl]."
    mc "You're right, he's not a bad father, he was pretty great."
    mc "But this thing he did keeps eating at me, it's like he knew how hurt I was about the fact that my mother left."
    mc "And just decided to keep it from me."

    scene e4s15-98 with dissolve
    hide e4s15_cleo_blink2
    cl "Look, I understand your hurt, but maybe he did it to protect you."

    scene e4s15-18 with dissolve
    cl "Maybe he saw that you were hurting, who knows what you would have done back then if he had told you."

    scene e4s15-100 with dissolve
    cl "But, maybe I'm wrong."
    cl "I tend to mess up a lot, but this is what I feel."

    scene e4s15-99 with dissolve
    cl "Just, try to calm down and reflect on this, alright?"

    scene e4s15-102 with dissolve
    cl "You don't have to do it now, let it sit for a while."

    scene e4s15-103 with dissolve
    cl "Let's just enjoy the gorgeous view of this place you brought me to, alright?"

    scene e4s15-15 with dissolve
    pause

    scene e4s15-104 with dissolve
    mc "It really is pretty, isn't it?"
return
