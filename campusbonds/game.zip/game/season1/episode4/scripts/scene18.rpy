
default e4s18_sadie_trustpoint = False

# Scene 18 - Planning ahead ####################################################

label e4s18:
    play music inhale
    scene e4s18-01 with wipeleft
    pause

    scene e4s18-03 with dissolve
    jon "Duude, I'm so bored."

    scene e4s18-02 with dissolve
    jon "I miss having parties in here."

    if affinity_spectrum < 0:
        scene e4s18-07 with dissolve
        mc "But there was a party literally a couple of days ago."

        scene e4s18-04 with dissolve
        jon "Really? Because it feels like an eternity."

        scene e4s18-02 with dissolve
        jon "That's how affected I am."

    scene e4s18-03 with dissolve
    jon "God damn it, [br]... that gremlin... she just ruined all our plans!"

    scene e4s18-05 with dissolve
    mc "I know right?"

    if affinity_spectrum > 0:
        scene e4s18-07 with dissolve
        mc "We can't even party anymore with that milf here..."

        scene e4s18-08 with dissolve
        mc "And I like milfs!"
    else:
        scene e4s18-06 with dissolve
        mc "It's a shame, but what can you do..."

    scene e4s18-09 with dissolve
    pause

    if e4s5_date == True and affinity_spectrum < 0:
        $ sadie_intimacy += 1
        $ e4s18_sadie_trustpoint = True
        scene e4s18-10 with dissolve
        mc "*I wonder if [jon] knows any place I could take [sd] to.*"

        scene e4s18-08 with dissolve
        mc "Hey... uh- [jon]."

        scene e4s18-12 with dissolve
        mc "Could you help me out with something?"

        scene e4s18-14 with dissolve
        jon "Sure dude, what's up?"

        menu:
            "Tell him":
                $ e4s18_sadie_introvert = True
                scene e4s18-13 with dissolve
                mc "So... I'm uh- looking to take [sd] out."

                scene e4s18-12 with dissolve
                mc "And I'd like some advice on a place that could work."

                scene e4s18-15 with dissolve
                jon "Taking things to the next step, I like that!"

            "Keep it to yourself":
                scene e4s18-13 with dissolve
                mc "So... I'm looking to take someone out."

                scene e4s18-12 with dissolve
                mc "And I'd like some advice on a place that could work."

                scene e4s18-14 with dissolve
                jon "Oh... a date!"
                jon "Who's the lucky lady?"

                scene e4s18-13 with dissolve
                mc "It's... someone, you wouldn't know them."

                scene e4s18-15 with dissolve
                jon "She goes to another college, right?"

                scene e4s18-14 with dissolve
                jon "I'm fucking with you, if you don't wanna tell me then fine."

        scene e4s18-11 with dissolve
        jon "Alright, listen up."

        scene e4s18-16 with dissolve
        jon "You want the best place to take a chick out?"
        jon "Take her to this place."

        scene e4s18-14 with dissolve
        jon "10/10, every single date I had there worked out."

        scene e4s18-16 with dissolve
        jon "Great place, great music, sexy women."
        jon "You can't go wrong with it."

        scene e4s18-17 with dissolve
        mc "Nice!"
        mc "How many dates did you take there?"

        scene e4s18-18 with dissolve
        jon "Uh... I don't know."
        jon "Like, two?"

        scene e4s18-19 with dissolve
        mc "Two?!"

        scene e4s18-20 with dissolve
        jon "Yeah dude, the place is expensive, don't give me that look."

        scene e4s18-15 with dissolve
        jon "Besides, 100 percent success rate is still 100 percent success rate."
        jon "Am I right or am I wrong?"

        scene e4s18-21 with dissolve
        mc "I guess you're right..."

        scene e4s18-20 with dissolve
        jon "Trust me bro."
        jon "You want a magical night? You take her there."

        scene e4s18-14 with dissolve
        jon "When have my plans ever failed?"

        scene e4s18-10 with dissolve
        pause

        scene e4s18-21 with dissolve
        mc "Alright... alright."
        mc "I'll trust you on this one."

        scene e4s18-02 with dissolve
        jon "Good, now back to our business."

    scene e4s18-23 with dissolve
    jon "Listen... I've been thinking."

    scene e4s18-22 with dissolve
    jon "And... I think I finally came up with a plan."
    jon "Wanna talk about it now?"

    scene e4s18-12 with dissolve
    mc "Now?"
    mc "What about the others?"

    scene e4s18-22 with dissolve
    jon "We never seem to find a good time for us all to get together."
    jon "I think it's best you and I get started on this now."
    jon "It can't wait anymore."

    scene e4s18-12 with dissolve
    mc "Alright, what do you have in mind?"

    scene e4s18-24 with dissolve
    jon "So... I've been in touch with the cheerleaders..."

    if e4s5_date == True:
        if affinity_spectrum > 0:
            scene e4s18-42 with dissolve
            $ sadie_intimacy += 1
            $ e4s18_sadie_trustpoint = True
            mc "*Ehh... too boring.*"
            mc "*Too fancy.*"
            mc "*Too far.*"
            mc "*Too... good?*"
            mc "*Hold on, what's this one?*"
            mc "*'2Km away', that should be interesting.*"
            mc "*Holy shit, but the price!*"
            mc "*I mean... it's still cheaper than most listings, but damn is it expensive.*"

        if e3s10_sadie_feet == True:
            if e4s18_sadie_trustpoint == False:
                $ sadie_intimacy += 1

            scene e4s18-31 with dissolve
            play sound phone_buzz
            mc "*Huh? A text from [sd].*"

            scene e4s18-27 with dissolve

            nvl clear

            sd_nvl "Hey there, handsome!"
            sd_nvl "These are missing you."

            if persistent.sd_gallery_13_unlocked == False:
                $ persistent.sd_gallery_13_unlocked = True
                $ renpy.show_screen("render_notify")
                $ persistent.sadie13 = True
                python:
                    update_sadie_list()

            sd_nvl "image: phone/sadie/1.webp"

            scene e4s18-31 with dissolve
            mc "*Holy shit!*"
            jon "Yo, are you with me?"

            scene e4s18-32 with dissolve
            mc "Huh?!"

            scene e4s18-35 with dissolve
            jon "The plan?"

            scene e4s18-32 with dissolve
            mc "Yeah, right."

            scene e4s18-36 with dissolve
            jon "I call this..."

            scene e4s18-37 with dissolve
            pause

            scene e4s18-38 with dissolve
            jon "Sabotage, take over and conquer!"
    else:
        if e2s6_sadie_romance == True and e4s5_sadie_mad == False and e3s10_sadie_feet == True:
            if e4s18_sadie_trustpoint == False:
                $ sadie_intimacy += 1

            scene e4s18-31 with dissolve
            play sound phone_buzz
            mc "*Huh? A text from [sd].*"

            scene e4s18-27 with dissolve

            nvl clear

            sd_nvl "Hey there, handsome!"
            sd_nvl "These are missing you."

            if persistent.sd_gallery_13_unlocked == False:
                $ persistent.sd_gallery_13_unlocked = True
                $ renpy.show_screen("render_notify")
                $ persistent.sadie13 = True
                python:
                    update_sadie_list()

            sd_nvl "image: phone/sadie/1.webp"

            scene e4s18-31 with dissolve
            mc "*Holy shit!*"
            jon "Yo, are you with me?"

            scene e4s18-32 with dissolve
            mc "Huh?!"

            scene e4s18-35 with dissolve
            jon "The plan?"

            scene e4s18-32 with dissolve
            mc "Yeah, right."

            scene e4s18-36 with dissolve
            jon "I call this..."

            scene e4s18-37 with dissolve
            pause

            scene e4s18-38 with dissolve
            jon "Sabotage, take over and conquer!"
        elif e3s24_cleo_path == True:
            $ cleo_intimacy += 1
            scene e4s18-25 with dissolve
            play sound phone_buzz
            pause

            scene e4s18-26 with dissolve
            pause

            scene e4s18-27 with dissolve

            nvl clear

            cl_nvl "Heyy!"
            n_nvl "Helloo!"
            cl_nvl "What are you up to?"
            n_nvl "Currently nothing."
            n_nvl "What about you?"
            cl_nvl "I was thinking about watching a movie."
            cl_nvl "Would you like to join me?"
            n_nvl "I'd love to, but unfortunately [jon]'s keeping me captive here."
            cl_nvl "Oh, no!"
            cl_nvl "Hopefully he's not keeping you on his couch."

            scene e4s18-28 with dissolve
            jon "Yo, are you with me?"

            scene e4s18-30 with dissolve
            mc "*Chuckles*"

            scene e4s18-35 with dissolve
            jon "Yo, [mc]!"

            scene e4s18-29 with dissolve
            jon "The plan?"

            scene e4s18-33 with dissolve
            mc "Yeah, right."

            scene e4s18-27 with dissolve
            n_nvl "Wait a second, I think [jon]'s just showing me something."
            cl_nvl "Okay, okay."

            scene e4s18-36 with dissolve
            jon "I call this..."

            scene e4s18-37 with dissolve
            pause

            scene e4s18-38 with dissolve
            jon "Sabotage, take over and conquer!"

            scene e4s18-27 with dissolve
            if affinity_spectrum > 0:
                n_nvl "Holy shit, he's got a black board with everything in detail!"
            else:
                n_nvl "He's even got a black board with everything in detail!"

            scene e4s18-39 with dissolve
            jon "Are you looking?"
            jon "Put down that stupid phone."

            scene e4s18-27 with dissolve
            n_nvl "Oh my God, he's even telling me to put down my phone."
            n_nvl "Must be getting serious now."
            cl_nvl "Haha!"

            scene e4s18-40 with dissolve
            jon "[mc]!"

            scene e4s18-34 with dissolve
            mc "Yeah, right, I'm here."

            scene e4s18-27 with dissolve
            n_nvl "Talk to you later."
        elif francesca_trust > 4:
            $ francesca_intimacy += 1
            scene e4s18-25 with dissolve
            play sound phone_buzz
            pause

            scene e4s18-26 with dissolve
            pause

            scene e4s18-27 with dissolve

            nvl clear

            fr_nvl "Hiii"
            n_nvl "Hey!"
            fr_nvl "What are you up to?"
            n_nvl "[jon]'s trying to make me do something."
            fr_nvl "Hopefully nothing illegal."
            n_nvl "You never know!"

            if e4s11_help == True:
                fr_nvl "I'm excited about tomorrow night."
                n_nvl "Yeah, me too!"
                n_nvl "Hopefully I get out in one piece tonight."

            n_nvl "Just... don't believe anything you're gonna see on the news, alright?"

            scene e4s18-28 with dissolve
            jon "Yo, are you with me?"

            scene e4s18-30 with dissolve
            mc "*Chuckles*"

            scene e4s18-35 with dissolve
            jon "Yo, [mc]!"

            scene e4s18-29 with dissolve
            jon "The plan?"

            scene e4s18-33 with dissolve
            mc "Yeah, right."

            scene e4s18-27 with dissolve
            n_nvl "Wait a second, I think [jon]'s just showing me something."
            fr_nvl "Okay."

            scene e4s18-36 with dissolve
            jon "I call this..."

            scene e4s18-37 with dissolve
            pause

            scene e4s18-38 with dissolve
            jon "Sabotage, take over and conquer!"

            scene e4s18-27 with dissolve
            if affinity_spectrum > 0:
                n_nvl "Holy shit, he's got a black board with everything in detail!"
            else:
                n_nvl "He's even got a black board with everything in detail!"

            scene e4s18-39 with dissolve
            jon "Are you looking?"
            jon "Put down that stupid phone."

            scene e4s18-27 with dissolve
            n_nvl "Oh my God, he's even telling me to put down my phone."
            n_nvl "Must be getting serious now."
            fr_nvl "Haha!"

            scene e4s18-40 with dissolve
            jon "[mc]!"

            scene e4s18-34 with dissolve
            mc "Yeah, right, I'm here."

            scene e4s18-27 with dissolve
            n_nvl "Talk to you later."
        else:
            scene e4s18-30 with dissolve
            mc "*Hah, look at this guy.*"
            mc "*Gosh, that's so embarrassing!*"
            mc "*How does he keep getting inside stores with that box over his head?*"
            mc "*I remember when he used to cosplay as an elf, haha.*"

            scene e4s18-28 with dissolve
            jon "Yo, are you with me?"

            scene e4s18-30 with dissolve
            mc "*Chuckles*"

            scene e4s18-35 with dissolve
            jon "Yo, [mc]!"

            scene e4s18-41 with dissolve
            mc "Huh?"

            scene e4s18-29 with dissolve
            jon "The plan?"

            scene e4s18-33 with dissolve
            mc "Yeah, right."

            scene e4s18-36 with dissolve
            jon "I call this..."

            scene e4s18-37 with dissolve
            pause

            scene e4s18-38 with dissolve
            jon "Sabotage, take over and conquer!"

    scene e4s18-43 with dissolve
    jon "So, what do you think?"

    scene e4s18-44 with dissolve
    jon "Cool, right?"
    jon "I made it myself."

    scene e4s18-45 with dissolve
    pause

    scene e4s18-46 with dissolve
    mc "Yeah... no wonder."

    scene e4s18-47 with dissolve
    pause

    scene e4s18-48 with dissolve
    pause

    scene e4s18-49 with dissolve
    mc "Entrepreneur, playboy, criminal mastermind?"

    scene e4s18-52 with dissolve
    mc "Man, you're barely alive."

    scene e4s18-53 with dissolve
    mc "What's with that description?"

    scene e4s18-54 with dissolve
    jon "Just, get in the role, alright?"

    scene e4s18-48 with dissolve
    pause

    scene e4s18-51 with dissolve
    mc "Why the..."

    scene e4s18-50 with dissolve
    mc "Why the fuck is my description just a donkey head?"

    scene e4s18-55 with dissolve
    jon "Don't get lost in the details, my friend."

    scene e4s18-56 with dissolve
    jon "This, right here, is what's important."

    scene e4s18-68 with dissolve
    jon "You said that [kv] wants to take over the clubs by becoming president, right?"

    scene e4s18-57 with dissolve
    show e4s18_jon_blink1
    mc "Right."

    scene e4s18-61 with dissolve
    hide e4s18_jon_blink1
    jon "So, it's simple, we sabotage his candidature."

    scene e4s18-57 with dissolve
    show e4s18_jon_blink1
    mc "And how are we doing this exactly?"

    scene e4s18-60 with dissolve
    hide e4s18_jon_blink1
    jon "Well, I didn't lay down everything yet."

    scene e4s18-61 with dissolve
    jon "I was thinking of just writing as we go."

    scene e4s18-59 with dissolve
    jon "But the plan is simple, we're gonna make his life a living hell."

    scene e4s18-62 with dissolve
    jon "He's going to wish he didn't candidate."
    jon "And this... this is just phase one."

    scene e4s18-57 with dissolve
    show e4s18_jon_blink1
    mc "God help us all."

    scene e4s18-61 with dissolve
    hide e4s18_jon_blink1
    jon "It all starts with us going to his place."

    if e4s5_date == True:
        scene e4s18-63 with dissolve
        mc "*Hmm... let's get back to the date with [sd].*"

        scene e4s18-64 with dissolve
        mc "*Do I have enough money for it?*"

        if money > 2:
            scene e4s18-63 with dissolve
            mc "*Yeah, this should be enough.*"
        else:
            scene e4s18-65 with dissolve
            mc "*Damn... I don't have enough.*"

            scene e4s18-63 with dissolve
            mc "*What should I do now?*"
            mc "*Maybe I can ask someone for some cash.*"

            menu:
                "[jon]" if jon_friendship > 3:
                    $ e4s18_ask_option = 1
                    scene e4s18-66 with dissolve
                    if affinity_spectrum > 0:
                        $ e4s18_sadie_extrovert = True
                        mc "Hey man, could you help me out with something?"

                        scene e4s18-67 with dissolve
                        jon "What's up?"

                        scene e4s18-57 with dissolve
                        show e4s18_jon_blink1
                        mc "I'm a bit tight on money and I'm taking someone out on a date."

                        scene e4s18-59 with dissolve
                        hide e4s18_jon_blink1
                        jon "Look at you speaking like a real man."

                        scene e4s18-58 with dissolve
                        jon "Who's the lucky lady, huh?"

                        scene e4s18-57 with dissolve
                        show e4s18_jon_blink1
                        mc "I'm taking [sd] out."

                        scene e4s18-61 with dissolve
                        hide e4s18_jon_blink1
                        jon "Taking things to the next step, I like that!"
                    else:
                        mc "Hey... regarding the place we spoke about earlier."
                        mc "With the date and all."

                        scene e4s18-57 with dissolve
                        show e4s18_jon_blink1
                        mc "Could you help me out with some money?"
                        mc "I didn't realize how expensive it will be and it doesn't really fit in my budget."

                    scene e4s18-58 with dissolve
                    hide e4s18_jon_blink1
                    jon "Of course I'll help you."
                    jon "Can't leave a brother hanging like that."

                    scene e4s18-68 with dissolve
                    $ renpy.show_screen("money_notify_pers")
                    jon "Here, take this and keep the change."
                    $ money += 3
                    $ renpy.show_screen("money_notify")
                    $ renpy.hide_screen("money_notify_pers")

                    scene e4s18-67 with dissolve
                    jon "Make me proud."

                    scene e4s18-57 with dissolve
                    show e4s18_jon_blink1
                    mc "Thanks man!"
                    mc "I'll owe you one."

                    scene e4s18-58 with dissolve
                    hide e4s18_jon_blink1
                    jon "Don't mention it."
                    jon "So... you coming?"

                    scene e4s18-57 with dissolve
                    show e4s18_jon_blink1
                    mc "Sure, like I got anything better to do."

                    hide e4s18_jon_blink1
                "[jd]" if e4s14_forgive == True:
                    $ e4s18_ask_option = 2
                    mc "*Maybe [jd] can help me.*"
                    mc "*Can't hurt to ask if his uncle needs any help around the pizzeria for a day or two.*"
                    mc "*I'll talk to him tomorrow.*"

                    scene e4s18-43 with dissolve
                    jon "So... you coming?"

                    scene e4s18-66 with dissolve
                    mc "Huh?"
                    mc "Sure, like I got anything better to do."
                "Dad":
                    $ e4s18_ask_option = 3
                    mc "..."
                    mc "*I'm not sure about this one.*"
                    mc "*Considering how things are between us, I don't want him to think I'm only reaching out when I need money.*"
                    mc "*I'll talk to him tomorrow.*"

                    scene e4s18-43 with dissolve
                    jon "So... you coming?"

                    scene e4s18-66 with dissolve
                    mc "Huh?"
                    mc "Sure, like I got anything better to do."
                "Find another way":
                    $ e4s18_ask_option = 4
                    scene e4s18-65 with dissolve
                    mc "*Ah, screw it!*"

                    scene e4s18-63 with dissolve
                    mc "*I'll find another way.*"
                    mc "*None of these options feel right.*"

                    scene e4s18-43 with dissolve
                    jon "So... you coming?"

                    scene e4s18-66 with dissolve
                    mc "Huh?"
                    mc "Sure, like I got anything better to do."

    jump e4s19
return
