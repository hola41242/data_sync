
# Scene 30 - Plan B ############################################################

label e4s30:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music sun_sets_on_a_protagonist
    scene e4s30-01 with Dissolve(2.0)
    pause

    scene e4s30-03 with dissolve
    pause

    scene e4s30-02 with dissolve
    jon "Now... what's with this College Rock club and you?"

    scene e4s30-05 with dissolve
    jon "I mean... why do you still hang out with them?"

    scene e4s30-04 with dissolve
    mc "Because I'm learning an instrument?"

    scene e4s30-06 with dissolve
    mc "And I can't say I'm a hundred percent decided on which one to choose."

    scene e4s30-03 with dissolve
    pause

    scene e4s30-02 with dissolve
    jon "Why not?"
    jon "I thought you'd stick with us."

    scene e4s30-06 with dissolve
    mc "I am, but I'm just choosing a different club."

    scene e4s30-05 with dissolve
    jon "Then how is that sticking with us?"

    scene e4s30-07 with dissolve
    jon "You'll barely have time for this club."

    scene e4s30-04 with dissolve
    mc "It's not like anything's happening in here anymore, with [br] and stuff."

    scene e4s30-07 with dissolve
    jon "Yeah... fair."

    scene e4s30-08 with dissolve
    jon "..."

    scene e4s30-05 with dissolve
    jon "But, how is it there?"

    scene e4s30-09 with dissolve
    mc "Come on man, what's with all the questions?"

    scene e4s30-13 with dissolve
    jon "I'm just trying to understand."
    jon "What do you guys do there daily?"

    scene e4s30-06 with dissolve
    mc "Well, first of all, it's a club full of girls."

    scene e4s30-10 with dissolve
    jon "Aaaahaa! Haha, you sneaky bastard."
    jon "Why didn't you say so from the get-go?"
    jon "Now I get it!"

    scene e4s30-11 with dissolve
    mc "Haha, no man, it's not like that."

    if affinity_spectrum > 0:
        scene e4s30-12 with dissolve
        mc "Although there are some pretty girls, that's not the reason."

    scene e4s30-04 with dissolve
    mc "Back when I was mad at you, one of my friends introduced me to that club."

    scene e4s30-06 with dissolve
    mc "So, I thought it would be a good opportunity to get a new perspective, you know?"
    mc "Besides [ev] and [eva], everyone's friendly."

    scene e4s30-13 with dissolve
    jon "What's up with [eva]?"

    scene e4s30-07 with dissolve
    jon "I know about [ev], she's the creepy librarian."

    if e3f1_drum == True or e3f1_option == 3:
        scene e4s30-06 with dissolve
        mc "Let's just say I once tried her drums and she almost punched me."

        scene e4s30-16 with dissolve
        jon "Didn't think a girl would have the upper hand on you."

        scene e4s30-14 with dissolve
        mc "I don't think you'd like me to remind you-"

        scene e4s30-15 with dissolve
        jon "Bhababa-"
        jon "Anyway..."

        scene e4s30-07 with dissolve
    else:
        scene e4s30-14 with dissolve
        mc "Let's just say I have a friend who once tried her drums, it didn't end well."

        scene e4s30-16 with dissolve
        jon "She's one of those, huh?"

        scene e4s30-12 with dissolve
        mc "More or less, yeah."

        scene e4s30-07 with dissolve
        jon "Anyway..."

    jon "I think I got the picture."

    scene e4s30-16 with dissolve
    jon "Let's get back to our business."

    scene e4s30-10 with dissolve
    jon "Now THIS plan..."
    jon "...this can't fail, not a chance."

    scene e4s30-04 with dissolve
    mc "What do you have in mind?"

    scene e4s30-16 with dissolve
    jon "Well, it's simple."
    jon "We'll give them something they cannot bury."
    jon "We're gonna put laxatives inside his drink, right before he has to present his candidacy again."

    scene e4s30-10 with dissolve
    jon "This way, it's going to kick in right as he is on stage, it should have all the people's eyes on him."

    scene e4s30-14 with dissolve
    mc "Wow, you really did think this through, didn't you?"

    scene e4s30-13 with dissolve
    jon "I take this very seriously man..."

    scene e4s30-07 with dissolve
    jon "That... and I wasn't in the mood to study."

    scene e4s30-12 with dissolve
    mc "So this is what too much free time does to a person, huh?"

    scene e4s30-16 with dissolve
    jon "At least I'm not wasting it like you."

    scene e4s30-14 with dissolve
    mc "Who says I'm wasting it?"

    scene e4s30-16 with dissolve
    jon "Anyway, I'm the one who came up with the plan, which means you're the one putting it into action."

    scene e4s30-17 with dissolve
    mc "What? Why me?"

    scene e4s30-13 with dissolve
    jon "Dude, I just told you."
    jon "Stop being slow and just get it done."

    scene e4s30-17 with dissolve
    mc "What if I get caught?"

    scene e4s30-16 with dissolve
    jon "I assume you still know how to fight, right?"

    scene e4s30-06 with dissolve
    mc "Yeah... I do."

    scene e4s30-04 with dissolve
    mc "What does that have to do with anything?"

    scene e4s30-13 with dissolve
    jon "You'll know if you slip up, just try to be as sneaky as you can."

    scene e4s30-04 with dissolve
    mc "So, how am I supposed to do it exactly?"

    scene e4s30-16 with dissolve
    jon "You're going to sit in the backstage and wait."
    jon "I'll make sure he gets a coffee or something, have someone bring it to him."
    jon "You'll be dressed up formally, like you're his servant."

    scene e4s30-17 with dissolve
    mc "But I don't want to be his servant."
    mc "What if he recognizes me?"

    scene e4s30-13 with dissolve
    jon "You don't have to be, just grab the coffee before anyone else does, slip in the laxatives, and hand it off to the real servant."

    scene e4s30-16 with dissolve
    jon "You're also gonna wear an earpiece and I'll guide you."

    scene e4s30-18 with dissolve
    jon "It's just a matter of in and out, come on I'm doing the groundwork here."

    scene e4s30-06 with dissolve
    mc "Dude, as much as I'd like to help... I really can't."

    scene e4s30-04 with dissolve
    mc "I've got to attend College Rock today."

    scene e4s30-15 with dissolve
    jon "Alright... don't worry about it."
    jon "I'll take care of your club situation."

    scene e4s30-04 with dissolve
    mc "How?"

    scene e4s30-16 with dissolve
    jon "Just... leave it to me, alright?"
    jon "Go ahead and get changed, I'll text you."

    scene e4s30-04 with dissolve
    mc "Alright."

    jump e4s31
return
