
# Scene 11 - Chill park day (Tuesday) ##########################################

label e4s11:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music flowers
    scene e4s11-01 with Dissolve(2.0)
    mc "I've never been to this park before."
    mc "When was this built?"

    scene e4s11-02 with dissolve
    fr "I don't know, I think about a year ago."

    scene e4s11-03 with dissolve
    fr "It's pretty recent."
    fr "The new mayor seems to be doing his job."

    scene e4s11-04 with dissolve
    mc "Yeah, for sure."

    scene e4s11-05 with dissolve
    mc "Missed you yesterday at College Rock."
    mc "Where were you?"

    if francesca_trust < 3:
        scene e4s11-06 with dissolve
        fr "I... wasn't feeling too well."
        fr "Probably caught the flu or something."
        fr "I'm better now, but I'll have to be careful about it."

        scene e4s11-07 with dissolve
        mc "I see."
    else:
        if e4s8_text == True:
            mc "I couldn't keep texting you because [ev] told me to stop."

            scene e4s11-16 with dissolve
            fr "Oh, haha!"
            fr "I understand."

            scene e4s11-17 with dissolve
            fr "Just some arguments with my dad."
        else:
            scene e4s11-06 with dissolve
            fr "I had a fight with my dad."

            scene e4s11-17 with dissolve
            fr "I wasn't in the mood to go to College Rock anymore, so I stayed home."

    scene e4s11-18 with dissolve
    fr "Wanna sit down here?"

    scene e4s11-19 with dissolve
    mc "Sure thing."

    scene e4s11-08 with dissolve
    pause

    scene e4s11-09 with dissolve
    fr "I saw [am] again last weekend around College Rock."

    scene e4s11-20 with dissolve
    mc "What was she doing there?"

    scene e4s11-11 with dissolve
    fr "I was left to rearrange some of the old instruments."
    fr "And she paid me a visit asking me how I was and stuff."

    scene e4s11-12 with dissolve
    fr "I don't trust her one bit."

    scene e4s11-10 with dissolve
    show e4s11_francesca_blink1
    mc "Why is she coming in and out of College Rock?"

    scene e4s11-20 with dissolve
    hide e4s11_francesca_blink1
    mc "Shouldn't there be a rule against that?"

    scene e4s11-15 with dissolve
    fr "There kind of is, she isn't allowed in there."

    scene e4s11-14 with dissolve
    fr "But, I mean, I was already there."
    fr "She couldn't really pull anything with me there, but still, just having her around pisses me off."

    scene e4s11-10 with dissolve
    show e4s11_francesca_blink1
    mc "Why don't you tell [ev] about it?"

    scene e4s11-12 with dissolve
    hide e4s11_francesca_blink1
    fr "I don't know..."

    scene e4s11-21 with dissolve
    fr "Do you think I should?"

    scene e4s11-10 with dissolve
    show e4s11_francesca_blink1
    menu:
        "Tell [ev]":
            $ e4s11_tell = True
            mc "Yeah, I really think you should."
            mc "It seems like she's bothering you."

            scene e4s11-14 with dissolve
            hide e4s11_francesca_blink1
            fr "I just... don't want us to be affected by her."

            scene e4s11-15 with dissolve
            fr "I'll probably just talk to [ev] about this and let her sort it out."

            scene e4s11-10 with dissolve
            show e4s11_francesca_blink1
            mc "Probably for the best, yeah."

        "Don't tell [ev]":
            mc "Nah, you're right."
            mc "Let's not overreact yet."
            mc "As long as she's not alone in there, it's probably fine."

            scene e4s11-12 with dissolve
            hide e4s11_francesca_blink1
            fr "Yeah."

    scene e4s11-13 with dissolve
    hide e4s11_francesca_blink1
    fr "From now on, we should probably lock the place."
    fr "So far, no one's been interested in our place so we didn't have any reason to lock it."

    scene e4s11-12 with dissolve
    fr "But I wouldn't want [am] to steal our stuff."

    scene e4s11-15 with dissolve
    fr "Or worse..."

    scene e4s11-08 with dissolve
    mc "*It sounds like [fr]'s really bothered by [am].*"

    scene e4s11-35 with dissolve
    mc "*Should I tell her about what happened in the bathroom?*"
    mc "*She doesn't seem to be in the best mood right now.*"

    menu:
        "Confess to [fr]":
            $ e4s11_confess = True
            scene e4s11-20 with dissolve
            mc "There's something I've been sitting on since Friday, and I think you deserve to know."

            scene e4s11-11 with dissolve
            fr "What's up?"

            scene e4s11-20 with dissolve
            mc "It's about [am]... and it's... not good."
            mc "Last Friday, before I arrived to College Rock."
            mc "I actually got there earlier than usual because I didn't have my phone on me."
            mc "She walked in on me and was all flirty and stuff."
            mc "Of course, I told her off and she left."
            mc "Then, when I went to the bathroom..."

            if e3s19_amber_lewd == False:
                if affinity_spectrum > 0:
                    mc "That crazy bitch walked into my stall."
                else:
                    mc "She just walked into my stall!"
                    mc "She's seriously messed up."

                mc "I snapped at her and told her to leave."
                mc "That wasn't normal."
            else:
                mc "She entered my stall."

                scene e4s11-22 with dissolve
                fr "What the hell?"
                fr "What happened next?"

                scene e4s11-35 with dissolve
                mc "*Shit... she's not reacting well...*"
                mc "*Maybe I should stop here before I make things worse.*"
                scene e4s11-37 with dissolve
                mc "*I'll probably have to leave the next part for another time.*"

                scene e4s11-23 with dissolve
                mc "I told her to leave."
                mc "She is crazy!"

            scene e4s11-24 with dissolve
            fr "That fucking psycho!"

            scene e4s11-25 with dissolve
            fr "She knows she can't beat us, so she's trying to crawl under our skin instead."

            scene e4s11-26 with dissolve
            fr "When I see her..."

            if e3s19_amber_lewd == True:
                scene e4s11-27 with dissolve
                mc "Wow... let's not do anything rash now."
                mc "She's not worth it."
                fr "..."

                scene e4s11-28 with dissolve
                fr "Yeah... you're right."
            else:
                scene e4s11-27 with dissolve
                fr "..."

            scene e4s11-22 with dissolve
            fr "Just be careful around her from now on, alright?"

            scene e4s11-24 with dissolve
            fr "I don't want her to get into our minds, not now."
            fr "She can be slippery at times."

            scene e4s11-28 with dissolve
            fr "I don't think there's a soul in there anymore."

            scene e4s11-24 with dissolve
            fr "I didn't think she'd go so low as to try to sabotage us through you."
            fr "That's just pathetic."

            if e3s19_amber_lewd == True:
                scene e4s11-35 with dissolve
                mc "*The way she talks about Amber... I'm not sure how she'd ever forgive me if she knew what happened.*"

            menu:
                "Reassure her":
                    $ e4s11_reassure = True
                    $ francesca_trust += 1
                    scene e4s11-10 with dissolve
                    show e4s11_francesca_blink1
                    mc "Don't worry [fr]."
                    mc "I promise I'll be careful."
                    mc "I've got your back."

                    scene e4s11-30 with dissolve
                    hide e4s11_francesca_blink1
                    mc "[am]'s games aren't going to mess with me, or with us."

                    scene e4s11-29 with dissolve
                    fr "Thanks [mc]."

                    scene e4s11-31 with dissolve
                    fr "It feels good to have you through this."

                    scene e4s11-32 with dissolve
                    pause

                    scene e4s11-34 with dissolve
                    pause

                    scene e4s11-33 with dissolve
                    mc "Hey, I don't want to be intrusive or anything."

                "Say nothing":
                    mc "..."

        "Don't tell her":
            scene e4s11-37 with dissolve
            mc "*I'll probably upset her more by what I have to say.*"
            mc "*I'll keep it to myself for now.*"

    if francesca_trust > 3:
        scene e4s11-10 with dissolve
        show e4s11_francesca_blink1
        if e4s11_reassure == False:
            mc "Hey, I don't want to be intrusive or anything."
        mc "But what happened with you and your father?"
        mc "I know you said you had a fight with him but didn't say the reason."

        scene e4s11-12 with dissolve
        hide e4s11_francesca_blink1
        fr "Yeah..."

        scene e4s11-36 with dissolve
        fr "It's the same old argument every single time."

        scene e4s11-26 with dissolve
        fr "He keeps pushing me to take over his business after I graduate."
        fr "And I keep telling him no, I am not fit for it."

        scene e4s11-24 with dissolve
        fr "I don't like it, I don't want to do it."

        scene e4s11-25 with dissolve
        fr "What's so hard to understand?"

        scene e4s11-23 with dissolve
        mc "That sounds exhausting, honestly."
        mc "Is he the kind of guy who ever backs down, or...?"
        mc "What happens if you don't take over?"

        scene e4s11-12 with dissolve
        fr "I don't know..."

        scene e4s11-24 with dissolve
        fr "But I really don't want to find out."

        scene e4s11-14 with dissolve
        fr "He usually backs down after I make my point clear."

        scene e4s11-38 with dissolve
        fr "But after some time he comes back thinking I've changed my mind or something."

        scene e4s11-10 with dissolve
        show e4s11_francesca_blink1
        mc "So what are you gonna do then?"

        scene e4s11-11 with dissolve
        fr "I'm gonna keep telling him no."

        scene e4s11-15 with dissolve
        fr "Maybe he'll eventually change his mind."

        scene e4s11-10 with dissolve
        show e4s11_francesca_blink1
        mc "What if he doesn't?"

        scene e4s11-14 with dissolve
        hide e4s11_francesca_blink1
        fr "I'm going to figure it out, I guess..."

        scene e4s11-11 with dissolve
        fr "Right now, College Rock's the only thing that feels like mine."

        scene e4s11-12 with dissolve
        fr "It might be my only shot at doing something that's actually mine."

        scene e4s11-10 with dissolve
        show e4s11_francesca_blink1
        mc "Yeah, that seems like a really good plan."

    scene e4s11-15 with dissolve
    hide e4s11_francesca_blink1
    fr "Anyway, leaving this aside..."

    scene e4s11-29 with dissolve
    fr "How's business class going for you?"

    scene e4s11-31 with dissolve
    fr "I remember you needing help with it a couple of days ago."

    scene e4s11-30 with dissolve
    mc "Yeah... I still don't get some concepts."
    mc "I don't think I'm cut out to be a businessman, haha!"
    mc "I just want to pass it and get it over with."

    scene e4s11-29 with dissolve
    fr "My dad leaves town in a couple of days to attend some meetings."
    fr "If you're still stuck, we could go over it at my place, but it's kind of now or never."
    fr "I'm gonna be pretty busy the next few days so I think that's my only window left."

    scene e4s11-30 with dissolve
    menu:
        "Accept [fr]'s help":
            $ e4s11_help = True
            $ francesca_trust += 1
            mc "That would be pretty cool!"

            scene e4s11-40 with dissolve
            fr "Haha, yeah."

            scene e4s11-39 with dissolve
            fr "By the time we're finished, you'll be the best businessman this town's ever seen!"

            scene e4s11-41 with dissolve
            if affinity_spectrum > 0:
                mc "Even bigger than you?"

                scene e4s11-39 with dissolve
                fr "Let's not get ahead of ourselves."

                scene e4s11-41 with dissolve
                mc "Haha!"
            else:
                mc "Haha, let's not exaggerate now!"

        "Turn her down":
            mc "I appreciate the help but I think I'm good."
            mc "The last time really helped me a lot."
            mc "I think I'm capable of doing it alone."

            scene e4s11-31 with dissolve
            fr "Alright, you know best."

    if e4s11_reassure == True and e3s19_amber_lewd == False:
        stop music fadeout 1.0
        scene e4s11-32 with dissolve
        pause
    else:
        stop music fadeout 1.0
        scene e4s11-08 with dissolve
        pause

    jump e4s12
return
