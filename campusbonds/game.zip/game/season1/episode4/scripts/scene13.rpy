
# Scene 13 - A new date ########################################################

label e4s13:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    $renpy.sound.play("audio/sfx/diner_ambient.ogg", loop=True)
    scene e4s13-01 with Dissolve(2.0)
    pause

    play music circles
    scene e4s13-02 with dissolve
    mc "Hey, is this seat taken?"

    scene e4s13-03 with dissolve
    cl "Haha, no, go ahead."

    scene e4s13-05 with dissolve
    mc "Thanks!"

    scene e4s13-09 with dissolve
    pause

    scene e4s13-04 with dissolve
    show e4s13_cleo_blink1
    mc "How have you been?"

    scene e4s13-06 with dissolve
    hide e4s13_cleo_blink1
    cl "Same as usual, classes and work."
    cl "What about you?"

    scene e4s13-04 with dissolve
    show e4s13_cleo_blink1
    mc "Classes as well, and some other things I've been caught up with [jon]."

    scene e4s13-07 with dissolve
    hide e4s13_cleo_blink1
    cl "Haha, he better not be making you sleep on his couch again."

    scene e4s13-04 with dissolve
    show e4s13_cleo_blink1
    mc "Oh my God, don't even remind me."
    mc "I feel pain every time I think about it."

    scene e4s13-08 with dissolve
    hide e4s13_cleo_blink1
    cl "Haha!"

    scene e4s13-04 with dissolve
    show e4s13_cleo_blink1
    if e3s24_cleo_path == True:
        $ e4s13_cleo_hangout = True
        mc "Sorry, I've been meaning to talk to you about that hangout we mentioned over text."
        mc "We could talk about it now if you're still interested."

        scene e4s13-12 with dissolve
        hide e4s13_cleo_blink1
        cl "Sure, don't stress your mind about it."

        scene e4s13-06 with dissolve
        cl "I have been pretty busy myself so it's alright."
        cl "Do you have anything in mind?"

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        mc "Honestly, not really."
        mc "I haven't been able to explore the city since I got here."

        scene e4s13-11 with dissolve
        hide e4s13_cleo_blink1
        cl "Hmm..."

        scene e4s13-07 with dissolve
        cl "Hey, I got a pretty nice idea."

        scene e4s13-12 with dissolve
        cl "You said you lived here before, right?"
        cl "Why don't you take me to your favorite place from then?"

        scene e4s13-06 with dissolve
        cl "I'm curious about the kind of person you were back then."

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        mc "Hey, that's actually not a bad idea."
        mc "If I can still find it, we should be able to have a nice date there."

        scene e4s13-07 with dissolve
        hide e4s13_cleo_blink1
        cl "So it's all set then!"

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        mc "How does today sound?"
        mc "I'm free in a couple of hours."

        scene e4s13-12 with dissolve
        hide e4s13_cleo_blink1
        cl "Yeah, that sounds nice."
        cl "I'm free too."

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        mc "Great!"

    if e3s10_cleo_hangout == False and cleo_trust > 2 and e3s21_mad == False:
        mc "I actually went back home this weekend."
        mc "I visited my dad."

        scene e4s13-07 with dissolve
        hide e4s13_cleo_blink1
        cl "You did?"
        cl "That's so cool!"

        scene e4s13-06 with dissolve
        cl "How did he feel about seeing you?"

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        mc "He was pretty happy, yeah."
        mc "We went to see this movie called 'Forced to Kill'."
        mc "He had a blast."

        scene e4s13-07 with dissolve
        hide e4s13_cleo_blink1
        cl "I'm happy for you!"

        scene e4s13-04 with dissolve
        show e4s13_cleo_blink1
        menu:
            "Propose to hang out":
                $ cleo_trust += 1
                $ e4s13_cleo_hangout = True

                mc "What do you say we do something fun later?"

                scene e4s13-12 with dissolve
                hide e4s13_cleo_blink1
                cl "Sure [mc]!"
                cl "Do you have anything in mind?"

                scene e4s13-04 with dissolve
                show e4s13_cleo_blink1
                mc "Honestly, not really."
                mc "I haven't been able to explore the city since I got here."

                scene e4s13-11 with dissolve
                hide e4s13_cleo_blink1
                cl "Hmm..."

                scene e4s13-07 with dissolve
                cl "Hey, I got a pretty nice idea."

                scene e4s13-12 with dissolve
                cl "You said you lived here before, right?"
                cl "Why don't you take me to your favorite place from then?"

                scene e4s13-06 with dissolve
                cl "I'm curious about the kind of person you were back then."

                scene e4s13-04 with dissolve
                show e4s13_cleo_blink1
                mc "Hey, that's actually not a bad idea."
                mc "If I can still find it, we should be able to have a nice date there."

                scene e4s13-07 with dissolve
                hide e4s13_cleo_blink1
                cl "Great!"

            "Leave it for another time":
                mc "*Maybe later.*"
                mc "I kinda wish your happiness could be transferred to this meal right now."
                mc "It's not looking great."

                scene e4s13-07 with dissolve
                hide e4s13_cleo_blink1
                cl "Haha, we don't really have a choice, do we?"

                scene e4s13-04 with dissolve
                show e4s13_cleo_blink1
                mc "I guess you're right..."

    jump e4s14
return
