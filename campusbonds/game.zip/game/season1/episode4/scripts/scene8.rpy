
# Scene 8 - College Rock #######################################################

label e4s8:
    play music laurel_breeze
    scene e4s8-01 with wipeleft
    pause

    scene e4s8-02 with dissolve
    mc "*Shit, I'm late for College Rock!*"
    mc "*Hope [ev]'s not gonna be too mad about it.*"

    scene e4s8-03 with dissolve
    pause

    stop music fadeout 1.0
    scene e4s8-04 with dissolve
    ev "Look who's finally decided to join us."

    play music serenity
    scene e4s8-05 with dissolve
    mc "Sorry! I kind of lost track of the time."

    scene e4s8-06 with dissolve
    ev "You better start tracking it because I won't accept slackers here."

    scene e4s8-07 with dissolve
    ev "Go to your instrument."

    scene e4s8-05 with dissolve
    mc "[fr]'s not here today?"

    scene e4s8-07 with dissolve
    ev "No, she's dealing with some personal problems."

    scene e4s8-05 with dissolve
    mc "I understand."

    scene e4s8-08 with dissolve
    pause

    scene e4s8-09 with dissolve
    pause

    scene e4s8-10 with dissolve
    mc "Hey [al]!"

    scene e4s8-11 with dissolve
    al "Oh, hi [mc]!"

    scene e4s8-12 with dissolve
    al "Didn't know you were joining us today."

    scene e4s8-13 with dissolve
    mc "Yeah, sorry for being late."

    scene e4s8-15 with dissolve
    al "Haha, don't apologize to me!"

    scene e4s8-21 with dissolve
    al "I kinda have the same habit of running late."

    scene e4s8-16 with dissolve
    al "Thankfully, [ev] isn't too upset about it."

    scene e4s8-14 with dissolve
    mc "Can't say the same for me."

    scene e4s8-19 with dissolve
    al "Don't worry, I'm sure she'll warm up to you eventually."

    scene e4s8-14 with dissolve
    mc "Eventually..."

    scene e4s8-18 with dissolve
    al "I see [fr]'s not here today."

    scene e4s8-17 with dissolve
    mc "Yeah... I don't really know where she is."
    mc "[ev] hasn't been very helpful."

    scene e4s8-20 with dissolve
    al "I see."

    scene e4s8-19 with dissolve
    al "Well... I'll be on my way."

    scene e4s8-17 with dissolve
    menu:
        "Practice with [al]":
            $ e4s8_alice_practice = True
            $ alice_trust += 1
            mc "Wait, do you wanna practice with me?"

            scene e4s8-21 with dissolve
            al "Sure, if that's alright with you."

            scene e4s8-17 with dissolve
            mc "Yeah, it's not a problem."
            mc "Doing it alone is a bit depressing."

            scene e4s8-15 with dissolve
            al "Haha, I can tell!"

            scene e4s8-16 with dissolve
            al "Alright, let's start then."

        "Practice alone":
            mc "See you!"

            scene e4s8-22 with dissolve
            pause

            scene e4s8-23 with dissolve
            mc "*Hmm... I wonder what's up with [fr].*"
            mc "*Maybe I should leave her a text.*"

            menu:
                "Leave her a text":
                    $ e4s8_text = True
                    $ francesca_trust += 1
                    $ evelyn_trust -= 1

                    scene e4s8-24 with dissolve
                    mc "*I'll leave her a text.*"

                    nvl clear

                    scene e4s8-25 with dissolve

                    n_nvl "Hey Francesca, what's up?"
                    n_nvl "Everything okay?"
                    n_nvl "Haven't seen you in practice today."

                    fr_nvl "Hey!"
                    fr_nvl "Yeah, I'm fine."
                    fr_nvl "Couldn't make it today."

                    scene e4s8-26 with dissolve
                    ev "More practicing, less playing on the phone."

                    scene e4s8-27 with dissolve
                    mc "But I wasn't playing."

                    scene e4s8-28 with dissolve
                    ev "Then what were you doing on it?"

                    scene e4s8-29 with dissolve
                    menu:
                        "Texting [fr]":
                            $ e4s8_evelyn_practice = True
                            scene e4s8-30 with dissolve
                            mc "I was texting [fr] to see what's wrong with her."

                            scene e4s8-31 with dissolve
                            ev "Why do you care?"

                            scene e4s8-32 with dissolve
                            mc "Because she's my partner?"
                            mc "And we're practicing together?"

                            scene e4s8-31 with dissolve
                            ev "Is that so?"

                            scene e4s8-28 with dissolve
                            ev "Then I guess you won't mind partnering up with me."

                            scene e4s8-27 with dissolve
                            mc "Nope, not at all."

                            scene e4s8-30 with dissolve
                            mc "In fact, I might learn a thing or two."

                            scene e4s8-29 with dissolve
                            ev "Interesting..."

                            scene e4s8-33 with dissolve
                            ev "Let's see what you know so far."

                        "Texting a friend":
                            scene e4s8-30 with dissolve
                            mc "I was texting a friend."
                            mc "We had something to take care of."

                            scene e4s8-33 with dissolve
                            ev "You can do that after we're finished here."

                            scene e4s8-32 with dissolve
                            mc "Okay, okay, I'll put it away."

                            scene e4s8-35 with dissolve
                            pause

                        "Playing":
                            call extrovert_affinity_check from _call_extrovert_affinity_check_73
                            call color_check from _call_color_check_142
                            $ evelyn_trust -= 1

                            scene e4s8-27 with dissolve
                            mc "Alright, you caught me."
                            mc "I was playing on it."
                            mc "I'll put it away now."

                            scene e4s8-34 with dissolve
                            pause

                            scene e4s8-35 with dissolve
                            pause

                "Ask [ev]":
                    scene e4s8-37 with dissolve
                    pause

                    scene e4s8-36 with dissolve
                    mc "*Let's ask [ev].*"

                    scene e4s8-38 with dissolve
                    mc "Hey [ev]!"

                    scene e4s8-39 with dissolve
                    mc "Sorry to bother you, I was wondering why [fr] isn't here today."

                    scene e4s8-40 with dissolve
                    mc "Do you know anything about her?"

                    scene e4s8-41 with dissolve
                    ev "No, I don't."

                    scene e4s8-42 with dissolve
                    ev "What's it to you?"

                    scene e4s8-40 with dissolve
                    mc "Oh... um..."

                    menu:
                        "No partner":
                            $ e4s8_evelyn_practice = True
                            $ evelyn_trust += 1
                            mc "I don't have anyone to help me with the guitar."
                            mc "That's why I'm asking."

                            scene e4s8-42 with dissolve
                            ev "Is that really the reason?"

                            scene e4s8-40 with dissolve
                            mc "Yeah... I don't have any knowledge in music so I don't feel comfortable playing by myself yet."

                            scene e4s8-43 with dissolve
                            ev "Alright, I suppose I could help you out."

                            scene e4s8-44 with dissolve
                            ev "At least you're trying."

                            scene e4s8-40 with dissolve
                            mc "Thanks!"

                        "Care about [fr]":
                            call introvert_affinity_check from _call_introvert_affinity_check_65
                            call color_check from _call_color_check_143
                            mc "Well... I care about her."
                            mc "I just wanted to know if she's fine."

                            scene e4s8-45 with dissolve
                            ev "Well, maybe you should start caring more about playing that guitar."

                            scene e4s8-46 with dissolve
                            ev "You're here to practice not to date."

                            scene e4s8-40 with dissolve
                            mc "That's not what I meant..."

                            scene e4s8-45 with dissolve
                            ev "Then what did you mean?"

                            scene e4s8-40 with dissolve
                            mc "I meant to ask about her well being, that's all."
                            mc "Why all the drama?"
                            mc "Can't you just tell me what's wrong with her?"

                            scene e4s8-46 with dissolve
                            ev "It's personal, so unless she tells you about it herself, you're not finding out."

                            scene e4s8-40 with dissolve
                            mc "Fine..."

                "Practice":
                    mc "*I'll keep practicing.*"

    scene black with Dissolve(2.0)
    pause(1.0)

    if e4s8_evelyn_practice == True:
        scene e4s8-47 with Dissolve(2.0)
        pause

        if music_skills > 4 or guitar_skills > 1:
            scene e4s8-48 with dissolve
            ev "I'm impressed! You managed to improve a lot in a week."
            ev "Keep this up and you'll have a spot in the competition."

            scene e4s8-50 with dissolve
            ev "I see [fr]'s doing a great job."

            scene e4s8-49 with dissolve
            mc "Yeah, she's a good teacher."

            scene e4s8-51 with dissolve
            mc "Hey, also..."

            scene e4s8-60 with dissolve
            mc "I hope you don't mind me asking this..."
            mc "But what's this competition you keep mentioning really about?"
            mc "Like... what are we actually supposed to do?"

            scene e4s8-58 with dissolve
            ev "It's a stage performance."
            ev "You go up on the stage and perform a song."

            scene e4s8-60 with dissolve
            mc "'You'?"

            scene e4s8-59 with dissolve
            ev "Yeah, I don't take part in it."

            scene e4s8-58 with dissolve
            ev "I'm only allowed to guide and teach, not play."

            scene e4s8-60 with dissolve
            mc "Yeah, I guess that makes sense."
            mc "So, is there any trophy or what's the reward for doing so?"
            mc "Is it just for gaining experience?"

            scene e4s8-58 with dissolve
            ev "There is a trophy that the club gets."
            ev "We have multiple of them showcased."

            scene e4s8-60 with dissolve
            mc "Oh, that's where they're from?"

            scene e4s8-48 with dissolve
            ev "Yeah, every single one of them has been earned through different competitions."

            scene e4s8-50 with dissolve
            ev "We might not have a big club but we sure fought for every one of them."

            scene e4s8-49 with dissolve
            mc "That's really nice, congratulations!"
            mc "Let's win this one as well, right?"

            scene e4s8-48 with dissolve
            ev "Hopefully, yeah."

            scene e4s8-48 with dissolve
            ev "I've got to go now..."

            scene e4s8-48 with dissolve
            ev "Nice work today!"

            scene e4s8-51 with dissolve
            pause

            scene e4s8-52 with dissolve
            menu:
                "Thank her":
                    call extrovert_affinity_check from _call_extrovert_affinity_check_74
                    call color_check from _call_color_check_144

                    $ evelyn_trust += 1

                    scene e4s8-53 with dissolve
                    mc "Hey, thanks [ev]!"

                    scene e4s8-54 with dissolve
                    mc "Your guidance really helped me today."

                    scene e4s8-55 with dissolve
                    pause

                "Stay quiet":
                    call introvert_affinity_check from _call_introvert_affinity_check_66
                    call color_check from _call_color_check_145

                    scene e4s8-57 with dissolve
                    mc "..."
        else:
            scene e4s8-58 with dissolve
            ev "Okay... you were decent today, but there's still room for growth."

            scene e4s8-59 with dissolve
            ev "Although, that's to be expected since you only started a week ago."

            scene e4s8-58 with dissolve
            ev "Maybe it will be in time for the competition, who knows?"

            scene e4s8-60 with dissolve
            mc "Yeah, we'll have to see."

            scene e4s8-48 with dissolve
            ev "Keep this up!"

            scene e4s8-51 with dissolve
            mc "Hey, also..."

            scene e4s8-60 with dissolve
            mc "I hope you don't mind me asking this..."
            mc "But what's this competition you keep mentioning really about?"
            mc "Like... what are we actually supposed to do?"

            scene e4s8-58 with dissolve
            ev "It's a stage performance."
            ev "You go up on the stage and perform a song."

            scene e4s8-60 with dissolve
            mc "'You'?"

            scene e4s8-59 with dissolve
            ev "Yeah, I don't take part in it."

            scene e4s8-58 with dissolve
            ev "I'm only allowed to guide and teach, not play."

            scene e4s8-60 with dissolve
            mc "Yeah, I guess that makes sense."
            mc "So, is there any trophy or what's the reward for doing so?"
            mc "Is it just for gaining experience?"

            scene e4s8-58 with dissolve
            ev "There is a trophy that the club gets."
            ev "We have multiple of them showcased."

            scene e4s8-60 with dissolve
            mc "Oh, that's where they're from?"

            scene e4s8-48 with dissolve
            ev "Yeah, every single one of them has been earned through different competitions."

            scene e4s8-50 with dissolve
            ev "We might not have a big club but we sure fought for every one of them."

            scene e4s8-49 with dissolve
            mc "That's really nice, congratulations!"
            mc "Let's win this one as well, right?"

            scene e4s8-50 with dissolve
            ev "Hopefully, yeah."

            scene e4s8-56 with dissolve
            pause

    if e4s8_alice_practice == True:
        scene e4s8-61 with Dissolve(2.0)
        pause

        scene e4s8-62 with dissolve
        pause

        scene e4s8-63 with dissolve
        pause

        scene e4s8-64 with dissolve
        mc "Hey so... a bit of a weird question."
        mc "Out of the blue."

        scene e4s8-65 with dissolve
        al "What's up?"

        scene e4s8-66 with dissolve
        mc "Why haven't you ever practiced with me and [fr] before?"
        mc "I mean, we both play the guitar, right?"

        scene e4s8-67 with dissolve
        al "I don't know."

        scene e4s8-68 with dissolve
        al "I guess I just thought you and [fr] were a thing, since you hung out so much."

        scene e4s8-67 with dissolve
        al "I didn't wanna interfere."

        scene e4s8-66 with dissolve
        menu:
            "We're a thing" if e3s24_francesca_lewd == True:
                $ e4s8_confess_alice = True
                mc "We're not official yet but I believe we're getting there."
                mc "I don't think you would have interfered though."

            "We're not":
                mc "We're not a thing."
                mc "We just happen to get along well."
                mc "Also, she's the one who introduced me here so I think it's natural that I spent the most time with her."

                scene e4s8-69 with dissolve
                al "Haha, when you put it like that it makes a lot more sense now."

                scene e4s8-66 with dissolve
                mc "Yeah, we're just friends."

        mc "Having another perspective on the guitar could be helpful."
        mc "Another pair of eyes means fewer chances for mistakes."

        scene e4s8-69 with dissolve
        al "Haha, I guess you're right!"

        scene e4s8-66 with dissolve
        mc "Also, I think that while I'm here, we should try to stay on good terms."
        mc "Without any unwanted tension."

        scene e4s8-67 with dissolve
        al "Yeah, I totally agree with that."

        scene e4s8-68 with dissolve
        al "Being a band, we have to learn each other's styles."

        scene e4s8-70 with dissolve
        al "The more united we are, the better music we can produce."

        scene e4s8-68 with dissolve
        al "Have you had the chance to talk to the other girls?"

        scene e4s8-66 with dissolve
        mc "A little bit."

        if e3f1_drum == True or e3f1_option == 3:
            mc "[eva]'s been giving me a bit of a hard time."

            scene e4s8-69 with dissolve
            al "Haha! You tried to play the drums?"

            scene e4s8-66 with dissolve
            if e3f1_drum == True:
                mc "Yeah, it didn't end well."
                mc "I think she hates me."

                scene e4s8-69 with dissolve
                al "Haha, rookie mistake!"

                scene e4s8-67 with dissolve
                al "I don't think she hates you."

                scene e4s8-70 with dissolve
                al "She just wants you to stay away from the drums."

                scene e4s8-66 with dissolve
                mc "Yeah, point made clear."
            else:
                mc "No, but I asked [pe] about them, and it didn't go well."

                scene e4s8-69 with dissolve
                al "Haha, at least you didn't try them!"

                scene e4s8-67 with dissolve
                al "I tried that, and it didn't really end well."

                scene e4s8-69 with dissolve
                al "But she'll adjust, don't worry."

            scene e4s8-66 with dissolve
            mc "Other than that, they've been pretty nice to me."

            scene e4s8-69 with dissolve
            al "I'm happy to hear that!"

        else:
            mc "They've been pretty nice to me."

            scene e4s8-69 with dissolve
            al "I'm happy to hear that!"
            al "Glad you didn't make the mistake of playing [eva]'s drums!"

            scene e4s8-66 with dissolve
            mc "Haha, why?"
            mc "What would have happened?"

            scene e4s8-67 with dissolve
            al "Let's just say it's better that you didn't."

        scene e4s8-66 with dissolve
        mc "When did you join this club?"

        scene e4s8-71 with dissolve
        al "Hmm... honestly not that long ago either."

        scene e4s8-68 with dissolve
        al "I'm lucky because I've been playing the guitar ever since I was a little kid."
        al "So I didn't need much introduction."

        scene e4s8-66 with dissolve
        mc "Except for the incident with [eva], haha!"

        scene e4s8-69 with dissolve
        al "Except for that, yeah!"

        scene e4s8-70 with dissolve
        al "But yeah, overall it was pretty easy."
        al "I think [ev] is also expecting me to take part in the competition."

        scene e4s8-67 with dissolve
        al "As you can see, we don't have a lot of members available, so..."

        scene e4s8-66 with dissolve
        mc "What's this competition really about?"
        mc "I heard a lot of stuff about it."

        scene e4s8-68 with dissolve
        al "Oh... it's just a stage performance, I guess."
        al "We go up on stage and perform a song."

        scene e4s8-67 with dissolve
        al "Honestly, it isn't that important to the club itself."

        scene e4s8-70 with dissolve
        al "If you manage to shine there and people really notice you, you could get opportunities for deals and whatnot."
        al "But that's pretty rare, you have to be really, really good."

        scene e4s8-67 with dissolve
        al "I honestly don't try that hard, I just want to have fun doing it."

        scene e4s8-66 with dissolve
        mc "That's interesting."
        mc "So no trophies, or what?"

        scene e4s8-68 with dissolve
        al "There is a trophy that the club gets, but there's no prize money or anything."
        al "At least not that I know of, or that we could get any."

        scene e4s8-66 with dissolve
        mc "So it's mostly for gaining experience."

        scene e4s8-67 with dissolve
        al "Yeah, you could say that."

        scene e4s8-66 with dissolve
        mc "Anyway, I think I've kept you from playing long enough."
        mc "What do you say we get back to it?"

        scene e4s8-69 with dissolve
        al "Sure thing!"
        al "That's the spirit!"

        scene e4s8-61 with dissolve
        pause

        scene black with Dissolve(2.0)
        pause(1.0)

    scene e4s8-23 with dissolve
    play sound phone_buzz
    pause

    scene e4s8-24 with dissolve
    pause

    nvl clear

    scene e4s8-25 with dissolve
    jn_nvl "Hey [mc]."
    jn_nvl "You there?"

    n_nvl "Yeah, what's up?"

    jn_nvl "I need you at the Party Ragers."
    jn_nvl "It's about what we talked earlier."
    jn_nvl "Meet me there, alright?"

    n_nvl "Sure, I'm omw."

    jump e4s9
return
