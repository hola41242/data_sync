
# Scene 3 - Unexpected visitor #################################################

label e4s3:
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s3-75 with Dissolve(2.0)
    pause

    scene e4s3-77 with dissolve
    mc "*Is that...*"

    play music hollow_grove
    scene e4s3-76 with dissolve
    mc "*[sc]?*"

    scene e4s3-78 with dissolve
    pause

    scene e4s3-79 with dissolve
    mc "[sc]?"

    scene e4s3-80 with dissolve
    sc "In the flesh."

    scene e4s3-82 with dissolve
    mc "You reek of alcohol!"

    scene e4s3-83 with dissolve
    sc "Loud and proud, baby!"

    scene e4s3-84 with dissolve
    mc "Hey, be careful!"
    mc "You're gonna fall."

    scene e4s3-81 with dissolve
    mc "Come on, let me help you."

    scene e4s3-85 with dissolve
    sc "Ey, leave me alone!"

    scene e4s3-86 with dissolve
    sc "I don't need your help."

    scene e4s3-87 with dissolve
    mc "Yeah, yeah, sure."

    scene e4s3-88 with dissolve
    sc "Leave me alone, duude..."

    scene e4s3-89 with dissolve
    sc "I don't even know you."

    scene e4s3-90 with dissolve
    mc "Where do you live?"

    scene e4s3-80 with dissolve
    sc "The streets. I'm like a nomad with better taste in liquor."

    if affinity_spectrum < 0:
        scene e4s3-91 with dissolve
        pause

        scene e4s3-92 with dissolve
        mc "*Yeah, that checks out.*"

    scene e4s3-87 with dissolve
    mc "*What the hell am I gonna do with you now?*"
    mc "*I can't leave her here, right?*"

    if affinity_spectrum < 0:
        scene e4s3-92 with dissolve
        mc "*I really hope [nt]'s not at the dorm right now. I have no idea how I'm gonna explain this.*"

    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s3-01 with Dissolve(2.0)
    pause
    mc "*Fuck... she's heavy!*"

    scene e4s3-02 with dissolve
    pause

    scene e4s3-03 with dissolve
    sc "You're trying to bang me or what?"

    scene e4s3-04 with dissolve
    if affinity_spectrum > 0:
        mc "Nah."
    else:
        mc "Trust me, that's the last thing on my mind right now."

    scene e4s3-06 with dissolve
    sc "Oh, why?"
    sc "Am I not attractive enough for you?"

    scene e4s3-05 with dissolve
    mc "No, it's not that."

    scene e4s3-08 with dissolve
    sc "So I'm attractive?"

    scene e4s3-07 with dissolve
    sc "That's really nice, I'm so happy!"

    scene e4s3-09 with dissolve
    mc "Just, lie in bed and try to get some rest."

    scene e4s3-10 with dissolve
    mc "I'm gonna bring you some water."

    scene e4s3-11 with dissolve
    sc "How about another beer?"

    if affinity_spectrum > 0:
        scene e4s3-12 with dissolve
        mc "Yeah, right."
        mc "How about a joint as well?"

        scene e4s3-13 with dissolve
        sc "Now, that's more like it!"

    scene e4s3-20 with dissolve
    sc "Wait, but who's this?"
    sc "I should know who's about to bang me, right?"

    if affinity_spectrum > 0:
        scene e4s3-12 with dissolve
        mc "Haha, I told you, I'm not gonna bang you."
    else:
        scene e4s3-13 with dissolve
        mc "..."

    scene e4s3-14 with dissolve
    mc "It's [mc]."

    scene e4s3-20 with dissolve
    sc "[mc]?!"

    scene e4s3-15 with dissolve
    sc "Damn, you were probably the last person I would have expected right now."

    scene e4s3-16 with dissolve
    mc "Oh, why is that?"

    scene e4s3-17 with dissolve
    sc "I don't know..."

    scene e4s3-18 with dissolve
    sc "Maybe... because I treated you like crap? Haha!"

    scene e4s3-17 with dissolve
    sc "Damn, maybe I do deserve to be banged."

    scene e4s3-19 with dissolve
    mc "Here, drink some water."

    scene e4s3-21 with dissolve
    menu:
        "Continue":
            $ scarlett_trust += 1
            $ e4s3_kiss = True
            scene e4s3-kiss1 with dissolve
            pause

            scene e4s3-kiss2 with dissolve
            pause

            scene e4s3-23 with dissolve
            sc "Take off your clothes..."

            scene e4s3-24 with dissolve
            mc "[sc], you're drunk!"

            scene e4s3-25 with dissolve
            sc "..."

        "Pull back":
            scene e4s3-22 with dissolve
            pause

            scene e4s3-24 with dissolve
            mc "[sc]..."

    scene e4s3-26 with dissolve
    sc "You're good at kissing too?"

    scene e4s3-27 with dissolve
    sc "What is this boy not good at..."

    scene e4s3-28 with dissolve
    mc "What do you mean?"

    scene e4s3-29 with dissolve
    sc "Don't think I haven't heard how people are talking about you."

    scene e4s3-30 with dissolve
    sc "[mc]'s doing this, [mc]'s doing that."

    scene e4s3-31 with dissolve
    if affinity_spectrum > 0:
        sc "Banging left and right."
    else:
        sc "Too bad you're not that extroverted."

        scene e4s3-17 with dissolve
        sc "That's one area you're lacking in."

        scene e4s3-18 with dissolve
        sc "Although, there's one more 'area' I haven't checked yet."

    scene e4s3-32 with dissolve
    sc "Maybe you are as good as they say."

    scene e4s3-35 with dissolve
    mc "Who's saying all of this?"

    scene e4s3-33 with dissolve
    sc "I don't know, I'm too drunk for this shit."
    sc "If you wanna bang me, now's your chance, you're not getting any closer than this."

    scene e4s3-34 with dissolve
    sc "So be quick, or slow, or whatever."

    scene e4s3-33 with dissolve
    sc "I'm going to sleep."

    if affinity_spectrum > 0:
        scene e4s3-35 with dissolve
        mc "You don't have to tell me twice."

        scene e4s3-37 with dissolve
        sc "Haha, see, that's what I like about you!"
        sc "You get my humor."
        sc "And you complete it."

        scene e4s3-33 with dissolve
        sc "Too bad though..."

        scene e4s3-35 with dissolve
        mc "Too bad what?"
        sc "..."
        mc "[sc]?"
        sc "Zzz..."
        mc "*You bitch.*"
    else:
        scene e4s3-32 with dissolve
        mc "*What's wrong with her?*"

    scene e4s3-36 with dissolve
    pause

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    call e4s3_lewd from _call_e4s3_lewd

    stop music
    scene e4s3-50 with vpunch
    pause

    play music with_a_whimper
    scene e4s3-51 with dissolve
    mc "Yo, what's up?"
    mc "You came back to life, or what?"

    scene e4s3-52 with dissolve
    sc "Where am I and what am I doing here?"

    scene e4s3-53 with dissolve
    mc "Man, you tell me!"

    scene e4s3-54 with dissolve
    if affinity_spectrum > 0:
        mc "You were drunker than a motherfucking squirrel on a vodka binge."
    else:
        mc "I had to drag you here because of how drunk you were."

    scene e4s3-55 with dissolve
    mc "What's up?"

    scene e4s3-56 with dissolve
    sc "Fuck... my head hurts."

    if affinity_spectrum > 0:
        scene e4s3-57 with dissolve
        mc "I'm honestly surprised it's only the head that hurts."
    else:
        scene e4s3-55 with dissolve
        mc "Yeah, I bet."

    scene e4s3-58 with dissolve
    sc "Did you do something to me, pervert?"

    if affinity_spectrum > 0:
        scene e4s3-57 with dissolve
        mc "Oh, absolutely."

        scene e4s3-59 with dissolve
        mc "I was this close to following your 'very clear' instructions about banging you... but then I realized, you wouldn't even remember it."

        scene e4s3-60 with dissolve
        mc "Of course I didn't do anything to you, what kind of animal do you take me for?"

        scene e4s3-58 with dissolve
        sc "You're a scumbag."

        scene e4s3-60 with dissolve
        mc "And you're a bitch, welcome to the club!"
    else:
        scene e4s3-61 with dissolve
        mc "God no!"

    scene e4s3-62 with dissolve
    sc "I'm gonna get out of here before someone gets the wrong idea."

    if affinity_spectrum > 0:
        scene e4s3-63 with dissolve
        mc "Yeah, thank God."
        mc "I can only imagine the rumors that would start if anyone saw me with you."

        scene e4s3-66 with dissolve
        mc "By the way, the door is in that direction!"

        scene e4s3-65 with dissolve
        mc "Make yourself out."

        scene e4s3-64 with dissolve
        pause

        scene e4s3-71 with dissolve
        sc "Guh!"
    else:
        scene e4s3-65 with dissolve
        mc "You should be thanking me!"

        scene e4s3-63 with dissolve
        mc "I didn't leave you on the streets."

        scene e4s3-64 with dissolve
        pause

        scene e4s3-67 with dissolve
        sc "Oh yeah, thank *you*!"

        scene e4s3-68 with dissolve
        sc "Real lifesaver, aren't you?"

        scene e4s3-69 with dissolve
        sc "What? Are you expecting a fucking trophy?"

        scene e4s3-70 with dissolve
        sc "Idiot."

    scene e4s3-72 with vpunch
    play sound door_close
    pause
    mc "*People these days...*"
    mc "*Can't be grateful of anything you do for them.*"

    if e3s24_cleo_path == True:
        scene e4s3-73 with dissolve
        play sound phone_buzz
        pause

        scene e4s3-74 with dissolve
        pause

        nvl clear

        cl_nvl "Hey handsome!"

        mc "*Wow...*"

        menu (nvl = True):
            "Compliment her":
                $ cleo_trust += 2
                n_nvl "Hello to you too, pretty!"
                cl_nvl "How was the trip home? ^^"
            "Tease her":
                $ cleo_trust += 1
                n_nvl "Handsome?"
                cl_nvl "What? Too soon?"
                cl_nvl ":X"
                n_nvl "Haha, no, I'm just teasing you."
                n_nvl "Hello to you too, pretty!"
                cl_nvl "Phew."
                cl_nvl "How was the trip home?"

        scene e4s3-93 with dissolve
        if e3s29_hate == True:
            mc "*Honestly... not that good.*"
        else:
            mc "*Honestly... mixed.*"

        mc "*But what do I tell her?*"

        menu (nvl = True):
            "Fine":
                n_nvl "It was mostly fine."
                cl_nvl "I'm glad!"
                cl_nvl "I hope your dad was happy to see you."
                n_nvl "More than happy, yeah."
                n_nvl "He really enjoyed the movie and my presence."
                cl_nvl "That's good to hear!"
            "Bad":
                $ e4s3_confide = True

                $ cleo_intimacy += 1
                $ cleo_trust += 1
                n_nvl "It didn't really go that well..."
                cl_nvl "Oh... why? What happened?"
                n_nvl "A lot actually."
                n_nvl "More like I ended up finding out a lot."
                cl_nvl "Hope it's not all bad news."
                n_nvl "It kind of is."
                cl_nvl "I'm here if you want to talk."
                n_nvl "Thanks [cl]!"
                n_nvl "Maybe not over text."
                cl_nvl "Yeah, of course."
                cl_nvl "Whenever you want, I'll be glad to listen."
            "Avoid the subject":
                n_nvl "You know... like any other trip."
                cl_nvl "Come on!! I wanna hear all about it."
                n_nvl "There's not a lot to say about it, really!"
                n_nvl "I was gone for only 2 days."

                if cleo_trust > 4:
                    cl_nvl "Alright, I get it, but I'm here if you want to talk later."

                cl_nvl "I hope your dad was happy to see you."
                n_nvl "More than happy, yeah."
                cl_nvl "That's good to hear!"

        menu (nvl = True):
            "Ask about her weekend":
                $ cleo_trust += 1
                n_nvl "How was your weekend?"
                cl_nvl "Filled with work mostly."
                cl_nvl "The diner was swarmed with clients."
                n_nvl "Oh, I'm sorry to hear that."
                cl_nvl "It's fine, at least I made some nice money from tips."
                n_nvl "Did you have any other problems there?"
                n_nvl "Like with [da]?"
                cl_nvl "No, it was alright."
                cl_nvl "He didn't bother me this time."
                n_nvl "Great!"
                cl_nvl "Anyway, I gtg [mc], my class is coming up."
                cl_nvl "Talk to you later!"

                menu (nvl = True):
                    "Send a heart":
                        $ cleo_trust += 1
                        n_nvl "<3"
                        cl_nvl "<3"

                    "Leave her on seen":
                        pass

            "End the conversation":
                n_nvl "Anyway, I'll talk to you later [cl]."
                n_nvl "I've got some stuff to do."
                cl_nvl "Okay! :)"

    stop music fadeout 1.0
    if e2f2_tiffany_refuse == False:
        jump e4s4
    else:
        jump e4s5
return

label e4s3_lewd:
    if persistent.disable_nsfw == True or persistent.disable_nsfw == False and persistent.type_nsfw == False:
        play music ariana_grande_synthet
        scene e4s3-38 with Dissolve(2.0)
        pause

        scene e4s3-40 with dissolve
        unknown "Come on baby, how long until I see you?"

        scene e4s3-39 with dissolve
        sc "I'll be there in a bit."

        scene e4s3-41 with dissolve
        sc "Be patient, will you?"

        scene e4s3-40 with dissolve
        unknown "You know I can't spend a minute without you."

        scene e4s3-42 with dissolve
        unknown "You and your hot body."

        scene e4s3-39 with dissolve
        sc "How much do you want me?"
        sc "I want to hear you say it."

        scene e4s3-42 with dissolve
        unknown "I want you the most baby."
        unknown "Your cologne, it is intoxicating."
        unknown "I'd rail you every single day of the week."

        scene e4s3-40 with dissolve
        sc "Hearing you speak like that makes me so wet."
        unknown "Then don't keep me waiting, jump into my arms."

        scene e4s3-43 with dissolve
        pause

        scene e4s3-44 with dissolve
        pause

        scene e4s3-45 with dissolve
        pause

        if persistent.disable_nsfw == True:
            scene e4s3-46 with dissolve
            pause

            scene e4s3-47 with dissolve
            sc "I'm ready!"

            scene e4s3-48 with dissolve
            mc "You are so hot baby..."
            mc "I can barely keep my boner in check."

            scene e4s3-49 with dissolve
            sc "Huh? [mc]?!?"
        else:
            if persistent.type_nsfw == False:
                scene e4s3-46_cen with dissolve
                pause

                scene e4s3-47_cen with dissolve
                sc "I'm ready!"

                scene e4s3-48_cen with dissolve
                mc "You are so hot baby..."
                mc "I can barely keep my boner in check."

                scene e4s3-49_cen with dissolve
                sc "Huh? [mc]?!?"

        if _in_replay:
            scene e4s3-50 with vpunch
            pause

    $ renpy.end_replay()
return
