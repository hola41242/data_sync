
# Scene 20 - The Last Hit (Thursday) ###########################################

label e4s20:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    play music little_tomcat
    scene e4s20-14 with Dissolve(2.0)
    pause

    scene e4s20-15 with dissolve
    pause

    play sound phone_buzz
    scene e4s20-16 with vpunch
    pause

    scene e4s20-17 with dissolve
    pause

    scene e4s20-18 with dissolve
    mc "What's up?"

    scene e4s20-19 with dissolve
    show e4s20_mc_blink1
    jon "It didn't work, bro!"

    scene e4s20-20 with dissolve
    hide e4s20_mc_blink1
    mc "What?"
    mc "What didn't work?"

    scene e4s20-19 with dissolve
    show e4s20_mc_blink1
    jon "They must have buried the news or something."
    jon "Nobody knows about [kv]'s little incident."

    scene e4s20-18 with dissolve
    hide e4s20_mc_blink1
    mc "But we made sure the cops get to his house..."

    scene e4s20-20 with dissolve
    mc "How's that even possible?"

    scene e4s20-19 with dissolve
    show e4s20_mc_blink1
    jon "I don't know man, clearly we haven't done enough damage."

    scene e4s20-18 with dissolve
    hide e4s20_mc_blink1
    mc "So what now?"

    scene e4s20-19 with dissolve
    show e4s20_mc_blink1
    jon "Fuck it, we're moving to plan B."

    scene e4s20-18 with dissolve
    hide e4s20_mc_blink1
    mc "Plan B?"
    mc "How many plans do you have?"

    scene e4s20-19 with dissolve
    show e4s20_mc_blink1
    jon "As many as we need."
    jon "I'm gonna let you know when's our next move."

    scene e4s20-18 with dissolve
    hide e4s20_mc_blink1
    mc "Alright, alright."

    if affinity_spectrum < 0:
        mc "Don't get into trouble, alright?"

        scene e4s20-19 with dissolve
        show e4s20_mc_blink1
        jon "Sure, mom!"

    scene e4s20-21 with dissolve
    hide e4s20_mc_blink1
    pause

    stop music fadeout 1.0
    scene e4s20-15 with dissolve
    pause

    play music travel_light
    scene e4s20-02 with wipeleft
    kv "I can't believe I spent the entire fucking night in prison."
    kv "When I catch the fuckers that did this..."

    scene e4s20-01 with dissolve
    pause

    scene e4s20-03 with dissolve
    sp "Yoo, my dude!"
    sp "What's happening?"

    scene e4s20-04 with dissolve
    kv "Dude, are you fucking kidding me?"

    scene e4s20-08 with dissolve
    sp "What? You want a hit?"

    scene e4s20-05 with dissolve
    kv "What the hell is the matter with you?"
    kv "Did you smoke pot again?"

    scene e4s20-03 with dissolve
    sp "Chillax man, it's just one hit."

    scene e4s20-07 with dissolve
    sp "Helps me think."

    scene e4s20-08 with dissolve
    sp "Here, join me. Take one yourself."

    scene e4s20-06 with dissolve
    kv "I can't believe it."

    scene e4s20-05 with dissolve
    kv "I thought you were sober again."
    kv "We didn't lift that stash from [jd] to get high, we took it to smooth things over with [ab]."
    kv "What are we gonna tell him?"

    scene e4s20-07 with dissolve
    sp "I'll get more. Chill."
    sp "[ab] won't even notice."
    sp "I had to make up for that little shit's stash anyway, we're in the clear."

    if e4s19_fail == True:
        scene e4s20-09 with dissolve
        kv "Yeah well, someone scratched [ab]'s car last night, so there's that."

    scene e4s20-05 with dissolve
    kv "But that's not the point."
    kv "I'm risking my ass with this campaign, and you're sitting here frying your brain like it's Saturday night in junkyard."

    scene e4s20-10 with dissolve
    sp "Hey, don't you fucking talk to me like that!"
    sp "I'm not a junkie, alright?"

    scene e4s20-08 with dissolve
    sp "Come on, [kv], I've always had your back."

    scene e4s20-07 with dissolve
    sp "Just let me be for now."
    sp "Don't bother me with any problems."
    sp "You know I gotta lay low for a bit."

    scene e4s20-11 with dissolve
    kv "..."

    scene e4s20-12 with dissolve
    kv "*Fucking junkie.*"
    kv "*Can't wait for him to get out of jail.*"

    scene e4s20-13 with dissolve
    pause

    jump e4s21
return
