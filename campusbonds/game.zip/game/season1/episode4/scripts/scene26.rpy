
$ e4s26_darryl_leave = False

# Scene 26 - Lover boy #########################################################

label e4s26:
    scene e4s26-01 with wipeleft
    play sound phone_buzz
    pause

    play music bloom
    scene e4s26-02 with dissolve
    cl "Hey, how are you?"

    scene e4s26-03 with dissolve
    mc "Hi [cl], I'm fine."

    scene e4s26-06 with dissolve
    mc "What's up with you?"

    scene e4s26-04 with dissolve
    cl "I'm back at my apartment."

    scene e4s26-05 with dissolve
    if e3s24_cleo_path == True:
        cl "Listen... can you help me out with something?"
    else:
        cl "Listen... I'd like to ask for a favor, if that's alright."

    scene e4s26-06 with dissolve
    mc "Sure, what's going on?"

    scene e4s26-02 with dissolve
    cl "So... I just ended my shift today at the diner and after leaving I noticed someone following me."

    scene e4s26-07 with dissolve
    cl "I knew I wasn't just being paranoid or something."

    scene e4s26-04 with dissolve
    cl "I took multiple turns and streets to see if he was still behind me, and he still was!"

    scene e4s26-05 with dissolve
    cl "Fortunately, I went into a store with two exits and lost him."

    scene e4s26-06 with dissolve
    mc "Wow, did you know that person or why were they following you?"

    scene e4s26-05 with dissolve
    cl "I don't know, I don't remember talking to anyone in particular."

    scene e4s26-02 with dissolve
    cl "I just did my normal shift, took my coat and left the place like I always do."

    scene e4s26-06 with dissolve
    mc "That's weird... and you're 100 percent sure they were following you?"

    scene e4s26-02 with dissolve
    cl "Yes, I am more than 100 percent sure."

    scene e4s26-03 with dissolve
    mc "Did you get a good look at their appearance?"

    scene e4s26-05 with dissolve
    cl "I tried to... but they had a hood on, couldn't get a good look."

    scene e4s26-08 with dissolve
    mc "Alright... alright."

    scene e4s26-06 with dissolve
    mc "What do you want me to do?"

    scene e4s26-05 with dissolve
    cl "I'd like to go and talk to the police, but I'm afraid of leaving my place because they might be following me again."

    scene e4s26-04 with dissolve
    cl "Could you come by and walk me there?"

    scene e4s26-02 with dissolve
    cl "The police shouldn't be too far away."

    scene e4s26-06 with dissolve
    mc "Okay, I'm on my way."

    if e3s24_cleo_path == True:
        scene e4s26-09 with dissolve
        cl "Thank you [mc]! I'm glad I can count on you, especially with everything going on."
    else:
        scene e4s26-04 with dissolve
        cl "Thank you! Again, sorry for bothering you."

    scene e4s26-08 with dissolve
    mc "Hey, it's okay, don't worry. We'll sort this out."

    scene e4s26-01 with dissolve
    pause

    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s26-10 with Dissolve(2.0)
    pause

    play music rollin_at_5
    scene e4s26-11 with dissolve
    da "So... [cl], would you... uh- like to go out with me?"

    scene e4s26-12 with dissolve
    da "Nah, that's too direct."

    scene e4s26-11 with dissolve
    da "So... about last time, sorry for what I did."
    da "Maybe you'd... uh- like to maybe fix it by going out with me?"

    scene e4s26-13 with dissolve
    menu:
        "Mock him":
            $ e4s26_darryl_leave = True
            scene e4s26-14 with dissolve
            mc "Keep trying, I'm sure it will eventually work!"

            scene e4s26-15 with dissolve
            da "What are you doing here?"

            scene e4s26-16 with dissolve
            show e4s26_darryl_blink1
            if e1s15_gfpretend == True:
                mc "What do you mean?"
                mc "I'm here to pick up my girlfriend."

                scene e4s26-17 with dissolve
                hide e4s26_darryl_blink1
                da "Come on... who are you fooling?"
                da "She's not your girlfriend."

                scene e4s26-16 with dissolve
                show e4s26_darryl_blink1
                if affinity_spectrum > 0:
                    mc "Why don't you stick around and see for yourself?"
                    mc "I bet you'll get excited watching us, weirdo."

                    scene e4s26-18 with dissolve
                    hide e4s26_darryl_blink1
                    da "No, I won't..."

                    scene e4s26-22 with dissolve
                    da "Why don't you kiss her when she gets out here then, huh?"

                    scene e4s26-15 with dissolve
                    da "Prove she's your girlfriend."

                    scene e4s26-16 with dissolve
                    show e4s26_darryl_blink1
                    mc "The fuck is wrong with you, bro?"
                    mc "I ain't gotta prove anything to you."

                    scene e4s26-23 with dissolve
                    hide e4s26_darryl_blink1
                    da "Then she's not your girlfriend."

                    scene e4s26-16 with dissolve
                    show e4s26_darryl_blink1
                    mc "Why the fuck are you being weird about it?"
                    mc "I knew you were stupid but I didn't think you were weird like that."
                    mc "I'm not gonna kiss her for your excitement, creep!"

                    scene e4s26-20 with dissolve
                    hide e4s26_darryl_blink1
                    pause
                else:
                    mc "I'm not fooling anyone."
                    mc "That's the truth."

                    scene e4s26-22 with dissolve
                    da "Why don't you kiss her when she gets out here then, huh?"

                    scene e4s26-15 with dissolve
                    da "Prove she's your girlfriend."

                    scene e4s26-16 with dissolve
                    show e4s26_darryl_blink1
                    mc "I don't have to prove anything to you."

                    scene e4s26-23 with dissolve
                    hide e4s26_darryl_blink1
                    da "Then she's not your girlfriend."

                    scene e4s26-20 with dissolve
                    mc "Sure, believe what you want."
                    mc "I'm not here to change your mind, I'm here to pick her up."

                scene e4s26-19 with dissolve
                pause

                scene e4s26-21 with dissolve
                pause

                scene e4s26-24 with dissolve
                play sound door_open
                cl "Hey!"

                scene e4s26-25 with dissolve
                pause

                scene e4s26-26 with dissolve
                pause
            else:
                mc "None of your business."

                scene e4s26-22 with dissolve
                da "Alright, just be sure to stay out of my way."

                scene e4s26-19 with dissolve
                da "I'm here to meet [cl]."

                scene e4s26-16 with dissolve
                show e4s26_darryl_blink1
                mc "I'm sure she's gonna be very happy to see you."

                scene e4s26-15 with dissolve
                hide e4s26_darryl_blink1
                da "Of course she will, why wouldn't she?"

                if e1s15_calm == True:
                    $ e4s26_darryl_leave = False
                    scene e4s26-20 with dissolve
                    mc "That's what I said, didn't I?"

                    scene e4s26-21 with dissolve
                    pause

                    scene e4s26-24 with dissolve
                    play sound door_open
                    cl "Hey!"

                    scene e4s26-25 with dissolve
                    pause
                else:
                    if e1s15_mad == True:
                        scene e4s26-16 with dissolve
                        show e4s26_darryl_blink1
                        mc "I don't know, maybe because you deserve to be punched in the face?"

                        scene e4s26-15 with dissolve
                        hide e4s26_darryl_blink1
                        da "Excuse me?"

                        scene e4s26-16 with dissolve
                        show e4s26_darryl_blink1
                        mc "You heard that, punk."
                        mc "I honestly don't even know why you're here."
                        mc "Do you enjoy making people who can't stand you uncomfortable?"

                        scene e4s26-23 with dissolve
                        da "[cl] can stand me and I don't make her uncomfortable."

                        scene e4s26-20 with dissolve
                        mc "Sure buddy, whatever you say."

                        scene e4s26-16 with dissolve
                        show e4s26_darryl_blink1
                        mc "That's why she avoids you, isn't it?"

                        scene e4s26-18 with dissolve
                        hide e4s26_darryl_blink1
                        da "She doesn't-"

                        scene e4s26-16 with dissolve
                        show e4s26_darryl_blink1
                        mc "Keep lying to yourself."

                        scene e4s26-19 with dissolve
                        hide e4s26_darryl_blink1
                        da "..."

                        scene e4s26-21 with dissolve
                        pause

                        scene e4s26-24 with dissolve
                        play sound door_open
                        cl "Hey!"

                        scene e4s26-25 with dissolve
                        pause

                        scene e4s26-26 with dissolve
                        pause

                        scene e4s26-27 with dissolve
                        cl "I Heard you and [da] arguing."

                        scene e4s26-28 with dissolve
                        show e4s26_cleo_blink1
                        menu:
                            "Lie":
                                $ cleo_intimacy -= 1
                                mc "We weren't arguing."

                                scene e4s26-42 with dissolve
                                hide e4s26_cleo_blink1
                                cl "Then what were you doing?"

                                scene e4s26-28 with dissolve
                                show e4s26_cleo_blink1
                                mc "Talking? Like normal people."

                                scene e4s26-42 with dissolve
                                hide e4s26_cleo_blink1
                                cl "Then why did he leave?"

                                scene e4s26-28 with dissolve
                                show e4s26_cleo_blink1
                                mc "I don't know."
                                mc "It's just [da] things at this point."

                                scene e4s26-27 with dissolve
                                cl "Fair enough."
                            "Truth":
                                mc "Yeah, he's a dumbass."

                                scene e4s26-42 with dissolve
                                cl "You didn't have to go that hard on him..."

                                scene e4s26-28 with dissolve
                                show e4s26_cleo_blink1
                                mc "Maybe not, but someone had to say it."
                                mc "He's been acting weird lately and I'm just worried about you."

                                scene e4s26-27 with dissolve
                                hide e4s26_cleo_blink1
                                cl "Well... thanks for being here."
        "Ignore him":
            scene e4s26-19 with dissolve
            mc "..."

            scene e4s26-20 with dissolve
            pause

            scene e4s26-21 with dissolve
            da "What are you doing here?"

            scene e4s26-16 with dissolve
            show e4s26_darryl_blink1
            mc "What does it look like?"
            mc "I'm here to pick up [cl]."

            scene e4s26-23 with dissolve
            hide e4s26_darryl_blink1
            da "For what?"

            scene e4s26-16 with dissolve
            show e4s26_darryl_blink1
            mc "We're supposed to hang out later, she asked me to come here."

            scene e4s26-18 with dissolve
            hide e4s26_darryl_blink1
            da "She already has a date?"

            scene e4s26-16 with dissolve
            show e4s26_darryl_blink1
            mc "Mhm."

            scene e4s26-19 with dissolve
            pause

            scene e4s26-21 with dissolve
            pause

            scene e4s26-24 with dissolve
            play sound door_open
            cl "Hey!"

            scene e4s26-25 with dissolve
            pause

    if e4s26_darryl_leave == False:
        scene e4s26-29 with dissolve
        pause

        scene e4s26-30 with dissolve
        pause

        scene e4s26-31 with dissolve
        cl "[da]? What are you doing here?"

        scene e4s26-32 with dissolve
        da "Oh... uhm... hey [cl]!"

        scene e4s26-33 with dissolve
        da "You know... I was maybe wondering..."
        da "Um..."

        scene e4s26-32 with dissolve
        da "Sorry for hanging out!"

        scene e4s26-34 with dissolve
        da "No... like, sorry for {b}NOT{/b} hanging out."

        scene e4s26-35 with dissolve
        da "Would you like to fix it like last time?"

        scene e4s26-31 with dissolve
        cl "What?"

        scene e4s26-34 with dissolve
        da "Wait... no, that's not right."
        da "Gahh!"

        scene e4s26-33 with dissolve
        da "Maybe you'd... uh... like to fix things by going out with me?"

        scene e4s26-31 with dissolve
        cl "[da], [mc] is already here."
        cl "I can't just leave him to hang out with you even if I wanted to."

        scene e4s26-36 with dissolve
        cl "I thought I made it clear enough that I don't want to hang out with you, we're just work colleagues, and that's that."

        scene e4s26-37 with dissolve
        da "But you never gave me the chance for more..."

        scene e4s26-31 with dissolve
        cl "Because I don't want that, it's not about chances here."

        scene e4s26-38 with dissolve
        cl "Learn to take 'no' for an answer, please!"

        scene e4s26-37 with dissolve
        da "But... but..."

        scene e4s26-16 with dissolve
        show e4s26_darryl_blink1
        mc "You heard her pal, get going."

        scene e4s26-30 with dissolve
        hide e4s26_darryl_blink1
        da "..."

        scene e4s26-39 with dissolve
        da "I'm not done..."

    stop music fadeout 1.0
    scene e4s26-28 with dissolve
    show e4s26_cleo_blink1
    if e3s24_cleo_path == True:
        mc "You okay?"

        scene e4s26-36 with dissolve
        hide e4s26_cleo_blink1
        cl "Yeah... I think I'm fine now."

        scene e4s26-42 with dissolve
        cl "Thanks for coming!"

        scene e4s26-28 with dissolve
        show e4s26_cleo_blink1
        mc "I'm here, don't worry."

        scene e4s26-40 with dissolve
        hide e4s26_cleo_blink1
        pause

        scene e4s26-41 with dissolve
        pause
    if e4s26_darryl_leave == False:
        mc "Thank you for calling me and not that creep."

        scene e4s26-27 with dissolve
        hide e4s26_cleo_blink1
        cl "Not in a million lives."

    play music one_fine_day
    scene e4s26-42 with dissolve
    cl "So... you ready to leave?"

    scene e4s26-28 with dissolve
    show e4s26_cleo_blink1
    mc "Sure, let's get this over with."

    scene e4s26-43 with dissolve
    hide e4s26_cleo_blink1
    pause

    if e4s26_darryl_leave == False:
        scene e4s26-44 with dissolve
        cl "Did you, by any chance, tell him where we were going?"

        scene e4s26-45 with dissolve
        mc "Haha, of course not."
        mc "Why would [da] know where you're headed?"

        scene e4s26-46 with dissolve
        cl "Haha, thanks! He sometimes creeps me out."
    else:
        scene e4s26-47 with dissolve
        mc "Also, [da] was here."

        scene e4s26-48 with dissolve
        cl "He was?"
        cl "What was he doing?"

        scene e4s26-49 with dissolve
        mc "I think he wanted to ask you out or something."

        scene e4s26-50 with dissolve
        cl "That guy can't take no for an answer..."

        scene e4s26-51 with dissolve
        mc "It seems so, yeah."

    scene e4s26-52 with dissolve
    pause

    if e3s24_cleo_path == False and e1s15_gfpretend == True:
        scene e4s26-53 with dissolve
        cl "I can't believe the girlfriend stunt didn't work..."

        scene e4s26-54 with dissolve
        mc "Yeah, I hoped it would last longer, but it seems like he slowly caught onto it."

        scene e4s26-55 with dissolve
        cl "Even if we were to hold hands and kiss he wouldn't believe it, that's how delusional he is."

        scene e4s26-54 with dissolve
        mc "Haha, yeah!"
    else:
        if e3s24_cleo_path == True:
            scene e4s26-55 with dissolve
            cl "Do you think if we were to hold hands and kiss in front of him he'd finally get it?"

            scene e4s26-54 with dissolve
            mc "Haha, I don't think so, no."
            mc "He's just a creep at this point, I think in a way it would turn him on."

            scene e4s26-56 with dissolve
            cl "Jesus... I can't think about that right now."

            scene e4s26-57 with dissolve
            cl "Let's just get going, okay?"

    scene e4s26-58 with dissolve
    pause

    jump e4s27
return
