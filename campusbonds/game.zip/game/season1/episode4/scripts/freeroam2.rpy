
# Variables
default e4f2_candance = False
default e4f2_mia = False
default e4f2_ken = False
default e4f2_scarlett = False

default e4f2_stripper1 = False
default e4f2_stripper2 = False
default e4f2_stripper3 = False
default e4f2_stripper4 = False

default e4f2_strippers = False

default e4f2_money1 = False

# Freeroam Collected Photos #

default persistent.e4f2_collected_p = 0
default persistent.e4f2_collected_tp = 11

# Freeroam 2 ###################################################################
label e4f2:
    define e4f2_tracks = ["party/i_wont_fall_in_love.ogg", "party/galaxies.ogg", "party/instrumentals/area_51.ogg", "party/instrumentals/aux_original_mix.ogg", "party/instrumentals/dimension.ogg", "party/instrumentals/moving_up.ogg", "party/instrumentals/nightrise.ogg", "party/instrumentals/piano.ogg", "party/instrumentals/rock_this_house.ogg", "party/instrumentals/turn_up.ogg", "party/instrumentals/open_inside.ogg", "party/instrumentals/random_drop.ogg", "party/instrumentals/2010_pop.ogg", "party/instrumentals/encryption.ogg", "party/instrumentals/hard_love.ogg", "party/instrumentals/lundstroems_daft_punk.ogg", "party/instrumentals/then_im_gone.ogg", "party/instrumentals/dance_tonight.ogg", "party/instrumentals/love_you.ogg"]
    $ renpy.random.shuffle(e4f2_tracks)
    $ renpy.music.queue (e4f2_tracks, loop=True)

    $ renpy.show_screen("questtracker_icon")

    $ renpy.block_rollback()

    $ current_quests.append("Interact with people.")

    scene e4f2-07 with dissolve

    call screen e4f2_bar
    hide e4f2-01
return

# Map ##########################################################################

# Dance Floor ###
label e4f2_dance_floor:
    if e4f2_strippers == False:
        if e4f2_ken == False:
            scene e4f2-01
        else:
            scene e4f2-01_1
    else:
        if e4f2_stripper1 == False:
            scene e4f2-01_2
        else:
            scene e4f2-01_3
    call screen e4f2_dance_floor with dissolve
return

label e4f2_candance:
    $ e4f2_candance = True

    scene e4f2-ca_01 with dissolve
    mc "Hey there!"

    if e2s10_lap_dance > 0:
        scene e4f2-ca_03 with dissolve
        ca "[mc]? Hi!"
        ca "I was wondering if I'd see you tonight."

        scene e4f2-ca_02 with dissolve
        mc "Yeah, well, I was caught up into something."
        mc "But I could make it to the party in the end."

        scene e4f2-ca_03 with dissolve
        ca "That's great!"

    if e3f3_help_mia == True:
        if e4f2_candance == True and e4f2_mia == True and e4f2_ken == True and e4f2_scarlett == True:
            if optional_quests:
                $ optional_quests.clear()
    else:
        if e4f2_candance == True and e4f2_ken == True and e4f2_scarlett == True:
            if optional_quests:
                $ optional_quests.clear()

    jump e4f2_dance_floor
return

label e4f2_stripper1:
    $ e4f2_stripper1 = True

    scene e4f2-str1_01 with dissolve
    if affinity_spectrum > 0:
        if e4f2_candance == True or e2s10_lap_dance > 0:
            mc "Hey, [ca]!"

            scene e4f2-str1_03 with dissolve
            ca "[mc], what's up?"
    else:
        mc "Hey, you!"

    scene e4f2-str1_02 with dissolve
    mc "Go into the bathroom, quick!"

    scene e4f2-str1_04 with dissolve
    ca "What happened?"

    scene e4f2-str1_05 with dissolve
    mc "There's no time, I'll explain everything later."
    mc "Just go!"

    scene e4f2-str1_04 with dissolve
    ca "Okay, okay."

    scene e4f2-str1_06 with dissolve
    ca "[lo], come on!"

    scene e4f2-str1_07 with dissolve
    if e4f2_stripper1 == True and e4f2_stripper2 == True and e4f2_stripper3 == True and e4f2_stripper4 == True:
        $ current_quests.remove("Gather the strippers.")
        $ current_quests.append("Go in the bathroom.")
    lo "Huh?"

    jump e4f2_dance_floor
return

# Couch ###
label e4f2_couch:
    if e3f3_help_mia == True:
        if e4f2_strippers == False:
            if e4f2_mia == False:
                scene e4f2-02
            else:
                scene e4f2-02_1
        else:
            if e4f2_stripper3 == False:
                scene e4f2-02_2
            else:
                scene e4f2-02_1
    else:
        if e4f2_strippers == False:
            scene e4f2-02_1
        else:
            if e4f2_stripper3 == False:
                scene e4f2-02_2
            else:
                scene e4f2-02_1
    call screen e4f2_couch with dissolve
return

label e4f2_mia:
    $ e4f2_mia = True

    scene e4f2-mia_01 with dissolve
    mc "Hey!"

    scene e4f2-mia_02 with dissolve
    mc "[mia], right?"

    scene e4f2-mia_03 with dissolve
    mia "Yeah, that's me. Hello!"

    scene e4f2-mia_02 with dissolve
    mc "What's up?"
    mc "Looks like you came back."

    scene e4f2-mia_04 with dissolve
    mia "Huh?"

    scene e4f2-mia_02 with dissolve
    mc "You were a bartender a couple of days ago."
    mc "You didn't seem to like it that much."

    scene e4f2-mia_06 with dissolve
    mia "Oh... you're the guy who helped me!"

    scene e4f2-mia_05 with dissolve
    mia "[mc], was it?"

    scene e4f2-mia_02 with dissolve
    mc "Yeah, that's me."

    scene e4f2-mia_03 with dissolve
    mia "Hey, thanks, by the way!"

    scene e4f2-mia_02 with dissolve
    mc "No problem! What made you come back?"

    scene e4f2-mia_06 with dissolve
    mia "The fact that I'm not bartending anymore, haha!"

    scene e4f2-mia_05 with dissolve
    mia "They stopped making jokes after we talked, so I thought I'd give it a shot on the partying side."

    scene e4f2-mia_03 with dissolve
    mia "And yeah, I've gotta admit, it's actually really fun!"

    scene e4f2-mia_02 with dissolve
    mc "Haha, I'm glad!"
    mc "Welcome among us, then!"

    scene e4f2-mia_03 with dissolve
    mia "Thanks!"

    scene e4f2-mia_05 with dissolve
    mia "I was just on my way to get a drink."
    mia "Would you like to join me?"

    scene e4f2-mia_02 with dissolve
    menu:
        "Drink with her":
            mc "Sure, I could use a drink."

            scene e4f2-mia_07 with dissolve
            pause

            if e4f2_ken == True:
                scene e4f2-mia_09 with dissolve
            else:
                scene e4f2-mia_08 with dissolve
            mia "You guys are crazy."

            scene e4f2-mia_12 with dissolve
            mia "Bringing in strippers not only on campus grounds, but inside the college too?"

            scene e4f2-mia_10 with dissolve
            mia "The dean would kill you if he'd found out."

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "Hey, don't look at me, I didn't organize any of this!"
            mc "I was surprised too when I got here."

            scene e4f2-mia_13 with dissolve
            hide e4f2_mia_blink1
            mia "It's honestly crazy to think that my sister hates this place so much."

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "Woah, hold on a bit."
            mc "Who's your sister?"

            scene e4f2-mia_13 with dissolve
            hide e4f2_mia_blink1
            mia "Some crazed control freak."
            mia "She dislikes anything that's not in order."

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "She sounds fun."

            scene e4f2-mia_14 with dissolve
            hide e4f2_mia_blink1
            mia "Yeah... far from it."

            scene e4f2-mia_15 with dissolve
            mia "And it's not only this place that she hates, if I'm being honest she hates everything."

            scene e4f2-mia_14 with dissolve
            mia "Come to think of it, what doesn't she hate?"

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "You?"

            scene e4f2-mia_15 with dissolve
            hide e4f2_mia_blink1
            mia "Me?"

            scene e4f2-mia_16 with dissolve
            mia "Haha, she probably hates me the most."
            mia "You don't even know the half of it."

            scene e4f2-mia_10 with dissolve
            mia "Anyway, you got any relatives worth talking shit about?"

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "Hmm... to be honest not really."
            mc "Although... I have this one childhood friend that I saw a couple of days ago."
            mc "Her name is [hl]."
            mc "Can't really stand her."

            scene e4f2-mia_16 with dissolve
            hide e4f2_mia_blink1
            mia "Haha, why not?"

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "I don't know... I guess we just grew apart."
            mc "She didn't hurt me in any bad way or something."
            mc "But she still treats me like I'm a kid."
            mc "And she's not that socially aware either meaning she might say a thing or two at a really wrong time."

            scene e4f2-mia_13 with dissolve
            hide e4f2_mia_blink1
            mia "Doesn't sound all that annoying to me, just misunderstood."

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "Well, it's not like she's my problem anymore, we've barely spoken over the last couple of years."
            mc "I was basically dragged into a conversation with her by my dad."

            scene e4f2-mia_10 with dissolve
            hide e4f2_mia_blink1
            mia "You do you, dude."

            scene e4f2-mia_11 with dissolve
            show e4f2_mia_blink1
            mc "Anyway, I'll go meet some other people."
            mc "See you around and thanks for coming to the party."

            scene e4f2-mia_13 with dissolve
            hide e4f2_mia_blink1
            if e4f2_ken == True:
                $ current_quests.remove("Interact with people.")
                $ current_quests.append("Sit on the couch.")

                if e4f2_candance == False or e4f2_scarlett == False:
                    $ optional_quests.append("Interact with people.")
            mia "See you!"

            jump e4f2_bar
        "Turn her down":
            mc "I'm trying to cut down on drinks tonight."
            mc "But thanks for the offer!"

            scene e4f2-mia_03 with dissolve
            mia "Alright, I get it."
            mia "No worries."
            mia "I'll see you around!"

            scene e4f2-mia_02 with dissolve
            if e4f2_ken == True:
                $ current_quests.remove("Interact with people.")
                $ current_quests.append("Sit on the couch.")

                if e4f2_candance == False or e4f2_scarlett == False:
                    $ optional_quests.append("Interact with people.")
            mc "Sure thing, bye!"

            jump e4f2_couch
return

label e4f2_couch_clickable:
    $ e4f2_strippers = True

    scene e4f2-ch_01 with dissolve
    pause

    scene e4f2-ch_02 with dissolve
    pause

    scene e4f2-ch_03 with dissolve
    pause

    scene e4f2-ch_04 with dissolve
    unknown "Hey there handsome!"
    unknown "You seem distant."

    scene e4f2-ch_05 with dissolve
    if affinity_spectrum < 0:
        mc "Yeah, well, parties aren't exactly my thing."

        scene e4f2-ch_07 with dissolve
        unknown "Why's that?"

        scene e4f2-ch_06 with dissolve
        mc "I don't know, I just don't enjoy that many people in a single room."

        scene e4f2-ch_08 with dissolve
        unknown "Oh... introvert much?"

        scene e4f2-ch_07 with dissolve
        unknown "Sorry, I'm a bit tired and I'd like to sit on the couch, do you mind?"

        scene e4f2-ch_06 with dissolve
        mc "Not really, have a seat."

        scene e4f2-ch_09 with dissolve
        pause

        scene e4f2-ch_11 with dissolve
        mc "Uh... what are you doing?"

        scene e4f2-ch_12 with dissolve
        unknown "I'm just laying a bit."
        unknown "Tonight's been really exhausting."

        scene e4f2-ch_16 with dissolve
        mc "I'm sorry to hear that."

        scene e4f2-ch_13 with dissolve
        unknown "Yeah... well it's my job, right?"

        scene e4f2-ch_17 with dissolve
        unknown "Plus, I'm getting some enjoyment out of it, too."

        scene e4f2-ch_14 with dissolve
        show e4f2_unknown_blink1
        mc "Well... good for you."

        scene e4f2-ch_13 with dissolve
        hide e4f2_unknown_blink1
        unknown "Think you have anything for me?"
    else:
        mc "Just sitting on the couch for a bit."

        scene e4f2-ch_08 with dissolve
        unknown "All these beautiful women around, must be exhausting, right?"
        unknown "Let me take a seat too."

        scene e4f2-ch_10 with dissolve
        pause

        scene e4f2-ch_15 with dissolve
        unknown "So... how are you enjoying the party, dear?"

        scene e4f2-ch_14 with dissolve
        show e4f2_unknown_blink1
        mc "It's pretty nice, yeah."
        mc "I like what [jon] did to the place."
        mc "Great drinks too, have you had any?"

        scene e4f2-ch_13 with dissolve
        hide e4f2_unknown_blink1
        unknown "Many, yeah."

        scene e4f2-ch_18 with dissolve
        mc "Here, have a sip."

        scene e4f2-ch_13 with dissolve
        unknown "Yummy."
        unknown "So... are you down for some fun?"
        unknown "Just for {color=#4CBB17}$1{/color}"

    unknown "I can make you feel really good."

    scene e4f2-ch_14 with dissolve
    show e4f2_unknown_blink1
    if affinity_spectrum < 0:
        menu:
            "Take her offer":
                $ e4f2_stripper_offer = True

                mc "Sure, I'd be down for some fun."

                scene e4f2-ch_22 with dissolve
                hide e4f2_unknown_blink1
                unknown "I wonder what you're hiding down there."

                scene e4f2-ch_14 with dissolve
                show e4f2_unknown_blink1
                if affinity_spectrum < 0:
                    mc "Wait... fun in public?"
                    mc "I'm not ready to strip in front of everybody."

                    scene e4f2-ch_23 with dissolve
                    hide e4f2_unknown_blink1
                    unknown "Haha, you're cute."
                else:
                    mc "Why don't you check it out?"

                    scene e4f2-ch_23 with dissolve
                    hide e4f2_unknown_blink1
                    unknown "Charming too."

                scene e4f2-ch_24 with dissolve
                pause

                scene e4f2-ch_25 with dissolve
                pause

                scene e4f2-ch_26 with dissolve
                pause

                scene e4f2-couch_anim with dissolve
                pause

                scene e4f2-ch_29 with dissolve
                unknown "Fuck... you're a good kisser."

                if affinity_spectrum < 0:
                    unknown "I taste some alcohol in there too, looks like you had fun, huh?"

                    scene e4f2-ch_28 with dissolve
                    mc "You could say that."

                scene e4f2-couch_anim with dissolve
                pause

                scene e4f2-ch_26 with dissolve
                pause

                scene e4f2-ch_29 with dissolve
                unknown "Ah... you have no idea how this grinding makes me feel."

                scene e4f2-couch_anim with dissolve
                pause

                if affinity_spectrum < 0:
                    scene e4f2-ch_31 with dissolve
                    ke "*Wait... what?*"

                    scene e4f2-ch_32 with dissolve
                    ke "*He actually went for the stripper?*"
                    ke "*I thought they weren't his thing.*"
                    ke "*He just got a lap dance for free, with my money!*"
                    ke "*I wanted to mess with him, I didn't think he'd go for her.*"

                scene e4f2-couch_anim with dissolve
                pause

                scene e4f2-ch_29 with dissolve
                unknown "Hope you enjoyed my show, sweetie."
                unknown "I'll see you around."

                scene e4f2-ch_28 with dissolve
                mc "See you!"

                scene e4f2-ch_30 with dissolve
                pause
            "Refuse her":
                mc "Sorry, I'm not interested."

                scene e4f2-ch_20 with dissolve
                hide e4f2_unknown_blink1
                unknown "Why not?"

                scene e4f2-ch_21 with dissolve
                unknown "Is this not hot enough for you?"

                scene e4f2-ch_19 with dissolve
                mc "No, it's not that."
                mc "I'm just not into strippers."

                scene e4f2-ch_20 with dissolve
                unknown "Okay, I get it."

                scene e4f2-ch_13 with dissolve
                unknown "You seemed fun."
                unknown "I'll be on my way then."

                scene e4f2-ch_30 with dissolve
                pause

                if affinity_spectrum < 0:
                    scene e4f2-ch_33 with dissolve
                    ke "Pleasure doing business with you!"

                    scene e4f2-ch_35 with dissolve
                    unknown "Easiest money I ever made, that guy's hopeless."

                    scene e4f2-ch_34 with dissolve
                    unknown "Probably hooked on some girl or shit, he wasn't interested in me at all."

                    scene e4f2-ch_33 with dissolve
                    ke "Yeah, figured that much."
                    ke "Thanks, anyway."

                    scene e4f2-ch_34 with dissolve
                    unknown "No problem!"
    else:
        $ renpy.show_screen("money_notify_pers")
        menu:
            "Take her offer {color=#f00}(-$1){/color}" if money > 0:
                $ e4f2_stripper_offer = True
                $ money -= 1

                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")
                mc "Sure, I'd be down for some fun."

                scene e4f2-ch_22 with dissolve
                unknown "I wonder what you're hiding down there."

                scene e4f2-ch_14 with dissolve
                show e4f2_unknown_blink1
                if affinity_spectrum < 0:
                    mc "Wait... fun in public?"
                    mc "I'm not ready to strip in front of everybody."

                    scene e4f2-ch_23 with dissolve
                    hide e4f2_unknown_blink1
                    unknown "Haha, you're cute."
                else:
                    mc "Why don't you check it out?"

                    scene e4f2-ch_23 with dissolve
                    hide e4f2_unknown_blink1
                    unknown "Charming too."

                scene e4f2-ch_24 with dissolve
                pause

                scene e4f2-ch_25 with dissolve
                pause

                scene e4f2-ch_26 with dissolve
                pause

                scene e4f2-couch_anim with dissolve
                pause

                scene e4f2-ch_29 with dissolve
                unknown "Fuck... you're a good kisser."

                if affinity_spectrum > 0:
                    unknown "I taste some alcohol in there too, looks like you had fun, huh?"

                    scene e4f2-ch_28 with dissolve
                    mc "You could say that."

                scene e4f2-couch_anim with dissolve
                pause

                scene e4f2-ch_26 with dissolve
                pause

                scene e4f2-ch_29 with dissolve
                unknown "Ah... you have no idea how this grinding makes me feel."

                scene e4f2-couch_anim with dissolve
                pause

                if affinity_spectrum < 0:
                    scene e4f2-ch_31 with dissolve
                    ke "*Wait... what?*"

                    scene e4f2-ch_32 with dissolve
                    ke "*He actually went for the stripper?*"
                    ke "*I thought they weren't his thing.*"
                    ke "*He just got a lap dance for free, with my money!*"
                    ke "*I wanted to mess with him, I didn't think he'd go for her.*"

                    scene e4f2-couch_anim with dissolve
                    pause

                scene e4f2-ch_29 with dissolve
                unknown "Hope you enjoyed my show, sweetie."
                unknown "I'll see you around."

                scene e4f2-ch_28 with dissolve
                mc "See you!"

                scene e4f2-ch_30 with dissolve
                pause
            "Refuse her":
                $ renpy.show_screen("money_notify")
                $ renpy.hide_screen("money_notify_pers")
                mc "Sorry, I'm not interested."

                scene e4f2-ch_20 with dissolve
                unknown "Why not?"

                scene e4f2-ch_21 with dissolve
                unknown "Is this not hot enough for you?"

                scene e4f2-ch_19 with dissolve
                mc "No, it's not that."
                mc "I'm just not into strippers."

                scene e4f2-ch_20 with dissolve
                unknown "Okay, I get it."

                scene e4f2-ch_13 with dissolve
                unknown "You seemed fun."
                unknown "I'll be on my way then."

                scene e4f2-ch_30 with dissolve
                pause

                if affinity_spectrum < 0:
                    scene e4f2-ch_33 with dissolve
                    ke "Pleasure doing business with you!"

                    scene e4f2-ch_35 with dissolve
                    unknown "Easiest money I ever made, that guy's hopeless."

                    scene e4f2-ch_34 with dissolve
                    unknown "Probably hooked on some girl or shit, he wasn't interested in me at all."

                    scene e4f2-ch_33 with dissolve
                    ke "Yeah, figured that much."
                    ke "Thanks, anyway."

                    scene e4f2-ch_34 with dissolve
                    unknown "No problem!"

    scene e4f2-ch_36 with dissolve
    pause

    scene e4f2-ch_37 with dissolve
    if e4f2_stripper_offer == True:
        jon "Enjoying the strippers I see, good, good!"

        scene e4f2-ch_38 with dissolve
        mc "Can't let them go to waste, huh?"

        scene e4f2-ch_39 with dissolve
        jon "That's what I like to hear."
        jon "If this goes well, we'll probably get a partnership here as well."
        jon "They used to be regulars at Eddy's."
    else:
        jon "Hey there! Enjoying the party?"

        scene e4f2-ch_38 with dissolve
        mc "Yeah, just relaxing a bit that's all."

        scene e4f2-ch_39 with dissolve
        jon "If you want a stripper, just ask me, alright?"
        jon "I know they might be expensive, but I can lend you some money if you'd like."

        scene e4f2-ch_38 with dissolve
        mc "I'm good, thanks."

    scene e4f2-ch_40 with dissolve
    ke "[jon]! Guys!"

    scene e4f2-ch_41 with dissolve
    jon "Yo, what's up?"

    scene e4f2-ch_42 with dissolve
    ke "Professor, incoming!"

    scene e4f2-ch_43 with dissolve
    jon "What, why?"

    scene e4f2-ch_42 with dissolve
    ke "I don't know, she was headed this way."

    scene e4f2-ch_44 with dissolve
    jon "Shit, let me talk to [sc]."

    scene e4f2-ch_43 with dissolve
    jon "We have to hide the booze."

    scene e4f2-ch_42 with dissolve
    ke "The strippers too!"

    scene e4f2-ch_43 with dissolve
    jon "Right, right, I'm gonna get going."

    scene e4f2-ch_46 with dissolve
    jon "[mc], can you talk to the strippers?"
    jon "Hide them in the bathroom or something until the professor leaves."

    scene e4f2-ch_45 with dissolve
    if affinity_spectrum > 0:
        mc "Don't have to tell me twice."
    else:
        mc "Okay, okay."

    scene e4f2-ch_43 with dissolve
    jon "[ke], you get the booze."

    scene e4f2-ch_42 with dissolve
    if optional_quests:
        $ optional_quests.clear()
    if current_quests:
        $ current_quests.clear()

    $ current_quests.append("Gather the strippers.")
    ke "On it."

    jump e4f2_couch
return

label e4f2_stripper3:
    $ e4f2_stripper3 = True

    scene e4f2-str3_01 with dissolve
    mc "Hey, you!"

    scene e4f2-str3_03 with dissolve
    unknown "What's up?"

    scene e4f2-str3_02 with dissolve
    mc "Quick, go into the bathroom."

    scene e4f2-str3_03 with dissolve
    unknown "Payment is upfront."

    scene e4f2-str3_02 with dissolve
    mc "No... not for that!"
    if e4f2_stripper1 == True and e4f2_stripper2 == True and e4f2_stripper3 == True and e4f2_stripper4 == True:
        $ current_quests.remove("Gather the strippers.")
        $ current_quests.append("Go in the bathroom.")
    mc "Just... get in there, there's no time to explain."

    jump e4f2_couch
return

# DJ ###
label e4f2_dj:
    scene e4f2-03
    call screen e4f2_dj with dissolve
return

# Vending ###
label e4f2_vending:
    if e4f2_strippers == False:
        scene e4f2-04
    else:
        if e4f2_stripper4 == False:
            scene e4f2-04_2
        else:
            scene e4f2-04_1
    call screen e4f2_vending with dissolve
return

label e4f2_stripper4:
    $ e4f2_stripper4 = True

    scene e4f2-str4_01 with dissolve
    mc "Hey!"

    scene e4f2-str4_02 with dissolve
    mc "Go into the bathroom, quick!"

    scene e4f2-str4_03 with dissolve
    unknown "Huh? Why?"
    unknown "What's wrong?"

    scene e4f2-str4_02 with dissolve
    mc "I'll explain everything there, just go!"

    scene e4f2-str4_04 with dissolve
    if e4f2_stripper1 == True and e4f2_stripper2 == True and e4f2_stripper3 == True and e4f2_stripper4 == True:
        $ current_quests.remove("Gather the strippers.")
        $ current_quests.append("Go in the bathroom.")
    unknown "Fuck... I knew this wouldn't end good."

    jump e4f2_vending
return

# Pool ###
label e4f2_pool:
    if e4f2_strippers == False:
        if e4f2_ken == False:
            scene e4f2-05
        else:
            scene e4f2-05_1
    else:
        if e4f2_stripper2 == False:
            scene e4f2-05_2
        else:
            scene e4f2-05_1
    call screen e4f2_pool with dissolve
return

label e4f2_ken:
    $ e4f2_ken = True
    scene e4f2-ken_01 with dissolve
    mc "Hey [ke]!"

    scene e4f2-ken_03 with dissolve
    ke "What's up, dude?"

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    mc "Just got to the party."
    mc "Where's [jd]?"

    scene e4f2-ken_04 with dissolve
    hide e4f2_ken_blink1
    ke "Oh, he took a bit of a break."

    scene e4f2-ken_05 with dissolve
    ke "Said he wanted to be alone."

    scene e4f2-ken_04 with dissolve
    ke "I heard about what happened between you and him."
    ke "I'm sorry about that, [mc]."

    scene e4f2-ken_05 with dissolve
    ke "I thought he would have quit by now."
    ke "At least that's what he told us."

    scene e4f2-ken_03 with dissolve
    ke "I told him this shit could get him in a load of trouble, but he just won't listen."

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    menu:
        "Be empathetic":
            $ ken_friendship += 1
            mc "Well... addictions aren't easy."
            mc "I just hope he gets over it."

            scene e4f2-ken_05 with dissolve
            hide e4f2_ken_blink1
            ke "Yeah... me too."

            scene e4f2-ken_04 with dissolve
            ke "And you're right, it's not easy."

            scene e4f2-ken_06 with dissolve
            ke "I'm glad you see this thing like I do."
        "Be judging":
            mc "Yeah, it's not smart of him to do that."
            mc "He's been putting [jon] and most of us at risk."

            scene e4f2-ken_05 with dissolve
            hide e4f2_ken_blink1
            ke "Let's just hope he manages to get over it."

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    mc "Yeah..."
    mc "Also, where's [ro]?"

    scene e4f2-ken_04 with dissolve
    hide e4f2_ken_blink1
    ke "Back to his old habits again."

    scene e4f2-ken_05 with dissolve
    ke "I'm starting to think he has a chick or something back home."

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    mc "Or maybe he hasn't gone back there in a week?"

    scene e4f2-ken_03 with dissolve
    hide e4f2_ken_blink1
    ke "Yeah, could be."
    ke "We're gonna have to wait and see his behaviour."

    scene e4f2-ken_06 with dissolve
    ke "Have you checked the strippers yet?"

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    if e4f2_candance == False:
        mc "Haha, not yet."
        mc "[jon] told me about them."

        scene e4f2-ken_06 with dissolve
        hide e4f2_ken_blink1
        ke "We've been planning on this for so long."
        ke "Finally convinced them to join us."

        scene e4f2-ken_02 with dissolve
        show e4f2_ken_blink1
        menu:
            "Be excited" if affinity_spectrum >= 0:
                mc "That's awesome!"

                scene e4f2-ken_07 with dissolve
                hide e4f2_ken_blink1
                ke "I know right?"
            "Be indifferent":
                mc "Yeah, they're not really my thing..."
                mc "But you guys enjoy them."

                scene e4f2-ken_07 with dissolve
                hide e4f2_ken_blink1
                ke "Haha, thanks!"
    else:
        if affinity_spectrum > 0:
            mc "Hell yeah I did!"
            mc "Can't believe you guys actually did that."

            scene e4f2-ken_07 with dissolve
            hide e4f2_ken_blink1
            ke "[jon]'s the one who pulled the strings."
            ke "Thank him!"

            scene e4f2-ken_02 with dissolve
            show e4f2_ken_blink1
            mc "Haha, will do."
        else:
            mc "Haha, nah."
            mc "They're not really my thing."

            scene e4f2-ken_06 with dissolve
            hide e4f2_ken_blink1
            ke "Why not?"

            scene e4f2-ken_02 with dissolve
            show e4f2_ken_blink1
            mc "I don't know, I'm just not into that."
            mc "I don't like sleeping around."

            scene e4f2-ken_07 with dissolve
            hide e4f2_ken_blink1
            ke "Pftt, alright, suit yourself."

    scene e4f2-ken_06 with dissolve
    hide e4f2_ken_blink1
    ke "I'll go check out the strippers."
    ke "See you dude."

    scene e4f2-ken_02 with dissolve
    show e4f2_ken_blink1
    if e3f3_help_mia == True:
        if e4f2_mia == True and current_quests:
            $ current_quests.remove("Interact with people.")
            $ current_quests.append("Sit on the couch.")

            if e3f3_help_mia == True:
                if e4f2_candance == False or e4f2_mia == False or e4f2_scarlett == False:
                    $ optional_quests.append("Interact with people.")
            else:
                if e4f2_candance == False or e4f2_scarlett == False:
                    $ optional_quests.append("Interact with people.")
    else:
        $ current_quests.remove("Interact with people.")
        $ current_quests.append("Sit on the couch.")

        if e3f3_help_mia == True:
            if e4f2_candance == False or e4f2_mia == False or e4f2_scarlett == False:
                $ optional_quests.append("Interact with people.")
        else:
            if e4f2_candance == False or e4f2_scarlett == False:
                $ optional_quests.append("Interact with people.")

    mc "Alright, see you around."

    hide e4f2_ken_blink1

    jump e4f2_pool
return

label e4f2_stripper2:
    $ e4f2_stripper2 = True

    scene e4f2-str2_01 with dissolve
    unknown "Come on, you stupid machine!"

    scene e4f2-str2_02 with dissolve
    mc "Hey!"

    scene e4f2-str2_03 with dissolve
    if e4f2_stripper_offer == False:
        unknown "Changed your mind?"
    else:
        unknown "Back for round two?"

    scene e4f2-str2_04 with dissolve
    mc "No, quick, go into the bathroom!"

    scene e4f2-str2_03 with dissolve
    unknown "Damn, take me to dinner first."

    scene e4f2-str2_04 with dissolve
    mc "I'm serious, there's no time, just go!"

    scene e4f2-str2_05 with dissolve
    unknown "Holy shit, you are serious."
    if e4f2_stripper1 == True and e4f2_stripper2 == True and e4f2_stripper3 == True and e4f2_stripper4 == True:
        $ current_quests.remove("Gather the strippers.")
        $ current_quests.append("Go in the bathroom.")
    unknown "Okay, okay, I'm going."

    jump e4f2_pool
return

# Staff ###
label e4f2_staff:
    scene e4f2-06
    call screen e4f2_staff with dissolve
return

label e4f2_bathroom:
    $ collected_p = persistent.e4f2_collected_p
    $ collected_tp = persistent.e4f2_collected_tp
    $ renpy.show_screen("render_count_notify_pers")
    menu:
        "End freeroam":
            if optional_quests:
                $ optional_quests.clear()
            if current_quests:
                $ current_quests.clear()

            $ renpy.hide_screen("questtracker_icon")

            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            return

        "Explore more":
            $ renpy.show_screen("render_count_notify")
            pause(0.5)
            $ renpy.hide_screen("render_count_notify_pers")

            jump e4f2_staff
return

# Bar ###
label e4f2_bar:
    if e4f2_strippers == False:
        scene e4f2-07
    else:
        scene e4f2-07_1
    call screen e4f2_bar with dissolve
return

label e4f2_scarlett:
    $ e4f2_scarlett = True

    scene e4f2-sc_01 with dissolve
    mc "Hey!"

    scene e4f2-sc_02 with dissolve
    sc "The shithead decided to turn up to the party."

    scene e4f2-sc_03 with dissolve
    sc "How fucking great."

    scene e4f2-sc_04 with dissolve
    mc "What's your deal?"
    mc "I just said hey."

    scene e4f2-sc_05 with dissolve
    sc "Yeah, and I'd rather you not do that."
    sc "I'm not in the mood tonight."

    scene e4f2-sc_04 with dissolve
    mc "Why are you at this party then?"

    scene e4f2-sc_05 with dissolve
    sc "Money is money."
    sc "Plus, I couldn't just leave you alone here."
    sc "You would have turned the place upside down."

    scene e4f2-sc_04 with dissolve
    mc "No, we wouldn't have."

    scene e4f2-sc_06 with dissolve
    sc "Haha, sure."

    scene e4f2-sc_04 with dissolve
    mc "And how much money do you really make here?"
    mc "The amount can't be that great."

    scene e4f2-sc_07 with dissolve
    sc "You don't even know..."
    sc "I won't get into details, business isn't for everyone."

    scene e4f2-sc_04 with dissolve
    mc "Ouch?"

    scene e4f2-sc_06 with dissolve
    sc "If that hurt you then you really are soft."

    scene e4f2-sc_04 with dissolve
    menu:
        "Make a joke" if affinity_spectrum > 0:
            call extrovert_affinity_check from _call_extrovert_affinity_check_76
            call color_check from _call_color_check_148
            $ scarlett_trust += 1
            mc "I might be soft but I got something really hard down here."

            if e4s1_joke == True:
                $ scarlett_trust -= 1
                scene e4f2-sc_05 with dissolve
                sc "Dude, what the fuck."
                sc "You made the same joke earlier today, didn't laugh then won't laugh now."

                scene e4f2-sc_04 with dissolve
                mc "You're not supposed to laugh at it."

                scene e4f2-sc_03 with dissolve
                sc "You're the worst thing that's happened to this club, I swear."
            else:
                sc "..."

                scene e4f2-sc_03 with dissolve
            if e3f3_help_mia == True:
                if e4f2_candance == True and e4f2_mia == True and e4f2_ken == True and e4f2_scarlett == True:
                    if optional_quests:
                        $ optional_quests.clear()
            else:
                if e4f2_candance == True and e4f2_ken == True and e4f2_scarlett == True:
                    if optional_quests:
                        $ optional_quests.clear()
            sc "Just... leave me alone."

        "Don't push it":
            $ scarlett_trust -= 1
            mc "..."

            scene e4f2-sc_06 with dissolve
            if e3f3_help_mia == True:
                if e4f2_candance == True and e4f2_mia == True and e4f2_ken == True and e4f2_scarlett == True:
                    if optional_quests:
                        $ optional_quests.clear()
            else:
                if e4f2_candance == True and e4f2_ken == True and e4f2_scarlett == True:
                    if optional_quests:
                        $ optional_quests.clear()
            sc "No come back?"
            sc "Pfft..."

    jump e4f2_bar
return

# Pool Couch ###
label e4f2_pool_couch:
    scene e4f2-08
    call screen e4f2_pool_couch with dissolve
return

# Vending Table ###
label e4f2_vending_table:
    scene e4f2-09
    call screen e4f2_vending_table with dissolve
return
