
# Scene 0 - Reversed chronology ################################################

label e4s0:
    $ renpy.block_rollback()
    $ config.rollback_enabled = False

    hide screen recap_skip

    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause(1.0)

    $ config.rollback_enabled = True

    play music hey_ruth fadeout 2.0
    scene e4s0-01 with Dissolve(2.0)
    ev "Alright, everyone, let's make sure we run this from start to finish today."
    ev "Given the fact that the competition is just around the corner, we'll need to have rehearsals almost daily."

    scene e4s0-02 with dissolve
    fr "I think [mc]'s running late again."

    scene e4s0-03 with dissolve
    ev "If he doesn't take this seriously soon, I'm not even sure he should be here anymore."

    scene e4s0-04 with dissolve
    play sound door_close
    pause

    scene e4s0-05 with dissolve
    fr "[mc]?"

    scene e4s0-06 with dissolve
    unknown "Hey, what's up?"

    scene e4s0-07 with dissolve
    ev "You're late."

    scene e4s0-08 with dissolve
    unknown "Sorry... had to make a pit stop."

    scene e4s0-07 with dissolve
    ev "Yeah, yeah. Just take a seat. We're starting soon."

    stop music fadeout 1.0
    scene e4s0-09 with dissolve
    fr "Wait..."
    fr "You're not [mc]!"

    scene e4s0-10 with dissolve
    ev "Huh?"

    scene e4s0-11 with dissolve
    ke "What do you mean I'm not [mc]?"
    ke "I'm here to play the drums!"

    scene e4s0-12 with dissolve
    eva "The drums??"

    scene e4s0-13 with dissolve
    el "Wait a minute, [ke]?"

    scene black
    play sound heart_beat
    show f1_text "A few days earlier." with wiperight
    pause

    hide f1_text with wipeleft

    jump e4s1
return
