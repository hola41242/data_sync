
# Scene 28 - Trust #############################################################

label e4s28:
    stop music fadeout 1.0
    scene black with Dissolve(2.0)
    pause(1.0)

    scene e4s28-01 with Dissolve(2.0)
    pause

    scene e4s28-02 with dissolve
    mc "..."
    mc "*I can't stop thinking about what happened the other night.*"

    if e4s27_listen == False:
        mc "*What did [am] mean by 'ask [fr] about it'?*"
        mc "*Did she really hide from me things about [am]?*"
        mc "*Or worse, maybe she's the bad guy in the story.*"
        mc "*Or maybe [am]'s just messing up with my head...*"
    else:
        mc "*The story [am] told me...*"

    if e4s27_believe == True:
        mc "*I believed her, she seemed genuine in that moment.*"
    else:
        mc "*I didn't believe her when she told me that.*"
        mc "*But what if it's true?*"

    mc "*What would her reason be to lie?*"
    mc "*What could [am] earn from all of this?*"
    mc "*It doesn't really add up.*"
    fr "Hey [mc]!"

    play music thanks_for_coming
    scene e4s28-03 with dissolve
    mc "*Shit, she's here.*"

    scene e4s28-04 with dissolve
    fr "Sorry, I ran a bit late."
    fr "My class was longer than usual today."

    scene e4s28-08 with dissolve
    mc "It's okay."

    scene e4s28-05 with dissolve
    pause

    scene e4s28-09 with dissolve
    fr "Have you started without me?"

    scene e4s28-06 with dissolve
    mc "Like I would know how to."

    scene e4s28-10 with dissolve
    fr "Haha!"

    if e4s11_help == False:
        fr "Thought you didn't need help anymore."

        scene e4s28-08 with dissolve
        mc "Yeah well... looks like I need it after all."

        scene e4s28-16 with dissolve
        mc "*I didn't need it, but I just wanted to meet up with her and talk.*"

    if e4s11_tell == True:
        scene e4s28-09 with dissolve
        fr "I also told [ev] about the whole [am] thing."
        fr "She shouldn't bother us anymore."

    scene e4s28-06 with dissolve
    pause

    scene e4s28-07 with dissolve
    pause

    scene e4s28-09 with dissolve
    fr "Hey, you're awfully quiet this morning."

    scene e4s28-11 with dissolve
    fr "Is there something wrong?"

    scene e4s28-14 with dissolve
    menu:
        "Tell her":
            $ e4s28_tell_her = True
            scene e4s28-15 with dissolve
            mc "*I hope I don't regret this...*"

            scene e4s28-13 with dissolve
            mc "There's something I want to talk to you about."

            scene e4s28-17 with dissolve
            fr "What's up?"

            scene e4s28-12 with dissolve
            show e4s28_francesca_blink1
            mc "So... last night I met up with [am]."

            scene e4s28-18 with dissolve
            hide e4s28_francesca_blink1
            fr "What? Why would you do that?"

            scene e4s28-36 with dissolve
            mc "She came into College Rock once again."
            mc "I don't know what her intentions were."
            mc "She only got there because I forgot to lock the place... I'm sorry."
        "Keep it to yourself":
            scene e4s28-16 with dissolve
            mc "*Maybe I'll tell her another time.*"

            scene e4s28-13 with dissolve
            mc "No, everything's alright."
            mc "Just thinking about the subject, that's all."

            scene e4s28-19 with dissolve
            fr "Oh, okay."

            scene e4s28-20 with dissolve
            fr "Seems like it's frying your brain, huh?"

            scene e4s28-21 with dissolve
            mc "Yeah... something like that."

            scene e4s28-20 with dissolve
            fr "Alright then, let's get started, shall we?"

            scene e4s28-21 with dissolve
            mc "Yeah... sure."

            scene e4s28-22 with dissolve
            pause

            scene black with Dissolve(2.0)
            pause(1.0)

            scene e4s28-22 with dissolve
            pause

            scene e4s28-23 with dissolve
            pause

            scene e4s28-24 with dissolve
            pause

            scene e4s28-26 with dissolve
            fr "Alright, there's something going on, I can tell it."

            scene e4s28-25 with dissolve
            fr "You haven't said a single thing since we began working."

            scene e4s28-12 with dissolve
            show e4s28_francesca_blink1
            mc "Yeah, because I'm focusing on it."

            scene e4s28-27 with dissolve
            hide e4s28_francesca_blink1
            fr "Dude, you haven't even began working on a single problem."

            scene e4s28-12 with dissolve
            show e4s28_francesca_blink1
            mc "Because it's hard?"

            scene e4s28-28 with dissolve
            hide e4s28_francesca_blink1
            fr "Alright, if you don't wanna tell me whatever."
            fr "You can keep it to yourself."

            scene e4s28-30 with dissolve
            fr "I just don't like it when you ignore me like that."

            scene e4s28-29 with dissolve
            menu:
                "Get defensive":
                    $ e4s28_defensive = True
                    $ francesca_trust -= 2
                    mc "..."
                    mc "Like how you shut me out? Left me wondering if I'd done something wrong?"

                    if e1s11_kiss_her == True:
                        mc "When you didn't want to talk to me after we kissed."
                    else:
                        mc "When you didn't want to talk to me for 3 days?"

                    fr "..."

                    scene e4s28-30 with dissolve
                    fr "Not cool [mc], not cool."
                    fr "Considering I already told you the reasons behind it and am actively trying to change..."
                    fr "Very shitty of you to hold that against me."

                    scene e4s28-29 with dissolve
                    mc "..."
                    mc "You're right... I'm sorry."
                    mc "I didn't mean it."

                    scene e4s28-37 with dissolve
                    fr "Well... you said it, so you obviously meant it."

                    scene e4s28-29 with dissolve
                    mc "..."
                    mc "Alright, I met up with [am] last night."
                "Shrug it off":
                    mc "..."

                    scene e4s28-16 with dissolve
                    pause
                    fr "Can you stop ignoring me, please?"

                    scene e4s28-31 with dissolve
                    fr "Tell me, did I do something wrong?"

                    scene e4s28-32 with dissolve
                    fr "Did something happen in your life?"

                    scene e4s28-38 with dissolve
                    fr "I don't want to stress you out, just want to know what's up..."

                    scene e4s28-39 with dissolve
                    mc "Alright, I met up with [am] last night."

            scene e4s28-35 with dissolve
            fr "What? Why would you do that?"

            scene e4s28-36 with dissolve
            mc "It's not like I planned to meet her."
            mc "She just showed up at College Rock again."
            mc "I basically forgot to lock the place and when I remembered she was already there."

    scene e4s28-31 with dissolve
    fr "Did she do anything?"

    scene e4s28-39 with dissolve
    mc "I don't know, from what she told me she didn't have time."
    mc "And it didn't seem like she stole anything."

    scene e4s28-30 with dissolve
    fr "Thank God I took the sheets back home that night to practice."

    scene e4s28-32 with dissolve
    fr "Maybe she was after those and failed to get them."

    scene e4s28-26 with dissolve
    fr "But we can never be so sure around her, we really have to remember to lock it every single time."

    scene e4s28-17 with dissolve
    fr "What else?"
    fr "What did she want?"

    scene e4s28-12 with dissolve
    show e4s28_francesca_blink1
    if e4s27_listen == True:
        mc "Well... she sat me down and told me her side of the story."
        mc "And how she believes you were both wrong, not just her."

        scene e4s28-33 with dissolve
        hide e4s28_francesca_blink1
        fr "..."

        scene e4s28-34 with dissolve
        fr "And you believed that?"

        scene e4s28-39 with dissolve
        if e4s27_believe == True:
            $ francesca_trust -= 1
            mc "I kind of did, yeah."
            mc "I'm sorry, she seemed genuine in the moment."
        else:
            $ francesca_trust += 1
            mc "I don't know..."
            mc "I didn't believe it when she told me."
            mc "But it kept eating at me and wanted your explanation."

        mc "Please tell me it's not true..."

        scene e4s28-31 with dissolve
        fr "What exactly did she tell you?"

        scene e4s28-39 with dissolve
        mc "Everything I think."
        mc "From her friends, to College Rock, to taking her spot in the squad."

        scene e4s28-35 with dissolve
        fr "But, that's not fair!"
        fr "That's not how it happened!"

        scene e4s28-36 with dissolve
        mc "Then how did it happen?"

        scene e4s28-29 with dissolve
        fr "..."
        mc "I can't believe this!"
        mc "Was she actually telling the truth?"

        scene e4s28-30 with dissolve
        fr "No..."

        scene e4s28-29 with dissolve
        mc "Oh my God [fr]..."
        mc "Why did you lie to me?"

        scene e4s28-38 with dissolve
        fr "I didn't lie to you!"
        fr "I told you that's not how it happened."

        scene e4s28-39 with dissolve
        mc "Then how did it happen?"

        scene e4s28-30 with dissolve
        fr "Yeah... I took her place in the squad, that is true."

        scene e4s28-35 with dissolve
        fr "But I didn't do it in bad faith!"

        scene e4s28-38 with dissolve
        fr "[ev] really wanted me to take over, she saw me as a better fit."
        fr "We were on the brink of losing the competition, I couldn't stand back and do nothing."

        scene e4s28-39 with dissolve
        mc "But did you think about how it affected her?"

        scene e4s28-32 with dissolve
        fr "Why does that matter?"
        fr "She is not a good person."

        scene e4s28-38 with dissolve
        fr "If she really cared about the club, she would have understood."

        scene e4s28-39 with dissolve
        mc "But it's not cool coming from her best friend."

        scene e4s28-37 with dissolve
        fr "Why are you defending her?"

        scene e4s28-39 with dissolve
        mc "Because I'm trying to see both sides here."

        scene e4s28-38 with dissolve
        fr "Really? Because it seems like you only see her side of the story."

        scene e4s28-39 with dissolve
        mc "That is not true at all!"
        mc "How can you even say that when you hid that from me?"
        mc "I don't have a problem with why you did it, I have a problem with why you lied to me."

        if francesca_trust > 4 or e4s23_francesca_lewd > 0 or e3s24_francesca_lewd == True:
            mc "I thought we were closer than that."
            mc "I thought I deserved to know the truth, let's leave Amber out of this for a bit."

            scene e4s28-35 with dissolve
            fr "You think I would lie to you?"
            fr "After what happened between us?"

            scene e4s28-36 with dissolve
            mc "You tell me!"
            mc "You think I wanted to believe her?"
            mc "After what happened between us... how could I not expect you to be honest?"
            mc "Think about it, how are we supposed to grow closer?"
            mc "Yeah, maybe you shouldn't open up about every personal stuff in your life."
            mc "But this [am] thing... I should have known from the beginning."
            mc "She's affecting all of us and you're not telling me all the facts."
        else:
            scene e4s28-30 with dissolve
            fr "I know why I did it!"

            scene e4s28-33 with dissolve
            mc "And why is that?"

            scene e4s28-38 with dissolve
            fr "Because she's a terrible person!"
            fr "I- I..."

            scene e4s28-39 with dissolve
            mc "What [fr]? What?"
            mc "I'm not telling you to open up about everything in your life."
            mc "I only want to know what could also affect me."
            mc "And this [am] thing... it's affecting all of us."

        scene e4s28-30 with dissolve
        fr "It's not my fault..."

        scene e4s28-29 with dissolve
        mc "Yeah, maybe it's not all your fault, but maybe you played your damn part in it as well."

        scene e4s28-38 with dissolve
        fr "[mc]... I..."

        if e4s27_believe == False:
            scene e4s28-35 with dissolve
            fr "You said you didn't believe her... but you came here ready to accuse me anyway."

        scene e4s28-32 with dissolve
        fr "That is not fair..."

        scene e4s28-30 with dissolve
        fr "Not..."

        scene e4s28-40 with dissolve
        mc "You're right... I-"

        scene e4s28-41 with dissolve
        pause

        scene e4s28-42 with dissolve
        fr "Wait, [fr]!"

        scene e4s28-43 with dissolve
        mc "*Shit... what have I done?*"
        mc "*Did I go too far again?*"

        scene e4s28-45 with dissolve
        mc "*Fuck...*"
        mc "..."

        stop music fadeout 1.0
        scene e4s28-44 with dissolve
        mc "*But she hid that from me!*"
        mc "*I'm not thinking straight... maybe I should call [ov] and talk about it.*"
    else:
        scene e4s28-12 with dissolve
        show e4s28_francesca_blink1
        mc "She tried to tell me something about you but I shut her down and told her to leave."

        scene e4s28-19 with dissolve
        hide e4s28_francesca_blink1
        fr "Good!"

        scene e4s28-12 with dissolve
        show e4s28_francesca_blink1
        mc "What was that all about?"

        scene e4s28-31 with dissolve
        hide e4s28_francesca_blink1
        fr "What do you mean?"

        scene e4s28-12 with dissolve
        show e4s28_francesca_blink1
        mc "I mean, what exactly did she want to tell me?"

        scene e4s28-30 with dissolve
        hide e4s28_francesca_blink1
        fr "Come on... you seriously believe her crap?"

        scene e4s28-12 with dissolve
        show e4s28_francesca_blink1
        mc "I don't, but I just want to make sure we're on the same page."
        mc "That's why I wanted to ask you about it."
        mc "It seems like [am] believes there's something more to the story, and I'd like to find out why."

        scene e4s28-30 with dissolve
        hide e4s28_francesca_blink1
        fr "There's nothing more, end of story."

        scene e4s28-34 with dissolve
        fr "After what I told you about her, you believe her?"

        scene e4s28-12 with dissolve
        show e4s28_francesca_blink1
        mc "I don't believe her!"
        mc "I just wanted to know what's up."

        scene e4s28-37 with dissolve
        hide e4s28_francesca_blink1
        fr "Why didn't you listen to her crap, then?"

        scene e4s28-32 with dissolve
        fr "Maybe you would have convinced yourself that she's making it up."

        scene e4s28-39 with dissolve
        mc "Why are you getting so defensive all of a sudden?"
        mc "If there's really nothing going on, you shouldn't be acting like this."

        scene e4s28-38 with dissolve
        fr "Yeah, because you actually believe her crap."
        fr "I told you already that she's not a good influence."

        scene e4s28-39 with dissolve
        mc "And I acknowledged that, I just wanted to know what she meant by 'there's more to the story'."

        scene e4s28-38 with dissolve
        fr "I... never mind."

        scene e4s28-46 with dissolve
        fr "I'm sorry, but I'm not feeling too well right now."
        fr "I need to clear my head."

        scene e4s28-47 with dissolve
        pause

        scene e4s28-48 with dissolve
        pause

        scene e4s28-49 with dissolve
        mc "*What was that?*"
        mc "*What is she hiding?*"
        mc "*That's not how I expected this to go at all...*"

        stop music fadeout 1.0
        scene e4s28-44 with dissolve
        mc "*Maybe I could have approached it differently.*"
        mc "*But why does it feel like I can't talk calmly anymore?*"
        mc "*I hate that...*"
        mc "*Maybe I should call [ov] and talk about that.*"
    jump e4s29
return
