
# Variables ####################################################################

# Fighting

default persistent.fight_difficulty = 0
default persistent.fight = 0
default persistent.fight_input = 0

# Episode count ################################################################

default episode_count = 1

# Disable 18+ Content ##########################################################

define persistent.disable_nsfw = True
define persistent.type_nsfw = False

# persistent.disable_nsfw == False
    # true = nsfw is enabled
    # false = nsfw is disabled

# persistent.type_nsfw == False
    # false = censor; true = skip;

default persistent.pageinvert = False

# Freeroam Collected Photos ####################################################

default collected_tp = 0
default collected_p = 0

# Guides #######################################################################

default persistent.intro = True
default persistent.tutorial = True

# Character Traits #############################################################
default introvert = 0
default extrovert = 0

default affinity_spectrum = 0

default money = 0

default music_skills = 0
default guitar_skills = 0
default strength = 0

# Character social status ######################################################

# Love Interests
default cleo_trust = 0
default francesca_trust = 0
default sadie_trust = 0
default tracy_trust = 0
default evelyn_trust = 0
default scarlett_trust = 0
default tiffany_trust = 0

# Other Female Characters
default olivia_trust = 0
default alice_trust = 0
default candance_trust = 0
default bridget_trust = 0
default mia_trust = 0
default ellie_trust = 0
default amber_trust = 0
default eva_trust = 0
default penny_trust = 0
default charlie_trust = 0
default claire_trust = 0
default lyla_trust = 0

# Male
default jon_friendship = 3
default nate_friendship = 0
default roman_friendship = 0
default ken_friendship = 0
default jordan_friendship = 0

# Character relationship status ################################################
default cleo_relationship = False
default francesca_relationship = False
default olivia_relationship = False
default sadie_relationship = False

# Intimacy variables (only for when the player has made serious progress with a LI)

default cleo_intimacy = 0
default tracy_intimacy = 0
default sadie_intimacy = 0
default francesca_intimacy = 0
default tiffany_intimacy = 0
default scarlett_intimacy = 0
default evelyn_intimacy = 0

# Episode 1 Variables ##########################################################

# E1S2
default e1s2_smile_back = False
default e1s2_talk_to_her = False

# E1S4
default balloon_hit = False

# E1S6
default e1s6_mad = False

# E1F3
default e1f3_rk_second = False

# E1S11
default e1s11_kiss_her = False

# E1S15
default e1s15_gfpretend = False
default e1s15_mad = False
default e1s15_calm = False
default e1s15_help = False

# E1S17
default e1s17_tracy = False
default e1s17_sadie = False
default e1s17_olivia = False

default e1s17_ov_ask = False
default e1s17_ovkiss = False

default e1s17_cleo_choice = False

# E1S18
default e1s18_ken_greet = False
default e1s18_sadie_greet = False
default e1s18_tracy_greet = False

# E1F2

default e1f2_tracy_kiss = False

# E1F5
default e1f5_scarlett_mytype = False
default e1f5_bouncer_talk = False
default e1f5_refuse_sadie = False
default e1f5_sadie_sex = False
default e1f5_tracy_sex = False
default e1f5_trsx_go_on = False
