
# Main Credits images ##########################################################

image credits-bg = im.Scale("credits/bg.webp", 1920, 1080)
image credits-logo = im.Scale("credits/logo.webp", 1920, 1080)

# E1 Credits images #

image e1_credits-bg_photos = im.Scale("season1/episode1/images/credits/bg_photos.webp", 1920, 1080)
image e1_credits-txt = im.Scale("season1/episode1/images/credits/txt.webp", 1920, 1080)

# E2 Credits images #

image e2_credits-bg_photos = im.Scale("season1/episode2/images/credits/bg_photos.webp", 1920, 1080)
image e2_credits-txt = im.Scale("season1/episode2/images/credits/txt.webp", 1920, 1080)

# E3 Credits images #

image e3_credits-bg_photos = im.Scale("season1/episode3/images/credits/bg_photos.webp", 1920, 1080)
image e3_credits-txt = im.Scale("season1/episode3/images/credits/txt.webp", 1920, 1080)

# E4 Credits images #

image e4_credits-bg_photos = im.Scale("season1/episode4/images/credits/bg_photos.webp", 1920, 1080)
image e4_credits-txt = im.Scale("season1/episode4/images/credits/txt.webp", 1920, 1080)

# E5 Credits images #

image e5_credits-bg_photos = im.Scale("season1/episode5/images/credits/bg_photos.webp", 1920, 1080)
image e5_credits-txt = im.Scale("season1/episode5/images/credits/txt.webp", 1920, 1080)

################################################################################


# Credits ############################################################

label credits:

    $ quick_menu = False

    if e4s36_song == False:
        play music "audio/menu/halloween_again.ogg"
    else:
        $ e4s36_song = False
    queue music ["audio/wonder_under.ogg", "audio/menu/perfect_one.ogg", "audio/college_rock.ogg"]

    scene credits-bg with dissolve
    if episode_count == 2:
        show e1_credits-txt with dissolve
        show e1_credits-bg_photos with Dissolve(2.0)
        pause

        hide credits-bg
        hide e1_credits-bg_photos with dissolve
        hide e1_credits-txt with dissolve
    if episode_count == 3:
        show e2_credits-txt with dissolve
        show e2_credits-bg_photos with Dissolve(2.0)
        pause

        hide credits-bg
        hide e2_credits-bg_photos with dissolve
        hide e2_credits-txt with dissolve
    if episode_count == 4:
        show e3_credits-txt with dissolve
        show e3_credits-bg_photos with Dissolve(2.0)
        pause

        hide credits-bg
        hide e3_credits-bg_photos with dissolve
        hide e3_credits-txt with dissolve
    if episode_count == 5:
        show e4_credits-txt with dissolve
        show e4_credits-bg_photos with Dissolve(2.0)
        pause

        hide credits-bg
        hide e4_credits-bg_photos with dissolve
        hide e4_credits-txt with dissolve
    if episode_count == 5.5:
        show e5_credits-txt with dissolve
        pause

        hide credits-bg with dissolve
        hide e5_credits-txt with dissolve

    show text "{size=60}Save your game now!{/size}" with dissolve
    pause

    if episode_count == 1:
        $ episode_count += 1

    if episode_count == 2:
        jump e1re

    if episode_count == 3:
        jump e2re

    if episode_count == 4:
        jump e3re

    if episode_count == 5:
        if e4s29_olivia_path == True and e4s36_olivia_cutscene == False:
            stop music fadeout 1.0
            scene e4s36-10 with Dissolve(2.0)
            unknown "*Nah... too corny.*"
            unknown "*Think... think...*"

            scene e4s36-11 with dissolve
            unknown "*...*"
            unknown "*I've never been the poetic kind.*"

            scene e4s36-10 with dissolve
            pause

            scene e4s36-13 with dissolve
            unknown "Alright, let's continue."

            scene e4s36-12 with dissolve
            unknown "*I know we had our moments.*"
            unknown "*And I know you will never forgive me.*"
            unknown "*But please, answer me, I need to know that you're well.*"
            unknown "*Even if it is without me, at least I'll be at peace.*"
            unknown "*Thank you for reading this letter, and I'm sorry.*"
            unknown "*For the pain I caused you.*"
            unknown "*I look forward to your response.*"
            unknown "*Signed, a stranger.*"
            unknown "*You'll know who I am.*"

            scene e4s36-13 with dissolve
            pause

        jump e4re

    scene credits-bg with dissolve
    show credits-logo with dissolve
    pause(1.0)

    hide credits-logo with dissolve

    call screen credits
return

# Credits Code #################################################################

label credits_2:
    stop music fadeout 5.0

    scene black with Dissolve(2.0)
    show text "Thanks for playing! \n This game was only made possible by you! \n \n Created by MCVN \n Sponsored by: {a=https://gamcore.com/}Gamcore{/a} \n Support the game on {a=https://patreon.com/mcvisualnovels}Patreon{/a}!" with dissolve
    if episode_count == 1:
        $ episode_count += 1
    if episode_count == 2:
        jump e1re
    if episode_count == 3:
        jump e2re
    if episode_count == 4:
        jump e3re
    if episode_count == 5:
        jump e4re
    pause

    scene black with dissolve
return

screen credits():

    if episode_count == 1:
        $ episode_count += 1

    if episode_count == 2:
        timer 0.01 action Jump ("e1re")

    if episode_count == 3:
        timer 0.01 action Jump ("e2re")

    if episode_count == 4:
        timer 0.01 action Jump ("e3re")

    if episode_count == 5:
        timer 0.01 action Jump ("e4re")

    key "mouseup_1" action Jump ("credits_2")
    key "K_SPACE" action Jump ("credits_2")
    key "K_RETURN" action Jump ("credits_2")

    style_prefix "credits_2"

    timer 118 action Jump ("credits_2") #118 seconds
    ## Adjust this number to control when the Credits screen is hidden and the game
    ## returns to its normal flow.

    frame at credits_scroll(1024.0): #bigger is slower
        ## Adjust this number to control the speed at which the credits scroll.
        background None
        xalign 0.5

        vbox:

            add "gui/logo.png":
                xsize 450
                ysize 249
                xalign 0.5
            null height 100


            text "Created by":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "MCVN":
                size 30
                xalign 0.5
            null height 75


            text "Sponsor(s)":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "Gamcore":
                size 30
                xalign 0.5
            null height 75


            text "Game Testers":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "MiltonPowers":
                size 30
                xalign 0.5
            null height 10

            text "Vrep":
                size 30
                xalign 0.5
            null height 10

            text "TonyMurray":
                size 30
                xalign 0.5
            null height 75


            text "Proof Readers":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "TonyMurray":
                size 30
                xalign 0.5
            null height 10

            text "MiltonPowers":
                size 30
                xalign 0.5
            null height 75


            text "Special thanks to":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "Ayko7":
                size 30
                xalign 0.5
            null height 10

            text "Resler32":
                size 30
                xalign 0.5
            null height 75


            text "Music (Creative commons license for commercial use)":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10
            text "source (Free Music Archive), license type (CC BY)":
                font "fonts/celebes_black.otf"
                color "#990000"
                size 40
                xalign 0.5
            null height 10

            text "Aftertune - Piano":
                size 30
                xalign 0.5
            null height 10
            text "Aftertune - Love You (Original Mix)":
                size 30
                xalign 0.5
            null height 10
            text "Akira Sora - 2010 Pop":
                size 30
                xalign 0.5
            null height 10
            text "Akira Sora - AUX ★ Original Mix":
                size 30
                xalign 0.5
            null height 10
            text "Anthem of Rain - Rock This House (Instrumental)":
                size 30
                xalign 0.5
            null height 10
            text "Anthem of Rain - Then I'm Gone (Instrumental)":
                size 30
                xalign 0.5
            null height 10
            text "Avantist - Tidalwave":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Encryption":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - French Toast":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Hard Love":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Heartache":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Inhale":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - It Was Then":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Milkshake":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Mom n' Pa":
                size 30
                xalign 0.5
            null height 10
            text "Beat Mekanik - Savage":
                size 30
                xalign 0.5
            null height 10
            text "BLUES OF T":
                size 30
                xalign 0.5
            null height 10
            text "Chris Zabriskie - It's All Around You":
                size 30
                xalign 0.5
            null height 10
            text "Cool Studios - OnFire":
                size 30
                xalign 0.5
            null height 10
            text "Creo - Dimension":
                size 30
                xalign 0.5
            null height 10
            text "Darkfluxx - Open Inside":
                size 30
                xalign 0.5
            null height 10
            text "Doctor Turtle - The Encouragement Stick":
                size 30
                xalign 0.5
            null height 10
            text "Doctor Turtle - Which That Is This (Long Version)":
                size 30
                xalign 0.5
            null height 10
            text "Easy Cheesy":
                size 30
                xalign 0.5
            null height 10
            text "Ethos - Coalescense":
                size 30
                xalign 0.5
            null height 10
            text "Evan Schaeffer - Laurel Breeze":
                size 30
                xalign 0.5
            null height 10
            text "Glad Rags - Wonder Under":
                size 30
                xalign 0.5
            null height 10
            text "Hotham - Dance Tonight":
                size 30
                xalign 0.5
            null height 10
            text "Jahzzar - Brighter":
                size 30
                xalign 0.5
            null height 10
            text "Jahzzar - Circles":
                size 30
                xalign 0.5
            null height 10
            text "Jahzzar - Liar":
                size 30
                xalign 0.5
            null height 10
            text "Jahzzar - Pause":
                size 30
                xalign 0.5
            null height 10
            text "Jangwa - River View":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - IN THE FIELD":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - MARATHON MAN":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - ONE FINE DAY":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - PIONEERS":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - RIVER MEDITATION":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - SERENITY":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - SOLO ACOUSTIC GUITAR":
                size 30
                xalign 0.5
            null height 10
            text "Jason Shaw - TRAVEL LIGHT":
                size 30
                xalign 0.5
            null height 10
            text "Jens East - Galaxies (ft. Diandra Faye)":
                size 30
                xalign 0.5
            null height 10
            text "Jens East - I Won't Fall In Love (feat. MaryLinn)":
                size 30
                xalign 0.5
            null height 10
            text "Jens East - Nightrise":
                size 30
                xalign 0.5
            null height 10
            text "JOEY HENDRIXX - DAFT PUNK (DISCO - RETRO - GROOVY)":
                size 30
                xalign 0.5
            null height 10
            text "John Bartmann - Bad Sexy Dad Vibes":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - 20/20":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Airplane Mode (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Bloom (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Border Blaster (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Crazy Glue (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Darien Gap - Instrumental":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Frannie (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Hey Ruth (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Hollow Grove (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - I Will Not Let You Let Me Down (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Inertia - Instrumental":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Invisible Light (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Little Tomcat (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Release":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Sundown (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Thanks For Coming (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - The Pawnbroker's Stepdaughter (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - With a Whimper":
                size 30
                xalign 0.5
            null height 10
            text "Josh Woodward - Words Fall Apart (Instrumental Version)":
                size 30
                xalign 0.5
            null height 10
            text "Kami - Moving Up":
                size 30
                xalign 0.5
            null height 10
            text "Kai Engel - Odesa":
                size 30
                xalign 0.5
            null height 10
            text "Kevin MacLeod - Aces High":
                size 30
                xalign 0.5
            null height 10
            text "Kevin MacLeod - Dances and Dames":
                size 30
                xalign 0.5
            null height 10
            text "Kevin MacLeod - Rollin at 5 - 210 - full":
                size 30
                xalign 0.5
            null height 10
            text "Lundstroem - Lundstroems daft punk":
                size 30
                xalign 0.5
            null height 10
            text "Magana - Area 51":
                size 30
                xalign 0.5
            null height 10
            text "Man Bites Dog - College Rock (How To Hold The Guitar Right)":
                size 30
                xalign 0.5
            null height 10
            text "Man Bites Dog - Perfect One":
                size 30
                xalign 0.5
            null height 10
            text "Mela - The Darker Side":
                size 30
                xalign 0.5
            null height 10
            text "Mr Smith - Breathe":
                size 30
                xalign 0.5
            null height 10
            text "Mr Smith - Punk Rock Holiday":
                size 30
                xalign 0.5
            null height 10
            text "Normcore - Heartless Man":
                size 30
                xalign 0.5
            null height 10
            text "Oh Yeah, the Future - Snowday":
                size 30
                xalign 0.5
            null height 10
            text "oji - failures.":
                size 30
                xalign 0.5
            null height 10
            text "PC-ONE - Love":
                size 30
                xalign 0.5
            null height 10
            text "PC-ONE - Write Hear Right Now (Instrumental Acoustic)":
                size 30
                xalign 0.5
            null height 10
            text "Pipe Choir - EVERYTHING WILL BE ALRIGHT":
                size 30
                xalign 0.5
            null height 10
            text "Play House - Random Drop":
                size 30
                xalign 0.5
            null height 10
            text "Punk Rock Opera - Nerve Damage":
                size 30
                xalign 0.5
            null height 10
            text "Quantum Jazz - Orbiting A Distant Planet":
                size 30
                xalign 0.5
            null height 10
            text "SLOU - Turn Up (Original Mix) - Bigroom House":
                size 30
                xalign 0.5
            null height 10
            text "Soundore - Evening Jazz":
                size 30
                xalign 0.5
            null height 10
            text "Steve Combs - Motown Rehearsal":
                size 30
                xalign 0.5
            null height 10
            text "Steve Combs - Sun Sets on a Protagonist":
                size 30
                xalign 0.5
            null height 10
            text "Steve Combs - William Henry Harrison High School Fight Song":
                size 30
                xalign 0.5
            null height 10
            text "Synthet - Ariana Grande Synthet instrumental":
                size 30
                xalign 0.5
            null height 10
            text "The New Valleys - Sad Guitar":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Brundlefly":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Careful!":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Electric Girlfriend":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Halloween Again":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Killer Rabbit":
                size 30
                xalign 0.5
            null height 10
            text "The Zombie Dandies - Welcome To Zombie Coast":
                size 30
                xalign 0.5
            null height 10
            text "UNIVERSFIELD - Beautiful Piano Melodies":
                size 30
                xalign 0.5
            null height 10
            text "UNIVERSFIELD - Bright and Positive Acoustic Melody":
                size 30
                xalign 0.5
            null height 10
            text "UNIVERSFIELD - Energizing Indie Pop Inspiration":
                size 30
                xalign 0.5
            null height 10
            text "UNIVERSFIELD - Sentimental Acoustic Tune for Emotional Scenes":
                size 30
                xalign 0.5
            null height 10
            text "Untimely Dosage - Keep it Down":
                size 30
                xalign 0.5
            null height 10
            text "Untimely Dosage - Pop Song":
                size 30
                xalign 0.5
            null height 10
            text "Van Loon - Dit It and Quit It":
                size 30
                xalign 0.5
            null height 10
            text "Van Loon - Hi As Hats":
                size 30
                xalign 0.5
            null height 75


            text "EPISODE 5 PART 1 - HAIL TO THE PRESIDENT":
                font "fonts/ArchitectBoldBold-AwdA.ttf"
                size 60
                xalign 0.5
return

transform credits_scroll(speed):
    xcenter 0.5 yanchor 0.0 ypos 1.0
    ypos 1200
    linear speed ypos -66000

style credits_hbox:
    spacing 40
    ysize 30

style credits_vbox:
    xalign 0.5
    text_align 0.5

style credits_label_text:
    xalign 0.5
    justify True
    size 125
    text_align 0.5
    color "#ff0000"

style credits_text:
    xalign 0.5
    size 60
    justify True
    text_align 0.5
    color "#ffffff"
