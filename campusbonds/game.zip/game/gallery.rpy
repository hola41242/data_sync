
init python:
    config.developer = False

image square_anim:
    "images/gallery/background.webp" with Dissolve(5.0)
    0.1
    "images/gallery/square.webp" with Dissolve(5.0)
    5
    "images/gallery/background.webp" with Dissolve(5.0)
    5
    repeat

label reset_gallery:

    call screen confirm(message="Are you sure you want to delete {color=#f00}{b}ALL{/b}{/color} your data? \n {color=#f00}{size=-10}{b} WARNING! THIS CAN'T BE UNDONE! {/b}{/size}{/color}",
    yes_action=Null, no_action=Jump("return_to_gallery")) with Dissolve(0.2)

    $ config.developer = True

    $ persistent._clear(progress=True)

    $ renpy.reload_script()

return

label return_to_gallery:
    call screen gallery with Dissolve(0.2)
return

define config.enter_replay_transition = fade

define config.exit_replay_transition = fade

default repeat = 1
default gallery = 0

default image_gallery = 0

screen gallery:

    # Layout ###################################################################

    add "square_anim"

    tag menu

    frame:
        yalign 0.95
        xalign 0.05
        textbutton "Main Menu" action Return()

    if gallery == 0:
        key "mouseup_3" action Return()
    else:
        key "mouseup_3" action SetScreenVariable("gallery", 0)

    frame:
        yalign 0.95
        xalign 0.95
        textbutton "Reset":
            action Call("reset_gallery")

    vbox:
        xalign 0.5
        yalign -0.01
        image "images/gallery/logo.png"

    # Scene Gallery ############################################################

    if gallery == 0:

        vbox:
            xalign 0.5
            yalign 0.95
            default episode = 1
            frame:
                hbox:
                    $ renpy.transition(Dissolve(0.2))
                    if episode == 1:
                        imagebutton:
                            idle "images/gallery/left_idle.webp"
                            action SetScreenVariable("episode", episode)
                    else:
                        imagebutton auto "images/gallery/left_%s.webp":
                            action SetScreenVariable("episode", episode -1)

                    textbutton "Episode [episode]"

                    if episode < 5:
                        imagebutton:
                            idle "images/gallery/right_idle.webp"
                            hover "images/gallery/right_hover.webp"
                            action SetScreenVariable("episode", episode +1)
                            #action NullAction()

                    else:
                        imagebutton:
                            idle "images/gallery/right_idle.webp"
                            action SetScreenVariable("episode", episode)

    if gallery == 0:

        vbox:
            xalign 0.5
            yalign 0.35
            spacing 20
            if episode == 1:
                $ renpy.transition(Dissolve(0.2))
                frame:
                    xsize 1550
                    ysize 830
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True
                        draggable True

                        frame:
                            imagebutton auto "images/gallery/season1/episode1/1_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e1s9_sadie_shower")

                        frame:
                            imagebutton auto "images/gallery/season1/episode1/2_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e1s9_tracy_shower")

                        if persistent.disable_nsfw == True:

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1s13_daydream")

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1f5_sadie_sex")

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1f5_tracy_sex")

                        if persistent.disable_nsfw == False:

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/censored/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1s13_daydream")

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/censored/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1f5_sadie_sex")

                            frame:
                                imagebutton auto "images/gallery/season1/episode1/censored/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e1f5_tracy_sex")

                        # Templates ################################################

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

            if episode == 2:
                $ renpy.transition(Dissolve(0.2))
                frame:
                    xsize 1550
                    ysize 830
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        if persistent.disable_nsfw == True:

                            if persistent.e2f1_daydream <= 1:
                                frame:
                                    imagebutton:
                                        idle "images/gallery/season1/episode2/1_idle.webp"
                                        hover "images/gallery/season1/episode2/1_50_hover.webp"
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e2f1_introvert_daydream")
                            if persistent.e2f1_daydream == 2:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode2/1_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e2f1_extrovert_daydream")

                        if persistent.disable_nsfw == False:

                            if persistent.e2f1_daydream <= 1:
                                frame:
                                    imagebutton:
                                        idle "images/gallery/season1/episode2/censored/1_idle.webp"
                                        hover "images/gallery/season1/episode2/censored/1_50_hover.webp"
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e2f1_introvert_daydream")
                            if persistent.e2f1_daydream == 2:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode2/censored/1_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e2f1_extrovert_daydream")

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/2_idle.webp"
                                    hover "images/gallery/season1/episode2/2_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2f2_tiffany_sex")
                        else:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/censored/2_idle.webp"
                                    hover "images/gallery/season1/episode2/censored/2_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2f2_tiffany_sex")

                        if persistent.e2f2_tracy_sex == True:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/3_idle.webp"
                                    hover "images/gallery/season1/episode2/3_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2f2_tracy_sex")
                        else:
                            frame:
                                imagebutton:
                                    idle "images/gallery/insensitive.webp"
                                    action NullAction()

                        frame:
                            imagebutton:
                                idle "images/gallery/season1/episode2/4_idle.webp"
                                hover "images/gallery/season1/episode2/4_hover.webp"
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e2s10_sadie_sex")

                        if persistent.e2s10_lap_dance <= 1:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/5_idle.webp"
                                    hover "images/gallery/season1/episode2/5_33_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2s10_lap_dance")
                        if persistent.e2s10_lap_dance == 2:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/5_idle.webp"
                                    hover "images/gallery/season1/episode2/5_66_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2s10_lap_dance")
                        if persistent.e2s10_lap_dance == 3:
                            frame:
                                imagebutton:
                                    idle "images/gallery/season1/episode2/5_idle.webp"
                                    hover "images/gallery/season1/episode2/5_hover.webp"
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e2s10_lap_dance")

                        frame:
                            imagebutton:
                                idle "images/gallery/season1/episode2/6_idle.webp"
                                hover "images/gallery/season1/episode2/6_hover.webp"
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e2s12_cleo_lewd")

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

            if episode == 3:
                $ renpy.transition(Dissolve(0.2))
                frame:
                    xsize 1550
                    ysize 830
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/1_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s6_sadie_sex")

                            frame:
                                imagebutton auto "images/gallery/season1/episode3/2_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3f3_tracy_sex")
                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/censored/1_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s6_sadie_sex")

                            frame:
                                imagebutton auto "images/gallery/season1/episode3/censored/2_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3f3_tracy_sex")

                        if persistent.e3s9_tiffany_sex == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s9_tiffany_sex")
                        else:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/3_50_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s9_tiffany_sex")

                        if persistent.e3s19_amber_lewd == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s19_amber")
                        else:
                            frame:
                                imagebutton:
                                    idle "images/gallery/insensitive.webp"

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s22_lewd")
                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode3/censored/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e3s22_lewd")

                        frame:
                            imagebutton auto "images/gallery/season1/episode3/6_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e3s24_lewd")

                        if persistent.disable_nsfw == True:
                            if persistent.e3s26_anal == True:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode3/7_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e3s26_candance_lewd")
                            else:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode3/7_50_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e3s26_candance_lewd")
                        if persistent.disable_nsfw == False:
                            if persistent.e3s26_anal == True:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode3/censored/7_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e3s26_candance_lewd")
                            else:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode3/censored/7_50_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e3s26_candance_lewd")

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

            if episode == 4:
                $ renpy.transition(Dissolve(0.2))
                frame:
                    xsize 1550
                    ysize 830
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            imagebutton auto "images/gallery/season1/episode4/1_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e4s3_lewd")

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/2_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s23_tracy_lewd")

                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/censored/2_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s23_tracy_lewd")

                        if persistent.e4s23_francesca_lewd == 2:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/3_50_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s23_francesca_lewd")
                        if persistent.e4s23_francesca_lewd == 1:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s23_francesca_lewd")

                        if persistent.e4s23_francesca_lewd == 0:
                            frame:
                                imagebutton:
                                    idle "images/gallery/insensitive.webp"
                                    action NullAction()

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s27_lewd")

                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode4/censored/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s27_lewd")

                        if persistent.disable_nsfw == True:
                            if persistent.e4s34_sadie_refuse == True:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode4/5_33_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e4s34_table_lewd")
                            else:
                                if persistent.e4s34_table_lewd == True:
                                    frame:
                                        imagebutton auto "images/gallery/season1/episode4/5_%s.webp":
                                            insensitive "images/gallery/insensitive.webp"
                                            action Replay("e4s34_table_lewd")
                                else:
                                    frame:
                                        imagebutton auto "images/gallery/season1/episode4/5_66_%s.webp":
                                            insensitive "images/gallery/insensitive.webp"
                                            action Replay("e4s34_table_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode4/6_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s34_bathroom_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode4/7_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s35_lewd")

                        if persistent.disable_nsfw == False:
                            if persistent.e4s34_sadie_refuse == True:
                                frame:
                                    imagebutton auto "images/gallery/season1/episode4/censored/5_33_%s.webp":
                                        insensitive "images/gallery/insensitive.webp"
                                        action Replay("e4s34_table_lewd")
                            else:
                                if persistent.e4s34_table_lewd == True:
                                    frame:
                                        imagebutton auto "images/gallery/season1/episode4/censored/5_%s.webp":
                                            insensitive "images/gallery/insensitive.webp"
                                            action Replay("e4s34_table_lewd")
                                else:
                                    frame:
                                        imagebutton auto "images/gallery/season1/episode4/censored/5_66_%s.webp":
                                            insensitive "images/gallery/insensitive.webp"
                                            action Replay("e4s34_table_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode4/censored/6_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s34_bathroom_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode4/censored/7_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e4s35_lewd")

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

            if episode == 5:
                $ renpy.transition(Dissolve(0.2))
                frame:
                    xsize 1550
                    ysize 830
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            imagebutton auto "images/gallery/season1/episode5/1_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e5f2_cleo_lewd")

                        frame:
                            imagebutton auto "images/gallery/season1/episode5/2_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e5s13_amber_lewd")

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode5/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s16_tiffany_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode5/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s20_cheerleader_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode5/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s22_evelyn_lewd")

                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode5/censored/3_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s16_tiffany_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode5/censored/4_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s20_cheerleader_lewd")

                            frame:
                                imagebutton auto "images/gallery/season1/episode5/censored/5_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5s22_evelyn_lewd")

                        frame:
                            imagebutton auto "images/gallery/season1/episode5/6_%s.webp":
                                insensitive "images/gallery/insensitive.webp"
                                action Replay("e5s25_francesca_lewd")

                        if persistent.disable_nsfw == True:
                            frame:
                                imagebutton auto "images/gallery/season1/episode5/7_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5f3_ruby_lewd")

                        if persistent.disable_nsfw == False:
                            frame:
                                imagebutton auto "images/gallery/season1/episode5/censored/7_%s.webp":
                                    insensitive "images/gallery/insensitive.webp"
                                    action Replay("e5f3_ruby_lewd")

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

    # Buttons #

    if gallery == 1:

        frame:
            yalign 0.949
            xalign 0.62
            textbutton "Scenes" action SetScreenVariable("gallery", 0)

    if gallery == 2:

        frame:
            yalign 0.949
            xalign 0.374
            textbutton "Scenes" action SetScreenVariable("gallery", 0)

    # Photo Gallery ############################################################

    if gallery == 2:

        vbox:
            xalign 0.5
            yalign 0.35
            spacing 20

            $ renpy.transition(Dissolve(0.2))

            frame:
                xsize 1550
                ysize 830

                if image_gallery == 0:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        yalign 0.5
                        xalign 0.5
                        cols 8
                        spacing 10

                        mousewheel True
                        scrollbars "horizontal"
                        draggable True

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/scarlett_idle.webp"
                                    hover "images/gallery/image_gallery/scarlett_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.0
                                    action SetScreenVariable("image_gallery", 1)

                                if any(persistent.scarlett_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "scarlett_gallery", format=u"Scarlett {seen}/{total}")

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/cleo_idle.webp"
                                    hover "images/gallery/image_gallery/cleo_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 2)

                                if any(persistent.cleo_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "cleo_gallery", format=u'Cleo {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/tracy_idle.webp"
                                    hover "images/gallery/image_gallery/tracy_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 3)

                                if any(persistent.tracy_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "tracy_gallery", format=u'Tracy {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/sadie_idle.webp"
                                    hover "images/gallery/image_gallery/sadie_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 4)

                                if any(persistent.sadie_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "sadie_gallery", format=u'Sadie {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/francesca_idle.webp"
                                    hover "images/gallery/image_gallery/francesca_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 5)

                                if any(persistent.francesca_list):
                                    add "gui/exclamation_mark.png"
                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "francesca_gallery", format=u'Francesca {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/tiffany_idle.webp"
                                    hover "images/gallery/image_gallery/tiffany_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 6)

                                if any(persistent.tiffany_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "tiffany_gallery", format=u'Tiffany {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/evelyn_idle.webp"
                                    hover "images/gallery/image_gallery/evelyn_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 7)

                                if any(persistent.evelyn_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "evelyn_gallery", format=u'Evelyn {seen}/{total}')

                        vbox:
                            frame:
                                xsize 351
                                ysize 746
                                imagebutton:
                                    idle "images/gallery/image_gallery/mixed_idle.webp"
                                    hover "images/gallery/image_gallery/mixed_hover.webp"
                                    xsize 340
                                    ysize 734
                                    xalign 0.95
                                    yalign 0.5
                                    action SetScreenVariable("image_gallery", 8)

                                if any(persistent.mixed_list):
                                    add "gui/exclamation_mark.png"

                            vbox:
                                xalign 0.5
                                text g.get_fraction(name = "mixed_gallery", format=u'Mixed {seen}/{total}')

                if image_gallery == 1:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="scarlett_gallery_1", locked="insensitive", unlocked="sc_gallery_1_th")

                            if persistent.sc_gallery_1_unlocked == True:
                                if persistent.scarlett1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett1", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="scarlett_gallery_2", locked="insensitive", unlocked="sc_gallery_2_th")

                            if persistent.sc_gallery_2_unlocked == True:
                                if persistent.scarlett2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett2", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_3", locked="insensitive", unlocked="sc_gallery_3_th")

                                if persistent.sc_gallery_3_unlocked == True:
                                    if persistent.scarlett3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett3", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_3_cen", locked="insensitive", unlocked="sc_gallery_3_th_cen")

                                if persistent.sc_gallery_3_unlocked == True:
                                    if persistent.scarlett3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett3", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_4", locked="insensitive", unlocked="sc_gallery_4_th")

                            if persistent.sc_gallery_4_unlocked == True:
                                if persistent.scarlett4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett4", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_5", locked="insensitive", unlocked="sc_gallery_5_th")

                            if persistent.sc_gallery_5_unlocked == True:
                                if persistent.scarlett5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett5", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_6", locked="insensitive", unlocked="sc_gallery_6_th")

                                if persistent.sc_gallery_6_unlocked == True:
                                    if persistent.scarlett6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett6", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_7", locked="insensitive", unlocked="sc_gallery_7_th")

                                if persistent.sc_gallery_7_unlocked == True:
                                    if persistent.scarlett7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett7", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_8", locked="insensitive", unlocked="sc_gallery_8_th")

                                if persistent.sc_gallery_8_unlocked == True:
                                    if persistent.scarlett8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett8", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_6_cen", locked="insensitive", unlocked="sc_gallery_6_th_cen")

                                if persistent.sc_gallery_6_unlocked == True:
                                    if persistent.scarlett6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett6", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_7_cen", locked="insensitive", unlocked="sc_gallery_7_th_cen")

                                if persistent.sc_gallery_7_unlocked == True:
                                    if persistent.scarlett7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett7", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_8_cen", locked="insensitive", unlocked="sc_gallery_8_th_cen")

                                if persistent.sc_gallery_8_unlocked == True:
                                    if persistent.scarlett8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett8", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_9", locked="insensitive", unlocked="sc_gallery_9_th")

                            if persistent.sc_gallery_9_unlocked == True:
                                if persistent.scarlett9 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett9", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_10", locked="insensitive", unlocked="sc_gallery_10_th")

                            if persistent.sc_gallery_10_unlocked == True:
                                if persistent.scarlett10 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett10", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_11", locked="insensitive", unlocked="sc_gallery_11_th")

                                if persistent.sc_gallery_11_unlocked == True:
                                    if persistent.scarlett11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett11", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="scarlett_gallery_11_cen", locked="insensitive", unlocked="sc_gallery_11_th_cen")

                                if persistent.sc_gallery_11_unlocked == True:
                                    if persistent.scarlett11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.scarlett11", False), Function(update_scarlett_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_12", locked="insensitive", unlocked="sc_gallery_12_th")

                            if persistent.sc_gallery_12_unlocked == True:
                                if persistent.scarlett12 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett12", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_13", locked="insensitive", unlocked="sc_gallery_13_th")

                            if persistent.sc_gallery_13_unlocked == True:
                                if persistent.scarlett13 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett13", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="scarlett_gallery_14", locked="insensitive", unlocked="sc_gallery_14_th")

                            if persistent.sc_gallery_14_unlocked == True:
                                if persistent.scarlett14 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.scarlett14", False), Function(update_scarlett_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                if image_gallery == 2:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="cleo_gallery_1", locked="insensitive", unlocked="cl_gallery_1_th")

                            if persistent.cl_gallery_1_unlocked == True:
                                if persistent.cleo1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo1", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_2", locked="insensitive", unlocked="cl_gallery_2_th")

                            if persistent.cl_gallery_2_unlocked == True:
                                if persistent.cleo2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo2", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_3", locked="insensitive", unlocked="cl_gallery_3_th")

                            if persistent.cl_gallery_3_unlocked == True:
                                if persistent.cleo3 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo3", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_4", locked="insensitive", unlocked="cl_gallery_4_th")

                            if persistent.cl_gallery_4_unlocked == True:
                                if persistent.cleo4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo4", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_5", locked="insensitive", unlocked="cl_gallery_5_th")

                            if persistent.cl_gallery_5_unlocked == True:
                                if persistent.cleo5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo5", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_6", locked="insensitive", unlocked="cl_gallery_6_th")

                            if persistent.cl_gallery_6_unlocked == True:
                                if persistent.cleo6 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo6", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_7", locked="insensitive", unlocked="cl_gallery_7_th")

                            if persistent.cl_gallery_7_unlocked == True:
                                if persistent.cleo7 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo7", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="cleo_gallery_8", locked="insensitive", unlocked="cl_gallery_8_th")

                                if persistent.cl_gallery_8_unlocked == True:
                                    if persistent.cleo8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.cleo8", False), Function(update_cleo_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="cleo_gallery_8_cen", locked="insensitive", unlocked="cl_gallery_8_th_cen")

                                if persistent.cl_gallery_8_unlocked == True:
                                    if persistent.cleo8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.cleo8", False), Function(update_cleo_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_9", locked="insensitive", unlocked="cl_gallery_9_th")

                            if persistent.cl_gallery_9_unlocked == True:
                                if persistent.cleo9 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo9", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_10", locked="insensitive", unlocked="cl_gallery_10_th")

                            if persistent.cl_gallery_10_unlocked == True:
                                if persistent.cleo10 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo10", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_11", locked="insensitive", unlocked="cl_gallery_11_th")

                            if persistent.cl_gallery_11_unlocked == True:
                                if persistent.cleo11 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo11", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_12", locked="insensitive", unlocked="cl_gallery_12_th")

                            if persistent.cl_gallery_12_unlocked == True:
                                if persistent.cleo12 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo12", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_13", locked="insensitive", unlocked="cl_gallery_13_th")

                            if persistent.cl_gallery_13_unlocked == True:
                                if persistent.cleo13 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo13", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_14", locked="insensitive", unlocked="cl_gallery_14_th")

                            if persistent.cl_gallery_14_unlocked == True:
                                if persistent.cleo14 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo14", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_15", locked="insensitive", unlocked="cl_gallery_15_th")

                            if persistent.cl_gallery_15_unlocked == True:
                                if persistent.cleo15 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo15", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="cleo_gallery_16", locked="insensitive", unlocked="cl_gallery_16_th")

                            if persistent.cl_gallery_16_unlocked == True:
                                if persistent.cleo16 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.cleo16", False), Function(update_cleo_list)]

                                    add "gui/exclamation_mark.png"

                if image_gallery == 3:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tracy_gallery_1", locked="insensitive", unlocked="tr_gallery_1_th")

                            if persistent.tr_gallery_1_unlocked == True:
                                if persistent.tracy1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy1", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_2", locked="insensitive", unlocked="tr_gallery_2_th")

                                if persistent.tr_gallery_2_unlocked == True:
                                    if persistent.tracy2 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy2", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_3", locked="insensitive", unlocked="tr_gallery_3_th")

                                if persistent.tr_gallery_3_unlocked == True:
                                    if persistent.tracy3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy3", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_2_cen", locked="insensitive", unlocked="tr_gallery_2_th_cen")

                                if persistent.tr_gallery_2_unlocked == True:
                                    if persistent.tracy2 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy2", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_3_cen", locked="insensitive", unlocked="tr_gallery_3_th_cen")

                                if persistent.tr_gallery_3_unlocked == True:
                                    if persistent.tracy3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy3", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_4", locked="insensitive", unlocked="tr_gallery_4_th")

                            if persistent.tr_gallery_4_unlocked == True:
                                if persistent.tracy4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy4", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_5", locked="insensitive", unlocked="tr_gallery_5_th")

                                if persistent.tr_gallery_5_unlocked == True:
                                    if persistent.tracy5 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy5", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_6", locked="insensitive", unlocked="tr_gallery_6_th")

                                if persistent.tr_gallery_6_unlocked == True:
                                    if persistent.tracy6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy6", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_7", locked="insensitive", unlocked="tr_gallery_7_th")

                                if persistent.tr_gallery_7_unlocked == True:
                                    if persistent.tracy7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy7", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_8", locked="insensitive", unlocked="tr_gallery_8_th")

                                if persistent.tr_gallery_8_unlocked == True:
                                    if persistent.tracy8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy8", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_5_cen", locked="insensitive", unlocked="tr_gallery_5_th_cen")

                                if persistent.tr_gallery_5_unlocked == True:
                                    if persistent.tracy5 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy5", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_6_cen", locked="insensitive", unlocked="tr_gallery_6_th_cen")

                                if persistent.tr_gallery_6_unlocked == True:
                                    if persistent.tracy6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy6", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_7_cen", locked="insensitive", unlocked="tr_gallery_7_th_cen")

                                if persistent.tr_gallery_7_unlocked == True:
                                    if persistent.tracy7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy7", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_8_cen", locked="insensitive", unlocked="tr_gallery_8_th_cen")

                                if persistent.tr_gallery_8_unlocked == True:
                                    if persistent.tracy8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy8", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_9", locked="insensitive", unlocked="tr_gallery_9_th")

                            if persistent.tr_gallery_9_unlocked == True:
                                if persistent.tracy9 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy9", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_10", locked="insensitive", unlocked="tr_gallery_10_th")

                                if persistent.tr_gallery_10_unlocked == True:
                                    if persistent.tracy10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy10", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_11", locked="insensitive", unlocked="tr_gallery_11_th")

                                if persistent.tr_gallery_11_unlocked == True:
                                    if persistent.tracy11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy11", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_10_cen", locked="insensitive", unlocked="tr_gallery_10_th_cen")

                                if persistent.tr_gallery_10_unlocked == True:
                                    if persistent.tracy10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy10", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tracy_gallery_11_cen", locked="insensitive", unlocked="tr_gallery_11_th_cen")

                                if persistent.tr_gallery_11_unlocked == True:
                                    if persistent.tracy11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tracy11", False), Function(update_tracy_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_12", locked="insensitive", unlocked="tr_gallery_12_th")

                            if persistent.tr_gallery_12_unlocked == True:
                                if persistent.tracy12 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy12", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_13", locked="insensitive", unlocked="tr_gallery_13_th")

                            if persistent.tr_gallery_13_unlocked == True:
                                if persistent.tracy13 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy13", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_14", locked="insensitive", unlocked="tr_gallery_14_th")

                            if persistent.tr_gallery_14_unlocked == True:
                                if persistent.tracy14 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy14", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_15", locked="insensitive", unlocked="tr_gallery_15_th")

                            if persistent.tr_gallery_15_unlocked == True:
                                if persistent.tracy15 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy15", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="tracy_gallery_16", locked="insensitive", unlocked="tr_gallery_16_th")

                            if persistent.tr_gallery_16_unlocked == True:
                                if persistent.tracy16 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tracy16", False), Function(update_tracy_list)]

                                    add "gui/exclamation_mark.png"

                if image_gallery == 4:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="sadie_gallery_1", locked="insensitive", unlocked="sd_gallery_1_th")

                            if persistent.sd_gallery_1_unlocked == True:
                                if persistent.sadie1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie1", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_2", locked="insensitive", unlocked="sd_gallery_2_th")

                            if persistent.sd_gallery_2_unlocked == True:
                                if persistent.sadie2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie2", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_3", locked="insensitive", unlocked="sd_gallery_3_th")

                                if persistent.sd_gallery_3_unlocked == True:
                                    if persistent.sadie3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie3", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_3_cen", locked="insensitive", unlocked="sd_gallery_3_th_cen")

                                if persistent.sd_gallery_3_unlocked == True:
                                    if persistent.sadie3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie3", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_4", locked="insensitive", unlocked="sd_gallery_4_th")

                            if persistent.sd_gallery_4_unlocked == True:
                                if persistent.sadie4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie4", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_5", locked="insensitive", unlocked="sd_gallery_5_th")

                            if persistent.sd_gallery_5_unlocked == True:
                                if persistent.sadie5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie5", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_6", locked="insensitive", unlocked="sd_gallery_6_th")

                            if persistent.sd_gallery_6_unlocked == True:
                                if persistent.sadie6 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie6", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_7", locked="insensitive", unlocked="sd_gallery_7_th")

                            if persistent.sd_gallery_7_unlocked == True:
                                if persistent.sadie7 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie7", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_8", locked="insensitive", unlocked="sd_gallery_8_th")

                                if persistent.sd_gallery_8_unlocked == True:
                                    if persistent.sadie8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie8", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_9", locked="insensitive", unlocked="sd_gallery_9_th")

                                if persistent.sd_gallery_9_unlocked == True:
                                    if persistent.sadie9 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie9", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_8_cen", locked="insensitive", unlocked="sd_gallery_8_th_cen")

                                if persistent.sd_gallery_8_unlocked == True:
                                    if persistent.sadie8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie8", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_9_cen", locked="insensitive", unlocked="sd_gallery_9_th_cen")

                                if persistent.sd_gallery_9_unlocked == True:
                                    if persistent.sadie9 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie9", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_10", locked="insensitive", unlocked="sd_gallery_10_th")

                            if persistent.sd_gallery_10_unlocked == True:
                                if persistent.sadie10 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie10", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_11", locked="insensitive", unlocked="sd_gallery_11_th")

                                if persistent.sd_gallery_11_unlocked == True:
                                    if persistent.sadie11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie11", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_12", locked="insensitive", unlocked="sd_gallery_12_th")

                                if persistent.sd_gallery_12_unlocked == True:
                                    if persistent.sadie12 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie12", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_11_cen", locked="insensitive", unlocked="sd_gallery_11_th_cen")

                                if persistent.sd_gallery_11_unlocked == True:
                                    if persistent.sadie11 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie11", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="sadie_gallery_12_cen", locked="insensitive", unlocked="sd_gallery_12_th_cen")

                                if persistent.sd_gallery_12_unlocked == True:
                                    if persistent.sadie12 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.sadie12", False), Function(update_sadie_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_13", locked="insensitive", unlocked="sd_gallery_13_th")

                            if persistent.sd_gallery_13_unlocked == True:
                                if persistent.sadie13 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie13", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_14", locked="insensitive", unlocked="sd_gallery_14_th")

                            if persistent.sd_gallery_14_unlocked == True:
                                if persistent.sadie14 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie14", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_15", locked="insensitive", unlocked="sd_gallery_15_th")

                            if persistent.sd_gallery_15_unlocked == True:
                                if persistent.sadie15 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie15", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="sadie_gallery_16", locked="insensitive", unlocked="sd_gallery_16_th")

                            if persistent.sd_gallery_16_unlocked == True:
                                if persistent.sadie16 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.sadie16", False), Function(update_sadie_list)]

                                    add "gui/exclamation_mark.png"

                if image_gallery == 5:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="francesca_gallery_1", locked="insensitive", unlocked="fr_gallery_1_th")

                            if persistent.fr_gallery_1_unlocked == True:
                                if persistent.francesca1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca1", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_2", locked="insensitive", unlocked="fr_gallery_2_th")

                            if persistent.fr_gallery_2_unlocked == True:
                                if persistent.francesca2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca2", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_3", locked="insensitive", unlocked="fr_gallery_3_th")

                            if persistent.fr_gallery_3_unlocked == True:
                                if persistent.francesca3 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca3", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_4", locked="insensitive", unlocked="fr_gallery_4_th")

                            if persistent.fr_gallery_4_unlocked == True:
                                if persistent.francesca4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca4", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_5", locked="insensitive", unlocked="fr_gallery_5_th")

                            if persistent.fr_gallery_5_unlocked == True:
                                if persistent.francesca5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca5", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_6", locked="insensitive", unlocked="fr_gallery_6_th")

                                if persistent.fr_gallery_6_unlocked == True:
                                    if persistent.francesca6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca6", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_7", locked="insensitive", unlocked="fr_gallery_7_th")

                                if persistent.fr_gallery_7_unlocked == True:
                                    if persistent.francesca7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca7", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_6_cen", locked="insensitive", unlocked="fr_gallery_6_th_cen")

                                if persistent.fr_gallery_6_unlocked == True:
                                    if persistent.francesca6 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca6", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_7_cen", locked="insensitive", unlocked="fr_gallery_7_th_cen")

                                if persistent.fr_gallery_7_unlocked == True:
                                    if persistent.francesca7 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca7", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_8", locked="insensitive", unlocked="fr_gallery_8_th")

                            if persistent.fr_gallery_8_unlocked == True:
                                if persistent.francesca8 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca8", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_9", locked="insensitive", unlocked="fr_gallery_9_th")

                                if persistent.fr_gallery_9_unlocked == True:
                                    if persistent.francesca9 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca9", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_10", locked="insensitive", unlocked="fr_gallery_10_th")

                                if persistent.fr_gallery_10_unlocked == True:
                                    if persistent.francesca10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca10", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_9_cen", locked="insensitive", unlocked="fr_gallery_9_th_cen")

                                if persistent.fr_gallery_9_unlocked == True:
                                    if persistent.francesca9 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca9", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_10_cen", locked="insensitive", unlocked="fr_gallery_10_th_cen")

                                if persistent.fr_gallery_10_unlocked == True:
                                    if persistent.francesca10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca10", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="francesca_gallery_11", locked="insensitive", unlocked="fr_gallery_11_th")

                            if persistent.fr_gallery_11_unlocked == True:
                                if persistent.francesca11 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.francesca11", False), Function(update_francesca_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_12", locked="insensitive", unlocked="fr_gallery_12_th")

                                if persistent.fr_gallery_12_unlocked == True:
                                    if persistent.francesca12 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca12", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_13", locked="insensitive", unlocked="fr_gallery_13_th")

                                if persistent.fr_gallery_13_unlocked == True:
                                    if persistent.francesca13 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca13", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_12_cen", locked="insensitive", unlocked="fr_gallery_12_th_cen")

                                if persistent.fr_gallery_12_unlocked == True:
                                    if persistent.francesca12 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca12", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="francesca_gallery_13_cen", locked="insensitive", unlocked="fr_gallery_13_th_cen")

                                if persistent.fr_gallery_13_unlocked == True:
                                    if persistent.francesca13 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.francesca13", False), Function(update_francesca_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                if image_gallery == 6:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_1", locked="insensitive", unlocked="tf_gallery_1_th")

                            if persistent.tf_gallery_1_unlocked == True:
                                if persistent.tiffany1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany1", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_2", locked="insensitive", unlocked="tf_gallery_2_th")

                            if persistent.tf_gallery_2_unlocked == True:
                                if persistent.tiffany2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany2", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_3", locked="insensitive", unlocked="tf_gallery_3_th")

                            if persistent.tf_gallery_3_unlocked == True:
                                if persistent.tiffany3 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany3", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="tiffany_gallery_4", locked="insensitive", unlocked="tf_gallery_4_th")

                                if persistent.tf_gallery_4_unlocked == True:
                                    if persistent.tiffany4 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tiffany4", False), Function(update_tiffany_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tiffany_gallery_4_cen", locked="insensitive", unlocked="tf_gallery_4_th_cen")

                                if persistent.tf_gallery_4_unlocked == True:
                                    if persistent.tiffany4 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tiffany4", False), Function(update_tiffany_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_5", locked="insensitive", unlocked="tf_gallery_5_th")

                            if persistent.tf_gallery_5_unlocked == True:
                                if persistent.tiffany5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany5", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_6", locked="insensitive", unlocked="tf_gallery_6_th")

                            if persistent.tf_gallery_6_unlocked == True:
                                if persistent.tiffany6 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany6", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_7", locked="insensitive", unlocked="tf_gallery_7_th")

                            if persistent.tf_gallery_7_unlocked == True:
                                if persistent.tiffany7 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany7", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="tiffany_gallery_8", locked="insensitive", unlocked="tf_gallery_8_th")

                                if persistent.tf_gallery_8_unlocked == True:
                                    if persistent.tiffany8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tiffany8", False), Function(update_tiffany_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="tiffany_gallery_8_cen", locked="insensitive", unlocked="tf_gallery_8_th_cen")

                                if persistent.tf_gallery_8_unlocked == True:
                                    if persistent.tiffany8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.tiffany8", False), Function(update_tiffany_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="tiffany_gallery_9", locked="insensitive", unlocked="tf_gallery_9_th")

                            if persistent.tf_gallery_9_unlocked == True:
                                if persistent.tiffany9 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.tiffany9", False), Function(update_tiffany_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                if image_gallery == 7:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="evelyn_gallery_1", locked="insensitive", unlocked="ev_gallery_1_th")

                            if persistent.ev_gallery_1_unlocked == True:
                                if persistent.evelyn1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.evelyn1", False), Function(update_evelyn_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="evelyn_gallery_2", locked="insensitive", unlocked="ev_gallery_2_th")

                            if persistent.ev_gallery_2_unlocked == True:
                                if persistent.evelyn2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.evelyn2", False), Function(update_evelyn_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_3", locked="insensitive", unlocked="ev_gallery_3_th")

                                if persistent.ev_gallery_3_unlocked == True:
                                    if persistent.evelyn3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn3", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_4", locked="insensitive", unlocked="ev_gallery_4_th")

                                if persistent.ev_gallery_4_unlocked == True:
                                    if persistent.evelyn4 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn4", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_3_cen", locked="insensitive", unlocked="ev_gallery_3_th_cen")

                                if persistent.ev_gallery_3_unlocked == True:
                                    if persistent.evelyn3 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn3", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_4_cen", locked="insensitive", unlocked="ev_gallery_4_th_cen")

                                if persistent.ev_gallery_4_unlocked == True:
                                    if persistent.evelyn4 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn4", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="evelyn_gallery_5", locked="insensitive", unlocked="ev_gallery_5_th")

                            if persistent.ev_gallery_5_unlocked == True:
                                if persistent.evelyn5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.evelyn5", False), Function(update_evelyn_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="evelyn_gallery_6", locked="insensitive", unlocked="ev_gallery_6_th")

                            if persistent.ev_gallery_6_unlocked == True:
                                if persistent.evelyn6 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.evelyn6", False), Function(update_evelyn_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192

                            add g.make_button(name="evelyn_gallery_7", locked="insensitive", unlocked="ev_gallery_7_th")

                            if persistent.ev_gallery_7_unlocked == True:
                                if persistent.evelyn7 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.evelyn7", False), Function(update_evelyn_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_8", locked="insensitive", unlocked="ev_gallery_8_th")

                                if persistent.ev_gallery_8_unlocked == True:
                                    if persistent.evelyn8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn8", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192

                                add g.make_button(name="evelyn_gallery_8_cen", locked="insensitive", unlocked="ev_gallery_8_th_cen")

                                if persistent.ev_gallery_8_unlocked == True:
                                    if persistent.evelyn8 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.evelyn8", False), Function(update_evelyn_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                if image_gallery == 8:
                    $ renpy.transition(Dissolve(0.2))
                    vpgrid:
                        xalign 0.5
                        cols 4
                        spacing 50

                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_1", locked="insensitive", unlocked="mixed_gallery_1_th")

                            if persistent.mixed_gallery_1_unlocked == True:
                                if persistent.mixed1 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed1", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_2", locked="insensitive", unlocked="mixed_gallery_2_th")

                            if persistent.mixed_gallery_2_unlocked == True:
                                if persistent.mixed2 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed2", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_3", locked="insensitive", unlocked="mixed_gallery_3_th")

                            if persistent.mixed_gallery_3_unlocked == True:
                                if persistent.mixed3 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed3", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_4", locked="insensitive", unlocked="mixed_gallery_4_th")

                            if persistent.mixed_gallery_4_unlocked == True:
                                if persistent.mixed4 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed4", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_5", locked="insensitive", unlocked="mixed_gallery_5_th")

                            if persistent.mixed_gallery_5_unlocked == True:
                                if persistent.mixed5 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed5", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_6", locked="insensitive", unlocked="mixed_gallery_6_th")

                            if persistent.mixed_gallery_6_unlocked == True:
                                if persistent.mixed6 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed6", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_7", locked="insensitive", unlocked="mixed_gallery_7_th")

                            if persistent.mixed_gallery_7_unlocked == True:
                                if persistent.mixed7 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed7", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_8", locked="insensitive", unlocked="mixed_gallery_8_th")

                            if persistent.mixed_gallery_8_unlocked == True:
                                if persistent.mixed8 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed8", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_9", locked="insensitive", unlocked="mixed_gallery_9_th")

                            if persistent.mixed_gallery_9_unlocked == True:
                                if persistent.mixed9 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed9", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_10", locked="insensitive", unlocked="mixed_gallery_10_th")

                                if persistent.mixed_gallery_10_unlocked == True:
                                    if persistent.mixed10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed10", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_10_cen", locked="insensitive", unlocked="mixed_gallery_10_th_cen")

                                if persistent.mixed_gallery_10_unlocked == True:
                                    if persistent.mixed10 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed10", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_11", locked="insensitive", unlocked="mixed_gallery_11_th")

                            if persistent.mixed_gallery_11_unlocked == True:
                                if persistent.mixed11 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed11", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_12", locked="insensitive", unlocked="mixed_gallery_12_th")

                            if persistent.mixed_gallery_12_unlocked == True:
                                if persistent.mixed12 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed12", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_13", locked="insensitive", unlocked="mixed_gallery_13_th")

                                if persistent.mixed_gallery_13_unlocked == True:
                                    if persistent.mixed13 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed13", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_14", locked="insensitive", unlocked="mixed_gallery_14_th")

                                if persistent.mixed_gallery_14_unlocked == True:
                                    if persistent.mixed14 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed14", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_13_cen", locked="insensitive", unlocked="mixed_gallery_13_th_cen")

                                if persistent.mixed_gallery_13_unlocked == True:
                                    if persistent.mixed13 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed13", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"

                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_14_cen", locked="insensitive", unlocked="mixed_gallery_14_th_cen")

                                if persistent.mixed_gallery_14_unlocked == True:
                                    if persistent.mixed14 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed14", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_15", locked="insensitive", unlocked="mixed_gallery_15_th")

                            if persistent.mixed_gallery_15_unlocked == True:
                                if persistent.mixed15 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed15", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        frame:
                            xsize 332
                            ysize 192
                            add g.make_button(name="mixed_gallery_16", locked="insensitive", unlocked="mixed_gallery_16_th")

                            if persistent.mixed_gallery_16_unlocked == True:
                                if persistent.mixed16 == True:
                                    imagebutton:
                                        idle "images/transparent.png"
                                        hover "images/transparent.png"
                                        xalign 0.5
                                        yalign 0.5
                                        xsize 320
                                        ysize 180
                                        action [SetVariable("persistent.mixed16", False), Function(update_mixed_list)]

                                    add "gui/exclamation_mark.png"

                        if persistent.disable_nsfw == True:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_17", locked="insensitive", unlocked="mixed_gallery_17_th")

                                if persistent.mixed_gallery_17_unlocked == True:
                                    if persistent.mixed17 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed17", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"
                        else:
                            frame:
                                xsize 332
                                ysize 192
                                add g.make_button(name="mixed_gallery_17_cen", locked="insensitive", unlocked="mixed_gallery_17_th_cen")

                                if persistent.mixed_gallery_17_unlocked == True:
                                    if persistent.mixed17 == True:
                                        imagebutton:
                                            idle "images/transparent.png"
                                            hover "images/transparent.png"
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 320
                                            ysize 180
                                            action [SetVariable("persistent.mixed17", False), Function(update_mixed_list)]

                                        add "gui/exclamation_mark.png"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

                        frame:
                            imagebutton auto "images/gallery/template_%s.webp"

    # Buttons #

    if gallery < 2:

        frame:
            yalign 0.949
            xalign 0.374
            textbutton "Photos" action SetScreenVariable("gallery", 2)

    if image_gallery >= 1 and gallery == 2:

        frame:
            yalign 0.949
            xalign 0.5
            textbutton "Return" action SetScreenVariable("image_gallery", 0)

    # Music Room ###############################################################

    if gallery == 1:

        vbox:
            xalign 0.5
            yalign 0.35
            spacing 20

            $ renpy.transition(Dissolve(0.2))

            frame:
                xsize 1550
                ysize 830

                text "Music (Creative commons license for commercial use)":
                    yalign 0.02
                    xalign 0.5
                text "source {a=https://freemusicarchive.org/}(Free Music Archive){/a}, {a=https://creativecommons.org/licenses/by-sa/4.0/}license type (CC BY){/a}":
                    yalign 0.07
                    xalign 0.5

                # Buttons ######################################################

                imagebutton:
                    idle "images/gallery/next_button_idle.webp"
                    hover "images/gallery/next_button_hover.webp"
                    xalign 0.95
                    yalign 0.5
                    action mr.Next()

                imagebutton:
                    idle "images/gallery/previous_button_idle.webp"
                    hover "images/gallery/previous_button_hover.webp"
                    xalign 0.05
                    yalign 0.5
                    action mr.Previous()

                frame:
                    xalign 0.575
                    yalign 0.985

                    imagebutton:
                        idle "images/gallery/pause_button_idle.webp"
                        hover "images/gallery/pause_button_hover.webp"
                        selected_idle "images/gallery/pause_button_hover.webp"
                        action mr.TogglePause()

                # Shuffle #

                frame:
                    xalign 0.5
                    yalign 0.985

                    textbutton "Shuffle":
                        action mr.ToggleShuffle()

                # Repeat #

                frame:
                    xalign 0.425
                    yalign 0.985

                    if repeat == 0:
                        imagebutton:
                            idle "images/gallery/repeat_button_idle.webp"
                            hover "images/gallery/repeat_button_hover.webp"
                            action [mr.ToggleLoop(), SetScreenVariable("repeat", 1)]

                    if repeat == 1:
                        imagebutton:
                            idle "images/gallery/repeat_button_hover.webp"
                            hover "images/gallery/repeat_button_hover.webp"
                            action [mr.ToggleSingleTrack(), SetScreenVariable("repeat", 2)]

                    if repeat == 2:
                        imagebutton:
                            idle "images/gallery/repeat_one_button_hover.webp"
                            hover "images/gallery/repeat_one_button_hover.webp"
                            action [mr.ToggleSingleTrack(), mr.ToggleLoop(), SetScreenVariable("repeat", 0)]

                # Music ########################################################

                frame:
                    yalign 0.55
                    xalign 0.5
                    ysize 620

                    vpgrid:
                        xalign 0.5
                        cols 1
                        spacing 10

                        draggable True
                        scrollbars "vertical"
                        mousewheel True

                        frame:
                            xsize 700
                            textbutton "{size=20}Aftertune - Piano{/size}":
                                action mr.Play("audio/party/instrumentals/piano.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Aftertune - Love You (Original Mix){/size}":
                                action mr.Play("audio/party/instrumentals/love_you.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Akira Sora - 2010 Pop{/size}":
                                action mr.Play("audio/party/instrumentals/2010_pop.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Akira Sora - AUX ★ Original Mix{/size}":
                                action mr.Play("audio/party/instrumentals/aux_original_mix.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Anthem of Rain - Rock This House (Instrumental){/size}":
                                action mr.Play("audio/party/instrumentals/rock_this_house.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Anthem of Rain - Then I'm Gone (Instrumental){/size}":
                                action mr.Play("audio/party/instrumentals/then_im_gone.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Avantist - Tidalwave{/size}":
                                action mr.Play("audio/tidalwave.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Encryption{/size}":
                                action mr.Play("audio/party/instrumentals/encryption.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - French Toast{/size}":
                                action mr.Play("audio/french_toast.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Hard Love{/size}":
                                action mr.Play("audio/party/instrumentals/hard_love.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Heartache{/size}":
                                action mr.Play("audio/heartache.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Inhale{/size}":
                                action mr.Play("audio/inhale.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - It Was Then{/size}":
                                action mr.Play("audio/it_was_then.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Milkshake{/size}":
                                action mr.Play("audio/milkshake.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Mom n' Pa{/size}":
                                action mr.Play("audio/mom_n_pa.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Beat Mekanik - Savage{/size}":
                                action mr.Play("audio/savage.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}BLUES OF T{/size}":
                                action mr.Play("audio/blues_of_t.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Chris Zabriskie - It's All Around You{/size}":
                                action mr.Play("audio/all_around_you.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Cool Studios - OnFire{/size}":
                                action mr.Play("audio/onfire.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Creo - Dimension{/size}":
                                action mr.Play("audio/party/instrumentals/dimension.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Darkfluxx - Open Inside{/size}":
                                action mr.Play("audio/party/instrumentals/open_inside.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Doctor Turtle - The Encouragement Stick{/size}":
                                action mr.Play("audio/the_encouragement_stick.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Doctor Turtle - Which That Is This (Long Version){/size}":
                                action mr.Play("audio/which_that_is_this.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Easy Cheesy{/size}":
                                action mr.Play("audio/easy_cheesy.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Ethos - Coalescense{/size}":
                                action mr.Play("audio/coalescense.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Evan Schaeffer - Laurel Breeze{/size}":
                                action mr.Play("audio/laurel_breeze.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Glad Rags - Wonder Under{/size}":
                                action mr.Play("audio/wonder_under.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Hotham - Dance Tonight{/size}":
                                action mr.Play("audio/party/instrumentals/dance_tonight.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jahzzar - Brighter{/size}":
                                action mr.Play("audio/brighter.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jahzzar - Circles{/size}":
                                action mr.Play("audio/circles.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jahzzar - Liar{/size}":
                                action mr.Play("audio/liar.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jahzzar - Pause{/size}":
                                action mr.Play("audio/pause.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jangwa - River View{/size}":
                                action mr.Play("audio/river_view.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - IN THE FIELD{/size}":
                                action mr.Play("audio/in_the_field.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - MARATHON MAN{/size}":
                                action mr.Play("audio/marathon_man.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - ONE FINE DAY{/size}":
                                action mr.Play("audio/one_fine_day.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - PIONEERS{/size}":
                                action mr.Play("audio/pioneers.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - RIVER MEDITATION{/size}":
                                action mr.Play("audio/river_meditation.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - SERENITY{/size}":
                                action mr.Play("audio/serenity.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - SOLO ACOUSTIC GUITAR{/size}":
                                action mr.Play("audio/solo_acoustic_guitar.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jason Shaw - TRAVEL LIGHT{/size}":
                                action mr.Play("audio/travel_light.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jens East - Galaxies (ft. Diandra Faye){/size}":
                                action mr.Play("audio/party/galaxies.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jens East - I Won't Fall In Love (feat. MaryLinn){/size}":
                                action mr.Play("audio/party/i_wont_fall_in_love.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Jens East - Nightrise{/size}":
                                action mr.Play("audio/party/instrumentals/nightrise.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}JOEY HENDRIXX - DAFT PUNK (DISCO - RETRO - GROOVY){/size}":
                                action mr.Play("audio/daft_punk.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}John Bartmann - Bad Sexy Dad Vibes{/size}":
                                action mr.Play("audio/bad_sexy_dad_vibes.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - 20/20{/size}":
                                action mr.Play("audio/twenty_twenty.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Airplane Mode (Instrumental Version){/size}":
                                action mr.Play("audio/airplane_mode.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Bloom (Instrumental Version){/size}":
                                action mr.Play("audio/bloom.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Border Blaster (Instrumental Version){/size}":
                                action mr.Play("audio/border_blaster.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Crazy Glue (Instrumental Version){/size}":
                                action mr.Play("audio/crazy_glue.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Darien Gap - Instrumental{/size}":
                                action mr.Play("audio/darien_gap.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Frannie (Instrumental Version){/size}":
                                action mr.Play("audio/frannie.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Hey Ruth (Instrumental Version){/size}":
                                action mr.Play("audio/hey_ruth.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Hollow Grove (Instrumental Version){/size}":
                                action mr.Play("audio/hollow_grove.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - I Will Not Let You Let Me Down (Instrumental Version){/size}":
                                action mr.Play("audio/iwnlylmd.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Inertia - Instrumental{/size}":
                                action mr.Play("audio/inertia.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Invisible Light (Instrumental Version){/size}":
                                action mr.Play("audio/invisible_light.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Little Tomcat (Instrumental Version){/size}":
                                action mr.Play("audio/little_tomcat.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Release{/size}":
                                action mr.Play("audio/release.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Sundown (Instrumental Version){/size}":
                                action mr.Play("audio/sundown.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Thanks For Coming (Instrumental Version){/size}":
                                action mr.Play("audio/thanks_for_coming.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - The Pawnbroker's Stepdaughter (Instrumental Version){/size}":
                                action mr.Play("audio/the_pawnbrokers_stepdaughter.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - With a Whimper{/size}":
                                action mr.Play("audio/with_a_whimper.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Josh Woodward - Words Fall Apart (Instrumental Version){/size}":
                                action mr.Play("audio/words_fall_apart.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Kami - Moving Up{/size}":
                                action mr.Play("audio/party/instrumentals/moving_up.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Kai Engel - Odesa{/size}":
                                action mr.Play("audio/odesa.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Kevin MacLeod - Aces High{/size}":
                                action mr.Play("audio/aces_high.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Kevin MacLeod - Dances and Dames{/size}":
                                action mr.Play("audio/dances_and_dames.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Kevin MacLeod - Rollin at 5 - 210 - full{/size}":
                                action mr.Play("audio/rollin_at_5.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Lundstroem - Lundstroems daft punk{/size}":
                                action mr.Play("audio/party/instrumentals/lundstroems_daft_punk.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Magana - Area 51{/size}":
                                action mr.Play("audio/party/instrumentals/area_51.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Man Bites Dog - College Rock (How To Hold The Guitar Right){/size}":
                                action mr.Play("audio/college_rock.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Man Bites Dog - Perfect One{/size}":
                                action mr.Play("audio/perfect_one.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Mela - The Darker Side{/size}":
                                action mr.Play("audio/the_darker_side.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Mr Smith - Breathe{/size}":
                                action mr.Play("audio/breathe.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Mr Smith - Punk Rock Holiday{/size}":
                                action mr.Play("audio/punk_rock_holiday.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Normcore - Heartless Man{/size}":
                                action mr.Play("audio/heartless_man.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Oh Yeah, the Future - Snowday{/size}":
                                action mr.Play("audio/snowday.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}oji - failures.{/size}":
                                action mr.Play("audio/failures.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}PC-ONE - Love{/size}":
                                action mr.Play("audio/love.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}PC-ONE - Write Hear Right Now (Instrumental Acoustic){/size}":
                                action mr.Play("audio/write_hear_right_now.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Pipe Choir - EVERYTHING WILL BE ALRIGHT{/size}":
                                action mr.Play("audio/everything_will_be_alright.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Play House - Random Drop{/size}":
                                action mr.Play("audio/party/instrumentals/random_drop.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Punk Rock Opera - Nerve Damage{/size}":
                                action mr.Play("audio/nerve_damage.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Quantum Jazz - Orbiting A Distant Planet{/size}":
                                action mr.Play("audio/orbiting_a_distant_planet.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}SLOU - Turn Up (Original Mix) - Bigroom House{/size}":
                                action mr.Play("audio/party/instrumentals/turn_up.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Soundore - Evening Jazz{/size}":
                                action mr.Play("audio/evening_jazz.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Steve Combs - Motown Rehearsal{/size}":
                                action mr.Play("audio/motown_rehearsal.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Steve Combs - Sun Sets on a Protagonist{/size}":
                                action mr.Play("audio/sun_sets_on_a_protagonist.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Steve Combs - William Henry Harrison High School Fight Song{/size}":
                                action mr.Play("audio/whhhsfs.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Synthet - Ariana Grande Synthet instrumental{/size}":
                                action mr.Play("audio/ariana_grande_synthet.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The New Valleys - Sad Guitar{/size}":
                                action mr.Play("audio/sad_guitar.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Brundlefly{/size}":
                                action mr.Play("audio/menu/brundlefly.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Careful!{/size}":
                                action mr.Play("audio/menu/careful.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Electric Girlfriend{/size}":
                                action mr.Play("audio/electric_girlfriend.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Halloween Again{/size}":
                                action mr.Play("audio/menu/halloween_again.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Killer Rabbit{/size}":
                                action mr.Play("audio/killer_rabbit.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}The Zombie Dandies - Welcome To Zombie Coast{/size}":
                                action mr.Play("audio/welcome_to_zombie_coast.ogg")
                                xalign 0.5
                            frame:
                                xsize 700
                                textbutton "{size=20}UNIVERSFIELD - Beautiful Piano Melodies{/size}":
                                    action mr.Play("audio/beautiful_piano_melodies.ogg")
                                    xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}UNIVERSFIELD - Bright and Positive Acoustic Melody{/size}":
                                action mr.Play("audio/bpam.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}UNIVERSFIELD - Energizing Indie Pop Inspiration{/size}":
                                action mr.Play("audio/energizing_indie_pop.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}UNIVERSFIELD - Sentimental Acoustic Tune for Emotional Scenes{/size}":
                                action mr.Play("audio/satfes.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Untimely Dosage - Keep it Down{/size}":
                                action mr.Play("audio/keep_it_down.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Untimely Dosage - Pop Song{/size}":
                                action mr.Play("audio/pop_song.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Van Loon - Dit It and Quit It{/size}":
                                action mr.Play("audio/did_it_and_quit_it.ogg")
                                xalign 0.5
                        frame:
                            xsize 700
                            textbutton "{size=20}Van Loon - Hi As Hats{/size}":
                                action mr.Play("audio/hi_as_hats.ogg")
                                xalign 0.5

    # Buttons #

    if gallery == 0:

        frame:
            yalign 0.949
            xalign 0.62
            textbutton "Music" action SetScreenVariable("gallery", 1)

    if gallery == 2:

        frame:
            yalign 0.949
            xalign 0.62
            textbutton "Music" action SetScreenVariable("gallery", 1)
