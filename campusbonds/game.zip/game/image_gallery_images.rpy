
# Insensitive #

image insensitive = "images/gallery/insensitive.webp"

# Images #######################################################################

# Scarlett ##################

# Episode 1
image sc_gallery_1 = "season1/episode1/images/gallery/scarlett/1.webp"
image sc_gallery_2 = "season1/episode1/images/gallery/scarlett/2.webp"
image sc_gallery_3 = "season1/episode1/images/gallery/scarlett/3.webp"

# Censored #
image sc_gallery_3_cen = "season1/episode1/images/gallery/scarlett/censored/3.webp"

# Episode 2
image sc_gallery_4 = "season1/episode2/images/gallery/scarlett/1.webp"
image sc_gallery_5 = "season1/episode2/images/gallery/scarlett/2.webp"
image sc_gallery_6 = "season1/episode2/images/gallery/scarlett/3.webp"
image sc_gallery_7 = "season1/episode2/images/gallery/scarlett/4.webp"
image sc_gallery_8 = "season1/episode2/images/gallery/scarlett/5.webp"

# Censored #
image sc_gallery_6_cen = "season1/episode2/images/gallery/scarlett/censored/3.webp"
image sc_gallery_7_cen = "season1/episode2/images/gallery/scarlett/censored/4.webp"
image sc_gallery_8_cen = "season1/episode2/images/gallery/scarlett/censored/5.webp"

# Episode 3
image sc_gallery_9 = "season1/episode3/images/gallery/scarlett/1.webp"
image sc_gallery_10 = "season1/episode3/images/gallery/scarlett/2.webp"
image sc_gallery_11 = "season1/episode3/images/gallery/scarlett/3.webp"

# Censored #
image sc_gallery_11_cen = "season1/episode3/images/gallery/scarlett/censored/3.webp"

# Episode 4
image sc_gallery_12 = "season1/episode4/images/gallery/scarlett/1.webp"
image sc_gallery_13 = "season1/episode4/images/gallery/scarlett/2.webp"

# Episode 5
image sc_gallery_14 = "season1/episode5/images/gallery/scarlett/1.webp"

# Cleo ##################

# Episode 1
image cl_gallery_1 = "season1/episode1/images/gallery/cleo/1.webp"
image cl_gallery_2 = "season1/episode1/images/gallery/cleo/2.webp"
image cl_gallery_3 = "season1/episode1/images/gallery/cleo/3.webp"
image cl_gallery_4 = "season1/episode1/images/gallery/cleo/4.webp"

# Episode 2
image cl_gallery_5 = "season1/episode2/images/gallery/cleo/1.webp"
image cl_gallery_6 = "season1/episode2/images/gallery/cleo/2.webp"
image cl_gallery_7 = "season1/episode2/images/gallery/cleo/3.webp"
image cl_gallery_8 = "season1/episode2/images/gallery/cleo/4.webp"

# Censored #
image cl_gallery_8_cen = "season1/episode2/images/gallery/cleo/censored/4.webp"

# Episode 3
image cl_gallery_9 = "season1/episode3/images/gallery/cleo/1.webp"
image cl_gallery_10 = "season1/episode3/images/gallery/cleo/2.webp"
image cl_gallery_11 = "season1/episode3/images/gallery/cleo/3.webp"

# Episode 4
image cl_gallery_12 = "season1/episode4/images/gallery/cleo/1.webp"
image cl_gallery_13 = "season1/episode4/images/gallery/cleo/2.webp"

# Episode 5
image cl_gallery_14 = "season1/episode5/images/gallery/cleo/1.webp"
image cl_gallery_15 = "season1/episode5/images/gallery/cleo/2.webp"
image cl_gallery_16 = "season1/episode5/images/gallery/cleo/3.webp"

# Tracy ##################

# Episode 1
image tr_gallery_1 = "season1/episode1/images/gallery/tracy/1.webp"
image tr_gallery_2 = "season1/episode1/images/gallery/tracy/2.webp"
image tr_gallery_3 = "season1/episode1/images/gallery/tracy/3.webp"

# Censored #
image tr_gallery_2_cen = "season1/episode1/images/gallery/tracy/censored/2.webp"
image tr_gallery_3_cen = "season1/episode1/images/gallery/tracy/censored/3.webp"

# Episode 2
image tr_gallery_4 = "season1/episode2/images/gallery/tracy/1.webp"
image tr_gallery_5 = "season1/episode2/images/gallery/tracy/2.webp"
image tr_gallery_6 = "season1/episode2/images/gallery/tracy/3.webp"
image tr_gallery_7 = "season1/episode2/images/gallery/tracy/4.webp"
image tr_gallery_8 = "season1/episode2/images/gallery/tracy/5.webp"

# Censored #
image tr_gallery_5_cen = "season1/episode2/images/gallery/tracy/censored/2.webp"
image tr_gallery_6_cen = "season1/episode2/images/gallery/tracy/censored/3.webp"
image tr_gallery_7_cen = "season1/episode2/images/gallery/tracy/censored/4.webp"
image tr_gallery_8_cen = "season1/episode2/images/gallery/tracy/censored/5.webp"

# Episode 3
image tr_gallery_9 = "season1/episode3/images/gallery/tracy/1.webp"
image tr_gallery_10 = "season1/episode3/images/gallery/tracy/2.webp"
image tr_gallery_11 = "season1/episode3/images/gallery/tracy/3.webp"

# Censored #
image tr_gallery_10_cen = "season1/episode2/images/gallery/tracy/censored/2.webp"
image tr_gallery_11_cen = "season1/episode2/images/gallery/tracy/censored/3.webp"

# Episode 4
image tr_gallery_12 = "season1/episode4/images/gallery/tracy/1.webp"
image tr_gallery_13 = "season1/episode4/images/gallery/tracy/2.webp"

# Episode 5
image tr_gallery_14 = "season1/episode5/images/gallery/tracy/1.webp"
image tr_gallery_15 = "season1/episode5/images/gallery/tracy/2.webp"
image tr_gallery_16 = "season1/episode5/images/gallery/tracy/3.webp"

# Sadie ##################

# Episode 1
image sd_gallery_1 = "season1/episode1/images/gallery/sadie/1.webp"
image sd_gallery_2 = "season1/episode1/images/gallery/sadie/2.webp"
image sd_gallery_3 = "season1/episode1/images/gallery/sadie/3.webp"

# Censored #
image sd_gallery_3_cen = "season1/episode1/images/gallery/sadie/censored/3.webp"

# Episode 2
image sd_gallery_4 = "season1/episode2/images/gallery/sadie/1.webp"
image sd_gallery_5 = "season1/episode2/images/gallery/sadie/2.webp"
image sd_gallery_6 = "season1/episode2/images/gallery/sadie/3.webp"
image sd_gallery_7 = "season1/episode2/images/gallery/sadie/4.webp"
image sd_gallery_8 = "season1/episode2/images/gallery/sadie/5.webp"
image sd_gallery_9 = "season1/episode2/images/gallery/sadie/6.webp"

# Censored #
image sd_gallery_8_cen = "season1/episode2/images/gallery/sadie/censored/5.webp"
image sd_gallery_9_cen = "season1/episode2/images/gallery/sadie/censored/6.webp"

# Episode 3
image sd_gallery_10 = "season1/episode3/images/gallery/sadie/1.webp"
image sd_gallery_11 = "season1/episode3/images/gallery/sadie/2.webp"
image sd_gallery_12 = "season1/episode3/images/gallery/sadie/3.webp"

# Censored #
image sd_gallery_11_cen = "season1/episode3/images/gallery/sadie/censored/2.webp"
image sd_gallery_12_cen = "season1/episode3/images/gallery/sadie/censored/3.webp"

# Episode 4
image sd_gallery_13 = "season1/episode4/images/gallery/sadie/1.webp"

# Episode 5
image sd_gallery_14 = "season1/episode5/images/gallery/sadie/1.webp"
image sd_gallery_15 = "season1/episode5/images/gallery/sadie/2.webp"
image sd_gallery_16 = "season1/episode5/images/gallery/sadie/3.webp"

# Censored #

# Francesca ##################

# Episode 1
image fr_gallery_1 = "season1/episode1/images/gallery/francesca/1.webp"
image fr_gallery_2 = "season1/episode1/images/gallery/francesca/2.webp"
image fr_gallery_3 = "season1/episode1/images/gallery/francesca/3.webp"

# Episode 2
image fr_gallery_4 = "season1/episode2/images/gallery/francesca/1.webp"
image fr_gallery_5 = "season1/episode2/images/gallery/francesca/2.webp"
image fr_gallery_6 = "season1/episode2/images/gallery/francesca/3.webp"
image fr_gallery_7 = "season1/episode2/images/gallery/francesca/4.webp"

# Censored #
image fr_gallery_6_cen = "season1/episode2/images/gallery/francesca/censored/3.webp"
image fr_gallery_7_cen = "season1/episode2/images/gallery/francesca/censored/4.webp"

# Episode 3
image fr_gallery_8 = "season1/episode3/images/gallery/francesca/1.webp"
image fr_gallery_9 = "season1/episode3/images/gallery/francesca/2.webp"
image fr_gallery_10 = "season1/episode3/images/gallery/francesca/3.webp"

# Censored #
image fr_gallery_9_cen = "season1/episode3/images/gallery/francesca/censored/2.webp"
image fr_gallery_10_cen = "season1/episode3/images/gallery/francesca/censored/3.webp"

# Episode 4
image fr_gallery_11 = "season1/episode4/images/gallery/francesca/1.webp"
image fr_gallery_12 = "season1/episode4/images/gallery/francesca/2.webp"
image fr_gallery_13 = "season1/episode4/images/gallery/francesca/3.webp"

# Censored #
image fr_gallery_12_cen = "season1/episode4/images/gallery/francesca/censored/2.webp"
image fr_gallery_13_cen = "season1/episode4/images/gallery/francesca/censored/3.webp"

# Tiffany ##################

# Episode 3
image tf_gallery_1 = "season1/episode3/images/gallery/tiffany/1.webp"

# Episode 4
image tf_gallery_2 = "season1/episode4/images/gallery/tiffany/1.webp"
image tf_gallery_3 = "season1/episode4/images/gallery/tiffany/2.webp"
image tf_gallery_4 = "season1/episode4/images/gallery/tiffany/3.webp"

# Censored
image tf_gallery_4_cen = "season1/episode4/images/gallery/tiffany/censored/4.webp"

# Episode 5
image tf_gallery_5 = "season1/episode5/images/gallery/tiffany/1.webp"
image tf_gallery_6 = "season1/episode5/images/gallery/tiffany/2.webp"
image tf_gallery_7 = "season1/episode5/images/gallery/tiffany/3.webp"
image tf_gallery_8 = "season1/episode5/images/gallery/tiffany/4.webp"
image tf_gallery_9 = "season1/episode5/images/gallery/tiffany/5.webp"

# Censored
image tf_gallery_8_cen = "season1/episode5/images/gallery/tiffany/censored/4.webp"

# Evelyn ##################

# Episode 3
image ev_gallery_1 = "season1/episode3/images/gallery/evelyn/1.webp"

# Episode 4
image ev_gallery_2 = "season1/episode4/images/gallery/evelyn/1.webp"
image ev_gallery_3 = "season1/episode4/images/gallery/evelyn/2.webp"
image ev_gallery_4 = "season1/episode4/images/gallery/evelyn/3.webp"

# Censored
image ev_gallery_3_cen = "season1/episode4/images/gallery/evelyn/censored/3.webp"
image ev_gallery_4_cen = "season1/episode4/images/gallery/evelyn/censored/4.webp"

# Episode 5
image ev_gallery_5 = "season1/episode5/images/gallery/evelyn/1.webp"
image ev_gallery_6 = "season1/episode5/images/gallery/evelyn/2.webp"
image ev_gallery_7 = "season1/episode5/images/gallery/evelyn/3.webp"
image ev_gallery_8 = "season1/episode5/images/gallery/evelyn/4.webp"

# Censored
image ev_gallery_8_cen = "season1/episode5/images/gallery/evelyn/censored/4.webp"

# Mixed ##################

# Episode 1
image mixed_gallery_1 = "season1/episode1/images/gallery/mixed/1.webp"
image mixed_gallery_2 = "season1/episode1/images/gallery/mixed/2.webp"
image mixed_gallery_3 = "season1/episode1/images/gallery/mixed/3.webp"
image mixed_gallery_4 = "season1/episode1/images/gallery/mixed/4.webp"

# Episode 2
image mixed_gallery_5 = "season1/episode2/images/gallery/mixed/1.webp"
image mixed_gallery_6 = "season1/episode2/images/gallery/mixed/2.webp"
image mixed_gallery_7 = "season1/episode2/images/gallery/mixed/3.webp"

# Episode 3
image mixed_gallery_8 = "season1/episode3/images/gallery/mixed/1.webp"
image mixed_gallery_9 = "season1/episode3/images/gallery/mixed/2.webp"
image mixed_gallery_10 = "season1/episode3/images/gallery/mixed/3.webp"
image mixed_gallery_11 = "season1/episode3/images/gallery/mixed/4.webp"
image mixed_gallery_12 = "season1/episode3/images/gallery/mixed/5.webp"
image mixed_gallery_13 = "season1/episode3/images/gallery/mixed/6.webp"

# Censored
image mixed_gallery_10_cen = "season1/episode3/images/gallery/mixed/censored/4.webp"
image mixed_gallery_13_cen = "season1/episode3/images/gallery/mixed/censored/6.webp"

# Episode 4
image mixed_gallery_14 = "season1/episode4/images/gallery/mixed/1.webp"
image mixed_gallery_15 = "season1/episode4/images/gallery/mixed/2.webp"
image mixed_gallery_16 = "season1/episode4/images/gallery/mixed/3.webp"
image mixed_gallery_17 = "season1/episode4/images/gallery/mixed/4.webp"

# Censored
image mixed_gallery_14_cen = "season1/episode4/images/gallery/mixed/censored/1.webp"
image mixed_gallery_17_cen = "season1/episode4/images/gallery/mixed/censored/4.webp"



# Thumbnails ###################################################################

# Scarlett ##################

# Episode 1
image sc_gallery_1_th = "images/gallery/image_gallery/thumbnails/scarlett/1.webp"
image sc_gallery_2_th = "images/gallery/image_gallery/thumbnails/scarlett/2.webp"
image sc_gallery_3_th = "images/gallery/image_gallery/thumbnails/scarlett/3.webp"

# Censored #
image sc_gallery_3_th_cen = "images/gallery/image_gallery/thumbnails/scarlett/censored/3.webp"

# Episode 2
image sc_gallery_4_th = "images/gallery/image_gallery/thumbnails/scarlett/4.webp"
image sc_gallery_5_th = "images/gallery/image_gallery/thumbnails/scarlett/5.webp"
image sc_gallery_6_th = "images/gallery/image_gallery/thumbnails/scarlett/6.webp"
image sc_gallery_7_th = "images/gallery/image_gallery/thumbnails/scarlett/7.webp"
image sc_gallery_8_th = "images/gallery/image_gallery/thumbnails/scarlett/8.webp"

# Censored #
image sc_gallery_6_th_cen = "images/gallery/image_gallery/thumbnails/scarlett/censored/6.webp"
image sc_gallery_7_th_cen = "images/gallery/image_gallery/thumbnails/scarlett/censored/7.webp"
image sc_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/scarlett/censored/8.webp"

# Episode 3
image sc_gallery_9_th = "images/gallery/image_gallery/thumbnails/scarlett/9.webp"
image sc_gallery_10_th = "images/gallery/image_gallery/thumbnails/scarlett/10.webp"
image sc_gallery_11_th = "images/gallery/image_gallery/thumbnails/scarlett/11.webp"

# Censored #
image sc_gallery_11_th_cen = "images/gallery/image_gallery/thumbnails/scarlett/censored/11.webp"

# Episode 4
image sc_gallery_12_th = "images/gallery/image_gallery/thumbnails/scarlett/12.webp"
image sc_gallery_13_th = "images/gallery/image_gallery/thumbnails/scarlett/13.webp"

# Episode 5
image sc_gallery_14_th = "images/gallery/image_gallery/thumbnails/scarlett/14.webp"

# Cleo ##################

# Episode 1
image cl_gallery_1_th = "images/gallery/image_gallery/thumbnails/cleo/1.webp"
image cl_gallery_2_th = "images/gallery/image_gallery/thumbnails/cleo/2.webp"
image cl_gallery_3_th = "images/gallery/image_gallery/thumbnails/cleo/3.webp"
image cl_gallery_4_th = "images/gallery/image_gallery/thumbnails/cleo/4.webp"

# Episode 2
image cl_gallery_5_th = "images/gallery/image_gallery/thumbnails/cleo/5.webp"
image cl_gallery_6_th = "images/gallery/image_gallery/thumbnails/cleo/6.webp"
image cl_gallery_7_th = "images/gallery/image_gallery/thumbnails/cleo/7.webp"
image cl_gallery_8_th = "images/gallery/image_gallery/thumbnails/cleo/8.webp"

# Censored #
image cl_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/cleo/censored/8.webp"

# Episode 3
image cl_gallery_9_th = "images/gallery/image_gallery/thumbnails/cleo/9.webp"
image cl_gallery_10_th = "images/gallery/image_gallery/thumbnails/cleo/10.webp"
image cl_gallery_11_th = "images/gallery/image_gallery/thumbnails/cleo/11.webp"

# Episode 4
image cl_gallery_12_th = "images/gallery/image_gallery/thumbnails/cleo/12.webp"
image cl_gallery_13_th = "images/gallery/image_gallery/thumbnails/cleo/13.webp"

# Episode 5
image cl_gallery_14_th = "images/gallery/image_gallery/thumbnails/cleo/14.webp"
image cl_gallery_15_th = "images/gallery/image_gallery/thumbnails/cleo/15.webp"
image cl_gallery_16_th = "images/gallery/image_gallery/thumbnails/cleo/16.webp"

# Tracy ##################

# Episode 1
image tr_gallery_1_th = "images/gallery/image_gallery/thumbnails/tracy/1.webp"
image tr_gallery_2_th = "images/gallery/image_gallery/thumbnails/tracy/2.webp"
image tr_gallery_3_th = "images/gallery/image_gallery/thumbnails/tracy/3.webp"

# Censored #
image tr_gallery_2_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/2.webp"
image tr_gallery_3_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/3.webp"

# Episode 2
image tr_gallery_4_th = "images/gallery/image_gallery/thumbnails/tracy/4.webp"
image tr_gallery_5_th = "images/gallery/image_gallery/thumbnails/tracy/5.webp"
image tr_gallery_6_th = "images/gallery/image_gallery/thumbnails/tracy/6.webp"
image tr_gallery_7_th = "images/gallery/image_gallery/thumbnails/tracy/7.webp"
image tr_gallery_8_th = "images/gallery/image_gallery/thumbnails/tracy/8.webp"

# Censored #
image tr_gallery_5_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/5.webp"
image tr_gallery_6_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/6.webp"
image tr_gallery_7_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/7.webp"
image tr_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/8.webp"

# Episode 3
image tr_gallery_9_th = "images/gallery/image_gallery/thumbnails/tracy/9.webp"
image tr_gallery_10_th = "images/gallery/image_gallery/thumbnails/tracy/10.webp"
image tr_gallery_11_th = "images/gallery/image_gallery/thumbnails/tracy/11.webp"

# Censored #
image tr_gallery_10_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/10.webp"
image tr_gallery_11_th_cen = "images/gallery/image_gallery/thumbnails/tracy/censored/11.webp"

# Episode 4
image tr_gallery_12_th = "images/gallery/image_gallery/thumbnails/tracy/12.webp"
image tr_gallery_13_th = "images/gallery/image_gallery/thumbnails/tracy/13.webp"

# Episode 5
image tr_gallery_14_th = "images/gallery/image_gallery/thumbnails/tracy/14.webp"
image tr_gallery_15_th = "images/gallery/image_gallery/thumbnails/tracy/15.webp"
image tr_gallery_16_th = "images/gallery/image_gallery/thumbnails/tracy/16.webp"

# Sadie ##################

# Episode 1
image sd_gallery_1_th = "images/gallery/image_gallery/thumbnails/sadie/1.webp"
image sd_gallery_2_th = "images/gallery/image_gallery/thumbnails/sadie/2.webp"
image sd_gallery_3_th = "images/gallery/image_gallery/thumbnails/sadie/3.webp"

# Censored #
image sd_gallery_3_th_cen = "images/gallery/image_gallery/thumbnails/sadie/censored/3.webp"

# Episode 2
image sd_gallery_4_th = "images/gallery/image_gallery/thumbnails/sadie/4.webp"
image sd_gallery_5_th = "images/gallery/image_gallery/thumbnails/sadie/5.webp"
image sd_gallery_6_th = "images/gallery/image_gallery/thumbnails/sadie/6.webp"
image sd_gallery_7_th = "images/gallery/image_gallery/thumbnails/sadie/7.webp"
image sd_gallery_8_th = "images/gallery/image_gallery/thumbnails/sadie/8.webp"
image sd_gallery_9_th = "images/gallery/image_gallery/thumbnails/sadie/9.webp"

# Censored #
image sd_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/sadie/censored/8.webp"
image sd_gallery_9_th_cen = "images/gallery/image_gallery/thumbnails/sadie/censored/9.webp"

# Episode 3
image sd_gallery_10_th = "images/gallery/image_gallery/thumbnails/sadie/10.webp"
image sd_gallery_11_th = "images/gallery/image_gallery/thumbnails/sadie/11.webp"
image sd_gallery_12_th = "images/gallery/image_gallery/thumbnails/sadie/12.webp"

# Censored #
image sd_gallery_11_th_cen = "images/gallery/image_gallery/thumbnails/sadie/censored/11.webp"
image sd_gallery_12_th_cen = "images/gallery/image_gallery/thumbnails/sadie/censored/12.webp"

# Episode 4
image sd_gallery_13_th = "images/gallery/image_gallery/thumbnails/sadie/13.webp"

# Episode 5
image sd_gallery_14_th = "images/gallery/image_gallery/thumbnails/sadie/14.webp"
image sd_gallery_15_th = "images/gallery/image_gallery/thumbnails/sadie/15.webp"
image sd_gallery_16_th = "images/gallery/image_gallery/thumbnails/sadie/16.webp"

# Censored #

# Francesca ##################

# Episode 1
image fr_gallery_1_th = "images/gallery/image_gallery/thumbnails/francesca/1.webp"
image fr_gallery_2_th = "images/gallery/image_gallery/thumbnails/francesca/2.webp"
image fr_gallery_3_th = "images/gallery/image_gallery/thumbnails/francesca/3.webp"

# Episode 2
image fr_gallery_4_th = "images/gallery/image_gallery/thumbnails/francesca/4.webp"
image fr_gallery_5_th = "images/gallery/image_gallery/thumbnails/francesca/5.webp"
image fr_gallery_6_th = "images/gallery/image_gallery/thumbnails/francesca/6.webp"
image fr_gallery_7_th = "images/gallery/image_gallery/thumbnails/francesca/7.webp"

# Censored #
image fr_gallery_6_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/6.webp"
image fr_gallery_7_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/7.webp"

# Episode 3
image fr_gallery_8_th = "images/gallery/image_gallery/thumbnails/francesca/8.webp"
image fr_gallery_9_th = "images/gallery/image_gallery/thumbnails/francesca/9.webp"
image fr_gallery_10_th = "images/gallery/image_gallery/thumbnails/francesca/10.webp"

# Censored #
image fr_gallery_9_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/9.webp"
image fr_gallery_10_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/10.webp"

# Episode 4
image fr_gallery_11_th = "images/gallery/image_gallery/thumbnails/francesca/11.webp"
image fr_gallery_12_th = "images/gallery/image_gallery/thumbnails/francesca/12.webp"
image fr_gallery_13_th = "images/gallery/image_gallery/thumbnails/francesca/13.webp"

# Censored #
image fr_gallery_12_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/12.webp"
image fr_gallery_13_th_cen = "images/gallery/image_gallery/thumbnails/francesca/censored/13.webp"

# Tiffany ##################

# Episode 3
image tf_gallery_1_th = "images/gallery/image_gallery/thumbnails/tiffany/1.webp"

# Episode 4
image tf_gallery_2_th = "images/gallery/image_gallery/thumbnails/tiffany/2.webp"
image tf_gallery_3_th = "images/gallery/image_gallery/thumbnails/tiffany/3.webp"
image tf_gallery_4_th = "images/gallery/image_gallery/thumbnails/tiffany/4.webp"

# Censored #
image tf_gallery_4_th_cen = "images/gallery/image_gallery/thumbnails/tiffany/censored/4.webp"

# Episode 5
image tf_gallery_5_th = "images/gallery/image_gallery/thumbnails/tiffany/5.webp"
image tf_gallery_6_th = "images/gallery/image_gallery/thumbnails/tiffany/6.webp"
image tf_gallery_7_th = "images/gallery/image_gallery/thumbnails/tiffany/7.webp"
image tf_gallery_8_th = "images/gallery/image_gallery/thumbnails/tiffany/8.webp"
image tf_gallery_9_th = "images/gallery/image_gallery/thumbnails/tiffany/9.webp"

# Censored #
image tf_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/tiffany/censored/8.webp"

# Evelyn ##################

# Episode 3
image ev_gallery_1_th = "images/gallery/image_gallery/thumbnails/evelyn/1.webp"

# Episode 4
image ev_gallery_2_th = "images/gallery/image_gallery/thumbnails/evelyn/2.webp"
image ev_gallery_3_th = "images/gallery/image_gallery/thumbnails/evelyn/3.webp"
image ev_gallery_4_th = "images/gallery/image_gallery/thumbnails/evelyn/4.webp"

# Censored #
image ev_gallery_3_th_cen = "images/gallery/image_gallery/thumbnails/evelyn/censored/3.webp"
image ev_gallery_4_th_cen = "images/gallery/image_gallery/thumbnails/evelyn/censored/4.webp"

# Episode 5
image ev_gallery_5_th = "images/gallery/image_gallery/thumbnails/evelyn/5.webp"
image ev_gallery_6_th = "images/gallery/image_gallery/thumbnails/evelyn/6.webp"
image ev_gallery_7_th = "images/gallery/image_gallery/thumbnails/evelyn/7.webp"
image ev_gallery_8_th = "images/gallery/image_gallery/thumbnails/evelyn/8.webp"

image ev_gallery_8_th_cen = "images/gallery/image_gallery/thumbnails/evelyn/censored/8.webp"

# Mixed ##################

# Episode 1
image mixed_gallery_1_th = "images/gallery/image_gallery/thumbnails/mixed/1.webp"
image mixed_gallery_2_th = "images/gallery/image_gallery/thumbnails/mixed/2.webp"
image mixed_gallery_3_th = "images/gallery/image_gallery/thumbnails/mixed/3.webp"
image mixed_gallery_4_th = "images/gallery/image_gallery/thumbnails/mixed/4.webp"

# Episode 2
image mixed_gallery_5_th = "images/gallery/image_gallery/thumbnails/mixed/5.webp"
image mixed_gallery_6_th = "images/gallery/image_gallery/thumbnails/mixed/6.webp"
image mixed_gallery_7_th = "images/gallery/image_gallery/thumbnails/mixed/7.webp"

# Episode 3
image mixed_gallery_8_th = "images/gallery/image_gallery/thumbnails/mixed/8.webp"
image mixed_gallery_9_th = "images/gallery/image_gallery/thumbnails/mixed/9.webp"
image mixed_gallery_10_th = "images/gallery/image_gallery/thumbnails/mixed/10.webp"
image mixed_gallery_11_th = "images/gallery/image_gallery/thumbnails/mixed/11.webp"
image mixed_gallery_12_th = "images/gallery/image_gallery/thumbnails/mixed/12.webp"
image mixed_gallery_13_th = "images/gallery/image_gallery/thumbnails/mixed/13.webp"

# Censored #
image mixed_gallery_10_th_cen = "images/gallery/image_gallery/thumbnails/mixed/censored/10.webp"
image mixed_gallery_13_th_cen = "images/gallery/image_gallery/thumbnails/mixed/censored/13.webp"

# Episode 4
image mixed_gallery_14_th = "images/gallery/image_gallery/thumbnails/mixed/14.webp"
image mixed_gallery_15_th = "images/gallery/image_gallery/thumbnails/mixed/15.webp"
image mixed_gallery_16_th = "images/gallery/image_gallery/thumbnails/mixed/16.webp"
image mixed_gallery_17_th = "images/gallery/image_gallery/thumbnails/mixed/17.webp"

# Censored #
image mixed_gallery_14_th_cen = "images/gallery/image_gallery/thumbnails/mixed/censored/14.webp"
image mixed_gallery_17_th_cen = "images/gallery/image_gallery/thumbnails/mixed/censored/17.webp"
