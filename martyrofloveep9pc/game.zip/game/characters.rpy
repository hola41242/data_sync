# Characters

#Main Characters
define p = Character("[pf]",who_color = "#00fff2")
define pt = Character("[pf]", who_color="#00fff2", what_color="#dfb8ff", what_italic=1)
define sa = Character("Samantha",who_color = "#eb02d7")
define mr = Character("Ms. Revello",who_color = "#eb02d7")
define mt = Character("Metal",who_color = "#010003")
define cd = Character("Candace",who_color = "#fc8403")
define cs = Character("Christina",who_color = "#cf350a")
define mm = Character("Mom",who_color = "#ffffff")
define dp = Character("Dr. Pratt",who_color = "#ff5c6c")
define ama = Character("Amanda",who_color = "#ff5c6c")
define mc = Character("Master Collins",who_color = "#a5f505")
define mrc = Character("Mr. Collins",who_color = "#a5f505")
define js = Character("Jessica",who_color = "#de1f4c")
define an = Character("Ann",who_color = "#9508cc")
define anth = Character("Ann",who_color = "#9508cc", what_color="#ffb8c2", what_italic=1)
define bi = Character("Billy",who_color = "#8fd685")
define fr = Character("Friend",who_color = "#104257")
define df = Character("Dumbface",who_color = "#666269", what_color="#7d807e")
define b = Character("Both",who_color = "#ffffff")
define mk = Character("Ms. Know-it-all",who_color = "#fa4e48")
define ri = Character("Rivka",who_color = "#fa4e48")
define uk = Character("Unknown",who_color = "#ffffff")
define ma = Character("Mr. Anderson",who_color = "#5875d6")
define mmi = Character("Mrs. Miller",who_color = "#f2e38d")
define sh = Character("Sharon",who_color = "#f2e38d")
define il = Character("Instant Love",who_color = "#eb02d7")
define bv = Character("Beautiful Voice",who_color = "#eb02d7")
define she = Character("Sheriff",who_color = "#364d73")
define li = Character("Librarian",who_color = "#71abad")
define fz = Character("Franz",who_color = "#ffffff")
define se = Character("Seller",who_color = "#ffffff")
define va = Character("Vanessa",who_color = "#50f2b9")
define cu = Character("Customer",who_color = "#ffffff")
define mrre = Character("Mr. Revello",who_color = "#0335ff")
define giu = Character("Giuseppe",who_color = "#0335ff")
define giut = Character("Giuseppe",who_color = "#0335ff", what_color="#aab0a7", what_italic=1)
define mrsre = Character("Mrs. Revello",who_color = "#05fa5f")
define vi = Character("Vittoria",who_color = "#05fa5f")
define mrslo = Character("Mrs. Lopez",who_color = "#05e2ff")
define br = Character("Brenda",who_color = "#05e2ff")
define brt = Character("Brenda", who_color="#05e2ff", what_color="#f2745e", what_italic=1)
define ni = Character("Nicole",who_color = "#dbde21")
define val = Character("Valentina",who_color = "#fa0244")
define cro = Character("Crowd",who_color = "#ffffff")
define brf = Character("Brainwashed Follower",who_color = "#615880")
define pp = Character("Possessed [pf]",who_color = "#00fff2")
define bas = Character("Bastard",who_color = "#0335ff")
define ub = Character("Unconfirmed Bastard",who_color = "#0335ff")
define ca = Character("Camille",who_color = "#25b8b3")
define re = Character("Reporter",who_color = "#ffffff")
define jos = Character("Josephine",who_color = "#ffea5e")
define jo = Character("Jo",who_color = "#ffea5e")
define cj = Character("CJ",who_color = "#00fc04")
define aal = Character("Aaliyah",who_color = "#bb82f5")
define ba = Character("Bartender",who_color = "#ffffff")
define yu = Character("Yua",who_color = "#fcd0b1")
define mh = Character("My Hero",who_color = "#3912fc")
define rd = Character("Rob Davies",who_color = "#feffba")
define cr = Character("Cara",who_color = "#43ebfa")
define ge = Character("George",who_color = "#1e5fb3")
define gi = Character("Gigi",who_color = "#fc03c2")
define cuc = Character("Cuck",who_color = "#0335ff")
define orl = Character("Orla",who_color = "#f7ae02")
define gin = Character("Ginevra",who_color = "#03fc90")
define coa = Character("Coach Robinson",who_color = "#329dfa")
define kp = Character("Kalvin",who_color = "#7c9cfc")
define ep = Character("Ethan",who_color = "#94ffd2")
define bo = Character("Body",who_color = "#ffffff")
define wi = Character("William",who_color = "#364d73")
define fzt = Character("Franz", who_color="#ffffff", what_color="#82d1ff", what_italic=1)
define may = Character("Metal & You",who_color = "#ffffff")
define el = Character("Elle",who_color = "#f7022b")
define pi = Character("Pia",who_color = "#e048a1")
define ti = Character("Tiffany",who_color = "#6e6e6e")
define de = Character("Destiny",who_color = "#b4d15c")
define te = Character("Tesia",who_color = "#42f598")
define of = Character("Officer",who_color = "#ffffff")
define pr = Character("Priest",who_color = "#ffffff")
define am = Character("Amelia",who_color = "#e8ff66")
define sc = Character("S's cousin",who_color = "#ffffff")
define ant = Character("Anto",who_color = "#3e7194")
define pl = Character("Player",who_color = "#ffffff")
define ren = Character("Renilic",who_color = "#43cee0")
define gil = Character("Gilmar",who_color = "#0ec96c")
define sk = Character("Sarka",who_color = "#ff0000")
define sku = Character("Unknown",who_color = "#ff0000")
define vt = Character("Valtr",who_color = "#2e4369")
define vtu = Character("Unknown",who_color = "#2e4369")
define is = Character("Isaac",who_color = "#0b362c")
define fu = Character("Fumino",who_color = "#fa3402")
define la = Character("Lalas",who_color = "#cf7448")
define com = Character("Commentator",who_color = "#ffffff")
define ada = Character("Adams",who_color = "#c4a7a1")
define nk = Character("Niko",who_color = "#444a54")
define jx = Character("Jaxrael",who_color = "#324f80")
define ho = Character("Hobo",who_color = "#ffffff")
define luk = Character("Unknown",who_color = "#fffeb8")
define dem = Character("Demna",who_color = "#0a0a0a")
define lgb = Character("LGBTQXYZ+ Dude",who_color = "#ff05b4")
define ref = Character("Referee",who_color = "#ffffff")
define sm = Character("Smith",who_color = "#ba9963")
define ben = Character("Benjamin",who_color = "#5cf7c3")
define bw = Character("Blind woman",who_color = "#acafb5")
define ro = Character("Rocko",who_color = "#8390a8")
define rai = Character("Rainbowman",who_color = "#e2b3f5")
define lo = Character("Lola",who_color = "#cf1204")
define joa = Character("Joanna",who_color = "#148ab8")
define yus = Character("Yusuf",who_color = "#fcb177")
define wic = Character("Wicko",who_color = "#000000")
define chu = Character("Chucko",who_color = "#6b7585")
define fab = Character("Fabienne",who_color = "#fc766f")
define ch = Character("Charlotte",who_color = "#e94af7")
define si = Character("Sigrid",who_color = "#0ccf40")
define fhn = Character("Forgot her name",who_color = "#f7ae02")
define mak = Character("Makena",who_color = "#e639c9")
define fla = Character("Flavor",who_color = "#4dff7c")
define jd = Character("Jordan",who_color = "#dbff4d")
define ray = Character("Raygun",who_color = "#2f9e6c")
define bl = Character("Blythe",who_color = "#ffed4f")
define bou = Character("Bouba",who_color = "#786260")
define vir = Character("Virgilio",who_color = "#c5cf8a")
define me = Character("Meg",who_color = "#0ce7f2")
define meg = Character("Megan",who_color = "#0ce7f2")
define jt = Character("Jalen Thomas",who_color = "#a9fce0")
define ru = Character("Ruby",who_color = "#e60a41")
define md = Character("Mr. Dorn",who_color = "#849ae0")
define hoss = Character("Hostess",who_color = "#ffffff")
define art = Character("Arthur",who_color = "#94cfe0")
define vad = Character("Vanessa's dad",who_color = "#b1ccb9")
define hos = Character("Host",who_color = "#ffffff")
define wai = Character("Waitress",who_color = "#ffffff")
define vl = Character("Valet",who_color = "#ffffff")
define mar = Character("Mary",who_color = "#5a0af0")
define se = Character("Selena",who_color = "#288bed")
define hcm = Character("Happy Crew Member",who_color = "#ebc930")
define dr = Character("Doctor",who_color = "#ffffff")
define ce = Character("Cesare",who_color = "#f32516")
define na = Character("Natalia",who_color = "#0e91a8")
define ba = Character("Barbara",who_color = "#2df3a7")
define je = Character("Jeffrey",who_color = "#68b1f5")
define nan = Character("News Anchor",who_color = "#ffffff")
define ed = Character("Edwige",who_color = "#65c9a3")
define kar = Character("Karen",who_color = "#ff0080")
define ro = Character("Roxie",who_color = "#7bff00")
define dj = Character("DJ Marshmello",who_color = "#7bff00")
define ka = Character("Kanna",who_color = "#B800B8")
define ar = Character("Arina",who_color = "#00d9ff")
define mi = Character("Michael",who_color = "#70aab4")
define dm = Character("Dr. Mendes",who_color = "#b6daa2")
define le = Character("Leah",who_color = "#eca058")
define mat  = Character("Matt",who_color = "#a2bada")
define hag  = Character("Hagar",who_color = "#a2dad3")
define hc  = Character("Hot coach",who_color = "#13e7ce")
define ya  = Character("Yamalo",who_color = "#e9722e")
define fa = Character("Fans",who_color = "#ffffff")
define rec = Character("Receptionist",who_color = "#ffffff")
define mal = Character("Malaika",who_color = "#2c39f5")
define jac = Character("Jacqueline",who_color = "#f5762c")
define pen = Character("Penelope",who_color = "#5fd4e4")
define sve = Character("Sveta",who_color = "#fa2755")
define ag = Character("Agent",who_color = "#ffffff")



#main menu video

image main_menu_animated:
    "gui/sec/intromark1.jpg"
    pause 3.6
    "gui/sec/intromark1a.jpg"
    pause 0.084
    "gui/sec/intromark1b.jpg"
    pause 0.084
    "gui/sec/intromark1c.jpg"
    pause 0.084
    "gui/sec/intromark1d.jpg"
    pause 0.084
    "gui/sec/intromark1e.jpg"
    pause 0.084
    "gui/sec/intromark1f.jpg"
    pause 0.084
    "gui/sec/intromark1g.jpg"
    pause 0.084
    "gui/sec/intromark1h.jpg"
    pause 0.084
    "gui/sec/intromark1i.jpg"
    pause 0.084
    "gui/sec/intromark16.jpg"
    pause 3.6
    "gui/sec/intromark16a.jpg"
    pause 0.084
    "gui/sec/intromark16b.jpg"
    pause 0.084
    "gui/sec/intromark16c.jpg"
    pause 0.084
    "gui/sec/intromark16d.jpg"
    pause 0.084
    "gui/sec/intromark16e.jpg"
    pause 0.084
    "gui/sec/intromark16f.jpg"
    pause 0.084
    "gui/sec/intromark16g.jpg"
    pause 0.084
    "gui/sec/intromark16h.jpg"
    pause 0.084
    "gui/sec/intromark16i.jpg"
    pause 0.084
    "gui/sec/intromark31.jpg"
    pause 3.6
    "gui/sec/intromark31a.jpg"
    pause 0.084
    "gui/sec/intromark31b.jpg"
    pause 0.084
    "gui/sec/intromark31c.jpg"
    pause 0.084
    "gui/sec/intromark31d.jpg"
    pause 0.084
    "gui/sec/intromark31e.jpg"
    pause 0.084
    "gui/sec/intromark31f.jpg"
    pause 0.084
    "gui/sec/intromark31g.jpg"
    pause 0.084
    "gui/sec/intromark31h.jpg"
    pause 0.084
    "gui/sec/intromark31i.jpg"
    pause 0.084
    repeat




init:

    $ flash = Fade(.25, 0, .75, color="#fff")


define gui.dialogue_text_outlines = [ (4, "#0E0E0E", 0, 0) ]
define gui.name_text_outlines = [ (2.2, "#333333", 1, 1) ]


init python:
    speed = 0
    angle = 0

#Cellphone
# NVL characters are used for the phone texting
define n_nvl = Character("Nighten", kind=nvl, image="nighten", callback=Phone_SendSound)
define e_nvl = Character("CJ", kind=nvl, callback=Phone_ReceiveSound)

define config.adv_nvl_transition = None
define config.nvl_adv_transition = Dissolve(0.3)

# Default name for MC
init python:

    def setReplay():
        global p
        global pf
        if persistent.p:
            p = persistent.p
        else:
            p = "Mark"
