#Important Decisions
default choice45a = False
default choice45b = False
default choice46a = False
default choice47a = False
default choice47b = False
default choice48a = False
default choice53a = False
default choice58a = False
default choice58b = False



# Start Episode 3
label ep3:
if choice9b:
    jump choice45_common

if choice11b:
    jump choice45_common
else:
    scene s1 with dissolve
    play music "audio/inspired.ogg"
    an "Hi, [p]! I was looking for you!"
    scene s2 with dissolve
    p "Oh hello, Ann! What happened? Let me guess...Daniel?"
    an "Hehe, it's not about him...I wanted to ask you something..."
    p "Sure, tell me."
    scene s3 with dissolve
    an "You see, tonight we have this...err...Master Collins's event...and I know you don't like him, but I don't want to go alone...besides, we did win that silly game as a team remember..."
    jump invitation

if choice10b:
    scene s1 with dissolve
    play music "audio/inspired.ogg"
    an "Hi, [p]! I was looking for you!"
    scene s2 with dissolve
    p "Oh hello, Ann! What happened? Let me guess...Daniel?"
    an "Hehe, it's not about him...I wanted to ask you something..."
    p "Sure, tell me."
    scene s3 with dissolve
    an "You see, tonight we have this...err...Master Collins's event...and I know you don't like him, but I don't want to go alone...besides, we did win that silly game as a team remember..."

label invitation:

menu:
    "Go with her.":
        jump choice45a

    "Don't.":
        jump choice45b

label choice45a:

    $ choice45a = True

    scene s4 with dissolve
    p "I'll go with you."
    scene s5 with dissolve
    an "Really?!"
    p "Yeah, I heard you say the other day you'll try anything once, right? I won't be the guy who ruins it for you."
    scene s6 with dissolve
    an "Yes! Oh my God, you're so cool! I was so sure you were gonna say no..."
    p "You really wanted to go, huh? But hey, if it sucks, you'll never hear the end of it, ok?"
    scene s7 with dissolve
    an "Deal! Meet you there! I'll text you the address later."
    p "Good, I'll be waiting..."

    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    scene s8 with Dissolve(2.0)
    pause 1.0
    scene s13 with dissolve
    pt "This's the location she shared..."
    scene s14 with dissolve
    pt "Here goes nothing."
    scene s15 with dissolve
    pt "Oh, wow..."
    scene s14 with dissolve
    pt "Keep your cool, man."
    scene s10 with dissolve
    pause 1.0
    play music "audio/garage.ogg" volume 0.8

    scene s11:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    scene s12 with dissolve
    pt "That brunette's eating me up with her eyes..."
    scene s16 with dissolve
    uk "Hi, there! Are you here for The Master's conference?"
    p "Hello! Yeah, I am."
    uk "Do you have your pin with you?"
    p " I have it right here!"
    stop music fadeout 3.0
    scene s17 with dissolve
    uk "Great! Come with me, please."
    p "Uhm, I'm actually waiting for a friend..."
    an "Nicole?"
    scene s18 with dissolve
    pause 0.5
    scene s19 with dissolve
    ni "Ann! Oh my God! Long time no see!"
    scene s20 with dissolve
    play music "audio/po.ogg"
    an "Hi, [p]!"

    scene s21:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    p "Heeeeyyy..."
    pt "Ann looks pretty tonight..."
    scene s22 with dissolve
    pause 1.5
    scene s23 with dissolve
    ni "Oh! I can see you're here for the conference."
    scene s24 with dissolve
    an "Yeah, with my buddy [p]."
    ni "Oh, so she's the one you were waiting for..."
    scene s25 with dissolve
    ni "Don't worry, guys, I'll get you the best seats!"
    an "Great!"
    p "Thank you!"
    pt "Wait a minute...\"the best seats\" means closer to Mr. Collins? Fuck!"
    scene s26 with dissolve
    ni "I need to tell Ann something real quick...Excuse us for a sec..."
    p "Sure, go ahead."
    scene s27 with dissolve
    an "What is it?"
    uk "I like short guys..."
    p "Huh?"
    scene s28 with dissolve
    uk "Hi."
menu:
    "Go with the flow.":
        jump choice46a
    "Short?!":
        jump choice46b

label choice46a:

    $ choice46a = True

    scene s29 with dissolve
    p "Haha, you do? Well, I like tall girls..."
    scene s30 with dissolve
    uk "But you came in here with a shorty."
    scene s29 with dissolve
    p "She's a friend..."
    scene s31 with dissolve
    uk "Valentina."
    p "[p]."

menu:
    "Ask for her number.":
        jump choice47a

    "You have a girlfriend, no need.":
        jump choice47b

label choice47a:

    $ choice47a = True

    scene s29 with dissolve
    p "So, Valentina, powerful name by the way, can I get your number?"
    scene s32 with dissolve
    val "I like that, your confidence. Men usually find me intimidating."
    p "Might be your height..."
    scene s33 with dissolve
    val "Ha!...Give me your phone."
    scene s34 with dissolve
    pause 2.0
    scene s35 with dissolve
    val "There."
    play sound "audio/shutter.ogg"
    scene s35
    scene s35a with dissolve
    scene s35b
    scene s35 with dissolve
    scene s36 with dissolve
    p "What the hell?!"
    scene s37 with dissolve
    an "Don't move...got it!"
    scene s38 with dissolve
    p "What are you doing?"
    scene s39 with dissolve
    an "Nothing, just taking pictures...I'll just save this one as evidence for now..."
    p "Evidence? What are you talking about?"
    scene s40 with dissolve
    an "Hey, you, Giganta! He has a girlfriend, you know that?!"
    scene s41 with dissolve
    val "Relax, shorty, we were just talking..."
    scene s42 with dissolve
    an "Did she just call me \"shorty\"?"
    scene s43 with dissolve
    an "Did she just call me \"shorty\"?"
    ni "Oh, come on! Drop it right there! You started it."
    scene s44 with dissolve
    p "Yeah, knock it off, Ann...Nicole, why don't you take us to the event? That's what we came for, right Ann?"
    ni "I couldn't agree more."
    scene s45 with dissolve
    p "Sorry about that, I don't know what got into her...I'd better get going, talk to you later Valentina."
    scene s46 with dissolve
    val "No worries, I didn't mind her. See ya!"

    jump choice47_common

label choice47b:

    $ choice47b = True

    scene s47 with dissolve
    an "[p], let's go!"
    p "Coming!"
    scene s29 with dissolve
    p "Nice talking to you, Valentina, take care!"
    scene s28 with dissolve
    val "Bye."

    jump choice47_common

label choice46b:
    scene s29 with dissolve
    p "What?! Excuse you?!"
    p "Ok, you're taller than me, but that doesn't mean I'm short, I'm 5'9..."
    scene s28 with dissolve
    uk "That's what I said: short."
    scene s48 with dissolve
    p "You're wearing heels!"
    scene s49 with dissolve
    uk "Touchy subject, huh? Fragile masculinity...hard pass. Bye."
    p "Okaaayyy..."
    scene s47 with dissolve
    an "[p], let's go!"
    p "Coming!"

    jump choice47_common

label choice47_common:

    stop music fadeout 3.0
    scene black with Dissolve(2.5)
    scene s50 with dissolve
    ni "As promised, these are the best seats guys! Enjoy the seminar!"
    an "Thank you, Ni, you're the best! I'll call you later."
    p "Thanks, Nicole!"
    scene black with dissolve
    scene s51 with dissolve
    an "It looks great, doesn't it?!"
    p "Yeah, like a concert...You know this type of events are full of light shows and..."
    scene s52 with dissolve
    mt "Welcome ladies and gentlemen to the main event of the year..."
    pt "That voice...is that...?"
    scene s53 with dissolve
    an "Look!"
    p "What?"
    scene s54 with dissolve
    play music "audio/funkpositive.ogg" volume 0.8
    pause 1.0
    scene s55:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    p "No{w=1.0} fucking{w=1.0} way..."

    scene s54 with dissolve
    mt "It's...tiiiiiiiiime to \"Unleash the Beast Within\"!!!"
    mt "This is the moment you've all been waiting for!"
    scene s56 with dissolve
    bi "May I present to you our Sensei..."
    scene s57 with dissolve
    mt "Our Guiding Light..."
    scene s58 with dissolve
    bi "The one and only..."
    scene s59 with dissolve
    b "Masteeeeeeeeeeer..."
    scene s60 with dissolve
    b "Tommy Collins!!!"
    scene s61 with dissolve
    mc "Take the hat, Billy, and give me my mic..."
    bi "Yes, Master!"
    scene s62 with dissolve
    mc "Who's ready to change their life? Say \"Hi!\""
    cro "Hi!!!"
    scene s63 with dissolve
    mc "Who's ready to change their life? Say \"Hi!\""
    cro "Hi!!!"
    scene s64 with dissolve
    mc "Stop, stop the music right there, DJ."
    stop music
    play sound "audio/scratch.ogg"
    mc "I'm gonna ask you a pretty serious question: When do people really start to live, huh? When? Do you know when?"
    play music "audio/raisingexpectation.ogg"
    mc "When you face death!"
    mc "People usually ask me: Master, what's up with your fascination with skulls and bones? How come you're always wearing death symbols, sensei?"
    scene s65 with dissolve
    mc "My answer is...because I'm obsessed with death! I want to face it every single day of my life!"
    scene s66 with dissolve
    mc "When you face death, all of a sudden everything gets reprioritized, you start paying attention to things you take for granted..."
    scene s65 with dissolve
    mc "What would you do if today was your last day alive? Who would you call?! What truth would you say?!"
    scene s67 with dissolve
    mc "Life's short and we never know when it's gonna end..."
    mc "Today, ladies and gentlemen, I'll help you get rid of your limiting beliefs by facing your deepest fear...today, you all are going to face..."
    stop music fadeout 3.0
    scene s68 with dissolve
    play sound "audio/deathgta.ogg"
    mc "Death!"
    an "What?!"
    p "This can't be good..."
    scene black with Dissolve(2.5)
    play music "audio/everyoneyouknow.ogg"
    scene s69 with dissolve
    mc "Behold...The Firewalk!"
    scene s70 with dissolve
    mc "If you can walk on fire, you can do anything in life! Nothing will stop you! You'll get whatever you want!"
    mc "Who will be the first person to walk across these hot coals and conquer their fears? Who's going to be the first one to say: \"Yes, I can!\"? Say \"Hi!\""
    cro "Hi!!!"
    scene s71 with dissolve
    pt "Holy fuck!"
    scene s72 with dissolve
    p "What...why are you smiling? You want me to...Hell no! I'm not doing it..."
    scene s73 with dissolve
    p "That smile will get you places, not with me though."
    scene s74 with dissolve
    an "Come on, [p]! You only live once! I want to do it...pretty please?"

menu:
    "Do it for her.":
        jump choice48a

    "Don't.":
        jump choice48b

label choice48b:
    scene s75 with dissolve
    p "It's not safe, Annie, look at all that fire coming out from those coals! In fact, I think I can't let you do it...I don't want you to get hurt."
    scene s76 with dissolve
    an "You said the same thing the first day we met, you're very protective...that's quite a beautiful trait you have."
    scene s77 with dissolve
    an "And yeah, you're right, I'm not dumb, I know what the most obvious outcome is."
    scene s78 with dissolve
    an "Let's watch some people get burned first!"
    p "Hahaha...what?"
    scene black with dissolve
    scene s79 with dissolve
    mc "There's nothing to fear! You're going to storm through this! It's cool moss! Scream Yes!"
    brf "Yes! Cool moss! Cool moss!"
    scene s80 with dissolve
    mc "Cool moss, cool moss!"
    an "Yeah, cool moss! Come on, you can do it!"
    mc "Scream yes!"
    brf "Yes!"
    mc "You go!"
    scene s81 with dissolve
    brf "Aaaaahhhhhh!!!"
    p "Hoooooly shit!"
    scene black with dissolve
    scene s82 with dissolve
    brf "Yessss, I did it, brother! Nothing happened! Now you go there and show me what real tigers are made of!"
    pt "How in the hell this guy did not get burned?"
    an "Yes, [p], show him! Haha!"
    scene s83 with dissolve
    p "Yeah, don't touch me."
    pt "There must be a trick...is this guy part of the staff?"
    scene s91 with dissolve
    an "I'm next!"
    pt "I thought you wouldn't...support her, she wants to do it..."
    p "You can do it, Annie!"
    scene black with Dissolve(1.0)
    scene s92 with dissolve
    mc "What's the worst that could happen? Burn your feet off and die? Come on! Go!"
    an "Yes! Cool moss!!!"
    pt "She's way too relaxed..."
    scene s93 with dissolve
    an "I got this!"
    p "Come on, Annie!"
    scene s94 with dissolve
    pt "Daaaaaammnn!"
    scene black with dissolve
    scene s95 with dissolve
    an "I did it, [p]!"
    p "You sure did! That was unbelievable!"
    scene s96 with dissolve
    p "What..."
    scene s97 with dissolve
    an "Aaaahhh!!!"
    p "Oh god..."
    stop music fadeout 3.0
    jump choice48_common

label choice48a:

    $ choice48a = True

    scene s75 with dissolve
    p "Ok, I'll go if you go..."
    scene s78 with dissolve
    an "Yes!"
    scene black with dissolve
    scene s79 with dissolve
    mc "There's nothing to fear! You're going to storm through this! It's cool moss! Scream Yes!"
    brf "Yes! Cool moss! Cool moss!"
    scene s80 with dissolve
    mc "Cool moss, cool moss!"
    an "Yeah, cool moss! Come on, you can do it!"
    mc "Scream yes!"
    brf "Yes!"
    mc "You go!"
    scene s81 with dissolve
    brf "Aaaaahhhhhh!!!"
    p "Hoooooly shit!"
    scene black with dissolve
    scene s82 with dissolve
    brf "Yessss, I did it, brother! Nothing happened! Now you go there and show me what real lions are made of!"
    pt "How in the hell this guy did not get burned?"
    an "Yes, [p], show him! Haha!"
    pt "You know what?"
    scene s84 with dissolve
    pp "I'll show you all adoring acolytes who I am!"
    brf "Yeah! Roar, brother! Grrr...Roooaarrr!"
    p "Don't ask for too much..."
    scene black with dissolve
    scene s85 with dissolve
    pt "What the hell am I doing? That fire is real no doubt, I can feel all the heat..."
    mc "I want you to unlock your inner power!"
    pt "Unlock my in...What the hell does that mean?!"
    mc "Connect with your confidence! Cool moss! Cool moss!"
    pt "Is that all the mental preparation I need? Really?"
    scene s86 with dissolve
    mc "Scream yes!"
    p "Yes!"
    scene s86a with dissolve
    mc "Louder!"
    scene s87 with dissolve
    pp "YES!!!"
    mc "Cool moss! You go!"
    scene s88 with dissolve
    pp "Cool moss, motherfuckers!"
    an "YES!"
    scene black with Dissolve(1.0)
    scene s89 with dissolve
    an "Oh my God! You did it!!! That was amazing!"
    scene s90 with dissolve
    p "I can't believe I didn't get my feet burned!"
    scene s91 with dissolve
    an "Can't believe it either, I'm going next!"
    scene black with dissolve
    scene s92 with dissolve
    mc "What's the worst that could happen? Burn your feet off and die? Come on! Go!"
    an "Yes! Cool moss!!!"
    pt "She's way too relaxed..."
    scene s93 with dissolve
    an "I got this!"
    p "Come on, Annie!"
    scene s94 with dissolve
    pt "Daaaaaammnn!"
    scene black with dissolve
    scene s95 with dissolve
    an "I did it, [p]!"
    p "You sure did! That was unbelievable!"
    scene s96 with dissolve
    p "What..."
    scene s97 with dissolve
    an "Aaaahhh!!!"
    p "Oh god..."
    stop music fadeout 3.0
    jump choice48_common

label choice48_common:
    scene black with Dissolve(3.0)

    $ renpy.movie_cutscene("videos/breakingnews.ogv")

    scene s98 with dissolve
    play music "audio/emergencysound.ogg"
    re "I'm here live from the luxurious Milton Hotel where a tragedy took place few minutes ago..."
    re "Over 30 people are being treated for severe burns after walking barefoot across hot coals..."
    re "A ritual for followers of famous motivational guru Tommy Collins."
    scene s99 with dissolve
    re "Here with me a spokesperson for Mr. Collins, Daniel Lopez..."
    scene s100 with dissolve
    re "Please tell us how this tragedy happened, Mr. Lopez."
    scene s101 with dissolve
    mt "There was no tragedy here, someone not familiar with the fire walk observed the event and called 911 erroneously reporting hundreds of people requiring medical attention for serious burns..."
    mt "Only 2 of 1000 participants requested any examination beyond what was readily available on site."
    scene s100 with dissolve
    re "Right...We've been told by many attendees this was an exclusive event for one hundred people only and a third of them got injured..."
    re "How would you explain this commotion? People really got their feet blistered and burned as you can see..."
    scene s102 with dissolve
    mt "They didn't believe enough in The Master."
    scene s103 with dissolve
    re "Unbelievable...for XYZ News, Josephine Garnier. Back to you Tom."
    mt "Hi, mom!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play music "audio/197.ogg"
    scene s104 with dissolve
    an "Thank you, [p], you're the best..."
    p "Hehe, why with that face?"
    scene s105 with dissolve
    an "It's the only one I have..."
    p "Hehe, you got lucky, Annie, could've been worse, a bunch of people got second and third degree burns from what I heard..."
    scene s106 with dissolve
    an "I know! Fortunately, I just got some dirt on my feet..."

if choice48a:
    scene s107 with dissolve
    an "But tell me, how'd you do it?!"
    p "I think you gotta be all worked up, you know, I felt like in a trance or something...but I really don't know..."
    jump endcar

label endcar:
    scene s108 with dissolve
    an "Did you see Daniel talking to a reporter at the end? Hehe..."
    p "Haha, noooo, I missed it...that was a big surprise, wasn't it? To see him and Billy at the event I mean..."
    scene s109 with dissolve
    an "Hahaha, their suits! Their sunglasses! That was epic! Hahaha"
    p "Hahaha."
    scene s108 with dissolve
    an "You know, all in all, I had fun tonight!"
    p "Me too, Annie, you made it fun..."
    scene black with Dissolve(1.0)
    scene s110a with Dissolve(0.033)
    scene s110b with Dissolve(0.033)
    scene s110c with Dissolve(0.033)
    scene s110d with Dissolve(0.033)
    scene s110e with Dissolve(0.033)
    scene s110f with Dissolve(0.033)
    scene s110g with Dissolve(0.033)
    scene s110h with Dissolve(0.033)
    scene s110i with Dissolve(0.033)
    scene s110j with Dissolve(0.033)
    scene s110k with Dissolve(0.033)
    scene s110l with Dissolve(0.033)
    scene s110m with Dissolve(0.033)
    scene s110n with Dissolve(0.033)
    scene s110o with Dissolve(0.033)
    scene s110p with Dissolve(0.033)
    scene s110q with Dissolve(0.033)
    scene s110 with dissolve
    an "Did I tell you you're the best yet?"
    p "Haha, shut up, only because we left your shoes with Nicole...where's the door?"
    an "To your right, my hero..."
    scene s111 with dissolve
    p "Haha, you're so full of bs too."
    an "Who else is?"
    p "I am."
    an "Haha."
    scene s112 with dissolve
    pause 1.5
    scene s113 with dissolve
    an "Thank you for everything, [p]!"
    scene s114 with dissolve
    an "Eh?"
    scene s115 with dissolve
    an "I think I lost my pin, let me check my purse..."
    scene s116 with dissolve
    an "It's not in here, must have fallen during the fire walk...I wanted to keep it..."
    scene s117 with dissolve
    p "Oh, you wanted a keepsake...here, you can have mine..."
    an "Oh my God, [p], stop it! You're too sweet to me..."
    p "I know, haha, truth is I'm sure it means more to you than it does to me, take it."
    scene s118 with dissolve
    an "I can totally see why Samantha fell for you..."
    scene s119 with dissolve
    an "A million times thank you!"
    scene s120 with dissolve

menu:
    "Try something.":
        jump choice49a

    "Don't.":
        jump choice49b

label choice49b:
    p "Bye, Annie, see you at college!"
    scene s121 with dissolve
    an "Good bye, [p]!"
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    jump choice45_common

label choice49a:
    pt "Should I...I don't think so, don't want to hurt S..."
    pt "Besides, Annie's a good girl, she's not a bitch..."
    pt "And my bro! He'd never forgive me if I kissed her...too many cons, but I think I can do this..."
    p "Come here!"
    scene s122 with dissolve
    pause 1
    scene s123 with dissolve
    pause 1
    scene s124 with dissolve
    an "What was that?"
    p "Nothing, I just felt like doing it...good night, Annie!"
    scene s125 with dissolve
    an "Good night, [p]..."
    pt "Yeah, Master move!"
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    jump choice45_common

label choice45b:

    $ choice45b = True

    scene s4 with dissolve
    pt "I don't think I can go with her...not only because I'm going to hate my life for a couple of hours if I go, but also because of Metal...what would he think? Would he feel betrayed? For sure, he loves drama..."
    p "I'm sorry, Ann, I don't think I can go you know..."
    scene s9 with dissolve
    an "Yeah, I kind of thought you wouldn't want to go, but I had to ask...it's ok, no biggie..."
    pt "She's such a nice girl...sorry, Annie...bros before hoes..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    jump choice45_common

label choice45_common:

    scene s773 with dissolve
    p "Hey, Riv! You're early for class!"
    scene s774 with dissolve
    ri "Riv?"
    p "Yeah, I thought of calling you Riv since we're friends now..."
    ri "Are we?"
    p "Haha, of course we are! Cut the crap...Oh! I like what you did to your hair! Looks smoother!"
    ri "Thanks I guess..."
    scene s775 with dissolve
    ri "Are you training for a marathon or something?"
    p "Not a marathon, no, but I do have a goal: I want to play soccer again."
    ri "I didn't know you played..."
    scene s776 with dissolve
    ri "Look! That's Billy over there."
    scene s778 with dissolve
    p "And the librarian, what's her name? You know her..."
    ri "Camille. You know she thinks you're cute?"
    p "Come on!"
    ri "That's exactly what I said to her! Don't you find it weird to see Billy wearing suits lately?"
    p "Totally!"

if choice45a:
    p "Oh, I haven't told you yet, I went..."
    jump billy

label billy:
    scene s779 with dissolve
    ri "She's pretty...Billy told me he's always liked her...you think he stands a chance now?"
    p "You mean now that he wears suits?"
    ri "I mean now that he's more confident."
    p "Well, confidence always wins..."
    scene s780 with dissolve
    play music "audio/tension1.ogg"
    p "That guy in black looks a little sus, Riv..."
    ri "You're right, looks like he's going to do something..."
    scene s781 with dissolve
    uk "What's your father's name?"
    p "What the hell?!"
    bi "What?! What do you want?!"
    scene s782 with dissolve
    uk "Perhaps I'm not making myself clear...."
    p "Hoooooly shit!!!"
    uk "Last chance: What's your father's name?!"
    bi "Please don't kill me!! I beg you!! Is it money you want?!"
    ri "I'm calling the police!"
    p "No time, Riv! We have to do something!"
    ri "Are you crazy?! There's nothing we can do!!"
    scene s783 with dissolve
    ri "Oh my god, [p], what are you doing?!! Come back here!!"
    scene s784 with dissolve
    uk "I saw you miles away, kid...you have balls for trying, I give you that, but you have no idea who you're dealing with..."
    scene s785 with dissolve
    uk "Game over."
    pt "Fuuuck!!!"
    pt "What did I do?!?! Is this really it?"
    pt "Am I gonna..."
    scene s786 with dissolve
    ri "FIIIIIIIIIIIRRREEEEEEEEE!"
    pt "She's sharp! Nobody would show up if she screamed \"help\"!"
    scene s788 with dissolve
    pt "Yeah, more people are gathering...they could've just saved my life!"
    scene s787 with dissolve
    she "Billyyyyyy!!!"
    bi "Daaaaddyyyy!!!"
    scene s789 with dissolve
    pt "Oh, thank God!!! He's running away..."
    pt "Breathe now...what an adrenaline rush when someone aims at you..."
    stop music fadeout 2.0
    scene black with Dissolve(1.5)
    scene s790 with dissolve
    bi "Daddyyyyyy! I thought I was gonna die!"
    p "Are you ok?"
    ca "Oh my God, you saved my life!"
    ri "[p]!!! Why did you do that?!"
    scene s791 with dissolve
    pt "Billy's The Sheriff's son? Well, that's a surprise..."
    she "Is everyone ok?"
    ri "I guess so."
    ca "I'm good."
    she "Y'all come with me, gotta talk to you..."
    scene black with dissolve
    play music "audio/beat4.ogg"
    scene s792 with dissolve
    she "Hey you, kid, I saw what you did for my son, you saved his life buying time there, I can't thank you enough, we'll forever be in your debt..."
    ca "Yeah, he risked his life for us, he's amazing! What the hell was that all about?"
    she "Listen y'all, it's very important you do not tell anybody about what just happened...let me conduct my own investigation first, I think I know that man..."
    ri "I don't know about that..."
    p "Dude, he wanted to kill your son! We should go to the police!"
    scene s793 with dissolve
    she "No, don't do that! Do not get the police involved!"
    scene s794 with dissolve
    ri "You're acting sketchy, old man...Is it true you killed your wife?"
    bi "WHAT?!?!"
    scene s795 with dissolve
    p "Riiivkaaa..."
    ri "What...you've heard the rumors, you want to know too, be honest...besides he's got some shady business going on, there's a reason why he doesn't want us to talk to the police, think about it..."
    scene s796 with dissolve
    bi "For your information, my mom died of cancer! Feel better about yourself now, little bitch?"
    ri "Oh so you're brave with unarmed women..."
    ri "Kudos, Billy!"
    bi "What?!"
    pt "Haha."
    p "Riv..."
    scene s797 with dissolve
    ca "Guys, focus. This is serious, we almost got killed today. As far as I'm concerned, I want nothing to do with this \"situation\"..."
    scene s798 with dissolve
    ca "You want to handle it? Be my guest."
    scene s799 with dissolve
    she "I'll handle it, I give you my word. And please do not talk about it at St. Francis...can't lose my job nor Billy's scholarship..."
    p "We'll keep our mouth shut, right Rivka?"
    ri "Yeah, I guess, but to tell the truth that's the least important thing...your lives are at risk, Sheriff...you don't seem to realize that..."
    she "I said I'll manage."
    ca "Good."
    stop music fadeout 3.0
    scene s800 with dissolve
    ca "Come, [p], I need to tell you something..."
    p "What is it?"
    scene s801 with dissolve
    ca "Thank you so much for saving me! I was so scared couldn't do anything, I froze. But you...you were so brave! I can't believe you risked your life for us, really..."
    p "No need to thank me, I wasn't thinking straight to be honest, I just knew I had to do something...anything..."
    scene s802 with dissolve
    ca "Even better, that moment revealed your true nature...Uhmmm, I was wondering maybe we can get together sometime...Uhmmm, can I get your number?"
    pt "She wastes no time..."
    p "Sure, we can have lunch or something..."
    scene s803 with dissolve
    ca "Right, lunch..."
    scene black with Dissolve(3.0)

    scene s700 with dissolve
    play music "audio/creepy.ogg"
    uk "Dude, you sure about that mask?"
    fz "Yeah, why? What's wrong?"
    scene s701 with dissolve
    uk "What's wrong? Everything is! You know these people are all about symbolism, you're trying to start something today? Tell me so I'm ready, you know we're on this together..."
    fz "Relax George, it's just a mask...it represents an innocent animal."
    ge "Yeah, a rabbit! A white one! You have to wear the one they gave us..."
    scene s702 with dissolve
    fz "Everything will be ok."
    ge "I hope you're right..."
    scene s703 with dissolve
    pause 1.5
    scene s704 with Dissolve(2.0)
    scene s705 with dissolve
    uk "Franz! What the fuck are you doing?! I'm about to punch you in the face!"
    fz "I'm not doing anything."
    uk "Don't play stupid with me! You know exactly what I mean...Showing up with a mask like that...You think that's brave? Cause it isn't, it's just stupid!"
    scene s706 with dissolve
    uk "You wanna get somewhere? Wanna help them? Hide! Go get your mask right now! George, take him to the lodge afterwards, The Nyacks are coming soon!"
    fz "Can everybody just relax?"
    scene s706a with dissolve
    uk "Relax? Listen you prick! Our lives are at stake right now: they tried to kill my son last week and it's not gonna be different with your families if we fail..."
    uk "Go and do what you're told! You're not gonna fuck this up!"
    fz "Ok, William."
    scene black with dissolve
    scene s707 with dissolve
    ge "Dude, it's them! I can't believe it! This's the first time they let us be so close!"
    fz "You're right, we're still at the lowest level, it's suspicious...even though they're wearing masks, we can easily tell it's them..."
    ge "We've been cleaning up after their rituals, they should trust us."
    fz "Not so sure about that, quiet now...and don't speak unless they tell you to."
    scene s709 with dissolve
    uk "Are you two new here? Why are you wearing white?"
    ge "No, Perfect Master, we're not new, we joined almost a year ago...we were told to wear white today and put on these masks."
    scene s710 with dissolve
    uk "Interesting...after a year and still Apprentices...Is everything ready?"
    fz "Yes, Perfect Master, they're waiting for you."
    uk "Good, good."
    scene s711 with dissolve
    fz "This way Perfect Masters."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    play music "audio/butter.ogg"
    scene s712 with dissolve
    sa "Come baby! You have to see them!"
    p "See what?"
    sa "You'd never guess..."
    p "What is it?"
    scene s713 with dissolve
    sa "Hurry!"
    scene s714 with dissolve
    sa "Look! They're back!"
    p "Who?"
    scene s715 with dissolve
    p "Where...where...I don't see anything."
    scene s716 with dissolve
    p "Oh, your snails! You told me you used to play with these! Well, not THESE obviously, but...you know what I mean."
    sa "Yeah, you remembered! I'm so happy they're back! I'm going to take so much care of them now!"
    p "What do they eat?"
    scene s717 with dissolve
    sa "Pretty much everything: they're omnivores, even detritivores for that matter..."
    p "Detri-what? What's that?"
    scene s718 with dissolve
    sa "Hehehe, they feed on dead or decomposing organic matter too."
    p "I'd never heard that word, not even from Rivka."
    sa "Hehehe."
    stop music fadeout 3.0

menu:
    "Mention her makeup":
        jump choice50a

    "No need.":
        jump choice50common

label choice50a:
    scene s719 with dissolve
    p "I like your makeup today, babe. You look beautiful, more than usual!"
    scene s718 with dissolve
    sa "Thank you babe! I'm glad you noticed!"
    scene s717 with dissolve
    sa "I wanted to look pretty for you! You know, I generally don't put on any makeup, but wanted to try something soft..."
    jump choice50common

label choice50common:
    scene s720 with dissolve
    vi "There you are, kids! We were looking for you...what are you doing out here?"

    play music "audio/sexback.ogg"
    scene s721:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    pt "Look at her! Why do I have to have such a hot mother-in-law?! Such natural beauty! She knows she doesn't need much makeup..."
    sa "I was just showing [p] the snails I found, mom."
    vi "Oh! Are they back? Let me see!"
    scene s722 with dissolve
    vi "Where are they?"
    pt "Don't stare [p]...don't stare..."
    scene s723 with dissolve
    sa "Here, let me show you..."
    vi "Oh, I see them! There's lots of them! This brings back some memories: you used to play with them all the time when you were little! And bugs! You liked bugs too!"
    pt "Yeah, keep talking you two..."
    pt "Wait, I forgot! Where's..."
    stop music fadeout 3.0
    scene s724 with dissolve
    pause
    pt "Fuck! I'm in trouble, he definitely saw me staring...what should I say?"
    p "Errr..."
    scene s725 with dissolve
    mrre "Honey, what were you saying about going to the beach next week?"
    pt "Oh, so you're just going to look the other way here? I'll take that all day! Besides it wasn't my fault, my eyes were pointing in that direction...your wife's ass was in the way, that's all."
    scene s726 with dissolve
    vi "Oh, yeah, we're going there next Saturday, we have a place at Sunny Beach...perhaps you'd like to go with us?"
    sa "Yeah, baby! What do you think?"
    p "Of course I'm going!"
    scene s727 with dissolve
    sa "Yayyy! We'll have so much fun!"
    scene black with Dissolve(3.0)

    play music "audio/jazz2.ogg"
    scene s126 with dissolve
    mm "Bye, kids, have fun at the beach!"
    p "We will, mom."
    sa "Good bye, Mrs. B! We'll be back tomorrow night..."
    scene s127 with dissolve
    p "I'd not seen this one, S! How many cars do you have?!"
    sa "Hehe, me...none; my dad, four...Baby, you'll have to take the back seat, ok?"
    p "No problem, let's go!"
    scene black with dissolve
    scene s128 with dissolve
    p "Hello!"
    sa "Chris, this's my boyfriend [p], Christina's my best friend."
    scene s129 with dissolve
    cs "Hey..."
    scene s130 with dissolve
    p "You go to St. Francis, don't you? I think I saw you my first day of classes."
    cs "Don't remember you, sorry..."
    p "Probably it wasn't you..."
    scene s131 with dissolve
    sa "This's her last year there! She'll start..."
    scene s132 with dissolve
    cs "Don't tell him about me, YOU are his girlfriend...talk about yourself."
    sa "She doesn't like to share much, that's something you two have in common, hehe...she's moodier than you though."
    scene s133 with dissolve
    cs "I'm right here, S!"
    sa "See?"
    scene s132 with dissolve
    cs "Just play some music..."
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s134 with dissolve
    sa "Hi, mom! We're finally here!"
    p "Hello, Vittoria!"
    cs "Hi, V..."
    scene s135 with dissolve
    vi "Oh, I'm glad you made it!"
    pt "Here we go again..."
    play music "audio/sexback.ogg"
    scene s136 with dissolve
    pause 1.5
    scene s137 with dissolve
    pause 1.5
    scene s138 with dissolve
    p "Oh, boy, here she comes..."
    scene s139 with dissolve
    pause 1.5
    scene s140 with dissolve
    pause 1.5
    scene s141 with dissolve
    vi "Welcome, kids!"
    pt "A soaking hug! Bring it!"

    scene s142:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "What a woman..."
    scene s143 with dissolve
    vi "We were waiting for you!"
    scene s144 with dissolve
    sa "Hey, mom..."
    scene s145 with dissolve
    vi "Hi, darling..."
    cs "How you doing, V?"
    scene s146 with vpunch
    pt "My turn! Excuse me, ladies..."
    vi "[p]! I hope you like our place..."
    scene s147 with dissolve
    p "It's beautiful, Vittoria! You have the whole beach to yourselves!"
    stop music fadeout 3.0
    scene s148 with dissolve
    sa "And dad?"
    vi "In the room, he said he was..."
    scene s149 with dissolve
    mrre "Someone summoned me?"
    play music "audio/reggae1.ogg"
    scene s150 with dissolve
    sa "OH MY GOD, dad, really?"
    vi "You're unbelievable, Giuseppe...Chris is here!"
    cs "Don't mind me..."
    mrre "See? Tina doesn't mind."
    scene s151 with dissolve
    mrre "Who wants some alcohol? Meee!"
    cs "Now we're talking..."
    scene black with dissolve
    scene s152 with dissolve
    sa "Mom, I have your martini right here!"
    vi "Thank you, honey."
    mrre "What're you drinking, son?"
    p "A beer's fine, thanks."
    scene s153 with dissolve
    sa "Mwah!"
    scene s154 with dissolve
    mrre "Here, champ. Enjoy!"
    p "Thank you, Mr. Revello."
    scene s155 with dissolve
    cs "A beer for me too, please, Mr. G."
    mrre "Sorry, Tina, that was the last one, there's wine and gin...I have to go buy more alcohol..."
    scene s156 with dissolve
    cs "Huh?"
    scene s157 with dissolve
    p "Here."
    cs "And you?"
    p "I'll have some wine."
    scene s158 with dissolve
    cs "Thanks..."
    scene s159 with dissolve
    pt "Ok, that's hot..."
    scene s160 with dissolve
    sa "Mom?"
    scene s161 with dissolve
    vi "Yeah, I saw that, he's a good kid."
    sa "I know."
    scene s162 with dissolve
    sa "Come, baby."
    scene s163 with dissolve
    pause 1.0
    scene s164 with dissolve
    sa "Love you, cat!"
    p "Love you, too."
    scene s163 with dissolve
    pause 1.0
    scene s165 with dissolve
    cs "Ewwww..."
    mrre "A little too much love if you ask me..."
    scene s166 with dissolve
    vi "Shut it! They're beautiful, ok? In fact, why aren't you a little bit more like [p]? When was the last time you told me you love me?"
    scene s167 with dissolve
    cs "Someone's in trouble..."
    scene s168 with dissolve
    mrre "Honey, you know how much I love you, there's no need to say it all the time..."
    scene s169 with dissolve
    vi "Who says there's no need?! How am I supposed to know if you never show it?!"
    cs "Yup, in BIG trouble."
    scene s170 with dissolve
    sa "Guys, guys, don't start, relax...let's enjoy the weekend, the sun!"
    scene s171 with dissolve
    mrre "{size=-6}Tell that to your mother...{/size}"
    vi "Excuse me?!"
    scene s172 with dissolve
    mrre "Nothing, honey!"
    stop music fadeout 3.0
    scene black with Dissolve(1.5)
    scene s173 with dissolve
    pause
    play music "audio/reggae2.ogg"
    scene s174 with dissolve
    pt "Don't gooooo...wake up! She's looking at you..."
    scene s175 with dissolve
    sa "What's wrong?"
    p "Nothing, I just don't know how to swim, S."
    scene s176 with dissolve
    sa "That's no problem at all! Come, I'll teach you!"
    scene s177 with dissolve
    sa "Lean forward, I'll hold your hands..."
    scene s178 with dissolve
    sa "Your watch's getting wet, baby..."
    p "Don't worry about it, babe, it's water resistant."
    scene s179 with dissolve
    sa "Ok, first of all, be relaxed, inhale and keep the air in your lungs so you can float naturally..."
    p "Don't let go..."
    sa "You're doing great, I'm not even holding you."
    scene s180 with dissolve
    vi "You have to go like this with your feet."
    scene s181 with dissolve
    pause
    scene s180 with dissolve
    pause
    scene s181 with dissolve
    pt "I have to see that..."
    scene s182 with dissolve

menu:
    "Could you show me how?":
        jump choice55a

    "Got it.":
        jump choice55b

label choice55b:
    scene s184 with dissolve
    sa "You can do it, baby!"
    scene s185 with dissolve
    sa "Kick, baby, kick!"
    vi "That's it, you're doing great!"
    p "Don't let go, I don't feel your hands!"
    sa "I'm right here."
    scene s186 with dissolve
    sa "You did it!"
    scene s187 with dissolve
    p "Thank you, S! You're the best! It's fun to swim, now I have to practice a lot, hehe..."
    sa "We'll do it together..."
    jump choice55_common

label choice55a:
    scene s183 with dissolve
    vi "Sure!"
    scene s189 with dissolve
    vi "You just have to kick with straight legs bending a little your knees..."
    scene s190 with dissolve
    vi "Like this..."
    scene s192 with dissolve
    vi "Look at my legs and feet, you see?"
    p "Oh, I see..."
    scene s190 with dissolve
    pause 1.0
    scene s191 with dissolve
    pt "Damn!"
    scene s193 with dissolve
    vi "Got it?"
    p "Ah? Oh, yeah, yeah..."
    sa "Get ready, baby, let's do it!"
    scene s194a with dissolve
    pause 1
    scene s194b with dissolve
    pause 1
    scene s184 with dissolve
    sa "You can do it!"
    scene s185 with dissolve
    sa "Kick, baby, kick!"
    vi "That's it, you're doing great!"
    p "Don't let go, I don't feel your hands!"
    sa "I'm right here."
    scene s186 with dissolve
    sa "You did it!"
    scene s187 with dissolve
    p "Thank you, S! You're the best! It's fun to swim, now I have to practice a lot, hehe..."
    sa "We'll do it together..."
    scene s188 with dissolve
    vi "Good job, [p]!"
    p "Thank you, Vittoria!"
    jump choice55_common

label choice55_common:

    stop music fadeout 3.0
    scene s194 with dissolve
    mrre "[p]! Come help me bring more alcohol, I need to buy my whiskey."
    cs "And beer!"
    pt "Fuck! I could stay here all day long..."
    p "Okay, sir, I'm coming."
    scene black with Dissolve(2.0)
    scene s195 with dissolve
    mrre "So tell me, how're things with my daughter?"
    p "It's been great! She's a beautiful person, I love her..."
    mrre "I'm glad to hear it, she looks very happy lately, I don't remember her being that happy since she was a child..."
    scene s196 with dissolve
    mrre "And have you changed your mind about selling your car?"
    p "Not really, no, I still don't want to sell it, Mr. Revello, it means a lot to me..."
    mrre "Yeah, my Sammy told me the story, but I had to ask again...maybe one day..."
    p "Yeah, may be..."
    scene s197 with dissolve
    pause 0.5
    scene s198 with dissolve
    mrre "My God..."
    scene s199 with dissolve
    mrre "That's Josephine Garnier!"
    p "Who? The journalist?"

    play music "audio/jazz1.ogg"
    scene s200:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause
    pt "Wooow! Hot as fuck...and Camille?! Damn! I knew she was hiding a nice body..."
    scene s201 with dissolve
    mrre "The brunette's looking at you!"
    p "I know her."
    mrre "You what?!"
    scene s202 with dissolve
    ca "Hi, [p]! I wasn't expecting to see you here!"
    p "Hi, Camille! I was gonna say the same to you, hehe."
    pt "Man, that blond's very sexy..."
    mrre "Ahem, ahem..."
    scene s203 with dissolve
    ca "Oh, [p], this is my sister Jo...Josephine."
    p "A pleasure to meet you, Josephine."
    scene s204 with dissolve
    jos "Hi, pleasure's mine."
    jos "So, you're [p], I've heard some things about you...You can call me Jo, if you're a friend of my sister that speaks for itself: she doesn't trust many people..."
    scene s205 with dissolve
    pt "Looks like Camille didn't want me to know that, perhaps her sister's oversharing, gotta change the subject..."
    mrre "Ahem, ahem..."
    pt "That's right!"
    scene s206 with dissolve
    p "Oh, I'm sorry to interrump, Jo. This is my..."
    scene s207 with dissolve
    mrre "Uncle! Giuseppe is the name."
    p "{size=-6}Whaaaaaat...{/size}"
    ca "Hello."
    mrre "Big fan of your work, Jo!"
    jo "Josephine is the name."
    scene s208 with dissolve
    jo "Cam, my drink's getting warm, better get going."
    ca "Yeah, you're right."
    scene s209 with dissolve
    ca "Talk to you soon, [p]!"
    p "Ok, bye Camille!"
    jo "Bye!"
    stop music fadeout 3.0
    scene s210 with dissolve
    mrre "Sssssssss, look at that tasty ass!"
    p "{size=-6}Whaaaaaat...{/size}"
    pt "What's wrong with this dude? Is he testing me? Well, he told me to do it, I can play dumb..."
    scene s211 with dissolve
    mrre "Imagine pounding that ass..."
    pt "The fuck?!"
    scene s212 with dissolve
    pt "It's a sweet ass indeed, your wife's bigger though..."
    p "I don't know what I shoud say, sir...you're my girlfriend's dad."
    scene s213 with dissolve
    mrre "Hahaha, relax! I'm not a snitch! Are you?"
    p "I'm not either, but that's not the point, you're saying these things as if we were best friends or something..."
    mrre "So you WOULD talk about these things with your buddies."
    p "Probably, but with you it's just...I find it weird...and why you said you were my uncle?"
    scene s214 with dissolve
    mrre "Haha, did you a favor right there, thank me later."
    p "What do you mean a favor?"
    mrre "I kept that door open for you, you were about to say I was your girl's father, weren't you? Rule N° 1: Do not say things you haven't been asked."
    p "What are you saying?"
    scene s215 with dissolve
    mrre "Come on, let's have a few drinks."
    scene s216 with dissolve
    mrre "Hey, cutie, a couple of whiskeys please!"
    scene s217 with dissolve
    mrre "Whose drink is this?"
    ba "Ugh, that blondie you two were talking to. She didn't like it, give me a sec I'll get rid of it..."
    mrre "No need, beautiful."
    scene s218 with dissolve
    pt "The fuck?! What's happening to this dude? Is he gonna lick that? Has he really become a sick fuck all of a sudden?"
    scene s219 with dissolve
    ba "Two whiskeys!"
    pt "She's a better view."
    p "Thank you!"
    scene s220 with dissolve
    ba "No prob, question: are you Eurasian?"
    p "What's that? The region between Europe and Asia? I'm not, my dad was from Spain though."
    ba "And your mom?"
    p "From here, my grandma is Asian. Why you ask?"
    scene s221 with dissolve
    ba "Just wanted to make small talk...you look like Jin Kook!"
    p "Who's that?"
    ba "My favorite Korean singer!"
    p "Oh, I get it, this K-pop culture, right? You look like an idol yourself!"
    scene s222 with dissolve
    ba "Ha! Suuuuure, an idol's making your drink..."
    p "Oh! I didn't mean it sarcastically, I meant it as a compliment because you're pretty. Did I offend you?"
    scene s223 with dissolve
    ba "Not at all! Irony is my kind of humor, that's all. Let me know if you need anything else, ok?"
    p "We will."
    scene black with dissolve
    play music "audio/gangstarap.ogg"
    scene s224 with dissolve
    mrre "I see, you're a natural..."
    p "Come again?"
    mrre "Did you see her tits?"
    p "Again, why are you saying those things to ME?"
    scene s225 with dissolve
    mrre "Kid, every man has a weakness: call it drugs, money, thirst for power...you're no junkie, you don't seem like a guy who would do anything for power either..."
    mrre "And you didn't even ask how much I would pay for your car...I'm pretty sure your weakness is the same as mine: women. Cheers!"
    scene s226 with dissolve
    p "..."
    scene s227 with dissolve
    mrre "Let me ask you something: who do you think the hottest woman in the world is? Do not say my daughter for god's sake."
    p "Uhmmm..."
    p "Madi...Madi Dorn."
    scene s228 with dissolve
    mrre "Now we're talking! Wasn't that difficult, was it? And yeah, you're right, that supermodel's really sexy...anyway, now answer this: if she was naked right in front of you, begging you to fuck her, would you say no?"
    p "Oh! I get it, you want to know if I'd cheat on your daughter, if I'm good enough for her...that's why you've been saying all those things, you wanted to get something out of me..."
    p "Sir, I'm in love with your daughter, I'd love to be with Samantha forever..."
    scene s227 with dissolve
    mrre "Forever...kid, nothing lasts forever: love, happiness, pain, troubles, life itself! Everything is..."

    scene black with Dissolve(3.0)
    $ renpy.movie_cutscene("videos/Temporary.ogv")
    scene black with Dissolve(2.0)

    scene s229 with dissolve
    mrre "Don't get attached to anything, to anyone, you'll save yourself some disappointment."
    mrre "Do whatever the fuck you want! All the time!"
    mrre "You care about love? Fuck love! Love's so fucking overrated! You'll learn that in time."
    mrre "And talking about relationships, real men are not made to have only one woman, monogamy is unnatural. Real men, like us, have one queen and many bitches: we make love only to one woman, we fuck the others, am I right?"
    pt "What does he want me to say? He can't be serious..."
    p "Haha, get real sir, stop playing with me."
    scene s230 with dissolve
    mrre "I'm dead serious."
    p "Yeah, you are, let's say I believe you...why would you tell me all this? What do you want from me?"
    scene s226 with dissolve
    pause 0.5
    scene s224 with dissolve
    mrre "The thing is I need your help: I've always wanted to fuck that bitch Josephine Garnier, to me no woman compares to her, she's my Madi Dorn. I thought she was a gold digger, but she barely looked at my jewelry...it's gonna be harder than I thought."
    scene s228 with dissolve
    mrre "And that's where you enter the equation: her sister is a friend of yours! Even more, she was practically begging you to fuck her! Don't look at me like that, kid, everybody cheats...just be smart and don't get caught."
    pt "What?! He wants me to cheat on his own daughter? This's surreal...wait...has this dude been cheating on his wife? Why? I wouldn't even think of it with an ass like that available all day..."
    p "Are you drunk? You're not making any sense. I think it's time to buy the drinks and go back."
    scene s229 with dissolve
    mrre "You're not listening...I would do anything to fuck that reporter..."
    scene s230a with dissolve
    mrre "Anything."
    p "..."
    scene s231 with dissolve
    mrre "I've seen the way you look at my wife."
    scene s231 with hpunch
    pt "What the?!!...Oh, so you waited this long to play that card...I wasn't expecting that..."
    scene s232 with dissolve
    mrre "Aaahhh, looks like I got your attention...perhaps we could make a deal, you know, negotiate."
    p "Negotiate?"
    mrre "Yeah, I'm sure we can understand each other, after all you and I are just the same deep inside."
    pt "You and me the same? You're a bastard who's been cheating on his wife, lying to his family..."
    pt "Oh I get it now, you wanted me to fuck Camille to have some dirt on me, to \"negotiate\" you call it, to blackmail me...no, how would he know if I did it?"
    pt "And he's putting his wife on the table? Yeah, right, like you could, she's gonna have sex with me just because you say so..."
    pt "Am I considering it? Nah, I'd never hurt S, that shit would be crazy, having sex with her mom...Fuck, I need to talk to someone, this old perv just unlocked a new low in my brain..."
    pt "Only one thing is certain: I can't take his word for it, need to be a hundred percent sure..."
    stop music fadeout 3.0
    scene s233 with dissolve
    p "Hey listen..."
    aal "I knew it was you!"
    scene s234 with dissolve
    aal "[p]!!!"
    cj "Hey, nigga, whaddup?!"
    play music "audio/reggaerap.ogg"
    p "No fucking way! I almost didn't recognize you! You two look completely different!"
    aal "You haven't changed one bit!"
    scene s235 with dissolve
    aal "Where have you been?! I sent you like a thousand messages and you never replied! I love you and I hate you, [p]!"
    cj "Aww, bitch needs some luuuuuvvv."
    p "The fuck, people, that's too much...and you don't touch me CJ, that's fucking gay!"
    cj "Racist homophobic motherfucker!"
    p "Shut up, son."
    scene s236 with dissolve
    cj "Yo, homie, for reals, you never picked up the phone, we went to your house and all that shit, your mom told us you were out in college...studying??!!!"
    cj "Nigga, what the fuck?! You hated that shit! And your leg looks fine to me! You ain't no cripple...why the fuck you're not back to training with the team?"
    pt "Mom never told me about their visit..."
    p "My bad, yeah, I changed my number long ago and lately I've been pretty busy at college."
    pt "Wait a minute, I think that's Metal's mom..."
    scene s237 with dissolve
    aal "That's all you're gonna say?! We've been so worried about you, asshole! And not even a call! In a year! A year!"
    p "Haha, guys, chill out, we have plenty of time to ca..."
    pt "Hold on, that's no Mr. Lopez! Is that...my Philosophy teacher?! Looks like him, haven't paid much attention to his face actually, I may be wrong, but that's definitely not Juan!"
    scene s238 with dissolve
    p "Dude, quick, you have your cellphone with you?"
    cj "Yeeeah..."
    p "Do me a favor: see that couple right there..."
    scene s239 with dissolve
    p "Take a picture of them, I want to see their faces better...Do not be so obvious, man."
    scene s240 with dissolve
    cj "Y-niggas are back?!"
    p "What? Yeah, yeah homie, yellow-niggas whatever, just do it."
    scene s241 with dissolve
    cj "We're back in business, baby!"
    aal "Who are they?"
    scene s242 with dissolve
    p "Huh? Oh, I think she's my friend's mom, and that's not her husband..."
    scene s243 with dissolve
    p "Exactly."
    scene s244 with dissolve
    cj "Got it, homie!"
    p "Let me see."
    scene s245 with dissolve
    cj "Here, take a look."
    scene s246 with dissolve
    pt "No way! I can't believe it! Mrs. Lopez is the sweetest woman in the world and she is...fuck! And yeah, she's with that fool."
    aal "So?"
    p "Yeah, it is her."
    cj "Who?"
    aal "His friend's mother and not her husband."
    cj "Damn! She cheating? Watcha gonna do with it?"
    p "Don't know yet, just send it to me, bruh."
    scene s247 with dissolve
    ub "[p]! Pick up those two bottles, we're leaving."
    pt "Hehe, she's cute."
    scene s248 with dissolve
    p "Guys, I gotta go, but we need to get together soon, ok?"
    cj "Whaaaat?! Who that? Your sugar?"
    p "Shut up."
    scene s249 with dissolve
    cj "Yo, before you go, we're throwing a party tonight! I'll send you location, it'll be lit! Everybody's coming!"
    aal "Nobody is, he's invited people we don't know, even a couple of sisters who were..."
    p "COUGH, COUGH, COUGH!!!"
    scene s250 with dissolve
    aal "What happened?!"
    p "I choked on my saliva...cough, cough..."
    pt "Hope that bastard didn't hear what she just said..."
    scene s251 with dissolve
    cj "You good?"
    p "Yeah, yeah, all good now...gotta go guys, see you later!"
    scene s252 with dissolve
    p "Thank you, girl! Bye!"
    ba "Bye!"
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s253 with dissolve
    ub "Seriously, what are you going to do with that picture?"
    p "What? What picture?"
    ub "Come on kid, you were talking next to me."
    p "Why you care? I'm not gonna tell you."
    scene s254 with dissolve
    ub "Hahaha, I knew you were just like me: you're going to blackmail that fat ass bitch, aren't you? You wanna fuck her!"
    p "What?! What are you talking about? That didn't even cross my mind."
    scene s255 with dissolve
    ub "So, what will you do with it?"
    p "I'm not talking to you about it."
    scene black with Dissolve(2.0)
    play music "audio/upbeat.ogg"
    scene s256 with dissolve
    vi "Heeeeeyyy, what took you so long?! Where's that booze?!"
    sa "Yes, dad! We want more!"
    cs "I want beer."
    pt "Are they drunk already?"
    scene s257 with dissolve
    sa "You must be hungry, have something to eat, baby, we've just eaten."
    p "Thanks, babe."
    pt "S is so kind..."
    pt "Man, Christina's look's scary."
    scene s258 with dissolve
    vi "Here, this's for you."
    p "Thank you, Vittoria! It looks delicious!"
    vi "It is!"
    pt "Your daughter definitely takes after you...he doesn't deserve you two."
    scene s259 with dissolve
    sa "What's on your mind, babe?"
    pt "What isn't..."
    p "Oh, nothing...I just saw a friend of mine where we bought the drinks and..."
    pt "He's gonna listen..."
    p "Can we sit over there while I eat? Come with us, Chistina."
    scene s260 with dissolve
    p "As I was saying, I saw my friend and he invited us to a party later. What do you think, cat? And you Christina, do you girls want to go?"
    sa "Sounds good, babe. I'd like to meet some friends of yours!"
    cs "I'm not sure I'd be comfortable around people I don't know..."
    p "I don't know all of them either, only my friend and his sister...he was inviting everybody at the beach, hehe."
    scene s261 with dissolve
    cs "That's lame, nobody will know each other there...a waste of my time, I'm in the mood to talk, not to meet."
    p "People talk when they meet."
    sa "She means she wants to talk about something serious, not introduce herself like a hundred times, it's an ordeal to her...she's going through a phase..."
    scene s262 with dissolve
    p "Hold it right there, babe, she told you not to tell me her things earlier."
    scene s263 with dissolve
    cs "Thank you! I didn't think you'd actually listen! S is right as always: it's like I overdosed after meeting you, one person a day is enough."
    p "Haha."
    scene s264 with dissolve
    sa "Finish up your meal, I want to show you something!"
    p "Okay."
    stop music fadeout 3.0
    scene black with Dissolve(2.5)
    play sound "audio/beachsound.mp3"


label samsex2:

    if _in_replay:
        $ pf = persistent.p

    scene s265 with dissolve
    p "Where are you taking me? Is this another of your secrets spots, babe?"
    sa "Hehe, I just wanted to be alone with you..."
    scene s266 with dissolve
    sa "Do you like it here?"
    p "I sure do...what do you have in mind?"
    play music "audio/sensual3.ogg"
    scene s267 with dissolve
    sa "What do you think?"
    scene s268 with dissolve
    p "Ooofff, give me that!"
    scene s269 with dissolve
    sa "You want it?"
    p "Yes, please!"
    sa "It's yours, take it!"
    scene s270 with dissolve
    p "I love that fit ass, baby!"
    sa "I know you do."
    scene s271 with dissolve
    sa "Ah! Hahaha, baby, you're crazy!"
    scene s272 with dissolve
    sa "It's so hard!"
    p "For you, baby..."
    scene s306 with hpunch
    sa "Ooohhh!"
    scene s273 with dissolve
    sa "Aaahh, I love your cock!"
    scene s306 with hpunch
    sa "Ooohhh!"
    scene s274 with dissolve
    pause
    scene s306 with dissolve
    pause
    scene s274 with dissolve

    scene s276:
        pause 0.0166
        "s277"
        pause 0.0166
        "s278"
        pause 0.0166
        "s279"
        pause 0.0166
        "s280"
        pause 0.0166
        "s281"
        pause 0.0166
        "s282"
        pause 0.0166
        "s283"
        pause 0.0166
        "s284"
        pause 0.0166
        "s285"
        pause 0.0166
        "s286"
        pause 0.0166
        "s287"
        pause 0.0166
        "s288"
        pause 0.0166
        "s289"
        pause 0.0166
        "s290"
        pause 0.0166
        "s291"
        pause 0.0166
        "s292"
        pause 0.0166
        "s293"
        pause 0.0166
        "s294"
        pause 0.0166
        "s295"
        pause 0.0166
        "s296"
        pause 0.0166
        "s297"
        pause 0.0166
        "s298"
        pause 0.0166
        "s299"
        pause 0.0166
        "s300"
        pause 0.0166
        "s301"
        pause 0.0166
        "s302"
        pause 0.0166
        "s303"
        pause 0.0166
        "s304"
        pause 0.0166
        "s305"
        pause 0.0166
        "s306"
        pause 0.0166
        "s306"
        pause 0.0333
        "s305"
        pause 0.0333
        "s304"
        pause 0.0333
        "s303"
        pause 0.0333
        "s302"
        pause 0.0333
        "s301"
        pause 0.0333
        "s300"
        pause 0.0333
        "s299"
        pause 0.0333
        "s298"
        pause 0.0333
        "s297"
        pause 0.0333
        "s296"
        pause 0.0333
        "s295"
        pause 0.0333
        "s294"
        pause 0.0333
        "s293"
        pause 0.0333
        "s292"
        pause 0.0333
        "s291"
        pause 0.0333
        "s290"
        pause 0.0333
        "s289"
        pause 0.0333
        "s288"
        pause 0.0333
        "s287"
        pause 0.0333
        "s286"
        pause 0.0333
        "s285"
        pause 0.0333
        "s284"
        pause 0.0333
        "s283"
        pause 0.0333
        "s282"
        pause 0.0333
        "s281"
        pause 0.0333
        "s280"
        pause 0.0333
        "s279"
        pause 0.0333
        "s278"
        pause 0.0333
        "s277"
        pause 0.0333
        "s276"
        pause 0.0333
        repeat
    pause

    scene s276:
        pause 0.0166
        "s277"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "s278"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "s279"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "s280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "s281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "s282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "s283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "s284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "s285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "s286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0166
        "s287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "s288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "s289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "s290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "s291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "s292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "s293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "s294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "s295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "s296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "s306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0333
        "s295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0333
        "s294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0333
        "s293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0333
        "s292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0333
        "s291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0333
        "s290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0333
        "s289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0333
        "s288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0333
        "s287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0333
        "s286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0333
        "s285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0333
        "s284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0333
        "s283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0333
        "s282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0333
        "s281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0333
        "s280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0333
        "s279"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0333
        "s278"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0333
        "s277"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0333
        "s276"
        pause 0.0333
        repeat
    pause

    scene s276:
        pause 0.0074
        "s277"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0074
        "s278"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0074
        "s279"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0074
        "s280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0074
        "s281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0074
        "s282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0074
        "s283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0074
        "s284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0074
        "s285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0074
        "s286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0074
        "s287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0074
        "s288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0074
        "s289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0074
        "s290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0074
        "s291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0074
        "s292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0074
        "s293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0074
        "s294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0074
        "s295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0074
        "s296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0074
        "s306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0222
        "s294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0222
        "s293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0222
        "s292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0222
        "s291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0222
        "s290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "s289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "s288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "s287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "s286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0222
        "s285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "s284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "s283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "s282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "s281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "s280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "s279"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "s278"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "s277"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "s276"
        pause 0.0222
        repeat
    sa "Oooh!"
    pause

    stop music fadeout 3.0
    scene s275 with dissolve
    p "Turn around, babe...I want to see you."
    scene s309 with dissolve
    sa "You make me so horny..."
    p "Hey! Where's my bush?!"
    scene s310 with dissolve
    sa "Haha, I was going to wear a bikini, had to trim it."
    p "Trim it? It's gone! I want my bush!"
    sa "Haha, it grows, baby."
    p "Noooooo, c'mere immediately!"
    scene s311 with dissolve
    sa "Catch me if you can!"
    scene s312 with dissolve
    sa "Come and get me, cat!"
    p "Yeah, you'd better run!"
    scene s307 with dissolve
    p "Gotcha! You're gonna pay for shaving it!"
    sa "Ooohhh, baby!"
    scene s313 with dissolve
    p "You've been a naughty girl!"
    sa "Ooofff!"
    scene black with dissolve
    play music "audio/theheat.ogg"
    scene s315 with dissolve
    sa "Give it to me, baby..."
    scene s314 with dissolve
    sa "Yeah, you feel me? I'm so wet..."
    scene s316 with dissolve
    p "Feels so good, babe..."
    scene s346 with hpunch
    sa "Aaahhh!"
    p "You're mine!"
    scene s316 with dissolve
    pause
    scene s346 with hpunch
    p "Mine! You hear me?"
    sa "Yes, baby, yours!"
    scene s316b with dissolve

    scene s316b:
        pause 0.0222
        "s317b"
        pause 0.0222
        "s318b"
        pause 0.0222
        "s319b"
        pause 0.0222
        "s320b"
        pause 0.0222
        "s321b"
        pause 0.0222
        "s322b"
        pause 0.0222
        "s323b"
        pause 0.0222
        "s324b"
        pause 0.0222
        "s325b"
        pause 0.0222
        "s326b"
        pause 0.0222
        "s327b"
        pause 0.0222
        "s328b"
        pause 0.0222
        "s329b"
        pause 0.0222
        "s330b"
        pause 0.0222
        "s331b"
        pause 0.0222
        "s332b"
        pause 0.0222
        "s333b"
        pause 0.0222
        "s334b"
        pause 0.0222
        "s335b"
        pause 0.0222
        "s336b"
        pause 0.0222
        "s337b"
        pause 0.0222
        "s338b"
        pause 0.0222
        "s339b"
        pause 0.0222
        "s340b"
        pause 0.0222
        "s341b"
        pause 0.0222
        "s342b"
        pause 0.0222
        "s343b"
        pause 0.0222
        "s344b"
        pause 0.0222
        "s345b"
        pause 0.0222
        "s346b"
        pause 0.0222
        "s346b"
        pause 0.0222
        "s345b"
        pause 0.0222
        "s344b"
        pause 0.0222
        "s343b"
        pause 0.0222
        "s342b"
        pause 0.0222
        "s341b"
        pause 0.0222
        "s340b"
        pause 0.0222
        "s339b"
        pause 0.0222
        "s338b"
        pause 0.0222
        "s337b"
        pause 0.0222
        "s336b"
        pause 0.0222
        "s335b"
        pause 0.0222
        "s334b"
        pause 0.0222
        "s333b"
        pause 0.0222
        "s332b"
        pause 0.0222
        "s331b"
        pause 0.0222
        "s330b"
        pause 0.0222
        "s329b"
        pause 0.0222
        "s328b"
        pause 0.0222
        "s327b"
        pause 0.0222
        "s326b"
        pause 0.0222
        "s325b"
        pause 0.0222
        "s324b"
        pause 0.0222
        "s323b"
        pause 0.0222
        "s322b"
        pause 0.0222
        "s321b"
        pause 0.0222
        "s320b"
        pause 0.0222
        "s319b"
        pause 0.0222
        "s318b"
        pause 0.0222
        "s317b"
        pause 0.0222
        "s316b"
        pause 0.0222
        repeat
    sa "Like that...feels so good baby, slowly...you're gonna make me cum so hard!"
    pause
    p "Yeah, baby? You like this pace?"
    sa "Yes, be gentle..."

    scene s316b:
        pause 0.0166
        "s317b"
        pause 0.0166
        "s318b"
        pause 0.0166
        "s319b"
        pause 0.0166
        "s320b"
        pause 0.0166
        "s321b"
        pause 0.0166
        "s322b"
        pause 0.0166
        "s323b"
        pause 0.0166
        "s324b"
        pause 0.0166
        "s325b"
        pause 0.0166
        "s326b"
        pause 0.0166
        "s327b"
        pause 0.0166
        "s328b"
        pause 0.0166
        "s329b"
        pause 0.0166
        "s330b"
        pause 0.0166
        "s331b"
        pause 0.0166
        "s332b"
        pause 0.0166
        "s333b"
        pause 0.0166
        "s334b"
        pause 0.0166
        "s335b"
        pause 0.0166
        "s336b"
        pause 0.0166
        "s337b"
        pause 0.0166
        "s338b"
        pause 0.0166
        "s339b"
        pause 0.0166
        "s340b"
        pause 0.0166
        "s341b"
        pause 0.0166
        "s342b"
        pause 0.0166
        "s343b"
        pause 0.0166
        "s344b"
        pause 0.0166
        "s345b"
        pause 0.0166
        "s346b"
        pause 0.0166
        "s346b"
        pause 0.0166
        "s345b"
        pause 0.0166
        "s344b"
        pause 0.0166
        "s343b"
        pause 0.0166
        "s342b"
        pause 0.0166
        "s341b"
        pause 0.0166
        "s340b"
        pause 0.0166
        "s339b"
        pause 0.0166
        "s338b"
        pause 0.0166
        "s337b"
        pause 0.0166
        "s336b"
        pause 0.0166
        "s335b"
        pause 0.0166
        "s334b"
        pause 0.0166
        "s333b"
        pause 0.0166
        "s332b"
        pause 0.0166
        "s331b"
        pause 0.0166
        "s330b"
        pause 0.0166
        "s329b"
        pause 0.0166
        "s328b"
        pause 0.0166
        "s327b"
        pause 0.0166
        "s326b"
        pause 0.0166
        "s325b"
        pause 0.0166
        "s324b"
        pause 0.0166
        "s323b"
        pause 0.0166
        "s322b"
        pause 0.0166
        "s321b"
        pause 0.0166
        "s320b"
        pause 0.0166
        "s319b"
        pause 0.0166
        "s318b"
        pause 0.0166
        "s317b"
        pause 0.0166
        "s316b"
        pause 0.0166
        repeat
    pause

    scene s316b:
        pause 0.009
        "s317b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.009
        "s318b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.009
        "s319b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.009
        "s320b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.009
        "s321b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.009
        "s322b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.009
        "s323b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.009
        "s324b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.009
        "s325b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.009
        "s326b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.009
        "s327b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.009
        "s328b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.009
        "s329b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.009
        "s330b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.009
        "s331b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.009
        "s332b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.009
        "s333b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.009
        "s334b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.009
        "s335b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.009
        "s336b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s337b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s338b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s339b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s340b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s341b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s342b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s343b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s344b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s345b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s346b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.009
        "s346b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "s345b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s344b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s343b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s342b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s341b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s340b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s339b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s338b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s337b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s336b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "s335b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "s334b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "s333b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "s332b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "s331b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "s330b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "s329b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "s328b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "s327b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "s326b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "s325b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "s324b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "s323b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "s322b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "s321b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "s320b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "s319b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "s318b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "s317b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "s316b"
        pause 0.0133
        repeat
    sa "I want you to fill me up, baby!"
    p "Yeah, babe, I wanna cum inside!"
    pause

    stop music fadeout 3.0
    scene s347 with hpunch
    scene s347 with flash
    scene s347 with flash
    play sound "audio/maleorg3.ogg"
    p "Aaahhh!!"
    sa "Babyyyy!!! Behave! You're gonna get me pregnant!"
    p "Haha, you're on the pill, don't joke like that, cat...hehe."
    scene s348 with dissolve
    sa "More? It's a mess down there..."
    p "I want you to cum, babe!"
    sa "Again?"
    p "You didn't cum, I didn't feel you shaking..."
    sa "I did!"
    scene s349 with hpunch
    p "Liar! Take this!"
    sa "Ooohhh!"
    scene s350 with dissolve
    scene s352 with dissolve
    scene s351 with dissolve
    sa "I'm so close...cumming hard this time, baby!"
    p "Cum, babe, cum!"
    scene s350 with dissolve
    scene s352 with dissolve
    scene s351 with hpunch
    sa "Ooohhh!"
    scene s350 with dissolve
    scene s352 with dissolve
    scene s351 with hpunch
    p "Cum, babe, cum on my cock..."
    scene s350 with dissolve
    scene s352 with dissolve
    scene s351 with dissolve
    scene s353 with hpunch
    scene s353 with flash
    sa "Aaahhh!!!"
    p "Yes, baby..."
    scene s354 with hpunch
    scene s354 with hpunch
    scene s354 with hpunch
    sa "So gooooooddd!"
    p "There it is..."
    scene black with Dissolve(1.5)
    scene s355 with dissolve
    sa "That was amazing! Love you, [p]!"
    p "Love you, too!"
    scene s356 with dissolve
    sa "Cat, errrrrmmm, have you seen our clothes?"
    p "Huh?"
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    play music "audio/relajante.ogg"
    scene s357 with dissolve
    sa "Beautiful sunset, isn't it?"
    p "Yeah, S, ama..."
    scene s358 with dissolve
    p "Woooowww! You look stunning, babe!"
    scene s359 with dissolve
    sa "Hehe, thank you baby, ready to go?"
    p "I'm the one who was waiting, cat...let's go!"
    scene s360 with dissolve
    p "Oh, you look good too, Christina!"
    scene s361 with dissolve
    cs "Yeah, whatever, what's up with that shirt?"
    p "I had to borrow some clothes from Sam's dad, I didn't bring any."
    cs "Okaaayyy..."
    scene s359 with dissolve
    sa "It suits you, baby!"
    p "You think? Not really my style..."
    scene s362 with dissolve
    cs "Let's get going, you'll talk on the way to the party."
    sa "Yes, Drill Sergeant!"
    scene black with Dissolve(1.0)
    scene s363 with dissolve
    cs "There's nothing here..."
    sa "I can't see them from here, perhaps is in that yacht! What did he say?"
    p "This's the location he shared..."
    scene s364 with dissolve
    p "Wow, babe, I'm so jealous! You can have a view like this anytime you want!"
    sa "We can come whenever you want, cat!"
    cs "I'm here too, just in case..."
    scene s365 with dissolve
    p "Why you say so?"
    cs "In case you two start being cheesy."
    p "Hehe, we're not."
    scene s366 with dissolve
    sa "Look guys! Someone's coming!"
    scene s367 with dissolve
    cs "Who's that?"
    p "I think that's my boy Carl..."
    scene s368 with dissolve
    cj "[p]!"
    scene s369 with dissolve
    cj "Hello, hello everybody!"
    p "Girls, this is Carl..."
    scene s370 with dissolve
    p "This is my girlfriend Samantha..."
    cj "Hey, girl!"
    sa "Hi, Carl!"
    scene s371 with dissolve
    p "And Christina."
    cj "Hi, sexy!"
    pt "Aaand...you're fucked."
    scene s372 with dissolve
    pt "WE are..."
    scene s373 with dissolve
    cj "Bruh, you won't guess who showed up!"
    p "Who?"
    cj "You gotta see him! Move!"
    stop music fadeout 3.0
    scene black with dissolve
    scene s374 with dissolve
    sa "Where did you guys meet, Carl?"
    cj "Playing soccer, he didn't tell you that? My boy here had a magical left foot to assist...too bad he's a pu...anyway...what about you two? Where you met?"
    sa "College, we take one class together...You know [p]'s been training hard lately!"
    cj "I see he's in shape, I'll have a serious talk with my boy later..."
    scene s375 with dissolve
    p "Bro, you just went past the boat."
    cj "What boat?"
    p "The one behind...where are you taking us?"
    play music "audio/lonewolf.ogg"
    scene s376 with dissolve
    cj "There!"
    scene s377 with dissolve
    cs "What the hell is that?"
    cj "The coolest thing you've ever seen, baby!"
    cs "Ugh."
    p "Why does it say Bora Bora?"
    cj "Isn't it like a cool destination or some shit? Well, this is the coolest place to be! I just said so."
    sa "Hehe."
    scene s378 with dissolve
    p "Can't believe some people actually showed up."
    pt "But no Jo nor Camille apparently..."
    cj "Haha, have a little faith in your homie!"
    p "Who's Aaliyah talking to? He looks familiar..."
    cj "You'll see."
    scene s379 with dissolve
    aal "Welcome everybody! Hey, [p], look who's here!"
    scene s380 with dissolve
    p "No{w=1.0} fucking{w=1.0} way!!{w=1.0} Rob Davies?!"
    aal "The one and only!"
    mh "Hello, everybody!"
    scene s381 with dissolve
    p "It's an honor, sir, my name's [p]...again, a great pleasure to meet you, you're a fantastic player!"
    mh "Haha, I do what I can. Call me Rob."
    sa "Hi!"
    aal "Grab a beer, girls!"
    scene s382 with dissolve
    cj "Let's go dance uptairs, people!"
    aal "Yeah, take them, Carl, I need to tell Rob something, we'll be with you in a minute..."
    stop music fadeout 3.0
    scene s383 with dissolve
    pause
    scene black with dissolve
    scene s384 with dissolve
    pause 2
    scene s385 with dissolve
    pause
    scene s386 with dissolve
    play music "audio/upbeatcooking.ogg"
    ba "Heeeeey!"
    p "Heeeey youuuu! What's your name again?"
    ba "Yua! Truth or dare? Quick!"

menu:
    "Truth?":
        jump choice56a

    "Dare.":
        jump choice56b

label choice56a:
    scene s387 with dissolve
    yu "What are you, a little bitch?"
    p "Haha, ok, ok, dare!"
    jump choice56b

label choice56b:
    scene s388 with dissolve
    yu "Kiss Cara!"
    p "What?"
    yu "You heard me: kiss Cara!"
    scene s389 with dissolve
    pt "What's she doing?"

menu:
    "Do it.":
        jump choice57a

    "No, thank you.":
        jump choice57b

label choice57a:
    scene s390 with dissolve
    p "Fine, I'll do it."

    jump choice57common

label choice57b:
    pt "That's a hard pass...more like an easy one."
    scene s390 with dissolve
    p "Yeah, I don't think I can do it, my girl's right behind you..."
    scene s391 with dissolve
    yu "Boooooo, you're a buzzkill!"
    p "Hehe, practicing your idol poses?"
    scene s392 with dissolve
    yu "Haha, you know it! I have to look kawaii all the time, [p]!"
    p "How do you know my name?"
    yu "That was the first thing your girlfriend said...Come on, kiss Cara!"
    p "You know what? Fuck it!"

    jump choice57common

label choice57common:

    scene s393 with dissolve
    yu "Oh, my God! Oh, my God! You're gonna do it! Sugoi!"
    scene s394 with dissolve
    sa "Hey baby!"
    pt "Oh, God, what's wrong with this girl?"
    p "Cara?"
    scene s395 with dissolve
    cr "Huh?"
    p "You just need to twist...nevermind."
    pt "Here goes nothing."
    scene s396 with dissolve
    cj "Daaaaamn!"
    cs "Hahaha."
    scene s397 with dissolve
    sa "What are you doing?"
    p "It was just an innocent kiss on the cheek, babe, don't get mad. Get mad at Yua, she dared me to do it."
    scene s398 with dissolve
    yu "You call that a kiss? That was no kiss, it doesn't count!"
    p "Sure it does! You didn't say how or where! Now it's your turn: truth or dare?"
    yu "Well, I'm not a bitch so...dare!"
    scene s399 with dissolve
    p "Haha, I like this girl, you could be a friend of mine...babe, what should we tell her to do?"
    scene s400 with dissolve
    sa "That's easy..."
    scene s401 with dissolve
    sa "{size=-7}French kiss Carl.{/size}"
    p "Haha, hell yeah!"
    scene s402 with dissolve
    p "I dare you to French kiss CJ!"
    scene s403 with dissolve
    yu "What?! No way! Errr..."
    scene s404 with dissolve
    yu "No offense, but I'm not into...chocolate."
    scene s404a with dissolve
    cj "You're not my type either, fucking chink!"
    stop music
    play sound "audio/scratch.ogg"
    scene s405 with dissolve
    yu "Oh my God!"
    cr "WHAAAT??!!"
    p "Whoa, whoa, whoa, what the fuck, dude?!"
    sa "Not cool, Carl, you'd better apologize to Yua right now!"
    scene s407 with dissolve
    cj "Me?! This bitch..."
    play sound "audio/augh.ogg"
    scene s408 with vpunch
    scene s408 with vpunch
    scene s408 with vpunch
    pause
    p "Holy shit!"
    sa "You totally had it coming!"
    cs "Epic."
    scene s409 with dissolve
    cr "Let's go, Yua! I want nothing to do with these people!"
    sa "Hold on, we're leaving too! We're not racist like him!"
    pt "Ha! Racist..."
    scene s410 with dissolve
    pause
    scene s410a with dissolve
    p "Why you chuckle?"
    scene s411 with dissolve
    cs "It's nothing."
    p "It's what S said, isn't it? A black...racist?"
    scene s412 with dissolve
    p "Right? We're going to hell..."
    scene s413 with dissolve
    cj "Yo, your girl's so not racist she thinks anybody can be one...that's cool. We have the right to be racist too!"
    p "I know you're not, but why the hell you said that thing to her?! She was being so nice to me! I've called you a million times worse..."
    scene s414 with dissolve
    cs "You're his friend, you're allowed to call him certain ways others can't..."
    scene s415 with dissolve
    cs "Was it the word \"chocolate\"? You have a trauma with it? I'm playing devil's advocate here and to be fair, she did say it first..."
    scene s416 with dissolve
    p "Come on! There's no comparison between the word \"chocolate\" and \"fucking chink\", even the way she said it was not offensive."
    scene s413 with dissolve
    cj "I know, it's just that I hate being rejected...damn, this shit hurts!"
    cs "Everybody hates it, but not everyone reacts like you did...you got issues. Well, I guess we're leaving."
    scene s417 with dissolve
    cs "Thanks for the beer."
    p "Wait! Let Cara and Yua go first, tell S that!"
    scene s418 with dissolve
    cs "How come?"
    scene s419 with dissolve
    cs "Ooohhhh! Because Cara is..."
    scene s420 with dissolve
    cs "You're definitely going to hell!"
    p "Not alone!"
    scene s421 with dissolve
    cj "Bruh, call 911, I'm dying..."
    p "Don't be so dramatic, man, it'll fade away just give it some minutes..."
    p "I gotta go see my girl, hang in there bro."
    scene black with dissolve
    play music "audio/happyface.ogg"
    scene s422 with dissolve
    rd "Hey, buddy, how's Johnson doing?"
    p "He'll be alright, don't worry man."
    rd "You sure? I'll go check on him anyway."
    p "Alright."
    scene s423 with dissolve
    sa "Baby, you're here, listen, if you want to stay to help him, it's ok, I know he's your friend...it's just I don't want to hang out with people like him."
    p "He's not a bad person, really, but he made a huge mistake, I'm with you on that one."
    sa "People capable of saying those horrible things to hurt others don't add anything to my life."
    pt "She's serious about this..."
    scene s424 with dissolve
    cs "His sister is coming back."
    scene s423 with dissolve
    sa "Are you leaving with us?"
    stop music fadeout 3.0

menu:
    "Of course!":
        jump choice58a

    "Stay.":
        jump choice58b

label choice58a:

    $ choice58a = True

    scene s425 with dissolve
    p "Sure. Let's go babe!"
    scene black with Dissolve(2.0)
    scene s750 with dissolve
    sa "Yua! Cara! Wait for us!"
    play sound "audio/iphone.ogg"
    scene s751a with dissolve
    pt "Camille!"
    stop sound
    scene s751b with dissolve
    p "Hi, Camille! What's up?"
    ca "Hi, [p]! Are you still near the beach?"
    p "I am, I am..."
    ca "Errr, we're having a few drinks with my sister...would you like to come to our place?"
    scene s751c with dissolve
    p "I can't right now, Camille, I'm sorry, I'm a little busy...maybe next time!"
    ca "Oh, ok...talk to you soon."
    p "Bye!"
    scene s751d with dissolve
    cs "What was that? A booty call?"
    p "What?! What are you talking about? It was my friend, she wanted to hang out..."
    cs "I heard \"drinks\"..."
    p "Yeah, and you wanted to go for sure...you should mind your own business girl...Did it sound like a booty call to you? Jeezz..."
    scene s751e with dissolve
    cs "Nope...I'm watching you anyways..."
    p "Not even S acts like that!"
    scene black with dissolve
    play music "audio/loft.ogg"
    scene s751 with dissolve
    cr "What do you guys want?"
    sa "Don't be like that, it wasn't any of us who said it, but again we're sorry, that guy doesn't speak for any of us...and I was thinking maybe we could hang out together..."
    p "Yeah, we can go to a bar or something...where are you girls heading?"
    scene s752 with dissolve
    yu "I have to go take a shower and get ready to work..."
    p "Work?"
    yu "Yeah, I have a second job in Cara's bar near here."
    scene s753 with dissolve
    p "You own a bar, Cara? Can we go?"
    cr "Are you over 21?"
    p "I'm not."
    scene s754 with dissolve
    cr "I can make an exception, just this once."
    sa "Sweet!"
    scene s755 with dissolve
    cr "I'll see you there, beautiful."
    yu "Boss, I'm going to be some minutes late!"
    cr "You're fired! Haha."
    yu "Haha."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    play music "audio/danceparty.ogg"
    scene s756 with dissolve
    scene s756:
        pause 0.3
        "s756a"
        pause 0.3
        "s756b"
        pause 0.3
        "s756c"
        pause 0.3
        "s756d"
        pause 0.3
        repeat
    ba "What's gonna be, sexy?"
    p "Sexy?! You think I'm sexy?"
    ba "Yep, baby darling."
    p "Baby darling?! Knock it off, man. You tripping..."
    ba "Haha, I like this one, Cara. Where'd you get him?"
    cr "Hahaha, stop playing him, Gigi. Give us some wine and vodka, please..."
    gi "I'm on it."
    scene s757 with dissolve
    scene s757:
        pause 0.3
        "s757a"
        pause 0.3
        "s757b"
        pause 0.3
        "s757c"
        pause 0.3
        "s757d"
        pause 0.3
        repeat
    pt "I can't hear what they're saying...they seem to get along pretty well though..."
    pt "Who wouldn't like S? She's great!"
    scene s758 with dissolve
    scene s758:
        pause 0.3
        "s758a"
        pause 0.3
        "s758b"
        pause 0.3
        "s758c"
        pause 0.3
        "s758d"
        pause 0.3
        repeat
    pt "I don't think Christina can hear them either, she's just in for the drinks, haha."
    scene s759 with dissolve
    scene s759:
        pause 0.3
        "s759a"
        pause 0.3
        "s759b"
        pause 0.3
        "s759c"
        pause 0.3
        "s759d"
        pause 0.3
        repeat
    pt "Hot woman...lately, I want to fuck everything that moves...maybe that old perv is right..."
    scene s760 with dissolve
    scene s760:
        pause 0.3
        "s760a"
        pause 0.3
        "s760b"
        pause 0.3
        "s760c"
        pause 0.3
        "s760d"
        pause 0.3
        repeat
    uk "Hi, Cara!"
    cr "Hi, Karen!"
    scene s761 with dissolve
    scene s761:
        pause 0.3
        "s761a"
        pause 0.3
        "s761b"
        pause 0.3
        "s761c"
        pause 0.3
        "s761d"
        pause 0.3
        repeat
    pt "Bye, Karen..."

    scene s763:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Here comes Yua..."

    scene s763a:
        ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
    pause
    pt "Wow! She's very pretty..."

    scene s763b:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Lord, lead me not into temptation..."

    scene s762 with dissolve
    scene s762:
        pause 0.3
        "s762a"
        pause 0.3
        "s762b"
        pause 0.3
        "s762c"
        pause 0.3
        "s762d"
        pause 0.3
        repeat
    yu "Hey, guys! Let me know if you need anything, ok?"
    p "Sure thing."

    scene black with dissolve
    scene s765 with dissolve
    scene s765:
        pause 0.3
        "s765a"
        pause 0.3
        "s765b"
        pause 0.3
        "s765c"
        pause 0.3
        "s765d"
        pause 0.3
        repeat
    sa "Baby..."
    p "Yes?"
    scene s766 with dissolve
    scene s766:
        pause 0.3
        "s766a"
        pause 0.3
        "s766b"
        pause 0.3
        "s766c"
        pause 0.3
        "s766d"
        pause 0.3
        repeat
    sa "Don't you think Chris is drunk already?"
    scene s767 with dissolve
    scene s767:
        pause 0.3
        "s767a"
        pause 0.3
        "s767b"
        pause 0.3
        "s767c"
        pause 0.3
        "s767d"
        pause 0.3
        repeat
    p "She's just having fun, isn't she?"
    scene s768 with dissolve
    scene s768:
        pause 0.3
        "s768a"
        pause 0.3
        "s768b"
        pause 0.3
        "s768c"
        pause 0.3
        "s768d"
        pause 0.3
        repeat
    p "Maybe too much..."
    sa "Better stop her before she starts doing something crazy...I'll go get her."
    p "Let me help you."
    scene s769 with dissolve
    scene s769:
        pause 0.3
        "s769a"
        pause 0.3
        "s769b"
        pause 0.3
        "s769c"
        pause 0.3
        "s769d"
        pause 0.3
        repeat
    cr "Why you guys stopped dancing? What happened?"
    p "Our friend seems to be a little drunk...she's been drinking since lunchtime."
    scene s770 with dissolve
    scene s770:
        pause 0.3
        "s770a"
        pause 0.3
        "s770b"
        pause 0.3
        "s770c"
        pause 0.3
        "s770d"
        pause 0.3
        repeat
    sa "We're leaving, Cara, thank you for everything...we'll be in touch."
    cs "Why are we leaving? I was having fun with my new friend, S..."
    cr "You're welcome to come anytime!"
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s771 with dissolve
    p "So, she goes crazy when she's drunk?"
    sa "You have no idea."
    p "You practically just saved her from herself then..."
    cs "Guys, I'm a little tipsy that's all, you worry too much."
    sa "We'll get home soon, Chris, so you can rest...I'm tired, it's been a long day..."
    p "Tell me about it..."
    scene s772 with dissolve
    pt "Yeah, too many things going on in my head...even though I met my childhood hero today, I can't stop thinking about Mrs. Lopez cheating on her husband...or what that bald bastard said to me..."
    pt "I have no energy to think about it tonight, just want this day to end..."
    scene black with Dissolve(3.0)

    jump choice58common

label choice58b:

    $ choice58b = True

    scene s426 with dissolve
    p "I want to talk to Rob, babe...won't take long."
    sa "Oh, ok. We'll be waiting for you at home, baby."
    scene black with dissolve
    play music "audio/openhighway.ogg" volume 0.7
    scene s427 with dissolve
    p "How you doing, CJ?"
    cj "My balls are in my throat, but I'll survive."
    p "Good...ok, I gotta ask, how do you know each other?!"
    scene s428 with dissolve
    cj "Rob can answer that..."
    rd "I've been training with these boys at City FC for the past two weeks, I'm a free agent now and it's time to come back home and put an end to my career at the club where it all started..."
    p "What?! Training with CJ? End of your career?!"
    cj "I'm being called to train with the first team more often bro, so I told him about the party, but didn't really expect he'd actually show up!"
    p "And I'm sorry to ask you this, Rob, but why are you coming back?! You're only 30! Last season you were outstanding in Europe!"
    scene s429 with dissolve
    rd "That's exactly why I want to come back, kid, I'm still useful, it's the right time to give something back...and they're offering me good terms in the contract, not gonna lie."
    p "I see...you have a successful carrer, you totally earned whatever they're paying you!"
    rd "Thanks, bro! You play football too?"
    p "I do, I do, not professionally..."
    scene s431 with dissolve
    cj "My boy used to play with us at the club, he was very good to tell the truth: could assist, had vision, even copied some of your moves Rob!"
    scene s430 with dissolve
    rd "Oh, so you're a Citizen too!"
    scene s432 with dissolve
    cj "He got some talent, but this nigga prefers to study! What the fuck?!"
    p "Dude, we've been through this already, I got injured...didn't quit because I wanted to."
    scene s433 with dissolve
    rd "Everybody gets injured, kid, that's no excuse! I've been through two knee surgeries and here I am! If it's still your dream you should go for it! Once a Citizen, always a Citizen!"
    scene s434 with dissolve
    rd "Tell you what: why don't you come over to train with the team next week? Not the pros, but the U21 team...Johnson here got me curious about your skills."
    rd "I'll talk to Robinson, he's a fan of mine, haha."
    cj "You can't say no to The Legend!"
    pt "CJ's right: my childhood hero wants to see me play! This day just keeps getting crazier! It's an opportunity I can't miss, but...am I ready? No seconds thoughts now!"
    p "I'll go!"
    stop music fadeout 3.0
    scene s430 with dissolve
    rd "Sweet! I'll talk to Robinson and confirm the day with Johnson."
    p "That sounds fantastic, thank you Rob."
    play sound "audio/iphone.ogg"
    scene s435 with dissolve
    pt "Camille?"
    stop sound
    scene s436 with dissolve
    p "Hi, Camille!"
    ca "Hi! Are you still near the beach?"
    p "I am, what's up?"
    ca "Not much, just having a few drinks with my sister, would you like to come to our place?"
    p "Sure! Just send me the address..."
    ca "Great! I'll be waiting for you!"
    scene s438 with dissolve
    rd "Glad you're back Aaliyah, could you take me to the shore?"
    p "Yeah, I'm leaving too."
    aal "I thought you were staying longer Rob..."
    rd "Sorry, I have to be somewhere else."
    cj "Why's everybody leaving? More people will show up."
    p "Keep dreaming, bro...besides, you already killed my party mood."
    scene black with Dissolve(2.0)
    play music "audio/sensual4.ogg"
    scene s440 with dissolve
    ca "Do you think he's coming?"
    jo "He just told you he is."
    scene s441 with dissolve
    ca "Yes, but you never know, he can always change his mind at the last minute."
    jo "You'll find out pretty soon, just relax. Aren't you going to dress up a little? Put some make-up on?"
    scene s442 with dissolve
    ca "Why? What's wrong with my clothes?"
    jo "You're not wearing a bra, I can see your nipples..."
    scene s443 with dissolve
    ca "That's the idea! These girls are going to help me tonight!"
    jo "Haha, you always act like a prude, but truly you're such a whore!"
    ca "You're the bitch! Who's having a date tonight with a complete stranger?"
    scene s444 with dissolve
    jo "First off, he's not a stranger, he's a friend from work and second, I just hope he's not like that disgusting bald man [p] was with...his uncle he said."
    ca "Ewww, that old perv and his boner, gross!"
    scene s445 with dissolve
    jo "Don't remind me. C'était vraiment dégueulasse."
    ca "Tell me about it."
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s439 with dissolve
    play music "audio/newmarch.ogg"
    ca "Why is he taking so long?!"
    jo "Haha, you're desperate to see him!"
    scene s446 with dissolve
    jo "Speaking of the devil..."
    scene s447 with dissolve
    pause
    scene s448 with dissolve
    ca "Hi, handsome! I'm glad you're finally here!"
    p "Hey, Camille...happy to see you too!"
    pt "Damn! Those tits!"
    ca "Come on in!"
    scene s449 with dissolve
    pt "Jo's such an elegant woman..."
    p "Hi, Jo! Nice outfit! Where are you going?"
    jo "Hi, [p]! Thanks! This guy from work invited me to a restaurant nearby."
    p "Oh, you have a date!"
    scene s450 with dissolve
    jo "Not a date in my dictionary, just free food in an elegant place, hehe."
    p "Ha, poor guy, I'm sure he has high hopes."
    ca "Jo is like that: always playing with men...sit here in the middle!"
    scene s451 with dissolve
    jo "Hey, that's not true! The way I see it is if men want to do something for me...great! There's nothing wrong with accepting a dinner or a gift. I'm not looking for a relationship, it's not my problem if men get their hopes up."
    jo "Right, [p]?"
    p "Uhmm, yeah, it's true it's not your problem: you don't have to deal with the consequences of whatever's going through someone's mind...question here is if you're somehow responsible for what they're thinking or feeling..."
    p "I mean, do you make it perfectly clear that you're not looking for a relationship?"
    jo "Not really, no, I don't see it necessary."
    p "No? If you agree and say \"Yes, we have a date.\", you kind of create false expectations, don't you think? Would they be spending their money on you if they knew they have no chance at all from the beginning?"
    p "If I don't know the rules of a game, I don't play it, simple as that. So, yeah I like being told those things, you know, to know where I'm getting myself into."
    scene s452 with dissolve
    p "I hate it when I have to read a woman's mind, just tell me what you want girl!"
    scene s453 with dissolve
    jo "Mystery is part of being a woman. Does your girlfriend tell you what she wants all the time?"
    p "Haha, sometimes...nice way to find out if I have a girlfriend by the way."
    scene s454 with dissolve
    jo "Hehe, I thought it was subtle..."
    p "It was, it was."
    ca "Focus guys..."
    scene s453 with dissolve
    jo "So, [p], you're basically saying that you want to know the end result before playing the game, not the rules...You want to know if you'll get something in return for your \"investment\"!"
    scene s454 with dissolve
    jo "I'm more like giving without expecting anything in return..."
    p "All the time? Sure I can do that sometimes, but not always, I'm not Jesus. People get tired of only giving and giving, a relationship is all about giving and receiving."
    jo "You're right about that, I wish my ex had thought like you...Do you really think people need a set of rules to start something? To me a relationship of any kind should be born naturally, you know, like us right now: you're being yourself, I'm being me if it flows and grows easily, perfect!"
    p "Yeah, and we could get to be good friends, we didn't say from the beginning \"Let's be friends!\"...I see your point."
    scene s455 with dissolve
    jo "Exactly! You're interesting...let me ask you something, honest boy, what do you think of my sis here?"
    ca "Jo!"
    scene s456 with dissolve
    p "I like her! I thought she was very serious when I first saw her, but the real thing is she takes her WORK seriously, big difference there. She always has a polite answer for everything, ready to help everybody...at least in the library, hehe."
    scene s457 with dissolve
    p "Truth is I don't know much about you Camille or you Jo, but since I'm here I'd like to get to know you two."
    pt "Mastering my bs..."
    jo "And her looks?"
    scene s458 with dissolve
    ca "Oh my god...Jo!"
    p "Definitely my type."
    scene s459 with dissolve
    pause
    scene s460 with dissolve
    jo "Haha, oh my god, how old are you, Cam?!"
    pt "How cute!"
    stop music fadeout 3.0
    scene s461 with dissolve
    jo "Whiskey or wine, [p]?"
    scene s462 with dissolve
    p "Uhm, whiskey, please...What are those cards?!"
    scene s463 with dissolve
    p "The empress, the lovers, the sun..."
    scene s464 with dissolve
    ca "These are Tarot cards! My sister and I like the esoteric world, the occult. Sometimes we like to know what the future will bring for us..."
    jo "Don't laugh!"
    scene s465 with dissolve
    p "I'm not laughing, why would I? I'm not stupid enough to make fun of other people's interests."
    scene s466 with dissolve
    ca "That was awesome..."
    p "What was?"
    scene s467 with dissolve
    jo "Hehe, what you just said...you say those things so naturally you don't even notice. I'm gonna get you some ice."
    p "Thanks!"
    scene s468 with dissolve
    ca "Do you want to know your future?"
    p "Yeah, please! What do I do?"
    ca "Come!"
    scene s469 with dissolve
    ca "I'm gonna shuffle the cards first, shuffling, shuffling, suffling...I'm very careful when I do it, I'm pretty gentle, I don't ever want to bang the cards on the table like a regular deck, you know."
    scene s470 with dissolve
    ca "Now, this's a very simple three card spread to do a general life reading. They represent your past, present and future, ok?"
    p "I'm nervous! This is fun!"
    ca "Haha, ready?"
    p "Yeah, yeah."
    scene s471 with dissolve
    play music "audio/russian3.mp3"
    ca "The Hierophant! This card represents traditional institutions, probably you come from a family with traditional values. You are very set in your ways, in your beliefs."
    ca "You also do what's expected of you, nothing unconventional. Regarding love, it means commitment, marriage..."
    p "I'm too young for that!"
    ca "I know, I'm just saying what it means and keep in mind that we're talking about your past here, you may have changed over time, or it could mean your parents raised you under those ideas, probably they have a solid marriage."
    scene s472 with dissolve
    ca "Now we've got...the Devil!"
    p "It's upside down to us..."
    ca "Yeah, it's reversed so it signifies that you are becoming aware of the things that have been trapping you: you're starting to see the light and take back control of your life. You're also starting to get the motivation to change those limiting circumstances."
    ca "And for your future we have..."
    scene s473 with dissolve
    p "A Tower?"
    ca "You know, people are generally afraid of the Death card, but the one you really need to brace yourself for is The Tower...as you can see, The Tower here represents chaos, destruction, loss...most of the time unavoidable."
    ca "Give me a moment, I want to be very responsible with what I'm about to say since I'm not an expert..."
    p "That serious, huh?"
    scene s474 with dissolve
    jo "Whoa! The Tower! What else? The Devil...the Hie...all of them Major Arcana!"
    p "What does that mean? Is that my drink?"
    scene s475 with dissolve
    jo "Yeah, here...Major Arcana cards have the biggest influence on your life, big impact, big lessons. Minor Arcana ones focus on everyday actions and decisions, nothing life-changing."
    jo "Looking at the whole spread, I'd say you'll go through the kind of thing you hope never happens to you..."
    p "What do you mean? A tragedy?"
    scene s472 with dissolve
    ca "Something like that...yeah, I have to agree with Jo, a traumatic event is coming, a big disaster..."
    p "Without filters...I don't know what to say..."
    scene s477 with dissolve
    ca "Sorry, but I have to be honest [p]...nothing's a hundred percent certain...if it comes, I'd suggest embracing it, do not resist this moment of transformation, it will only bring you pain...take it as a fresh start: after destruction comes creation."
    pt "The fuck?!"
    stop music fadeout 3.0
    scene s478 with dissolve
    jo "Do you believe in this kind of stuff?"
    p "To be honest not much, but I trust you two...this is a whole new world I ignore and it seems like you know what you're talking about..."
    scene s479 with dissolve
    ca "Don't overthink it...at the end, your future is in your hands, at least most of it is...Do your best!"
    p "Okaaayyy."
    scene s480 with dissolve
    jo "Yeah, listen to Cam, she's right! Don't think too much of it! I gotta go now...it was nice talking to you [p]! "
    p "Same here, take care Jo!"
    ca "Have fun, sis!"
    scene s481 with dissolve
    ca "Sorry, about that [p], I didn't want to ruin the night..."
    p "You haven't, Cam, I'm not worried about that really, it's just that I've had a veeery long day, believe me."
    ca "Yeah? Wanna share?"
    p "Probably, I need this drink first..."
    scene s482 with dissolve
    ca "Cheers!"
    p "Cheers."
    scene s483 with dissolve
    pause 1.0
    scene s484 with dissolve
    p "You have a beautiful place here Cam, full view of the ocean."
    ca "Thanks, I just moved in, we saved for so many years to buy it, my sister and I, I mean. She doesn't live here though, she has an apartment downtown..."
    scene s485 with dissolve
    p "Wow, it's pretty cool you already own a house, I don't own shit."
    scene s486 with dissolve
    ca "You're still young, I've been working since I was sixteen...I'm 26 now."
    p "You're young too! Are you kidding me?! Twenty-six and you have this whole place for yourself?!"
    scene s487 with dissolve
    ca "Haha, I don't waste any money to be honest...unlike my sister, hehe. Give me a sec, I'll go grab my phone to play some music..."
    p "Alright."
    scene s488 with dissolve
    ca "Do you need more ice?"
    pt "Holy shit!"
    p "Huh?"
    scene s489 with dissolve
    ca "More ice?"
    p "Ahem, ahem...no, don't worry, I'm good, thanks...."
    ca "Be right back!"
    scene black with dissolve
    scene s490 with dissolve
    pt "Those are really beautiful tits..."
    pt "\"Everybody has a weakness, I'm sure yours and mine are the same...\""
    scene s491 with dissolve
    pause 1.0
    scene s490 with dissolve
    pt "\"If she was naked in front of you, wouldn't you fuck her?\""
    scene s493 with dissolve
    pt "The fuck?! How come the bastard's words stuck in my head?...I have to..."

label camsex1:

    if _in_replay:
        $ pf = persistent.p

    ca "So, what do you think?"
    scene s494 with dissolve
    pause 1.0
    scene s495 with dissolve
    p "Oh my God! You look stunning!"
    scene s496 with dissolve
    ca "You think?"
    play music "audio/sensual1.ogg"

    scene s497:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "Holy fuck! I'm out of words..."
    ca "I can tell you like this..."
    scene s498 with dissolve
    ca "You want me to model for you?"
    p "You read my mind...come closer please!"
    scene s499 with dissolve
    pause 1.5
    scene s500 with dissolve
    ca "Oh god, I'm trying to be confident here, but it's not easy..."
    pt "Look at that body! Damn!"
    p "You're doing great Cam, just take your time."
    ca "All right, here we go."
    scene s501 with dissolve
    pause
    scene s502 with dissolve
    pt "She has something I find mysteriously tempting, can't tell what it is..."
    scene s503 with dissolve
    pt "Oh! Nevermind."
    scene s504 with dissolve
    pause
    scene s505 with dissolve
    p "Can I get a 360?"
    scene s506 with dissolve
    ca "You like this, don't you?"
    p "I'm loving it!"
    scene s507 with dissolve
    pause
    scene s508 with dissolve
    pause
    scene s509 with dissolve
    pause
    scene s510 with dissolve
    p "Ooooofff!"
    scene s511 with dissolve
    p "Oh my God, Cam! You're so hot!"
    scene s512 with dissolve
    ca "Haha, you sure?"
    p "I'm tripping here..."
    scene s514 with dissolve
    ca "Why? I'm not doing anything."
    scene s515 with dissolve
    p "You're not?"
    scene s544 with dissolve
    ca "Nope."
    scene s515 with dissolve

    scene s515:
        pause 0.0333
        "s516"
        pause 0.0333
        "s517"
        pause 0.0333
        "s518"
        pause 0.0333
        "s519"
        pause 0.0333
        "s520"
        pause 0.0333
        "s521"
        pause 0.0333
        "s522"
        pause 0.0333
        "s523"
        pause 0.0333
        "s524"
        pause 0.0333
        "s525"
        pause 0.0333
        "s526"
        pause 0.0333
        "s527"
        pause 0.0333
        "s528"
        pause 0.0333
        "s529"
        pause 0.0333
        "s530"
        pause 0.0333
        "s531"
        pause 0.0333
        "s532"
        pause 0.0333
        "s533"
        pause 0.0333
        "s534"
        pause 0.0333
        "s535"
        pause 0.0333
        "s536"
        pause 0.0333
        "s537"
        pause 0.0333
        "s538"
        pause 0.0333
        "s539"
        pause 0.0333
        "s540"
        pause 0.0333
        "s541"
        pause 0.0333
        "s542"
        pause 0.0333
        "s543"
        pause 0.0333
        "s544"
        pause 0.0333
        "s544"
        pause 0.0333
        "s543"
        pause 0.0333
        "s542"
        pause 0.0333
        "s541"
        pause 0.0333
        "s540"
        pause 0.0333
        "s539"
        pause 0.0333
        "s538"
        pause 0.0333
        "s537"
        pause 0.0333
        "s536"
        pause 0.0333
        "s535"
        pause 0.0333
        "s534"
        pause 0.0333
        "s533"
        pause 0.0333
        "s532"
        pause 0.0333
        "s531"
        pause 0.0333
        "s530"
        pause 0.0333
        "s529"
        pause 0.0333
        "s528"
        pause 0.0333
        "s527"
        pause 0.0333
        "s526"
        pause 0.0333
        "s525"
        pause 0.0333
        "s524"
        pause 0.0333
        "s523"
        pause 0.0333
        "s522"
        pause 0.0333
        "s521"
        pause 0.0333
        "s520"
        pause 0.0333
        "s519"
        pause 0.0333
        "s518"
        pause 0.0333
        "s517"
        pause 0.0333
        "s516"
        pause 0.0333
        "s515"
        pause 0.0333
        repeat
    pause

    scene s545 with dissolve
    p "Come here already!"
    ca "What are you gonna do to me?"
    p "You'll see..."
    scene s546 with dissolve
    ca "I'm scared...you have bad intentions."
    p "I'll be kind."
    scene s547 with dissolve
    pause 1.5
    scene s548 with dissolve
    p "My God, they're soft!"
    ca "You're so gentle...I love it!"
    scene s549 with dissolve
    p "They invite me to be..."
    ca "Are they bigger than your girlfriend's?"
    scene s550 with dissolve
    p "What? Oh, you're a naughty girl."
    scene s551 with dissolve
    ca "YOU are! You have your hands on me!"
    p "I do, I do, can't help it...can't think straight right now...you're so hot."
    scene s552 with dissolve
    ca "I won't tell anybody."
    p "That's all I needed to know."
    scene s553 with dissolve
    pause 1
    scene s554 with dissolve
    ca "I'll show you what's good..."
    scene s556 with vpunch
    p "Wooow, they're perfect!"
    scene s555 with dissolve
    ca "They can be yours..."
    p "Come, I need to taste them."
    scene s557 with dissolve
    ca "Good boy, suck them gently."
    scene s558 with dissolve
    pause
    scene s559 with dissolve
    ca "Hey! Don't bite, naughty boy..."
    scene s560 with dissolve
    p "Sorry, your tits are just too delicious, can't control myself."
    scene s562 with hpunch
    p "Look at them!"
    scene s561 with dissolve
    ca "I can feel how hard you are."
    p "Yeah, with all your teasing...and you keep doing it."
    scene s563 with dissolve
    ca "I'm not teasing you..."
    p "Hey, I was having fun with my boobs!"
    ca "Yours?"
    p "Yes! They're mine tonight!"
    scene s564 with dissolve
    ca "They're not..."
    p "That's it! Take this thing off!"
    scene black with dissolve
    scene s565 with dissolve
    ca "Ooohhh, what a bad boy...you make me so wet..."
    p "Ssssss..."
    scene s566 with dissolve
    ca "My God, I love your cock!"
    scene s570a with dissolve
    p "Ooohhh, you're so tight..."
    scene s566 with dissolve
    pause
    scene s570a with dissolve
    pause
    scene s566 with dissolve

label sit0:
    scene s566:
        pause 0.0333
        "s566a"
        pause 0.0333
        "s567"
        pause 0.0333
        "s567a"
        pause 0.0333
        "s568"
        pause 0.0333
        "s568a"
        pause 0.0333
        "s569"
        pause 0.0333
        "s569a"
        pause 0.0333
        "s570"
        pause 0.0333
        "s570a"
        pause 0.0333
        "s571"
        pause 0.0333
        "s572"
        pause 0.0333
        "s573"
        pause 0.0333
        "s574"
        pause 0.0333
        "s575"
        pause 0.0333
        "s576"
        pause 0.0333
        "s577"
        pause 0.0333
        "s578"
        pause 0.0333
        "s579"
        pause 0.0333
        "s579a"
        pause 0.0333
        "s580"
        pause 0.0333
        "s580a"
        pause 0.0333
        "s581"
        pause 0.0333
        "s581a"
        pause 0.0333
        "s582"
        pause 0.0333
        "s582a"
        pause 0.0333
        "s583"
        pause 0.0333
        "s583a"
        pause 0.0333
        "s584"
        pause 0.0333
        repeat
    pause

menu:
    "Faster.":
        jump sit1

    "Change angle.":
        jump sit2

label sit1:

    scene s566:
        pause 0.0166
        "s566a"
        pause 0.0166
        "s567"
        pause 0.0166
        "s567a"
        pause 0.0166
        "s568"
        pause 0.0166
        "s568a"
        pause 0.0166
        "s569"
        pause 0.0166
        "s569a"
        pause 0.0166
        "s570"
        pause 0.0166
        "s570a"
        pause 0.0166
        "s571"
        pause 0.0166
        "s571a"
        pause 0.0166
        "s572"
        pause 0.0166
        "s572a"
        pause 0.0166
        "s573"
        pause 0.0166
        "s573a"
        pause 0.0166
        "s574"
        pause 0.0166
        "s574a"
        pause 0.0166
        "s575"
        pause 0.0166
        "s575a"
        pause 0.0166
        "s576"
        pause 0.0166
        "s576a"
        pause 0.0166
        "s577"
        pause 0.0166
        "s577a"
        pause 0.0166
        "s578"
        pause 0.0166
        "s578a"
        pause 0.0166
        "s579"
        pause 0.0166
        "s579a"
        pause 0.0166
        "s580"
        pause 0.0166
        "s580a"
        pause 0.0166
        "s581"
        pause 0.0166
        "s581a"
        pause 0.0166
        "s582"
        pause 0.0166
        "s582a"
        pause 0.0166
        "s583"
        pause 0.0166
        "s583a"
        pause 0.0166
        "s584"
        pause 0.0166
        repeat
    pause
    p "Yeah, like that..."

menu:
    "Slower.":
        jump sit0

    "Change angle.":
        jump sit2

label sit2:

    scene s585:
        pause 0.0333
        "s585a"
        pause 0.0333
        "s586"
        pause 0.0333
        "s586a"
        pause 0.0333
        "s587"
        pause 0.0333
        "s587a"
        pause 0.0333
        "s588"
        pause 0.0333
        "s588a"
        pause 0.0333
        "s589"
        pause 0.0333
        "s589a"
        pause 0.0333
        "s590"
        pause 0.0333
        "s590a"
        pause 0.0333
        "s591"
        pause 0.0333
        "s591a"
        pause 0.0333
        "s592"
        pause 0.0333
        "s592a"
        pause 0.0333
        "s593"
        pause 0.0333
        "s593a"
        pause 0.0333
        "s594"
        pause 0.0333
        "s594a"
        pause 0.0333
        "s595"
        pause 0.0333
        "s595a"
        pause 0.0333
        "s596"
        pause 0.0333
        "s596a"
        pause 0.0333
        "s597"
        pause 0.0333
        "s598"
        pause 0.0333
        "s599"
        pause 0.0333
        "s599a"
        pause 0.0333
        "s600"
        pause 0.0333
        "s600a"
        pause 0.0333
        "s601"
        pause 0.0333
        "s601a"
        pause 0.0333
        "s602"
        pause 0.0333
        "s602a"
        pause 0.0333
        "s603"
        pause 0.0333
        repeat
    pause

    p "You sure know how to move your ass..."
    ca "You like it?"

    scene s585:
        pause 0.0222
        "s585a"
        pause 0.0222
        "s586"
        pause 0.0222
        "s586a"
        pause 0.0222
        "s587"
        pause 0.0222
        "s587a"
        pause 0.0222
        "s588"
        pause 0.0222
        "s588a"
        pause 0.0222
        "s589"
        pause 0.0222
        "s589a"
        pause 0.0222
        "s590"
        pause 0.0222
        "s590a"
        pause 0.0222
        "s591"
        pause 0.0222
        "s591a"
        pause 0.0222
        "s592"
        pause 0.0222
        "s592a"
        pause 0.0222
        "s593"
        pause 0.0222
        "s593a"
        pause 0.0222
        "s594"
        pause 0.0222
        "s594a"
        pause 0.0222
        "s595"
        pause 0.0222
        "s595a"
        pause 0.0222
        "s596"
        pause 0.0222
        "s596a"
        pause 0.0222
        "s597"
        pause 0.0222
        "s598"
        pause 0.0222
        "s599"
        pause 0.0222
        "s599a"
        pause 0.0222
        "s600"
        pause 0.0222
        "s600a"
        pause 0.0222
        "s601"
        pause 0.0222
        "s601a"
        pause 0.0222
        "s602"
        pause 0.0222
        "s602a"
        pause 0.0222
        "s603"
        pause 0.0222
        repeat
    pause

    ca "Does your girl move like this?"
    p "You're dirty, Cam..."

    scene s585:
        pause 0.0166
        "s585a"
        pause 0.0166
        "s586"
        pause 0.0166
        "s586a"
        pause 0.0166
        "s587"
        pause 0.0166
        "s587a"
        pause 0.0166
        "s588"
        pause 0.0166
        "s588a"
        pause 0.0166
        "s589"
        pause 0.0166
        "s589a"
        pause 0.0166
        "s590"
        pause 0.0166
        "s590a"
        pause 0.0166
        "s591"
        pause 0.0166
        "s591a"
        pause 0.0166
        "s592"
        pause 0.0166
        "s592a"
        pause 0.0166
        "s593"
        pause 0.0166
        "s593a"
        pause 0.0166
        "s594"
        pause 0.0166
        "s594a"
        pause 0.0166
        "s595"
        pause 0.0166
        "s595a"
        pause 0.0166
        "s596"
        pause 0.0166
        "s596a"
        pause 0.0166
        "s597"
        pause 0.0166
        "s598"
        pause 0.0166
        "s599"
        pause 0.0166
        "s599a"
        pause 0.0166
        "s600"
        pause 0.0166
        "s600a"
        pause 0.0166
        "s601"
        pause 0.0166
        "s601a"
        pause 0.0166
        "s602"
        pause 0.0166
        "s602a"
        pause 0.0166
        "s603"
        pause 0.0166
        repeat
    pause

    p "Fuck!"
    ca "I want you to come inside!"
    pt "Shit, that's hot! But I can't come this quick..."

    scene s585:
        pause 0.0088
        "s585a"
        pause 0.0088
        "s586"
        pause 0.0088
        "s586a"
        pause 0.0088
        "s587"
        pause 0.0088
        "s587a"
        pause 0.0088
        "s588"
        pause 0.0088
        "s588a"
        pause 0.0088
        "s589"
        pause 0.0088
        "s589a"
        pause 0.0088
        "s590"
        pause 0.0088
        "s590a"
        pause 0.0088
        "s591"
        pause 0.0088
        "s591a"
        pause 0.0088
        "s592"
        pause 0.0166
        "s592a"
        pause 0.0166
        "s593"
        pause 0.0166
        "s593a"
        pause 0.0166
        "s594"
        pause 0.0166
        "s594a"
        pause 0.0166
        "s595"
        pause 0.0166
        "s595a"
        pause 0.0166
        "s596"
        pause 0.0166
        "s596a"
        pause 0.0166
        "s597"
        pause 0.0166
        "s598"
        pause 0.0166
        "s599"
        pause 0.0166
        "s599a"
        pause 0.0166
        "s600"
        pause 0.0166
        "s600a"
        pause 0.0166
        "s601"
        pause 0.0166
        "s601a"
        pause 0.0166
        "s602"
        pause 0.0166
        "s602a"
        pause 0.0166
        "s603"
        pause 0.0166
        repeat
    pause
    ca "I'm so close, baby..."

    scene s640 with vpunch
    scene s640 with vpunch
    scene s640 with vpunch
    ca "Aaahhh, fuck!!! Your dick made me come so fast!"
    scene s612 with dissolve
    ca "It feels so good..."
    p "Keep moving, Cam..."
    ca "Yes, I want your cum in my pussy..."
    p "Shit!"

    scene s604 with dissolve
    scene s604:
        pause 0.0166
        "s605"
        pause 0.0166
        "s606"
        pause 0.0166
        "s607"
        pause 0.0166
        "s608"
        pause 0.0166
        "s609"
        pause 0.0166
        "s610"
        pause 0.0166
        "s611"
        pause 0.0166
        "s612"
        pause 0.0166
        "s612a"
        pause 0.0166
        "s612b"
        pause 0.0166
        "s612c"
        pause 0.0166
        "s613"
        pause 0.0166
        "s613a"
        pause 0.0166
        "s613b"
        pause 0.0166
        "s613c"
        pause 0.0166
        "s614"
        pause 0.0166
        "s615"
        pause 0.0166
        "s616"
        pause 0.0166
        "s617"
        pause 0.0166
        "s618"
        pause 0.0166
        "s619"
        pause 0.0166
        "s620"
        pause 0.0166
        "s621"
        pause 0.0166
        "s622"
        pause 0.0166
        "s623"
        pause 0.0166
        "s624"
        pause 0.0166
        "s625"
        pause 0.0166
        "s626"
        pause 0.0166
        "s627"
        pause 0.0166
        "s628"
        pause 0.0166
        "s629"
        pause 0.0166
        "s630"
        pause 0.0166
        "s631"
        pause 0.0166
        "s632"
        pause 0.0166
        "s633"
        pause 0.0166
        "s634"
        pause 0.0166
        "s635"
        pause 0.0166
        "s636"
        pause 0.0166
        "s637"
        pause 0.0166
        "s638"
        pause 0.0166
        "s639"
        pause 0.0166
        repeat
    pause

    ca "Give me your cum, already!"

    scene s604:
        pause 0.0088
        "s605"
        pause 0.0088
        "s606"
        pause 0.0088
        "s607"
        pause 0.0088
        "s608"
        pause 0.0088
        "s609"
        pause 0.0088
        "s610"
        pause 0.0088
        "s611"
        pause 0.0088
        "s612"
        pause 0.0088
        "s612a"
        pause 0.0088
        "s612b"
        pause 0.0088
        "s612c"
        pause 0.0088
        "s613"
        pause 0.0088
        "s613a"
        pause 0.0088
        "s613b"
        pause 0.0088
        "s613c"
        pause 0.0088
        "s614"
        pause 0.0088
        "s615"
        pause 0.0088
        "s616"
        pause 0.0088
        "s617"
        pause 0.0088
        "s618"
        pause 0.0088
        "s619"
        pause 0.0088
        "s620"
        pause 0.0088
        "s621"
        pause 0.0088
        "s622"
        pause 0.0088
        "s623"
        pause 0.0088
        "s624"
        pause 0.0088
        "s625"
        pause 0.0088
        "s626"
        pause 0.0088
        "s627"
        pause 0.0088
        "s628"
        pause 0.0088
        "s629"
        pause 0.0088
        "s630"
        pause 0.0088
        "s631"
        pause 0.0088
        "s632"
        pause 0.0088
        "s633"
        pause 0.0088
        "s634"
        pause 0.0088
        "s635"
        pause 0.0088
        "s636"
        pause 0.0088
        "s637"
        pause 0.0088
        "s638"
        pause 0.0088
        "s639"
        pause 0.0088
        repeat
    pause
    p "Ohhh, fuck!"
    scene s641 with vpunch
    scene s641 with vpunch
    scene s641 with vpunch
    p "Aaahhh!!!"
    ca "Haha, I can feel your warm cum..."
    stop music fadeout 3.0
    scene s642 with dissolve
    ca "Oh my god!"
    p "I gave you what you wanted..."
    scene s643 with dissolve
    ca "Yeah! Love it!"
    scene black with dissolve
    scene s644 with dissolve
    ca "Come, I want more of you!"
    scene s646 with dissolve
    ca "I'm waiting..."
    scene black with dissolve
    play music "audio/gettingdirty.ogg" volume 0.7
    scene s647 with dissolve
    p "You're incredible, Camille."
    ca "You think?"
    scene s648 with dissolve
    p "Yeah, I love your pussy..."
    scene s649 with dissolve
    ca "Fuck me, baby!"
    scene s650 with dissolve
    pause
    scene s651 with Dissolve(0.06)
    scene s652 with Dissolve(0.06)
    scene s653 with Dissolve(0.06)
    scene s654 with Dissolve(0.06)
    scene s655 with dissolve
    ca "You like my body?"
    scene s656 with dissolve
    p "You have no idea how much..."
    scene s657 with dissolve
    pause
    scene s658 with vpunch

    scene s658:
        pause 0.0166
        "s659"
        pause 0.0166
        "s660"
        pause 0.0166
        "s661"
        pause 0.0166
        "s662"
        pause 0.0166
        "s663"
        pause 0.0166
        "s664"
        pause 0.0166
        "s665"
        pause 0.0166
        "s666"
        pause 0.0166
        "s667"
        pause 0.0166
        "s668"
        pause 0.0166
        "s669"
        pause 0.0166
        "s670"
        pause 0.0166
        "s671"
        pause 0.0166
        "s672"
        pause 0.0166
        "s673"
        pause 0.0166
        "s674"
        pause 0.0166
        "s675"
        pause 0.0166
        "s676"
        pause 0.0166
        "s677"
        pause 0.0166
        "s678"
        pause 0.0166
        "s679"
        pause 0.0166
        "s680"
        pause 0.0166
        "s681"
        pause 0.0166
        "s682"
        pause 0.0166
        "s683"
        pause 0.0166
        "s684"
        pause 0.0166
        "s685"
        pause 0.0166
        "s686"
        pause 0.0166
        "s687"
        pause 0.0166
        "s688"
        pause 0.0166
        "s689"
        pause 0.0166
        "s690"
        pause 0.0166
        "s691"
        pause 0.0166
        "s692"
        pause 0.0166
        "s693"
        pause 0.0166
        "s694"
        pause 0.0166
        "s695"
        pause 0.0166
        "s696"
        pause 0.0166
        "s697"
        pause 0.0166
        "s698"
        pause 0.0166
        "s699"
        pause 0.0166
        "s699a"
        pause 0.0166
        "s699b"
        pause 0.0166
        "s699c"
        pause 0.0166
        "s699d"
        pause 0.0166
        "s699e"
        pause 0.0166
        "s699f"
        pause 0.0166
        "s699g"
        pause 0.0166
        "s699h"
        pause 0.0166
        "s699i"
        pause 0.0166
        "s699j"
        pause 0.0166
        repeat
    pause
    play sound "audio/sex3.mp3"
    scene s658face:
        pause 0.0166
        "s660face"
        pause 0.0166
        "s662face"
        pause 0.0166
        "s664face"
        pause 0.0166
        "s666face"
        pause 0.0166
        "s668face"
        pause 0.0166
        "s670face"
        pause 0.0166
        "s672face"
        pause 0.0166
        "s674face"
        pause 0.0166
        "s676face"
        pause 0.0166
        "s678face"
        pause 0.0166
        "s680face"
        pause 0.0166
        "s682face"
        pause 0.0166
        "s684face"
        pause 0.0166
        "s686face"
        pause 0.0166
        "s688face"
        pause 0.0166
        "s690face"
        pause 0.0166
        "s692face"
        pause 0.0166
        "s694face"
        pause 0.0166
        "s696face"
        pause 0.0166
        "s698face"
        pause 0.0166
        "s699aface"
        pause 0.0166
        "s699cface"
        pause 0.0166
        "s699eface"
        pause 0.0166
        "s699gface"
        pause 0.0166
        "s699iface"
        pause 0.0166
        repeat
    pause
    p "Oh, fuck! You're amazing!"
    pt "I'm gonna come again if I keep this pace..."
    stop sound fadeout 2.0
    scene s728 with vpunch
    p "You like this?"
    scene s729 with dissolve
    ca "Uhum!"
    scene black with Dissolve(1.5)
    scene s730 with dissolve
    pause
    scene s731 with dissolve
    pause
    scene s732 with dissolve
    pause
    scene s733 with dissolve
    pause
    scene s736 with dissolve
    pause
    scene s737 with vpunch
    scene s737 with vpunch
    scene s737 with vpunch
    ca "Aaahhh!"
    scene s734 with dissolve
    pause
    scene s735 with dissolve
    pause
    scene s738 with dissolve
    ca "Oh my god!"
    scene s739 with dissolve
    ca "I'm cumming!"
    p "I'm cumming too...inside of you!"
    scene s740 with vpunch
    play sound "audio/femorg3.ogg"
    scene s740 with vpunch
    scene s740 with vpunch
    scene s740 with vpunch
    pause
    scene s741 with vpunch
    play sound "audio/maleorg1.ogg"
    scene s741 with vpunch
    scene s741 with vpunch
    scene s741 with vpunch
    pause
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s742 with dissolve
    ca "You're not staying the night?"
    p "I can't, Cam, I have to go now..."
    ca "You can come back anytime you want, you know that right?"
    p "Yeah, we'll talk about this..."
    scene black with Dissolve(2.0)

    $ renpy.end_replay()

    scene s743 with dissolve
    pause
    scene s744 with dissolve
    pt "What did I just do? It didn't even take a Madi Dorn to cheat on S..."
    pt "S...she didn't even cross my mind..."
    pt "That old bastard was right..."
    scene black with Dissolve(2.0)
    play music "audio/cosy.ogg"
    scene s745 with dissolve
    pt "Oh, God! This day seems endless, one temptation after the other..."
    vi "How was your party, [p]?"
    pt "She's acting casually...probably because she considers me family already...or she had some drinks too..."
    p "Hey, Vittoria...good, good, it's always good to see old friends...and you? How come you're up?"
    vi "I'm just waiting for Giuseppe, he went to buy something...Sam and Chris are already sleeping if you're wondering..."
    scene s746 with dissolve
    p "Yeah, I was about to ask..."
    vi "They started drinking when they came back and well, they got a little drunk and went to bed."
    p "I see, I should've come back with them...and by the way, where am I sleeping?"
    vi "You're taking the couch! My husband doesn't want you to sleep with Sammy, you know, very protective and jealous father."
    pt "Right..."
    scene s747 with dissolve
    vi "I'd better go back to my room, don't want you to feel uncomfortable..."
    p "You mean the smoke?"
    vi "The smoke and also my clothes, maybe it's a little awkward to you..."
    p "I don't mind...this's your house Vittoria, you can do and wear whatever you like."
    scene s748 with dissolve
    vi "You know what, [p]? I like you for my daughter, you're a good boy...take a rest."
    pt "I'm not..."
    p "Good night, Vittoria."
    scene s749 with dissolve
    pt "I don't want to think anymore, I'm exhausted...just want this day to end..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    jump choice58common

label choice58common:

    scene s804 with dissolve
    pause 1
    scene s805 with dissolve
    p "Good morning, Vittoria!"
    vi "Morning, [p]!"
    scene s806 with dissolve
    p "Uhmm, sorry to bother you, but your husband said I could borrow more clothes, I just took a shower and these clothes are kind of dirty...uhm, there's a purple suitcase he said."
    vi "Oh, yeah, behind those curtains."
    p "Thanks...Oh, and by the way, you make that dress look beautiful, Vittoria!"
    play music "audio/sexback.ogg"

    scene s807:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    vi "Awww, how cute! Thank you so much, [p]!"
    p "Just stating facts..."
    scene black with dissolve
    scene s808 with dissolve
    vi "What a handsome son-in-law I have!"
    p "Haha, you sounded just like my mom...thanks, Vittoria!"
    vi "Giuseppe bought all those clothes thinking he was going to lose weight. You can take them all if you want, give them good use."
    p "I'm good, thank you...but I know a charity that you can donate those clothes to."
    scene s809 with dissolve
    vi "Oh, I loved the idea! Give me their number later, all right?"
    p "Will do."
    vi "Now let's go have some breakfast!"
    stop music fadeout 3.0
    scene black with dissolve
    scene s810 with dissolve
    sa "Morning, baby, nice shirt! Hi, mom."
    p "Haha, you know it's your dad's..."
    sa "I know, I know...looks good on you though."
    vi "Talking about Giuseppe...where's he, darling?"
    sa "In the living...he said he's not hungry."
    scene s811 with dissolve
    vi "What would you like for breakfast, honey?"
    p "To be honest, I'm not hungry either, Vittoria...a juice would do."
    vi "Okay."
    scene s812 with dissolve
    vi "And Chris? Where's she?"
    sa "She doesn't feel well, she's hungover. I couldn't sleep well because of her..."
    vi "Oh, honey, go to my bed if you need to sleep some more."
    sa "Yeah, I need it, but I'm looking after her, she was vomiting just now."
    vi "Better let her rest...I wanted to take you all for some ice cream, but I guess that's not happening..."
    sa "Oh no, mom, not a good idea...everybody's..."
    scene s813 with dissolve
    p "I'm in! I mean...ice cream sounds good..."
    scene s814 with dissolve
    vi "Exactly! You're one of mine! I'll go ask Giuseppe if he wants to come too..."
    scene s815 with dissolve
    sa "Why are you wearing heels, mom? They're not much good for walking on the beach."
    vi "You're right, darling, as usual...I'll go change."
    scene black with dissolve
    scene s816 with dissolve
    sa "Dad said we all could watch a movie later, baby...what do you think?"
    p "Sure, that's a good plan for a Sunday."

if choice58b:
    sa "Sorry baby, I wasn't awake when you came back yesterday, got a little drunk too...you took long, what did you do?"
    pt "There it is...the question I don't want to answer...once you start a path of lies, it never ends well..."
    p "I was talking to Rob, baby, and guess what? He wants to see me play: he said he'll give me a chance to do some trials!"
    scene s817 with dissolve
    sa "Get out of here! Really?!"
    p "Yes! He's gonna call me next week! First, he needs to talk to a former coach of mine, at least that's what he said..."
    scene s818 with dissolve
    sa "This's your chance, cat! Oh my God! You've been training so hard lately! Can I go with you?"
    p "Of course! I'd love to have you there...to celebrate or cry afterwards."
    sa "You're definitely going to make it!"
    cs "S!"
    scene s819 with dissolve
    sa "She may need something..."
    scene s820 with dissolve
    sa "We'll talk when you guys come back, baby..."

else:
    scene s818 with dissolve
    sa "Do you know I love you so much?"
    p "Haha, I do, babe! I love you, too!"
    cs "S!"
    scene s819 with dissolve
    sa "She may need something..."
    scene s820 with dissolve
    sa "Enjoy your ice cream, cat...I'll be waiting..."
    jump icecream

label icecream:
    play music "audio/cookingup.ogg" volume 0.8
    scene black with Dissolve(1.5)
    scene s821 with dissolve
    p "So...is it a good place?"
    vi "Oh, it's the best! You're going to love it! They have all these artisanal flavors from all over the world!"
    p "Really? Which one is your favorite?"
    scene s822 with dissolve
    vi "It's called Raspberry Lychee Rose from France!"
    p "Did you know lychee is native to China?"
    vi "Oh, I didn't know that...you know things, just like my Sammy...Look, that's the shop!"
    scene black with dissolve
    play sound "audio/shopbell.ogg"
    scene s823 with dissolve
    yu "Welcome to Sunny Creamery!"
    p "Yua?"
    yu "Heeeeeyyy, [p]! Glad to see you again!"
if choice58b:
    pt "No hard feelings, huh? Well, it was CJ who offended her, not me. Besides, this's not the place to talk about it, she's working..."
    jump yuaice

label yuaice:
    p "Girl, is there a place where you don't work at?"
    scene s824 with dissolve
    yu "Hahaha, today is my first day here actually...I'm taking over Sunny Beach! Haha."
    p "Yeah, I can tell!"
    scene s825 with dissolve
    vi "Darling...Yua, right? What happened to Willow?"
    yu "Oh, she found a better job she said, she left her number if you want it..."
    vi "I already have it, darling...that girl's adorable! I'm going to miss her."
    yu "Could you tell me your name, please?"
    vi "Vittoria, honey..."
    yu "Vittoria, perhaps I can make you like me too! Come over here, please, I'll show you all the flavors we have!"
    scene s826 with dissolve
    yu "Uhmmm...Sticky Mango from Thailand, Japanese Metropolitan, Crunchy Ube, Salted Caramel, Mint Chip...but I'm sure you'd like our Raspberry Lychee Rose, right Vittoria?"
    scene s827 with dissolve
    vi "Wow! Sweety! How did you..."
    yu "Willow! She made me a list of our top customers and I just happen to have very good memory."
    p "That was really cool! Nice detail, Yua!"
    vi "I knew that girl's wonderful! And so are you, Yua!"
    scene s828 with dissolve
    yu "Hehe, thanks you two!"
    scene s829 with dissolve
    yu "[p], your name was not on that list, I'm sorry, what flavor would you like?"
    p "Uhmmm, something more classic...Chocolate chip?"
    yu "Just give me a sec, ok?"
    scene black with dissolve
    scene s830 with dissolve
    p "Wow, that's a huge cone! And the texture looks just...different!"
    vi "Yeah, the dairy base is made from scratch and it shows! They've always stayed true to a super-premium ice cream, using natural fresh ingredients only...never compromised quality!"
    p "Haha, I love how you love this place!"
    vi "Haha, yeah, Giuseppe's a friend of the owner...uuuhm, not a friend, an old acquaintance...that's how we became frequent clients here."
    p "I see...and why didn't Giuseppe come with us?"
    scene s831 with dissolve
    vi "I don't know, he said he had things to do..."
    pt "Her expression changed, she's not ok with it...Hold on, did he do it on purpose so I could..."
    scene s832 with dissolve
    vi "So [p], how's college? Are you studying Psychology like Sammy? I forgot..."
    p "No, I'm into Business...well, not really INTO it, you know, but I have to do something..."
    scene s833 with dissolve
    vi "Oh, I know that feeling: my father wanted me and my sister to study Law and so, we did...I worked on it for a few years, not really my thing..."
    vi "Believe it or not, I wanted to be an actress, but going to college was the safe bet for the family..."
    vi "We didn't have the resources back then to pursue a dream and I couldn't waste time...Then I met Giuseppe, got married, Sammy came! So that dream just faded away."
    pt "That's pretty much the future ME talking..."
    p "Do you regret it? Not following your dream, I mean..."
    scene s834 with dissolve
    vi "No, not at all...not now. I'm very satisfied with the life I have and every single \"mistake\" got me here...made me who I am."
    vi "If I had done things differently, perhaps I wouldn't be the woman I am now, perhaps I wouldn't have my Sammy...so...I truly don't regret anything."
    p "Wow, I wish to get there at some point of my life...you know, that brings to my mind a quote I heard in my Phi..."
    play sound "audio/shopbell.ogg"
    stop music fadeout 3.0
    scene s835 with dissolve
    p "{size=-6}...losophy class...{/size}"
    pt "That fool! Is he really fucking my bro's mother? Look at him! Man, what should I do? Haven't had the time to think about it yet, but the more I do it the angrier I get..."
    vi "What quote?"
    p "Huh?"
    scene s832 with dissolve
    vi "What quote? You were about to say something and got distracted, everything ok?"
    pt "Not really...I wanted to talk with Franz or Dr. Pratt first, they would definitely give me good advice...I already have your husband's: blackmail her. What a piece of shit..."
    pt "I'd like to know what you would do..."
    p "Vittoria, you've treated me very well since the day we met, welcoming me to your home and I'm very thankful for it..."
    scene s836 with dissolve
    p "Something is bothering me and I want to share it with you because I trust you..."
    scene s837 with dissolve
    p "I'm just gonna say it..."
    scene s838 with dissolve
    p "My friend's mom is having an affair with, don't look, that guy who just came in..."
    p "I'm feeling lost here, really don't know what to do...tell my friend, talk to his mom, do nothing..."
    scene s839 with dissolve
    vi "That's a tough one...I have to picture myself being in that situation..."
    scene s831 with dissolve
    vi "Well, if it's me the one who's cheating and you find out, I'd like you to talk with me first; but if it's my husband who's cheating..."
    scene s832 with dissolve
    vi "I'd also want you to tell me first, hehe."
    p "Hehe, I don't fully get it...so what you're saying is that I shouldn't talk to the person who's doing it, but to the one I care the most about?"
    scene s840 with dissolve
    vi "Probably that's what I would do...if my best friend's having an affair I'd talk to her first, listen to her...even knowing she did something wrong, I'd take her side. She's my friend, not her husband."
    vi "If my Sammy stole something, for instance, I'd defend her no matter what...and of course I know stealing is wrong."
    p "So you value people over your principles..."
    scene s841 with dissolve
    vi "Wouldn't you steal to feed your starving little brother if that were the only way? Wouldn't you disobey an order to kill an innocent?"
    p "I didn't see it that way...you're right..."
    vi "Let's put it this way: the people I value won't make me break my principles."
    p "Wow!"
    scene s842 with dissolve
    vi "But hey, the other person has to be willing to do the exact same thing for me. That's the only condition: reciprocity."
    p "Partners in crime! If we go to hell, let's at least go together, huh?"
    play sound "audio/shopbell.ogg"
    scene s843 with dissolve
    p "He's leaving..."
    vi "This ice cream's melting already...Wanna go after him? "
    p "What for?"
    vi "I may have an idea..."
    scene black with Dissolve(1.5)
    play music "audio/fashionsaxo.ogg"
    scene s844 with dissolve
    vi "We're going to need some proof if you finally want to talk to your friend."
    p "I already have a picture of them holding hands."
    vi "Holding hands won't do."
    p "I saw them kissing...I'm pretty sure she wouldn't deny it, she doesn't have the heart to lie..."
    scene s845 with dissolve
    p "Yeah, I take that back...we think we know people and then..."

if choice58b:
    pt "Stop it right there! Who the hell am I to judge Mrs. Lopez after what I did?"
    jump mrslopez

label mrslopez:
    scene black with dissolve
    scene s846 with dissolve
    p "What's the plan, Vittoria?"
    vi "You're going to put an end to this."
    p "What?! How?!"
    vi "You want that asshole to spend one more night with your friend's mom?"
    p "I don't..."
    scene black with dissolve
    scene s847 with dissolve
    p "That's her."
    vi "So this's the hotel they're staying at."
    p "Looks like it."
    scene s848 with dissolve
    vi "Look at that. You shouldn't let that asshole put a finger on her anymore..."
    p "You're right, what do I do?"
    scene s849 with dissolve
    vi "All right, you have two ways to end this today, listen: option number one, just go there. She'll be embarrased and SHE would want to talk to you, I'm sure."
    vi "That's going to take you at least two hours, with all the drama and the excuses...Be back at 4 tops, we're leaving before rush hour..."
    p "And option two?"
    scene s850 with dissolve
    vi "I go there and pretend to be his wife or another mistress, but that might go wrong, we don't even know his name..."
    p "Mr. Anderson...he's my teacher at St. Fancis..."
    scene s851 with dissolve
    vi "What?! Does this perv teach my Sammy?"
    p "Actually, he does, we're taking his class together."
    scene s852 with dissolve
    vi "Ok, now it's personal! Change of plans, just leave it to me, I'll make them fight somehow! They won't be sleeping together tonight, I promise!"
    p "Vittoria, this's not your battle and yet you're so committed to the cause...you're amazing! Thanks for helping me!"
    scene s853 with dissolve
    pt "No way a woman like her is someone's object: she's so strong-willed and confident...Hey asshole, she's not your property! She doesn't belong to you! You can't talk about her as if she were yours!"
    pt "Negotiate? Pfff! What is she? An article?...son of a bitch...real men...fuck you! This's a real woman right here! So independent, so determined...what's the word they use now?...Empowered! God, I hate that word..."
    scene s849 with dissolve
    vi "Hey, [p], wake up! They're leaving...I'm going, ok?"
    stop music fadeout 3.0
menu:
    "Stop her.":
        jump choice59a

    "Let her do it.":
        jump choice59b

label choice59a:
    scene s854 with dissolve
    vi "Getting into character..."
    p "Wait! I can't let you do it."
    scene s855 with dissolve
    p "I don't want you getting into trouble because of me...I really appreciate the fact that you're willing to do this for me, not for my friend you don't even know him... and I can't let you do it..."
    p "You talked about reciprocity earlier, well, you deserve to be filled the same way you pour...If you ever need my help, you can count on me...anytime, Vittoria."
    pt "Man, I'm getting good at saying those things..."
    scene s856 with dissolve
    vi "[p]..."
    p "Yeah?"
    scene s857 with dissolve
    vi "They left."
    p "Shit! I'll be back before four, tell Sami!"
    jump choice59common

label choice59b:
    scene s854 with dissolve
    vi "Getting into character..."
    pt "Yeah, it's better to let her do it...I don't know if Mrs. Lopez would even listen to me, but she's definitely going to listen to Vittoria."
    scene black with dissolve
    play music "audio/beat1.ogg"
    scene s858 with dissolve
    pt "This's is a good spot...let's see."
    scene s859 with dissolve
    pt "I'm nervous..."
    scene s860 with dissolve
    pt "Vittoria's like: \"Who are you?\", \"This is my man, bitch!\""
    scene s861 with dissolve
    pt "Whooaaa, hohohoho, yeah, take that, motherfucker...literally speaking..."
    scene s862 with dissolve
    pt "What?! Mrs. Lopez's defending him?"
    scene s863 with dissolve
    pt "I don't know what's going on..."
    scene s864 with dissolve
    pt "WHAT?! They're leaving together?!"
    play sound "audio/missionfailed.ogg"
    pt "Damn, mission failed..."
    pt "Ha! Game references in my head..."
    scene black with dissolve
    scene s865 with dissolve
    vi "I'm sorry, [p], I couldn't do it..."
    p "It's ok, Vittoria, thanks for trying, you're the best!"
    p "I gotta hurry to catch them...we said this ends today, didn't we?"
    vi "Good luck..."
    pt "Aww, poor Vittoria, she really wanted to help..."
    stop music fadeout 3.0
    jump choice59common

label choice59common:
    scene black with Dissolve(2.0)
    pt "They're heading to the beach..."
    play music "audio/groovetube.ogg"
    scene s866 with dissolve
    pt "Alright, not sure what I'm gonna say, but time to put an end to it. Come on, [p]!"
    p "Mrs. Lopez!"
    scene s867 with dissolve
    mrslo "Oh! [p]! Hi! What are you doing here?"
    p "Chilling...where's Daniel? And Juan?"
    scene s868 with dissolve
    mrslo "Oh, they're near here...buying ice cream..."
    pt "So transparent...I caught her off guard, this's gonna be easy...fuck! Forgot my phone!...Well, she doesn't know it..."
    p "Cool, let me call Daniel, I want to see..."
    scene s869 with dissolve
    mrslo "NO!"
    scene s870 with dissolve
    p "No?"
    mrslo "I mean..."
    pt "She can't even come up with something."
    scene s871 with dissolve
    ma "Hey, boy, I think you're bothering us."
    p "Boy? I'm your student, Mr. Anderson! Or perhaps you only recognize the ones whose mothers you fuck?"
    scene s872 with hpunch
    pt "Daaamn! Now that I said that out loud, I really want to punch his dumb face, it's infuriating! But then she'd probably take his side and wouldn't talk to me..."
    mrslo "Oh my God!"
    ma "Errrr..."
    pt "That asshole's embarrased, must be cheating on his wife too..."
    scene s873 with dissolve
    mrslo "Come with me, [p], we need to talk...I could use a drink..."
    stop music fadeout 3.0
    scene black with Dissolve(1.0)
    scene s874 with dissolve
    ba "Hiiiiii!!!"

if choice58a:
    pt "Not this dude again...forgot his name."
    mrslo "One martini, please!"
    pt "Vittoria likes that too..."
    ba "Right away!"
    scene s875 with dissolve
    ba "And for you, honey bunny?"
    p "What the hell?! I told you yesterday not to call me that, bruh."
    jump gigibar

else:
    mrslo "One martini, please!"
    pt "Vittoria likes that too..."
    ba "Right away!"
    scene s875 with dissolve
    ba "And for you, honey bunny?"
    p "What the hell?! Don't call me that, bruh."
    jump gigibar

label gigibar:

    scene s876 with dissolve
    ba "I'm not a \"bruh\", I'm a woman!"
    p "Riiiight...not going there today...a martini for me, too."
    scene black with dissolve
    play music "audio/beat7.ogg"
    scene s877 with dissolve
    mrslo "How'd you find out?"
    pt "Good start, she's not denying it..."
    p "It's not like you're hiding: you're kissing and holding hands in public...Did you...want to get caught?"
    mrslo "I don't know..."
    p "I'm sorry to tell you this, but...Juan's a good man..."
    scene s878 with dissolve
    mrslo "Don't you think I know that?!"

if choice58b:
    pt "What the fuck am I doing? I'm such a hypocrite...I did the same to S..."
    jump hypo

label hypo:
    p "I'm sorry...I...I don't know what you're going through..."
    scene s879 with dissolve
    mrslo "It doesn't matter what I'm going through, I'm not the victim here, [p]...I know I'm doing a terrible thing to my family and I'm not running away from my responsibility..."
    ba "Martinis."
    scene s880 with dissolve
    mrslo "Thank you, honey."
    scene s881 with dissolve
    pause 1
    scene s882 with dissolve
    mrslo "Give me another one, please darling."
    scene s883 with dissolve
    mrslo "You wonder why I did it? I wanted to put myself first at least for once...I'm being selfish, I admit that, but I was so bored, couldn't take it anymore, [p]..."
    mrslo "Every time I talked to my husband about what was bothering me, you know what he said: \"Woman, you don't know how to be happy.\""
    scene s884 with dissolve
    mrslo "That got me so angry! You have no idea...He's supposed to be my husband, my partner! I wanted to share my problems with him, but he got mad and we just got into arguments..."
    mrslo "He should've cared about what his wife was going through, not say: \"You don't know how to be happy.\""
    scene s885 with dissolve
    mrslo "Oh, Lord, that was exhausting! Everything was perfect in Juan's mind, well...not to me! Nothing exciting happened for years! A spark was missing in my marriage, not only in my marriage, in my life!"
    p "Well..."
    scene s886 with dissolve
    mrslo "And why Daniel's teacher? You must be wondering, right? We went to school together, you know? And he always liked me so...it was convenient and easy."
    mrslo "I thought things would be...different...exciting since he could finally have me, you know? But..."
    scene s887 with dissolve
    mrslo "I've doubled my trouble: Paul's such a wimp, so needy...I wanted to end this affair last week, but he started crying when I told him I didn't want to see him anymore..."
    mrslo "And I'm sure he'd show up at my house if I leave him...Gosh, I don't know what to do...I'm stucked in the middle of two unhappy relationships...no one to blame but me..."
    pt "I've never seen this side of Mrs. Lopez, it's pretty much like talking to Metal..."
    pt "I didn't have to ask anything...she probably just needed to be listened to..."
    ba "Martini."
    scene s880 with dissolve
    mrslo "Thank you, honey."
    p "Daniel told me you didn't drink..."
    scene s888 with dissolve
    mrslo "Yeah, but with all this going on, I needed something to help me relax...I kind of enjoy it now."
    scene s889 with dissolve
    p "I see...listen Mrs. Lopez..."
    scene s890 with dissolve
    p "There's nothing wrong with having an inner conflict and wanting to start over if life isn't what we expected...everybody wants to feel good, be happy, I get that..."
    scene s891 with dissolve
    p "I'm not here to lecture you, I'm nobody to tell you what to do with your life..."
    p "And I really appreciate you being honest with me and, in the same way, I wanna be honest with you: I can't cover up for you..."
    scene s892 with dissolve
    p "Daniel's my friend and I wouldn't like to hide this from him...that being said, I'm not a snitch either..."
    scene s893 with dissolve
    p "So here's the deal: you end whatever this is you have with Mr. Anderson TODAY and I won't tell Daniel what I saw."
    scene s894 with dissolve
    mrslo "I'm not sure I can do it today, [p]...I'm going to need more time..."
    p "You said it yourself: you want nothing to do with this guy anymore...And you also said you'd deal with the consequences of your actions..."
    mrslo "I know, but...give me a week, I have to think thoroughly how I'm going to do it. I know you owe your loyalty to my son and I love it really: I'm glad my son found friends like you, like Candy..."
    scene s895 with dissolve
    p "Mrs. Lopez, I don't want to tell on you, you've always been great to me. To be honest, I'm shocked by this whole situation...in my mind, you're the sweetest person ever, you'll always be...so out of respect, I had to talk to you first."
    scene s896 with dissolve
    mrslo "Oh, darling, I'm grateful you did...that was very mature. At your age, I would've told my best friend instead of talking to her mom...Come here, honey, give me a hug!"
    scene s897 with dissolve
    pt "Nice..."
    mrslo "Are you looking at my boobs?"
    pt "How can I not?"
    p "Nope, not really...I'm just...uhm..."
    scene s898 with dissolve
    mrslo "[p]...do you...do you find a woman like me...attractive?"
    p "What do you mean \"like you\"?"
    scene s899 with dissolve
    mrslo "I don't know...old I guess..."
    pt "Old? Nah...it seems that she lacks confidence...perhaps that's why she ended up with Juan, I've always thought she was too pretty for him..."
    pt "I didn't know she was this insecure though...yeah, that must be it, low self-steem: Juan, Mr. Anderson...she could do so much better..."
    scene s900 with dissolve
    p "I think you're a beautiful woman, Mrs. Lopez."
    scene s901 with dissolve
    mrslo "Thank you, darling! And you can call me Brenda, I don't like the sound of \"Mrs. Lopez\" all the time, makes me feel old..."
    scene s902 with dissolve
    br "I remember you used to be the most polite and respectful kid in the neighborhood, and now you've become this fine young gentleman...You kids grow so fast..."
    p "That's true, time flies...anyway, you said you needed a week, right?"
    scene s903 with dissolve
    br "Yes, darling, I really want to end to this...I promise I'll do it this week."
    p "I'm sure you will...Look, I gotta go now, we'll talk again soon..."
    scene s902 with dissolve
    br "Yes, sweety, stop by the house next week..."
    p "I will! Bye, Brenda."
    stop music fadeout 2.5
    scene black with Dissolve(2.5)
    scene s904 with dissolve
    pt "Looks like Vittoria's sunbathing..."
    play music "audio/sexback.ogg"

    scene s905:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Man, she's a Goddess..."
    scene s906 with dissolve
    p "Hey, Vittoria..."
    vi "Oh, hi [p]! Glad you're back! How'd it go?"
    p "They're done!"
    vi "Yes! You did it!"
    p "We did! If it hadn't been for you, I wouldn't have done anything..."
    scene s907 with dissolve
    vi "I did nothing, honey...you give me too much credit..."
    p "No, seriously, you gave me the courage to actually do something, thank you! And Vittoria...where is everybody?"
    scene s908 with dissolve
    vi "Giuseppe took the girls shopping...\"for doing so well at college\", he said...he loves to spoil them."
    pt "I see...this is too convenient, they left us alone...he's doing it on purpose, no doubt..."
    p "Why didn't you go?"
    vi "I'm not in the mood to walk again, I'd rather relax, sunbathe. Oh, honey, you left your phone in the living room...Sammy was calling you to go with them, that's when she noticed..."
    p "Oh, ok...I'll go check and text her back."
    scene s909 with dissolve
    vi "There's food in the kitchen if you're hungry..."
    p "Thanks! And you? Do you need anything?"
    vi "I'm good, thank you, [p]."
    stop music fadeout 3.0
    scene black with dissolve
    scene s910 with dissolve
    pt "She sent me a message:  {i}\"Let me know when you're back, cat!\"{/i}...Ok, we're leaving in a couple of hours...better make the most of this time..."

menu:
    "Text her.":
        jump choice60a

    "Don't.":
        jump choice60b

label choice60a:
    pt "{i}\"I'm already here! Where are you?\"{/i}"
    pt "I'm sure she'll be back in no time..."
    scene black with dissolve
    scene s911 with dissolve
    sa "Baby, I missed you! Mom told me you ran into your friend at the beach..."
    p "Yeah, she wanted to talk with me..."
    scene s912 with dissolve
    p "What did you buy, babe?"
    sa "Dresses and shoes...the bags are in the car..."
    scene s913 with dissolve
    ub "Come here, [p], I want to talk to you..."
    sa "What is it?"
    ub "Just come here."
    scene black with dissolve
    play music "audio/gangstarap.ogg"
    scene s914 with dissolve
    ub "Are you stupid?"
    p "What?!"
    ub "I took the girls to the mall and you call my daughter to come back?...Are you stupid?"
    pt "I knew it...This bastard left us alone on purpose...who's the stupid one? This dude's a cuck...less of a man..."
    p "If I'm stupid, you're a cuck."
    scene s915 with dissolve
    cuc "Ha...watch your mouth, kid, you don't want me as your enemy."
    pt "You have nothing on me..."
    scene s916 with dissolve
    p "Fuck you, man. I'm getting real ti..."
    scene s917 with dissolve
    sa "Hey, what's going on here?"
    cuc "Nothing, honey, I'm just telling [p] not to get lost like that, we wanted to spend time with him before leaving..."
    sa "It's ok, dad, no biggie, we see each other almost every day at college."
    scene s918 with dissolve
    cuc "And he can come back here anytime! He's family!"
    scene s919 with dissolve
    cuc "But right now, it's time to hit the road...tell your mom we're leaving in about 20 minutes, honey."
    sa "Ok, dad...yeah, Chris wanted to go back too."
    pt "Everything's wrong with this guy..."
    stop music fadeout 3.0
    jump choice60common

label choice60b:
    pt "No need to call her, she'll be back sooner or later..."
    scene black with dissolve
    play music "audio/197.ogg"
    scene s920 with dissolve
    pt "Vittoria told me she didn't need anything...she's having a great time on her own, doesn't want to be bothered...and I'm not in the mood to talk..."
    pt "Maybe I can improve my swimming a little bit..."
    scene s921 with dissolve
    vi "[p], are you gonna need any help?"
    p "Only if I drown."
    vi "Don't joke like that!"
    pt "That's right! I can pretend to be drowning..."
    scene s922 with dissolve
    pt "This's nice, but no time to waste, let's drown already!"
    scene s923 with dissolve
    vi "Oh my God, [p]!"
    scene s924 with dissolve
    pt "Hehe, I'm a horrible human being..."
    scene s925 with dissolve
    vi "I got you, [p], I got you!"
    pt "I didn't think this through...what now?"
    scene s926 with dissolve
    vi "[p]! Stay with me!"
    pt "Man, I'm taking things too far...I don't have the heart to keep doing this..."
    scene s927 with dissolve
    p "What happened?"
    vi "Oh my God, [p], you blacked out."
    scene s928 with dissolve
    vi "You got me so scared..."
    pt "Damn, she's about to cry..."
    p "I'm sorry, I'm sorry, didn't mean to worry you...I'm ok now..."
    vi "You sure?"
    p "Yeah, no need to worry anymore, come here..."
    scene s929 with dissolve
    p "You just saved my life, Vittoria. I'll never be able to thank you enough..."
    vi "Don't say that...if something had happened to you, I would've never forgiven myself."
    p "I'm alive, thanks to you! How could I repay you?"
    scene s930 with dissolve
    pt "She's so close..."
    vi "I feel guilty for not paying attention when you started swimming..."
    pt "Guilty? Oh! It's the kind of guilt S felt when I bought her the guitar...S! What am I thinking?! She's Samantha's mom!"
    p "Guilty? How can you say that?! There's no reason to feel guilty...You're a true heroine in my book, Vittoria!"
    scene s931 with dissolve
    pt "Man, she's just as adorable as S is...I feel like an asshole for making her feel that way..."
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene s932 with dissolve
    ub "I see you were having fun in the pool."
    pt "That's what you wanted...What a cuckold...I'll let him think we got a deal, but when the time comes, I won't do shit for him..."
    sa "Hi, baby! I missed you!"
    p "Same here, babe."
    vi "[p] wanted to improve his swimming skills so I help him out..."
    pt "She's not saying anything about me almost drowning...she doesn't want to worry S unnecessarily...Vittoria's just great!"
    scene s933 with dissolve
    cs "Sorry to interrump, but before you start making plans...I'm not feeling well, can we leave? I want to sleep and if I do it here we'll get stuck in traffic later...besides, I have an exam tomorrow morning."
    vi "Sure, darling, we're leaving within 15 minutes, is that ok? Everybody, get ready."
    jump choice60common

label choice60common:
    scene black with Dissolve(2.5)
    scene s934 with dissolve
    p "Bye! Thank you for everything!"
    sa "See you tomorrow, cat!"
    vi "Bye, darling! Say hi to your mom."
    play music "audio/newmarch.ogg"
    scene black with dissolve
    scene s935 with dissolve
    p "Hey, Franz!"
    scene s936 with dissolve
    fz "Hey, brother!"
    mm "Hi, son, did you have fun at the beach?"
    p "Yeah, mom, I had a great time there!"
    scene s937 with dissolve
    fz "What's up with the shirt and that purple suitcase?"
    p "Just some clothes my girlfriend's dad gave me."
    scene s938 with dissolve
    mm "Boys, I'm going to see Amanda, ok? I'm running late...And you don't get lost, you hear me?"
    fz "Haha, I hear you, mom, loud and clear...say hi to Amanda."
    scene s939 with dissolve
    mm "Come visit your mother more often...Love you, son."
    fz "I will. Love you, too."
    scene black with Dissolve(1.5)
    scene s940 with dissolve
    fz "So how you doing?"
    p "Can't complain, life's good...you? How's work?"
    fz "Boring...and your girl? Samantha, right?"
    p "Yeah, you remembered! If you showed up more often, I could introduce her to you...or perhaps we could have a double date!"
    scene s941 with dissolve
    fz "Not happening...I broke up with Amelia last week..."
    p "You what?! You've been together since high school! How did that happen?! Did you cheat on her?"
    scene s942 with dissolve
    fz "No, it was nothing like that...There's something I have to do and I need to be alone to get it done...that's what happens when you have a purpose."
    p "What purpose? I don't understand."
    fz "Let me put it this way: I have a purpose bigger than my relationship with Amelia."
    p "Man, that's cold...she loves you so much...wasn't she your happy place?"
    scene s944 with dissolve
    fz "That doesn't matter...when you're really into something, being happy is the least important thing, brother. When you have a purpose, you're ready to suffer for it, even risk your life for it..."
    fz "Purpose outweighs everything, happiness included."
    p "You got excited right there...talking like a martyr."
    scene s943 with dissolve
    fz "Maybe I am one..."
    p "That's your dream, isn't it? You've always wanted to be a hero..."
    fz "Listen, I gotta go now, I'll call you next week, ok?"
    p "Ok."
    stop music fadeout 3.0
    scene s945 with dissolve
    fz "Come here, take care of our mother, ok? I love you."
    p "I know."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    play music "audio/reggaerap.ogg"
    scene s955 with dissolve
    p "Have you talked to Metal recently?"
    cd "I saw him yesterday at college, but we couldn't talk, he was late for class, why?"
    p "He's not attending Business class lately."
    cd "Oh, yeah, he mentioned something about a girl in that class he doesn't want to see anymore..."
    p "Really?"
    scene s956 with dissolve
    cd "Yeah, he also said you and that girl have become close..."
    p "What?"
    cd "You know how he is...always exaggerating everything..."
    p "And he gets mad if you don't believe him, doesn't he?"
    scene s957 with dissolve
    play sound "audio/phonevibe.ogg"
    cd "Haha, exactly."
    scene s958 with dissolve
    p "Hold on a sec..."

    e_nvl "{size=-5}Yo, nigga, tmw 9 am at the club!{/size}"
    n_nvl "{size=-5}What's up? Don't tell me...{/size}"
    e_nvl "{size=-5}Yeah, you owe me big time! Rob wants to see you play tomorrow!!!{/size}"
    show s960
    n_nvl "{size=-5}Dude, for real?!{/size}"
    e_nvl "{size=-5}You're my boy, can't let your talent go to waste...hope u ready.{/size}"
    n_nvl "{size=-5}Class is permanent, bro...{/size}"
    e_nvl "{size=-5}Haha, u nervous?{/size}"
    n_nvl "{size=-5}Not at all, brother...I've been training for this. I'm very excited...{/size}"
    e_nvl "{size=-5}Don't let me down, nigga!{/size}"
    show s959
    n_nvl "{size=-5}I won't, brother.{/size}"
    e_nvl "{size=-5}Ttyl.{/size}"
    n_nvl "{size=-5}K.{/size}"

label tryout:
    show s959
    pt "I can't believe it, this's the moment I've been waiting for..."
    cd "Aren't you going to tell me?"
    scene s961 with dissolve
    cd "What is it?"
    p "I forgot to tell you, bro: I met Rob Davies last Saturday!"
    scene s962 with dissolve
    cd "Whoa, whoa, hold your horses right there! How did that happen?! How come you didn't tell me?!"
    p "I've had so many things in my head, sorry sis...but listen: tomorrow at 9 am, I'm going to City FC for a tryout in front of him!"
    scene s963 with dissolve
    cd "Oh my god! I'm so happy for you! I'm going with you! You're gonna have to take me!"
    p "Of course, sis, I want you and S there!"
    scene s964 with dissolve
    cd "Oh..."
    scene s965 with dissolve
    cd "Great!"
    p "Haha, what a hypocritical smile, brother!"
    cd "I'm not faking it, this's 100 percent real..."
    p "Haha."
    scene s966 with dissolve
    sh "Hi, [p]!"
    p "Hi, Sharon."
    scene s967 with dissolve
    sh "Ready to go?"
    cd "Go where?"
    scene s968 with dissolve
    sh "To the mall, did you forget?"
    scene s969 with dissolve
    cd "Shit! Sorry, mom, it completely slipped my mind...I haven't finished an essay that's due tomorrow..."
    sh "I can never make plans with you, Candace..."
    stop music fadeout 3.0

menu:
    "Tell her you can go.":
        jump choice61a

    "Nah, I need to rest for tomorrow.":
        jump choice61b

label choice61b:
    sh "I'll just call a friend..."
    scene s970 with dissolve
    sh "Nice seeing you, [p]."
    cd "Mom..."
    p "Same here, Sharon."
    cd "Mom!"
    scene s971 with dissolve
    cd "I'm going to talk to her before she leaves...You pick me up tomorrow?"
    p "Yes, sis, at 8. I don't want to be late."
    scene s972 with dissolve
    cd "Okay...Love you!"
    p "Love you too."
    scene s973 with dissolve
    p "Whoooaa, haha, sorry sis, my son Argos won!"
    jump tryout1

label choice61a:
    scene s974 with dissolve
    p "I can go with you, Sharon, if you want."
    scene s975 with dissolve
    sh "You really want to go, [p]?"
    cd "Huh? Why would you want to go?"
    p "I don't know...I don't want Sharon to go alone, that's all."
    cd "And don't call her Sharon."
    scene s976 with dissolve
    sh "Don't listen to Candy...Let's go!"
    p "What, now? Ok."
    scene s977 with dissolve
    p "Tomorrow...8 am. Be ready!"
    scene black with Dissolve(2.0)

    play music "audio/po.ogg"
    scene s978 with dissolve
    p "Oh, this's the store you wanted to come..."
    sh "Yeah, and now that I think of it, it was a good idea you came with me and not Candy: I need a man's opinion."
    p "You're going on a date or something?"
    scene s979 with dissolve
    sh "Yes, I downloaded a dating app a month ago and met one interesting guy...this is our third date..."
    p "Time to show him your new lingerie?"
    sh "Third time's a charm, isn't it? Let me look around."
    scene s980 with dissolve
    sh "Brenda? Is that you?"
    scene s981:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    br "Hi, Sharon!"
    sh "Look at you! You look stunning tonight! What's the plan?"
    br "Going out with Juan...I want to give him a surprise later..."
    sh "Spicing things up, huh?"
    p "Hello, Brenda, you look beautiful!"
    sh "She does, doesn't she?"
    scene s982 with dissolve
    sh "Wait a minute...did you just call her \"Brenda\"?"
    p "I did, yeah..."
    sh "I thought that was our thing!"
    p "Our thing?! Calling someone by their first name's a \"thing\" now?"
    br "Haha, he's still adorable when he's nervous..."
    sh "Yeah, it's kind of flattering to know we can make men his age feel nervous, don't you think?"
    br "You can say that again...it's refreshing."
    pt "Man, I suddenly feel intimidated by these two beautiful mature women..."
    scene s983 with dissolve
    se "Excuse me, may I help you?"
    br "We're just looking around, honey..."
    scene s984 with dissolve
    sh "Actually, yes, you can help me...by any chance, do you..."
    scene s985 with dissolve
    br "[p]...I want you to know that I did it..."
    p "You mean..."
    br "Yes."
    p "How'd it go?"
    br "I told him I wanted to give my marriage one last chance and, surprisingly, he was very understanding about it, he just accepted it..."
    p "Just like that? You said he was going to cry, make a scene, even go to your house..."
    scene s986 with dissolve
    br "I know, I thought so, yes, but I guess I was wrong..."
    pt "That's weird...is she lying?"
    scene s987 with dissolve
    br "And [p], I also wanted to thank you for keeping this between us, it's so satisfying to have someone you can share a secret with...you're incredible..."
    p "I'm not, I just want to see you well..."
    scene s988 with dissolve
    p "I mean you...and Daniel...and Juan..."
    scene s989 with dissolve
    sh "Brenda! Come here! This one would look good on you!"
    br "Coming!"
    stop music fadeout 3.0
    scene black with Dissolve(1.0)

    scene s990 with dissolve
    sh "[p]! We're here, we need you!"
    pt "Yes!"
    p "Coming."
    scene s991 with dissolve
    p "Where are you?"
    sh "Here, it's open."
    scene s992 with dissolve
    pt "There she is...this's gonna be good..."
    scene s993 with dissolve
    sh "Hey, [p]..."
    scene s994 with dissolve
    sh "What do you think?"

    play music "audio/sensual3.ogg"

    scene s995:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Man, I've seen her several times wearing bikinis, but this's somehow different...hotter? Yeah, hotter..."
    p "I don't know what to say, Sharon..."
    sh "Ha, no need to, your face says it all...but I'm not so sure about the back..."
    scene s996:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    sh "Doesn't it look like something a granny would wear? Something smaller would be better I think..."
    p "Well, I don't think my grandma would wear that, but I get what you..."
    br "Sharon! You're shameless! Leave him alone."
    pt "Please, don't!"
    scene s997 with dissolve
    sh "What's wrong, Brenda? [p]'s seen us wearing bikinis at the beach before, how's this different?"
    pt "My thoughts exactly!"
    br "He's not a kid anymore, that's the difference...He's all grown up now and...it's embarrasing..."
    sh "Don't be so insecure, woman, we need a man's opinion...you look gorgeous! He'll tell you the same..."
    br "I don't know..."
    scene s998 with dissolve
    sh "Come in, [p], tell her what you think..."
    br "Sharon..."
    pt "Oh, I'm going in! Not giving you a chance to change your mind...let's see..."
    scene s999 with hpunch
    br "Hey, [p]."
    pt "Wow!"
    scene s1000:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    br "And?"
    p "I have to agree with Sharon: you look amazing, Brenda!"
    sh "Told you."
    scene s1001 with dissolve
    sh "Look at him! That's the kind of reaction you're going to get from your husband. If this doesn't bring the spark back into your relationship, I don't know what will. Right, [p]?"
    scene s1002 with dissolve
    p "Oh yeah, definitely! I'm sure this will work!"
    scene s1001 with dissolve
    sh "See, Brenda? As you said, he's not a kid anymore...trust him!"
    scene s1002 with dissolve
    p "Uuuhm, is it me or it's getting hot in here?"
    scene s1003 with dissolve
    sh "Hahaha...Oh, I love you, [p]...you're just too sincere sometimes...give us some minutes, but don't go too far!"
    p "Why? There's more?"
    sh "Of course there is!"
    scene black with Dissolve(1.5)
    sh "[p], are you there?"
    p "I'm right here!"
    scene s1004:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    sh "I like this one better. It's sexier, don't you think?"
    p "Yes! It fits you like a glove, Sharon!"
    scene s1005 with dissolve
    sh "Haha, wait 'till you see Brenda, you're going to pass out!"
    pt "Sssss, that's a fine ass! And you said Brenda looks hotter? Pfff, I'm such a lucky sob..."
    scene s1006 with dissolve
    br "Is this too revealing, [p]?"
    scene s1007:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Fuck! I'm getting hard..."
    pt "What I would give to see her back..."
    pt "Do not push your luck..."
    br "[p]?"
    p "I'm just gonna say one thing: Juan is a very fortunate man. That's it, I said it, sorry, I'm not gonna say anything else...I'm out."
    sh "Hahaha."
    scene s1008 with dissolve
    br "You're so sweet..."
    sh "I wouldn't say \"sweet\" is the right word..."
    scene s1009 with dissolve
    sh "Now go wait outside."
    stop music fadeout 3.0
    scene black with Dissolve(1.0)
    scene s1010 with dissolve
    sh "Bye, Brenda! Go wild with Juan! Hahaha."
    br "Jesus, Sharon..."
    scene black with Dissolve(1.5)
    scene s1011 with dissolve
    sh "And here we are...thanks for your help!"
    p "Don't mention it...I wouldn't mind doing it again, hehe."
    sh "I'm sure you wouldn't..."
    scene s1012 with dissolve
    sh "[p], quick question...do you have a thing for older women?"
    p "Uuuhm, I don't know...I like women. Why you ask?"
    sh "It'd make perfect sense why you never asked my Candy out."
    p "I already told you I don't see her that way..."
    scene s1011 with dissolve
    sh "What way? The way you looked at Brenda and me? Hahaha."
    p "Hey, that's not fair...any man would appreciate a view like that!"
    sh "Haha, say hi to Elizabeth!"
    p "I will."
    jump tryout1

label tryout1:
    scene black with Dissolve(3.0)
    play music "audio/phonk.ogg"
    scene s1013 with dissolve
    pt "Today's the day! Man, I'm so excited! I'm feeling very confident...\"Hard training, easy game\"...You got this, [p]!"
    scene black with Dissolve(1.0)
    scene s1014 with dissolve
    sa "Woooow! I've never been to a stadium before, this's huge!"
    cd "Imagine it with 50 000 people."
    p "That'd be a dream come true..."
    scene s1015 with dissolve
    p "You can sit here or go higher for a better view if you want...Here, babe, hold my stuff, please, I'm gonna warm up a little before it starts..."
    scene s1016 with dissolve
    sa "Good luck, baby, remember: this's what you've been training for!"
    cd "Show them what you got, brother!"
    scene black with dissolve
    scene s1017 with dissolve
    pt "Can't fail today...I won't! It suddenly feels like the rest of my life depends on how I do today..."
    scene s1018 with dissolve
    pt "I can feel it...this's where I belong!"
    play sound "audio/silbatostart.ogg"
    scene black with Dissolve(2.5)
    scene s1019 with dissolve
    rd "Robinson! This's my boy I was telling you about..."
    coa "Blanco? I thought you retired from football...the club contacted your family a while ago and they said you couldn't play no more..."
    pt "Damn, mom...at least tell me about it...well, it's true I didn't want to talk to anybody when I got injured..."
    p "Yes, coach, that's what the doctors said, but here I am...I've been training on my own just to make it back into the team..."
    coa "I see..."
    scene s1020 with dissolve
    coa "I completely understand why you vouched for him, Rob, if he's still half the player he used to be I want him...I don't need to see him in a long match..."
    scene s1021 with dissolve
    coa "Can you still dribble and score?"
    p "Absolutely, coach!"
    pt "Yes! This's gonna be easy...if I have to dribble past my former teammates, I can definitely do it!"
    scene s1022 with dissolve
    rd "I've only heard good things about you, don't let me down, kid...when I retire, I'm thinking of becoming an agent, just to let you know, haha."
    p "I'll give you a call, haha! Hey, Rob, thanks for the opportunity!"
    coa "Johnson, Arthur, everybody out! Ethan, Kalvin, come here!"
    scene s1023 with dissolve
    rd "Wait a minute...is he calling The Phillipses?"
    scene s1024 with dissolve
    cj "Yo, nigga, what's good?"
    p "Hey, bro."
    rd "Yes, you're facing them..."
    p "Who?"
    scene s1025 with dissolve
    rd "The Phillips Brothers...and he's telling them not to go easy on you."
    cj "You're gonna face them? That's not fair!"
    p "Why? Who are they?"
    cj "The Academy's young talents soon to go pro..."
    scene s1026 with dissolve
    rd "I've been told Kalvin was the best defender in the past Youth League, he's called \"The Dog of War\"...wasn't dribbled past in the entire season, not even once! Very strong player...and he's only 17!"
    p "That beast is 17?!"
    scene s1027 with dissolve
    cj "And don't forget his 16 year-old brother, the real talent in the family: Ethan \"Poker Face\" Phillips, MVP of the last two tournaments..."
    p "Wow! That's impressive for a goalkeeper...is he...is he pointing at me?"
    cj "He is...nigga, he's unbeaten in over 100 official games!"
    p "One hundred games?! You gotta be kidding me! That's like what...2 years?!"
    cj "Yeah...sure he has conceded some goals during trainings, but his official record's just ridiculous."
    p "Wait a second, I kind of remember a kid with a crazy record like that...50 games or so...but he was way shorter than this guy..."
    cj "Dude, that's him!"
    p "For real? Damn...hey, you remember that kid was challenging all of us to take penalty kicks?"
    scene s1028 with dissolve
    cj "Yeah..."
    p "And you took his challenge..."
    scene s1029 with dissolve
    cj "Yes..."
    p "He saved it and you lost 100 do..."
    scene s1030 with vpunch
    cj "YES!"
    scene s1031 with dissolve
    coa "Blanco, come here!"
    rd "Good luck, [p]!"
    cj "You're gonna need it..."
    scene black with dissolve
    stop music fadeout 3.0
    scene s1032 with dissolve
    p "Tell me, coach..."
    coa "I'll be a hundred percent honest with you, kid: I don't care if you got injured, depressed, lost, whatever...I liked your work ethics, not to mention your talent...that's why you're getting this chance, not because of Rob..."
    coa "But you've been gone for a year, can you imagine what my players would think if I just welcome you back into the team?"
    p "I wouldn't like to be given away a spot, coach. You've always rewarded hard work: \"The one who trains the hardest, plays.\""
    scene s1033 with dissolve
    coa "That's right. Not gonna lie to you: these two are something else, elite players, younger than you and real monsters..."
    coa "Can you compete at their level? I want to win the National Championship this year...I would've already if Johnson hadn't missed so many chances last season...I need goals!"
    scene s1034 with dissolve
    coa "Score...if you can score, you're back in. That's all. Go!"
    scene black with dissolve
    play music "audio/rockfut.ogg"
    scene s1035 with dissolve
    pt "Coach Robinson's always been fair...he's right: I need to show everybody I deserve to be back and this is the best way to do that: facing the best!"
    pt "This dude sure is imposing, but looks heavy, slow..."
    scene s1036 with dissolve
    rd "Ooohhh, that first touch with the outside of the foot...that's how you recognize a good player."
    scene s1037 with dissolve
    cj "Kalvin knows it, look at him! He's very excited to face [p]!"
    scene s1038 with dissolve
    pt "Yes, come for me! Show me what you got...\"Dog of War\" my balls!"
    scene s1039 with dissolve
    play sound "audio/versussound.ogg"
    scene s1039a with Dissolve(0.022)
    scene s1039b with Dissolve(0.022)
    scene s1039c with Dissolve(0.022)
    scene s1039d with Dissolve(0.022)
    scene s1039e with Dissolve(0.022)
    scene s1039f with Dissolve(0.022)
    scene s1039g with Dissolve(0.022)
    scene s1039h with Dissolve(0.022)
    scene s1039i with Dissolve(0.022)
    scene s1039j with Dissolve(0.022)
    scene s1039k with Dissolve(0.022)
    scene s1039l with Dissolve(0.022)
    scene s1039m with hpunch
    play sound "audio/versussound.ogg"
    scene s1040 with Dissolve(0.022)
    scene s1040a with Dissolve(0.022)
    scene s1040b with Dissolve(0.022)
    scene s1040c with Dissolve(0.022)
    scene s1040d with Dissolve(0.022)
    scene s1040e with Dissolve(0.022)
    scene s1040f with Dissolve(0.022)
    scene s1040g with Dissolve(0.022)
    scene s1040h with Dissolve(0.022)
    scene s1040i with Dissolve(0.022)
    scene s1040j with vpunch
    play sound "audio/versussound.ogg"
    scene s1041 with Dissolve(0.0133)
    scene s1041a with Dissolve(0.0133)
    scene s1041b with Dissolve(0.0133)
    scene s1041c with Dissolve(0.0133)
    scene s1041d with Dissolve(0.0133)
    scene s1041e with Dissolve(0.0133)
    scene s1041f with Dissolve(0.0133)
    scene s1041g with Dissolve(0.0133)
    scene s1041h with Dissolve(0.0133)
    scene s1041i with Dissolve(0.0133)
    scene s1041j with Dissolve(0.0133)
    scene s1041k with Dissolve(0.0133)
    scene s1041l with Dissolve(0.0133)
    scene s1041m with Dissolve(0.0133)
    scene s1041n with hpunch
    play sound "audio/fightmk.ogg"
    scene s1041n with dissolve
    scene s1042 with vpunch
    pause
    scene s1094 with dissolve
    pt "Good positioning, forcing me into my right foot...you think it's my weak foot, huh? Sure, it used to be..."

    menu:
        "Do a Classic Stepover.":
            scene s1043 with dissolve
            pt "I'm sure I'm faster..."
            scene Stepover with Dissolve(0.333)
            pause
            pt "Too fast for you?"
            scene s1043:
                pause 0.0166
                "s1044"
                pause 0.0166
                "s1045"
                pause 0.0166
                "s1046"
                pause 0.0166
                "s1047"
                pause 0.0166
                "s1048"
                pause 0.0166
                "s1049"
                pause 0.0166
                "s1050"
                pause 0.0166
                "s1051"
                pause 0.0166
                "s1052"
                pause 0.0166
                "s1053"
                pause 0.0166
                "s1054"
                pause 0.0166
                "s1055"
                pause 0.0166
                "s1056"
                pause 0.0166
                "s1057"
                pause 0.0166
                "s1058"
                pause 0.0166
                "s1059"
                pause 0.0166
                "s1060"
                pause 0.0166
                "s1061"
                pause 0.0166
                "s1062"
                pause 0.0166
                "s1063"
                pause 0.0166
                "s1064"
                pause 0.0166
                "s1065"
                pause 0.0166
                "s1066"
                pause 0.0166
                "s1067"
                pause 0.0166
                "s1068"
                pause 0.0166
                "s1069"
                pause 0.0166
                "s1070"
                pause 0.0166
                "s1071"
                pause 0.0166
                "s1072"
                pause 0.0166
                "s1073"
                pause 0.0166
                "s1074"
                pause 0.0166
                "s1075"
                pause 0.0166
                "s1076"
                pause 0.0166
                "s1077"
                pause 0.0166
                "s1078"
                pause 0.0166
                "s1079"
                pause 0.0166
                "s1080"
                pause 0.0166
                "s1081"
                pause 0.0166
                "s1082"
                pause 0.0166
                "s1083"
                pause 0.0166
                "s1084"
                pause 0.0166
                "s1085"
                pause 0.0166
                "s1086"
                pause 0.0166
                "s1087"
                pause 0.0166
                "s1088"
                pause 0.0166
                "s1089"
                pause 0.0166
                "s1090"
                pause 0.0166
                "s1091"
                pause 0.0166
                "s1092"
                pause 0.0166
                "s1093"
                pause 0.0166
            pause
            p "So long, Phillips!"
            jump wontpass

        "Do The Elastico.":
            scene s1094:
                pause 0.0166
                "s1095"
                pause 0.0166
                "s1096"
                pause 0.0166
                "s1097"
                pause 0.0166
                "s1098"
                pause 0.0166
                "s1099"
                pause 0.0166
                "s1100"
                pause 0.0166
                "s1101"
                pause 0.0166
                "s1102"
                pause 0.0166
                "s1103"
                pause 0.0166
                "s1104"
                pause 0.0166
                "s1105"
                pause 0.0166
                "s1106"
                pause 0.0166
                "s1107"
                pause 0.0166
                "s1108"
                pause 0.0166
                "s1109"
                pause 0.0166
                "s1110"
                pause 0.0166
                "s1111"
                pause 0.0166
                "s1112"
                pause 0.0166
                "s1113"
                pause 0.0166
                "s1114"
                pause 0.0166
                "s1115"
                pause 0.0166
                "s1116"
                pause 0.0166
                "s1117"
                pause 0.0166
                "s1118"
                pause 0.0166
                "s1119"
                pause 0.0166
                "s1120"
                pause 0.0166
                "s1121"
                pause 0.0166
                "s1122"
                pause 0.0166
                "s1123"
                pause 0.0166
                "s1124"
                pause 0.0166
                "s1125"
                pause 0.0166
                "s1126"
                pause 0.0166
                "s1127"
                pause 0.0166
                "s1128"
                pause 0.0166
                "s1129"
                pause 0.0166
                "s1130"
                pause 0.0166
                "s1131"
                pause 0.0166
                "s1132"
                pause 0.0166
                "s1133"
                pause 0.0166
                "s1134"
                pause 0.0166
            pause
            rd "Sweeeeeet! What a trick!"
            p "Ciao, Phillips!"
            jump wontpass

label wontpass:

    scene s1135 with dissolve
    kp "You're not going anywhere!"
    scene s1136 with hpunch
    pt "Shit! I thought I'd lost him...this dude's not only strong, but also fast..."
    scene s1137 with dissolve
    kp "You can't beat me!"
    p "We'll see about that."
    kp "Try as much as you want, Blanco."
    scene black with dissolve
    scene s1043 with dissolve
    pt "I'll try something different this time..."

    menu:
        "Do a Classic Stepover.":

            scene Stepover with Dissolve(0.333)
            pause
            pt "He didn't buy that feint, it's too simple..."
            jump wontpass1

        "Do The Elastico.":
            scene s1094 with dissolve
            pt "I'll show you what I got!"
            scene s1094:
                pause 0.0166
                "s1095"
                pause 0.0166
                "s1096"
                pause 0.0166
                "s1097"
                pause 0.0166
                "s1098"
                pause 0.0166
                "s1099"
                pause 0.0166
                "s1100"
                pause 0.0166
                "s1101"
                pause 0.0166
                "s1102"
                pause 0.0166
                "s1103"
                pause 0.0166
                "s1104"
                pause 0.0166
                "s1105"
                pause 0.0166
                "s1106"
                pause 0.0166
                "s1107"
                pause 0.0166
                "s1108"
                pause 0.0166
                "s1109"
                pause 0.0166
                "s1110"
                pause 0.0166
                "s1111"
                pause 0.0166
                "s1112"
                pause 0.0166
                "s1113"
                pause 0.0166
                "s1114"
                pause 0.0166
                "s1115"
                pause 0.0166
                "s1116"
                pause 0.0166
                "s1117"
                pause 0.0166
                "s1118"
                pause 0.0166
                "s1119"
                pause 0.0166
                "s1120"
                pause 0.0166
                "s1121"
                pause 0.0166
                "s1122"
                pause 0.0166
                "s1123"
                pause 0.0166
                "s1124"
                pause 0.0166
                "s1125"
                pause 0.0166
                "s1126"
                pause 0.0166
                "s1127"
                pause 0.0166
                "s1128"
                pause 0.0166
                "s1129"
                pause 0.0166
                "s1130"
                pause 0.0166
                "s1131"
                pause 0.0166
                "s1132"
                pause 0.0166
                "s1133"
                pause 0.0166
                "s1134"
                pause 0.0166
            pause
            cj "YES!"
            rd "Sweet!"
            jump wontpass1

label wontpass1:
    scene s1135 with dissolve
    pt "This dude uses his arms a lot..."
    scene s1136 with hpunch
    pt "Fuck! Not again..."
    scene s1138 with dissolve
    kp "I've seen you play before, I know all your moves...You won't get past me, I promise!"
    pt "Is that so? You think you've seen all my moves?"
    scene s1139 with dissolve
    p "Hey, Phillips, let's go again."
    kp "Are you sure you want to embarrass yourself again?"
    p "I'm going to shut your mouth...let's go again."
label laboba:

    scene s1140 with dissolve

    menu:
        "Do a Classic Stepover.":
            scene s1043 with dissolve
            pt "I don't think a stepover would do it..."
            scene Stepover with Dissolve(0.333)
            pause
            scene s1136 with hpunch
            pt "Fuck!"
            jump laboba

        "Do The Elastico.":
            scene s1094 with dissolve
            pt "I can't believe my Elastico isn't working, it's one of my best tricks...it has to work this time!"
            scene s1094:
                pause 0.0166
                "s1095"
                pause 0.0166
                "s1096"
                pause 0.0166
                "s1097"
                pause 0.0166
                "s1098"
                pause 0.0166
                "s1099"
                pause 0.0166
                "s1100"
                pause 0.0166
                "s1101"
                pause 0.0166
                "s1102"
                pause 0.0166
                "s1103"
                pause 0.0166
                "s1104"
                pause 0.0166
                "s1105"
                pause 0.0166
                "s1106"
                pause 0.0166
                "s1107"
                pause 0.0166
                "s1108"
                pause 0.0166
                "s1109"
                pause 0.0166
                "s1110"
                pause 0.0166
                "s1111"
                pause 0.0166
                "s1112"
                pause 0.0166
                "s1113"
                pause 0.0166
                "s1114"
                pause 0.0166
                "s1115"
                pause 0.0166
                "s1116"
                pause 0.0166
                "s1117"
                pause 0.0166
                "s1118"
                pause 0.0166
                "s1119"
                pause 0.0166
                "s1120"
                pause 0.0166
                "s1121"
                pause 0.0166
                "s1122"
                pause 0.0166
                "s1123"
                pause 0.0166
                "s1124"
                pause 0.0166
                "s1125"
                pause 0.0166
                "s1126"
                pause 0.0166
                "s1127"
                pause 0.0166
                "s1128"
                pause 0.0166
                "s1129"
                pause 0.0166
                "s1130"
                pause 0.0166
                "s1131"
                pause 0.0166
                "s1132"
                pause 0.0166
                "s1133"
                pause 0.0166
                "s1134"
                pause 0.0166
            pause
            scene s1136 with hpunch
            pt "Fuck! Same result...he's sized me up pretty well..."
            jump laboba

        "Do La Boba.":
            pt "A few years back, I watched this very classy Argentinian player who had a simple, but explosive move..."
            pt "The guy was very small and thin, but he could dribble past anybody...it didn't matter how big his opponents were, everybody was ridiculed by his trick..."
            pt "And he did it all the time: \"you had to be really dumb to fall for it.\", they said...Defenders knew what was coming and yet, they ate it up..."
            scene s1141 with dissolve
            pt "He didn't attack defenders the way I do, instead, he waited patiently for them...Just standing there, keeping the ball..."
            scene s1142 with dissolve
            pt "That threw defenders: they didn't know which way he was going until it was too late."
            scene s1143 with dissolve
            pt "They had lost the moment they hesitated..."
            scene s1144 with dissolve
            pt "Now! With a sudden feint he'll be off balance!"
            scene s1145 with dissolve
            pt "I'll show you his signature move: La Boba!"
            scene s1146:
                pause 0.0222
                "s1147"
                pause 0.0222
                "s1148"
                pause 0.0222
                "s1149"
                pause 0.0222
                "s1150"
                pause 0.0222
                "s1151"
                pause 0.0222
                "s1151"
                pause 0.0222
                "s1150"
                pause 0.0222
                "s1149"
                pause 0.0222
                "s1148"
                pause 0.0222
                "s1147"
                pause 0.0222
                "s1146"
                pause 0.0222
                "s1146"
                pause 0.0222
                "s1147"
                pause 0.0222
                "s1148"
                pause 0.0222
                "s1149"
                pause 0.0222
                "s1150"
                pause 0.0222
                "s1151"
                pause 0.0222
                "s1152"
                pause 0.0222
                "s1153"
                pause 0.0222
                "s1154"
                pause 0.0222
                "s1155"
                pause 0.0222
                "s1156"
                pause 0.0222
                "s1157"
                pause 0.0222
                "s1158"
                pause 0.0222
                "s1159"
                pause 0.0222
                "s1160"
                pause 0.0222
                "s1161"
                pause 0.0222
                "s1162"
                pause 0.0222
                "s1163"
                pause 0.0222
                "s1164"
                pause 0.0222
                "s1165"
                pause 0.0222
                "s1166"
                pause 0.0222
                "s1166a"
                pause 0.0222
                "s1167"
                pause 0.0222
                "s1167a"
                pause 0.0222
                "s1168"
                pause 0.0222
                "s1168a"
                pause 0.0222
                "s1169"
                pause 0.0222
                "s1170"
                pause 0.0222
                "s1171"
                pause 0.0222
            pause
            jump score

label score:
    scene s1172 with dissolve
    pt "Eat shit, Phillips! I won!"
    scene s1173 with dissolve
    coa "Beautiful nutmeg!"
    rd "No way he just did a Boba! Damn, this kid's good..."
    scene s1186 with dissolve
    sa "I know nothing about soccer, but that was great, wasn't it?"
    cd "It was awesome! He's going to shoot now..."
    scene s1174 with dissolve
    coa "Let's see if he can score now..."
    play sound "audio/versussound.ogg"
    scene s1175a with Dissolve(0.022)
    scene s1175b with Dissolve(0.022)
    scene s1175c with Dissolve(0.022)
    scene s1175d with Dissolve(0.022)
    scene s1175e with Dissolve(0.022)
    scene s1175f with Dissolve(0.022)
    scene s1175g with Dissolve(0.022)
    scene s1175h with Dissolve(0.022)
    scene s1175i with Dissolve(0.022)
    scene s1175j with Dissolve(0.022)
    scene s1175k with Dissolve(0.022)
    scene s1175l with hpunch
    play sound "audio/versussound.ogg"
    scene s1176 with Dissolve(0.006)
    scene s1176a with Dissolve(0.006)
    scene s1176b with Dissolve(0.006)
    scene s1176c with Dissolve(0.006)
    scene s1176d with Dissolve(0.006)
    scene s1176e with Dissolve(0.006)
    scene s1176f with Dissolve(0.006)
    scene s1176g with Dissolve(0.006)
    scene s1176h with Dissolve(0.006)
    scene s1176i with Dissolve(0.006)
    scene s1176j with Dissolve(0.006)
    scene s1176k with Dissolve(0.006)
    scene s1176l with Dissolve(0.006)
    scene s1176m with Dissolve(0.006)
    scene s1176n with vpunch
    play sound "audio/versussound.ogg"
    scene s1177 with Dissolve(0.01)
    scene s1177a with Dissolve(0.01)
    scene s1177b with Dissolve(0.01)
    scene s1177c with Dissolve(0.01)
    scene s1177d with Dissolve(0.01)
    scene s1177e with Dissolve(0.01)
    scene s1177f with Dissolve(0.01)
    scene s1177g with Dissolve(0.01)
    scene s1177h with Dissolve(0.01)
    scene s1177i with Dissolve(0.01)
    scene s1177j with Dissolve(0.01)
    scene s1177k with Dissolve(0.01)
    scene s1177l with Dissolve(0.01)
    scene s1177m with hpunch
    play sound "audio/fightmk.ogg"
    scene s1177m with dissolve
    scene s1175 with vpunch
    pause
    scene s1178 with dissolve
    pt "I have to score: I don't care if you're the best goalkeeper in the league, this's going in..."
    stop music fadeout 3.0
    scene s1179 with dissolve
    pt "You won't take this away from me, nobody will!"
    play sound "audio/electric.ogg"
    scene s1179e with Dissolve(0.03)
    scene s1179f with Dissolve(0.03)
    scene s1179g with Dissolve(0.03)
    scene s1179h with Dissolve(0.03)
    scene s1179h with Dissolve(0.03)
    scene s1179g with Dissolve(0.03)
    scene s1179f with Dissolve(0.03)
    scene s1179e with Dissolve(0.03)
    play music "audio/highvoltage.ogg"
    scene s1179b:
        pause 0.03
        "s1179a"
        pause 0.03
        "s1179"
        pause 0.03
        "s1179c"
        pause 0.03
        "s1179d"
        pause 0.03
        "s1179d"
        pause 0.03
        "s1179c"
        pause 0.03
        "s1179"
        pause 0.03
        "s1179a"
        pause 0.03
        "s1179b"
        pause 0.03
        repeat
    p "Aaahhh!!!"
    pt "This's my dream!"
    stop music
    play sound "audio/ballkick.ogg"
    scene s1180 with Dissolve(2.0)
    play sound "audio/heartbeat.ogg"
    scene s1181 with Dissolve(2.0)
    scene s1182 with Dissolve(2.0)
    play sound "audio/netsound.ogg"
    scene s1183 with hpunch
    kp "Holy shit! What a goal!"
    scene s1184 with dissolve
    p "I did it..."
    play music "audio/inspiring.ogg"
    scene s1185 with dissolve
    p "Yes! I did it! Yes!"
    cj "He's back!"
    rd "Crack!"
    coa "Yes!"
    sa "I've never seen him this happy at college...it's like he belongs in here, on this field."
    cd "Yeah, I know, that's his true self..."
    scene s1185b with Dissolve(2.0)
    pause
    scene black with Dissolve(2)
    scene s1187 with dissolve
    coa "[p]! I knew you still got it! That was fantastic! Listen, our pre-season training starts next month and I want you there on the 11th, ok?"
    p "That sounds amazing, coach! Thank you so much for the opportunity!"
    coa "This's just the beginning, kid, don't you ever leave us again, that left foot will get you far!"
    scene s1188 with dissolve
    rd "Hey, that thing about being your agent stands: I'm right here whenever you need me, just in case...you killed it, kid."
    p "Haha, thank you, Rob, that means a lot coming from you."
    kp "Game recognize game...Hey, [p]!"
    scene s1189 with dissolve
    kp "Well played...and welcome to the team, brother!"
    p "Thank you, man!"
    ep "Great shot, dude."
    p "Thanks!"
    scene black with dissolve
    scene s1190 with dissolve
    sa "Wooohoooo! Great job! You were fantastic, baby!"
    cd "Yaaayyy! You did it, brother!"
    pt "Yes, I did it..."
    pt "\"Effort never betrays.\", used to say my dad...it certainly paid off today..."
    pt "Thank you, S! Thank you, Candy! This victory's yours, too! You've been there for me..."
    pt "I love you."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    pause
    jump ep4

image Stepover:
    "s1043"
    pause 0.0166
    "s1044"
    pause 0.0166
    "s1045"
    pause 0.0166
    "s1046"
    pause 0.0166
    "s1047"
    pause 0.0166
    "s1048"
    pause 0.0166
    "s1049"
    pause 0.0166
    "s1050"
    pause 0.0166
    "s1051"
    pause 0.0166
    "s1052"
    pause 0.0166
    "s1053"
    pause 0.0166
    "s1054"
    pause 0.0166
    "s1055"
    pause 0.0166
    "s1056"
    pause 0.0166
    "s1057"
    pause 0.0166
    "s1058"
    pause 0.0166
    "s1059"
    pause 0.0166
    "s1060"
    pause 0.0166
    "s1061"
    pause 0.0166
    "s1062"
    pause 0.0166
    "s1063"
    pause 0.0166
    "s1064"
    pause 0.0166
    "s1065"
    pause 0.0166
    "s1066"
    pause 0.0166
    "s1067"
    pause 0.0166
    "s1068"
    pause 0.0166
    "s1069"
    pause 0.0166
    "s1070"
    pause 0.0166
    "s1071"
    pause 0.0166
    "s1072"
    pause 0.0166
    "s1073"
    pause 0.0166
    "s1074"
    pause 0.0166
    "s1075"
    pause 0.0166
    "s1076"
    pause 0.0166
    "s1077"
    pause 0.0166
    "s1078"
    pause 0.0166
    "s1079"
    pause 0.0166
    "s1080"
    pause 0.0166
    "s1081"
    pause 0.0166
    "s1082"
    pause 0.0166
    "s1083"
    pause 0.0166
    "s1084"
    pause 0.0166
    "s1085"
    pause 0.0166
    "s1086"
    pause 0.0166
    "s1087"
    pause 0.0166
    "s1088"
    pause 0.0166
    "s1089"
    pause 0.0166
    "s1090"
    pause 0.0166
    "s1091"
    pause 0.0166
    "s1092"
    pause 0.0166
    "s1093"
    pause 0.0166
pause
