#Important Decisions
default choice80a = False
default choice80b = False




# Start Episode 7
label ep7:

    $ renpy.movie_cutscene("videos/nexus.ogv")

    scene im122 with dissolve
    play music "audio/notthatactive.mp3"
    uk "Ma'am, wait up! Let me help you!"
    scene im120 with dissolve
    bw "Thank you so much, young man! What a beautiful voice you have!"
    uk "Thanks, ma'am, I've heard that before."
    bw "It's so sweet, so melodic, so...pure!"
    uk "Haha, thank you, ma'am."
    scene im121 with dissolve
    bw "Do you sing, son? You have to!"
    uk "Haha, I used to, ma'am...in a church choir when I was a kid..."
    bw "Well, you should do it professionally, son...by the way, what's your name?"
    uk "Benjamin."
    bw "No wonder: \"Son of the right\"."
    ben "Yup, that's me, ma'am!"
    scene black with Dissolve(1)
    scene im123 with dissolve
    ben "Do you need an extra hand fine gentlemen?"
    lgb "Ugh, why is it that people never ask for someone's pronouns before talking to them? And what's up with that voice anyways?"
    scene im124 with dissolve
    ben "What about it?"
    lgb "You have a kid's voice, what happened? Never hit puberty?"
    rai "Hohoho, you're so evil!"
    ben "Well, I'd rather have this voice than yours...you sound like a Mardashian with that annoying vocal fry..."
    scene im125 with dissolve
    lgb "What did you saaaaay?"
    ben "That word didn't even need the fryyyyyy..."
    scene im126 with dissolve
    lgb "Just keep walking, privileged cisgendeeerrrr..."
    ben "Have a good day!"
    ben "{size=-7}Meep.{/size}"
    scene black with Dissolve(1)
    scene im127 with dissolve
    ben "Good morning, Miss Garnier! You wanted to see me?"
    scene im128 with dissolve
    jo "Oh, hi, Ben! Good morning to you, as well!"
    scene im129 with dissolve
    jo "Listen, I wanted to talk to you about a job opportunity with the Big Boss herself!"
    ben "Really?! What is it about, Miss Garnier?!"
    jo "She'll be hosting a huge party at her manor and just asked me to find some waiters...I immediately thought of you!"
    ben "I can definitely do it, Miss Garnier! Thank you so much! I need to save as much as I can for my baby girl!"
    scene im130 with dissolve
    jo "I know, Ben, I know...and she'll be paying good money for that single day too! Come with me, I'll give you all the details..."
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

    scene im131 with dissolve
    play music "audio/darkside.mp3"
    pt "He said he needed my help to kill S's murderer...who could that man be? Why he wanted to kill me?"
    pt "But...killing someone...What do you think, Panther? Do I look like I have it in me?"

if choice79b:

    scene im132 with dissolve
    pt "Who am I kidding? I couldn't even tackle Diaz back...go kill somebody, yeah right..."
    pt "I'm a selfish coward...don't want to go to jail, I want to live..."
    pt "I'm so sorry..."
    stop music fadeout 3
    scene black with Dissolve(3)
    jump endgiutalk

if choice79a:

    pt "Do I have it in me?"
    scene im134 with dissolve
    pt "I have to find out..."
    scene im135 with dissolve
    p "Where are you? We need to talk."
    giu "The Gold Rush. You know it?"
    p "Yeah, I know where it is, wait for me..."
    stop music fadeout 2
    scene black with Dissolve(2)
    scene im136 with Dissolve(2)
    play music "audio/russian2.mp3"
    p "Hey..."
    scene im137 with dissolve
    ro "We're closed."
    p "Closed? Come on, man, I'm 21."
    ro "I didn't ask anything. We're closed, I said."
    p "But I just talked to a friend of mine, he said he was in there..."
    scene im138 with dissolve
    ro "Calling me a liar?"
    p "Chill, man...let me call him."
    scene im139 with dissolve
    play sound "audio/unansweredcall.mp3"
    pause
    pt "Come on..."
    pt "Pick up the phone..."
    scene black with dissolve
    scene im140 with dissolve
    pt "This bastard..."
    ro "Ma'am."
    stop sound
    scene im141 with dissolve
    el "Hi there! I'm Elle..are you [p], a friend of Giuseppe?"
    p "That's me!"
    el "Welcome to The Gold Rush! Follow me, please!"
    stop music fadeout 2
    scene black with Dissolve(2)
    scene im142 with dissolve
    play music "audio/benmoose.ogg"
    el "You're gonna have to wait some time, darling...he's in a private show right now."
    p "How long is he gonna take?"
    el "That depends, haha...come have a seat."
    scene black with dissolve
    scene im143 with dissolve
    el "In the meantime, what can I offer you, darling?"
    scene im144 with dissolve
    p "What CAN you offer me?"
    scene im145 with dissolve
    pause 1
    scene im146 with dissolve
    p "Hi."

if choice65a:

    scene im147 with dissolve
    el "Hahaha, now I remember you! You came in here with Daniel! That's why your face looked familiar!"
    p "I'm flattered to be remembered among so many men who come to your place."
    el "Haha, you were a peculiar group with that other guy who asked my girls about their body count...haha."
    scene im148 with dissolve
    el "My God! What a weird guy! What was that all about?! Haha."
    p "Yeah, I don't know, haha...we're laughing now, but it was very embarrasing at the moment...You know you don't have to worry about him coming to your place anymore, right?"
    scene im152 with dissolve
    el "'Cause he went to France?"
    p "How'd you know?!"
    el "He's still in touch with Tiffany, I overheard them on the phone the other night...he wants her to go live with him, haha! Apparently, he can't forget Tiff..."
    p "Haha, Billy being Billy..."
    jump elletalk

label elletalk:

    scene im149 with dissolve
    pt "Damn, I find this woman so hot...might be that bearing, look at her! She truly is The Queen around here..."
    p "Why don't you take a seat?"
    scene im150 with dissolve
    p "I'd like your company while I wait..."
    scene im151 with dissolve
    el "Sure, darling, sure..."
    stop music fadeout 3
    scene black with dissolve
    scene im153 with Dissolve(1)
    el "There's something I'd like to know first: how do you really know Giuseppe? He said you were friends, but come on, from where? I know all his friends..."
    p "You know all his friends?"
    el "Of course, we grew up in the same neighborhood."
    p "I see, so you are close...Do you know his family, too?"
    scene im154 with dissolve
    el "Yeeeah..."
    p "His daughter was my girlfriend."
    scene im155 with dissolve
    el "Oh, my God! I'm so sorry!"
    p "Yeah...me too."
    el "You must be here for the same reason then...trying to forget!"
    scene im156 with dissolve
    el "Let me call one of my girls..."
    p "Oh, no, no, it's not necessary, that's not why I'm here, Elle...I just wanted to talk with Giuseppe and he told me he was here..."
    el "You sure?"
    p "Yeah, just keep me company...perhaps, uhmm, change the subject? I don't feel like going into any of it right now..."
    el "Of course, darling...I understand..."
    scene im157 with dissolve
    play music "audio/chillpopsexy.mp3"
    el "And look around! This is not the place to feel depressed! It's a strip club, not a therapist's office!"
    p "Haha, thanks."
    p "Wow, you have a beautiful smile..."
    scene im158 with dissolve
    el "You're not the first one to notice, darling."
    p "I'm sure of it...uuuhmm, and how's business going?"
    el "Better than I could've ever hoped for, darling, thanks for asking...some customers just want the whole place for themselves lately, and that kind of privacy is expensive."
    pt "Oh, so that's why it's empty...this dude's throwing away all his money...it's like he's already saying good bye..."
    el "Anyway, what about you? What do you do?"
    p "Play soccer."
    scene im159 with dissolve
    el "Is that so? My daughter loves soccer, you know...do you play professionally?"
    p "No, not yet, but I trust I can get there."
    el "You're that good, huh?"
    p "Well, I don't like to tell...would you like to come to one of my games?"
    scene im160 with dissolve
    el "Me?! Hahaha, you're barking up the wrong tree, darling...I could be your mother!"
    p "But you're not...come on, it'll be fun! And I can get you the best seats in our stadium!"
    scene im161 with dissolve
    pause
    giu "Come on, [p]..."
    stop music fadeout 3
    scene im162 with dissolve
    pause
    scene im164 with dissolve
    giu "Let's talk outside."
    p "Alright."
    scene im163 with dissolve
    p "Think about it..."
    scene black with Dissolve(1)
    play sound "audio/cigarlighter.ogg"
    scene im165 with dissolve
    play music "audio/gangstarap.ogg"
    giu "I can't believe you're actually here...thought you had a lot of things going on..."
    p "I need to know who killed Samantha."
    scene im166 with dissolve
    giu "Just for the fact of knowing or you're gonna do something about it?"
    p "I'm here to help you do it."
    scene im167 with dissolve
    play sound "audio/cigarsmokein.ogg"
    giu "You say it so lightly, kid. You have no idea what it takes to kill someone..."
    p "What does it take?"
    scene im168 with dissolve
    pause 1.5
    play sound "audio/exhalesmoke.mp3"
    scene im169 with dissolve
    pause 2
    scene im170 with dissolve
    giu "Your soul."
    p "..."
    scene im171 with dissolve
    p "Have you killed someone?"
    scene im172 with dissolve
    pause
    p "Is that a yes?"
    scene im173 with dissolve
    giu "Hey, listen, I don't need you anymore: Sam's murderer's been dealt with."
    p "You killed him?"
    giu "I wish. The ones who hired him did it."
    play sound "audio/cigarsmokein.ogg"
    scene im174 with dissolve
    pause 2
    scene im175 with dissolve
    giu "What? You're not satisfied? You want names?"
    play sound "audio/cigarsmokeout.ogg"
    scene im176 with dissolve
    pause 2
    scene im177 with dissolve
    giu "What are you going to do with those names?"
    p "I don't know..."
    scene im178 with dissolve
    pause
    scene im179 with dissolve
    giu "Gordon Wardell. That's my daughter's murderer's name."
    p "I don't know who he is...why he wanted me dead?"
    giu "He didn't. His bosses did."
    p "Same question: Why?"
    scene im180 with dissolve
    giu "Because of your brother."
    p "What?!" with vpunch
    giu "He bit off more than he could chew."
    p "What? Be direct, man. I don't get it, what does my brother have to do with anything? Who is this...Gordon? Who are his bosses?"
    scene im181 with dissolve
    giu "All I'm gonna say is that they're closer to you than you could imagine...but you want more \"direct\"? Ask the source itself then: your brother, he can give you a straight answer."
    giu "After all, he's the reason why these sick people want your head...wanted...I think you're safe...for now..."
    pt "My brother? What the hell is he talking about?"
    scene im182 with dissolve
    giu "Listen, I respect you for showing up tonight, I thought you were a fucking pussy..."
    giu "No, that's not true, I never did: Sam would've never chosen a fucking loser to be her boyfriend...but I still wonder what she saw in you..."
    scene im183 with dissolve
    giu "And I wasn't gonna let you do anything anyway, she would've killed me..."
    scene im184 with dissolve
    p "{size=-6}You said I could make it right...{/size}"
    scene im185 with dissolve
    giu "What was that?"
    stop music fadeout 3
    p "You said I could make it right!" with vpunch
    scene im186 with dissolve
    giu "Aaahh..."
    scene im187 with dissolve
    giu "I lied...go home."
    p "That's it? Go home? I didn't come all the way here to go home...what the hell?"
    p "Maybe..."
    play music "audio/phobia.ogg"
    p "Maybe you should do that!" with hpunch
    scene im188 with dissolve
    giu "What did you say?"
    p "Yeah, you should go home! What are you doing here when your wife needs you? Go home!"
    scene im189 with dissolve
    giu "You little bitch..."
    scene im190 with vpunch
    giu "You better shut up before I make you shut up..."
    scene im191 with dissolve
    giu "Go home..."
    scene im192 with vpunch
    scene im192 with vpunch
    giu "HOME WAS WHERE MY DAUGHTER WAS!!!"
    giu "Where the fuck is that now, huh?! Where the fuck is my daughter?!"
    p "I'm sorry, it all happened so f..."
    scene im193 with vpunch
    scene im193 with vpunch
    giu "SHUT UP, SHUT UP, SHUT UUUUPPP!!!"
    giu "I don't want to listen to you!!"
    giu "It happened in front of your eyes, you fucking pussy!!"
    giu "Home..."
    giu "Can you give me back my daughter?!"
    scene im194 with vpunch
    scene im194 with vpunch
    giu "ANSWER MEEE!!! CAN YOU GIVE ME BACK MY DAUGHTER??!!!"
    pause
    p "I can't..."
    scene im194 with vpunch
    giu "THEN SHUT YOUR FUCKING MOUTH, YOU PIECE OF SHIT!!!"
    el "Giuseppe..."
    scene im195 with dissolve
    el "That's enough."
    scene im196 with dissolve
    pause
    scene im197 with dissolve
    pause
    scene im198 with Dissolve(1)
    giu "Ask your brother...and do it quick, I've heard you're running out of time."
    pt "Out of time? I don't understand shit..."
    stop music fadeout 3
    scene im199 with Dissolve(2)
    el "Are you ok?"
    p "Physically, yeah, I'm ok..."
    el "He's not a bad man, you know, these are just hard times...for everybody..."
    p "I know, I understand...thank you for that...I need to go now..."
    scene im200 with dissolve
    el "Wait..."
    el "The best seats, you said?"
    pause
    p "I did, yeah..."
    scene im201 with dissolve
    el "I'm going to need two tickets."
    p "Are you just trying to make me feel better now?"
    el "Yeah."
    p "It's kind of working..."
    scene im202 with dissolve
    pause
    p "So...you'll only go see me out of pity?"
    scene im203 with dissolve
    el "Yeah."
    p "Ha...I'm asking the wrong questions here...but I'm getting you those tickets anyway..."
    scene im204 with dissolve
    el "Haha."
    p "You won't regret it, you'll see..."
    p "Bye."
    scene black with Dissolve(3)
    jump endgiutalk

label endgiutalk:

if choice75b:

    jump jostadiumtalk

if choice75a:

    scene im1 with dissolve
    play music "audio/sensual17.mp3"
    br "[p], is your house clean?"
    p "What? Why are you asking that?"
    br "Is it?"
    p "I guess so..."
    scene im2 with dissolve
    br "Oooh, I see..."
    scene im3 with dissolve
    br "Oh! Are you sick? Hehe."
    p "Sick? No, I'm not sick...what...what's this?"
    br "It's nothing, I just thought you were sick and needed a nurse!"
    scene im4 with dissolve
    p "A nurse?"
    p "Uuuhm...what if I say yes? What's gonna happen?"
    scene im5 with dissolve
    br "Do you need a nurse or not?"
    p "Cough, cough, cough..."
    scene im6 with dissolve
    br "Oh, no, sir! Is that a cough I'm hearing? I'm going to have to do a full check-up!"
    p "Hahaha, oh, I get it now...haha..."
    p "So earlier when you asked me about my house...uhm, you wanted my dick to clean your pipes or something like that?"
    scene im7 with dissolve
    br "Hahaha...when you're done training, come over and find out what I meant...I'm home alone!"
    p "If that's the case, I'm going right away!"
    stop music fadeout 2

    scene black with Dissolve(2)

label brendasex2:

    if _in_replay:
        $ pf = persistent.p

    scene im8 with dissolve
    br "Come in, [p]! I'm in my bedroom..."
    pt "Haha, she's so ready...I don't know what I'm getting myself into, but, man, this's so exciting..."
    scene im9 with dissolve
    pause
    br "Hurry!"
    p "I'm coming..."
    scene black with dissolve
    play sound "audio/dooropen.ogg"
    scene im11 with dissolve
    play music "audio/solo.mp3"
    scene im11 with dissolve
    scene im12 with dissolve
    scene im13 with dissolve
    scene im13 with hpunch
    scene im13 with hpunch
    p "Holy shit!"
    br "Do you like it?"
    scene im10 with hpunch
    scene im10 with hpunch
    p "Like it? My God!"

    scene im14:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "You are so beautiful, Brenda! Wooow!"
    p "You're perfect!"
    scene im14a with dissolve
    br "You think?"
    p "Daaamnn, that's another thing I love about you..."

    scene im14b:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "You can be so shy and innocent one minute and super sexy and confident the next! That's just so hot!"
    p "And I can't believe you're all mine!"

    scene im15:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    br "Hahaha, you love to think I'm all yours, don't you? Haha, I'm mine! Haha."
    p "Nope, not anymore, you're mine now!"
    br "Haha, are you ready to roleplay?"
    p "Yeah, I'm excited! It's the first time I'm going to do it..."
    p "Cough, cough, cough..."
    br "Hahaha."

    scene im16 with dissolve
    br "Oh, no! That's a serious cough I'm hearing, sir, I think I'm going to have to check your pulse first..."
    p "My pulse? I don't see how it is rela..."
    scene im17 with vpunch
    p "Ooohh!"
    p "Yes, yes, my pulse! Totally necessary!"
    br "Hahaha, sir, you seem pretty healthy to me..."
    p "Healthy? No, I'm about to faint actually, I need to get on the bed...if you excuse me..."
    scene black with dissolve
    scene im18 with dissolve
    br "Oh, no, sir, this might be a very serious infection...Drop your pants, now!"
    p "Done!"
    scene im20 with dissolve
    br "Just like I thought! This requires immediate treatment!"
    p "Yeah, I couldn't agree more..."
    scene im21 with dissolve
    pause
    p "Save my life, please!"
    scene im21a with dissolve
    br "Don't worry, sir, I know my job, you're in good mouth!"
    p "Haha."
    scene im22 with vpunch
    p "Yes!"
    scene im23 with dissolve
    pause
    scene im32 with dissolve
    pause
    scene im44 with dissolve
    br "Aahhh..."
    scene im32 with dissolve
    pause
    scene im44 with dissolve
    pause

    scene im23:
        pause 0.0299
        "im24"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0299
        "im25"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0299
        "im26"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0299
        "im27"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0299
        "im28"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0299
        "im29"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0299
        "im30"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0299
        "im31"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0299
        "im32"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0299
        "im33"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0299
        "im34"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0299
        "im35"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im36"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im37"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im38"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im39"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im40"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im41"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0299
        "im42"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0299
        "im43"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0299
        "im44"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0299
        "im45"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0299
        "im46"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0299
        "im47"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0299
        "im48"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0299
        "im49"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0299
        "im50"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0299
        "im51"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0299
        "im52"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0299
        repeat
    pause

    scene im25:
        pause 0.0333
        "im26"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0333
        "im27"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0333
        "im28"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0333
        "im29"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0333
        "im30"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0333
        "im31"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0333
        "im32"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0333
        "im32"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0333
        "im31"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0333
        "im30"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0333
        "im29"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0333
        "im28"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0333
        "im27"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0333
        "im26"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0333
        "im25"
        pause 0.0333
        repeat
    pause

    p "Yeah, I'm starting to feel a lot better..."

    scene im25b:
        pause 0.0266
        "im26b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0266
        "im27b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0266
        "im28b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0266
        "im29b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0266
        "im30b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0266
        "im31b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0266
        "im32b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0266
        "im32b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0266
        "im31b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0266
        "im30b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0266
        "im29b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0266
        "im28b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0266
        "im27b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0266
        "im26b"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0266
        "im25b"
        pause 0.0266
        repeat
    pause 2.5536

    scene im25c:
        pause 0.0266
        "im26c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0266
        "im27c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0266
        "im28c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0266
        "im29c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0266
        "im30c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0266
        "im31c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0266
        "im32c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0266
        "im32c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0266
        "im31c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0266
        "im30c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0266
        "im29c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0266
        "im28c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0266
        "im27c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0266
        "im26c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0266
        "im25c"
        pause 0.0266
        repeat
    pause 2.5536

    scene im54 with vpunch
    play sound "audio/maleorg1.ogg"
    scene im54 with flash
    scene im54 with vpunch
    scene im54 with flash
    scene im55 with Dissolve(1)
    p "Oh, fuck!"
    br "Haha, my turn now! or I have to wait?"
    p "Wait?! Who do you think I am? Anderson?"
    br "Hahaha, shut up!"
    scene im56 with dissolve
    br "I'm not going to leave a single drop in you!"
    scene im57 with dissolve
    p "You're not allowed to stop until I'm drained..."
    br "Haha."
    scene im59 with dissolve
    p "Yeah, show me what's mine."
    br "Hahaha, that again?! I'm mine!"
    p "Ok, you are yours, but your pussy's mine."
    scene im60 with dissolve
    br "Hahaha, what I got on my face is yours...wanna lick it?"
    p "What?! You crazy, I'm not gonna lick it...clean yourself up."
    br "I won't! You have to look at what you've done!"
    stop music fadeout 3
    scene im61 with Dissolve(1)
    br "Don't clean up your cock either...I want to feel your hot cum inside, haha."
    p "Daaamn..."
    scene black with dissolve
    scene im63a with Dissolve(1)
    play music "audio/barsong.mp3"
    br "Much better..."
    br "You want to get me pregnant, don't you?"
    p "No, I don't."
    br "Yes, you do. You want to give Daniel a little brother...you're sick in the head!"
    p "What the hell?! I never said that...and let's not talk about Daniel..." with hpunch
    scene im62 with dissolve
    br "Don't wanna talk about him? Then why you're getting harder and harder?"
    br "Mmm, your semen's so tasty, [p]...and thick! You must be very fertile..."
    p "Shit..."
    scene im62a with dissolve
    br "Haha, how old are you, by the way? Twenty?"
    p "Yeah, why?"
    scene im62b with dissolve
    br "You're so young! I bet no girl has ever ridden you like I'm about to..."
    br "I'm gonna show you what a mature woman can do!"

    scene im63 with dissolve

    scene im63:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "im64"
        xpos 0.5 ypos 0.606 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "im65"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "im66"
        pause 0.0222
        "im67"
        pause 0.0222
        "im68"
        pause 0.0222
        "im69"
        pause 0.0222
        "im70"
        pause 0.0222
        "im71"
        pause 0.0222
        "im72"
        pause 0.0222
        "im73"
        pause 0.0222
        "im74"
        pause 0.0222
        "im75"
        pause 0.0222
        "im76"
        pause 0.0222
        "im77"
        pause 0.0222
        "im78"
        pause 0.0222
        "im79"
        pause 0.0222
        "im80"
        pause 0.0222
        "im81"
        pause 0.0222
        "im82"
        pause 0.0222
        "im83"
        pause 0.0222
        "im84"
        pause 0.0222
        "im85"
        pause 0.0222
        "im86"
        pause 0.0222
        "im87"
        pause 0.0222
        "im88"
        xpos 0.5 ypos 0.594 xanchor 0.5 yanchor 0.6
        pause 0.0222
        repeat
    pause
    br "I'm gonna break your cock!"
    p "Shit, you weren't bullshitting..."
    br "Uhum..."

label brendcowsex2:

    scene im63:
        pause 0.0166
        "im64"
        pause 0.0166
        "im65"
        pause 0.0166
        "im66"
        pause 0.0166
        "im67"
        pause 0.0166
        "im68"
        pause 0.0166
        "im69"
        pause 0.0166
        "im70"
        pause 0.0166
        "im71"
        pause 0.0166
        "im72"
        pause 0.0166
        "im73"
        pause 0.0166
        "im74"
        pause 0.0166
        "im75"
        pause 0.0166
        "im76"
        pause 0.0166
        "im77"
        pause 0.0166
        "im78"
        pause 0.0166
        "im79"
        pause 0.0166
        "im80"
        pause 0.0166
        "im81"
        pause 0.0166
        "im82"
        pause 0.0166
        "im83"
        pause 0.0166
        "im84"
        pause 0.0166
        "im85"
        pause 0.0166
        "im86"
        pause 0.0166
        "im87"
        pause 0.0166
        "im88"
        pause 0.0166
        repeat
    pause
    p "Fuuuck!"

menu:
    "Cum.":
        jump brendcowsex2cum1

    "Change angle.":
        jump brendcowsex2angle2

label brendcowsex2angle2:

    scene im93:
        pause 0.0166
        "im94"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im95"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im96"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im97"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im98"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im99"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im100"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im101"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im102"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im103"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im104"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im105"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im106"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im107"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im108"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im109"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im110"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im111"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im112"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im113"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im114"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im115"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im116"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im117"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im118"
        pause 0.0166
        repeat
    pause
    p "You're amazing!"
    br "Am I?"

    scene im105:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "im106"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "im107"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "im108"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "im109"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0166
        "im110"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0166
        "im111"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "im112"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0166
        "im113"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0166
        "im114"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0166
        "im115"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "im116"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "im117"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im118"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "im93"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "im94"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "im95"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "im96"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im97"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "im98"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "im99"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0166
        "im100"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0166
        "im101"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0166
        "im102"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "im103"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0166
        "im104"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0166
        repeat
    pause

    p "Oh, fuck, yeah!"

menu:
    "Cum.":
        jump brendcowsex2cum2

    "Change angle.":
        jump brendcowsex2

label brendcowsex2cum1:

    p "Yeah, like that! I'm cumming!"
    br "Cum, baby, make me a mother again..."
    p "What?! Don't say that!"
    br "Come on! Fill me up!"

    scene im63:
        pause 0.0133
        "im64"
        pause 0.0133
        "im65"
        pause 0.0133
        "im66"
        pause 0.0133
        "im67"
        pause 0.0133
        "im68"
        pause 0.0133
        "im69"
        pause 0.0133
        "im70"
        pause 0.0133
        "im71"
        pause 0.0133
        "im72"
        pause 0.0133
        "im73"
        pause 0.0133
        "im74"
        pause 0.0133
        "im75"
        pause 0.0133
        "im76"
        pause 0.0133
        "im77"
        pause 0.0133
        "im78"
        pause 0.0133
        "im79"
        pause 0.0133
        "im80"
        pause 0.0133
        "im81"
        pause 0.0133
        "im82"
        pause 0.0133
        "im83"
        pause 0.0133
        "im84"
        pause 0.0133
        "im85"
        pause 0.0133
        "im86"
        pause 0.0133
        "im87"
        pause 0.0133
        "im88"
        pause 0.0133
        repeat
    pause 2.7664

    stop music fadeout 3
    play sound "audio/maleorg1.ogg"
    scene im89 with vpunch
    scene im89 with vpunch
    scene im89 with flash
    br "Ooohh, baby, I feel it throbbing..."
    scene im90 with dissolve
    br "My God! Look!"
    scene im91 with dissolve
    p "What."
    scene im92 with dissolve
    p "Hey, watch out, this's a new T-shirt! I think it's a good time to clean that up!"
    br "Haha, I'm on it! You got 2 minutes to be ready, we're going again!"

    jump sex2last

label brendcowsex2cum2:

    scene im93:
        pause 0.0133
        "im94"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im95"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im96"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im97"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im98"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im99"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im100"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im101"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im102"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im103"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im104"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im105"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im106"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im107"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im108"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im109"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im110"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im111"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im112"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im113"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im114"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im115"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im116"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im117"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im118"
        pause 0.0133
        repeat
    pause 2.7664

    stop music fadeout 3
    play sound "audio/maleorg1.ogg"
    scene im119 with vpunch
    scene im119 with vpunch
    scene im119 with flash
    scene im119 with dissolve
    scene im119 with flash
    br "Fuck, yeah! Give it to me!"
    p "Wooow! You are fantastic...."
    scene im119a with dissolve
    br "I know! Haha, you got two minutes while I clean myself...we won't stop until you get me pregnant!"
    p "Shut up! Not gonna happen...not today at least..."
    br "Hahaha, I knew it! You want me to carry your son!"
    p "Haha, I don't think so, it's just the lust speaking..."

    jump sex2last

label sex2last:

    scene black with Dissolve(2)

    play music "audio/slowrockhot.mp3"

    scene im276 with dissolve
    br "What a great fuck! I love your cock so much, [p]..."
    p "I'm not drained yet...c'mon, start moving!"
    br "My God!"

    scene im205 with dissolve

    scene im205:
        pause 0.0166
        "im206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "im218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "im222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "im224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "im226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0166
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0166
        "im228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0166
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0166
        "im230"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0166
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0166
        "im232"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0166
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0166
        "im234"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0166
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "im236"
        pause 0.0166
        "im237"
        pause 0.0166
        "im238"
        pause 0.0166
        "im239"
        pause 0.0166
        "im240"
        pause 0.0166
        "im241"
        pause 0.0166
        "im242"
        pause 0.0166
        "im243"
        pause 0.0166
        "im244"
        pause 0.0166
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "im246"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0166
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0166
        "im248"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0166
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0166
        "im250"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0166
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0166
        "im252"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0166
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0166
        "im254"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0166
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "im256"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "im258"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "im260"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im262"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "im264"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im266"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im268"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im270"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im272"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im274"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im275"
        pause 0.0166
        repeat
    pause

    br "Oh, fuck! I don't think I can live without your cock now!"
    p "You're saying that on Juan's bed..."
    br "Oh, my God! Shut up, you're heartless!"
    p "Me?! You're the one begging me to get you pregnant while your husband's working..."
    br "Sick fuck!"

    scene im205:
        pause 0.0122
        "im206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im230"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im232"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im234"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im236"
        pause 0.0122
        "im237"
        pause 0.0122
        "im238"
        pause 0.0122
        "im239"
        pause 0.0122
        "im240"
        pause 0.0122
        "im241"
        pause 0.0122
        "im242"
        pause 0.0122
        "im243"
        pause 0.0122
        "im244"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im246"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im248"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im250"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im252"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im254"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im256"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im258"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im260"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im262"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im264"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im266"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im268"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im270"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im272"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im274"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0122
        "im275"
        pause 0.0122
        repeat
    pause
    p "A little faster?"
    p "That got you hornier, huh? You're soulless too..."
    br "Shut up, it's you...What are you doing to me?!"
    p "Just coming inside you...on your husband's bed!"
    br "Fuck, we're horrible people...but I can't fight it, I want this!"

    scene im205:
        pause 0.0122
        "im206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im230"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im232"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im234"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im236"
        pause 0.0122
        "im237"
        pause 0.0122
        "im238"
        pause 0.0122
        "im239"
        pause 0.0122
        "im240"
        pause 0.0122
        "im241"
        pause 0.0122
        "im242"
        pause 0.0122
        "im243"
        pause 0.0122
        "im244"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im246"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im248"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im250"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im252"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im254"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im256"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im258"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im260"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im262"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im264"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im266"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im268"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im270"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im272"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im274"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122

        "im205"
        pause 0.0122
        "im207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0122
        "im227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im237"
        pause 0.0122
        "im239"
        pause 0.0122
        "im241"
        pause 0.0122
        "im243"
        pause 0.0122
        "im245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0122
        "im247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0122
        "im249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0122
        "im251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0122
        "im253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0122
        "im255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0122
        "im257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0122
        "im259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0122
        "im261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0122
        "im263"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0122
        "im265"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0122
        "im267"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0122
        "im269"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0122
        "im271"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0122
        "im273"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0122
        "im275"
        pause 0.0122
    pause 3.416

    scene im240 with vpunch
    play sound "audio/femorg12.ogg"
    scene im277 with dissolve
    scene im277 with flash
    scene im277 with flash
    pause
    play sound "audio/femorg12.ogg"
    scene im278 with dissolve
    scene im278 with vpunch
    scene im278 with vpunch
    pause

    stop music fadeout 3
    stop sound
    scene black with Dissolve(3)

    $ renpy.end_replay()


    scene im367 with dissolve
    sh "Bye, baby, study hard!"
    cd "Mom, shut up, you know I always do it, no need to tell me all the time..."
    mt "Bye, Ms. Harris!"
    sh "Bye, Daniel, it's good to see you back to black today, it suits you , honey!"
    mt "Hehehe, thanks!"
    scene black with dissolve
    scene im363 with Dissolve(1.5)
    pause 1
    scene im364 with Dissolve(1.5)
    pause
    scene im365 with dissolve
    sh "Mmm...who do we have here?"
    sh "What were you doing there, [p]? I just saw Daniel at college...Juan's working right now...Brenda?"
    scene im366 with dissolve
    sh "This nasty mind of mine, but..."
    sh "\"Think the worst and you won't be disappointed.\""
    sh "I'll ask her later..."

    scene black with Dissolve(3)

label jostadiumtalk:

    play music "audio/bendreams.ogg"
    scene im368 with Dissolve(1)
    p "Joooo..."
    scene im369 with dissolve
    p "Hold up, please!"
    scene im371 with dissolve
    jo "Oh, hi, [p]! What can I do for you?"
    p "Hey, what happened here?! Were you always this tall?!"
    scene im372 with dissolve
    jo "Hahaha, you're getting shorter! I didn't know you were intimidated by tall women, [p]..."
    p "I'm not, I love tall women..."
    scene im373 with dissolve
    p "Besides, you're cheating."
    jo "Haha, I'm pretty sure I'm still taller without the heels...but come on, you didn't want to talk about height, did you?"
    scene im374 with dissolve
    p "You're right...I wanted to ask you something: is it possible to get some free tickets for our next match here? I want to invite some people..."
    scene im375 with dissolve
    jo "Some people, you said? We only give away tickets to our professional players, [p]..."
    p "Damn, that's too bad...I guess I'll have to pay for them."
    scene im376 with dissolve
    jo "Haha, I'm joking, you can get all the tickets you want."
    p "Oh, you got me right there! In that case, I'm gonna need two tickets...please?"
    jo "No problem...Listen, on a completely unrelated subject: my sister's been asking about you...what did you do to her?!"
    p "Haha...nothing...how's she doing?"
    scene im377 with dissolve
    jo "Why don't you ask her yourself? I'm meeting her in about an hour in a cafe nearby, wanna join us?"

menu:
    "Yeah!":
        jump choice80a

    "I have to go somewhere else...":
        jump choice80b

label choice80a:

    $ choice80a = True

    scene im378 with dissolve
    p "It'd be great to see her! I'll take a shower and then...meet you at your office?"
    jo "Yeah, I'll be waiting...she'll be thrilled to see you!"
    stop music fadeout 2
    scene black with Dissolve(2)
    scene im400 with dissolve
    play music "audio/ilove.ogg"
    jo "Ugh, these earrings are killing me, better take them out..."
    p "What's wrong?"
    jo "I guess they're not made of pure gold."
    scene im401 with dissolve
    p "Haha."
    jo "No, seriously, I'm allergic to nickel, it makes my earlobes itch. And most earrings are alloys of a metal and nickel, except the gold ones...the expensive ones..."
    p "You're allergic to non-gold jewelry?"
    jo "Sounds funny, huh?"
    p "Yeah, haha, you learn something new every day...so, if I ever get you a present, I HAS to be..."
    jo "Haha, come on, cut it out."
    p "Haha."
    scene black with dissolve
    play sound "audio/shopbell.ogg"
    scene im381 with dissolve
    fhn "Hi, Jo!"
    jo "Hi, darling, how's it going?"
    fhn "Good!"
    pt "What was her name?"
    scene im382 with dissolve
    fhn "Hi, spaceman!"
    p "What the hell? Do we treat each other like that already?"
    scene im383 with dissolve
    fhn "Hahaha, sorry, it was just too epic...how have you been?"
    p "I've been all right...Jessica's cousin..."
    scene im384 with dissolve
    jo "Her name's Orla."
    p "Oh yeah, I remember now...Orla, thanks."
    scene im385 with dissolve
    orl "I forgot your name as well..."
    p "[p]."
    orl "Got it."
    scene im386 with dissolve
    orl "Hazelnut almond milk latte, right?"
    jo "Yeah! With some organic whipped cream, don't forget!"
    orl "Got it."
    scene im387 with dissolve
    orl "And for you?"
    p "I don't know any of those fancy names...just give me some coffee..."
    scene im388 with dissolve
    jo "Hehe, get him a Venti americano."
    pt "Venti? What the hell is that?"
    p "Yeah, that one."
    orl "Got it."
    scene black with Dissolve(1)
    scene im389 with dissolve
    jo "Where do you know her from?"
    p "A friend's party...but we barely talk, she was with her group of friends and I was with mine..."
    jo "I don't know her much either...but seems nice."

if choice79a:
    scene im390 with dissolve
    jo "So, tell me...you've been banned for...how long? Four matches?"
    p "Three...it was only a tackle...part of the game, you know..."
    jo "Right...are you sure it was part of the game? How are you feeling these days, [p]?"
    p "I've been better, thanks for asking Jo, I know it's your job to make su..."
    jo "I'm not asking because it's my job, I care about you as a person, too, not only as a player."
    p "Then...as a person: I'll be all right. As a player...I think I won't be breaking any more ankles."
    jo "Don't joke about it."
    p "You know he broke my knee before, right?"
    jo "I heard about it, yeah..."
    p "See? He deserved it."
    scene im391 with dissolve
    jo "Sarka Nyack would definitely agree with you."
    p "The owner's daughter?"
    jo "Well, she's like in charge of the club now...she asked me about that match and well, I couldn't leave your \"revenge\" out...she started laughing and literally said: I love it!"
    jo "Maybe she considered it justice, like you do...I don't know...she's a little odd to be honest..."
    p "Well, if she said she loved it, that IS odd."
    scene im392 with dissolve
    jo "Yeah, right?"
    jump jocafetalk

label jocafetalk:

    scene im394 with dissolve
    p "Hey, I've been hearing pretty good things about you! \"Oh, she's doing a great job!\", \"She's so nice and efficient!\"...things like that..."
    scene im395 with dissolve
    jo "Really?!"
    p "Yeah, yeah...I'm so glad things are working out for you, my friend."
    scene im396 with dissolve
    jo "Aww, thank you, [p], that's sweet of you...you're such a great brother-in-law!"
    scene im396 with hpunch
    p "What?!"
    scene im397 with dissolve
    jo "Hahaha..."
    play sound "audio/shopbell.ogg"
    scene im398 with dissolve
    stop music fadeout 3
    pause 1
    scene im399 with dissolve
    jo "OH{w=1.0} MY{w=1.0} GOD!!!" with hpunch
    p "What? What is it?!"
    scene im402 with dissolve
    pt "Beautiful legs..."
    ca "Hi, [p]..."
    pt "Wait a minute..."

    play music "audio/benmellow.mp3"

    scene im403:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Camille?!"
    p "WOOOOWWW!!!"
    ca "Haha...hi..."
    pt "I knew she was hot, but not this hot!!!"

    call screen camcafe1

    screen camcafe1():
        modal True

        viewport:

            add "im403"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("camillecafe")

label camillecafe:

    scene im404 with dissolve
    jo "{size=-7}I didn't know she liked you this much...she never dresses like that...{/size}"
    jo "[p]! Go! I'm telling you she's all dressed up for you!"
    scene im405 with dissolve
    pause
    pt "That's right, and she's all mine!"
    scene im406 with dissolve
    p "Woooowww, Cam, you look amazing! I'm speechless...Wow!"
    scene im407 with dissolve
    ca "Really?"
    p "Of course! What's wrong with you?! Why you doubt it?"
    scene im408 with dissolve
    ca "Head up, you're gorgeous, Camille!"
    scene im409 with dissolve
    p "Man, I'm feeling so short today..."
    ca "Haha, you are."
    p "Hey!"
    jo "Get a room you two!"
    scene im410 with dissolve
    jo "Where are you taking my sis, [p]? You're not staying here, she's overdressed for this place..."
    pt "Oh, I know where I'd like to take her..."
    p "I don't know..."
    scene im411 with dissolve
    p "Where would you like to go, Cam?"
    scene im412 with dissolve
    ca "I don't know, give me some ideas..."
    p "A place where we can have some fun!"
    pt "If you know what I mean..."
    scene im413 with dissolve
    ca "Mmm..."
    scene im414 with dissolve
    ca "I know where! Come!"
    pt "Yes!"
    p "Cool, let's go!"
    jo "[p]!"
    scene im415 with dissolve
    jo "Come here, one second..."
    scene im416 with dissolve
    jo "Don't hurt her."
    p "What?"
    jo "If you just want to have sex, there are other types of girls...Cami's not like that...she really likes you, okay?"
    scene im417 with dissolve
    stop music fadeout 3
    pt "She knows what I'm going through...like Riv said: I have to heal first, I haven't...it's too soon for me to be flirting...but I feel she can help me...damn..."
    pt "I'm a mess inside, but I've decided not to show it."
    p "I won't hurt her, Jo."
    ca "[p], let's go!"
    p "Coming..."
    scene black with Dissolve(2)

    play music "audio/lasvegasgangsta.mp3"
    scene im1110 with Dissolve(1)
    p "What are we doing here, Cam?"
    ca "This is where I usually have fun! Haha."
    pt "I didn't mean this when I said \"fun\"!"
    scene im1112 with dissolve
    ca "Come! I want you to meet my friends!"
    pt "I'm meeting your friends now?! What am I? Your new boyfriend?!"
    scene im1111 with dissolve
    ca "Hi, guys!"
    uk "Camille's not Cyrax, but she's coming with a noob, it don't matter 'cause she's the hottest sister in the hood...Sup, girl?"
    scene im1113 with dissolve
    uk "Hey, girl! You're looking fine! Where's the party at?!"
    ca "Hehehe...we're going clubbing later, just came by to say hi..."
    pt "Are we?"
    scene im1114 with dissolve
    ca "Oh, Makena, Flavor, this is [p]..."
    mak "Hi, there!"
    fla "Sup, G?"
    p "Hey...not much."
    mak "You're here to dance?"
    p "I can't hear the music."
    scene im1115 with dissolve
    mak "My girl Jordan is bringing her speaker."
    fla "Yeah, that's what's up."
    scene im1116 with dissolve
    ca "Oh, Raygun is here..."
    mak "Don't call her!"
    ca "Poor girl, nobody wants to battle her anymore."
    p "Why not?"
    ca "Mmm...where do I start?"
    scene im1117 with dissolve
    mak "She's a bad loser, that's why, never accepts defeat...last week she kicked Jordan's speaker after losing her battle!"
    ca "Oh my God, yeah, I remember...J got so angry, almost punched her in the face!"
    scene im1118 with dissolve
    uk "I'll do it tonight if she can't control herself."
    ca "J!"
    jd "Help me out, Flav."
    scene im1119 with dissolve
    jd "Hey, baby, I feel like a midget tonight! You look stunning!"
    ca "Hehe, thanks, baby...J, there's someone I'd like you to meet..."
    scene im1120 with dissolve
    jd "What's up, buddy? I'm Jordan."
    scene im1120a with dissolve
    p "Hey! [p]."
    jd "Who's this, Cami? Your boyfriend?"
    scene im1121 with dissolve
    ca "If he wants to, hehehe."
    jd "You heard my girl, make your move, buddy!"
    pt "I wouldn't mind a threesome..."
    scene im1122 with dissolve
    fla "We ready, peopleeeee!"
    scene im1123 with dissolve
    ray "Jordan, I'm very sorry about last week...can I dance with you guys?"
    jd "Last chance, Rachael, if you do something like that again I'm through with you!"
    ray "It won't happen again, I promise..."
    jd "Last chance, Rachael, last chance."
    scene im1124 with dissolve
    pause
    scene im1125 with dissolve
    ca "There're no battles tonight, just practice, Jordan just told me..."
    ca "It would've been fun to watch one, crews from other neighborhoods come to compete...I like it..."
    p "That does sound fun! I'd like to see you dance in one of those battles...with the proper clothes, of course..."
    scene im1126 with dissolve
    ca "Haha, I'll let you know then!"
    p "I can't believe how versatile you are: you work at a library, can be super sexy and sweet at the same time...and now you're into breakdancing?! You're full of surprises, Cam!"
    scene im1127 with dissolve
    ca "I may have more surprises for you...actually, the next one is in my place...what do you say?"
    p "What do I...Let's go! Now!"
    stop music fadeout 2

    scene black with Dissolve(2)


label camsex3:

    if _in_replay:
        $ pf = persistent.p

    scene im1179 with Dissolve(1)
    play music "audio/sensual2.mp3"
    p "Your skin's so soft, Cami..."
    p "And your scent is so intoxicating...I love it..."
    ca "I want to know everything you love about me, haha."
    scene black with dissolve
    scene im1128 with dissolve
    p "Your moves, too..."
    scene im1129 with dissolve
    ca "I know! I already showed them to you in the library, hahaha."
    p "Brrrrr..."
    scene im1130 with dissolve
    p "Brrrrr..."
    ca "Hahaha..."
    scene im1130a with dissolve
    ca "Get comfortable now..."
    p "Oooh, yeah, come here with me."
    ca "Not so fast..."
    p "But I'm so ready!"
    ca "I know you are..."
    scene im1131 with dissolve
    stop music fadeout 3
    ca "I didn't dress up to not show it off...let me model this dress for you!"
    p "Oh, yeah, please, do that! I'll get more comfortable then..."
    scene black with dissolve
    play music "audio/hotrocknroll.ogg"
    scene im1132 with dissolve
    p "Maaaaann...I love your body..."

    scene im1133:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    ca "Hahaha, I know you love my boobs!"
    p "Your boobs, your legs, your feet, everything!"

    call screen camroom1

    screen camroom1():
        modal True

        viewport:

            add "im1133"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("camroom2")

label camroom2:

    call screen camroom2

    screen camroom2():
        modal True

        viewport:

            add "im1134"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("camroom3")

label camroom3:

    call screen camroom3

    screen camroom3():
        modal True

        viewport:

            add "im1135"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("camroomsex")

label camroomsex:

    scene im1136
    pause
    p "I'm sorry, but I can't keep waiting..."
    ca "Haha, come get it!"
    scene im1137 with dissolve
    p "Nope, it's not gonna work...you're gonna have to bend your knees a little..."
    ca "Haha, you really are short!"
    scene im1138 with dissolve
    p "Ha-ha, very funny...you love me anyways, after all, you're all dressed up just for me."
    ca "Haha, you think way too much of yourself...I did not dress up for you!"
    p "Liar! You're gonna pay for that."
    scene im1139 with dissolve
    ca "No, please! Don't do it too hard!"
    p "You're asking for it!"
    scene im1140 with dissolve
    ca "You can't get in there if I don't bend anyways..."
    p "Okay, that's it!"
    stop music fadeout 3
    scene black with dissolve
    scene im1143 with dissolve
    ca "What is that I'm feeling?"
    p "Where's your pussy?"
    play sound "audio/oh2.mp3" volume 3
    scene im1144 with hpunch
    p "Here!"
    scene im1141 with dissolve
    ca "Oh, my God, I needed your cock so much!"
    p "Yeah?"
    play sound "audio/femorg16.mp3" volume 2
    scene im1142 with vpunch
    p "There! Take it!"
    scene im1141 with dissolve
    pause
    play sound "audio/femorg16.mp3" volume 2
    scene im1142 with vpunch
    pause
    scene im1145 with dissolve
    pause
    play sound "audio/oh1.mp3" volume 3
    scene im1146 with vpunch
    pause
    p "Take this dress off, it's getting on my way!"
    scene black with dissolve

    play music "audio/masquerade.mp3"

    scene im1147 with dissolve

    scene im1147:
        pause 0.0266
        "im1148"
        pause 0.0266
        "im1149"
        pause 0.0266
        "im1150"
        pause 0.0266
        "im1151"
        pause 0.0266
        "im1152"
        pause 0.0266
        "im1153"
        pause 0.0266
        "im1154"
        pause 0.0266
        "im1155"
        pause 0.0266
        "im1156"
        pause 0.0266
        "im1157"
        pause 0.0266
        "im1158"
        pause 0.0266
        "im1159"
        pause 0.0266
        "im1160"
        pause 0.0266
        "im1161"
        pause 0.0266
        "im1162"
        pause 0.0266
        "im1163"
        pause 0.0266
        "im1164"
        pause 0.0266
        "im1165"
        pause 0.0266
        "im1166"
        pause 0.0266
        "im1167"
        pause 0.0266
        "im1168"
        pause 0.0266
        "im1169"
        pause 0.0266
        "im1170"
        pause 0.0266
        "im1171"
        pause 0.0266
        "im1172"
        pause 0.0266
        "im1173"
        pause 0.0266
        "im1174"
        pause 0.0266
        "im1175"
        pause 0.0266
        "im1176"
        pause 0.0266
        repeat
    pause

    ca "How's my pussy?"
    p "Soaking..."
    p "Hot..."
    p "Tight..."
    p "I wouldn't like it otherwise."
    ca "Oh, you're mean..."

    scene im1147:
        pause 0.0233
        "im1148"
        pause 0.0233
        "im1149"
        pause 0.0233
        "im1150"
        pause 0.0233
        "im1151"
        pause 0.0233
        "im1152"
        pause 0.0233
        "im1153"
        pause 0.0233
        "im1154"
        pause 0.0233
        "im1155"
        pause 0.0233
        "im1156"
        pause 0.0233
        "im1157"
        pause 0.0233
        "im1158"
        pause 0.0233
        "im1159"
        pause 0.0233
        "im1160"
        pause 0.0233
        "im1161"
        pause 0.0233
        "im1162"
        pause 0.0233
        "im1163"
        pause 0.0233
        "im1164"
        pause 0.0233
        "im1165"
        pause 0.0233
        "im1166"
        pause 0.0233
        "im1167"
        pause 0.0233
        "im1168"
        pause 0.0233
        "im1169"
        pause 0.0233
        "im1170"
        pause 0.0233
        "im1171"
        pause 0.0233
        "im1172"
        pause 0.0233
        "im1173"
        pause 0.0233
        "im1174"
        pause 0.0233
        "im1175"
        pause 0.0233
        "im1176"
        pause 0.0233
        repeat
    pause

    ca "Oh, your cock just got harder!"
    p "You love it, don't you?"
    ca "It drives me crazy!"

    scene im1147:
        pause 0.0166
        "im1148"
        pause 0.0166
        "im1149"
        pause 0.0166
        "im1150"
        pause 0.0166
        "im1151"
        pause 0.0166
        "im1152"
        pause 0.0166
        "im1153"
        pause 0.0166
        "im1154"
        pause 0.0166
        "im1155"
        pause 0.0166
        "im1156"
        pause 0.0166
        "im1157"
        pause 0.0166
        "im1158"
        pause 0.0166
        "im1159"
        pause 0.0166
        "im1160"
        pause 0.0166
        "im1161"
        pause 0.0166
        "im1162"
        pause 0.0166
        "im1163"
        pause 0.0166
        "im1164"
        pause 0.0166
        "im1165"
        pause 0.0166
        "im1166"
        pause 0.0166
        "im1167"
        pause 0.0166
        "im1168"
        pause 0.0166
        "im1169"
        pause 0.0166
        "im1170"
        pause 0.0166
        "im1171"
        pause 0.0166
        "im1172"
        pause 0.0166
        "im1173"
        pause 0.0166
        "im1174"
        pause 0.0166
        "im1175"
        pause 0.0166
        "im1176"
        pause 0.0166
        repeat
    pause 4

    play sound "audio/femorg17.mp3" volume 16

    scene im1177 with vpunch
    scene im1177 with vpunch
    scene im1177 with dissolve
    scene im1177 with vpunch
    pause 1.5
    scene im1178 with Dissolve(2)
    stop music fadeout 3
    stop sound fadeout 3
    pause
    ca "Oh, God, you make me come so easily every time..."
    scene black with Dissolve(1)

    play music "audio/trainingnighthot.mp3"

    scene im1230 with dissolve
    p "You're a real hot view, Cami..."
    ca "Put it in, why it's not in?!"
    scene im1230a with dissolve
    p "You just can't wait, haha..."
    scene im1230b with vpunch
    p "There!"
    p "How do you like it?"
    scene im1231 with dissolve
    ca "I think I love you! Hahaha."
    p "Me or my cock?"
    scene im1232 with vpunch
    ca "Ahhh!"
    ca "I can't decide!"

    scene im1180 with dissolve

    scene im1180:
        pause 0.0222
        "im1181"
        pause 0.0222
        "im1182"
        pause 0.0222
        "im1183"
        pause 0.0222
        "im1184"
        pause 0.0222
        "im1185"
        pause 0.0222
        "im1186"
        pause 0.0222
        "im1187"
        pause 0.0222
        "im1188"
        pause 0.0222
        "im1189"
        pause 0.0222
        "im1190"
        pause 0.0222
        "im1191"
        pause 0.0222
        "im1192"
        pause 0.0222
        "im1193"
        pause 0.0222
        "im1194"
        pause 0.0222
        "im1195"
        pause 0.0222
        "im1196"
        pause 0.0222
        "im1197"
        pause 0.0222
        "im1198"
        pause 0.0222
        "im1199"
        pause 0.0222
        "im1200"
        pause 0.0222
        "im1201"
        pause 0.0222
        "im1202"
        pause 0.0222
        "im1203"
        pause 0.0222
        "im1204"
        pause 0.0222
        "im1205"
        pause 0.0222
        "im1206"
        pause 0.0222
        "im1207"
        pause 0.0222
        "im1208"
        pause 0.0222
        "im1209"
        pause 0.0222
        "im1210"
        pause 0.0222
        "im1211"
        pause 0.0222
        "im1212"
        pause 0.0222
        "im1213"
        pause 0.0222
        "im1214"
        pause 0.0222
        "im1215"
        pause 0.0222
        "im1216"
        pause 0.0222
        "im1217"
        pause 0.0222
        "im1218"
        pause 0.0222
        "im1219"
        pause 0.0222
        "im1220"
        pause 0.0222
        "im1221"
        pause 0.0222
        "im1222"
        pause 0.0222
        "im1223"
        pause 0.0222
        "im1224"
        pause 0.0222
        "im1225"
        pause 0.0222
        "im1226"
        pause 0.0222
        "im1227"
        pause 0.0222
        "im1228"
        pause 0.0222
        "im1229"
        pause 0.0222
        repeat
    pause

    p "Oh, fuck! Your pussy feels amazing!"
    ca "You can have it whenever you want..."
    p "Yeah?"
    p "That's an offer I can't refuse..."

    scene im1180:
        pause 0.0166
        "im1181"
        pause 0.0166
        "im1182"
        pause 0.0166
        "im1183"
        pause 0.0166
        "im1184"
        pause 0.0166
        "im1185"
        pause 0.0166
        "im1186"
        pause 0.0166
        "im1187"
        pause 0.0166
        "im1188"
        pause 0.0166
        "im1189"
        pause 0.0166
        "im1190"
        pause 0.0166
        "im1191"
        pause 0.0166
        "im1192"
        pause 0.0166
        "im1193"
        pause 0.0166
        "im1194"
        pause 0.0166
        "im1195"
        pause 0.0166
        "im1196"
        pause 0.0166
        "im1197"
        pause 0.0166
        "im1198"
        pause 0.0166
        "im1199"
        pause 0.0166
        "im1200"
        pause 0.0166
        "im1201"
        pause 0.0166
        "im1202"
        pause 0.0166
        "im1203"
        pause 0.0166
        "im1204"
        pause 0.0166
        "im1205"
        pause 0.0166
        "im1206"
        pause 0.0166
        "im1207"
        pause 0.0166
        "im1208"
        pause 0.0166
        "im1209"
        pause 0.0166
        "im1210"
        pause 0.0166
        "im1211"
        pause 0.0166
        "im1212"
        pause 0.0166
        "im1213"
        pause 0.0166
        "im1214"
        pause 0.0166
        "im1215"
        pause 0.0166
        "im1216"
        pause 0.0166
        "im1217"
        pause 0.0166
        "im1218"
        pause 0.0166
        "im1219"
        pause 0.0166
        "im1220"
        pause 0.0166
        "im1221"
        pause 0.0166
        "im1222"
        pause 0.0166
        "im1223"
        pause 0.0166
        "im1224"
        pause 0.0166
        "im1225"
        pause 0.0166
        "im1226"
        pause 0.0166
        "im1227"
        pause 0.0166
        "im1228"
        pause 0.0166
        "im1229"
        pause 0.0166
        repeat
    pause

    p "I can get used to this."
    ca "Me cumming all day you say? 'Cause I'm so close..."

    scene im1180:
        pause 0.0133
        "im1181"
        pause 0.0133
        "im1182"
        pause 0.0133
        "im1183"
        pause 0.0133
        "im1184"
        pause 0.0133
        "im1185"
        pause 0.0133
        "im1186"
        pause 0.0133
        "im1187"
        pause 0.0133
        "im1188"
        pause 0.0133
        "im1189"
        pause 0.0133
        "im1190"
        pause 0.0133
        "im1191"
        pause 0.0133
        "im1192"
        pause 0.0133
        "im1193"
        pause 0.0133
        "im1194"
        pause 0.0133
        "im1195"
        pause 0.0133
        "im1196"
        pause 0.0133
        "im1197"
        pause 0.0133
        "im1198"
        pause 0.0133
        "im1199"
        pause 0.0133
        "im1200"
        pause 0.0133
        "im1201"
        pause 0.0133
        "im1202"
        pause 0.0133
        "im1203"
        pause 0.0133
        "im1204"
        pause 0.0133
        "im1205"
        pause 0.0133
        "im1206"
        pause 0.0133
        "im1207"
        pause 0.0133
        "im1208"
        pause 0.0133
        "im1209"
        pause 0.0133
        "im1210"
        pause 0.0133
        "im1211"
        pause 0.0133
        "im1212"
        pause 0.0133
        "im1213"
        pause 0.0133
        "im1214"
        pause 0.0133
        "im1215"
        pause 0.0133
        "im1216"
        pause 0.0133
        "im1217"
        pause 0.0133
        "im1218"
        pause 0.0133
        "im1219"
        pause 0.0133
        "im1220"
        pause 0.0133
        "im1221"
        pause 0.0133
        "im1222"
        pause 0.0133
        "im1223"
        pause 0.0133
        "im1224"
        pause 0.0133
        "im1225"
        pause 0.0133
        "im1226"
        pause 0.0133
        "im1227"
        pause 0.0133
        "im1228"
        pause 0.0133
        "im1229"
        pause 0.0133
        repeat
    pause

    ca "Baby, let's come together!"
    p "Yeah, almost there..."
    ca "Don't pull out, I want to feel your warm cum inside! You know I love it..."

    scene im1233 with flash
    scene im1233 with vpunch
    scene im1233 with flash
    scene im1233 with vpunch
    scene im1233 with dissolve
    pause
    ca "Oh, my God, oh, my God, more is coming!"
    play sound "audio/cum1.mp3" volume 16
    scene im1234 with vpunch
    scene im1234 with vpunch
    scene im1234 with dissolve
    pause 1
    scene im1235 with Dissolve(2)
    ca "You look very sexy all wet, baby, hahaha..."
    p "You get a free pass today...just because I'm so comfortable inside you..."
    stop music fadeout 3
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    jump choice80_common

label choice80b:

    $ choice80b = True

    stop music fadeout 3
    scene im379 with dissolve
    p "I can't today, sorry, I already told my friend I'll meet her after training."
    scene im380 with dissolve
    jo "That's okay, maybe some other time..."
    p "Yup."
    scene black with Dissolve(2)

    play music "audio/reflecting.mp3"
    scene im1240 with Dissolve(2)
    an "[p]! Right on time!"
    p "Hey, Annie."
    an "We were about to choose the movie..."
    scene im1241 with dissolve
    an "Welcome!"
    p "Haha, so much affection, Annie."
    an "You know me."
    scene black with dissolve
    scene im1242 with dissolve
    p "Hey, Riv, what are we watching?"
    ri "Ann wants to watch a drama, doesn't have enough with her life..."
    p "Haha...I wouldn't mind a drama as long as it has a lesson at the end."
    an "See?"
    ri "I hate you two."
    scene black with dissolve
    scene im1243 with dissolve
    pause
    scene im1244 with dissolve
    pause
    scene im1245 with dissolve
    pause
    scene im1246 with dissolve
    pause
    scene im1247 with dissolve
    p "Let me pause it real quick, I want to tell you something..."
    scene im1248 with dissolve
    p "Annie..."
    scene im1249 with dissolve
    p "Rivka...haha, it's nothing bad..."
    p "I just wanted to thank you for treating me like this..."
    scene im1248 with dissolve
    p "As if nothing had happened, you know? You don't bring \"it\" up, you're not asking me if I'm okay all the time as if I were the fucking victim here..."
    scene im1250 with dissolve
    p "You don't blame me...I usually don't share these things, but I see how much you care about me inviting me to do stuff with you..."
    scene im1251 with dissolve
    p "It's your way to check on me, isn't it? I don't want you to worry about me..."
    p "Yeah, it's true: sometimes I feel like losing control...other times I'm sad...angry...very angry..."
    scene im1250 with dissolve
    p "But I know I'm gonna be fine, I'll get through this...and the reason why I know it, it's because I have people like you in my life..."
    scene im1252 with dissolve
    p "Thank you, Annie..."
    scene im1253 with dissolve
    p "Thank you, Riv..."
    scene im1252 with dissolve
    p "I love you."
    scene im1254 with dissolve
    an "I love you, too!"
    scene im1255 with dissolve
    ri "I'm not going to say that, I'm not that dramatic, but...I like you a little more today..."
    p "Haha."
    stop music fadeout 3
    scene im1256 with dissolve
    uk "Hi, there!"

    scene im1257:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/needunow.mp3"
    pause
    an "Oh, hi, mom!"
    pt "That's your mom! My God, she lit up the room...literally! She's gorgeous!"
    an "Mom, these are my friends from college: Rivka and [p]."
    ri "Good afternoon, Mrs. Myers."
    p "Hi, Mrs. Myers."
    bl "I'm Blythe, call me Blythe."

    call screen blytheentrance

    screen blytheentrance():
        modal True

        viewport:

            add "im1257"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("blythedoor1")

label blythedoor1:

    scene im1258 with dissolve
    bl "I'll be in my room, baby..."
    pt "Nooooo, there's room for one more here...man, I do have a thing for older women..."
    an "Okay, mom...maybe I'll order something to eat later, is that ok?"
    bl "Sure, baby, no problem."
    stop music fadeout 3
    scene black with Dissolve(1)
    scene im1259 with Dissolve(1)
    pause
    play music "audio/sadpiano1.ogg"
    pt "I really hope I don't ever have to go back to college...it'd mean I failed, I gave up on my dream..."
    pt "I can't do that, there're people who believe in me, YOU believed in me..."
    pt "I thought I was wasting my time in St. Francis, but I met the best person in the world by going there...God, it hurts so much when I think of you, S..."
    scene im1260 with dissolve
    pt "Just let me tell you this, Samantha: I know why I like being with these two so much..."
    pt "Ann is so kind-hearted...just like you..."
    pt "Rivka is so smart...just like you..."
    pt "You liked them, too, didn't you?"

    stop music fadeout 3
    scene black with Dissolve(3.0)

    jump choice80_common

label choice80_common:

    jump ep8
