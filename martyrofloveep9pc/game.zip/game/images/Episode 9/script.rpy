#Important Decisions
default choice88a = False
default choice88b = False




# Start Episode 9
label ep9ann:

    pause

    $ renpy.movie_cutscene("videos/answers.ogv")

    scene i780 with Dissolve(2)
    play music "audio/intromovido.ogg"
    vi "Thank you so much for visiting me...I wasn't expecting it at all, what a pleasant surprise..."
    scene i781 with dissolve
    vi "I really appreciate you taking the time to come...Errr, could you tell me your daughters' names again, please?"
    scene i782 with dissolve
    pen "Jessica Moore is my daughter, and I'm Penelope, by the way."
    scene i782a with dissolve

    call screen jessdance

    screen jessdance():
        modal True

        viewport:

            add "i782a"
            mousewheel True

        imagebutton auto "jd1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "jd1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jdance")

label jdance:

    show jd1:
        pause 0.0266
        "jd2"
        pause 0.0266
        "jd3"
        pause 0.0266
        "jd4"
        pause 0.0266
        "jd5" 
        pause 0.0266
        "jd6"
        pause 0.0266
        "jd7"
        pause 0.0266
        "jd8"
        pause 0.0266
        "jd9"
        pause 0.0266
        "jd10"
        pause 0.0266
        "jd11"
        pause 0.0266
        "jd12"
        pause 0.0266
        "jd13"
        pause 0.0266
        "jd14"
        pause 0.0266
        "jd15" 
        pause 0.0266
        "jd16"
        pause 0.0266
        "jd17"
        pause 0.0266
        "jd18"
        pause 0.0266
        "jd19"
        pause 0.0266
        "jd20"
        pause 0.0266
        "jd21"
        pause 0.0266
        "jd22"
        pause 0.0266
        "jd23"
        pause 0.0266
        "jd24"
        pause 0.0266
        "jd25" 
        pause 0.0266
        "jd26"
        pause 0.0266
        "jd27"
        pause 0.0266
        "jd28"
        pause 0.0266
        "jd29"
        pause 0.0266
        "jd30"
        pause 0.0266
        "jd31"
        pause 0.0266
        "jd32"
        pause 0.0266
        "jd33"
        pause 0.0266
        "jd34"
        pause 0.0266
        "jd35" 
        pause 0.0266
        "jd36"
        pause 0.0266
        "jd37"
        pause 0.0266
        "jd38"
        pause 0.0266
        "jd39"
        pause 0.0266
        "jd40"
        pause 0.0266
        "jd41"
        pause 0.0266
        "jd42"
        pause 0.0266
        "jd43"
        pause 0.0266
        "jd44"
        pause 0.0266
        "jd45" 
        pause 0.0266
        "jd46"
        pause 0.0266
        "jd47"
        pause 0.0266
        "jd48"
        pause 0.0266
        "jd49"
        pause 0.0266
        "jd50"
        pause 0.0266
        "jd51"
        pause 0.0266
        "jd52"
        pause 0.0266
        "jd53"
        pause 0.0266
        "jd54"
        pause 0.0266
        "jd55" 
        pause 0.0266
        "jd56"
        pause 0.0266
        "jd57"
        pause 0.0266
        "jd58"
        pause 0.0266
        "jd59"
        pause 0.0266
        "jd60"
        pause 0.0266
        "jd61"
        pause 0.0266
        "jd62"
        pause 0.0266
        "jd63"
        pause 0.0266
        "jd64"
        pause 0.0266
        "jd65" 
        pause 0.0266
        "jd66"
        pause 0.0266
        "jd67"
        pause 0.0266
        "jd68"
        pause 0.0266
        "jd69"
        pause 0.0266
        "jd70"
        pause 0.0266
        "jd71"
        pause 0.0266
        "jd72"
        pause 0.0266
        "jd73"
        pause 0.0266
        "jd74"
        pause 0.0266
        "jd75" 
        pause 0.0266
        "jd76"
        pause 0.0266
        "jd77"
        pause 0.0266
        "jd78"
        pause 0.0266
        "jd79"
        pause 0.0266
        "jd80"
        pause 0.0266
        "jd81"
        pause 0.0266
        "jd82"
        pause 0.0266
        "jd83"
        pause 0.0266
        "jd84"
        pause 0.0266
        "jd85" 
        pause 0.0266
        "jd86"
        pause 0.0266
        "jd87"
        pause 0.0266
        "jd88"
        pause 0.0266
        "jd89"
        pause 0.0266
        "jd90"
        pause 0.0266
        "jd91"
        pause 0.0266
        "jd92"
        pause 0.0266
        "jd93"
        pause 0.0266
        "jd94"
        pause 0.0266
        "jd95" 
        pause 0.0266
        "jd96"
        pause 0.0266
        "jd97"
        pause 0.0266
        "jd98"
        pause 0.0266
        "jd99"
        pause 0.0266
        "jd100"
        pause 0.0266
        "jd101"
        pause 0.0266
        "jd102"
        pause 0.0266
        "jd103"
        pause 0.0266
        "jd104"
        pause 0.0266
        "jd105"
        pause 0.0266
        "jd106"
        pause 0.0266
        "jd107"
        pause 0.0266
        "jd108"
        pause 0.0266
        "jd109"
        pause 0.0266
        "jd110"
        pause 0.0266
        "jd111"
        pause 0.0266
        "jd112"
        pause 0.0266
        "jd113"
        pause 0.0266
        "jd114"
        pause 0.0266
        "jd115"
        pause 0.0266
        "jd116"
        pause 0.0266
    pause

    scene i783 with dissolve
    bl "I'm Ann Myers's mom, Blythe."

    scene i783a with dissolve

    call screen anndance

    screen anndance():
        modal True

        viewport:

            add "i783a"
            mousewheel True

        imagebutton auto "ad1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "ad1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("adance")

label adance:

    show ad1:
        pause 0.0266
        "ad2"
        pause 0.0266
        "ad3"
        pause 0.0266
        "ad4"
        pause 0.0266
        "ad5" 
        pause 0.0266
        "ad6"
        pause 0.0266
        "ad7"
        pause 0.0266
        "ad8"
        pause 0.0266
        "ad9"
        pause 0.0266
        "ad10"
        pause 0.0266
        "ad11"
        pause 0.0266
        "ad12"
        pause 0.0266
        "ad13"
        pause 0.0266
        "ad14"
        pause 0.0266
        "ad15" 
        pause 0.0266
        "ad16"
        pause 0.0266
        "ad17"
        pause 0.0266
        "ad18"
        pause 0.0266
        "ad19"
        pause 0.0266
        "ad20"
        pause 0.0266
        "ad21"
        pause 0.0266
        "ad22"
        pause 0.0266
        "ad23"
        pause 0.0266
        "ad24"
        pause 0.0266
        "ad25" 
        pause 0.0266
        "ad26"
        pause 0.0266
        "ad27"
        pause 0.0266
        "ad28"
        pause 0.0266
        "ad29"
        pause 0.0266
        "ad30"
        pause 0.0266
        "ad31"
        pause 0.0266
        "ad32"
        pause 0.0266
        "ad33"
        pause 0.0266
        "ad34"
        pause 0.0266
        "ad35" 
        pause 0.0266
        "ad36"
        pause 0.0266
        "ad37"
        pause 0.0266
        "ad38"
        pause 0.0266
        "ad39"
        pause 0.0266
        "ad40"
        pause 0.0266
        "ad41"
        pause 0.0266
        "ad42"
        pause 0.0266
        "ad43"
        pause 0.0266
        "ad44"
        pause 0.0266
        "ad45" 
        pause 0.0266
        "ad46"
        pause 0.0266
        "ad47"
        pause 0.0266
        "ad48"
        pause 0.0266
        "ad49"
        pause 0.0266
        "ad50"
        pause 0.0266
        "ad51"
        pause 0.0266
        "ad52"
        pause 0.0266
        "ad53"
        pause 0.0266
        "ad54"
        pause 0.0266
        "ad55" 
        pause 0.0266
        "ad56"
        pause 0.0266
        "ad57"
        pause 0.0266
        "ad58"
        pause 0.0266
        "ad59"
        pause 0.0266
        "ad60"
        pause 0.0266
        "ad61"
        pause 0.0266
        "ad62"
        pause 0.0266
        "ad63"
        pause 0.0266
        "ad64"
        pause 0.0266
        "ad65" 
        pause 0.0266
        "ad66"
        pause 0.0266
        "ad67"
        pause 0.0266
        "ad68"
        pause 0.0266
        "ad69"
        pause 0.0266
        "ad70"
        pause 0.0266
        "ad71"
        pause 0.0266
        "ad72"
        pause 0.0266
        "ad73"
        pause 0.0266
        "ad74"
        pause 0.0266
        "ad75" 
        pause 0.0266
        "ad76"
        pause 0.0266
        "ad77"
        pause 0.0266
        "ad78"
        pause 0.0266
        "ad79"
        pause 0.0266
        "ad80"
        pause 0.0266
        "ad81"
        pause 0.0266
        "ad82"
        pause 0.0266
        "ad83"
        pause 0.0266
        "ad84"
        pause 0.0266
        "ad85" 
        pause 0.0266
    pause

    scene i784 with dissolve
    sve "And I'm Sveta, my daughter is Rivka."

    scene i784a with dissolve

    call screen rivdance

    screen rivdance():
        modal True

        viewport:

            add "i784a"
            mousewheel True

        imagebutton auto "rd1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "rd1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("rdance")

label rdance:

    show rd1:
        pause 0.0266
        "rd2"
        pause 0.0266
        "rd3"
        pause 0.0266
        "rd4"
        pause 0.0266
        "rd5" 
        pause 0.0266
        "rd6"
        pause 0.0266
        "rd7"
        pause 0.0266
        "rd8"
        pause 0.0266
        "rd9"
        pause 0.0266
        "rd10"
        pause 0.0266
        "rd11"
        pause 0.0266
        "rd12"
        pause 0.0266
        "rd13"
        pause 0.0266
        "rd14"
        pause 0.0266
        "rd15" 
        pause 0.0266
        "rd16"
        pause 0.0266
        "rd17"
        pause 0.0266
        "rd18"
        pause 0.0266
        "rd19"
        pause 0.0266
        "rd20"
        pause 0.0266
        "rd21"
        pause 0.0266
        "rd22"
        pause 0.0266
        "rd23"
        pause 0.0266
        "rd24"
        pause 0.0266
        "rd25" 
        pause 0.0266
        "rd26"
        pause 0.0266
        "rd27"
        pause 0.0266
        "rd28"
        pause 0.0266
        "rd29"
        pause 0.0266
        "rd30"
        pause 0.0266
        "rd31"
        pause 0.0266
        "rd32"
        pause 0.0266
        "rd33"
        pause 0.0266
        "rd34"
        pause 0.0266
        "rd35" 
        pause 0.0266
        "rd36"
        pause 0.0266
        "rd37"
        pause 0.0266
        "rd38"
        pause 0.0266
        "rd39"
        pause 0.0266
        "rd40"
        pause 0.0266
        "rd41"
        pause 0.0266
        "rd42"
        pause 0.0266
        "rd43"
        pause 0.0266
        "rd44"
        pause 0.0266
        "rd45" 
        pause 0.0266
        "rd46"
        pause 0.0266
        "rd47"
        pause 0.0266
        "rd48"
        pause 0.0266
        "rd49"
        pause 0.0266
        "rd50"
        pause 0.0266
        "rd51"
        pause 0.0266
        "rd52"
        pause 0.0266
        "rd53"
        pause 0.0266
        "rd54"
        pause 0.0266
        "rd55" 
        pause 0.0266
        "rd56"
        pause 0.0266
        "rd57"
        pause 0.0266
        "rd58"
        pause 0.0266
        "rd59"
        pause 0.0266
    pause
    vi "Oh, Rivka! Yes, adorable girl, well mannered..."
    scene i785 with dissolve
    pen "Vittoria, we usually do different types of volunteer work and we wanted to invite you to join us...or just to go to the theater, we do that a lot, too!"
    vi "Oh, thank you so much, but..."
    scene i786 with dissolve
    ed "She will go!"
    vi "Ladies...my mom Edwige and my sister, Ginevra."    
    scene i787 with dissolve
    ed "Bisogna che tu esca di casa, figlia..."
    vi "She's worried because I haven't left the house lately..."
    scene i788 with dissolve
    sve "Don't stress about it, Edwige, I know we should've come sooner, but we'll do anything to support your daughter from now on."
    ed "Thank you!"
    sve "Oh, we brought something for Vittoria, it's in my car, I'll be back in a minute..."
    stop music fadeout 2
    scene black with Dissolve(1)
    scene i800 with Dissolve(1)
    play music "audio/forestambient.mp3"
    ed "Sei bellissima, Vivi."
    vi "I don't know, mom...I feel fat..."
    scene i801 with dissolve
    sve "Fat? You have the perfect body! It fits you perfectly!"

    scene i802:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    vi "It is a beautiful dress...and I love the color...thank you so much, Sveta."
    sve "But try the others if that one doesn't convince you..."

    call screen vitrying

    screen vitrying():
        modal True

        viewport:

            add "i802"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying1")

label vitrying1:

    scene i803:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    vi "I'm not young anymore to be wearing something like this, don't you think?"
    sve "Again: with that body, everything looks good on you, Vittoria."

    call screen vitryinga

    screen vitryinga():
        modal True

        viewport:

            add "i803"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying2")

label vitrying2:

    scene i804:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    ed "Perfect!"
    vi "I love it, yes...it looks expensive, I don't think I can accept it..."
    
    call screen vitryingb

    screen vitryingb():
        modal True

        viewport:

            add "i804"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying3")

label vitrying3:

    scene i805 with dissolve
    sve "Oh, shut ut, we're here to see you smile again. You're very welcome!"
    stop music fadeout 3
    scene black with Dissolve(3)
    jump amandaof


label ep9:

    pause

    $ renpy.movie_cutscene("videos/answers.ogv")

    scene i780 with Dissolve(2)
    play music "audio/intromovido.ogg"
    vi "Thank you so much for visiting me...I wasn't expecting it at all, what a pleasant surprise..."
    scene i781 with dissolve
    vi "I really appreciate you taking the time to come...Errr, could you tell me your daughters' names again, please?"
    scene i782 with dissolve
    pen "Jessica Moore is my daughter, and I'm Penelope, by the way."

    scene i782a with dissolve

    call screen jessdance1

    screen jessdance1():
        modal True

        viewport:

            add "i782a"
            mousewheel True

        imagebutton auto "jd1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "jd1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jdance1")

label jdance1:

    show jd1:
        pause 0.0266
        "jd2"
        pause 0.0266
        "jd3"
        pause 0.0266
        "jd4"
        pause 0.0266
        "jd5" 
        pause 0.0266
        "jd6"
        pause 0.0266
        "jd7"
        pause 0.0266
        "jd8"
        pause 0.0266
        "jd9"
        pause 0.0266
        "jd10"
        pause 0.0266
        "jd11"
        pause 0.0266
        "jd12"
        pause 0.0266
        "jd13"
        pause 0.0266
        "jd14"
        pause 0.0266
        "jd15" 
        pause 0.0266
        "jd16"
        pause 0.0266
        "jd17"
        pause 0.0266
        "jd18"
        pause 0.0266
        "jd19"
        pause 0.0266
        "jd20"
        pause 0.0266
        "jd21"
        pause 0.0266
        "jd22"
        pause 0.0266
        "jd23"
        pause 0.0266
        "jd24"
        pause 0.0266
        "jd25" 
        pause 0.0266
        "jd26"
        pause 0.0266
        "jd27"
        pause 0.0266
        "jd28"
        pause 0.0266
        "jd29"
        pause 0.0266
        "jd30"
        pause 0.0266
        "jd31"
        pause 0.0266
        "jd32"
        pause 0.0266
        "jd33"
        pause 0.0266
        "jd34"
        pause 0.0266
        "jd35" 
        pause 0.0266
        "jd36"
        pause 0.0266
        "jd37"
        pause 0.0266
        "jd38"
        pause 0.0266
        "jd39"
        pause 0.0266
        "jd40"
        pause 0.0266
        "jd41"
        pause 0.0266
        "jd42"
        pause 0.0266
        "jd43"
        pause 0.0266
        "jd44"
        pause 0.0266
        "jd45" 
        pause 0.0266
        "jd46"
        pause 0.0266
        "jd47"
        pause 0.0266
        "jd48"
        pause 0.0266
        "jd49"
        pause 0.0266
        "jd50"
        pause 0.0266
        "jd51"
        pause 0.0266
        "jd52"
        pause 0.0266
        "jd53"
        pause 0.0266
        "jd54"
        pause 0.0266
        "jd55" 
        pause 0.0266
        "jd56"
        pause 0.0266
        "jd57"
        pause 0.0266
        "jd58"
        pause 0.0266
        "jd59"
        pause 0.0266
        "jd60"
        pause 0.0266
        "jd61"
        pause 0.0266
        "jd62"
        pause 0.0266
        "jd63"
        pause 0.0266
        "jd64"
        pause 0.0266
        "jd65" 
        pause 0.0266
        "jd66"
        pause 0.0266
        "jd67"
        pause 0.0266
        "jd68"
        pause 0.0266
        "jd69"
        pause 0.0266
        "jd70"
        pause 0.0266
        "jd71"
        pause 0.0266
        "jd72"
        pause 0.0266
        "jd73"
        pause 0.0266
        "jd74"
        pause 0.0266
        "jd75" 
        pause 0.0266
        "jd76"
        pause 0.0266
        "jd77"
        pause 0.0266
        "jd78"
        pause 0.0266
        "jd79"
        pause 0.0266
        "jd80"
        pause 0.0266
        "jd81"
        pause 0.0266
        "jd82"
        pause 0.0266
        "jd83"
        pause 0.0266
        "jd84"
        pause 0.0266
        "jd85" 
        pause 0.0266
        "jd86"
        pause 0.0266
        "jd87"
        pause 0.0266
        "jd88"
        pause 0.0266
        "jd89"
        pause 0.0266
        "jd90"
        pause 0.0266
        "jd91"
        pause 0.0266
        "jd92"
        pause 0.0266
        "jd93"
        pause 0.0266
        "jd94"
        pause 0.0266
        "jd95" 
        pause 0.0266
        "jd96"
        pause 0.0266
        "jd97"
        pause 0.0266
        "jd98"
        pause 0.0266
        "jd99"
        pause 0.0266
        "jd100"
        pause 0.0266
        "jd101"
        pause 0.0266
        "jd102"
        pause 0.0266
        "jd103"
        pause 0.0266
        "jd104"
        pause 0.0266
        "jd105"
        pause 0.0266
        "jd106"
        pause 0.0266
        "jd107"
        pause 0.0266
        "jd108"
        pause 0.0266
        "jd109"
        pause 0.0266
        "jd110"
        pause 0.0266
        "jd111"
        pause 0.0266
        "jd112"
        pause 0.0266
        "jd113"
        pause 0.0266
        "jd114"
        pause 0.0266
        "jd115"
        pause 0.0266
        "jd116"
        pause 0.0266
    pause

    scene i783 with dissolve
    bl "I'm Ann Myers's mom, Blythe."

    scene i783a with dissolve

    call screen anndance1

    screen anndance1():
        modal True

        viewport:

            add "i783a"
            mousewheel True

        imagebutton auto "ad1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "ad1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("adance1")

label adance1:

    show ad1:
        pause 0.0266
        "ad2"
        pause 0.0266
        "ad3"
        pause 0.0266
        "ad4"
        pause 0.0266
        "ad5" 
        pause 0.0266
        "ad6"
        pause 0.0266
        "ad7"
        pause 0.0266
        "ad8"
        pause 0.0266
        "ad9"
        pause 0.0266
        "ad10"
        pause 0.0266
        "ad11"
        pause 0.0266
        "ad12"
        pause 0.0266
        "ad13"
        pause 0.0266
        "ad14"
        pause 0.0266
        "ad15" 
        pause 0.0266
        "ad16"
        pause 0.0266
        "ad17"
        pause 0.0266
        "ad18"
        pause 0.0266
        "ad19"
        pause 0.0266
        "ad20"
        pause 0.0266
        "ad21"
        pause 0.0266
        "ad22"
        pause 0.0266
        "ad23"
        pause 0.0266
        "ad24"
        pause 0.0266
        "ad25" 
        pause 0.0266
        "ad26"
        pause 0.0266
        "ad27"
        pause 0.0266
        "ad28"
        pause 0.0266
        "ad29"
        pause 0.0266
        "ad30"
        pause 0.0266
        "ad31"
        pause 0.0266
        "ad32"
        pause 0.0266
        "ad33"
        pause 0.0266
        "ad34"
        pause 0.0266
        "ad35" 
        pause 0.0266
        "ad36"
        pause 0.0266
        "ad37"
        pause 0.0266
        "ad38"
        pause 0.0266
        "ad39"
        pause 0.0266
        "ad40"
        pause 0.0266
        "ad41"
        pause 0.0266
        "ad42"
        pause 0.0266
        "ad43"
        pause 0.0266
        "ad44"
        pause 0.0266
        "ad45" 
        pause 0.0266
        "ad46"
        pause 0.0266
        "ad47"
        pause 0.0266
        "ad48"
        pause 0.0266
        "ad49"
        pause 0.0266
        "ad50"
        pause 0.0266
        "ad51"
        pause 0.0266
        "ad52"
        pause 0.0266
        "ad53"
        pause 0.0266
        "ad54"
        pause 0.0266
        "ad55" 
        pause 0.0266
        "ad56"
        pause 0.0266
        "ad57"
        pause 0.0266
        "ad58"
        pause 0.0266
        "ad59"
        pause 0.0266
        "ad60"
        pause 0.0266
        "ad61"
        pause 0.0266
        "ad62"
        pause 0.0266
        "ad63"
        pause 0.0266
        "ad64"
        pause 0.0266
        "ad65" 
        pause 0.0266
        "ad66"
        pause 0.0266
        "ad67"
        pause 0.0266
        "ad68"
        pause 0.0266
        "ad69"
        pause 0.0266
        "ad70"
        pause 0.0266
        "ad71"
        pause 0.0266
        "ad72"
        pause 0.0266
        "ad73"
        pause 0.0266
        "ad74"
        pause 0.0266
        "ad75" 
        pause 0.0266
        "ad76"
        pause 0.0266
        "ad77"
        pause 0.0266
        "ad78"
        pause 0.0266
        "ad79"
        pause 0.0266
        "ad80"
        pause 0.0266
        "ad81"
        pause 0.0266
        "ad82"
        pause 0.0266
        "ad83"
        pause 0.0266
        "ad84"
        pause 0.0266
        "ad85" 
        pause 0.0266
    pause

    scene i784 with dissolve
    sve "And I'm Sveta, my daughter is Rivka."

    scene i784a with dissolve

    call screen rivdance1

    screen rivdance1():
        modal True

        viewport:

            add "i784a"
            mousewheel True

        imagebutton auto "rd1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "rd1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("rdance1")

label rdance1:

    show rd1:
        pause 0.0266
        "rd2"
        pause 0.0266
        "rd3"
        pause 0.0266
        "rd4"
        pause 0.0266
        "rd5" 
        pause 0.0266
        "rd6"
        pause 0.0266
        "rd7"
        pause 0.0266
        "rd8"
        pause 0.0266
        "rd9"
        pause 0.0266
        "rd10"
        pause 0.0266
        "rd11"
        pause 0.0266
        "rd12"
        pause 0.0266
        "rd13"
        pause 0.0266
        "rd14"
        pause 0.0266
        "rd15" 
        pause 0.0266
        "rd16"
        pause 0.0266
        "rd17"
        pause 0.0266
        "rd18"
        pause 0.0266
        "rd19"
        pause 0.0266
        "rd20"
        pause 0.0266
        "rd21"
        pause 0.0266
        "rd22"
        pause 0.0266
        "rd23"
        pause 0.0266
        "rd24"
        pause 0.0266
        "rd25" 
        pause 0.0266
        "rd26"
        pause 0.0266
        "rd27"
        pause 0.0266
        "rd28"
        pause 0.0266
        "rd29"
        pause 0.0266
        "rd30"
        pause 0.0266
        "rd31"
        pause 0.0266
        "rd32"
        pause 0.0266
        "rd33"
        pause 0.0266
        "rd34"
        pause 0.0266
        "rd35" 
        pause 0.0266
        "rd36"
        pause 0.0266
        "rd37"
        pause 0.0266
        "rd38"
        pause 0.0266
        "rd39"
        pause 0.0266
        "rd40"
        pause 0.0266
        "rd41"
        pause 0.0266
        "rd42"
        pause 0.0266
        "rd43"
        pause 0.0266
        "rd44"
        pause 0.0266
        "rd45" 
        pause 0.0266
        "rd46"
        pause 0.0266
        "rd47"
        pause 0.0266
        "rd48"
        pause 0.0266
        "rd49"
        pause 0.0266
        "rd50"
        pause 0.0266
        "rd51"
        pause 0.0266
        "rd52"
        pause 0.0266
        "rd53"
        pause 0.0266
        "rd54"
        pause 0.0266
        "rd55" 
        pause 0.0266
        "rd56"
        pause 0.0266
        "rd57"
        pause 0.0266
        "rd58"
        pause 0.0266
        "rd59"
        pause 0.0266
    pause
    vi "Oh, Rivka! Yes, adorable girl, well mannered..."
    scene i785 with dissolve
    pen "Vittoria, we usually do different types of volunteer work and we wanted to invite you to join us...or just to go to the theater, we do that a lot, too!"
    vi "Oh, thank you so much, but..."
    scene i786 with dissolve
    ed "She will go!"
    vi "Ladies...my mom Edwige and my sister, Ginevra."    
    scene i787 with dissolve
    ed "Bisogna che tu esca di casa, figlia..."
    vi "She's worried because I haven't left the house lately..."
    scene i788 with dissolve
    sve "Don't stress about it, Edwige, I know we should've come sooner, but we'll do anything to support your daughter from now on."
    ed "Thank you!"
    sve "Oh, we brought something for Vittoria, it's in my car, I'll be back in a minute..."
    stop music fadeout 2
    scene black with Dissolve(1)
    scene i800 with Dissolve(1)
    play music "audio/forestambient.mp3"
    ed "Sei bellissima, Vivi."
    vi "I don't know, mom...I feel fat..."
    scene i801 with dissolve
    sve "Fat? You have the perfect body! It fits you perfectly!"

    scene i802:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    vi "It is a beautiful dress...and I love the color...thank you so much, Sveta."
    sve "But try the others if that one doesn't convince you..."

    call screen vitryingx

    screen vitryingx():
        modal True

        viewport:

            add "i802"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying1x")

label vitrying1x:

    scene i803:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    vi "I'm not young anymore to be wearing something like this, don't you think?"
    sve "Again: with that body, everything looks good on you, Vittoria."

    call screen vitryingax

    screen vitryingax():
        modal True

        viewport:

            add "i803"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying2x")

label vitrying2x:

    scene i804:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    ed "Perfect!"
    vi "I love it, yes...it looks expensive, I don't think I can accept it..."
    
    call screen vitryingbx

    screen vitryingbx():
        modal True

        viewport:

            add "i804"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vitrying3x")

label vitrying3x:

    scene i805 with dissolve
    sve "Oh, shut ut, we're here to see you smile again. You're very welcome!"
    stop music fadeout 3
    scene black with Dissolve(3)

label boxes:

    scene i718 with Dissolve(2)
    play music "audio/lair.mp3"
    pt "I could only find two boxes, I thought there were a lot more...and I'm not even sure these are Franz's..."
    pt "Even my dad's files are gone...was it mom? I'll ask her later..."
    scene i719 with dissolve
    pt "This one is small, but heavy...I'm afraid of what I may find..."
    scene i720 with dissolve
    scene i720 with hpunch
    
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene i720 with dissolve
    pt "There it is again..."
    pt "A gun triggered it this time...was that..."
    pt "Not right now, focus...this shit must be Franz's, why did he bring it here? I'm not touching it, who knows if it's been used..."
    pt "What else is he hiding?"
    scene i720a with dissolve
    pause
    scene i721 with Dissolve(1)
    scene i721 with vpunch
    pt "WHAT?! This's been in the basement?! My God, how much is that?!"
    pt "And what are these?! Blood samples? This is getting so weird! Fuck, I should've worn gloves!"
    pt "A cellphone...my dad's ring...that stupid symbol is important, isn't it? The Triskele, something like that, I'll look it up online...Giuseppe had the exact same ring, I thought it was just a coincidence..."
    pt "I'd better hide all this stuff somewhere in my room...or is it safer where it was? I'm surprised mom didn't find it before, she goes there all the time to do the laundry...it must have been placed there recently...Franz..."
    scene black with Dissolve(1)
    scene i722 with dissolve
    pause
    scene i723 with dissolve
    pt "\"The Triskelion is an ancient Celtic symbol\"...\"it symbolizes triplicities: life, death, and rebirth; mind, body, and spirit; heaven, earth and damnation; father, son and holy spirit...\""
    pt "Okay, that's what my father told me, I remember now...but that doesn't give me anything..."
    pt "\"What secret societies use Celtic symbols?\"...interesting link, let's see..."
    pt "The Triquetra...the Celtic Cross...the Triskelion, here...\"in recent years, it has been adopted by the BDSM community...\""
    pt "BDSM? What's that?"
    pt "\"Bondage and Discipline, Dominance and Submission, and Sadism and Masochism...\""
    pt "\"...sexual activity involving such practices as the use of physical restraints, the granting and relinquishing of control, and the infliction of pain...\""
    pt "A sexual practice? That's all?"
    scene i724 with dissolve
    pt "Mmm, where can people do this? There must be some sort of club in the city..."
    scene i725 with dissolve
    pause
    scene i725 with hpunch
    pt "That's what the ring is for! For members! Wait a minute, my dad was part of that club?! And Giuseppe?! Well, that dude lived in a whorehouse...but my dad?!"
    pt "Perhaps if I start wearing it, someone may tell me something...uuuhhmmm..."
    pt "She said my brother would call...should I turn it on? Do I really want to talk to him?"
    pt "And that key...I'm assuming it's a key...only Franz could tell me what that really is..."
    pt "This is getting too complicated...I don't know if I want to go down this rabbit hole..."
    pt "And the gold...and the blood!"
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

label amandaof:

    scene i208 with dissolve

    play music "audio/homeinstrumental.mp3"
    ama "How often are you having those flashbacks?"
    p "Once a week...I don't know what's wrong with my head...I'm worried, doc..."
    ama "Have you identified any triggers?"
    p "I don't have it clear...I'd say something that reminds me of S, but that wouldn't be accurate: I think of her constantly and the flash is not there..."
    p "And that's another thing: I know it is a flashback, a memory, but it's too fast and the only thing I get to see is a flash..."
    scene i209 with dissolve
    ama "Maybe it's your own brain trying to protect you from reliving the full memory...but that's not my area of expertise, [p], that's a psychiatrist field."
    p "A psychiatrist? That sounds hardcore...would I need to take some pills?"
    ama "I can't tell you that right now...I know someone who..."
    p "No, doc...Amanda...I don't want to share my trauma with anybody else...if you can't help me, I'll see what I can do. I don't want to talk to anybody else."
    scene i210 with dissolve
    ama "You have to take it seriously, [p], it doesn't sound like something emotional: it is pshysical, chemical...you have to see a psychiatrist!"
    p "You even stood up, doc? Haha...Amanda, I appreciate your good intentions, but I'm not doing that..."
    ama "You have to!"
    p "You're being too emotional, doc, keep it professional..."
    ama "Sometimes, you...you know I'm right, you're just being stubborn..."
    p "Nope, not happening...unless..."
    scene i211 with dissolve
    ama "Okay, what do you want?"
    p "You're willing to negotiate, doc? Haha, you're breaking all the protocols, Amanda!"
    ama "Feels more like blackmail...tell me, a new pair of football boots would do it?"
    p "Haha..."
    ama "I'm serious."
    scene i212 with dissolve
    p "Come on...I think our time's up for today..."
    ama "We don't have time limits."
    p "I know, but you said you had to do some grocery shopping, didn't you?"
    ama "It can wait."
    pt "She's serious about it...can I use this situation to my advantage? If there's something that I want is to see those big tits..."
    ama "Well?"
    p "I want you to be my model..."
    scene i213 with dissolve
    ama "What did you say?"
    p "I want to paint a portrait of you...You know I stopped painting after my dad died, and I've been wanting to get back into it, but never find the time...I think you are the right person to help me reconnect with that side of me..."
    scene i214 with dissolve
    ama "Do you know I still have your painting in my bedroom?"
    p "Seriously? I don't believe you."
    ama "No, really, I do."
    p "Can I see it?"
    ama "Sure!"
    scene black with dissolve
    scene i215 with dissolve
    ama "There! I love it!"
    p "Haha, I really liked colors back then...can't believe you still have it, I thought you got rid of it long time ago..."
    ama "Are you crazy? You gave it to me for my birthday!"
    p "I don't think it matches your decoration..."
    ama "It doesn't matter, I like it there."
    scene i216 with dissolve
    p "So, doc? Would you be my muse?"
    ama "What would I have to do?"
    p "To pose for one or two hours..."
    ama "Can't you paint my face from a picture?"
    p "I could do that, but come on, doc...I want to create something with you there, co-create!"
    ama "It's probably very hard to hold one pose for two hours..."
    p "That too..."
    scene i217 with dissolve
    ama "I don't know...you promise you'll go to see my friend afterwards?"
    p "I'll go see whoever you want me to if we do this..."
    ama "I guess we could try then..."
    scene i218 with dissolve
    p "Yes! I'll let you know when, it'll be fun!"
    p "Oh, and doc, before I forget, I'm playing an important match this Saturday...would you come?"
    scene i218a with dissolve
    ama "It was about time you invited your favorite therapist to one of your matches, don't you think?"
    p "Haha, Saturday, 11 am...just in case you have some appointments..."
    ama "I don't think I do, but I'll cancel them if so...I'll be there!"

    stop music fadeout 3
    scene black with Dissolve(3)

    scene i300 with dissolve
    play music "audio/track15.mp3"
    p "Hi..."
    rec "Hi! You're one of our players, aren't you?"
    p "Uhum, how do you know?"
    scene i301 with dissolve
    rec "You're in great shape, few men in this place are, hehe...what can I do for you?"
    p "Thank you for that, you're in great shape, too...eerrr, what's your name?"
    rec "Jacqueline..."
    p "I'm [p]...so, Jacqueline, is Jo in her office? She wanted to talk to me..."
    jac "Yes, yes, give me one second to call her."
    p "Thanks again."
    scene black with dissolve
    scene i302 with dissolve
    p "Hello, my friend! You always look good, don't you?"
    jo "Haha, shut up, come, let's go to my office."
    scene black with dissolve
    scene i303 with dissolve
    p "Nice! You're doing pretty good, Jo!"
    jo "Hehe, I just got promoted..."
    p "Congratulations! You deserve it more than anybody! Are you the owner's right hand now?"
    jo "Pretty much, yes, Sarka never comes, she just delegates...and because of that, I discovered something about you! Please, take a seat."
    scene i304 with dissolve
    p "What is it?"
    jo "I was looking through your files and what I found is shocking, to say the least...there..."
    scene i305 with dissolve
    jo "We're not paying you anything! Why didn't you say it?"
    p "Am I supposed to get paid?"
    jo "Of course! Not a lot, but something! You're on our Under-21 squad!"
    p "I've had many other things in mind, Jo...good thing I didn't need the money..."
    p "How much are we talking about? I remember I signed something when I was 15...I was getting like a hundred dollars a week...for my cab, you know...it went directly to my mom's bank account."
    scene i306 with dissolve
    jo "Do you, at least, have a representative?"
    p "Nope, do I need one?"
    jo "You'd better start taking this side of football more seriously, [p]...if not, someone might take advantage of your talent, I'd hate to see that."
    scene i307 with dissolve
    jo "People have begun to pay attention to you, my friend, you're one of our best players. I'll tell you something else: an agent came the other day and wanted information about you...date of birth, salary...that's how I found out..."
    jo "She works for a big sports agency, I wanted to talk to you before giving her your number...She also said she'll be in your next match against LA Fantasy. They represent many players from that team: Yamalo, Ficti, Price..."
    jo "And between us: they can cut you a good deal with us, [p]."
    p "I don't know...I always thought that my agent should be someone I trust...someone like you, for example..."
    scene i308 with dissolve
    jo "Like me? Do you trust me?"
    p "Of course I do! And not only because of what everybody says about you, I'm a witness myself of your capability...and right now, you're taking my side! Even though you'll represent the club in the negotiation with my future agent..."
    p "You're being fair with me, an honest woman and a good friend."
    scene i309 with dissolve
    jo "Shut up, I'm blushing..."
    p "Haha, it's true! And I'm serious, eh...wouldn't you like to be my agent?"
    scene i310 with dissolve
    jo "Oh, God, stop playing...and like you said, I represent the club, it's impossible, [p]...I would have to quit due to the conflict of interest, no, no, no..."
    jo "Besides, I doubt I could make a living out of it..."
    p "Why not? I'll be worth millions! Haha...I know my mom wouldn't like to do it and all my friends are my age...The more I think about it, the more I want you to be my agent."
    scene i311 with dissolve
    jo "It does sound interesting, challenging! Don't forget I'm a journalist, I consider myself a good communicator...if you keep playing well, I could sell you to a big club in Europe with no problems..."
    p "Europe?! Whoa, don't get carried away too soon, Jo...I'm not even a pro yet!"
    jo "You know what? You could meet that agent after your next match to know more about what they do exactly, what percentage they're asking for or how they make money...endorsements, etc..."
    p "I like it, you're taking my proposal more seriously..."
    scene i312 with dissolve
    jo "It's the only way I work, okay? And here's a little tip: ask her for money!"
    p "What?"
    jo "Yes, they should pay you for representing you, Rob says you're no ordinary player, believe in yourself! Aim high, ask her for a million dollars!"
    scene i312 with vpunch
    p "What?! What you talking about, Willis? A million dollars?"
    jo "What was that?"
    p "Nothing...something a friend says..."
    jo "Okaaayyy, but trust me on this one...she may not offer you that much because of your age, but I know that agency paid 3 million to Yamalo's father to represent him. If they want you, you'll definitely get something!"
    p "So, you're basically telling me that YOU have to pay me for representing me..."
    scene i313 with dissolve
    jo "Haha, idiot...what I'm saying is that you were right to trust me, I'm giving you all these tips!"
    p "I know...thank you, Jo, really..."
    jo "Don't thank me yet, meet her first...maybe you fall for their offer and don't want to work with me anymore, hehe."
    p "A million dollars sounds very tempting...but you can get me more, right?"
    jo "Haha, of course! My cut would be higher, haha."
    stop music fadeout 3
    scene black with Dissolve(3)


    scene i315 with Dissolve(1)
    play music "audio/strongandloaded.mp3"
    p "The Fantastic Five are ours?"
    cj "You know...The Fantatic Five..."
    scene i316 with dissolve
    cj "Their goalkeeper and captain: Richard Price."
    p "He looks mad..."
    scene i317 with dissolve
    cj "The fastest player in the league, their left-back: Tom Hardy."
    cj "We're gonna have to foul him if we want to stop him..."
    p "That fast, huh?"
    scene i318 with dissolve
    cj "Their tireless defensive midfielder: Tyler Banks."
    scene i319 with dissolve
    fa "We love you, Tyler!"
    cj "Oh, yeah, he even has a fan club...hot girls support that son of a bitch, I don't know why..."
    p "And the last two?"
    cj "Oh, yeah, their aces..."
    scene i320 with dissolve
    cj "Ficti Junior, the player with most dribbles in the league...he has an attitude problem: every game he needs to fight with his rivals..."
    p "Joker can take advantage of that..."
    scene i321 with dissolve
    cj "And the wonderkid Yamalo, crazy skills and the most assists in the league...he's so arrogant, I hate him!"
    p "We'll see if he can back up that ego."
    scene i322 with dissolve
    cj "It's gonna be our hardest match of the season, bro, but imagine a victory here, in their stadium, with their fans......we'll lead in the standings if we win!"
    scene i323 with vpunch
    pause
    cj "That's a great team right there, bro..."
    p "We have a great team, too, do not forget it!"
    gil "And more important: we're gonna have a battle for the numbers, mão!"
    p "A battle for the numbers?"
    scene i324 with dissolve
    gil "Yeah, who's the best number 7 and the best number 10! I can get more dribbles than Ficti! And you, more assists than Yamalo! A battle for the numbers!"
    scene i325 with dissolve
    p "I like the way you think, irmão, let's do it!"
    gil "Yes! I'll show him who is the best Brazilian!"
    scene i326 with dissolve
    coa "[p]! Come here!"
    scene i327 with dissolve
    pt "Heeeyyy, it's so good to see some familiar faces!"
    scene i328 with dissolve
    pt "Carl's mom..."
    pt "Man, I'd love to see my mom in the crowd one day...I have to make it, she'll come then..."
    scene i329 with dissolve
    pt "But today, I got Candy!"
    scene i330 with dissolve
    pt "And Amanda! They're all the support I need!"
    scene i337 with dissolve
    pt "Whoa, everybody's come! Jo! Camille! Hi!"

    scene i338:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause

    pt "They're both super hot!"
    pt "You want me to see something? Where's she pointing to?"

    call screen jostadium

    screen jostadium():
        modal True

        viewport:

            add "i338"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jostadium")

label jostadium:

    scene i339 with dissolve
    pause 
    pt "She must be that agent Jo told me about..."
    pt "Man, I'm excited!"
    coa "[p]!"
    p "Yes!"
    scene i331a with dissolve
    coa "Listen: no woman is beating me today, you hear me?"
    p "Haha."
    coa "Don't laugh, I'm fucking serious! Women don't belong in football!"
    p "Whoooaa...okaaayyy..."
    scene i332 with dissolve
    pt "She seems to know what she's doing..."
    scene i333 with dissolve
    pt "And being hot is a plus..."
    scene i334 with dissolve
    coa "You wanted to play in the center? There, you got it, behind Arthur. Control the tempo, I brough you back for games like this, don't make me lose! A hundred percent right from the start! Go!"
    p "Yes, sir!"
    scene i335 with dissolve
    vir "Any last minute changes?"
    p "Nope, same message: win, you idiots!"
    scene i336 with dissolve
    vir "Haha...oh, we will, Robinson you piece of shit!"
    p "Haha."
    scene black with Dissolve(1)    
    scene i340 with dissolve
    art "How many people do you think have come?"
    p "Two thousand? And they're still coming..."
    art "Only fifty come to see us in our stadium...if we're lucky..."
    p "Yeah, we've never had this kind of support at home...but don't let it intimidate you, bro, we're winning today!"
    stop music fadeout 3
    scene black with Dissolve(1)
    play sound "audio/whistle1.mp3"
    scene i341 with dissolve
    pt "Ok, Yamalo, let the game begin..."
    pt "The battle for the number 10!"

    play music "audio/firstmatchplaying.mp3"

    scene i342 with Dissolve(1)
    
    scene i342:
        pause 0.0666
        "i342"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i342"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i342"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i342"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i342"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i342"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i342"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i342"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i342"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i342"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i342"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i342"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i342"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i342"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i342"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i342"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i342"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i342"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i342"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i342"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i342"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i342"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i342"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i342"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i342"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i342"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i342"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i342"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i342"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i342"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i342"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i342"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i342"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i342"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i342"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i342"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i342"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i342"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i342"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i342"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i342"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i342"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i342"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i342"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i342"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i342"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i342"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i342"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i342"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pt "Robinson wants us to always have numerical advantage against Ficti and Yamalo..."

    scene i343 with Dissolve(1)

    scene i343:
        pause 0.0666
        "i343"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i343"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i343"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i343"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i343"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i343"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i343"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i343"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i343"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i343"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i343"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i343"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i343"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i343"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i343"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i343"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i343"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i343"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i343"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i343"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i343"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i343"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i343"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i343"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i343"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i343"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i343"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i343"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i343"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i343"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i343"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i343"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i343"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i343"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i343"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i343"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i343"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i343"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i343"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i343"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i343"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i343"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i343"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i343"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i343"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i343"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i343"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i343"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i343"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "We needed The Shadow in this match, his defensive work is ten times superior to Corky's..."
    
    scene i346 with Dissolve(1)

    scene i346:
        pause 0.0666
        "i346"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i346"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i346"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i346"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i346"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i346"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i346"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i346"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i346"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i346"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i346"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i346"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i346"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i346"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i346"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i346"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i346"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i346"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i346"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i346"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i346"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i346"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i346"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i346"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i346"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i346"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i346"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i346"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i346"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i346"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i346"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i346"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i346"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i346"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i346"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i346"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i346"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i346"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i346"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i346"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i346"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i346"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i346"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i346"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i346"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i346"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i346"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i346"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i346"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "That dude's a bullet! What a scary pace! CJ was right: no way we can stop him without fouls..."

    scene i344 with Dissolve(1)

    scene i344:
        pause 0.0666
        "i344"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i344"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i344"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i344"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i344"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i344"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i344"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i344"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i344"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i344"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i344"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i344"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i344"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i344"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i344"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i344"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i344"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i344"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i344"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i344"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i344"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i344"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i344"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i344"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i344"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i344"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i344"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i344"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i344"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i344"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i344"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i344"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i344"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i344"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i344"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i344"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i344"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i344"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i344"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i344"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i344"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i344"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i344"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i344"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i344"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i344"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i344"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i344"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i344"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "I feel like this is the match that will make me a professional...or not...I need to outshine Yamalo! I have to go after him!"

    scene i348d with hpunch
    ya "Aaaahhhhh!!!"
    p "Ball, motherfucker, why you scream?"
    scene i348e with dissolve
    hc "Heeeeyyyy, referee! That's a red card!"
    p "Oh, shut up! You know I didn't touch him!"
    scene i348f with hpunch
    p "What?! Are you blind?! He's doing a Buskets!"
    ref "Don't disrespect me, Blanco, or I'll send you to the showers."
    scene i348g with dissolve
    ren "If you dive again, I'm gonna break you for real, bitch."
    ya "Chill out, brother, it's part of football."
    ren "Your football, not mine. And don't call me brother, you son of a bitch! You've been warned."
    stop music fadeout 2
    scene black with Dissolve(1)
    scene i349 with Dissolve(1)

    play music "audio/training.mp3"

    pt "El Diegote once said: \"Football is a game of deceit.\""

    scene i350 with dissolve

    scene i350:
        pause 0.0222
        "i351"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "i352"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "i353"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "i354"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "i355"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "i356"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "i357"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "i358"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "i359"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "i360"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "i361"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "i362"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "i363"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "i364"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "i365"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0222
        "i366"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0222
        "i367"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0222
        "i368"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0222
        "i369"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0222
        "i370"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0222
        "i371"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0222
        "i372"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0222
        "i373"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0222
        "i374"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0222
        "i375"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0222
        "i376"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0222
        "i377"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0222
        "i378"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0222
        "i379"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0222
        "i380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.030
        pause 0.0222
        "i381"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0222
        "i382"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0222
        "i383"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0222
        "i384"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0222
        "i385"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0222
        "i386"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0222
        "i387"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0222
        "i388"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0222
        "i389"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0222
        "i390"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0222
        "i391"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0222
        "i392"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0222
        "i393"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0222
        "i394"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0222
        "i395"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0222
        "i396"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046        
        pause 3
        "i397"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i398"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i399"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i400"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i401"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i402"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i403"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i406"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i407"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i408"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i409"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i410"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i411"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i412"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i413"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i414"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i415"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i416"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i417"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i418"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i419"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i420"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i421"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i422"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i423"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i424"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i425"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i426"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i427"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i428"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i429"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i430"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i431"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i432"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i433"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i434"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i435"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i436"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i437"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i438"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i439"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i440"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i441"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i442"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i443"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i444"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
    pt "\"I would pretend to go in one direction, then quickly change course...\""
    pt "Deceiving, not cheating, that's the difference between this kid and me: I don't need to cheat to win, I'm good enough!"
    scene i445 with vpunch
    pt "\"¡La pelota no se mancha!\""
    p "Gilmar!"
    scene i446 with Dissolve(1)
    pause 1
    scene i447 with Dissolve(1)
    pause 1
    scene i448 with Dissolve(1)
    pause 1
    scene i449 with Dissolve(1)
    pause 1
    scene i347 with hpunch
    scene i347 with hpunch
    pt "Holy shit, what a save!"
    pt "Price is really good, it was a great shot..."
    scene i348 with Dissolve(1)
    pt "Who's that for? Gilmar? No...Ethan?"

    scene i345 with Dissolve(1)

    scene i345:
        pause 0.0666
        "i345"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i345"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i345"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i345"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i345"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i345"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i345"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i345"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i345"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i345"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i345"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i345"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i345"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i345"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i345"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i345"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i345"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i345"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i345"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i345"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i345"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i345"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i345"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i345"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i345"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i345"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i345"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i345"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i345"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i345"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i345"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i345"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i345"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i345"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i345"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i345"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i345"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i345"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i345"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i345"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i345"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i345"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i345"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i345"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i345"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i345"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i345"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i345"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i345"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "Banks is a ball-winning machine...really hard to get past, he's so physical..."

    scene i450 with Dissolve(1)

    scene i450:
        pause 0.0666
        "i450"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i450"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i450"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i450"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i450"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i450"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i450"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i450"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i450"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i450"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i450"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i450"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i450"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i450"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i450"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i450"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i450"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i450"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i450"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i450"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i450"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i450"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i450"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i450"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i450"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i450"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i450"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i450"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i450"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i450"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i450"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i450"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i450"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i450"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i450"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i450"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i450"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i450"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i450"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i450"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i450"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i450"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i450"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i450"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i450"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i450"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i450"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i450"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i450"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "Hardy's not only fast, but also technical..."

    scene i451 with Dissolve(1)

    scene i451:
        pause 0.0666
        "i451"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i451"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i451"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i451"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i451"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i451"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i451"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i451"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i451"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i451"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i451"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i451"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i451"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i451"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i451"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i451"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i451"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i451"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i451"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i451"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i451"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i451"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i451"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i451"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i451"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i451"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i451"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i451"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i451"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i451"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i451"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i451"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i451"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i451"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i451"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i451"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i451"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i451"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i451"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i451"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i451"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i451"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i451"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i451"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i451"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i451"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i451"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i451"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i451"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    ya "Aaaahhhh! Refereeeeee!"
    vir "Dive now!"

    scene i348a with Dissolve(1)

    scene i348a:
        pause 0.0666
        "i348a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "i348a"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "i348a"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "i348a"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "i348a"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "i348a"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "i348a"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "i348a"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "i348a"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "i348a"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "i348a"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "i348a"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "i348a"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "i348a"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "i348a"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "i348a"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "i348a"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "i348a"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "i348a"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "i348a"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "i348a"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "i348a"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "i348a"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "i348a"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "i348a"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "i348a"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "i348a"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "i348a"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "i348a"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "i348a"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "i348a"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "i348a"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "i348a"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "i348a"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "i348a"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "i348a"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "i348a"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "i348a"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "i348a"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "i348a"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "i348a"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "i348a"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "i348a"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "i348a"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "i348a"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "i348a"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "i348a"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "i348a"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "i348a"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    pt "Nice trivela, Ficti, just like mine."
    scene i348b with hpunch
    scene i348b with hpunch
    pause 1
    scene i348c with Dissolve(1)
    stop music fadeout 3
    pt "Hahaaaa...hell yeah! Take that Price! Show him who the number one is, brother!"
    pt "I've just realized we all are having our personal battles today...and we all want to win!"
    scene black with Dissolve(1)

    play music "audio/boostyourpowers.mp3"
    scene i454 with dissolve
    pt "A clear chance! Come on, brother, you can do it..."
    pt "Price's covering the far post, he wants CJ to shoot to the near post...what a smart keeper..."
    scene i455 with dissolve
    pt "Yes, chip it! You got this! Your mom is watching!"
    scene i456 with dissolve
    scene i456 with dissolve
    scene i457 with dissolve
    scene i457 with vpunch
    pt "Noooooo! What the fuck was that, bro?!"
    scene i458 with dissolve
    pt "We're not gonna have many chances like that one...fuck!"
    scene i458a with dissolve
    cd "What the hell?!"
    mal "Oh my God..."
    scene black with Dissolve(1)
    
    scene i460 with dissolve
    p "Mão! Give me the ball!"
    scene i461 with dissolve
    gil "Shoot, irmão!"

    scene i470 with Dissolve(1)
    play sound "audio/hitpost.mp3" volume 2
    scene i470:
        pause 0.0133
        "i470a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0005
        pause 0.0133
        "i471"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "i471a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0015
        pause 0.0133
        "i472"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "i472a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0133
        "i473"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "i473a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0035
        pause 0.0133
        "i474"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "i474a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0045
        pause 0.0133
        "i475"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "i475a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0055
        pause 0.0133
        "i476"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "i476a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0065
        pause 0.0133
        "i477"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "i477a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0075
        pause 0.0133
        "i478"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "i478a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0085
        pause 0.0133
        "i479"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "i479a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0095
        pause 0.0133
        "i480"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "i480a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0105
        pause 0.0133
        "i481"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "i482"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "i483"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "i484"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "i485"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0222
        "i486"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0222
        "i487"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0222
        "i488"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0222
        "i489"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0222
        "i490"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0222
        "i491"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0222
        "i492"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0222
        "i493"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0222
        "i494"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0222
        "i495"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0222
        "i496"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0222
        "i497"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0222
        "i498"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0222
        "i499"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0222
        "i500"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0222
        "i501"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0222
        "i502"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0222
        "i503"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0222
        "i504"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0222
        "i505"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0222
        "i506"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0222
        "i507"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0222
        "i508"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0222
        "i509"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0222
        "i510"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0222
        "i511"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0222
        "i512"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0222
        "i513"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0222
        "i514"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0222
        "i515"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0222
        "i516"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0222
        "i517"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0222
        "i518"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0222
        "i519"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0222
        "i520"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0222
        "i521"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.051
        pause 0.0222
        "i522"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.052
        pause 0.0222
        "i523"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.053
        pause 0.0222
        "i524"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.054
        pause 0.0222
        "i525"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.055
        pause 0.0222
        "i526"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.056
        pause 0.0222
        "i527"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.057
        pause 0.0222
        "i528"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.058
        pause 0.0222
        "i529"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.059
        pause 0.0222
        "i530"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0222
        "i531"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.061
        pause 0.0222
        "i532"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.062
        pause 0.0222
        "i533"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.063
        pause 0.0222
        "i534"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.064
        pause 0.0222
        "i535"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.065
        pause 0.0222
        "i536"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.066
        pause 0.0222
    pause

    scene i550 with Dissolve(1)
    play sound "audio/hitpost.mp3" volume 2
    scene i550:
        pause 0.0222
        "i551"
        pause 0.0222
        "i552"
        pause 0.0222
        "i553"
        pause 0.0222
        "i554" 
        pause 0.0222
        "i555"
        pause 0.0222
        "i556"
        pause 0.0222
        "i557"
        pause 0.0222
        "i558"
        pause 0.0222
        "i559"
        pause 0.0222
        "i560"
        pause 0.0222
        "i561"
        pause 0.0222
        "i562"
        pause 0.0222
        "i563"
        pause 0.0222
        "i564"
        pause 0.0222
        "i565"
        pause 0.0222
        "i566"
        pause 0.0222
        "i567"
        pause 0.0222
        "i568"
        pause 0.0222
        "i569"
        pause 0.0222
        "i570"
        pause 0.0222
        "i571"
        pause 0.0222
        "i572"
        pause 0.0222
        "i573"
        pause 0.0222
        "i574"
        pause 0.0222
        "i575"
        pause 0.0222
        "i576"
        pause 0.0222
        "i577"
        pause 0.0222
        "i578"
        pause 0.0222
        "i579"
        pause 0.0222
        "i580"
        pause 0.0222
        "i581"
        pause 0.0222
        "i582"
        pause 0.0222
        "i583"
        pause 0.0222
        "i584"
        pause 0.0222
        "i585"
        pause 0.0222
        "i586"
        pause 0.0222
        "i587"
        pause 0.0222
        "i588"
        pause 0.0222
        "i589"
        pause 0.0222
        "i590"
        pause 0.0222
        "i591"
        pause 0.0222
        "i592"
        pause 0.0222
        "i593"
        pause 0.0222
        "i594"
        pause 0.0222
        "i595"
        pause 0.0222
        "i596"
        pause 0.0222
        "i597"
        pause 0.0222
        "i598"
        pause 0.0222
        "i599"
        pause 0.0222
        "i600"
        pause 0.0222
        "i601"
        pause 0.0222
        "i602"
        pause 0.0222
        "i603"
        pause 0.0222
        "i604"
        pause 0.0222
        "i605"
        pause 0.0222
        "i606"
        pause 0.0222
        "i607"
        pause 0.0222
        "i608"
        pause 0.0222
        "i609"
        pause 0.0222
        "i610"
        pause 0.0222
        "i611"
        pause 0.0222
        "i612"
        pause 0.0222
        "i613"
        pause 0.0222
        "i614"
        pause 0.0222
        "i615"
        pause 0.0222
        "i616"
        pause 0.0222
    pause
    
    scene i538 with Dissolve(1)
    pause

if choice85a:

    play sound "audio/crowdbooing.mp3" volume 1.5
    scene i540 with Dissolve(2)
    pause

    jump resumeyamalo

if choice85b:

    play sound "audio/crowdbooing.mp3" volume 1.5
    scene i541 with Dissolve(2)
    pause
    
    jump resumeyamalo

if choice85c:

    play sound "audio/crowdbooing.mp3" volume 1.5
    scene i539 with Dissolve(2)
    pause

    jump resumeyamalo


label resumeyamalo:

    scene i542 with Dissolve(1)
    pause
    scene i790 with dissolve
    hc "Hey, referee! He's mocking us!"
    scene i791 with dissolve
    p "Are you out of your mind?!"
    ref "Excessive celebration, second yellow card."
    play sound "audio/crowdcelebrate.mp3" volume 1.6 fadein 1.5
    hc "Yes! Go home, Blanco!"
    scene i792 with dissolve
    ref "Unsporting behavior."
    stop sound fadeout 1.5
    coa "Fuck off, referee! You're killing football, crook!"
    play sound "audio/crowdbooing.mp3" volume 1.5
    scene i793 with dissolve
    coa "How much are they paying you?! Make it more obvious, cockroach!"
    scene black with Dissolve(1)
    scene i794 with dissolve
    p "I'm sorry, coach, I fucked it up..."
    coa "Haha, are you crazy? We already pocketed the three points! Have you forgotten who has the most clean sheets in the league's history?"
    p "Ethan?"
    scene i795 with dissolve
    coa "Haha, not Ethan, you idiot, meeeee! ZERO goals conceded in more than 500 games! This game is ours, trust me, kid! One step closer to the title!"
    coa "Now you should be apologizing for not taking Vini or Yamalo with you: you already had a red card, you should've punched those motherfuckers and wait for their reaction..."
    coa "But I forgive you because you celebrated in front of that woman...that's my boy!"
    stop music fadeout 3
    scene black with Dissolve(2)
    scene i796 with Dissolve(1)
    play sound "audio/honk.mp3"
    ag "[p] Blanco!"
    cd "Who's that? Do you know her?"
    p "I think she's an agent..."
    cd "An agent?"
    scene i797 with dissolve
    cd "What do you want?"
    ag "Talk to your boyfriend...I'm Ruby Blumenau, do you have a minute, [p]?"    
    p "That coffee will have to wait, ladies...this is important."
    scene i798 with dissolve
    ru "Come on, hop in!"
    scene black with Dissolve(3)

    jump thanksfor

    jump choice88_common

label choice88_common:




    scene black with Dissolve(3)

    jump thanksfor

label thanksfor:

    scene black with Dissolve(3)
    "I'll be back..."
    "AlienCat."
