#Important Decision
default choice5a = False
default choice6b = False
default choice7a = False
default choice7b = False
default choice9a = False
default choice9b = False
default choice10a = False
default choice10b = False
default choice11a = False
default choice11b = False



# Start Episode
label start:
    scene black
    menu:
        "This visual novel contains adult-only material."
        "Are you 18 years old or above?"

        "Yes":
            jump begin
        "No":
            jump end
label end:
    $ renpy.quit()

label begin:

# Get players name
    python:
        pf = renpy.input("What is your name?")
        pf = pf.strip()
        if pf =="":
            pf = "Mark"
            persistent.p = pf
        else:
            persistent.p = pf


# Star Scene

    scene sce1 with Dissolve(1.5)
    scene sce2 with Dissolve(1.5)
    scene sce3 with Dissolve(1.5)
    scene sce4 with Dissolve(1.5)
    scene sce6 with Dissolve(1.5)
    scene sce7 with Dissolve(1.5)
    pause
    scene sce8 with Dissolve(2)
    $ renpy.pause()

    "..."
    scene sce9 with dissolve
    scene sce9a with dissolve
    p "Don't you move?"
    scene sce8 with dissolve
    "..."
    scene sce9 with dissolve
    scene sce9a with dissolve
    p "How'd you get there?"
    scene sce8 with dissolve
    "..."
    scene sce9 with dissolve
    pt "I never really liked snails. I used to think they were dumb and disgusting, even unnecessary."
    pt "When did that change?"
    pt "I guess that's another thing I got from you."
    pt "I can see how beautiful this one is..."
    pt "You taught me so many things...things that have become part of me."
    pt "This is not the real me, this is the YOU in me liking a snail."
    pt "I wasn't soft...you made me."
    pt "I wasn't nice...you made me."
    pt "I wasn't weak...you made me."
    pt "I wasn't strong...you made me."
    pt "..."
    pt "Thank you..."

    scene sce10 with Dissolve(2.0)
    scene sce11 with Dissolve(3.0)
    scene sce12 with Dissolve(3.0)
    scene black with Dissolve(3.0)

    scene sce13 with dissolve
    play music "audio/sorry.ogg"

    pt "After all these years..."
    pt "Our story always comes back looking for my scar."
    pt "It takes the shape of a snail today. What will it be tomorrow?"
    scene sce14 with dissolve
    pt "No, don't think about it. I'm not doing this exercise again. I'm not going there. I've got no time for this...not today..."
    pt "I gotta get ready for...but...is it a sign? Should I...call it off?"
    pt "Don't start, [p]. She's not here anymore, hasn't been for a long time. But still..."
    pt "I wish I had done things differently..."
    pt "That fucking night..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    play music "audio/exercisechris.ogg" volume 0.8

    scene sce15a:
        pause 0.1
        "sce15b"
        pause 0.1
        "sce16c"
        pause 0.1
        "sce17b"
        pause 0.1
        "sce16b"
        pause 0.1
        "sce15c"
        pause 0.1
        "sce16a"
        pause 0.1
        "sce17"
        pause 0.1
        "sce17c"
        pause 0.1
        "sce15d"
        pause 0.1
        "sce17a"
        pause 0.1
        "sce16e"
        pause 0.1
        "sce16"
        pause 0.1
        "sce17a"
        pause 0.1
        "sce15b"
        pause 0.1
        "sce16d"
        pause 0.1
        "sce17d"
        pause 0.1
        repeat
    pause

    scene sce17e with dissolve
    p "Wooow."
    scene sce17b with dissolve
    cs "You comin'?"

menu:
    "Do it.":
        jump choice1

label choice1:
    scene sce17 with dissolve
    p "Inside."
    scene sce18 with dissolve
    pause
    scene sce19 with dissolve
    p "No foreplay, I wanna fuck you."
    cs "Too much talking."
    scene sce20 with vpunch
    cs "Aahh!"
    p "Ooff, you're wet already."
    scene sce21 with dissolve
    cs "Dude, I love your cock..."
    p "I know you do."

menu:
    "Push it a bit more.":
        jump choice2

label choice2:

    scene sce22 with vpunch
    cs "Aaaahhhh!!"
    scene sce23 with dissolve
    p  "You're sooo hot, Tina! I love your ass."
    cs "It's yours tonight."
    scene sce23a with dissolve

    scene sce23b:
        pause 0.0133
        "sce23c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "sce23d"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "sce23e"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "sce23f"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "sce23g"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "sce23h"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "sce23i"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "sce23j"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "sce23k"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "sce23l"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "sce23m"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "sce23n"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "sce23o"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "sce23p"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "sce23q"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "sce23r"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "sce23s"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "sce23t"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "sce23u"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "sce23v"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "sce23w"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0133
        "sce23x"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0133
        "sce23y"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "sce23z"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "sce23z"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "sce23y"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "sce23x"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0133
        "sce23w"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0133
        "sce23v"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "sce23u"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "sce23t"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "sce23s"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "sce23r"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "sce23q"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "sce23p"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "sce23o"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "sce23n"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "sce23m"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "sce23l"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "sce23k"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "sce23j"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "sce23i"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "sce23h"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "sce23g"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "sce23f"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "sce23e"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "sce23d"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "sce23c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "sce23b"
        pause 0.0133
        repeat
    pause

menu:
    "Faster.":
        jump choice2a

label choice2a:

    scene sce23b:
        pause 0.008
        "sce23c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.008
        "sce23d"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.008
        "sce23e"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.008
        "sce23f"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.008
        "sce23g"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.008
        "sce23h"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.008
        "sce23i"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.008
        "sce23j"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.008
        "sce23k"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.008
        "sce23l"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.008
        "sce23m"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.008
        "sce23n"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.008
        "sce23o"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.008
        "sce23p"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.008
        "sce23q"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.008
        "sce23r"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.008
        "sce23s"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.008
        "sce23t"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.008
        "sce23u"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.008
        "sce23v"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.008
        "sce23w"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.008
        "sce23x"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.008
        "sce23y"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.008
        "sce23z"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.008
        "sce23z"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.008
        "sce23y"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.008
        "sce23x"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.008
        "sce23w"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.008
        "sce23v"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.008
        "sce23u"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.008
        "sce23t"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.008
        "sce23s"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.008
        "sce23r"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.008
        "sce23q"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.008
        "sce23p"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.008
        "sce23o"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.008
        "sce23n"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.008
        "sce23m"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.008
        "sce23l"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.008
        "sce23k"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.008
        "sce23j"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.008
        "sce23i"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.008
        "sce23h"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.008
        "sce23g"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.008
        "sce23f"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.008
        "sce23e"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.008
        "sce23d"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.008
        "sce23c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.008
        "sce23b"
        pause 0.008
        repeat
    cs "Oh, yeah like that, don't stop!"
    pause

    scene sce21 with dissolve
    scene sce19 with dissolve
    p "Turn around, I wanna see your face."
    scene sce24 with hpunch
    cs "Ah!"
    scene sce25 with dissolve
    cs "You wanted me since day one, didn't you?"
    scene sce25a with dissolve
    scene sce25b with dissolve
    scene sce25c with dissolve
    scene sce25d with dissolve
    scene sce25e with dissolve
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    scene sce14 with dissolve
    pt "So many mistakes..."
    pt "I tried to bury my flaws under lies."
    pt "I truly was a horrible person, never considered others in my decisions. I just did what I felt like doing at the moment. It was all about me, my happiness, my pleasure."
    pt "So young, so immature, so selfish..."
    pt "Did I do a good job with my life? Am I really a different man? Better? Would you be proud?"
    pt "Stop it! I won't do this. I won't open that door, it's so hard to close."
    scene sce30 with dissolve
    pt "Fuck! Stupid snail! How the fuck did you get in here?!"
    pt "You had to remind me of her. I was ok a minute ago and now I'm so fucking angry."
    pt "No...I'm frustrated."
    scene sce31 with dissolve
    pt "No."
    pt "I'm sad."
    pt "No, not even that...I'm just..."

    scene black with dissolve

    $ renpy.movie_cutscene("videos/Empty.ogv")

    scene black with Dissolve(1.0)

    pt "This story...MY story...begins with a dream."
    play sound "audio/whistle.mp3"

    scene sce32 with dissolve
    play music "audio/funky.ogg"

    pt "I fell in love with soccer watching Rob Davies on tv."
    pt "Every weekend I used to wake up early just to see him play. So talented player, so classy, in and out of the field. Rich, handsome, married to a celebrity. My boy had everything."
    scene sce33 with dissolve
    pt "That was the kind of life I wanted for myself."
    pt "I remember when dad took me to watch his film \"Bend it like Davies\"...it sucked! but hey! I loved the man and wanted to be just like him, I even played as a midfielder because of him."
    scene sce34 with dissolve
    pt "At eighteen, I was already playing at a well-known club and when school was finally over, I devoted my time to get a spot in the U20 team...I trained really hard for it."
    pt "I was ready to sacrifice my youth, my friends, everything I had to make my dream come true."
    scene sce35 with dissolve
    pt "I wasn't gonna fail..."
    pt "I was gonna do this for me!"
    scene sce36 with dissolve
    pt "Coach Robinson had seen how much effort I put into it, staying hours after training, practicing crosses and free kicks just like Davies..."
    scene sce37a with dissolve
    pt "Months of hard work finally paid off: he gave me the chance to start one Saturday, no bench for me that day..."
    scene sce38 with dissolve
    pt "It was a rough game, I was fouled many times...but still, I played the best game of my life..."
    scene sce38a with Dissolve(1.5)
    pt "The stands were empty, the stadium was silent, but I swear I could hear a crowd cheering me up, chanting my name..."
    scene sce38b with dissolve
    pt "Mom was not there, dad was not there, my brother was not there, Candace was not there, Metal was not there, but you know what? It didn't matter..."
    scene sce38c with dissolve
    pt "I was truly happy that day."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    pt "I felt I was a step closer to becoming a pro, to me it was just a matter of time. I thought I'd made the right decision."
    pt "Decisions..."
    pt "Is it really us who decide or we're just someone's puppets?"

menu:
    "Puppets.":
        jump choice3

label choice3:

    play music "audio/walking.ogg"
    scene sce37 with dissolve
    pt "It sure felt that way the day this criminal broke my leg..."
    pt "Someone else had pulled the strings and I had to deal with the consequences...I thought I had a promising future and suddenly, this happened."
    pt "It was not fair."
    pt "Life hardly is..."
    scene black with Dissolve(2.0)

    play sound "audio/glitch1.ogg"
    scene sce39 with Dissolve(0.1)
    scene sce39k with Dissolve(0.1)
    scene sce39l with Dissolve(0.1)
    scene sce39m with Dissolve(0.1)
    scene sce39c:
        pause 0.05
        "sce39g"
        pause 0.05
        "sce39d"
        pause 0.05
        "sce39i"
        pause 0.05
        "sce39e"
        pause 0.05
        "sce39j"
        pause 0.05
        "sce39f"
        pause 0.05
        "sce39b"
        pause 0.05
        "sce39h"
        pause 0.05
        repeat
    play sound "audio/glitch2.ogg"
    pause
    pt "After undergoing surgery, I wanted to go home right away. I just couldn't bear being in a hospital, but the doctors recommended to stay for some weeks because \"the fracture extended into his knee\", \"nerve complications\", I heard them say."
    play sound "audio/glitch1.ogg"
    pt "It sounded bad..."
    play sound "audio/glitch2.ogg"
    pt "I didn't want to see anybody while being there. Candace went to visit but I wanted to be left alone with my thoughts, bottling up so many feelings."
    play sound "audio/glitch1.ogg"
    play sound "audio/glitch2.ogg"
    pt "Mom had seen me act like this before, she started to worry. She knew something was off with me and called my old psychologist and friend of hers: Doctor Pratt."
    scene sce39a with dissolve
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    play music "audio/bothofu.ogg"

    scene sce40b:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    dp "Hi, [p]! Long time no see!"
    p "Hey, doc! It's so good to see you again!"
    dp "You've grown up so much already!"
    scene sce42 with dissolve
    dp "Let me put my jacket right here."
    scene sce42a with dissolve
    scene sce42b with dissolve
    scene sce42c with dissolve
    scene sce43 with hpunch
    pt "What the..."
    scene sce44 with dissolve
    dp "Can I get a hug?"
    p "Of course, doc! No need to ask...I've missed you a lot!"
    scene sce44a with dissolve
    dp "Aw, you're so sweet as usual...come here!"

menu:
    "Hug her.":
        jump choice4a

    "Check those out first.":
        jump choice4b

label choice4a:
    scene sce46a with dissolve
    dp "I'm here for you, [p]. You can count on me."
    jump choice4_common

label choice4b:
    scene sce45 with hpunch
    pt "Damn! I'm getting hard so quickly...she'll notice."
    scene sce45c with Dissolve(0.2)
    scene sce45d with Dissolve(0.2)
    scene sce45b with fade
    pt "Fuck! I can't stop looking at her as what she really is: a beautiful mature woman. I've been here for too long already..."
    scene sce45e with Dissolve(0.2)
    scene sce45f with Dissolve(0.2)
    scene sce45a with fade
    pt "Good...go for that hug now."
    scene sce46 with dissolve
    pt "Mmff...here they come..."
    scene sce46a with dissolve
    pt "They feel so soft pressing against my chest...wait...did she say anything?"
    jump choice4_common

label choice4_common:
    scene black with Dissolve(2.0)
    scene sce47 with dissolve
    dp "Elizabeth told me you're not letting your friends come visit..."
    p "Yeah, I didn't feel like it."
    dp "Do you feel like having me here?"
    p "Sure doc, you're special. You saved me, I owe you a lot."
    scene sce47a with dissolve
    dp "I love how grateful you are, Eli taught you well, but you owe me nothing son...I've seen you grow, we're practically family!"
    scene sce48a with Dissolve(2.0)
    pt "She kept coming the following days, I started to open up little by little again telling her how much it meant to me that she was there."
    scene sce48 with dissolve
    pt "We never addressed the elephant in the room though, I guess she wanted me to take the first step..."
    scene sce49 with dissolve
    dp "Not in the mood for talking today either? You know you have to vent, right? Suppressing those feelings will end up eating you at some point of your life."
    pt "I can't think straight with you wearing that dress..."
    p "What do you want me to say, doc? I don't share much, you know it."
    dp "Well, I guess I'll just sit and keep you company."
    scene sce49b with dissolve
    p "I've heard what everybody is saying..."
    scene sce49a with dissolve
    dp "What are they saying?"
    p "You know, that I'm not playing again."
    scene sce50 with dissolve
    dp "How does that make you feel?"
    p "Sad...upset...angry because they may be right. My knee hurts when I try to move it, my shinbone feels weak and I just..."
    dp "Go on."
    p "I'll leave it there..."
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene sce51 with dissolve
    pt "A couple of weeks went by and I was done with my attitude. I got sick of feeling sorry for myself."
    pt "Dr. Pratt's presence really helped me...again. There was something about her that made me feel at ease, safe. Her support gave me all the motivation I needed to start over..."
    p "One step at a time, [p]. You can do it!"

    scene black with Dissolve(3.0)

    dp "Is this what you want?"
    scene sce58a with dissolve
    play music "audio/beatdoc.ogg"
    scene sce58b with dissolve
    scene sce58c with dissolve
    scene sce58d with dissolve
    scene sce58e with dissolve
    scene sce58 with dissolve
    p "Yeah. That's all I need, doc."
    dp "I've seen the way you look at me now...it's just wrong."
    p "But this feels soooo right..."
    play sound "audio/knock.ogg"
    dp "I want to help you, but I don't think you deserve it."
    p "What?! Why not? I totally do!"
    scene sce59 with dissolve
    dp "Mmm...you think you can handle me, son?"
    p "Of course I can, doc!"
    play sound "audio/knock.ogg"
    stop music fadeout 3.0
    scene sce60 with dissolve
    pt "Don't tell me I am..."
    play sound "audio/doorbang.mp3"
    scene sce61 with hpunch
    pt "Nooooooooooo!!!"
    mm "Son, are you awake?"
    scene sce60 with dissolve
    pt "Not yet. Don't move your head, [p], you can go back to that dream."
    scene sce62 with dissolve
    pt "Focus...focus...sleep...sleep..."
    play sound "audio/doorbang.mp3"
    scene sce61 with hpunch
    pt "Fuuuuccckkkk!!!"
    mm "Candace is here!"
    p "I don't want to see her!"
    scene sce63 with dissolve
    cd "She meant here, HERE, douche!"
    scene sce64 with dissolve
    cd "Sorry, Mrs. B."
    scene sce65 with dissolve
    scene sce65a with dissolve
    pause
    scene sce63 with dissolve
    cd "Hurry up!"
    scene sce66 with dissolve
    p "Dude, I'm hurt, but I'm coming anyways."
    scene sce67 with dissolve
    cd "That's what she said!"
    p "Haha."
    scene sce65a with dissolve
    scene sce65b with dissolve
    mm "I'll leave you two alone."
    scene black with Dissolve(2.0)
    play sound "audio/tada1.mp3"
    scene sce69 with dissolve
    cd "Tadaaa!"
    play sound "audio/tada2.mp3"
    scene sce69 with dissolve:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
    pause
    play sound "audio/tada3.mp3"
    scene sce69 with dissolve:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.0
    pause

    play sound "audio/tada4.mp3"
    scene sce69 with dissolve
    play music "audio/beat3.ogg"
    p "Nice! What's up with the guitar?"
    cd "Duuhh...it's for you obviously."
    scene sce70 with dissolve
    p "I thought you were gonna sing something for me."
    cd "Pff, I don't know how to play it."
    scene sce71 with dissolve
    p "You realize I don't know either, right?"
    scene sce71 with dissolve
    scene sce72 with dissolve
    cd "You'll figure and sing a song to me. Muah!"
    scene sce73 with dissolve
    cd "It's so great to see you again, buddy!"
    p "You too, Candy."
    cd "Good...good..."
    stop music
    play sound "audio/scratch.ogg"
    scene sce74 with hpunch
    p "Ouch!"
    scene sce75 with dissolve
    p "What the fuck?!"
    cd "No, what the fuck with YOU! What was that crap you wanted to be alone?!"
    pt "Still do..."
    cd "What did you say?"
    scene sce77 with dissolve
    play music "audio/beat3.ogg"
    p "I din't say anything...just help me out."
    cd "No, but you thought of it, I know you...Come on, stand up! Don't be a penis!"
    scene sce78 with dissolve
    p "\"A pussy\" goes the expression."
    stop music
    play sound "audio/scratch.ogg"
    scene sce74 with hpunch
    cd "Too soon to be a smartass!"
    scene sce79 with dissolve
    cd "Here..."
    scene sce80 with dissolve
    cd "I don't care if you wanted some time alone, it's me dude, Candace! Candy!!! I'll never leave you alone!"
    p "Ok, ok, I'm sorry, alright?"
    scene sce81 with dissolve
    cd "I forgive you, but don't be like that again. You know how much I care about you."
    p "I know, I'm sorry again..."
    scene black with dissolve
    play music "audio/beat3.ogg"
    scene sce83 with dissolve
    cd "Oh! By the way, Metal and I came yesterday, but your brother told us you didn't want to be bothered."
    p "He was right, not even him bothered me."
    scene sce84 with dissolve
    cd "I knew it!! He literally took one second to \"ask\" you. That son of a bitch!!"
    mm "Candy!!"
    scene sce85 with Dissolve(1.0)
    scene sce86 with dissolve
    cd "Sorry, Mrs. B!"
    scene sce87 with dissolve
    cd "Ok, serious question: How are you?"
    p "You know how many times I've heard that question in the last weeks? I'm alright, don't worry. YOU tell me, how's college?"
    scene sce88 with dissolve
    cd "Oh{w=1.0} my{w=1.0} God!"
    scene sce88a with dissolve
    cd "I thought you were never gonna ask. It's super cool! I love it! I've met a lot of new people and classes are really fun!!"
    p "That's what I like about you..."
    scene sce89 with dissolve
    cd "What."
    p "You glow."
    scene sce90 with dissolve
    cd "Flirting with your best friend, huh?...you had your chance already."
    p "Did I?"
    scene sce91 with dissolve
    cd "Mooooving oooon..."
    scene black with dissolve
    scene sce92 with dissolve
    p "No, really, make yourself comfortable. I don't have a broken leg."
    cd "Haha, stop complaining. You love the way I am AND you need me, your life would suck if it were only you and Metal."
    p "We really don't know that, it's always been the three of us."
    cd "Exactly!! We kind of miss you at St. Francis."
    p "Yeah, mom's been telling me about it since the first day I got admitted to the hospital."
    scene sce93 with dissolve
    cd "And?"
    p "She sent my papers there some months ago, while I was playing..."
    scene sce94 with dissolve
    cd "Aaand?"
    p "Long story short: I got in..."
    scene sce95 with dissolve
    cd "Aaaaaaanndd?"
    pt "Haha she knows me, being accepted doesn't mean I'm going."
    p "I'm giving it a shot."
    scene sce96 with dissolve
    cd "No way! Are you serious?"
    p "Yup."
    scene sce97 with dissolve
    cd "But wait...that means..."
    scene sce98 with dissolve
    p "That means I'll be seeing you everyday."
    pt "Candace always worries about me...I'm lucky to have her in my life..."
    scene sce98a with dissolve
    scene sce98b with dissolve
    scene sce98c with dissolve
    scene sce98d with dissolve
    scene black with dissolve
    scene sce98e with dissolve
    scene sce98f with dissolve
    scene sce98g with dissolve
    scene sce98h with dissolve
    scene sce98i with dissolve
    pause
    stop music
    play sound "audio/scratch.ogg"
    scene sce98j with hpunch
    p "Oh shit!!"
    scene sce98k
    cd "Hell, no, you're not daydreaming on me!"
    p "I wasn't."
    cd "I know that smile, you dickhead."
    p "Why you're always calling me names?"
    cd "Cause!"
    scene sce93 with dissolve
    cd "Look I gotta go now, mom and I are going to the mall. Call Metal, he...oh no wait! I forgot, he went on a trip to Europe with his family. He's coming back next month."
    p "Europe? Nice! Well, we'll see him then."
    cd "Yeap. See ya, buddy!"
    scene black with dissolve
    scene sce99 with dissolve
    p "Candy!"
    cd "Yeah?"
    p "Thank you."
    scene sce100 with dissolve
    cd "Peace out!"

    scene black with Dissolve(2.0)
    pause
    play music "audio/imagination.ogg"
    pt "It took me six months to heal."
    scene sce101 with dissolve
    pt "Six months in which I learned new things."
    p "The tutorial said this was the G chord, but it sounds different...mmm...maybe it's the fret..."
    p "You're not gonna beat me!"
    scene sce102 with dissolve
    pt "Six months in which I recovered my smile."
    mt "Dude, we suck at this game."
    p "I know..."
    pt "People I love have been with me during this time."
    pt "It got easier with them by my side."
    scene sce103 with dissolve
    pt "When I was playing soccer it seemed I was alone: my friends were in college; mom never liked the idea, she wanted me to keep studying; my brother was...who knows what he was doing with his life."
    pt "My only supporter was my dad but I lost him..."
    pt "I don't want to lose these people."
    scene sce104 with dissolve
    pt "They bring light into my life!"
    pt "I wanna be with them, I need them. And I'll do anything to keep them."
    scene sce105 with dissolve
    pt "Even if that means letting a dream go..."
    scene sce105a with dissolve
    scene sce105b with dissolve
    scene sce105c with dissolve
    scene sce105d with dissolve
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene sce106 with dissolve
    pt "Well, well, well...here I am. My first day at Saint Francis..."
    pt "Who would've thought? I used to argue with mom uncountable times because I never wanted to come here."
    pt "I had so many great things in mind except this: the dull life of the majority."
    pt "Go to college, get your degree, find a decent job where you can die comfortably every day..."
    pt "I've started that path, huh? Well, let's die with dignity. Who knows?...maybe it's not so bad after all..."
    scene black with dissolve
    play music "audio/engine.ogg" volume 0.8
    scene sce107 with dissolve
    pt "Okaaayyy, not a bad start."
    scene sce108:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "Nope, not bad at all..."
    scene sce109 with dissolve

menu:

    "Say hi.":
        jump choice5a

    "Just keep walking.":
        jump choice5b

label choice5a:

    $ choice5a = True

    scene sce109 with dissolve
    p "Hello!"
    scene sce110 with dissolve
    p "..."
    pt "I take that back, definitely a bad start."

    jump choice5_common

label choice5b:
    scene sce111 with dissolve
    pause

    jump choice5_common

label choice5_common:

    scene sce112 with dissolve
    mt "Hey broooo!!"
    scene sce113 with dissolve
    p "Duuuude, what's up?"
    scene sce114 with dissolve
    mt "The ceiling."
    p "Ha."

menu:
    "Hug Metal.":
        jump choice6a

    "Do your famous handshake.":
        jump choice6b

label choice6a:
    scene sce115 with dissolve
    pause
    scene sce116 with dissolve
    df "Gaaaayy..."

    jump choice6_common

label choice6b:

    $ choice6b = True

    scene sce117
    b "Bros"
    scene sce118
    b "before"
    scene sce119
    b "hoes."
    scene sce120 with dissolve
    df "Sweeeeett!"

    jump choice6_common

label choice6_common:

    scene sce114 with dissolve
    mt "Let's hurry, man. We're already late for class!"
    p "Ok, ok."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce121 with dissolve
    pause 1.0
    scene sce122 with dissolve
    mt "Annieeeee, Annieeeee!!"
    scene sce123 with dissolve
    an "Hello, Daniel."
    scene sce124a with dissolve
    mt "What a coincidence we're taking the same class!"
    pt "Yeah, right. You didn't insist on taking it..."
    mt "It's so good to see you! Hey Ann, this is my buddy [p], it's his first day here."
    scene sce124 with dissolve
    an "Hi, [p]. I like your hair!"
    p "Mmm...thanks? I like yours."
    an "Hehe."
    scene sce125 with dissolve
    an "This is Jessica, it's her first day too."
    p "Hello, Jessica."
    scene sce126 with dissolve
    p "So girls...what's up with that guy over there?"
    play music "audio/simpleplan.ogg" volume 0.6
    scene sce127:
        ypos -2.0
        ease 10 ypos 0.0
    pause

    scene sce128 with dissolve
    js "Right? We were just talking about it, he's been staring at us for ten minutes without saying a word...a little creepy if you ask me."
    scene sce129 with dissolve
    an "Don't be like that, Mr. Collins is just a little odd or at least that's what I've heard, give him a chance."
    scene sce130 with dissolve
    p "Oh! He's our teacher."
    mk "Professor."
    scene sce131 with dissolve
    mrc "All right, students! Take a seat! The MasterClass is about to begin!"
    scene sce132 with dissolve
    mrc "I know I don't need to introduce myself, I'm sure you already know who I am."
    mrc "But formalities are important here at Saint Francis so...I'm Master Tommy Collins! You can call me Master Collins or simply Master."
    mc "I've been watching you and I see some potential in the room but before sharing a piece of my knowledge, I have a question for all of you: Do you know many of your teachers here are entrepreneurs?"
    mk "Professors!"
    scene sce133 with dissolve
    mc "YOU! Hungry boy, say a number!"

menu:
    "I don't know.":
        jump choice7a

    "0.":
        jump choice7b

    "1.":
        jump choice7c

label choice7a:

    $ choice7a = True

    scene sce134 with dissolve
    mc "You are not hungry enough! I need someone who wants to eat the world!"
    scene sce135 with dissolve
    mc "YOU!...sitting next to Mr. Sheep."
    p "Heeyy!"
    mc "Say a number! Don't let me down!"
    scene sce136 with dissolve
    mt "1?"
    mc "You goddamn right!"
    scene sce137 with dissolve

    jump choice7_common

label choice7b:

    $ choice7b = True

    scene sce134 with dissolve
    mc "Zero? Really? What's wrong with this generation?!"
    scene sce135 with dissolve
    mc "YOU!...sitting next to Mr. Sheep."
    p "Heeyy!"
    mc "Say a number! Don't let me down!"
    scene sce136 with dissolve
    mt "1?"
    mc "You goddamn right!"
    scene sce137 with dissolve

    jump choice7_common

label choice7c:
    scene sce138 with dissolve
    mc "You goddamn right!"

    jump choice7_common

label choice7_common:

    scene sce132 with dissolve
    mc "I'm the only one of your teachers..."
    mk "May anybody speak properly in this class?"
    mc "...with multiple sources of income. So if it is about financial advice, I'm your guy!"
    mc "I really don't need this job, I'm a successful millionare! But I take pride in my desire to help future generations here at Saint Francis."
    mc "You may not know this yet, but the world out there is a jungle! And right now you all are prey being devoured by wolfs, lions, sharks...pick any animal, you'll still be prey!"
    mc "I'll teach you how to be Predators in life and maybe, just maybe, one day you'll all be like me: Masters!"
    scene sce139 with dissolve
    pause
menu:
    "Look at Metal.":
        jump choice8a

    "Look at Jessica.":
        jump choice8b

label choice8a:

    scene sce140 with dissolve
    p "What the..."
    p "Dude...dude! You ok?"
    scene sce141 with dissolve
    mt "Never been better."
    p "If you say so..."

    jump choice8_common

label choice8b:
    scene sce142 with dissolve
    pause
    scene sce143 with dissolve
    pause
    scene sce144 with dissolve
    pause
    scene sce145 with dissolve
    pause
    scene sce146 with dissolve
    pause

    jump choice8_common

label choice8_common:

    scene sce132 with dissolve
    mc "Enough talk, time for action! I'm going to need 4 students for our first activity."
    scene sce147 with dissolve
    mc "Great! We've got ourselves a volunteer! Come here!"
    scene sce148 with dissolve
    mc "What's your name, son?"
    mt "Daniel, Master Collins!"
    mc "Daniel! You'll be one of the future leaders of this country!"
    scene sce149 with dissolve
    mc "Who else is rea..."
    scene sce150 with dissolve
    mc "...another eager mind! Excellent!"
    scene sce151 with dissolve
    js "What do you think? Should we go? Just for fun?"
    mc "Yes! A proactive young lady!"
    scene sce152 with dissolve
    js "Nevermind."
    scene sce153 with dissolve
    js "Ann?!"
    scene sce154 with dissolve
    pause
    scene sce155 with dissolve
    mt "Come on, brother!"
    stop music fadeout 3.0

menu:
    "What gives.":
        jump choice9a

    "Stay with Jessica.":
        jump choice9b

label choice9a:

    $ choice9a = True

    scene sce156 with dissolve
    js "Seriously?"
    p "How bad could it be?"
    js "Whatever."

if choice7a:
    scene sce158 with dissolve
    mc "What a surprise, Mr. Sheep! Welcome!"
    js "Ha!"
    scene sce159 with dissolve
    pt "You've got to be kidding me."

    jump complete4

if choice7b:
    scene sce158 with dissolve
    mc "What a surprise, Mr. Sheep! Welcome!"
    js "Ha!"
    scene sce159 with dissolve
    pt "You've got to be kidding me."

else:
    scene sce158 with dissolve
    mc "A potential shark makes his appearance!"
    js "Pff."
    scene sce159 with dissolve
    pt "I only said \"one\"..."

label complete4:

    scene black with dissolve
    scene sce132 with dissolve
    mc "Ok class, now that all the participants are here, let me explain the rules to you: your classmates here will have to work in pairs, one will take the role of the leader and the other will be the follower."
    mc "Followers will stay on the right side of the room and leaders will be on my left, facing their partners."
    mc "I'm going to blindfold our followers here, and they will have to get to the other side listening to their partners instructions."
    mc "Simple enough, isn't it? I'll find out who might be leadership material!"
    mc "And of course there's a prize! They will be competing to get two spots for my next seminar \"Unleash the Beast Within\"! This is a one in a lifetime opportunity!"
    mt "I can't believe it, that's awesome!!"
    df "Let's do this!"
    scene sce160 with dissolve
    mc "I know people who did not volunteer are regretting it already, but it is what it is."
    mc "Let's get ready to start."
    scene sce161 with dissolve
    pt "Who should I partner up with?"
    pt "Metal wants me to work with Dumbface, but damn! Look at him...besides, Ann is next to me..."

menu:
    "Dumbface.":
        jump choice10a
    "Ann.":
        jump choice10b

label choice10a:

    play music "audio/race.ogg" volume 0.7
    pt "\"Bros before hoes\" it is. You can thank me later, bro."
    pt "Man, it's gonna be so rude to walk past Ann...at least make your move first, Metal!"

menu:
    "Wait.":
        jump choice11a

    "Ignore Ann.":
        jump choice11b

label choice11a:

    $ choice11a = True

    pt "What are you waiting for?"
    scene sce162 with dissolve
    an "[p], do you want to work together?"
    p "Sure!"
    pt "Sorry, bro."
    scene black with dissolve
    scene sce163 with dissolve
    an "Do you want to lead?"
    p "I don't think so. If we're gonna be blindfolded, I'd rather follow your instructions. I don't want you to trip or get hurt."
    scene sce164 with dissolve
    an "Awww...thank you! You're cute."
    pt "Man, I'm so full of bs."
    scene black with Dissolve(1.0)
    scene sce165 with dissolve
    mt "What a friend you are..."
    p "Dude, I wanted to help...you took way too long to ask her."
    mt "Excuses, excuses..."
    scene sce166 with dissolve
    mc "Followers! Are you ready?"
    mt "YES!"
    scene sce167 with dissolve
    mc "Leaders are you ready?"
    scene sce168 with dissolve
    df "Yes, Master!"
    scene sce160 with dissolve
    mc "Go!!"
    scene black
    pt "Can't see anything with this thing, I just have to trust Ann..."
    scene sce169 with dissolve
    an "Turn right, [p]! Go straight like 20 long steps..."
    df "Go! Move!"
    mt "Go where!"
    scene black
    pt "One, two, three...fifteen, sixteen..."
    an "Ok, stop! Take it off."
    scene sce170 with hpunch
    an "We won!!"
    p "Wow, you made it so simple!"
    scene sce171 with dissolve
    mc "Congratulations! Very good work, young lady! You really are something else!"
    scene sce172 with dissolve
    mc "And you! You definitely can follow orders!"
    pt "Was that supposed to be a compliment?"
    mc "Don't forget, young man, a good leader was once a good follower!"
    scene sce173 with dissolve
    mc "You're going to need this pin for the event. You'll be in the VIP area."
    an "Thank you, Mr. Collins! We'll be there!"
    pt "They look nice, but no way I'm going...imagine a hundred people like this guy."
    scene black with dissolve
    scene sce132 with dissolve
    mc "I'm glad to see people with great potential here. That last activity just show me who is ready to be a predator in this class!"
    mc "Well, that's all for today students. See you on Thursday for another life-changing lesson! Class dismissed!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce174 with dissolve
    p "Hey, Jessica, have you seen Metal?"
    scene sce175 with dissolve
    js "Who?"
    scene sce174 with dissolve
    p "Daniel."
    scene sce175 with dissolve
    js "Who?"
    p "Haha. Come on!"
    scene sce176 with dissolve
    js "He left while you guys were talking to Mr. Collins."
    p "That's weird."
    pt "Damn, Metal..."
    scene black with Dissolve(1.5)
    scene sce177 with dissolve
    p "Girls I gotta run now, I have another class. It was nice meeting you! See you around."
    an "Bye, [p]. Nice meeting you as well."
    js "See ya."

    scene black with Dissolve(2.0)

    jump choice9_common

label choice11b:

    $ choice11b = True

    scene sce178 with dissolve
    pause
    scene sce179 with dissolve
    p "Hey, man, let's work together."

if choice6b:

    scene sce180 with dissolve
    df "Of course, buddy. \"Bros before hoes\", right?"
    pt "What the..."
    df "I'm Billy."
    p "[p]."
    scene sce181 with dissolve
    bi "You can lead, by the way. I'm better at listening than at commanding anyways."
    p "Ok, I'll be the leader."

    scene black with Dissolve(1.0)
    scene sce183 with dissolve
    pause
    scene sce166 with dissolve
    mc "Followers! Are you ready?"
    mt "YES!"
    bi "Yes, Master Collins!"
    scene sce167 with dissolve
    mc "Leaders, are you ready?"
    an "Yeah!"
    p "Yeah, yeah."
    scene sce160 with dissolve
    mc "Go!!"
    scene sce183 with dissolve
    scene sce184 with dissolve
    p "Alright, Billy, listen..."

else:
    scene sce182 with dissolve
    df "Hold up a second, mmm...are you a sheep or a tiger?"
    pt "What?!"
    pt "Just play along, [p]."
    p "Huff...a tiger."
    scene sce180 with dissolve
    df "Welcome to the team, brother!"
    pt "Really?"
    scene sce181 with dissolve
    df "My name's Billy, by the way. Listen, I'm not a predator yet, but you do look like one, why don't you do the leading thing?"
    p "Whatever dude."
    scene sce180 with dissolve
    bi "Yeah, definitely a predator, you don't give a fuck. I trust you!"
    pt "Someone kill me..."
    scene black with dissolve
    scene sce183 with dissolve
    pause
    scene sce166 with dissolve
    mc "Followers! Are you ready?"
    mt "YES!"
    bi "Yes, Master Collins!"
    scene sce167 with dissolve
    mc "Leaders, are you ready?"
    an "Yeah!"
    p "Yeah, yeah."
    scene sce160 with dissolve
    mc "Go!!"
    scene sce183 with dissolve
    scene sce184 with dissolve
    p "Alright, Billy, listen..."

menu:
    "Turn right!":
        jump choice12a

    "Go straight!":
        jump choice12b

label choice12a:
    scene sce187 with dissolve
    p "Good, Billy, now go straight carefully."
    scene sce188 with dissolve
    p "What are you doing?!"
    scene sce189 with dissolve
    p "Stoooooooop!!"
    scene sce186 with dissolve
    pause
    scene black with dissolve
    scene sce191 with dissolve
    mc "Well, class, apparently, your classmate here has no idea how to be a leader."
    scene sce192 with dissolve
    p "What?! It was Billy's fault! He started running out of nothing!"
    mc "A follower is just a reflection of the leader!"
    mc "But I'm not surprised at all, I knew you didn't have what it takes."
    scene sce194 with dissolve
    mc "And you all can leave now. Nobody here is worth my time! Class dismissed!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce195 with dissolve
    p "Hey, bro, wait up!"
    scene sce196 with dissolve
    pt "I guess he really wanted to win..."
    scene black with Dissolve(1.5)
    scene sce177 with dissolve
    p "Girls I gotta run now, nice meeting you! Bye!"
    an "Bye, [p]."
    js "See ya."

    scene black with Dissolve(2.5)

    jump choice9_common

label choice12b:
    scene sce184 with dissolve
    pt "I'm going to delay things a little so Metal and Ann can win...what a great friend I am!"
    p "Go straight, Billy!"
    scene sce185 with dissolve
    p "Why are you ru...noooo!"
    scene sce186 with dissolve
    pause
    scene black with dissolve
    scene sce190 with dissolve
    mc "Well, class, Billy here got hurt so we'll leave the activity for another time. Too bad! You've missed the chance to go to my seminar!"
    scene sce193 with dissolve
    mc "Your classmate here really needed it because he has no idea how to be a leader!"
    mc "It's not surprising at all, I knew he didn't have what it takes."
    scene sce194 with dissolve
    mc "You all can leave now. Class dismissed!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce195 with dissolve
    p "Hey, bro, wait up!"
    scene sce196 with dissolve
    pt "I guess he really wanted to win...Billy is there, should I apologize to him?"
    pt "Nah, I didn't tell him to run."
    scene black with Dissolve(1.5)
    scene sce177 with dissolve
    p "I gotta go girls, I have another class! Bye!"
    an "Bye, [p]."

    scene black with Dissolve(2.5)

    jump choice9_common

label choice10b:

    $ choice10b = True

    play music "audio/race.ogg" volume 0.7
    scene sce161 with dissolve
    p "Hey, Ann, do you..."
    scene sce162 with dissolve
    an "Let's work together, [p]!"
    p "Oh, ok, good!"
    pt "Sorry, bro."
    scene black with dissolve
    scene sce163 with dissolve
    an "Do you want to lead?"
    p "I don't think so. If we're gonna be blindfolded, I'd rather follow your instructions. I don't want you to trip or get hurt."
    scene sce164 with dissolve
    an "Awww...thank you! You're cute."
    pt "Man, I'm so full of bs."
    scene black with Dissolve(1.0)
    scene sce165 with dissolve
    mt "What a friend you are..."
    p "Dude, I wanted to help...you took way too long to ask her."
    mt "Excuses, excuses..."
    scene sce166 with dissolve
    mc "Followers! Are you ready?"
    mt "YES!"
    scene sce167 with dissolve
    mc "Leaders are you ready?"
    scene sce168 with dissolve
    df "Yes, Master!"
    scene sce160 with dissolve
    mc "Go!!"
    scene black
    pt "Can't see anything with this thing, I just have to trust Ann..."
    scene sce169 with dissolve
    an "Turn right, [p]! Go straight like 20 long steps..."
    df "Go! Move!"
    mt "Go where!"
    scene black
    pt "One, two, three...fifteen, sixteen..."
    an "Ok, stop! Take it off."
    scene sce170 with hpunch
    an "We won!!"
    p "Wow, you made it so simple!"
    scene sce171 with dissolve
    mc "Congratulations! Very good work, young lady! You really are something else!"
    scene sce172 with dissolve
    mc "And you! You definitely can follow orders!"
    pt "Was that supposed to be a compliment?"
    mc "Don't forget, young man, a good leader was once a good follower!"
    scene sce173 with dissolve
    mc "You're going to need this pin for the event. You'll be in the VIP area."
    an "Thank you, Mr. Collins! We'll be there!"
    pt "They look nice, but no way I'm going...imagine a hundred people like this guy."
    scene black with dissolve
    scene sce132 with dissolve
    mc "I'm glad to see people with great potential here. That last activity just show me who is ready to be a predator in this class!"
    mc "Well, that's all for today students. See you on Thursday for another life-changing lesson! Class dismissed!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce174 with dissolve
    p "Hey, Jessica, have you seen Metal?"
    scene sce175 with dissolve
    js "Who?"
    scene sce174 with dissolve
    p "Daniel."
    scene sce175 with dissolve
    js "Who?"
    p "Haha. Come on!"
    scene sce176 with dissolve
    js "He left while you guys were talking to Mr. Collins."
    p "That's weird..."
    pt "Damn, Metal."
    scene black with Dissolve(1.5)
    scene sce177 with dissolve
    p "Girls I gotta run now, I have another class. It was nice meeting you! See you around."
    an "Bye, [p]. Nice meeting you as well."
    js "See ya."

    scene black with Dissolve(2.5)

    jump choice9_common

label choice9b:

    $ choice9b = True

    scene sce139a with dissolve
    pt "I'd rather die before taking part in this."
    play music "audio/funkything.ogg" volume 0.6
    scene sce197 with dissolve
    p "You seem surprised your friend wanted to participate."
    js "Absolutely! She hates being in the spotlight. Well, she used to. She's changed over the last year...I like this new Ann, more...more confident."
    p "You know what? I can tell exactly the same about Metal."
    scene sce198 with dissolve
    js "Who?"
    p "My friend, Daniel."
    scene sce197 with dissolve
    js "I know! I was just messing with you...you know I've heard a story about \"Metal\"."
    p "What story?"
    scene sce199 with dissolve
    js "I'm not sure I should tell ya..."
    p "Come on, don't leave me hanging."
    scene black with dissolve
    scene sce132 with dissolve
    mc "Silence please! All participants are here, let me explain the rules to you: your classmates here will have to work in pairs, one will take the role of the leader and the other will be the follower."
    mc "Followers will stay on the right side of the room and leaders will be on the left, facing their partners."
    mc "I'm going to blindfold our followers here, and they will have to get to the other side listening to their partners instructions."
    mc "Simple enough, isn't it? I'll find out who might be leadership material!"
    mc "And of course there's a prize! They will be competing to get two spots for my next seminar \"Unleash the Beast Within\"! This is a one in a lifetime opportunity!"
    mt "I can't believe it, that's awesome!!"
    df "Let's do this!"
    scene sce160 with dissolve
    mc "I know people who did not volunteer are regretting it already, but it is what it is."
    mc "Let's get ready to start."
    scene black with Dissolve(1.0)
    scene sce200 with dissolve
    js "So...what are you going to major in?"
    p "Changing the subject?"
    js "Hehe, did it work?"
    p "Business. You?"
    js "The same! You don't strike me as the business type, you know."
    p "You mean \"Master\" Collins type?"
    scene sce152 with dissolve
    js "Ugh, that guy's a joke, not a real businessman I'm telling ya...I meant more like my dad's type, they do have the same vibe though."
    scene black with Dissolve(1.0)
    scene sce201 with dissolve
    mc "And we've got our winners here! Rivka and Billy! What a promising future you have!"
    js "Oh my God."
    p "Are they for real?"
    mt "I'm so jealous right now."
    scene black with dissolve
    scene sce132 with dissolve
    mc "I'm glad to see people with great potential here. That last activity just show me who is ready to be a predator in this class!"
    mc "Well, that's all for today students. See you on Thursday for another life-changing lesson! Class dismissed!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    scene sce202 with dissolve
    js "I can't believe you guys lost!"
    scene sce203 with dissolve
    an "It's ok. I'm happy for Billy, looks like he's a true leader."
    mt "He's not! I'm sure she was cheating! No way she was following those directions..."
    js "Anyways, let's get moving. I have another class!"
    p "Yeah, me too."

    scene black with Dissolve(2.5)

    jump choice9_common

label choice9_common:

    scene black
    jump Ep2
