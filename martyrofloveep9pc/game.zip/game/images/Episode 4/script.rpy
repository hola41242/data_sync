#Important Decisions
default choice62a = False
default choice62b = False
default choice63a = False
default choice63b = False
default choice64a = False
default choice64b = False
default choice65a = False
default choice65b = False
default choice66a = False
default choice66b = False
default choice67a = False
default choice67b = False

#Vanessa cum
default choice76a = False
default choice76b = False




# Start Episode 4
label ep4:

    $ renpy.movie_cutscene("videos/evil.ogv")

    play music "audio/creepy.ogg"
    scene ima1 with dissolve
    ge "What do you think there's inside?"
    fz "We won't know until we get in..."
    ge "I have a bad feeling about this, Franz, it was a mess last time...and now we're wearing this? It just keeps getting worse."
    fz "William said not to leave a single hair in there."
    ge "See? That's what I'm talking about..."
    fz "Just be cautious."
    scene ima2 with Fade(1,0,1.5)
    fz "What the fuck is this?"
    ge "Holy shit! Is that...is that what I think it is?!"
    fz "Yeah, looks like it..."
    scene ima3 with dissolve
    ge "I'm not going anywhere near that satanic shit!"
    fz "{i}\"Get rid of everything you find in there.\"{/i}, those were the orders."
    ge "Fuck the orders, man! I'm not doing this..."
    fz "We have to..."
    scene ima4 with dissolve
    ge "No, Franz, we don't have to...look at that shit! Even the place feels heavy!"
    fz "Calm down."
    ge "Dude, body disposal is a felony! That's ten to twelve years! Listen to me: we're not doing this...I know what you're gonna say and yeah, I want to know what happened to my sister, but not at this cost..."
    fz "George, we knew what we were getting into, I'm not quitting now..."
    scene ima5 with dissolve
    ge "Where are you going?! Hold up!"
    scene ima6 with dissolve
    ge "I can't let you do it, man, what are you thinking? We're here to end this, not to be a part of it. I know you want to avenge your dad, but don't lose yourself in the process."
    fz "Wake up, George, we're already part of it: it's not the first bloody room we clean!  We got dirt on our hands already, deal with it!"
    ge "This's fucking different! There's a corpse there, don't you understand? And what if they have cameras in here? Have you thought of it? They're always watching!"
    fz "And we're not wearing masks today..."
    fz "Fuck! This's it then...this's when we make a choice: if we do it, they'll have something on us; if we don't, we're dead..."
    stop music fadeout 3.0
    bo "{size=-8}Segítség...{/size}"
    scene ima7 with dissolve
    ge "Did you hear that?!"
    bo "{size=-8}Help...{/size}"
    scene ima7a with vpunch
    fz "Hoooooly shit!"
    ge "What the fuck's going on?!"
    scene ima8 with dissolve
    pause 1
    scene ima9 with dissolve
    fz "HOLY FUCK!!! George, get the car! Now!"
    ge "Jesus Christ! I'm on it!"
    fz "We're gonna get you out of here...you're gonna get through this, you hear me?!"
    scene black with Dissolve(1.5)
    pause
    play music "audio/sadpiano.ogg"
    fzt "\"Morality, like art, consists of drawing the line somewhere.\""
    scene ima10 with dissolve
    fzt "Where do I draw mine?"
    fzt "Where did the man who did this draw his?"
    scene ima11 with dissolve
    fzt "Am I good?"
    fzt "Bad?"
    fzt "Both?"
    fzt "A decent man can do horrible things to protect his family...a violent murderer must have someone he'd never hurt..."
    fzt "We all are capable of doing beautiful and terrible things, we all can be heroes in some stories and villains in others..."
    scene ima12 with dissolve
    fzt "Don't you ever dare to call me a hero, little girl, I knew this was happening and I just stood there and watched...I chose to do nothing."
    fzt "I can't even start to imagine the hell you've been through..."
    fzt "I know I'm late..."
    fzt "I'm sorry..."
    scene ima13 with dissolve
    fzt "This could be Amelia, my brother, George's sister! That's why he's so worried..."
    fzt "I've been told to forgive, I've been taught to show some sympathy, have mercy...\"You're a good boy, don't let anybody change your heart.\""
    fzt "\"Love your enemies, bless them that curse you, do good to them that hate you...\""
    fzt "I certainly can't do that."
    fzt "My enemies are all those who can hurt another human being like this! Am I supposed to love them? Seriously?!"
    fzt "Love can't be the answer! Many have tried those ways and they all ended up killed. You don't shake hands with the ones who spit on you, you don't give a flower if you received a knife."
    scene ima14 with dissolve
    fzt "You don't defeat evil with kindness...to defeat evil you gotta become something even worse...that's the sacrifice!"
    fzt "I want to stop this...I have to!"
    fzt "George, my friend, we won't win this war unless we sacrifice our souls...can you do that?"
    fzt "Can I?"
    scene ima15 with dissolve
    fzt "Can I be more evil than this?"
    stop music fadeout 3.0
    scene black with Dissolve(3)

    scene ima16 with dissolve
    wi "Where the fuck is Franz?!"
    ge "In his bedroom, with the girl..."
    wi "You two really fucked it up this time...get him!"
    scene ima17 with dissolve
    fz "That's everything we had, haven't gone grocery shopping this week, sorry...you got some cereal there, bacon, toasts..."
    scene ima18 with dissolve
    fz "If you need anything just let us know, we'll be in the living room, ok?"
    uk "..."
    fz "Uhm...no comments? Err...do you speak English?"
    scene ima19 with dissolve
    fz "A little? No problem, we'll work that out...Those clothes are too big for you...I'll get you something better later, ok? Uhm, I leave you alone..."
    scene ima20 with dissolve
    uk "{size=-8}Thank you.{/size}"
    fz "You are very welcome...eat something and try to rest...uhm...you're safe now, ok?"
    scene ima21 with dissolve
    ge "Franz, come here..."
    fz "Coming."
    play music "audio/beat6.ogg"
    scene black with dissolve
    scene ima22 with dissolve
    wi "What the fuck were you two thinking?! You had one job, one fucking job...clean! Was it really that hard?!"
    fz "Listen, we were about to do it, but we found her...what did you expect us to do? Leave her? Kill her? We're not murderers..."
    wi "Oh, no, you're not...you're heroes, right? Tell me, heroes, what do you think it's going to happen now?"
    fz "Why you're acting as if saving her was wrong?"
    scene ima23 with dissolve
    wi "Because it was, asshole! Can't you see it?! How stupid can you be?! It was you or her! You killed us the moment you saved her!"
    ge "What?! You don't know that for sure..."
    scene ima24 with dissolve
    wi "Ooohhh, fuuuck meeeee! This's my fault for recruiting these two dumb pieces of shit..."
    scene ima25 with dissolve
    wi "Little Georgie here thought this was a game, right? You betrayed them, son of a bitch! They tested your loyalty and you failed!"
    wi "You think she was still alive by some sort of miracle? They don't know how to kill, is that it? As far as I'm concerned, this girl could even be one of them..."
    wi "And by the way, geniuses, what's she doing here? Why she's not in the hospital?"
    ge "Franz checked her wounds, she has many cuts, but none's lethal, right Franz?...And we didn't want to get Police attention, so..."
    scene ima26 with dissolve
    wi "Oh, no, definitely you made a better move: you brought her to your place...downtown...in broad daylight...brilliant! Just brilliant!"
    wi "No lethal wounds, you said? I'll let you do your own thinking...I'm fucking sick of you two, go fuck yourselves..."
    scene ima27 with dissolve
    ge "Hold up! What do we do now?"
    scene ima28 with dissolve
    wi "Rats...that's what you are to them: rats..."
    wi "Hide."
    stop music fadeout 3.0
    scene black with dissolve
    scene ima29 with dissolve
    ge "Dude, what the fuck?! Did he just come over to say that?!"
    fz "He's mad, we fucked everything up...to be honest, we got off easy: I was expecting a punch..."
    scene ima30 with dissolve
    ge "Brother, we don't deserve that...we saved that girl today! If that means we're fucked, I can die happy now."
    fz "What about your sister? My father?"
    ge "This feels way better than revenge, brother, trust me...besides, uhm, remember William said he won't let them get near his son again? He must have a backup plan already..."
    fz "You're right about that..."
    scene black with Dissolve(3.0)

    play music "audio/tension2.ogg"
    scene ima349 with dissolve
    mrre "I don't want to hear about it, do it!"
    cs "I can't! How am I go...do you realize what you're asking?!"
    mrre "Just remember what happens if you don't..."
    cs "He doesn't even like me!"
    scene ima350 with dissolve
    mrre "Shush, shush...enough talk. Get it done."
    scene ima351 with dissolve
    mrre "Don't forget to record it..."
    stop music fadeout 2.5
    scene black with Dissolve(3.0)

    play music "audio/jazzinstrumental.ogg"
    scene s946 with dissolve
    an "Hi, [p]! How are you doing?"
    p "Heeyyy, good, good, you girls?"
    scene s947 with dissolve
    js "We're great...we were just talking about you!"
    p "Yeah? What were you saying?"
    js "I was just thinking, you know, my birthday is coming...you wanna come?"
    p "Sure! When is it?"
    scene s948 with dissolve
    js "Next Saturday, after finals...and just to let you know, I'm inviting few people...feel special, haha!"
    p "I do! I like that..."
    an "You can bring Samantha if you want."
    scene s949 with dissolve
    js "Errrr...no, he can't, I don't know her very well."
    an "She's cool, I've talked to her a couple of times, Jess."
    js "It doesn't matter, I don't know her."
    scene s950 with dissolve
    js "Sorry, [p], I probably sounded like a bitch, but I hope you understand...it's my birthday and as I said I'm inviting few people...I like you, that's why you're invited..."
    p "Yeah, you acted a little bitchy there, hehe, but I understand...and I like you, too!"
    scene s951 with dissolve
    an "You're so naive...she didn't mean it as frie..."
    scene s952 with dissolve
    an "Aaahhh!"
    js "Ann, you shut up!"
    scene s953 with dissolve
    js "Oh! I almost forget...it's a theme party! You know, I like the space, UFOs, that kind of stuff, so..."
    p "Cool! What should I wear? A spacesuit?"
    js "Haha...that'd be awesome, to be honest."
    p "Haha, you know, there's this video game I really like about a space soldier...I'll see what I can do!"
    an "Hey, that sci-fi themed party sounds pretty cool, Jess!"
    scene s954 with dissolve
    p "Yeah, I'm down for it! Gotta go girls now, I have an exam...wish me luck!"
    an "Good luck, [p]!"
    stop music fadeout 3.0

    scene black with Dissolve(3.0)
    play sound "audio/bell.mp3"
    scene ima31 with dissolve
    pt "Someone's coming..."
    play music "audio/chill.ogg"
    scene ima32 with dissolve
    uk "Yes?"
    scene ima33 with dissolve
    uk "Oh! Hahaha, I'm sorry..."
    scene ima34 with dissolve
    uk "What's this all about?"
    p "What do you mean? Is this Jessica's place?"
    uk "Uhum...are you a stripper or something?"
    p "Haha, no, no, I'm not...wait...how come you're not wearing...don't tell me she..."
    scene ima35 with dissolve
    uk "Yup, she's always been a jokester, but I guess she plays too much sometimes...sorry."
    scene ima35 with hpunch
    p "Fuuuuuck! She got me gooooood..."
    uk "If it's of any help, your costume's awesome!"
    p "Nope, it doesn't help...damn, I'm not going in like this, and this shit cost me lot, fuck!"
    scene ima36 with dissolve
    p "Give her this, ok?"
    uk "You bought her a present? She's going to feel super guilty..."
    p "That's the idea...I'm out..."
    stop music fadeout 3.0
    scene ima37 with dissolve
    uk "I'm really sorry, my cousin can be a real bitch sometimes..."
    p "Yeah, now I know..."
    an "Nice outfit, space man!"
    play music "audio/po.ogg"
    scene ima38:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "Ann? Wow, you look incredible! That's an amazing costume!"
    an "Haha, thanks! Hi, Orla!"
    orl "Hi, Annie! I'm sure you know there's no...Oh, I see...you're just an angel, girl..."
    p "I'm confused, what's happening here? Did Jessica prank you, too? That doesn't make any sense, you're her best friend..."
    scene ima39 with dissolve
    p "So...did you lie to me?"
    orl "I did not..."
    p "Then, I don't know what's going on here..."
    scene ima40 with dissolve
    p "How come you're wearing that?"
    an "Hehe..."
    p "He-he, what? I don't get it...think, [p], think...you were there when Jessica told me about the party..."
    orl "I knew it!"
    p "So, you knew about the prank, but didn't tell me...Jessica told you not to probably...and she's your friend so...but you didn't want me to look like a fool..."
    scene ima40 with hpunch
    p "OH MY GOD! You did this for me?! Really?!"
    an "Haha, uhum..."
    p "It's like she said: You're an angel! I can't believe it...let me give you a hug...you're amazing!"
    scene ima41 with dissolve
    p "{size=-5}Seriously, you're an awesome human being, Annie...{/size}"
    scene ima42 with dissolve
    an "Not really, let's just show everybody how cool we look!"
    pt "I don't want to go in there anymore, if they're all like Jessica, fuck them! I'd rather do something with you alone!"
    pt "Uhm, but I can't tell her that, it's her friend's birthday, she's not leaving, she must know everybody in there...and she's wearing that suit! Now it's me who can't let her go in there alone..."
    p "You know I was about to leave, but since you're here..."
    p "Let's do this!"
    stop music fadeout 3.0
    scene black with Dissolve(1.5)
    scene ima43 with dissolve
    orl "I think Jess is in the backyard if you want to give her that...I'll go see my boyfriend now..."
    p "Yeah, go ahead, thanks..."
    an "Talk to you later, Orla!"
    scene ima44 with dissolve
    an "What do you want to do now?"
    p "Drink? I don't know, I thought you were gonna tell me..."
    scene ima45 with dissolve
    an "Uhm...if I'm not mistaken, that girl over there's Vanessa...the hair, the slutty dress, yeah, it's her...I don't really like her..."

if choice38a:

    p "Vanessa? Rings a bell..."
    jump partyjess

label partyjess:
    an "And that guy goes to college with us..."
    p "He does?"
    an "Yeah, I saw Jess talking to him a couple times, but didn't know they were close..."
    p "Never saw him before."
    an "No? He's in Mr. Collins's class...Oh, did you hear what happened to him?"
    p "Nope, what happened to \"The Master\"?"
    an "You mean what didn't happen to him...Poor guy: he got fired from St. Francis! You know he's being sued by everybody who got injured in his last event, right?"

if choice45a:

    p "You included?"
    an "Haha, noooo..."
    jump partyjess1

label partyjess1:

    p "I didn't know any of it..."
    an "That's why we didn't have a final and everybody just passed..."
    p "I kind of feel sorry for him now that you're telling me..."
    scene ima46 with dissolve
    an "Yeah, me too...I mean he's a bullshit artist, but I don't wish him bad...I don't wish bad on anybody..."
    p "I think I need that drink now."
    scene ima47 with dissolve
    an "Haha, so what's gonna be?"
    p "Let's see..."
    scene black with Dissolve(1.0)
    scene ima45 with dissolve

    call screen jessparty

    screen jessparty():
        add "ima45"
        modal True

        imagebutton auto "vanehouse_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Vanessa")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vanessatalk")

label vanessatalk:
    play music "audio/upbeat.ogg"
    scene ima48 with dissolve
    pt "I want to know who this Vanessa is...Ann told me she doesn't like her though..."
    p "Hello."
    scene ima49 with dissolve
    pause 1
    scene ima50 with dissolve
    va "Now, this's interesting!"
    scene ima51 with dissolve
    va "Hey, Ann, didn't know you had a boyfriend...why are you two wearing that?"
    an "Long story..."
    scene ima52 with dissolve
    p "Hey, I remember you! You sold me a guitar some months ago!"
    va "It's probable, yeah...what was your name again?"
    p "[p]."
    va "You should've told me Ann was your girlfriend to give you a discount..."
    p "Oh, no, we're not a couple...we're friends..."
    scene ima53 with dissolve
    an "I want to say hi to Jess, [p]."
    p "Sure, go ahead."
    scene ima54 with dissolve
    an "You're coming with me."
    p "But I'm..."
    scene ima55 with dissolve
    an "Moooove!"
    p "Geeezzz..."
    scene ima56 with dissolve
    p "Talk to you later, Vanessa."
    scene ima57 with dissolve
    pause 1
    an "Ugh."
    scene black with Dissolve(1.0)

    call screen jessparty1

    screen jessparty1():
        add "ima45a"
        modal True

        imagebutton auto "arrow1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jessgarden")

label jessgarden:

    stop music fadeout 3.0
    scene ima58 with dissolve
    p "Hey, that was rude...I was talking to them."
    an "Them? You mean her...I told you I don't like her...{i}\"I didn't know you had a boyfriend\"{/i}, bitch..."
    p "Haha, she's alright."
    an "Shh...keep walking..."
    pt "Jessica's over there...looking fine tonight...and bored..."
    scene ima58 with dissolve

label jessparty2:

    call screen jessparty2

    screen jessparty2():
        add "ima58a"
        modal True

        imagebutton auto "jessgarden_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Jessica")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jesstalk")

        imagebutton auto "arrow2_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("drink")

label drink:
    scene ima59 with dissolve
    pt "Just some drinks...I could grab some later..."

    call screen jessparty3

    screen jessparty3():
        add "ima59a"
        modal True

        imagebutton auto "arrow3_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow3")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("jessparty2")

label jesstalk:

    play music "audio/barilicious.ogg"
    scene ima60 with dissolve
    p "Hey! Happy Birthday..."
    scene ima61 with dissolve
    pause 1
    scene ima62 with dissolve
    js "[p]! Oh my God! C'mere, I was just thinking about you!"
    scene ima63 with dissolve
    js "Hold it, please!"
    scene ima64 with dissolve
    js "I'm so sorry, [p], I didn't..."
    an "Hey, Jess!"
    scene ima65 with dissolve
    js "I didn't see you there, Annie..."
    an "I'm not that short, hehe."
    js "Why are you dressed like that? What's going on?"
    an "I just wanted to match outfits with our buddy [p] here..."
    scene ima66 with dissolve
    js "Jesus, Ann, you're making me look like the worst sh...excuse me..."
    pt "What the hell?"
    scene ima67 with dissolve
    an "Jess! Come on, where are you going?"
    uk "Way to go, asshole!"
    scene ima68 with hpunch
    p "What?! Who the fuck are you calling an asshole, asshole?...And don't give me that look, bitch!"
    scene ima69 with dissolve
    p "Listen to me, you motherfucker, I've had a real bad day and I'm about to snap at someone, is it gonna be you?...Get the fuck out of here before I break your fucking nose..."
    scene ima70 with dissolve
    p "Yeah, that's right...all that juice didn't grow you balls!"
    pt "Hahaha, he must think I'm crazy as hell, wearing this suit and all, haha..."
    pt "If he knew I don't even know how to fight...how hard could it be anyways."
    scene black with dissolve
    scene ima71 with dissolve
    pt "Ok, what now?"
    stop music fadeout 3.0

label jessparty4:
    call screen jessparty4

    screen jessparty4():
        add "ima71a"
        modal True

        imagebutton auto "arrow4_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow4")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("valgarden")

        imagebutton auto "arrow5_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow5")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("blackotalk")

label blackotalk:

    scene ima84 with dissolve
    p "Hey, bro, have you seen Jessica?"
    scene ima85 with dissolve
    uk "I saw her going upstairs...looked upset."
    p "And the girl you were talking to? Vanessa..."
    scene ima86 with dissolve
    uk "Her loss...that bitch's not pretty, but hot, you know what I mean?"
    p "Yeah, I get you, hot does not equal beautiful. Sometimes, you see a pretty face and that's all, you don't get turned on."
    scene ima87 with dissolve
    uk "Exactly! Ugly bitches know how to ride! Who needs a pretty face? You don't fuck a face..."
    p "Well, sometimes you do..."
    scene ima88 with dissolve
    uk "Aaahhh, haha!"
    p "Ahaaa!"
    p "Gotta go check on Jessica, man."
    uk "Aight."
    scene black with dissolve
    scene ima143 with dissolve
    p "Vanessa, have you seen Jessica?"
    va "She went upstairs, cutie."
    p "Is it ok if I go there?"
    va "I don't think she'd mind..."
    scene black with dissolve
    scene ima107 with dissolve
    pt "Let's go find her..."
    scene ima110 with dissolve
    pause 1
    jump jessroom

label valgarden:

if choice9b:
    scene ima72 with dissolve
    pt "Nice ass...too bad I don't know them, Jessica could introduce us...hey! I still have her present with me, better go give it to her..."
    scene black with dissolve
    scene ima84 with dissolve
    p "Hey, bro, have you seen Jessica?"
    scene ima85 with dissolve
    uk "I saw her going upstairs...looked upset."
    p "And the girl you were talking to? Vanessa..."
    scene ima86 with dissolve
    uk "Her loss...bitch's not pretty, but hot, you know what I mean?"
    p "Yeah, I get you, hot does not equal beautiful. Sometimes, you see a pretty face and that's all, you don't get turned on."
    scene ima87 with dissolve
    uk "Exactly! Ugly bitches know how to ride! Who needs a pretty face? You don't fuck a face..."
    p "Well, sometimes you do..."
    scene ima88 with dissolve
    uk "Aaahhh, haha!"
    p "Ahaaa!"
    p "Gotta go check on Jessica, man."
    uk "Aight."
    scene black with dissolve
    scene ima143 with dissolve
    p "Vanessa, have you seen Jessica?"
    va "She went upstairs, cutie."
    p "Is it ok if I go there?"
    va "I don't think she'd mind..."
    scene black with dissolve
    scene ima107 with dissolve
    pt "Let's go find her..."
    scene ima110 with dissolve
    pause 1
    jump jessroom

if choice11b:
    scene ima72 with dissolve
    pt "Nice ass...too bad I don't know them, Jessica could introduce us...hey! I still have her present with me, better go give it to her..."
    scene black with dissolve
    scene ima84 with dissolve
    p "Hey, bro, have you seen Jessica?"
    scene ima85 with dissolve
    uk "I saw her going upstairs...looked upset."
    p "And the girl you were talking to? Vanessa..."
    scene ima86 with dissolve
    uk "Her loss...bitch's not pretty, but hot, you know what I mean?"
    p "Yeah, I get you, hot does not equal beautiful. Sometimes, you see a pretty face and that's all, you don't get turned on."
    scene ima87 with dissolve
    uk "Exactly! Ugly bitches know how to ride! Who needs a pretty face? You don't fuck a face..."
    p "Well, sometimes you do..."
    scene ima88 with dissolve
    uk "Aaahhh, haha!"
    p "Ahaaa!"
    p "Gotta go check on Jessica, man."
    uk "Aight."
    scene black with dissolve
    scene ima143 with dissolve
    p "Vanessa, have you seen Jessica?"
    va "She went upstairs, cutie."
    p "Is it ok if I go there?"
    va "I don't think she'd mind..."
    scene black with dissolve
    scene ima107 with dissolve
    pt "Let's go find her..."
    scene ima110 with dissolve
    pause 1
    jump jessroom

if choice45b:
    scene ima72 with dissolve
    pt "Nice ass...too bad I don't know them, Jessica could introduce us...hey! I still have her present with me, better go give it to her..."
    scene black with dissolve
    scene ima84 with dissolve
    p "Hey, bro, have you seen Jessica?"
    scene ima85 with dissolve
    uk "I saw her going upstairs...looked upset."
    p "And the girl you were talking to? Vanessa..."
    scene ima86 with dissolve
    uk "Her loss...bitch's not pretty, but hot, you know what I mean?"
    p "Yeah, I get you, hot does not equal beautiful. Sometimes, you see a pretty face and that's all, you don't get turned on."
    scene ima87 with dissolve
    uk "Exactly! Ugly bitches know how to ride! Who needs a pretty face? You don't fuck a face..."
    p "Well, sometimes you do..."
    scene ima88 with dissolve
    uk "Aaahhh, haha!"
    p "Ahaaa!"
    p "Gotta go check on Jessica, man."
    uk "Aight."
    scene black with dissolve
    scene ima143 with dissolve
    p "Vanessa, have you seen Jessica?"
    va "She went upstairs, cutie."
    p "Is it ok if I go there?"
    va "I don't think she'd mind..."
    scene black with dissolve
    scene ima107 with dissolve
    pt "Let's go find her..."
    scene ima110 with dissolve
    pause 1
    jump jessroom

if choice45a:
    scene ima72 with dissolve
    pt "Hey! That's Ann's friend...what was her name?...Uhm...Nicole!"
    scene ima73 with dissolve
    p "Nicole?"
    scene ima74 with dissolve
    ni "Oh, hi, there! I was just telling Valentina your face looked familiar..."
    p "Yeah, we met at Master Collins's event, remember?"
    ni "Yes, yes! You were with Ann..."
    p "Yup, [p]'s my name, in case you forgot..."
    ni "Oh, yeah, yeah, I remember!"
    scene ima75 with dissolve
    ni "Uhm, [p], sorry to ask, but why are you dressed like that?"
    p "Like what? Hehehe...it's better if you ask Jessica."
    ni "Okaaayyy, will do...in fact, I'm going to ask her right now."
    scene ima76 with dissolve
    ni "Wasn't she right there a minute ago?...I'll go find her."
    scene black with dissolve
    scene ima77 with dissolve
    play music "audio/russian1.mp3" volume 0.8
    p "Hey..."
    scene ima78 with dissolve
    pause 1
    scene ima79 with dissolve
    pause

if choice47a:

    scene ima81 with dissolve
    val "Quick question: why you asked for my number if you were never gonna call?"
    p "Errr, you're right, you got me there...no excuses, I'm sorry."
    val "I remember Shorty said you had a girlfriend, I hope that was not the reason why you didn't call..."
    p "Maybe...I don't know really, I've been pretty busy, you know: college, training, I have a lot of things going on...I'm very sorry."
    scene ima80 with dissolve
    val "Don't be..."
    jump valwine

label valwine:
    scene ima80 with dissolve
    p "Mmm..."
    val "I saw how much you cared for Shorty when she got her feet burned, you were so protective, like her older brother...I liked it a lot..."
    p "Oh, you saw that? Hehe, I was just being helpful, Ann's a good friend..."
    scene ima82 with dissolve
    p "Uhm, do you wanna go grab another drink, Valentina?"
    val "Lead the way."
    stop music fadeout 3.0
    scene black with dissolve
    scene ima83 with dissolve
    pt "Dude didn't get lucky...I have nothing to say to him anyways, I'll just walk past..."

    call screen jessparty5

    screen jessparty5():
        add "ima83a"
        modal True

        imagebutton auto "arrow6_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Arrow6")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("beers")

label beers:
    scene ima89 with dissolve
    val "Grab those beers, I hope they're still cold...here, leave it there, please."
    p "No problem."

    call screen jessparty6

    screen jessparty6():
        add "ima89"
        modal True

        imagebutton auto "wineglass_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "glass")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("glass")

label glass:
    scene ima91 with dissolve

    call screen jessparty7

    screen jessparty7():
        add "ima91"
        modal True

        imagebutton auto "twobeers_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "twobeers")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("twobeers")

label twobeers:

    scene ima90 with dissolve
    p "You wanna sit here?"
    val "Naw, those chairs are too low for me...let's get inside, follow me."
    play music "audio/happyface.ogg"
    scene ima92 with dissolve
    p "I'm right behind you."
    scene ima93 with dissolve
    val "Beer."
    p "Oh, yeah, sorry."
    scene ima94 with dissolve
    p "Here."
    val "Thanks."
    scene ima95 with dissolve
    val "What'd you get her?"
    p "Oh, this? A perfume."
    scene ima96 with dissolve
    val "Haven't you heard that gifting someone a perfume will break the relation?"
    p "What?! Nooope, I have not...why would it bre...wait...are you messing with me?"
    scene ima97 with dissolve
    val "Is that why you're wearing that? Someone messed with you?"
    p "Oh, yeah, she got me good..."
    val "Who did? Jessica?"
    p "Yup."
    scene ima98 with dissolve
    val "So that's why you're gifting her a perfume."
    p "Haha, nooo, where'd you get that from? Are you superstitious?"
    val "I'm not, I just watched a video somewhere..."
    scene ima99 with dissolve
    val "And how so you didn't leave? I would've gotten so angry...she tried to ridicule you, but didn't count on you having the personality to stay..."
    val "It's like you said: Fuck her, fuck everybody, I don't care what these people think about me..."
    scene ima99a with dissolve
    p "Oh, no, haha, it wasn't like that, I got upset and was about to leave, but Ann showed up wearing a spacesuit, too, so...she made it less uncomfortable..."
    scene ima100 with dissolve
    val "Are you and Shorty more than friends?"
    scene ima101 with dissolve
    p "Oh, no, not at all. We're good friends...I think, that's all."
    scene ima102 with dissolve
    val "More people are coming..."
    p "Not a people's person?"
    scene ima103 with dissolve
    val "It's not like that, I just had a crowded event earlier and was hoping to get home and relax, but Nicole called me and here I am..."
    scene ima104 with dissolve
    val "Buuut! I don't regret it now..."
    pt "She likes you, bro..."

menu:
    "Make a move.":
        jump choice62a

    "S.":
        jump choice62b

label choice62b:

    $ choice62b = True

    p "Uuuh, give me a minute, Valentina, I'm going to give this to Jessica...be right back."
    scene ima96 with dissolve
    val "Oh..."
    scene ima95 with dissolve
    val "Okay."
    pt "I'm really stupid...but I'm not hurting anybody tonight."
    stop music fadeout 3.0
    scene black with dissolve
    scene ima107 with dissolve
    pt "Mmm, I guess she's in her room, but I can't go up there all by myself, this's not my house."
    scene ima108 with dissolve
    pt "Oh, Nicole's coming down..."
    scene ima109 with dissolve
    ni "[p], I'm sorry, that prank was in very poor taste...Jessica sometimes thinks she's still twelve."
    p "Yeah, but it's ok now, no big deal."
    ni "I'm glad you take it that way, but don't be too soft on her, she needs to understand it was not ok. She's in the second room to your left."
    p "Thanks, Nicole."
    scene ima110 with dissolve
    p "Second door..."

label jessroom:
    play music "audio/jazzinstrumental.ogg"
    scene ima111 with dissolve
    p "Hey!"
    scene ima112 with dissolve
    js "C'mere, I want to talk to you..."
    an "I'll be downstairs."
    scene ima113 with dissolve
    js "Please, forgive me, [p], I'm so so..."
    p "Waiiiiiiittt! I've been carrying this for a while now, here, I hope you like it."
    scene ima114 with dissolve
    js "What..."
    scene ima115 with dissolve
    js "Oh my God, [p]!"
    scene ima116 with dissolve
    js "I'm so sorry, I don't know what I was thinking to do that to YOU!"
    p "It's ok, I know you're sorry and I'm not angry anymore, there's nothing to talk about...in fact, the more you mention it the angrier I get..."
    p "Let's move on already!"
    scene ima117 with dissolve
    p "Come on, open it!"
    scene ima118 with dissolve
    js "Hey! How did you know?!"
    scene ima119 with dissolve
    js "This's my favorite!"
    p "Haha, you're bullshitting me...again..."
    scene ima120 with dissolve
    pause 1
    p "Too soon?"
    js "Yeah...and I'm not..."
    scene ima121 with dissolve
    js "Look over there."
    scene ima122 with dissolve
    p "Is it the same?"
    js "Yeah, it is...I can't thank you enough really! Give me another hug!"
    scene ima117 with dissolve
    pause 1
    scene ima123 with dissolve
    js "How about a dance now?"
    p "Let's drink first, haha."
    js "Deal!"
    stop music fadeout 2.0
    scene black with Dissolve(1.0)
    scene ima124 with dissolve
    js "Nobody's here..."
    p "I can see your friend Vanessa."
    js "Let's go!"
    scene black with dissolve
    play music "audio/footballwhistle.ogg" volume 0.8
    scene ima125a:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.4
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.4
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.4
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.1
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.4
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.1
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.08
        "ima125"
        pause 0.1
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.03
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.1
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.08
        "ima125"
        pause 0.1
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.03
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.03
        "ima125"
        pause 0.05
        "ima125a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.03
        "ima125"
        pause 0.05
    pause
    an "Hey, guys! What took you so long? I was showing off my suit to everybody..."
    js "Annie, don't drink too much..."
    p "Why not? It's a party!"
    js "She's a lightweight...a reeeeeeal lightweight, look at her eyes already!"
    p "And that's only beer...she's not a lightweight, she's a flyweight!"
    js "Haha."
    an "What are you guys mumbling? C'mere!"
    scene ima126 with dissolve
    an "Sorry, [p], you're gonna have to get your own beer."
    p "That's ok, I'll get one in a minute...I'm having another issue right now..."
    an "What is it?"
    p "Uhm...not sure I should tell you..."
    an "Come on, you know you can tell me anything."
    p "Errr...ok, I'll tell ya, but keep it to yourself...I'm having a boner..."
    scene ima127 with dissolve
    an "Hahaha, what?! What did you see?"
    p "Nothing, this things just happen, you know...and this suit's so tight...just give me a minute."
    an "So your erections last one minute?"
    scene ima128 with dissolve
    p "What?! That's a low blow!"
    scene ima129 with dissolve
    an "Low blow! Hahaha..."
    scene ima130 with dissolve
    pt "That's not even dirty..."
    scene ima131 with dissolve
    p "Yeah, I guess it is funny..."
    p "It's like the other day I was with my..."
    scene ima132 with dissolve
    pause 0.5
    scene ima133 with dissolve
    p "What the..."
    scene ima134 with dissolve
    p "Hey...you dead?"
    scene ima135 with dissolve
    js "[p]! I told you to look after her, she got sloshed!"
    p "First of all, I don't remember you telling me to keep an eye on her drinking...and second, I just looked away for a mi..."
    js "It was obvious you had to..."
    scene ima136 with dissolve
    js "Anyway, can you please take her to the guest room? It's the one next to mine."
    p "Ok, boss, I'm on it, only because it's your birthday..."
    stop music fadeout 3.0
    scene black with dissolve
    scene ima137 with dissolve
    pt "How the hell did I end up babysitting?"
    va "Hey!"
    scene ima138 with dissolve
    va "You look bored...if you wanna have fun, get rid of her...I'll be here...just saying."
    pt "Just like that?"
    an "Come again, [p]?"
    p "I didn't say anything, Annie."
    scene black with dissolve
    scene ima139 with dissolve
    p "Try to rest, ok?"
    an "Don't go."
    p "Uh? What do you want me to do?"
    an "Lie down with me...tell me a story till I fall asleep."
    p "Haha, what? Aren't you a little old for tales?"
    an "Pleeeeaasee..."

menu:
    "She deserves it.":
        jump choice63a

    "There's an ass waiting downstairs.":
        jump choice63b

label choice63a:

    $ choice63a = True

    pt "After what she did for me today, I simply can't leave her..."
    p "Okay, Annie, you win."
    scene black with dissolve
    scene ima140 with dissolve
    p "Once upon a time, there was this soldier named Ann..."
    p "Shepard!"
    p "Ann Shepard was her name..."
    p "She was short, very short..."
    scene black with Dissolve(2.0)
    play music "audio/loft.ogg"
    scene ima140a with dissolve
    pause 2
    scene ima140b with dissolve
    an "[p]?"
    p "Hmm?"
    scene ima140c with dissolve
    an "Did you stay the whole night with me?"
    p "Uh-hum..."
    an "You should've gone back downstairs."
    p "Mmm, I had no business downstairs...besides, you didn't want me to leave you alone."
    scene ima140d with dissolve
    an "I don't remember that."
    p "Well, you asked and I stayed with you."
    scene ima140e with dissolve
    an "I know! Give me a hug...you're the best, [p]."
    p "Nope, you are."
    an "I'm hungry, let's have breakfast."
    p "Give me five more minutes..."
    stop music fadeout 3.0
    jump choice62common

label choice63b:

    $ choice63b = True

    p "Be right back, Annie, gotta go to the bathroom."
    an "Don't take long..."
    scene black with dissolve
    scene ima141 with dissolve
    va "I knew you'd come..."
    scene ima142 with dissolve
    va "Come on, let's go to my place, it's just around the corner..."
    p "Let's go."
    scene black with Dissolve(1.5)

label vanesex1:

    if _in_replay:
        $ pf = persistent.p

    play music "audio/exercisechris.ogg" volume 0.8
    scene ima270 with dissolve
    va "Nobody will bother us here, come!"
    scene ima271 with dissolve
    pause
    scene ima272 with dissolve
    pause
    scene ima273 with dissolve
    p "Oooooffff..."
    va "Mmmpphh..."
    scene ima274 with dissolve
    va "I can't take it anymore..."
    p "It's not even in yet."
    va "Shut up and get naked!"
    scene ima275 with dissolve
    va "My pussy's waiting..."
    scene ima276 with dissolve
    p "This's a fine ass..."
    scene ima277 with dissolve
    va "Why are you taking so long? Put it in!"
    p "Hungry, huh? I like taking my time...come on, I want to see those tits first..."
    va "Fine!"

    scene ima278:
        ypos -2.0
        ease 6 ypos 0.0
        ease 6 ypos -2.0
        ease 6 ypos 0.0
    pause

    va "And? What do you think?"
    p "You got great curves, not gonna lie...come..."
    scene ima279 with dissolve
    p "I like what I see..."
    va "Shut up already and show me what your small dick can do."
    p "Small, huh?"
    scene ima289 with hpunch
    va "Aaahhh!"
    p "What's wrong? That's not even half of it..."

    scene ima279:
        pause 0.0233
        "ima280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0233
        "ima281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0233
        "ima282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0233
        "ima283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0233
        "ima284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0233
        "ima285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0233
        "ima286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0233
        "ima287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0233
        "ima288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0233
        "ima289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0233
        "ima290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0233
        "ima291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0233
        "ima292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0233
        "ima293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0233
        "ima294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0233
        "ima295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0233
        "ima296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0233
        "ima297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0233
        "ima298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0233
        "ima299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0233
        "ima300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0233
        "ima301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0233
        "ima302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0233
        "ima303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0233
        "ima304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0233
        "ima305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0233
        "ima306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0233
        "ima307"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0233
        "ima308"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0233
        "ima279"
        pause 0.0233
        repeat
    play sound "audio/sex6.mp3"
    pause

    scene ima279:
        pause 0.0133
        "ima280"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima281"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima282"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima283"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima284"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima285"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima286"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima287"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima288"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima289"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima290"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima294"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "ima295"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima296"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima297"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima298"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima299"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima300"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima301"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima302"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima303"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima304"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima305"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima306"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima307"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima308"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima279"
        pause 0.0133
        repeat
    play sound "audio/sex2.mp3"
    pause
    stop music fadeout 3.0
    stop sound fadeout 2.0
    scene ima308a with dissolve
    va "Wait, don't come just yet, baby..."
    p "I wasn't gonna come."
    va "Let's switch, I want to feel it all..."
    scene black with dissolve
    play music "audio/bigmoney.ogg" volume 0.7
    scene ima310 with dissolve
    va "Ooohh, fuck, it's so hot in here..."
    p "Yeah, I love your sweaty body, it's so sexy..."
    scene ima309 with dissolve
    va "Yes, touch me, baby, make me yours!"
    p "No need to tell me...why you're not moving?"

    scene ima311:
        pause 0.0133
        "ima312"
        pause 0.0133
        "ima313"
        pause 0.0133
        "ima314"
        pause 0.0133
        "ima315"
        pause 0.0133
        "ima316"
        pause 0.0133
        "ima317"
        pause 0.0133
        "ima318"
        pause 0.0133
        "ima319"
        pause 0.0133
        "ima320"
        pause 0.0133
        "ima321"
        pause 0.0133
        "ima322"
        pause 0.0133
        "ima323"
        pause 0.0133
        "ima324"
        pause 0.0133
        "ima325"
        pause 0.0133
        "ima326"
        pause 0.0133
        "ima327"
        pause 0.0133
        "ima328"
        pause 0.0133
        "ima329"
        pause 0.0133
        "ima330"
        pause 0.0133
        "ima331"
        pause 0.0133
        "ima332"
        pause 0.0133
        "ima333"
        pause 0.0133
        "ima334"
        pause 0.0133
        "ima335"
        pause 0.0133
        "ima336"
        pause 0.0133
        "ima337"
        pause 0.0133
        "ima338"
        pause 0.0133
        "ima339"
        pause 0.0133
        "ima340"
        pause 0.0133
        "ima341"
        pause 0.0133
        "ima342"
        pause 0.0133
        "ima311"
        pause 0.0133
        repeat
    pause

    va "You want it like this?"
    p "Oh, yeah, that's perfect..."

    scene ima311:
        pause 0.0133
        "ima312a"
        pause 0.0133
        "ima313a"
        pause 0.0133
        "ima314a"
        pause 0.0133
        "ima315a"
        pause 0.0133
        "ima316a"
        pause 0.0133
        "ima317a"
        pause 0.0133
        "ima318a"
        pause 0.0133
        "ima319a"
        pause 0.0133
        "ima320a"
        pause 0.0133
        "ima321a"
        pause 0.0133
        "ima322a"
        pause 0.0133
        "ima323a"
        pause 0.0133
        "ima324a"
        pause 0.0133
        "ima325a"
        pause 0.0133
        "ima326a"
        pause 0.0133
        "ima327a"
        pause 0.0133
        "ima328a"
        pause 0.0133
        "ima329a"
        pause 0.0133
        "ima330a"
        pause 0.0133
        "ima331a"
        pause 0.0133
        "ima332a"
        pause 0.0133
        "ima333a"
        pause 0.0133
        "ima334a"
        pause 0.0133
        "ima335a"
        pause 0.0133
        "ima336a"
        pause 0.0133
        "ima337a"
        pause 0.0133
        "ima338a"
        pause 0.0133
        "ima339a"
        pause 0.0133
        "ima340a"
        pause 0.0133
        "ima341a"
        pause 0.0133
        "ima342a"
        pause 0.0133
        "ima311"
        pause 0.0133
        repeat
    pause

    scene ima311:
        pause 0.0133
        "ima312b"
        pause 0.0133
        "ima313b"
        pause 0.0133
        "ima314b"
        pause 0.0133
        "ima315b"
        pause 0.0133
        "ima316b"
        pause 0.0133
        "ima317b"
        pause 0.0133
        "ima318b"
        pause 0.0133
        "ima319b"
        pause 0.0133
        "ima320b"
        pause 0.0133
        "ima321b"
        pause 0.0133
        "ima322b"
        pause 0.0133
        "ima323b"
        pause 0.0133
        "ima324b"
        pause 0.0133
        "ima325b"
        pause 0.0133
        "ima326b"
        pause 0.0133
        "ima327b"
        pause 0.0133
        "ima328b"
        pause 0.0133
        "ima329b"
        pause 0.0133
        "ima330b"
        pause 0.0133
        "ima331b"
        pause 0.0133
        "ima332b"
        pause 0.0133
        "ima333b"
        pause 0.0133
        "ima334b"
        pause 0.0133
        "ima335b"
        pause 0.0133
        "ima336b"
        pause 0.0133
        "ima337b"
        pause 0.0133
        "ima338b"
        pause 0.0133
        "ima339b"
        pause 0.0133
        "ima340b"
        pause 0.0133
        "ima341b"
        pause 0.0133
        "ima342b"
        pause 0.0133
        "ima311"
        pause 0.0133
        repeat
    pause

    scene ima311:
        pause 0.0133
        "ima312c"
        pause 0.0133
        "ima313c"
        pause 0.0133
        "ima314c"
        pause 0.0133
        "ima315c"
        pause 0.0133
        "ima316c"
        pause 0.0133
        "ima317c"
        pause 0.0133
        "ima318c"
        pause 0.0133
        "ima319c"
        pause 0.0133
        "ima320c"
        pause 0.0133
        "ima321c"
        pause 0.0133
        "ima322c"
        pause 0.0133
        "ima323c"
        pause 0.0133
        "ima324c"
        pause 0.0133
        "ima325c"
        pause 0.0133
        "ima326c"
        pause 0.0133
        "ima327c"
        pause 0.0133
        "ima328c"
        pause 0.0133
        "ima329c"
        pause 0.0133
        "ima330c"
        pause 0.0133
        "ima331c"
        pause 0.0133
        "ima332c"
        pause 0.0133
        "ima333c"
        pause 0.0133
        "ima334c"
        pause 0.0133
        "ima335c"
        pause 0.0133
        "ima336c"
        pause 0.0133
        "ima337c"
        pause 0.0133
        "ima338c"
        pause 0.0133
        "ima339c"
        pause 0.0133
        "ima340c"
        pause 0.0133
        "ima341c"
        pause 0.0133
        "ima342c"
        pause 0.0133
        "ima311"
        pause 0.0133
        repeat
    play sound "audio/sex9.mp3"
    pause

    scene ima311:
        pause 0.0133
        "ima312c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima313c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima314c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima315c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima316c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima317c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima318c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima319c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima320c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima321c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima322c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima323c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima324c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima325c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima326c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima327c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima328c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima329c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "ima330c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "ima331c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "ima332c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "ima333c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0133
        "ima334c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "ima335c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "ima336c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "ima337c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "ima338c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "ima339c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "ima340c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "ima341c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "ima342c"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "ima311"
        pause 0.0133
        repeat
    play sound "audio/sex9.mp3"
    pause

    p "Fuck, I'm close..."
    va "Careful...don't come inside, I don't want your child..."
    p "No? I thought you did."
    va "Nope, never."

menu:
    "Come inside anyways.":
        jump choice76a

    "Face.":
        jump choice76b

label choice76a:

    $ choice76a = True

    stop music fadeout 3.0
    scene ima343 with vpunch
    play sound "audio/maleorg1.ogg"
    scene ima343 with vpunch
    scene ima343 with vpunch
    va "What?"
    p "So good..."
    va "Dude, what the shit?!"
    scene ima344 with dissolve
    va "What were you thinking?! You're gonna get me pregnant!"
    p "I'm sorry, I couldn't help it...you're just too sexy..."
    va "Sorry? Really?"
    scene ima345 with dissolve
    va "You're an asshole, get the hell out of my house!"
    p "..."
    va "Out I said!"
    p "Ok, ok, I'm leaving...sorry..."
    jump choice62common

label choice76b:

    $ choice76b = True

    stop music fadeout 3.0
    scene ima346 with dissolve
    va "Give it to me, baby, I want to taste it..."
    scene ima347 with vpunch
    play sound "audio/maleorg1.ogg"
    scene ima347 with flash
    scene ima347 with flash
    scene ima347 with vpunch
    va "Ooohhh, there it is!"
    scene ima348 with dissolve
    p "So good! Don't ask me to give you a kiss, eh..."
    va "Haha...kiss me! Haha."
    jump choice62common

label choice62a:

    $ choice62a = True

label valesex1:

    if _in_replay:
        $ pf = persistent.p

    p "Uhm, Valentina, do you want to get out of here?"
    scene ima105 with dissolve
    val "Cheers to that! Of course I do...let's go!"
    scene ima106 with dissolve
    pause 1
    stop music fadeout 3.0
    scene black with Dissolve(1.5)

    scene ima144 with dissolve
    val "Nice hotel you..."
    p "Come here!"
    scene ima145 with dissolve
    val "Hey, there..."
    val "Did you know your outfit turns me on?"
    p "You mean I turn you on."
    val "Perhaps...so you like tall girls, huh?"
    p "No, I like you."
    scene ima146 with dissolve
    val "That crap doesn't work with me, you know..."
    p "What does?"
    val "This."
    scene ima148 with dissolve
    pause 1
    scene ima146 with dissolve
    val "And?"
    p "Shit, it works."
    scene ima149 with dissolve
    pause 1
    scene ima147 with dissolve
    p "I can lick you too...lose this dress, I want to see what you're hiding..."
    scene ima147b with dissolve
    scene ima147c with dissolve
    scene ima147d with dissolve
    val "Me too, take this off."
    scene black with dissolve
    play music "audio/sensual1.ogg"
    scene ima150 with dissolve
    p "Leave the shoes on..."
    scene ima151 with dissolve
    val "Why's that? Your fetish?"
    p "Don't know yet, but I like how they look on you..."
    val "Haha, fine!"
    scene ima152 with dissolve
    val "Do you need an invitation?"
    p "Easy, I'm just enjoying the view."
    scene ima153 with dissolve
    pause
    p "Okay! I'm gonna eat that now!"
    scene ima154 with dissolve
    val "Blah, blah, blah...still waiting..."
    scene ima155 with dissolve
    val "Ngh!"
    scene ima157 with dissolve
    val "Yeah, like that..."
    scene ima158 with dissolve
    val "Ah!"
    scene ima159 with vpunch
    val "Aaahhh!"
    scene ima160 with dissolve
    val "Ssss..."
    p "You're so tasty..."
    scene ima161 with dissolve
    val "Ooohh."
    p "Lie down."
    scene ima162 with dissolve
    p "Delicious..."
    scene ima163 with dissolve
    val "You're gonna taste it?"
    p "I'm done with that...what I want to do is..."
    scene ima164 with hpunch
    p "This!"
    val "Aaahh!"
    scene ima165 with dissolve

    scene ima165:
        pause 0.0233
        "ima166"
        pause 0.0233
        "ima167"
        pause 0.0233
        "ima168"
        pause 0.0233
        "ima169"
        pause 0.0233
        "ima170"
        pause 0.0233
        "ima171"
        pause 0.0233
        "ima172"
        pause 0.0233
        "ima173"
        pause 0.0233
        "ima174"
        pause 0.0233
        "ima175"
        pause 0.0233
        "ima176"
        pause 0.0233
        "ima177"
        pause 0.0233
        "ima178"
        pause 0.0233
        "ima179"
        pause 0.0233
        "ima180"
        pause 0.0233
        "ima181"
        pause 0.0233
        "ima182"
        pause 0.0233
        "ima183"
        pause 0.0233
        "ima184"
        pause 0.0233
        "ima185"
        pause 0.0233
        "ima186"
        pause 0.0233
        "ima187"
        pause 0.0233
        "ima188"
        pause 0.0233
        "ima189"
        pause 0.0233
        "ima190"
        pause 0.0233
        "ima191"
        pause 0.0233
        "ima192"
        pause 0.0233
        "ima193"
        pause 0.0233
        "ima194"
        pause 0.0233
        "ima165"
        pause 0.0233
        repeat
    pause

    scene ima165:
        pause 0.0166
        "ima166"
        pause 0.0166
        "ima167"
        pause 0.0166
        "ima168"
        pause 0.0166
        "ima169"
        pause 0.0166
        "ima170"
        pause 0.0166
        "ima171"
        pause 0.0166
        "ima172"
        pause 0.0166
        "ima173"
        pause 0.0166
        "ima174"
        pause 0.0166
        "ima175"
        pause 0.0166
        "ima176"
        pause 0.0166
        "ima177"
        pause 0.0166
        "ima178"
        pause 0.0166
        "ima179"
        pause 0.0166
        "ima180"
        pause 0.0166
        "ima181"
        pause 0.0166
        "ima182"
        pause 0.0166
        "ima183"
        pause 0.0166
        "ima184"
        pause 0.0166
        "ima185"
        pause 0.0166
        "ima186"
        pause 0.0166
        "ima187"
        pause 0.0166
        "ima188"
        pause 0.0166
        "ima189"
        pause 0.0166
        "ima190"
        pause 0.0166
        "ima191"
        pause 0.0166
        "ima192"
        pause 0.0166
        "ima193"
        pause 0.0166
        "ima194"
        pause 0.0166
        "ima165"
        pause 0.0166
        repeat
    pause

    scene ima165:
        pause 0.0133
        "ima166"
        pause 0.0133
        "ima167"
        pause 0.0133
        "ima168"
        pause 0.0133
        "ima169"
        pause 0.0133
        "ima170"
        pause 0.0133
        "ima171"
        pause 0.0133
        "ima172"
        pause 0.0133
        "ima173"
        pause 0.0133
        "ima174"
        pause 0.0133
        "ima175"
        pause 0.0133
        "ima176"
        pause 0.0133
        "ima177"
        pause 0.0133
        "ima178"
        pause 0.0133
        "ima179"
        pause 0.0133
        "ima180"
        pause 0.0133
        "ima181"
        pause 0.0133
        "ima182"
        pause 0.0133
        "ima183"
        pause 0.0133
        "ima184"
        pause 0.0133
        "ima185"
        pause 0.0133
        "ima186"
        pause 0.0133
        "ima187"
        pause 0.0133
        "ima188"
        pause 0.0133
        "ima189"
        pause 0.0133
        "ima190"
        pause 0.0133
        "ima191"
        pause 0.0133
        "ima192"
        pause 0.0133
        "ima193"
        pause 0.0133
        "ima194"
        pause 0.0133
        "ima165"
        pause 0.0133
        repeat
    pause

label valclosefastest:

    scene ima165a with dissolve:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6

    scene ima165a:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "ima166a"
        pause 0.0133
        "ima167a"
        pause 0.0133
        "ima168a"
        pause 0.0133
        "ima169a"
        pause 0.0133
        "ima170a"
        pause 0.0133
        "ima171a"
        pause 0.0133
        "ima172a"
        pause 0.0133
        "ima173a"
        pause 0.0133
        "ima174a"
        pause 0.0133
        "ima175a"
        pause 0.0133
        "ima176a"
        pause 0.0133
        "ima177a"
        pause 0.0133
        "ima178a"
        pause 0.0133
        "ima179a"
        pause 0.0133
        "ima180a"
        pause 0.0133
        "ima181a"
        pause 0.0133
        "ima182a"
        pause 0.0133
        "ima183a"
        pause 0.0133
        "ima184a"
        pause 0.0133
        "ima185a"
        pause 0.0133
        "ima186a"
        pause 0.0133
        "ima187a"
        pause 0.0133
        "ima188a"
        pause 0.0133
        "ima189a"
        pause 0.0133
        "ima190a"
        pause 0.0133
        "ima191a"
        pause 0.0133
        "ima192a"
        pause 0.0133
        "ima193a"
        pause 0.0133
        "ima194a"
        pause 0.0133
        "ima165a"
        pause 0.0133
        repeat
    pause

menu:
    "Slower.":
        jump valcloseslow

    "Continue.":
        jump valdog

label valcloseslow:

    scene ima165a:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0266
        "ima166a"
        pause 0.0266
        "ima167a"
        pause 0.0266
        "ima168a"
        pause 0.0266
        "ima169a"
        pause 0.0266
        "ima170a"
        pause 0.0266
        "ima171a"
        pause 0.0266
        "ima172a"
        pause 0.0266
        "ima173a"
        pause 0.0266
        "ima174a"
        pause 0.0266
        "ima175a"
        pause 0.0266
        "ima176a"
        pause 0.0266
        "ima177a"
        pause 0.0266
        "ima178a"
        pause 0.0266
        "ima179a"
        pause 0.0266
        "ima180a"
        pause 0.0266
        "ima181a"
        pause 0.0266
        "ima182a"
        pause 0.0266
        "ima183a"
        pause 0.0266
        "ima184a"
        pause 0.0266
        "ima185a"
        pause 0.0266
        "ima186a"
        pause 0.0266
        "ima187a"
        pause 0.0266
        "ima188a"
        pause 0.0266
        "ima189a"
        pause 0.0266
        "ima190a"
        pause 0.0266
        "ima191a"
        pause 0.0266
        "ima192a"
        pause 0.0266
        "ima193a"
        pause 0.0266
        "ima194a"
        pause 0.0266
        "ima165a"
        pause 0.0266
        repeat
    pause

menu:
    "Faster.":
        jump valclosefastest1

    "Continue.":
        jump valdog

label valclosefastest1:
    scene ima165a:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "ima166a"
        pause 0.0133
        "ima167a"
        pause 0.0133
        "ima168a"
        pause 0.0133
        "ima169a"
        pause 0.0133
        "ima170a"
        pause 0.0133
        "ima171a"
        pause 0.0133
        "ima172a"
        pause 0.0133
        "ima173a"
        pause 0.0133
        "ima174a"
        pause 0.0133
        "ima175a"
        pause 0.0133
        "ima176a"
        pause 0.0133
        "ima177a"
        pause 0.0133
        "ima178a"
        pause 0.0133
        "ima179a"
        pause 0.0133
        "ima180a"
        pause 0.0133
        "ima181a"
        pause 0.0133
        "ima182a"
        pause 0.0133
        "ima183a"
        pause 0.0133
        "ima184a"
        pause 0.0133
        "ima185a"
        pause 0.0133
        "ima186a"
        pause 0.0133
        "ima187a"
        pause 0.0133
        "ima188a"
        pause 0.0133
        "ima189a"
        pause 0.0133
        "ima190a"
        pause 0.0133
        "ima191a"
        pause 0.0133
        "ima192a"
        pause 0.0133
        "ima193a"
        pause 0.0133
        "ima194a"
        pause 0.0133
        "ima165a"
        pause 0.0133
        repeat
    pause

menu:
    "Slower.":
        jump valcloseslow

    "Continue.":
        jump valdog

label valdog:

    scene ima210 with hpunch
    val "Nghh, yes, faster!"
    scene ima195 with dissolve

    scene ima195:
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111
        repeat
    play sound "audio/sex8.mp3"
    pause

    p "Shit, you're amazing...can I come inside?"
    play sound "audio/sex8.mp3"
    val "Ngh, ngh, ngh..."

    scene ima195:
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0084
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0084
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0084
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0084
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0084
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0084
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0084
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0084
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0084
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0084
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0084
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0084
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0084
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0084
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0084
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0084
        "ima195"
        pause 0.0084

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111

        "ima195"
        pause 0.0111
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0111
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0111
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0111
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0111
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0111
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0111
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0111
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0111
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0111
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0111
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0111
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0111
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0111
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0111
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0111
        "ima195"
        pause 0.0111
        repeat
    play sound "audio/sex8.mp3"
    p "I'll take that as a yes..."

    scene ima195:
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

        "ima195"
        pause 0.0076
        "ima196"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima197"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima198"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima199"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima200"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima201"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima202"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima203"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima204"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima205"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima206"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima207"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima208"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima209"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima210"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0076
        "ima211"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0076
        "ima212"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0076
        "ima213"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0076
        "ima214"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0076
        "ima215"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0076
        "ima216"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0076
        "ima217"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0076
        "ima218"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0076
        "ima219"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0076
        "ima220"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0076
        "ima221"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0076
        "ima222"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0076
        "ima223"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0076
        "ima224"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0076
        "ima195"
        pause 0.0076

    pause 2
    play sound "audio/femorg1.ogg"

    scene ima225 with vpunch
    scene ima225 with vpunch
    scene ima225 with vpunch
    scene ima225 with flash
    scene ima225 with flash
    scene ima225 with vpunch
    scene ima225 with vpunch
    scene ima225 with vpunch
    scene ima225 with flash
    scene ima225 with flash
    scene ima225 with vpunch
    scene ima225 with vpunch
    scene ima225 with vpunch
    stop music fadeout 3.0
    pause
    stop sound fadeout 2.0
    scene black with Dissolve(1.5)
    scene ima226 with dissolve
    val "That was amazing..."
    p "It was, yeah...uhm, you're on the pill, right?"
    val "Ha, and now is when you ask?"
    p "Well, I don't think when I'm in the middle of..."
    val "I am...c'mere, we're not done yet..."
    scene black with dissolve
    scene ima227 with dissolve
    p "What are you trying to do?"
    val "I don't know, just trying new things, haha."
    p "Watch the heels, you're gonna take my eye out."
    val "You wanted me to wear them so now deal with it...hold my hand."
    p "I don't want to make any effort...you ride me!"
    scene ima227a with dissolve
    val "Oh, I'm gonna ride you hard, you lazy ass!"
    p "Blah, blah, blah...still waiting..."
    val "Oh, yeah?"

    play music "audio/garage.ogg" volume 0.8
    scene ima228:
        pause 0.0166
        "ima229"
        pause 0.0166
        "ima230"
        pause 0.0166
        "ima231"
        pause 0.0166
        "ima232"
        pause 0.0166
        "ima233"
        pause 0.0166
        "ima234"
        pause 0.0166
        "ima235"
        pause 0.0166
        "ima236"
        pause 0.0166
        "ima237"
        pause 0.0166
        "ima238"
        pause 0.0166
        "ima239"
        pause 0.0166
        "ima240"
        pause 0.0166
        "ima241"
        pause 0.0166
        "ima242"
        pause 0.0166
        "ima243"
        pause 0.0166
        "ima244"
        pause 0.0166
        "ima245"
        pause 0.0166
        "ima246"
        pause 0.0166
        "ima247"
        pause 0.0166
        "ima248"
        pause 0.0166
        "ima249"
        pause 0.0166
        "ima250"
        pause 0.0166
        "ima251"
        pause 0.0166
        "ima252"
        pause 0.0166
        "ima253"
        pause 0.0166
        "ima254"
        pause 0.0166
        "ima255"
        pause 0.0166
        "ima256"
        pause 0.0166
        "ima257"
        pause 0.0166
        "ima258"
        pause 0.0166
        "ima259"
        pause 0.0166
        "ima260"
        pause 0.0166
        "ima261"
        pause 0.0166
        "ima262"
        pause 0.0166
        "ima263"
        pause 0.0166
        "ima264"
        pause 0.0166
        "ima265"
        pause 0.0166
        "ima228"
        pause 0.0166
        repeat
    val "You won't last a minute you'll see!"
    pause

    p "Shit! I can't resist your wet pussy!"
    val "Oh, my god, you're hitting the spot!"

    scene ima228:
        pause 0.0111
        "ima229"
        pause 0.0111
        "ima230"
        pause 0.0111
        "ima231"
        pause 0.0111
        "ima232"
        pause 0.0111
        "ima233"
        pause 0.0111
        "ima234"
        pause 0.0111
        "ima235"
        pause 0.0111
        "ima236"
        pause 0.0111
        "ima237"
        pause 0.0111
        "ima238"
        pause 0.0111
        "ima239"
        pause 0.0111
        "ima240"
        pause 0.0111
        "ima241"
        pause 0.0111
        "ima242"
        pause 0.0111
        "ima243"
        pause 0.0111
        "ima244"
        pause 0.0111
        "ima245"
        pause 0.0111
        "ima246"
        pause 0.0111
        "ima247"
        pause 0.0111
        "ima248"
        pause 0.0111
        "ima249"
        pause 0.0111
        "ima250"
        pause 0.0111
        "ima251"
        pause 0.0111
        "ima252"
        pause 0.0111
        "ima253"
        pause 0.0111
        "ima254"
        pause 0.0111
        "ima255"
        pause 0.0111
        "ima256"
        pause 0.0111
        "ima257"
        pause 0.0111
        "ima258"
        pause 0.0111
        "ima259"
        pause 0.0111
        "ima260"
        pause 0.0111
        "ima261"
        pause 0.0111
        "ima262"
        pause 0.0111
        "ima263"
        pause 0.0111
        "ima264"
        pause 0.0111
        "ima265"
        pause 0.0111
        "ima228"
        pause 0.0111
        repeat
    val "I want you to come with me!"
    pause

    p "Holy shit!"

    scene ima266 with vpunch
    scene ima266 with vpunch
    scene ima266 with vpunch
    scene ima266 with flash
    scene ima266 with flash
    val "Aaahhh!!!"
    val "Amazing..."
    p "Fuck, that was incredible, Valentina!"
    scene ima267 with dissolve
    val "Told ya..."
    val "I'm exhausted...I'm falling asleep right here..."
    p "Come here...I want to feel you all sweaty..."
    stop music fadeout 3.0
    jump choice62common

label choice62common:

    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    pause

    play music "audio/bensweet.ogg" fadein 3.0
    scene ima358 with dissolve
    fzt "Tesia is her name..."
    fzt "She's twenty years old..."
    fzt "...from Hungary."
    fzt "That's pretty much all she shared with us the first week..."
    scene ima357 with dissolve
    fzt "Her English got better quickly..."
    fzt "She likes saying \"shin\" instead of \"shit\"...I guess that's her thing..."
    fzt "It's kind of funny when she says it..."
    scene ima359 with dissolve
    te "Hoooly shin!"
    fz "Haha."
    fzt "She loved my favorite sweatshirt, told her to keep it but she didn't want to, so I had one made for her..."
    scene ima360 with dissolve
    fzt "She wears it all the time now, day and night..."
    scene ima361 with dissolve
    fzt "George and I have never been more responsible..."
    fzt "We want to see her well, she's suffered enough..."
    scene ima362 with dissolve
    fzt "For sure things are not going to be easy, some days are gonna be better than others..."
    scene ima362a with dissolve
    fzt "We feel powerless sometimes..."
    fzt "We'd like to do more..."
    scene ima362b with dissolve
    fzt "We may not have all the answers..."
    fzt "We may not have the right words..."
    fzt "But kid, there's this one thing we can do for you..."
    scene ima362c with dissolve
    fzt "Be there."
    fzt "We won't let you go through this alone."
    stop music fadeout 3.0

    scene black with Dissolve(3.0)

if choice58a:

    scene ima513 with dissolve
    p "I can't believe that son of a bitch failed me! That makes no sense! I attended all his stupid classes, passed the mid-term and the final!"
    ri "You know what's like suuuuper weird? You're the only one who didn't pass!"
    p "I know! And to make matters worse, he quit! What a coward! I'm gonna talk to the Dean!"
    ri "Yeah, I'll go with you, he kind of respects me..."
    jump endcamille

if choice58b:

    scene ima513 with dissolve
    p "I can't believe that son of a bitch failed me! That makes no sense! I attended all his stupid classes, passed the mid-term and the final!"
    ri "You know what's like suuuuper weird? You're the only one who didn't pass!"
    p "I know! And to make matters worse, he quit! What a coward! I'm gonna talk to the Dean!"
    ri "Yeah, I'll go with you, he kind of respects me..."

    p "Thank you, Riv, I owe you one..."
    ri "Make it two."
    scene ima514 with dissolve
    ca "[p]!"
    scene ima515 with dissolve
    play music "audio/bendowntown.ogg" volume 0.8
    ca "Hi, guys...[p], can I talk to you?"
    p "Yeah, sure, Camille."
    scene ima516 with dissolve
    ri "I'll call you later."
    p "Okay."
    scene ima517 with dissolve
    ri "Bye, Camille."
    ca "Bye!"
    scene ima518 with dissolve
    ca "Billy just told me you're dropping out...is it true?"
    p "Billy told you that? How did he...well, that's not exactly accurate, you know. I'm just taking a break for a semester...uhmmm, do you know I play soccer?"
    ca "Not really, no."
    p "I'm gonna start training next month so...uhm...do you want to have lunch? I'll tell you all about it."
    scene ima519 with dissolve
    ca "Oooh, I'd love to, but can't right now, I have a meeting with HR..."
    scene ima520 with dissolve
    ca "But hey, we have to find you a proper way to say goodbye to St. Francis...why don't you come by the library tomorrow?"
    ca "I'll keep it between us..."

menu:
    "Us? There's no \"us\".":
        jump choice64a

    "Can't wait!":
        jump choice64b

label choice64a:

    $ choice64a = True

    stop music fadeout 3.0
    pt "\"Us\" was a one time thing, Cam."
    p "I can't, sorry, I'll be busy tomorrow..."
    scene ima521 with dissolve
    ca "Oh, well, you let me know when then."
    p "Yeah, sure."
    jump endcamille

label choice64b:

    $ choice64b = True

    stop music fadeout 3.0
    p "I think I know what you have in mind."
    ca "I'll show you a new trick..."
    scene black with Dissolve(2.5)

label camsex2:

    if _in_replay:
        $ pf = persistent.p

    play music "audio/camlibra.ogg"
    scene ima522 with Dissolve(2.0)
    pt "My{w=1.0} God..."
    pt "She's so sexy..."

    scene ima523:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    pt "Love those tits..."
    p "Excuse me, is this Sex Education 101?"
    scene ima524 with dissolve
    ca "Sexual Health Education, mister! Looks like you've got a lot to learn..."
    p "Oh, yes, please, Miss Garnier, teach me!"
    ca "Quiet!"
    ca "Today's lecture is..."
    ca "Impregnation!"
    scene ima524 with hpunch
    p "What?!"
    ca "You heard me, mister...don't just stand there, get close!"
    scene ima525 with dissolve
    ca "Hold it right there!"
    p "What's wrong, Miss Garnier?"
    ca "I've seen that look before...I don't like it!"
    scene ima526 with dissolve
    ca "So lustful...so disrespectful..."
    p "That's a false accusation!"
    ca "Oh, you're calling me a liar now."
    p "No, I'm not, but..."
    ca "Shh...tell me, mister, what is it you like so much about me?"
    scene ima527 with dissolve
    ca "My breasts?"
    scene ima529 with dissolve
    ca "Or is it my pussy what you're looking at?"
    p "I can't really see it from here, Miss Garnier."
    scene ima530 with hpunch
    ca "Ahaaa!"
    ca "So it is my pussy what you're after!"
    p "I wouldn't dare, Miss Garnier, I swear it."
    ca "Quiet!"
    scene ima531 with dissolve
    ca "I lost my train of thought here..."
    scene ima532 with dissolve
    p "Haha."
    ca "What was I saying?"
    scene ima533 with dissolve
    p "You were about to show me how to kiss passionately, Miss Garnier, I'm gonna need your help with that."
    ca "Yeah? Well, I'm here to teach you, that's my job..."
    p "What should I do? I really want to pass this class."
    ca "I wouldn't like you to fail..."
    scene ima534 with dissolve
    p "So tell me what to do please...is it ok if I rub your butt like this?"
    ca "It's a start..."
    scene ima535 with dissolve
    ca "Hold me tighter."
    p "Like this?"
    ca "You're a fast learner."
    scene ima536 with hpunch
    p "Come here!"
    scene ima537 with dissolve
    pause
    scene ima538 with dissolve
    ca "Ngh..."
    scene ima539 with dissolve
    pause
    scene ima540 with dissolve
    ca "Mmmfff!"
    scene ima541 with dissolve
    p "Wooow, Miss Garnier, I could feel all your passion in that kiss..."
    p "Are you...are you falling for your student?"
    ca "What if I am? He saved my life after all..."
    p "I don't think that's a good idea..."
    ca "I don't think it's a good idea, either..."
    scene ima540 with hpunch
    ca "Mmmfff!"
    stop music fadeout 3.0
    scene black with Dissolve(1.0)
    scene ima542 with dissolve
    p "Miss Garnier...uhm...you have such an elegant walk..."
    scene ima543 with dissolve
    ca "Thank you, sir...take a seat, please."
    scene ima544 with dissolve
    ca "Hey, who told you to take off your pants?"
    p "I'm a proactive student!"
    ca "Is that so?"
    scene ima545 with Dissolve(1)
    pause 1.2
    scene ima546 with dissolve
    p "Come here."
    scene ima547 with hpunch
    p "Ah!"
    ca "Oh my God, [p], I can feel all of it! I love you!"
    p "No, you don't, you just have my cock inside."
    ca "You think you're too cool, huh?"
    scene ima548 with dissolve
    ca "If I move, this chair's going to break..."
    p "You don't need to move your whole body, just feel my dick."
    ca "It's so hard!"
    ca "You're making it throb...ah...ah...ah..."
    p "And I have an even better idea..."

    play music "audio/sensual6.mp3"
    scene black with Dissolve(1.5)

    scene ima549a with vpunch
    ca "Ah! Baby, I love your cock!"
    scene ima550a with dissolve
    p "And I love your pussy, Cam..."
    scene ima550 with dissolve
    ca "Let me try something..."

    scene ima550:
        pause 0.0266
        "ima551"
        pause 0.0266
        "ima552"
        pause 0.0266
        "ima553"
        pause 0.0266
        "ima554"
        pause 0.0266
        "ima555"
        pause 0.0266
        "ima556"
        pause 0.0266
        "ima557"
        pause 0.0266
        "ima558"
        pause 0.0266
        "ima559"
        pause 0.0266
        "ima560"
        pause 0.0266
        "ima561"
        pause 0.0266
        "ima562"
        pause 0.0266
        "ima563"
        pause 0.0266
        "ima564"
        pause 0.0266
        "ima565"
        pause 0.0266
        "ima566"
        pause 0.0266
        "ima567"
        pause 0.0266
        "ima568"
        pause 0.0266
        "ima569"
        pause 0.0266
        "ima570"
        pause 0.0266
        "ima571"
        pause 0.0266
        "ima572"
        pause 0.0266
        "ima573"
        pause 0.0266
        "ima574"
        pause 0.0266
        "ima575"
        pause 0.0266
        "ima576"
        pause 0.0266
        "ima577"
        pause 0.0266
        "ima578"
        pause 0.0266
        "ima579"
        pause 0.0266
        "ima580"
        pause 0.0266
        "ima581"
        pause 0.0266
        "ima582"
        pause 0.0266
        "ima583"
        pause 0.0266
        "ima584"
        pause 0.0266
        "ima585"
        pause 0.0266
        "ima586"
        pause 0.0266
        "ima587"
        pause 0.0266
        "ima588"
        pause 0.0266
        "ima589"
        pause 0.0266
    pause

    ca "Shit! What was that?!"
    ca "Did you like it?"
    p "A lot! It's like your secret move or something? Do it again!"
    ca "Haha, okay!"

    scene ima550:
        pause 0.0266
        "ima551"
        pause 0.0266
        "ima552"
        pause 0.0266
        "ima553"
        pause 0.0266
        "ima554"
        pause 0.0266
        "ima555"
        pause 0.0266
        "ima556"
        pause 0.0266
        "ima557"
        pause 0.0266
        "ima558"
        pause 0.0266
        "ima559"
        pause 0.0266
        "ima560"
        pause 0.0266
        "ima561"
        pause 0.0266
        "ima562"
        pause 0.0266
        "ima563"
        pause 0.0266
        "ima564"
        pause 0.0266
        "ima565"
        pause 0.0266
        "ima566"
        pause 0.0266
        "ima567"
        pause 0.0266
        "ima568"
        pause 0.0266
        "ima569"
        pause 0.0266
        "ima570"
        pause 0.0266
        "ima571"
        pause 0.0266
        "ima572"
        pause 0.0266
        "ima573"
        pause 0.0266
        "ima574"
        pause 0.0266
        "ima575"
        pause 0.0266
        "ima576"
        pause 0.0266
        "ima577"
        pause 0.0266
        "ima578"
        pause 0.0266
        "ima579"
        pause 0.0266
        "ima580"
        pause 0.0266
        "ima581"
        pause 0.0266
        "ima582"
        pause 0.0266
        "ima583"
        pause 0.0266
        "ima584"
        pause 0.0266
        "ima585"
        pause 0.0266
        "ima586"
        pause 0.0266
        "ima587"
        pause 0.0266
        "ima588"
        pause 0.0266
        "ima589"
        pause 0.0266
        "ima590"
        pause 0.0266
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
        "ima590"
        pause 0.0084
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
        "ima590"
        pause 0.0084
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
        "ima590"
        pause 0.0084
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
        "ima590"
        pause 0.0084
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
        "ima590"
        pause 0.0084
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0084
        "ima620b"
        pause 0.0084
        "ima620a"
        pause 0.0084
    pause

    scene ima620a with dissolve
    p "Hey! Why you stop? Don't stop!"
    ca "Hahaha, I'm not sure you can take it..."
    p "Are you kidding me? You'll come first!"
    ca "You said the same last time..."
    p "Just move!"

    scene ima560:
        pause 0.0266
        "ima561"
        pause 0.0266
        "ima562"
        pause 0.0266
        "ima563"
        pause 0.0266
        "ima564"
        pause 0.0266
        "ima565"
        pause 0.0266
        "ima566"
        pause 0.0266
        "ima567"
        pause 0.0266
        "ima568"
        pause 0.0266
        "ima569"
        pause 0.0266
        "ima570"
        pause 0.0266
        "ima571"
        pause 0.0266
        "ima572"
        pause 0.0266
        "ima573"
        pause 0.0266
        "ima574"
        pause 0.0266
        "ima575"
        pause 0.0266
        "ima576"
        pause 0.0266
        "ima577"
        pause 0.0266
        "ima578"
        pause 0.0266
        "ima579"
        pause 0.0266
        "ima580"
        pause 0.0266
        "ima581"
        pause 0.0266
        "ima582"
        pause 0.0266
        "ima583"
        pause 0.0266
        "ima584"
        pause 0.0266
        "ima585"
        pause 0.0266
        "ima586"
        pause 0.0266
        "ima587"
        pause 0.0266
        "ima588"
        pause 0.0266
        "ima589"
        pause 0.0266
        "ima590"
        pause 0.0266
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0266
        "ima621"
        pause 0.0266
        "ima622"
        pause 0.0266
        "ima623"
        pause 0.0266
        "ima624"
        pause 0.0266
        "ima625"
        pause 0.0266
        "ima626"
        pause 0.0266
        "ima627"
        pause 0.0266
        "ima628"
        pause 0.0266
        "ima629"
        pause 0.0266
        "ima630"
        pause 0.0266
        "ima631"
        pause 0.0266
        "ima632"
        pause 0.0266
        "ima633"
        pause 0.0266
        "ima634"
        pause 0.0266
        "ima635"
        pause 0.0266
        "ima636"
        pause 0.0266
        "ima637"
        pause 0.0266
        "ima638"
        pause 0.0266
        "ima639"
        pause 0.0266
        "ima640"
        pause 0.0266
        "ima641"
        pause 0.0266
        "ima642"
        pause 0.0266
        "ima643"
        pause 0.0266
        "ima644"
        pause 0.0266
        "ima645"
        pause 0.0266
        "ima646"
        pause 0.0266
        "ima647"
        pause 0.0266
        "ima648"
        pause 0.0266
        "ima649"
        pause 0.0266
        "ima650"
        pause 0.0266
        repeat
    pause

    p "I'm loving it, Cam..."
    ca "Yeah?"
    p "Yes!"

label camlibslower:

    scene ima550:
        pause 0.0266
        "ima551"
        pause 0.0266
        "ima552"
        pause 0.0266
        "ima553"
        pause 0.0266
        "ima554"
        pause 0.0266
        "ima555"
        pause 0.0266
        "ima556"
        pause 0.0266
        "ima557"
        pause 0.0266
        "ima558"
        pause 0.0266
        "ima559"
        pause 0.0266
        "ima560"
        pause 0.0266
        "ima561"
        pause 0.0266
        "ima562"
        pause 0.0266
        "ima563"
        pause 0.0266
        "ima564"
        pause 0.0266
        "ima565"
        pause 0.0266
        "ima566"
        pause 0.0266
        "ima567"
        pause 0.0266
        "ima568"
        pause 0.0266
        "ima569"
        pause 0.0266
        "ima570"
        pause 0.0266
        "ima571"
        pause 0.0266
        "ima572"
        pause 0.0266
        "ima573"
        pause 0.0266
        "ima574"
        pause 0.0266
        "ima575"
        pause 0.0266
        "ima576"
        pause 0.0266
        "ima577"
        pause 0.0266
        "ima578"
        pause 0.0266
        "ima579"
        pause 0.0266
        "ima580"
        pause 0.0266
        "ima581"
        pause 0.0266
        "ima582"
        pause 0.0266
        "ima583"
        pause 0.0266
        "ima584"
        pause 0.0266
        "ima585"
        pause 0.0266
        "ima586"
        pause 0.0266
        "ima587"
        pause 0.0266
        "ima588"
        pause 0.0266
        "ima589"
        pause 0.0266
        "ima590"
        pause 0.0266
        "ima591"
        pause 0.0266
        "ima592"
        pause 0.0266
        "ima593"
        pause 0.0266
        "ima594"
        pause 0.0266
        "ima595"
        pause 0.0266
        "ima596"
        pause 0.0266
        "ima597"
        pause 0.0266
        "ima598"
        pause 0.0266
        "ima599"
        pause 0.0266
        "ima600"
        pause 0.0266
        "ima601"
        pause 0.0266
        "ima602"
        pause 0.0266
        "ima603"
        pause 0.0266
        "ima604"
        pause 0.0266
        "ima605"
        pause 0.0266
        "ima606"
        pause 0.0266
        "ima607"
        pause 0.0266
        "ima608"
        pause 0.0266
        "ima609"
        pause 0.0266
        "ima610"
        pause 0.0266
        "ima611"
        pause 0.0266
        "ima612"
        pause 0.0266
        "ima613"
        pause 0.0266
        "ima614"
        pause 0.0266
        "ima615"
        pause 0.0266
        "ima616"
        pause 0.0266
        "ima617"
        pause 0.0266
        "ima618"
        pause 0.0266
        "ima619"
        pause 0.0266
        "ima620"
        pause 0.0266
        "ima621"
        pause 0.0266
        "ima622"
        pause 0.0266
        "ima623"
        pause 0.0266
        "ima624"
        pause 0.0266
        "ima625"
        pause 0.0266
        "ima626"
        pause 0.0266
        "ima627"
        pause 0.0266
        "ima628"
        pause 0.0266
        "ima629"
        pause 0.0266
        "ima630"
        pause 0.0266
        "ima631"
        pause 0.0266
        "ima632"
        pause 0.0266
        "ima633"
        pause 0.0266
        "ima634"
        pause 0.0266
        "ima635"
        pause 0.0266
        "ima636"
        pause 0.0266
        "ima637"
        pause 0.0266
        "ima638"
        pause 0.0266
        "ima639"
        pause 0.0266
        "ima640"
        pause 0.0266
        "ima641"
        pause 0.0266
        "ima642"
        pause 0.0266
        "ima643"
        pause 0.0266
        "ima644"
        pause 0.0266
        "ima645"
        pause 0.0266
        "ima646"
        pause 0.0266
        "ima647"
        pause 0.0266
        "ima648"
        pause 0.0266
        "ima649"
        pause 0.0266
        "ima650"
        pause 0.0266
        "ima651"
        pause 0.0266
        "ima652"
        pause 0.0266
        "ima653"
        pause 0.0266
        "ima654"
        pause 0.0266
        "ima655"
        pause 0.0266
        "ima656"
        pause 0.0266
        "ima657"
        pause 0.0266
        "ima658"
        pause 0.0266
        "ima659"
        pause 0.0266
        "ima660"
        pause 0.0266
        "ima661"
        pause 0.0266
        "ima662"
        pause 0.0266
        "ima663"
        pause 0.0266
        "ima664"
        pause 0.0266
        "ima665"
        pause 0.0266
        "ima666"
        pause 0.0266
        "ima667"
        pause 0.0266
        "ima668"
        pause 0.0266
        "ima669"
        pause 0.0266
        "ima670"
        pause 0.0076
        repeat
    pause

    scene ima550:
        pause 0.0233
        "ima551"
        pause 0.0233
        "ima552"
        pause 0.0233
        "ima553"
        pause 0.0233
        "ima554"
        pause 0.0233
        "ima555"
        pause 0.0233
        "ima556"
        pause 0.0233
        "ima557"
        pause 0.0233
        "ima558"
        pause 0.0233
        "ima559"
        pause 0.0233
        "ima560"
        pause 0.0233
        "ima561"
        pause 0.0233
        "ima562"
        pause 0.0233
        "ima563"
        pause 0.0233
        "ima564"
        pause 0.0233
        "ima565"
        pause 0.0233
        "ima566"
        pause 0.0233
        "ima567"
        pause 0.0233
        "ima568"
        pause 0.0233
        "ima569"
        pause 0.0233
        "ima570"
        pause 0.0233
        "ima571"
        pause 0.0233
        "ima572"
        pause 0.0233
        "ima573"
        pause 0.0233
        "ima574"
        pause 0.0233
        "ima575"
        pause 0.0233
        "ima576"
        pause 0.0233
        "ima577"
        pause 0.0233
        "ima578"
        pause 0.0233
        "ima579"
        pause 0.0233
        "ima580"
        pause 0.0233
        "ima581"
        pause 0.0233
        "ima582"
        pause 0.0233
        "ima583"
        pause 0.0233
        "ima584"
        pause 0.0233
        "ima585"
        pause 0.0233
        "ima586"
        pause 0.0233
        "ima587"
        pause 0.0233
        "ima588"
        pause 0.0233
        "ima589"
        pause 0.0233
        "ima590"
        pause 0.0233
        "ima591"
        pause 0.0233
        "ima592"
        pause 0.0233
        "ima593"
        pause 0.0233
        "ima594"
        pause 0.0233
        "ima595"
        pause 0.0233
        "ima596"
        pause 0.0233
        "ima597"
        pause 0.0233
        "ima598"
        pause 0.0233
        "ima599"
        pause 0.0233
        "ima600"
        pause 0.0233
        "ima601"
        pause 0.0233
        "ima602"
        pause 0.0233
        "ima603"
        pause 0.0233
        "ima604"
        pause 0.0233
        "ima605"
        pause 0.0233
        "ima606"
        pause 0.0233
        "ima607"
        pause 0.0233
        "ima608"
        pause 0.0233
        "ima609"
        pause 0.0233
        "ima610"
        pause 0.0233
        "ima611"
        pause 0.0233
        "ima612"
        pause 0.0233
        "ima613"
        pause 0.0233
        "ima614"
        pause 0.0233
        "ima615"
        pause 0.0233
        "ima616"
        pause 0.0233
        "ima617"
        pause 0.0233
        "ima618"
        pause 0.0233
        "ima619"
        pause 0.0233
        "ima620"
        pause 0.0233
        "ima621"
        pause 0.0233
        "ima622"
        pause 0.0233
        "ima623"
        pause 0.0233
        "ima624"
        pause 0.0233
        "ima625"
        pause 0.0233
        "ima626"
        pause 0.0233
        "ima627"
        pause 0.0233
        "ima628"
        pause 0.0233
        "ima629"
        pause 0.0233
        "ima630"
        pause 0.0233
        "ima631"
        pause 0.0233
        "ima632"
        pause 0.0233
        "ima633"
        pause 0.0233
        "ima634"
        pause 0.0233
        "ima635"
        pause 0.0233
        "ima636"
        pause 0.0233
        "ima637"
        pause 0.0233
        "ima638"
        pause 0.0233
        "ima639"
        pause 0.0233
        "ima640"
        pause 0.0233
        "ima641"
        pause 0.0233
        "ima642"
        pause 0.0233
        "ima643"
        pause 0.0233
        "ima644"
        pause 0.0233
        "ima645"
        pause 0.0233
        "ima646"
        pause 0.0233
        "ima647"
        pause 0.0233
        "ima648"
        pause 0.0233
        "ima649"
        pause 0.0233
        "ima650"
        pause 0.0233
        "ima651"
        pause 0.0233
        "ima652"
        pause 0.0233
        "ima653"
        pause 0.0233
        "ima654"
        pause 0.0233
        "ima655"
        pause 0.0233
        "ima656"
        pause 0.0233
        "ima657"
        pause 0.0233
        "ima658"
        pause 0.0233
        "ima659"
        pause 0.0233
        "ima660"
        pause 0.0233
        "ima661"
        pause 0.0233
        "ima662"
        pause 0.0233
        "ima663"
        pause 0.0233
        "ima664"
        pause 0.0233
        "ima665"
        pause 0.0233
        "ima666"
        pause 0.0233
        "ima667"
        pause 0.0233
        "ima668"
        pause 0.0233
        "ima669"
        pause 0.0233
        "ima670"
        pause 0.0056
        repeat
    pause

    scene ima550:
        pause 0.0206
        "ima551"
        pause 0.0206
        "ima552"
        pause 0.0206
        "ima553"
        pause 0.0206
        "ima554"
        pause 0.0206
        "ima555"
        pause 0.0206
        "ima556"
        pause 0.0206
        "ima557"
        pause 0.0206
        "ima558"
        pause 0.0206
        "ima559"
        pause 0.0206
        "ima560"
        pause 0.0206
        "ima561"
        pause 0.0206
        "ima562"
        pause 0.0206
        "ima563"
        pause 0.0206
        "ima564"
        pause 0.0206
        "ima565"
        pause 0.0206
        "ima566"
        pause 0.0206
        "ima567"
        pause 0.0206
        "ima568"
        pause 0.0206
        "ima569"
        pause 0.0206
        "ima570"
        pause 0.0206
        "ima571"
        pause 0.0206
        "ima572"
        pause 0.0206
        "ima573"
        pause 0.0206
        "ima574"
        pause 0.0206
        "ima575"
        pause 0.0206
        "ima576"
        pause 0.0206
        "ima577"
        pause 0.0206
        "ima578"
        pause 0.0206
        "ima579"
        pause 0.0206
        "ima580"
        pause 0.0206
        "ima581"
        pause 0.0206
        "ima582"
        pause 0.0206
        "ima583"
        pause 0.0206
        "ima584"
        pause 0.0206
        "ima585"
        pause 0.0206
        "ima586"
        pause 0.0206
        "ima587"
        pause 0.0206
        "ima588"
        pause 0.0206
        "ima589"
        pause 0.0206
        "ima590"
        pause 0.0206
        "ima591"
        pause 0.0206
        "ima592"
        pause 0.0206
        "ima593"
        pause 0.0206
        "ima594"
        pause 0.0206
        "ima595"
        pause 0.0206
        "ima596"
        pause 0.0206
        "ima597"
        pause 0.0206
        "ima598"
        pause 0.0206
        "ima599"
        pause 0.0206
        "ima600"
        pause 0.0206
        "ima601"
        pause 0.0206
        "ima602"
        pause 0.0206
        "ima603"
        pause 0.0206
        "ima604"
        pause 0.0206
        "ima605"
        pause 0.0206
        "ima606"
        pause 0.0206
        "ima607"
        pause 0.0206
        "ima608"
        pause 0.0206
        "ima609"
        pause 0.0206
        "ima610"
        pause 0.0206
        "ima611"
        pause 0.0206
        "ima612"
        pause 0.0206
        "ima613"
        pause 0.0206
        "ima614"
        pause 0.0206
        "ima615"
        pause 0.0206
        "ima616"
        pause 0.0206
        "ima617"
        pause 0.0206
        "ima618"
        pause 0.0206
        "ima619"
        pause 0.0206
        "ima620"
        pause 0.0206
        "ima621"
        pause 0.0206
        "ima622"
        pause 0.0206
        "ima623"
        pause 0.0206
        "ima624"
        pause 0.0206
        "ima625"
        pause 0.0206
        "ima626"
        pause 0.0206
        "ima627"
        pause 0.0206
        "ima628"
        pause 0.0206
        "ima629"
        pause 0.0206
        "ima630"
        pause 0.0206
        "ima631"
        pause 0.0206
        "ima632"
        pause 0.0206
        "ima633"
        pause 0.0206
        "ima634"
        pause 0.0206
        "ima635"
        pause 0.0206
        "ima636"
        pause 0.0206
        "ima637"
        pause 0.0206
        "ima638"
        pause 0.0206
        "ima639"
        pause 0.0206
        "ima640"
        pause 0.0206
        "ima641"
        pause 0.0206
        "ima642"
        pause 0.0206
        "ima643"
        pause 0.0206
        "ima644"
        pause 0.0206
        "ima645"
        pause 0.0206
        "ima646"
        pause 0.0206
        "ima647"
        pause 0.0206
        "ima648"
        pause 0.0206
        "ima649"
        pause 0.0206
        "ima650"
        pause 0.0206
        "ima651"
        pause 0.0206
        "ima652"
        pause 0.0206
        "ima653"
        pause 0.0206
        "ima654"
        pause 0.0206
        "ima655"
        pause 0.0206
        "ima656"
        pause 0.0206
        "ima657"
        pause 0.0206
        "ima658"
        pause 0.0206
        "ima659"
        pause 0.0206
        "ima660"
        pause 0.0206
        "ima661"
        pause 0.0206
        "ima662"
        pause 0.0206
        "ima663"
        pause 0.0206
        "ima664"
        pause 0.0206
        "ima665"
        pause 0.0206
        "ima666"
        pause 0.0206
        "ima667"
        pause 0.0206
        "ima668"
        pause 0.0206
        "ima669"
        pause 0.0206
        "ima670"
        pause 0.0046
        repeat
    pause

menu:
    "Change angle.":
        jump camlibangleup

    "Slower.":
        jump camlibslower

label camlibangleup:

    show ima672 with dissolve
    show ima725 with vpunch
    show ima672 with dissolve
    show ima725 with vpunch
    p "What was that? You came?"
    ca "A little bit..."
    ca "Don't worry, I can still go!"

    scene ima672 with dissolve

    scene ima682:
        pause 0.0266
        "ima683"
        pause 0.0266
        "ima684"
        pause 0.0266
        "ima685"
        pause 0.0266
        "ima686"
        pause 0.0266
        "ima687"
        pause 0.0266
        "ima688"
        pause 0.0266
        "ima689"
        pause 0.0266
        "ima690"
        pause 0.0266
        "ima691"
        pause 0.0266
        "ima692"
        pause 0.0266
        "ima693"
        pause 0.0266
        "ima694"
        pause 0.0266
        "ima695"
        pause 0.0266
        "ima696"
        pause 0.0266
        "ima697"
        pause 0.0266
        "ima698"
        pause 0.0266
        "ima699"
        pause 0.0266
        "ima700"
        pause 0.0266
        "ima701"
        pause 0.0266
        "ima702"
        pause 0.0266
        "ima703"
        pause 0.0266
        "ima704"
        pause 0.0266
        "ima705"
        pause 0.0266
        "ima706"
        pause 0.0266
        "ima707"
        pause 0.0266
        "ima708"
        pause 0.0266
        "ima709"
        pause 0.0266
        "ima710"
        pause 0.0266
        "ima711"
        pause 0.0266
        "ima712"
        pause 0.0266
        "ima713"
        pause 0.0266
        "ima714"
        pause 0.0266
        "ima715"
        pause 0.0266
        "ima716"
        pause 0.0266
        "ima717"
        pause 0.0266
        "ima718"
        pause 0.0266
        "ima719"
        pause 0.0266
        "ima720"
        pause 0.0266
        "ima721"
        pause 0.0266
        "ima722"
        pause 0.0266
        "ima723"
        pause 0.0266
        "ima724"
        pause 0.0266
        "ima725"
        pause 0.0266
        "ima726"
        pause 0.0266
        "ima727"
        pause 0.0266
        "ima728"
        pause 0.0266
        "ima729"
        pause 0.0266
        "ima730"
        pause 0.0266
        "ima731"
        pause 0.0266
        "ima732"
        pause 0.0266
        "ima733"
        pause 0.0266
        "ima734"
        pause 0.0266
        "ima735"
        pause 0.0266
        "ima736"
        pause 0.0266
        "ima737"
        pause 0.0266
        "ima738"
        pause 0.0266
        "ima739"
        pause 0.0266
        "ima740"
        pause 0.0266
        "ima741"
        pause 0.0266
        "ima742"
        pause 0.0266
        "ima743"
        pause 0.0266
        "ima744"
        pause 0.0266
        "ima745"
        pause 0.0266
        "ima746"
        pause 0.0266
        "ima747"
        pause 0.0266
        "ima748"
        pause 0.0266
        "ima749"
        pause 0.0266
        "ima750"
        pause 0.0266
        "ima751"
        pause 0.0266
        "ima752"
        pause 0.0266
        "ima753"
        pause 0.0266
        "ima754"
        pause 0.0266
        "ima755"
        pause 0.0266
        "ima756"
        pause 0.0266
        "ima757"
        pause 0.0266
        "ima758"
        pause 0.0266
        "ima759"
        pause 0.0266
        "ima760"
        pause 0.0266
        "ima761"
        pause 0.0266
        "ima762"
        pause 0.0266
        "ima763"
        pause 0.0266
        "ima764"
        pause 0.0266
        "ima765"
        pause 0.0266
        "ima766"
        pause 0.0266
        "ima767"
        pause 0.0266
        "ima768"
        pause 0.0266
        "ima769"
        pause 0.0266
        "ima770"
        pause 0.0266
        "ima771"
        pause 0.0266
        "ima772"
        pause 0.0266
        repeat

    p "Daaaammmn...this's incredible!"
    ca "I'm driving you crazy, huh?"
    p "Pfff...you have to look at this to understand!"
    ca "Hahaha...come inside, baby, I love it when you do!"
    p "Oh, I will!"

    scene ima672:
        pause 0.0266
        "ima673"
        pause 0.0266
        "ima674"
        pause 0.0266
        "ima675"
        pause 0.0266
        "ima676"
        pause 0.0266
        "ima677"
        pause 0.0266
        "ima678"
        pause 0.0266
        "ima679"
        pause 0.0266
        "ima680"
        pause 0.0266
        "ima681"
        pause 0.0266
        "ima682"
        pause 0.0266
        "ima683"
        pause 0.0266
        "ima684"
        pause 0.0266
        "ima685"
        pause 0.0266
        "ima686"
        pause 0.0266
        "ima687"
        pause 0.0266
        "ima688"
        pause 0.0266
        "ima689"
        pause 0.0266
        "ima690"
        pause 0.0266
        "ima691"
        pause 0.0266
        "ima692"
        pause 0.0266
        "ima693"
        pause 0.0266
        "ima694"
        pause 0.0266
        "ima695"
        pause 0.0266
        "ima696"
        pause 0.0266
        "ima697"
        pause 0.0266
        "ima698"
        pause 0.0266
        "ima699"
        pause 0.0266
        "ima700"
        pause 0.0266
        "ima701"
        pause 0.0266
        "ima702"
        pause 0.0266
        "ima703"
        pause 0.0266
        "ima704"
        pause 0.0266
        "ima705"
        pause 0.0266
        "ima706"
        pause 0.0266
        "ima707"
        pause 0.0266
        "ima708"
        pause 0.0266
        "ima709"
        pause 0.0266
        "ima710"
        pause 0.0266
        "ima711"
        pause 0.0266
        "ima712"
        pause 0.0266
        "ima713"
        pause 0.0266
        "ima714"
        pause 0.0266
        "ima715"
        pause 0.0266
        "ima716"
        pause 0.0266
        "ima717"
        pause 0.0266
        "ima718"
        pause 0.0266
        "ima719"
        pause 0.0266
        "ima720"
        pause 0.0266
        "ima721"
        pause 0.0266
        "ima722"
        pause 0.0266
        "ima723"
        pause 0.0266
        "ima724"
        pause 0.0266
        "ima725"
        pause 0.0266
        "ima726"
        pause 0.0266
        "ima727"
        pause 0.0266
        "ima728"
        pause 0.0266
        "ima729"
        pause 0.0266
        "ima730"
        pause 0.0266
        "ima731"
        pause 0.0266
        "ima732"
        pause 0.0266
        "ima733"
        pause 0.0266
        "ima734"
        pause 0.0266
        "ima735"
        pause 0.0266
        "ima736"
        pause 0.0266
        "ima737"
        pause 0.0266
        "ima738"
        pause 0.0266
        "ima739"
        pause 0.0266
        "ima740"
        pause 0.0266
        "ima741"
        pause 0.0266
        "ima742"
        pause 0.0266
        "ima743"
        pause 0.0266
        "ima744"
        pause 0.0266
        "ima745"
        pause 0.0266
        "ima746"
        pause 0.0266
        "ima747"
        pause 0.0266
        "ima748"
        pause 0.0266
        "ima749"
        pause 0.0266
        "ima750"
        pause 0.0266
        "ima751"
        pause 0.0266
        "ima752"
        pause 0.0266
        "ima753"
        pause 0.0266
        "ima754"
        pause 0.0266
        "ima755"
        pause 0.0266
        "ima756"
        pause 0.0266
        "ima757"
        pause 0.0266
        "ima758"
        pause 0.0266
        "ima759"
        pause 0.0266
        "ima760"
        pause 0.0266
        "ima761"
        pause 0.0266
        "ima762"
        pause 0.0266
        "ima763"
        pause 0.0266
        "ima764"
        pause 0.0266
        "ima765"
        pause 0.0266
        "ima766"
        pause 0.0266
        "ima767"
        pause 0.0266
        "ima768"
        pause 0.0266
        "ima769"
        pause 0.0266
        "ima770"
        pause 0.0266
        "ima771"
        pause 0.0266
        "ima772"
        pause 0.0266
        "ima773"
        pause 0.0266
        "ima774"
        pause 0.0266
        "ima775"
        pause 0.0266
        "ima776"
        pause 0.0266
        "ima777"
        pause 0.0266
        "ima778"
        pause 0.0266
        "ima779"
        pause 0.0266
        "ima780"
        pause 0.0266
        "ima781"
        pause 0.0266
        "ima782"
        pause 0.0266
        "ima783"
        pause 0.0266
        "ima784"
        pause 0.0266
        "ima785"
        pause 0.0266
        "ima786"
        pause 0.0266
        "ima787"
        pause 0.0266
        "ima788"
        pause 0.0266
        "ima789"
        pause 0.0266
        "ima790"
        pause 0.0266
        "ima791"
        pause 0.0266
        "ima792"
        pause 0.0076
        repeat
    pause

    scene ima672:
        pause 0.0233
        "ima673"
        pause 0.0233
        "ima674"
        pause 0.0233
        "ima675"
        pause 0.0233
        "ima676"
        pause 0.0233
        "ima677"
        pause 0.0233
        "ima678"
        pause 0.0233
        "ima679"
        pause 0.0233
        "ima680"
        pause 0.0233
        "ima681"
        pause 0.0233
        "ima682"
        pause 0.0233
        "ima683"
        pause 0.0233
        "ima684"
        pause 0.0233
        "ima685"
        pause 0.0233
        "ima686"
        pause 0.0233
        "ima687"
        pause 0.0233
        "ima688"
        pause 0.0233
        "ima689"
        pause 0.0233
        "ima690"
        pause 0.0233
        "ima691"
        pause 0.0233
        "ima692"
        pause 0.0233
        "ima693"
        pause 0.0233
        "ima694"
        pause 0.0233
        "ima695"
        pause 0.0233
        "ima696"
        pause 0.0233
        "ima697"
        pause 0.0233
        "ima698"
        pause 0.0233
        "ima699"
        pause 0.0233
        "ima700"
        pause 0.0233
        "ima701"
        pause 0.0233
        "ima702"
        pause 0.0233
        "ima703"
        pause 0.0233
        "ima704"
        pause 0.0233
        "ima705"
        pause 0.0233
        "ima706"
        pause 0.0233
        "ima707"
        pause 0.0233
        "ima708"
        pause 0.0233
        "ima709"
        pause 0.0233
        "ima710"
        pause 0.0233
        "ima711"
        pause 0.0233
        "ima712"
        pause 0.0233
        "ima713"
        pause 0.0233
        "ima714"
        pause 0.0233
        "ima715"
        pause 0.0233
        "ima716"
        pause 0.0233
        "ima717"
        pause 0.0233
        "ima718"
        pause 0.0233
        "ima719"
        pause 0.0233
        "ima720"
        pause 0.0233
        "ima721"
        pause 0.0233
        "ima722"
        pause 0.0233
        "ima723"
        pause 0.0233
        "ima724"
        pause 0.0233
        "ima725"
        pause 0.0233
        "ima726"
        pause 0.0233
        "ima727"
        pause 0.0233
        "ima728"
        pause 0.0233
        "ima729"
        pause 0.0233
        "ima730"
        pause 0.0233
        "ima731"
        pause 0.0233
        "ima732"
        pause 0.0233
        "ima733"
        pause 0.0233
        "ima734"
        pause 0.0233
        "ima735"
        pause 0.0233
        "ima736"
        pause 0.0233
        "ima737"
        pause 0.0233
        "ima738"
        pause 0.0233
        "ima739"
        pause 0.0233
        "ima740"
        pause 0.0233
        "ima741"
        pause 0.0233
        "ima742"
        pause 0.0233
        "ima743"
        pause 0.0233
        "ima744"
        pause 0.0233
        "ima745"
        pause 0.0233
        "ima746"
        pause 0.0233
        "ima747"
        pause 0.0233
        "ima748"
        pause 0.0233
        "ima749"
        pause 0.0233
        "ima750"
        pause 0.0233
        "ima751"
        pause 0.0233
        "ima752"
        pause 0.0233
        "ima753"
        pause 0.0233
        "ima754"
        pause 0.0233
        "ima755"
        pause 0.0233
        "ima756"
        pause 0.0233
        "ima757"
        pause 0.0233
        "ima758"
        pause 0.0233
        "ima759"
        pause 0.0233
        "ima760"
        pause 0.0233
        "ima761"
        pause 0.0233
        "ima762"
        pause 0.0233
        "ima763"
        pause 0.0233
        "ima764"
        pause 0.0233
        "ima765"
        pause 0.0233
        "ima766"
        pause 0.0233
        "ima767"
        pause 0.0233
        "ima768"
        pause 0.0233
        "ima769"
        pause 0.0233
        "ima770"
        pause 0.0233
        "ima771"
        pause 0.0233
        "ima772"
        pause 0.0233
        "ima773"
        pause 0.0233
        "ima774"
        pause 0.0233
        "ima775"
        pause 0.0233
        "ima776"
        pause 0.0233
        "ima777"
        pause 0.0233
        "ima778"
        pause 0.0233
        "ima779"
        pause 0.0233
        "ima780"
        pause 0.0233
        "ima781"
        pause 0.0233
        "ima782"
        pause 0.0233
        "ima783"
        pause 0.0233
        "ima784"
        pause 0.0233
        "ima785"
        pause 0.0233
        "ima786"
        pause 0.0233
        "ima787"
        pause 0.0233
        "ima788"
        pause 0.0233
        "ima789"
        pause 0.0233
        "ima790"
        pause 0.0233
        "ima791"
        pause 0.0233
        "ima792"
        pause 0.0056
        repeat
    pause

    scene ima672:
        pause 0.0206
        "ima673"
        pause 0.0206
        "ima674"
        pause 0.0206
        "ima675"
        pause 0.0206
        "ima676"
        pause 0.0206
        "ima677"
        pause 0.0206
        "ima678"
        pause 0.0206
        "ima679"
        pause 0.0206
        "ima680"
        pause 0.0206
        "ima681"
        pause 0.0206
        "ima682"
        pause 0.0206
        "ima683"
        pause 0.0206
        "ima684"
        pause 0.0206
        "ima685"
        pause 0.0206
        "ima686"
        pause 0.0206
        "ima687"
        pause 0.0206
        "ima688"
        pause 0.0206
        "ima689"
        pause 0.0206
        "ima690"
        pause 0.0206
        "ima691"
        pause 0.0206
        "ima692"
        pause 0.0206
        "ima693"
        pause 0.0206
        "ima694"
        pause 0.0206
        "ima695"
        pause 0.0206
        "ima696"
        pause 0.0206
        "ima697"
        pause 0.0206
        "ima698"
        pause 0.0206
        "ima699"
        pause 0.0206
        "ima700"
        pause 0.0206
        "ima701"
        pause 0.0206
        "ima702"
        pause 0.0206
        "ima703"
        pause 0.0206
        "ima704"
        pause 0.0206
        "ima705"
        pause 0.0206
        "ima706"
        pause 0.0206
        "ima707"
        pause 0.0206
        "ima708"
        pause 0.0206
        "ima709"
        pause 0.0206
        "ima710"
        pause 0.0206
        "ima711"
        pause 0.0206
        "ima712"
        pause 0.0206
        "ima713"
        pause 0.0206
        "ima714"
        pause 0.0206
        "ima715"
        pause 0.0206
        "ima716"
        pause 0.0206
        "ima717"
        pause 0.0206
        "ima718"
        pause 0.0206
        "ima719"
        pause 0.0206
        "ima720"
        pause 0.0206
        "ima721"
        pause 0.0206
        "ima722"
        pause 0.0206
        "ima723"
        pause 0.0206
        "ima724"
        pause 0.0206
        "ima725"
        pause 0.0206
        "ima726"
        pause 0.0206
        "ima727"
        pause 0.0206
        "ima728"
        pause 0.0206
        "ima729"
        pause 0.0206
        "ima730"
        pause 0.0206
        "ima731"
        pause 0.0206
        "ima732"
        pause 0.0206
        "ima733"
        pause 0.0206
        "ima734"
        pause 0.0206
        "ima735"
        pause 0.0206
        "ima736"
        pause 0.0206
        "ima737"
        pause 0.0206
        "ima738"
        pause 0.0206
        "ima739"
        pause 0.0206
        "ima740"
        pause 0.0206
        "ima741"
        pause 0.0206
        "ima742"
        pause 0.0206
        "ima743"
        pause 0.0206
        "ima744"
        pause 0.0206
        "ima745"
        pause 0.0206
        "ima746"
        pause 0.0206
        "ima747"
        pause 0.0206
        "ima748"
        pause 0.0206
        "ima749"
        pause 0.0206
        "ima750"
        pause 0.0206
        "ima751"
        pause 0.0206
        "ima752"
        pause 0.0206
        "ima753"
        pause 0.0206
        "ima754"
        pause 0.0206
        "ima755"
        pause 0.0206
        "ima756"
        pause 0.0206
        "ima757"
        pause 0.0206
        "ima758"
        pause 0.0206
        "ima759"
        pause 0.0206
        "ima760"
        pause 0.0206
        "ima761"
        pause 0.0206
        "ima762"
        pause 0.0206
        "ima763"
        pause 0.0206
        "ima764"
        pause 0.0206
        "ima765"
        pause 0.0206
        "ima766"
        pause 0.0206
        "ima767"
        pause 0.0206
        "ima768"
        pause 0.0206
        "ima769"
        pause 0.0206
        "ima770"
        pause 0.0206
        "ima771"
        pause 0.0206
        "ima772"
        pause 0.0206
        "ima773"
        pause 0.0206
        "ima774"
        pause 0.0206
        "ima775"
        pause 0.0206
        "ima776"
        pause 0.0206
        "ima777"
        pause 0.0206
        "ima778"
        pause 0.0206
        "ima779"
        pause 0.0206
        "ima780"
        pause 0.0206
        "ima781"
        pause 0.0206
        "ima782"
        pause 0.0206
        "ima783"
        pause 0.0206
        "ima784"
        pause 0.0206
        "ima785"
        pause 0.0206
        "ima786"
        pause 0.0206
        "ima787"
        pause 0.0206
        "ima788"
        pause 0.0206
        "ima789"
        pause 0.0206
        "ima790"
        pause 0.0206
        "ima791"
        pause 0.0206
        "ima792"
        pause 0.0046
        repeat
    pause

    p "Brrrr, brrrr..."
    p "Fuck, I'm cumming!"
    ca "Cum in me, baby, come in me!"

menu:
    "Slower.":
        jump camlibslow

    "Cum.":
        jump camlibcum

label camlibslow:

    scene ima672:
        pause 0.0266
        "ima673"
        pause 0.0266
        "ima674"
        pause 0.0266
        "ima675"
        pause 0.0266
        "ima676"
        pause 0.0266
        "ima677"
        pause 0.0266
        "ima678"
        pause 0.0266
        "ima679"
        pause 0.0266
        "ima680"
        pause 0.0266
        "ima681"
        pause 0.0266
        "ima682"
        pause 0.0266
        "ima683"
        pause 0.0266
        "ima684"
        pause 0.0266
        "ima685"
        pause 0.0266
        "ima686"
        pause 0.0266
        "ima687"
        pause 0.0266
        "ima688"
        pause 0.0266
        "ima689"
        pause 0.0266
        "ima690"
        pause 0.0266
        "ima691"
        pause 0.0266
        "ima692"
        pause 0.0266
        "ima693"
        pause 0.0266
        "ima694"
        pause 0.0266
        "ima695"
        pause 0.0266
        "ima696"
        pause 0.0266
        "ima697"
        pause 0.0266
        "ima698"
        pause 0.0266
        "ima699"
        pause 0.0266
        "ima700"
        pause 0.0266
        "ima701"
        pause 0.0266
        "ima702"
        pause 0.0266
        "ima703"
        pause 0.0266
        "ima704"
        pause 0.0266
        "ima705"
        pause 0.0266
        "ima706"
        pause 0.0266
        "ima707"
        pause 0.0266
        "ima708"
        pause 0.0266
        "ima709"
        pause 0.0266
        "ima710"
        pause 0.0266
        "ima711"
        pause 0.0266
        "ima712"
        pause 0.0266
        "ima713"
        pause 0.0266
        "ima714"
        pause 0.0266
        "ima715"
        pause 0.0266
        "ima716"
        pause 0.0266
        "ima717"
        pause 0.0266
        "ima718"
        pause 0.0266
        "ima719"
        pause 0.0266
        "ima720"
        pause 0.0266
        "ima721"
        pause 0.0266
        "ima722"
        pause 0.0266
        "ima723"
        pause 0.0266
        "ima724"
        pause 0.0266
        "ima725"
        pause 0.0266
        "ima726"
        pause 0.0266
        "ima727"
        pause 0.0266
        "ima728"
        pause 0.0266
        "ima729"
        pause 0.0266
        "ima730"
        pause 0.0266
        "ima731"
        pause 0.0266
        "ima732"
        pause 0.0266
        "ima733"
        pause 0.0266
        "ima734"
        pause 0.0266
        "ima735"
        pause 0.0266
        "ima736"
        pause 0.0266
        "ima737"
        pause 0.0266
        "ima738"
        pause 0.0266
        "ima739"
        pause 0.0266
        "ima740"
        pause 0.0266
        "ima741"
        pause 0.0266
        "ima742"
        pause 0.0266
        "ima743"
        pause 0.0266
        "ima744"
        pause 0.0266
        "ima745"
        pause 0.0266
        "ima746"
        pause 0.0266
        "ima747"
        pause 0.0266
        "ima748"
        pause 0.0266
        "ima749"
        pause 0.0266
        "ima750"
        pause 0.0266
        "ima751"
        pause 0.0266
        "ima752"
        pause 0.0266
        "ima753"
        pause 0.0266
        "ima754"
        pause 0.0266
        "ima755"
        pause 0.0266
        "ima756"
        pause 0.0266
        "ima757"
        pause 0.0266
        "ima758"
        pause 0.0266
        "ima759"
        pause 0.0266
        "ima760"
        pause 0.0266
        "ima761"
        pause 0.0266
        "ima762"
        pause 0.0266
        "ima763"
        pause 0.0266
        "ima764"
        pause 0.0266
        "ima765"
        pause 0.0266
        "ima766"
        pause 0.0266
        "ima767"
        pause 0.0266
        "ima768"
        pause 0.0266
        "ima769"
        pause 0.0266
        "ima770"
        pause 0.0266
        "ima771"
        pause 0.0266
        "ima772"
        pause 0.0266
        "ima773"
        pause 0.0266
        "ima774"
        pause 0.0266
        "ima775"
        pause 0.0266
        "ima776"
        pause 0.0266
        "ima777"
        pause 0.0266
        "ima778"
        pause 0.0266
        "ima779"
        pause 0.0266
        "ima780"
        pause 0.0266
        "ima781"
        pause 0.0266
        "ima782"
        pause 0.0266
        "ima783"
        pause 0.0266
        "ima784"
        pause 0.0266
        "ima785"
        pause 0.0266
        "ima786"
        pause 0.0266
        "ima787"
        pause 0.0266
        "ima788"
        pause 0.0266
        "ima789"
        pause 0.0266
        "ima790"
        pause 0.0266
        "ima791"
        pause 0.0266
        "ima792"
        pause 0.0076
        repeat
    pause

    scene ima672:
        pause 0.0233
        "ima673"
        pause 0.0233
        "ima674"
        pause 0.0233
        "ima675"
        pause 0.0233
        "ima676"
        pause 0.0233
        "ima677"
        pause 0.0233
        "ima678"
        pause 0.0233
        "ima679"
        pause 0.0233
        "ima680"
        pause 0.0233
        "ima681"
        pause 0.0233
        "ima682"
        pause 0.0233
        "ima683"
        pause 0.0233
        "ima684"
        pause 0.0233
        "ima685"
        pause 0.0233
        "ima686"
        pause 0.0233
        "ima687"
        pause 0.0233
        "ima688"
        pause 0.0233
        "ima689"
        pause 0.0233
        "ima690"
        pause 0.0233
        "ima691"
        pause 0.0233
        "ima692"
        pause 0.0233
        "ima693"
        pause 0.0233
        "ima694"
        pause 0.0233
        "ima695"
        pause 0.0233
        "ima696"
        pause 0.0233
        "ima697"
        pause 0.0233
        "ima698"
        pause 0.0233
        "ima699"
        pause 0.0233
        "ima700"
        pause 0.0233
        "ima701"
        pause 0.0233
        "ima702"
        pause 0.0233
        "ima703"
        pause 0.0233
        "ima704"
        pause 0.0233
        "ima705"
        pause 0.0233
        "ima706"
        pause 0.0233
        "ima707"
        pause 0.0233
        "ima708"
        pause 0.0233
        "ima709"
        pause 0.0233
        "ima710"
        pause 0.0233
        "ima711"
        pause 0.0233
        "ima712"
        pause 0.0233
        "ima713"
        pause 0.0233
        "ima714"
        pause 0.0233
        "ima715"
        pause 0.0233
        "ima716"
        pause 0.0233
        "ima717"
        pause 0.0233
        "ima718"
        pause 0.0233
        "ima719"
        pause 0.0233
        "ima720"
        pause 0.0233
        "ima721"
        pause 0.0233
        "ima722"
        pause 0.0233
        "ima723"
        pause 0.0233
        "ima724"
        pause 0.0233
        "ima725"
        pause 0.0233
        "ima726"
        pause 0.0233
        "ima727"
        pause 0.0233
        "ima728"
        pause 0.0233
        "ima729"
        pause 0.0233
        "ima730"
        pause 0.0233
        "ima731"
        pause 0.0233
        "ima732"
        pause 0.0233
        "ima733"
        pause 0.0233
        "ima734"
        pause 0.0233
        "ima735"
        pause 0.0233
        "ima736"
        pause 0.0233
        "ima737"
        pause 0.0233
        "ima738"
        pause 0.0233
        "ima739"
        pause 0.0233
        "ima740"
        pause 0.0233
        "ima741"
        pause 0.0233
        "ima742"
        pause 0.0233
        "ima743"
        pause 0.0233
        "ima744"
        pause 0.0233
        "ima745"
        pause 0.0233
        "ima746"
        pause 0.0233
        "ima747"
        pause 0.0233
        "ima748"
        pause 0.0233
        "ima749"
        pause 0.0233
        "ima750"
        pause 0.0233
        "ima751"
        pause 0.0233
        "ima752"
        pause 0.0233
        "ima753"
        pause 0.0233
        "ima754"
        pause 0.0233
        "ima755"
        pause 0.0233
        "ima756"
        pause 0.0233
        "ima757"
        pause 0.0233
        "ima758"
        pause 0.0233
        "ima759"
        pause 0.0233
        "ima760"
        pause 0.0233
        "ima761"
        pause 0.0233
        "ima762"
        pause 0.0233
        "ima763"
        pause 0.0233
        "ima764"
        pause 0.0233
        "ima765"
        pause 0.0233
        "ima766"
        pause 0.0233
        "ima767"
        pause 0.0233
        "ima768"
        pause 0.0233
        "ima769"
        pause 0.0233
        "ima770"
        pause 0.0233
        "ima771"
        pause 0.0233
        "ima772"
        pause 0.0233
        "ima773"
        pause 0.0233
        "ima774"
        pause 0.0233
        "ima775"
        pause 0.0233
        "ima776"
        pause 0.0233
        "ima777"
        pause 0.0233
        "ima778"
        pause 0.0233
        "ima779"
        pause 0.0233
        "ima780"
        pause 0.0233
        "ima781"
        pause 0.0233
        "ima782"
        pause 0.0233
        "ima783"
        pause 0.0233
        "ima784"
        pause 0.0233
        "ima785"
        pause 0.0233
        "ima786"
        pause 0.0233
        "ima787"
        pause 0.0233
        "ima788"
        pause 0.0233
        "ima789"
        pause 0.0233
        "ima790"
        pause 0.0233
        "ima791"
        pause 0.0233
        "ima792"
        pause 0.0056
        repeat
    pause

    scene ima672:
        pause 0.0206
        "ima673"
        pause 0.0206
        "ima674"
        pause 0.0206
        "ima675"
        pause 0.0206
        "ima676"
        pause 0.0206
        "ima677"
        pause 0.0206
        "ima678"
        pause 0.0206
        "ima679"
        pause 0.0206
        "ima680"
        pause 0.0206
        "ima681"
        pause 0.0206
        "ima682"
        pause 0.0206
        "ima683"
        pause 0.0206
        "ima684"
        pause 0.0206
        "ima685"
        pause 0.0206
        "ima686"
        pause 0.0206
        "ima687"
        pause 0.0206
        "ima688"
        pause 0.0206
        "ima689"
        pause 0.0206
        "ima690"
        pause 0.0206
        "ima691"
        pause 0.0206
        "ima692"
        pause 0.0206
        "ima693"
        pause 0.0206
        "ima694"
        pause 0.0206
        "ima695"
        pause 0.0206
        "ima696"
        pause 0.0206
        "ima697"
        pause 0.0206
        "ima698"
        pause 0.0206
        "ima699"
        pause 0.0206
        "ima700"
        pause 0.0206
        "ima701"
        pause 0.0206
        "ima702"
        pause 0.0206
        "ima703"
        pause 0.0206
        "ima704"
        pause 0.0206
        "ima705"
        pause 0.0206
        "ima706"
        pause 0.0206
        "ima707"
        pause 0.0206
        "ima708"
        pause 0.0206
        "ima709"
        pause 0.0206
        "ima710"
        pause 0.0206
        "ima711"
        pause 0.0206
        "ima712"
        pause 0.0206
        "ima713"
        pause 0.0206
        "ima714"
        pause 0.0206
        "ima715"
        pause 0.0206
        "ima716"
        pause 0.0206
        "ima717"
        pause 0.0206
        "ima718"
        pause 0.0206
        "ima719"
        pause 0.0206
        "ima720"
        pause 0.0206
        "ima721"
        pause 0.0206
        "ima722"
        pause 0.0206
        "ima723"
        pause 0.0206
        "ima724"
        pause 0.0206
        "ima725"
        pause 0.0206
        "ima726"
        pause 0.0206
        "ima727"
        pause 0.0206
        "ima728"
        pause 0.0206
        "ima729"
        pause 0.0206
        "ima730"
        pause 0.0206
        "ima731"
        pause 0.0206
        "ima732"
        pause 0.0206
        "ima733"
        pause 0.0206
        "ima734"
        pause 0.0206
        "ima735"
        pause 0.0206
        "ima736"
        pause 0.0206
        "ima737"
        pause 0.0206
        "ima738"
        pause 0.0206
        "ima739"
        pause 0.0206
        "ima740"
        pause 0.0206
        "ima741"
        pause 0.0206
        "ima742"
        pause 0.0206
        "ima743"
        pause 0.0206
        "ima744"
        pause 0.0206
        "ima745"
        pause 0.0206
        "ima746"
        pause 0.0206
        "ima747"
        pause 0.0206
        "ima748"
        pause 0.0206
        "ima749"
        pause 0.0206
        "ima750"
        pause 0.0206
        "ima751"
        pause 0.0206
        "ima752"
        pause 0.0206
        "ima753"
        pause 0.0206
        "ima754"
        pause 0.0206
        "ima755"
        pause 0.0206
        "ima756"
        pause 0.0206
        "ima757"
        pause 0.0206
        "ima758"
        pause 0.0206
        "ima759"
        pause 0.0206
        "ima760"
        pause 0.0206
        "ima761"
        pause 0.0206
        "ima762"
        pause 0.0206
        "ima763"
        pause 0.0206
        "ima764"
        pause 0.0206
        "ima765"
        pause 0.0206
        "ima766"
        pause 0.0206
        "ima767"
        pause 0.0206
        "ima768"
        pause 0.0206
        "ima769"
        pause 0.0206
        "ima770"
        pause 0.0206
        "ima771"
        pause 0.0206
        "ima772"
        pause 0.0206
        "ima773"
        pause 0.0206
        "ima774"
        pause 0.0206
        "ima775"
        pause 0.0206
        "ima776"
        pause 0.0206
        "ima777"
        pause 0.0206
        "ima778"
        pause 0.0206
        "ima779"
        pause 0.0206
        "ima780"
        pause 0.0206
        "ima781"
        pause 0.0206
        "ima782"
        pause 0.0206
        "ima783"
        pause 0.0206
        "ima784"
        pause 0.0206
        "ima785"
        pause 0.0206
        "ima786"
        pause 0.0206
        "ima787"
        pause 0.0206
        "ima788"
        pause 0.0206
        "ima789"
        pause 0.0206
        "ima790"
        pause 0.0206
        "ima791"
        pause 0.0206
        "ima792"
        pause 0.0046
        repeat
    pause

    p "I'm gonna fill you good!"
    ca "Yes, please, cum in me, please, cum in me!"

menu:
    "Cum.":
        jump camlibcum

label camlibcum:

    stop music fadeout 3.0

    play sound "audio/maleorg2.ogg"
    scene ima725 with vpunch
    scene ima725 with vpunch
    scene ima725 with vpunch
    pause
    play sound "audio/maleorg2.ogg"
    scene ima795 with vpunch
    scene ima795 with vpunch
    scene ima795 with flash
    pause 0.5
    scene ima796 with dissolve
    ca "Yes, baby! That's what I wanted!"
    p "I'm not done yet, I want more..."
    ca "Me, too!"

    play music "audio/camlibra.ogg"
    scene black with Dissolve(2.0)
    scene ima798 with Dissolve(2.0)
    pause
    scene ima797 with pushleft
    pause
    scene ima800 with pushleft
    p "Fuck!"
    scene ima799 with pushleft
    ca "Ooohhh, what a bad boy...you just keep filling me up!"
    scene ima793 with vpunch
    scene ima793 with vpunch
    p "Yeah, I'm passing this class!"
    p "Fuck, you're too delicious..."
    scene ima794 with dissolve
    ca "Haha, your cum is, baby!"

    stop music fadeout 3.0

    jump endcamille

label endcamille:

    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    pause

    play sound "audio/vibrator.mp3"
    scene ima801 with dissolve
    pause 2.5
    stop sound
    scene ima802 with dissolve
    p "Hello."
    bi "[p]! My boy!"
    p "Who's this? Billy?"
    bi "Yes, buddy, the one and only! Listen, I have a business idea!"
    p "Bye."
    scene ima803 with dissolve
    bi "No, no, don't hang up, it was a joke, Jesus.."
    p "So what is it?"
    play music "audio/barilicious.ogg" fadein 3.0
    scene ima804 with dissolve
    bi "I wanted to invite you to my going away party."
    p "Going a...oh, yeah, Rivka told me you're moving away...sure, count me in, bro...when is it?"
    bi "Tonight, at The Gold Rush!"
    p "The Gold Ru...wait...isn't that the whorehouse in Chinatown?"
    bi "Strip Club...you know it, huh?"
    p "I've heard of it..."
    scene ima805 with dissolve
    bi "Is there something wrong?"
    p "Mmm..."

menu:
    "Nothing.":
        jump choice65a

    "AIDS! That place's full of AIDS!":
        jump choice65b

label choice65b:

    $ choice65b = True

    scene ima806 with dissolve
    p "I don't know man, I'm afraid of getting HIV to be honest."
    bi "But you won't have to do anything...maybe just pay for a lap dance for your buddy..."
    p "Sorry, man, I'm good."
    scene ima808 with dissolve
    bi "I knew you were a pussy!"
    scene ima809 with dissolve
    p "Pussy?! I saved your life, you ungrateful bitch!"
    scene ima809a with dissolve
    p "You know what, Billy? Fuck you!"
    scene ima809b with hpunch
    stop music
    play sound "audio/iphonehangup.ogg"
    pause
    bi "Hello?"
    bi "Oh, yeah? Well...uhm...fuck you, too..."
    scene ima810 with dissolve
    bi "Yeah, who had the last word, bitch?"

    scene black with Dissolve(3.0)

    play music "audio/season.ogg" volume 0.8
    scene ima352 with dissolve
    sa "What did your mom say, baby?"
    p "She got so angry, she wants me to keep studying, but there's not much she can do, it's my life."
    sa "She just wants what's best for you and, in her mind, studying is."
    scene ima353 with dissolve
    p "I know, but you can study at any age...to be a soccer player you only have like ten good years."
    sa "Yeah, it's a short career, but very profitable, isn't it?"
    p "Well, only really good players make millions...the average ones have comfortable lives..."
    p "But I don't think money's the reason why I want to do it...I simply love football!"
    scene ima354 with dissolve
    sa "Never lose that genuine feeling, cat! You know I'm going to all your matches, right?"
    scene ima355 with dissolve
    p "Haha, come here...I'll have to score in every single match then!"
    sa "You'll have ninety minutes to do it, that's more than enough."
    p "Someone's been reading the rules!"
    sa "Haha, it's not rocket science."
    scene ima356 with dissolve
    sa "You know I'm going to miss you in class, right?"
    p "I'll go see you whenever that happens, babe..."
    sa "I want to be with you forever, cat...do you know what \"forever\" is?"
    p "What."
    sa "The sum of nows..."
    sa "Just like this one."

    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    pause

    jump ep5

label choice65a:

    $ choice65a = True

    scene ima806 with dissolve
    p "No, nothing, I'll meet you there."
    scene ima807 with dissolve
    bi "Sweet! Later, bruh!"
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    play music "audio/stripclub.mp3"
    scene ima811 with Dissolve(1.5)
    pause
    scene ima812 with Dissolve(1.5)
    pause
    scene ima813 with Dissolve(1.5)
    pause
    scene black with dissolve
    scene ima814 with dissolve
    uk "Welcome, gentlemen, we've been expecting you..."
    mt "Hi, Elle, you got everything?"
    scene ima815 with dissolve
    el "Hi, Daniel my love, yes, the girls you requested are ready."
    mt "Good, good..."
    pt "The fuck?"
    pt "Wait, I've seen her face somewhere...can't remember right now..."
    scene ima816 with dissolve
    mt "I got you, Billy! Tonight, you're gonna lose your..."
    scene ima817 with dissolve
    bi "Shuuuushhhh! Don't say it out loud."
    mt "Sorry, man..."
    scene ima818 with dissolve
    el "My love, you want me to go get the girls?"
    mt "Yes, Elle, thanks, you can proceed..."
    el "Right away, my love!"
    scene ima819 with dissolve
    pause 1
    scene ima820 with dissolve
    scene ima819 with dissolve
    pt "She knows her business, no doubt about it..."
    scene black with dissolve
    scene ima821 with dissolve
    mt "Wait to see the girls I chose: fucking hot!"
    bi "This's gonna be so awesome!!!"
    mt "You'd better have fun, brothers, we have the whole place to ourselves and I even got you the VIP private show! You're welcome!"
    p "How did you pull that off, brother? It must be so expensive..."
    mt "Don't worry about it, business is going well."
    p "Business? What business? We haven't talked lately, bro..."
    stop music fadeout 3.0
    scene ima822 with dissolve
    bi "You can catch up anytime, the show's about to start!"
    el "Lights please, Rocko...Lay back and live your dreams, gentlemen!"

    play music "audio/techhouseinfra.ogg" volume 0.8
    scene ima823 with dissolve
    el "Here comes one of the sexiest girls in the whole city, our Rookie of the Month..."
    scene ima824 with dissolve
    el "She recently went viral showing off her twerking moves on Pik Pok..."
    mt "Ooohhh, yeah, I saw her video!"
    el "Gentlemen, she's your...Destiny!"
    scene ima825 with dissolve
    de "Hi, guys..."
    bi "Oh, my god, you're a goddess!"
    scene ima826 with dissolve
    de "Hahaha, thank you, bae."
    scene ima828 with dissolve
    bi "You lucky son of a bitch, she's so into you!"
    scene ima827 with dissolve
    p "Bro, this's a strip club, she's into everyone, she gets paid for pretending..."
    scene ima830 with dissolve
    el "Not yet, beautiful, save that for later."
    pt "I wanted to see that ass..."
    scene ima829 with dissolve
    el "Magnificent as usual, Destiny...come down here with me, beauty."
    scene black with dissolve
    scene ima831 with dissolve
    el "Now coming right out to the stage...Tiffany!"
    el "Black never looked so good..."
    scene ima833 with dissolve
    el "The finest ass in town, gentlemen!"
    scene ima832 with dissolve
    ti "Are you looking to have some fun tonight, big boys?"
    bi "Yes!"
    scene ima834 with dissolve
    ti "Who's ready for a lap dance?"
    bi "I am!"
    scene ima835 with dissolve
    ti "Can you handle this?"
    bi "Yes!"
    scene ima836 with dissolve
    mt "I don't think you can, Billy...she's more like my size."
    bi "Shut up!"
    scene ima837 with dissolve
    el "That's enough, Tiff, come join us...lights, please Rocko."
    scene black with dissolve
    scene ima838 with dissolve
    el "Up coming to the stage next is...Miss Fan Favorite for three consecutive years..."
    scene ima839 with dissolve
    el "Pia!"
    pi "Hi, guys!"
    scene ima840 with dissolve
    bi "Woooowww! I think I found my one!"
    scene ima841 with dissolve
    mt "She's so sexy!"
    bi "Easy, bro, she's taken!"
    scene ima842 with dissolve
    bi "Yeah, I'm in love!"
    p "You fall in love at brothels, Billy? For real? You also kiss prostitutes, right?"
    mt "Hahaha...Rule number one, Billy: never use your mouth with a whore..."
    bi "Why not?"
    scene ima843 with dissolve
    el "Wonderful, Pia!"
    el "You all get on the stage, girls."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene ima844 with Dissolve(2.0)
    play music "audio/rockjoy.ogg" volume 0.7
    mt "Time to pick, brothers..."
    bi "Why shouldn't we kiss prostitutes?"
    p "Really?"
    mt "It's better not to think too much of it..."
    bi "Tell me!"
    mt "How many men you think have used them before you? You'll be using your mouth where many others came..."
    bi "Shit! That's hot!"
    p "What the fuck?!"
    mt "Pick now, Billy!"
    scene ima846 with dissolve
    mt "Would it be Tiffany and her big ass?"
    bi "That big ass scares me..."
    mt "Scares you?"
    bi "Yeah, uhmmm...perhaps she's too much to handle as you said..."
    p "Haha."
    scene ima847 with dissolve
    p "How about Destiny? I didn't notice those eyes before..."
    bi "She's pretty, isn't she? I want to see her naked!"
    p "You're not the only one..."
    scene ima845 with dissolve
    mt "Oh, no, Billy, you don't want her for your first....ahem...ahemm...she's the most popular girl around here..."
    bi "Like a celebrity? Yeah, look at her!"
    p "No, Billy, you don't get it."
    mt "She's super famous, Billy...like a pornstar."
    bi "Shut up!"
    scene ima848 with dissolve
    bi "Mrs. Elle, I'm going with Pia!"
    el "Great choice, handsome!"
    scene ima849 with dissolve
    el "Pia, sweetie, come down here."
    scene ima850 with dissolve
    pi "Come on, cutie, follow me."
    bi "Yeah, before that, I have one question to ask..."
    pi "Yeah?"
    bi "What's your body count?"
    stop music
    play sound "audio/scratch.ogg"
    scene ima851 with vpunch
    scene ima851 with vpunch
    pi "What?!"
    bi "Your body count...you know, how many men have..."
    scene ima852 with dissolve
    mt "Billy! What the hell, man?! You're embarrasing us!"
    bi "What...we were just talking about it..."
    scene ima853 with dissolve
    ti "Haha, what's wrong with this guy? Hey, big boy, you wanna know MY body count?"
    bi "Wouldn't hurt."
    ti "Two."
    bi "An hour?"
    scene ima854 with dissolve
    mt "Billy!!"
    el "Rocko!"
    scene ima855 with dissolve
    el "This gentleman needs to leave...show him out, please."
    pt "Fuck! I knew this would happen, Billy's so fucking stupid..."
    play sound "audio/slap1.ogg"
    scene ima856 with hpunch
    p "Move, Billy."
    bi "Hey! My neck!"
    p "Elle, I'm sorry, I don't think that's gonna be necessary...uhm...Billy here is...I didn't want to say it, but...uhm...he's mentally challenged. He has this condition..."
    play sound "audio/punch.ogg"
    mt "Move, Billy."
    bi "Ouch! What the fuck?!"
    scene ima857 with dissolve
    mt "Oh, yes, Elle! Billy's got this...chronic...intellectual...disability? Yes! Chronic Intellectual Disability! CID!"
    el "Never heard of it, but still...he's upsetting my girls. Disrespect is something I won't tolerate, my love, you know it. Besides, I don't think any of my girls would like to..."
    scene ima858 with dissolve
    ti "I want him, Elle! Give me an hour with the retard, I'll teach him a lesson."
    bi "Hey!"
    scene ima858 with vpunch
    may "Shut up, Billy!!!"
    el "Well, if you want him, he's all yours, Tiff..."
    scene black with Dissolve(1.5)
    scene ima859 with dissolve
    mt "Ok, brother, you're next..."
    p "Finally..."

menu:
    "Pia.":
        jump choice66a

    "Destiny.":
        jump choice66b

label choice66a:

    $ choice66a = True

    pt "Yeah, let's see what Miss Fan Favorite got for me..."
    scene black with Dissolve(1.5)

label piasex1:

    if _in_replay:
        $ pf = persistent.p

    play music "audio/sensual8.mp3" volume 0.8
    scene ima960 with dissolve
    pi "Ok, dude, I don't have all night, it's gonna be a thousand dollars."
    scene ima960 with hpunch
    p "1K!!! I don't know the prices for those services, but sounds really expensive..."
    pi "That's what I charge, you want it or not?"

    scene ima961:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "Well..."

menu:
    "All right.":
        jump choice67a

    "I need to know your body count first...":
        jump choice67b

label choice67a:

    $ choice67a = True

    scene ima970 with dissolve
    pi "You'll see it's totally worth it."
    scene ima972 with vpunch
    p "Come here!"
    scene ima972c with vpunch
    p "Oooh, those nipples got hard..."
    scene ima971a with dissolve
    p "Let me see what I'm paying for..."
    scene ima971 with vpunch
    p "Nice..."
    p "Make me come now."

    scene ima973 with dissolve

    scene ima973:
        pause 0.0084
        "ima973a"
        pause 0.0084
        "ima973b"
        pause 0.0176
        "ima974"
        pause 0.0176
        "ima974a"
        pause 0.0176
        "ima974b"
        pause 0.0176
        "ima975"
        pause 0.0176
        "ima976"
        pause 0.0176
        "ima976a"
        pause 0.0176
        "ima977"
        pause 0.0176
        "ima978"
        pause 0.0176
        "ima979"
        pause 0.0176
        "ima980"
        pause 0.0176
        "ima981"
        pause 0.0176
        "ima982"
        pause 0.0176
        "ima983"
        pause 0.0176
        "ima984"
        pause 0.0176
        "ima985"
        pause 0.0176
        "ima986"
        pause 0.0176
        "ima987"
        pause 0.0176
        "ima988"
        pause 0.0176
        "ima989"
        pause 0.0176
        "ima990"
        pause 0.0176
        "ima991"
        pause 0.0176
        "ima992"
        pause 0.0176
        "ima993"
        pause 0.0176
        "ima994"
        pause 0.0176
        "ima995"
        pause 0.0176
        "ima996"
        pause 0.0176
        "ima997"
        pause 0.0176
        "ima997a"
        pause 0.0176
        "ima998"
        pause 0.0084
        "ima998a"
        pause 0.0084
        "ima999"
        pause 0.0084
        "ima999a"
        pause 0.0084
        "ima1000"
        pause 0.0084
        "ima1000a"
        pause 0.0084
        "ima1001"
        pause 0.0084
        "ima1002"
        pause 0.0084
        "ima1003"
        pause 0.0084
        repeat
    pause

    p "Yeah, that's what I'm talking about..."
    p "You're such a dirty fuck!"

    scene ima1007:
        pause 0.0084
        "ima1008"
        pause 0.0176
        "ima1009"
        pause 0.0176
        "ima1010"
        pause 0.0176
        "ima1011"
        pause 0.0176
        "ima1012"
        pause 0.0176
        "ima1013"
        pause 0.0176
        "ima1014"
        pause 0.0176
        "ima1015"
        pause 0.0176
        "ima1016"
        pause 0.0176
        "ima1017"
        pause 0.0176
        "ima1018"
        pause 0.0176
        "ima1019"
        pause 0.0176
        "ima1020"
        pause 0.0176
        "ima1021"
        pause 0.0176
        "ima1022"
        pause 0.0176
        "ima1023"
        pause 0.0176
        "ima1024"
        pause 0.0176
        "ima1025"
        pause 0.0176
        "ima1026"
        pause 0.0176
        "ima1027"
        pause 0.0176
        "ima1028"
        pause 0.0176
        "ima1029"
        pause 0.0176
        "ima1030"
        pause 0.0176
        "ima1031"
        pause 0.0176
        "ima1032"
        pause 0.0176
        "ima1033"
        pause 0.0176
        "ima1034"
        pause 0.0176
        "ima1035"
        pause 0.0176
        "ima1036"
        pause 0.0176
        "ima1037"
        pause 0.0176
        "ima1038"
        pause 0.0176
        "ima1039"
        pause 0.0176
        "ima1040"
        pause 0.0176
        "ima1041"
        pause 0.0176
        "ima1042"
        pause 0.0176
        "ima1043"
        pause 0.0084
        "ima1044"
        pause 0.0084
        "ima1045"
        pause 0.0084
        "ima1046"
        pause 0.0084
        "ima1047"
        pause 0.0084
        "ima1048"
        pause 0.0084
        repeat
    pi "You wanna cum inside your dirty bitch?"
    p "Yeah..."

    scene ima1007:
        pause 0.0111
        "ima1008"
        pause 0.0111
        "ima1009"
        pause 0.0111
        "ima1010"
        pause 0.0111
        "ima1011"
        pause 0.0111
        "ima1012"
        pause 0.0111
        "ima1013"
        pause 0.0111
        "ima1014"
        pause 0.0111
        "ima1015"
        pause 0.0111
        "ima1016"
        pause 0.0111
        "ima1017"
        pause 0.0111
        "ima1018"
        pause 0.0111
        "ima1019"
        pause 0.0111
        "ima1020"
        pause 0.0111
        "ima1021"
        pause 0.0111
        "ima1022"
        pause 0.0111
        "ima1023"
        pause 0.0111
        "ima1024"
        pause 0.0111
        "ima1025"
        pause 0.0111
        "ima1026"
        pause 0.0111
        "ima1027"
        pause 0.0111
        "ima1028"
        pause 0.0111
        "ima1029"
        pause 0.0111
        "ima1030"
        pause 0.0111
        "ima1031"
        pause 0.0111
        "ima1032"
        pause 0.0111
        "ima1033"
        pause 0.0111
        "ima1034"
        pause 0.0111
        "ima1035"
        pause 0.0111
        "ima1036"
        pause 0.0111
        "ima1037"
        pause 0.0111
        "ima1038"
        pause 0.0111
        "ima1039"
        pause 0.0111
        "ima1040"
        pause 0.0111
        "ima1041"
        pause 0.0111
        "ima1042"
        pause 0.0111
        "ima1043"
        pause 0.0111
        "ima1044"
        pause 0.0084
        "ima1045"
        pause 0.0084
        "ima1046"
        pause 0.0084
        "ima1047"
        pause 0.0084
        "ima1048"
        pause 0.0111
        repeat
    pi "Cum in your dirty bitch!"

    scene ima973:
        pause 0.0076
        "ima973a"
        pause 0.0076
        "ima973b"
        pause 0.0133
        "ima974"
        pause 0.0133
        "ima974a"
        pause 0.0133
        "ima974b"
        pause 0.0133
        "ima975"
        pause 0.0133
        "ima976"
        pause 0.0133
        "ima976a"
        pause 0.0133
        "ima977"
        pause 0.0133
        "ima978"
        pause 0.0133
        "ima979"
        pause 0.0133
        "ima980"
        pause 0.0133
        "ima981"
        pause 0.0133
        "ima982"
        pause 0.0133
        "ima983"
        pause 0.0133
        "ima984"
        pause 0.0133
        "ima985"
        pause 0.0133
        "ima986"
        pause 0.0133
        "ima987"
        pause 0.0133
        "ima988"
        pause 0.0133
        "ima989"
        pause 0.0133
        "ima990"
        pause 0.0133
        "ima991"
        pause 0.0133
        "ima992"
        pause 0.0133
        "ima993"
        pause 0.0133
        "ima994"
        pause 0.0133
        "ima995"
        pause 0.0133
        "ima996"
        pause 0.0133
        "ima997"
        pause 0.0133
        "ima997a"
        pause 0.0133
        "ima998"
        pause 0.0076
        "ima998a"
        pause 0.0076
        "ima999"
        pause 0.0076
        "ima999a"
        pause 0.0076
        "ima1000"
        pause 0.0076
        "ima1000a"
        pause 0.0076
        "ima1001"
        pause 0.0076
        "ima1002"
        pause 0.0076
        "ima1003"
        pause 0.0076
        repeat
    pause

    p "Shit! You're hot..."
    pi "Cum in my pussy, cum in my pussy!"

    scene ima1004 with vpunch
    scene ima1004 with vpunch
    pi "Aaahh, yes!"
    stop music fadeout 3.0
    scene ima1005 with vpunch
    p "Fuck!"
    p "That was money well spent..."
    scene ima1006 with dissolve
    pi "Come back next week, my pussy will be waiting for you...I want YOU again!"
    pt "Me? My money you mean..."

    jump endstrip

label choice67b:

    $ choice67b = True

    scene ima962 with dissolve
    pi "Rocko!"
    pt "Haha, the hell with this bitch, I'm not paying for sex!"
    stop music fadeout 3.0
    scene black with dissolve
    $ renpy.end_replay()

    scene ima963 with dissolve
    el "It's ok, Rocko..."
    scene ima964 with dissolve
    p "Jesus, Rocko, chill out...I didn't do anything, ask her."
    scene ima965 with dissolve
    el "So tell me what happened? You don't like my girls?"
    p "Oh, no, Elle, they're all pretty sexy, it's just me...I'm not used to this kind of interaction..."
    el "What do you mean?"
    p "I'm not sure..."
    scene ima966 with dissolve
    el "I bet you're like my ex-husband: don't know what to do when a woman is more straightforward than you, right? You like making the first move, being the dominant one..."
    p "Yeah, kind of...I know where I am, of course, but...no offense, I don't like fake interest if you know what I mean..."
    scene ima967 with dissolve
    el "I get it, these places are not for everybody...well, I guess I won't be seeing you around here again."
    scene ima968 with dissolve
    p "Who knows? Maybe next time you introduce me to a real classy woman..."
    scene ima969 with dissolve
    el "Haha."
    pt "Dude! You're my idol!"

    scene black with Dissolve(2.0)
    play music "audio/beat3.ogg"
    scene ima950 with dissolve
    bi "Brothers! I have great news..."
    mt "What happened to your shirt?"
    scene ima951 with dissolve
    bi "I found my soulmate and...guess what?"
    bi "I'm getting married!"
    p "Haha."
    mt "He's being serious, man..."
    p "Get out of here, he's joking."
    scene ima952 with dissolve
    mt "Trust me, you don't know him as much as I do."
    scene ima953 with dissolve
    mt "Come here, Billy, I want to talk to you real quick..."
    bi "Whatever you're gonna say, you can say it in front of my wife, brother."
    mt "Yeah, I'd rather not, let's discuss it on our way home..."
    scene ima954 with dissolve
    bi "You go ahead, my homies, I'm spending the night with my Tiff."
    p "{size=-5}You're gonna wake up without your wallet...{/size}"
    scene ima955 with dissolve
    bi "Come again?"
    scene ima956 with dissolve
    mt "Billy, I don't think you realize that Tiffany here...your future wife...works in a whorehouse."
    pt "Uhum, probably, Metal already fucked your wife, dude..."
    scene ima957 with dissolve
    bi "Worked: I'm gonna take her out of that life!"
    pt "Jesus, this dude's exhausting...I've heard enough."
    scene ima958 with dissolve
    p "Good luck with that, Billy, I wish you two the best."
    scene ima959 with dissolve
    bi "Thanks, brother! You're scoring points to be my best man!"
    p "I'm good, Billy, I'm good..."

    stop music fadeout 3.0

    scene black with Dissolve(3.0)

    play music "audio/season.ogg" volume 0.8
    scene ima352 with dissolve
    sa "What did your mom say, baby?"
    p "She got so angry, she wants me to keep studying, but there's not much she can do, it's my life."
    sa "She just wants what's best for you and, in her mind, studying is."
    scene ima353 with dissolve
    p "I know, but you can study at any age...to be a soccer player you only have like ten good years."
    sa "Yeah, it's a short career, but very profitable, isn't it?"
    p "Well, only really good players make millions...the average ones have comfortable lives..."
    p "But I don't think money's the reason why I want to do it...I simply love football!"
    scene ima354 with dissolve
    sa "Never lose that genuine feeling, cat! You know I'm going to all your matches, right?"
    scene ima355 with dissolve
    p "Haha, come here...I'll have to score in every single match then!"
    sa "You'll have ninety minutes to do it, that's more than enough."
    p "Someone's been reading the rules!"
    sa "Haha, it's not rocket science."
    scene ima356 with dissolve
    sa "You know I'm going to miss you in class, right?"
    p "I'll go see you whenever that happens, babe..."
    sa "I want to be with you forever, cat...do you know what \"forever\" is?"
    p "What."
    sa "The sum of nows..."
    sa "Just like this one."

    stop music fadeout 3.0

    scene black with Dissolve(3.0)
    pause

    jump ep5

label choice66b:

    $ choice66b = True

    pt "Yeah, the Rookie of the Month, she's not so worn out yet, hehe..."
    scene black with Dissolve(1.5)

label destinysex1:

    if _in_replay:
        $ pf = persistent.p

    play music "audio/ukgarage.ogg"
    scene ima860 with dissolve
    de "Hey, handsome, you have good taste..."
    p "I had no choice, you're really hot, Destiny."

    scene ima861:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    de "I get that a lot around here."
    p "I bet you do...sorry, I'm generally more original, but I'm a little nervous...it's my first time in a place like this..."
    de "You don't look nervous."
    p "I can pretend really well."
    scene ima862 with dissolve
    de "Let me help you unwind."
    scene ima863 with dissolve
    pause 1.5
    scene ima864 with hpunch
    de "Tadaaa!"
    p "Holy shit!"
    de "Better?"
    p "I love the view."
    de "Hehehe."
    scene ima865 with dissolve
    p "Mmmmphh...can I ask you a question?"
    de "My body count? Haha."
    p "Haha...uhmm...would I get into trouble if I touch you?"
    scene ima866 with dissolve
    de "Hehe, someone's impatient..."
    pt "You have no idea..."
    de "Unlike others, I don't have sex with clients if that's what you really wanted to know...just dance, handsome..."
    pt "Fuuuck! I don't want to leave blue-balled...why would anyone pay to get aroused only?"
    pt "And why would anyone pay for sex? Well, if you look like Billy probably you just have to..."
    pt "But I can get some action for free!"
    scene ima867 with dissolve
    de "You there?"
    p "Yeah, sorry, I was just...uhm...can you shake it?"

    scene ima867:
        pause 0.0206
        "ima868"
        pause 0.0206
        "ima869"
        pause 0.0206
        "ima870"
        pause 0.0206
        "ima871"
        pause 0.0206
        "ima872"
        pause 0.0206
        "ima873"
        pause 0.0206
        "ima874"
        pause 0.0206
        "ima875"
        pause 0.0206
        "ima876"
        pause 0.0206
        "ima877"
        pause 0.0206
        "ima878"
        pause 0.0206
        "ima879"
        pause 0.0206
        "ima880"
        pause 0.0206
        "ima881"
        pause 0.0206
        "ima882"
        pause 0.0206
        "ima883"
        pause 0.0206
        "ima884"
        pause 0.0206
        "ima885"
        pause 0.0206
        "ima886"
        pause 0.0206
        "ima887"
        pause 0.0206
        "ima887a"
        pause 0.0206
        "ima887b"
        pause 0.0206
        repeat
    pause

    de "Like this?"
    p "Yeah, exactly like that..."

    scene ima888:
        pause 0.0206
        "ima889"
        pause 0.0206
        "ima890"
        pause 0.0206
        "ima891"
        pause 0.0206
        "ima892"
        pause 0.0206
        "ima893"
        pause 0.0206
        "ima894"
        pause 0.0206
        "ima895"
        pause 0.0206
        "ima896"
        pause 0.0206
        "ima897"
        pause 0.0206
        "ima898"
        pause 0.0206
        "ima899"
        pause 0.0206
        "ima900"
        pause 0.0206
        "ima901"
        pause 0.0206
        "ima902"
        pause 0.0206
        "ima903"
        pause 0.0206
        "ima904"
        pause 0.0206
        "ima905"
        pause 0.0206
        "ima906"
        pause 0.0206
        "ima907"
        pause 0.0206
        "ima908"
        pause 0.0206
        "ima908a"
        pause 0.0206
        "ima908b"
        pause 0.0206
        repeat
    pause

    de "A little faster?"

    scene ima888:
        pause 0.0166
        "ima889"
        pause 0.0166
        "ima890"
        pause 0.0166
        "ima891"
        pause 0.0166
        "ima892"
        pause 0.0166
        "ima893"
        pause 0.0166
        "ima894"
        pause 0.0166
        "ima895"
        pause 0.0166
        "ima896"
        pause 0.0166
        "ima897"
        pause 0.0166
        "ima898"
        pause 0.0166
        "ima899"
        pause 0.0166
        "ima900"
        pause 0.0166
        "ima901"
        pause 0.0166
        "ima902"
        pause 0.0166
        "ima903"
        pause 0.0166
        "ima904"
        pause 0.0166
        "ima905"
        pause 0.0166
        "ima906"
        pause 0.0166
        "ima907"
        pause 0.0166
        "ima908"
        pause 0.0166
        "ima908a"
        pause 0.0166
        "ima908b"
        pause 0.0166
        repeat
    pause

    p "Fuck!"
    p "I'm sorry, I have to do this..."
    scene ima909 with hpunch
    de "Aaahhh!!!"
    scene ima910 with hpunch
    pause
    scene ima911 with dissolve
    de "Hey, you can't do that."
    p "Sorry, it's just that..."
    de "I could tell Rocko about it."
    p "No need...coming here was not a good idea, I'm not made to just watch...I'm about to...uhmm..."
    scene ima912 with dissolve
    de "To what?"
    scene ima913 with dissolve
    pause 1
    scene ima914 with dissolve
    de "I see...You know what? I like you! I can help you with that if you do something for me..."
    p "Do what?"
    de "I don't know yet, but you'll owe me a favor...what do you say?"
    p "Yeah, sure, whatever...I won't say no when the time comes."
    de "Goooood! We have a deal then!"
    scene black with dissolve
    scene ima915 with dissolve
    de "You're so ready, bad boy."
    p "Don't call me names, call me [p]."
    de "Ooohhh, I like that...[p]."
    scene ima916 with dissolve
    de "I've been naughty, baby, come on your naughty girl's tits, ok?"
    p "Sssss..."

    scene ima916:
        pause 0.0233
        "ima917"
        pause 0.0233
        "ima918"
        pause 0.0233
        "ima919"
        pause 0.0233
        "ima920"
        pause 0.0233
        "ima921"
        pause 0.0233
        "ima922"
        pause 0.0233
        "ima923"
        pause 0.0233
        "ima924"
        pause 0.0233
        "ima925"
        pause 0.0233
        "ima926"
        pause 0.0233
        "ima927"
        pause 0.0233
        "ima928"
        pause 0.0233
        "ima929"
        pause 0.0233
        "ima930"
        pause 0.0233
        "ima931"
        pause 0.0233
        "ima932"
        pause 0.0233
        "ima933"
        pause 0.0233
        "ima934"
        pause 0.0233
        "ima935"
        pause 0.0233
        "ima936"
        pause 0.0233
        "ima937"
        pause 0.0233
        "ima938"
        pause 0.0233
        "ima939"
        pause 0.0233
        "ima940"
        pause 0.0233
        "ima941"
        pause 0.0233
        "ima942"
        pause 0.0233
        "ima943"
        pause 0.0233
        "ima944"
        pause 0.0233
        "ima945"
        pause 0.0233
        "ima946"
        pause 0.0233
        repeat
    pause

    scene ima916:
        pause 0.0206
        "ima917"
        pause 0.0206
        "ima918"
        pause 0.0206
        "ima919"
        pause 0.0206
        "ima920"
        pause 0.0206
        "ima921"
        pause 0.0206
        "ima922"
        pause 0.0206
        "ima923"
        pause 0.0206
        "ima924"
        pause 0.0206
        "ima925"
        pause 0.0206
        "ima926"
        pause 0.0206
        "ima927"
        pause 0.0206
        "ima928"
        pause 0.0206
        "ima929"
        pause 0.0206
        "ima930"
        pause 0.0206
        "ima931"
        pause 0.0206
        "ima932"
        pause 0.0206
        "ima933"
        pause 0.0206
        "ima934"
        pause 0.0206
        "ima935"
        pause 0.0206
        "ima936"
        pause 0.0206
        "ima937"
        pause 0.0206
        "ima938"
        pause 0.0206
        "ima939"
        pause 0.0206
        "ima940"
        pause 0.0206
        "ima941"
        pause 0.0206
        "ima942"
        pause 0.0206
        "ima943"
        pause 0.0206
        "ima944"
        pause 0.0206
        "ima945"
        pause 0.0206
        "ima946"
        pause 0.0206
        repeat
    p "Your skin feels so soft...and those tits..."
    de "A hundred percent natural, baby!"

    scene ima916:
        pause 0.0206
        "ima917"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0206
        "ima918"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0206
        "ima919"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0206
        "ima920"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0206
        "ima921"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0206
        "ima922"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0206
        "ima923"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0206
        "ima924"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0206
        "ima925"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0206
        "ima926"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0206
        "ima927"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0206
        "ima928"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0206
        "ima929"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0206
        "ima930"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0206
        "ima931"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0206
        "ima932"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0206
        "ima933"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0206
        "ima934"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0206
        "ima935"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0206
        "ima936"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.010
        pause 0.0206
        "ima937"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0206
        "ima938"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0206
        "ima939"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0206
        "ima940"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0206
        "ima941"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0206
        "ima942"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0206
        "ima943"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0206
        "ima944"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0206
        "ima945"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0206
        "ima946"
        pause 0.0206
        repeat
    pause

    p "I'm so fucking close!"

    scene ima947 with flash
    scene ima947 with flash
    p "Aaahhh, fuck!"
    stop music fadeout 3.0
    scene ima948 with dissolve
    pause
    scene ima949 with dissolve
    p "That was really good, Destiny..."
    de "You're gonna have to come back next week for more, [p]!"
    p "We'll see about that..."

    jump endstrip

label endstrip:

    scene black with Dissolve(2.0)

    $ renpy.end_replay()

    play music "audio/beat3.ogg"
    scene ima950 with dissolve
    bi "Brothers! I have great news..."
    mt "What happened to your shirt?"
    scene ima951 with dissolve
    bi "I found my soulmate and...guess what?"
    bi "I'm getting married!"
    p "Haha."
    mt "He's being serious, man..."
    p "Get out of here, he's joking."
    scene ima952 with dissolve
    mt "Trust me, you don't know him as much as I do."
    scene ima953 with dissolve
    mt "Come here, Billy, I want to talk to you real quick..."
    bi "Whatever you're gonna say, you can say it in front of my wife, brother."
    mt "Yeah, I'd rather not, let's discuss it on our way home..."
    scene ima954 with dissolve
    bi "You go ahead, my homies, I'm spending the night with my Tiff."
    p "{size=-5}You're gonna wake up without your wallet...{/size}"
    scene ima955 with dissolve
    bi "Come again?"
    scene ima956 with dissolve
    mt "Billy, I don't think you realize that Tiffany here...your future wife...works in a whorehouse."
    pt "Uhum, probably, Metal already fucked your wife, dude..."
    scene ima957 with dissolve
    bi "Worked: I'm gonna take her out of that life!"
    pt "Jesus, this dude's exhausting...I've heard enough."
    scene ima958 with dissolve
    p "Good luck with that, Billy, I wish you two the best."
    scene ima959 with dissolve
    bi "Thanks, brother! You're scoring points to be my best man!"
    p "I'm good, Billy, I'm good..."
    stop music fadeout 3.0

    scene black with Dissolve(3.0)
    pause

    jump ep5
