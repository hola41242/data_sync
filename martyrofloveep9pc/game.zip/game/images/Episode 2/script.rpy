#Important Decisions
default choice21b = False
default choice28a = False
default choice28b = False
default choice38a = False



# Start Episode 2
label Ep2:
if choice11a:
    scene sc1 with dissolve
    pause 1.0
    scene sc2 with dissolve
    pt "What an awkward class that was...I don't think that's how a regular class is supposed to be...or at least I hope not..."
    scene sc4 with Dissolve(1.0)
    scene sc5 with Dissolve(1.0)
    cd "[p]!"
    scene sc6 with Dissolve(1.0)
    play music "audio/feliz.ogg"
    scene sc7 with dissolve
    p "Candy! I'm so happy to see you!"
    scene sc8 with dissolve
    cd "Me too! I can't believe you're finally here!"
    scene sc9 with dissolve
    cd "Oh, dude, I wanted you to be here since forever!"
    scene sc10 with dissolve
    cd "So how's your first day going?"
    p "I just finished a weird class..."
    cd "Uhu uhu..."
    p "...with a weird guy..."
    cd "Uhu uhu..."
    p "Listen, I'll tell you all about it later, right now I gotta get going. Do you know where room Z1 is?"
    cd "Your going the wrong way."
    p "Ok, can you take me there, please?"
    cd "Sure, brother!"
    p "Thanks, brother...you...you can let go now."
    cd "I won't! I'm comfortable here."
    p "Come on, bro! I'm already late!"
    cd "Only if you promise."
    p "What."
    cd "Promise."
    p "WHAT."
    cd "Just do it."
    p "Ok! I promise."
    cd "Hehehe...let's go!"
    scene black with dissolve
    scene sc11 with dissolve
    cd "Z1!"
    p "Thank you, Candy. Talk to you later, ok? Yours, mine?"
    cd "Mine. I'll get home by 7, after gym."
    p "Ok, ok. See ya!"

    jump philclass

if choice11b:
    scene sc1 with dissolve
    pause 1.0
    scene sc2 with dissolve
    pt "What an awkward class that was...I don't think that's how a regular class is supposed to be...or at least I hope not..."
    scene sc4 with Dissolve(1.0)
    scene sc5 with Dissolve(1.0)
    cd "[p]!"
    scene sc6 with Dissolve(1.0)
    play music "audio/feliz.ogg"
    scene sc7 with dissolve
    p "Candy! I'm so happy to see you!"
    scene sc8 with dissolve
    cd "Me too! I can't believe you're finally here!"
    scene sc9 with dissolve
    cd "Oh, dude, I wanted you to be here since forever!"
    scene sc10 with dissolve
    cd "So how's your first day going?"
    p "I just finished a weird class..."
    cd "Uhu uhu..."
    p "...with a weird guy..."
    cd "Uhu uhu..."
    p "Listen, I'll tell you all about it later, right now I gotta get going. Do you know where room Z1 is?"
    cd "Your going the wrong way."
    p "Ok, can you take me there, please?"
    cd "Sure, brother!"
    p "Thanks, brother...you...you can let go now."
    cd "I won't! I'm comfortable here."
    p "Come on, bro! I'm already late!"
    cd "Only if you promise."
    p "What."
    cd "Promise."
    p "WHAT."
    cd "Just do it."
    p "Ok! I promise."
    cd "Hehehe...let's go!"
    scene black with dissolve
    scene sc11 with dissolve
    cd "Z1!"
    p "Thank you, Candy. Talk to you later, ok? Yours, mine?"
    cd "Mine. I'll get home by 7, after gym."
    p "Ok, ok. See ya!"

    jump philclass

if choice10b:

    scene sc1 with dissolve
    pause 1.0
    scene sc2 with dissolve
    pt "What an awkward class that was...I don't think that's how a regular class is supposed to be...or at least I hope not..."
    scene sc4 with Dissolve(1.0)
    scene sc5 with Dissolve(1.0)
    cd "[p]!"
    scene sc6 with Dissolve(1.0)
    play music "audio/feliz.ogg"
    scene sc7 with dissolve
    p "Candy! I'm so happy to see you!"
    scene sc8 with dissolve
    cd "Me too! I can't believe you're finally here!"
    scene sc9 with dissolve
    cd "Oh, dude, I wanted you to be here since forever!"
    scene sc10 with dissolve
    cd "So how's your first day going?"
    p "I just finished a weird class..."
    cd "Uhu uhu..."
    p "...with a weird guy..."
    cd "Uhu uhu..."
    p "Listen, I'll tell you all about it later, right now I gotta get going. Do you know where room Z1 is?"
    cd "Your going the wrong way."
    p "Ok, can you take me there, please?"
    cd "Sure, brother!"
    p "Thanks, brother...you...you can let go now."
    cd "I won't! I'm comfortable here."
    p "Come on, bro! I'm already late!"
    cd "Only if you promise."
    p "What."
    cd "Promise."
    p "WHAT."
    cd "Just do it."
    p "Ok! I promise."
    cd "Hehehe...let's go!"
    scene black with dissolve
    scene sc11 with dissolve
    cd "Z1!"
    p "Thank you, Candy. Talk to you later, ok? Yours, mine?"
    cd "Mine. I'll get home by 7, after gym."
    p "Ok, ok. See ya!"

    jump philclass

if choice9b:

    play music "audio/feliz.ogg"
    scene sc3 with dissolve
    p "So she's why you wanted to take that class, huh? I should've guessed..."
    mt "Really cute, isn't she? I still can't believe they're going to Master Collins's event, I wanted to go with Ann!"
    scene sc3a with dissolve
    mt "Do you imagine it? Me, Ann, Master Collins..."
    p "I don't know why you said Master Collins there but...hey dude! We'll talk about it later, take me to Z1!"
    scene black with dissolve
    scene sc12 with dissolve
    mt "See you later, ok? There's this...something...I gotta do."
    p "No worries, bro, and thanks!"
    jump philclass

label philclass:

    stop music fadeout 3.0
    scene sc13 with dissolve
    pt "It's begun already..."
    scene sc14 with dissolve
    pt "Is that Ms. Know-it-all? Well, only those two empty seats left..."
    scene sc15 with dissolve

menu:
    "Talk to her.":
        jump choice13a

    "Sit down.":
        jump choice13b

label choice13a:
    scene sc15 with dissolve
    p "How many of your PROFESSORS are entrepreneurs?"
    scene sc16 with dissolve
    mk "Zero."
    p "You goddamn...wrong! Can I sit here?"
    mk "You can...you're ok...so far."
    scene black with dissolve
    scene sc17 with dissolve
    mk "You know you gave me quite a look back there in Business class."
    p "Yeah, I know, you were being...intense."
    mk "I take it as a compliment...you're honest, I like honest."
    p "I'm not down for intense, but you're ok...so far."
    mk "I'm Rivka."
    p "[p]."
    scene sc19 with dissolve
    p "This class is full."
    ri "The room is smaller."
    p "Yeah, it's another way to put it."
    ri "It's the right way."
    p "Jeez..."

    jump choice13_common

label choice13b:
    scene sc18 with dissolve
    pause
    scene sc17 with dissolve
    mk "You know you gave me quite a look back there in Business class."
    p "Yeah, I remember, you were being...intense."
    mk "I take it as a compliment...you're...honest, I like honest."
    p "I'm not down for intense."
    mk "I'm Rivka."
    p "[p]."
    scene sc19 with dissolve
    p "This class is full."
    ri "The room is smaller."
    p "Yeah, it's another way to put it."
    ri "It's the right way."
    p "Jeez..."

    jump choice13_common

label choice13_common:
    bv "Good morning! I'm sorry I'm late!"
    play music "audio/motivacional.ogg"
    scene sc20:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "OH{w=1.0} MY{w=1.0} GOD!"
    pt "Who is she?!"

    scene black with dissolve

    $ renpy.movie_cutscene("videos/Samantha.ogv")

    scene black with Dissolve(1.0)

    scene sc21 with dissolve
    il "I'm sorry I'm late Mr...Anderson, it won't happen again."
    ma "Good morning, Ms..."
    il "Revello! Samantha Revello."
    scene sc22 with dissolve
    ma "Do not worry, Ms. Revello. Come in and have a seat. It's good to see someone with manners when entering a room."
    scene sc23a with dissolve
    pt "My God!"
    scene sc23c with dissolve
    scene sc23d with dissolve
    scene sc23 with dissolve
    ri "You don't stand a chance."
    scene sc24 with dissolve
    p "Are...are you talking to..."
    ri "And she's coming."
    scene sc25 with dissolve
    sa "Hi!"
    p "Hi."
    pt "What's this? How come I feel so nervous all of a sudden?"
    sa "Is this seat free?"
    p "Ye...Yes."
    scene sc26 with dissolve
    pt "I can't believe how beautiful she is..."
    scene black with dissolve
    scene sc27 with dissolve
    ma "...That being said, I want you to discuss why you're here."
    scene sc27a with dissolve
    sa "What do you mean \"here\", Mr. Anderson? This class? College? Alive on Earth?"
    scene sc27b with dissolve
    pt "Yeah! What do you mean by \"here\", Mr. Anderson?"
    ma "Very insteresting question! I don't like guiding your minds into an answer. Just try to understand the complexity of this question,if any, and share as much as you want."
    scene black with dissolve
    scene sc30 with dissolve
    sa "What do you guys think he's referring to?"
    scene sc28 with dissolve
    ri "I don't know, ask your fan here."
    scene sc29 with dissolve
    ri "What do you think he's referring to?"
    p "Ahem, ahem, cough, cough, ahem."
    scene sc32 with dissolve
    p "Hi, I'm [p], I got your name earlier...Samantha. Just ignore my friend here."
    scene sc29 with dissolve
    ri "Friend?"
    scene sc34 with dissolve
    p "Anyways, answering your question, I'm going to interpret \"here\" as in college...I'm here to study I guess."
    scene sc29 with dissolve
    ri "Very deep."
    scene sc28 with dissolve
    ri "And you Samantha? Why are you here? I'm Rivka, by the way."
    scene sc30 with dissolve
    sa "Nice meeting you...if you want a profound answer let me think."
    scene sc34 with dissolve
    p "Take your time, no worries."
    scene sc33 with dissolve
    p "Why don't YOU share your answer, Rivka? Enlight us."

    scene sc40 with dissolve
    ri "Dubito ergo cogito, dubito ergo sum."

menu:
    "Pff, of course I get it.":
        jump choice14a

    "Uh?":
        jump choice14b

label choice14a:
    scene sc36 with dissolve
    p "\"I doubt therefore I think, I think therefore I am.\""
    scene sc41 with dissolve
    ri "You can translate, good."
    pt "This girl..."
    scene sc36 with dissolve
    p "Let me guess, you're going to major in Philosophy."
    scene sc40 with dissolve
    ri "Proudly. Let me guess, you want to be a businessman like Master Collins."
    sa "Who?"
    scene sc35 with dissolve
    ri "A professor we make fun of."
    sa "Oh, okay."
    jump choice14_common

label choice14b:
    scene sc42 with dissolve
    ri "That's what I thought."
    jump choice14_common

label choice14_common:

    scene sc40 with dissolve
    ri "Why are you taking this class anyways? I bet you don't even know what Philosophy means."
    p "You want a definition?"
    scene sc42 with dissolve
    ri "The etymology would be better."

menu:
    "Basic stuff.":
        jump choice15a

    "Ety...what?":
        jump choice15b

label choice15a:
    p "That's easy: it comes from the greek phílos which means..."

menu:
    "Plant.":
        jump choice16a

    "Love of.":
        jump choice16b

    "Study of.":
        jump choice16c

label choice16a:
    jump choice16_common

label choice16b:
    scene sc36 with dissolve
    pause
    jump sophia

label choice16c:
    jump choice16_common

label sophia:
    p "And sophía which means..."

menu:
    "Wisdom.":
        jump choice17a

    "Knowledge.":
        jump choice17b

    "Intelligence.":
        jump choice17c

label choice17a:
    scene sc36 with dissolve
    pause
    jump choice17_common

label choice17b:
    jump choice16_common

label choice17c:
    jump choice16_common

label choice15b:
    jump choice15_common

label choice16_common:
    scene sc42 with dissolve
    ri "You fooled me for a second."
    jump continue

label choice15_common:
    scene sc40 with dissolve
    ri "My point exactly."
    jump continue

label choice17_common:
    scene sc41 with dissolve
    ri "You're ok..."

label continue:
    stop music fadeout 3.0
    scene sc30 with dissolve
    sa "Guys! You went off topic...any other reason why you're here? Rivka?"
    scene sc35 with dissolve
    ri "To find interesting people."
    p "How's that working out?"
    scene sc41 with dissolve
    ri "Not good, [p], not good."
    scene sc37 with dissolve
    sa "Not well."
    p "Ha!"
    sa "Well, I'm HERE at college to major in Psychology and HERE in this class...to learn mainly, you know: \"Philosophy is at once the most sublime and the most trivial of human pursuits\"."
    scene sc38 with dissolve
    ri "Hey! The unexamined life is not worth living!"
    scene sc39 with dissolve
    ri "But it's an interesting quote. I'll give you that."
    scene black with Dissolve(1.5)
    scene sc27 with dissolve
    ma "I'll be closing the door next time so please, don't be late!"
    scene sc43 with dissolve
    sa "Nice meeting you guys! See you tomorrow!"
    ri "Bye."
    p "Bye, Samantha!"
    scene sc44 with dissolve
    p "Do yo have more classes?"
    ri "Later, I'm going to the library now. And you?"
menu:
    "Walk her there.":
        jump choice18a

    "Try to find Samantha.":
        jump choice18b

label choice18a:
    p "I'm free too. I'd like to know where the library is, can I walk with you?"
    ri "If you want to, I don't mind."
    scene black with dissolve
    play music "audio/aesthetic.ogg"
    scene sc45 with dissolve
    ri "That's a big backpack."
    p "Yeah, I know, I've had it since high school."
    ri "I can tell."
    scene sc46 with dissolve
    p "And how come you didn't bring anything?"
    scene sc47 with dissolve
    ri "I don't need anything, everything is in here."
    scene sc48 with dissolve
    ri "And it's the first day...what do you have in there anyways? A laptop?"
    p "Not really, just a pen and my notebook."
    ri "My point exactly."
    scene black with dissolve
    scene sc49 with dissolve
    ri "Well, that's the library. Are you going in?"
    p "No, not today, I'm going home now."
    ri "Oh, ok. See you around then."
    p "Yeah, see ya and thanks for the short tour, Rivka."
    scene black with Dissolve(1.5)

    jump choice18_common

label choice18b:
    p "I'm going home."
    ri "All right, see you around."
    p "See you soon, Rivka."
    play music "audio/season.ogg" volume 0.8
    scene black with dissolve
    pt "There she is!"
    scene sc50 with dissolve
    pt "What am I doing? I feel like I'm stalking her. I should've waited, it's too soon, we've just met...oh god, all these thoughts."
    scene sc51 with dissolve
    pt "What am I gonna say to her? I'm gonna scare her. It's better not to do it...oh, come on, man, grow a pair!"
    scene sc52 with dissolve

if choice5a:
    pt "Damn, she's meeting her friend. Wait a sec, isn't that...?"
    scene sc52a with dissolve
    pt "Oh, yeah...well, making a U-turn before they see me."
    jump jess

else:
    pt "Noooooo...missed opportunity, abort mission."
    jump jess

label jess:

    scene sc52 with dissolve
    scene sc53 with dissolve
    an "Jess, isn't that [p]?"
    js "He has his mind in the clouds I guess...come on, take his left!"
    an "Hehe, alright!"
    scene sc54 with dissolve
    p "Ann?"
    scene sc55 with dissolve
    p "Jessica?"
    scene sc56 with dissolve
    js "Metal?"
    p "Uh?"
    an "Ummm...prey?"
    scene sc57 with dissolve
    p "What?!"
if choice10b:
    p "We just won the game together!"
    jump hehe

if choice11a:
    p "We just won the game together!"
    jump hehe

label hehe:
    an "Hehe."
    scene sc58 with dissolve
    p "I'm out of here."
    js "We're just messing with you, [p]!"
    p "Yeah, yeah, I'm going home anyways."
    an "Sorryyyy..."

    scene black with Dissolve(2.0)
    jump choice18_common

label choice18_common:

    scene sc59 with dissolve
    pt "What a long day...I'm really tired."
    scene sc60 with dissolve
    pt "I don't know about the classes, but I've met cool people today: Jessica, Ann, even Rivka wasn't that bad..."
    scene sc61 with dissolve
    pt "And Samantha...wow, she was really something. She can definitely make this whole college thing worth it."
    stop music fadeout 3.0
    scene sc62 with dissolve
    pt "Finally home! I'm starving..."

if choice9b:
    scene sc62a with dissolve
    pt "Who's texting me? Candy...she wants me to visit her..."

    jump menu1

if choice10b:
    pt "Oh! I told Candace, I'll go visit her..."

    jump menu1

if choice11a:
    pt "Oh! I told Candace, I'll go visit her..."

    jump menu1

if choice11b:
    pt "Oh! I told Candace, I'll go visit her..."

    jump menu1

label menu1:

menu:
    "Go see her.":
        jump choice19a

label choice19a:
    pt "I'll take a shower first."
    scene black with Dissolve(1.0)
    jump candyhome

label candyhome:
    play sound "audio/doorbell.ogg"
    scene sc63a with dissolve
    mmi "Yes?"
    p "Hi, Mrs. Miller. Is Candy home?"
    mmi "Oh, hi, honey. Yes, yes, Come in."
    scene sc63 with dissolve
    pause 1.0
    scene sc64 with dissolve
    pause 1.0
    play music "audio/inspired.ogg"
    scene sc65 with dissolve
    p "Hey, my boy!"
    scene sc66 with dissolve
    pause
    scene sc67 with dissolve
    p "You missed me, Argos? Of course you did, I'm your father! Where's your mom? Let's go see her."
    scene black with dissolve
    scene sc68 with dissolve
    p "Look who I found outside, Mrs. Miller."
    mmi "My baby! He loves you, doesn't he?"
    scene sc69 with dissolve
    mmi "And son it's the second time you call me Mrs. Miller...do I have to remind you I'm single now? You can call me Ms. Ha...you know what, just call me Sharon from now on."
    p "I'm glad to see you with that attitude, Mrs...Sharon. It feels weird to call you that though."
    scene sc70 with dissolve
    sh "Well, this is the new me, you'd better get used to it."

menu:
    "Ask where Candace is.":
        jump choice21a

    "Keep talking to her.":
        jump choice21b

label choice21a:

    p "And Candy? In the shower?"
    scene sc71 with dissolve
    sh "I think she's in her room, go see her, she was waiting for you."
    p "Ok. Good to see you...Sharon."
    stop music fadeout 3.0

    jump choice21_common

label choice21b:

    $ choice21b = True

    scene sc72 with dissolve
    sh "Have a sit, son. Would you like anything to drink?"
    p "I'm ok, thanks..."

menu:
    "Ask about her job.":
        jump choice22a

    "Ask about her divorce.":
        jump choice22b

label choice22a:
    p "How was work today?"
    scene sc74 with dissolve
    sh "Ugh, a lot of problems...it's really hard to deal with victims of abuse, but I'd rather not get into it right now."
    jump choice22_common

label choice22b:
    p "How are you handling your new single life?"
    scene sc73 with dissolve
    sh "I know it's not ok to say it, but being married to Paul was unbearable in the end. I feel great now! So much lighter!"
    p "Yeah, I can see it."
    jump choice22_common

label choice22_common:

    scene black with dissolve
    scene sc75 with dissolve
    sh "And you? How was your first day? I'm glad you finally joined Candy at college."
    p "Yeah, it's not like we take classes together, you know, but it's good to know she's around."
    p "And my first day?...it was all right I guess. I met a couple of cool girls..."
    scene sc76 with dissolve
    sh "Girls, huh? Does Candy know?"
    p "What? Why you ask that?"
    scene sc77 with dissolve
    sh "Just asking, you know my Candy is...let's say overprotective with you."
    p "She's the best!"
    scene sc78 with dissolve
    sh "So when are you going to date my daughter?"
    p "What?! She's my best friend, you know that."
    sh "That makes things even easier for you."
    p "I meant I don't see her that way."
    scene sc79 with dissolve
    pt "How come she puts me on the spot like that?"
    scene sc80 with dissolve
    sh "I hope that's true, [p]."
    scene sc81 with dissolve
    sh "Sometimes we don't appreciate what we have until it's taken away from us..."
    pt "Oh, I believe she's projecting...or not?"
    stop music fadeout 3.0

menu:
    "Ask to know.":
        jump choice23a

    "Leave it there.":
        jump choice23b

label choice23a:

    scene sc79 with dissolve
    p "Did anything happen to you?"
    scene sc82 with dissolve
    sh "What do you mean?"
    p "Perhaps...you didn't appreciate someone or someone didn't appreciate you."
    scene sc83 with dissolve
    sh "You got that from your mother, you know that?"
    scene sc84 with dissolve
    p "I've been told that before, can't help it. I'm used to being HER psychologist. After seeing so many patients, I guess she wanted someone to listen to her too."
    p "Well, I'd better check on Candace before she falls asleep. It was nice talking to you...Sharon."
    scene sc77 with dissolve
    sh "Same here. Oh, and son, turn off the lights when you leave, ok? I'll be sleeping for sure."
    p "Alright, I'll do it."

    jump choice21_common

label choice23b:

    scene sc78 with dissolve
    p "Thanks for the advice, Sharon. I'll go talk to Candy now, it's getting late."
    sh "Sure, [p], go!"

    jump choice21_common

label choice21_common:

    scene black with Dissolve(1.0)
    play sound "audio/knock.ogg"
    scene sc85 with dissolve
    p "Candy?"
    cd "No, it's Metal...come on in!"
    scene black with dissolve
    play music "audio/beat1.ogg"
    scene sc86 with dissolve
    p "I was just asking in case you were naked, butthead."
    cd "I know, give me a sec."
    scene sc87 with dissolve
    p "What are you doing?"
    cd "Just sending a message."
    scene sc88 with dissolve
    cd "Do you.."
    scene sc89 with dissolve
    pause
    scene sc90 with dissolve
    cd "Let me take a picture of you two."
    p "Aight."
    scene sc91 with dissolve
    play sound "audio/shutter.ogg"
    pause
    cd "One more with the flash on."
    scene sc92 with dissolve
    play sound "audio/shutter.ogg"
    scene sc92a with dissolve
    scene sc92b
    scene sc91 with dissolve
    cd "Nice!"
    scene sc93 with dissolve
    cd "Aww, you look adorable."
    p "I don't like adorable, I like gangsta. Let me see."
    scene sc95 with dissolve
    cd "Look how \"gangsta\" you are...flash off."
    scene sc96 with dissolve
    scene sc97 with dissolve
    cd "Flash on."
    cd "Which one you like?"
menu:
    "Off.":
        jump choice24a
    "On.":
        jump choice24b

label choice24a:
    p "Off."
    cd "Ok, I'll send it to you."
    jump choice24_common

label choice24b:
    p "On."
    cd "Ok, I'll send it to you."
    jump choice24_common

label choice24_common:

if choice21b:
    scene sc98 with dissolve
    cd "What took you so long?"
    jump giveson

else:
    jump giveson

label giveson:

    scene sc99 with dissolve
    cd "You're wearing it too!"
    scene sc100a with dissolve
    cd "Here, put it on the desk please and give me my son."
    scene sc101 with dissolve
    p "Great minds think alike, right? I was just talking to your mom...she wants me to call her Sharon now."
    scene sc102 with dissolve
    cd "Ugh, she thinks she's 18 again since dad moved out."
    scene sc103 with dissolve
    p "Let her be, she deserves to be happy..."
    cd "I'm not saying she doesn't, it's just that she thinks she's my sister sometimes..."
    p "Uhm..."
    scene sc104 with dissolve
    cd "Don't!"
    p "Have I..."
    cd "Shh."
    p "...ever told you..."
    scene sc105 with dissolve
    cd "Not listening."
    p "...you two look like twins?"
    cd "Done?"
    scene sc106 with dissolve
    p "Well, you know what they say, before you marry the daughter you gotta see what the mom looks like."
    scene sc107 with dissolve
    p "What."
    p "She does look like your sister."
    scene sc108 with dissolve
    cd "Dude, you realize that's how gross old men hit on my mom, don't you? She's over 40! It's a compliment to her, not to me buttface!"
    p "Yeah, sorry, sis. You know I'm a pain in the ass when I'm tired."
    scene sc109 with dissolve
    cd "To be honest, you're always a pain in the ass."
    p "Riiight. Hey, don't you wanna know how I did today?"
    stop music fadeout 3.0

menu:
    "Tell her about Master.":
        jump choice25a
    "Tell her about Samantha.":
        jump choice25b

label choice25a:

    scene sc110 with dissolve
    p "You know I'm taking this class with Metal, Business 1."

if choice9a:
    cd "Oh, yeah, you were telling me in the morning, what happened?"
    jump bus

if choice9b:
    cd "Yeah, I recall him telling you to sign up for it."
    jump bus

label bus:

    scene sc111 with dissolve
    p "Bro, the prof...teacher was one of these poisonous snake oil salesmen I hate. He was like \"I'm the biggest businessman in the world and I'm here to help you be as successful as I am.\" What a bullshit artist!"
    scene sc112 with dissolve
    cd "Oh my God, like your cousin! I can imagine your face!"
    scene sc113 with dissolve
    p "Yeah, you know how much I hate this so-called gurus...it's honestly hard for me to think of something worse for society than these big time frauds, that's what they are!"
    scene sc114 with dissolve
    cd "Haha, chill, bro. Remember the time we went to your cousin's event? Dude, your speech at the end..."
    p "Haha, a good one, wans't it?"
    cd "Haha."
    scene sc115 with dissolve
    cd "You were like \"I've got to give it to my cousin because he's a real businessman: he managed to make you pay thousands for a light show and two inspirational quotes from the Internet.\""
    scene sc116 with dissolve
    cd "Duuuuude, you were my hero that night. I wrote down all those punchlines in my diary that year."
    p "First of all, I don't speak like that...and bro, I got into so much trouble with my relatives afterwards..."
    scene sc117 with dissolve
    cd "Or when you said: \"My cousin has no product or service. What business does he run besides telling people he has a successful business?\"."
    scene sc118 with dissolve
    p "Haha, it's true! You don't see Leon Tusk giving conferences on \"five steps to have a productive morning.\" He's too busy working on a real business!"

if choice10b:

    scene sc119 with dissolve
    p "Oh, and there was this competition...to know who could be a good leader..."
    cd "Yeah?"
    p "Uhm, I'm ashamed to say it..."
    cd "What."
    p "I won it, look!"
    scene sc120 with dissolve
    cd "You won a pin?"
    p "This is supposed to be like a VIP pass for the teacher's seminar!"
    p "Haha, no way!"
    p "Yeah, I know, probably I'll just give it to Metal... I did it for him after all, no way I'm going."
    pt "Or yes way?"
    scene black with dissolve
    scene sc121 with dissolve
    p "Listen sis, I'm a bit sleepy, better get going."
    cd "Alright, bro, c'mere."
    scene sc122 with dissolve
    cd "See you tomorrow, ok?"
    scene sc123 with dissolve
    cd "Love you!"
    p "Love you, too."
    scene sc124 with dissolve
    jump choice25_common

if choice11a:

    scene sc119 with dissolve
    p "Oh, and there was this competition...to know who could be a good leader..."
    cd "Yeah?"
    p "Uhm, I'm ashamed to say it..."
    cd "What."
    p "I won it, look!"
    scene sc120 with dissolve
    cd "You won a pin?"
    p "This is supposed to be like a VIP pass for the teacher's seminar!"
    p "Haha, no way!"
    p "Yeah, I know, probably I'll just give it to Metal... I did it for him after all, no way I'm going."
    pt "Or yes way?"
    scene black with dissolve
    scene sc121 with dissolve
    p "Listen sis, I'm a bit sleepy, better get going."
    cd "Alright, bro, c'mere."
    scene sc122 with dissolve
    cd "See you tomorrow, ok?"
    scene sc123 with dissolve
    cd "Love you!"
    p "Love you, too."
    scene sc124 with dissolve
    jump choice25_common

else:
    scene black with dissolve
    scene sc121 with dissolve
    p "Listen sis, I'm a bit sleepy, better get going."
    cd "Alright, bro, c'mere."
    scene sc122 with dissolve
    cd "See you tomorrow, ok?"
    scene sc123 with dissolve
    cd "Love you!"
    p "Love you, too."
    scene sc124 with dissolve
    jump choice25_common

label choice25b:

    scene sc125 with dissolve
    p "I met this beautiful girl today, her name is Samantha."
    cd "Beautiful?"
    scene sc110 with dissolve
    p "Well, to me, yeah. Beautiful is an opinion."
    cd "Yeah, a shallow one. You're not shallow."
    p "I am, sometimes."
    scene sc125 with dissolve
    p "Anyway, that's not the point. I don't know why but when I saw her, it felt...new! It was like..."
    scene sc126 with dissolve
    cd "Felt? Talking about feelings now?"
    p "Dude! What's wrong? Let me finish...are you...are you jealous?"
    cd "Why would I be?"
    p "I don't know you tell me."
    scene sc127 with dissolve
    cd "Well, I'm not, I'm just tired."
    p "Okaaayy, now that I come to think of it, yeah, it's been a long day for me too."
    scene sc121 with dissolve
    p "I guess I'd better get going then."
    cd "Wait bro, c'mere."
    scene sc122 with dissolve
    cd "See you tomorrow, ok?"
    scene sc123 with dissolve
    cd "Love you!"
    p "Love you, too."
    scene sc124 with dissolve

    jump choice25_common

label choice25_common:
    scene black with Dissolve(2.0)
    pause
    scene black with dissolve

    play music "audio/beat5.ogg" volume 0.7
    scene sc128 with dissolve
    pt "I have to read for Philosophy class...if not, Rivka and Samantha will outsmart me pretty soon. I definitely want to look good in front of Sami..."
    scene sc129 with dissolve
    pt "Who do we have here?"
    p "Morning! I have a question: where can I find Philosophy books?"
    scene sc130 with dissolve
    li "Good morning. Section B, next to the study area."
    p "Thanks!"

menu:
    "Say something nice.":
        jump choice26a
    "No need.":
        jump choice26b

label choice26a:
    scene sc131 with dissolve
    p "You just saved my life in my war against illiteracy."
    pt "Not bad, she kinda smiled."

    jump choice26_common
label choice26b:
    jump choice26_common

label choice26_common:
    scene black with dissolve
    scene sc132a with dissolve
    pt "Is that Samantha?"
    scene sc132a with dissolve
    scene sc132b with dissolve
    scene sc132c with dissolve
    scene sc132 with dissolve
    pt "Yes!"
    scene sc133 with dissolve
    p "Hello, Samantha!"
    scene sc134 with dissolve
    sa "Oh, hi, [p]."
    p "What are you reading?"
    sa "Studies on mental disorders...Psychopathy mainly...uhmmm"
    scene sc135 with dissolve
    sa "Would you like to take a test?"
    p "A test to know if I'm a psychopath?"
    scene sc136 with dissolve
    sa "Well, it's not conclusive, it's just to know if you have any psychopathic traits."
    scene sc135 with dissolve
    sa "What do you say?"

menu:
    "Of course!":
        jump choice27a

label choice27a:
    pt "How could I say no to you?"
    p "Alright, let's do it."
    scene sc137 with dissolve
    sa "Yes!! Thank you! I needed a test subject."
    p "Don't mention it, I'm glad I can help."
    scene sc138 with dissolve
    sa "All right, picture this:"
    stop music fadeout 3.0
    scene black with dissolve
    scene sc139 with dissolve
    sa "On Christmas, a kid gets a soccer ball..."
    scene sc140 with dissolve
    sa "...and a bike."
    scene sc141 with dissolve
    sa "He hates both gifts. Why?"

menu:
    "It's not what he wanted.":
        jump choice28a
    "He doesn't have legs.":
        jump choice28b

label choice28a:

    $ choice28a = True

    scene sc142 with dissolve
    sa "That's one of many possible healthy answers. Here's another one:"
    jump choice28_common

label choice28b:

    $ choice28b = True

    scene sc143 with dissolve
    sa "That's what a psychopath would say."
    p "Really? Just like that? Come on! Give me another chance."
    sa "All right, here's another one:"
    jump choice28_common

label choice28_common:
    scene black with dissolve
    play music "audio/dramatic.ogg"
    scene sc144 with dissolve
    sa "You're a burglar with a knife about to break in a house."
    scene sc145 with dissolve
    p "A knife?"
    sa "Yeah, you need it...just in case."
    scene sc145a with dissolve
    p "Could it be a samurai katana?"
    sa "What? Why would you...a knife is enough."
    p "Ok, ok."
    scene sc146 with dissolve
    sa "Once in the house, you start looking for something to steal..."
    scene sc147 with dissolve
    sa "But you get caught in the process."
    scene sc148 with dissolve
    sa "The homeowner hurries into his room and hides in the closet. At this point, knowing he's really scared: what would you do?"

menu:
    "Leave.":
        jump choice29a
    "Pretend to leave.":
        jump choice29b

label choice29a:
    stop music fadeout 3.0
    scene sc149 with dissolve
    p "I'd steal everything I could on my way out. I'm a thief, not a murderer."
    sa "Even though stealing isn't right, it is an acceptable answer."
    p "So I did well?"

if choice28a:
    scene sc150 with dissolve
    sa "Yeah, pretty good actually, 2 out of 2."
    p "Sweeeeet!"
    sa "I guess you're not a psychopath."
    p "You had any doubts?"
    scene sc151 with dissolve
    sa "Hehe. As I said, these tests are not conclusive..."
    jump endtest

if choice28b:
    scene sc150a with dissolve
    sa "One good, one bad."
    p "Mmm, let's try one more!"
    scene sc150 with dissolve
    sa "Ok! The last one."

label case3:
    scene sc138 with dissolve
    sa "A murderer..."
    p "I don't wanna be a murderer."
    scene sc150a with dissolve
    sa "Not you, A murderer."
    p "Ok, sorry, go on."
    scene black with dissolve

    scene sc152 with dissolve
    play sound "audio/evillaugh.ogg"
    sa "A murderer stabs a man to death and he doesn't run away."
    scene sc153 with dissolve
    sa "He stays near the crime scene watching what he did. Why?"
menu:
    "He wants to make sure the man is dead.":
        jump choice30a
    "He likes blood.":
        jump choice30b
    "It'd be suspicious if he escapes.":
        jump choice30c

label choice30a:
    stop sound fadeout 2.0
    scene sc150 with dissolve
    sa "You're not a danger to society after all."
    p "Haha. How accurate can those tests be?"
    sa "Enough to determine antisocial behavior, in fact..."
    jump endtest

label choice30b:
    stop sound fadeout 2.0
    scene sc150 with dissolve
    sa "You're not a danger to society after all."
    p "Haha. How accurate can those tests be?"
    sa "Enough to determine antisocial behavior, in fact..."
    jump endtest

label choice30c:
    stop sound fadeout 2.0
    scene sc154 with dissolve
    sa "Interesting. You do have two psycopathic traits after all."
    p "Really? I messed it up in the last one?"
    sa "Yes, sir."
    p "How accurate can those tests be?"
    sa "Enough to determine antisocial behavior, in fact..."
    jump endtest

label choice29b:
    scene sc155 with dissolve
    p "I would close the room's door so he thinks I left, but I'm just waiting for him to get out. Oh! wait...how do I know he doesn't have a cellphone with him?"
    scene sc156 with dissolve
    p "Maybe it's better to go after him and..."
    sa "You're making it worse."
    p "I'm a psycho, aren't I? How am I doing so far?"
    stop music fadeout 3.0

if choice28a:
    scene sc150a with dissolve
    sa "One good, one bad."
    p "Can I try one more?"
    scene sc150 with dissolve
    sa "Yes, sir!"
    jump case3

if choice28b:
    scene sc154 with dissolve
    sa "Badly. You do have two psycopathic traits after all."
    p "Really? I messed it up again?"
    sa "Yes, sir."
    p "How accurate can those tests be?"
    sa "Enough to determine antisocial behavior, in fact..."
    jump endtest

label endtest:
    scene sc157 with dissolve
    li "Excuse me, you're being loud. You know you can't talk in here."
    p "I'm VERY sorry, I didn't mean to disturb anybody. It won't happen again."
    scene sc158 with dissolve
    sa "I'm sorry, [p], it was all my fault."
    p "Don't worry, I got excited with those tests. Let's go."
    scene black with dissolve
    play music "audio/beat8.ogg"
    scene sc159 with dissolve
    sa "Thank you for your help."
    p "No worries."
    sa "Well, I'll see you in class, I'm going to run now."
    p "Run? Where do you do it?"
    scene sc160 with dissolve
    sa "Around the campus or near the soccer field, two or three times a week."
    p "Cool! Can I...can I join you one day? I used to run too, you know, and now I wanna get back to it."
    scene sc161 with dissolve
    sa "Sure!...if you wake up early. I usually run before classes, today I overslept that's why I'm doing it at this time."
    p "How early are we talking about?"
    sa "Let's say...7?"
    p "That works for me."
    scene sc162 with dissolve
    sa "Give me your phone."
    scene sc163 with dissolve
    sa "Let me know the night before, ok?"
    p "Oh, ok...S?"
    sa "Yeah, you can call me S."
    scene sc164 with dissolve
    pt "You can call me anytime..."
    scene sc165 with dissolve
    p "I guess I'll see you around, S."
    sa "Yeah, sure! And thanks for your help again. Bye, [p]!"
    stop music fadeout 3.0

    scene black with Dissolve(3.0)
    play music "audio/kawai.ogg"

    scene sc166 with dissolve
    mt "Quit playing games with my heart..."
    scene sc167 with dissolve
    mt "with my heart...my heart..."
    scene sc168 with dissolve
    mt "I should've known from the start..."
    scene sc169 with dissolve
    stop music fadeout 3.0
    p "Hey, dude! What are you singing?"
    scene sc170 with dissolve
    mt "Uuuhhhmmm...the new Cowstones' song..."
    p "Yeah, right. That sounded a lot like FSB to me."
    scene sc171 with dissolve
    mt "Noo...what are you talking about?!"
    p "Let me hear it."
    scene sc172 with dissolve
    mt "Here."
    play music "audio/hard.ogg" volume 0.7
    pause
    mt "See? Rock."
    p "Alright, bro...actually, that's not bad at all...what's the name of the song?"
    scene sc170 with dissolve
    mt "Quit...I mean...Reina Sexual."
    p "Haha, Sexual Queen? But it's not in Spanish, at least the verse is not."
    scene sc173 with dissolve
    mt "Wait for it...here it comes..."
    scene sc174 with dissolve
    mt "Reina sexual! Princesa del sexo anal!"
    scene sc175 with dissolve
    b "Reina sexual! Princesa del sexo anal!"
    scene sc176 with dissolve
    p "Come, Jessica! Sing with me!"
    js "I don't know what you're saying...something about sex definitely."
    p "Princesa del sexo anal!"
    scene sc177 with dissolve
    js "Anal sex! Haha."
    p "Haha, just dance!"
    js "Yeah!"
    scene sc178 with dissolve
    pause 1.0
    scene sc179 with dissolve
    js "Is that...?"
    mt "Yes."
    p "What. What happened?"
    uk "Turn that off."
    mt "Yes, sir!"
    stop music
    scene sc180 with dissolve
    pause 1.0
    scene sc181 with dissolve
    pause 1.0
    scene sc182 with dissolve
    pt "Who's this guy? He's big."
    scene sc183 with dissolve
    uk "What was that?"

menu:
    "Be respectful.":
        jump choice31a

    "Don't be.":
        jump choice31b

label choice31a:
    scene sc182 with dissolve
    p "We're very sorry, sir, we didn't know we couln't dance in here, we didn't mean to disturb anybody."
    scene sc183 with dissolve
    uk "You get a free pass, boy. Just keep in mind that ignorance is not an excuse for a crime."
    pt "Crime? What the f..."
    jump endsheriff

label choice31b:
    scene sc182 with dissolve
    p "What was what?"
    scene sc183 with dissolve
    uk "The singing and the dancing."
    scene sc182 with dissolve
    p "There! You got it, you got it."
    scene sc183 with dissolve
    uk "You don't know who I am, do you?"
    p "Nope."
    jump endsheriff

label endsheriff:
    scene sc184 with dissolve
    js "We apologize, sir."
    mt "Yes, Mr. Sheriff, we'll behave."
    scene sc183 with dissolve
    she "I wouldn't like to have to repeat myself."
    scene sc185 with dissolve
    she "Everything seems to be in order now."
    pt "Who's he speaking to?"
    scene black with dissolve
    play music "audio/beat3.ogg"
    scene sc186 with dissolve
    js "Ann told me he used to be a pro-wrestler or something. She also said he's obsessed with order and doesn't let anybody gamble or smoke. Oh! And he hates frat boys."
    scene sc187 with dissolve
    mt "You forgot the fact that he tortured a cat in a public pool, he burned down an entire building, he killed his ex-wife..."
    scene sc188 with dissolve
    js "What?!?!"
    p "He's high af, don't worry, he's bullshitting."
    scene sc189 with dissolve
    mt "No, I'm not!"
    p "You totally are, he wouldn't be free if he had done such things."
    mt "He was acquitted, yeah, but it's common believe the jury made a mistake."
    p "That's literally the end of the last urban legend you read to me...a creepo something."
    scene sc190 with dissolve
    mt "Creepypasta."
    p "See, I'm telling ya."
    scene sc191 with dissolve
    js "You got me worried for a sec."
    scene sc192 with dissolve
    js "Hey, I almost forgot...Ann wants to talk to you."
    p "To me? What about?"
    scene sc193 with dissolve
    js "Your friend here."
    scene sc194 with dissolve
    p "Metal! Where are you going?"
    js "He's embarrased."
    p "How come? What did he do?"

if choice9b:
    p "You were gonna tell me something about him back in Business class."
    jump continuejess

label continuejess:
    scene sc195 with dissolve
    js "I'll let Ann tell you. Gotta go now, see you in class."
    p "Really? You won't tell me?"
    scene sc196 with dissolve
    js "Bye!"
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    scene sc209 with dissolve
    pt "There they are."
    play music "audio/feelingfine.ogg" volume 0.6
    scene sc210:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0

    pause

    p "Hello, girls...Jessica told me you wanted to talk to me, Ann?"
    scene sc211 with dissolve
    an "Yeah, I don't know where to start..."
    scene sc212 with dissolve
    js "Your friend's a stalker."
    p "What?!"
    scene sc213 with dissolve
    an "Jess! Don't say that!"
    js "What...he totally is."
    an "I don't like talking trash about anybody! Especially behind their backs!"
    js "Okay, chill out, sorry!"
    an "Thank you!"
    js "You're welcome!"
    pt "Hehe, they remind me of Metal and me..."
    p "I'm confused, tell me what happened."
    scene sc214 with dissolve
    an "Well, it all started last year when I met Daniel in Marketing class...since the very first moment he was pretty...attentive, let's say. I soon began seeing him more frequently..."
    an "Literally, everywhere I went he was there, too. I didn't think much of it to tell the truth, it was logical to see him after all: we're in the same university; never mentioned it to anybody until Jess asked me about you..."
    scene sc215 with dissolve
    an "...and the topic just came out naturally. She thinks everything was a little...sketchy...we're even in this class together this semester."
    an "Long story short, yesterday he...uhm...he..."
    scene sc216 with dissolve
    an "He showed up at my front door with flowers! There I said it."
    p "What?! For real?"
    pt "She looks concerned..."
    p "Well, that was..."

menu:
    "Romantic.":
        jump choice32a

    "Creepy.":
        jump choice32b

label choice32a:

    scene sc217 with dissolve
    js "What?!"
    pt "I got your back, buddy, who else if not me?"
    scene sc218 with dissolve
    p "It was his way to tell you \"I like you\". It was impulsive...yeah, I get it, but he made a big effort to find out things about you, like...where you live..."
    pt "What am I saying?"
    p "And he showed up with flowers...uninvited..."
    scene sc219 with dissolve
    js "Go on, I like where this is going."
    pt "Damn..."

menu:
    "Think!":
        jump choice33a

    "Apologize.":
        jump choice33b

label choice33a:

    scene sc220 with dissolve
    p "Can I ask you a simple question, Ann? Would it be different if you LIKED the person who did that? If it'd been your crush who showed up like that and not Daniel...would we be having this conversation?"
    scene sc221 with dissolve
    an "You know I was thinking exactly the same and you're right, there's some hypocrisy from our side because we condemned Daniel and not the action itself, I give you that."
    an "But, and this is a big but..."
    pt "Haha...big butt..."
    an "...you're missing out CONSENT! That makes all the difference: I never gave Daniel my address or told him I liked him. Without consent, what he did was not romantic, was just wrong...scary."
    scene sc222 with dissolve
    js "Yeah!"
    scene sc220 with dissolve
    p "You're right, I didn't see it that way. He went out of line, I apologize for the two of us...I'll talk to him, don't worry."
    scene sc223 with dissolve
    an "Thank you! I knew you'd understand."
    js "You can sit with us."
    jump choice32_common

label choice33b:

    scene sc220 with dissolve
    p "You know what? You're right, I won't excuse my friend's behavior. I'm very sorry, I'll talk to him, Ann."
    scene sc223 with dissolve
    an "Thank you! I knew you'd understand."
    js "You can sit with us."
    jump choice32_common

label choice32b:

    scene sc224 with dissolve
    js "You see? Even his friend thinks he's a creepo, I told you to watch out."
    p "Are you afraid of him, Ann?"
    scene sc215 with dissolve
    an "I'm not gonna lie, it was scary at the moment, but then I had time to think and I don't believe he's capable of you know...hurting me or anybody. It's Jess who puts ideas in my head..."
    p "I'll talk to him, don't worry. And you're right: Daniel is not capable of causing any harm, trust me on that one."
    scene sc225 with hpunch
    an "Jess was right about you! Thank you, [p]!"
    js "Oh, I see! You did it on purpose the first time! You think you're funny, don't you?"
    an "Let go!"
    p "What'd she say about me?"
    js "Nothing!"
    jump choice32_common

label choice32_common:

    stop music fadeout 2.0
    ri "Hello, [p]."
    scene sc226 with dissolve
    p "Oh, hi, Rivka. How're you doing?"
    ri "Not bad, you?"
    p "Chilling, talking to my friends here."
    scene sc227 with dissolve
    ri "Oh, ok, I guess we'll talk later then."
    p "Sure."
    scene black with dissolve
    play music "audio/simpleplan.ogg" volume 0.6
    scene sc229 with dissolve
    mc "Good morning, students! Take a seat, please. I have great news for all of you!"
    scene sc286 with dissolve
    mc "Two of my employees have left the company. They're new entrepreneurs now, thanks to me obviously, and today I'll be recruiting two of you to come work for me! How does that sound?!"
    bi "No way!"
    scene sc287 with dissolve
    mc "Let me explain to you what you'll get if you decide to join me!"
    scene sc288 with dissolve
    js "Hey, guys, I looked up on the Internet a list of questions to spot a fake business guru. Do you want to know if Master Collins is one?"
    p "No need, he sure is."
    js "Yeah, I know, it's just for fun..."
    scene sc289 with dissolve
    an "I still give him the benefit of the doubt."
    scene sc290 with dissolve
    js "Here we go then! First question: Do they show off a luxurious lifestyle?"
    scene sc291 with dissolve
    mc "Do you guys know what it feels like to drive a 6 figure car? Evidently not because you don't have one, unlike me..."
    scene sc292 with dissolve
    p "There's your answer."
    an "Yeah, pretty obvious...next one, Jess."
    scene sc290a with dissolve
    js "Uhm, let me see...do they have a secret formula to get rich and successful quickly, without much effort?"
    scene sc293 with dissolve
    mc "In my book \"The Ultimate Success Formula\" I show you step by step how my students are earning 6 and even 7 figures working from their laptops from home...and more important, without investing one cent! You'll be driving a car like mine in no time!"
    play sound "audio/whatjontron.ogg"
    p "What?! Where do I sign?!"
    scene sc289a with dissolve
    an "Well, unless you're in drug trafficking, it's impossible to make thousands in a short time. I'm starting to believe you guys..."
    js "Told ya."
    p "Yup."
    scene sc290a with dissolve
    js "Ok, here's another one: Do they despise traditional education?"
    scene sc295 with dissolve
    mc "You don't need to come to college to actually earn a living. I studied here and I feel I wasted years of my life: tons and tons of information and no practical use."
    an "How can he say that?!"
    js "Does he even realize he works for a university?"
    p "I don't think he does."
    scene sc286 with dissolve
    mc "Look at me! I didn't learn from books, I learned from experience...I took action!"
    scene sc296 with dissolve
    ri "Taking action without knowledge is really stupid..."
    scene sc297 with dissolve
    bi "Rivka! I thought you loved Master Collins."
    ri "Yeah...not really, Billy, not really."
    scene sc289b with dissolve
    an "I can't believe he belittled the role of colleges, I guess you guys were right..."
    js "Wait up, it's not over yet...Do they tell you to avoid \"toxic\" people?"
    scene sc298 with dissolve
    mc "Avoid negative people! Acknowledge that positive thinking improves your results! If you hang around negative, small minded people it makes you look negative and small minded yourself!"
    scene sc299 with dissolve
    mc "Remember: if you don't succeed today, you will tomorrow. You are not the person who you'll get to be!"
    scene sc300 with dissolve
    bi "Yeah! I'm not the person who I'll get to be!"
    scene sc297 with dissolve
    bi "I'm sorry, Rivka, but we can't be friends anymore...you are toxic."
    ri "Bye."
    stop music fadeout 3.0

menu:
    "Save Billy from the Master's cult.":
        jump choice34a

    "Not my business.":
        jump choice34b

label choice34a:
    scene sc301 with dissolve
    p "Hey, Billy don't buy that crap. To him, toxic people are the ones who warn you about scammers like him, generally your family and friends."
    scene sc302 with dissolve
    bi "I'm not the person who I'll get to be!"
    scene sc287 with dissolve
    mc "That's the right attitude!"
    pt "Bye, Billy."
    jump choice34_common

label choice34b:
    scene black with dissolve
    jump choice34_common

label choice34_common:

    scene sc303 with dissolve
    ri "You are not the person who you will get to be?"
    p "I know, so obvious and basic! You saw his face? It was like he'd just said the most intelligent thing in the world."
    ri "Who falls for that crap?"

if choice9b:
    scene sc304 with dissolve
    js "You and Ann did in the first class."
    ri "I was bored!"
    an "No shame, you know I'll try anything once."
    jump endfalseguru

if choice9a:
    scene sc305 with dissolve
    js "[p] and Ann did in the first class."
    p "Heeeey! I did it for my friend!"
    an "No shame, you know I'll try anything once."
    jump endfalseguru

label endfalseguru:
    scene black with dissolve
    scene sc306 with dissolve
    mc "It would break my heart to see you fall for false promises to get rich overnight with business models taken from Alice in Wonderland..."
    an "Is he an idiot or a teletubby gave birth to him?"
    ri "That's exactly what he said he does!"
    scene sc307aa with dissolve
    js "Tallying up our responses now guys aaaaaand..."
    scene sc307:
        pause 0.3
        "sc307a"
        pause 0.3
        "sc307"
        pause 0.3
        "sc307a"
        pause 0.3
        repeat
    play sound "audio/warning.ogg"
    js "\"He's not only a bullshit artist, but a criminal on the loose, report him to your local authorities immediately!\""
    an "Wow!"
    p "Accurate af."
    ri "Haha."
    scene sc308 with dissolve
    mc "You can now come to my desk for a quick interview if you're interested. Be a doer like me, not a don'ter!"
    scene sc309 with dissolve
    bi "I'm a doer, not a don'ter!"
    js "My God."
    ri "A cult, indeed."
    scene black with Dissolve(3.0)
    pause
    play music "audio/creepy.ogg"
    play sound "audio/vomit.ogg"
    scene sc197 with dissolve
    pause 2.0
    scene sc197a with dissolve
    pause 2.0
    scene sc197b with dissolve
    uk "I want out, man."
    scene sc198 with dissolve
    uk "You know you can't leave just like that, you've seen too much...WE have seen too much."
    scene sc199 with dissolve
    uk "I know, but after what we've done, I can't go back in there...what if they want us to do it again?...I wish we could go back in time."
    scene sc200 with dissolve
    uk "Don't lose it now. We did what we had to do to know more about their practices, they trust us now."
    scene sc201 with dissolve
    uk "You're right, I'm sorry. What are we gonna do?"
    scene sc202 with dissolve
    uk "I don't know, I don't know...we need to think our next steps carefully."
    scene sc203 with dissolve
    uk "Fuck! I thought this was gonna be easier, but look at us now...when did it all go to hell?!"
    scene sc204 with dissolve
    uk "Keep it together, we couldn't know things would escalate this much all of a sudden, but it was a risk. We have to remember why we're doing this in the first place."
    scene sc201 with dissolve
    uk "You're right...we need answers..."
    scene sc205 with dissolve
    uk "I need to know what happened to my father and once I do, I'll put an end to all this madness!"
    scene sc201 with dissolve
    uk "What do you mean?"
    scene sc206 with dissolve
    uk "Oh, no bruh, not even think about it, this shit is way bigger than us. And they'd go after not only us, but our families too!"
    scene sc202 with dissolve
    uk "Yeah, I'm not thinking clearly either, I need some time..."
    scene sc207 with dissolve
    uk "I'm too scared, Franz."
    scene sc208 with dissolve
    fz "So am I...so am I..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    scene black
    play sound "audio/iphone.ogg"
    scene black
    pause
    stop sound
    sa "Hello?"

    scene sc310:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/motivacional.ogg"
    pause
    p "Hi, S, it's [p]...are you running tomorrow morning?"
    sa "Hi! Yeah, you comin'?"
    p "Yup, you said at 7, right?"
    scene sc311 with dissolve
    sa "Uhum, see you in the parking lot, ok?"
    p "Sure, I'll be there!"
    scene black with dissolve
    scene sc230 with dissolve
    sa "Hi, [p]. You made it!"
    p "Of course I did! I was looking for a chance to go back to running, but I didn't want to do it alone, it's boring."
    scene sc231 with dissolve
    sa "Oh, yeah, I know what you mean. You can always listen to some good music, though."
    p "You're right. What kind of music do you like?"
    scene sc232 with dissolve
    sa "Rock, mainly, but I can listen to all kinds. You?"

menu:
    "Only 2 percent of couples survived when each person had completely different music tastes.":
        jump choice34c

    "We can be in that 2 percent.":
        jump choice34d

label choice34c:
    p "What a coincidence! I'm into rock, too!"
    scene sc233 with dissolve
    sa "Sweet! Do you play any instrument?"
    p "The guitar...I'm not really good at it, but I watch some tutorials to get better."
    scene sc234 with dissolve
    sa "You learned by yourself? Nice! I'd like to learn how to play my favorite songs, but first I need to buy a guitar, hehe."
    p "Now I know what I'm getting you for Christmas."
    scene sc235 with dissolve
    pause 1.0
    jump stretch

label choice34d:
    p "I listen to reggae and hip hop..."
    scene sc233 with dissolve
    sa "Oh, ok, don't know much about it..."
    pt "Damn."
    scene sc235 with dissolve
    p "And rock, of course!"
    scene sc234 with dissolve
    sa "Cool! I'd like to take guitar lessons, you know, but first I need a guitar, hehe...my dad promised to buy me one soon."
    p "Sounds good..."
    jump stretch

label stretch:
    scene black with dissolve
    scene sc236 with dissolve
    sa "We have to stretch out before running, ok?"
    p "Alright."
    scene sc237 with dissolve
    scene sc238 with dissolve
    pt "What a nice body she has."
    scene sc239 with dissolve
    pt "This is the first time I step on a soccer field after my injury...this pitch used to be my life..."
    scene sc240 with dissolve
    pt "The green, the smell..."
    scene sc240a with dissolve
    scene sc240b with dissolve
    scene sc240c with dissolve
    scene sc240d with dissolve
    scene sc240e with dissolve
    scene sc241 with dissolve
    sa "Are you ok?"
    stop music fadeout 3.0

menu:
    "Share some.":
        jump choice35a

    "Don't.":
        jump choice35b

label choice35a:
    scene sc243 with dissolve
    p "Yeah, it's just...this pitch brings back some memories..."
    scene sc241 with dissolve
    sa "Good or bad?"
    p "Both. Before coming here to St. Francis, I wanted to be a professional soccer player, you know, but I got injured...really bad."
    scene sc244 with dissolve
    sa "Oh, I'm so sorry. Are you ok now?"
    pt "Cut the crap, [p]! You're ruining the moment."
    scene sc245 with dissolve
    p "Yeah, yeah...it's all good now, don't worry. Let's do those stretches!"
    sa "All right!"
    jump choice35_common

label choice35b:
    scene sc242 with dissolve
    p "I'm great!"
    sa "Let's get to it then!"
    jump choice35_common

label choice35_common:


    scene sc247 with dissolve
    pause 1.0
    play music "audio/futurehouse.ogg" volume 0.7
    scene sc246:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    scene sc248:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "She takes it seriously, how cute!"
    scene sc249:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    sa "What...Can't one focus before training?"
    p "I didn't say anything."
    scene sc250:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    sa "I won't go easy on you...what's the point of anything if you don't give your hundred percent?"
    p "Ok, ok...I'll put in everything I've got."
    pt "Damn..I thought we were gonna take it easy."
    scene sc251 with dissolve
    pause 1.0
    scene sc252 with dissolve
    sa "Ready!"
    p "Let's get to it!"
    scene black with dissolve
    scene sc253 with Dissolve(1.0)
    pause 1.0
    scene sc254 with Dissolve(1.0)
    pause 1.0
    scene sc255 with dissolve
    pause 1.0
    scene sc256 with dissolve
    pause 1.0
    scene sc257 with dissolve
    pause 1.0
    scene sc258 with dissolve
    pause 1.0
    scene sc259 with dissolve
    pause 1.0
    scene sc260 with dissolve
    p "She's so beautiful..."
    scene sc261 with dissolve
    scene sc262 with dissolve
    sa "What."
    scene sc263 with dissolve
    p "Nothing."
    scene sc264 with dissolve
    pause 1.0
    scene sc265 with dissolve
    pause 1.0
    scene sc266 with dissolve
    pause 1.0
    scene black with Dissolve(1.0)
    scene sc267 with dissolve
    p "One last sprint? A hundred meters?"
    sa "Ok!"
    p "On the count of three..."
    scene sc268
    p "Three!"
    sa "I knew it, you cheater!"
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene sc269 with dissolve
    p "There's nobody here at this time, that's great! I'm not a people's person."
    scene sc270 with dissolve
    pause 1.0
    scene sc271 with dissolve
    sa "Me, neither. Here!"
    scene sc272 with dissolve
    p "Thanks!"
    scene sc273 with dissolve
    sa "Where do you live?"
    p "A few blocks away...in Cicero."
    sa "It's on my way, I'll take you there."

menu:
    "That's cool.":
        jump choice36a

    "That's cool.":
        jump choice36b

label choice36a:
    scene sc273a with dissolve
    sa "Wait...what?"
    p "That's cool, thank you."
    scene sc273b with dissolve
    sa "That's even more confusing..."
    p "Haha, shotgun!"
    scene sc274 with dissolve
    p "Hehehe."
    jump choice36_common

label choice36b:

    scene sc273c with dissolve
    sa "Wait...what?"
    p "That's cool, I don't want to cause you any trouble, S. I can walk, it's not that far."
    scene sc274 with dissolve
    sa "Yeah, right, you look exhausted. I told you it's fine, get in."
    p "Alright, thank you!"
    jump choice36_common

label choice36_common:

    play music "audio/relajante.ogg"
    scene black with dissolve
    scene sc275 with dissolve
    p "I like your car!"
    sa "Thanks. Technically, it's not mine, it's my dad's. Do you have a car?"
    scene sc276 with dissolve
    p "I inherited my dad's when he passed away, but I've never driven it."
    scene sc277 with dissolve
    sa "I'm so sorry to hear your dad passed away."
    p "Appreciate it, but don't worry...it's been a while. Tell you what: you'll be the first person I'll take for a ride."
    scene sc278 with dissolve
    sa "You said you've never driven it, wanna kill us?"
    p "Haha, nooo, I know how to drive, it's just..."
    sa "I get it, I was just joking..."
    scene sc279 with dissolve
    p "Well, as I said, I'm driving next time!"
    scene black with dissolve
    scene sc280 with dissolve
    p "This is it, thank you for the ride home, S. It was a nice morning."
    sa "It was, wasn't it? We should do it again!"
    p "For sure! Anytime! Well, see you in class."
    scene sc281 with dissolve
    p "Byeeee!"
    scene sc282 with dissolve
    mm "Is she your girlfriend, son? She's pretty!"
    p "No, mom...not yet."
    scene sc283 with dissolve
    mm "Oh, so are you hooking up?"
    p "Hooking up? Do you know what that means?"
    scene sc284 with dissolve
    mm "Dating?"
    p "Close enough, but no, we're not hooking up. She's just a friend from college."
    scene sc282 with dissolve
    mm "See? I told you: University wasn't that bad."
    p "Yeah, mom, you told me...like a thousand times..."
    mm "Hehe, help me out with the groceries, son."
    scene black with dissolve
    scene sc285 with dissolve
    mm "Now, spill the tea and I want pics or it didn't happen!"
    p "Stop talking like that, mom."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    play music "audio/mycat.ogg" volume 0.7
    scene sc717 with dissolve
    pt "I'm starting to feel alive again...Samantha's given me the motivation I was lacking of...Thank you, S! You're amazing!"
    scene sc718 with Dissolve(3.0)
    scene sc719 with Dissolve(3.0)
    scene sc720 with Dissolve(3.0)
    pt "Perhaps if I train hard enough, I could..."
    scene sc721 with dissolve
    pause 1.0
    play sound "audio/miau.ogg"
    scene sc722 with dissolve
    p "Huh?"
    scene sc723 with dissolve
    p "Heeeyyy, buddy, what you doing there?"
    play sound "audio/miau1.ogg"
    scene sc724 with dissolve
    p "Why you cry? Don't cry...you hungry?"
    scene sc725 with dissolve
    p "What do you need? Food? Love? Both?"
    scene sc726 with dissolve
    p "Oh, you want a hug! Hehehe, come here!"
    scene sc727 with dissolve
    sa "[p]! I didn't know you come here to jog..."
    p "Oh! Hi, Sammy! What a surprise!"
    scene sc728 with dissolve
    pt "Who's she with?"
    scene sc729 with dissolve
    sa "Is this your cat? Hi, little cutie...What's his name?"
    scene sc730 with dissolve
    p "Actually, it's not mine, I just found him here, I think he doesn't have a home, he's all dirty, may need some water..."
    scene sc731 with dissolve
    sa "Mom, this is [p], my friend from college."
    pt "Friendzoned in less than a minute..."
    mrsre "Hello, [p]...are you taking the cat home?"
    p "A pleasure to meet you, Mrs. Revello...Yes, I'm taking him home to feed him."
    scene sc732 with dissolve
    mrsre "Awww, that's very nice of you! My daughter and I love cats as well, but can't have one at home since my husband's allergic to them..."
    scene sc733 with dissolve
    sa "Yeah, I've always wanted to have one...One day I'll have many!"
    play sound "audio/miau.ogg"
    scene sc734 with dissolve
    sa "Awwww, poor baby."
    mrsre "He must be hungry. We won't hold you any longer, looks like you've got yourself a demanding cat."
    p "Nice meeting you, Mrs. Revello...see you in class, S!"
    scene sc733 with dissolve
    sa "Yeah, let me know how the baby is doing, ok?"
    p "Sure. Talk to you later!"
    stop music fadeout 3.0
    scene black with Dissolve(3.0)
    pause

    scene sc750 with dissolve
    cd "Are you gonna tell me what you did?"
    scene sc751 with dissolve
    mt "It's a little embarrasing..."
    scene sc752 with dissolve
    cd "You told me to come, bruh, just say it."
    scene sc753 with dissolve
    cd "And these roses? Are they for me?"
    mt "Why would I give you red roses?...those were for...that's what I wanted to talk about..."
    scene sc754 with dissolve
    cd "I'm listening..."
    scene sc755 with dissolve
    mt "There's this girl from college I really like...she's the sweetest girl in the world!"
    scene sc756 with dissolve
    mt "I thought we had something going on, she gave me all the signals: she was always flirting with me at college, you know..."
    play music "audio/lonewolf.ogg"
    scene sc757a with dissolve
    scene sc757b with dissolve
    scene sc757c with dissolve
    scene sc757d with dissolve
    scene sc757 with dissolve
    an "Oh, Daniel, you're so handsome!"
    mt "I know, babe."
    cd "Are you sure that's how it happened?"
    mt "One hundred percent."
    cd "At the campus? Really?"
    mt "Yeah! Are you deaf?"
    cd "Just double-checking..."
    scene sc758 with dissolve
    mt "She even touched me once!"
    cd "Define \"touch\"..."
    scene sc759 with dissolve
    mt "Well...there was this thing between us while we were working on a Marketing project..."
    scene sc760a with dissolve
    scene sc760b with dissolve
    scene sc760c with dissolve
    scene sc760d with dissolve
    scene sc760 with dissolve
    an "Daniel, my love, can I borrow your pen?"
    scene sc761 with dissolve
    mt "Sure! Here you are!"
    an "Thanks!"
    scene sc762 with dissolve
    pause
    scene sc763 with dissolve
    cd "Are you serious?"
    scene sc764 with dissolve
    mt "I'm not so sure that's how it happened though..."
    cd "I'm pretty sure that's exactly how it did..."
    scene sc765 with dissolve
    mt "Anyways, I woke up this morning and said to myself: \"Daniel, today she's gonna become your girlfriend!\""
    scene sc766 with dissolve
    mt "So I went to her house to give her those flowers..."
    cd "I can't believe she gave you her address..."
    scene sc759 with dissolve
    mt "Yeah, not exactly..."
    scene sc767 with dissolve
    an "How do you know where I live?"
    scene sc768 with dissolve
    mt "I followed you!"
    scene sc769 with dissolve
    cd "What did you say to her when you gave her the flowers, by the way?"
    mt "Not much, just that I liked her and wanted to give her roses..."
    scene sc770 with dissolve
    mt "I love you so much since the very first moment I saw you, I want to spend the rest of my life with you!"
    scene sc771 with dissolve
    mt "Take these roses as a symbol of my infinite love to you, my queen!"
    scene sc772 with dissolve
    pause
    scene sc773 with dissolve
    pause
    stop music fadeout 3.0
    scene sc756 with dissolve
    mt "She didn't say anything and just left...I really don't understand her, why is she giving me mixed signals?"
    scene sc774 with dissolve
    cd "Mixed signals? Are you high?"
    mt "You know I live high..."
    scene sc775 with dissolve
    mt "This is the first time I'm rejected, Candy..."
    cd "Is it?"
    mt "And I wanted to ask you: how do you live with that? how do you deal with rejection?"
    scene sc776 with dissolve
    cd "Well, people eventually stop thinking about..."
    scene sc777 with dissolve
    mt "No, I meant YOU specifically, Candace Miller, how do you deal with the fact that [p] will never see you as a woman? How do YOU live with rejection?"
    cd "Ha-Ha, very funny..."
    scene sc769 with dissolve
    cd "Remind me why we're friends again?"
    scene sc778 with dissolve
    play music "audio/summer.ogg"
    uk "Candy, sweetheart! I didn't know you were here..."

    scene sc779:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    cd "Hello, Mrs. Lopez, looking beautiful as usual!"
    mrslo "Awww, always so kind, Candy my darling."
    scene sc780 with dissolve
    mrslo "Oh, and those flowers?"
    mt "I bought them for you, mom! I know how much you love roses!"
    scene sc781 with dissolve
    mrslo "What a considerate son, I have!"
    scene sc782 with dissolve
    mrslo "Isn't he a gentleman, Candy?"
    cd "Errrr, yeahh?"
    scene sc783 with dissolve
    mrslo "I'll put them in a vase right now, thank you darling!"
    mt "You're very welcome, mom!"
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene sc784 with dissolve
    mt "Where were we?"
    cd "This girl who turned you down..."
    scene sc786 with dissolve
    play music "audio/secret.ogg"
    mt "Oh, yeah, how do you deal with that? How can you be friends with someone who rejected you? I mean you and [p]...isn't it awkward?"
    cd "He never rejected me."
    scene sc787 with dissolve
    mt "What?! You've never told him you love him?"
    scene sc788 with dissolve
    cd "Not really...no."
    scene sc789 with dissolve
    mt "Bullshit! I don't believe you...how long has it been?!"
    scene sc790 with dissolve
    mt "C, I know I can be stupid sometimes and ruin all my chances with girls, but there's something I'll never be..."
    cd "And what is that?"
    scene sc791 with dissolve
    mt "A coward. You should try it and go all-in for once, before it's too late..."
    scene sc792 with dissolve
    cd "I'm afraid to tell him..."
    scene sc793 with dissolve
    mt "Come on, C! Grow a womb!"
    scene sc794 with dissolve
    cd "\"A pair\" goes the expression."
    mt "What?! But you always say..."
    scene sc795 with dissolve
    cd "I know..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

    scene sc313 with dissolve
    p "S!"
    scene sc314 with dissolve
    sa "[p]! Are you free today?"
    p "Yeah, what's up?"
    sa "I told you the other day I wanted to buy a guitar, would you help me pick one?"
    p "Sure! Where do I pick you up from?"
    scene sc315 with dissolve
    sa "It's not necessary, we can meet at the mall."
    p "I insist, please, you were my ride last time."
    scene sc316 with dissolve
    sa "Oh! Wait! Are you driving your dad's car?"
    p "Yup."
    scene sc317 with dissolve
    sa "Really? I'm honored...you don't have to."
    p "I know I don't have to, I want to. Send me your address, S!"
    scene sc318 with dissolve
    sa "Okay! I'll be waiting."
    p "Cool! See you in a bit."
    scene sc319 with dissolve
    pt "I must hurry...first things first, these clothes won't do..."
    scene black with Dissolve(2.0)

    play music "audio/luckyday.ogg" volume 0.7
    scene sc320 with dissolve
    p "What do you think, Panther?"
    play sound "audio/knock.ogg"
    scene sc321 with dissolve
    mm "Good-looking like his mother! Where are you going, son?"
    p "To the mall."
    mm "With Candy?"
    p "Nope, with Samantha."
    scene sc322 with dissolve
    mm "OooOooOoo! So you're having a date!"
    p "Nah, not really mom, but I wanted to look decent...Oh, and I'm taking the car."
    scene sc323 with dissolve
    mm "What car?"
    p "Dad's."
    scene sc324 with dissolve
    mm "It's an important day then! I was wondering when you were going to do it, I've kept it in excellent conditions...Do you need money?"
    p "No, mom, thanks, you gave me enough last week and I have some savings too...Where's Franz by the way? I haven't seen him in his room lately."
    scene sc325 with dissolve
    mm "He moved out with a friend of his, didn't he tell you?"
    p "Nope, I'll call him later...I'm leaving now, mom."
    scene sc324 with dissolve
    mm "Let's go! I want to see you driving!"
    scene black with dissolve
    scene sc326 with dissolve
    p "It's ok, mom...I miss him too."
    mm "Sorry, son. It's just the memories I have in this car..."
    scene sc327 with dissolve
    mm "Do you have...uhm...protection?!"
    p "What do you mea...oooh! So you and dad in the car...ewwwww...way too much information."
    scene sc328 with dissolve
    mm "You didn't answer my question, young man."
    scene black with dissolve

    play sound "audio/carstart.ogg"

    scene sc329 with dissolve
    mm "Have fun, son! Drive safe!"
    p "Bye mom!"
    scene sc330 with dissolve
    pt "What if I..."
    play sound "audio/carengine.ogg"
    scene sc331 with dissolve
    pt "Shit! This car's powerful, better slow down..."
    scene sc332 with dissolve
    pt "It's going to be a great day hanging out with Sammy..."
    scene sc333 with dissolve
    pt "Perhaps I could buy her..."
    scene sc334 with dissolve
    pt "Yeah! I'm a genius!"
    scene sc335 with dissolve
    pause 1.5
    scene sc336 with Dissolve(3.0)
    pt "Ooops."
    scene sc337 with dissolve
    pause 1.5
    scene sc338 with dissolve
    pause 1.4
    stop music fadeout 3.0
    scene sc339 with dissolve
    pt "This store looks good."
    scene sc340 with dissolve
    pause 1.0
    scene sc341:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/besttime.ogg"
    pause
    se "Welcome to Music Ideas! How can I help you?"
    p "Hello! I'm looking for an acoustic guitar."
    scene sc342 with dissolve
    se "You're at the right place, let me show you the ones we have. Are you looking for anything in particular?"
    p "Not really, just a good one for beginners."
    scene sc343 with dissolve
    se "In that case, you don't need a professional one...this model is the right one for you: the body is made of mahogany, back and side, with a solid spruce top. It's carefully designed for superior tone and playing performance."
    p "I'm sold! You're very good at your job! I don't know much about guitars really, but the blue one looks good and I trust you."
    scene sc344 with dissolve
    se "Thank you for saying that! I needed it..."

menu:
    "Ask.":
        jump choice37a

    "Don't.":
        jump choice38_common

label choice37a:

    p "Everything ok?"
    scene sc344 with dissolve
    se "Yeah, I had a bad time with a customer just now, that's all..."
    scene sc345 with dissolve
    se "But you made my day with your comment!"
    p "I'm glad to hear that...I'm [p], by the way."
    scene sc346 with dissolve
    se "Vanessa."

menu:
    "Flirt.":
        jump choice38a

    "Not my type":
        jump choice38b

label choice38a:

    $ choice38a = True

    scene sc345a with dissolve
    p "Vanessa, I mean no disrespect, but you look like trash..."
    scene sc347 with dissolve
    va "What?!"
    p "Yeah, and as someone who deeply cares about the environment I'm obligated to take you out."
    scene sc348 with dissolve
    va "Haha...that was a terrible pick up line."
    p "It was, wasn't it?"
    cu "Excuse me, how much does this bass cost?"
    scene sc349 with dissolve
    va "I'll be with you in a minute, sir!"
    scene sc350 with dissolve
    va "It was terrible..."

menu:
    "Look down.":
        jump choice39a

    "Or not.":
        jump choice39b

label choice39a:
    scene sc351 with dissolve
    scene sc351b with dissolve
    scene sc351c with dissolve
    scene sc351d with dissolve
    scene sc351a with dissolve
    va "But it worked."
    scene sc352 with dissolve
    pause 1.0
    jump endseller

label choice39b:
    va "But it worked."
    scene sc352 with dissolve
    pause 1.0
    jump endseller

label choice38b:
    p "A pleasure."
    scene sc345 with dissolve
    p "Well, I gotta get going...How much is it?"
    scene sc345a with dissolve
    va "Oh...come with me."
    scene black with dissolve
    scene sc353 with dissolve
    va "Thank you for your purchase! Have a nice day!"
    p "You too."
    stop music fadeout 3.0
    jump samhouse

label choice38_common:

    scene black with dissolve
    scene sc353 with dissolve
    se "Thank you for your purchase! Have a nice day!"
    p "You too."
    stop music fadeout 3.0
    jump samhouse

label endseller:

    scene black with dissolve
    scene sc353 with dissolve
    va "Here you are, [p]."
    p "Thanks, Vanessa."
    scene sc354 with dissolve
    va "Hit me up later!"
    p "Will do."
    scene black with dissolve
    scene sc355 with dissolve
    pt "A much needed confidence boost...Samantha: I'm coming for you!"
    stop music fadeout 3.0

label samhouse:
    scene black with Dissolve(2.5)
    scene sc356 with dissolve
    pt "Honey, I'm home!"
    scene sc356a with Dissolve(0.02)
    scene sc356b with Dissolve(0.02)
    scene sc356c with Dissolve(0.02)
    scene sc356d with Dissolve(0.02)
    scene sc356e with Dissolve(0.02)
    scene sc356f with Dissolve(0.02)
    scene sc356g with Dissolve(0.02)
    scene sc356h with Dissolve(0.02)
    scene sc356i with Dissolve(0.02)
    scene sc356j with Dissolve(0.02)
    scene sc356k with Dissolve(0.02)
    scene sc356l with Dissolve(0.02)
    scene sc356m with Dissolve(0.02)
    scene sc356n with Dissolve(0.02)
    scene sc356o with Dissolve(0.02)
    scene sc356p with dissolve
    pause 1.0
    play music "audio/butter.ogg"
    scene sc357 with Dissolve(3.0)
    pause 1.0
    scene sc358 with Dissolve(3.0)
    pause 1.0
    scene sc359 with Dissolve(3.0)
    sa "Hi, [p]! I was wai..."
    scene sc360 with hpunch
    p "Surprise!"
    sa "What...no way, you're kidding, you did not..."
    p "I sure did!"
    scene sc361 with dissolve
    sa "Why did you do that?"
    p "You wanted a guitar, didn't you?"
    scene sc362 with dissolve
    sa "Are you serious? I didn't do anything to deserve this, it's too much."
    p "Take it, please. I wanted to do something for you."
    sa "Yeah, but why?"
    pt "Because I like you a lot!"
    p "I just felt like doing something for you, you know, to make you happy, but I'm not sure it worked..."
    pt "I'm starting to feel a lot like Metal..."
    scene sc363 with dissolve
    sa "Oh my gosh, I'm being so rude, I'm sorry...here, let me have it. Come in, please, we'll talk inside..."
    scene sc364 with dissolve
    sa "I can't believe you did this for me it, I feel guilty for making you spend your money on me..."
    p "Guilty?"
    sa "Yeah, I have this...thingy, you know...it's like I think I'm privileged enough and I don't like to be given anything away, and you come with a present like this when we barely know each other...this is overwhelming."
    scene sc365 with dissolve
    p "Wooow, you really are noble! You don't see noble these days...I've never met a person like you..."
    p "In fact, I've only met entitled bit...girls, who think they deserve everything in life just for the fact of being themselves...well, that's not the point..."
    p "What a sweet and beautiful heart you have, S! Don't you ever change, seriously!"
    scene sc366 with dissolve
    p "There it is! Finally a smile!"
    p "Hey, listen, I wouldn't do this kind of thing for many people, but I wanted to do it for you. And yeah, you're right I spent some money and time on it, I thought you'd appreciate the effort, but don't worry I'll take it back to the store..."

    scene sc367 with dissolve
    sa "What?! Are you crazy?! No way! I would never do that to you! I'd feel like the worst person in the world!"
    p "Problem solved then: you'll keep the guitar...Don't think too much of it, S, let's check it out instead!"
    stop music fadeout 3.0
    scene sc368 with dissolve

    sa "All right."
    play sound "audio/treasure.ogg"
    scene sc369 with Dissolve(1.0)
    scene sc369a with Dissolve(0.3)
    scene sc369b with Dissolve(0.3)
    scene sc369c with Dissolve(0.3)
    scene sc369d with Dissolve(0.3)
    scene sc369e with Dissolve(0.3)
    sa "Oh my God! I love it!"
    play music "audio/dancewithme.ogg" volume 0.8
    scene sc370 with dissolve

    sa "How do I look?!"
    p "Ridiculously happy..."
    sa "I am!!!"
    scene sc371 with dissolve
    pause 1.0
    scene sc372 with dissolve
    pause 1.0
    scene sc373 with dissolve
    sa "Thank you, thank you, thank you!!!"
    pt "Yes! I've been waiting for this hug!"
    scene sc374 with dissolve
    pause 1.0
    scene sc375 with dissolve
    sa "I'll never forget this..."
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    scene sc376 with dissolve
    sa "What would you like to do now? My plan was to spend some time at the mall buying the guitar."
    p "We can still go if you want, we can watch a movie or go to a cafe."
    sa "You tell me..."
    scene sc377 with dissolve
    scene sc378
    scene sc377 with dissolve

menu:
    "Go to the movies.":
        jump choice40a

    "Stay.":
        jump choice40b

label choice40a:

    scene sc378
    scene sc377 with dissolve
    p "Why don't we go to the movies?"
    scene sc378
    scene sc377
    scene sc379 with dissolve
    sa "Let's go!"
    scene black with Dissolve(2.0)

    play music "audio/beat8.ogg"
    scene sc380 with dissolve
    sa "I completely forgot you were driving today, it looks brand new! My dad has a muscle car as well."
    p "Cool! You know, the fact that it's a muscle car is pretty much all I know about it..."
    scene sc381 with dissolve
    sa "Same here, don't know about cars."
    scene sc382 with dissolve
    p "Enough talk then, hop in and let's just enjoy the ride!"
    sa "Agreed!"
    scene black with dissolve
    scene sc383 with dissolve
    pause 1.5
    scene sc384 with Dissolve(2.0)
    pause 1.0
    scene sc385 with dissolve
    sa "What movie are we watching?"

menu:
    "Comedy?":
        jump choice41a

    "You choose.":
        jump choice41b

label choice41a:
    p "Fred?"
    sa "An overrated movie with dumb and tasteless humor...great!"
    scene sc386 with dissolve
    sa "Hasta la vista, baby!"
    p "Haha, no problemo, dickwad."
    scene sc388 with dissolve
    sa "You wanna fight?"
    p "Haha, not really, you'd kick my ass...But seriously, what are we watching then?"
    scene sc387 with dissolve
    sa "I usually watch indie films, but there's none right now...what about some horror?"
    p "\"The Devil attacks again\" it is."
    sa "All right, let's give it a try."
    scene black with Dissolve(2.0)
    jump choice41common

label choice41b:
    p "You tell me."
    scene sc387 with dissolve
    sa "I usually watch indie films, but there's none right now...what about some horror?"
    p "\"The Devil attacks again\" it is."
    sa "All right, let's give it a try."
    scene black with Dissolve(2.0)
    jump choice41common

label choice41common:

    stop music fadeout 3.0
    scene sc389 with dissolve
    pause
    scene sc390 with dissolve
    pt "What the hell is this?"
    scene sc391 with dissolve
    pt "She's not having fun either, gotta do something..."
    p "Pretty bad, isn't it?"
    scene sc392 with dissolve
    sa "I forgot how terrible these movies are...people always making the most idiotic decisions..."
    scene sc392a with dissolve
    sa "Do you want some?"
    p "Not now, thanks."
    play music "audio/imagination.ogg"
    scene sc393 with dissolve
    p "Uhm...I was wondering...do you want to count shoulders?"
    scene sc393a with dissolve
    sa "What do you mean?"
    scene sc394 with dissolve
    p "One."
    scene sc395 with dissolve
    p "Two."
    scene sc396 with dissolve
    p "Three."
    scene sc397 with dissolve
    p "Four."
    scene sc398 with dissolve
    sa "Haha...You have to stretch out a bit."
    p "Why?"
    sa "You've been making some good moves."
    p "Haha."
    scene sc399 with dissolve
    pt "My god, her lips are so inviting, maybe I should..."

menu:
    "Kiss her!":
        jump choice42

label choice42:
    pt "The moment of truth has come..."
    scene sc400 with dissolve
    pause 1.0
    scene sc401 with dissolve
    pause 1.0
    scene sc402 with dissolve
    pause 1.0
    scene sc401 with dissolve
    pause 1.0
    scene sc402 with dissolve
    pause 1.0
    scene sc403 with dissolve
    pause
    pt "She's looking at my lips..."
    scene sc401 with dissolve
    pause 1.0
    scene sc402 with Dissolve(2.2)
    stop music fadeout 3.0
    scene black with Dissolve(1.0)
    pause

    play sound "audio/varita.ogg"
    scene walk00:
        pause 0.0366
        "walk01"
        pause 0.0366
        "walk02"
        pause 0.0366
        "walk03"
        pause 0.0366
        "walk04"
        pause 0.0366
        "walk05"
        pause 0.0366
        "walk06"
        pause 0.0366
        "walk07"
        pause 0.0366
        "walk08"
        pause 0.0366
        "walk09"
        pause 0.0366
        "walk10"
        pause 0.0366
        "walk11"
        pause 0.0366
        "walk12"
        pause 0.0366
        "walk13"
        pause 0.0366
        "walk14"
        pause 0.0366
        "walk15"
        pause 0.0366
        "walk16"
        pause 0.0366
        "walk17"
        pause 0.0366
        "walk18"
        pause 0.0366
        "walk19"
        pause 0.0366
        "walk20"
        pause 0.0366
        "walk21"
        pause 0.0366
        "walk22"
        pause 0.0366
        "walk23"
        pause 0.0366
        "walk24"
        pause 0.0366
        "walk25"
        pause 0.0366
        "walk26"
        pause 0.0366
        "walk27"
        pause 0.0366
        "walk28"
        pause 0.0366
        "walk29"
        pause 0.0366
        "walk30"
        pause 0.0366
        "walk31"
        pause 0.0366
        "walk32"
        pause 0.0366
        "walk33"
        pause 0.0366
        "walk34"
        pause 0.0366
        "walk35"
        pause 0.0366
        "walk36"
        pause 0.0366
        "walk37"
        pause 0.0002
        "walk38"
        pause 0.0002
    pause
    p "Look at you! YOU are the one with the moves!"
    scene walk39 with dissolve
    sa "Not bad, huh? You've seen nothing yet..."

    scene sc404 with dissolve
    sa "Come on, [p]! Let's go!"
    p "Where are we going?"
    sa "You'll see!"
    scene sc405 with dissolve
    p "Hold up! I need a kiss first!"
    scene sc406 with dissolve
    pause 0.5
    scene sc407 with dissolve
    sa "Move!"
    scene black with dissolve
    scene sc408 with dissolve
    p "Are we close now? We're leaving the city..."
    sa "Be patient, it's gonna be worth it."
    scene sc409 with dissolve
    sa "There! Pull over there!"
    scene black with dissolve
    play music "audio/romantica2.ogg"
    scene sc410 with dissolve
    sa "Hold my hand, I'll show you something!"
    scene sc411 with dissolve
    sa "Hurry, [p]! We'll miss the sunset!"
    p "It's a long way up."
    sa "We're almost there!"
    scene sc412 with dissolve
    sa "Look!"
    p "Woooooow, no waaaaayyy!"
    sa "Told ya!"
    scene sc413 with dissolve
    sa "Best view of the city, isn't it?"
    p "It sure is...wooow, thank you for bringing me here, S!"
    p "I have the feeling something is missing though..."
    scene sc414 with dissolve
    sa "Another kiss?"
    p "If you insist..."
    scene sc415 with dissolve
    pause
    scene sc416 with dissolve
    pause 1.0
    scene sc417 with dissolve
    pause 1.5
    scene sc418 with dissolve
    pause
    scene sc418a with dissolve
    pause
    scene sc419 with Dissolve(2.0)
    pause 1.5
    scene black with Dissolve(3.5)
    stop music fadeout 3.0

    jump choice40_common

label choice40b:

    scene sc378
    scene sc377 with dissolve
    p "Why don't we stay? We could play something on your new guitar."
    scene sc378
    scene sc377
    scene sc379a with dissolve
    sa "You'll have to teach me how..."
    p "Yeah, I could do that..."
    scene black with Dissolve(2.0)

    scene sc661 with dissolve
    sa "Like this?"
    p "Yes! You got it! That's the C chord!"
    mrsre "Hi, darling, I see you already bought the guitar..."
    scene sc663:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/sexback.ogg"
    pause
    pt "Her mom's so hot!"
    scene sc662b with dissolve
    pause 0.5
    scene sc662a with dissolve
    sa "Oh! Hi, mom...actually, it was a gift from [p]!"
    scene sc664 with dissolve
    sa "Look! Isn't it beautiful?!"
    mrsre "It sure is, darling, very well-made too! This is not cheap."
    scene sc665 with dissolve
    mrsre "He must really like you to buy you something like this..."
    p "Ahem ahem..."
    sa "Mom!"
    scene sc666 with dissolve
    mrsre "Hi, [p], how's the cat doing? Did you keep him?"
    p "Yeah, I told S I posted some pictures to know if someone was looking for her, it was a she by the way, but nobody replied so we decided to keep her...I named her Panther."
    scene sc666a with dissolve
    mrsre "Awww, how lovely! It's so good to hear that...you've got a good heart, just like my Sammy does..."
    p "Oh, I wish I had such a beautiful and kind heart as Samantha, Mrs. Revello..."
    scene sc666b with dissolve
    pause
    scene sc667 with dissolve
    mrsre "By the way, my husband is outside taking a look at your car...The Charger's yours, right?"
    p "Yes, ma'am."
    scene sc667a with dissolve
    mrsre "Don't call me ma'am, you can call me Vittoria."
    p "Ok...Vittoria."
    stop music fadeout 3.0
    scene sc668 with dissolve
    sa "That's true, I forgot about your car!"
    p "Let's go take a look at it then."
    scene black with Dissolve(2.0)
    play music "audio/reggae1.ogg"
    scene sc669 with dissolve
    pause 1.0
    scene sc670 with dissolve
    pause 1.0
    scene sc671 with dissolve
    pause 1.0
    scene sc672 with dissolve
    pause 1.0
    scene sc672a with dissolve
    sa "Hi, dad!"
    scene sc673 with dissolve
    mrre "Hi, sweetheart!"
    scene sc674 with dissolve
    sa "Dad, this is [p]."
    p "Good to meet you, Mr. Revello."
    mrre "Same here, kid."
    scene sc675 with dissolve
    mrre "Kid, you've got a beauty right here..."
    pt "I know..."
    mrre "Wouldn't you like to sell it?"
    scene sc676 with dissolve
    sa "Dad!"
    mrre "What...it's a harmless question...let him answer."
    scene sc677 with dissolve
    p "It's not for sale, sir, sorry."
    scene sc678 with dissolve
    mrre "Come on, kid! Aren't you my daughter's boyfriend? Don't you want to get along with your father-in-law? You'd score extra points if you sell it to me..."
    pt "Haha, what the hell?!"
    scene sc679 with dissolve
    sa "Mooommm!!"
    vi "Ok, Giuseppe, that's enough, you're making [p] feel uncomfortable...let's leave the kids alone."
    mrre "What did I say? You're overreacting, ladies..."
    sa "Just go, dad."
    stop music fadeout 3.0

menu:
    "Agree with him.":
        jump agree1

    "Say nothing.":
        jump disagree1

label agree1:
    scene sc677 with dissolve
    p "It's true what they say, sir: The more women in the family, the less drama you'll have..."
    scene sc680 with dissolve
    mrre "Said no one ever, right? Hahaha."
    p "Hahaha."
    scene sc681 with dissolve
    mrre "Sammy, I like this kid!"
    pt "I fucked it up..."
    scene sc682 with dissolve
    p "I...I was just playing along with your dad, S, trying to win him over...that's not what I really think."
    scene sc683 with dissolve
    sa "You wanted my dad to like you? That reminds me...you didn't say anything when he called you my boyfriend..."
    p "Did I have to?"
    scene sc684 with dissolve
    sa "I don't know..."
    scene sc685 with dissolve
    sa "Anyways, let's go somewhere else I don't want to stay home with my parents around."

    jump leaving

label disagree1:

    scene sc683 with dissolve
    sa "I'm sorry about that, dad has no filters sometimes..."
    p "That's ok, I don't mind, ready to go now?"
    scene sc685 with dissolve
    sa "Yeah, let's go, I don't want to stay home with my parents around."

    jump leaving

label leaving:

    scene black with dissolve
    scene sc686 with dissolve
    pause
    scene sc687 with dissolve
    sa "What's your favorite place?"
    p "My room."
    scene sc688 with dissolve
    sa "Haha, probably mine too, I could stay there all day long reading...and coffee, I'd definitely need some coffee. But I meant in the city..."
    p "Yeah, I know...uuuhm...there's this spot dad used to take me to...Do you wanna go?"
    sa "YES! Show me!"
    scene black with dissolve
    scene sc689 with dissolve
    p "We can park near here..."
    play music "audio/feliz.ogg"
    scene sc690 with dissolve
    p "So? What do you think?"
    sa "This is a great view! You said you used to come here with your dad?"
    scene sc691 with dissolve
    p "Yeah, when I was a kid, we used to play soccer right there on your left...we lost so many balls!"
    sa "I can imagine, are you going to play soccer for St. Francis? Can you?"
    scene sc692 with dissolve
    p "That's a really hard question...truth is I don't know, I'm out of shape, my leg feels better yes, but...I don't know..."
    sa "We'll keep running together to get you in shape...we're young, some doors should remain open..."
    p "That's very sweet of you, S..."
    scene sc693 with dissolve
    sa "Wait!!! Nooooooo!!!"
    scene sc694 with hpunch
    p "Whoa...what the hell?!"
    sa "Sorryyyyyyy..."
    scene sc695 with dissolve
    sa "You almost step on this baby!"
    p "What is it? A snail?"
    scene sc696 with dissolve
    sa "Look! You were about to kill him!"
    pt "Eww, is that...is that its teeth? Do they have teeth?...Say something nice, she likes it..."
    scene sc697 with dissolve
    pt "And skulls...I already know she likes cats..."
    scene sc698 with dissolve
    pt "And flowers? Mmm...she likes nature? life? death?"
    scene sc696 with dissolve
    p "Oh, good thing you saved it."
    scene sc700 with dissolve
    sa "You wanna touch him?"
    p "I think I'll pass."
    scene sc701 with dissolve
    sa "Your loss, let me put him somewhere safe."
    scene sc702 with dissolve
    sa "Bye, cutie!"
    p "You really like animals, don't you?"
    scene sc703 with dissolve
    sa "You don't?"
    p "I do! I like cats and dogs, but not a fan of snails..."
    scene sc704 with dissolve
    sa "Hehe, well, there used to be many of them on my backyard, so I grew up playing with snails instead of dolls."
    scene sc703 with dissolve
    sa "Is that weird?"
    p "It's not common to me, but I wouldn't call it weird, I'd call it special."
    scene sc705 with dissolve
    sa "Special, huh?"
    p "Very..."
    scene sc708 with dissolve
    pause 1.0
    scene sc709 with dissolve
    sa "This is just beautiful..."
    scene sc710 with dissolve
    sa "Love it!"
    p "Hehe, I'm glad you like it."
    stop music fadeout 3.0
    scene sc710 with dissolve
    scene black with Dissolve(2.5)
    scene sc711 with dissolve
    sa "Since you've shown me your favorite place, I want to show you mine!"
    p "Oh, that's great! So...you're driving?"
    scene sc712 with dissolve
    sa "Can I?"
    p "Sure!"
    scene sc713 with dissolve
    sa "Sweet! I'll show you how it's done!"
    p "Wait...what?"
    play music "audio/western.ogg" volume 0.5
    play sound "audio/carengine.ogg"
    scene sc714 with dissolve
    sa "This car's sweeeettt!"
    p "Ok, slow down..."
    scene black with dissolve
    scene sc714a with dissolve
    p "You drive so fast I didn't realize when we left the city!"
    sa "I don't drive fast, you drive slowly..."
    scene sc715 with dissolve
    sa "Muahahaha..."
    p "We're gonna die!"
    scene sc715a with dissolve
    sa "Relax, we're almost there."
    p "Thank God!"
    stop music fadeout 3.0
    scene black with Dissolve(2.0)
    play music "audio/romantica2.ogg"
    scene sc410 with dissolve
    sa "Hold my hand, I'll show you something!"
    pt "I'm gonna hold her soft hands...YES!"
    scene sc411 with dissolve
    sa "Hurry! We'll miss the sunset!"
    p "It's a long way up."
    sa "We're almost there! You won't regret it!"
    scene sc412 with dissolve
    sa "Look!"
    p "Woooooow, no waaaaayyy!"
    sa "Told ya!"
    scene sc413 with dissolve
    sa "Almost as good as your secret spot, isn't it?"
    p "Haha, are you kidding me? This's waaaaayyy better...wooow, thank you for bringing me here, S! I had no idea of this place...I have the feeling something is missing though..."
    sa "What is it?"

menu:
    "Make your move, [p], now!":
        jump kissito

label kissito:
    pt "Time to get close to her..."
    p "This!"
    scene sc415 with dissolve
    pause
    scene sc416 with dissolve
    pause 1.0
    scene sc417 with dissolve
    pause 1.5
    scene sc418 with dissolve
    pause
    scene sc418a with dissolve
    pause
    scene sc419 with Dissolve(2.0)
    pause 1.5
    stop music fadeout 3.0
    scene black with Dissolve(3.5)

    jump choice40_common

label choice40_common:

    scene black with dissolve
    pt "Tomber amoureux..."
    pt "Fall in love..."
    play music "audio/perfectlywrong.ogg"
    pt "What a big catastrophe falling passionately in love is..."
    scene sc736 with dissolve
    pt "All balance in your life is disturbed: you're either jealous, nervous, worried, anxious, unfocused, vulnerable..."
    scene sc737 with dissolve
    pt "...ecstatic..."
    pt "...fulfilled..."
    scene sc738 with dissolve
    pt "Alive!"
    scene sc740 with dissolve
    pt "Tomber amoureux..."
    pt "Fall in love..."
    pt "It's the only way..."
    pt "You feel real love only when you stop fighting and give up...when you put your guard down..."
    pt "Because happiness..."
    pt "Happiness is in the fall."
    scene sc739 with dissolve
    pt "I want to hold your hand while falling..."
    stop music fadeout 3.0
    scene black with Dissolve(3.0)

label samsex1:

    if _in_replay:
        $ pf = persistent.p


    play music "audio/bigmoney.ogg" volume 0.7
    scene sc420 with hpunch
    sa "Come here already!"
    scene sc421 with dissolve
    sa "Closer, I want to tell you something..."
    scene sc422 with dissolve
    sa "You're my cat!"
    p "Haha, I'll be what you want me to."
    sa "Good! Now give me that cock!"

    scene sc467 with dissolve
    scene sc468 with dissolve
    scene sc469 with dissolve
    pause
    scene sc469n with dissolve
    pause
    scene sc469 with dissolve
    pause
    scene sc469h with dissolve
    scene sc469n with dissolve
    scene sc469h with dissolve
    scene sc469 with dissolve
    scene sc469heyes with dissolve
    scene sc469n with dissolve
    scene sc469h with dissolve
    scene sc469 with dissolve
    scene sc469h with dissolve

    scene sc469h:
        pause 0.0333
        "sc470"
        pause 0.0333
        "sc470a"
        pause 0.0333
        "sc470b"
        pause 0.0333
        "sc470c"
        pause 0.0333
        "sc470d"
        pause 0.0333
        "sc470e"
        pause 0.0333
        "sc470f"
        pause 0.0333
        "sc470g"
        pause 0.0333
        "sc470h"
        pause 0.0222
        "sc470i"
        pause 0.0222
        "sc471"
        pause 0.0222
        "sc471a"
        pause 0.0222
        "sc471b"
        pause 0.0222
        "sc471c"
        pause 0.0222
        "sc471d"
        pause 0.0222
        "sc471e"
        pause 0.0222
        "sc471f"
        pause 0.0222
        "sc471g"
        pause 0.0222
        "sc471f"
        pause 0.0222
        "sc471e"
        pause 0.0222
        "sc471d"
        pause 0.0222
        "sc471c"
        pause 0.0222
        "sc471b"
        pause 0.0222
        "sc471a"
        pause 0.0222
        "sc471"
        pause 0.0222
        "sc470i"
        pause 0.0222
        "sc470h"
        pause 0.0222
        "sc470g"
        pause 0.0666
        "sc470f"
        pause 0.0666
        "sc470e"
        pause 0.0666
        "sc470d"
        pause 0.0666
        "sc470c"
        pause 0.0666
        "sc470b"
        pause 0.0666
        "sc470a"
        pause 0.0666
        "sc470"
        pause 0.0666
        "sc469h"
        pause 0.0666
        "sc473"
        pause 0.0666
        "sc473a"
        pause 0.0666
        "sc473b"
        pause 0.0666
        "sc473c"
        pause 0.0666
        "sc473d"
        pause 0.0666
        "sc473e"
        pause 0.0666
        "sc473f"
        pause 0.0666
        "sc472g"
        pause 0.0666
        "sc472h"
        pause 0.0666
        "sc472g"
        pause 0.0666
        "sc472f"
        pause 0.0666
        "sc472e"
        pause 0.0666
        "sc472d"
        pause 0.0666
        "sc472c"
        pause 0.0666
        "sc472b"
        pause 0.0666
        "sc472a"
        pause 0.0666
        "sc472"
        pause 0.0666
        "sc474"
        pause 0.0666
        "sc474a"
        pause 0.0666
        "sc474b"
        pause 0.0666
        "sc474c"
        pause 0.0666
        "sc474d"
        pause 0.0666
        "sc474e"
        pause 0.0666
        "sc474f"
        pause 0.0666
        "sc469h"
        pause 0.0666
        repeat
    pause
    p "You really like teasing me, huh?"

    scene sc478 with dissolve
    p "Yeah baby, taste it..."
    scene sc479 with dissolve
    scene sc480 with dissolve

    scene sc481:
        pause 0.0333
        "sc482"
        pause 0.0333
        "sc483"
        pause 0.0333
        "sc484"
        pause 0.0333
        "sc485"
        pause 0.0333
        "sc486"
        pause 0.0333
        "sc487"
        pause 0.0333
        "sc488"
        pause 0.0333
        "sc489"
        pause 0.0333
        "sc490"
        pause 0.0333
        "sc491"
        pause 0.0333
        "sc492"
        pause 0.0333
        "sc493"
        pause 0.0333
        "sc494"
        pause 0.0333
        "sc495"
        pause 0.0333
        "sc496"
        pause 0.0333
        "sc497"
        pause 0.0333
        "sc498"
        pause 0.0333
        "sc499"
        pause 0.0333
        "sc500"
        pause 0.0333
        "sc501"
        pause 0.0333
        "sc502"
        pause 0.0333
        "sc502"
        pause 0.0333
        "sc501"
        pause 0.0333
        "sc500"
        pause 0.0333
        "sc499"
        pause 0.0333
        "sc498"
        pause 0.0333
        "sc497"
        pause 0.0333
        "sc496"
        pause 0.0333
        "sc495"
        pause 0.0333
        "sc494"
        pause 0.0333
        "sc493"
        pause 0.0333
        "sc492"
        pause 0.0333
        "sc491"
        pause 0.0333
        "sc490"
        pause 0.0333
        "sc489"
        pause 0.0333
        "sc488"
        pause 0.0333
        "sc487"
        pause 0.0333
        "sc486"
        pause 0.0333
        "sc485"
        pause 0.0333
        "sc484"
        pause 0.0333
        "sc483"
        pause 0.0333
        "sc482"
        pause 0.0333
        "sc481"
        pause 0.0333
        repeat
    p "Argh!"
    pause

menu:
    "Deeper.":
        jump bjd

label bjd:

    scene sc503:
        pause 0.0333
        "sc504"
        pause 0.0333
        "sc505"
        pause 0.0333
        "sc506"
        pause 0.0333
        "sc507"
        pause 0.0333
        "sc508"
        pause 0.0333
        "sc509"
        pause 0.0333
        "sc510"
        pause 0.0333
        "sc511"
        pause 0.0333
        "sc512"
        pause 0.0333
        "sc513"
        pause 0.0333
        "sc514"
        pause 0.0333
        "sc515"
        pause 0.0333
        "sc516"
        pause 0.0333
        "sc517"
        pause 0.0333
        "sc518"
        pause 0.0333
        "sc518"
        pause 0.0333
        "sc517"
        pause 0.0333
        "sc516"
        pause 0.0333
        "sc515"
        pause 0.0333
        "sc514"
        pause 0.0333
        "sc513"
        pause 0.0333
        "sc512"
        pause 0.0333
        "sc511"
        pause 0.0333
        "sc510"
        pause 0.0333
        "sc509"
        pause 0.0333
        "sc508"
        pause 0.0333
        "sc507"
        pause 0.0333
        "sc506"
        pause 0.0333
        "sc505"
        pause 0.0333
        "sc504"
        pause 0.0333
        "sc503"
        pause 0.0333
        repeat
    p "Oohh, that's better!"
    pause

label doggy:

    scene sc519 with dissolve
    p "You're amazing..."
    scene sc520 with dissolve
    pause
    scene sc522 with dissolve
    sa "Come!"
    scene sc523 with dissolve
    pause 1.0
    scene sc524 with dissolve
    p "I love your ass, babe..."
    sa "I know you do!"
    scene sc525 with dissolve
    sa "Stick it in already!"
    scene sc526 with dissolve
    p "I'm going!"
    scene sc527 with hpunch
    sa "Mmmh..."
    scene sc536 with hpunch
    sa "Aaahh!"
    scene sc528 with dissolve

    scene sc528:
        pause 0.0166
        "sc529"
        pause 0.0166
        "sc530"
        pause 0.0166
        "sc531"
        pause 0.0166
        "sc532"
        pause 0.0166
        "sc533"
        pause 0.0166
        "sc534"
        pause 0.0166
        "sc535"
        pause 0.0166
        "sc536"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc542"
        pause 0.0166
        "sc543"
        pause 0.0166
        "sc544"
        pause 0.0166
        "sc545"
        pause 0.0166
        "sc546"
        pause 0.0166
        "sc547"
        pause 0.0166
        "sc548"
        pause 0.0166
        "sc549"
        pause 0.0166
        "sc550"
        pause 0.0166
        "sc551"
        pause 0.0166
        "sc552"
        pause 0.0166
        "sc553"
        pause 0.0166
        "sc553"
        pause 0.0166
        "sc552"
        pause 0.0166
        "sc551"
        pause 0.0166
        "sc550"
        pause 0.0166
        "sc549"
        pause 0.0166
        "sc548"
        pause 0.0166
        "sc547"
        pause 0.0166
        "sc546"
        pause 0.0166
        "sc545"
        pause 0.0166
        "sc544"
        pause 0.0166
        "sc543"
        pause 0.0166
        "sc542"
        pause 0.0166
        "sc541"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc535"
        pause 0.0166
        "sc534"
        pause 0.0166
        "sc533"
        pause 0.0166
        "sc532"
        pause 0.0166
        "sc531"
        pause 0.0166
        "sc530"
        pause 0.0166
        "sc529"
        pause 0.0166
        "sc528"
        pause 0.0166

        "sc528"
        pause 0.0166
        "sc529"
        pause 0.0166
        "sc530"
        pause 0.0166
        "sc531"
        pause 0.0166
        "sc532"
        pause 0.0166
        "sc533"
        pause 0.0166
        "sc534"
        pause 0.0166
        "sc535"
        pause 0.0166
        "sc536"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc542"
        pause 0.0166
        "sc543"
        pause 0.0166
        "sc544"
        pause 0.0166
        "sc545"
        pause 0.0166
        "sc546"
        pause 0.0166
        "sc547"
        pause 0.0166
        "sc548"
        pause 0.0166
        "sc549"
        pause 0.0166
        "sc550"
        pause 0.0166
        "sc551"
        pause 0.0166
        "sc552"
        pause 0.0166
        "sc553"
        pause 0.0166
        "sc553"
        pause 0.0166
        "sc552"
        pause 0.0166
        "sc551"
        pause 0.0166
        "sc550"
        pause 0.0166
        "sc549"
        pause 0.0166
        "sc548"
        pause 0.0166
        "sc547"
        pause 0.0166
        "sc546"
        pause 0.0166
        "sc545"
        pause 0.0166
        "sc544"
        pause 0.0166
        "sc543"
        pause 0.0166
        "sc542"
        pause 0.0166
        "sc541"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc535"
        pause 0.0166
        "sc534"
        pause 0.0166
        "sc533"
        pause 0.0166
        "sc532"
        pause 0.0166
        "sc531"
        pause 0.0166
        "sc530"
        pause 0.0166
        "sc529"
        pause 0.0166
        "sc528"
        pause 0.0166

        "sc528"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc528"
        pause 0.0074

        "sc528"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc528"
        pause 0.0074

        "sc528"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc553"
        pause 0.0074
        "sc552"
        pause 0.0074
        "sc551"
        pause 0.0074
        "sc550"
        pause 0.0074
        "sc549"
        pause 0.0074
        "sc548"
        pause 0.0074
        "sc547"
        pause 0.0074
        "sc546"
        pause 0.0074
        "sc545"
        pause 0.0074
        "sc544"
        pause 0.0074
        "sc543"
        pause 0.0074
        "sc542"
        pause 0.0074
        "sc541"
        pause 0.0074
        "sc540"
        pause 0.0074
        "sc539"
        pause 0.0074
        "sc538"
        pause 0.0074
        "sc537"
        pause 0.0074
        "sc536"
        pause 0.0074
        "sc535"
        pause 0.0074
        "sc534"
        pause 0.0074
        "sc533"
        pause 0.0074
        "sc532"
        pause 0.0074
        "sc531"
        pause 0.0074
        "sc530"
        pause 0.0074
        "sc529"
        pause 0.0074
        "sc528"
        pause 0.0074
        repeat
    p "Give me that big ass!"
    pause

    sa "Oh, God, keep going!"
    p "This feels so good..."
    stop music fadeout 3.0
    p "C'mere, babe!"


    scene sc423 with dissolve
    scene sc423:
        pause 0.0366
        "sc423a"
        pause 0.0366
        "sc424"
        pause 0.0366
        "sc424a"
        pause 0.0366
        "sc425"
        pause 0.0366
        "sc425a"
        pause 0.0366
        "sc426"
        pause 0.0366
        "sc426a"
        pause 0.0366
        "sc427"
        pause 0.0366
        "sc427a"
        pause 0.0366
        "sc428"
        pause 0.0366
        "sc428a"
        pause 0.0366
        "sc429"
        pause 0.0366
        "sc429a"
        pause 0.0366
        "sc430"
        pause 0.0366
        "sc430a"
        pause 0.0366
        "sc431"
        pause 0.0366
        "sc432"
        pause 0.0366
        "sc433"
        pause 0.0366
        "sc434"
        pause 0.0366
        "sc435"
        pause 0.03
        "sc436"
        pause 0.03
        "sc437"
        pause 0.03
        "sc438"
        pause 0.03
        "sc439"
        pause 0.03
        "sc440"
        pause 0.03
        "sc441"
        pause 0.03
        "sc442"
        pause 0.03
        "sc443"
        pause 0.03
        "sc444"
        pause 0.03
        "sc445"
        pause 0.03
        "sc446"
        pause 0.03
        "sc447"
        pause 0.03
        "sc448"
        pause 0.03
        "sc449"
        pause 0.03
        "sc450"
        pause 0.03
        "sc451"
        pause 0.03
        "sc452"
        pause 0.03
    pause
    play music "audio/theheat.ogg" volume 0.8

    scene sc453 with dissolve
    p "This nipple is mine..."
    scene sc454 with dissolve
    p "Your tits are mine..."
    scene sc454a with Dissolve(0.1)
    scene sc454b with Dissolve(0.1)
    scene sc454c with Dissolve(0.1)
    sa "I'm all yours!"
    scene sc455 with dissolve
    p "Look at them!"

    scene sc454aa:
        pause 0.06
        "sc454aaa"
        pause 0.06
        "sc455"
        pause 0.0003
        "sc455a"
        pause 0.0003
        "sc456finger"
        pause 0.06
        "sc456"
        pause 0.06
        "sc457"
        pause 0.0003
        "sc458"
        pause 0.0003
        "sc459"
        pause 0.06
        "sc460"
        pause 0.06
        "sc461"
        pause 0.06
        "sc462"
        pause 0.06
        "sc463"
        pause 0.06
        "sc464"
        pause 0.06
        "sc465"
        pause 0.09
        "sc466"
        pause 0.12
        "sc465a"
        pause 0.06
        "sc464"
        pause 0.06
        "sc463"
        pause 0.06
        "sc462"
        pause 0.06
        "sc461"
        pause 0.06
        "sc460"
        pause 0.06
        "sc459"
        pause 0.06
        "sc458"
        pause 0.0003
        "sc457"
        pause 0.0003
        "sc456"
        pause 0.06
        "sc456finger"
        pause 0.06
        "sc455a"
        pause 0.0003
        "sc455"
        pause 0.0003
        "sc454aaa"
        pause 0.06
        "sc454aa"
        pause 0.06
        repeat
    pause

    scene sc521 with dissolve
    p "Lie down, my cat."
    scene sc555 with dissolve
    p "You're so beautiful..."
    scene sc556 with dissolve
    pause
    scene sc557 with dissolve
    sa "Hug me!"
    scene sc558 with dissolve
    sa "I love you, cat!"
    p "I love you, too!"
    scene sc559 with dissolve
    pause
    scene sc560 with dissolve
    pause
    scene sc561 with dissolve
    p "I'm going in, babe!"
    scene sc562 with hpunch
    sa "Ooohhh!"
    scene sc563 with dissolve
    pause
    scene sc564 with dissolve
    pause
    scene sc565 with dissolve
    sa "Aaahhh!"
    scene sc566 with dissolve
    pause
    scene sc567 with dissolve
    pause
    scene sc568 with dissolve
    pause
    scene sc569 with hpunch
    pause
    scene sc570 with dissolve
    pause
    scene sc571 with dissolve
    pause
    scene sc572 with dissolve
    pause
    scene sc573 with dissolve
    pause
    scene sc574 with dissolve
    p "I love you, babe..."
    scene sc575 with dissolve
    sa "I love you more!"
    scene sc576 with dissolve
    scene sc575 with dissolve
    pause
    scene sc577 with vpunch

label misio:
    scene sc577:
        pause 0.0333
        "sc578"
        pause 0.0333
        "sc579"
        pause 0.0333
        "sc580"
        pause 0.0333
        "sc581"
        pause 0.0333
        "sc582"
        pause 0.0333
        "sc583"
        pause 0.0333
        "sc584"
        pause 0.0333
        "sc585"
        pause 0.0333
        "sc586"
        pause 0.0333
        "sc587"
        pause 0.0333
        "sc588"
        pause 0.0333
        "sc589"
        pause 0.0333
        "sc590"
        pause 0.0333
        "sc591"
        pause 0.0333
        "sc592"
        pause 0.0333
        "sc593"
        pause 0.0333
        "sc594"
        pause 0.0333
        "sc595"
        pause 0.0333
        "sc596"
        pause 0.0333
        "sc597"
        pause 0.0333
        "sc598"
        pause 0.0333
        "sc599"
        pause 0.0333
        "sc600"
        pause 0.0333
        "sc601"
        pause 0.0333
        "sc602"
        pause 0.0333
        "sc603"
        pause 0.0333
        "sc604"
        pause 0.0333
        "sc605"
        pause 0.0333
        "sc606"
        pause 0.0333
        "sc607"
        pause 0.0333
        "sc608"
        pause 0.0333
        "sc609"
        pause 0.0333
        "sc610"
        pause 0.0333
        "sc611"
        pause 0.0333
        "sc612"
        pause 0.0333
        "sc613"
        pause 0.0333
        "sc614"
        pause 0.0333
        "sc615"
        pause 0.0333
        "sc616"
        pause 0.0333
        "sc617"
        pause 0.0333
        "sc618"
        pause 0.0333
        "sc619"
        pause 0.0333
        "sc620"
        pause 0.0333
        "sc621"
        pause 0.0333
        "sc622"
        pause 0.0333
        "sc623"
        pause 0.0333
        "sc624"
        pause 0.0333
        "sc625"
        pause 0.0333
        "sc626"
        pause 0.0333
        "sc627"
        pause 0.0083
        "sc628"
        pause 0.0083
        "sc629"
        pause 0.0083
        "sc630"
        pause 0.0083
        "sc631"
        pause 0.0083
        repeat
    pause

    sa "Keep going, baby..."

    scene sc577:
        pause 0.0222
        "sc578"
        pause 0.0222
        "sc579"
        pause 0.0222
        "sc580"
        pause 0.0222
        "sc581"
        pause 0.0222
        "sc582"
        pause 0.0222
        "sc583"
        pause 0.0222
        "sc584"
        pause 0.0222
        "sc585"
        pause 0.0222
        "sc586"
        pause 0.0222
        "sc587"
        pause 0.0222
        "sc588"
        pause 0.0222
        "sc589"
        pause 0.0222
        "sc590"
        pause 0.0222
        "sc591"
        pause 0.0222
        "sc592"
        pause 0.0222
        "sc593"
        pause 0.0222
        "sc594"
        pause 0.0222
        "sc595"
        pause 0.0222
        "sc596"
        pause 0.0222
        "sc597"
        pause 0.0222
        "sc598"
        pause 0.0222
        "sc599"
        pause 0.0222
        "sc600"
        pause 0.0222
        "sc601"
        pause 0.0222
        "sc602"
        pause 0.0222
        "sc603"
        pause 0.0222
        "sc604"
        pause 0.0222
        "sc605"
        pause 0.0222
        "sc606"
        pause 0.0222
        "sc607"
        pause 0.0222
        "sc608"
        pause 0.0222
        "sc609"
        pause 0.0222
        "sc610"
        pause 0.0222
        "sc611"
        pause 0.0222
        "sc612"
        pause 0.0222
        "sc613"
        pause 0.0222
        "sc614"
        pause 0.0222
        "sc615"
        pause 0.0222
        "sc616"
        pause 0.0222
        "sc617"
        pause 0.0222
        "sc618"
        pause 0.0222
        "sc619"
        pause 0.0222
        "sc620"
        pause 0.0222
        "sc621"
        pause 0.0222
        "sc622"
        pause 0.0222
        "sc623"
        pause 0.0222
        "sc624"
        pause 0.0222
        "sc625"
        pause 0.0222
        "sc626"
        pause 0.0222
        "sc627"
        pause 0.0055
        "sc628"
        pause 0.0055
        "sc629"
        pause 0.0055
        "sc630"
        pause 0.0055
        "sc631"
        pause 0.0055
        repeat
    pause

menu:
    "Faster":
        jump cum1
    "Slower":
        jump misio

label cum1:
    scene sc577:
        pause 0.0222
        "sc579"
        pause 0.0222
        "sc581"
        pause 0.0222
        "sc583a"
        pause 0.0222
        "sc585a"
        pause 0.0222
        "sc587a"
        pause 0.0222
        "sc589a"
        pause 0.0222
        "sc591a"
        pause 0.0222
        "sc593a"
        pause 0.0222
        "sc595a"
        pause 0.0222
        "sc597a"
        pause 0.0222
        "sc599a"
        pause 0.0222
        "sc601a"
        pause 0.0222
        "sc603a"
        pause 0.0222
        "sc605a"
        pause 0.0222
        "sc607a"
        pause 0.0222
        "sc609a"
        pause 0.0222
        "sc611a"
        pause 0.0222
        "sc613a"
        pause 0.0222
        "sc615a"
        pause 0.0222
        "sc617a"
        pause 0.0222
        "sc619a"
        pause 0.0222
        "sc621a"
        pause 0.0222
        "sc623"
        pause 0.0222
        "sc625"
        pause 0.0222
        "sc627"
        pause 0.0222
        "sc629"
        pause 0.0222
        repeat
    pause

menu:
    "Cum with her.":
        jump cumwh

label cumwh:
    scene sc635:
        pause 0.0166
        "sc636"
        pause 0.0166
        "sc637"
        pause 0.0166
        "sc638"
        pause 0.0166
        "sc639"
        pause 0.0166
        "sc640"
        pause 0.0166
        "sc641"
        pause 0.0166
        "sc642"
        pause 0.0166
        "sc643"
        pause 0.0166
        "sc644"
        pause 0.0166
        "sc645"
        pause 0.0166
        "sc646"
        pause 0.0166
        "sc647"
        pause 0.0166
        "sc648"
        pause 0.0166
        "sc649"
        pause 0.0166
        "sc650"
        pause 0.0166
        "sc651"
        pause 0.0166
        "sc652"
        pause 0.0166
        "sc653"
        pause 0.0166
        "sc654"
        pause 0.0166
        "sc655"
        pause 0.0166
        "sc656"
        pause 0.0166
        "sc657"
        pause 0.0166
        "sc658"
        pause 0.0166
        "sc633"
        pause 0.0166
        "sc634"
        pause 0.0166
        repeat
    p "I'm cumming!"
    sa "Me, too!"
    pause


menu:
    "Inside.":
        jump insi

    "Pull out.":
        jump outi

label insi:
    stop music fadeout 3.0
    scene sc741 with flash
    scene sc741 with flash
    scene sc741 with flash
    sa "Aaahhh!"
    scene sc742 with dissolve
    sa "Oooohh, baby..."
    scene sc743 with dissolve
    sa "You're gonna be a dad!"
    p "WHAT?!"
    sa "Hahaha."
    sa "You should've seen your face!"
    scene black with Dissolve(1.0)
    scene sc744 with dissolve
    sa "Don't you ever leave me..."
    p "I won't..."
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    jump ep3

label outi:
    stop music fadeout 3.0
    scene sc745 with dissolve
    sa "Ooofff, cum baby cum!"
    scene sc746 with flash
    scene sc746 with flash
    scene sc746 with flash
    sa "Aaahhh!"
    scene sc747 with dissolve
    sa "That's a lot of cum..."
    scene sc748 with dissolve
    sa "You have to clean it now!"
    scene black with Dissolve(1.0)
    scene sc744 with dissolve
    sa "Don't you ever leave me..."
    p "I won't..."
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    jump ep3
