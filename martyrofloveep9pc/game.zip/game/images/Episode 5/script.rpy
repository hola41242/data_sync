#Important Decisions
default choice68a = False
default choice68b = False
default choice69a = False
default choice69b = False
default choice70a = False
default choice70b = False
default choice71a = False
default choice71b = False
default choice72a = False
default choice72b = False
default choice81a = False
default choice81b = False
default choice82a = False
default choice82b = False


# Start Episode 5
label ep5:

    $ renpy.movie_cutscene("videos/fall.ogv")

    scene ima510 with dissolve
    play music "audio/bentomorrow.ogg"
    cs "I don't know what to do..."
    cs "I'm tired of pretending to be strong..."
    scene ima511 with dissolve
    cs "When are you going to wake up, mom?"
    cs "I need you here with me...right now..."
    cs "I don't want to do it..."
    scene ima512 with Dissolve(1.5)
    pause 1
    scene black with Dissolve(2.0)

    scene ima363 with dissolve
    p "Hey, Christina, what's going on?"
    cs "Hey, come on in, take a seat."
    scene ima364 with dissolve
    p "Thanks..."
    scene ima365 with dissolve
    p "So, what is it? What did you want to tell me?"
    cs "Are you in a hurry?"
    p "I'm not, it's just that you said over the phone it was important, that's why I'm here...is it about S?"
    scene ima366 with dissolve
    cs "In a way it is..."
    scene ima367 with dissolve
    cs "I'm gonna need some alcohol, do you want some?"
    p "I'm good, thanks...I think I'm not gonna drink anymore, you know, my training and all."
    cs "Oh, yeah, S told me about it...so, you're dropping out of St. Francis..."
    p "Not dropping out...not yet, I'm suspending my studies for a year tops, that's the agreement I got with my mom...you know what parents are like..."
    cs "I don't know actually...S hasn't told you anything about me, huh?"
    p "Mmm, nope, not really...we don't talk about you...but the few times she's done it, it's like...uhm...I can sense that she admires you, to be honest..."
    scene ima368 with dissolve
    cs "Admires me?!"
    p "Yes, yes, I don't remember how it came out, but she said you're the strongest person she knows...I don't know why she said it, but those were her exact words..."
    scene ima369 with dissolve
    cs "I'm going for that drink...be right back."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene ima370 with Dissolve(2.0)
    play music "audio/foundletters.mp3"
    pause 2
    scene ima371 with dissolve
    pause 2
    scene ima372 with dissolve
    pause 2
    scene ima373 with dissolve
    pause 2
    play sound "audio/breakingglass1.ogg"
    scene ima374 with dissolve
    scene ima374 with vpunch
    cs "Fuuuck!"
    scene black with dissolve
    scene ima375 with dissolve
    p "What happened?! Are you hurt?!"
    cs "I'm not."
    scene ima376 with dissolve
    p "Hey, what's wrong?"
    cs "Nothing."
    p "I understand if you don't want to tell me, we're not that close, but you're definitely not ok...do you want me to call S?"
    cs "No need, I'm exhausted, that's all..."
    scene ima377 with dissolve
    cs "Have you ever been fed up with life?"
    p "Fed up with life? Like very stressed, depressed, something like that?"
    cs "No, like tired of living."
    scene ima377 with hpunch
    p "Tired of living?! That's...heavy...why are you asking such thing? Should I worry?"
    cs "Just answer the question..."
    p "Uuuhm...I've been down, yeah, like really down when I lost my dad...but...tired of living? I've never felt that way...are you feeling that way right now?"
    scene ima378 with dissolve
    cs "Don't worry, I'm not gonna kill myself..."
    cs "If your mother and S were in danger, who would you save? You can only save one..."
    p "What? What a weird question...Are you sure you're ok?"
    cs "Just answer fucking the question..."
    p "I don't want to."
    scene black with dissolve
    scene ima379 with dissolve
    pt "What's she doing?"
    p "Isn't it cold?"
    cs "I don't care..."
    scene ima380 with dissolve
    pt "I'm kind of lost here...don't know what to do..."
    pause
    p "My mom."
    scene ima381 with dissolve
    p "I'd save my mom."
    scene ima382 with dissolve
    cs "Me, too."
    scene ima383 with dissolve
    cs "I'm going to the bathroom..."
    p "Ok, I'm going with you."
    scene ima384 with dissolve
    pause
    p "Oh, no, I meant..."
    scene ima385 with dissolve
    cs "I told you I'm not gonna hurt myself..."
    p "Yeah, well, you never know...better safe than sorry."
    scene black with dissolve
    scene ima386 with dissolve
    pt "Man, this is super uncomfortable...what could it be? I don't know what she's going through so better be careful with what I say..."
    pt "Sometimes women want us to be not only psychologists, but also psychics!"
    scene ima387 with dissolve
    pt "Uuuhm...she's all dressed up, maybe she had a date and got canceled at the last minute...I don't know...I don't think I want to handle this..."
    stop music fadeout 3.0

menu:
    "Text S.":
        jump choice68a

    "Don't.":
        jump choice68b

label choice68a:

    $ choice68a = True


    p "{i}\"Sami, I'm at your friend Christina's place. Can you come?\"{/i}"
    sa "{i}\"What's wrong? What are you doing there, cat?\"{/i}"
    p "{i}\"She said she needed to tell me something important, but now she's...not feeling well.\"{/i}"
    sa "{i}\"Be there in 20, mwah!\"{/i}"
    scene black with dissolve
    scene ima389 with dissolve
    p "Hey, you got me worried...are you feeling better?"
    cs "Yeah, I had a little breakdown, that's all...too many things going on right now in my life..."
    p "I see..."
    play sound "audio/bell.mp3"
    scene ima390 with dissolve
    cs "I'm not expecting anybody..."
    scene ima391 with dissolve
    play music "audio/secret.ogg"
    cs "S?! Hi...what are you doing here?"
    sa "Hey! [p] called...are you ok?"
    cs "I'm fine, come in, girl."
    scene ima392 with dissolve
    p "Hey, baby!"
    sa "Hey, cat!"
    p "I let you girls talk, ok?"
    sa "Sure, I'll call you later."
    scene ima393 with hpunch
    sa "Mwah!"
    scene ima394 with dissolve
    sa "Love you!"
    p "Love you, too!"
    scene ima395 with dissolve
    p "Bye, Christina."
    cs "Yeah, bye, thanks for everything."
    p "No problem."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)

    scene ima422 with dissolve
    play music "audio/groovetube.ogg"
    pt "Okay, that was awkward..."
    scene ima396 with Dissolve(2.0)
    pause
    scene ima400 with Dissolve(2.0)
    pause
    scene ima397 with dissolve
    pt "I'm hungry..."
    scene ima398 with dissolve
    pt "What the...where's my wallet?"
    scene ima399 with dissolve
    pt "Fuck...it must've fallen in the kitchen when I sat on the floor!"
    scene ima399a with dissolve
    pt "Well, nothing I can do about it, let's go back..."
    stop music fadeout 2.0
    scene black with dissolve
    scene ima401 with Dissolve(1.5)
    play music "audio/motivacional.ogg"

    scene ima402b:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause

    sa "Babe! Babe!"
    pt "S? What does she have in her hand?"
    pt "Oh, come on! She's just the best!"
    sa "Cat! Look what you forgot!"
    scene ima402 with dissolve
    p "You're awesome, babe, seriously, always looking after me..."
    pt "Man, I gotta be a better man...for her..."
    pt "Why do I want to cry?"
    scene ima403 with dissolve
    stop music fadeout 2.0
    p "Careful, cat, this dude's gonna get on the sidewalk..."
    pt "What's he doing?"
    scene ima404 with dissolve
    scene ima404 with vpunch
    play music "audio/tension1.ogg"
    pt "What the hell?! Is that a gun?!"
    scene ima405 with dissolve
    pt "No! S!!!"

menu:
    "Stop her!":
        jump choice69a

    "Move, motherfucker!!!":
        jump choice69b

label choice69a:

    $ choice69a = True

    scene ima406 with dissolve
    pt "What are you trying to do, cat?! Save me? I won't let you do that!"
    pt "Dad? Is it you moving my hand? You want to save her too, don't you?"
    scene ima407 with dissolve
    pt "Hey, cat! Look at me! Look at me!"
    pt "..."
    pt "She won't..."
    pt "Saving me is all she has in her mind right now..."
    pt "I don't deserve you...never did..."
    pt "Why do I feel everything's happening in slow motion?"
    pt "Is this going to be the last..."

    play sound "audio/silencer.ogg"
    stop music
    scene black

    pause
    pt "What was that sound?"
    pt "Where am I?"
    p "Hello?"
    p "Hello??"
    pt "Wait...did that guy shoot me?!"
    pt "Am I..."
    pt "...dead?!"
    pt "Wasn't my life supposed to flash before my eyes in a second?"
    pt "I didn't see any of that..."
    pt "Does that mean I'm alive?"
    pt "If I'm alive then...S!"
    p "S!"
    p "Samantha!"
    p "Samantha!!"
    p "S!!!"
    scene black with dissolve
    play sound "audio/policesiren.ogg"
    scene ima408a with dissolve
    scene ima408b with dissolve
    scene ima408a with dissolve
    scene black with dissolve
    scene ima408a with dissolve
    scene ima408b with dissolve
    scene ima408 with dissolve
    play music "audio/sadpiano.ogg"
    pt "What...what's this?"
    pt "Samantha! Where are you?!"
    play sound "audio/scrying.ogg"
    pt "S!!!"
    pt "No, no, no baby, don't cry...I'm ok..."
    scene ima409 with vpunch
    scene ima409 with hpunch
    scene ima409 with vpunch
    scene ima409 with hpunch
    scene ima409 with vpunch
    pt "What the fuck is this?!?!"
    pt "Why's my body over there?!?!"
    pt "Samantha!"
    pt "I can't speak!"
    scene ima410 with Dissolve(1.5)
    scene ima410 with vpunch
    pt "What?!?!"
    scene ima411 with vpunch
    scene ima411 with vpunch
    pt "My hands!!!"
    pt "No, no, noooo, this can't be happening!!!"
    pt "I...I..."
    sa "Whyyyyy??? Whyyy???"
    scene ima412 with dissolve
    stop sound fadeout 3.0
    pt "Why?"
    pt "I don't know why, baby...I don't know why that guy shot me...I don't know why this had to happen..."
    scene ima409 with dissolve
    pt "I have to go now..."
    scene ima413 with dissolve
    pt "Something is taking me..."
    scene ima413a with dissolve
    pt "What I would give to hug you one last time..."
    pt "So many memories we won't get to make...it is unfathomably sad..."
    pt "This's the sadness I felt earlier...wasn't I supposed to feel peace?"
    scene ima413c with dissolve
    pt "It just hurts...a lot...makes me angry..."
    pt "I don't want to die!"
    pt "..."
    scene ima413 with dissolve
    pt "I had to..."
    pt "It had to be me..."
    pt "This crazy world needs you, S, your kindness, your empathy...they're unmatched..."
    scene ima413b with dissolve
    pt "You had to live, my love...You're the better person!"
    pt "Let it all out, cat, and then...grow stronger!"
    scene ima413b with vpunch
    scene ima413b with vpunch
    pt "Do something with that pain!!!"
    pt "...our pain."
    scene ima414 with dissolve
    pt "That hug will have to wait..."
    pt "I'm sure I'll see you again..."
    pt "Take your time."
    scene ima415 with dissolve
    pt "Good bye..."
    pt "My cat."
    stop music fadeout 4.0
    scene black with Dissolve(4.0)
    pause
    scene mol1 with dissolve
    pause
    scene black with Dissolve(2.0)
    scene mol2 with Dissolve(2)
    pause
    scene black with Dissolve(4)
    pause

menu:
    "End game.":
        jump endgame
    "Play as Franz.":
        jump franzstory

label endgame:

    $ renpy.quit()

label choice69b:

    $ choice69b = True

    pt "What the hell's happening to my body?! It's not responding!"
    pt "I have to hurry!"
    scene ima416 with hpunch
    pt "Nooooooo!!! What are you doing?!!!"
    pt "Move, motherfu..."
    play sound "audio/silencer.ogg"
    stop music
    scene ima417 with vpunch
    scene ima417 with vpunch
    pause
    play music "audio/filaments.ogg"
    scene ima418 with Dissolve(2.0)
    play sound "audio/policesiren.ogg"
    uk "Fuuucckk!!!"
    scene ima419 with Dissolve(2.0)
    pause
    scene ima420 with Dissolve(2.0)
    pause
    stop sound
    play sound "audio/screamingno.ogg"
    scene ima421 with Dissolve(1.2)
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    pause 0.5
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    pause 0.5
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    scene ima421 with hpunch
    scene ima421 with vpunch
    pause
    scene ima423 with Dissolve(2.0)
    pause
    scene ima423a with dissolve
    scene ima423b with dissolve
    scene ima423c with dissolve
    scene ima423d with dissolve
    stop sound
    stop music fadeout 4.0
    scene black with Dissolve(4.0)
    pause
    scene hasbecome with dissolve
    pause
    scene black with Dissolve(2.0)
    scene mol2 with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause
    jump samfuneral

label choice68b:

    $ choice68b = True

    scene ima388 with dissolve
    cs "But I want to know what she wanted to tell me, that's why I came here in the first place..."
    scene black with dissolve
    play music "audio/russian3.mp3"
    scene ima389 with dissolve
    p "Hey, you got me worried...are you feeling better?"
    cs "Yeah, I had a little breakdown, that's all...too many things going on right now in my life..."
    p "I see..."
    cs "Why are you standing? Come have a seat with me."
    p "Uuuhhmm, ok."
    scene ima442 with dissolve
    cs "I have to thank you...you've been really helpful."
    scene ima443 with dissolve
    pause
    pt "Chill, bro, perhaps she's just one of those girls who unnecessarily touches others...she doesn't strike me as such, though."
    pt "Well, it's not like she's squeezing...it probably means nothing..."
    scene ima444 with dissolve
    pt "Okayyyy, what's she doing now?"
    p "What are you..."
    scene ima445 with hpunch
    p "Whoa! What the hell?! What are you doing?!"
    cs "What...you don't like my nipples?"
    p "What?! No! You're Samantha's best friend...are you sure you're ok?"
    cs "For someone who doesn't like them, you just can't look away..."
    scene ima446 with dissolve
    p "What the...too many eyes about to judge me!"
    cs "Don't you want to lick them?"
    stop music fadeout 3.0

menu:
    "Think!":
        jump choice70a

    "Not with your dick!":
        jump choice70b

label choice70a:

    $ choice70a = True

    p "I don't know what's gotten into you, probably you drank too much, Christina..."
    p "I'm just gonna go..."
    scene black with Dissolve(1.5)
    play music "audio/beat6.ogg"
    scene ima425 with dissolve
    pt "What the hell was that? I didn't think she even liked me...if she was hotter maybe..."
    pt "What am I thinking?"
    pt "That's a line I'm not gonna cross..."
    scene ima424 with dissolve
    pt "It's getting late...not many people on the streets..."
    scene ima426 with dissolve
    pt "Should I tell S? No, first, I'm..."
    uk "[p] Blanco!"
    scene ima427 with dissolve
    pause 0.5
    scene ima428 with dissolve
    play sound "audio/silencer.ogg"
    stop music
    scene ima428b with Dissolve(0.1)
    scene ima428a with Dissolve(0.1)

    scene black
    pause
    play music "audio/bensadday.ogg"
    pt "What happened?"
    pt "That guy knew my name..."
    pt "Did he shoot me?"
    pt "Why?"
    scene ima429 with vpunch
    pt "What the hell?! These are not my hands!"
    pt "Where am I?"
    scene ima431 with dissolve
    pt "I must be dreaming..."
    pt "This can't be real!"
    pt "It feels like I'm awake though..."
    scene ima432 with dissolve
    uk "My head's bigger than [p]'s..."
    uk "[p]...did you die?"
    uk "Where did you go?"
    uk "This's not Hell nor Heaven...just...Infinite Void?"
    uk "I'm so sorry...I failed you...your life was just starting..."
    uk "I feel so sad for you...so guilty...I should've done more while I was you..."
    uk "..."
    uk "While I was who?"
    uk "I'm losing our memories...what was your name?"
    scene ima429 with dissolve
    uk "No, not yet..."
    uk "Not yet..."
    uk "I'm not done..."
    uk "We're not done..."
    stop music fadeout 4.0
    scene black with Dissolve(4.0)
    pause

menu:
    "End game.":
        jump endgame
    "Play as Franz.":
        jump franzstory

label choice70b:

    $ choice70b = True

    scene ima447 with hpunch
    p "Give me those tits!"
    cs "Ouch!"
    scene ima448 with dissolve
    cs "Wait, not here, it's uncomfortable...let's go upstairs."


label chrissex1:

    if _in_replay:
        $ pf = persistent.p

    play music "audio/exercisechris.ogg" volume 0.6
    scene black with Dissolve(1.5)
    scene ima460 with dissolve
    pt "Nice contacts..."
    scene ima461 with dissolve
    cs "Come..."
    scene ima462 with dissolve
    pause
    scene ima463 with hpunch
    p "Ssssss..."
    scene ima464 with dissolve
    p "That's a fine ass."
    scene ima465 with dissolve
    cs "You comin' or what?"
    p "Oh, I AM comming..."
    p "Inside!"
    scene ima466 with dissolve
    cs "Oh, yeah, come and get it."
    scene ima467 with dissolve
    p "I'm gonna fuck you well!"
    cs "Too much talking..."
    play sound "audio/spit.ogg"
    scene ima468 with dissolve
    p "Lean on the bed..."
    scene ima469 with dissolve
    p "Ooff, you're wet already."
    cs "It got in so eas..."
    scene ima471 with hpunch
    cs "Aaaahhhh!!"
    scene ima470 with dissolve
    cs "Dude, I love your cock..."
    p "I know you do...take it, bitch!"
    scene ima471 with hpunch
    cs "Aaaahhhh!!"
    scene ima472 with dissolve
    cs "Just to be clear...I'm not your bitch."
    scene ima472a with dissolve
    p "Haha, I got a little carried away...turn around, I want to see your face..."
    p "Bitch!"
    cs "You're the bitch!"
    scene ima473 with hpunch
    cs "You wanted me since day one, didn't you?"
    scene ima475 with dissolve
    p "You're so hot, Tina..."
    scene ima474 with dissolve
    cs "Tina? Nobody calls me that."
    scene ima476 with hpunch
    p "I do now!"
    scene ima477 with dissolve

    scene ima477:
        pause 0.0233
        "ima478"
        pause 0.0233
        "ima479"
        pause 0.0233
        "ima480"
        pause 0.0233
        "ima481"
        pause 0.0233
        "ima482"
        pause 0.0233
        "ima483"
        pause 0.0233
        "ima484"
        pause 0.0233
        "ima485"
        pause 0.0233
        "ima486"
        pause 0.0233
        "ima487"
        pause 0.0233
        "ima488"
        pause 0.0233
        "ima489"
        pause 0.0233
        "ima490"
        pause 0.0233
        "ima491"
        pause 0.0233
        "ima492"
        pause 0.0233
        "ima493"
        pause 0.0233
        "ima494"
        pause 0.0233
        "ima495"
        pause 0.0233
        "ima496"
        pause 0.0233
        "ima497"
        pause 0.0233
        "ima498"
        pause 0.0233
        "ima499"
        pause 0.0233
        "ima500"
        pause 0.0233
        "ima501"
        pause 0.0233
        "ima502"
        pause 0.0233
        "ima503"
        pause 0.0233
        "ima504"
        pause 0.0233
        "ima505"
        pause 0.0233
        "ima506"
        pause 0.0233
        "ima477"
        pause 0.0233
        repeat
    pause

    cs "Oh, yeah, faster!"

    scene ima477:
        pause 0.0166
        "ima478"
        pause 0.0166
        "ima479"
        pause 0.0166
        "ima480"
        pause 0.0166
        "ima481"
        pause 0.0166
        "ima482"
        pause 0.0166
        "ima483"
        pause 0.0166
        "ima484"
        pause 0.0166
        "ima485"
        pause 0.0166
        "ima486"
        pause 0.0166
        "ima487"
        pause 0.0166
        "ima488"
        pause 0.0166
        "ima489"
        pause 0.0166
        "ima490"
        pause 0.0166
        "ima491"
        pause 0.0166
        "ima492"
        pause 0.0166
        "ima493"
        pause 0.0166
        "ima494"
        pause 0.0166
        "ima495"
        pause 0.0166
        "ima496"
        pause 0.0166
        "ima497"
        pause 0.0166
        "ima498"
        pause 0.0166
        "ima499"
        pause 0.0166
        "ima500"
        pause 0.0166
        "ima501"
        pause 0.0166
        "ima502"
        pause 0.0166
        "ima503"
        pause 0.0166
        "ima504"
        pause 0.0166
        "ima505"
        pause 0.0166
        "ima506"
        pause 0.0166
        "ima477"
        pause 0.0166
        repeat
    pause

    scene ima477:
        pause 0.0133
        "ima478"
        pause 0.0133
        "ima479"
        pause 0.0133
        "ima480"
        pause 0.0133
        "ima481"
        pause 0.0133
        "ima482"
        pause 0.0133
        "ima483"
        pause 0.0133
        "ima484"
        pause 0.0133
        "ima485"
        pause 0.0133
        "ima486"
        pause 0.0133
        "ima487"
        pause 0.0133
        "ima488"
        pause 0.0133
        "ima489"
        pause 0.0133
        "ima490"
        pause 0.0133
        "ima491"
        pause 0.0133
        "ima492"
        pause 0.0133
        "ima493"
        pause 0.0133
        "ima494"
        pause 0.0133
        "ima495"
        pause 0.0133
        "ima496"
        pause 0.0133
        "ima497"
        pause 0.0133
        "ima498"
        pause 0.0133
        "ima499"
        pause 0.0133
        "ima500"
        pause 0.0133
        "ima501"
        pause 0.0133
        "ima502"
        pause 0.0133
        "ima503"
        pause 0.0133
        "ima504"
        pause 0.0133
        "ima505"
        pause 0.0133
        "ima506"
        pause 0.0133
        "ima477"
        pause 0.0133
        repeat
    pause

    scene ima507 with Dissolve(1.5)
    pause
    scene ima508 with Dissolve(1.5)
    pause
    scene ima508a with Dissolve(1.5)
    pause

    scene ima509 with Dissolve(1.5)

    scene ima509:
        pause 0.3
        "ima509a"
        pause 0.3
        "ima509"
        pause 0.3
        "ima509a"
        pause 0.3
        repeat
    pause

    stop music fadeout 3.0

    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    play music "audio/gangstarap.ogg"
    scene ima433 with dissolve
    p "Fuuucckk!"
    pt "I'm having this post nut clarity bullshit..."
    pt "What the fuck's wrong with me?! I don't like this person I'm becoming..."
    scene ima434 with dissolve
    pt "Is that S? What's she doing here so late?!"
    pt "Not a good time to see her, I feel like shit!"
    pt "That's because I am shit!"
    pt "Not gonna be able to deal with this guilt..."
    scene ima435 with dissolve
    sa "Baaabe! What are you doing here?"
    p "Cat! I have to te..."
    scene ima436 with dissolve
    scene ima436a with dissolve
    scene ima436b with dissolve
    uk "[p] Blanco!"
    scene ima437 with Dissolve(0.2)
    play sound "audio/bikebrake.ogg"
    scene ima437a with Dissolve(0.2)
    scene ima437a with vpunch
    sa "Noooooo..."
    scene ima438 with dissolve
    play sound "audio/silencer.ogg"
    stop music
    scene ima438b with Dissolve(0.1)
    scene ima438a with Dissolve(0.1)
    scene black
    pause
    play sound "audio/policesiren.ogg"
    scene black with dissolve
    play music "audio/filaments.ogg"
    scene ima439a with dissolve
    scene ima439b with dissolve
    scene ima439a with dissolve
    scene black with dissolve
    scene ima439a with dissolve
    scene ima439b with dissolve
    scene ima439 with dissolve
    uk "Fuuucckk!!!"
    pt "All this blood..."
    pt "...is not mi...S!"
    p "Samantha!!!"
    pt "Shit, my head hurts..."
    p "Sam! Are you..."
    scene ima440 with Dissolve(2.0)
    p "What the..."
    play sound "audio/screamingno.ogg"
    scene ima441 with Dissolve(1.2)
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    pause 0.5
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    pause 0.5
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    scene ima441 with hpunch
    scene ima441 with vpunch
    pause
    stop sound
    scene ima441a with Dissolve(1.0)
    scene ima441b with Dissolve(1.0)
    scene ima441c with Dissolve(1.0)
    pause
    stop music fadeout 4.0
    scene black with Dissolve(4.0)
    pause
    scene hasbecome with dissolve
    pause
    scene black with Dissolve(2.0)
    scene mol2 with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause
    jump samfuneral

label samfuneral:

    pt "Is life actually nothing more than a tragedy?"
    pt "From the very first moment we're born, we begin to die..."
    pt "That's right, we're not living, we're dying...dying every minute of every day..."
    pt "We've all been lied to!"
    pt "This is not life, can't be..."
    play music "audio/thegreenroad.ogg"
    scene ima1050a with Dissolve(3.0)
    pt "This is Death."
    scene ima1050b with Dissolve(1.0)
    scene ima1050 with Dissolve(1.0)
    pt "It's always been there, lurking..."
    pt "It doesn't matter if we don't want to pay attention to it, it's inevitable..."
    scene ima1051 with dissolve
    pt "The fate no one can escape..."
    pt "Death will come for all of us one day..."
    pt "We all know it and knowing it doesn't make it easier to accept."
    scene ima1052 with dissolve
    pt "It was way too soon for you, S...way too soon..."
    pt "It's so fucking painful..."
    pt "I can stand pain...what I can't tolerate is the lack of explanation..."
    pt "Why you?"
    pt "I know why..."
    pt "Because I was a fucking coward!!"
    pt "I'm so sorry, my cat..."
    scene ima1054 with dissolve
    pr "Would anyone like to say some words?"
    uk "I would..."
    scene ima1056 with dissolve
    pause 0.5
    scene ima1057 with dissolve
    scene ima1056 with dissolve
    pause 0.5
    scene ima1055 with dissolve
    uk "Everybody here knows that my cousin Samantha was the epitome of kindness, the most empathetic, righteous person ever..."
    sc "On my flight here, I had this recurring thought in my head I couldn't get rid of: \"Why her?\" She was so full of virtues, why did this have to happen to a person like her?"
    sc "Then I remember a conversation we had long time ago about \"The Curse of Virtue\", she called it: things end up badly even when you do the right thing all the time..."
    scene ima1058 with dissolve
    sc "I asked her: \"Then, why do it? Why do what's right in the first place?"
    sc "\"Duty and regret.\", she said."
    sc "\"I feel like it's my duty to do the right thing, especially when nobody else would...and I don't want the could haves and should haves come hunt me at night.\""
    sc "\"Duty and regret.\""
    sc "She was only 13, 14 at that time and she was already the best..."
    scene ima1059 with dissolve
    sc "A different breed of people, for sure...so caring, so brilliant, the smartest in the family...our Sam..."
    sc "We all are going to miss you..."
    scene ima1052 with dissolve
    sc "My cousin gave her life because she felt it was her responsibility to save another human being and I'm sure as hell that, wherever she is, she doesn't regret it."
    scene ima1053 with Dissolve(2.0)
    pause 1
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    pause
    scene ima1060 with Dissolve(3)
    play music "audio/samdeathsecretspot.ogg" fadein 3.0 volume 0.8
    pause 2.5
    scene ima1061 with Dissolve(1)
    pt "{i}\"Duty and regret.\"{/i}"
    pt "It sounded so like you..."
    scene ima1062 with Dissolve(1)
    pt "{i}\"I don't want the could haves and should haves come hunt me at night...\"{/i}"
    pt "I have so many of those right now..."
    pt "I need you so much!"
    scene black with Dissolve(1)
    scene ima1063 with Dissolve(2)
    pt "Perhaps, I can find you here..."
    scene ima1063a with Dissolve(2)
    pt "Perhaps, I can tell you how much I'm sorry..."
    scene ima1063b with Dissolve(2)
    pt "Samantha..."
    scene ima1064b with Dissolve(2)
    pause
    scene ima1064 with Dissolve(2)
    pt "Yes, babe, I am..."
    stop music fadeout 2.5
    scene black with Dissolve(2.5)


    scene ima1065d with dissolve
    play music "audio/walking.ogg"
    p "What the hell?! Where did the sun go?!"
    scene ima1065 with hpunch
    p "This can't be the same spot!"
    scene ima1065a with dissolve
    p "What happened here?!"
    scene ima1065c with dissolve
    pause 0.6
    scene black with Dissolve(2)
    scene ima1065b with Dissolve(2)
    p "That's how I remember it!"
    scene ima1066 with Dissolve(2)
    p "This's just too much, I'm going nuts!"
    p "I thought I'd find you here...don't know what to do anymore..."
    p "I can't deal with this guilt..."
    scene ima1067 with dissolve
    p "I could've been a better boyfriend, a better man...I could've spent more weekends with you, heard more of your stories..."
    p "I could have saved you!"
    scene ima1068 with dissolve
    p "God, I could have saved you!!!"
    p "I'm so sorry, I can't take it..."
    p "It should've been me! It should've been me..."
    scene ima1069 with dissolve
    p "I can't live through this..."
    p "I can't..."
    p "I..."
    scene ima1070 with Dissolve(2)
    p "...give up."
    stop music fadeout 2.5
    scene black with Dissolve(2.5)
    pause
    scene ima1071 with Dissolve(2)
    play music "audio/romantica2.ogg"
    pause 1
    scene ima1072 with dissolve
    pause 1
    scene ima1073 with dissolve
    pause 1
    scene ima1074 with dissolve
    pause 1
    scene ima1075 with dissolve
    pause 1

    scene ima1076 with dissolve
    pause
    scene ima1077 with dissolve
    pause
    scene ima1076 with dissolve
    pause
    scene ima1077 with dissolve
    pause

    scene ima1078 with dissolve

    scene ima1079:
        pause 0.3
        "ima1080"
        pause 0.3
        "ima1081"
        pause 0.3
        "ima1080"
        pause 0.3
        repeat
    pause

    scene ima1082:
        pause 0.3
        "ima1083"
        pause 0.3
        "ima1084"
        pause 0.3
        "ima1083"
        pause 0.3
        repeat
    pt "Huh? What's this heat? It feels like you!"
    p "Samantha!"

    scene ima1085:
        pause 0.3
        "ima1086"
        pause 0.3
        "ima1087"
        pause 0.3
        "ima1086"
        pause 0.3
        repeat
    pt "A snail?"
    pt "Glowing?! Am I dreaming?"

    scene ima1088 with Dissolve(2)

    scene ima1088:
        pause 0.3
        "ima1089"
        pause 0.3
        "ima1090"
        pause 0.3
        "ima1089"
        pause 0.3
        repeat
    pt "It's so beautiful...this can't be real..."

    scene ima1091 with dissolve
    scene ima1091:
        pause 0.3
        "ima1092"
        pause 0.3
        "ima1093"
        pause 0.3
        "ima1092"
        pause 0.3
        repeat
    p "Come here, buddy..."

    scene ima1094 with dissolve

    scene ima1095:
        pause 0.3
        "ima1096"
        pause 0.3
        "ima1097"
        pause 0.3
        "ima1096"
        pause 0.3
        repeat
    pt "Huh? Another one?"

    scene ima1098 with dissolve
    scene ima1099 with dissolve
    scene ima1100 with dissolve
    pause 0.7
    scene ima1101 with dissolve
    p "What?! No way!!!"
    scene ima1102 with dissolve
    pt "How is this..."
    scene ima1103 with dissolve
    pt "...possible?!"

    scene ima1104 with Dissolve(2)

    scene ima1104:
        pause 0.3
        "ima1105"
        pause 0.3
        "ima1106"
        pause 0.3
        "ima1107"
        pause 0.3
        repeat
    pt "Are you doing this, Samantha?"
    pt "Are you making this miracle?"
    pt "Where are you?"
    pt "I need you with me..."
    scene ima1109 with dissolve
    pt "I'm so sorry..."
    scene ima1112 with Dissolve(5)
    pause
    scene ima1111 with dissolve
    pause
    scene ima1113 with dissolve
    pt "It's getting warmer..."
    scene ima1114 with dissolve
    pt "Something's happening..."
    scene ima1115 with dissolve
    pt "S?"
    scene ima1116 with dissolve
    pause
    pt "I can feel your warmth..."
    scene ima1116a with dissolve
    pause
    scene ima1118 with Dissolve(2)
    pause
    scene ima1119 with Dissolve(2)
    pause
    scene ima1117 with Dissolve(2)
    pause
    scene ima1117a with Dissolve(2.5)
    scene ima1117c with Dissolve(2.5)
    pause
    stop music fadeout 3.0

    scene black with Dissolve(3.0)
    pause

    scene ima1655 with dissolve
    play music "audio/midnightseas.mp3"
    cd "How are you holding up, brother?"
    p "Not good, Candy, not good..."
    play sound "audio/femalecough.mp3"
    scene ima1656 with hpunch
    ri "Not well..."
    scene ima1658 with dissolve
    pause
    scene ima1659 with dissolve
    pause
    p "You remembered."
    scene ima1660 with dissolve
    p "You learned from her too, huh?"
    scene ima1657 with dissolve
    ri "Who else did? Because, apparently, you did not."
    p "Why you say so?"
    ri "You look like shit."
    scene ima1661 with dissolve
    ri "What...I'm just saying what we both can see...I hate to see people feeling sorry for themselves...you're his best friend, you should be the one telling him..."
    scene ima1662 with dissolve
    p "I'm not eating nor sleeping well, but come on, it's been only a week, I think I have the right to cry for a while..."
    scene ima1663 with dissolve
    cd "Of course you do...do whatever you need to heal."
    scene ima1664 with dissolve
    ri "But heal! Do not stay broken like this...Samantha was brave, strong! Not pathetic...This infuriates me! This is not what she..."
    scene ima1665 with Dissolve(1)
    pause
    scene ima1666 with dissolve
    pause
    scene ima1665 with Dissolve(1)
    pause
    scene ima1666 with dissolve
    pause
    scene ima1667 with dissolve
    ri "All right, you need to understand something, [p]: You are not the only one who's lost her!"
    ri "Ok, I get it, you have a broken heart, it may feel like the end of the world, but it's not, trust me...there are hundreds of things worse than that."
    ri "Having said that, get on your feet...and do it quickly...you owe it to her."
    scene ima1668 with dissolve
    ri "I have nothing else to tell you..."
    ri "Don't forget to take a shower."
    scene black with Dissolve(1)
    scene ima1669 with dissolve
    pause
    scene ima1670 with dissolve
    pt "It's not that bad, she's exaggerating...some eye drops, a little shave and we're good..."
    pt "\"You owe it to her...\""
    pt "\"You're not the only one who lost her!\""
    scene ima1671 with dissolve
    pt "She's right, S meant a lot to many people...she was my girlfriend, but also a friend, a cousin...a daughter!"
    pt "I wonder how Vittoria is doing..."
    stop music fadeout 2.0
    scene black with Dissolve(2)

    scene ima1672 with dissolve
    play sound "audio/bell.mp3"
    pause 3
    play sound "audio/opendoor.mp3"
    scene ima1673 with dissolve
    sc "Yes?"
    scene ima1674 with dissolve
    sc "You?! What are you doing here? You're not welcome."
    uk "Who is it, Anto?"
    ant "Nobody."
    play sound "audio/doorslam.ogg"
    pause 0.5
    scene ima1675 with vpunch
    p "What the hell?!"
    pt "They're blaming me for what happened..."
    ant "Do not open."
    uk "Why? I want to see who you're talking to like that..."
    play sound "audio/opendoor.mp3"
    scene ima1676 with dissolve
    uk "Oh!"
    uk "You're...were Samantha's boyfriend, right? I saw you at the funeral...uhm...[p]?"
    scene ima1677 with dissolve
    uk "I'm Ginevra, her aunt...Vittoria's sister."
    p "A pleasure...uhmm...I didn't mean to disturb any of you, I just wanted to know if there's anything I can do for Vittoria...she always treated me right and I came to help somehow..."
    scene ima1678 with dissolve
    p "But...I think I should get going, I wasn't sure if you blamed me for what happened...now I know..."
    scene ima1680 with dissolve
    gin "Nothing could be further from the truth, we don't think it was your fault...what did my daughter say?"
    p "She didn't have to say anything, I could feel it..."
    scene ima1679 with dissolve
    gin "Well, I'm telling you that's not what we think...neither Giuseppe nor my sister..."
    scene ima1681 with dissolve
    gin "Maybe she can tell you that herself..."
    scene ima1682 with dissolve
    gin "Come in, she didn't want to see anybody last time I checked, but I'll ask her, that's what I can do for you."
    p "Thank you."
    scene black with Dissolve(2)


    scene ima1683 with dissolve
    play music "audio/peacefulnight.mp3"
    pause
    scene ima1684 with dissolve
    vi "She'd just made us buy it the day before...Giuseppe wanted to get rid of it, but I wouldn't let him..."
    scene ima1685 with dissolve
    vi "I should've gotten her a cat!"
    p "Oh, Vittoria..."
    scene ima1686 with dissolve
    vi "I don't think I can live through this, [p]..."
    pt "That's exactly how I feel most of the time..."
    p "Don't talk like that."
    scene ima1687 with dissolve
    vi "It's too hard."
    p "I know it is."
    scene ima1688a with dissolve
    vi "My head's about to blow up and my eyes hurt so much, but that's nothing compared to how I feel inside..."
    p "You're not alone, Vittoria, I'm here for you...anything you need, I'll do it."
    scene ima1689a with dissolve
    pause
    scene ima1690a with dissolve
    vi "My daughter loved you so much..."
    pt "I know, she gave her life for me..."
    p "I didn't know how much I loved her, Vittoria...I wish I'd done it better..."
    vi "You made her very happy, that I can tell you...come, let's have a seat."
    scene black with dissolve
    scene ima1691a with dissolve
    p "Vittoria, I..."
    scene ima1692a with dissolve
    vi "Let me go first, I didn't think this was necessary, but my sister just told me something..."
    scene ima1693a with dissolve
    vi "I don't blame you for what happened, neither Giuseppe...and that's all you should care about..."
    vi "We wouldn't have had you in her funeral if we thought otherwise..."
    vi "We've seen the videos at the police station and yeah, it looks like he wants YOU dead, but..."
    scene ima1694 with dissolve
    pause
    scene ima1695 with dissolve
    vi "I'm sorry..."
    p "You don't have to be..."
    scene ima1696a with dissolve
    vi "You know, and don't take this personal, my husband did some research into you when Sam first introduced you to us...Giuseppe trusts nobody...and he has his ways to know things..."
    vi "He said you're as clean as they come: your life's been Samantha, college, home...He assured the family you had nothing to do with what happened."
    scene ima1697a with dissolve
    vi "Some people are just crazy, evil, they don't need any excuse to do horrible things...most likely that guy took you for someone else..."
    pt "That's something I'd love to be 100 percent sure about...did that guy say my name?"
    pt "My mind's blocked the exact moment of the tragedy, I simply can't remember...the trauma's stronger than my will to relive that memory..."
    scene ima1698a with dissolve
    vi "And, on top of all that, my Sammy chose you: she thought your life was worth saving at any cost..."
    scene ima1699 with dissolve
    pause
    scene ima1700 with dissolve
    p "I'm so sorry, Vittoria, I know you'd rather have Samantha here with you, it should've been me, I know! I didn't do anything! I'm so sorry, I'm so sorry..."
    vi "Don't do that, stand up...[p]...look at me..."
    p "I can't, I'm so sorry..."
    scene ima1701b with dissolve
    vi "Come on, listen to me, my daughter was a true heroine! And you have a big responsability now: earn what my daughter did for you!"
    vi "Be the best man you can be and nothing less, you hear me! Be great for her, be worthy!"
    pt "I'll never be worth a sacrifice like that..."
    p "I'll try my best..."
    vi "Do not just try, get it done!"
    p "I will."
    scene ima1702b with dissolve
    vi "And I'll make sure you fulfill this promise."
    stop music fadeout 3.0
    scene black with Dissolve(3)
    pause

    play music "audio/relajante.ogg"
    scene ima1705 with dissolve
    coa "What do you mean he's not coming?!"
    cj "Chill, coach, didn't you hear?"
    coa "Hear what?!"
    cj "His girl was murdered last week."
    scene ima1706 with dissolve
    coa "What?! What are you talking about?!"
    scene ima1707 with dissolve
    rd "It was all over the news, Robinson, give the kid a break..."
    scene ima1708 with dissolve
    pl "Hey, Rob!"
    rd "Hey, buddy! Keep training hard, I'll sign autographs later, ok?"
    coa "Don't be such a fan, Lalas!"
    scene ima1709 with dissolve
    rd "So as I was saying, give the kid a break...two weeks maybe?"
    jos "Good morning, coach Robinson!"
    coa "Morning! Wait, I've seen you before...you're a journalist, right?"
    scene ima1710 with dissolve
    jos "Yes! Josephine Garnier, I'm going to be working here at the club now, I'm the new Chief Communications Officer..."
    jos "My first assignment is to conduct a series of interviews to boost our social media engagement..."
    coa "I see...so you're starting with our superstar..."
    jos "Yeah, and then I'd like an interview with you coach, you're an institution here at City F.C."
    coa "Thank you, darling, about time someone recognizes my work, haha..."
    scene ima1711 with dissolve
    cj "What about me?"
    jos "And you are?"
    scene ima1712 with dissolve
    cj "Come on! I'm Carl \"The Hitman\" Johnson, the Academy's all time top scorer...and we met at Sunny Beach, remember?"
    scene ima1713 with dissolve
    jos "Oh, yeeeah, I do, I have good memory...you were with your sister...all time top goalscorer you said?"
    scene ima1714 with dissolve
    coa "Don't listen to him, he's lying....if you're looking to interview our best young talents, you should start with The Phillipses...and perhaps...no, they are the real deal."
    scene ima1715 with dissolve
    coa "Carl, before I forget, tell Blanco he's got a week, if he doesn't show up next Monday, he's done!"
    cj "Don't worry, coach, I got you."
    scene ima1716 with dissolve
    coa "Good, oh, and send him my condolences, too."
    scene ima1717 with dissolve
    cj "You ain't a cold bastard like everyone says, coach."
    scene ima1718 with hpunch
    coa "What?! Ten laps, now!"
    cj "Yes, sir!"
    stop music fadeout 3.0
    scene black with Dissolve(3)

    jump ep6

# FRANZ'S STORY

label franzstory:

    scene black with dissolve
    play music "audio/sadangelicchoir.ogg"
    scene ima1120 with dissolve
    fzt "I couldn't go to my little brother's funeral...I just couldn't..."
    fzt "It's something mom's never gonna forgive me..."
    fzt "But I refuse to see him in a coffin..."
    fzt "I'm so sorry, [p], it's all on me, you had nothing to do with it and yet..."
    scene ima1121 with dissolve
    fzt "Fuuuuuuck!"
    fzt "I have to pay for it...I will...but first I'll make others pay too."
    fzt "I don't have time for tears, I'm already condemmed...I need anger, hate...I won't let them hurt anybody else..."
    fzt "Focus, focus, you have a purpose."
    scene ima1122 with dissolve
    fzt "God, have mercy on my soul for what I'm about to do..."
    scene ima1123 with Dissolve(0.8)
    scene ima1124 with Dissolve(0.8)
    scene ima1125 with Dissolve(0.8)
    scene ima1126 with Dissolve(0.8)
    pause
    scene ima1127 with Dissolve(2.0)
    pause
    stop music fadeout 2
    scene black with Dissolve(2.0)

    scene ima1128 with dissolve
    play music "audio/russian5.mp3" volume 0.6 fadein 3
    pause
    am "There you are!"
    scene ima1129 with dissolve
    pause 1
    scene ima1130 with dissolve
    am "What the fuck's wrong with you?! When are you gonna stop being so fucking selfish?!"
    scene ima1131 with dissolve
    fz "Calm down, Amelia..."
    am "Fuck you! Don't tell me to calm down! How could you do that to your mother?! You're gonna regret not saying goodbye to your brother!"
    scene ima1132 with dissolve
    am "What's happened to you? I don't recognize you anymore..."
    scene ima1133 with dissolve
    ge "Amelia..."
    scene ima1134 with dissolve
    am "Don't you fucking touch me! You know what's going on and tell me nothing!"
    am "What the fuck's wrong with you two?!"
    scene ima1135 with dissolve
    fz "Leave us alone, George."
    ge "Yeah...I'll be out with T, just in case..."
    fz "Okay."
    scene ima1136 with dissolve
    fz "Come."
    scene black with dissolve
    scene ima1137 with dissolve
    am "Aren't you gonna talk to me?"
    scene ima1138 with dissolve
    fz "I'm here, aren't I?"
    am "Why are you acting like this? This's so not you."
    fz "My brother just died..."
    scene ima1139 with dissolve
    am "He didn't just die, he was murdered! And I think you know a lot more than those detectives investigating the case..."
    scene ima1140 with dissolve
    am "Finally, you dare to look at me."
    scene ima1141 with dissolve
    am "Seriously, what's going on? You loved your brother so much, why didn't you show up to support your mother in these hard times?"
    fz "..."
    scene ima1142 with dissolve
    am "Talk to me, Franz, I'm worried about you...we used to share everything and one day, overnight, you closed yourself off from everybody, even from me..."
    am "I thought you were cheating on me..."
    fz "You know I never did that...you are the most important person in my life..."
    scene ima1143 with dissolve
    am "Then why don't you trust me anymore? You know I would die for you..."
    fzt "I know...that's exactly why I can't make you part of my mess..."
    scene ima1144 with dissolve
    am "You told me to stay away, but it's so fucking hard...I miss you, you have no idea how much..."
    fzt "She's hurting..."
    stop music fadeout 3

menu:
    "Fuck...I miss you, too!":
        jump choice71a

    "Don't ruin her life.":
        jump choice71b

label choice71a:

    $ choice71a = True

    scene ima1145 with dissolve
    fz "Mel..."
    fz "I love you."
    scene ima1147 with dissolve
    pause 1
    scene ima1148 with dissolve
    am "I love you more, Zee!"
    scene ima1149 with dissolve
    am "Kiss me!!!"
    scene ima1150 with dissolve
    pause
    scene ima1151 with dissolve
    am "My place, now!"
    fz "Haha, let's go!"

label ameliasex1:

    if _in_replay:
        $ pf = persistent.p


    scene black with Dissolve(1.0)

    play sound "audio/cinematicwhoosh.ogg"
    scene ima1186 with Dissolve(0.0999)
    scene ima1187 with Dissolve(0.0999)
    scene ima1188 with Dissolve(0.0999)
    play music "audio/sensual13.mp3"
    scene ima1189 with hpunch
    scene ima1189 with hpunch

    am "Haha, I love it when you treat me like this!"
    scene ima1190 with dissolve
    fz "My masochistic baby..."
    scene ima1191 with dissolve
    am "Yeah?"
    scene ima1192 with dissolve
    fz "Your bodysuit's too tight, I can't touch what I want..."
    am "No?"
    scene ima1193 with dissolve
    fz "No, I can only rub it..."

    scene ima1193:
        pause 0.0366
        "ima1194"
        pause 0.0366
        "ima1195"
        pause 0.0366
        "ima1196"
        pause 0.0366
        "ima1197"
        pause 0.0366
        "ima1198"
        pause 0.0366
        "ima1199"
        pause 0.0366
        "ima1200"
        pause 0.0366
        "ima1201"
        pause 0.0366
        "ima1202"
        pause 0.0366
        "ima1203"
        pause 0.0366
        "ima1204"
        pause 0.0366
        "ima1205"
        pause 0.0366
        "ima1206"
        pause 0.0366
        "ima1207"
        pause 0.0366
        "ima1208"
        pause 0.0366
        "ima1209"
        pause 0.0366
        "ima1210"
        pause 0.0366
        "ima1211"
        pause 0.0366
        "ima1212"
        pause 0.0366
        "ima1213"
        pause 0.0366
    pause
    fz "See?"
    fz "You haven't slept with anyone in my absence, have you?"
    am "You know I'm only yours..."
    fz "Good, this pussy's mine forever!"

    scene ima1213:
        pause 0.0366
        "ima1212"
        pause 0.0366
        "ima1211"
        pause 0.0366
        "ima1210"
        pause 0.0366
        "ima1209"
        pause 0.0366
        "ima1208"
        pause 0.0366
        "ima1207"
        pause 0.0366
        "ima1206"
        pause 0.0366
        "ima1205"
        pause 0.0366
        "ima1204"
        pause 0.0366
        "ima1203"
        pause 0.0366
        "ima1202"
        pause 0.0366
        "ima1201"
        pause 0.0366
        "ima1200"
        pause 0.0366
        "ima1199"
        pause 0.0366
        "ima1198"
        pause 0.0366
        "ima1197"
        pause 0.0366
        "ima1196"
        pause 0.0366
        "ima1195"
        pause 0.0366
        "ima1194"
        pause 0.0366
        "ima1193"
        pause 0.0366
    pause
    scene ima1214 with dissolve
    am "Forever, baby!"
    scene ima1215 with vpunch
    fz "Forever!"
    fz "I want to stick it in you now, get on the sofa."
    scene black with dissolve
    scene ima1221 with dissolve
    fz "Yeah, now we're talking..."
    scene ima1220 with dissolve
    pause
    scene ima1219 with dissolve
    am "Slowly, baby, I want to enjoy every second..."
    scene ima1216 with dissolve
    pause
    scene ima1217 with dissolve
    am "It feels like it's been ages since the last time..."
    scene ima1221 with dissolve
    pause
    scene ima1222 with vpunch
    pause
    scene ima1223 with dissolve
    am "I missed you so much, Zee..."

    scene ima1224 with dissolve
    pause
    scene ima1224b with dissolve
    pause
    scene ima1240b with Dissolve(1)
    pause
    scene ima1224b with dissolve
    pause
    scene ima1240b with Dissolve(1)
    pause
    scene ima1224 with dissolve

    scene ima1224:
        pause 0.0333
        "ima1225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0333
        "ima1226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0011
        pause 0.0333
        "ima1227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0012
        pause 0.0333
        "ima1228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0013
        pause 0.0333
        "ima1229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0014
        pause 0.0333
        "ima1230"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0015
        pause 0.0333
        "ima1231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0016
        pause 0.0333
        "ima1232"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0017
        pause 0.0333
        "ima1233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0018
        pause 0.0333
        "ima1234"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0019
        pause 0.0333
        "ima1235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0333
        "ima1236"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0021
        pause 0.0333
        "ima1237"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0022
        pause 0.0333
        "ima1238"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0023
        pause 0.0333
        "ima1239"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0024
        pause 0.0333
        "ima1240"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1241"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1242"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1243"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1244"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1246"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0333
        "ima1247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0024
        pause 0.0333
        "ima1248"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0023
        pause 0.0333
        "ima1249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0022
        pause 0.0333
        "ima1250"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0021
        pause 0.0333
        "ima1251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0020
        pause 0.0333
        "ima1252"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0019
        pause 0.0333
        "ima1253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0018
        pause 0.0333
        "ima1254"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0017
        pause 0.0333
        "ima1255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0016
        pause 0.0333
        "ima1256"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0015
        pause 0.0333
        "ima1257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0014
        pause 0.0333
        "ima1258"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0013
        pause 0.0333
        "ima1259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0012
        pause 0.0333
        "ima1260"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0011
        pause 0.0333
        "ima1261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0333
        "ima1262"
        pause 0.0333
        repeat
    pause

    scene ima1224:
        pause 0.0222
        "ima1225"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "ima1226"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0011
        pause 0.0222
        "ima1227"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0012
        pause 0.0222
        "ima1228"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0013
        pause 0.0222
        "ima1229"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0014
        pause 0.0222
        "ima1230"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0015
        pause 0.0222
        "ima1231"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0016
        pause 0.0222
        "ima1232"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0017
        pause 0.0222
        "ima1233"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0018
        pause 0.0222
        "ima1234"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0019
        pause 0.0222
        "ima1235"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "ima1236"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0021
        pause 0.0222
        "ima1237"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0022
        pause 0.0222
        "ima1238"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0023
        pause 0.0222
        "ima1239"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0024
        pause 0.0222
        "ima1240"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1241"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1242"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1243"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1244"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1245"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1246"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0025
        pause 0.0222
        "ima1247"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0024
        pause 0.0222
        "ima1248"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0023
        pause 0.0222
        "ima1249"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0022
        pause 0.0222
        "ima1250"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0021
        pause 0.0222
        "ima1251"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0020
        pause 0.0222
        "ima1252"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0019
        pause 0.0222
        "ima1253"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0018
        pause 0.0222
        "ima1254"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0017
        pause 0.0222
        "ima1255"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0016
        pause 0.0222
        "ima1256"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0015
        pause 0.0222
        "ima1257"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0014
        pause 0.0222
        "ima1258"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0013
        pause 0.0222
        "ima1259"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0012
        pause 0.0222
        "ima1260"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.0011
        pause 0.0222
        "ima1261"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "ima1262"
        pause 0.0222
        repeat
    pause
    fz "Too soft, baby, too much love, I want lust!"
    fz "Hey..."
    fz "Hey, you're not listening..."
    am "Ooh, ooh, ooh..."
    fz "Come on, let's get in the shower..."


    stop music fadeout 2
    scene black with Dissolve(2)

    play sound "audio/shower1.mp3"
    scene ima1263 with dissolve
    fz "This is the way we do it!"
    play music "audio/sensual3.ogg"
    scene ima1340 with dissolve
    am "I love you so much, Franz, you sure know what I like!"
    fz "Yeah, you want this, don't you?"
    am "I do!"
    scene ima1264 with dissolve

label ameangle1:

    scene ima1264:
        pause 0.0222
        "ima1265"
        pause 0.0222
        "ima1266"
        pause 0.0222
        "ima1267"
        pause 0.0222
        "ima1268"
        pause 0.0222
        "ima1269"
        pause 0.0222
        "ima1270"
        pause 0.0222
        "ima1271"
        pause 0.0222
        "ima1272"
        pause 0.0222
        "ima1273"
        pause 0.0222
        "ima1274"
        pause 0.0222
        "ima1275"
        pause 0.0222
        "ima1276"
        pause 0.0222
        "ima1277"
        pause 0.0222
        "ima1278"
        pause 0.0222
        "ima1279"
        pause 0.0222
        "ima1280"
        pause 0.0222
        "ima1281"
        pause 0.0222
        "ima1282"
        pause 0.0222
        "ima1283"
        pause 0.0222
        "ima1284"
        pause 0.0222
        "ima1285"
        pause 0.0222
        "ima1286"
        pause 0.0222
        "ima1287"
        pause 0.0222
        "ima1288"
        pause 0.0222
        "ima1289"
        pause 0.0222
        "ima1290"
        pause 0.0222
        "ima1291"
        pause 0.0222
        "ima1292"
        pause 0.0222
        "ima1293"
        pause 0.0222
        "ima1294"
        pause 0.0222
        "ima1295"
        pause 0.0222
        "ima1296"
        pause 0.0222
        "ima1297"
        pause 0.0222
        "ima1298"
        pause 0.0222
        "ima1299"
        pause 0.0222
        "ima1300"
        pause 0.0222
        "ima1301"
        pause 0.0222
        "ima1302"
        pause 0.0222
        "ima1303"
        pause 0.0222
        "ima1304"
        pause 0.0222
        "ima1305"
        pause 0.0222
        "ima1306"
        pause 0.0222
        "ima1307"
        pause 0.0222
        "ima1308"
        pause 0.0222
        "ima1309"
        pause 0.0222
        "ima1310"
        pause 0.0222
        "ima1311"
        pause 0.0222
        "ima1312"
        pause 0.0222
        "ima1313"
        pause 0.0222
        "ima1314"
        pause 0.0222
        "ima1315"
        pause 0.0222
        "ima1316"
        pause 0.0222
        "ima1317"
        pause 0.0222
        "ima1318"
        pause 0.0222
        "ima1319"
        pause 0.0222
        "ima1320"
        pause 0.0222
        "ima1321"
        pause 0.0222
        "ima1322"
        pause 0.0222
        "ima1323"
        pause 0.0222
        "ima1324"
        pause 0.0222
        "ima1325"
        pause 0.0222
        "ima1326"
        pause 0.0222
        "ima1327"
        pause 0.0222
        "ima1328"
        pause 0.0222
        "ima1329"
        pause 0.0222
        "ima1330"
        pause 0.0222
        "ima1331"
        pause 0.0222
        "ima1332"
        pause 0.0222
        "ima1333"
        pause 0.0222
        "ima1334"
        pause 0.0222
        "ima1335"
        pause 0.0222
        "ima1336"
        pause 0.0222
        "ima1337"
        pause 0.0222
        "ima1338"
        pause 0.0222
        repeat
    pause
    fz "Slowly...the way you like it, baby..."

    scene ima1264:
        pause 0.0166
        "ima1265"
        pause 0.0166
        "ima1266"
        pause 0.0166
        "ima1267"
        pause 0.0166
        "ima1268"
        pause 0.0166
        "ima1269"
        pause 0.0166
        "ima1270"
        pause 0.0166
        "ima1271"
        pause 0.0166
        "ima1272"
        pause 0.0166
        "ima1273"
        pause 0.0166
        "ima1274"
        pause 0.0166
        "ima1275"
        pause 0.0166
        "ima1276"
        pause 0.0166
        "ima1277"
        pause 0.0166
        "ima1278"
        pause 0.0166
        "ima1279"
        pause 0.0166
        "ima1280"
        pause 0.0166
        "ima1281"
        pause 0.0166
        "ima1282"
        pause 0.0166
        "ima1283"
        pause 0.0166
        "ima1284"
        pause 0.0166
        "ima1285"
        pause 0.0166
        "ima1286"
        pause 0.0166
        "ima1287"
        pause 0.0166
        "ima1288"
        pause 0.0166
        "ima1289"
        pause 0.0166
        "ima1290"
        pause 0.0166
        "ima1291"
        pause 0.0166
        "ima1292"
        pause 0.0166
        "ima1293"
        pause 0.0166
        "ima1294"
        pause 0.0166
        "ima1295"
        pause 0.0166
        "ima1296"
        pause 0.0166
        "ima1297"
        pause 0.0166
        "ima1298"
        pause 0.0166
        "ima1299"
        pause 0.0166
        "ima1300"
        pause 0.0166
        "ima1301"
        pause 0.0166
        "ima1302"
        pause 0.0166
        "ima1303"
        pause 0.0166
        "ima1304"
        pause 0.0166
        "ima1305"
        pause 0.0166
        "ima1306"
        pause 0.0166
        "ima1307"
        pause 0.0166
        "ima1308"
        pause 0.0166
        "ima1309"
        pause 0.0166
        "ima1310"
        pause 0.0166
        "ima1311"
        pause 0.0166
        "ima1312"
        pause 0.0166
        "ima1313"
        pause 0.0166
        "ima1314"
        pause 0.0166
        "ima1315"
        pause 0.0166
        "ima1316"
        pause 0.0166
        "ima1317"
        pause 0.0166
        "ima1318"
        pause 0.0166
        "ima1319"
        pause 0.0166
        "ima1320"
        pause 0.0166
        "ima1321"
        pause 0.0166
        "ima1322"
        pause 0.0166
        "ima1323"
        pause 0.0166
        "ima1324"
        pause 0.0166
        "ima1325"
        pause 0.0166
        "ima1326"
        pause 0.0166
        "ima1327"
        pause 0.0166
        "ima1328"
        pause 0.0166
        "ima1329"
        pause 0.0166
        "ima1330"
        pause 0.0166
        "ima1331"
        pause 0.0166
        "ima1332"
        pause 0.0166
        "ima1333"
        pause 0.0166
        "ima1334"
        pause 0.0166
        "ima1335"
        pause 0.0166
        "ima1336"
        pause 0.0166
        "ima1337"
        pause 0.0166
        "ima1338"
        pause 0.0166
        repeat
    pause

    scene ima1264:
        pause 0.0133
        "ima1265"
        pause 0.0133
        "ima1266"
        pause 0.0133
        "ima1267"
        pause 0.0133
        "ima1268"
        pause 0.0133
        "ima1269"
        pause 0.0133
        "ima1270"
        pause 0.0133
        "ima1271"
        pause 0.0133
        "ima1272"
        pause 0.0133
        "ima1273"
        pause 0.0133
        "ima1274"
        pause 0.0133
        "ima1275"
        pause 0.0133
        "ima1276"
        pause 0.0133
        "ima1277"
        pause 0.0133
        "ima1278"
        pause 0.0133
        "ima1279"
        pause 0.0133
        "ima1280"
        pause 0.0133
        "ima1281"
        pause 0.0133
        "ima1282"
        pause 0.0133
        "ima1283"
        pause 0.0133
        "ima1284"
        pause 0.0133
        "ima1285"
        pause 0.0133
        "ima1286"
        pause 0.0133
        "ima1287"
        pause 0.0133
        "ima1288"
        pause 0.0133
        "ima1289"
        pause 0.0133
        "ima1290"
        pause 0.0133
        "ima1291"
        pause 0.0133
        "ima1292"
        pause 0.0133
        "ima1293"
        pause 0.0133
        "ima1294"
        pause 0.0133
        "ima1295"
        pause 0.0133
        "ima1296"
        pause 0.0133
        "ima1297"
        pause 0.0133
        "ima1298"
        pause 0.0133
        "ima1299"
        pause 0.0133
        "ima1300"
        pause 0.0133
        "ima1301"
        pause 0.0133
        "ima1302"
        pause 0.0133
        "ima1303"
        pause 0.0133
        "ima1304"
        pause 0.0133
        "ima1305"
        pause 0.0133
        "ima1306"
        pause 0.0133
        "ima1307"
        pause 0.0133
        "ima1308"
        pause 0.0133
        "ima1309"
        pause 0.0133
        "ima1310"
        pause 0.0133
        "ima1311"
        pause 0.0133
        "ima1312"
        pause 0.0133
        "ima1313"
        pause 0.0133
        "ima1314"
        pause 0.0133
        "ima1315"
        pause 0.0133
        "ima1316"
        pause 0.0133
        "ima1317"
        pause 0.0133
        "ima1318"
        pause 0.0133
        "ima1319"
        pause 0.0133
        "ima1320"
        pause 0.0133
        "ima1321"
        pause 0.0133
        "ima1322"
        pause 0.0133
        "ima1323"
        pause 0.0133
        "ima1324"
        pause 0.0133
        "ima1325"
        pause 0.0133
        "ima1326"
        pause 0.0133
        "ima1327"
        pause 0.0133
        "ima1328"
        pause 0.0133
        "ima1329"
        pause 0.0133
        "ima1330"
        pause 0.0133
        "ima1331"
        pause 0.0133
        "ima1332"
        pause 0.0133
        "ima1333"
        pause 0.0133
        "ima1334"
        pause 0.0133
        "ima1335"
        pause 0.0133
        "ima1336"
        pause 0.0133
        "ima1337"
        pause 0.0133
        "ima1338"
        pause 0.0133
        repeat
    pause
    am "Oh my, baby, you're so fucking deep in me!"
    am "Give it to meee!"

menu:
    "Change angle.":
        jump ameangle2

    "Cum.":
        jump amecum

label ameangle2:

    scene ima1579 with dissolve

    play sound "audio/shower1.mp3"

    scene ima1579:
        pause 0.0166
        "ima1580"
        pause 0.0166
        "ima1581"
        pause 0.0166
        "ima1582"
        pause 0.0166
        "ima1583"
        pause 0.0166
        "ima1584"
        pause 0.0166
        "ima1585"
        pause 0.0166
        "ima1586"
        pause 0.0166
        "ima1587"
        pause 0.0166
        "ima1588"
        pause 0.0166
        "ima1589"
        pause 0.0166
        "ima1590"
        pause 0.0166
        "ima1591"
        pause 0.0166
        "ima1592"
        pause 0.0166
        "ima1593"
        pause 0.0166
        "ima1594"
        pause 0.0166
        "ima1595"
        pause 0.0166
        "ima1596"
        pause 0.0166
        "ima1597"
        pause 0.0166
        "ima1598"
        pause 0.0166
        "ima1599"
        pause 0.0166
        "ima1600"
        pause 0.0166
        "ima1601"
        pause 0.0166
        "ima1602"
        pause 0.0166
        "ima1603"
        pause 0.0166
        "ima1604"
        pause 0.0166
        "ima1605"
        pause 0.0166
        "ima1606"
        pause 0.0166
        "ima1607"
        pause 0.0166
        "ima1608"
        pause 0.0166
        "ima1609"
        pause 0.0166
        "ima1610"
        pause 0.0166
        "ima1611"
        pause 0.0166
        "ima1612"
        pause 0.0166
        "ima1613"
        pause 0.0166
        "ima1614"
        pause 0.0166
        "ima1615"
        pause 0.0166
        "ima1616"
        pause 0.0166
        "ima1617"
        pause 0.0166
        "ima1618"
        pause 0.0166
        "ima1619"
        pause 0.0166
        "ima1620"
        pause 0.0166
        "ima1621"
        pause 0.0166
        "ima1622"
        pause 0.0166
        "ima1623"
        pause 0.0166
        "ima1624"
        pause 0.0166
        "ima1625"
        pause 0.0166
        "ima1626"
        pause 0.0166
        "ima1627"
        pause 0.0166
        "ima1628"
        pause 0.0166
        "ima1629"
        pause 0.0166
        "ima1630"
        pause 0.0166
        "ima1631"
        pause 0.0166
        "ima1632"
        pause 0.0166
        "ima1633"
        pause 0.0166
        "ima1634"
        pause 0.0166
        "ima1635"
        pause 0.0166
        "ima1636"
        pause 0.0166
        "ima1637"
        pause 0.0166
        "ima1638"
        pause 0.0166
        "ima1639"
        pause 0.0166
        "ima1640"
        pause 0.0166
        "ima1641"
        pause 0.0166
        "ima1642"
        pause 0.0166
        "ima1643"
        pause 0.0166
        "ima1644"
        pause 0.0166
        "ima1645"
        pause 0.0166
        "ima1646"
        pause 0.0166
        "ima1647"
        pause 0.0166
        "ima1648"
        pause 0.0166
        "ima1649"
        pause 0.0166
        "ima1650"
        pause 0.0166
        "ima1651"
        pause 0.0166
        "ima1652"
        pause 0.0166
        "ima1653"
        pause 0.0166
        repeat
    am "Yes, baby, keep thrusting!"
    am "Harder!"

    scene ima1579:
        pause 0.0133
        "ima1580"
        pause 0.0133
        "ima1581"
        pause 0.0133
        "ima1582"
        pause 0.0133
        "ima1583"
        pause 0.0133
        "ima1584"
        pause 0.0133
        "ima1585"
        pause 0.0133
        "ima1586"
        pause 0.0133
        "ima1587"
        pause 0.0133
        "ima1588"
        pause 0.0133
        "ima1589"
        pause 0.0133
        "ima1590"
        pause 0.0133
        "ima1591"
        pause 0.0133
        "ima1592"
        pause 0.0133
        "ima1593"
        pause 0.0133
        "ima1594"
        pause 0.0133
        "ima1595"
        pause 0.0133
        "ima1596"
        pause 0.0133
        "ima1597"
        pause 0.0133
        "ima1598"
        pause 0.0133
        "ima1599"
        pause 0.0133
        "ima1600"
        pause 0.0133
        "ima1601"
        pause 0.0133
        "ima1602"
        pause 0.0133
        "ima1603"
        pause 0.0133
        "ima1604"
        pause 0.0133
        "ima1605"
        pause 0.0133
        "ima1606"
        pause 0.0133
        "ima1607"
        pause 0.0133
        "ima1608"
        pause 0.0133
        "ima1609"
        pause 0.0133
        "ima1610"
        pause 0.0133
        "ima1611"
        pause 0.0133
        "ima1612"
        pause 0.0133
        "ima1613"
        pause 0.0133
        "ima1614"
        pause 0.0133
        "ima1615"
        pause 0.0133
        "ima1616"
        pause 0.0133
        "ima1617"
        pause 0.0133
        "ima1618"
        pause 0.0133
        "ima1619"
        pause 0.0133
        "ima1620"
        pause 0.0133
        "ima1621"
        pause 0.0133
        "ima1622"
        pause 0.0133
        "ima1623"
        pause 0.0133
        "ima1624"
        pause 0.0133
        "ima1625"
        pause 0.0133
        "ima1626"
        pause 0.0133
        "ima1627"
        pause 0.0133
        "ima1628"
        pause 0.0133
        "ima1629"
        pause 0.0133
        "ima1630"
        pause 0.0133
        "ima1631"
        pause 0.0133
        "ima1632"
        pause 0.0133
        "ima1633"
        pause 0.0133
        "ima1634"
        pause 0.0133
        "ima1635"
        pause 0.0133
        "ima1636"
        pause 0.0133
        "ima1637"
        pause 0.0133
        "ima1638"
        pause 0.0133
        "ima1639"
        pause 0.0133
        "ima1640"
        pause 0.0133
        "ima1641"
        pause 0.0133
        "ima1642"
        pause 0.0133
        "ima1643"
        pause 0.0133
        "ima1644"
        pause 0.0133
        "ima1645"
        pause 0.0133
        "ima1646"
        pause 0.0133
        "ima1647"
        pause 0.0133
        "ima1648"
        pause 0.0133
        "ima1649"
        pause 0.0133
        "ima1650"
        pause 0.0133
        "ima1651"
        pause 0.0133
        "ima1652"
        pause 0.0133
        "ima1653"
        pause 0.0133
        repeat
    pause

    scene ima1579:
        xpos 0.4 ypos 0.4 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0133
        "ima1580"
        pause 0.0133
        "ima1581"
        pause 0.0133
        "ima1582"
        pause 0.0133
        "ima1583"
        pause 0.0133
        "ima1584"
        pause 0.0133
        "ima1585"
        pause 0.0133
        "ima1586"
        pause 0.0133
        "ima1587"
        pause 0.0133
        "ima1588"
        pause 0.0133
        "ima1589"
        pause 0.0133
        "ima1590"
        pause 0.0133
        "ima1591"
        pause 0.0133
        "ima1592"
        pause 0.0133
        "ima1593"
        pause 0.0133
        "ima1594"
        pause 0.0133
        "ima1595"
        pause 0.0133
        "ima1596"
        pause 0.0133
        "ima1597"
        pause 0.0133
        "ima1598"
        pause 0.0133
        "ima1599"
        pause 0.0133
        "ima1600"
        pause 0.0133
        "ima1601"
        pause 0.0133
        "ima1602"
        pause 0.0133
        "ima1603"
        pause 0.0133
        "ima1604"
        pause 0.0133
        "ima1605"
        pause 0.0133
        "ima1606"
        pause 0.0133
        "ima1607"
        pause 0.0133
        "ima1608"
        pause 0.0133
        "ima1609"
        pause 0.0133
        "ima1610"
        pause 0.0133
        "ima1611"
        pause 0.0133
        "ima1612"
        pause 0.0133
        "ima1613"
        pause 0.0133
        "ima1614"
        pause 0.0133
        "ima1615"
        pause 0.0133
        "ima1616"
        pause 0.0133
        "ima1617"
        pause 0.0133
        "ima1618"
        pause 0.0133
        "ima1619"
        pause 0.0133
        "ima1620"
        pause 0.0133
        "ima1621"
        pause 0.0133
        "ima1622"
        pause 0.0133
        "ima1623"
        pause 0.0133
        "ima1624"
        pause 0.0133
        "ima1625"
        pause 0.0133
        "ima1626"
        pause 0.0133
        "ima1627"
        pause 0.0133
        "ima1628"
        pause 0.0133
        "ima1629"
        pause 0.0133
        "ima1630"
        pause 0.0133
        "ima1631"
        pause 0.0133
        "ima1632"
        pause 0.0133
        "ima1633"
        pause 0.0133
        "ima1634"
        pause 0.0133
        "ima1635"
        pause 0.0133
        "ima1636"
        pause 0.0133
        "ima1637"
        pause 0.0133
        "ima1638"
        pause 0.0133
        "ima1639"
        pause 0.0133
        "ima1640"
        pause 0.0133
        "ima1641"
        pause 0.0133
        "ima1642"
        pause 0.0133
        "ima1643"
        pause 0.0133
        "ima1644"
        pause 0.0133
        "ima1645"
        pause 0.0133
        "ima1646"
        pause 0.0133
        "ima1647"
        pause 0.0133
        "ima1648"
        pause 0.0133
        "ima1649"
        pause 0.0133
        "ima1650"
        pause 0.0133
        "ima1651"
        pause 0.0133
        "ima1652"
        pause 0.0133
        "ima1653"
        pause 0.0133
        repeat
    pause
    am "I love how our bodies understand each other, baby..."
    fz "I don't want to pull out, Mel..."
    am "Don't! Give it to me, baby!"

    scene ima1579:
        pause 0.0133
        "ima1580"
        pause 0.0133
        "ima1581"
        pause 0.0133
        "ima1582"
        pause 0.0133
        "ima1583"
        pause 0.0133
        "ima1584"
        pause 0.0133
        "ima1585"
        pause 0.0133
        "ima1586"
        pause 0.0133
        "ima1587"
        pause 0.0133
        "ima1588"
        pause 0.0133
        "ima1589"
        pause 0.0133
        "ima1590"
        pause 0.0133
        "ima1591"
        pause 0.0133
        "ima1592"
        pause 0.0133
        "ima1593"
        pause 0.0133
        "ima1594"
        pause 0.0133
        "ima1595"
        pause 0.0133
        "ima1596"
        pause 0.0133
        "ima1597"
        pause 0.0133
        "ima1598"
        pause 0.0133
        "ima1599"
        pause 0.0133
        "ima1600"
        pause 0.0133
        "ima1601"
        pause 0.0133
        "ima1602"
        pause 0.0133
        "ima1603"
        pause 0.0133
        "ima1604"
        pause 0.0133
        "ima1605"
        pause 0.0133
        "ima1606"
        pause 0.0133
        "ima1607"
        pause 0.0133
        "ima1608"
        pause 0.0133
        "ima1609"
        pause 0.0133
        "ima1610"
        pause 0.0133
        "ima1611"
        pause 0.0133
        "ima1612"
        pause 0.0133
        "ima1613"
        pause 0.0133
        "ima1614"
        pause 0.0133
        "ima1615"
        pause 0.0133
        "ima1616"
        pause 0.0133
        "ima1617"
        pause 0.0133
        "ima1618"
        pause 0.0133
        "ima1619"
        pause 0.0133
        "ima1620"
        pause 0.0133
        "ima1621"
        pause 0.0133
        "ima1622"
        pause 0.0133
        "ima1623"
        pause 0.0133
        "ima1624"
        pause 0.0133
        "ima1625"
        pause 0.0133
        "ima1626"
        pause 0.0133
        "ima1627"
        pause 0.0133
        "ima1628"
        pause 0.0133
        "ima1629"
        pause 0.0133
        "ima1630"
        pause 0.0133
        "ima1631"
        pause 0.0133
        "ima1632"
        pause 0.0133
        "ima1633"
        pause 0.0133
        "ima1634"
        pause 0.0133
        "ima1635"
        pause 0.0133
        "ima1636"
        pause 0.0133
        "ima1637"
        pause 0.0133
        "ima1638"
        pause 0.0133
        "ima1639"
        pause 0.0133
        "ima1640"
        pause 0.0133
        "ima1641"
        pause 0.0133
        "ima1642"
        pause 0.0133
        "ima1643"
        pause 0.0133
        "ima1644"
        pause 0.0133
        "ima1645"
        pause 0.0133
        "ima1646"
        pause 0.0133
        "ima1647"
        pause 0.0133
        "ima1648"
        pause 0.0133
        "ima1649"
        pause 0.0133
        "ima1650"
        pause 0.0133
        "ima1651"
        pause 0.0133
        "ima1652"
        pause 0.0133
        "ima1653"
        pause 0.0133
        repeat
    pause
    am "I want your son!"
    am "Get me pregnant!"

    scene ima1579:
        pause 0.0122
        "ima1580"
        pause 0.0122
        "ima1581"
        pause 0.0122
        "ima1582"
        pause 0.0122
        "ima1583"
        pause 0.0122
        "ima1584"
        pause 0.0122
        "ima1585"
        pause 0.0122
        "ima1586"
        pause 0.0122
        "ima1587"
        pause 0.0122
        "ima1588"
        pause 0.0122
        "ima1589"
        pause 0.0122
        "ima1590"
        pause 0.0122
        "ima1591"
        pause 0.0122
        "ima1592"
        pause 0.0122
        "ima1593"
        pause 0.0122
        "ima1594"
        pause 0.0122
        "ima1595"
        pause 0.0122
        "ima1596"
        pause 0.0122
        "ima1597"
        pause 0.0122
        "ima1598"
        pause 0.0122
        "ima1599"
        pause 0.0122
        "ima1600"
        pause 0.0122
        "ima1601"
        pause 0.0122
        "ima1602"
        pause 0.0122
        "ima1603"
        pause 0.0122
        "ima1604"
        pause 0.0122
        "ima1605"
        pause 0.0122
        "ima1606"
        pause 0.0122
        "ima1607"
        pause 0.0122
        "ima1608"
        pause 0.0122
        "ima1609"
        pause 0.0122
        "ima1610"
        pause 0.0122
        "ima1611"
        pause 0.0122
        "ima1612"
        pause 0.0122
        "ima1613"
        pause 0.0122
        "ima1614"
        pause 0.0122
        "ima1615"
        pause 0.0122
        "ima1616"
        pause 0.0122
        "ima1617"
        pause 0.0122
        "ima1618"
        pause 0.0122
        "ima1619"
        pause 0.0122
        "ima1620"
        pause 0.0122
        "ima1621"
        pause 0.0122
        "ima1622"
        pause 0.0122
        "ima1623"
        pause 0.0122
        "ima1624"
        pause 0.0122
        "ima1625"
        pause 0.0122
        "ima1626"
        pause 0.0122
        "ima1627"
        pause 0.0122
        "ima1628"
        pause 0.0122
        "ima1629"
        pause 0.0122
        "ima1630"
        pause 0.0122
        "ima1631"
        pause 0.0122
        "ima1632"
        pause 0.0122
        "ima1633"
        pause 0.0122
        "ima1634"
        pause 0.0122
        "ima1635"
        pause 0.0122
        "ima1636"
        pause 0.0122
        "ima1637"
        pause 0.0122
        "ima1638"
        pause 0.0122
        "ima1639"
        pause 0.0122
        "ima1640"
        pause 0.0122
        "ima1641"
        pause 0.0122
        "ima1642"
        pause 0.0122
        "ima1643"
        pause 0.0122
        "ima1644"
        pause 0.0122
        "ima1645"
        pause 0.0122
        "ima1646"
        pause 0.0122
        "ima1647"
        pause 0.0122
        "ima1648"
        pause 0.0122
        "ima1649"
        pause 0.0122
        "ima1650"
        pause 0.0122
        "ima1651"
        pause 0.0122
        "ima1652"
        pause 0.0122
        "ima1653"
        pause 0.0122
        repeat
    pause

label amecum:

    stop sound
    stop music fadeout 3
    play sound "audio/femorg7.ogg"
    scene ima1342 with vpunch
    scene ima1342 with vpunch
    scene ima1342 with flash
    scene ima1343 with dissolve
    scene ima1343 with vpunch
    scene ima1343 with vpunch
    scene ima1343 with flash
    fz "Yeah, baby, take it all..."
    stop sound
    scene black with Dissolve(3.0)

    $ renpy.end_replay()

    jump endamelia

label choice71b:

    $ choice71b = True

    scene ima1145 with dissolve
    fzt "She won't be safe being close to me..."
    fz "Mel, listen...you don't have to worry about me, I'm ok, really...there are certain things I need to take care of first and then, we'll deal with our unfinished business..."
    fz "Just give me some time, ok?"
    scene ima1146 with dissolve
    fz "Gotta go now, text me when you get home."
    scene black with Dissolve(3.0)

    jump endamelia

label endamelia:

    scene black
    pause
    scene ima1152 with dissolve
    play music "audio/sixcoffinnail.ogg"
    pause
    scene ima1153 with dissolve
    pause
    play sound "audio/gun.mp3"
    scene ima1153 with dissolve
    scene ima1154 with Dissolve(0.0333)
    scene ima1154a with Dissolve(0.0333)
    scene ima1153 with Dissolve(0.0333)
    scene ima1153a with Dissolve(2)
    pause
    scene ima1155 with dissolve
    pause
    play sound "audio/cockgun.mp3"
    scene ima1156 with dissolve
    pause
    scene ima1157 with dissolve
    pause
    scene ima1158 with dissolve
    pause
    scene ima1158a with dissolve
    pause
    play sound "audio/assaultrifle.ogg"
    scene ima1158a with Dissolve(0.0333)
    scene ima1158b with Dissolve(0.0333)
    scene ima1158c with vpunch
    scene ima1158c with vpunch
    scene ima1158c with vpunch
    scene ima1158c with vpunch
    scene ima1158c with vpunch
    scene ima1158c with vpunch
    scene ima1158c with vpunch

    scene ima1158d with Dissolve(1)
    stop sound
    pause
    scene ima1159 with dissolve
    ge "Have you thought about it?"
    fz "I have no time to babysit, George, why don't you decide what's better for the girl?"
    ge "The girl?"
    fz "Tesia, whatever...you do it."
    ge "I just thought you wanted to have a voice in it, she cares about what you think..."
    scene ima1160 with dissolve
    fz "I have no time for distractions...you handle that."
    ge "I will."
    scene ima1161 with dissolve
    fz "Daaamn, dude, you're sharp as fuck! We're gonna need that."
    fz "Mine looks...uhm...angry..."
    scene ima1162 with dissolve
    ge "We're gonna need that, too."
    fz "Let's go, William's waiting..."
    ge "Yeah, we'll come back tomorrow."

    stop music fadeout 2
    scene black with Dissolve(2.0)

    scene ima1163 with Dissolve(1.5)
    pause
    scene ima1164 with dissolve
    fz "And? What's the plan?"
    pause 1
    scene ima1165 with Dissolve(1)
    pause 1
    scene ima1166 with Dissolve(1)
    wi "Over there..."
    play music "audio/phobia.ogg"
    scene ima1167 with Dissolve(1)

    pause
    scene ima1168 with dissolve
    wi "This's the son of a bitch we're after: Isaac Nyack..."
    wi "Senator! Isaac Nyack...politician, investor, philanthropist, author...a charismatic man loved by everybody..."
    scene ima1169 with dissolve
    wi "Also a sadistic cult leader, sexual predator, and murderer!"
    wi "Responsible for the death of your father, Franz and your sister's disappearance, George..."
    wi "Tonight, we have to make our final decision..."
    scene ima1170 with dissolve
    wi "Save or kill, those are our options...your lives will be at stake, so it is fair to vote."
    wi "Mission one: saving 9 people...european inmigrants all of them, mainly from Verliko, Tapolka and Mirukov...they're being kept in an abandoned industrial building located in South Roseland..."
    wi "The building belongs to Skyline Cosmetics, owned by..."
    scene ima1171 with dissolve
    wi "Sarka \"The Viper\" Nyack."
    ge "Can't believe that woman's a murderer..."
    wi "I can't confirm that she's killed anybody, I've never seen her torture anybody either, but she definitely knows what's happening..."
    fz "Her crime is the same as ours...as far as we know..."
    ge "Don't compare us to that bitch! She takes part in the rituals...remember that day we saw her?"
    fz "Yeah, and we cleaned up the place afterwards...We've cleaned a lot of bloody rooms, George, that was us taking part in their rituals..."
    scene ima1172 with dissolve
    wi "Her brother, Valtr, sick motherfucker...there's a reason why they call him \"The Butcher\"...depraved, twisted cannibal..."
    ge "What?! Cannibal?! These people are animals!"
    wi "They all are! And when you make your decision, remember he's the one who ordered the hit on your brother..."
    fzt "[p]..."
    fz "No need to remind me...go on, how do we save those girls?"
    scene ima1173 with dissolve
    wi "Eight girls, one boy...not easy, but doable, there's a police patrol parked in front of the building all the time..."
    ge "It's incredible how The Nyacks own everything in this city..."
    fz "And everyone...so we have to kill cops?"
    wi "No, I'll use some gas to put them to sleep, this's a stealth mission until we have no other choice..."
    wi "Inside the warehouse, we'll find ten men with guns, maybe a couple of assault riffles..."
    scene ima1174 with dissolve
    wi "But what really worries me is this guy over here...my informant didn't have much on him, we just call him \"Incognito\"..."
    wi "Twelve corpses were found in West Lawn, in an old house owned by Valtr Nyack. The bodies presented multiple lacerations, chemical burns and missing organs...we're positive this guy was hiding there..."
    wi "This psycho is in the warehouse now, we must act now if we really want to save the girls...I don't know what he'll do to them or if they'll be used in future rituals..."
    wi "We must prepare for possible use of gas or poison, too..."
    scene ima1175 with dissolve
    wi "We're in the dark with him, we ignore the full extent of his skills...he could be good with guns, knives, poison, we simply don't know...it's a huge disadvantage..."
    wi "HE is the real thread when rescuing those people..."
    scene ima1176 with dissolve
    ge "or SHE..."
    wi "I highly doubt it, but yeah, could be..."
    ge "What about the second mission?"
    scene ima1177 with dissolve
    wi "A suicide mission to tell the truth..."
    wi "On the 21st, a moon worship ritual will be held in a manor located in South Hermitage...Isaac, Valtr and Sarka will be there, the place's gonna be heavily guarded, expect 40-50 security guards at least..."
    fz "That many? The Elite will be there , huh?"
    scene ima1178 with dissolve
    wi "And these two..."
    ge "Who were they again?"
    fz "Niko and Jaxrael, former ZIA agents, like William, The Nyacks' elite bodyguards..."
    wi "I can deal with one of them, but two...impossible...If only we had a sniper to get this job done..."
    fz "George can be our sniper, his accuracy's just sick!"
    wi "Yeah? I'll go with you next time, I need to see that...maybe we could make it out of it alive..."
    wi "But that's not my priority, your lives won't be my priority, I'm telling ya..."
    scene ima1179 with dissolve
    wi "Listen carefully, if we go to that manor, we're killing everybody who participates in that fucking ritual, you hear me? EVERYBODY. If you don't have it in you, it's better to go save those girls..."
    wi "If I go to that manor, there's no way I'm leaving without Isaac Nyack's head."
    scene ima1180 with dissolve
    wi "And you! You should want the same, he killed your father, his son killed your brother, you owe it to them!"
    scene ima1181 with dissolve
    ge "I vote for saving those girls!"
    scene ima1182 with dissolve
    wi "You know what I want: kill them all."
    scene ima1183 with dissolve
    ge "It's on you, brother, whatever you decide, we're on this together."
    wi "Your father, your brother..."
    ge "Even if we manage to kill them, someone else will take over, it'll never end...think of Tesia..."
    fz "No pressure, huh?"
    stop music fadeout 3

menu:
    "Save.":
        jump choice72a

    "Kill.":
        jump choice72b

label choice72b:

    $ choice72b = True

    scene ima1183 with dissolve
    play music "audio/emotion.mp3"
    fzt "These people will never face traditional justice for their crimes, they own the system..."
    fzt "It's our duty to hold them accountable for their actions...that's a hero in my book!"
    fzt "{i}\"That's your dream, isn't it? You've always wanted to be a hero...\"{/i}"
    fzt "You always knew it, right, little brother?"
    fzt "I should've told you...I'm so sorry...Fuuuckk!!"
    scene ima1184 with dissolve
    fz "It's our purpose to stop them no matter what..."
    fz "I want to kill them all, everyone in that fucking ritual...nobody survives!"
    wi "Amen."
    stop music fadeout 3
    jump endsheriff1

label choice72a:

    $ choice72a = True

    scene ima1183 with dissolve
    play music "audio/gangstarap.ogg"
    fzt "Tesia..."
    fzt "We can save more people, I'd give anything to save just one more life..."
    fzt "Fuck! George's right..."
    fz "Why can't we do both?"
    wi "Pft, too many movies, kid...I get you, saving those girls sounds easier and you're thinking we won't get much damage, but trust me, we will."
    wi "And if by some sort of miracle, we managed to get out of that factory unharmed, they would double the security for their ritual on the 21, making it impossible to get even close to that manor..."
    wi "You have to choose..."
    scene ima1185 with dissolve
    fz "Getting them out is just the beginning...Tesia has these nightmares all the time..."
    fzt "Fuuucckkk!! It's so hard...I'm sorry, brother..."
    fzt "I'm sure you'd try to save them too..."
    fz "I want to save them...and stop that motherfucker \"Incognito\" in the process."
    ge "Let's do it, brother!"
    stop music fadeout 3
    jump endsheriff1

label endsheriff1:

    scene black with Dissolve(3)
    pause
    play music "audio/allright.mp3"
    scene im341 with Dissolve(2)
    fz "T!"
    scene im342 with dissolve
    te "Mmm?"
    ge "Watching V?"
    scene im343 with dissolve
    te "Yeah!"
    fz "You're gonna have to pause it, Little T, you're coming with us...let's go!"
    scene im344 with dissolve
    te "Go where?"
    scene im345 with dissolve
    ge "It's your lucky day, Little T! You wanted to do something about that hair, didn't you?"
    scene im344a with dissolve
    te "Yes, yes! Let's go! Yaaayyyy!"
    scene black with Dissolve(1)
    scene im346 with dissolve
    lo "I love it, Joanna! What a wonderful job!"
    joa "I didn't have to do much, you're so pretty, Lola."
    lo "Fredo's gonna love this, haha!"
    scene im347 with dissolve
    fz "Hello, Joanna! We have a pretty serious case right here, we're gonna need your magic!"
    scene im348 with dissolve
    fz "What."
    scene im349 with dissolve
    joa "Oh, hi, Franz! Hi, George...hi, beauty...I'll be with you guys in a minute."
    lo "Hi, George! Do you like my new haircut?"
    ge "Yes, Lola."
    scene im350 with dissolve
    lo "When are you going to call me?"
    ge "Soon, Lola, soon..."
    lo "Don't take too long..."
    scene im351 with dissolve
    lo "Hi there, Franz!"
    fz "Hey, Lola...how's John?"
    lo "Working on his novel...for a change, haha."
    scene im352 with dissolve
    te "Can you do me something similar?"
    joa "A bob? Let me see...yeah, that can work out...you have a beautiful face, sweetie! Yeah, I know exactly what to do!"
    scene black with Dissolve(1)
    scene im353 with dissolve
    fz "You're gonna tap that ass?"
    ge "You asked her about John, ha, you're cold..."
    ge "I don't know...Do you know how many men she's been with? Everybody I speak to says they already fucked her..."
    fz "I've heard something about it..."
    ge "Yeah?"
    fz "Uhum...I've heard her husband likes getting cucked...you're a lucky man."
    scene im354 with dissolve
    ge "You think? I don't want to get syphilis..."
    fz "I don't know, man, I think I'd do her anyways, but I prefer Joanna."
    ge "Yeah, me too."
    scene black with Dissolve(1)
    scene im355 with dissolve
    pause
    te "Hoooly shin!"
    scene im356 with dissolve
    pause
    scene im357 with dissolve
    te "Woooowww! Am I dreaming?"
    joa "What do you think, honey? Best scissors in town or what?"
    scene im358 with dissolve
    te "My God...thank you so much, Joanna! I'm so happy!"
    scene im359 with dissolve
    joa "Oh, darling! What's wrong? You're gonna make me cry..."
    scene im360 with dissolve
    fz "Thank you, Joanna, you have no idea what this means to her...to all of us..."
    joa "Did she burn her hair or something? It was badly damaged..."
    fz "Something like that...fortunately, you did your magic once again."
    scene black with dissolve
    scene im361 with dissolve
    te "Thank you so much, guys...I'll never be able to pay back what you're doing for me..."
    ge "We just want to see you happy, T...don't worry about anything else."
    te "I love you!"
    fz "We love you too, Little T."
    stop music fadeout 2
    scene black with Dissolve(2)
    scene im362 with dissolve
    fz "I'll go buy some snacks, you sure you only want some chocolate?"
    te "Yes, that's all...thanks, Franz."
    fz "Fine, don't start without me, eh! I know you."
    te "Hehehe."
    scene black with Dissolve(1)
    scene im280 with dissolve
    play sound "audio/doorbell1.ogg"
    pause 2
    play sound "audio/opendoor.mp3"
    scene im281 with dissolve
    te "You forgot your wa..."
    play music "audio/tension4.ogg"
    scene im281 with dissolve
    scene im282 with hpunch
    te "Aaahhh!!!"
    uk "Look at you! You look so pretty!"
    scene im283 with dissolve
    te "George, get out of here!"
    uk "Ugh, kids these days..."
    scene black with dissolve
    scene im284 with dissolve
    ge "Stay away from her."
    ge "What do you want, Sarka?"
    sk "Don't get nervous, Georgie, I just want to talk."
    ge "Nervous? Who's nervous? Tell him not to touch her."
    scene im285 with dissolve
    sk "First of all, Georgie, don't you ever tell me what to do. And second, if you pull a gun like that, you must be ready to use it...you're lucky you did not aim at me: Niko would've killed you in the act..."
    sk "Errr...what are you waiting for? Put the gun down."
    scene im286 with dissolve
    sk "There's nothing to think here, Georgie, I'll give you two seconds...one..."
    scene im287 with dissolve
    ge "Let her go."
    scene im288 with dissolve
    sk "See how easy it is to come to an understanding...now let's wait for Franzie, he shouldn't take long..."
    scene black with dissolve
    scene im289 with Dissolve(1)
    sk "You two are so adorable together!"
    sk "It is fun to play heroes, right Georgie? Come on, sit down."
    scene im290 with dissolve
    ge "What do you want?"
    sk "You don't look surprise to see me here...why's that? Were you expecting my visit?"
    sk "Niko?"
    nk "Everything's under control, ma'am, there are no signs of a set-up."
    sk "So you're just being brave, Georgie...for her..."
    scene im291 with dissolve
    fz "Are you ok?"
    ge "We are."
    scene im292 with dissolve
    sk "Franziiieee! Come join us!"
    sk "Of course they are okay, Franzie, aren't you? Come on, we're not savages...take a seat!"
    stop music fadeout 2
    scene black with Dissolve(1)
    scene im293 with dissolve
    sk "At last! Our family's been reunited! I love it!"
    sk "First, let me thank you two for all your hard work at the old manor: you did an amazing job cleaning everything up..."
    scene im294 with dissolve
    sk "Such a shame we can't do anything in there anymore, it was the perfect location, nobody knew about it...such a waste of space...and money..."
    scene im295 with dissolve
    sk "And that's all on you two..."
    play music "audio/disturbingevent.mp3"
    scene im297 with dissolve
    sk "Help me understand one thing because I'm really having a hard time getting it..."
    scene im296 with dissolve
    sk "Why did you take something that belongs to me? What were you thinking? What did you think was going to happen?"
    sk "You don't steal from your masters, didn't your fathers tell you that? After all, they were magnificent fellow builders for a while..."
    scene im298 with dissolve
    sk "Didn't we treat them fairly, Niko?"
    nk "You did, ma'am."
    sk "Thank you!"
    scene im299 with dissolve
    sk "Ugh, this's giving a headache...why am I such a kind woman? Better do this quicly."
    fzt "She's weird as fuck..."
    scene im300 with dissolve
    sk "Listen, Franzie: that god you pray to...he can't deliver, neither can William..."
    scene im301 with dissolve
    sk "I can!"
    scene im302 with dissolve
    sk "What else do you want to know? What were you trying to find out?"
    scene im303 with dissolve
    sk "He died of cancer, read his death certificate, okay Franzie?"
    scene im304 with dissolve
    sk "And to you: your father was a real piece of shit and you know it! Selling your sister like that...ewww..."
    sk "Where's that rat now, huh? He got the money and vanished, didn't he? Or I'm lying?"
    scene im305 with dissolve
    ge "What happened to my sister?!"
    scene im306 with hpunch
    jx "Silence!"
    fzt "Holy shit, this guy didn't hesitate to pull his gun...he is quick..."
    scene im307 with dissolve
    jx "When she speaks, you only listen."
    sk "Hahaha."
    scene im308 with dissolve
    sk "Calm down, Georgie, I said I can deliver, didn't I?"
    scene im309 with dissolve
    sk "Here's a little secret: she's alive."
    scene im309 with hpunch
    fzt "What?! After all these years!"
    fzt "Why does she seem to be enjoying all this?! Is this a game to her?!"
    scene im310 with dissolve
    sk "Was it Belgium? Or France?"
    scene im311 with dissolve
    sk "Anyway, hear me out, this's what's going to happen now...you're gonna love it!"
    scene im312 with dissolve
    sk "I'm going to give you a life..."
    scene im313 with dissolve
    pause
    scene im314 with dissolve
    sk "For a life!"
    sk "How does that sound?"
    fzt "How can you say it so lightly? You're talking about my brother!"
    scene im315 with dissolve
    sk "In fact, I'm giving you three! Come on!"
    scene im316 with dissolve
    sk "Oh, and I'm not even counting your mothers', William's, Amelia's...it's not fair, eh? How many do you want?! I shouldn't be this generous!"
    play sound "audio/knock.ogg"
    scene im317 with dissolve
    uk "Franz? Are you there?"
    fzt "Charlotte?"
    scene im318 with dissolve
    pause
    fz "Yeah, yeah, what's up?"
    scene im319 with dissolve
    ch "Do you have Internet? Mine's not working..."
    fz "Mmm...yeah, mine's not working either...I'm about to call the company..."
    ch "Yeah, I think I'll do that too...thanks, mate...everything ok?"
    fz "Yes, talk to you later, Charlotte."
    ch "Alright."
    scene im320 with dissolve
    sk "Time to leave."
    nk "This way ma'am."
    scene im321 with dissolve
    sk "One more thing, if you ever try to mess up with me and my businesses again, I'll put a bullet in your heads. This...relationship...is no longer beneficial, I have enough pets."
    scene im322 with dissolve
    sk "Move the fuck on!"
    scene im323 with dissolve
    sk "I'm exhausted now...you exhausted me...what's wrong with you, Sarka? Coming in here looking for a truce...a truce you don't even need!"
    sk "Hahaha, I'm so magnanimous! I thought this was going to be fun...being nice sucks!"
    sk "Come on, Georgie, walk me out, I don't have all day...I need your neighbors to see us."
    stop music fadeout 2
    scene black with Dissolve(2)

    scene im324 with dissolve
    play music "audio/darkside.mp3"
    fzt "All this time she knew where to find us..."
    fzt "\"Nothing exists without their knowledge, nothing happens without their consent.\"...that's what my father wrote."
    fzt "A life for a life...fucking bitch!"
    fzt "She just admitted they killed my brother right there! Is she that confident she can get away with murder? If so, why not just kill us?"
    scene im325 with dissolve
    fzt "There are many things I don't understand yet..."
    fzt "And she brought the heavy artillery tonight to scare the shit out of us...to show us how powerful they are..."
    fzt "They're always ahead...way ahead of us...we're not ready..."
    scene im326 with dissolve
    fzt "Tesia..."
    scene im327 with dissolve
    fzt "Seeing Sarka must have brought back some horrible memories...poor girl..."
    scene im328 with dissolve
    te "I'm so sorry, Franz, this is all my fault...if you did not save me..."
    scene im329 with dissolve
    fz "What?! Don't you ever say that again, T! What's the matter with you?!"
    scene im330 with dissolve
    fz "You're not responsible for anything that has happened tonight...George and I have a long history with that woman and her family...way before you came into our lives, nothing is your fault."
    fz "Tesia, you are our miracle."
    fz "You're a reminder that I can do something good in my life. You're worthy, I love you, kid."
    scene im331 with dissolve
    te "I love you too."
    play sound "audio/opendoor.mp3"
    fz "Nothing will happen to you, to any of us...you heard her, it's over now..."
    play sound "audio/doorclosed.ogg"
    ge "Over?"
    scene im332 with dissolve
    ge "This has just started...give me the key for the lockbox, I need to see your father's list one more time."
    fz "What list?"
    ge "Don't play dumb just because of her...sooner or later she'll find out what we're about to do."

if choice72b:

    scene im333 with dissolve
    ge "Going to that manor would be suicide, I can't die now that I know my sister's alive."
    fz "I know. What do we do now?"
    jump changeofplans

label changeofplans:

    scene im333 with dissolve
    ge "We're saving those girls and then I'm gone! No time to waste, brother!"
    fz "Gone? Gone where? We don't know where to start..."
    ge "That's why I want to see those names again...some of those motherfuckers were from France, weren't they?"
    fz "You're right, but she said Belgium, too...maybe William has something else for us..."
    ge "William? This bitch gave us more information in 5 minutes than William in two years...I'm three years late!"
    scene im334 with dissolve
    te "What are you talking about? You scare me..."
    ge "T! We're gonna need you're help!"
    scene im335 with dissolve
    fz "George."
    ge "She's stronger than you think..."
    scene im336 with dissolve
    ge "Listen, T, I know you were in shock to see that woman here, but you must have heard what she said about my little sister, right? She was abducted more than three years ago...just like you..."
    scene im337 with dissolve
    ge "Yes, Little T, I always knew she was alive, and she's just confirmed it...I have to go find her immediately, that's why I need you!"
    ge "I'm sorry, T, I know you don't want to relive what happened to you, or perhaps it was us who were afraid to know, that's why we didn't ask much..."
    ge "But I'm asking now...something you remember...something that might help me find my sister...anything T!"
    scene im338 with dissolve
    pause
    fz "George..."
    scene im339 with dissolve
    te "I'll do it."
    scene im340 with dissolve
    te "I'll do it."
    te "Give me some time to think, but I'll tell you all I can remember...I want to help!"
    ge "You're stronger than you think, Tesia, you're a warrior!"
    stop music fadeout 3
    scene black with Dissolve(3)

    play music "audio/bentomorrow.ogg"
    scene im1095 with Dissolve(1)
    fz "Mom?"
    mm "Franz, I've always let you do whatever you wanted..."
    mm "When you became a rebel after your father died, smoking and doing God knows what else...when you decided not to go to college and work instead, when you moved out not telling me where you were going to live..."
    mm "I do not know what phase you're going through this time, I don't care...Not going to your brother's funeral?"
    mm "I don't want to talk to you right now, I'm not ready...close the door when you leave."
    scene im1096 with dissolve
    pause 1.5
    scene black with Dissolve(1)
    scene im1097 with dissolve
    pause 1.5
    scene im1098 with dissolve
    sa "Hi, we never met, I'm Samantha."
    fz "Yes, I know, my brother showed me some pictures of you two...I'm Franz."
    fz "Thank you for coming, my mom's in my brother's room."
    sa "She never leaves his room..."
    fz "No? You've been coming frequently?"
    sa "Yeah...we're helping each other..."
    fz "Again, thank you so much for keeping my mom company during these hard times."
    scene im1099 with dissolve
    sa "No need to thank me, coming here is the least I can do...and I told you, we're helping each other: she lost a child and I lost the person I loved the most..."
    fz "Seems like we all know what losing is...there are some losses you never recover from, you just can't get on with your life."
    scene im1100 with dissolve
    sa "I understand what you mean: there is no such thing as moving on from love! But you have to move...move WITH your losses!"
    sa "That's what I'm doing: moving WITH my loss...[p] is my biggest one so far."
    fzt "Moving WITH your loss...interesting...she's wise..."
    fz "You know, my brother once told me he found your brain sexy, Samantha."
    scene im1101 with dissolve
    sa "He did? He never told me that...I mean, he told me I was intelligent, but not that my intelligence was sexy..."
    fz "You learn something new every day...well, I have to go now, I wish we had met under different circumstances...take care."
    scene im1102 with dissolve
    sa "YOU take care...Franz Blanco."
    scene im1103 with dissolve
    fzt "Why she said it like that?"
    fzt "She's smart...and loved my brother...is she looking into what I'm doing? Does she know?"
    fzt "\"There is no such thing as moving on from love!\""
    scene im1104 with dissolve
    fzt "I know where that love is going to take you, Samantha..."
    scene im1105 with dissolve
    fzt "I'll see you there."
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

    play music "audio/foundletters.mp3"
    scene im1085 with dissolve
    te "This Saturday, isn't it?"
    fz "Yeah, this Saturday."
    scene im1086 with dissolve
    te "I wanted to tell you something, Franz..."
    fz "I'm listening."
    scene im1087 with dissolve
    te "I know I'm gonna sound very selfish, but..."
    scene im1088 with dissolve
    te "I don't want to lose the little things I got: my moments with you and George..."
    scene im1089 with hpunch
    te "Don't take them away from me, please! That's all I have!"
    fz "Tesia..."
    scene im1090 with dissolve
    fz "We'll be back to you, Little T, we're going to Europe afterwards, remember?"
    fz "You know this is something I need to do, I owe it to my brother...I couldn't save him..."
    scene im1091 with dissolve
    te "Franz..."
    te "You saved me."
    scene im1092 with dissolve
    fz "I did, didn't I?"
    fz "And it was the greatest thing I've done in my life..."
    fz "Thank you for that, Little T."
    stop music fadeout 3
    scene black with Dissolve(3)

    scene im1106 with dissolve
    te "Here, you got this, guys, I'll be waiting for you to go to France..."
    fz "Hehe, thanks for the vote of confidence, Tesia, I saw you packing your clothes earlier."
    scene im1107 with dissolve
    te "Don't take long, okay?"
    fz "We'll be back for dinner!"
    scene black with Dissolve(1)
    scene im450 with Dissolve(1.5)
    ge "I thought William would already be here."
    fz "It's still early...come on, let's get changed."

    scene black with dissolve
    play music "audio/tensioncellowrath.mp3"
    scene im451 with Dissolve(1.5)
    pause
    scene im452 with Dissolve(1)
    ge "I don't know about these things, man, they're heavy..."
    fz "If you don't mind getting shot in the legs, lose them."
    scene im453 with Dissolve(1.5)
    ge "Are you ready for this, brother?"
    scene im454 with dissolve
    fz "I don't think I'll ever be ready to kill people..."
    ge "I know what you mean...but we'll have to do it today, we're here to save those girls at any cost!"
    scene im455 with dissolve
    ge "And when we're done with it, you and Little T are coming with me to Europe, we have to find my sister!"
    fz "Hell yeah, brother! We'll make it out alive!"
    fz "We're going to find Fabi!"
    play sound "audio/carbraking.ogg"
    stop music fadeout 1
    pause 0.5
    scene im456 with dissolve
    fz "Quick, take cover!"
    play sound "audio/carstop.ogg"
    ge "That should be William."
    fz "Never assume, always confirm. That was our first lesson."
    scene black with dissolve
    scene im457 with dissolve
    pause 2
    scene im458 with dissolve
    pause 2
    play sound "audio/guncock.mp3"
    scene im459 with dissolve
    uk "Drop the gun...slowly."
    fzt "What the hell?! When did he get behind me?!"
    scene im461 with dissolve
    uk "Finger always on the trigger, boy...that's too much of a weapon for you anyways..."
    play sound "audio/gunclock.mp3"
    scene im460
    uk "Bang! You're dead."
    wi "Stop messing around, gentlemen..."

    play music "audio/blackice.mp3" volume 0.8

    scene im462:
        ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -0.4

    wi "We got a job to do."
    wi "We're not coming back empty-handed."
    fzt "Oh, William brought some backup..."
    fz "That rifle looks sick! It even has a grenade launcher!"
    wi "We may need it...rescuing those girls won't be easy."
    scene im463 with dissolve
    uk "Hey, Wills, are these two really your guys?"

    scene im464:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause

    uk "We don't need any of these nuisances..."
    fz "What?! Hey, William, who the fuck is this guy?!"
    wi "Watch your mouth, kid, and show some respect! These two are the best hitmen your eyes will ever see: Wicko and Yusuf."
    wi "Didn't you just get a taste of their skills? You'd better shut up, they may save your ass today..."
    scene im465 with dissolve
    wi "Enough with the introductions, you two are coming with me, we're taking down their fucking sniper first..."
    wi "Wicko and Yusuf will be on their own, they work better that way...move!"
    stop music fadeout 3
    scene black with Dissolve(2)
    scene im466 with dissolve
    wi "This's the perfect spot to leave the van...come on, let's get in."
    scene black with dissolve
    play music "audio/sixcoffinnail.ogg"
    scene im467 with dissolve
    wi "Here, put these masks on, they come with a radio, just press this button...it'll be helpful."
    fz "You don't have one?"
    wi "If I need a mask, I'll get one from them."
    scene im468 with dissolve
    wi "Ok, listen, this whole operation depends on what we're about to do: this motherfucker's always aiming at the main building...we have to stop him before Wicko and Yusuf get there..."
    ge "Why did you bring them in? You don't trust us? We've been shooting day and night, we can do this!"
    wi "How many people have you killed?"
    scene im469 with dissolve
    pause
    wi "Exactly."
    wi "But I trust you two. I know you have what it takes to kill, you have all the motives to do so...and that makes me sad...I just wish I didn't have to witness it today."
    scene im470 with dissolve
    ge "What are you talking about, old man?"
    wi "Yeah, I'm getting old..."
    scene im471 with dissolve
    wi "I see myself in you two...twenty, thirty years ago..."
    wi "You're not afraid...but mainly because you don't know what taking someone's life means..."
    wi "Listen, killing's not something to be proud of...don't lie to yourselves thinking that you'll come out of this being heroes..."
    wi "Murderers is what you'll become!"
    scene im472 with vpunch
    wi "Yeah...those men in there have families just like you, they have lost too...maybe more than you...others just need money and don't care about anything else..."
    wi "To us, they're doing something horrible and we're pulling the trigger based on that..."
    scene im473 with dissolve
    fz "William...we understand."
    fz "We've thought of it before, my friend, we know there's a price to pay for saving those girls, and we're at peace with it."
    scene im474 with dissolve
    fz "In fact, we're glad to exchange our souls for their lives, aren't we?"
    scene im475 with dissolve
    fz "Come on! That sacrifice makes us even better human beings!"
    scene im476 with dissolve
    fz "And those men in there ARE doing something horrible, I don't care about their reasons...putting an end to it is our duty!"
    fz "We'll be making this a better world if we get to kill at least one of those motherfuckers, you can label me as a murderer afterwards, I don't care...when I die, I'll accept my punishment...or reward, end of story!"
    fz "So say no more about that, old man, and tell us that plan of yours again..."
    wi "Very well then..."
    scene im477 with dissolve
    wi "There must be a couple of patrols on the west side...Wicko will be taking care of all of them, he hates dirty cops...that way he'll secure our exit."
    ge "That dude's scary..."
    wi "And you don't even know what he's capable of...I bet men in there know him very well, they'll be petrified."
    fz "And the other guy? Yosef, you said?"
    scene im478 with dissolve
    wi "Yusuf...he has to find the exact location where the girls are being captive..."
    ge "You said they're somewhere underground..."
    scene im479 with dissolve
    wi "Yes, but I don't know where the access is...I assume you get there through the main building..."
    wi "Yusuf will be checking all the others to confirm my theory: if he can't find any other entrance, it IS in the main building..."
    scene im480 with dissolve
    wi "And we are dealing with their sniper...I do have an idea of where he could be, but that motherfucker moves constantly..."
    scene im482 with dissolve
    wi "It won't be easy, I'm telling you...there's also a Wicko wannabe to protect him..."
    scene im481 with dissolve
    fz "Nothing's been easy so far, old man, we got this! Don't worry about us, we've seen death before in case you forgot...you made us see it, haha."
    wi "You wanted to..."
    stop music fadeout 3
    scene black with Dissolve(2.5)

    scene im483 with Dissolve(1)
    wi "I'll go this way and you go left...I'll try to be watching you from afar..."
    ge "We don't need you to babysit, old man."
    fz "Yeah, we got this."

    play music "audio/letsplay.mp3" volume 0.8
    scene black with dissolve
    scene im484 with Dissolve(2)
    pause
    scene im485 with Dissolve(2)
    fzt "I ask pardon for all whom I have injured..."

    scene im420 with Dissolve(2)
    pause

    scene im420:
        pause 0.0444
        "im421"
        pause 0.0444
        "im422"
        pause 0.0444
        "im423"
        pause 0.0444
        "im424"
        pause 0.0444
        "im425"
        pause 0.0444
        "im426"
        pause 0.0444
        "im427"
        pause 0.0444
        "im428"
        pause 0.0444
        "im429"
        pause 0.0444
        "im430"
        pause 0.0444
        "im431"
        pause 0.0444
        "im432"
        pause 0.0444
        "im433"
        pause 0.0555
        "im434"
        pause 0.0555
        "im435"
    pause

    scene im436:
        pause 0.0555
        "im437"
        pause 0.0555
        "im438"
        pause 0.0444
        "im439"
        pause 0.0444
        "im440"
        pause 0.0444
        "im441"
        pause 0.0444
        "im442"
        pause 0.0444
        "im443"
        pause 0.0444
        "im444"
        pause 0.0444
        "im445"
        pause 0.0444
        "im446"
        pause 0.0444
        "im447"
        pause 0.0444
        "im448"
        pause 0.0555
        "im449"
        pause 0.0555
        "im420"
    pause
    fzt "Amen."

    scene black with dissolve
    play sound "audio/equipweapon.mp3" volume 5
    scene im486 with dissolve
    fz "I'm ready!"
    ge "Let's save those girls, brother!"

menu:

    "Knock him down.":
        jump choice81a

    "You'll need him.":
        jump choice81b


label choice81a:

    $ choice81a = True

    fzt "I'm tired of losing..."

    scene im486:
        pause 0.0333
        "im487"
        pause 0.0333
        "im488"
        pause 0.0333
        "im489"
        pause 0.0333
        "im490"
        pause 0.0333
        "im491"
        pause 0.0333
        "im492"
        pause 0.0333
        "im493"
        pause 0.0333
        "im494"
        pause 0.0333
        "im495"
        pause 0.0333
        "im496"
        pause 0.0333
        "im497"
        pause 0.0333
        "im498"
        pause 0.0333
        "im499"
        pause 0.0333
        "im500"
        pause 0.0333
        "im501"
        pause 0.0333
        "im502"
        pause 0.0333
        "im503"
        pause 0.0333
        "im504"
        pause 0.0333
        "im505"
        pause 0.0333
        "im506"
        pause 0.0333
    play sound "audio/cinematicpunch1.mp3" volume 10
    pause
    fzt "I won't lose another brother."
    scene black with Dissolve(1)
    scene im507 with Dissolve(1)
    fz "You have to find Fabienne..."
    fz "And protect Little T, my brother."
    scene black with Dissolve(1)
    scene im508 with Dissolve(1)
    pause
    fzt "Alright, you got this, Franz..."
    play sound "audio/equipweapon.mp3" volume 5
    scene im509 with dissolve
    fzt "Let's do it!"
    scene black with dissolve
    scene im512 with dissolve
    pause
    scene im514 with dissolve
    pause
    fzt "A couple of chairs out of place, but no food no nothing...they must come to this part of the factory from time to time..."
    fzt "I must be super alert now that I'm alone..."
    scene im515 with Dissolve(1)
    fzt "I'm getting nervous...calm down...calm down..."
    scene im516 with Dissolve(1)
    fzt "There's no one here..."
    play sound "audio/snipershot.mp3" volume 1.5
    scene im517 with hpunch
    scene im517 with hpunch
    fzt "Shit!"
    fzt "It has started..."
    stop music fadeout 3
    scene black with Dissolve(2.5)
    scene im519 with Dissolve(1)
    play music "audio/maximalism.mp3" volume 0.8
    uk "I know you're there..."
    uk "There's nowhere to hide, bitch."

    scene im519:
        pause 0.0333
        "im520"
        pause 0.0333
        "im521"
        pause 0.0333
        "im522"
        pause 0.0333
        "im523"
        pause 0.0222
        "im524"
        pause 0.0222
        "im525"
        pause 0.0222
        "im526"
        pause 0.0222
        "im527"
        pause 0.0222
        "im528"
        pause 0.0222
        "im529"
        pause 0.0222
        "im530"
        pause 0.0222
        "im531"
        pause 0.0222
        "im532"
        pause 0.0222
        "im533"
        pause 0.0222
        "im534"
        pause 0.0222
        "im535"
        pause 0.0222
        "im536"
        pause 0.0222
        "im537"
        pause 0.0222
        "im538"
        pause 0.0222
        "im539"
        pause 0.0222
        "im540"
        pause 0.0222
        "im541"
        pause 0.0222
        "im542"
        pause 0.0222
        "im543"
        pause 0.0222
        "im544"
        pause 0.0222
        "im545"
        pause 0.0222
    play sound "audio/assaultrifle.mp3"
    pause

    scene im546 with dissolve
    wi "Who says I'm hiding?"
    scene im547 with dissolve
    wi "Bitch."
    scene black with Dissolve(2)

    scene im735 with dissolve
    uk "Please, don't kill me!"
    scene im736 with dissolve
    uk "I have a daugh..."

    play sound "audio/gunshot1.mp3"
    scene im737:
        pause 0.0333
        "im737a"
        pause 0.0333
        "im738"
        pause 0.0333
    scene im739 with dissolve
    pause
    scene black with dissolve
    scene im740 with Dissolve(1)
    play sound "audio/gunshot3.mp3"
    scene im740:
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
    pause 0.3885
    scene im742 with dissolve
    scene im742a with dissolve
    pause
    scene im743 with dissolve
    wic "Lalalala..."
    scene black with dissolve
    scene im744 with dissolve
    uk "Well, well, well, look who we got here..."
    uk "What are you doing here, Wicko? Who hired you?"
    scene im745 with dissolve
    uk "Whoever did really wants results..."
    uk "Hahaha, it doesn't matter...Chucko's here to kill you!"
    chu "You'd better start praying..."
    stop music fadeout 3
    scene black with Dissolve(2)

    scene im550 with dissolve
    fzt "This must be the area..."
    play music "audio/crazydriving.mp3" volume 0.8
    scene im551 with dissolve
    fzt "Moment of truth..."
    scene im552 with dissolve
    fzt "Say hello to my little friend, you fuckers!"
    fzt "No, wait! This's my support side, the technique's wrong..."
    scene im553 with dissolve
    scene im554 with dissolve
    fzt "Change shoulders...switch hands..."
    scene im555 with dissolve
    fzt "Yeah, definitely not my strong side, but here I go!"

    scene im556 with dissolve
    scene im557:
        pause 0.0333
        "im558"
        pause 0.0333
        "im559"
        pause 0.0333
        "im560"
        pause 0.0333
        "im561"
        pause 0.0333
        "im562"
        pause 0.0333
        "im563"
        pause 0.0333
        "im564"
        pause 0.0333
        "im565"
        pause 0.0333
        "im566"
        pause 0.0333
    pause

label snipermission:

    call screen aiming1

    screen aiming1():
        add "im566"
        modal True

        imagebutton auto "handgun_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "handgun")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("aiming1")

        imagebutton auto "trap_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "trap")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("beartrap")

label beartrap:
    fzt "Looks like one of those bear traps...it's big..."
    jump snipermission

label aiming1:

    fzt "Wait a minute..."
    scene im567 with dissolve
    scene im568 with dissolve
    pause
    fzt "There he is!"
    scene im566 with dissolve

    scene im566:
        pause 0.0666
        "im570"
        pause 0.0666
        "im571"
        pause 0.0666
        "im572"
        pause 0.0666
        "im573"
        pause 0.0666
        "im574"
        pause 0.0666
        "im574"
        pause 0.0666
        "im573"
        pause 0.0666
        "im572"
        pause 0.0666
        "im571"
        pause 0.0666
        "im570"
        pause 0.0666
        "im566"
        pause 0.0666
        "im570"
        pause 0.0666
        "im571"
        pause 0.0666
        "im572"
        pause 0.0666
        "im573"
        pause 0.0666
        "im574"
        pause 0.0666
        "im575"
        pause 0.0666
        "im576"
        pause 0.0666
        "im577"
        pause 0.0666
        "im578"
        pause 0.0666
        "im579"
        pause 0.0666
        "im580"
        pause 0.0666
        "im581"
        pause 0.0666
        "im582"
        pause 0.0666
        "im583"
        pause 0.0666
        "im584"
        pause 0.0666
        "im585"
        pause 0.0666
        "im586"
        pause 0.0666
        "im587"
        pause 0.0666
        "im588"
        pause 0.0666
        "im566"
        pause 0.0666
        repeat
    pause
    fzt "I don't think I can do it from here, I don't feel comfortable, can't keep it steady..."
    fzt "Fuck, George would've easily taken him down from this angle..."
    fzt "Better go the other way around..."
    scene black with dissolve
    scene im589 with dissolve
    pause 1.5
    scene im590 with dissolve
    fzt "This is much better...go!"

    scene im591 with dissolve
    scene im592:
        pause 0.0333
        "im593"
        pause 0.0333
        "im594"
        pause 0.0333
        "im595"
        pause 0.0333
        "im596"
        pause 0.0333
        "im597"
        pause 0.0333
        "im598"
        pause 0.0333
        "im599"
        pause 0.0333
        "im600"
        pause 0.0333
    pause
    fzt "If you hesitate, you're dead, Franz...do it!"

    scene im600x with dissolve
    pause
    scene im601x with dissolve
    pause
    scene im602x with dissolve
    pause

init python:
    def corkGunTransform(t, st, at):
        global cork_gun_pos
        global cork_gun_opos

        mousepos = renpy.get_mouse_pos()

        if mousepos[0] - cork_gun_size[0] <= config.screen_width - cork_gun_size[0] and mousepos[0] >= cork_gun_size[0]:
            cork_gun_pos = (mousepos[0] - cork_gun_size[0], cork_gun_opos[1])

        t.xpos = cork_gun_pos[0]

        cork_gun_pos = (cork_gun_pos[0], cork_gun_opos[1] + (mousepos[1] - config.screen_height) / 3)
        t.ypos = cork_gun_pos[1]

        return 0

transform half_size:
    zoom 0.5

screen manualshot:
    image "images/manualshotbackground.png"

    imagebutton auto "assassin1head_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "assassin1head")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("shootingassassin1")

    add cork_gun_transform
    modal True

label manualshotgun:

    $cork_gun_image = Image("images/cork-gun.png")
    $cork_gun_size = (1262 / 2, 1080 / 2)
    $cork_gun_pos = (0, 0)
    $cork_gun_opos = (config.screen_width / 2 - cork_gun_size[0] / 2, config.screen_height - cork_gun_size[1])
    $cork_gun_transform = Transform(child = cork_gun_image, pos = (cork_gun_opos[0], cork_gun_opos[1]), function = corkGunTransform)

    call screen manualshot

label shootingassassin1:

    play sound "audio/assaultriflemany.mp3" volume 2.5

    scene im602:
        pause 0.0333
        "im602a"
        pause 0.0333
        "im602b"
        pause 0.0333
        "im602c"
        pause 0.0333
        "im602d"
        pause 0.0333
        "im602e"
        pause 0.0333
        "im602f"
        pause 0.0333
        "im602g"
        pause 0.0333
        "im602h"
        pause 0.0333
        "im602i"
        pause 0.0333
        "im602j"
        pause 0.0333
    pause
    scene im602j with vpunch
    scene im602j with vpunch
    fzt "HOLY SHIT! I just killed a man!"
    scene im626 with dissolve
    fzt "He deserved it, he killed my brother, he deserved it, he killed my brother..."
    fzt "I have to move! I just gave away my location!"
    scene im628 with dissolve
    fzt "Quick! Decide!"

label snipermission1:

    call screen decide

    screen decide():
        add "im628"
        modal True

        imagebutton auto "sniperarrow1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "sniperarrow1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("sniperarrow1")

        imagebutton auto "sniperarrow2_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "sniperarrow2")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("sniperarrow2")

label sniperarrow1:

    fzt "Careful with that trap...there are many of those apparently..."
    scene im629 with dissolve
    fzt "The sun in on my side today, I can see their shadows..."
    scene im631 with dissolve
    pause 1
    scene im630 with dissolve
    pause
    scene im632 with dissolve
    fzt "There!"
    pause
    fzt "Why you stop?"

    call screen takecover

    screen takecover():
        add "im632"
        modal True

        imagebutton auto "takecover1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "takecover1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("takecover1")

label takecover1:

    scene im633 with dissolve
    pause
    fzt "Come on...move!"
    pause
    fzt "Patience, Franz...he won't stay there forever..."
    scene im646 with dissolve
    fzt "Shit...look at that...my first kill..."
    scene im647 with dissolve
    fzt "Is that a jerrycan over there?"
    fzt "Maybe I could create a distraction...if there's any fuel left in it..."
    fzt "I'll aim lower...felt some muzzle rise the first time..."
    fzt "Tighter grip...one shot only...here we go!"
    stop music fadeout 3

screen manualshot2:
    image "images/manualshot2background.png"

    imagebutton auto "jerrycan_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "jerrycan")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("jerrycanexplo")

    add cork_gun_transform
    modal True

label manualshot2:

    call screen manualshot2

label jerrycanexplo:

    play sound "audio/assaultriflesingleshot.mp3"
    play sound "audio/explosion1.mp3" volume 1.5
    scene im635:
        pause 0.0333
        "im636"
        pause 0.0333
        "im635"
        pause 0.0333
        "im638"
        pause 0.0333
        "im639"
        pause 0.0333
        "im640"
        pause 0.0166
        "im641"
        pause 0.0166
        "im642"
        pause 0.0166
        "im643"
        pause 0.0166
        "im644" with vpunch
        pause 0.0333
    scene im644 with dissolve
    fzt "Shit, my ears!"
    scene im645 with Dissolve(1)
    fzt "His shadow! He's looking that way...go, go, go!"
    play sound "audio/twofootsteps.mp3"
    scene im648 with dissolve
    scene im649 with dissolve
    fzt "Gotcha, motherfucker!"

    call screen kill2

    screen kill2():
        add "im649"
        modal True

        imagebutton auto "headshot1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "headshot1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("kill2")

label kill2:

    play sound "audio/assaultriflesingleshot.mp3" volume 3
    scene im650:
        pause 0.0333
        "im651"
        pause 0.0333
        "im652"
        pause 0.0333
    scene im653 with dissolve
    fzt "Take that, you fucking pedophile! You deserve it!"
    scene im654 with Dissolve(1)
    pause
    fzt "Daaammnn...two bodies already..."
    scene im655 with dissolve
    play music "audio/infrabreathe.mp3" volume 0.8
    play sound "audio/gettingshot.mp3" volume 3
    scene im659 with vpunch
    fzt "The fuck?! Where did it come from?!"
    fzt "It stings..."
    scene im660 with dissolve
    fzt "Where are you, son of a bitch?"
    play sound "audio/gunshot4.mp3"
    scene im661 with dissolve
    pause
    fzt "Oh, thank God that Turkish guy's here..."
    fzt "He's not even taking cover...what a crazy motherfucker..."
    scene im662 with dissolve
    fzt "We can do this!"
    stop sound
    scene im663 with dissolve
    pause
    fzt "What the hell is he doing?!"
    scene im664 with dissolve
    fzt "That sniper should be up there..."
    scene im665 with dissolve
    pause
    scene im666 with dissolve
    pause
    fzt "What?"
    fzt "I don't undertand...two?"
    scene im667 with dissolve
    fz "Wait!"
    scene im669 with dissolve
    fzt "Well, he got that side covered..."
    scene im670 with hpunch
    fzt "I got you motherfucker!"

    call screen killwickowannabe

    screen killwickowannabe():
        add "im670"
        modal True

        imagebutton auto "killwickowanna_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "killwickowanna")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("killwickowannabe")

label killwickowannabe:

    play sound "audio/assaultriflesingleshot.mp3" volume 3
    scene im671:
        pause 0.0333
        "im672"
        pause 0.0333
        "im671"
        pause 0.0333
        "im672"
        pause 0.0333
        "im671"
        pause 0.0333
    scene im673 with dissolve
    play music "audio/gettingshot2.mp3"
    play sound "audio/grunt1.mp3"
    scene im675 with vpunch
    stop music fadeout 2
    fzt "Fuck!"
    scene im676 with Dissolve(1)
    play sound "audio/gunshot4.mp3"
    pause
    fzt "Now that he's distracted!"
    scene im678 with dissolve
    fzt "Take the fucking shot, Franz!"
    play music "audio/tension3.ogg"


init python:
    def bloodyarmTransform(t, st, at):
        global bloodyarm_pos
        global bloodyarm_opos

        mousepos = renpy.get_mouse_pos()

        if mousepos[0] - bloodyarm_size[0] <= config.screen_width - bloodyarm_size[0] and mousepos[0] >= bloodyarm_size[0]:
            bloodyarm_pos = (mousepos[0] - bloodyarm_size[0], bloodyarm_opos[1])

        t.xpos = bloodyarm_pos[0]

        bloodyarm_pos = (bloodyarm_pos[0], bloodyarm_opos[1] + (mousepos[1] - config.screen_height) / 3)
        t.ypos = bloodyarm_pos[1]

        return 0

transform half_size:
    zoom 0.5

screen manualshot3:
    image "images/manualshot3background.png"

    imagebutton auto "wickowannabehead_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "wickowannabehead")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("shootingwickowannabe")

    add bloodyarm_transform
    modal True

label manualshotgun2:

    $bloodyarm_image = Image("images/bloodyarm.png")
    $bloodyarm_size = (1462 / 2, 1080 / 2)
    $bloodyarm_pos = (0, 0)
    $bloodyarm_opos = (config.screen_width / 2 - bloodyarm_size[0] / 2, config.screen_height - bloodyarm_size[1])
    $bloodyarm_transform = Transform(child = bloodyarm_image, pos = (bloodyarm_opos[0], bloodyarm_opos[1]), function = bloodyarmTransform)

    call screen manualshot3

label shootingwickowannabe:

    play sound "audio/assaultriflemany.mp3" volume 2.5

    scene im679:
        pause 0.0333
        "im680"
        pause 0.0333
        "im681"
        pause 0.0333
        "im682"
        pause 0.0166
        "im683"
        pause 0.0166
        "im685"
        pause 0.0333
        "im686"
        pause 0.0166
        "im687"
        pause 0.0166
        "im689"
        pause 0.0333
        "im690"
        pause 0.0333
        "im691"
        pause 0.0333
        "im692"
        pause 0.0333
        "im693"
        pause 0.0333
    pause
    fzt "Three..."
    fz "May God have mercy upon my soul."
    scene im694 with dissolve
    fzt "Don't think about it...not now..."
    scene im695 with dissolve
    fzt "This's not over yet."
    play sound "audio/gunshothard.mp3"
    scene im695 with dissolve
    scene im696 with vpunch
    pause
    fzt "That was unnecessary..."
    scene im697 with dissolve
    pause
    scene im698 with dissolve
    yus "Not bad, kid, you're skilled...you have a future as a hitman."
    fz "Not interested."
    yus "Too bad, money's good...where's Wills?"
    fz "We split and I lost him."
    yus "It's you and me then to kill that sniper, no time to waste: I found an elevator to get to lower levels, a truck's heading that way too...to take the girls somewhere else I presume..."
    scene im698 with vpunch
    fz "What?! We were not counting on that...today's the 21st, though...The Nyack's mansion! We must hurry!"
    scene im698a with dissolve
    yus "Relax, kid, I left my boy Wicko there, he'll deal with that truck, shouldn't be a problem."
    scene im698b with dissolve
    fzt "These guys are professionals, they got it all covered...we wouldn't have made it without them...William knew."
    fz "Ok, man, how do we do this?"
    scene im699 with dissolve
    yus "You'll be the bait."
    yus "Climb up there, he'll show himself and when he does...BAM! I kill him."
    scene im699 with hpunch
    fz "What?! That's your master plan?!"
    yus "If you have a better idea, share it right now..."
    fz "I don't know...a bomb?"
    yus "I don't have a bomb, do you?"
    fz "No..."
    yus "It's settled then. Hurry up...and grab a pistol, it's lighter."
    scene im700 with dissolve
    yus "Don't worry, I'll get him easily. I'm the best!"
    stop music fadeout 3
    scene black with Dissolve(2)
    scene im701 with Dissolve(1)
    pause
    scene im702 with Dissolve(1)
    fzt "I'm trusting this dude with my life..."
    scene black with dissolve
    play music "audio/tensioncellowrath.mp3"
    scene im703 with Dissolve(1)
    pause
    scene im704 with Dissolve(1)
    pause
    scene im705 with Dissolve(1)
    fzt "He must have heard me by now, you can't be really quiet walking on these containers..."
    scene black with dissolve
    scene im707 with dissolve
    fzt "No signs of him yet..."
    scene im708 with dissolve
    pause
    scene im709 with dissolve
    pause
    scene im710 with dissolve
    pause
    scene im711 with dissolve
    pause
    scene im712 with dissolve
    pause
    scene im713 with dissolve
    pause
    scene im714 with Dissolve(0.5)
    scene im715 with Dissolve(0.5)
    scene im716 with Dissolve(0.5)
    fzt "Okay, Franz, focus now..."
    play sound "audio/gunshothard.mp3"
    scene im717 with hpunch
    scene im717 with hpunch
    scene im723 with dissolve
    pause
    yus "His temple...not bad...come on, come to daddy."
    play sound "audio/deadbodyfall.mp3" volume 6

    scene im717 with dissolve
    scene im718:
        pause 0.0777
        "im719"
        pause 0.0777
        "im720"
        pause 0.0777
        "im721"
        pause 0.0777
        "im722"
        pause 0.0777
    pause 0.3885
    scene im722 with vpunch
    pause
    fzt "Daaammnn...this dude's good! He had the slightest ch..."
    fzt "What are you doing, Franz? Praising someone's killing skills? Just shut up and go save those girls!"
    stop music fadeout 3
    scene black with Dissolve(2)

    jump backtowicko

label sniperarrow2:

    fzt "Go!"
    scene im725 with dissolve
    scene im726 with dissolve
    scene im727 with dissolve
    scene im728 with dissolve
    scene im729 with dissolve
    scene im730 with dissolve
    play sound "audio/manscreaming1.mp3" volume 0.6
    scene im731 with vpunch
    scene im731 with vpunch
    fz "FUUUUCCKKKK!!!"
    scene im732 with vpunch
    scene im732 with vpunch
    fzt "A hidden trap??!!"
    fzt "Fuuuuuck!!! I'm not gonna make it..."
    stop music fadeout 3
    scene im733 with Dissolve(1)
    pause
    play sound "audio/snipershot.mp3"
    scene im733 with Dissolve(0.2)
    stop music
    scene black
    pause
    scene franzhasbecome with dissolve
    pause
    scene black with Dissolve(2.0)
    scene murderer with Dissolve(2)
    pause
    scene black with Dissolve(4)

    return

label backtowicko:

    pause
    scene im745 with dissolve
    chu "Why don't we settle this like men? No weapons, just our hands."
    chu "Haha, oh, you have no idea how I'm going to enjoy this..."

    scene im746 with dissolve
    play sound "audio/versussound.ogg"
    play music "audio/getready.mp3"
    scene im747 with Dissolve(0.022)
    scene im748 with Dissolve(0.022)
    scene im749 with Dissolve(0.022)
    scene im750 with Dissolve(0.022)
    scene im751 with Dissolve(0.022)
    scene im752 with Dissolve(0.022)
    scene im753 with Dissolve(0.022)
    scene im754 with Dissolve(0.022)
    scene im755 with Dissolve(0.022)
    scene im756 with Dissolve(0.022)
    scene im757 with Dissolve(0.022)
    scene im758 with hpunch
    play sound "audio/versussound.ogg"
    scene im759 with Dissolve(0.022)
    scene im760 with Dissolve(0.022)
    scene im761 with Dissolve(0.022)
    scene im762 with Dissolve(0.022)
    scene im763 with Dissolve(0.022)
    scene im764 with Dissolve(0.022)
    scene im765 with Dissolve(0.022)
    scene im766 with Dissolve(0.022)
    scene im767 with vpunch
    play sound "audio/versussound.ogg"
    scene im768 with Dissolve(0.0133)
    scene im769 with Dissolve(0.0133)
    scene im770 with Dissolve(0.0133)
    scene im771 with Dissolve(0.0133)
    scene im772 with Dissolve(0.0133)
    scene im773 with Dissolve(0.0133)
    scene im774 with Dissolve(0.0133)
    scene im775 with Dissolve(0.0133)
    scene im776 with Dissolve(0.0133)
    scene im777 with Dissolve(0.0133)
    scene im778 with Dissolve(0.0133)
    scene im779 with Dissolve(0.0133)
    scene im780 with Dissolve(0.0133)
    scene im781 with Dissolve(0.0133)
    scene im782 with hpunch
    scene im782 with dissolve

    play music "audio/adventure.mp3" volume 0.8
    scene im782 with dissolve
    play sound "audio/cardentrance.mp3"
    scene im783 with vpunch
    scene im783 with vpunch
    pause

    scene im746 with dissolve
    scene im785 with dissolve
    chu "Are you ready for this, Wicko?"

    scene im786:
        pause 0.0222
        "im787"
        pause 0.0222
        "im788"
        pause 0.0222
        "im789"
        pause 0.0222
        "im790"
        pause 0.0222
        "im791"
        pause 0.0222
        "im792"
        pause 0.0222
        "im793"
        pause 0.0222
        "im794"
        pause 0.0222
        "im795"
        pause 0.0222
        "im796"
        pause 0.0222
        "im797"
        pause 0.0222
        "im798"
        pause 0.0222
        "im799"
        pause 0.0222
        "im800"
        pause 0.0222
        "im801"
        pause 0.0222
        "im802"
        pause 0.0222
        "im803"
        pause 0.0222
        "im804"
        pause 0.0222
        "im805"
        pause 0.0222
        "im806"
        pause 0.0222
        "im807"
        pause 0.0222
        "im808"
        pause 0.0222
        "im809"
        pause 0.0222
        "im810"
        pause 0.0222
        "im811"
        pause 0.0222
        "im812"
        pause 0.0222
        "im813"
        pause 0.0222
        "im814"
        pause 0.0222
        "im815"
        pause 0.0222
    pause
    chu "Impressed?"
    chu "Faster than the speed of light, huh?"

    call screen killchucko

    screen killchucko():
        add "im815"
        modal True

        imagebutton auto "headshotchucko_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "headshotchucko")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("killchucko")

label killchucko:

    play sound "audio/gunshot1.mp3"
    scene im816:
        pause 0.0333
        "im817"
        pause 0.0333
        "im818"
        pause 0.0333
        "im817"
        pause 0.0333
        "im819"
        pause 0.0333
        "im819a"
        pause 0.0666
        "im820"
        pause 0.0666
    scene im821 with dissolve
    pause
    scene im822 with Dissolve(2)
    scene black with Dissolve(1)

    scene im823 with Dissolve(1)
    wi "Take cover right now!"
    yus "Cover is for rookies, Wills, what's wrong with you? Getting old?"
    fz "I don't see anybody."
    wi "Two men behind that wall."
    scene im824 with dissolve
    wi "You ok?"
    fz "Yeah, this is just a scratch."
    wi "And George?"
    fz "Don't worry about him, he'll be here any minute..."
    wi "Listen you two, I just saw them take one girl underground, we have to get on that elevator..."
    stop music fadeout 3
    play sound "audio/elevatorspooky.ogg"
    scene im825 with dissolve
    wi "Take cover, kid, someone's coming..."

    play sound "audio/oldelevatordoor.mp3"

    scene im826 with dissolve
    scene im826a with dissolve
    scene im827 with dissolve
    pause 1
    scene im828 with Dissolve(2)
    play music "audio/whoisyourgod.mp3"
    scene im828 with vpunch
    scene im828 with vpunch
    yus "Dutch!!!"
    yus "What the hell is he doing here?! You didn't say anything about him!"
    wi "I didn't know he was going to be here..."
    yus "What do they have down there? I doubt there's only a few girls..."
    scene im829 with dissolve
    fzt "Now you're taking cover, huh...That Dutch guy must be a beast..."
    fzt "I think I have a clean shot from here..."


    call screen killdutch

    screen killdutch():
        add "im829"
        modal True

        imagebutton auto "headshotdutch_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "headshotdutch")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("killdutch")

label killdutch:

    play sound "audio/assaultriflesingleshot.mp3" volume 2
    scene im830:
        pause 0.0333
        "im831"
        pause 0.0333
        "im830"
        pause 0.0333
    scene im832 with dissolve
    fzt "Fuck! Where'd he go?"
    wi "Move, Franz, now!!!"
    scene im833 with dissolve
    fzt "Move where?!"
    scene im834 with dissolve
    scene im835 with dissolve
    scene im836 with dissolve
    scene im836a with dissolve
    play sound "audio/grenadelauncher.mp3" volume 2
    scene im837:
        pause 0.0999
        "im838"
        pause 0.0999
        "im839"
        pause 0.0999
        "im840"
        pause 0.0999
        "im840"
        pause 0.0999
    pause 0.4995
    play sound "audio/explosion2.mp3" volume 2
    scene im841 with vpunch
    scene im841 with vpunch
    scene im841 with vpunch
    scene im842 with dissolve
    scene im843 with dissolve
    scene im844 with vpunch
    scene im844 with vpunch
    pause
    fzt "Oh, shit! Everything hurts...my legs...my ribs..."
    fzt "I can't move..."

    play sound "audio/assaultriflemany.mp3" volume 2
    scene im845:
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
        "im846"
        pause 0.0333
        "im845"
        pause 0.0333
    pause 0.4329
    scene im847 with dissolve

    play sound "audio/gunshotmany.mp3"
    scene im848:
        pause 0.0666
        "im848a"
        pause 0.0666
        "im848"
        pause 0.0666
        "im848a"
        pause 0.0666
        "im848"
        pause 0.0666
    pause
    fzt "You can do it, Turkish guy..."
    scene im849 with dissolve
    wi "Don't fall asleep, be right back."
    play sound "audio/gunshot3.mp3"
    scene im849:
        pause 0.0666
        "im849x"
        pause 0.0666
        "im849"
        pause 0.0666
        "im849x"
        pause 0.0666
        "im849"
        pause 0.0666
        "im849x"
        pause 0.0666
        "im849"
        pause 0.0666
    fzt "Go, do it quickly...another grenade blast like that and you're dead too..."
    scene im850 with dissolve
    wi "I'm serious, kid, do not close your eyes..."
    scene im849 with dissolve
    stop music fadeout 4
    scene im849a with Dissolve(0.8)
    scene im849b with Dissolve(0.8)
    scene im849c with Dissolve(0.8)

    scene black with Dissolve(2)
    play music "audio/betterlife.mp3"
    scene im851a with Dissolve(3)
    fzt "Little brother?"
    scene im851 with hpunch
    fz "[p]!"
    scene im852 with dissolve
    fz "What are you kids doing?"
    scene im853 with dissolve
    fab "Yes!"
    p "Seriously, Franz?"
    fz "What?"
    p "You said we were going to play football outside, not superheroes."
    fz "What are you talking about? I don't want to play superheroes..."
    scene im854 with dissolve
    fab "Lalalalala..."
    p "Yeah, right, then why are you wearing that?"
    scene im855 with dissolve
    p "And you quit doing the victory dance!"
    fab "La."
    fz "Wearing what? What am I..."
    stop music fadeout 3
    scene im856 with dissolve
    scene im856 with vpunch
    play sound "audio/burningfire.mp3" fadein 3
    fzt "What the hell?!"
    fzt "I'm bleeding!"
    fzt "Wait a minute...I was not here..."
    fzt "But this is so vivid..."
    scene im858 with Dissolve(3)
    play music "audio/chasedbyterror.mp3"
    pause
    fzt "You killed three men today, don't you remember?"
    scene black with Dissolve(2)
    play sound "audio/burningfire.mp3"
    "Don't you dare die on me, you hear me?!"
    fzt "Who's that?"
    "You can't die on me, brother!"
    fzt "Brother?"
    fzt "[p]?"
    scene black with Dissolve(1)
    scene im859a with Dissolve(1)
    scene im859b with dissolve
    fzt "George?"
    fzt "What happened?"
    scene im859c with Dissolve(1)
    scene im859 with Dissolve(1)
    ge "I'm gonna get you out of here, brother, stay awake!"
    scene im860 with Dissolve(2)
    pause
    scene im861 with Dissolve(2)
    pause
    stop music fadeout 4
    stop sound fadeout 4

    scene black with Dissolve(4.0)
    scene nobodywas with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause

    return

#2nd mission
label choice81b:

    $ choice81b = True

    scene im510 with dissolve
    fz "Hold up, George..."
    scene im510a with dissolve
    fz "We can get caught in the open by that sniper, let's go through those buildings on the left..."
    ge "We're still a mile away from him, this place's huge...but okay, better safe than sorry..."
    scene black with dissolve
    scene im511 with dissolve
    ge "We're getting out of this alive, brother!"
    fz "I know, go!"
    scene black with dissolve
    scene im514 with dissolve
    pause 1
    scene im513 with dissolve
    ge "Nothing here."
    fz "Nothing this way, either. Keep moving."
    scene im516 with dissolve
    fz "There's no one here..."
    play sound "audio/snipershot.mp3" volume 1.5
    scene im518 with hpunch
    scene im518 with hpunch
    ge "What the hell?!"
    fz "Must be the sniper..."
    ge "I'd never heard that kind of sound before..."
    fz "Keep moving, brother."
    stop music fadeout 3
    scene black with Dissolve(2.5)
    scene im519 with Dissolve(1)
    play music "audio/maximalism.mp3" volume 0.8
    uk "I know you're there..."
    uk "There's nowhere to hide, bitch."

    scene im519:
        pause 0.0333
        "im520"
        pause 0.0333
        "im521"
        pause 0.0333
        "im522"
        pause 0.0333
        "im523"
        pause 0.0222
        "im524"
        pause 0.0222
        "im525"
        pause 0.0222
        "im526"
        pause 0.0222
        "im527"
        pause 0.0222
        "im528"
        pause 0.0222
        "im529"
        pause 0.0222
        "im530"
        pause 0.0222
        "im531"
        pause 0.0222
        "im532"
        pause 0.0222
        "im533"
        pause 0.0222
        "im534"
        pause 0.0222
        "im535"
        pause 0.0222
        "im536"
        pause 0.0222
        "im537"
        pause 0.0222
        "im538"
        pause 0.0222
        "im539"
        pause 0.0222
        "im540"
        pause 0.0222
        "im541"
        pause 0.0222
        "im542"
        pause 0.0222
        "im543"
        pause 0.0222
        "im544"
        pause 0.0222
        "im545"
        pause 0.0222
    play sound "audio/assaultrifle.mp3"
    pause

    scene im546 with dissolve
    wi "Who says I'm hiding?"
    scene im547 with dissolve
    wi "Bitch."
    scene black with Dissolve(2)

    scene im735 with dissolve
    uk "Please, don't kill me!"
    scene im736 with dissolve
    uk "I have a daugh..."

    play sound "audio/gunshot1.mp3"
    scene im737:
        pause 0.0333
        "im737a"
        pause 0.0333
        "im738"
        pause 0.0333
    scene im739 with dissolve
    pause
    scene black with dissolve
    scene im740 with Dissolve(1)
    play sound "audio/gunshot3.mp3"
    scene im740:
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
        "im741"
        pause 0.0555
        "im740"
        pause 0.0555
    pause 0.3885
    scene im742 with dissolve
    scene im742a with dissolve
    pause
    scene im743 with dissolve
    wic "Lalalala..."
    scene black with dissolve
    scene im744 with dissolve
    uk "Well, well, well, look who we got here..."
    uk "What are you doing here, Wicko? Who hired you?"
    scene im745 with dissolve
    uk "Whoever did really wants results..."
    uk "Hahaha, it doesn't matter...Chucko's here to kill you!"
    chu "You'd better start praying..."
    stop music fadeout 3
    scene black with Dissolve(2)

    scene im550 with dissolve
    ge "They must be around here, brother..."
    scene im862 with dissolve
    ge "You go that way..."
    fz "Got it."
    play music "audio/crazydriving.mp3" volume 0.8
    scene im591 with dissolve
    fzt "Tight grip..."
    scene im590 with dissolve
    fzt "Stock on the outside of my shoulder..."
    fzt "I'm missing something..."
    play sound "audio/policeradio.mp3"
    pause
    ge "Hey, Franz, I spotted one dude, you?"
    fz "Not yet, give me a second..."

    scene im591 with dissolve
    scene im592:
        pause 0.0333
        "im593"
        pause 0.0333
        "im594"
        pause 0.0333
        "im595"
        pause 0.0333
        "im596"
        pause 0.0333
        "im597"
        pause 0.0333
        "im598"
        pause 0.0333
        "im599"
        pause 0.0333
        "im600"
        pause 0.0333
    pause
    fz "I can see one! I have a clean shot."
    fzt "Reverse your stands!"
    ge "You shoot first, I need this one to get distracted..."
    fz "Ok, here I go..."

    scene im600x with dissolve
    pause
    scene im601x with dissolve
    pause
    scene im602x with dissolve
    pause

init python:
    def corkGunTransform(t, st, at):
        global cork_gun_pos
        global cork_gun_opos

        mousepos = renpy.get_mouse_pos()

        if mousepos[0] - cork_gun_size[0] <= config.screen_width - cork_gun_size[0] and mousepos[0] >= cork_gun_size[0]:
            cork_gun_pos = (mousepos[0] - cork_gun_size[0], cork_gun_opos[1])

        t.xpos = cork_gun_pos[0]

        cork_gun_pos = (cork_gun_pos[0], cork_gun_opos[1] + (mousepos[1] - config.screen_height) / 3)
        t.ypos = cork_gun_pos[1]

        return 0

transform half_size:
    zoom 0.5

screen manualshotb:
    image "images/manualshotbackground.png"

    imagebutton auto "assassin1headb_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "assassin1headb")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("shootingassassin1b")

    add cork_gun_transform
    modal True

label manualshotgunb:

    $cork_gun_image = Image("images/cork-gun.png")
    $cork_gun_size = (1262 / 2, 1080 / 2)
    $cork_gun_pos = (0, 0)
    $cork_gun_opos = (config.screen_width / 2 - cork_gun_size[0] / 2, config.screen_height - cork_gun_size[1])
    $cork_gun_transform = Transform(child = cork_gun_image, pos = (cork_gun_opos[0], cork_gun_opos[1]), function = corkGunTransform)

    call screen manualshotb

label shootingassassin1b:

    play sound "audio/assaultriflemany.mp3" volume 2.5

    scene im602:
        pause 0.0333
        "im602a"
        pause 0.0333
        "im602b"
        pause 0.0333
        "im602c"
        pause 0.0333
        "im602d"
        pause 0.0333
        "im602e"
        pause 0.0333
        "im602f"
        pause 0.0333
        "im602g"
        pause 0.0333
        "im602h"
        pause 0.0333
        "im602i"
        pause 0.0333
        "im602j"
        pause 0.0333
    pause
    scene im602j with vpunch
    scene im602j with vpunch
    fzt "HOLY SHIT! I just killed a man!"
    play sound "audio/gunshot3.mp3"
    pause
    ge "Done."
    fz "Mine's dead, too..."
    ge "There are many bear traps around, brother."
    scene im628 with dissolve
    fz "Yeah, I saw one."
    ge "Hey, Franz, I just saw a shadow on top of these containers, come here..."
    play sound "audio/shootout1.mp3" volume 2
    scene im626 with hpunch
    scene im626 with hpunch
    scene im628 with dissolve
    scene im629 with dissolve
    scene im630 with dissolve
    scene im863 with dissolve
    scene im864 with dissolve
    scene im865 with dissolve
    scene im866 with dissolve
    scene im867 with dissolve
    scene im868 with dissolve
    scene im869 with dissolve
    scene im870 with dissolve
    play sound "audio/gunshot3.mp3"
    scene im870:
        pause 0.0666
        "im871"
        pause 0.0666
        "im870"
        pause 0.0666
        "im871"
        pause 0.0666
        "im870"
        pause 0.0666
        "im871"
        pause 0.0666
        "im870"
        pause 0.0666
    pause
    scene im870 with dissolve
    ge "Hold there, he's mine."
    scene im872 with dissolve
    fzt "He could come this way..."
    scene im873 with dissolve
    fzt "On top of the con..."
    fzt "Is that the sniper?"
    stop music fadeout 3

    call screen killsniper2

    screen killsniper2():
        add "im873"
        modal True

        imagebutton auto "sniperhead_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "sniperhead")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("sniperhead1")

label sniperhead1:

    play sound "audio/assaultriflesingleshot.mp3" volume 3
    scene im874:
        pause 0.0333
        "im875"
        pause 0.0333
        "im876"
        pause 0.0333
        "im876a"
        pause 0.0333
        "im877"
        pause 0.0333
    play music "audio/bulletonmetal.mp3" volume 2
    scene im878 with dissolve
    stop music
    fzt "Fuck, I missed!"
    fzt "Gotta find cover..."
    stop music
    scene im872 with dissolve
    scene im879 with dissolve
    scene im880 with dissolve
    scene im881 with dissolve
    pause
    fzt "I could go this way to help George..."
    play sound "audio/gunshothard.mp3"
    scene im881 with hpunch
    play music "audio/blackice.mp3" volume 0.8
    scene im882 with dissolve
    fzt "Turkish guy..."
    ge "Dude, I told you I wanted him!"

    scene im884 with dissolve

    scene im884:
        pause 0.0444
        "im885"
        pause 0.0444
        "im886"
        pause 0.0444
        "im887"
        pause 0.0444
        "im888"
        pause 0.0444
        "im889"
        pause 0.0444
        "im890"
        pause 0.0444
        "im891"
        pause 0.0444
        "im892"
        pause 0.0444
        "im893"
        pause 0.0444
        "im894"
        pause 0.0444
        "im895"
        pause 0.0444
        "im896"
        pause 0.0444
        "im897"
        pause 0.0444
        "im898"
        pause 0.0444
        "im899"
        pause 0.0444
    play sound "audio/gunshothard1.mp3"
    pause
    fz "It wasn't me, it was the Turkish man."
    scene im900 with dissolve
    ge "Yusuf? Daaamn, he's good! It was a perfect shot, brother!"
    scene im882 with dissolve
    scene im883 with dissolve
    ge "I'm coming your way, we need a plan to kill that sniper."
    scene black with dissolve
    scene im902 with dissolve
    yus "You two did a good job getting this close unnoticed..."
    scene im901 with dissolve
    ge "Look what I found."
    fz "You okay?"
    ge "Yeah, it doesn't even hurt, don't worry about it."
    scene im903 with dissolve
    yus "The predator's become the prey now, haha."
    fz "He's outnumbered...I saw him."
    yus "You saw him?"
    fz "Yeah, I fired, but missed."
    scene im904 with dissolve
    yus "Ugh, that means he's trash..."
    scene im905 with dissolve
    yus "If a sniper's any good, you'll never see him until he shoots, and that's generally too late...I thought he was going to be a challenge, I'm getting bored here..."
    scene im906 with dissolve
    ge "That's why I got this! Entertaining enough?"
    yus "That's a start, I wouldn't mind seeing some fireworks, haha."
    fzt "Is killing fun for this bastard?"
    scene im907 with dissolve
    yus "Actually, that's a great idea, let's bomb him! He's a coward and doesn't deserve any of my bullets."
    fzt "That is true: we've killed all his friends and he's still up there hiding."
    yus "Oh, and let's do it quick, I know where the girls are."
    ge "What?! That's great! Every minute counts, let's end this...you guys cover me."
    scene im908 with dissolve
    fz "Hold on, George, I think it's better if I do it, you two are better shooters than I am."
    ge "You sure, buddy?"
    fz "Yeah, yeah, give me that."
    scene black with dissolve
    scene im909 with dissolve
    fz "How long do I have after I release the spoon?"
    yus "Four seconds."
    scene im910 with dissolve
    pause
    scene im911 with dissolve
    play sound "audio/policeradio.mp3"
    pause
    ge "Dude, I saw a glint!"
    fz "Blow his head up, I'm not carrying any weapons..."
    ge "I think it was his scope..."
    scene im912 with dissolve
    fz "Do you see him?"
    ge "Not now, no..."
    fz "I'm just gonna throw it from here..."
    ge "Aim to your left, that's where I saw the glint..."
    fz "Alright, here I go."
    scene im913 with dissolve
    fzt "Grab the spoon, don't release it, pull this ring..."
    scene im914 with dissolve
    pause 1
    scene im915 with Dissolve(1)
    play sound "audio/bombbounce.mp3" volume 2.5
    scene im916 with dissolve
    fzt "Gotta get the hell out of here!"
    play sound "audio/explosion3.mp3" volume 1.5
    scene im917 with vpunch
    scene im917 with vpunch
    scene im918 with dissolve
    scene im919 with dissolve
    fzt "Shit!"
    play sound "audio/deadbodyfall.mp3" volume 6
    scene im920 with Dissolve(1)
    scene im920 with vpunch
    pause
    fzt "Holy fuck, that's a horrible death..."
    scene black with dissolve
    scene im921 with dissolve
    yus "You did a good job, kid, I didn't have much faith in you, to be honest."
    scene im922 with dissolve
    yus "Somebody grab that weapon, we may need it...Fire it first, it could be damaged after that explosion..."
    stop music fadeout 3
    scene black with Dissolve(2)

    jump backtowickob

label backtowickob:

    pause
    scene im745 with dissolve
    chu "Why don't we settle this like men? No weapons, just our hands."
    chu "Haha, oh, you have no idea how I'm going to enjoy this..."

    scene im746 with dissolve
    play sound "audio/versussound.ogg"
    play music "audio/getready.mp3"
    scene im747 with Dissolve(0.022)
    scene im748 with Dissolve(0.022)
    scene im749 with Dissolve(0.022)
    scene im750 with Dissolve(0.022)
    scene im751 with Dissolve(0.022)
    scene im752 with Dissolve(0.022)
    scene im753 with Dissolve(0.022)
    scene im754 with Dissolve(0.022)
    scene im755 with Dissolve(0.022)
    scene im756 with Dissolve(0.022)
    scene im757 with Dissolve(0.022)
    scene im758 with hpunch
    play sound "audio/versussound.ogg"
    scene im759 with Dissolve(0.022)
    scene im760 with Dissolve(0.022)
    scene im761 with Dissolve(0.022)
    scene im762 with Dissolve(0.022)
    scene im763 with Dissolve(0.022)
    scene im764 with Dissolve(0.022)
    scene im765 with Dissolve(0.022)
    scene im766 with Dissolve(0.022)
    scene im767 with vpunch
    play sound "audio/versussound.ogg"
    scene im768 with Dissolve(0.0133)
    scene im769 with Dissolve(0.0133)
    scene im770 with Dissolve(0.0133)
    scene im771 with Dissolve(0.0133)
    scene im772 with Dissolve(0.0133)
    scene im773 with Dissolve(0.0133)
    scene im774 with Dissolve(0.0133)
    scene im775 with Dissolve(0.0133)
    scene im776 with Dissolve(0.0133)
    scene im777 with Dissolve(0.0133)
    scene im778 with Dissolve(0.0133)
    scene im779 with Dissolve(0.0133)
    scene im780 with Dissolve(0.0133)
    scene im781 with Dissolve(0.0133)
    scene im782 with hpunch

    scene im782 with dissolve

    play music "audio/adventure.mp3" volume 0.8
    scene im782 with dissolve
    play sound "audio/cardentrance.mp3"
    scene im783 with vpunch
    scene im783 with vpunch
    pause

    scene im746 with dissolve
    scene im785 with dissolve
    chu "Are you ready for this, Wicko?"

    scene im786:
        pause 0.0222
        "im787"
        pause 0.0222
        "im788"
        pause 0.0222
        "im789"
        pause 0.0222
        "im790"
        pause 0.0222
        "im791"
        pause 0.0222
        "im792"
        pause 0.0222
        "im793"
        pause 0.0222
        "im794"
        pause 0.0222
        "im795"
        pause 0.0222
        "im796"
        pause 0.0222
        "im797"
        pause 0.0222
        "im798"
        pause 0.0222
        "im799"
        pause 0.0222
        "im800"
        pause 0.0222
        "im801"
        pause 0.0222
        "im802"
        pause 0.0222
        "im803"
        pause 0.0222
        "im804"
        pause 0.0222
        "im805"
        pause 0.0222
        "im806"
        pause 0.0222
        "im807"
        pause 0.0222
        "im808"
        pause 0.0222
        "im809"
        pause 0.0222
        "im810"
        pause 0.0222
        "im811"
        pause 0.0222
        "im812"
        pause 0.0222
        "im813"
        pause 0.0222
        "im814"
        pause 0.0222
        "im815"
        pause 0.0222
    pause
    chu "Impressed?"
    chu "Faster than the speed of light, huh?"

    call screen killchuckob

    screen killchuckob():
        add "im815"
        modal True

        imagebutton auto "headshotchuckob_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "headshotchuckob")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("killchuckob")

label killchuckob:

    play sound "audio/gunshot1.mp3"
    scene im816:
        pause 0.0333
        "im817"
        pause 0.0333
        "im818"
        pause 0.0333
        "im817"
        pause 0.0333
        "im819"
        pause 0.0333
        "im819a"
        pause 0.0666
        "im820"
        pause 0.0666
    scene im821 with dissolve
    pause
    scene im822 with Dissolve(2)
    scene black with Dissolve(1)

    scene im923 with Dissolve(1)
    ge "We're almost there, brother..."
    fz "Yeah, we're gonna save them!"
    yus "What are you doing down there, Wills?"
    wi "Quiet! Take cover right now!"
    yus "Cover is for rookies, we don't do that, what's wrong with you?"
    fz "I don't see anybody."
    wi "Two men behind that wall."
    stop music fadeout 3
    play sound "audio/elevatorspooky.ogg"
    scene im924 with dissolve
    wi "Someone's coming again...quick, Franz, go to one of those columns over there!"
    fz "Got it."
    play sound "audio/oldelevatordoor.mp3"
    scene im826 with dissolve
    scene im826a with dissolve
    scene im827 with dissolve
    pause 1
    scene im828 with Dissolve(2)
    play music "audio/whoisyourgod.mp3"
    scene im828 with vpunch
    scene im828 with vpunch
    yus "Dutch!!!"
    play sound "audio/lasersight1.mp3" volume 1.5
    scene im925 with Dissolve(1)
    pause 1
    play sound "audio/snipershot.mp3" volume 2
    scene im926 with Dissolve(0.1)
    scene im927 with vpunch
    scene im927 with vpunch
    scene im928 with Dissolve(1)
    fz "Holy shit! Who did it?!"
    ge "He looked dangerous, I had to do it."
    yus "Hey! He was mine!"
    wi "Shut up, Yusuf! Hey, kid, you're lethal with that weapon, that man you just killed was gonna give us a lot of trouble!"
    scene black with dissolve
    scene im929 with dissolve
    fz "They're going to start firing like crazy, don't you think?"
    ge "Or they are too frightened to do anything now that I killed their leader."
    fz "What should I do?"
    ge "Just wait for William or Yusuf to act first..."
    uk "Don't shoot! We give up!"
    fzt "What?"
    scene im930 with dissolve
    uk "We give up! Don't shoot!"
    yus "How many are you?"
    uk "Only two...we're coming out..."
    scene im931 with Dissolve(1)
    yus "We won't kill you, but you're gonna have to answer all my questions."
    uk "Anything you want, but don't shoot, please! It's just not worth it..."
    fzt "Good, nobody else needs to die unnecessarily."
    scene black with dissolve
    scene im932 with dissolve
    wi "Stay down!"
    yus "Speak, what's down there?"
    uk "Some cells for..."
    yus "For..."
    uk "Some girls."
    scene im933 with dissolve
    yus "Hey, don't start giving me vague, incomplete answers, that just pisses me off..."
    uk "Ok, ok, I'm sorry."
    yus "How many girls are there?"
    uk "One."
    yus "One?"
    wi "Must be the one I saw earlier, she looked beaten up."
    yus "What happened to the others?"
    uk "Yesterday some people came in and took them..."
    scene im933 with hpunch
    fzt "What?!"
    yus "Where?"
    uk "I don't know, they don't tell us those things, each of us has one task only and we're not allowed to ask questions..."
    yus "Smart...Who's \"they\"?"
    uk "One of them goes by Niko, but nobody here uses their real name..."
    yus "How long have you been here?"
    uk "Two years."
    yus "Once the girls are taken elsewhere, do they ever come back?"
    pause
    scene im935 with dissolve
    uk "No."
    scene im934 with dissolve
    yus "Now...what else is downstairs? I doubt your bosses hired a man like Dutch to escort a few girls."
    uk "Okay, listen, I don't know if it's true, never been there or seen anything, but I've heard there's a hidden lab..."
    yus "What kind of lab? Meth?"
    uk "I don't know for sure, but I doubt it...we have to wear these masks because of it...from time to time, there's a chemical gas leak that can be fatal..."
    fzt "It must be that fucking \"Incognito\" who's doing that...some sick experiments? Is that why he needed to keep at least one girl?"
    uk "If you want to find out, the elevator can get you there, but you need a code or something..."
    yus "Interesting. You've been very useful."
    scene im936 with dissolve
    uk "Oh, tha..."

    scene im937 with dissolve
    play sound "audio/gunshot1.mp3"
    scene im937:
        pause 0.0555
        "im938"
        pause 0.0555
        "im939"
        pause 0.0555
    pause 0.1665
    scene im940 with dissolve

    play sound "audio/gunshot3.mp3"
    scene im940:
        pause 0.0555
        "im941"
        pause 0.0555
        "im942"
        pause 0.0555
        "im943"
        pause 0.0555
        "im944"
        pause 0.0555
        "im945"
        pause 0.0555
        "im944"
        pause 0.0555
    pause
    scene im946 with Dissolve(1)
    fzt "Daaammn!"
    fzt "I should've known we were not taking any hostages..."
    fzt "They knew what was going on in here...I won't feel bad for them."
    stop music fadeout 3
    scene black with Dissolve(2)
    scene im947 with Dissolve(1)
    play music "audio/crime.ogg"
    yus "There are no buttons in here, this should be taking us to the cells automatically...where do you think the rest of the girls are?"
    wi "I'm sure they took them to The Nyacks' manor, those motherfuckers are always one step ahead!"
    wi "Today's the 21st, isn't it? We're going there! I won't let them win!"
    scene im948 with dissolve
    wi "Are you coming? You wanted to rescue those girls in the first place..."
    fzt "Why are you looking at me? I wasn't counting on the girls not being here..."
    fzt "And I promised George we'd go find Fabienne after this..."
    scene im949 with dissolve
    ge "We're in, William...this's not over until we save every single girl!"
    scene im950 with dissolve
    wi "That's what I'm talking about!"
    yus "Hell, yeah!"
    wi "Now let's go find that girl and get the hell out of here."
    scene im951 with dissolve
    ge "I'll take that grenade just in case..."
    scene black with dissolve
    scene im952 with dissolve
    yus "I counted 3 floors down, Wills."
    wi "Yeah, me too..."
    wi "George, stay in the elevator, don't let the doors close...you can cover us from here."
    ge "Roger that."
    scene im952a with dissolve
    scene im952b with dissolve
    ge "What?"
    fz "Nothing."
    stop music fadeout 3
    scene black with Dissolve(2)
    scene im953 with dissolve
    pause
    play sound "audio/doorcode.mp3"
    scene im954 with Dissolve(1)
    play sound "audio/pneumaticdoor.mp3"
    pause
    yus "Quiet now."
    play sound "audio/bigswitch.mp3"
    scene im955 with dissolve
    fzt "What the hell?! I don't see shit!"
    yus "Well played."
    wi "George, come closer, that weapon has a flashlight...but don't step out of the elevator, it's the only way out as far as we know."
    scene im956 with dissolve
    yus "Turn that shit off, they can see our shadows...just leave it to me."
    ge "William?"
    wi "Do it."
    play music "audio/tensionhorrorinsidious.ogg"
    scene im955 with Dissolve(1)
    pause
    scene im957 with dissolve
    pause
    scene im958 with dissolve
    fzt "I don't know about this..."
    scene im959 with dissolve
    pause
    scene im960 with dissolve
    wi "Can you see anything?"
    fz "I think he went right."
    ge "Left, he went left."
    scene im961 with dissolve
    play sound "audio/gunshot1.mp3"
    scene im962:
        pause 0.0699
        "im961"
        pause 0.0699
    pause 0.7
    play sound "audio/headcut.mp3" volume 1.5
    pause 2
    wi "What the...that sounded like a sword after the gunshot...weird..."
    wi "Yusuf?"
    scene im961 with hpunch
    wi "Lights!"
    scene im963 with dissolve
    wi "Yusuf?!"
    scene im964 with dissolve
    wi "Come on, Franz, move!"
    play sound "audio/monster2.mp3" volume 2
    scene im965 with dissolve
    pause
    fz "What the fuck is that sound, man?"
    play sound "audio/headfall.mp3" volume 2
    scene im966:
        pause 0.0666
        "im967"
        pause 0.0666
    scene im968 with vpunch
    fz "Huh?!"
    scene im969 with Dissolve(1)
    scene im969 with vpunch
    scene im969 with vpunch
    fz "HOLY SHIT!!! He chopped his head off in a second!!"
    ge "How was that even possible?!"
    wi "He must have an ax, a machete...he's strong..."
    scene im970 with dissolve
    scene im970 with hpunch
    scene im971 with Dissolve(1)
    pause 0.5
    scene im972 with Dissolve(1)
    pause
    wi "What are you waiting for?! He killed Yusuf!"
    play sound "audio/lasersight1.mp3" volume 1.5
    scene im973 with Dissolve(1)
    pause 1
    play sound "audio/snipershot.mp3" volume 2
    scene im974 with dissolve
    play music "audio/assaultrifle2.mp3"
    scene im979 with vpunch
    scene im979:
        pause 0.0666
        "im975"
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im978"
        pause 0.0666
        "im979"
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im979"
        pause 0.0666
        "im978"
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im978"
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im978"
        pause 0.0666
        "im979"
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im975"
        pause 0.0666
        "im976"
        pause 0.0666
        "im975"
        pause 0.0666
        "im976"
        pause 0.0666
        "im978"
        pause 0.0666
        "im979"
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im978"
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im979"
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im978"
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im975" with vpunch
        pause 0.0666
        "im976" with vpunch
        pause 0.0666
        "im979"
        pause 0.0666
        "im978"
        pause 0.0666
    pause 2
    stop music fadeout 1.2
    scene im980 with Dissolve(1)
    pause
    fz "Why is he still standing?"
    wi "No polymer can take that many bullets, not even Kevlar...what is that thing?"
    play music "audio/tensionthrillerdayx.ogg"
    scene im972 with vpunch
    ge "That's a fucking ghost, guys!"
    wi "Calm down...a ghost doesn't need to cover his head, he used his hands."
    fz "Remember what the guy said about a hidden lab? Can this thing be like something Incognito's been working on?"
    ge "Could he be Incognito?"
    wi "Too many assumptions...listen you two, we don't need to kill it, just go past it. I'm gonna try to fight it...look, he only has knives."
    fz "Knives? I can't see anything..."
    wi "He does, they're right there...George, forget about that elevator, you're going left; Franz, go right...Find that girl!"
    ge "What?! Are you crazy?! You can't fight it: it took dozens of bullets! That's suicide!"
    fz "George's right, Will. You can't defeat him."
    wi "But I can slow it down."
    ge "I'm gonna be the one who says it: one death's enough. We tried...I'm sorry, but it's not even worth it anymore...don't risk your life, Will."
    wi "What?! Yusuf gave his life to rescue that girl, we owe it to him! Right, Franz?"
    pause
    wi "Franz?"
    stop music fadeout 3

menu:
    "Yusuf?? Fuck him!":
        jump choice82a

    "We're saving that girl!":
        jump choice82b

label choice82a:

    $ choice82a = True

    fz "George's right, William, it's not worth it."
    play music "audio/tensiongilgobeach.ogg"
    scene im981 with dissolve
    wi "What?!"
    ge "Face it, there's nothing we can do against that thing..."
    wi "You cowards!"
    scene im982 with dissolve
    scene im983 with dissolve
    scene im984 with dissolve
    scene im985 with dissolve
    ge "Hurry! It's coming!"
    scene im986 with dissolve
    fz "Let's get the hell out, William!"
    scene im987 with dissolve
    pause 1
    scene im988 with dissolve
    pause 1
    scene im989 with dissolve
    wi "You're ugly as fuck!"
    ge "What are you waiting for?! Close it!"
    scene im990 with vpunch
    wi "Gotcha, motherfucker!"
    play sound "audio/grenadelauncher.mp3" volume 2

    scene im991:
        pause 0.0777
        "im992"
        pause 0.0777
        "im993"
        pause 0.1
    pause 0.2554
    play sound "audio/explosion2.mp3" volume 2
    scene im994 with dissolve
    scene im994 with vpunch
    scene im994 with vpunch
    scene im994 with vpunch
    scene im995 with Dissolve(1.5)
    pause
    fz "Fuuuck, fuck, fuck!!! Why did you do that?!"
    fzt "What a crazy motherfucker! Fuuuck!"
    fzt "God, my wrist is broken! Did I lose any fingers?"
    scene im996 with dissolve
    fz "George?"
    ge "I'm getting us out!"
    fzt "I doubt it still works..."
    fzt "I'm losing too much blood..."
    stop music fadeout 3
    scene black with Dissolve(3.0)
    pause
    play sound "audio/elevatorspooky.ogg"

    scene black with Dissolve(4.0)
    scene nobodywas with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause

    return

label choice82b:

    $ choice82b = True

    play music "audio/tension3.ogg"

    fzt "This is for you, brother!"
    fz "It's now or never, Will...you sure you can handle him?"
    wi "Don't underestimate me, kid, you have no idea what I've been through."
    scene im982 with dissolve
    ge "You two are crazy...I'm gonna throw this grenade before you go..."
    fz "Don't!"
    scene im983 with dissolve
    fz "William has a grenade, too, and hasn't used it, there must be a reason..."
    scene im984 with dissolve
    wi "Clever...it's too risky, look at those pipes...I can't stop thinking about the lethal gas that guy mentioned...could it also be flammable?"
    ge "It says \"water\"."
    wi "That's for rookies like you who believe it."
    scene im985 with dissolve
    ge "Guys..."
    wi "Yeah, yeah, I'm coming..."
    stop music fadeout 3
    scene im997 with dissolve

    play sound "audio/assaultrifle.mp3"
    scene im997:
        pause 0.0666
        "im998"
        pause 0.0666
        "im997"
        pause 0.0666
        "im998"
        pause 0.0666
        "im997"
        pause 0.0666
    pause 0.333
    wi "Move!"
    play music "audio/tensiongalvanizer.mp3"
    scene im999 with dissolve
    wi "Daaamn! You are one ugly motherfucker..."
    play sound "audio/knifeslash.ogg" volume 1.5
    scene im1000 with dissolve
    fzt "Go right, go right!"
    scene im1001 with dissolve
    fz "I can't see shit!"
    ge "There's a door here, brother, it needs a code I think...and Yusuf's body...whoa!"
    fz "Focus! Let's find that girl!"
    scene im1002 with dissolve
    fz "Hey, George, give me some light just a moment."
    ge "Coming."
    scene im1002 with dissolve
    scene im1003 with dissolve
    pause
    ge "Yup, same here...shoot it!"
    fz "Okay, I know where it is now...go! We don't have time!"
    ge "I'm on it!"
    scene im1002 with dissolve
    scene im1004 with dissolve
    scene im1005 with dissolve
    scene im1006 with dissolve
    scene im1007 with dissolve
    pause
    scene im1008 with dissolve
    pause
    scene im1009 with dissolve
    play sound "audio/lightbutton.mp3" volume 2
    fzt "What do these do?"
    scene im1010 with dissolve
    play sound "audio/lightbutton.mp3" volume 2
    fzt "Nothing..."
    scene im1011 with dissolve
    play sound "audio/lightbutton.mp3" volume 2
    pause
    scene im1013 with dissolve
    play sound "audio/lightbutton.mp3" volume 2
    pause
    scene im1014 with dissolve
    play sound "audio/lightbutton.mp3" volume 2
    pause 0.5
    scene im1014 with vpunch
    fz "Come on!"
    scene im1012 with dissolve
    fzt "Please be in there!"
    stop music fadeout 3

    call screen lockshot

    screen lockshot():
        add "im1012"
        modal True

        imagebutton auto "lockshot1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "lockshot1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("lockshot")

label lockshot:

    play sound "audio/assaultriflesingleshot.mp3" volume 2
    scene im1015:
        pause 0.0333
        "im1016"
        pause 0.0666
        "im1015"
        pause 0.0333
    scene im1015a with dissolve
    play sound "audio/electricity.mp3"
    scene im1017 with Dissolve(0.0666)
    scene im1015a with Dissolve(0.0333)
    scene im1015a with dissolve
    scene im1018 with Dissolve(1)
    fzt "Yes!"
    scene im1019 with dissolve
    pause
    scene im1020 with dissolve
    scene im1021 with dissolve

    call screen girlfound

    screen girlfound():
        add "im1021"
        modal True

        imagebutton auto "girlfound1_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "girlfound1")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("girlfound")

label girlfound:

    play music "audio/tension5.ogg"
    fzt "There!"
    scene im1022 with dissolve
    pause 0.5
    scene im1023 with dissolve
    fz "Hey! We need to get out of here! Now!"
    scene im1024 with dissolve
    fzt "Jesus!"
    fz "I'm here to save you, can you walk?"
    scene im1025 with dissolve
    uk "Save me? Really?"
    scene im1023 with dissolve
    scene im1023 with hpunch
    fzt "What the hell?!"
    fzt "\"Save you\"...very poor choice of words..."
    fz "Listen, I'm not one of the bad guys..."
    play sound "audio/monster2.mp3" volume 2
    scene im1023 with dissolve
    scene im1026
    fzt "What the..."
    scene im1026 with vpunch
    fzt "It can't be! He killed William?!"
    scene im1027 with dissolve
    uk "What the fuck is that thing?!"
    fz "Quick, get behind me!"
    scene im1026 with dissolve
    fzt "What do I do?! Bullets don't work..."
    fzt "Fight him? He's stronger than William..."
    scene im1028 with dissolve
    fz "Stay behind, girl!"
    scene im1029 with dissolve
    pause


init python:
    def corkGun1Transform(t, st, at):
        global cork_gun1_pos
        global cork_gun1_opos

        mousepos = renpy.get_mouse_pos()

        if mousepos[0] - cork_gun1_size[0] <= config.screen_width - cork_gun1_size[0] and mousepos[0] >= cork_gun1_size[0]:
            cork_gun1_pos = (mousepos[0] - cork_gun1_size[0], cork_gun1_opos[1])

        t.xpos = cork_gun1_pos[0]

        cork_gun1_pos = (cork_gun1_pos[0], cork_gun1_opos[1] + (mousepos[1] - config.screen_height) / 3)
        t.ypos = cork_gun1_pos[1]

        return 0

transform half_size:
    zoom 0.5

screen manualshotfinal:
    image "images/manualshotfinal.png"

    imagebutton auto "electricshock_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "electricshock")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("electricshock1")

    imagebutton auto "misselectricshock_%s":
        focus_mask True
        hovered SetVariable("screen_tooltip", "misselectricshock")
        unhovered SetVariable("screen_tooltip", "")
        action Jump ("misselectricshock1")

    add cork_gun1_transform
    modal True

label manualshotfinal:

    $cork_gun1_image = Image("images/cork-gun1.png")
    $cork_gun1_size = (1262 / 2, 1080 / 2)
    $cork_gun1_pos = (0, 0)
    $cork_gun1_opos = (config.screen_width / 2 - cork_gun1_size[0] / 2, config.screen_height - cork_gun1_size[1])
    $cork_gun1_transform = Transform(child = cork_gun1_image, pos = (cork_gun1_opos[0], cork_gun1_opos[1]), function = corkGun1Transform)

    call screen manualshotfinal

label electricshock1:

    play sound "audio/assaultrifle3.mp3" volume 2
    stop music fadeout 3

    scene im1030a:
        pause 0.0777
        "im1031"
        pause 0.0777
        "im1032"
        pause 0.0777
        "im1033"
        pause 0.0777
        "im1034"
        pause 0.0777
        "im1035"
        pause 0.0777
        "im1036"
        pause 0.1
    pause 0.666

    scene im1036:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.590 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.610 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1036"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
    pause 0.1328

    scene im1037:
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
        "im1038"
        pause 0.0666
        "im1037"
        pause 0.0666
    play sound "audio/electricity2.mp3" volume 1.5
    pause 4.329
    scene im1039 with Dissolve(1)
    scene im1039 with vpunch
    scene im1039 with vpunch
    fz "Fry, you fucking piece of shit!"
    stop sound
    scene im1040 with dissolve
    scene im1041 with dissolve
    play music "audio/tensionbreathoffreedom.ogg"
    uk "Is he dead?"
    fz "Smells like it..."
    uk "There's still some electricity on him, look!"
    scene im1042 with dissolve
    ge "Franz! Are you there?!"
    fz "I'm here, I found her! We're...okay..."
    ge "Oh, my God, William!"
    scene black with Dissolve(2)
    scene im1043 with Dissolve(2)
    pause
    fzt "William...he's been stabbed..."
    uk "Jesus! I'm so sorry! I'm so sorry!"
    fzt "She feels responsible? Well..."
    ge "He's still breathing!"
    fz "Quick! Carry him!"
    ge "You're gonna have to help me."
    fz "Let's get out of this place once and for all!"
    stop music fadeout 4
    scene black with Dissolve(4.0)
    scene oneperson with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause

    return

label misselectricshock1:

    play sound "audio/assaultrifle.mp3"

    scene im1046:
        pause 0.0777
        "im1045"
        pause 0.0777
        "im1046"
        pause 0.0777
        "im1048"
        pause 0.0777
        "im1049"
        pause 0.0777
    play sound "audio/bulletonmetal.mp3" volume 2
    stop music fadeout 3
    scene im1050 with dissolve
    scene im1051 with dissolve
    fzt "What?!"
    uk "Why did he do that?"
    fz "I have no idea..."
    play music "audio/chasedbyterror.mp3"
    scene im1052 with dissolve
    scene im1053 with dissolve
    scene im1053 with vpunch
    fzt "Fuck! That must be the toxic gas they told us about."
    fz "Is that the only way out?"
    scene im1054 with dissolve
    uk "Yeah...that's it for us, I've seen what that gas does! Fuck!"
    scene im1055 with dissolve
    pause
    scene im1056 with dissolve
    uk "Shoot me."
    scene im1056 with vpunch
    fz "What?!"
    uk "I don't wanna have a horrible death. I'm ready, do it."
    fzt "This girl's tough...nothing like Little T..."
    fz "Are you out of your mind?! I'm here to get you out alive, I'm not gonna kill you!"
    scene im1057 with dissolve
    scene im1057 with vpunch
    fzt "I don't have time to think! I should try to open that door now!"
    fzt "No, wait, even if I manage to open it, she doesn't have a mask!"
    play sound "audio/monster2.mp3" volume 0.3
    pause
    fzt "And that beast is on the other side...it really is over..."
    scene im1057 with vpunch
    fzt "Fuck! And I had managed to get this far unharmed!"
    stop music fadeout 4
    wi "{i}\"We don't need to kill it, just go past it.\"{/i}"
    wi "{i}\"I can slow it down.\"{/i}"
    play music "audio/walking.ogg"
    scene im1058 with Dissolve(1.5)
    fzt "You bastard, you knew it all along..."
    fzt "It's the only way."
    scene im1059 with Dissolve(1.5)
    pause
    scene im1060 with Dissolve(1.5)
    fz "Hold this for a second."
    scene im1061 with Dissolve(1.5)
    pause 1.5
    scene im1062 with Dissolve(1.5)
    pause
    scene im1063 with Dissolve(1.5)
    pause
    scene im1064 with dissolve
    scene im1065 with dissolve
    fz "Here, put this on."
    scene im1066 with dissolve
    uk "I don't want it, I'm ready to die!"
    scene im1067 with dissolve
    fz "I know you are, but I'm more stubborn than you!"
    scene im1068 with dissolve
    fz "Careful, don't let it fall."
    scene im1069 with dissolve
    uk "What are you doing?"
    fz "Getting you out!"
    scene im1070 with vpunch
    uk "Nooo!!!"
    fz "Too late!"
    fz "Hurry! Put it on! The gas is already here!"
    scene im1071 with dissolve
    fzt "Oh, fuck, I'm dead!"
    scene im1072 with vpunch
    pause
    fzt "I'm scared..."
    scene im1073 with dissolve
    fz "There's an elevator to your left...it has no buttons, just close it and it'll work!"
    fz "That mask has a radio, but it's not working here underground...press the button on the right ear once you're out, just in case..."
    fz "Or simply scream \"George\"...my friend will help you out!"
    scene im1074 with dissolve
    uk "Why?! Why are you doing this for me?!"
    fzt "For you? I don't know you, this is for my brother!"
    fz "I see it in your eyes: they couldn't break your spirit! That's why you're still here, isn't it?"
    stop music fadeout 5
    fz "They need fear and won't find it in you! You're a fighter, so keep fighting! This is not over!"
    uk "What's your name?"
    play music "audio/tensionflyinghigh.mp3"
    scene im1077 with dissolve
    fz "I am Franz Blanco...and you?"
    uk "Sigrid Bielke, B-I-E-L-K-E."
    si "Thank you, Franz Blanco!"
    fz "Get ready, Sigrid!"
    scene im1074 with dissolve
    scene im1075 with dissolve
    pause 1.5
    scene im1076 with dissolve
    si "I'm gonna live!"
    scene im1077 with dissolve
    fz "You're goddamn right! You're gonna live, Sigrid Bielke!"
    scene im1077 with vpunch
    scene im1077 with vpunch
    scene im1077 with vpunch
    fz "Aaaahh!!!"
    scene im1078 with Dissolve(1)
    pause
    scene im1079 with dissolve
    pause 1.5
    scene im1080 with vpunch
    fzt "There you are! I still can't believe this thing is real..."
    fzt "I must stop you!"
    fzt "Knife...where's the knife?!"
    scene im1080 with dissolve:
        xpos 0.5 ypos 0.7 xanchor 0.5 yanchor 0.6 zoom 1.9
    pause 1.5
    scene im1080
    fzt "Hiding it until the last moment, huh? Fuck it!"
    scene im1081 with dissolve
    fz "Go, Sigrid, go! Don't look back!"
    play sound "audio/slitthroat1.mp3" volume 1.1
    scene im1082 with vpunch
    scene im1082 with vpunch
    pause
    fzt "He's too strong..."
    fzt "I never stood a chance..."
    scene im1083 with Dissolve(2)
    si "George! George!"
    fzt "What are you looking at?"
    fzt "I'm right here!"
    scene im1083a
    fzt "Grab him, grab him, Franz! Don't let go..."
    fzt "Look, [p]..."
    fzt "I saved her!"
    scene im1083b
    fzt "Live!"
    fzt "Please..."
    play sound "audio/slitthroat2.mp3" volume 1.7
    scene im1083c with dissolve

    stop music fadeout 4
    scene black with Dissolve(4.0)
    scene franzhasbecome with Dissolve(2)
    pause
    scene black with Dissolve(2.0)
    scene truemartyr with Dissolve(2)
    pause
    scene black with Dissolve(4.0)

    scene sigridwas with Dissolve(2)
    pause
    scene black with Dissolve(4.0)
    pause

    return
