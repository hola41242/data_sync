#Important Decisions
default choice83a = False
default choice83b = False
default choice84a = False
default choice84b = False
default choice85a = False
default choice85b = False
default choice85c = False
default choice86a = False
default choice86b = False
default choice87a = False
default choice87b = False


# Start Episode 8
label ep8:

    $ renpy.movie_cutscene("videos/inevitable.ogv")
   
    scene im1270 with dissolve
    play music "audio/darkside.mp3"
    p "What's that odor, brother? Like rotten eggs..."
    fz "Rotten eggs must be...I don't have much time, what did you want to talk about?"
    p "Sorry, it's a little distracting..."
    scene im1271 with dissolve
    p "It's about Samantha's death, I wanted to ask you something...shit, my head hurts every time I start thinking about it."
    fz "Don't think about it."
    p "I can't help it, there's something I need to know...her murderer...was actually going after me, wasn't he?"
    scene im1272 with dissolve
    fz "You're asking me? How would I know?"
    p "I've heard some things and...I've been thinking a lot lately, connecting all the dots..."
    scene im1273 with dissolve

if choice74b:
    p "You know, I never told you or mom about this, but I almost died one day on my way to college: I saw this guy aiming at Billy, a friend of mine...and this dude said something about Billy's father, I couldn't hear clearly..."
    p "It turned out my friend's father was \"The Sheriff\", your friend William's nickname at St. Francis, nobody was hurt in the end fortunately...but I remember Sheriff being so afraid of us contacting the police back then..."
    p "Some time later, you showed up with him when you went to pick me up from the police station...I don't know, man..."
    jump franztalkliving

label franztalkliving:
    p "And yeah, it is true that you've been acting \"differently\" for the past year, year and a half? Come on, Franz, mom doesn't even know where you live! Are you protecting her from something? Is that why you don't visit us anymore?"
    p "You even broke up with Amelia, who's the most loyal girl someone could find! It all adds up, but I need to hear it from you...is it true? You messed up with the wrong people and that's why Samantha is dead?"
    scene im1272 with dissolve
    fz "Who told you that?"
    scene im1274 with vpunch
    p "It doesn't matter...it's true, isn't it? It's a simple yes or no!"
    pause
    fz "Yes."
    fz "It is true."
    fz "I made a mistake...but I promise you and mom are safe..."
    p "As safe as Samantha was? I don't think you realize what happened as a result of your fucking \"mistake\"..."
    scene im1275 with hpunch
    p "The best person I met is dead! You know I've been struggling with that guilt and you haven't said shit! You let me believe it was all on me! I know I was a coward who couldn't react fast enough, I take my share of the blame..."
    scene im1277 with hpunch
    p "But we weren't supposed to be in a situation like that in the first place! We did nothing! SHE did nothing to deserve that!"
    fz "Let's talk, brother...maybe you understand how it all..."
    scene im1276 with hpunch
    p "Understand?! Fuck you, Franz! YOU are the one who needs to understand that whatever it is that you're doing, it got the most beautiful human being killed!"
    scene im1277 with hpunch
    p "You have to live knowing that, you piece of shit! Fuck your own life, not others'!"
    scene im1277a with hpunch
    pause
    fz "Sorry, brother, can't let you punch me, I need to be at 100 percent health..."
    p "I hope you die, you fucking murderer!"
    scene im1278 with dissolve
    ge "[p], calm down, don't say those things...Do you want to know what we've been doing? You won't like what you'll hear...very powerful people are involved...I can tell you some things..."
    p "Do I look like I fucking care about what you're doing? Do you think there's something you can tell me that can justify what happened? Are you that stupid, George?"
    p "Oh, yeah, I want to hear your side of the story...after listening to you I'm gonna say: yeah, you were right, she had to die...Fuck you too, George!"
    scene im1279 with hpunch
    p "You played with our lives! They didn't belong to you! You two killed Samantha!"
    scene im1280 with dissolve
    p "And you! I don't know you, but you better stop hanging out with these bastards, they're gonna ruin your life sooner than later!"
    scene im1281 with dissolve
    pause 1
    scene im1282 with hpunch
    p "Fuck you all!"
    play sound "audio/woodbreak.mp3"
    scene im1283 with vpunch
    pause 2
    stop music fadeout 3
    scene black with Dissolve(3)

if choice75b:
    jump trainbouba

if choice75a:

    scene black with Dissolve(2)
    pause
    play music "audio/allright.mp3"
    scene br1 with Dissolve(2)
    sh "I knew it! Tell me all about it, you whore!"
    br "Shay! Don't call me that! I'm ashamed..."
    scene br2 with dissolve
    sh "No, you're not, you can't fool me...why would you be ashamed? You're hooking up with a man half your age! You should be proud!"
    scene br3 with dissolve
    sh "That boy IS hot! He's got this mysterious aura..."
    scene br3 with dissolve
    scene br3a with dissolve
    scene br3 with dissolve
    scene br3a with dissolve
    scene br3 with dissolve
    sh "Oooohh, hot!"
    sh "I would totally do him, too! Haha..."
    scene br5 with dissolve
    br "You have no idea how hot he can be..."
    sh "I can imagine...well, the way I see it, this's beneficial for both of you: you're helping him deal with his grief and he'll help you get over Juan once and for all..."
    scene br4 with dissolve
    br "Shay, don't say that..."
    scene br7 with dissolve
    sh "Oh, come on, Bree, isn't it what you want? Get a divorce, girl, Juan is an idiot who doesn't value you!"
    br "Let's not talk about Juan right now..."
    scene br4 with dissolve
    br "Do you think I should call [p] tonight?"
    sh "Haha, when was the last time you saw him?"
    br "A couple weeks ago..."
    sh "Let him miss you!"
    scene br6 with dissolve
    br "Haha, yeah, you're right! I do want him to miss me!"
    scene br8 with dissolve
    sh "Well, Bree, I'm running late for work...how do I look today? Do you think my boss's going to like my new dress?"
    br "Are you dating your boss?"
    sh "Not dating, no...hahaha..."
    br "My God, you're beyond hope...sorry, but...you can't be saved."
    sh "Haha, you're the one to talk! At least, I'm divorced!"
    br "You're so mean, Shay!"
    sh "Hahaha."
    stop music fadeout 3
    scene black with Dissolve(2)

    scene br12 with Dissolve(1)
    br "Look at you, Brenda!"

    play music "audio/barsong.mp3"
    scene br13:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    br "Haha, wooow! I've never felt so sexy before!"
    br "[p]'s given me a second wind! I'm dying to see his face when I show him this!"

    call screen brendamirror1

    screen brendamirror1():
        modal True

        viewport:

            add "br9"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("brendamirror2")

label brendamirror2:

    call screen brendamirror2

    screen brendamirror2():
        modal True

        viewport:

            add "br10"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("brendalookmirror")


label brendalookmirror:

    scene br10a
    brt "Oh, my God! It fits you like a glove, girl!"
    brt "My butt looks amazing! Hehehe..."
    brt "What a great idea it was to buy this!"
    scene br11 with dissolve
    brt "A little makeup wouldn't hurt..."
    stop music fadeout 3
    scene black with Dissolve(3)

    play music "audio/summer.ogg"
    scene im1620 with dissolve
    sh "Hi, [p], she's in her room!"
    p "Hi, Sharon, you're looking good as usual..."

    scene im1621:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    sh "Haha, as good as Brenda?"
    p "Whaaaat? I don't get why the comparison, but...I guess so..."
    sh "Haha, you sure you don't get it? Because I've heard some things..."
    p "Like what?"

    scene im1622 with dissolve
    sh "You know, like the fact that you're visiting her pretty often and doing her some...\"favors\"..."
    scene im1622 with vpunch
    pt "What?! Did Brenda tell her?!"
    p "Favors? What are you talking about?"
    scene im1623 with dissolve
    sh "I don't know, but I was thinking...maybe you can do me, too...I mean, do me a favor..."
    p "Yeeeeaaah, I think I can do that...I feel like we're not in the same page though..."
    sh "Oh, I think we are..."
    pt "She wants me to...for real?!"
    p "Nope, I think we're not...I'm gonna go see Candy now, it's getting late..."
    scene im1624 with dissolve
    sh "Go and do that, [p]...go and do that, haha..."
    p "Okaaayyy, byyyeee..."
    stop music fadeout 2
    scene black with Dissolve(2)

    play music "audio/cafebrensha.mp3"
    scene br37 with Dissolve(1)
    sh "I called out your lover the other day, hahaha, it was so funny!"
    br "What?! Oh my God, what did you do this time, Shay?"
    sh "Haha, nothing really...I just asked him if he would do me the same favor he's doing you...if you know what I mean, haha..."
    scene br41 with hpunch
    br "Sharon! Are you out of your mind?!"
    sh "Haha, it was a joke, calm down, I'd never do anything with the boy, he's all yours! Plus the fact that my Candy still likes him, I think...but why did you get so upset all of a sudden?"
    scene br42 with dissolve
    br "Because!"
    sh "Wait a minute..."
    sh "Oh{w=1.0} my{w=1.0} God!"
    scene br35 with dissolve
    sh "Don't tell me you're having feelings for [p]..."
    br "I don't know..."    
    scene br38 with dissolve
    sh "My God! You totally are! I thought this was just casual sex! You letting your sexual frustration go...you can't possibly be contemplating a serious relationship!"
    scene br42 with hpunch
    br "Relax, nobody has said anything like that..."
    scene br43 with dissolve
    br "Or...did...did he say anything to you?"
    sh "Haha, Brenda, please! You're playing with me, aren't you?"
    scene br39 with dissolve
    sh "I wouldn't even know what to say to you if you were serious..."
    br "Enjoy the sex?"
    scene br37 with dissolve
    sh "Haha, yeah, that sounds pretty much like me! Haha..."
    scene br47 with dissolve
    br "You don't have to worry about that, I'm having real fun! I may even show him that lingerie we bought, haha...and who knows? Maybe I have another surprise!"
    scene br40 with dissolve
    sh "Your divorce papers! Hahaha..."
    scene br44 with dissolve
    br "Perhaps..."
    sh "What?!"
    br "Yeah, I feel that [p] can help me find the strength I need to actually get divorced..."
    br "Perhaps it is like you said: we're helping each other at this specific time of our lives...I don't feel I'm using him nor the other way around..."
    br "And to tell the truth: I do like him."
    sh "Bree..."
    scene br45 with dissolve
    sh "Listen, Bree: you deserve everything! You're sweet...and kind...and funny, a beautiful woman with a beautiful heart!"
    scene br46 with dissolve
    br "Awww, Shay, you're going to make me cry..."
    sh "Please, don't, haha...you do wathever makes you feel happy, girl, you know I'm with you a hundred percent!"
    br "Shay..."
    stop music fadeout 3

    scene black with Dissolve(3)
    jump trainbouba

label trainbouba:

    pause
    play music "audio/openhighway.ogg" volume 0.7
    scene im1283e with dissolve
    uk "Yo, need a goalkeeper?"
    scene im1283f with dissolve
    p "Yeah, but I need a good one...please, call Ethan, Bouba."
    bou "Fuck you."

if choice79a:
    scene im1283g with dissolve
    bou "When will you be back, brother?"
    p "Two more weeks."    
    bou "Dude, don't do that shit again, we need you, seriously."
    bou "The match against Vulcano is in three weeks, you have to be there!"
    p "Don't worry, man, I'll be back the week before...if Robinson puts me in..."
    scene im1283h with dissolve
    bou "Bro, we can't win the tournament without you, Robinson knows it...just don't break nobody no more!"
    p "Ha, I'll try..."
    jump continuetrain

label continuetrain:

    scene im1283i with dissolve
    p "Save this, Bouba!"
    scene black with dissolve    
    scene im1283d with dissolve
    pt "Train."
    pt "If it hurts, train harder!"    
    scene im1283a with dissolve
    pt "Outwork the doubt!"
    scene im1283j with dissolve
    pt "Outwork the excuses!"
    scene im1283k with dissolve
    pt "Outwork the pain!"
    pt "Just keep moving..."
    scene im1283b with dissolve
    pt "For her!"
    pt "This is all you have now."
    stop music fadeout 2.5
    jump giureadytokill

label giureadytokill:

    scene black with Dissolve(3)
    scene im1362 with Dissolve(1.5)
    play music "audio/tensioncellowrath.mp3"
    giut "Nah, I'm not going to need this..."
    scene im1363 with Dissolve(1.5)
    pause
    scene im1364 with Dissolve(1.5)
    giut "They have to look at the eyes of a loving father before they die."
    scene im1365 with Dissolve(1.5)
    pause
    scene im1366 with Dissolve(1.5)
    pause
    scene black with Dissolve(3)

    scene im1625 with Dissolve(1.5)
    pause
    scene im1626 with Dissolve(1.5)
    giut "Niko and Jaxrael are here...that means Sarka and Valtr are already in there..."
    giut "I don't see any other limo...should I go for them or wait for the Big Fish?"
    scene im1627 with Dissolve(1.5)
    giut "I think this is my chance to achieve something, it'll only get harder if I keep waiting...soon this place will be packed with security guards..."
    giut "No, Giuseppe, wait for Isaac..."
    pause
    giut "Fuck! I wanted to torture him, but it's not gonna be possible...William, don't forget your promise! You have to kill that son of a bitch!"
    scene black with dissolve
    scene im1627a with dissolve
    nk "Who's there?!"
    scene im1627b with dissolve
    giu "Surprise, motherfuckers!"
    scene im1627c with dissolve
    play sound "audio/assaultrifle2.mp3"
    scene im1627c:
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
        "im1627c"
        pause 0.0666
        "im1627d" with vpunch
        pause 0.0666
    pause 2.5
    scene im1627c with dissolve
    scene im1627e with dissolve
    giu "Burn in hell!"
    stop sound
    stop music fadeout 3
    scene black with Dissolve(3)
    pause

    play music "audio/lonewolf.ogg"
    scene im1576 with Dissolve(2.5)
    uk "Who are we watching, Ruby?"
    ru "Ethan Phillips, Kalvin Phillips, Jalen Thomas and Landon Allen, sir."
    uk "And who's the wonderkid?"
    scene im1577 with dissolve
    ru "That'd be Ethan Phillips, sir! City's goalkeeper, 16, Kalvin Phillips Sr. represents him...he was supposed to become a pro this season, but his father asked for more money to sign."
    uk "Ha, parents these days...they have no idea how to manage their kids' careers..."
    scene im1578 with dissolve
    ru "That's why we're here, Mr. Dorn!"
    md "You're right, Ruby, you're right."
    scene black with dissolve

if choice79a:
    scene im1284 with dissolve
    el "I don't see him playing..."
    scene im1285 with dissolve
    uk "The number ten is not on the field, mom...must be benched."
    el "He's on the bench? I thought he was good..."
    uk "Generally, the number ten is the best player on the team..."
    el "I didn't know that, you're gonna have to explain everything to me!"
    uk "K, mom."
    scene black with dissolve
    jump endellestadium

if choice79b:
    scene im1600 with dissolve
    an "How come [p]'s not playing?! You suck, coach!"
    bl "Annie, don't scream like that and sit down!"
    scene im1601 with dissolve
    an "Mom! It's a stadium! We're supposed to be screaming all the time!"
    scene black with dissolve
    jump endellestadium

label endellestadium:

    scene im1286 with dissolve
    fu "With Blanco being available, why is he on the bench again? I'm very surprised...your thoughts about that, Rob..."
    rd "He couldn't train normally a couple days this week because of his wrist...it's been giving him problems lately, you know? But I thought he was gonna be a starter today."
    fu "My God...didn't he give the assist to win last week, Rob?"
    rd "Robinson sent him in to play a few final minutes and [p] changed the course of that match...made an immediate impact, Fumi."
    fu "Seriously, Rob, why isn't he starting this important game? Make it make sense!"
    scene im1287 with dissolve
    rd "If he were injured, he wouldn't be on the bench tonight...seems like a tactical decision, but I agree with you, he should be playing..."
    fu "We've won three times so far this year and two of those victories were thanks to [p]!"
    scene im1288 with dissolve
    fu "Let's take a quick look at the top six, Rob: luckily, we keep the third position at least for one more week...I wanted to ask you: what do you think of total wins being the first tiebreaker and not goal difference?"
    rd "I don't like it, from what I've heard it cost us the title last season, right? Look at Phoenix United, for example, they haven't lost a single game, they have scored 24 goals in six games and yet they are 6th, not 5th."
    fu "Goal United has more wins...Goal Fury! Sorry...I think we're the only league with that kind of tiebreaker..."
    rd "Yeah, in Europe you look at the goal difference first...anyway, it means we have to win tonight! Too many draws already..."
    fu "And our rivals, Vulcano, silently climbed to the second place after last week's win. They've always been a very difficult team for us: we drew both matches last season and our team couldn't score a single goal against them!"
    stop music fadeout 3
    rd "That table looks tight, Fumi...it's true that the league's just started, but I can foresee an exciting title race this year..."
    pause
    
    scene black with Dissolve(1)
    play music "audio/engine.ogg"
    scene im1289 with dissolve
    fu "Vulcano has an amazing player in Jalen Thomas, a box-to-box midfielder who can deffend and attack at the same level, he actually does pretty much everything for his team..."
    scene im1290 with dissolve
    fu "And they also have the \"Pichichi\", the \"Capocannoniere\" of the tournament: Landon Allen! A classic number 9: tall, strong, great heading skills...ten goals in six games!"
    fu "Huge difference with our forwards: only Arthur has managed to score two goals this season...and Carl Johnson hasn't scored a single goal yet!"
    rd "To be honest, Fumi, I'm nervous and excited at the same time: Vulcano represents a big challenge for Robinson's team..."
    scene black with dissolve

    scene im1291 with Dissolve(1)
    
    scene im1291:
        pause 0.0666
        "im1291"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1291"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1291"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1291"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1291"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1291"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1291"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1291"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1291"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1291"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1291"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1291"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1291"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1291"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1291"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1291"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1291"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1291"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1291"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1291"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1291"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1291"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1291"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1291"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1291"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1291"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1291"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1291"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1291"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1291"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1291"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1291"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1291"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1291"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1291"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1291"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1291"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1291"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1291"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1291"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1291"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1291"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1291"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1291"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1291"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1291"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1291"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1291"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1291"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1292 with dissolve

    scene im1292:
        pause 0.0666
        "im1292"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1292"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1292"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1292"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1292"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1292"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1292"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1292"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1292"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1292"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1292"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1292"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1292"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1292"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1292"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1292"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1292"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1292"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1292"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1292"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1292"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1292"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1292"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1292"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1292"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1292"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1292"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1292"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1292"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1292"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1292"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1292"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1292"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1292"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1292"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1292"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1292"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1292"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1292"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1292"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1292"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1292"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1292"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1292"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1292"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1292"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1292"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1292"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1292"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1293 with dissolve

    scene im1293:
        pause 0.0666
        "im1293"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1293"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1293"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1293"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1293"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1293"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1293"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1293"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1293"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1293"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1293"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1293"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1293"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1293"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1293"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1293"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1293"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1293"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1293"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1293"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1293"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1293"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1293"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1293"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1293"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1293"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1293"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1293"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1293"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1293"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1293"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1293"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1293"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1293"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1293"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1293"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1293"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1293"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1293"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1293"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1293"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1293"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1293"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1293"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1293"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1293"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1293"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1293"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1293"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    fu "What a player Thomas is!"
    
    scene im1294 with dissolve
    rd "Nakamura is also on fire tonight, he's too fast for Adams! Tomassini is not helping at all on the left and Smith has to cover the space, leaving a gap in the middle of the defense...Vulcano has total control of the game right now..."
    fu "Tomassini as a starter, Rob...nothing to add..."
    play sound "audio/whistle2.mp3" volume 1.5
    scene im1295 with hpunch
    fu "Just our luck tonight! Penalty for Vulcano, Rob...and Allen deserves an Oscar, let me tell you..."
    rd "Yeeeah, but it was a clear foul...Phillips made an amateur mistake tackling him like that inside the box."
    fu "And is it a red card, too?"
    rd "No, it'd be \"Double Jeopardy\" in case he sees the red card...he did attempt to play the ball, but Allen was faster, that's what I saw...penalty kick and a yellow card in my book."
    scene im1296 with Dissolve(1)
    rd "What do you think, Fumino? Today is the day?"
    scene im1297 with Dissolve(1)
    fu "I hope not, I think it'll be 110 clean sheets after this match!"
    fu "I do have a bad feeling, though..."
    scene im1298 with Dissolve(1.3)
    scene im1299 with hpunch
    fu "Beautiful technique, what class...the way he opened up his foot..."
    rd "Not only his foot, his hip and knee as well, very good player..."
    scene im1300 with Dissolve(1)
    fu "Mwahaha, Ethan has it under control...Thomas is good, but Ethan is a monster!"
    scene im1301 with dissolve
    rd "I'm not so sure, Fumi, it's a very complicated ball for such a tall keeper..."
    scene im1302 with dissolve
    scene im1303 with dissolve
    pause
    fu "No waaayy! Ethan changed his facial expression!"
    rd "How did you get to see it from here?"
    fu "I'm telling you!"
    scene im1304 with dissolve
    fu "Ethan barely touches it with the tip of his fingers!"
    play sound "audio/ballpost.mp3"
    scene im1305 with hpunch
    fu "It hits the post!"
    fu "I'm scared! Aaahhhhh!!!"
    scene im1305a with dissolve
    fu "Where's the ball?! Did it cross the line?! Tell me it didn't, Rob!"
    scene im1306 with dissolve
    rd "No, it did not..."
    rd "Not yet..."
    stop music fadeout 3
    scene im1307 with Dissolve(1)
    pause 0.5
    scene im1308 with Dissolve(1)
    play sound "audio/ballkick1.mp3"
    scene im1309 with hpunch
    scene im1309 with hpunch
    fu "NOOOO!!!"
    play sound "audio/ballkick1.mp3"
    scene im1310 with hpunch
    pause
    scene im1311 with hpunch
    coa "What the hell are you doing, Phillips?!"
    scene black with dissolve
    scene im1312 with dissolve
    pause
    rd "Fumino is in shock...we all are...complete silence in the stadium..."
    rd "Yes, Citizens, believe or not, we have conceded a goal after...9823 minutes! An insane number! You've set an unbeatable record for future generations, we're so proud of you, Ethan!"
    rd "Fumi?"
    rd "Still not there..."
    scene im1313 with dissolve
    rd "Our only concern now should be not losing this match, we have not seen the ball since the game started. Players like Virgilio or Lalas should ask for it, they need to appear or this is going to be a long night..."
    rd "First, I'd like to see what the team's reaction is...conceding a goal after such a long time might affect them psychologically, we are proven vulnerable now and Vulcano is a team that smells blood and goes for the jugular..."
    play music "audio/firstmatchwelcome.mp3"
    scene black with dissolve
    scene im1314 with Dissolve(1)
    rd "Arthur and Gilmar gotta wake up, too! Nothing from them in fifteen minutes!"
    rd "Come on, guys!"

    scene im1315 with dissolve

    scene im1315:
        pause 0.0666
        "im1315"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1315"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1315"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1315"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1315"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1315"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1315"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1315"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1315"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1315"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1315"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1315"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1315"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1315"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1315"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1315"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1315"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1315"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1315"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1315"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1315"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1315"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1315"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1315"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1315"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1315"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1315"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1315"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1315"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1315"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1315"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1315"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1315"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1315"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1315"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1315"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1315"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1315"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1315"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1315"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1315"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1315"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1315"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1315"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1315"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1315"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1315"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1315"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1315"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1315a with dissolve

    scene im1315a:
        pause 0.0666
        "im1315a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1315a"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1315a"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1315a"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1315a"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1315a"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1315a"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1315a"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1315a"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1315a"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1315a"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1315a"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1315a"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1315a"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1315a"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1315a"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1315a"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1315a"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1315a"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1315a"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1315a"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1315a"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1315a"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1315a"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1315a"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1315a"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1315a"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1315a"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1315a"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1315a"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1315a"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1315a"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1315a"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1315a"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1315a"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1315a"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1315a"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1315a"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1315a"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1315a"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1315a"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1315a"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1315a"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1315a"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1315a"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1315a"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1315a"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1315a"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1315a"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1316 with dissolve

    scene im1316:
        pause 0.0666
        "im1316"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1316"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1316"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1316"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1316"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1316"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1316"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1316"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1316"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1316"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1316"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1316"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1316"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1316"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1316"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1316"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1316"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1316"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1316"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1316"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1316"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1316"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1316"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1316"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1316"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1316"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1316"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1316"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1316"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1316"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1316"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1316"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1316"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1316"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1316"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1316"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1316"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1316"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1316"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1316"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1316"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1316"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1316"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1316"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1316"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1316"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1316"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1316"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1316"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1317 with dissolve
    fu "Nakamura seems unstopable tonight, Rob."
    rd "He's having fun with Tomassini and Adams..."
    scene im1318a with dissolve
    fu "Could it be the formation too, Rob? It's the first time we play a 4-4-2 this season..."
    scene im1319a with dissolve
    rd "I really don't like blaming the coaches, it's the players: Tomassini is not helping Adams at all, that's why that wing is all Nakamura's."
    fu "Gilmar is a better winger than a second forward, he would be more helpful in defense as well..."
    scene im1320a with dissolve
    rd "Johnson...same as always: he's the kind of guy who just fits into the background, you know what I mean?"
    fu "I know, nothing about him really stands out..."
    scene im1321a with dissolve
    rd "And I'll tell you one more thing: Arthur! I know he's a very technical player, but this is not a game for him...this is a match to run, fight, roll up your sleeves...and that's simply not his style."
    fu "That's why Virgilio is close to him, to do the pressing for him."
    rd "That's another thing, Virgilio has to be in the center! Not doing all the wing work, he's being wasted there!"
    fu "Too many things to correct and yet you don't blame the coach, Robbie? We all know Robinson loooves the old school Italian football: defense, defense and defense! But this is not even the real Catenaccio style with 3 center backs..."
    fu "The initial plan probably was to secure a draw versus Vulcano, but we're losing now, coach! Wake up!"
    scene im1322 with dissolve
    rd "Where's Nakamura?"
    scene im1323 with dissolve
    fu "Back to the game, Rob!"
    scene im1324 with dissolve
    pause 0.5
    scene im1325 with dissolve
    pause 0.5
    scene im1326 with dissolve
    fu "That's a foul, ref!"
    rd "Ngh, it's not, that happens all the time in the area..."
    scene im1327 with dissolve  
    fu "Oh my God, he's completely alone!"
    rd "What a smart play...Allen does a really good silent job all the time..."
    scene im1328 with hpunch 
    fu "Noooo!!!"
    scene im1329 with dissolve
    fu "Save it, Ethan! Show them who the real MVP is!"
    scene im1330 with hpunch
    fu "Yeeees! Oh my God!"
    rd "Ethan's not from this world, wow!"
    scene im1331 with dissolve
    fu "Luckily, Tomassini gets there first to send it out..."
    scene im1332 with Dissolve(0.03)
    scene im1333 with Dissolve(0.03)
    scene im1333 with hpunch
    play sound "audio/what.mp3"
    fu "What?!"
    fu "Rob?"
    scene im1334 with dissolve
    rd "A disaster, Fumi...Riccardo is so nervous...he's not a bad player, but this match is beyond him...Robinson needs to look at the bench immediately..."
    fu "I only have one question: is Tomassini better than [p]?"
    rd "Errr...I hope Riccardo's family isn't watching our stream."
    fu "Thank you."
    rd "Robinson is calling someone..."
    stop music fadeout 3
    scene black with dissolve
    scene im1335 with dissolve
    fu "Finally some changes! Carl and [p] are warming up, Citizens! Excuse my French, but what the flipping \"F\" was Robinson thinking?! We gave away 35 minutes!"
    rd "We have to attack, Fumi, it's the same losing 0-2 as 0-5, a loss is a loss and Robinson knows it...we were talking about it earlier: it's better to win two games 1-0 than one game 6-0, goal difference does not matter..."
    fu "If we end up with the same points, of course...what worries me is that we're not competing at all...any team can lose a game, but not like this!"
    
    scene black with dissolve
    play music "audio/firstmatchplaying.mp3"
    scene im1336 with Dissolve(1)
    rd "Apparently, Robinson will make the substitutions now, he won't wait for the halftime."
    fu "He needs to correct his tactical errors before it's too late, Rob!"

if choice79b:
    an "Look, mom! [p]'s about to get in! Woohoooo!!!"
    scene im1603 with dissolve
    p "Come on, Riccardo! Leave it to me."
    scene im1602 with dissolve
    an "That's my buddy, everybody! Destroy them, [p]!"
    rd "He's got quite a loud fan down there, Fumi, you got some competition..."
    fu "Shush."

    scene im1603 with Dissolve(0.3)
    play sound "audio/cardentrance.mp3" volume 2
    scene im1604 with Dissolve(0.00004)
    scene im1605 with Dissolve(0.00004)
    scene im1606 with Dissolve(0.00004)
    scene im1607 with Dissolve(0.00004)
    scene im1608 with Dissolve(0.00004)
    scene im1609 with Dissolve(0.00004)
    scene im1610 with Dissolve(0.00004)
    scene im1611 with Dissolve(0.00004)
    scene im1612 with Dissolve(0.00004)
    scene im1613 with Dissolve(0.00004)
    scene im1614 with Dissolve(0.00004)
    scene im1615 with Dissolve(0.00004)
    scene im1616 with Dissolve(0.00004)

    scene im1617 with hpunch
    pause
    fu "[p] \"The Architect\" Blanco..."
    rd "The Architect?"
    fu "Haha, I don't know, I just came up with it...The Professor? The Maestro? The Magician? I'll ask him later, let me introduce him!"
    rd "Ok, ok..."
    fu "[p] \"The Architect\" Blanco, 20 years old, central attacking midfielder..."
    fu "A classic creative playmaker converted to right winger this season, his versatility and dribbling allow him to play on both wings, but I think his contribution would be even higher playing behind the central forward..."
    fu "He has fantastic vertical passing, we need that in this match: someone who can find open spaces with his passes and unlock Vulcano's defense!"
    rd "And Fumi, besides creating opportunities for others, do not forget: he can score!"
    fu "That's right! Why was he benched?!"
    jump annback


if choice79a:

    scene im1337 with dissolve
    p "Come on, Riccardo! Leave it to me."
    scene im1354 with dissolve
    el "Let's go, [p]! You're the best!"
    jump ellewatching

label ellewatching:

    scene im1337 with dissolve
    rd "Here comes your favorite player, Fumi..."

    scene im1337 with Dissolve(0.3)
    play sound "audio/cardentrance.mp3" volume 2
    scene im1351 with Dissolve(0.00004)
    scene im1350 with Dissolve(0.00004)
    scene im1349 with Dissolve(0.00004)
    scene im1348 with Dissolve(0.00004)
    scene im1347 with Dissolve(0.00004)
    scene im1346 with Dissolve(0.00004)
    scene im1345 with Dissolve(0.00004)
    scene im1344 with Dissolve(0.00004)
    scene im1343 with Dissolve(0.00004)
    scene im1342 with Dissolve(0.00004)
    scene im1341 with Dissolve(0.00004)
    scene im1340 with Dissolve(0.00004)
    scene im1339 with Dissolve(0.00004)

    scene im1338 with hpunch
    pause
    fu "[p] \"The Architect\" Blanco..."
    rd "The Architect?"
    fu "Haha, I don't know, I just came up with it...The Professor? The Maestro? The Magician? I'll ask him later, let me introduce him!"
    rd "Ok, ok..."
    fu "[p] \"The Architect\" Blanco, 20 years old, central attacking midfielder..."
    fu "A classic creative playmaker converted to right winger this season, his versatility and dribbling allow him to play on both wings, but I think his contribution would be even higher playing behind the central forward..."
    fu "He has fantastic vertical passing, we need that in this match: someone who can find open spaces with his passes and unlock Vulcano's defense!"
    rd "And Fumi, besides creating opportunities for others, do not forget: he can score!"
    fu "That's right! Why was he benched?!"

label annback:
    scene im1352 with dissolve
    rd "They're coming on for Tomassini and...Johnson?! I wasn't expecting that!"
    fu "Me neither, but a pleasant surprise, finally! We'll be playing offensive football, that's what we all wanted to see, coach!"
    scene im1353 with dissolve
    rd "[p] giving some instructions to Virgilio, I assume he'll be playing in the center now...are they keeping the 4-4-2? Let's see it, this's gonna get interesting..."
    scene black with dissolve

    scene im1355 with dissolve

    scene im1355:
        pause 0.0666
        "im1355"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1355"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1355"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1355"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1355"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1355"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1355"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1355"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1355"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1355"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1355"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1355"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1355"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1355"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1355"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1355"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1355"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1355"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1355"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1355"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1355"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1355"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1355"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1355"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1355"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1355"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1355"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1355"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1355"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1355"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1355"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1355"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1355"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1355"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1355"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1355"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1355"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1355"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1355"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1355"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1355"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1355"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1355"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1355"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1355"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1355"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1355"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1355"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1355"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666
    pause 3

    scene im1356 with dissolve

    scene im1356:
        pause 0.0666
        "im1356"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1356"
        xpos 0.5001 ypos 0.601 xanchor 0.5 yanchor 0.601 zoom 1.002
        pause 0.0666
        "im1356"
        xpos 0.5002 ypos 0.602 xanchor 0.5 yanchor 0.602 zoom 1.003
        pause 0.0666
        "im1356"
        xpos 0.5003 ypos 0.603 xanchor 0.5 yanchor 0.603 zoom 1.004
        pause 0.0666
        "im1356"
        xpos 0.5004 ypos 0.604 xanchor 0.5 yanchor 0.604 zoom 1.005
        pause 0.0666
        "im1356"
        xpos 0.5005 ypos 0.605 xanchor 0.5 yanchor 0.605 zoom 1.006
        pause 0.0666
        "im1356"
        xpos 0.5006 ypos 0.606 xanchor 0.5 yanchor 0.606 zoom 1.007
        pause 0.0666
        "im1356"
        xpos 0.5007 ypos 0.607 xanchor 0.5 yanchor 0.607 zoom 1.008
        pause 0.0666
        "im1356"
        xpos 0.5008 ypos 0.608 xanchor 0.5 yanchor 0.608 zoom 1.009
        pause 0.0666
        "im1356"
        xpos 0.5009 ypos 0.609 xanchor 0.5 yanchor 0.609 zoom 1.01
        pause 0.0666
        "im1356"
        xpos 0.5010 ypos 0.610 xanchor 0.5 yanchor 0.610 zoom 1.011
        pause 0.0666
        "im1356"
        xpos 0.5011 ypos 0.611 xanchor 0.5 yanchor 0.611 zoom 1.012
        pause 0.0666
        "im1356"
        xpos 0.5012 ypos 0.612 xanchor 0.5 yanchor 0.612 zoom 1.013
        pause 0.0666
        "im1356"
        xpos 0.5013 ypos 0.613 xanchor 0.5 yanchor 0.613 zoom 1.014
        pause 0.0666
        "im1356"
        xpos 0.5014 ypos 0.614 xanchor 0.5 yanchor 0.614 zoom 1.015
        pause 0.0666
        "im1356"
        xpos 0.5015 ypos 0.615 xanchor 0.5 yanchor 0.615 zoom 1.016
        pause 0.0666
        "im1356"
        xpos 0.5016 ypos 0.616 xanchor 0.5 yanchor 0.616 zoom 1.017
        pause 0.0666
        "im1356"
        xpos 0.5017 ypos 0.617 xanchor 0.5 yanchor 0.617 zoom 1.018
        pause 0.0666
        "im1356"
        xpos 0.5018 ypos 0.618 xanchor 0.5 yanchor 0.618 zoom 1.019
        pause 0.0666
        "im1356"
        xpos 0.5019 ypos 0.619 xanchor 0.5 yanchor 0.619 zoom 1.020
        pause 0.0666
        "im1356"
        xpos 0.5020 ypos 0.620 xanchor 0.5 yanchor 0.620 zoom 1.021
        pause 0.0666
        "im1356"
        xpos 0.5021 ypos 0.621 xanchor 0.5 yanchor 0.621 zoom 1.022
        pause 0.0666
        "im1356"
        xpos 0.5022 ypos 0.622 xanchor 0.5 yanchor 0.622 zoom 1.023
        pause 0.0666
        "im1356"
        xpos 0.5023 ypos 0.623 xanchor 0.5 yanchor 0.623 zoom 1.024
        pause 0.0666
        "im1356"
        xpos 0.5024 ypos 0.624 xanchor 0.5 yanchor 0.624 zoom 1.025
        pause 0.0666
        "im1356"
        xpos 0.5025 ypos 0.625 xanchor 0.5 yanchor 0.625 zoom 1.026
        pause 0.0666
        "im1356"
        xpos 0.5026 ypos 0.626 xanchor 0.5 yanchor 0.626 zoom 1.027
        pause 0.0666
        "im1356"
        xpos 0.5027 ypos 0.627 xanchor 0.5 yanchor 0.627 zoom 1.028
        pause 0.0666
        "im1356"
        xpos 0.5028 ypos 0.628 xanchor 0.5 yanchor 0.628 zoom 1.029
        pause 0.0666
        "im1356"
        xpos 0.5029 ypos 0.629 xanchor 0.5 yanchor 0.629 zoom 1.03
        pause 0.0666
        "im1356"
        xpos 0.5030 ypos 0.630 xanchor 0.5 yanchor 0.630 zoom 1.031
        pause 0.0666
        "im1356"
        xpos 0.5031 ypos 0.631 xanchor 0.5 yanchor 0.631 zoom 1.032
        pause 0.0666
        "im1356"
        xpos 0.5032 ypos 0.632 xanchor 0.5 yanchor 0.632 zoom 1.033
        pause 0.0666
        "im1356"
        xpos 0.5033 ypos 0.633 xanchor 0.5 yanchor 0.633 zoom 1.034
        pause 0.0666
        "im1356"
        xpos 0.5034 ypos 0.634 xanchor 0.5 yanchor 0.634 zoom 1.035
        pause 0.0666
        "im1356"
        xpos 0.5035 ypos 0.635 xanchor 0.5 yanchor 0.635 zoom 1.036
        pause 0.0666
        "im1356"
        xpos 0.5036 ypos 0.636 xanchor 0.5 yanchor 0.636 zoom 1.037
        pause 0.0666
        "im1356"
        xpos 0.5037 ypos 0.637 xanchor 0.5 yanchor 0.637 zoom 1.038
        pause 0.0666
        "im1356"
        xpos 0.5038 ypos 0.638 xanchor 0.5 yanchor 0.638 zoom 1.039
        pause 0.0666
        "im1356"
        xpos 0.5039 ypos 0.639 xanchor 0.5 yanchor 0.639 zoom 1.040
        pause 0.0666
        "im1356"
        xpos 0.5040 ypos 0.640 xanchor 0.5 yanchor 0.640 zoom 1.041
        pause 0.0666
        "im1356"
        xpos 0.5041 ypos 0.641 xanchor 0.5 yanchor 0.641 zoom 1.042
        pause 0.0666
        "im1356"
        xpos 0.5042 ypos 0.642 xanchor 0.5 yanchor 0.642 zoom 1.043
        pause 0.0666
        "im1356"
        xpos 0.5043 ypos 0.643 xanchor 0.5 yanchor 0.643 zoom 1.044
        pause 0.0666
        "im1356"
        xpos 0.5044 ypos 0.644 xanchor 0.5 yanchor 0.644 zoom 1.045
        pause 0.0666
        "im1356"
        xpos 0.5045 ypos 0.645 xanchor 0.5 yanchor 0.645 zoom 1.046
        pause 0.0666
        "im1356"
        xpos 0.5046 ypos 0.646 xanchor 0.5 yanchor 0.646 zoom 1.047
        pause 0.0666
        "im1356"
        xpos 0.5047 ypos 0.647 xanchor 0.5 yanchor 0.647 zoom 1.048
        pause 0.0666
        "im1356"
        xpos 0.5048 ypos 0.648 xanchor 0.5 yanchor 0.648 zoom 1.049
        pause 0.0666

    rd "It's not common to see a number 10 getting dirty to win a ball..."    
    play sound "audio/whistle4.mp3"
    scene im1356 with hpunch
    fu "What?! No way! That was not a foul!!! Come on!"
    scene im1357 with dissolve
    rd "Unbelievable! Just in the previous play, Thomas made a studs-up tackle and it was not sanctioned! You can have a bad day, but this referee is just awful!"
    fu "They want to eat him alive...and I totally understand them! I like this attitude change, Rob...yeah, put pressure on the ref, Kalvin! Fight!"
    scene im1358 with dissolve
    rd "Change of attitude and change of formation, Fumi, now we're playing Robinson's classic 4-5-1! You know I played for him under this exact same formation...some years ago..."
    fu "Many years ago, when coach Robinson wasn't afraid to attack!"
    pause
    fu "Don't give me that look, I'm sorry, but somebody has to say it..."
    scene im1359 with dissolve
    fu "On a brighter note, Rob, do you think this is the best eleven we can get?"
    rd "If it isn't, it hits the post...a little imbalanced for my taste, nobody marks! I would like a more natural defensive midfielder like Johnson instead of Lalas and it'd be perfect."
    scene im1360 with dissolve
    fu "I have to disagree, Rob, this team has football! And what do you mean nobody marks? Everybody is doing it!"
    rd "You're right, Fumi, haha, you're so passionate tonight...I must say something: what a great move to put Carl on the left wing to control Nakamura! CJ is fast and more physical than Gilmar, he's helping Adams a lot!"
    rd "And Fumi, probably you won't like this, but that's all on Robinson."
    scene black with Dissolve(1.5)
    scene im1361 with dissolve
    fu "End of the first half...Vulcano's trio was destroying us, Rob, but I saw a clear improvement in the last minutes with the substitutions...your thoughts?"
    rd "Just like you said, their attackers are playing high level football tonight, we couldn't find a way to stop them in the beginning, let's see what happens in the second half...the first step was to neutralize that trio and we did it."
    fu "I must sound repetitive, but we need to attack! Attack and attack...we don't know what their goalkeeper looks like!"
    rd "Haha, true!"
    stop music fadeout 2.5
    scene black with Dissolve(2)

    scene im1367 with dissolve
    play music "audio/sixcoffinnail.ogg"
    scene im1367 with vpunch
    scene im1367 with vpunch
    coa "What the fuck was that?! You fucking suck!"
    scene im1367 with vpunch
    coa "In our stadium, you fucking idiots! In our stadium! What the fuck are you doing?"
    scene im1368 with vpunch
    coa "Why don't you go donate your organs?! You're not alive! You're corpses! I saw a fucking dead team out there!"
    scene im1369 with dissolve    
    coa "Am I saying something funny? Why the fuck are you smiling, you lazy piece of shit?!"
    coa "You better start running or you won't be playing for the rest of the season! You have talent? Fucking prove it!"
    scene im1370 with dissolve
    coa "Ethan! What the fuck did you do in that first goal?! It was an easy ball!"
    pt "What did he do? He saved it! Robinson's not being fair..."
    coa "Kalvin! Don't sit on the floor, stand up! You've been acting like a fucking loser from the start! I knew it was a mistake to give you the captain's armband!"
    pt "Well...something's wrong with them...conceding two goals affected them this much?"
    pt "Sometimes I forget they're very young...maybe they can't handle this kind of pressure, they've never been two goals down...but the game's not over yet!"
    scene im1370 with vpunch
    coa "Tomassini! Where the fuck are you?!"
    scene im1371 with dissolve
    scene im1371 with vpunch
    coa "Take that uniform off! I don't even want to see you on the bench! Go learn how to kick a ball!"
    pt "Daaamn! Robinson is an ass..."
    scene im1372 with vpunch
    coa "The rest of you go out there and show me you're not fucking pussies! No excuses!"
    pt "That kind of talk does not work with all of us..."
    scene im1373 with dissolve
    pt "I can count with Gilmar, I should pass him the ball...Virgilio, CJ, I'm sure they're motivated too..."
    scene black with dissolve
    scene im1597 with dissolve
    p "Don't worry, Tomasso, we'll save your ass..."
    scene im1598 with dissolve
    art "Fuck! We're wearing the same cleats! That's why I was playing so bad!"
    scene im1599 with dissolve
    p "Haha, get the fuck out..."
    gil "Come on, putas, get ready!"
    stop music fadeout 3
    scene black with Dissolve(2)

if choice79a:

    scene im1374 with dissolve
    el "It is fun, isn't it Meg?"
    me "It is, but the better team is not your friend's, hehe."
    el "Ha, you're mean...can you tell if he's any good at least?"
    me "I want to see him more minutes...but I can tell his ball control is excellent! He gave a couple of nice passes, too...let me watch him more..."
    jump startsecondhalf

label startsecondhalf:

    scene im1375 with dissolve
    fu "Thank you for your messages, Citizens, many of you saying you like our set up, yeah, it's getting better and better every week thanks to your views!"
    rd "I can read many compliments to you, Fumi..."
    fu "Yeah, let's not read those, we're here to talk about football! I'm feeling pretty confident our team can make a comeback and steal the three points from Vulcano!"
    rd "I can imagine how the halftime talk went, Fumi...the team must show some reaction after that!"
    scene black with dissolve
    play music "audio/rockfut.ogg"
    scene im1376 with dissolve
    p "Virgilio, Corky, it's up to us to start creating chances..."
    vir "[p], our defense sucks today, I'd never seen them like this before...and Ethan looks lost...we can't count on the Phillipses!"
    p "Give them some minutes, they need to see our attitude first...that's why we need to keep the ball among the three of us...pass and move, okay? We can do it."
    la "Just tell me where you want the ball, [p], I'll put it there, don't worry too much..."
    p "No, I didn't mean your long passes, Corky, short passes among us, ground level...that Thomas is taller, he would steal the ball from me..."
    p "Virgilio, stay close to me, you'll be my first option to pass...and take the shot, man! You have a powerful shot..."
    vir "Okay, I will, we're not losing tonight!"
    scene im1377 with dissolve
    rd "I'm getting excited, Fumi, we needed someone like Blanco to organize the team, I can see him giving instructions already..."
    scene im1378 with dissolve
    pt "Forget about Nakamura, he's just having a good day...CJ can stop him, I did it myself in the first half...and Allen is just a poacher, no more than that...yeah, top goalscorer, but Arthur is ten times more technical..."
    pt "This guy Thomas is the real deal, we have to stop him...how do we do that? Even if we pressure him constantly to force him to pass quickly, he doesn't lose precision..."
    pt "If he has a weakness, it must be his dribbling: he has no tricks, I'm sure he would eat one of my feints, he can't read them 'cause he can't do them...but, at the same time, he can outrun me...uhmmm..."
    pt "That number 4 is supposed to be their defensive midfielder...he's never well-positioned...he trusts Thomas will never lose the ball?"
    pt "That's it! That's the space to attack! Right behind Thomas!"
    scene im1379 with dissolve
    pt "This is where I like to play! I can see everything from here! I'm a playmaker, not a winger, Robinson you fucker!"
    pt "Let's go get the ball first..."

    scene im1380 with dissolve

    scene im1380:
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0666
        "im1380"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0666
    pt "Virgilio and I can stop him!"
    pt "You won't go past us, Thomas, you have to pass it next time...the rest of your team is average at best...we're gonna win, you'll see!"

    scene im1381 with dissolve
    la "Give me the ball, Virg!"
    scene im1382 with dissolve
    pt "Oh, yeah, pass and run!"
    scene im1383 with dissolve
    pt "Corky hides his passes so fucking well!"
    scene im1384 with dissolve
    pt "My turn!"
    scene im1385 with dissolve
    scene im1386 with dissolve
    fu "Heel and nutmeg from Blanco! Another backheel from Virgilio! Beautiful triangle passing, Rob! That's what we all came to see: total football! I told you this team had football!"
    rd "Haha, indeed, you did...what a fantastic play, Fumi!"
    fu "That number 6 is playing rugby or what?"
    scene im1387 with dissolve
    pt "Yes! Look at all this space! Arthur is making a diagonal already..."
    scene im1388 with dissolve
    pt "CJ is marked..."
    scene im1387 with dissolve
    scene im1389 with dissolve
    pt "Gilmar is free...he wants it wide? Why? No, dude!"
    p "Diagonal!"
    pt "I shouldn't be saying it out loud, the defenders know now!"
    pt "Ref's playing an advantage? Who was fouled?"
    scene im1387 with dissolve
    pt "It doesn't matter, it's a 4 versus 4...this is a goal!"
    scene im1390 with dissolve
    pt "I'll go for him...if they are not going to run the way I want, I'll dribble him...I got this!"
    scene im1391 with dissolve
    pt "I have an easy pass between his legs! With all that space ahead, Gilmar is the better option, he's faster..."
    pt "Arthur wants me to attack the space he's leaving...that's a good idea, too, the defender is chasing him...what should I do?"
    scene im1391 with vpunch
    ren "[p]!"
    scene im1392 with dissolve
    pt "Joker! You motherfucker..."
    pt "You're the best option!"
    scene im1393 with dissolve
    scene im1394 with dissolve
    pause 1
    scene im1395 with dissolve
    pt "Nice pass, [p]! You surprised me..."
    pt "Haha, Gilmar wanted it...keep running and don't complain..."
    scene im1396 with dissolve
    fu "Renilic is given a one-on-one chance to score after a beautiful trivela by Blanco!"
    scene im1397 with dissolve
    scene im1398 with dissolve
    scene im1399 with dissolve
    scene im1400 with dissolve
    scene im1400 with hpunch
    fu "Gooooooaaalllll!!! Yes! Renilic with a great shot from inside the box to make it 1-2 and give us hope!"
    rd "A great run by Renilic and a better pass by Blanco! What vision! We can do it, Fumi, the team's started to play really well!"

if choice79a:
    scene im1401 with dissolve
    el "Goaaaalll!!! Yay! That's our team!"
    me "It was built beautifully!"
    scene im1402 with dissolve
    me "And all thanks to..."
    scene im1403 with dissolve
    pause
    scene black with dissolve
    jump playmaker

if choice79b:

    scene im1618 with dissolve
    an "It was all on my buddy or what?!"
    an "You have good taste, by the way..."
    scene black with dissolve
    jump playmaker

label playmaker:

    scene im1404 with dissolve

    scene im1404:
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0666
        "im1404"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0666
    rd "Great game by Blanco, constantly moving and offering as an option for his teammates..."

    scene im1405 with dissolve

    scene im1405:
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0666
        "im1405"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0666    
    fu "We have full control of the ball these minutes thanks to [p]: he's re-built his teammates' morale with these consecutives passes and long possession..."
    rd "We're dictating the tempo now, Fumi: this team finally moves the way Robinson wanted!"
    fu "You mean the way [p] wants it!"
    scene im1406 with dissolve
    fu "We can't find an opening, Rob, Vulcano is only defending in the last minutes...it seems that they have given up on attacking..."
    rd "You know what they say: a 2-0 lead is the worst lead, it gave our rivals a false sense of security and, after our goal, they panicked and are trying to protect the advantage..."
    scene im1407 with dissolve
    fu "They do have a compact and solid defensive strategy...perhaps a long range shot can change things..."
    rd "Or an attempt to dribble past the defenders, take on them one-on-one..."
    stop music fadeout 2
    scene black with dissolve
    scene im1408 with dissolve
    fu "Look, look, Rob...[p] heard you, he may just have found a gap!"
    fu "Get ready, Thomas! [p] is coming!"
    scene black with dissolve
    scene im1409 with dissolve
    play music "audio/maximalism.mp3" volume 0.8

menu:

    "Double Stepover.":
        jump doublestepover

    "New Boba.":
        jump newboba

label doublestepover:

    scene im1410 with dissolve

    scene im1410:
        pause 0.0222
        "im1411"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "im1412"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "im1413"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "im1414"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "im1415"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "im1416"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "im1417"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "im1418"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "im1419"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "im1420"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "im1421"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "im1422"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "im1423"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "im1424"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "im1425"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "im1426"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "im1427"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "im1428"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "im1429"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "im1430"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0133
        "im1431"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0133
        "im1432"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0133
        "im1433"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "im1434"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0133
        "im1435"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0133
        "im1436"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0133
        "im1437"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0133
        "im1438"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0133
        "im1439"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0133
        "im1440"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0133
        "im1441"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0133
        "im1442"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0133
        "im1443"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0133
        "im1444"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0133
        "im1445"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0133
        "im1445a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0133
        "im1446"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0133
        "im1446a"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0133
        "im1447"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0133
        "im1448"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0133
        "im1449"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0133
        "im1450"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0133
        "im1451"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0133
        "im1452"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0133
        "im1453"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0133
        "im1454"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0133
        "im1455"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0133
        "im1456"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0133
        "im1457"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0133
        "im1458"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.050
        pause 0.0133
        "im1459"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.051
        pause 0.0133
        "im1460"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.052
        pause 0.0133
        "im1461"
        pause 0.0166
        "im1462"
        pause 0.0166
        "im1463"
        pause 0.0166
        "im1464"
        pause 0.0166
        "im1465"
        pause 0.0166
        "im1466"
        pause 0.0166
        "im1467"
        pause 0.0166
        "im1468"
        pause 0.0166
        "im1469"
        pause 0.0166
        "im1470"
        pause 0.0166
    pause
    fu "Woooooffff! What a classy Double Stepover!"
    scene im1472 with dissolve
    pt "You're a great player, Thomas, I respect you...you're the only one in your team who can take the ball away from me..."
    pt "But I win this time!"
    scene im1473 with vpunch
    p "Bye."
    scene im1471 with dissolve
    pt "This is my goal!"
    scene im1592 with vpunch
    pt "What the hell?!"
    play sound "audio/whistle2.mp3"
    scene im1593 with dissolve
    fu "That's a penalty! Clear foul inside the box, Rob!"
    rd "Damn, it was going to be a beautiful goal, Fumi..."
    scene black with dissolve
    scene im1594 with dissolve
    fu "There goes our penalty specialist: Virgilio...I'd say he's the most feared player from the penalty spot, Rob, this must be a goal!"
    scene im1595 with dissolve
    scene im1596 with dissolve
    scene im1596 with vpunch
    rd "Yes! He masked his intentions until the very end and changed directions, a penalty masterclass!"
    fu "Call me a fan, Rob, but I would've loved to see Blanco taking that penalty..."
    rd "Haha, we scored, Fumi! Smile!"
    scene black with dissolve
    scene im1580 with dissolve
    md "Thomas and Allen, I want them...forget about The Phillipses, they're not the kind of player I represent, they lack personality...on that team, I like Blanco, what do you think, Ruby?"
    ru "He dribbled past Thomas right there, he's good, sir!"
    scene im1581 with dissolve
    md "That or he's just having a good day...you had never heard of him, that worries me...keep tracking him for now..."
    ru "Yes, sir!"
    scene im1583 with dissolve
    ru "[p] Blanco, are you really that good?"
    scene black with Dissolve(1)
    jump resumegame2

label newboba:

    scene im1480 with dissolve

    scene im1480:
        pause 0.0166
        "im1481"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im1482"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im1483"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im1484"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im1485"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im1486"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im1487"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im1488"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im1489"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im1490"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im1491"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "im1492"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "im1493"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1494"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1495"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "im1496"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "im1497"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "im1498"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "im1499"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "im1500"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0166
        "im1501"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0166
        "im1502"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0166
        "im1503"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0166
        "im1504"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0166
        "im1505"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0166
        "im1506"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0166
        "im1507"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0166
        "im1508"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0166
        "im1509"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0166
        "im1510"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "im1511"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0166
        "im1512"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0166
        "im1513"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0166
        "im1514"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0166
        "im1515"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0166
        "im1516"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0166
        "im1517"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0166
        "im1518"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0166
        "im1519"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0166
        "im1520"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0166
        "im1521"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0166
        "im1522"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0166
        "im1523"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0166
        "im1524"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0166
        "im1525"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0166
        "im1526"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0166
        "im1527"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0166
        "im1528"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0166
        "im1529"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0166
        "im1530"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0166
        "im1531"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.051
        pause 0.0166
        "im1532"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.052
        pause 0.0166
        "im1533"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.053
        pause 0.0166
        "im1534"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.054
        pause 0.0166
        "im1535"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.055
        pause 0.0166
        "im1536"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.056
        pause 0.0166
        "im1537"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.057
        pause 0.0166
        "im1538"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.058
        pause 0.0166
        "im1539"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.059
        pause 0.0166
        "im1540"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0122
        "im1541"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.061
        pause 0.0122
        "im1542"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.062
        pause 0.0122
        "im1543"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.063
        pause 0.0122
        "im1544"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.064
        pause 0.0122
        "im1545"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.065
        pause 0.0122
        "im1546"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.066
        pause 0.0122
        "im1547"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.067
        pause 0.0122
        "im1548"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.068
        pause 0.0122
        "im1549"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.069
        pause 0.0122
        "im1550"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0122
        "im1551"
        pause 0.0133
        "im1552"
        pause 0.0133
        "im1553"
        pause 0.0133
        "im1554"
        pause 0.0133
        "im1555"
        pause 0.0133    
        "im1556"
        pause 0.0133
        "im1557"
        pause 0.0133
        "im1558"
        pause 0.0133
        "im1559"
        pause 0.0133
        "im1560"
        pause 0.0133
        "im1561"
        pause 0.0133
        "im1562"
        pause 0.0133
        "im1563"
        pause 0.0133
        "im1564"
        pause 0.0133
        "im1565"
        pause 0.0133    
        "im1566"
        pause 0.0133
        "im1567"
        pause 0.0133
        "im1568"
        pause 0.0133
        "im1569"
        pause 0.0133
        "im1570"
        pause 0.0133
    pause
    fu "Was that a Boba?!"
    rd "It was his own Boba with a little jump, he's improving it every time! What an efective body feint!"
    scene im1571 with dissolve
    fu "My God, Rob, he ridiculed Thomas! This must be a goal!"
    scene im1572 with Dissolve(1)
    scene im1573 with dissolve
    scene im1573 with vpunch
    scene im1573 with vpunch
    fu "Goooooaaaallll!!!"
    fu "Goal, goal, goal! We tied the match at 2, Rob! We can beat Vulcano!"
    rd "You can say that again, Fumi, what a solo goal by Blanco! We needed him to open this tough defense! A different game starts now..."
    scene im1574 with dissolve
    fu "And that's becoming his signature celebration, isn't it? I love it!"

if choice79a:
    scene im1575 with dissolve
    el "Marvelous goaaaalll! Wooow! You're the best, [p]! I love you!"
    scene im1575a with dissolve
    pause
    scene im1575b with dissolve
    me "Mom, behave!"
    jump resumegame1

if choice79b:
    scene im1619 with dissolve
    an "I knew you'd score, [p]! They can't stop you!"
    bl "Amazing!"
    jump resumegame1

label resumegame1:

    scene im1579 with dissolve
    md "I know what you're thinking: \"How did I miss him?\""
    ru "I'm sorry, Mr. Dorn...he wasn't even on my radar..."
    md "Good luck we came then."
    scene im1580 with dissolve
    md "Anyway, sign Thomas and Allen...forget about The Phillipses, they're not the kind of player I represent, they lack personality..."
    ru "And Blanco, sir? He's good!"
    md "Or he's just having a good day...you didn't know about him, that says a lot...keep tracking him before you make a move."
    scene im1581 with dissolve
    md "You asked me for one player to represent exclusively, didn't you? Tell you what: if everything turns out well, he's all yours, your first client."
    scene im1582 with dissolve
    ru "My first client..."
    scene im1583 with dissolve
    ru "[p] Blanco."
    scene black with Dissolve(1)

label resumegame2:

    scene im1584 with dissolve

    scene im1584:
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.020
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.024
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.025
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.026
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.027
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.028
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.029
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.031
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.032
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.033
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.034
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.035
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.036
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.037
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.038
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.039
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.040
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.041
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.042
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.043
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.044
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.045
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.046
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.047
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.048
        pause 0.0666
        "im1584"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.049
        pause 0.0666
    rd "I like their number nine a lot, Fumi: he's got this cunning, this malice needed for that role, especially against \"The Hounds\"..."
    rd "For real, he's facing the best center-backs in the league and he's actually making them look bad tonight...this kid is ready to be a professional footballer..."
    scene im1587 with vpunch
    fu "CJ shoots!"
    fu "To say \"over the crossbar\" would be an understatement...that ball knocked on God's door..."
    rd "Haha."
    scene im1586 with vpunch
    rd "Easy ball for Ethan..."
    scene im1588 with dissolve
    fu "That Thomas, Rob..."
    rd "Impressive, isn't he?"
    fu "He's literally EVERYWHERE!"    
    scene im1585 with vpunch
    scene im1585 with vpunch
    fu "Joker saves us with the face! Oh my God, Rob! I almost had a heart attack!"
    rd "In the last minute, Fumi! What an exciting match!"
    play sound "audio/endgamewhistle.ogg"
    scene black with Dissolve(2)
    scene im1589 with dissolve
    fu "A draw that leaves nobody satisfied, Rob..."
    rd "What a game we just watched, Fumi, I had so much fun! Two of the strongest teams in the tournament gave us a match to remember! Neither team deserved to lose, fair final score if you ask me..."
    fu "Yeah, but we gave away the first half, don't forget..."
    stop sound
    stop music fadeout 3
    scene black with Dissolve(1)
    scene im1590 with dissolve
    jt "Blanco!"
    jt "Great game, brother!"
    scene im1591 with dissolve
    p "What a pain in the ass you are, Thomas!"
    jt "Haha, respect, brother...why didn't you play the 90 minutes? Are you injured?"
    p "I'm not, but wait for me in your stadium, I'll play the whole game and beat you there!"
    jt "Haha, you have a strong team, but no way you can beat us at home!"
    p "We'll see about that, brother."
    scene black with Dissolve(3)
    pause

if choice79b:

    play music "audio/allright.mp3"

    scene im1631 with dissolve
    an "[p]!!! You are the best player in the world! Thank you for inviting me!"
    bl "Hi, [p], congratulations, great game! We really enjoyed it!"
    p "I'm glad you did, thanks for coming!"
    scene im1632 with dissolve
    an "Rivka couldn't make it, she had a last-minute thingy...and my mom didn't want me to come alone so..."
    p "Like I said, I'm glad you both came! I'll get you more tickets next time, Annie, so you can invite your whole family if you want...or Jessica! I haven't seen her in a while..."
    scene im1633 with dissolve
    an "She's not studying this semester, just like you..."
    p "Really? What happened?"
    an "Well, she never wanted to be there in the first place..."
    scene im1634 with dissolve
    bl "Sorry to interrupt...I have to go now, my husband and I are going out for dinner tonight...are you going somewhere with my Annie?"
    p "I was thinking about getting something to eat...I'm kind of hungry..."
    bl "A restaurant sounds good, I don't like her going to bars to drink, she's too young!"
    scene im1635 with dissolve
    bl "You seem responsible, I'm trusting you, don't let me down! Promise to bring her back home safe, okay? She's my baby."
    an "Mom..."
    p "I'll take good care of her, ma'am, don't worry."
    scene black with Dissolve(1)
    scene im1821 with dissolve
    pause 1
    scene im1822 with dissolve
    mt "Hey..."
    p "Hey, brother! Where have you been?"
    scene im1823 with dissolve
    mt "So, you two are dating now?"
    p "What?! No, man, we're friends, what are you talking about?"
    an "Hi, Daniel..."
    scene im1823a with dissolve
    mt "Hello, Ann, how are you?"
    an "Good..."
    scene im1824 with dissolve
    p "You okay, Annie?"
    an "Yeah, yeah, I'm good..."
    scene im1825 with dissolve
    hcm "Next."
    mt "That's me!"
    p "See you in a bit, brother..."
    scene black with dissolve
    scene im1826 with dissolve
    p "Oh, I didn't realize Metal was with that homeless dude..."
    an "Homeless? How do you know?"
    p "You're right, I was to quick to judge...I barely saw him when I greeted Daniel..."
    scene im1826a with dissolve
    an "His pants remind me of Master Collins's..."
    p "Oh, yeah, the first day, right?"
    scene im1827 with dissolve
    pause
    p "What?"
    p "Naaah, that's not Collins, that guy's too skinny...although, you told me he got sued and had some serious problems..."
    pause
    p "Nah, it can't be..."
    scene im1828 with dissolve
    p "He's coming this way..."
    stop music fadeout 3
    scene im1829 with dissolve
    p "Uuuuhmm, I don't know, what do you think?"
    an "It's really hard to tell...try to imagine him all flashy like he was..."
    scene im1829a with dissolve
    pause 1
    scene im1829b with dissolve
    pause 1
    scene im1829c with dissolve
    play music "audio/simpleplan.ogg" volume 0.6
    pause
    scene im1829b with Dissolve(2)

    scene im1829:
        pause 0.5
        "im1830"
        pause 0.5
        "im1829"
        pause 0.5
        "im1830"
        pause 0.5
        "im1829"
        pause 0.5
        "im1830"
        pause 0.5
        "im1829"
        pause 0.5
        "im1830"
        pause 0.5
        "im1829"
        pause 0.5
        "im1830"
        pause 0.1
        repeat
    pause

    scene im1829 with dissolve
    p "Master?"
    stop music
    play sound "audio/scratch.ogg"
    scene im1831 with hpunch
    pause 0.5
    p "No{w=1.0} fucking{w=1.0} way!"
    an "Oh my God!"
    scene im1832 with dissolve
    pause 0.6
    scene im1833 with dissolve
    pause 0.6
    mt "Tommy! Wait!"
    pt "Tommy?! It's him!" with hpunch
    scene im1834 with dissolve
    mt "What happened?!"
    p "He just ran off..."
    an "Do you want us to go with you?"
    mt "No, no, it's not necessary..."
    scene im1835 with dissolve
    an "[p], what do we do? I think we should go help somehow, right?"
    p "I don't think that's a good idea, Annie, he was very ashamed...didn't want to be recognized..."
    scene im1836 with dissolve
    an "I want to do something for him..."
    p "I know, I feel the same way, but I seriously think now is not the moment...let Daniel handle it for now..."
    scene im1837 with dissolve
    an "Oh, [p], I'm so sad now, I want to cry!"
    p "It is very sad...after seeing him so...alive in his classes...damn...what could've happened?"
    an "[p]..."
    p "Aw, Annie, you're such a kind girl...I'll call Daniel tomorrow and see what we can do, we'll help him somehow, I promise."
    an "Please..."
    scene black with Dissolve(2)
    play music "audio/evening.mp3"
    scene im1838 with Dissolve(1)
    p "Safe! As promised to your mom...feeling better?"
    scene im1839 with dissolve
    an "I am, yeah, it was just so...shocking..."
    p "It was, it was...can I ask you something?"
    an "What is it?"
    p "Has Metal come to your house again? You looked very uncomfortable when you saw him..."
    scene im1840 with dissolve
    an "Was it that obvious?"
    p "Painfully obvious."
    scene im1841 with dissolve
    an "Don't say that! And no, I haven't seen him around anymore...but I told you I was really scared when it happened, I simply ran off...Master Collins's style..."
    p "Haha..."
    an "Now, I feel nervous, anxious when I see him, I don't know...it's just my natural response..."
    p "I see...but I told you he won't hurt you, he's a good guy! He was helping Master Collins, wasn't he?"
    an "Yeah, I just can't help it...come on, we barely knew each other and he said he loved me all of a sudden! Seeing him here was just too much..."
    p "I get it..."
    scene im1842 with dissolve
    p "Well, Annie, thank you again for coming to my game, I'll get you tickets for the next one...gotta go now..."
    scene im1843 with dissolve
    an "Wait!"
    scene im1844 with dissolve
    pause 1
    scene im1845 with dissolve
    pause 1.5
    scene im1846 with dissolve
    an "Bye!"
    scene im1847 with dissolve
    pt "Annie..."
    stop music fadeout 3
    scene black with Dissolve(3)
    scene im1848 with Dissolve(1)
    pt "I didn't want to complicate things with Annie, she's such a good girl and I really care about her..."
    pt "She deserves someone better, kinder, more innocent...I'm not a good match for her...and I don't want to start a serious relationship any time soon...with anyone...I'm not ready..."
    play audio "audio/miau2.mp3"
    scene im1849 with dissolve
    p "What? Wanna watch TV and sit on my chest?"
    nan "{i}\"According to witnesses, the suspect would be 50 year-old local businessman Giuseppe Revello, but this information has not been confirmed by Police yet...\"{/i}"
    scene im1850 with dissolve
    p "Huh?"
    nan "{i}\"Again, our condolences to Senator Nyack and his family for such a terrible loss...\"{/i}"
    scene im1852 with dissolve
    play audio "audio/miau3.mp3"
    scene im1852 with hpunch
    p "What the hell happened?!"
    p "Vittoria!"
    scene black with Dissolve(2)

    jump choice83_common

if choice79a:

    play music "audio/jazzinstrumental.ogg"
    scene im1628 with dissolve
    el "[p]! I didn't know you were that good! Thank you for inviting us! Megan and I had never been to this stadium before, it's beautiful!"
    scene im1629 with dissolve
    meg "Yeah, thanks a lot, [p]! You played really well!"
    p "Hehe, thank you for coming you two, it means a lot to me..."
    scene im1630 with dissolve
    el "I bet you're starving now! Let me take you out for dinner, my treat!"
    meg "Yeah, we know a good place near here, you'll like it..."
    p "How could I say no? Let's go!"
    scene black with Dissolve(1)
    scene im1636 with Dissolve(1)
    hoss "Good evening, Ms. Wolfe!"
    el "Hi, cutie, table for three, please."
    hoss "Right away!"
    scene im1637 with dissolve
    p "Let me help you with that, Elle..."
    el "Thank you, darling...men are always gentlemen until they get what they want, aren't they?"
    meg "Haha...mom..."
    scene im1638 with dissolve
    el "Just the usual for me and my daughter, please, beauty, and bring a menu for [p]..."
    scene im1639 with dissolve
    hoss "At your service, Ms. Wolfe."
    scene black with Dissolve(1)
    scene im1640 with Dissolve(1)
    p "Hey, Megan, your mom told me you liked football a lot!"
    meg "I do, I do! I'm a freestyler actually..."
    p "A freestyler? Like those guys who can juggle with a ball?"
    meg "Haha, I do more than juggling..."
    scene im1641 with dissolve
    el "You should watch her videos, she's kind of famous!"
    scene im1642 with dissolve
    meg "Just a little bit..."
    p "That's pretty cool, Megan!"
    scene im1641 with dissolve
    el "I'll show you her videos when we get back to the car, I left my cellphone there..."
    p "Sure, I'd love to see that!"
    scene im1643 with dissolve
    el "So, [p], what now?"
    p "What do you mean?"
    el "I came to one of your games, watched you play like you wanted...what's next?"
    scene im1644 with dissolve
    meg "Haha, mom...that's why you're single! You have no patience!"
    scene im1645 with dissolve
    p "It's okay...I can answer that..."
    pt "What's next, huh? Sex! Haha, what are my options here?"
    pt "She did make the time to come see me, there's a mutual interest right there...Mmm, she runs a strip club, but she's not a whore...at least, that's the vibe I get from her..."
    scene im1646 with dissolve
    el "So? I'm all ears, what can you offer me?"
    pt "Offer you? What could you be looking for at this stage of your life?"
    pt "You've got money, so that's not it...and I bet many wealthier men have asked you out...and yet, you're here with me...think, [p], think! This is your chance!"
    scene im1647 with dissolve
    p "Listen, Elle, I don't want you to waste your time, I know you're a busy, successful businesswoman and, actually, that's all I know about you and I don't like it..."
    scene im1648 with dissolve
    p "No, I mean...I do like what I know about you, what I do not like is the fact of knowing so little about you...that's what I meant, if it makes any sense..."
    scene im1649 with dissolve 
    el "Haha, you lose your confidence when you're not on a soccer field?"
    p "Ha, apparently...what I want is to get to know you better because I'm attracted to you, there. How about that?"
    scene im1650 with dissolve
    p "How about that?"
    meg "Wut?"
    p "What I just said to your mom..."
    scene im1651 with dissolve
    el "I liked it."
    p "Good."
    scene im1652 with dissolve
    stop music fadeout 3
    va "Hey! Have you been following me? Haha."
    p "You wish! How you doing?"

    play music "audio/barsong.mp3"
    
    scene im1653:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    va "Doing fine, sexy voice..."
    va "When will you be back for another...guitar?"
    p "I might need one soon..."
    va "Haha."
    scene im1654 with dissolve
    va "Are you treating my man well, ladies?"
    el "Your man?"
    p "She's joking."
    scene im1655 with dissolve
    va "I gotta go meet my family, [p], I'm already late...hit me up, okay?"
    p "Sure...if I need a new guitar..."
    scene black with dissolve
    scene im1656 with dissolve
    el "Your friend?"
    p "Yeah..."
    scene im1657 with dissolve
    meg "More like friend with benefits..."
    p "What?! No! Keep eating..."
    scene im1658 with dissolve
    el "Hahaha, I know women, come on! It's funny to see how a woman like her can make you nervous, haha."
    p "You know what happened?"
    p "Have you heard that...theory, I guess, that when a man's surrounded by beautiful women, he becomes more attractive? Other women start wondering: \"why's that gorgeous woman with him?\"...things like that, you know..."
    el "I've heard that somewhere..."
    p "It's true! Your company just made me more attractive!"
    el "Let's pretend I believe it, [p], haha...Cheers!"
    meg "Buddy..."
    scene im1657 with dissolve
    meg "Yu rullu funna wutch..."
    p "What?"
    scene im1659 with dissolve
    meg "I said: you're really fun to watch! Not now...when you play, I mean..."
    el "Oh, Meg, stop it, don't speak while chewing..."
    pt "Yeah, you shouldn't, but..."
    p "That was the best compliment I've heard like...in my whole life...thank you!"
    scene im1660 with dissolve
    meg "I got you, dude, I got you."
    stop music fadeout 3
    scene black with Dissolve(2)

label vanesex3:

    if _in_replay:
        $ pf = persistent.p

    scene im1660a with Dissolve(1)
    pause 1
    scene im1663 with Dissolve(1)
    pt "Why do I feel so sleepy? The night's not over yet!"
    scene im1661 with dissolve
    pt "It was an exhausting game, I had to run a lot...plus all that meat and wine..."
    play sound "audio/opcldoor.ogg"
    scene im1662 with dissolve
    pause 1
    scene im1661 with dissolve
    pause 1
    scene im1664 with dissolve
    pause 1
    scene im1665 with dissolve
    va "Hey, you!"
    scene im1666 with dissolve
    pause 1
    scene im1667 with dissolve
    va "Pants off now! I want that dick!"

menu:

    "Do it.":
        jump choice83a

    "I'm good, thanks.":
        jump choice83b

label choice83a:

    $ choice83a = True

    play music "audio/gettingdirty.ogg" volume 0.7
    p "In your ass?"
    scene im1668 with dissolve
    va "Haha, I'd scream...would you like that?"
    p "You locked the door, didn't you?"
    va "What do you think?"
    scene im1669 with dissolve
    va "What's it gonna be?"
    p "Daaammmnnn!"

    scene im1670:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    p "You're trouble..."
    va "I'm convincing...Do you know any other woman like me?"
    p "No."
    pt "Well, not for free..."

    call screen vanebath1

    screen vanebath1():
        modal True

        viewport:

            add "im1670"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vanebath2")

label vanebath2:

    call screen vanebath2

    screen vanebath2():
        modal True

        viewport:

            add "im1670a"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("vanebathdog")


label vanebathdog:

    scene im1673 with dissolve
    p "Come here! I want your wet pussy, not that dirty dry ass."
    va "Ngh, shut up."
    scene im1672 with dissolve
    p "What a naughty woman you are, coming in here when your entire family is out there..."
    scene im1671 with dissolve
    pause 0.5
    scene im1674 with vpunch
    scene im1674 with vpunch
    p "Yeah, this is what you came for..."
    va "Shut up and fuck me!"

    scene im1675 with dissolve    

    scene im1675:
        pause 0.0166
        "im1676"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im1677"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im1678"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im1679"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im1680"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im1681"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im1682"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im1683"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im1684"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im1685"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im1686"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "im1687"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "im1688"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1689"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1690"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "im1691"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "im1692"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "im1693"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "im1694"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "im1695"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "im1696"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0166
        "im1697"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0166
        "im1698"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0166
        "im1699"
        pause 0.0166
        "im1700"
        pause 0.0166
        "im1701"
        pause 0.0166
        "im1702"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0166
        "im1703"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0166
        "im1704"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0166
        "im1705"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "im1706"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0166
        "im1707"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0166
        "im1708"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0166
        "im1709"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0166
        "im1710"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0166
        "im1711"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0166
        "im1712"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0166
        "im1713"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0166
        "im1714"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0166
        "im1715"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "im1716"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0166
        "im1717"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0166
        "im1718"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0166
        "im1719"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0166
        "im1720"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0166
        "im1721"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0166
        "im1722"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0166
        "im1723"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0166
        "im1724"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0166
        "im1725"
        pause 0.0166
        repeat
    pause

    scene im1675:
        pause 0.0133
        "im1676"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im1677"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im1678"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im1679"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im1680"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im1681"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im1682"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im1683"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im1684"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im1685"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im1686"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "im1687"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "im1688"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "im1689"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "im1690"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "im1691"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "im1692"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "im1693"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "im1694"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "im1695"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0133
        "im1696"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0133
        "im1697"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0133
        "im1698"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "im1699"
        pause 0.0133
        "im1700"
        pause 0.0133
        "im1701"
        pause 0.0133
        "im1702"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.023
        pause 0.0133
        "im1703"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.022
        pause 0.0133
        "im1704"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.021
        pause 0.0133
        "im1705"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0133
        "im1706"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019
        pause 0.0133
        "im1707"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018
        pause 0.0133
        "im1708"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "im1709"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "im1710"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "im1711"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "im1712"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "im1713"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "im1714"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "im1715"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im1716"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im1717"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im1718"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im1719"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im1720"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im1721"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im1722"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im1723"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im1724"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im1725"
        pause 0.0133
        repeat
    pause
    va "Harder, bitch!"
    p "Oh, I'll show you who the bitch is..."

    play sound "audio/doorbang.mp3"
    stop music
    scene im1726 with vpunch
    scene im1726 with vpunch
    uk "Hey, what's going on in there?"    
    va "Shit! That's my dad's voice!"
    vad "{size=-7}Excuse me, could you open this door for me?{/size}"
    uk "{size=-7}That's weird, it should be open...{/size}"
    scene im1727 with dissolve
    va "Hide! Hurry!"
    scene black with Dissolve(2)
    scene im1728 with dissolve
    p "Haha, what are you doing?"
    va "Shh!"
    scene im1729 with dissolve
    pause 1
    play sound "audio/knock.ogg"
    scene im1729a with dissolve
    vad "Hey, didn't you hear me knocking? Why did you lock the door?"
    p "I didn't do that, man...uuuhm, probably, my friend who just left was trying to be funny and locked me up in here...and I'm wearing earphones, sorry I didn't hear you..."
    vad "Oh, I see...I'm sorry, too..."
    scene im1729c with dissolve
    pause
    scene black with Dissolve(1)
    scene im1729b with Dissolve(1)
    va "I think he left already, go check..."
    p "I'm not going out...too bad for him if he's still out there, he's gonna hear his daughter moan."
    va "You better make me cum or I'll tell him you tried to rape me..."
    scene im1729b with hpunch
    p "What?! That's not funny...you're out of your mind..."
    va "That's right, you're hooking up with a crazy bitch."
    pt "Shit! Is she serious? Man, this's taking longer than I wanted..."

    scene black with dissolve
    play music "audio/rockjoy.ogg" volume 0.7
    scene im1730 with dissolve    

    scene im1730:
        pause 0.0222
        "im1731"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "im1732"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "im1733"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "im1734"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "im1735"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "im1736"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "im1737"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "im1738"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "im1739"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "im1740"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "im1741"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "im1742"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "im1743"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "im1744"
        pause 0.0222
        "im1745"
        pause 0.0222
        "im1746"
        pause 0.0222
        "im1747"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "im1748"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "im1749"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "im1750"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "im1751"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "im1752"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "im1753"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "im1754"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "im1755"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "im1756"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "im1757"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "im1758"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "im1759"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "im1760"
        pause 0.0222
        repeat
    pause

    pt "Cum already...this is taking too long!"

    scene im1761:
        pause 0.0133
        "im1762"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im1763"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im1764"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im1765"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im1766"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im1767"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im1768"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im1769"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im1770"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im1771"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im1772"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "im1773"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "im1774"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "im1775"
        pause 0.0133
        "im1776"
        pause 0.0133
        "im1777"
        pause 0.0133
        "im1778"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "im1779"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "im1780"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "im1781"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "im1782"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "im1783"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "im1784"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "im1785"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "im1786"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "im1787"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "im1788"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "im1789"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "im1790"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "im1791"
        pause 0.0133
        repeat
    pause

    play sound "audio/femaleorg3.ogg"
    scene im1791a with vpunch
    scene im1791a with vpunch
    p "Damn, you're loud, they might hear us outside!"
    va "You don't want them to know?"
    p "You don't care? I think I even saw your mom..."
    va "Haha, I'm glad I came...and you didn't...slave."
    p "The fuck? Don't call me that...you really are a crazy bitch..."
    va "Haha, wait some minutes in here before you go out..."

    stop music fadeout 3
    scene black with Dissolve(3.0)

    $ renpy.end_replay()


    scene im1792 with dissolve
    el "There you are! You sure took a long time..."
    meg "Sorry, mom..."
    scene im1793 with dissolve
    meg "We know what you just did and that was completely disrespectful! My mom was kind enough to invite you here, you know...and you end up having sex with another woman right in front of us?"
    pt "What?! That bitch told them?!" with hpunch
    pt "Or they heard her? I don't think so, her dad would be waiting here to kick my ass..."
    p "Errr..."
    meg "You can't even deny it, you make me sick! I know my mom doesn't give a shit about you, but you're not worth her time...you're just a horrible person...I'm done talking to you."
    scene im1794 with dissolve
    meg "Let's go, mom."
    pt "And that's how you fuck up good chances in life..."
    pt "That crazy bitch..."
    pt "And I didn't even come!"
    scene black with Dissolve(2)
    scene im1848 with Dissolve(1)
    pt "I can't believe that bitch snitched on me...I liked the experience, though...is that considered public sex?"
    play audio "audio/miau2.mp3"
    scene im1849 with dissolve
    p "What? Wanna watch TV and sit on my chest?"
    nan "{i}\"According to witnesses, the suspect would be 50 year-old local businessman Giuseppe Revello, but this information has not been confirmed by Police yet...\"{/i}"
    scene im1850 with dissolve
    p "Huh?"
    nan "{i}\"Again, our condolences to Senator Nyack and his family for such a terrible loss...\"{/i}"
    scene im1852 with dissolve
    play audio "audio/miau3.mp3"
    scene im1852 with hpunch
    p "What the hell happened?!"
    p "Vittoria!"
    scene black with Dissolve(2)

    jump choice83_common

label choice83b:

    $ choice83b = True

    scene im1795 with dissolve
    va "Whaaattt?!"
    p "Yeeeah, I'm good..."
    scene im1796 with dissolve
    va "Fuck you."
    p "Yeeeah, good night to you, too."
    scene black with Dissolve(2)

    $ renpy.end_replay()

    play music "audio/citytraffic.mp3"
    play sound "audio/claxon.ogg"
    scene im1797 with dissolve
    meg "Shut up!"
    meg "What's going on back there? Aren't you too close?"
    scene im1798 with dissolve
    el "Haha, nothing's going on, I was just showing him your videos, Meggy!"
    p "Yeah, you're pretty good, Megan...you can teach me some of your tricks one day..."
    meg "I don't know about that...mom, I'm taking you home and then going to Cara's, okay?"
    el "Suuuuure, honeyyy, suuure...at what time are you coming back?"
    meg "Why?"
    el "Just asking..."
    meg "Well, I don't know."
    stop music fadeout 2
    scene black with Dissolve(2)
    play music "audio/unwind.mp3"
    scene im1799 with Dissolve(1)
    el "She won't be coming back tonight, I know her...come on, have a drink with me..."
    scene im1800 with Dissolve(1)
    el "What happened to your hand?"
    scene im1801 with dissolve
    p "This? Uuuhm, poor anger management..."
    el "Who did you punch?"
    p "You mean \"what\"...a wall, a door..."
    el "Why would you do that?"
    p "Physical pain can distract you from other type of pain..."
    scene im1802 with dissolve
    pause
    p "Who plays the piano? You or Megan?"
    scene im1803 with dissolve
    el "That'd be me! You want me to play something for you?"
    p "I'd love to!"
    scene im1804 with dissolve
    el "I'm a little drunk, so forgive me if it's not perfect, hehe."
    stop music fadeout 3
    scene im1804a with dissolve
    pause
    pt "She's focusing...I love it when someone shows their talent seriously...I bet she's good!"
    el "All right, I'm ready."
    play music "audio/ballethappy.mp3"
    scene im1805 with dissolve
    pause 1.5
    scene im1806 with Dissolve(1.5)
    pause 1.5
    scene im1807 with Dissolve(1.5)
    pause 1.5
    scene im1808 with Dissolve(1.5)
    pause 1.5
    scene im1808a with Dissolve(1.5)
    pause 1.5
    scene black with Dissolve(1.5)
    scene im1809 with dissolve
    p "That deserves a standing ovation! You play beautifully, Elle!"
    el "Haha, thanks! Let's make a toast!"
    scene im1810 with dissolve
    el "Here's to you!"
    p "To me?"
    el "Yes! Because I had so much fun tonight watching you play! You looked really good on that field...Can I give you some advice?"
    p "Football advice?"
    el "No, silly, life advice..."
    p "I'm listening..."
    el "Look back, look ahead and don't forget to look around at the faces of those who care about you."
    p "That was...deep...you think I needed that? Haha...I liked it. It reminded me of that quote...uuuhm...\"life must be lived looking forward, but it can only be understood looking backwards\"...something like that..."
    el "I knew it! You become a poet when drunk! Haha."
    scene im1811 with dissolve
    p "My turn!"
    p "Here's to you! May you live long enough to be a problem to Megan!"
    scene im1812 with dissolve
    el "What?"
    p "A true poet, right? No, but seriously, here's to your smile...may you never lose it!"
    scene im1813 with dissolve
    el "Haha, cheers!"
    p "Cheers!"
    stop music fadeout 3
    scene black with Dissolve(2)

    play sound "audio/womanlaugh.ogg"
    scene im1814 with Dissolve(2)
    pause
    play sound "audio/womanlaugh1.mp3"
    scene im1815 with Dissolve(2)
    pause
    scene im1816 with Dissolve(2)
    pause
    scene im1817 with dissolve
    b "I..."
    b "Jinx!"
    el "Haha, you shut up, haha...are you going to kiss me?"
    p "The sentence started with \"I\"...but that was my plan, yeah..."
    el "Was?"
    scene im1818 with dissolve
    pause
    scene im1819 with dissolve
    pause
    scene im1820 with dissolve
    el "Let's go to my bedroom..."
    p "I won't say no to that..."

label ellesex1:

    if _in_replay:
        $ pf = persistent.p

    scene black with Dissolve(1)
    play music "audio/sensual13.mp3"
    scene im1983 with Dissolve(1)
    el "I like your lips..."
    p "And I'd like to see yours..."
    el "You mean...haha, get undressed, now!"
    scene black with dissolve
    scene im1879 with dissolve
    p "Look at that, you're a natural ginger..."
    scene im1880 with dissolve
    el "You thought I wasn't?"
    p "I didn't know, now I know...what a beautiful pussy..."
    scene im1884 with dissolve
    el "Is it the first one you see? Haha."
    p "I've seen some, I've seen some...but this one is special..."
    scene im1881 with dissolve
    el "Special how?"
    p "My first ginger."
    scene im1881a with vpunch
    pause
    scene im1882 with dissolve
    el "Isn't your hand broken?"
    p "Don't worry about it."
    scene im1883 with vpunch
    pause 1
    scene im1882 with Dissolve(1)
    pause
    scene im1883 with vpunch
    pause 1
    scene im1886 with Dissolve(1)
    pause
    play sound "audio/femorg10.ogg"
    scene im1885 with vpunch
    scene im1885 with vpunch
    p "Yeah, that's what I wanted..."
    scene im1887 with Dissolve(1)
    p "This smells like urine..."
    el "Oh my God! Don't smell it! Take it off!"
    scene black with dissolve
    scene im1888 with dissolve
    el "You dragged me where it is all wet, dirty boy, haha..."
    p "I just wanted to take a closer look at your pussy...now, could you please open these beautiful legs, ma'am?"
    el "Haha, only because you asked nicely, sir, haha..."
    scene im1889 with dissolve
    p "My God!"
    p "I'm in love..."
    scene im1889a with dissolve
    p "You are perfect, ma'am..."
    p "Well, I'm going in!"

    scene im1890a with dissolve

    scene im1890a:
        pause 0.0222
        "im1891a"
        pause 0.0222
        "im1892a"
        pause 0.0222
        "im1893a"
        pause 0.0222
        "im1894a"
        pause 0.0222
        "im1895a"
        pause 0.0222
        "im1896a"
        pause 0.0222
        "im1897a"
        pause 0.0222
        "im1898a"
        pause 0.0222
        "im1899a"
        pause 0.0222
        "im1900a"
        pause 0.0222
        "im1901a"
        pause 0.0222
        "im1902a"
        pause 0.0222
        "im1903a"
        pause 0.0222
        "im1904a"
        pause 0.0222
        "im1905a"
        pause 0.0222
        "im1906a"
        pause 0.0222
        "im1907a"
        pause 0.0222
        "im1908a"
        pause 0.0222
        "im1909a"
        pause 0.0222
        "im1910a"
        pause 0.0222
        "im1911a"
        pause 0.0222
        "im1912a"
        pause 0.0222
        "im1913a"
        pause 0.0222
        "im1914a"
        pause 0.0222
        "im1915a"
        pause 0.0222
        "im1916a"
        pause 0.0222
        "im1917a"
        pause 0.0222
        "im1918a"
        pause 0.0222
        "im1919a"
        pause 0.0222
        "im1920a"
        pause 0.0222
        "im1921a"
        pause 0.0222
        "im1922a"
        pause 0.0222
        "im1923a"
        pause 0.0222
        "im1924a"
        pause 0.0222
        "im1925a"
        pause 0.0222
        "im1926a"
        pause 0.0222
        "im1927a"
        pause 0.0222
        "im1928a"
        pause 0.0222
        "im1929a"
        pause 0.0222
        "im1930a"
        pause 0.0222
        "im1931a"
        pause 0.0222
        "im1932a"
        pause 0.0222
        "im1933a"
        pause 0.0222
        "im1934a"
        pause 0.0222
        "im1935a"
        pause 0.0222
        "im1936a"
        pause 0.0222
        "im1937a"
        pause 0.0222
        "im1938a"
        pause 0.0222
        "im1939a"
        pause 0.0222
        repeat
    el "I'm having so much fun! Hahaha...YOU are so much fun! Make me cum again!"    
    el "You can come inside as a reward, hahaha..."
    p "Say no more!"

    scene im1890b:
        pause 0.0166
        "im1891b"
        pause 0.0166
        "im1892b"
        pause 0.0166
        "im1893b"
        pause 0.0166
        "im1894b"
        pause 0.0166
        "im1895b"
        pause 0.0166
        "im1896b"
        pause 0.0166
        "im1897b"
        pause 0.0166
        "im1898b"
        pause 0.0166
        "im1899b"
        pause 0.0166
        "im1900b"
        pause 0.0166
        "im1901b"
        pause 0.0166
        "im1902b"
        pause 0.0166
        "im1903b"
        pause 0.0166
        "im1904b"
        pause 0.0166
        "im1905b"
        pause 0.0166
        "im1906b"
        pause 0.0166
        "im1907b"
        pause 0.0166
        "im1908b"
        pause 0.0166
        "im1909b"
        pause 0.0166
        "im1910b"
        pause 0.0166
        "im1911b"
        pause 0.0166
        "im1912b"
        pause 0.0166
        "im1913b"
        pause 0.0166
        "im1914b"
        pause 0.0166
        "im1915b"
        pause 0.0166
        "im1916b"
        pause 0.0166
        "im1917b"
        pause 0.0166
        "im1918b"
        pause 0.0166
        "im1919b"
        pause 0.0166
        "im1920b"
        pause 0.0166
        "im1921b"
        pause 0.0166
        "im1922b"
        pause 0.0166
        "im1923b"
        pause 0.0166
        "im1924b"
        pause 0.0166
        "im1925b"
        pause 0.0166
        "im1926b"
        pause 0.0166
        "im1927b"
        pause 0.0166
        "im1928b"
        pause 0.0166
        "im1929b"
        pause 0.0166
        "im1930b"
        pause 0.0166
        "im1931b"
        pause 0.0166
        "im1932b"
        pause 0.0166
        "im1933b"
        pause 0.0166
        "im1934b"
        pause 0.0166
        "im1935b"
        pause 0.0166
        "im1936b"
        pause 0.0166
        "im1937b"
        pause 0.0166
        "im1938b"
        pause 0.0166
        "im1939b"
        pause 0.0166
        repeat
    pause

    play sound "audio/maleorg5.ogg"
    scene im1981 with vpunch
    scene im1981 with vpunch
    scene im1981 with flash
    pause
    stop music fadeout 3
    scene im1982 with flash
    play sound "audio/maleorg5.ogg"
    scene im1982 with vpunch
    scene im1982 with vpunch
    pause

    scene black with Dissolve(1)
    play music "audio/hotrocknroll.ogg"
    scene im1940 with Dissolve(1)
    pause
    scene im1941 with pushleft
    pause
    scene im1942 with pushleft
    pause
    scene im1943 with pushleft
    pause
    scene im1944 with pushleft
    pause
    scene im1945 with dissolve
    pause
    scene im1946 with vpunch
    pause
    scene im1945 with dissolve
    pause
    scene im1946 with vpunch
    p "Shit!"
    scene im1945 with dissolve
    pause
    scene im1947 with Dissolve(1)
    p "Tighter?"
    scene im1948 with vpunch
    scene im1948 with vpunch
    el "Aahhh, God..."
    scene black with dissolve
    scene im1949 with dissolve
    el "Can you still go?"
    p "Can't you feel the answer?"
    scene im1949a with dissolve
    el "I feel it in my uterus, to be honest..."
    scene im1949b with dissolve
    p "This is a firm butt!"
    el "For a woman my age, you say?"
    p "I didn't say that..."
    stop music fadeout 3
    scene im1949c with dissolve
    el "I still keep some moves, you know?"
    p "Show me, let me be the judge of it..."

    play music "audio/slowrockhot.mp3"

    scene im1950 with dissolve

    scene im1950:
        pause 0.0166
        "im1951"
        pause 0.0166
        "im1952"
        pause 0.0166
        "im1953"
        pause 0.0166
        "im1954"
        pause 0.0166
        "im1955"
        pause 0.0166
        "im1956"
        pause 0.0166
        "im1957"
        pause 0.0166
        "im1958"
        pause 0.0166
        "im1959"
        pause 0.0166
        "im1960"
        pause 0.0166
        "im1961"
        pause 0.0166
        "im1962"
        pause 0.0166
        "im1963"
        pause 0.0166
        "im1964"
        pause 0.0166
        "im1965"
        pause 0.0166
        "im1966"
        pause 0.0166
        "im1967"
        pause 0.0166
        "im1968"
        pause 0.0166
        "im1969"
        pause 0.0166
        "im1970"
        pause 0.0166
        "im1971"
        pause 0.0166
        "im1972"
        pause 0.0166
        "im1973"
        pause 0.0166
        "im1974"
        pause 0.0166
        "im1975"
        pause 0.0166
        "im1976"
        pause 0.0166
        "im1977"
        pause 0.0166
        "im1978"
        pause 0.0166
        "im1979"
        pause 0.0166
        "im1980"
        pause 0.0166
        repeat
    pause
    el "This will make you cum in a minute."
    p "It's not fair...I was close already..."
    el "Enjoy it."

    scene im1950:
        pause 0.0122
        "im1951"
        pause 0.0122
        "im1952"
        pause 0.0122
        "im1953"
        pause 0.0122
        "im1954"
        pause 0.0122
        "im1955"
        pause 0.0122
        "im1956"
        pause 0.0122
        "im1957"
        pause 0.0122
        "im1958"
        pause 0.0122
        "im1959"
        pause 0.0122
        "im1960"
        pause 0.0122
        "im1961"
        pause 0.0122
        "im1962"
        pause 0.0122
        "im1963"
        pause 0.0122
        "im1964"
        pause 0.0122
        "im1965"
        pause 0.0122
        "im1966"
        pause 0.0122
        "im1967"
        pause 0.0122
        "im1968"
        pause 0.0122
        "im1969"
        pause 0.0122
        "im1970"
        pause 0.0122
        "im1971"
        pause 0.0122
        "im1972"
        pause 0.0122
        "im1973"
        pause 0.0122
        "im1974"
        pause 0.0122
        "im1975"
        pause 0.0122
        "im1976"
        pause 0.0122
        "im1977"
        pause 0.0122
        "im1978"
        pause 0.0122
        "im1979"
        pause 0.0122
        "im1980"
        pause 0.0122
        repeat
    pause

    scene im1960 with vpunch
    scene im1960 with vpunch
    scene im1960 with flash
    pause 1.5

    stop music fadeout 3
    scene black with Dissolve(2.5)

    $ renpy.end_replay()

    scene im1984 with Dissolve(1)

    play music "audio/sensual16.mp3"
    el "Turn on the tv, I need it to sleep..."
    p "Sleep? We're taking a shower, aren't we?"
    el "In a bit."
    nan "{i}\"The suspect would be 50 year-old local businessman Giuseppe Revello, but this information has not been confirmed by Police yet...\"{/i}"
    scene im1985 with dissolve
    el "What?! What did he do?"
    scene im1986 with dissolve
    nan "{i}\"Again, our condolences to Senator Nyack and his family for such a terrible loss...\"{/i}"
    p "What?" with hpunch
    scene im1987 with dissolve
    el "My phone!"
    scene im1988 with dissolve
    pt "They're saying Giuseppe killed Senator Nyack's son?! What the hell?!"
    pt "Vittoria! I have to call her!"
    scene black with dissolve
    scene im1989 with dissolve
    pause 1
    scene im1990 with dissolve
    el "It goes straight to voicemail...I need to go see somebody, what are you going to do?"
    scene im1991 with dissolve
    el "Arina, dark glass."
    scene im1992 with Dissolve(1.5)
    pt "Cool..."
    p "I was thinking of going to Vittoria's..."
    scene im1993 with dissolve
    el "That's a great idea...if it's true, she'll need all the support she can get, I may go there later..."
    p "Ok, I'm taking a shower now..."
    el "There are some bandages in the black cabinet in case you need some...for your hand, I mean."
    p "Thanks, you're so thoughtful...Elle, tonight was..."
    scene im1994 with dissolve
    el "Now is not the moment."
    p "Okay...you're right."
    scene im1995 with Dissolve(1)
    el "But...I liked it...a lot..."
    p "Yeah, me too."
    stop music fadeout 3
    scene black with Dissolve(3)
    jump choice83_common

label choice83_common:

    play music "audio/russian4.mp3" volume 0.5
    scene im1853 with Dissolve(1.5)
    dr "Done, it didn't touch the heart, he's going to make it..."
    ge "Thank God, I was so worried..."
    dr "Thanks to me."
    fz "Good job as usual, Cesare...how much?"
    scene im1854 with dissolve
    ce "Let's not discuss money right now, Franz..."
    fz "We won't be here long, that's why I asked."
    nan "{i}\"We interrupt this program to bring you some breaking news: Valtr Nyack, Senator Nyack's son, has been killed at his residence on the day of his birthday...\"{/i}"
    scene im1855 with dissolve
    si "Him?"
    nan "{i}\"According to witnesses, the suspect would be 50 year-old local businessman Giuseppe Revello, but this information has not been confirmed by Police yet...\"{/i}"
    scene im1856 with hpunch
    si "You deserved that, motherfucker! Die, you son of a bitch!"
    nan "{i}\"Also this afternoon, a fire was reported in one of The Nyacks' factories, fortunately, nobody was injured...\"{/i}"
    scene im1857 with dissolve
    ge "A fire? No one injured?"
    fz "Pft, they lie all the time..."
    ge "I can't believe he killed Valtr, man, I knew Revello got balls, but I don't know...do you think it's true?"
    fz "It has to be...I don't think Valtr wanted to disappear, he would have to live hiding if he's still alive..."
    ge "I've had enough of that family...for now...Belgium, brother, we'll find Fabienne!"
    stop music fadeout 3
    scene black with Dissolve(2)
    pause

    play music "audio/darkside.mp3"
    scene im1858 with Dissolve(1)
    uk "So, you were Samantha's boyfriend..."
    p "Yes, were you friends?"
    uk "Not friends, but I knew her...I'm sorry for your loss."
    p "..."
    p "Sorry, I didn't catch your name when you opened the door..."
    scene im1859 with dissolve
    na "Natalia."
    na "This whole situation sucks, you know? Life's not being fair to Mrs. Revello..."
    p "I couldn't agree more, it's just terrible...being for her is the only thing we can do."
    na "Yeah, my parents said the same."
    scene black with dissolve
    scene im1860 with dissolve
    p "Good evening..."
    scene im1861 with dissolve
    vi "[p]! They're saying in the news that Giuseppe killed this man and then committed suicide! Can you believe it?! They're liars! I won't believe anything until I see it!"
    p "What?!"
    pt "I didn't know he killed himself...that's so not him..."
    scene im1862 with dissolve
    vi "Giuseppe is not suicidal, I know they're lying! He always told Sammy not to believe in the news!"
    p "There must be a mistake then...they said it is an ongoing investigation, that was the last thing I heard..."
    vi "I want to go to the police station, can you take me there? I'm so nervous I can't drive."
    pt "She's shaking..."
    scene im1863 with dissolve
    uk "Vicky, we've talked about it...it's better to wait here...what if somebody from the police comes?"
    vi "I can't simply wait in here, Barbara, I'm sure you can understand that..."
    scene im1864 with dissolve
    uk "Let me make some calls first, Vittoria, we have to know exactly how to proceed in cases like this..."
    vi "If it were up to me, I'd go directly to that mansion they mentioned...but I don't have the faintest idea where it is..."
    vi "Do it quickly, Jeff, I can't wait any longer..."
    scene black with Dissolve(2)
    scene im1865 with dissolve
    na "What a strong woman Mrs. Revello is, don't you think?"
    p "She is, indeed."
    na "First, her daughter and now, her husband..."
    p "We have to wait for your dad to give us information on Giuseppe...perhaps he's still alive in a hospital..."
    scene im1866 with dissolve
    na "He's dead."
    p "According to the news, but maybe it's like Vittoria said: they lie all the..."
    na "Listen, my dad said he was going to make some calls, but truth is he already did...he has some contacts in the police department and they confirmed it: Mr. Revello is dead."
    scene im1867 with vpunch
    p "What?! Don't tell me that...did he kill himself?"
    na "That I don't know, my dad didn't give us any details, he just said \"dead\"."
    p "Where's your dad now? Where'd he go?"
    na "I don't know...he's just killing time because my parents don't want to break the news to Vittoria...officially, I mean..."
    na "Maybe he'll bring somebody from the department to tell her...but Mrs. Revello is in complete denial, she won't believe it until she sees his body...you heard her."
    scene im1868 with dissolve
    p "It is so sad, you have to understand...Vittoria probably can't fathom the idea of losing all her family, she refuses to believe it...and Giuseppe killing himself? I don't buy it."
    scene im1869 with dissolve
    na "I have a question: why does it matter if he killed himself or not? You seem surprised only by the suicide thing...as a matter of fact, neither you nor Mrs. Revello questioned the killing spree part..."
    scene im1870 with vpunch
    p "Killing spree?!"
    na "Oh, so that is it...you didn't watch the whole report, did you? I guess she didn't watch it either..."
    p "I heard he killed a senator's son..."
    scene im1871 with dissolve
    pt "Not any senator...Isaac Nyack's...my club's owner..."

if choice79a:
    scene im1872 with Dissolve(1.5)
    vi "{i}\"My husband did some research into you...\"{/i}"
    scene im1873 with Dissolve(1.5)
    giu "{i}\"They're closer to you than you could imagine...\"{/i}"
    scene im1874 with Dissolve(1.5)
    ge "{i}\"Very powerful people are involved...\"{/i}"
    scene im1871 with dissolve
    scene im1875 with dissolve
    pt "Isaac Nyack is Gordon Wardell's boss!" with vpunch
    pt "What?!" with vpunch
    pt "Nyack killed S and, tonight, Giuseppe..."
    scene im1876 with vpunch
    scene im1876 with vpunch
    pt "...killed his son!!!"
    scene im1876 with vpunch
    scene im1876 with vpunch
    pt "WHAT?!"
    na "Dude..."
    scene im1877 with dissolve
    na "Dude, react...what's wrong?"
    p "Everything's wrong!"
    pt "I need to calm down before Vittoria sees me..."
    scene im1878 with dissolve
    na "Jesus, your face looked like if you had seen the devil..."
    p "Sorry...I need some time alone..."
    na "Yeah, sure, whatever..."
    stop music fadeout 2
    scene black with Dissolve(2)
    jump yuastory

else:

    jump annstory

label yuastory:
    

    scene i1 with dissolve
    play music "audio/phobia.ogg"
    pt "I have to be right about this: Isaac Nyack got Samantha killed and Giuseppe killed his son to take revenge for her...but, originally, Nyack didn't want to kill S, he wanted to kill me! What did Franz do to him? Did he steal from him?"
    pt "No, money has never motivated Franz to do anything...and I don't think Senator Nyack would order to kill someone over a simple debt...it has to be something very serious...drugs?"
    pt "I can't focus...all I can think of right now is Giuseppe, poor man...he lost his only child, suffered from cancer...he was practically forced to do what he did tonight...who could blame him?"
    pt "He's just another victim here...I know who should be held accountable for this tragedy!"
    scene i2 with Dissolve(1)
    pause 1
    scene black with Dissolve(1)
    play sound "audio/doorbang.mp3"
    scene i3 with dissolve
    p "Franz!"
    play sound "audio/bangdoor.mp3"
    p "Open the fucking door!"
    scene i4 with dissolve
    uk "Excuse me...are you [p]?"
    scene i5 with dissolve
    p "Yeah, I am, and you are...?"
    ch "Hi, I'm Charlotte, a friend of your brother..."
    scene i6 with dissolve
    ch "Franz gave me this for you before leaving."
    p "Leaving?"
    scene i7 with dissolve
    pt "What's that? A key?"
    p "Do you know where he went?"
    ch "I don't, he didn't want to tell me, they just left with many bags...the three of them..."
    pt "Three?"
    scene i8 with dissolve
    pt "That girl...who is she?"
    scene i9 with dissolve
    ch "And he also said he would call you soon..."
    p "Oh, okay, Charlotte...thank you so much."
    scene black with Dissolve(1)
    scene i10 with dissolve
    pt "What a strange key...if it is a key..."
    scene i11 with dissolve
    pt "Franz left, even though it was Giuseppe who killed Isaac's son...my brother must be involved somehow, there's no other reason...What's next? More deaths? Is Vittoria in danger? Am I in danger? My mom?"
    pt "I can't share any of this with anybody, it'd be a heavy burden on any of my friends...besides, it's only a theory...a solid, rational one, but still...I should try to find out more about this first..."
    pt "I think Franz's boxes are still in the basement, at least a couple of them are, I could start there...and there must be a clue in Vittoria's house...Giuseppe's laptop, something!"
    scene i12 with dissolve
    pt "Elle! Giuseppe and she were close! She must know something! But..."
    stop music fadeout 3
    yu "[p]! I knew it was you!"
    scene i13 with dissolve
    yu "Is everything all right?"
    p "Yuaaa!!!" with hpunch

    
    play music "audio/feelingfine.ogg"
    scene i14:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause

    p "Now it is! What are you doing here?"
    yu "Waiting for a friend...you know my sister Fumino, don't you?"
    p "Sister? I do know her...I didn't know she was your sister, though..."

    call screen yuafu

    screen yuafu():
        modal True

        viewport:

            add "i14"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("yuafustreet")

label yuafustreet:

    scene i15 with dissolve
    p "You're the club's streamer, I've watched you and Rob...how you doing?"
    scene i16 with dissolve
    fu "Great game tonight, [p] Blanco..."
    yu "Oh, you have to tell me all about it!"
    scene i17 with dissolve
    p "About the game? I just played, nothing extraordinary...YOU have to tell me where the party is at! You both look beautiful!"
    scene i18 with dissolve
    fu "That's because tonight is my sister's debut as a singer!"
    p "Seriously?! Congratulations, Yua! I always knew you had the potential to become an idol!"
    yu "Haha, not there yet...it's not like I'm getting paid or anything..."
    p "It doesn't matter, it's something you like doing, money has nothing to do with it...where is your show?"
    yu "At Cara's club..."
    play sound "audio/honk.mp3"
    scene i19 with dissolve
    fu "Our ride is here!"
    yu "Michael!"
    stop music fadeout 3
    scene i20 with dissolve
    yu "Are you free right now? Wanna come? I could use the extra support..."
    stop music fadeout 3

menu:

    "Yua and Fumino.":
        jump choice84a

    "Vittoria!":
        jump choice84b

label choice84a:

    $ choice84a = True

    play music "audio/dontstop.mp3"
    p "Sure! I don't want to miss your debut, future superstar!"
    scene i21 with dissolve
    yu "Haha, hop in!"
    fu "Yes!"
    scene black with Dissolve(1)
    scene i23 with dissolve
    fu "[p], before I forget, you know I always give players nicknames when streaming, so uhmmm...what would you like to be called?"
    p "What have you been calling me?"
    fu "Starting tonight, I'm calling you \"The Architect\"...you know, 'cause you're a creative builder of the play, but I have more options..."

menu:

    "The Architect.":
        jump choice85a

    "The Magician.":
        jump choice85b

    "The Iceman.":
        jump choice85c

label choice85a:

    $ choice85a = True

    scene i24 with dissolve
    fu "I knew you'd like it, haha."
    p "You know me pretty well, apparently..."
    fu "It's a gift, hehe."
    jump choice85_common

label choice85b:

    $ choice85b = True

    scene i25 with dissolve
    fu "Rob likes that one, too."
    scene i26 with dissolve
    mi "What do you play, man?"
    p "Soccer."
    mi "You must be good then...to be called \"The Magician\"..."
    p "I'm not bad at it."
    jump choice85_common

label choice85c:

    $ choice85c = True

    scene i27 with dissolve
    yu "I love that one! The Iceman sounds sexy!"
    fu "Yeah, right? Ok, Iceman it is!"
    jump choice85_common

label choice85_common:

    stop music fadeout 3
    scene black with Dissolve(3)
    scene i28 with Dissolve(1)
    play music "audio/dancetheme.mp3"
    uk "It's a very emotional evening for all of us who have the privilege to know her, she's worked so hard for this moment...You deserve it, baby!"
    yu "Love you, Karen!"
    kar "Love you more!"

    scene i29:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    kar "Let's make her debut unforgettable! Everybody, give it up for our super talented new artist..."
    kar "Yua!"

    scene i39:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    yu "Thank you for being here with me tonight, I hope you enjoy the show!"
    yu "Love you all!"

    scene i32 with dissolve
    p "We love you, too, Yua! You're the best!"
    fu "Oh, my God, her dream is coming true! She looks so beautiful tonight!"
    p "Gorgeous!"

    scene i30 with Dissolve(1.3)
    pause 1.3
    scene i31 with Dissolve(1.3)
    pause 1.3
    scene i34 with Dissolve(1.3)
    pause 1.3
    scene i35 with Dissolve(1.3)
    pause 1.3
    scene i36 with Dissolve(1.3)
    pause 1.6

    call screen yuafu1

    screen yuafu1():
        modal True

        viewport:

            add "i38"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("yuafubar")

label yuafubar:

    stop music fadeout 3
    scene i37 with dissolve
    pt "They both are really beautiful..."
    pt "Dear Universe: don't make me choose!"

    play music "audio/sportparty1.mp3"

    scene i33:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    pause
    pt "I'm so happy for you, Yua...you have everything to get to the top: beautiful voice, the looks, the work ethics..."
    scene i40 with dissolve
    pt "This's been fun, hasn't it? I needed it to clear my mind..."
    scene i41 with dissolve
    pt "I wonder how Vittoria is doing right now...I'll think about her tomorrow, I won't ruin this moment for Yua...changed that face, [p]!"
    scene i39b with dissolve
    pt "Look at her!"
    scene i39d with Dissolve(2)
    pt "Wow!"
    pt "You'll make it, I have no doubt!"

    scene i39c:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause 
    pt "You were born to shine!"

    call screen yuashine

    screen yuashine():
        modal True

        viewport:

            add "i39c"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("yuabar")

label yuabar:

    stop music fadeout 3
    scene black with Dissolve(2)

    scene i43 with Dissolve(1)
    play music "audio/sportparty2.mp3"

label backtoclub:

    call screen yuabar

    screen yuabar():
        add "i43"
        modal True

        imagebutton auto "yuabar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Yua")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("yuatalk")

        imagebutton auto "fumibar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Fumino")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("fumitalk")

        imagebutton auto "kannabar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Kanna")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("kannatalk")

label yuatalk:

    scene i52
    pt "She's busy with her friends right now, don't want to disturb her..."

    jump backtoclub      

label fumitalk:

    scene i42 with dissolve
    fu "Come on, [p], don't be boring, dance with me!"
    scene black with dissolve
    scene i53 with dissolve
    p "You're very happy tonight, Fumino..."
    fu "I am! My sis just made her debut as a singer!"

if choice85a:
    fu "And call me Fumi...Architect!"
    jump fumikeeptalk

if choice85b:
    fu "And call me Fumi...Magician!"
    jump fumikeeptalk

if choice85c:
    fu "And call me Fumi...Iceman!"
    jump fumikeeptalk

label fumikeeptalk:
    p "Haha, don't you prefer Fumi-chan?"
    scene i54 with dissolve
    fu "I know what you're doing': you want me to call you \"onii-chan\"!"
    p "Haha...how old are you, by the way?"
    fu "Eighteen."
    p "Yeah? You look fifteen."
    scene i55 with dissolve
    fu "Thank you! But I'm not! I couldn't be working for City Group if I were."
    p "That's true..."
    scene black with Dissolve(1)
    jump backtoclub        

label kannatalk:

    scene i45:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0

    uk "What a cute couple you are! Are you Yua's sister?"
    fu "Yes, ma'am, and you are..."
    ka "Cara's mother, Kanna...do you know my daughter?"
    fu "Of course! She is soooo funny, haha...a pleasure to meet you, ma'am."
    pt "A pleasure, indeed..."
    scene i44 with dissolve
    ka "We're leaving soon, but I want you all to come with us! I feel more comfortable if Cara parties at home...could you tell your sister, please? I don't feel like interrupting her right now..."
    fu "Sure, ma'am, don't worry. I bet Cara's telling her already, but I'll talk to my sister anyway..."
    ka "Thank you!"
    scene black with Dissolve(1)

    jump karenorcara

label karenorcara:

    scene i43 with dissolve

if choice83a:
    jump karenbar

if choice83b:
    jump carabar

label karenbar:
    
    call screen karenbar

    screen karenbar():
        add "i43"
        modal True


        imagebutton auto "karenbar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Karen")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("karentalk")

label karentalk:
    
    scene i52
    pt "That woman's hot...and she's alone, I think..."
    scene i190 with dissolve
    p "Excuse me..."
    scene i191 with dissolve
    p "Would you like to dance?"
    scene i192 with dissolve
    kar "I'd love to!"
    scene black with dissolve
    scene i193 with dissolve
    kar "Thanks for saving me...that guy was really boring..."
    p "You seemed entertained."
    kar "Pretending is part of my job."
    p "Are you pretending now?"
    scene i194 with dissolve
    kar "Who knows?"
    scene i195 with dissolve
    uk "This one, Karen?"
    kar "What do you think,Roxie?"

    scene i196:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    ro "He looks fit...what's your name?"
    p "[p]...Are you DJ Marshmallow or just look alike?"
    ro "Haha, Mello! M-E-L-L-O! Roxie by day, Marshmello by night!"
    dj "You coming with us?"
    kar "But he's with Yua..."
    scene i197 with dissolve
    p "Hold on, hold on...I can make my own decisions, where are you going?"
    dj "My place...wanna come?"
    pt "My first threesome?"
    pt "Man, I'm blueballed after Vanessa...this is a gift from heaven! And they're not bad..."
    scene i198 with dissolve
    kar "And?"
    p "I'm ready when you are."
    scene i200 with dissolve
    dj "Let's go! This woman needs a cock!"
    pt "And you, too!"
    scene black with dissolve
    scene i201 with dissolve
    fu "[p], are you leaving?"
    p "Yes, nice meeting you, Fumino...say bye to Yua, she's busy talking to her friends, didn't want to bother...well...bye!"
    stop music fadeout 2.5
    scene black with Dissolve(2)

label djsex1:

    if _in_replay:
        $ pf = persistent.p

    scene i202 with dissolve
    play music "audio/diamondtwerk.ogg"
    p "You're not gonna drug me and steal from me, are you?"
    dj "Hahaha, shut up, you're the one who looks like could use some money!"
    kar "Haha, I'm going into the sauna after the workout, Roro..."
    scene i203 with dissolve
    p "How good is it? My coach recommends taking a sauna after training, but I've never done it."
    kar "Your coach?"
    p "Yeah, I play soccer..."
    scene i204 with dissolve
    dj "Hey! We already went through the introductions part! Take off your pants!"
    scene i205 with dissolve
    dj "We want to see if you'll be able to satisfy us."
    p "Show me the product then! I can't see anything with all those clothes on..."

    scene i206:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause
    dj "How about now?"
    pt "I'm a lucky bastard!"
    p "Mmm...another angle?"

    call screen djthreesome

    screen djthreesome():
        modal True

        viewport:

            add "i206"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("djthreesome1")

label djthreesome1:

    scene i207:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause
    dj "And?"
    p "You have a fine fat ass, Roxie!"
    dj "Hey!"
    kar "Mine's small, don't look at it..."
    p "It looks pretty firm...and you legs! Damn, Karen!"

    call screen djthreesome2

    screen djthreesome2():
        modal True

        viewport:

            add "i207"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("djthreesome2")

label djthreesome2:

    scene i620 with dissolve
    p "Come here, give me a kiss."
    kar "It was about time you get close..."
    dj "Kiss this beauty!"
    scene i621 with dissolve
    dj "Yeah, that's hot...your clothes, hurry! I wanna see what you got!"
    scene black with dissolve
    scene i623 with dissolve
    pause
    scene i622 with dissolve
    dj "You're acting like a sneaky child!"
    kar "Don't pinch it, bite that nippple!"
    dj "Don't! Bite hers, she loves it..."
    scene i624 with dissolve
    pause
    dj "Told ya! This is not a child's cock, let me tell ya..."
    scene black with dissolve
    scene i625 with dissolve
    dj "Wanna come on our tits?"
    pt "This keeps getting better and better...although..."
    scene i628 with Dissolve(1.5)
    pt "Yeeeeaah, that'd be a better duo!"
    scene i627 with Dissolve(1.5)
    pt "Or them!"
    scene i626 with Dissolve(1.5)
    scene i626 with hpunch
    pt "Or them!"
    pt "Will it ever be possible?"
    dj "I want to feel this cock inside!"
    pt "Huh? Who said that?"
    scene i629 with dissolve
    pt "Oh, that's right..."
    pt "Well, this is not bad, either..."
    scene i630 with dissolve
    pt "It could be better, but I just want to come..."
    scene i631 with dissolve
    pt "Come on, make me come!"
    pt "I don't know why I'm not fully enjoying this..."
    scene i632 with vpunch
    scene i632 with vpunch
    scene i631 with Dissolve(1)
    pause 0.5
    scene i632 with vpunch
    scene i632 with vpunch
    scene i631 with Dissolve(1)
    pause
    pt "I think I really wish they were somebody else..."
    scene i633 with Dissolve(2)
    pt "Yeah, my cock just got harder imagining Yua and Fumi...their pussies must be so tasty..."
    stop music fadeout 3
    pt "I should've stayed with them, I could be having more fun..."
    pt "Well, what's done is done..."
    p "I wanna be on top!"
    play music "audio/trainingday.mp3"
    scene black with Dissolve(1.5)

    scene i634 with dissolve
    pt "Yeah, I like to be in control."

    scene i640 with dissolve

    scene i640:
        pause 0.0166
        "i641"
        pause 0.0166
        "i642"
        pause 0.0166
        "i643"
        pause 0.0166
        "i644"
        pause 0.0166
        "i645"
        pause 0.0166
        "i646"
        pause 0.0166
        "i647"
        pause 0.0166
        "i648"
        pause 0.0166
        "i649"
        pause 0.0166
        "i650"
        pause 0.0166
        "i651"
        pause 0.0166
        "i652"
        pause 0.0166
        "i653"
        pause 0.0166
        "i654"
        pause 0.0166
        "i655"
        pause 0.0166
        "i656"
        pause 0.0166
        "i657"
        pause 0.0166
        "i658"
        pause 0.0166
        "i659"
        pause 0.0166
        "i660"
        pause 0.0166
        "i661"
        pause 0.0166
        "i662"
        pause 0.0166
        "i663"
        pause 0.0166
        "i664"
        pause 0.0166
        "i665"
        pause 0.0166
        "i666"
        pause 0.0166
        "i667"
        pause 0.0166
        "i668"
        pause 0.0166
        "i669"
        pause 0.0166
        "i670"
        pause 0.0166
        "i671"
        pause 0.0166
        "i672"
        pause 0.0166
        "i673"
        pause 0.0166
        "i674"
        pause 0.0166
        "i675"
        pause 0.0166
        repeat
    pt "I usually like to give my woman pleasure, but not tonight..."
    pt "I don't even know you, why would I care?"
    pt "I'm just gonna fill you up!"

    scene i640:
        pause 0.0133
        "i641"
        pause 0.0133
        "i642"
        pause 0.0133
        "i643"
        pause 0.0133
        "i644"
        pause 0.0133
        "i645"
        pause 0.0133
        "i646"
        pause 0.0133
        "i647"
        pause 0.0133
        "i648"
        pause 0.0133
        "i649"
        pause 0.0133
        "i650"
        pause 0.0133
        "i651"
        pause 0.0133
        "i652"
        pause 0.0133
        "i653"
        pause 0.0133
        "i654"
        pause 0.0133
        "i655"
        pause 0.0133
        "i656"
        pause 0.0133
        "i657"
        pause 0.0133
        "i658"
        pause 0.0133
        "i659"
        pause 0.0133
        "i660"
        pause 0.0133
        "i661"
        pause 0.0133
        "i662"
        pause 0.0133
        "i663"
        pause 0.0133
        "i664"
        pause 0.0133
        "i665"
        pause 0.0133
        "i666"
        pause 0.0133
        "i667"
        pause 0.0133
        "i668"
        pause 0.0133
        "i669"
        pause 0.0133
        "i670"
        pause 0.0133
        "i671"
        pause 0.0133
        "i672"
        pause 0.0133
        "i673"
        pause 0.0133
        "i674"
        pause 0.0133
        "i675"
        pause 0.0133
        repeat
    pause 2

    play sound "audio/maleorg4.ogg"

    scene i676 with vpunch
    scene i676 with flash
    scene i676 with vpunch
    scene i676 with vpunch
    scene i676 with flash
    p "Fuuuck!"
    scene i677 with dissolve
    scene i677 with vpunch
    pt "Now it's her turn to get pregnant!"
    pt "What am I thinking? I don't give a shit about anything anymore..."
    scene black with Dissolve(1)
    scene i678 with dissolve
    kar "Yeah, lick my butthole!"
    scene i679 with dissolve
    p "Sorry, Karen, she won't be able to reach it now, I need her pussy..."
    kar "You're so greedy!"

    scene i680 with dissolve

    scene i680:
        pause 0.0222
        "i681"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "i682"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "i683"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "i684"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "i685"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "i686"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "i687"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "i688"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "i689"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "i690"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "i691"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "i692"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "i693"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "i694"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "i695"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0222
        "i696"
        pause 0.0222
        "i697"
        pause 0.0222
        "i698"
        pause 0.0222
        "i699"
        pause 0.0222
        "i700"
        pause 0.0222
        "i701"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0222
        "i702"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0222
        "i703"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0222
        "i704"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0222
        "i705"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0222
        "i706"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0222
        "i707"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "i708"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "i709"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "i710"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "i711"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "i712"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "i713"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "i714"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "i715"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        repeat
    pause
    p "Haha, you're just sniffing it, Roxie..."
    p "Don't worry, I'll be done in a minute, then you two can have all the fun you want..."

    scene i698:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.14
        pause 0.0166
        "i699"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.13
        pause 0.0166
        "i700"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.12
        pause 0.0166
        "i701"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.11
        pause 0.0166
        "i702"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "i703"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "i704"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0166
        "i705"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0166
        "i706"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "i707"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0166
        "i708"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0166
        "i709"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0166
        "i710"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "i711"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "i712"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "i713"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i714"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i715"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i680"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i681"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i682"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1
        pause 0.0166
        "i683"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0166
        "i684"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0166
        "i685"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.03
        pause 0.0166
        "i686"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.04
        pause 0.0166
        "i687"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.05
        pause 0.0166
        "i688"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.06
        pause 0.0166
        "i689"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.07
        pause 0.0166
        "i690"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.08
        pause 0.0166
        "i691"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.09
        pause 0.0166
        "i692"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.1
        pause 0.0166
        "i693"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.11
        pause 0.0166
        "i694"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.12
        pause 0.0166
        "i695"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.13
        pause 0.0166
        "i696"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.14
        pause 0.0166
        "i697"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.14
        pause 0.0166
        repeat
    pause

    scene i716 with dissolve
    play sound "audio/maleorg4.ogg"
    scene i716 with vpunch
    scene i716 with vpunch
    scene i716 with flash
    play sound "audio/maleorg4.ogg"
    scene i716 with vpunch
    scene i716 with vpunch
    scene i716 with dissolve
    scene i717 with Dissolve(1.5)
    pt "There..."
    pt "I'm still hard, but that's enough...they don't deserve more of my cum, haha..."
    pt "I'm sure I can have a better threesome in the future..."

    stop music fadeout 3
    scene black with Dissolve(2)
    pause
    scene i726 with Dissolve(2)
    pt "Am I still here?"
    pt "Where are they?"
    scene i727 with Dissolve(1)
    pause 1
    scene i728 with dissolve
    pause
    pt "Nice body, Karen...I think I want another round now, haha..."
    scene black with dissolve
    play music "audio/sensual5.mp3"
    scene i729 with dissolve
    p "Morning! Do you mind if I..."
    scene i730 with dissolve
    kar "As long as you don't talk, I just want to switch off."
    p "That's cool, I can enjoy silence, too."
    scene i731 with dissolve
    pause
    pt "It's not forbidden to watch..."
    scene i732 with dissolve
    pt "Hi..."
    scene i733 with Dissolve(1)
    pause
    scene i734 with Dissolve(1)
    pause
    scene i735 with Dissolve(1)
    pause
    pt "What kind of game is this? First one to speak is gay? Haha."
    scene i736 with Dissolve(1)
    pause
    scene i737 with Dissolve(1)
    pause
    pt "A teasing game? Oooff, I'm sweating already..."
    pt "I'll have a surprise for you when you open your eyes, hehe..."
    scene i738 with Dissolve(1)
    pause
    scene i739 with Dissolve(1)
    pause
    scene i740 with Dissolve(1)
    pt "Yeeeahh, don't open your eyes..."
    scene i741 with dissolve
    pt "Come here..."
    scene i742 with dissolve
    pt "Whooops...busted..."
    scene i743 with dissolve
    kar "What are you doing?"
    p "Nothing...yet..."
    scene i744 with dissolve
    kar "I'm gonna bite it for being so shameless..."
    p "Can't you be kinder?"
    scene i745 with dissolve
    kar "Like this?"
    p "Can you use your mouth?"
    scene i746 with dissolve
    p "Haha, not like that...here, let me show you..."

    scene i750 with vpunch
    scene i750 with dissolve

    scene i750:
        pause 0.0133
        "i751"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0133
        "i752"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0133
        "i753"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0133
        "i754"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0133
        "i755"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0133
        "i756"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0133
        "i757"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0133
        "i758"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0133
        "i759"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0133
        "i760"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01
        pause 0.0133
        "i761"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011
        pause 0.0133
        "i762"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012
        pause 0.0133
        "i763"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013
        pause 0.0133
        "i764"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014
        pause 0.0133
        "i765"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015
        pause 0.0133
        "i766"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016
        pause 0.0133
        "i767"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017
        pause 0.0133
        "i768"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018  
        pause 0.0133
        "i769"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019  
        pause 0.0133
        "i770"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0133
        "i771"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 
        pause 0.0133
        "i772"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "i773"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "i774"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 
        pause 0.0133
        "i775"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "i776"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "i777"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133
        "i778"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0133

        "i778"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i777"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i776"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i775"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i774"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i773"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i772"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i771"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        "i770"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.02
        pause 0.0222
        "i769"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.019  
        pause 0.0222
        "i768"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.018  
        pause 0.0222
        "i767"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.017  
        pause 0.0222
        "i766"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.016  
        pause 0.0222
        "i765"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.015  
        pause 0.0222
        "i764"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.014  
        pause 0.0222
        "i763"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.013  
        pause 0.0222
        "i762"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.012  
        pause 0.0222
        "i761"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.011  
        pause 0.0222
        "i760"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.01  
        pause 0.0222
        "i759"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.009
        pause 0.0222
        "i758"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.008
        pause 0.0222
        "i757"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.007
        pause 0.0222
        "i756"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.006
        pause 0.0222
        "i755"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.005
        pause 0.0222
        "i754"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.004
        pause 0.0222
        "i753"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.003
        pause 0.0222
        "i752"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.002
        pause 0.0222
        "i751"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.001
        pause 0.0222
        "i750"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0222
        repeat
    pause

menu:

    "Face.":
        jump facekaren

    "Mouth.":
        jump mouthkaren

label facekaren:

    scene i749 with Dissolve(1)
    play sound "audio/maleorg5.ogg"
    scene i749a with vpunch
    scene i749a with flash
    scene i749a with dissolve
    p "Yeah, good job..."
    stop music fadeout 3
    scene black with Dissolve(3)

    $ renpy.end_replay()

    jump ep9


label mouthkaren:

    scene i747 with dissolve
    play sound "audio/maleorg5.ogg"
    scene i747 with vpunch
    scene i747 with flash
    scene i747 with vpunch
    pause 1
    scene i748 with Dissolve(1)
    p "Let me see...yeahh..."

    stop music fadeout 3
    scene black with Dissolve(3)

    $ renpy.end_replay()

    jump ep9

label carabar:

    call screen carabar

    screen carabar():
        add "i43"
        modal True

        imagebutton auto "carabar_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "Cara")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("caratalk")

label caratalk:

    scene i46 with dissolve
    cr "Heeeyyy! Long time no see!"
    p "Hey, Cara, I'm glad you remember me..."
    cr "How could I forget?! You kissed me in front of your girlfriend! Best compliment ever!"
    pt "The hell?!" with hpunch
    scene i47 with dissolve
    p "I kissed you on the cheek..."

    scene i48:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    pause
    meg "I knew it was you!"
    p "Megan? Nice shoes!"
    meg "Haha, are you saying they don't match my dress?"
    cr "I see you know Meg..."
    p "Not long ago...she's cool, I like her."
    scene i49 with dissolve
    meg "I thought you were with my mom!"
    p "Haha, why not tell everybody, right? I was, but...hasn't she called you?"
    meg "My phone is at Cara's..."
    pt "Fatty knows everybody...and her mom's hot...and her friends: Yua, Megan...it'd be smart to get close to her..."
    scene i50 with dissolve
    cr "I just told Yua to leave for my place, I'm kind of tired of being here every day...you coming?"
    p "Yeah, I think I'm in..."
    scene i51 with dissolve
    yu "Let's go, [p]! The night's young!"
    p "I thought you were tired after your show..."
    yu "Not even close!"
    stop music fadeout 3
    scene black with Dissolve(2)
    scene i56 with Dissolve(1)
    play music "audio/sportparty3.mp3"
    fu "Richmond Hills?! Yua never told me you lived here, Cara! I've never been to this part of the city before..."
    p "Me, neither."
    scene i57 with dissolve
    p "You live on top of Li Tower?!"
    cr "Cara Li...hello?"
    p "WHAT?!" with hpunch
    mi "Wait a minute...Xiang Li, the tech mogul, is your dad?!"
    ka "Haha, you're not the first ones to react like that!"
    cr "Getting tired of it already..."
    scene i58 with dissolve
    ka "Come in, please, everybody is welcome! Offer them something to drink, Cara."
    cr "Okay, mom."
    scene i59 with dissolve
    ka "Make yourselves comfortable."
    fu "Wooow! You live in the future!"
    scene i60 with dissolve
    ka "I could give you a tour in the morning."
    fu "That'd be awesome!"
    mi "Please!"
    pt "We're sleeping over now? Michael was the ride..."
    scene i61 with dissolve
    cr "Is wine fine everybody?"
    yu "Speak now or forever hold your peace!"
    mi "Is there something stronger? Whiskey, perhaps?"
    p "I second that."
    scene i62 with dissolve
    ka "All right, have fun, kids, that's it for me...I can finally be at ease having you all here, safe...don't break anything!"
    fu "Have a good night's sleep, Mrs. Li!"
    cr "Bye, mom."
    p "Bye, Mrs. Li, thank you for everything!"
    scene i63 with dissolve
    meg "Guys, I have to leave, my mom's been calling me all night and she's not picking up right now! Something bad must have happened..."
    scene i64 with dissolve
    p "I do know what happened, Megan...first of all, she's perfectly fine...physically, I mean...errr, we were watching the news, 'cause that's what we were doing, and she recognized one of her friends...uhm, getting shot..."
    scene i65 with hpunch
    meg "What?! My God...and you just left her alone?!"
    p "She said she was gonna make some calls and told me to leave so..."
    scene i66 with dissolve
    meg "That does sound like my mom, she doesn't like to be seen when vulnerable..."
    scene i67 with dissolve
    cr "Noodles, I'm waking Hoke up immediately..."
    meg "Thank you, Donut."
    scene black with Dissolve(1)
    scene i68 with dissolve
    fu "You never told me Cara's house was this nice..."
    yu "I'm pretty sure I did, I tell you everything."
    fu "You said \"nice\", but not reeeeaaaal nice!"
    mi "It's an amazing place! I wonder what gadgets Cara has in her room!"
    scene i69 with dissolve
    yu "Uhmmm, Arina was a big surprise when I first came here...not anymore..."
    scene i70 with dissolve
    p "Maybe her dad has a secret room full of unreleased devices that are worth millions, some crazy new shit like that..."
    mi "You read my mind!"
    scene i71 with dissolve
    yu "Haha, you guys are the crazy ones!"
    p "Don't you know who Xiang Li is? He must be using a Yphone 33 right now!"
    cr "Nope, not yet..."
    scene i72 with dissolve
    cr "Guys, don't you want to put on your pajamas? There's a guest room waiting for each of you..."
    fu "A room for ourselves? I'd like to see that!"
    yu "Let's do it, I want to take a shower...these clothes are sweaty and I want to remove all this makeup, too..."
    stop music fadeout 3
    scene black with Dissolve(2)
    scene i74 with Dissolve(1)
    pause 1
    scene i75 with Dissolve(1)
    pt "This is a guest room? She even said I can keep these pajamas, haha...is that what people do when they're super rich?"
    yu "Arina, open the door."
    scene i76 with dissolve
    p "What the..."
    yu "I told you you have to say \"lock the door\", not only \"close\"..."    

    play music "audio/cutekorean.ogg"

    scene i77:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    pause
    pt "My God..."
    yu "Were you going to say something?"
    p "That I don't like this Arina thing, I feel like I'm being watched."
    yu "Well, you are, how do you think it works? There are cameras and sensors everywhere."
    p "Cameras? So, I can't do anything to you then..."
    scene i78 with dissolve
    yu "Haha...what did you want to do to me?"
    p "You know, I think I can see your nipples..."
    scene i79 with dissolve
    yu "From that distance? I doubt it."
    p "Why don't you get closer? Just to confirm..."
    scene i80 with Dissolve(1)
    yu "Like this close?"
    p "Yup, definitely, I can see them."
    scene i81 with dissolve
    yu "It's your reward for supporting me tonight."
    p "But that's not all, isn't it?"
    scene i82 with dissolve
    yu "Haha, what else do you want? I told you you have to take me out on dates and be my boyfriend before considering something else..."
    p "But you don't want to date broken guys, so..."
    yu "That's right! I'm just showing you what you're missing out for not being ready!"
    p "Ha, didn't know you were such a tease, Yua..."
    scene i83 with dissolve
    fu "What's going oooonnn?"
    p "Nothing yet."
    scene i84 with dissolve
    fu "Whaaat..."
    yu "What are you doing here? Go back to your room!"
    fu "I can't sleep..."
    yu "Fumino! We're in the middle of something."
    fu "[p]?"
    p "Yeah, we are in the middle of something, Fumi..."
    scene i85 with dissolve
    fu "Can I get a goodnight hug at least?"
    p "Only if you promise to leave afterwards..."
    fu "Okay."
    scene i86 with dissolve
    pause
    scene i87 with dissolve
    pause
    yu "Ok, that's enough...bye, Fumino."
    scene i88 with dissolve
    fu "Hey! I can see your nipples!"
    yu "Out!"
    scene black with dissolve
    scene i89 with dissolve
    yu "One thing: you shouldn't spoil her, she thinks she can get anything acting like a child."
    p "She is a little childish, but I don't mind, she's young..."
    yu "Well, I do mind...I don't want her to touch you."

    scene i90:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0

    p "Haha, I didn't know you were the jealous type."
    yu "Well, I am...don't let her touch you."
    p "Who's acting childish now? You are dating Michael so I can hug whoever I want."
    yu "I'm not dating him and you can't. Period."
    p "Whoooa...is this a taste of how our relationship would be?"
    yu "Nope, this is: get on the bed...now!"
    scene black with dissolve
    scene i91 with dissolve
    pause
    p "This is gonna be good..."
    scene i92 with vpunch
    p "Daaamn!"
    scene i93 with dissolve
    yu "THIS is a taste of how our relatioship would be."
    p "Can I suck them? Just to be sure about the taste part..."
    yu "No, you can't...you prefer my little sister's..."
    p "Haha, what?! You're serious about that, huh? I bet you hated to see me with her the whole night."
    scene i94 with dissolve
    yu "Shut up...and you hated me talking to Michael the entire night, didn't you?"
    p "That was alright, he was our ride, haha...and don't lie, you didn't even pay attention to the guy!"
    yu "Yeah, but he was looking at these..."
    p "Who wouldn't? They're perfect."
    scene i95 with dissolve
    yu "They are, aren't they? You said you wanted to suck them?"
    p "Yes! Come here."
    yu "Not happening, you only get to see them...you know what the steps are to start sucking..."
    p "But..."
    yu "No buts."
    scene i96 with dissolve
    yu "I think I've rewarded you enough...time to sleep."
    p "Whaaat..."
    scene i97 with dissolve
    p "Are you for real?"
    yu "Yeah! You have to work harder for these, I'm not an easy girl."
    p "I love it that you're not...and I've never thought you were, just in case...but..."
    yu "Nope, don't be greedy..."
    yu "Take me out on a date and we'll see...tell you something: you scored some good points after going to my debut."
    scene black with Dissolve(1)
    scene i98 with dissolve
    yu "Don't you want this?"
    p "It definitely feels great to cuddle with you...and your natural scent...mmm..."
    yu "Haha, good night, [p]...Arina, turn off all the lights."
    p "Good night, Yua."
    stop music fadeout 3
    scene black with Dissolve(2)
    pause

    scene i100 with Dissolve(1)
    scene i99 with Dissolve(0.03)
    scene i100 with Dissolve(0.03)
    scene i99 with Dissolve(0.03)
    scene i100 with Dissolve(0.03)
    scene i99 with Dissolve(0.03)
    scene i100 with Dissolve(0.03)
    scene i99 with dissolve
    play music "audio/trackwithbirds2.mp3" fadein 2
    pause
    scene i101 with dissolve
    pause 
    scene i102 with dissolve
    p "Huh?"
    scene i103 with hpunch
    p "Jesus! What the hell?! Yua, wake up!"
    scene i104 with dissolve
    ar "Good morning, sir, I'm Arina."
    p "Arina? The AI? What the hell?!"
    ar "Correction: I'm not THE AI, I'm an assitant. Your presence is required for breakfast."
    yu "Hi, Arina!"
    ar "Good morning, Miss Takase, breakfast is ready."
    yu "We're coming, give us some minutes..."
    scene black with dissolve
    scene i105 with dissolve
    yu "Surprised?"
    p "What the hell was that? Looked like a real person! I'd never seen one of those...robots? Only in the news...in China!"
    yu "Like Fumi said: Cara's family live in the future...gotta go change, see you in a bit, handsome."
    p "Handsome? Treating me like your boyfriend now?"
    scene i106 with dissolve
    pause
    scene black with Dissolve(2)
    scene i107 with dissolve
    p "Good morning, everybody!"
    fu "Someone is in a good mood...Come! Sit here next to me, [p]!"
    yu "Still wearing pajamas? You didn't even open the closet in your room, did you?"
    p "I haven't touched anything, why would I?"
    scene i108 with dissolve
    ka "There's plenty of clothes for our guests in there...you can take whatever you need."
    p "Really? Jeez, I don't know...Cara told me I could take these pajamas and that's more than enough."
    scene i109 with dissolve
    cr "Did I say that?"
    p "Yeah...you see I feel like I'm taking advantage of you..."
    scene i110 with dissolve
    cr "I'm kidding! You're not taking advantage of our trust, don't be silly. It's not a big deal, it's our way to treat our friends: everybody's wearing what they found in their closets in case you didn't notice..."
    cr "It's a Li thing."
    scene i111 with dissolve
    fu "Look what I got!"
    ka "But we don't want to offend you, don't take it as an insult, [p]...we're not bragging, it's just our thing..."
    p "Oh, no, I'm not offended, it's just something new to me...and thank you! I'll check it out before leaving...my clothes from yesterday are smelly, to be honest..."
    ka "Again, take whatever you feel comfortable with."
    scene i112 with dissolve
    ar "What would you like for breakfast, [p]?"
    p "Talking about new things...how do you know my name?"
    scene i113 with dissolve
    ar "Correction: I'm not a thing, I'm Arina. I scan every guest, someone has said your name. It's either [p] or Subject 88, which one would you prefer?"
    p "Why \"Subject 88\"?"
    ar "Eighty-nine people have entered The Lis' residence."
    p "Amazing...errr, a sandwich and some coffee would be fine, Arina, thank you."
    ar "Received."
    scene black with Dissolve(2)
    scene i114 with dissolve
    yu "Thank you so much for everything, Mrs. Li!"
    yu "So soon, honey? It's Sunday, I thought you were staying the whole day..."
    yu "I'd love to, but I have to go to the ice cream shop today, my friend filled in for me yesterday so..."
    scene i115 with dissolve
    fu "Excuse me, Mrs. Li, yesterday you said you could give us a tour around your beautiful home..."
    ka "Sure I did, honey, next time?"
    fu "I'm not leaving yet. Only Yua and Michael have to leave for work, but I can share a taxi later...with [p]!"
    pt "What?"
    ka "Oh, if that's the case, you're more than welcome to stay!"
    scene i116 with dissolve
    fu "We are staying...right, [p]?"
    pt "Why you put me on the spot like that?!"

    stop music fadeout 3

menu:

    "Yua.":
        jump choice86a

    "Fumino.":
        jump choice86b

label choice86a:

    $ choice86a = True

    play music "audio/campfirecalm.mp3"

    p "Next time, Fumi, when Yua can."
    scene i117 with dissolve
    fu "Whaaat..."
    p "We all came together, we should leave together."
    scene i118 with dissolve
    ka "I like that...I hope you kids can come back soon, I'll be waiting..."
    scene black with Dissolve(2)
    scene i120 with dissolve
    yu "You have my number now, call me, ok? I gotta run!"
    p "Oh, I'm calling you, baby!"
    yu "Hehe."
    fu "See you at the club, [p]!"
    p "Bye, Fumi!"
    scene black with Dissolve(1)
    scene i121 with dissolve
    pause
    pt "Vittoria is not answering..."
    scene i122 with dissolve
    pt "I guess she'll call me back if she needs me..."
    stop music fadeout 3
    scene black with Dissolve(3)

    jump ep9

label choice86b:

    $ choice86b = True

    play music "audio/campfirecalm.mp3"

    pt "I don't know how I'm choosing this after \"sleeping\" with Yua..."
    p "I can stay a bit longer, Fumi, if that's what you want."
    scene i119 with dissolve
    fu "Yaaayyyy! We'll have so much fun!"
    pt "Not the smartest move if I wanted something with Yua..."
    scene black with Dissolve(1)
    scene i123 with dissolve
    ka "Errr, do you want to sunbathe first? I'm kind of full, don't feel like walking much just yet..."
    p "Sounds good to me."
    fu "Are there any swimsuits in the closets?"
    scene i124 with dissolve
    ka "Yes, of course, you'll find everything you need in there."
    fu "Sweet!"
    ka "The pool is on the third floor, see you there within 20 minutes..."
    scene i125 with dissolve
    fu "Cara!"
    pt "Noooo, don't tell her!"
    stop music fadeout 3
    scene black with Dissolve(2)
    scene i126 with dissolve
    play music "audio/sportparty4.mp3"
    ar "I've just left some towels and sunscreen on the chairs to your right, [p]."
    p "Thank you, Arina, you're awesome."
    ar "I'll be inside."
    scene i127 with dissolve
    p "Oh, Arina, one question..."
    ar "Yes?"
    scene i128 with dissolve
    p "Sonaldo or Nessi?"
    scene i129 with dissolve
    ar "Sonaldo, what kind of question is that?"
    p "Haha."
    scene i130 with dissolve
    ar "Siuuuu!"
    p "Hahaha, what the hell?!"
    p "Uuuhm, Arina, is Sonaldo the best player in history?"
    scene i131 with dissolve
    ar "\"The best\" is an opinion: Relé won 3 World Cup titles, one at the age of 17, fact. Sonaldo is \"Mister Champions\", he holds the record for most goals and assists; all the best players do play The Champions Cup, but not all the best player participate in the World Cup, facts."
    ar "Nessi's been knocked out of The Champions Cup 14 times, his numbers in direct elimination rounds are these: 26 games played of 27, 4 goals, 1 assist, 3 missed penalties. Facts."
    p "Okay, okay, I can read facts, give me your opinion..."
    ar "In terms of elegance, leadership and talent, I'd choose \"El Diegote\"."
    p "Haha, you goddamn right! I didn't know you were a football expert! That's an interesting pick...he doesn't have the numbers to be the best..."
    ar "That's why I said \"elegance, leadership and talent\" to justify my choice. Not to mention the fouls he received back then would be life without parole nowadays."
    p "Haha...I'm impressed, Arina, I thought you could only analize data...you really are amazing!"
    scene i132 with dissolve
    scene i131 with Dissolve(0.03)
    scene i132 with Dissolve(0.03)
    scene i131 with Dissolve(0.03)
    scene i132 with Dissolve(0.03)
    scene i131 with Dissolve(0.03)
    scene i132 with dissolve
    ar "I need to get inside to avoid overheating."
    p "Oh, ok, Arina, go."
    stop music fadeout 3
    scene black with Dissolve(1)
    scene i133 with dissolve
    pt "The perfect blend of nature and modernity..."
    pt "Even the air you breathe is different..."
    scene i134 with dissolve
    pt "Yua got really mad, she didn't even say goodbye to me...well, what was I expecting?"
    fu "[p]! Look what I found!"
    scene i135 with dissolve
    p "Heeeyyy!"

    play music "audio/fashionstylish4.mp3"

    scene i136:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    pause
    pt "I made the right choice by staying...totally worth it!"
    fu "I can see you like me..."
    p "And I know you like me."

    call screen fupool

    screen fupool():
        modal True

        viewport:

            add "i136"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("fupool1")

label fupool1:

    scene i137:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    pause
    fu "I don't like you anymore: you spent the night with my sister..."
    p "Nothing happened."
    fu "I don't know if I believe you..."
    p "Haha, I'm here, aren't I?"

    scene i138 with dissolve
    ka "That fits you like a glove, sweetheart!"
    fu "Thank you! And you look fantastic, Mrs. Li! What a body!"

    scene i139:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0
    pause
    ka "I try to stay in shape...you know, for a woman my age..."
    p "You look really well, Mrs. Li...oh, Arina left some sunscreen over here..."
    pt "In case you want me to put it on you..."
    ka "Thank you!"

    scene i140 with dissolve
    fu "[p], can you help me put on sunscreen?"
    pt "This girl..."

    scene i141:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause
    pt "I'd rather put some on Cara's mom...Geezz, I'm getting a boner..."
    pt "Haha, what's up with that face, Fumi?"
    p "Yes, Fumi, I can help you with that."

    call screen fupoola

    screen fupoola():
        modal True

        viewport:

            add "i141"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("fupool2")

label fupool2:

    scene i142 with dissolve
    fu "Yaaayyy!"
    stop music fadeout 2
    scene black with Dissolve(1)
    scene i143 with Dissolve(1)
    play music "audio/fashionstylish3.mp3"
    ka "How long have you been together?"
    p "Oh, no, we're not a couple."
    ka "No? You sure act like one..."
    fu "Hehehe."
    scene i144 with dissolve
    p "For doing this, you say? I'm taking it as seriously as I can...not fooling around..."
    ka "Haha, I didn't say you were..."
    fu "We're taking it slow."
    scene i145 with dissolve
    ka "Oh, you're dating..."
    fu "Not there yet..."
    scene i144 with dissolve
    p "We actually met yesterday."
    fu "Hehe, true...I mean, I knew who he was and viceversa, but we formally met yesterday, yeah..."
    ka "That's surprising, you two have a lot of chemistry for a day old relationship... and I know it's not my business, but you do look great together!"
    fu "Thanks!"
    scene i146 with dissolve
    ka "I'm going in and you?"
    fu "I don't want chlorine damaging my hair..."
    scene i147 with dissolve
    ka "This pool isn't deep, if you don't swim, you won't get your hair wet, sweetheart...I'm not swimming either, I just got my hair done yesterday..."

    scene i148:
        ypos -2
        ease 10 ypos 0.0
        ease 10 ypos -2
        ease 10 ypos 0.0

    p "It looks really good, Mrs. Li!"
    p "Your hair, I mean..."
    ka "Thank you!"
    p "You're very welcome!"

    call screen kannapool

    screen kannapool():
        modal True

        viewport:

            add "i148"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("kannapool1")

label kannapool1:

    scene i149 with dissolve
    ka "Look, sweetheart, it's this deep, you can simply stand up."
    fu "Maybe in a few minutes, I'd like to get a little tanned first..."
    ka "You, [p]?"
    p "Same, in a few minutes..."
    pt "Let me enjoy the view first."
    scene i150 with dissolve
    cr "Coming! Make some roooooom!"
    ar "The floor is wet, Cara."
    pt "Oh, boy..."
    scene i151 with dissolve
    ka "Cara, don't run!"
    cr "Too late!"
    pt "She knows it isn't depp, what's she doing?"
    scene i152 with dissolve
    ka "Oh, my God, Cara!"
    pt "Aaaand she ruined the day...it was obvious she would trip..."
    stop music
    play audio "audio/splash2.ogg"  volume 1.5
    scene i153 with vpunch
    scene i153 with vpunch
    pt "She didn't fall on the concrete, fortunately."
    fu "Ouch!"
    scene i154 with dissolve
    ka "Cara, don't play like that!"
    fu "I don't think she's playing!"
    ka "What?!"
    pt "She's supposed to be lighter in water, right?"
    scene i155 with Dissolve(1)
    pause 1
    scene black with dissolve
    scene i156 with dissolve
    fu "Are you sure you're ok, Cara?"
    cr "My head hurts a little, but I'm fine..."
    ka "I'm not taking any chances, you hit your head pretty hard...Ari, call Dr. Schneider."
    ar "Dialing..."
    scene i157 with dissolve
    ka "Oh, my God, thank you very much, son, you acted so quickly! I don't know what would've happened if you hadn't been here..."
    p "I'm here to help in case you need anything else, Mrs. Li..."
    scene i158 with dissolve
    pause 1.5
    scene black with Dissolve(2)
    play music "audio/track15.mp3"
    scene i159 with dissolve
    p "How's cara doing?"
    fu "The doctor's just arrived, I didn't want him to see me wearing this so...wait, you put on new clothes already, are you leaving?"
    p "Yeah, there are some things I have to do today...wanna share a cab? I'll wait for you."
    fu "I'm staying a bit longer, I have nothing to do at home...Mrs. Li said she will send us home with her chauffeur later..."
    p "Mmm, I really need to leave now, but I can wait a few minutes until the doctor is done to say goodbye..."
    fu "It may take a while...Mrs. Li wanted a thorough examination..."
    p "Well, in that case, say goodbye to them...and thank you! Give them thanks for everything."
    scene i160 with dissolve
    pause
    p "Haha."
    scene i161 with dissolve
    p "See you at the club, Fumi."
    fu "I had so much fun, [p]...let's do this again!"
    pt "Yeah, it was going great until Cara showed up, haha..."
    p "Sure, Fumi, we'll do it again."

    stop music fadeout 3
    scene black with Dissolve(3)

    jump ep9

label choice84b:

    $ choice84b = True

    p "You said at Cara's bar, right? Sunny Beach...that's like a 45-minute drive..."
    p "I'm sorry, I'm actually in the middle of something...but best of luck, Yua! Break a leg!"
    scene i22 with dissolve
    fu "Whaaaaaat..."
    yu "Will do! I hope I can see you soon..."
    scene black with Dissolve(2)

    play music "audio/chillsong1.mp3"
    scene i162 with Dissolve(1)
    pause 0.5
    scene i163 with Dissolve(1)
    pause 0.5
    scene i164 with dissolve
    p "Elle..."
    scene i165 with dissolve
    el "[p]! I don't want to believe it..."
    p "It's horrible..."
    scene i166 with dissolve
    el "Natalia says Vittoria went to the morgue...I don't know if we should go there..."

    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene i166 with dissolve
    pt "Shit!"
    p "I don't know if I want to be close to a dead body, Elle, you know after..."
    scene i167 with dissolve
    el "Oh, my God, you're right...I'm so sorry about that."
    p "It's okay."
    scene i168 with dissolve
    na "My parents are with her, Mrs. Wolfe, there's nothing to worry."
    el "I know, honey, but I'm not there...I think I'm going...what are you kids doing?"
    scene i169 with dissolve
    na "You can help me talking to people who come, I really don't want to be repeating myself..."
    pt "You're saying it in front of Elle...this bitch doesn't even try to be polite..."
    p "Ok, I can do that."
    stop music fadeout 3
    scene black with Dissolve(2.5)
    
    scene i170 with dissolve
    play music "audio/welcometothestripclub.ogg"
    na "I'm tired..."
    p "I notice. Did many people come?"
    na "Like six in the hour you were gone..."
    p "You can sleep there, I got you."
    na "I prefer my bed..."
    scene i171 with dissolve
    na "And no offense...I just met you."
    scene i172 with dissolve
    p "What is that supposed to mean? You think I'm going to do something to you? It was you who told me to stay in the first place!"
    na "Chill, dude, sorry...I'm just tired."
    scene i172a with dissolve
    na "Jesus, everybody's so touchy tonight...I want to go home..."
    p "Nobody's stopping you, call a taxi!"
    scene i173 with dissolve
    na "Don't you know women don't want a solution? We just want you to listen."
    p "What?"
    scene i174 with dissolve
    na "Nothing."
    p "Ooofff...I'm not talking to you."
    na "Thanks."
    p "You started the conversation!"
    pt "This bitch is an energy vampire! Going to a morgue sounds like a good plan now..."
    stop music fadeout 3
    scene black with Dissolve(2)
    pause
    uk "Hello?"
    scene i175 with Dissolve(2)
    ba "Hi?"
    scene i176 with Dissolve(2)
    p "Oh, hi, good morning...something happened?"
    ba "We're leaving now and I have to ask you for a big favor...[p], right? Do you have a car?"
    p "I do...where's Vittoria?"
    scene i177 with dissolve
    ba "In her room, she took some sleeping pills...listen, her sister called me yesterday and said she'll be arriving at 1 pm, my husband and I will be busy at that time today...could you pick her up from the airport?"
    p "At 1? What time is it now?"
    ba "Six."
    p "Oh, yeah, yeah, I can do that...I've met her sister before, I remember her..."
    scene i178 with dissolve
    ba "Ginevra's really nice, I'll talk to her and give her your number...don't worry about Vittoria, she'll be sleeping until tomorrow probably..."
    p "Got it...I'm going to sleep a couple hours more...I feel very tired, I don't know why."
    ba "Okay, but don't oversleep, Ginevra will be waiting...I'll be back in the evening..."
    p "Ok, I got this...see you later maybe."    
    scene black with Dissolve(2)
    play music "audio/infrayourattention.mp3"
    scene i179 with dissolve
    pt "The airport looks nicer, more modern!"
    pt "It's been a while since my last trip...let's find her!"
    scene i180 with dissolve
    pt "Easy enough, hehe..."
    pt "Oh, is that her mom?"

    scene i181:
        ypos -1.4
        ease 10 ypos 0.0
        ease 10 ypos -1.4
        ease 10 ypos 0.0
    pause
    pt "So...having a great body is a family thing, eh..."
    gin "Hi, [p], thank you for coming for us!"
    gin "This is my mom, Edwige."
    p "A pleasure to meet you, ma'am."
    ed "Piacere mio."
    pt "Okay, that was sexy..."

    call screen ginair

    screen ginair():
        modal True

        viewport:

            add "i181"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("ginair1")

label ginair1:

    scene i182 with dissolve
    p "Let me help you with your luggage, ladies."
    scene i183 with dissolve
    gin "Are you sure? Is your hand ok?"
    p "Yeah, I'm fine, this is not serious...don't worry about it."
    scene black with dissolve
    scene i184 with dissolve
    ed "Questa non è la macchina di Giuseppe?"
    gin "No, ma."
    scene i185 with dissolve
    gin "I like your car, [p], it's very comfortable and you drive very smoothly."
    p "Oh, thanks, I think it's the car, not my driving. It was my dad's treasure, he liked modifying it...now I just take it to his mechanic..."
    scene i186 with dissolve
    p "Anyway, in case you're wondering, I saw Vittoria last night, but nothing had been confirmed by then. And today, well, she was asleep when I left..."
    p "I still can't believe what the news said about Giuseppe..."
    gin "Let's not mention him, [p], please, we're here for Vittoria."
    scene i187 with dissolve
    p "Oh, sorry..."
    ed "Giuseppe? Era un uomo volgare, non mi è mai piaciuto...ma non avrei mai immaginato che fosse un assassino."
    p "Errr...assassin, you said? I'm just gonna keep driving..."
    gin "You don't want to argue with my mom, trust me."
    p "Nope, I don't."
    scene black with dissolve
    scene i188 with dissolve
    gin "Thank you so much, [p]! It's so nice to know that my sister can count on people like you."
    p "I'd like to do more...I'm relieved now that you and your mom are here...is there anything else I can do to help? I feel like I'm not doing enough..."
    gin "Actually, there is...come, sit with me for a minute."
    scene black with dissolve
    scene i189 with dissolve
    gin "My mom and I were thinking of getting rid of all of Giuseppe's belongings, pictures, everything...I'd like to know your opinion, too...maybe we're being too biased towards my sister..."
    p "I don't know what to say, he's...was part of Vittoria's life...I think that's her decision to make, I wouldn't touch anything..."
    gin "See? It's always good to have another point of view..."
    scene i265 with dissolve
    gin "[p], and one more thing: do you know of someone who could spiritually cleanse this house?"
    p "Someone like who? I don't know who does that...a shaman?"
    gin "A shaman, a priest..."
    p "Mmm...I can find out, I want to help!"
    scene i266 with dissolve
    gin "Okay, I leave it in your hands, thank you! I'll go check if they need me upstairs and let Vittoria know you're here..."
    scene i267 with dissolve
    stop music fadeout 3
    pause
    scene black with dissolve

    play music "audio/coldshower.mp3"

    scene i268a with dissolve
    pt "Who can help me with that? I think my mom has Dean Schuck's number...he was a priest, right?"
    pt "Wait a minute, I've seen a priest talking to Camille in the library from time to time..."
    scene i269a with dissolve
    pt "Yes! Let's call her!"
    scene i270 with dissolve
    jo "Hi, [p]!"
    p "Jo?"
    jo "Yup, Camille forgot her phone here in the house...wanna leave a message?"
    p "Uuuhm, I wanted to ask her about a priest..."
    jo "A priest?"
    p "Yes, I need someone to do a spiritual...house...cleaning...something like that..."
    scene i271 with dissolve
    jo "Hehe, a priest doesn't do that, you need a psychic, a medium!"
    p "A psychic? Are they even real?"
    scene i272 with dissolve
    jo "Of course they are! And you're in luck, my friend: I'm into that world, you know that, right? Divination, smudging, channeling...I just happen to know the right person: a professional healer!"
    p "Professional healer? How do you even become that? Doesn't matter, I trust you...can you call him...her? I'm sending you the address."
    scene i273 with dissolve
    jo "Before I do that, I have a favor to ask: can I go with her? I want to witness the whole ritual! Maybe she senses a spirit, a parasitic entity, something!"
    p "I was thinking of some salt, incense, lavander...not holy water and ghosts, haha...if you want to come, come! Let me know when you are on your way..."
    jo "I hope she can do it today, I'm calling her right now! I was about to get into the pool, but this is a way more exciting plan for a Sunday, haha, thank you, [p]!"
    stop music fadeout 2
    scene black with Dissolve(2)

    play music "audio/thrill.mp3"

    scene i274a with Dissolve(1)
    jo "You should've told me it was in your in-laws' house, I would've worn something more formal."
    p "I don't see anything wrong with your clothes..."
    jo "I'm showing too much."
    scene i275a with dissolve
    p "You have too much, can't hide it."
    jo "Idiot...I've watched the news: that poor woman just lost her husband...after losing her daughter...I should've worn something more appropriate, respectful, darker colors..."
    p "I'm wearing green and Vittoria, yellow..."
    scene i276 with dissolve
    p "And I doubt they'll remember what you're wearing...that lady you brought has a crow on her shoulder! What's her name again?"
    jo "Hagar...I can hear what they are going to say when we leave: \"Why did you bring that crazy old lady and that whore?!\" Argh! I'm going to kill you!"
    p "Nobody's gonna say that, relax."
    scene i277 with dissolve
    pt "Vittoria is on autopilot...I can't tell how she's feeling, she's simply not there..."
    scene black with dissolve
    scene i278 with dissolve
    gin "Wow!"
    scene i279 with dissolve
    ed "Oddio!"
    scene i280a with dissolve
    hag "Someone who's not here loved that painting."
    p "What the hell?"
    scene i281 with dissolve
    gin "V!"
    vi "I've had enough, I told you I didn't want this."
    hag "Some of you are not ready to listen...I should leave."
    scene i282 with dissolve
    ed "Che succede? No, non andare via, per favore."
    hag "Is that Spanish?"
    ed "Spanish, yes! No se vaya, por favor."
    hag "Oh, no, I was just asking...I don't speak Spanish..."
    scene i283 with dissolve
    p "I do...not perfectly, but enough...she says: don't leave, please."
    scene i284 with dissolve
    hag "I'll leave after burning sage to purify this house and don't worry, there are no negative energies in here. I misunderstood the purpose of my visit and made an unnecessary comment, I'm sorry."
    p "Dice que quemará...sage...no sé cómo decirlo, una hierba para purificar, que no siente energías negativas en la casa...y que lamenta su comentario."
    scene i285 with dissolve
    ed "Hablas muy bien español."
    p "Gracias...mi padre me enseñó."
    ed "Y a mí, mi mamá..."
    scene i286 with dissolve
    hag "Don't move, I just saw something."
    p "Huh?"
    scene i287 with dissolve
    hag "Look at me."
    hag "Yes, yes..."
    hag "You are protected: there are two auras near you, besides your own..."
    hag "One male...one female..."
    p "What the hell?!" with vpunch

    stop music
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene i287 with dissolve
    hag "And that's the price you have to pay for that protection."
    p "My God..."
    hag "Don't cry. Every time you do, those spirits become angry. Remember this: Life's an echo."
    scene i288 with dissolve
    hag "I'll go get those herbs, excuse me..."
    pt "Wait! I..."
    jo "I'll help you!"
    scene black with Dissolve(1)
    scene i289 with Dissolve(1)
    gin "So we're supposed to burn those herbs?"
    p "Yup, she said she couldn't do it herself because she wasn't welcome anymore, that it would ruin the cleansing..."
    p "And we have to carry that pot around the house because the smoke has to reach all the rooms..."
    scene i290 with dissolve
    ed "¿Y qué te dijo cuando se te acercó?"
    p "Ah, que hay dos presencias protegiéndome, no sé qué habrá visto...y al final dijo: \"La vida es un eco.\""
    ed "¿Estás protegido? ¡Qué hermoso! Quiero que me diga algo así también! Tienes que darme su número."
    p "Sí, le pido a mi amiga luego."
    scene i291 with dissolve
    gin "Bene, bene, bene, you two are best friends in Spanish now! My mom speaks perfect Spanish!"
    gin "But don't let her fool you, [p], she understands English, she just pretends she doesn't."
    scene i292 with dissolve
    gin "See? Haha."
    scene i293 with dissolve
    ed "No hablo inglés correctamente y detesto sentirme estúpida!"
    p "Entiendo. A nadie le gusta sentirse estúpido, pero equivocarse es la única forma de aprender."
    scene i294 with dissolve
    gin "Questo è esattamente quello che gli dico!"
    scene black with Dissolve(3)

    jump ep9

label annstory:

    stop music fadeout 2
    scene black with Dissolve(2)
    play sound "audio/shortsiren.mp3"
    scene i295 with Dissolve(1)
    play music "audio/sadrock.mp3"
    na "The police is here...they're going to confirm what I told you."
    p "Oh, fuck, I was hoping this was just a bad dream...poor Vittoria..."
    na "Yeah..."
    scene i296 with Dissolve(1)
    pause
    scene i297 with dissolve
    na "Next step: the morgue. Are you going?"
    p "How do you know all that?"
    na "My dad is a former cop, I know the procedure."
    p "Oh...I'm staying, I don't want to see any corpse."
    na "Same here."
    scene black with Dissolve(1)
    scene i171 with dissolve
    na "You can go home if you want, this is going to take hours..."
    scene i173 with dissolve
    p "What will you do?"
    na "Sleep."
    p "Oh, ok...yeah, I think I'm leaving, there's nothing I can do for Vittoria today..."
    scene i170 with dissolve
    na "Or any other day..."
    p "You are very pessimistic, aren't you?"
    na "I've been told."
    scene i174 with dissolve
    p "Well, good luck with that...see ya."
    na "Bye."
    stop music fadeout 3
    scene black with Dissolve(3)
    pause
    scene i259 with Dissolve(1)
    play music "audio/lasvegasgangsta.mp3"
    p "What do you mean he lost everything? Wasn't he...like a billionaire?"
    mt "He had to pay millions in compensations, brother."
    p "Can't he work? The dude could sell literally anything!"
    scene i260 with dissolve
    mt "He's depressed, brother, I'm trying to get him motivated first..."
    scene i261 with dissolve
    p "What about his relatives? They don't want to help him or what?"
    mt "I'm telling you bro, he doesn't want to be seen like this...he's still stupidly proud..."
    p "That pride may be all he has left...I'll send you some money later, dude."
    mt "Thank you, brother, everything counts!"
    scene black with dissolve
    scene i219 with dissolve
    pt "Should I call Ann and tell her? Would this complicate things even more?"
    pt "Perhaps, we're getting too close..."

menu:

    "Do not let that girl go.":
        jump choice87a

    "I won't make her hope for more.":
        jump choice87b


label choice87b:

    $ choice87b = True

    stop music fadeout 3

    pt "There's nothing we can do for The Master anyways...I think it's better to wait a couple weeks for things to cool off...what now?"
    pt "Mmm..."
    scene i219 with hpunch
    pt "Vittoria!"
    pt "It's early to bother her, she must have had a long night...I'll go see her in the afternoon..."
    scene black with Dissolve(2)
    play music "audio/forestambient.mp3"
    scene i262 with dissolve
    gin "Oh, [p]! How have you been? Come in, come in..."
    p "Hello, Ginevra, I'm glad to see you already here..."
    scene i263 with dissolve
    gin "Please, have a seat, my mom is with Vittoria right now..."
    p "Oh, your mom came, too? That's really good, your sister needs her family right now, I'm worried about Vittoria."
    gin "We are, too."
    scene i264 with dissolve
    p "And how is she?"
    gin "I don't know how to put it...in shock? I don't know if she cried all night before we got here, but she is calm right now..."
    p "Well, last night she was in denial at first, but when the police came, she started crying...mmm, do you have any idea how we could help her? That's why I'm here."
    gin "Yes, we were thinking about it during the flight: my mom thinks that a trip back to Italy would help her, at least for some months...in the meantime, I'd stay here getting rid of all of Giuseppe's belongings, pictures, everything..."
    gin "Perhaps, you could help me with that?"
    p "If Vittoria wants that, yeah, sure, I can help."
    pt "But I don't want her to leave..."
    scene i265 with dissolve
    gin "[p], are you Catholic?"
    p "I went to a Catholic school...and university...is there a reason why you're asking?"
    gin "By any chance, do you know a priest who can bless this house? A priest, a pastor, a shaman, someone who can spiritually cleanse this house, that's another thing my mom wants to get done as soon as possible..."
    p "I don't think I do, but I'm sure I can find someone...leave it to me, I want to be helpful!"
    scene i266 with dissolve
    gin "Okay, I leave it in your hands, thank you! I'll go check if they need me upstairs and let Vittoria know you're here..."
    scene i267 with dissolve
    stop music fadeout 3
    pause
    scene black with dissolve

    play music "audio/coldshower.mp3"

    scene i268 with dissolve
    pt "Who can help me with that? I think my mom has Dean Schuck's number...he was a priest, right?"
    pt "Wait a minute, I've seen a priest talking to Camille in the library from time to time..."
    scene i269 with dissolve
    pt "Yes! Let's call her!"
    scene i270 with dissolve
    jo "Hi, [p]!"
    p "Jo?"
    jo "Yup, Camille forgot her phone here in the house...wanna leave a message?"
    p "Uuuhm, I wanted to ask her about a priest..."
    jo "A priest?"
    p "Yes, I need someone to do a spiritual...house...cleaning...something like that..."
    scene i271 with dissolve
    jo "Hehe, a priest doesn't do that, you need a psychic, a medium!"
    p "A psychic? Are they even real?"
    scene i272 with dissolve
    jo "Of course they are! And you're in luck, my friend: I'm into that world, you know that, right? Divination, smudging, channeling...I just happen to know the right person: a professional healer!"
    p "Professional healer? How do you even become that? Doesn't matter, I trust you...can you call him...her? I'm sending you the address."
    scene i273 with dissolve
    jo "Before I do that, I have a favor to ask: can I go with her? I want to witness the whole ritual! Maybe she senses a spirit, a parasitic entity, something!"
    p "I was thinking of some salt, incense, lavander...not holy water and ghosts, haha...if you want to come, come! Let me know when you are on your way..."
    jo "I hope she can do it today, I'm calling her right now! I was about to get into the pool, but this is a way more exciting plan for a Sunday, haha, thank you, [p]!"
    stop music fadeout 2
    scene black with Dissolve(2)

    play music "audio/thrill.mp3"

    scene i274 with Dissolve(1)
    jo "You should've told me it was in your in-laws' house, I would've worn something more formal."
    p "I don't see anything wrong with your clothes..."
    jo "I'm showing too much."
    scene i275 with dissolve
    p "You have too much."
    jo "Idiot...I've watched the news: that poor woman just lost her husband...after losing her daughter...I should've worn something more appropriate, respectful...like you, you're wearing dark colors!"
    scene i276 with dissolve
    p "I doubt they'll remember what you're wearing...that lady you brought has a crow on her shoulder! What's her name again?"
    jo "Hagar...I can hear what they are going to say when we leave: \"Why did you bring that crazy old lady and that whore?!\" Argh! I'm going to kill you!"
    p "Nobody's gonna say that, relax."
    scene i277 with dissolve
    pt "Vittoria is on autopilot...I can't tell how she's feeling, she's simply not there..."
    scene black with dissolve
    scene i278 with dissolve
    gin "Wow!"
    scene i279 with dissolve
    ed "Oddio!"
    scene i280 with dissolve
    hag "Someone who's not here loved that painting."
    p "What the hell?"
    scene i281 with dissolve
    gin "V!"
    vi "I've had enough, I told you I didn't want this."
    hag "Some of you are not ready to listen...I should leave."
    scene i282 with dissolve
    ed "Che succede? No, non andare via, per favore."
    hag "Is that Spanish?"
    ed "Spanish, yes! No se vaya, por favor."
    hag "Oh, no, I was just asking...I don't speak Spanish..."
    scene i283 with dissolve
    p "I do...not perfectly, but enough...she says: don't leave, please."
    scene i284 with dissolve
    hag "I'll leave after burning sage to purify this house and don't worry, there are no negative energies in here. I misunderstood the purpose of my visit and made an unnecessary comment, I'm sorry."
    p "Dice que quemará...sage...no sé cómo decirlo, una hierba para purificar, que no siente energías negativas en la casa...y que lamenta su comentario."
    scene i285 with dissolve
    ed "Hablas muy bien español."
    p "Gracias...mi padre me enseñó."
    ed "Y a mí, mi mamá..."
    scene i286 with dissolve
    hag "Don't move, I just saw something."
    p "Huh?"
    scene i287 with dissolve
    hag "Look at me."
    hag "Yes, yes..."
    hag "You are protected: there are two auras near you, besides your own..."
    hag "One male...one female..."
    p "What the hell?!" with vpunch

    stop music
    play sound "audio/breathwoosh.mp3"

    scene flashback1:
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2.5
        pause 0.0666
        "flashback2"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 2
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6 zoom 1.5
        pause 0.0166
        "flashback1"
        xpos 0.5 ypos 0.6 xanchor 0.5 yanchor 0.6
        pause 0.0166
    pause 0.1162
    scene i287 with dissolve
    hag "And that's the price you have to pay for that protection."
    p "My God..."
    hag "Don't cry. Every time you do, those spirits become angry. Remember this: Life's an echo."
    scene i288 with dissolve
    hag "I'll go get those herbs, excuse me..."
    pt "Wait! I..."
    jo "I'll help you!"
    scene black with Dissolve(1)
    scene i289 with Dissolve(1)
    gin "So we're supposed to burn those herbs?"
    p "Yup, she said she couldn't do it herself because she wasn't welcome anymore, that it would ruin the cleansing..."
    p "And we have to carry that pot around the house because the smoke has to reach all the rooms..."
    scene i290 with dissolve
    ed "¿Y qué te dijo cuando se te acercó?"
    p "Ah, que hay dos presencias protegiéndome, no sé qué habrá visto...y al final dijo: \"La vida es un eco.\""
    ed "¿Estás protegido? ¡Qué hermoso! Quiero que me diga algo así también! Tienes que darme su número."
    p "Sí, le pido a mi amiga luego."
    scene i291 with dissolve
    gin "Bene, bene, bene, you two are best friends in Spanish now? My mom speaks perfect Spanish!"
    gin "But don't let her fool you, [p], she understands English, she just pretends she doesn't."
    scene i292 with dissolve
    gin "See? Haha."
    scene i293 with dissolve
    ed "No hablo inglés correctamente y detesto sentirme estúpida!"
    p "Entiendo. A nadie le gusta sentirse estúpido, pero equivocarse es la única forma de aprender."
    scene i294 with dissolve
    gin "Questo è esattamente quello che gli dico!"
    scene black with Dissolve(3)

    jump ep9ann

label choice87a:
    
    $ choice87a = True

    stop music fadeout 3

    
    scene i220 with dissolve
    pt "Annie..."
    pt "She's such a sweet girl..."
    scene i222 with dissolve
    play music "audio/cutekawai.ogg"
    anth "Oh, my God! Oh, my God! Oh, my God! [p]'s calling me...what do I do?! This's gonna be so awkward..."
    anth "Please, don't bring it up, don't bring it up..."
    scene i221 with dissolve
    anth "Okay, Ann, breathe, you got this..."
    scene i223 with dissolve
    an "Hey, buddie!"
    p "Annie! Good morning! Listen, I've just called Daniel, he says Master Collins doesn't want to see anybody for now...I guess we'll have to wait if we want to help..."
    an "Oh, that, mmm...don't worry, we'll think of something...[p], on a different topic, I have to take Catastrophe to the vet today, do you want to come with us?"
    p "Catastrophe? Haha, that's a cool name...yeah, yeah, I can go, I don't have any plans."
    an "Sweet! Come over around noon, okay?"
    p "Alright, Annie, see you in a bit."
    scene black with Dissolve(1)
    scene i224 with Dissolve(1)
    uk "Hi, Catastrophe, are you in a good mood today?"
    an "He's not, haha, is Dr. Mendes in her office, Leah?"
    scene i225 with dissolve
    le "Yeah, she just got here...he's gained weight, hasn't he?"
    an "Whatcha talkin' bout, Willis?"
    scene i225a with dissolve
    le "Haha, you and your references from the 80s..."
    an "Hehe, you know I love those old TV shows!"
    scene black with dissolve
    scene i226 with dissolve
    dm "Ann! Is your son ready for his vaccines?"
    an "Haha, I don't think he is, but he needs them...and I want you to deworm him, too, Dr. Mendes."
    dm "No problem."
    scene i227 with dissolve
    an "Careful, doctor, my baby's very grumpy today..."
    dm "You're not going to scratch me, right Catastrophe?"
    scene i228 with dissolve
    dm "Of course not! Who's the most adorable cat in the room?"
    an "Haha, he loves you, doctor."
    dm "That or he knows I'll give him his Churu before leaving."
    an "Haha, that too..."
    scene black with dissolve
    scene i229 with dissolve
    an "That was very quick..."
    dm "He's a very healthy cat, you take good care of him...oh, ask Leah for his treat, I don't have any in here."
    an "Hehe, thanks so much, doctor, you're the best!"
    scene i230 with dissolve
    dm "Goodbye."
    p "Bye, Dr. Mendes, maybe I'll bring my cat next time."
    dm "You know where to find us."
    scene black with Dissolve(1)
    scene i231 with dissolve
    an "Thank you for bringing us, [p]!"
    p "No problem, Annie...I liked your vet, she's very caring...mine's more worried about charging me for everything..."
    an "Yeah, Dr. Mendes is very good, that's why I come...she's Vanessa's mother, do you remember Vanessa?"
    p "Vanessa? Mmm, it rings a bell..."
    an "She was at Jessica's birthday party...wearing a red dress..."
    p "Oh, that girl..."
    scene i232 with dissolve
    an "Nothing like her mother, right? Dr. Mendes is super nice and Vanessa is so...insufferable..."
    scene i233 with dissolve
    p "I don't know her very well, but I remember you said you didn't like her...I guess we don't like her then, but we like her mom!"
    scene black with Dissolve(2)
    scene i234 with Dissolve(1)
    an "Are you staying for lunch?"
    p "If I'm welcome..."
    an "You're going to meet my dad..."
    p "That was your plan all along, wasn't it?"
    an "Haha, sure, sure..."
    scene black with dissolve
    scene i235 with dissolve
    an "Catastrophe says thank you!"
    p "Are you sure? I think he's planning my murder..."
    an "Haha, that's his normal face...give me a sec, I'll go find my parents so we can eat together."
    scene i236 with dissolve
    p "Your mom's in the backyard, she's waving at us..."
    stop music fadeout 3
    scene i237 with dissolve
    an "Oh, she's sunbathing...ask her if we're having lunch soon, I'm hungry...I'll go upstairs to find my dad."
    p "All right, I'll talk to your mom..."

    scene i238:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/needunow.mp3"
    pause
    bl "Hi, son, how did it go?"
    pt "Oh, my God!"
    p "Hello, Mrs. Myers, all good: Catastrophe loves his vet and I like spending time with Ann, everybody won!"
    bl "Haha, it was a good day then."
    pt "It's not over yet..."

    call screen blythepool

    screen blythepool():
        modal True

        viewport:

            add "i238"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("blythepool1")

label blythepool1:

    scene i239 with dissolve
    bl "I saw you lifting the carrier, is your hand okay?"
    p "Oh, yeah, yeah...I don't need that bandage anymore, I wear it because I think it looks cool, haha...but thank you for noticing, that was very thoughtful..."
    bl "Thanks to you, you are like your T-shirt: \"Limited Edition\"...my Annie is very lucky to have someone like you...answer me this: are you dating?"
    p "Haha, we're not, we're friends."
    scene i240 with dissolve
    bl "For now, haha...where did she go?"
    p "To find your husband...oh, she wanted to know if we're going to have lunch now or..."
    bl "I can order some pizza if you are hungry...let me sunbathe a little more before she comes...although it's cloudy, haha."
    scene black with dissolve
    scene i241 with dissolve
    pt "Bro!"
    scene i242 with hpunch
    pt "Prrrr..."
    pt "I'd better stop staring at it before Ann sees me..."
    scene i243 with dissolve
    stop music fadeout 3
    an "[p]! I want you to meet my dad."
    scene i244 with dissolve
    p "Hello, sir."
    mat "I'm Matt, nice to finally meet you, [p]."
    p "Finally?"
    mat "Yeah, yeah, my wife and Annie were talking about your match during breakfast...they went to see you yesterday, didn't they?"
    p "They did, yeah...they were very supportive."
    bl "Honey..."

    scene i245:
        ypos -2.0
        ease 10 ypos 0.0
        ease 10 ypos -2.0
        ease 10 ypos 0.0
    play music "audio/fashionstylish1.mp3"
    pause
    bl "Sorry to interrupt...can you order some pizza? The kids are hungry..."
    an "I don't want pizza, mom...I want sushi!"
    mat "We want sushi!"
    bl "We have a guest today, Annie...why don't you ask [p] what he would like to have?"
    pt "What I would like?"

    call screen blythepool1

    screen blythepool1():
        modal True

        viewport:

            add "i245"
            mousewheel True

        imagebutton auto "mousescroll_%s":
            focus_mask True
            hovered SetVariable("screen_tooltip", "mousescroll")
            unhovered SetVariable("screen_tooltip", "")
            action Jump ("blythepool2")

label blythepool2:

    scene i246 with vpunch
    stop music
    play sound "audio/djstop.mp3"
    p "Jesus!"
    p "Can I help you?"
    p "Errr...sushi is fine..."
    scene i247 with dissolve
    an "Yes! Victory dance!"
    pt "Victory dance? That reminds me of..."
    mat "I'm calling Naruto's!"
    scene black with Dissolve(1)
    scene i248 with Dissolve(1)
    play music "audio/reflecting.mp3"
    mat "Ann told me you two met at St. Francis, [p]..."
    p "Yes, sir, last semester, we took a business class together..."
    bl "And now you want to play soccer professionally, right?"
    p "I want to try at least...I'm not a pro yet..."
    mat "I'm too lazy for sports...training every single day must be really hard, exhausting..."
    p "Mmm...I've heard that \"Discipline weighs ounces, regret weighs tons.\""
    scene i249 with dissolve
    bl "Wooow! I loved it! I should welcome you to the family just because of that quote!"
    an "Mom!"
    p "Haha, it's not mine, I heard it somewhere..."
    scene i250 with dissolve
    mat "Still, that's the right mindset in this household! I may not be sporty, but I do code every day! If you ever want to date my daughter, you have my blessing!"
    an "Dad!"
    p "Haha...I'm gonna need Catastrophe's blessing, too, sir."
    mat "Now that's a different story, haha..."
    mat "And Matt, call me Matt, no sir."
    stop music fadeout 3
    scene black with Dissolve(2)
    scene i251 with Dissolve(1)
    play music "audio/cutekawai.ogg"
    an "I'm sorry, [p], I know my parents can be awkward sometimes..."
    p "Sorry? What are you talking about? I like them!"
    scene i252 with dissolve
    an "Like them?"
    p "Yeah!"
    scene i253 with dissolve
    an "Uuuhm...did you like what they were saying...about us?"
    p "It was all right...I liked your kiss more."
    scene i254 with dissolve
    an "And you had to say it..."
    p "Haha."
    an "I don't want to talk about it, it's embarrassing!"
    p "Why? I said I liked it...same way I like spending my Sunday with you..."
    scene i255 with dissolve
    p "Relax, Annie..."
    scene i256 with dissolve
    an "Now I'm being awkward...I like spending time with you, too, maybe we could keep hanging out...just like today..."
    p "I'd like that very much...why are you making it weird? You're not gonna kiss me again, are you?"
    scene i257 with dissolve
    an "Asshole...you think you all that, don't you?"
    p "Haha...stop being weird!"
    scene i258 with dissolve
    mat "Gotcha! Keep the cage open, you two birdies!"
    an "Dad!"
    stop music fadeout 3
    scene black with Dissolve(3)

    jump ep9ann

    
